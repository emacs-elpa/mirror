;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bicycle" "1.2.1"
  "Cycle outline and code visibility."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/tarsius/bicycle"
  :commit "b638dcc3945950d05400466c7166d0c941f18694"
  :revdesc "v1.2.1-0-gb638dcc39459"
  :keywords '("outlines")
  :authors '(("Jonas Bernoulli" . "emacs.bicycle@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.bicycle@jonas.bernoulli.dev")))
