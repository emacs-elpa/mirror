;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "window-purpose" "1.8.1"
  "Purpose-based window management for Emacs."
  '((emacs      "24.4")
    (let-alist  "1.0.3")
    (imenu-list "0.1"))
  :url "https://github.com/bmag/emacs-purpose"
  :commit "bb462f12f836414425edac32ebd069b4fd5b98d4"
  :revdesc "bb462f12f836"
  :keywords '("frames"))
