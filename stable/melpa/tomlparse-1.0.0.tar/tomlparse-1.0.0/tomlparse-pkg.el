;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tomlparse" "1.0.0"
  "A straight-forward tree sitter based parser for toml data."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/tomlparse.el"
  :commit "637acb0a1e410b4db9ebe91598fb782c8e6c5ee9"
  :revdesc "637acb0a1e41"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
