;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-cscope" "0.1.1"
  "Helm interface for xcscope.el."
  '((xcscope "1.0")
    (helm    "1.6.7")
    (cl-lib  "0.5")
    (emacs   "24.1"))
  :url "https://github.com/alpha22jp/helm-cscope.el"
  :commit "b82db54071bd2d1c77db2e648f8b4e61b1abe288"
  :revdesc "b82db54071bd"
  :keywords '("cscope" "helm")
  :authors '(("alpha22jp" . "alpha22jp@gmail.com"))
  :maintainers '(("alpha22jp" . "alpha22jp@gmail.com")))
