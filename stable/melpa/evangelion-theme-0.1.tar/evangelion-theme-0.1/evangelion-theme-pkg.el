;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evangelion-theme" "0.1"
  "A purple colorscheme inspired by neon genesis evangelion."
  '((emacs "27.1"))
  :url "https://github.com/crmsnbleyd/evangelion-theme"
  :commit "1255e20763c2d864f68d42493bddedb7ff9e0899"
  :revdesc "1255e20763c2"
  :keywords '("faces" "theme")
  :authors '(("Andrew Jose" . "mail@drewsh.com"))
  :maintainers '(("Andrew Jose" . "mail@drewsh.com")))
