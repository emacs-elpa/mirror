;;; evangelion-theme.el --- a purple colorscheme inspired by neon genesis evangelion -*- lexical-binding: t; -*-
;; Package-Version: 0.1
;; Package-Revision: 1255e20763c2

;; Copyright (C) 2024 Andrew Jose, xero harrison

;; SPDX-License-Identifier: GPL-3.0-or-later
;; Author: Andrew Jose <mail@drewsh.com>
;; Maintainer: Andrew Jose <mail@drewsh.com>
;; URL: https://github.com/crmsnbleyd/evangelion-theme
;; Package-Requires: ((emacs "27.1"))
;; Keywords: faces, theme
