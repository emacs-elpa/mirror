;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-act" "1.0"
  "Commands that let avy act from a distance."
  '((avy         "0.5.0")
    (back-button "0.6.8")
    (emacs       "29.1"))
  :url "https://gitlab.com/nameiwillforget/avy-act"
  :commit "bd73d847d23c18fa9d63d9a523fb61339ed4bb27"
  :revdesc "bd73d847d23c"
  :keywords '("tools" "convenience")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
