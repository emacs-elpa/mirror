;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tf2-conf-mode" "0.2"
  "TF2 Configuration files syntax highlighting."
  ()
  :url "https://github.com/wynro/emacs-tf2-conf-mode"
  :commit "868516217c94dc741272f0fbfd2f7886be4897c1"
  :revdesc "868516217c94"
  :keywords '("languages")
  :authors '(("Guillermo Robles" . "guillerobles1995@gmail.com"))
  :maintainers '(("Guillermo Robles" . "guillerobles1995@gmail.com")))
