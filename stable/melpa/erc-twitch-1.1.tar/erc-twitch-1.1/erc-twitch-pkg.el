;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-twitch" "1.1"
  "Support for Twitch emotes for ERC."
  '((json "1.3")
    (erc  "5.0"))
  :url "https://github.com/vibhavp/erc-twitch"
  :commit "6938191c787d66fef4c13674e0a98a9d64eff364"
  :revdesc "6938191c787d"
  :keywords '("twitch" "erc" "emotes")
  :authors '(("Vibhav Pant" . "vibhavp@gmail.com"))
  :maintainers '(("Vibhav Pant" . "vibhavp@gmail.com")))
