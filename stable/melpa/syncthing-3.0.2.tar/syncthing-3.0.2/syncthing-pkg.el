;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syncthing" "3.0.2"
  "Client for Syncthing."
  '((emacs "27.1"))
  :url "https://github.com/KeyWeeUsr/emacs-syncthing"
  :commit "c650aa6ce2c6f594deb7e89645f1de6295de953c"
  :revdesc "3.0.2-0-gc650aa6ce2c6"
  :keywords '("convenience" "syncthing" "sync" "client" "view")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
