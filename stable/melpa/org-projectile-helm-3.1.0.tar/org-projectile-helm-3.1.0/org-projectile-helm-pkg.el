;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-projectile-helm" "3.1.0"
  "Helm functions for org-projectile."
  '((org-projectile "1.0.0")
    (helm           "2.3.1")
    (emacs          "25"))
  :url "https://github.com/IvanMalison/org-projectile"
  :commit "214a6068c467323a795b27996c1e7b75ae42dc68"
  :revdesc "214a6068c467"
  :keywords '("org" "projectile" "todo" "helm" "outlines")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
