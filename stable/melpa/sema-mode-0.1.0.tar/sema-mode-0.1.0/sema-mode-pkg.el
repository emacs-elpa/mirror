;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sema-mode" "0.1.0"
  "Major mode for editing Sema files."
  '((emacs "25.1"))
  :url "https://github.com/helgesverre/sema"
  :commit "9cd090b27ee0d5d6977399d2f29e46e38a334eed"
  :revdesc "9cd090b27ee0"
  :keywords '("languages" "lisp"))
