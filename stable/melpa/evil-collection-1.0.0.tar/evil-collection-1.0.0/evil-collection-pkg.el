;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "1.0.0"
  "A set of keybindings for Evil mode."
  '((emacs "26.3")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "4ab182ddf139f0df2b5da2e745ad0aad195fb23f"
  :revdesc "4ab182ddf139"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
