;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-sql-connect" "0.0.1"
  "Choose a database to connect to via Helm."
  '((helm "0.0.0"))
  :url "https://github.com/eric-hansen/helm-sql-connect"
  :commit "5919083fc206b08c657d796e18671b69b1afd366"
  :revdesc "5919083fc206"
  :keywords '("tools" "convenience" "comm")
  :authors '(("Eric Hansen" . "hansen.c.eric@gmail.com"))
  :maintainers '(("Eric Hansen" . "hansen.c.eric@gmail.com")))
