;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indium" "2.1.7"
  "JavaScript Awesome Development Environment."
  '((emacs               "25")
    (seq                 "2.16")
    (js2-mode            "20140114")
    (js2-refactor        "0.9.0")
    (company             "0.9.0")
    (json-process-client "0.2.0"))
  :url "https://github.com/NicolasPetton/indium"
  :commit "7211c9f18b397c3dde713c33495a39de3fcd9998"
  :revdesc "7211c9f18b39"
  :keywords '("tools" "javascript")
  :authors '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")))
