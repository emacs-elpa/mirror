;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-hugo" "0.12.2"
  "Hugo Markdown Back-End for Org Export Engine."
  '((emacs  "26.3")
    (tomelr "0.4.3"))
  :url "https://ox-hugo.scripter.co"
  :commit "af3d0cdf8c672be498d54bc9efdd0e40b2528602"
  :revdesc "af3d0cdf8c67"
  :keywords '("org" "markdown" "docs")
  :authors '(("Kaushal Modi" . "kaushal.modi@gmail.com")
             ("Matt Price" . "moptop99@gmail.com"))
  :maintainers '(("Kaushal Modi" . "kaushal.modi@gmail.com")
                 ("Matt Price" . "moptop99@gmail.com")))
