;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cursor-flash" "1.0"
  "Highlight the cursor on buffer/window-switch."
  '((emacs "24.3"))
  :url "https://github.com/Boruch-Baum/emacs-cursor-flash"
  :commit "638a09afa11402cbee374407c6347e003026fae7"
  :revdesc "638a09afa114"
  :keywords '("convenience" "faces" "maint"))
