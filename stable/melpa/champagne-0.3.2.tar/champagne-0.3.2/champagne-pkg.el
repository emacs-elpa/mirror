;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "champagne" "0.3.2"
  "Graphical countdowns."
  '((emacs    "28.1")
    (posframe "1.4.2"))
  :url "https://github.com/positron-solutions/champagne"
  :commit "42ef0451e4abe800f047583c4c3b04e51b29d5ee"
  :revdesc "42ef0451e4ab"
  :keywords '("games")
  :authors '(("Psionic K" . "contact@positron.solutions"))
  :maintainers '(("Psionic K" . "contact@positron.solutions")))
