;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-typst" "1.0.0"
  "Typst support for citar."
  '((emacs "29.1")
    (citar "1.4"))
  :url "https://codeberg.org/ashton314/citar-typst"
  :commit "5ce419484e3bb27d8f3ba116ce9d1fd959fc549b"
  :revdesc "5ce419484e3b"
  :authors '(("Ashton Wiersdorf" . "https://lambdaland.org/"))
  :maintainers '(("Ashton Wiersdorf" . "https://lambdaland.org/")))
