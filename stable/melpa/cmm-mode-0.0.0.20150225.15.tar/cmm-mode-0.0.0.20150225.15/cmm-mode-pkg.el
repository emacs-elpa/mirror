;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmm-mode" "0.0.0.20150225.15"
  "Major mode for C-- source code."
  ()
  :url "https://github.com/bgamari/cmm-mode"
  :commit "c3ad514dff3eb30434f6b20d953276d4c00de1ee"
  :revdesc "c3ad514dff3e")
