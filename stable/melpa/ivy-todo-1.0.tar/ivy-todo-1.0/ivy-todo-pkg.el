;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-todo" "1.0"
  "Manage org-mode TODOs with ivy."
  '((ivy   "0.8.0")
    (emacs "24"))
  :url "https://github.com/Kungsgeten/ivy-todo"
  :commit "33bf7426fde989fbf1af6811dc0d5e7a1e7dad83"
  :revdesc "33bf7426fde9"
  :keywords '("convenience")
  :authors '(("Erik Sjöstrand" . "sjostrand.erik@gmail.com"))
  :maintainers '(("Erik Sjöstrand" . "sjostrand.erik@gmail.com")))
