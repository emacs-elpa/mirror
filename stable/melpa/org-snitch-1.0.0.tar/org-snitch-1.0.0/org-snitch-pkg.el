;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-snitch" "1.0.0"
  "Project-specific org-capture and link faces."
  '((emacs "28.1"))
  :url "https://github.com/morazotti/org-snitch"
  :commit "dfe8812bb37cd1c1bd959c5396a1e69678e41dce"
  :revdesc "dfe8812bb37c"
  :keywords '("org" "project" "outlines")
  :authors '(("Nícolas Morazotti" . "nicolas.morazotti@gmail.com"))
  :maintainers '(("Nícolas Morazotti" . "nicolas.morazotti@gmail.com")))
