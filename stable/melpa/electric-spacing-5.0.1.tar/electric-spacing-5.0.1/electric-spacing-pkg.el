;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-spacing" "5.0.1"
  "Insert operators with surrounding spaces smartly."
  ()
  :url "https://github.com/xwl/electric-spacing"
  :commit "9d0f8a213133f2619a4e9dfbba3b00d4348c07b0"
  :revdesc "9d0f8a213133"
  :authors '(("William Xu" . "william.xwl@gmail.com"))
  :maintainers '(("William Xu" . "william.xwl@gmail.com")))
