;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jquery-doc" "1.10"
  "JQuery api documentation interface for emacs."
  ()
  :url "https://github.com/ananthakumaran/jquery-doc.el"
  :commit "13fb21bc084dc0a1ed733c078c2cf12fe5c75159"
  :revdesc "13fb21bc084d"
  :keywords '("docs" "jquery")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
