;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubernetes-helm" "1.0"
  "Extension for controlling helm, the package manager for kubernetes."
  '((yaml-mode "")
    (emacs     "26.1"))
  :url "https://github.com/abrochard/kubernetes-helm"
  :commit "2e4b6dfa101e78910bf4d08576188499acd1cdb4"
  :revdesc "2e4b6dfa101e"
  :keywords '("kubernetes" "helm" "k8s"))
