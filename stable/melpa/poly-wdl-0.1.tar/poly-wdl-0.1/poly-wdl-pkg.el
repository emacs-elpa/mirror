;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-wdl" "0.1"
  "Polymode for WDL."
  '((emacs    "25")
    (polymode "0.2")
    (wdl-mode "20170709"))
  :url "https://github.com/jmonlong/poly-wdl"
  :commit "60752647cf1740baa69879878f5a28387dd8b22e"
  :revdesc "60752647cf17"
  :keywords '("languages")
  :authors '(("Jean Monlong" . "jean.monlong@gmail.com"))
  :maintainers '(("Jean Monlong" . "jean.monlong@gmail.com")))
