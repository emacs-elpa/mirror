;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noman" "0.6"
  "Read command line help without a man page."
  '((emacs "29.1"))
  :url "https://github.com/andykuszyk/noman.el"
  :commit "953e3761b05874dee49952fad63ce1cb3c91d707"
  :revdesc "953e3761b058"
  :keywords '("docs")
  :authors '(("Andy Kuszyk" . "emacs@akuszyk.com"))
  :maintainers '(("Andy Kuszyk" . "emacs@akuszyk.com")))
