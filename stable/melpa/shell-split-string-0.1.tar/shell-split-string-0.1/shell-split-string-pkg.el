;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-split-string" "0.1"
  "Split strings using shell-like syntax."
  ()
  :url "https://github.com/10sr/shell-split-string-el"
  :commit "6d01c9249853fe1f8fd925ee80f97232d4e3e5eb"
  :revdesc "6d01c9249853"
  :keywords '("utility" "library" "shell" "string")
  :authors '(("10sr" . "8.slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8.slashes+el[at]gmail[dot]com")))
