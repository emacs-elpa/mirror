;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tql-mode" "0.1"
  "TQL mode."
  '((emacs "24"))
  :url "https://github.com/tiros-dev/tql-mode"
  :commit "f224927dc191c837442df8cdb3e01c86495d6a36"
  :revdesc "f224927dc191"
  :keywords '("languages" "tql")
  :authors '(("Sean McLaughlin" . "seanmcl@gmail.com"))
  :maintainers '(("Sean McLaughlin" . "seanmcl@gmail.com")))
