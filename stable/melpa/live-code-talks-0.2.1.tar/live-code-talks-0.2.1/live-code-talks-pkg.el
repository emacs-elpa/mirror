;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-code-talks" "0.2.1"
  "Support for slides with live code in them."
  '((emacs                    "24")
    (cl-lib                   "0.5")
    (narrowed-page-navigation "0.1"))
  :url "https://github.com/david-christiansen/live-code-talks"
  :commit "3a2ecdb49b2651d87999d4cad56ba8f1004c7a99"
  :revdesc "3a2ecdb49b26"
  :keywords '("docs" "multimedia")
  :authors '(("David Raymond Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Raymond Christiansen" . "david@davidchristiansen.dk")))
