;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "say-what-im-doing" "0.2"
  "Dictate what you're doing with text to speech."
  ()
  :url "https://github.com/benaiah/say-what-im-doing"
  :commit "4acc16360a29646040b51db158ba7fdeb711449d"
  :revdesc "4acc16360a29"
  :keywords '("text to speech" "dumb" "funny"))
