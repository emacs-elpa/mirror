;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-x" "1.0"
  "Python.el extras for interactive evaluation."
  '((python  "0.24")
    (folding "0"))
  :url "https://github.com/wavexx/python-x.el"
  :commit "e606469aafec2e6beda8c589540b88a5a6f6f33f"
  :revdesc "v1.0-0-ge606469aafec"
  :keywords '("python" "eval" "folding")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
