;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "teletext-yle" "0.1.0"
  "Teletext provider for Finnish national network YLE."
  '((emacs    "24.3")
    (teletext "0.1"))
  :url "https://github.com/lassik/emacs-teletext-yle"
  :commit "d4bd713e8a5d6145d4a13fb97b7a6c4c5140d4e6"
  :revdesc "d4bd713e8a5d"
  :keywords '("comm" "help" "hypermedia")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
