;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linum-relative" "0.6"
  "Display relative line number in emacs."
  ()
  :url "https://github.com/coldnew/linum-relative"
  :commit "896df4b40c1e1eb59f55fcee48a1543f0ccd724e"
  :revdesc "896df4b40c1e"
  :keywords '("converience")
  :authors '(("coldnew" . "coldnew.tw@gmail.com"))
  :maintainers '(("coldnew" . "coldnew.tw@gmail.com")))
