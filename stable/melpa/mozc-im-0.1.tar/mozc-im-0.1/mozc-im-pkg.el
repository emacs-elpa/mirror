;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc-im" "0.1"
  "Mozc with input-method-function interface."
  '((mozc "0"))
  :url "https://github.com/d5884/mozc-im"
  :commit "9fca4cf0d6bbcee202fbb7b2884dacb45f317295"
  :revdesc "9fca4cf0d6bb"
  :keywords '("i18n" "extentions")
  :authors '(("Daisuke Kobayashi" . "d5884jp@gmail.com"))
  :maintainers '(("Daisuke Kobayashi" . "d5884jp@gmail.com")))
