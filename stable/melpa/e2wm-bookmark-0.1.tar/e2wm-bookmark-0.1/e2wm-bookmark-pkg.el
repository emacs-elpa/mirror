;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2wm-bookmark" "0.1"
  "Bookmark plugin for e2wm.el."
  '((e2wm "1.2"))
  :url "https://github.com/myuhe/e2wm-bookmark.el"
  :commit "9699371e87584491bfbf9fbea4f63127ec2dc2e2"
  :revdesc "9699371e8758"
  :keywords '("window manager" "convenience" "e2wm"))
