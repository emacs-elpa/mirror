;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-reticulate" "1.0.0"
  "Babel Functions for reticulate."
  '((org   "9.4")
    (emacs "24.4"))
  :url "https://github.com/jackkamm/ob-reticulate"
  :commit "e4a8cedd8efb5aa39b8ab332f9da7717a9563271"
  :revdesc "e4a8cedd8efb"
  :keywords '("literate programming" "reproducible research" "r" "statistics" "languages" "outlines" "processes"))
