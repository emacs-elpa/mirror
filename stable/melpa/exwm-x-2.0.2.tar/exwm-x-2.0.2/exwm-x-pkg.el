;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-x" "2.0.2"
  "A derivative wm based on EXWM (emacs x window manager)."
  '((cl-lib "0.5")
    (async  "1.6")
    (exwm   "0.22"))
  :url "https://github.com/tumashu/exwm-x"
  :commit "8fd00a0ca586e1c80d08209919f1414b448bc228"
  :revdesc "8fd00a0ca586"
  :keywords '("window-manager" "exwm")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
