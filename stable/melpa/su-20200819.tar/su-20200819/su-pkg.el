;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "su" "20200819"
  "Automatically read and write files as users."
  '((emacs "26.1"))
  :url "https://github.com/PythonNut/su.el"
  :commit "dcb5a5c11aeb1a3ec525e82c2771f9928f62bfaa"
  :revdesc "dcb5a5c11aeb"
  :keywords '("convenience" "helm" "fuzzy" "flx")
  :authors '(("PythonNut" . "pythonnut@pythonnut.com"))
  :maintainers '(("PythonNut" . "pythonnut@pythonnut.com")))
