;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rcirc-groups" "0.5"
  "[No description available]."
  ()
  :url "http://pgsql.tapoueh.org/elisp/rcirc"
  :commit "f62fd450dbd3381e38bdfa6df90a95c8175bd69f"
  :revdesc "f62fd450dbd3"
  :keywords '("irc" "rcirc" "notify")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
