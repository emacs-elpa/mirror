;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbdb" "3.2"
  "Core of BBDB."
  '((emacs "24"))
  :commit "f18720ff5cd963a0bf6fc0e41293e50c0172b8ae"
  :revdesc "v3.2-0-gf18720ff5cd9")
