;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clear-text" "0.1"
  "Make you use clear text."
  ()
  :url "https://github.com/xuchunyang/clear-text.el"
  :commit "bf667d62b4baae5ca5a5cf959f4cd1c33535223e"
  :revdesc "bf667d62b4ba"
  :keywords '("convenience")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
