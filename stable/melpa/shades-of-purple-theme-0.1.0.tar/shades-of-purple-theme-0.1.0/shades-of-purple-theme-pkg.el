;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shades-of-purple-theme" "0.1.0"
  "A theme with bold shades of purple."
  ()
  :url "https://github.com/arturovm/shades-of-purple-emacs"
  :commit "c64c91892737b583d7740d2af6fa296dfa73f925"
  :revdesc "c64c91892737"
  :authors '(("Arturo Vergara" . "hello@dead.computer"))
  :maintainers '(("Arturo Vergara" . "hello@dead.computer")))
