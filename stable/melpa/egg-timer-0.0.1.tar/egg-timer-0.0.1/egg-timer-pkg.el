;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "egg-timer" "0.0.1"
  "Commonly used intervals for setting timers while working."
  '((emacs "24.1"))
  :url "https://github.com/wpcarro/egg-timer.el"
  :commit "9e1294f44e33265b2d92cbd1374bbddbcc551949"
  :revdesc "9e1294f44e33"
  :authors '(("William Carroll" . "wpcarro@gmail.com"))
  :maintainers '(("William Carroll" . "wpcarro@gmail.com")))
