;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cider-hydra" "0.1.0"
  "Hydras for CIDER."
  '((cider "0.18.0")
    (hydra "0.13.0"))
  :url "https://github.com/clojure-emacs/cider-hydra"
  :commit "5956c3909cd9beae11f64973e4f0d830cea7860d"
  :revdesc "5956c3909cd9"
  :keywords '("convenience" "tools")
  :authors '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com"))
  :maintainers '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com")))
