;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rats" "0.2.0"
  "Rapid testing suite for Go."
  '((s       "1.10.0")
    (go-mode "1.3.1")
    (cl-lib  "0.5"))
  :url "https://github.com/ane/rats.el"
  :commit "8ad4023a4b9b00c1224b10b0060f6dc60b4814a4"
  :revdesc "0.2.0-0-g8ad4023a4b9b"
  :keywords '("convenience")
  :authors '(("Antoine Kalmbach" . "ane@iki.fi"))
  :maintainers '(("Antoine Kalmbach" . "ane@iki.fi")))
