;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "p-search" "1.0.0"
  "Emacs Search Tool Aggregator."
  '((emacs  "29.1")
    (compat "29.1"))
  :url "https://github.com/zkry/p-search"
  :commit "4cab2337796e92311894149d87f26f576b997298"
  :revdesc "4cab2337796e"
  :keywords '("tools"))
