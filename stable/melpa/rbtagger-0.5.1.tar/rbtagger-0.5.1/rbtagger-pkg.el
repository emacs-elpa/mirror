;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rbtagger" "0.5.1"
  "Ruby tagging tools."
  '((emacs "25.1"))
  :url "https://www.github.com/thiagoa/rbtagger"
  :commit "650c428ef145ce697f02ef12cfadd9deb82b856f"
  :revdesc "650c428ef145"
  :keywords '("languages" "tools")
  :authors '(("Thiago Araújo" . "thiagoaraujos@gmail.com"))
  :maintainers '(("Thiago Araújo" . "thiagoaraujos@gmail.com")))
