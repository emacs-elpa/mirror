;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jumblr" "0.0.1"
  "[No description available]."
  '((s    "1.8.0")
    (dash "2.2.0"))
  :url "https://github.com/mkmcc/jumblr"
  :commit "45d6621f04947233b19589e4c93133af22872241"
  :revdesc "45d6621f0494"
  :keywords '("anagram" "word game" "games")
  :authors '(("Mike McCourt" . "mkmcc@astro.berkeley.edu"))
  :maintainers '(("Mike McCourt" . "mkmcc@astro.berkeley.edu")))
