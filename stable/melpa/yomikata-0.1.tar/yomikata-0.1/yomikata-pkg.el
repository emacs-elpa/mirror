;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yomikata" "0.1"
  "Annotates text with furigana tooltips."
  '((emacs "29.1"))
  :url "https://example.com"
  :commit "43d3d910da01c4b193e272450af915c63588fa41"
  :revdesc "43d3d910da01"
  :keywords '("i18n" "mouse" "text"))
