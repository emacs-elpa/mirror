;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "power-mode" "0.1.0"
  "Imbue Emacs with power!."
  '((emacs "26.1"))
  :url "https://github.com/elizagamedev/power-mode.el"
  :commit "313698d9c7766c17b077a70b31a2d0f52496d767"
  :revdesc "v0.1.0-0-g313698d9c776"
  :keywords '("games"))
