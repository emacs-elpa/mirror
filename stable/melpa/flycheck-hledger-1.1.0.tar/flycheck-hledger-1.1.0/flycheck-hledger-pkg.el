;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-hledger" "1.1.0"
  "Flycheck module to check hledger journals."
  '((emacs    "27.1")
    (flycheck "31"))
  :url "https://github.com/DamienCassou/flycheck-hledger/"
  :commit "62e4f1a0e0b6a2f40c7ac303b8b27755957682ac"
  :revdesc "v1.1.0-0-g62e4f1a0e0b6"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
