;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsist-view" "0.1"
  "Mode for viewing emacsist.com."
  ()
  :url "https://github.com/lujun9972/emacsist-view"
  :commit "fd1f0a8c48af6e390ec27a179af3b8c8bd3c47b6"
  :revdesc "fd1f0a8c48af"
  :keywords '("convenience" "usability")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
