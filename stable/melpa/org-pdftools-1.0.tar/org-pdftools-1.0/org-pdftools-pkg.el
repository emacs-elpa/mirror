;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-pdftools" "1.0"
  "Support for links to documents in pdfview mode."
  '((org       "9.3")
    (pdf-tools "1.0"))
  :url "https://github.com/fuxialexander/org-pdftools"
  :commit "ebcd6a8d5be006235dc170ba28ca9d92a032a0ef"
  :revdesc "ebcd6a8d5be0"
  :keywords '("org" "pdf-tools")
  :authors '(("Alexander Fu Xi" . "fuxialexander@gmail.com"))
  :maintainers '(("Alexander Fu Xi" . "fuxialexnader@gmail.com")))
