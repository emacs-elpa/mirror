;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thinks" "1.13"
  "Insert text in a think bubble."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/davep/thinks.el"
  :commit "60c3d0adaabe78ea705466077fcdb2f7dcb15dde"
  :revdesc "60c3d0adaabe"
  :keywords '("convenience" "quoting")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
