;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-agenda-daytime-mode" "0.0.3"
  "Display the time clocked today in the modeline."
  '((org   "9.6.18")
    (emacs "26.1"))
  :url "https://www.draketo.de/software/emacs-daytime"
  :commit "f10c7b92a5b2a25f2300b885c2c70526ada50d9c"
  :revdesc "f10c7b92a5b2"
  :keywords '("org" "lisp" "clock" "time" "agenda")
  :authors '(("Arne Babenhauserheide" . "arne_bab@web.de"))
  :maintainers '(("Arne Babenhauserheide" . "arne_bab@web.de")))
