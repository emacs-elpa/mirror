;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "myrddin-mode" "0.1"
  "Major mode for editing Myrddin source files."
  '((emacs "24.3"))
  :url "https://git.sr.ht/~jakob/myrddin-mode"
  :commit "b996da5e3bae842eacba4b3e429899bb841b077e"
  :revdesc "v0.1-0-gb996da5e3bae"
  :keywords '("languages")
  :authors '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org"))
  :maintainers '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org")))
