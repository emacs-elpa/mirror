;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-control" "0.4.0"
  "Management for indentation level."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/indent-control"
  :commit "fb8b9772effa8206d82be9c8e597f6dd5f4ceaec"
  :revdesc "fb8b9772effa"
  :keywords '("convenience" "control" "indent" "tab" "generic" "level")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
