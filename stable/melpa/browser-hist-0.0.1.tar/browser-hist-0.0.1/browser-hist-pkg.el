;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browser-hist" "0.0.1"
  "Search through the Browser history."
  '((emacs "27.1"))
  :url "https://github.com/agzam/browser-hist.el"
  :commit "3e80044f9049a817195fb3eb37d586214cc6ed16"
  :revdesc "3e80044f9049"
  :keywords '("convenience" "hypermedia" "matching" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
