;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idle-require" "1.0"
  "Load elisp libraries while Emacs is idle."
  ()
  :url "http://nschum.de/src/emacs/idle-require/"
  :commit "7cc85c48c338e790006a29d20af3818f4328c693"
  :revdesc "7cc85c48c338"
  :keywords '("internal")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
