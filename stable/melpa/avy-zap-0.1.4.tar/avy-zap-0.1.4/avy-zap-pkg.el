;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-zap" "0.1.4"
  "Zap to char using `avy'."
  '((avy "0.2.0"))
  :url "https://github.com/cute-jumper/avy-zap"
  :commit "67fed60d0dfe9087ca4fe3332f4a78e775b8d239"
  :revdesc "67fed60d0dfe"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
