;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-extra-operator" "0.2"
  "Evil operator for evaluating codes, taking notes, searching via google, etc."
  '((evil "1.0.7"))
  :url "https://github.com/Dewdrops/evil-extra-operator"
  :commit "8992143cc182e88fccf4a08ffa14ee6db8e14406"
  :revdesc "8992143cc182"
  :keywords '("evil" "plugin")
  :authors '(("Dewdrops" . "v_v_4474@126.com"))
  :maintainers '(("Dewdrops" . "v_v_4474@126.com")))
