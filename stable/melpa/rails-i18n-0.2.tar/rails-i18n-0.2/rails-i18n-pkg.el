;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rails-i18n" "0.2"
  "Seach and insert i18n on ruby code."
  '((emacs "27.2")
    (yaml  "0.1.0"))
  :url "https://github.com/otavioschwanck/rails-i18n.el"
  :commit "3a28b20776f0e946ca0f71dac6372e2b559e51b7"
  :revdesc "3a28b20776f0"
  :keywords '("tools" "languages")
  :authors '(("Otávio Schwanck dos Santos" . "otavioschwanck@gmail.com"))
  :maintainers '(("Otávio Schwanck dos Santos" . "otavioschwanck@gmail.com")))
