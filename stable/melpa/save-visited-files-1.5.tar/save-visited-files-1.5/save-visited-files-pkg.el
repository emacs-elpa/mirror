;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "save-visited-files" "1.5"
  "Save opened files across sessions."
  ()
  :url "https://github.com/nflath/save-visited-files"
  :commit "fb3fb62786316263ae6854f3130ad96612c6c2ba"
  :revdesc "fb3fb6278631"
  :authors '(("Nathaniel Flath" . "nflath@gmail.com"))
  :maintainers '(("Nathaniel Flath" . "nflath@gmail.com")))
