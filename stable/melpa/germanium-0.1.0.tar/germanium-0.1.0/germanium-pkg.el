;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "germanium" "0.1.0"
  "Generate image from source code using germanium."
  '((emacs "26.1"))
  :url "https://github.com/matsuyoshi30/germanium-el"
  :commit "fc8be71dedc6c04be76290bdcaf412dea1743433"
  :revdesc "fc8be71dedc6"
  :keywords '("convenience"))
