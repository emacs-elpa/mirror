;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-notifications" "0.1"
  "Creates notifications for org-mode entries."
  '((emacs     "25.1")
    (org       "9.0")
    (sound-wav "0.02")
    (alert     "0.1.0")
    (seq       "2.21"))
  :url "https://github.com/doppelc/org-notifications"
  :commit "87685e28404bc0e50db7987757a5101dc388e839"
  :revdesc "87685e28404b"
  :keywords '("outlines"))
