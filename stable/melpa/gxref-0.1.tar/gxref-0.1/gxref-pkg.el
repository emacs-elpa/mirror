;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gxref" "0.1"
  "Xref backend using GNU Global."
  '((emacs "25"))
  :url "https://github.com/dedi/gxref"
  :commit "15723a9d910d7dd9ea18cab0336332cf988aeceb"
  :revdesc "v0.1-0-g15723a9d910d"
  :keywords '("xref" "global" "tools"))
