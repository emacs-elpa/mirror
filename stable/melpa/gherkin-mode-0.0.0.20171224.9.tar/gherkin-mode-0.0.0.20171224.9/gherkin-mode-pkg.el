;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gherkin-mode" "0.0.0.20171224.9"
  "An emacs major mode for editing gherkin files."
  ()
  :url "https://github.com/candera/gherkin-mode"
  :commit "0313492e7da152f0aa73ddf96c0287ded8f51253"
  :revdesc "0313492e7da1"
  :keywords '("languages"))
