;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sourcemap" "0.3"
  "Sourcemap parser."
  '((emacs "24.3"))
  :url "https://github.com/syohex/emacs-sourcemap"
  :commit "64c89d296186f48d9135fb8aad501de19f64bceb"
  :revdesc "64c89d296186"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
