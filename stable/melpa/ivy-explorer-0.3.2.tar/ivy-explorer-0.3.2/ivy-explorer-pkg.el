;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-explorer" "0.3.2"
  "Dynamic file browsing grid using ivy."
  '((emacs "25")
    (ivy   "0.10.0"))
  :url "https://github.com/clemera/ivy-explorer"
  :commit "14adb6164f1d1646f503c3e4bd9aa559805f93d7"
  :revdesc "14adb6164f1d"
  :keywords '("convenience" "files" "matching")
  :authors '(("Clemens Radermacher" . "clemera@posteo.net"))
  :maintainers '(("Clemens Radermacher" . "clemera@posteo.net")))
