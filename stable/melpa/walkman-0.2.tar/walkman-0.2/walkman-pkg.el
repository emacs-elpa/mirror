;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "walkman" "0.2"
  "Write HTTP requests in Org mode."
  '((transient "0.1.0")
    (org       "8.3.5")
    (json-mode "1.6.0")
    (emacs     "26.3"))
  :url "https://github.com/abrochard/walkman"
  :commit "00b4fd5cae7fe27085995dbb178828fb765c7edc"
  :revdesc "00b4fd5cae7f"
  :keywords '("walkman" "http" "curl" "org" "comm"))
