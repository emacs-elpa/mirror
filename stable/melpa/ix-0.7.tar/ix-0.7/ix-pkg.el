;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ix" "0.7"
  "Emacs client for http://ix.io pastebin."
  '((grapnel "0.5.3"))
  :url "http://www.github.com/theanalyst/ix.el"
  :commit "498dac674f4f1910d39087b1457c5da5465a0614"
  :revdesc "0.7-0-g498dac674f4f"
  :authors '(("Abhishek L" . "abhishekl.2006@gmail.com"))
  :maintainers '(("Abhishek L" . "abhishekl.2006@gmail.com")))
