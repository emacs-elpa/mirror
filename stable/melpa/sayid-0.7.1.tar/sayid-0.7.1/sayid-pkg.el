;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "0.7.1"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.23"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "b0fe109ccd7c8377be02bb9938153d251a7db4b3"
  :revdesc "v0.7.1-0-gb0fe109ccd7c"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
