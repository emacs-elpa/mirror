;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quelpa-use-package" "0.0.2"
  "Quelpa handler for use-package."
  '((emacs  "29.1")
    (quelpa "1.0"))
  :url "https://github.com/quelpa/quelpa-use-package"
  :commit "642ee79e65cb5496b0ffd15d597ce25a69de20c8"
  :revdesc "642ee79e65cb"
  :keywords '("package" "management" "elpa" "use-package")
  :authors '(("Reto Hubmann" . "(@steckerhalter)"))
  :maintainers '(("Reto Hubmann" . "(@steckerhalter)")))
