;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kiwix" "1.1.5"
  "Searching offline Wikipedia through Kiwix."
  '((emacs   "25.1")
    (request "0.3.0"))
  :url "https://github.com/stardiviner/kiwix.el"
  :commit "cb843349c10b1a492ceb59da20bfcef3ef02f4b5"
  :revdesc "cb843349c10b"
  :keywords '("kiwix" "wikipedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
