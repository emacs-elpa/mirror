;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-rsync" "0.7"
  "Allow rsync from dired buffers."
  '((s     "1.12.0")
    (dash  "2.0.0")
    (emacs "25.1"))
  :url "https://github.com/stsquad/dired-rsync"
  :commit "95607fc7eb84e792122b52d2b1d62f49199a2a37"
  :revdesc "95607fc7eb84"
  :authors '(("Alex Bennée" . "alex@bennee.com"))
  :maintainers '(("Alex Bennée" . "alex@bennee.com")))
