;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avandu" "0.0.0.20221106.59"
  "Gateway to Tiny Tiny RSS."
  ()
  :url "https://github.com/ryuslash/avandu"
  :commit "f064cd62f878d945cc2f202cda9a1a82b39d9e22"
  :revdesc "f064cd62f878"
  :keywords '("net")
  :authors '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainers '(("Tom Willemse" . "tom@ryuslash.org")))
