;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-preview" "0.1.2"
  "Live preview by any shell command while editing."
  '((emacs "24.4"))
  :url "https://github.com/lassik/emacs-live-preview"
  :commit "603a4a1759fbec92e7a1cabc249517c78e59ce7e"
  :revdesc "0.1.2-0-g603a4a1759fb"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
