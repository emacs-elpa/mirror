;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "r-ts-mode" "1.1.1"
  "R treesitter mode."
  '((emacs "30.1"))
  :url "https://codeberg.org/R-for-emacs/r-ts-mode"
  :commit "8b55753ffe811a7454873ebfdae8345a6e7d71dc"
  :revdesc "8b55753ffe81"
  :authors '(("Manuel Teodoro" . "ttm@teoten.me"))
  :maintainers '(("Manuel Teodoro" . "ttm@teoten.me")))
