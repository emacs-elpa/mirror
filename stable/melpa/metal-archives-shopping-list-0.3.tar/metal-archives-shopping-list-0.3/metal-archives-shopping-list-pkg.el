;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metal-archives-shopping-list" "0.3"
  "Add shopping list generation support to metal-archives."
  '((emacs          "26.3")
    (org-ml         "5.8.7")
    (alert          "1.2")
    (ht             "2.3")
    (metal-archives "0.3"))
  :url "https://github.com/seblemaguer/metal-archives.el"
  :commit "b7279dd0331cb5da4a8f0aa25378d22e0042dc40"
  :revdesc "b7279dd0331c"
  :keywords '("org" "calendar")
  :authors '(("Sébastien Le Maguer" . "lemagues@tcd.ie"))
  :maintainers '(("Sébastien Le Maguer" . "lemagues@tcd.ie")))
