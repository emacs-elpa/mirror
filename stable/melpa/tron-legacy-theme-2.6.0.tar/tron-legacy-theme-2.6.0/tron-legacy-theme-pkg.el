;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tron-legacy-theme" "2.6.0"
  "An original retro-futuristic theme inspired by Tron: Legacy."
  ()
  :url "https://github.com/ianpan870102/tron-legacy-emacs-theme"
  :commit "74e0cf066392c6fa99327e42b24caf4ed2fc414f"
  :revdesc "74e0cf066392")
