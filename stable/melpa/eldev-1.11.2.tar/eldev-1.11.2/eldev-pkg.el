;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "1.11.2"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "92a46b48793e561b00189a06014df0d7bbeed3be"
  :revdesc "92a46b48793e"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
