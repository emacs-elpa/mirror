;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "0.1"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "c7707c98730bb3ffaf84aeed341fae3cf35c314b"
  :revdesc "c7707c98730b"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
