;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "webpaste" "3.2.2"
  "Paste to pastebin-like services."
  '((emacs   "24.4")
    (request "0.2.0")
    (cl-lib  "0.5"))
  :url "https://github.com/etu/webpaste.el"
  :commit "78272662e6992b8614e79a571ff2395fa9630357"
  :revdesc "3.2.2-0-g78272662e699"
  :keywords '("convenience" "comm" "paste")
  :authors '(("Elis etu Hirwing" . "elis@hirwing.se"))
  :maintainers '(("Elis etu Hirwing" . "elis@hirwing.se")))
