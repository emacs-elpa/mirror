;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "director" "0.1"
  "Simulate user sessions."
  '((emacs "27.1"))
  :url "https://github.com/bard/emacs-director"
  :commit "975bcfb67f65516dd86738a0ea6de2b29b74fa55"
  :revdesc "975bcfb67f65"
  :authors '(("Massimiliano Mirra" . "hyperstruct@gmail.com"))
  :maintainers '(("Massimiliano Mirra" . "hyperstruct@gmail.com")))
