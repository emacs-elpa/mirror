;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-firefox-evil" "1.0"
  "Firefox hotkeys to functions."
  '((emacs "24.4")
    (exwm  "0.16"))
  :url "https://github.com/walseb/exwm-firefox-evil"
  :commit "73de0eb7f060960afa1ee2fd78331ad35018e5ed"
  :revdesc "73de0eb7f060"
  :keywords '("extensions")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
