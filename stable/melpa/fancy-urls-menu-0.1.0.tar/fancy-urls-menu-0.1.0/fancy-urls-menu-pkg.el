;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-urls-menu" "0.1.0"
  "Interface for viewing and opening URLs in current buffer."
  '((emacs "29.1"))
  :url "https://codeberg.org/kakafarm/emacs-fancy-urls-menu/"
  :commit "4a817ef24a91fb8e53cbece1a8351321c919d62a"
  :revdesc "4a817ef24a91"
  :keywords '("convenience")
  :maintainers '((nil . "yuval.langer@gmail.com")))
