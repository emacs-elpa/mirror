;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proc-net" "0.0.1"
  "Network process tools."
  ()
  :url "https://github.com/nicferrier/emacs-proc-net"
  :commit "52090f8cb7b54d36306a7b2d33e3549593c7c0bb"
  :revdesc "52090f8cb7b5"
  :keywords '("processes")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
