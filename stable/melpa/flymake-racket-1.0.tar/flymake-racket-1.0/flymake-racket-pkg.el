;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-racket" "1.0"
  "Flymake extension for Racket."
  '((emacs "26.1"))
  :url "https://github.com/jojojames/flymake-racket"
  :commit "2c62718556c7b378af4e62dd622fa9fb132032be"
  :revdesc "2c62718556c7"
  :keywords '("languages" "racket" "scheme")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
