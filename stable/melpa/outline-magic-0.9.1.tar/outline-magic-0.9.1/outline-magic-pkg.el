;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-magic" "0.9.1"
  "Outline mode extensions for Emacs."
  ()
  :url "https://github.com/tj64/outline-magic"
  :commit "9dc1fdae32d7e89130fba7193daab330de9299e5"
  :revdesc "9dc1fdae32d7"
  :keywords '("outlines"))
