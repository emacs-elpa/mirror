;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-protocol" "0.9.1"
  "Provide fever/newsblur/owncloud/ttrss protocols for elfeed."
  '((emacs  "24.4")
    (elfeed "2.1.1")
    (cl-lib "0.5"))
  :url "https://github.com/fasheng/elfeed-protocol"
  :commit "bcefb85a1d4075f36e73a94bda569e71f28a52c2"
  :revdesc "bcefb85a1d40"
  :keywords '("news")
  :authors '(("Xu Fasheng" . "fasheng[AT]fasheng.info"))
  :maintainers '(("Xu Fasheng" . "fasheng[AT]fasheng.info")))
