;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "regswap" "1.0"
  "Functionality for swapping two regions."
  '((emacs "24.3"))
  :url "https://github.com/skitov/regswap"
  :commit "6f4c91c160668691f6c1896579e2f81cfdd198f7"
  :revdesc "6f4c91c16066")
