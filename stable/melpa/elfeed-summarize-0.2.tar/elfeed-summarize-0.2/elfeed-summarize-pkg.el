;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-summarize" "0.2"
  "Add LLM-powered inline summaries to elfeed."
  '((emacs  "28.1")
    (elfeed "3.4.1")
    (llm    "0.28.4"))
  :url "https://github.com/fritzgrabo/elfeed-summarize"
  :commit "b4d9f8a7bb72d9fd0db804eff535c42859d94cf8"
  :revdesc "b4d9f8a7bb72"
  :keywords '("comm")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
