;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crossword" "1.0"
  "Download and play crossword puzzles."
  '((emacs "26.1"))
  :url "https://github.com/Boruch-Baum/emacs-crossword"
  :commit "fa80bfef81168509ddbd840d95c6671efe91c253"
  :revdesc "fa80bfef8116"
  :keywords '("games"))
