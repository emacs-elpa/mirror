;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solidity-mode" "0.1.10"
  "Major mode for ethereum's solidity language."
  ()
  :url "https://github.com/ethereum/emacs-solidity"
  :commit "93412f211fad7dfc3b02aa226856fc52b6a15c22"
  :revdesc "93412f211fad"
  :keywords '("languages" "solidity")
  :authors '(("Lefteris Karapetsas" . "lefteris@refu.co"))
  :maintainers '(("Lefteris Karapetsas" . "lefteris@refu.co")))
