;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-defer" "0.1"
  "Defer non-essential vc.el work."
  '((emacs "25.1"))
  :url "https://github.com/google/vc-defer"
  :commit "34db6425a92fc7095d1c265a3a81221d17018d35"
  :revdesc "34db6425a92f"
  :keywords '("vc" "tools")
  :authors '(("Matt Armstrong" . "marmstrong@google.com"))
  :maintainers '(("Tom Fitzhenry" . "tomfitzhenry@google.com")))
