;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typespec-ts-mode" "0.2"
  "Major mode for TypeSpec (using tree-sitter)."
  '((emacs "29.1"))
  :url "https://github.com/pradyuman/typespec-ts-mode"
  :commit "2da8117b717f290a585a136bf03a6f0a23a4bb82"
  :revdesc "2da8117b717f"
  :keywords '("languages" "tree-sitter" "typespec")
  :authors '(("Pradyuman Vig" . "me@pmn.co"))
  :maintainers '(("Pradyuman Vig" . "me@pmn.co")))
