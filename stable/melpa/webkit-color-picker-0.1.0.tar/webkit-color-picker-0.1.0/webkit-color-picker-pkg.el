;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "webkit-color-picker" "0.1.0"
  "Insert and adjust colors using Webkit Widgets."
  '((emacs    "26.0")
    (posframe "0.1.0"))
  :url "https://github.com/osener/emacs-webkit-color-picker"
  :commit "ed0e33db344d8260587467905060581b993a4e57"
  :revdesc "ed0e33db344d"
  :keywords '("tools")
  :authors '(("Ozan Sener" . "hi@ozan.email"))
  :maintainers '(("Ozan Sener" . "hi@ozan.email")))
