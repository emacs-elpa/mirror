;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shfmt" "0.1"
  "Reformat shell scripts using shfmt."
  '((emacs       "24")
    (reformatter "0.3"))
  :url "https://github.com/purcell/emacs-shfmt"
  :commit "cd94266badc71c1e981e904e10f28c6a80237a2f"
  :revdesc "cd94266badc7"
  :keywords '("languages")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
