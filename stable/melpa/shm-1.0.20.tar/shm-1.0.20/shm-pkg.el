;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shm" "1.0.20"
  "Structured Haskell Mode."
  ()
  :url "https://github.com/projectional-haskell/structured-haskell-mode"
  :commit "8abc5cd73e59ea85bef906e14e87dc388c4f350f"
  :revdesc "8abc5cd73e59"
  :keywords '("development" "haskell" "structured")
  :authors '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainers '(("Chris Done" . "chrisdone@gmail.com")))
