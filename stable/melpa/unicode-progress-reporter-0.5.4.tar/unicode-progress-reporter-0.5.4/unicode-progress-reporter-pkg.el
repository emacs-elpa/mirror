;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-progress-reporter" "0.5.4"
  "Progress-reporter with fancy characters."
  '((emacs           "24.1.0")
    (ucs-utils       "0.7.6")
    (persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/unicode-progress-reporter"
  :commit "f4705332412b12fc72ca868b77c78465561bda75"
  :revdesc "v0.5.4-0-gf4705332412b"
  :keywords '("interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
