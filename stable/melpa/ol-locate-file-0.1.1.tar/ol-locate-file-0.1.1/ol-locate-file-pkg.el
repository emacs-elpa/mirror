;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-locate-file" "0.1.1"
  "Locate-based file links for Org mode."
  '((emacs "30.1")
    (org   "9.3"))
  :url "https://github.com/p-snow/ol-locate-file"
  :commit "73766f7076324a872deb06d3d413eabf88890944"
  :revdesc "73766f707632"
  :keywords '("hypermedia" "convenience")
  :authors '(("p-snow" . "public@p-snow.org"))
  :maintainers '(("p-snow" . "public@p-snow.org")))
