;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tmux-pane" "0.1"
  "Provide integration between emacs window and tmux pane."
  '((names "0.5")
    (emacs "24")
    (s     "0"))
  :url "https://github.com/laishulu/emacs-tmux-pane"
  :commit "5e83ec65a1d38af9b8a389bdf34a78d13437e63d"
  :revdesc "5e83ec65a1d3"
  :keywords '("convenience" "terminals" "tmux" "window" "pane" "navigation" "integration"))
