;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirtree" "0.1"
  "Directory tree views."
  ()
  :url "https://github.com/emacsorphanage/dirtree"
  :commit "4230dfb63dd303178adadab445db3b44c27984c5"
  :revdesc "4230dfb63dd3"
  :authors '(("Ye Wenbin" . "wenbinye@gmail.com"))
  :maintainers '(("Ye Wenbin" . "wenbinye@gmail.com")))
