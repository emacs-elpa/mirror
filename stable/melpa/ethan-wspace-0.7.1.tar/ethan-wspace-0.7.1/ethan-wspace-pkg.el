;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ethan-wspace" "0.7.1"
  "Whitespace customizations for emacs."
  ()
  :url "https://github.com/glasserc/ethan-wspace"
  :commit "e055ee6730c0b03525d32e67511ef6c51e4c29e4"
  :revdesc "e055ee6730c0"
  :keywords '("whitespace" "tab" "newline" "trailing" "clean")
  :authors '(("Ethan Glasser-Camp" . "ethan@betacantrips.com"))
  :maintainers '(("Ethan Glasser-Camp" . "ethan@betacantrips.com")))
