;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "context-clues" "0.3.0"
  "Easily copy context like the current file name and path."
  '((emacs     "28.1")
    (transient "0.3.0"))
  :url "https://github.com/mrcnski/context-clues"
  :commit "36fa56896fa9982f26715bd7c59a1eebc6c00756"
  :revdesc "36fa56896fa9"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
