;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "context-clues" "0.3.0"
  "Easily copy context like the current file name and path."
  '((emacs     "28.1")
    (transient "0.3.0"))
  :url "https://github.com/mrcnski/context-clues"
  :commit "55483a68c18e4c5960bfb89c0ea95265a89db0ab"
  :revdesc "55483a68c18e"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
