;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "udev-mode" "0.1"
  "Major mode for editing udev rules files."
  '((emacs "24"))
  :url "https://github.com/benley/emacs-udev-mode"
  :commit "e939a83712e9d5b95f7315945806dbfa0ef36244"
  :revdesc "e939a83712e9"
  :keywords '("languages" "unix")
  :authors '(("Benjamin Staffin" . "benley@gmail.com"))
  :maintainers '(("Benjamin Staffin" . "benley@gmail.com")))
