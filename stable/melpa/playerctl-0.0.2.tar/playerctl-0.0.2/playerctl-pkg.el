;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "playerctl" "0.0.2"
  "Control your music player (e.g. Spotify) with playerctl."
  ()
  :url "https://github.com/thomasluquet/playerctl.el"
  :commit "c75358240a9bc234f31fc3e652929b103b1238b9"
  :revdesc "c75358240a9b"
  :keywords '("multimedia" "playerctl" "music")
  :authors '(("Thomas Luquet" . "thomas@luquet.net"))
  :maintainers '(("Thomas Luquet" . "thomas@luquet.net")))
