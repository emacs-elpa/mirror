;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popup-switcher" "0.2.14"
  "Switch to other buffers and files via popup."
  '((cl-lib "0.3")
    (popup  "0.5.3"))
  :url "https://github.com/kostafey/popup-switcher"
  :commit "6ac35cc2aeace8e42b99622ee8b3a56dc3cff57d"
  :revdesc "6ac35cc2aeac"
  :keywords '("popup" "switch" "buffers" "functions")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
