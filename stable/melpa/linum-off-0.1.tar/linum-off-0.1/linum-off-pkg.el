;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linum-off" "0.1"
  "Provides an interface for turning line-numbering off."
  ()
  :url "http://www.emacswiki.org/emacs/auto-indent-mode.el "
  :commit "8e900536d4f91432e76fa5cc0adee6efcae8201e"
  :revdesc "8e900536d4f9"
  :keywords '("line" "numbering"))
