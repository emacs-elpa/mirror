;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fill-page" "0.3.7"
  "Fill buffer so you don't see empty lines at the end."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/fill-page"
  :commit "95f82f93848ca608d4c4d9ec7386d94745cbc691"
  :revdesc "95f82f93848c"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
