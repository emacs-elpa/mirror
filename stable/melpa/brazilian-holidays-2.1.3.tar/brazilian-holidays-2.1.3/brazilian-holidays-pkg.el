;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brazilian-holidays" "2.1.3"
  "Brazilian holidays."
  '((emacs "26"))
  :url "https://github.com/jadler/brazilian-holidays"
  :commit "eaf7684da40c2ad1162cee07f3ffd4c1881f7cf6"
  :revdesc "2.1.3-0-geaf7684da40c"
  :keywords '("calendar" "holidays" "brazilian")
  :authors '(("Jaguaraquem A. Reinaldo" . "jaguar.adler@gmail.com"))
  :maintainers '(("Jaguaraquem A. Reinaldo" . "jaguar.adler@gmail.com")))
