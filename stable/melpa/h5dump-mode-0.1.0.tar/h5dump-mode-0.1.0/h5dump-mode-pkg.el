;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "h5dump-mode" "0.1.0"
  "Major mode for navigating h5dump output."
  '((emacs "25.1"))
  :url "https://github.com/berquist/h5dump-mode"
  :commit "6b8309f41f94e9801729b189652a21d2f9f8e059"
  :revdesc "6b8309f41f94"
  :keywords '("languages" "hdf5"))
