;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erblint" "0.0.1"
  "An Emacs interface for Shopify's erblint tool."
  '((emacs "24"))
  :url "https://github.com/leodcs/erblint-emacs"
  :commit "874966672fd7cfa12e72ed40d0d375ee0214b15e"
  :revdesc "874966672fd7"
  :keywords '("project" "convenience"))
