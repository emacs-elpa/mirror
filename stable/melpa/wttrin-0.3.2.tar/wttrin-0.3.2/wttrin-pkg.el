;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "0.3.2"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "fe653a231b186393b02a2723985e61ce97baba1c"
  :revdesc "v0.3.2-0-gfe653a231b18"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
