;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-php" "0.0.1"
  "Execute PHP within org-mode blocks."
  '((org "8"))
  :url "https://github.com/stardiviner/ob-php"
  :commit "fd30c5e945a08b605725cf51808b3512ca885777"
  :revdesc "fd30c5e945a0"
  :keywords '("org" "babel" "php")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
