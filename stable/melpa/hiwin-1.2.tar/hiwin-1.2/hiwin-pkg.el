;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hiwin" "1.2"
  "Visible active window mode."
  ()
  :url "https://github.com/yoshida-mediba/hiwin-mode"
  :commit "e219f46e092a034a2f1dc9784280b8f9779bd388"
  :revdesc "e219f46e092a"
  :keywords '("faces" "editing" "emulating"))
