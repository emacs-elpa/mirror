;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "volume" "1.0"
  "Tweak your sound card volume from Emacs."
  ()
  :url "http://www.brockman.se/software/volume-el/"
  :commit "fd7f006ef40292456185344f7ae9304015dfaf24"
  :revdesc "fd7f006ef402"
  :authors '(("Daniel Brockman" . "daniel@brockman.se"))
  :maintainers '(("Daniel Brockman" . "daniel@brockman.se")))
