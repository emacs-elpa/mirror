;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "digitalocean-helm" "0.1"
  "Create and manipulate digitalocean droplets."
  '((emacs "24.3")
    (helm  "2.5"))
  :url "https://github.com/olymk2/digitalocean-api"
  :commit "34dc6d961aee225244936450815c73f8fd422501"
  :revdesc "34dc6d961aee"
  :keywords '("processes" "tools")
  :authors '(("Oliver Marks" . "oly@digitaloctave.com"))
  :maintainers '(("Oliver Marks" . "oly@digitaloctave.com")))
