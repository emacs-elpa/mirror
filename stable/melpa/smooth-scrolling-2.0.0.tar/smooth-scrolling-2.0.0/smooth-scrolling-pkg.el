;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smooth-scrolling" "2.0.0"
  "Make emacs scroll smoothly."
  ()
  :url "https://github.com/aspiers/smooth-scrolling/"
  :commit "6a1420be510decde0a5eabc56cff229ae554417e"
  :revdesc "v2.0.0-0-g6a1420be510d"
  :keywords '("convenience")
  :authors '(("Adam Spiers" . "emacs-ss@adamspiers.org")
             ("Jeremy Bondeson" . "jbondeson@gmail.com")
             ("Ryan C. Thompson" . "rct+github@thompsonclan.org"))
  :maintainers '(("Adam Spiers" . "emacs-ss@adamspiers.org")))
