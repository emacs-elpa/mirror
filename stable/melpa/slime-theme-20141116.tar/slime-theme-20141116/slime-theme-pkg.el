;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime-theme" "20141116"
  "An Emacs 24 theme based on Slime (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "33b02aea17b4eeab09f1bad627943210821e0f28"
  :revdesc "33b02aea17b4")
