;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-dogears" "0.1"
  "Helm source for Dogears."
  '((emacs   "26.3")
    (dogears "0.1-pre")
    (helm    "3.6"))
  :url "https://github.com/alphapapa/dogears.el"
  :commit "7ba83bd8924cec66fe3ede3334e98b1845e6852e"
  :revdesc "v0.1-0-g7ba83bd8924c"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
