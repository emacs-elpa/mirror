;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "all-the-icons-ibuffer" "1.3.0"
  "Display icons for all buffers in ibuffer."
  '((emacs         "24.4")
    (all-the-icons "2.2.0"))
  :url "https://github.com/seagle0128/all-the-icons-ibuffer"
  :commit "767b52186c1d9ef52f087f34a48af39c31e45b73"
  :revdesc "767b52186c1d"
  :keywords '("convenience" "icons" "ibuffer")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
