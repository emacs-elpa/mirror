;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esa" "0.8.13"
  "Emacs integration for esa.io."
  '((cl-lib "0.3"))
  :url "https://github.com/nabinno/esa.el"
  :commit "0f69f9f45ac15018c48853509ac38e68286f9c0e"
  :revdesc "0f69f9f45ac1"
  :keywords '("tools" "esa")
  :authors '(("Nab Inno" . "nab@blahfe.com"))
  :maintainers '(("Nab Inno" . "nab@blahfe.com")))
