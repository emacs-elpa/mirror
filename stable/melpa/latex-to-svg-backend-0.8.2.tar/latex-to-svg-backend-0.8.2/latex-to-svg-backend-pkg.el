;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-backend" "0.8.2"
  "Content-addressed LaTeX-to-SVG image rendering."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/latex-to-svg-backend"
  :commit "b996e9b7ab6dba25e95dd7e96743fd8534001410"
  :revdesc "v0.8.2-0-gb996e9b7ab6d"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
