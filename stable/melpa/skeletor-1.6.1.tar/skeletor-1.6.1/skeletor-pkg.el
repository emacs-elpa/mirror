;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "skeletor" "1.6.1"
  "Provides project skeletons for Emacs."
  '((s         "1.7.0")
    (f         "0.14.0")
    (dash      "2.2.0")
    (cl-lib    "0.3")
    (let-alist "1.0.3")
    (emacs     "24.1"))
  :url "https://github.com/chrisbarrett/skeletor.el"
  :commit "d986806559628623b591542143707de8d76347d0"
  :revdesc "d98680655962"
  :authors '(("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainers '(("Chris Barrett" . "chris.d.barrett@me.com")))
