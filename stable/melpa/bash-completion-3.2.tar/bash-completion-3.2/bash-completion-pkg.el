;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bash-completion" "3.2"
  "Bash completion for the shell buffer."
  '((emacs "25.3"))
  :url "https://github.com/szermatt/emacs-bash-completion"
  :commit "ed9c76252ac82d6352ba438f664b390fdd0b5d6c"
  :revdesc "ed9c76252ac8"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
