;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popup-edit-menu" "0.0.3"
  "A popup context edit menu package."
  '((emacs "24"))
  :url "https://github.com/debugfan/popup-edit-menu"
  :commit "639d5a190e3915ee3d9cc3ea61fd3e6d3fac1f5c"
  :revdesc "639d5a190e39"
  :keywords '("lisp" "pop-up" "context" "edit" "menu")
  :authors '(("Debugfan Chin" . "debugfanchin@gmail.com"))
  :maintainers '(("Debugfan Chin" . "debugfanchin@gmail.com")))
