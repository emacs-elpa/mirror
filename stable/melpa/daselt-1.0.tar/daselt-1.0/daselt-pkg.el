;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "1.0"
  "Daselt's Emacs module."
  '((emacs "29.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "d016dc190878e81d8bc8472dde50dc5d88900eb5"
  :revdesc "d016dc190878"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
