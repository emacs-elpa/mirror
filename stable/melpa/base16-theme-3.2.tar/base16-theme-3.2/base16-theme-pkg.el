;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "3.2"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "a01e1fe184dbcd5d0c7ed706ae144eb9299cd417"
  :revdesc "a01e1fe184db"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
