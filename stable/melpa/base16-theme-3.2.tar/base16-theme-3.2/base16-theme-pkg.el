;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "3.2"
  "A set of base16 themes for your favorite editor."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "a01e1fe184dbcd5d0c7ed706ae144eb9299cd417"
  :revdesc "a01e1fe184db"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
