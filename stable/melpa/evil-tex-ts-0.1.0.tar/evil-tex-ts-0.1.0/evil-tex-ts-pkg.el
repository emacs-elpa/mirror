;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-tex-ts" "0.1.0"
  "Tree-sitter based LaTeX text objects for Evil."
  '((emacs "29.1")
    (evil  "1.0"))
  :url "https://github.com/chestnykh/evil-tex-ts"
  :commit "c66804d0116d63e7b96f6818959bdcf2bb6e6f6d"
  :revdesc "c66804d0116d"
  :keywords '("tex" "emulation" "vi" "evil" "wp"))
