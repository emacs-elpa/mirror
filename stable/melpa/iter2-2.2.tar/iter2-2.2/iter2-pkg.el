;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iter2" "2.2"
  "Reimplementation of Elisp generators."
  '((emacs "25.1"))
  :url "https://github.com/doublep/iter2"
  :commit "60a30589d5bea2b50ccab32a1b3e1388d38ecdb2"
  :revdesc "60a30589d5be"
  :keywords '("elisp" "extensions")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
