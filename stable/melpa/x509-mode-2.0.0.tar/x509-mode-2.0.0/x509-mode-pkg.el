;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "2.0.0"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "6b070cc0fdc4df440f806053a20e9dbc47e04bf4"
  :revdesc "6b070cc0fdc4"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
