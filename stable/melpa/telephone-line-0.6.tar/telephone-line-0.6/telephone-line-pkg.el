;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telephone-line" "0.6"
  "Rewrite of Powerline."
  '((emacs      "24.4")
    (cl-lib     "0.5")
    (cl-generic "0.2")
    (seq        "1.8"))
  :url "https://github.com/dbordak/telephone-line"
  :commit "314187790b5c5e9962c6d8eac9323b5b801e4aef"
  :revdesc "0.6-0-g314187790b5c"
  :keywords '("mode-line")
  :authors '(("Daniel Bordak" . "dbordak@fastmail.fm"))
  :maintainers '(("Daniel Bordak" . "dbordak@fastmail.fm")))
