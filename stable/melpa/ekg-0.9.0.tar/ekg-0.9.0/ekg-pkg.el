;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.0"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "be6cc349a5054154470173af6521e569cb21bcb1"
  :revdesc "be6cc349a505"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
