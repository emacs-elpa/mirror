;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-agent-shell" "0.2.0"
  "Org-babel backend for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.50.1")
    (org         "9.6"))
  :url "https://github.com/eddof13/ob-agent-shell"
  :commit "b08ae4ec0690b98850eabf8759175bf66eea4d5c"
  :revdesc "v0.2.0-0-gb08ae4ec0690"
  :keywords '("tools" "convenience" "outlines")
  :authors '(("Eddie Jesinsky" . "eddie@jesinsky.com"))
  :maintainers '(("Eddie Jesinsky" . "eddie@jesinsky.com")))
