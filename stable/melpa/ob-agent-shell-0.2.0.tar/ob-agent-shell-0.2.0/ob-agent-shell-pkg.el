;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-agent-shell" "0.2.0"
  "Org-babel backend for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.50.1")
    (org         "9.6"))
  :url "https://github.com/eddof13/ob-agent-shell"
  :commit "81319268885a84147ae55e2375382bdd8d2cc836"
  :revdesc "v0.2.0-0-g81319268885a"
  :keywords '("tools" "convenience" "outlines")
  :authors '(("Eddie Jesinsky" . "eddie@jesinsky.com"))
  :maintainers '(("Eddie Jesinsky" . "eddie@jesinsky.com")))
