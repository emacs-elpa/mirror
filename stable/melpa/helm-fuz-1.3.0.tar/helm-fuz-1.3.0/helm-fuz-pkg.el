;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-fuz" "1.3.0"
  "Integrate Helm and Fuz."
  '((emacs "25.1")
    (fuz   "1.3.0")
    (helm  "3.2"))
  :url "https://github.com/cireu/fuz.el"
  :commit "90ca9207a9c1decda24a552b94ff41169ecccb14"
  :revdesc "1.3.0-0-g90ca9207a9c1"
  :keywords '("convenience")
  :authors '(("Zhu Zihao" . "all_but_last@163.com"))
  :maintainers '(("Zhu Zihao" . "all_but_last@163.com")))
