;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "4.1.1"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "88e0fb504564440e187ff458c26c81a9e591e863"
  :revdesc "v4.1.1-0-g88e0fb504564"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
