;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "traad" "3.1.1"
  "Emacs interface to the traad refactoring server."
  '((dash              "2.13.0")
    (deferred          "0.3.2")
    (popup             "0.5.0")
    (request           "0.2.0")
    (request-deferred  "0.2.0")
    (virtualenvwrapper "20151123"))
  :url "https://github.com/abingham/traad"
  :commit "1f05cb4e5e96a90d2fb2bbc93093084327c40cf2"
  :revdesc "1f05cb4e5e96"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
