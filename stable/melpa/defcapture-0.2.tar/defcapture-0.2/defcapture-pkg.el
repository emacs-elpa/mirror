;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "defcapture" "0.2"
  "A convenience macro for the Doct DSL."
  '((emacs "25.1")
    (doct  "3.0")
    (org   "9.4"))
  :url "https://github.com/aggu4/defcapture"
  :commit "9e0ef881c50b23ce7f9305d7fcb8326bfb154429"
  :revdesc "9e0ef881c50b"
  :keywords '("convenience" "org")
  :authors '(("Abraham Aguilar" . "a.aguilar@ciencias.unam.mx"))
  :maintainers '(("Abraham Aguilar" . "a.aguilar@ciencias.unam.mx")))
