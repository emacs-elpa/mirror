;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "origami-predef" "1.0"
  "Apply folding when finding (opening) files."
  '((emacs   "24.3")
    (origami "1.0"))
  :url "https://github.com/alvarogonzalezsotillo/origami-predef"
  :commit "edcba971ba52a14f69a436ad47888827d7927982"
  :revdesc "edcba971ba52"
  :keywords '("convenience" "folding")
  :authors '(("lvaro González Sotillo" . "alvarogonzalezsotillo@gmail.com"))
  :maintainers '(("lvaro González Sotillo" . "alvarogonzalezsotillo@gmail.com")))
