;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-yaml" "0.0.2"
  "A flymake handler for YAML."
  '((flymake-easy "0.1"))
  :url "https://github.com/yasuyk/flymake-yaml"
  :commit "0dd11eed29fe4054ff5b4e06e2c39b4d925d6aae"
  :revdesc "0dd11eed29fe"
  :keywords '("yaml")
  :authors '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
