;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gruvbox-theme" "1.30.5"
  "A retro-groove colour theme for Emacs."
  '((autothemer "0.2.19"))
  :url "https://github.com/greduan/emacs-theme-gruvbox"
  :commit "ba1f46df59a323e6580d75d980a8ce9c59f2c10a"
  :revdesc "ba1f46df59a3"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
