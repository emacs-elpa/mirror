;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "use-ttf" "0.1.3"
  "Keep font consistency across different OSs."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/use-ttf"
  :commit "3d044b252f48fac5d1f662979b3ac18d80ef27d9"
  :revdesc "3d044b252f48"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
