;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awk-yasnippets" "0.0.1"
  "Yasnippets for AWK."
  '((emacs     "26.3")
    (yasnippet "0.8.0"))
  :url "https://github.com/uberkael/awk-yasnippets"
  :commit "b4f89db8b424278ebfbc118f14c73c02ea4be964"
  :revdesc "b4f89db8b424"
  :keywords '("snippets")
  :maintainers '(("Adriano Martinez" . "uberkael@gmail.com")))
