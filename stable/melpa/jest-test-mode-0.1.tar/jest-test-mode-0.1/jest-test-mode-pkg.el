;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jest-test-mode" "0.1"
  "Minor mode for running Node.js tests using jest."
  ()
  :url "https://github.com/rymndhng/jest.el"
  :commit "6902ce68ef0dd50074e408c78e3076487bff425f"
  :revdesc "6902ce68ef0d"
  :authors '(("Raymond Huang" . "rymndhng@gmail.com"))
  :maintainers '(("Raymond Huang" . "rymndhng@gmail.com")))
