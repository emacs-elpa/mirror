;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-at-point" "1.1"
  "Edit(copy,cut..) current things(word,symbol..) under cursor."
  ()
  :url "https://github.com/enoson/edit-at-point.el"
  :commit "3b800c11685102e1eab62ec71c5fc1589ebb81a7"
  :revdesc "3b800c116851"
  :authors '((nil . "e.enoson@gmail.com"))
  :maintainers '((nil . "e.enoson@gmail.com")))
