;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sharper" "1.0"
  "Dotnet CLI wrapper, using Transient."
  '((emacs "25"))
  :url "https://github.com/sebasmonia/sharper"
  :commit "92cea23750da059ef966204dbc7747559dd1b08f"
  :revdesc "92cea23750da"
  :keywords '("maint" "tool")
  :authors '(("Sebastian Monia" . "smonia@outlook.com"))
  :maintainers '(("Sebastian Monia" . "smonia@outlook.com")))
