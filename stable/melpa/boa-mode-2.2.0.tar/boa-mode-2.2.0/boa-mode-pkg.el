;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boa-mode" "2.2.0"
  "Mode for boa language files."
  '((cc-mode "5.33.1"))
  :url "https://github.com/boalang/syntax-highlight"
  :commit "d375a818b4c0005b5b6c30bb84c07b0ee305606f"
  :revdesc "d375a818b4c0"
  :keywords '("boa" "msr" "language")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
