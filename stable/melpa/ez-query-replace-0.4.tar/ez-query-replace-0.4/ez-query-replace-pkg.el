;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ez-query-replace" "0.4"
  "A smarter context-sensitive query-replace that can be reapplied."
  '((dash "1.2.0")
    (s    "1.11.0"))
  :url "https://github.com/Wilfred/ez-query-replace"
  :commit "f5dbd2d3e5e62e6b7e7cc1a98fc4d0cd411e5afa"
  :revdesc "f5dbd2d3e5e6"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
