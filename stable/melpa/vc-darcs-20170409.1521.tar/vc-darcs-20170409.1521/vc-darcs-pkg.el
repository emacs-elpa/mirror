;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-darcs" "20170409.1521"
  "A VC backend for darcs."
  '((emacs "24"))
  :url "https://github.com/velkyel/vc-darcs"
  :commit "9c5cbf6fd9b624a31e918dd1a516b24d8b7ffe9d"
  :revdesc "9c5cbf6fd9b6"
  :keywords '("vc")
  :authors '(("Jorgen Schaefer" . "forcer@forcix.cx")
             ("Juliusz Chroboczek" . "jch@pps.univ-paris-diderot.fr"))
  :maintainers '(("Libor apák" . "capak@inputwish.com")))
