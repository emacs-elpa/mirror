;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-stats" "0.1.0"
  "Personal Knowledge Management Dashboard."
  '((emacs     "27.1")
    (transient "0.3.0"))
  :url "https://github.com/GerardoCendejas/ox-reveal-layouts"
  :commit "ba3e155283e8a7e5ca3d12893162c1612420220c"
  :revdesc "ba3e155283e8"
  :keywords '("hypermedia" "tools" "reveal" "slides")
  :authors '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu"))
  :maintainers '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu")))
