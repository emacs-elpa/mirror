;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stan-mode" "10.2.0"
  "Major mode for editing Stan files."
  '((emacs "24.4"))
  :url "https://github.com/stan-dev/stan-mode/tree/master/stan-mode"
  :commit "2dd330604563d143031fc8ffd516266217aa1f9b"
  :revdesc "2dd330604563"
  :keywords '("languages" "c")
  :authors '(("Jeffrey Arnold" . "jeffrey.arnold@gmail.com")
             ("Daniel Lee" . "bearlee@alum.mit.edu")
             ("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu"))
  :maintainers '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu")))
