;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-raku" "0.7"
  "Raku support in Flycheck."
  '((emacs    "26.3")
    (flycheck "0.22"))
  :url "https://github.com/Raku/flycheck-raku"
  :commit "d141782cf1c7936b2bbe027f82ec1c9887c08be3"
  :revdesc "d141782cf1c7"
  :keywords '("tools" "convenience")
  :authors '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com")
             ("Johnathon Weare" . "jrweare@gmail.com")
             ("Siavash Askari Nasr" . "siavash.askari.nasr@gmail.com"))
  :maintainers '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com")
                 ("Johnathon Weare" . "jrweare@gmail.com")
                 ("Siavash Askari Nasr" . "siavash.askari.nasr@gmail.com")))
