;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-less" "0.3"
  "Flymake handler for LESS stylesheets (lesscss.org)."
  '((less-css-mode "0.15"))
  :url "https://github.com/purcell/flymake-less"
  :commit "8cbb5e41c8f4b988cee3ef4449cfa9aea3540893"
  :revdesc "8cbb5e41c8f4"
  :keywords '("languages")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
