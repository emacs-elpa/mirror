;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "writefreely" "0.1.0"
  "Push your Org files as markdown to a writefreely instance."
  '((emacs   "24.3")
    (org     "9.0")
    (ox-gfm  "0.0")
    (request "0.3"))
  :url "https://github.com/dangom/writefreely.el"
  :commit "5344b5c516fa406866b2ea9b3d4ea6aff58fbe86"
  :revdesc "5344b5c516fa"
  :keywords '("convenience")
  :authors '(("Daniel Gomez" . "d.gomezatposteodotorg"))
  :maintainers '(("Daniel Gomez" . "d.gomezatposteodotorg")))
