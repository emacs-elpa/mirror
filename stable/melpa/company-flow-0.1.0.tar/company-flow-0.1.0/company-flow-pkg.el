;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-flow" "0.1.0"
  "Flow backend for company-mode."
  '((company "0.8.0")
    (cl-lib  "0.5.0"))
  :url "https://github.com/aaronjensen/company-flow"
  :commit "a3d80171d1c4e34b17e1e043c7e9309f40f0f4b4"
  :revdesc "a3d80171d1c4"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
