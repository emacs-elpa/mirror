;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elcord" "1.1.0"
  "Allows you to integrate Rich Presence from Discord."
  '((emacs "25.1"))
  :url "https://github.com/Mstrodl/elcord"
  :commit "76883a4aff46d32fd0462eaf29da8b8519b2645e"
  :revdesc "76883a4aff46"
  :keywords '("games")
  :authors '(("Wilfredo Velázquez-Rodríguez" . "zulu.inuoe@gmail.com"))
  :maintainers '(("Wilfredo Velázquez-Rodríguez" . "zulu.inuoe@gmail.com")))
