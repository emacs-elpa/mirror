;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sift" "0.2.0"
  "Front-end for sift, a fast and powerful grep alternative."
  ()
  :url "https://github.com/nlamirault/sift.el"
  :commit "8c3f3d14a351a2394027d72ee0599aa73b9f0d13"
  :revdesc "8c3f3d14a351"
  :keywords '("sift" "ack" "pt" "ag" "grep" "search")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
