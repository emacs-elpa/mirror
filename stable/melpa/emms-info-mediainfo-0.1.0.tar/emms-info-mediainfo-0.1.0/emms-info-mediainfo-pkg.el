;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms-info-mediainfo" "0.1.0"
  "Info-method for EMMS using medianfo."
  ()
  :url "https://github.com/fgallina/emms-info-mediainfo"
  :commit "67132f814c4a127982c624f62e8894336583521e"
  :revdesc "67132f814c4a"
  :keywords '("multimedia" "processes")
  :authors '(("Fabián Ezequiel Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Fabián Ezequiel Gallina" . "fgallina@gnu.org")))
