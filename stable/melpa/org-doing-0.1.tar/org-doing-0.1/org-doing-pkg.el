;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-doing" "0.1"
  "Keep track of what you're doing."
  ()
  :url "https://github.com/omouse/org-doing"
  :commit "6a74b573bcac737b0f068032efc2c6d3abc4f368"
  :revdesc "6a74b573bcac"
  :keywords '("tools" "org"))
