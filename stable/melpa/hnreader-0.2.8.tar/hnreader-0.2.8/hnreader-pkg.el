;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hnreader" "0.2.8"
  "A hackernews reader."
  '((emacs   "25.1")
    (promise "1.1")
    (request "0.3.0")
    (org     "9.2"))
  :url "https://github.com/thanhvg/emacs-hnreader/"
  :commit "a56f67a99a855ca656da1c1985e09f44509e4bbb"
  :revdesc "a56f67a99a85"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
