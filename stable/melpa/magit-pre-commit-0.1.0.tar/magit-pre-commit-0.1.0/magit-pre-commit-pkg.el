;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-pre-commit" "0.1.0"
  "Magit integration for pre-commit."
  '((emacs "29.1")
    (magit "3.0.0")
    (yaml  "0.5.0"))
  :url "https://github.com/DamianB-BitFlipper/magit-pre-commit.el"
  :commit "1b4056fc72c64b12aa2ac799d69a100aec253e39"
  :revdesc "1b4056fc72c6"
  :keywords '("git" "tools" "vc"))
