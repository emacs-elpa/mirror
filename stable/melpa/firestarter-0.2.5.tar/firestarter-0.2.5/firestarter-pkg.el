;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firestarter" "0.2.5"
  "Execute (shell) commands on save."
  ()
  :url "https://github.com/wasamasa/firestarter"
  :commit "4d6b106f325ac1802eabce3c8a7cd0a4c7a32864"
  :revdesc "4d6b106f325a"
  :keywords '("convenience")
  :authors '(("Vasilij Schneidermann" . "v.schneidermann@gmail.com"))
  :maintainers '(("Vasilij Schneidermann" . "v.schneidermann@gmail.com")))
