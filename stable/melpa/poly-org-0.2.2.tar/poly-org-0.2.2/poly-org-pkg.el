;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-org" "0.2.2"
  "Polymode for org-mode."
  '((emacs    "25")
    (polymode "0.2.2"))
  :url "https://github.com/polymode/poly-org"
  :commit "8f4d11489532be98a291258ca27405aa528fc126"
  :revdesc "8f4d11489532"
  :keywords '("languages" "multi-modes"))
