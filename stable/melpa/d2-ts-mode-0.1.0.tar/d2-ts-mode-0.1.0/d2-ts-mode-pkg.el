;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "d2-ts-mode" "0.1.0"
  "Tree-sitter support for D2."
  '((emacs "30.1"))
  :url "https://github.com/sorah/d2-ts-mode"
  :commit "5428aea7fdc2852df55022d6c18a13fbcef36754"
  :revdesc "5428aea7fdc2"
  :keywords '("languages" "d2" "tree-sitter"))
