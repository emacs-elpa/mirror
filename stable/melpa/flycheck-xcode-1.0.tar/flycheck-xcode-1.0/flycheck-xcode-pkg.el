;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-xcode" "1.0"
  "Flycheck extension for Apple's Xcode."
  '((emacs    "25.1")
    (flycheck "0.25"))
  :url "https://github.com/jojojames/flycheck-xcode"
  :commit "f2dbbfbf91e6532831d502ab315f0eb0237c2804"
  :revdesc "f2dbbfbf91e6"
  :keywords '("languages" "xcode")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
