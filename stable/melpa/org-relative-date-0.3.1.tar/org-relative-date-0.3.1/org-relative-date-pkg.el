;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-relative-date" "0.3.1"
  "Live relative-date overlays on org timestamps."
  '((emacs "27.1")
    (org   "9.1"))
  :url "https://github.com/RobertPlant/org-relative-date"
  :commit "b2ff8be7cb076f3e09c70f843aa410b9714e7ff6"
  :revdesc "b2ff8be7cb07"
  :keywords '("calendar" "org" "convenience")
  :authors '(("Rob Plant" . "rob@robertplant.io"))
  :maintainers '(("Rob Plant" . "rob@robertplant.io")))
