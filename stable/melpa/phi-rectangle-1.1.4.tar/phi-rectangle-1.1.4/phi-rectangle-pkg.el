;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-rectangle" "1.1.4"
  "Another rectangle-mark command (rewrite of rect-mark)."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "a755e42d1feeed4967ffbadd85240ee69e2002f4"
  :revdesc "a755e42d1fee")
