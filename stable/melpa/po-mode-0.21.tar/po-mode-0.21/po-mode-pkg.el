(define-package "po-mode" "0.21" "Major mode for GNU gettext PO files" 'nil :commit "25eb1bdca30ed25d2e5d51b9feeb28a3faff51ec" :keywords
  '("i18n" "gettext"))
;; Local Variables:
;; no-byte-compile: t
;; End:
