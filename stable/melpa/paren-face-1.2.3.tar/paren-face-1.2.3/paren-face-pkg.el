;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paren-face" "1.2.3"
  "A face for parentheses in lisp modes."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/paren-face"
  :commit "2c279a236404b2eebacb435aa92d5e9c97939c03"
  :revdesc "v1.2.3-0-g2c279a236404"
  :keywords '("faces" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev")))
