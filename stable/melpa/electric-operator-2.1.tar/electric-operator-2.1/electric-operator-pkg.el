;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-operator" "2.1"
  "Automatically add spaces around operators."
  '((dash  "2.10.0")
    (emacs "24.4"))
  :url "https://github.com/davidshepherd7/electric-operator"
  :commit "92c3eae146cb9bfcebef4b33498ab7d0973033fe"
  :revdesc "92c3eae146cb"
  :keywords '("electric")
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
