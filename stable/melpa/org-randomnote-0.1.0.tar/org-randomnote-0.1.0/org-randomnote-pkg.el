;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-randomnote" "0.1.0"
  "Find a random note in your Org-Mode files."
  '((f    "0.19.0")
    (dash "2.12.0"))
  :url "https://github.com/mwfogleman/org-randomnote"
  :commit "82129a67a7c119905bfaa7f340f2ba100e2bc7b2"
  :revdesc "82129a67a7c1"
  :authors '(("Michael Fogleman" . "michaelwfogleman@gmail.com"))
  :maintainers '(("Michael Fogleman" . "michaelwfogleman@gmail.com")))
