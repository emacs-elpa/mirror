;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-mongo" "0.1.0"
  "Execute mongodb queries within org-mode blocks."
  '((org "8"))
  :url "https://github.com/krisajenkins/ob-mongo"
  :commit "1cb2d279002a74544be265c7e269b34cdefe7ba4"
  :revdesc "1cb2d279002a"
  :keywords '("org" "babel" "mongo" "mongodb")
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
