;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "1.25.0"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.30.2")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "4837d1ce0f70a0f13741377438fd73a7631de45d"
  :revdesc "4837d1ce0f70"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
