;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wacspace" "0.4.2"
  "The WACky WorkSPACE manager for emACS."
  '((dash   "1.2.0")
    (cl-lib "0.2"))
  :url "https://github.com/shosti/wacspace.el"
  :commit "b951995c204ff23699d2bda515a96221147a725d"
  :revdesc "b951995c204f"
  :keywords '("workspace")
  :authors '(("Emanuel Evans" . "emanuel.evans@gmail.com"))
  :maintainers '(("Emanuel Evans" . "emanuel.evans@gmail.com")))
