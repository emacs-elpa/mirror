;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp-server-lib" "0.3.0"
  "Model Context Protocol server library."
  '((emacs "27.1"))
  :url "https://github.com/laurynas-biveinis/mcp-server-lib.el"
  :commit "e643b25af647e7bb5d3958262c9c728a3bb9676f"
  :revdesc "0.3.0-0-ge643b25af647"
  :keywords '("comm" "tools")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
