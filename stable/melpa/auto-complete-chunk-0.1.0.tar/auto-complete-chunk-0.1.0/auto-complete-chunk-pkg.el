;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-chunk" "0.1.0"
  "Auto-completion for dot.separated.words."
  '((auto-complete "1.4"))
  :url "https://github.com/tkf/auto-complete-chunk"
  :commit "a9aa77ffb84a1037984a7ce4dda25074272f13fe"
  :revdesc "a9aa77ffb84a")
