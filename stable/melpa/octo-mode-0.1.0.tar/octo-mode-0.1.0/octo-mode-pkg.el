;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "octo-mode" "0.1.0"
  "Major mode for Octo assembly language."
  ()
  :url "https://github.com/cryon/octo-mode"
  :commit "a9f9e652feb941d4a622f2d59f552a2261940ed0"
  :revdesc "a9f9e652feb9"
  :keywords '("language" "octo")
  :authors '(("John Olsson" . "john@cryon.se"))
  :maintainers '(("John Olsson" . "john@cryon.se")))
