;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-treeusage" "0.4"
  "Examine the usage of org headings in a tree-like manner."
  '((emacs "26.1")
    (dash  "2.17.0")
    (org   "9.1.6"))
  :url "https://github.com/mtekman/org-treeusage.el"
  :commit "f2d3e5cfac135dea304a3f75711520b0d80fc847"
  :revdesc "f2d3e5cfac13"
  :keywords '("outlines"))
