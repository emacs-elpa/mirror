;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "warm-mode" "0.1.0"
  "Warm colors for nighttime coding."
  '((emacs "27.1"))
  :url "https://github.com/smallwat3r/emacs-warm-mode"
  :commit "8ca28dcce43a186e8252980e498d01b1493c981d"
  :revdesc "8ca28dcce43a"
  :keywords '("faces" "convenience")
  :authors '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com"))
  :maintainers '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com")))
