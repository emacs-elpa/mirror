;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-leader" "0.4.3"
  "Let there be <leader>."
  '((evil "0"))
  :url "https://github.com/cofi/evil-leader"
  :commit "753b01eb4958370ae2226b3780ff31fe157c2852"
  :revdesc "753b01eb4958"
  :keywords '("evil" "vim-emulation" "leader")
  :authors '(("Michael Markert" . "markert.michael@googlemail.com"))
  :maintainers '(("Michael Markert" . "markert.michael@googlemail.com")))
