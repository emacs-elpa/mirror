;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient-dwim" "1.0.0"
  "Useful preset transient commands."
  '((emacs     "26.1")
    (transient "0.1"))
  :url "https://github.com/conao3/transient-dwim.el"
  :commit "2f4e5c361048e4bc36973f75a62c107660d6d743"
  :revdesc "2f4e5c361048"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
