;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unidecode" "0.1"
  "Convert Unicode text into safe ASCII strings."
  ()
  :url "https://github.com/sindikat/unidecode"
  :commit "55344fe1714da390df5403fd960d13d9b1576e8c"
  :revdesc "55344fe1714d"
  :authors '(("sindikat" . "sindikatatmail36dotnet"))
  :maintainers '(("sindikat" . "sindikatatmail36dotnet")))
