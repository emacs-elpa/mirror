;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "1.27.2"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.30.2")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "b122f2e043313d470fa68c0c1e042e3dec536cbf"
  :revdesc "b122f2e04331"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
