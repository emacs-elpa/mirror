;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-latex-impatient" "0.1.0"
  "Preview org-latex Fragments Instantly via MathJax."
  '((emacs    "26")
    (names    "0.5.2")
    (s        "1.8.0")
    (posframe "0.8.0")
    (org      "9.3")
    (dash     "2.17.0"))
  :url "https://github.com/yangsheng6810/org-latex-instant-preview"
  :commit "15c640904ec52bda40a465d80a0f8fa59337fc49"
  :revdesc "15c640904ec5"
  :keywords '("tex" "tools")
  :authors '(("Sheng Yang" . "styang@fastmail.com"))
  :maintainers '(("Sheng Yang" . "styang@fastmail.com")))
