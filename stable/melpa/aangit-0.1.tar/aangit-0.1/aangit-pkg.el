;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aangit" "0.1"
  "Quickly scaffold new Angular apps with Aangit."
  '((emacs     "28.1")
    (transient "0.4"))
  :url "https://github.com/stephenwithav/aangit"
  :commit "e23404199c598695ccd28c31ce032acd2de9932a"
  :revdesc "e23404199c59"
  :keywords '("angular")
  :authors '(("Steven Edwards" . "steven@stephenwithav.io"))
  :maintainers '(("Steven Edwards" . "steven@stephenwithav.io")))
