;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "now-playing" "1.1.0"
  "Interface for the macOS Music app."
  '((emacs     "30.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/now-playing"
  :commit "262766052b0036e3e3600248e30f3ac4aca24f9d"
  :revdesc "262766052b00"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
