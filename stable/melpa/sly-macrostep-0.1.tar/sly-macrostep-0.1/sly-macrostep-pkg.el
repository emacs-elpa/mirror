;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly-macrostep" "0.1"
  "Support named readtables in Common Lisp files."
  '((sly "1.0.0-beta2"))
  :url "https://github.com/capitaomorte/sly-macrostep"
  :commit "d3e07006d9b1d87237d7c0cf85249701abba1af5"
  :revdesc "d3e07006d9b1"
  :keywords '("languages" "lisp" "sly")
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
