;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "robot-mode" "0.8.0"
  "Major-mode for Robot Framework files."
  '((emacs "26.1"))
  :url "https://github.com/kopoli/robot-mode"
  :commit "cb12e5adcba3379a67483e268229c152e0a8405f"
  :revdesc "v0.8.0-0-gcb12e5adcba3"
  :keywords '("languages" "files")
  :authors '(("Kalle Kankare" . "kalle.kankare@iki.fi"))
  :maintainers '(("Kalle Kankare" . "kalle.kankare@iki.fi")))
