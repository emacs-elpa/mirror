;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-forge" "0.0.0"
  "Company backend for mentions and references from forge."
  '((emacs   "29.1")
    (company "1.0.0")
    (forge   "0.4.0"))
  :url "https://github.com/pkryger/company-forge.el"
  :commit "640d61dd34a6384949f7f2921461975d846b7b23"
  :revdesc "640d61dd34a6"
  :keywords '("tools" "completion" "company" "forge")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
