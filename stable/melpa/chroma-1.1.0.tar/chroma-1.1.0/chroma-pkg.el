;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chroma" "1.1.0"
  "Color manipulation library."
  '((emacs "24.1"))
  :url "https://github.com/galdor/chroma"
  :commit "ace854e577a126f830443de89f617e5ff4b4cfce"
  :revdesc "v1.1.0-0-gace854e577a1"
  :authors '(("Nicolas Martyanoff" . "nicolas@n16f.net"))
  :maintainers '(("Nicolas Martyanoff" . "nicolas@n16f.net")))
