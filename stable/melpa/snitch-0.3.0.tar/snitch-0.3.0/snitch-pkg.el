;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snitch" "0.3.0"
  "An Emacs firewall."
  '((emacs "27.1"))
  :url "https://github.com/mrmekon/snitch-el"
  :commit "14e91336fb04c23d7b23836642eef3f2edef03bf"
  :revdesc "snitch-0.3.0-0-g14e91336fb04"
  :keywords '("processes" "comm")
  :authors '(("Trevor Bentley" . "snitch.el@x.mrmekon.com"))
  :maintainers '(("Trevor Bentley" . "snitch.el@x.mrmekon.com")))
