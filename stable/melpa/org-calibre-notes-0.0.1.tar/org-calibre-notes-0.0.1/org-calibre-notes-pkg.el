;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-calibre-notes" "0.0.1"
  "Extract highlights and notes from Calibre EPUB reader."
  '((counsel "0.13.4")
    (emacs   "27.1"))
  :url "https://github.com/bpanthi977/org-calibre-notes"
  :commit "f9f4b2b8abe1f7f9bc00bd738aba3d040b24b10a"
  :revdesc "f9f4b2b8abe1"
  :authors '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainers '(("Bibek Panthi" . "bpanthi977@gmail.com")))
