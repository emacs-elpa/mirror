;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vuiet" "1.0"
  "The music player and explorer for Emacs."
  '((emacs    "26.1")
    (lastfm   "1.1")
    (versuri  "1.0")
    (s        "1.12.0")
    (bind-key "2.4")
    (mpv      "0.1.0"))
  :url "https://github.com/mihaiolteanu/vuiet"
  :commit "4e15dacd6445d490fefc47070f8e5b98db5e0dc6"
  :revdesc "4e15dacd6445"
  :keywords '("multimedia")
  :authors '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainers '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm")))
