;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-emacs" "0.4.2"
  "Evaluate Emacs Lisp expressions in a separate Emacs process."
  '((emacs "24.4"))
  :url "https://github.com/twlz0ne/with-emacs.el"
  :commit "1e5b65a8b879dbc423e42e53a61dfd87cb131f40"
  :revdesc "1e5b65a8b879"
  :keywords '("tools")
  :authors '(("Gong Qijian" . "gongqijian@gmail.com"))
  :maintainers '(("Gong Qijian" . "gongqijian@gmail.com")))
