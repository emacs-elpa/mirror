;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "i3wm-config-mode" "1.0"
  "Better syntax highlighting for i3wm's config file."
  ()
  :url "TODO"
  :commit "4d0709b742570cbb73fb638de28557bb8f1aa233"
  :revdesc "4d0709b74257"
  :keywords '("i3" "config" "syntax highlighting" "font-lock")
  :authors '(("Alexander Miller" . "alexanderm@web.de"))
  :maintainers '(("Alexander Miller" . "alexanderm@web.de")))
