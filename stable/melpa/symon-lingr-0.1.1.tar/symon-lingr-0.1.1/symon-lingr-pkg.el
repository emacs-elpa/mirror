;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symon-lingr" "0.1.1"
  "A notification-based Lingr client powered by symon.el."
  '((symon "1.1.2"))
  :url "http://hins11.yu-yake.com/"
  :commit "566ca54cf8b262f71f4af9314b82549b664d96fa"
  :revdesc "566ca54cf8b2")
