;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "figlet" "0.5"
  "Annoy people with big, ascii art text."
  ()
  :url "https://github.com/jpkotta/figlet"
  :commit "de95386fd7f969a58b3531e28016279a28c848b0"
  :revdesc "de95386fd7f9"
  :authors '(("Philip Jackson" . "phil@shellarchive.co.uk"))
  :maintainers '(("Philip Jackson" . "phil@shellarchive.co.uk")))
