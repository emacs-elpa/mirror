;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "2bit" "1.0"
  "Library for reading data from 2bit files."
  '((emacs "24.3"))
  :url "https://github.com/davep/2bit.el"
  :commit "1ce390483cf55a039a8bdad28d294ce068f31e75"
  :revdesc "1ce390483cf5"
  :keywords '("files" "data")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
