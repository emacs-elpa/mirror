;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "httpcode" "0.1"
  "Explains the meaning of an HTTP status code."
  ()
  :url "https://github.com/rspivak/httpcode.el"
  :commit "2c8eb3b5455254ba70fb71f7178886bfc2d3af90"
  :revdesc "2c8eb3b54552"
  :authors '(("Ruslan Spivak" . "ruslan.spivak@gmail.com"))
  :maintainers '(("Ruslan Spivak" . "ruslan.spivak@gmail.com")))
