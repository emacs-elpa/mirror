;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "datetime" "0.10.2"
  "Parsing, formatting and matching timestamps."
  '((emacs  "25.1")
    (extmap "1.1.1"))
  :url "https://github.com/doublep/datetime"
  :commit "b8e5fc2b7338f26ee816a3b03322c585dbd3b686"
  :revdesc "b8e5fc2b7338"
  :keywords '("lisp" "i18n")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
