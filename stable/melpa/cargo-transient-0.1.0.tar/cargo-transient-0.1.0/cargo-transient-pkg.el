;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cargo-transient" "0.1.0"
  "A transient for interacting with cargo."
  '((emacs "28.1"))
  :url "https://github.com/peterstuart/cargo-transient"
  :commit "5a0e5f6c2abd1583bd31f0b6a39336ab7a127830"
  :revdesc "5a0e5f6c2abd"
  :authors '(("Peter Stuart" . "peter@peterstuart.org"))
  :maintainers '(("Peter Stuart" . "peter@peterstuart.org")))
