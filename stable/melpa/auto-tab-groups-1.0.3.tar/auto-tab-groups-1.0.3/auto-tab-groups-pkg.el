;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-tab-groups" "1.0.3"
  "Simple auto tab group creator for specified commands."
  '((emacs "29.1"))
  :url "https://github.com/MArpogaus/auto-tab-groups"
  :commit "170397f4d10c53f8faf66c6690b5837d24967875"
  :revdesc "v1.0.3-0-g170397f4d10c"
  :keywords '("convenience" "tabs")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
