;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "point-stack" "1.1"
  "Back and forward navigation through buffer locations."
  ()
  :url "https://github.com/dgutov/point-stack"
  :commit "c5070a2246a335d5266a09781b5db7bd77e7054c"
  :revdesc "c5070a2246a3"
  :authors '(("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainers '(("Dmitry Gutov" . "dgutov@yandex.ru")))
