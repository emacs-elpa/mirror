;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-secretario-org" "0.0.1"
  "[No description available]."
  '((emacs  "26.1")
    (cl-lib "0.5"))
  :url "https://github.com/leo/el-secretario-org"
  :commit "73274798c0ab2f4ec09e4944db904edfa8dcc045"
  :revdesc "73274798c0ab"
  :authors '(("Leo" . "http://github/leo"))
  :maintainers '(("Leo" . "leo@leo-B85-HD3")))
