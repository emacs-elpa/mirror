;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons-completion" "0.0.1"
  "Add icons to completion candidates."
  '((emacs      "25.1")
    (nerd-icons "0.0.1"))
  :url "https://github.com/rainstormstudio/nerd-icons-completion"
  :commit "6b4704ae580fe3a288916b2c0090d8d39f3d3bee"
  :revdesc "6b4704ae580f"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")))
