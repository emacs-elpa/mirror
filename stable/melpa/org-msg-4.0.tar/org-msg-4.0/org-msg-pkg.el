;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-msg" "4.0"
  "Org mode to send and reply to email in HTML."
  '((emacs   "24.4")
    (htmlize "1.54"))
  :url "https://github.com/jeremy-compostella/org-msg"
  :commit "60e22e446325a9b3387396459d98be7c1c52579d"
  :revdesc "60e22e446325"
  :keywords '("extensions" "mail")
  :authors '(("Jérémy Compostella" . "jeremy.compostella@gmail.com"))
  :maintainers '(("Jérémy Compostella" . "jeremy.compostella@gmail.com")))
