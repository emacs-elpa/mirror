;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brainfuck-mode" "0.0.0.20150113.16"
  "Brainfuck mode for Emacs."
  '((langdoc "20130601.1450"))
  :url "https://github.com/tom-tan/brainfuck-mode/"
  :commit "36e69552bb3b97a4f888d362c59845651bd0d492"
  :revdesc "36e69552bb3b"
  :keywords '("brainfuck" "langdoc")
  :authors '(("Tomoya Tanjo" . "ttanjo@gmail.com"))
  :maintainers '(("Tomoya Tanjo" . "ttanjo@gmail.com")))
