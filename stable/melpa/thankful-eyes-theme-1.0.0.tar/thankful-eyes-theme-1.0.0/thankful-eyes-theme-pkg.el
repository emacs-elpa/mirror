;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thankful-eyes-theme" "1.0.0"
  "Thankful Eyes: Un tema oscuro elegante para Emacs."
  '((emacs "24.1"))
  :url "https://github.com/tuusuario/thankful-eyes-theme"
  :commit "0c82dda70a0dbb67c4e167c82cb10211631e1eb6"
  :revdesc "0c82dda70a0d"
  :keywords '("themes" "color")
  :authors '(("Tu Nombre" . "tu@email.com"))
  :maintainers '(("Tu Nombre" . "tu@email.com")))
