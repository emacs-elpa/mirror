;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-commit-insert-issue" "0.4.1"
  "Get issues list when typing \"Fixes #\"."
  '((emacs      "25")
    (projectile "0")
    (s          "0")
    (ghub       "0")
    (bitbucket  "0"))
  :url "https://gitlab.com/emacs-stuff/git-commit-insert-issue/"
  :commit "8a403005ea7f7611bb1bfd829eeefe5a4f10bb40"
  :revdesc "8a403005ea7f"
  :keywords '("tools" "vc" "github" "gitlab" "bitbucket" "commit" "issues"))
