;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eros-inspector" "1.0.1"
  "Glue between eros and inspector."
  '((emacs     "24.4")
    (eros      "0.1.0")
    (inspector "0.38"))
  :url "https://github.com/port19x/eros-inspector"
  :commit "c1625f553ec944883867f0975bff08f10dd3086f"
  :revdesc "c1625f553ec9"
  :keywords '("convenience" "lisp" "tool" "debugging" "development")
  :authors '(("port19" . "port19@port19.xyz"))
  :maintainers '(("port19" . "port19@port19.xyz")))
