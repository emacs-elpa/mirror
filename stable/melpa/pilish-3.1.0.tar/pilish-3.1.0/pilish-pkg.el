;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.1.0"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.4.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "c795351037df4ff9c49ea7ac89ca217770c3757e"
  :revdesc "v3.1.0-0-gc795351037df"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
