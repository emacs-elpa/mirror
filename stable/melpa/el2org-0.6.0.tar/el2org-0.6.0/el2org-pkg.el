;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el2org" "0.6.0"
  "Convert elisp file to org file."
  '((emacs "25.1"))
  :url "https://github.com/tumashu/el2org"
  :commit "4a33469cd305e581603d7ef63bc2a1f2156f2e2e"
  :revdesc "4a33469cd305"
  :keywords '("convenience")
  :authors '(("Feng Shu" . "tumashuAT163.com"))
  :maintainers '(("Feng Shu" . "tumashuAT163.com")))
