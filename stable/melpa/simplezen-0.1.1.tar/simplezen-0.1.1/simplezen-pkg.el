;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simplezen" "0.1.1"
  "A simple subset of zencoding-mode for Emacs."
  ()
  :url "https://github.com/magnars/simplezen.el"
  :commit "c0ddaefbb38fcc1c9775434f734f89227d246a30"
  :revdesc "0.1.1-0-gc0ddaefbb38f"
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
