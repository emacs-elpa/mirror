;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-jump-zap" "0.1.2"
  "Character zapping, `ace-jump-mode` style."
  '((ace-jump-mode "1.0")
    (dash          "2.10.0"))
  :url "https://github.com/waymondo/ace-jump-zap"
  :commit "1a9bf779d8f9225ede9ec482b840942bb58111df"
  :revdesc "1a9bf779d8f9"
  :keywords '("convenience" "tools" "extensions")
  :authors '(("justin talbott" . "justin@waymondo.com"))
  :maintainers '(("justin talbott" . "justin@waymondo.com")))
