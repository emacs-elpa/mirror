;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lf" "1.0"
  "A Language Features library for Emacs Lisp."
  '((s     "1.12.0")
    (dash  "2.16.0")
    (emacs "27.1")
    (org   "9.1"))
  :url "https://alhassy.github.io/lf.el/"
  :commit "b7aafa945be046aa30cc003a1f8e5a7eea9e6ce3"
  :revdesc "b7aafa945be0"
  :keywords '("convenience" "programming")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
