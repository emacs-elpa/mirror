;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "db" "0.0.6"
  "A database for EmacsLisp."
  '((kv "0.0.11"))
  :url "https://github.com/nicferrier/emacs-db"
  :commit "976c508d26d6465b683fe2299691d1964a60b3dc"
  :revdesc "976c508d26d6"
  :keywords '("data" "lisp")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
