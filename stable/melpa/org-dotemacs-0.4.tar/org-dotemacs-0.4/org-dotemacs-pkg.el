;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-dotemacs" "0.4"
  "Store your emacs config as an org file, and choose which bits to load."
  '((org    "7.9.3")
    (cl-lib "0.5"))
  :url "https://github.com/vapniks/org-dotemacs"
  :commit "36b0bcf4f3ff7d5c318db4eeeb171a32d5ea8164"
  :revdesc "36b0bcf4f3ff"
  :keywords '("local")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
