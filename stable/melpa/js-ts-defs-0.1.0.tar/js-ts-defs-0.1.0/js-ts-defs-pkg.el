;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-ts-defs" "0.1.0"
  "Find JavaScript variable definitions using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/jacksonrayhamilton/js-ts-defs"
  :commit "459431b3f99a44fc04b43a4f5bad5ba401d1c294"
  :revdesc "459431b3f99a"
  :keywords '("languages" "javascript" "tree-sitter")
  :authors '(("Jackson Ray Hamilton" . "jackson@jacksonrayhamilton.com"))
  :maintainers '(("Jackson Ray Hamilton" . "jackson@jacksonrayhamilton.com")))
