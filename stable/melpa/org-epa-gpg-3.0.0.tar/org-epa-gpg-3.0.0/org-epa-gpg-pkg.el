;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-epa-gpg" "3.0.0"
  "Patch to enable EasyPG .gpg images in Org mode inline."
  '((emacs "27.1"))
  :url "https://github.com/KeyWeeUsr/org-epa-gpg"
  :commit "6f3b8b77bdf63e96465322bbb545b96c9641d521"
  :revdesc "3.0.0-0-g6f3b8b77bdf6"
  :keywords '("lisp" "org" "gpg" "pgp" "epa" "encryption" "image" "inline" "patch")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
