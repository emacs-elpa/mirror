;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-args" "1.0"
  "Motions and text objects for delimited arguments in Evil."
  '((evil "1.0.8"))
  :url "https://github.com/wcsmith/evil-args"
  :commit "2a88b4d19953a11227cc1e91973b92149116f44c"
  :revdesc "2a88b4d19953"
  :keywords '("evil" "vim-emulation")
  :authors '(("Connor Smith" . "wconnorsmith@gmail.com"))
  :maintainers '(("Connor Smith" . "wconnorsmith@gmail.com")))
