;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-rage" "0.0.1"
  "Helm command for rage characters."
  '((helm  "1.9.8")
    (emacs "24.4"))
  :url "https://github.com/bomgar/helm-rage"
  :commit "bba0f3ce91f2e7f174dadd6260000316a5358397"
  :revdesc "bba0f3ce91f2")
