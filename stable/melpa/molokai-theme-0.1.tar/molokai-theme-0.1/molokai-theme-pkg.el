;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "molokai-theme" "0.1"
  "Molokai theme with Emacs theme engine."
  ()
  :url "https://github.com/alloy-d/color-theme-molokai"
  :commit "96182c2adb10d3b3c8cdcdc5f94a61ad9e09d3c0"
  :revdesc "96182c2adb10"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
