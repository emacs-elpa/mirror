;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hsluv" "1.0.0"
  "Hsluv color space conversions."
  ()
  :url "https://github.com/woozong/hsluv-elisp"
  :commit "8713e5fbafd834635a93c37b0ddfad5bd3d38aa8"
  :revdesc "8713e5fbafd8"
  :keywords '("color"))
