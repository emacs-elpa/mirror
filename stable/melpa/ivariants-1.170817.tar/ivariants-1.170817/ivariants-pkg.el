;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivariants" "1.170817"
  "Ideographic variants editor and browser."
  '((emacs    "24.3")
    (ivs-edit "1.0"))
  :url "https://github.com/kawabata/ivariants"
  :commit "c056850745fcfa1e20aed9f6a7378869c623b5c7"
  :revdesc "c056850745fc"
  :keywords '("i18n" "languages")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
