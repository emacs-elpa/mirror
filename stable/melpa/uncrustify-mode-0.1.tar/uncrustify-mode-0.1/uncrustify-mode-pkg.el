;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uncrustify-mode" "0.1"
  "Minor mode to automatically uncrustify."
  ()
  :url "https://github.com/koko1000ban/emacs-uncrustify-mode"
  :commit "8618e7afc8c1ea1a9d7683bade574f0fff6182f1"
  :revdesc "8618e7afc8c1"
  :keywords '("popup" "gtags")
  :authors '(("Tabito Ohtani" . "koko1000ban@gmail.com"))
  :maintainers '(("Tabito Ohtani" . "koko1000ban@gmail.com")))
