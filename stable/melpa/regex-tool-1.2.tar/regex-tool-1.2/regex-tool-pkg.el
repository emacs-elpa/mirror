;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "regex-tool" "1.2"
  "[No description available]."
  ()
  :url "http://www.newartisans.com/"
  :commit "68966cbe6e6efa4213c32930388408b7b48cdcbf"
  :revdesc "68966cbe6e6e"
  :keywords '("regex" "languages" "programming" "development")
  :authors '(("John Wiegley" . "johnw@newartisans.com"))
  :maintainers '(("John Wiegley" . "johnw@newartisans.com")))
