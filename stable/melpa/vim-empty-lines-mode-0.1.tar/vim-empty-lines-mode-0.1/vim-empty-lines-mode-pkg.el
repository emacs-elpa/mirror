;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-empty-lines-mode" "0.1"
  "Vim-like empty line indicator at end of files."
  '((emacs "23"))
  :url "https://github.com/jmickelin/vim-empty-lines-mode"
  :commit "7f6267c71627333b2cf8c9035b8f497c92029ae5"
  :revdesc "7f6267c71627"
  :keywords '("emulations")
  :authors '(("Jonne Mickelin" . "jonne@ljhms.com"))
  :maintainers '(("Jonne Mickelin" . "jonne@ljhms.com")))
