;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snap-indent" "1.1"
  "Simple automatic indentation."
  '((emacs "24.1"))
  :url "https://github.com/jeffvalk/snap-indent"
  :commit "ef3bcab6535f6503d4b0812ce6acd3b184b49484"
  :revdesc "ef3bcab6535f"
  :keywords '("indent" "tools" "convenience")
  :authors '(("Jeff Valk" . "jv@jeffvalk.com"))
  :maintainers '(("Jeff Valk" . "jv@jeffvalk.com")))
