;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-clipmenu" "0.0.1"
  "Emacs client for clipmenu."
  '((emacs "24")
    (emacs "25.1")
    (f     "0.20.0")
    (s     "1.12.0")
    (dash  "2.16.0")
    (ivy   "0.13.0"))
  :url "https://github.com/wpcarro/ivy-clipmenu.el"
  :commit "c9ccfa7f03edc66bd5deb6d5afcd3f7cf5149fdc"
  :revdesc "c9ccfa7f03ed"
  :authors '(("William Carroll" . "wpcarro@gmail.com"))
  :maintainers '(("William Carroll" . "wpcarro@gmail.com")))
