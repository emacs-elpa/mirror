;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-grep" "1.0"
  "Grep/search tools and configuration."
  '((projectile "0.10.0"))
  :url "https://github.com/tychoish/git-grep/"
  :commit "efd17cf9f0a7b953861728adc2b53db7be6ad0f9"
  :revdesc "efd17cf9f0a7"
  :keywords '("grep" "search" "using" "git-grep")
  :maintainers '(("tychoish" . "garen@tychoish.com")))
