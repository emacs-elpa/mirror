;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "janet-mode" "0.1.0"
  "Defines a major mode for Janet."
  '((emacs "24.3"))
  :url "https://github.com/ALSchwalm/janet-mode"
  :commit "94a59b3d9a52447f9272e55fc5503376aae638e8"
  :revdesc "94a59b3d9a52"
  :authors '(("Adam Schwalm" . "adamschwalm@gmail.com"))
  :maintainers '(("Adam Schwalm" . "adamschwalm@gmail.com")))
