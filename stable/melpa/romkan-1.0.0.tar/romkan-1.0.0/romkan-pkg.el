;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "romkan" "1.0.0"
  "Romaji/Kana conversion library."
  '((emacs "24.3"))
  :url "https://github.com/cromo/romkan"
  :commit "98f41dfd83837b6658a1cf1dc3aeaccba4cf0021"
  :revdesc "v1.0.0-0-g98f41dfd8383"
  :keywords '("i18n" "languages")
  :authors '(("gicrisf" . "giovanni.crisalfi@protonmail.com"))
  :maintainers '(("gicrisf" . "giovanni.crisalfi@protonmail.com")))
