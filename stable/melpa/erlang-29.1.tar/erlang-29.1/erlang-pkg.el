;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "29.1"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "751f87b703fe5948607d08e82599ce644b772e76"
  :revdesc "OTP-29.1-0-g751f87b703fe"
  :keywords '("erlang" "languages" "processes"))
