;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "distinguished-theme" "0.0.1"
  "A dark and elegant theme for emacs."
  ()
  :url "https://github.com/Lokaltog/distinguished-theme"
  :commit "20c3b5e46eb89137b654c7d375e657cd4588d39c"
  :revdesc "20c3b5e46eb8"
  :authors '(("Kim Silkebækken" . "kim.silkebaekken@gmail.com"))
  :maintainers '(("Kim Silkebækken" . "kim.silkebaekken@gmail.com")))
