;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "synquid" "0.1"
  "Major mode for editing Synquid files."
  '((flycheck "27")
    (emacs    "24.3"))
  :url "https://github.com/cpitclaudel/synquid-mode"
  :commit "e400c59ade9d24c568bec88c8d1e9e829b19a774"
  :revdesc "e400c59ade9d"
  :keywords '("languages")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
