;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tangonov-theme" "1.5.1"
  "A 256 color dark theme featuring bright pastels."
  '((emacs "27.1"))
  :url "https://sr.ht/~trevdev/tangonov-theme/"
  :commit "ab5d75805187018fcd0b698bbc05019477afa94a"
  :revdesc "1.5.1-0-gab5d75805187"
  :keywords '("faces" "theme" "dark" "fringe")
  :authors '(("Trevor Richards" . "trev@trevdev.ca"))
  :maintainers '(("Trevor Richards" . "trev@trevdev.ca")))
