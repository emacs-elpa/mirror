;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truthy" "0.2.8"
  "Test the content of a value."
  '((list-utils "0.4.2"))
  :url "https://github.com/rolandwalker/truthy"
  :commit "276a7e6b13606d28e4f2e423bb1ea30904c5def3"
  :revdesc "v0.2.8-0-g276a7e6b1360"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
