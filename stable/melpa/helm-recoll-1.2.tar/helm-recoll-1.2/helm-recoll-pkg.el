;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-recoll" "1.2"
  "Helm interface for the recoll desktop search tool."
  '((helm  "3.3")
    (emacs "24.4"))
  :url "https://github.com/emacs-helm/helm-recoll"
  :commit "8548b157f40f5e7a4940a54abe5ca0016fd9bdee"
  :revdesc "1.2-0-g8548b157f40f"
  :keywords '("convenience")
  :authors '(("Thierry Volpiatto" . "thierry.volpiattoatgmail.com"))
  :maintainers '(("Joe Bloggs" . "vapniksatyahoo.com")
                 ("Michael Heerdegen" . "michael_heerdegenatweb.de")
                 ("Cayetano Santos" . "cayetanosantosatgmail.com")))
