;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy-dash" "0.13.0"
  "Dash destructuring for `loopy'."
  '((emacs "25.1")
    (loopy "0.13.0")
    (dash  "2.19"))
  :url "https://github.com/okamsn/loopy"
  :commit "56c8413dbcffef2b1a0896d53584296619cb1504"
  :revdesc "56c8413dbcff"
  :keywords '("extensions"))
