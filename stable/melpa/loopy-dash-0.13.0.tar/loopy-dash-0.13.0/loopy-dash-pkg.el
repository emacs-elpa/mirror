;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy-dash" "0.13.0"
  "Dash destructuring for `loopy'."
  '((emacs "25.1")
    (loopy "0.13.0")
    (dash  "2.19"))
  :url "https://github.com/okamsn/loopy"
  :commit "80a30903628bc8de36c51c966e6cf5b114001e47"
  :revdesc "80a30903628b"
  :keywords '("extensions"))
