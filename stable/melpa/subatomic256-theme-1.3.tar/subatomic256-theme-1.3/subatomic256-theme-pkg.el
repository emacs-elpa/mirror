;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "subatomic256-theme" "1.3"
  "Fork of subatomic-theme for terminals."
  ()
  :url "https://github.com/cryon/subatomic256"
  :commit "27d8061b29aeac9560fd7c7e6868ca11bf105b7c"
  :revdesc "27d8061b29ae"
  :authors '(("John Olsson" . "john@cryon.se"))
  :maintainers '(("John Olsson" . "john@cryon.se")))
