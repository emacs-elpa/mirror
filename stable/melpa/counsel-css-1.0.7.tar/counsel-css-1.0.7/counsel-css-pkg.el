;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-css" "1.0.7"
  "Stylesheet-selector-aware swiper."
  '((emacs   "24.4")
    (counsel "0.7.0")
    (cl-lib  "0.5"))
  :url "https://github.com/hlissner/emacs-counsel-css"
  :commit "61a38c9d50fa9d1e38b2fa550d07130eb9322524"
  :revdesc "61a38c9d50fa"
  :keywords '("convenience" "tools" "counsel" "swiper" "selector" "css" "less" "scss")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "henrik@lissner.net")))
