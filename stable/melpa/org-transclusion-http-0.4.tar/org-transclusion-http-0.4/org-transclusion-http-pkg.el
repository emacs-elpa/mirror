;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-transclusion-http" "0.4"
  "Transclude over HTTP."
  '((emacs            "28.1")
    (org-transclusion "1.4.0")
    (plz              "0.7.2"))
  :url "https://git.sr.ht/~ushin/org-transclusion-http"
  :commit "a764f05a9eaeca002c76b85d090ca6b036e9dbaf"
  :revdesc "v0.4-0-ga764f05a9eae"
  :authors '(("Joseph Turner" . "firstnameatushin.org"))
  :maintainers '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht")))
