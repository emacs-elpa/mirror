;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lox-ts-mode" "0.1.0"
  "Major mode for Lox using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/lox-ts-mode"
  :commit "7737f251fab5c5a603b5bd2550bdd08ceb0b0bb5"
  :revdesc "7737f251fab5"
  :keywords '("lox" "tree-sitter" "languages")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
