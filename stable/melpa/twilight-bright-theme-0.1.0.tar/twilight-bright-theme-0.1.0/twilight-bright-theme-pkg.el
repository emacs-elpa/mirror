;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "twilight-bright-theme" "0.1.0"
  "A Emacs 24 faces port of the TextMate theme."
  ()
  :url "https://github.com/jimeh/twilight-bright-theme.el"
  :commit "c461673b8962ac3f9e5f0df276d2f2186a2e6ee0"
  :revdesc "c461673b8962"
  :keywords '("themes")
  :authors '(("Jim Myhrberg" . "contact@jimeh.me"))
  :maintainers '(("Jim Myhrberg" . "contact@jimeh.me")))
