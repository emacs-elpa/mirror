;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blamee" "1.0.5"
  "Chunked git-blame overlays with popup details."
  '((emacs "27.1"))
  :url "https://github.com/fvi-att/blamee"
  :commit "60bb7e7dd29e0e0fabd172e91d362b00fac363c4"
  :revdesc "1.0.5-0-g60bb7e7dd29e"
  :keywords '("tools" "vc" "git")
  :authors '(("fvi-att" . "jshimizujp@gmail.com"))
  :maintainers '(("fvi-att" . "jshimizujp@gmail.com")))
