;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bullets" "0.2.4"
  "Show bullets in org-mode as UTF-8 characters."
  ()
  :url "https://github.com/sabof/org-bullets"
  :commit "b70ac2ec805bcb626a6e39ea696354577c681b36"
  :revdesc "b70ac2ec805b")
