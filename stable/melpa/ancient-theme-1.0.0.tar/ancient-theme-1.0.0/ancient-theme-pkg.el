;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ancient-theme" "1.0.0"
  "A theme about a ruins."
  '((emacs "27.1"))
  :url "https://github.com/thomasbestvina/ancient-theme"
  :commit "16c2904e5e30d46bb0278c4108c8e906e6f75973"
  :revdesc "16c2904e5e30"
  :keywords '("faces" "theme")
  :authors '(("Thomas Bestvina" . "bestvinathomas@gmail.com"))
  :maintainers '(("Thomas Bestvina" . "bestvinathomas@gmail.com")))
