;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hide-mode-line" "1.0.3"
  "Minor mode that hides/masks your modeline."
  '((emacs "24.4"))
  :url "https://github.com/hlissner/emacs-hide-mode-line"
  :commit "bc5d293576c5e08c29e694078b96a5ed85631942"
  :revdesc "v1.0.3-0-gbc5d293576c5"
  :keywords '("frames" "mode-line")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "git@henrik.io")))
