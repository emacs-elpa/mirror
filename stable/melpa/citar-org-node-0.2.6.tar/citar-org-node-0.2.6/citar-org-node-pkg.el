;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-org-node" "0.2.6"
  "Citar integration with org-node."
  '((emacs    "26.1")
    (citar    "1.1")
    (org-node "3.0.0")
    (ht       "1.6"))
  :url "https://github.com/krisbalintona/citar-org-node"
  :commit "edc3e7e7abfd8dc5ad029df79d28b0c317ff8ac7"
  :revdesc "edc3e7e7abfd"
  :keywords '("tools")
  :authors '(("Kristoffer Balintona" . "krisbalintona@gmail.com"))
  :maintainers '(("Kristoffer Balintona" . "krisbalintona@gmail.com")))
