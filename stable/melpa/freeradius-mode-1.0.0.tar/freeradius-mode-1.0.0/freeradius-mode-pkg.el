;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "freeradius-mode" "1.0.0"
  "Major mode for FreeRadius server config files."
  '((emacs "24.4"))
  :url "https://github.com/VersBinarii/freeradius-mode"
  :commit "3c3e63de6132e9ee25d15ccba32903f8afb83ba5"
  :revdesc "3c3e63de6132")
