;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pomm" "0.2.0"
  "Pomodoro and Third Time timers."
  '((emacs     "27.1")
    (alert     "1.2")
    (seq       "2.22")
    (transient "0.3.0"))
  :url "https://github.com/SqrtMinusOne/pomm.el"
  :commit "0942131ac3f2d20cc1004eecdb99ec0db1271c31"
  :revdesc "0942131ac3f2"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
