;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-flx" "20151016"
  "Flx based fuzzy matching for company."
  '((emacs   "24")
    (company "0.8.12")
    (flx     "0.5"))
  :url "https://github.com/PythonNut/helm-flx"
  :commit "5b4db06a49ac3ed197479f49e766f574ed3f56c4"
  :revdesc "5b4db06a49ac"
  :keywords '("convenience" "company" "fuzzy" "flx")
  :authors '(("PythonNut" . "pythonnut@pythonnut.com"))
  :maintainers '(("PythonNut" . "pythonnut@pythonnut.com")))
