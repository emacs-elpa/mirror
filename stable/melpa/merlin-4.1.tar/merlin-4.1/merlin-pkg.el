;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "merlin" "4.1"
  "Mode for Merlin, an assistant for OCaml."
  ()
  :url "https://github.com/ocaml/merlin"
  :commit "ab02f60994c81166820791b5f465f467d752b8dc"
  :revdesc "v4.1-0-gab02f60994c8"
  :keywords '("ocaml" "languages")
  :authors '(("Frédéric Bour" . "frederic.bourlakaban.net"))
  :maintainers '(("Frédéric Bour" . "frederic.bourlakaban.net")))
