;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vector-utils" "0.1.2"
  "Vector-manipulation utility functions."
  ()
  :url "https://github.com/rolandwalker/vector-utils"
  :commit "2bd63c8ade1a2b6f8aac403c5f25adda2215a685"
  :revdesc "v0.1.2-0-g2bd63c8ade1a"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
