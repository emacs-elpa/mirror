;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-slime" "0.4.0"
  "Helm-sources and some utilities for SLIME."
  '((emacs  "24")
    (helm   "3.2")
    (slime  "2.18")
    (cl-lib "0.5"))
  :url "https://github.com/emacs-helm/helm-slime"
  :commit "e0dbf04d447098a1d074bc04e125764ff82091b7"
  :revdesc "e0dbf04d4470"
  :keywords '("convenience" "helm" "slime")
  :authors '(("Takeshi Banse" . "takebi@laafc.net"))
  :maintainers '(("Takeshi Banse" . "takebi@laafc.net")))
