;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-at-point" "1.0.0"
  "Ido-style completion-at-point."
  '((emacs "24"))
  :url "https://github.com/katspaugh/ido-at-point"
  :commit "e5907bbe8a3d148d07698b76bd994dc3076e16ee"
  :revdesc "e5907bbe8a3d"
  :keywords '("convenience" "abbrev"))
