;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ztree" "1.0.7"
  "Text mode directory tree."
  '((cl-lib "0"))
  :url "https://github.com/fourier/ztree"
  :commit "48f17807ac6c765a66cf29b2fcdd08f1aa7da7d6"
  :revdesc "48f17807ac6c"
  :keywords '("files" "tools")
  :authors '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com"))
  :maintainers '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com")))
