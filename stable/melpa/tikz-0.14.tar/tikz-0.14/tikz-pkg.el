;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tikz" "0.14"
  "A minor mode to edit TikZ pictures."
  '((emacs "24.1"))
  :url "https://github.com/emiliotorres/tikz"
  :commit "3cf94ba80194a3c8d21307eb44f6f8ca644a07e7"
  :revdesc "3cf94ba80194"
  :keywords '("tex")
  :authors '(("Emilio Torres-Manzanera" . "torres@uniovi.es"))
  :maintainers '(("Emilio Torres-Manzanera" . "torres@uniovi.es")))
