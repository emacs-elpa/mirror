;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "csgo-conf-mode" "1.0"
  "CS:GO Configuration files syntax highlighting."
  ()
  :url "https://github.com/wynro/emacs-csgo-conf-mode"
  :commit "ab68ee93abc6df6ff36aa47a38ff221e12ded13b"
  :revdesc "ab68ee93abc6"
  :keywords '("languages")
  :authors '(("Guillermo Robles" . "guillerobles1995@gmail.com"))
  :maintainers '(("Guillermo Robles" . "guillerobles1995@gmail.com")))
