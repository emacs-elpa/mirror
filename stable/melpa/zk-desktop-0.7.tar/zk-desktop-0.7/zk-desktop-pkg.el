;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-desktop" "0.7"
  "Desktop environment for zk."
  '((emacs    "27.1")
    (zk       "0.6")
    (zk-index "0.9"))
  :url "https://github.com/localauthor/zk"
  :commit "599be69ae1c1283935f98f9aca4ccda47063d82c"
  :revdesc "599be69ae1c1"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
