;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-buttons" "1.0"
  "Define, save, and load code-safe buttons in files for emacs."
  ()
  :url "https://github.com/rpav/buffer-buttons"
  :commit "da65212b1c91182880069e6c28f6a0cc46ee99ce"
  :revdesc "da65212b1c91"
  :authors '(("Ryan Pavlik" . "rpavlik@gmail.com"))
  :maintainers '(("Ryan Pavlik" . "rpavlik@gmail.com")))
