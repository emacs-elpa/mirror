;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grep-a-lot" "1.0.7"
  "Manages multiple search results buffers for grep.el."
  ()
  :url "https://github.com/ZungBang/emacs-grep-a-lot"
  :commit "9f9f645b9e308a0d887b66864ff97d0fca1ba4ad"
  :revdesc "9f9f645b9e30"
  :keywords '("tools" "convenience" "search")
  :authors '(("Avi Rozen" . "avi.rozen@gmail.com"))
  :maintainers '(("Avi Rozen" . "avi.rozen@gmail.com")))
