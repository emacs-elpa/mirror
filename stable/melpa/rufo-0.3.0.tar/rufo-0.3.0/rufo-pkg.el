;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rufo" "0.3.0"
  "Use rufo to automatically format ruby files."
  '((emacs "24.3"))
  :url "https://github.com/danielma/rufo.el"
  :commit "4e7413fafd0320f30190ae9835ab021cf7a9ebdc"
  :revdesc "4e7413fafd03"
  :authors '(("Daniel Ma and contributors" . "danielhgma@gmail.com"))
  :maintainers '(("Daniel Ma and contributors" . "danielhgma@gmail.com")))
