;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-leanpub" "0.2"
  "Export Org documents to Leanpub book format."
  '((org    "9.1")
    (ox-gfm "1.0")
    (emacs  "26.1"))
  :url "https://gitlab.com/zzamboni/ox-leanpub"
  :commit "50e84bd735d5da8629da3158d40804625c4114cc"
  :revdesc "50e84bd735d5"
  :keywords '("files" "org" "leanpub")
  :authors '(("Diego Zamboni" . "diego@zzamboni.org"))
  :maintainers '(("Diego Zamboni" . "diego@zzamboni.org")))
