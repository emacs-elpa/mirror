;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gruber-darker-theme" "0.6"
  "Gruber Darker color theme for Emacs 24."
  ()
  :url "https://github.com/rexim/gruber-darker-theme"
  :commit "0c08d77e615aceb9e6e1ca66b1fbde275200cfe4"
  :revdesc "0c08d77e615a"
  :authors '(("Alexey Kutepov" . "reximkut@gmail.com"))
  :maintainers '(("Alexey Kutepov" . "reximkut@gmail.com")))
