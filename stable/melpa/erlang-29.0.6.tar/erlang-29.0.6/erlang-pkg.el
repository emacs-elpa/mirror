;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "29.0.6"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "e07fd07837e5aa845657f5fa340637121e451d47"
  :revdesc "OTP-29.0.6-0-ge07fd07837e5"
  :keywords '("erlang" "languages" "processes"))
