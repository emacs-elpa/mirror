;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "refine" "0.3"
  "Interactive value editing."
  '((emacs      "24.3")
    (s          "1.11.0")
    (dash       "2.12.0")
    (list-utils "0.4.4")
    (loop       "1.2"))
  :url "https://github.com/Wilfred/refine"
  :commit "9760e56ab849a4827e6c9425fdef6f5a7784c967"
  :revdesc "9760e56ab849"
  :keywords '("convenience")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
