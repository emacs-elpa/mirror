;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-prog-extra" "0.2"
  "Customizable highlighting for source-code."
  '((emacs "26.2"))
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra"
  :commit "04dcab2741a96cd273ce12e881a43063876ee806"
  :revdesc "04dcab2741a9"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
