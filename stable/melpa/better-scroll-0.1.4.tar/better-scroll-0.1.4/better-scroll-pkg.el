;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "better-scroll" "0.1.4"
  "Improve user experience when scrolling window."
  '((emacs "24.3"))
  :url "https://github.com/jcs-elpa/better-scroll"
  :commit "eaa8dae6f048fcff773f3cca2e3113c52ad0463f"
  :revdesc "eaa8dae6f048"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
