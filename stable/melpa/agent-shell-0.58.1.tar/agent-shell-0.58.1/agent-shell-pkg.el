;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.58.1"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8f127ce493c8519a1d99655e7d96d0ec4fc9c031"
  :revdesc "8f127ce493c8")
