;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-format" "0.5.7"
  "Format elisp code."
  ()
  :url "http://www.emacswiki.org/emacs/download/elisp-format.el"
  :commit "640316f4930978a632b16d24c1a2fa75798e0ff0"
  :revdesc "640316f49309"
  :authors '((nil . "AndyStewartlazycat.manatee@gmail.com"))
  :maintainers '((nil . "AndyStewartlazycat.manatee@gmail.com")))
