;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sakura-theme" "1.0.1"
  "Filled with cherry blossoms."
  ()
  :url "https://github.com/emacsfodder/emacs-theme-sakura"
  :commit "d78648632a94dd5354d2fed0f94fcb7aece29132"
  :revdesc "d78648632a94"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
