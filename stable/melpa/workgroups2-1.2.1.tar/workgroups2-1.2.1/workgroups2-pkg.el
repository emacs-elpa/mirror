;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "workgroups2" "1.2.1"
  "New workspaces for Emacs."
  '((emacs "25.1")
    (dash  "2.8.0"))
  :url "https://github.com/pashinin/workgroups2"
  :commit "737306531f6834227eee2f63b197a23401003d23"
  :revdesc "737306531f68"
  :keywords '("session" "management" "window-configuration" "persistence")
  :authors '(("Sergey Pashinin" . "sergeyatpashinindotcom"))
  :maintainers '(("Sergey Pashinin" . "sergeyatpashinindotcom")))
