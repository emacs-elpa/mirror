;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lol-data-dragon" "0.0.0.20200705.31"
  "Browse Champions of League of Legends on Data Dragon."
  '((emacs "25.1"))
  :url "https://github.com/xuchunyang/lol-data-dragon.el"
  :commit "0deec9867bd7ba96220ee2968a9b2a94fd474431"
  :revdesc "0deec9867bd7"
  :keywords '("games" "hypermedia"))
