;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "htmltagwrap" "0.0.3"
  "Wraps a chunk of HTML code in tags."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/htmltagwrap"
  :commit "8cb33f9513d79e44a602927f35d5a3bb0dccbb92"
  :revdesc "8cb33f9513d7"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
