;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-relint" "0.1.0"
  "A relint Flymake backend."
  '((emacs  "26.1")
    (relint "1.23"))
  :url "https://github.com/liuyinz/flymake-relint"
  :commit "cded537b8208e87632e1fb5b9bdc819a736eb9a3"
  :revdesc "cded537b8208"
  :keywords '("lisp")
  :authors '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers '(("liuyinz" . "liuyinz95@gmail.com")))
