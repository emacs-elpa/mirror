;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dynamic-fonts" "0.6.4"
  "Set faces based on available fonts."
  '((font-utils      "0.7.0")
    (persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/dynamic-fonts"
  :commit "d318498b377d8941c7420f51616c78e3440d00f5"
  :revdesc "v0.6.4-0-gd318498b377d"
  :keywords '("faces" "frames")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
