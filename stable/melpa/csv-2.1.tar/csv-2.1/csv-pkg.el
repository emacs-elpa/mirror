;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "csv" "2.1"
  "Functions for reading and parsing CSV files."
  ()
  :url "https://gitlab.com/u11/csv.el"
  :commit "aa1dfa1263565d5fac3879c21d8ddf5f8915e411"
  :revdesc "aa1dfa126356"
  :keywords '("extensions" "data" "csv")
  :authors '(("Ulf Jasper" . "ulf.jasper@web.de"))
  :maintainers '(("Ulf Jasper" . "ulf.jasper@web.de")))
