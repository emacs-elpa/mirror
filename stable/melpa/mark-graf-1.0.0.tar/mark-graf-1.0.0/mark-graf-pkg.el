;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mark-graf" "1.0.0"
  "Modern WYSIWYG-style markdown editing."
  '((emacs "30.1"))
  :url "https://github.com/mark-graf/mark-graf"
  :commit "bc71e02131da9804800fc3f453697ed566602bdb"
  :revdesc "bc71e02131da"
  :keywords '("markdown" "wp" "text"))
