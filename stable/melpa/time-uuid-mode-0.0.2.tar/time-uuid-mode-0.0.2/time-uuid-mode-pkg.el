;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-uuid-mode" "0.0.2"
  "Minor mode for previewing time uuids as an overlay."
  '((emacs "24.3"))
  :url "https://github.com/RobertPlant/time-uuid-mode"
  :commit "e30f50229c617bdd31a1edcd849cba1f3423fea1"
  :revdesc "e30f50229c61"
  :keywords '("extensions" "convenience" "data" "tools")
  :authors '(("Robert Plant" . "rob@robertplant.io"))
  :maintainers '(("Robert Plant" . "rob@robertplant.io")))
