;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-regexp-steroids" "1.1.0"
  "Extends visual-regexp to support other regexp engines."
  '((visual-regexp "1.1"))
  :url "https://github.com/benma/visual-regexp-steroids.el/"
  :commit "a6420b25ec0fbba43bf57875827092e1196d8a9e"
  :revdesc "v1.1.0-0-ga6420b25ec0f"
  :keywords '("external" "foreign" "regexp" "replace" "python" "visual" "feedback")
  :authors '(("Marko Bencun" . "mbencun@gmail.com"))
  :maintainers '(("Marko Bencun" . "mbencun@gmail.com")))
