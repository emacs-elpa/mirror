;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gvariant" "1.0.0"
  "GVariant (GLib) helpers."
  '((emacs  "24")
    (parsec "0.1.3"))
  :url "https://github.com/wbolster/emacs-gvariant"
  :commit "79c34d11ee6a34f190f1641a133d34b0808a1143"
  :revdesc "1.0.0-0-g79c34d11ee6a"
  :keywords '("languages")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
