;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tomorrow-night-deepblue-theme" "1.2.4"
  "The Tomorrow Night Deepblue color theme."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/tomorrow-night-deepblue-theme.el"
  :commit "0c9ee6ba3b2fbdf4ab37cf486d9b0f1f7de09a71"
  :revdesc "1.2.4-0-g0c9ee6ba3b2f"
  :keywords '("faces" "themes"))
