;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-codesearch" "1.0.0"
  "Counsel interface for codesearch.el."
  '((codesearch "1")
    (counsel    "0.10.0")
    (emacs      "24")
    (ivy        "0.10.0"))
  :url "https://github.com/abingham/emacs-counsel-codesearch"
  :commit "f7254af39e95246b599a4f72b10a1e1066c382d8"
  :revdesc "f7254af39e95"
  :keywords '("tools")
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
