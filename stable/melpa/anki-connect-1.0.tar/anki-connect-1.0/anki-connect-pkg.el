;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-connect" "1.0"
  "Anki-connect API."
  '((emacs "24.3"))
  :url "https://github.com/lujun9972/anki-connect.el"
  :commit "118492f5367bad7de5e3d377ddfaccdd5206afdc"
  :revdesc "118492f5367b"
  :keywords '("lisp" "anki")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
