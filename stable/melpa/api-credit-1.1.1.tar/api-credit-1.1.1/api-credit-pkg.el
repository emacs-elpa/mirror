;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "api-credit" "1.1.1"
  "AI API balance in the modeline."
  '((emacs "25.1"))
  :url "https://github.com/OverbearingPearl/api-credit"
  :commit "f865e03874ba7b06eb29bf62f5b67f305fc61e4c"
  :revdesc "f865e03874ba"
  :keywords '("comm" "convenience")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
