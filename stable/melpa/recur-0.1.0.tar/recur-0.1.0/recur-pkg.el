;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recur" "0.1.0"
  "Tail call optimization."
  '((emacs "24.3"))
  :url "https://github.com/ROCKTAKEY/recur"
  :commit "46d213633d5325113e857b1c212f2b2937cf29d5"
  :revdesc "46d213633d53"
  :keywords '("lisp")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
