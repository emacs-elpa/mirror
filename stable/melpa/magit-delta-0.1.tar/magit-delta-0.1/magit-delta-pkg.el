;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-delta" "0.1"
  "Use delta when viewing diffs in Magit."
  ()
  :url "https://github.com/dandavison/magit-delta"
  :commit "cf041cb7374a6550a6959947bea725d4fa94c3c8"
  :revdesc "cf041cb7374a"
  :authors '(("Dan Davison" . "dandavison7@gmail.com"))
  :maintainers '(("Dan Davison" . "dandavison7@gmail.com")))
