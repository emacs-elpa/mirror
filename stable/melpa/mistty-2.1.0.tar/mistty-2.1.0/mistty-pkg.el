;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "2.1.0"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "b95846865a067cafef9e894debb54fe38300b53d"
  :revdesc "b95846865a06"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
