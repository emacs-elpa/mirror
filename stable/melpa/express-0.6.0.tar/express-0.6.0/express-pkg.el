;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "express" "0.6.0"
  "Alternatives to `message'."
  '((string-utils "0.3.2"))
  :url "https://github.com/rolandwalker/express"
  :commit "e6dc9abdc395ef537408befebeb4fd3ed4ee5c60"
  :revdesc "v0.6.0-0-ge6dc9abdc395"
  :keywords '("extensions" "message" "interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
