;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-proxy" "0.1.0"
  "Evaluate expressions with proxy."
  '((emacs "24.4")
    (dash  "2.0"))
  :url "https://github.com/twlz0ne/with-proxy.el"
  :commit "aeaa7bb54555a727665677640568cc9006804dbc"
  :revdesc "aeaa7bb54555"
  :keywords '("networking")
  :authors '(("Gong Qijian" . "gongqijian@gmail.com"))
  :maintainers '(("Gong Qijian" . "gongqijian@gmail.com")))
