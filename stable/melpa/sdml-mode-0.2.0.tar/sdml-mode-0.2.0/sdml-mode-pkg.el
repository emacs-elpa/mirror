;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sdml-mode" "0.2.0"
  "Major mode for SDML."
  '((emacs              "28.1")
    (tree-sitter        "0.18.0")
    (tree-sitter-indent "0.4"))
  :url "https://github.com/johnstonskj/emacs-sdml-mode"
  :commit "1f59deffa3186a9eafe3921fdb793549a4629a03"
  :revdesc "v0.2.0-0-g1f59deffa318"
  :keywords '("languages" "tools")
  :authors '(("Simon Johnston" . "johnstonskj@gmail.com"))
  :maintainers '(("Simon Johnston" . "johnstonskj@gmail.com")))
