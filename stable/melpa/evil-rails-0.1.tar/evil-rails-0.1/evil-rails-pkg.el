;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-rails" "0.1"
  "[No description available]."
  '((evil             "1.0")
    (projectile-rails "1.0"))
  :url "https://github.com/antono/evil-rails"
  :commit "68a9ca3d26ecb1bdcbb422f05e220e958d467251"
  :revdesc "68a9ca3d26ec"
  :keywords '("ruby" "rails" "vim" "project" "convenience" "web" "evil" "projectile")
  :authors '(("Antono Vasiljev" . "antono.vasiljev@gmail.com"))
  :maintainers '(("Antono Vasiljev" . "antono.vasiljev@gmail.com")))
