;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "untitled-new-buffer" "0.0.1"
  "Open untitled new buffer like other text editors."
  '((emacs          "24.4")
    (magic-filetype "0.2.0"))
  :url "https://github.com/zonuexe/untitled-new-buffer.el"
  :commit "6f1818c66bf176f88f1d59cd16b4c3bb3ecc5daa"
  :revdesc "6f1818c66bf1"
  :keywords '("files" "convenience")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
