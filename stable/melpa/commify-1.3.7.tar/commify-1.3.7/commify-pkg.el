;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "commify" "1.3.7"
  "Toggle grouping commas in numbers."
  '((s "1.9.0"))
  :url "https://github.com/ddoherty03/commify"
  :commit "d14cde94a8b542bd355a9f63c3f57f2322ae9756"
  :revdesc "v1.3.7-0-gd14cde94a8b5"
  :keywords '("convenience" "editing" "numbers" "grouping" "commas")
  :authors '(("Daniel E. Doherty" . "ded-commify@ddoherty.net"))
  :maintainers '(("Daniel E. Doherty" . "ded-commify@ddoherty.net")))
