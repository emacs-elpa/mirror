;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iqa" "0.0.1"
  "Init file(and directory) Quick Access."
  '((emacs "24.3"))
  :url "https://github.com/a13/iqa.el"
  :commit "c762fb0db4648201738e01922292c195b2c0e17a"
  :revdesc "c762fb0db464")
