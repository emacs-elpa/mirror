;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frog-jump-buffer" "0.1.5"
  "The fastest buffer-jumping Emacs lisp package around."
  '((emacs     "24")
    (avy       "0.4.0")
    (dash      "2.4.0")
    (frog-menu "0.2.8"))
  :url "https://github.com/waymondo/frog-jump-buffer"
  :commit "d82cc1a449d368f5a3dac61695400926da222a84"
  :revdesc "d82cc1a449d3"
  :keywords '("convenience" "tools"))
