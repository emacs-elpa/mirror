;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "share2computer" "0.0.1"
  "Tumashu's emacs configuation."
  ()
  :url "https://github.com/tumashu/share2computer"
  :commit "f589c7b9cab952d372ea3c677a4682dabef45e69"
  :revdesc "f589c7b9cab9"
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
