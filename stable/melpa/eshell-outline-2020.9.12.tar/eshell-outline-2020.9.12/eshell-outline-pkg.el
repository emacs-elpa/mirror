;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-outline" "2020.9.12"
  "Enhanced outline-mode for Eshell."
  '((emacs "25.1"))
  :url "https://git.jamzattack.xyz/eshell-outline"
  :commit "d497b1b321d47ce68195dd7d04620d7d9acb41de"
  :revdesc "d497b1b321d4"
  :keywords '("unix" "eshell" "outline" "convenience")
  :authors '(("Jamie Beardslee" . "jdb@jamzattack.xyz"))
  :maintainers '(("Jamie Beardslee" . "jdb@jamzattack.xyz")))
