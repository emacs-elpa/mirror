;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-cliplink" "0.2"
  "Insert org-mode links by URL from the clipboard."
  ()
  :url "https://github.com/rexim/org-cliplink"
  :commit "953e714dc4c26633cce36286b18ffeab79c9a118"
  :revdesc "953e714dc4c2"
  :authors '(("Alexey Kutepov" . "reximkut@gmail.com"))
  :maintainers '(("Alexey Kutepov" . "reximkut@gmail.com")))
