;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pycheckers" "0.16"
  "Multiple syntax checker for Python, using Flycheck."
  '((flycheck "0.18"))
  :url "https://github.com/msherry/flycheck-pycheckers"
  :commit "055830b67cd0f0d7196a5b71bd5cce3197a557a7"
  :revdesc "055830b67cd0"
  :keywords '("convenience" "tools" "languages"))
