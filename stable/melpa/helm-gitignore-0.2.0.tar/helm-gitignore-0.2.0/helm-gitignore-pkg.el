;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-gitignore" "0.2.0"
  "Generate .gitignore files with gitignore.io."
  '((gitignore-mode "1.1.0")
    (helm           "1.7.0")
    (request        "0.1.0")
    (cl-lib         "0.5"))
  :url "https://github.com/jupl/helm-gitignore"
  :commit "2a2e7da7855a6db0ab3bb6a6a087863d7abd4391"
  :revdesc "2a2e7da7855a"
  :keywords '("helm" "gitignore" "gitignore.io"))
