;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jq-format" "1.0.0"
  "Reformat JSON and JSONLines using jq."
  '((emacs       "24")
    (reformatter "0.3"))
  :url "https://github.com/wbolster/emacs-jq-format"
  :commit "47e1c5adb89b37b4d53fe01302d8c675913c20e7"
  :revdesc "1.0.0-0-g47e1c5adb89b"
  :keywords '("languages")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
