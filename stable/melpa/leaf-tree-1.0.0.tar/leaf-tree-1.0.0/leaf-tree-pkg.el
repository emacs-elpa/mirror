;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-tree" "1.0.0"
  "Interactive side-bar feature for init.el using leaf."
  '((emacs      "25.1")
    (imenu-list "0.8"))
  :url "https://github.com/conao3/leaf-tree.el"
  :commit "22f6c116cf1465c28d4a35d8a4587a8b614be175"
  :revdesc "22f6c116cf14"
  :keywords '("convenience" "leaf")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
