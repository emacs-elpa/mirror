;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indicators" "0.0.4"
  "Display the buffer relative location of line in the fringe."
  ()
  :url "https://github.com/Fuco1/indicators.el"
  :commit "bf9c7a79d8198e902e31d034b9bae2599ee6bc1e"
  :revdesc "bf9c7a79d819"
  :keywords '("fringe" "frames")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
