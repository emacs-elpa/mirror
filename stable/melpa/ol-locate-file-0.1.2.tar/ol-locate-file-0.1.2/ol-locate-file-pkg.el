;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-locate-file" "0.1.2"
  "Locate-based file links for Org mode."
  '((emacs "30.1")
    (org   "9.3"))
  :url "https://github.com/p-snow/ol-locate-file"
  :commit "30f84f72616f38975a2dd069dd9f729cb21cca32"
  :revdesc "30f84f72616f"
  :keywords '("hypermedia" "convenience")
  :authors '(("p-snow" . "public@p-snow.org"))
  :maintainers '(("p-snow" . "public@p-snow.org")))
