;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-grammarly" "0.2.1"
  "Flymake support for Grammarly."
  '((emacs     "26.1")
    (grammarly "0.3.0"))
  :url "https://github.com/jcs-elpa/flymake-grammarly"
  :commit "5e5dc903642d8b66f6400d0ac34ca08b836d8195"
  :revdesc "5e5dc903642d"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
