;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-cfengine3" "0.0.7"
  "Org Babel functions for CFEngine 3."
  ()
  :url "https://github.com/nickanderson/ob-cfengine3"
  :commit "195ba4694a0ec18d3fb89342e8e0988b382a5b1a"
  :revdesc "195ba4694a0e"
  :keywords '("tools" "convenience")
  :authors '(("Nick Anderson" . "nick@cmdln.org"))
  :maintainers '(("Nick Anderson" . "nick@cmdln.org")))
