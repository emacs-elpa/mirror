;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ml" "6.0.2"
  "Functional Org Mode API."
  '((emacs "27.1")
    (org   "9.7")
    (dash  "2.17")
    (s     "1.12"))
  :url "https://github.com/ndwarshuis/org-ml"
  :commit "27ec4c118621ceccf832dd993d17d1ef29a1cb8a"
  :revdesc "27ec4c118621"
  :keywords '("org-mode" "outlines")
  :authors '(("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainers '(("Nathan Dwarshuis" . "ndwar@yavin4.ch")))
