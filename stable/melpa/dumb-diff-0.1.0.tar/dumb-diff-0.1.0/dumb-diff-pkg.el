;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-diff" "0.1.0"
  "[No description available]."
  '((emacs "24.3"))
  :url "https://github.com/jacktasia/dumb-diff"
  :commit "68f356816a16cd2b502f1c231a6a09d7a5f57f37"
  :revdesc "68f356816a16"
  :keywords '("programming" "diff"))
