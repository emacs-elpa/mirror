;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scribble-mode" "0.1"
  "Major mode for editing Scribble documents."
  '((emacs "24"))
  :url "https://github.com/emacs-pe/scribble-mode"
  :commit "369050a4e9d2b99a1a62f6c7595919f9ccfa7809"
  :revdesc "369050a4e9d2"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
