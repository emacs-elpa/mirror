;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verdict" "0.1.4"
  "Generic test runner with treemacs results UI."
  '((emacs    "29.1")
    (treemacs "3.0")
    (dash     "2.0"))
  :url "https://github.com/tjarvstrand/verdict.el"
  :commit "84fff362b8068a1a8112b772fa927b56a6786482"
  :revdesc "84fff362b806"
  :keywords '("tools" "processes")
  :authors '(("Thomas Järvstrand" . "https://github.com/tjarvstrand"))
  :maintainers '(("Thomas Järvstrand" . "https://github.com/tjarvstrand")))
