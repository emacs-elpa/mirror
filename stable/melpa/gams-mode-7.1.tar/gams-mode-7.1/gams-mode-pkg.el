;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gams-mode" "7.1"
  "Major mode for General Algebraic Modeling System (GAMS)."
  '((emacs "24.3"))
  :url "https://github.com/ShiroTakeda/gams-mode"
  :commit "c01474a5bbf4fa11564579f258e97941c85980d1"
  :revdesc "c01474a5bbf4"
  :keywords '("languages" "tools" "gams"))
