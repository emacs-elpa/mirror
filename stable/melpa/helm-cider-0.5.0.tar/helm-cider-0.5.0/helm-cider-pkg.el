;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-cider" "0.5.0"
  "Helm interface to CIDER."
  '((emacs     "26")
    (cider     "1.0")
    (helm-core "2.8"))
  :url "https://github.com/clojure-emacs/helm-cider"
  :commit "00809e45de919c82753f332f29358f0ddbf21936"
  :revdesc "00809e45de91"
  :keywords '("cider" "clojure" "helm" "languages")
  :authors '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com"))
  :maintainers '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com")))
