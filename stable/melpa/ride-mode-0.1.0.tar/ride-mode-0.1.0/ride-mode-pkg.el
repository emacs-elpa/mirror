;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ride-mode" "0.1.0"
  "A major-mode for editing RIDE language."
  '((emacs "25.1"))
  :url "https://github.com/deadblackclover/ride-mode"
  :commit "b693e5c33090530d2ea9d792fa148ea983f8607f"
  :revdesc "b693e5c33090"
  :keywords '("languages")
  :authors '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com"))
  :maintainers '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com")))
