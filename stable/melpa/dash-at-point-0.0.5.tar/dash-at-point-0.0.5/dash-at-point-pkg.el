;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dash-at-point" "0.0.5"
  "Search the word at point with Dash."
  ()
  :url "https://github.com/stanaka/dash-at-point"
  :commit "597d7cf61d923ee3819ab8a7ddc9b7c8d658f33f"
  :revdesc "597d7cf61d92"
  :authors '(("Shinji Tanaka" . "shinji.tanaka@gmail.com"))
  :maintainers '(("Shinji Tanaka" . "shinji.tanaka@gmail.com")))
