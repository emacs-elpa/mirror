;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zerodark-theme" "4.7"
  "A dark, medium contrast theme for Emacs."
  '((all-the-icons "2.0.0"))
  :url "https://github.com/NicolasPetton/zerodark-theme"
  :commit "342055346446bb8306ac2d3d2ac1f4236c84a404"
  :revdesc "342055346446"
  :keywords '("themes")
  :authors '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")))
