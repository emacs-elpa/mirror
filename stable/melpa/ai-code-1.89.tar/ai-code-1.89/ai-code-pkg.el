;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.89"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "9604229f088f45a013826511ab549c5334b4c294"
  :revdesc "9604229f088f"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
