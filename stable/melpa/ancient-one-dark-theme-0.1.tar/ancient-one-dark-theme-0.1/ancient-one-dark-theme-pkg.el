;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ancient-one-dark-theme" "0.1"
  "A color theme based off uetchy's Ancient One Dark Theme."
  '((emacs "24"))
  :url "https://github.com/sigvt/ancient-one-dark-emacs"
  :commit "d56c3b14dba8bcaf345c204fcfed282a12fa30b9"
  :revdesc "d56c3b14dba8")
