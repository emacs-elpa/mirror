;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smog" "0.1"
  "Analyse the writing style, word use and readability of prose."
  ()
  :url "https://github.com/zzkt/smog"
  :commit "186d3a3a680458107b28bd334b8b84ab64662920"
  :revdesc "186d3a3a6804"
  :keywords '("tools" "style" "readability" "prose")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
