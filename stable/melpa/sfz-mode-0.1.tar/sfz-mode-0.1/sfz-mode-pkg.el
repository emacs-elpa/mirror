;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sfz-mode" "0.1"
  "[No description available]."
  ()
  :url "https://github.com/sfztools/emacs-sfz-mode"
  :commit "8c28dbdedb70f2617f3e7da8423e45777239754b"
  :revdesc "8c28dbdedb70"
  :keywords '("languages"))
