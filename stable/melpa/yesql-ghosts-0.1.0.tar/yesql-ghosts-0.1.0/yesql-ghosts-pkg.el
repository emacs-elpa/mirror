;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yesql-ghosts" "0.1.0"
  "Display ghostly yesql defqueries inline."
  '((s     "1.9.0")
    (dash  "2.10.0")
    (cider "0.8.0"))
  :url "https://github.com/magnars/yesql-ghosts"
  :commit "bd834e97f263f9f981758c1462bc6297a83ca852"
  :revdesc "0.1.0-0-gbd834e97f263"
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
