;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "logalimacs" "1.0.0"
  "Front-end to logaling-command for Ruby gems."
  ()
  :url "https://github.com/logaling/logalimacs"
  :commit "cfd7aaa925934f876eee6e8c550cf6e7a239a2ac"
  :revdesc "1.0.0-0-gcfd7aaa92593"
  :authors '(("Yuta Yamada" . "yamada@clear-code.com"))
  :maintainers '(("Yuta Yamada" . "yamada@clear-code.com")))
