;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symbols-outline" "1.0.0"
  "Display symbols (functions, variables, etc) in outline view."
  '((emacs "27.1"))
  :url "https://github.com/liushihao456/symbols-outline.el"
  :commit "e9ba4721ae6037c98095bf7602fbfdd38c2fb873"
  :revdesc "e9ba4721ae60"
  :keywords '("outlines"))
