;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "playground" "0.2.0"
  "Manage sandboxes for alternative configurations."
  '((emacs "24.4"))
  :url "https://github.com/akirak/emacs-playground"
  :commit "0fe3fa1eaeb48cecd123d8a1de8c1da680128c76"
  :revdesc "0fe3fa1eaeb4"
  :keywords '("maint")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
