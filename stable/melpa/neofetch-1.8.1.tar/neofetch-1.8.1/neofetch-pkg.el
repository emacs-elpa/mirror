;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neofetch" "1.8.1"
  "Pretty system information tool for the Eshell."
  '((emacs "30.2"))
  :url "https://codeberg.org/benja2998/neofetch.el"
  :commit "171b49930dd655693d067fc3f764b3b2f5feb36f"
  :revdesc "171b49930dd6"
  :keywords '("tools")
  :authors '(("benja2998" . "benja2998@proton.me"))
  :maintainers '(("benja2998" . "benja2998@proton.me")))
