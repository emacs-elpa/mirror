;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morganey-mode" "0.0.1"
  "Major mode for editing Morganey files."
  '((emacs "24.4"))
  :url "https://github.com/morganey-lang/morganey-mode"
  :commit "0e757d21180f6f17b69d075b1de93a21a3a8adbc"
  :revdesc "0e757d21180f"
  :authors '(("Alexey Kutepov" . "reximkut@gmail.com"))
  :maintainers '(("Alexey Kutepov" . "reximkut@gmail.com")))
