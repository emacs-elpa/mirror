;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imgur" "1.1.0"
  "Imgur client."
  '((emacs "27.1"))
  :url "https://github.com/KeyWeeUsr/imgur"
  :commit "3eb96d58909c5c62613ee57495bdfe7e92d0c4b7"
  :revdesc "1.1.0-0-g3eb96d58909c"
  :keywords '("convenience" "imgur" "client")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
