;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bln-mode" "1.0.0"
  "Binary line navigation minor-mode."
  ()
  :url "https://github.com/mgrachten/bln-mode"
  :commit "0d9cbf0eddd8f85c08816e47723788ba192ad0aa"
  :revdesc "0d9cbf0eddd8"
  :keywords '("lisp"))
