;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-venv" "0.0.2"
  "Execute with Python virtual environment activated."
  '((cl-lib "0.5")
    (emacs  "24.4"))
  :url "https://github.com/10sr/with-venv-el"
  :commit "c34979519278a6e17312e8c47a19eb7bc94e5002"
  :revdesc "c34979519278"
  :keywords '("processes" "python" "venv")
  :authors '(("10sr" . "8.slashes[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8.slashes[at]gmail[dot]com")))
