;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "0.1.0"
  "[No description available]."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer-mode"
  :commit "8724cc169edbad4282d667249a845976f5d073be"
  :revdesc "8724cc169edb"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
