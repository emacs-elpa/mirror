;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nav" "49"
  "Emacs mode for filesystem navigation."
  ()
  :url "https://github.com/emacsorphanage/nav"
  :commit "c5eb234c063f435dbdcd1f8bdc46cfc68c973ebe"
  :revdesc "c5eb234c063f"
  :authors '(("Issac Trotts" . "issactrotts@google.com"))
  :maintainers '(("Issac Trotts" . "issactrotts@google.com")))
