;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-img-tiqav" "0.0.1"
  "[No description available]."
  '((helm-img "0.0.1"))
  :url "https://github.com/l3msh0/helm-img"
  :commit "3ddfdaaf9b5286cd6b6d326d90f50cb603cb2c41"
  :revdesc "3ddfdaaf9b52"
  :keywords '("convenience")
  :authors '(("Sho Matsumoto" . "l3msh0_at_gmail.com")))
