;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison-ts-mode" "0.2.0"
  "Tree-sitter support for Unison."
  '((emacs "29.1"))
  :url "https://github.com/fmguerreiro/unison-ts-mode"
  :commit "e31a211899e5c249a521b8b1e09f48bcc40383af"
  :revdesc "e31a211899e5"
  :keywords '("languages" "unison" "tree-sitter")
  :authors '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com"))
  :maintainers '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com")))
