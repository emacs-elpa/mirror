;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anaphora" "1.0.4"
  "Anaphoric macros providing implicit temp variables."
  ()
  :url "https://github.com/rolandwalker/anaphora"
  :commit "3b2da3f759b244975852e79721c4a2dbad3905cf"
  :revdesc "v1.0.4-0-g3b2da3f759b2"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
