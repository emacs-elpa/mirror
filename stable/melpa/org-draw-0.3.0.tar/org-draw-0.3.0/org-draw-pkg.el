;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-draw" "0.3.0"
  "Draw into Org from a browser."
  '((emacs "28.1"))
  :url "https://github.com/larrasket/org-draw"
  :commit "e17d9d5df9821849c48cffefd3733c6a66a6eaf3"
  :revdesc "e17d9d5df982"
  :keywords '("org" "multimedia" "hypermedia")
  :authors '(("Saleh" . "root@lr0.org"))
  :maintainers '(("Saleh" . "root@lr0.org")))
