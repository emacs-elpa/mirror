;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auth-source-1password" "0.0.1"
  "1password integration for auth-source."
  '((emacs "24.4"))
  :url "https://github.com/dlobraico"
  :commit "7f40833696f1cbc7974b3e75db9793adbf219570"
  :revdesc "7f40833696f1"
  :authors '(("Dominick LoBraico" . "auth-source-1password@lobrai.co"))
  :maintainers '(("Dominick LoBraico" . "auth-source-1password@lobrai.co")))
