;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-matterircd" "0.1"
  "Matterircd integration for ERC."
  '((emacs "24.4"))
  :url "https://github.com/alexmurray/erc-matterircd"
  :commit "bc07c208fa4b788f08d53e2bf6ac8a818c6ecfc8"
  :revdesc "bc07c208fa4b"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
