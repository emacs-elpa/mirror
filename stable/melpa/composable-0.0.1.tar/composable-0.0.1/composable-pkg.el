;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "composable" "0.0.1"
  "Composable editing."
  '((emacs "24.4"))
  :url "https://github.com/paldepind/composable.el"
  :commit "4739b6a730498e7526d06222810c3ccf3723d509"
  :revdesc "4739b6a73049"
  :keywords '("lisp")
  :authors '(("Simon Friis Vindum" . "simon@vindum.io"))
  :maintainers '(("Simon Friis Vindum" . "simon@vindum.io")))
