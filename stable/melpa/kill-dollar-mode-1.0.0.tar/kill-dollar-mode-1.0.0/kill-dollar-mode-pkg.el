;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kill-dollar-mode" "1.0.0"
  "Remove leading $ from shell-script-like text."
  '((emacs "27.1"))
  :url "https://github.com/sandinmyjoints/kill-dollar-mode"
  :commit "96c1fe1b40950a2666a39bd53ff9e5faa9d46ef1"
  :revdesc "1.0.0-0-g96c1fe1b4095"
  :keywords '("convenience" "tools"))
