;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-fd" "0.1.0"
  "Counsel interface for fd."
  '((emacs "24.4"))
  :url "https://github.com/yqrashawn/counsel-fd"
  :commit "02202717bc86cd63943de080dfc7862b35200fe1"
  :revdesc "02202717bc86"
  :keywords '("tools")
  :authors '(("Rashawn Zhang" . "namy.19@gmail.com"))
  :maintainers '(("Rashawn Zhang" . "namy.19@gmail.com")))
