;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-noter-pdftools" "1.0"
  "Integration between org-pdftools and org-noter."
  '((emacs        "26.1")
    (org          "9.3")
    (pdf-tools    "0.8")
    (org-pdftools "1.0")
    (org-noter    "1.4.1"))
  :url "https://github.com/fuxialexander/org-pdftools"
  :commit "d8bc2a0c6a77f16e5a8db18986ade7323c471808"
  :revdesc "d8bc2a0c6a77"
  :keywords '("convenience")
  :authors '(("Alexander Fu Xi" . "fuxialexander@gmail.com"))
  :maintainers '(("Alexander Fu Xi" . "fuxialexnader@gmail.com")))
