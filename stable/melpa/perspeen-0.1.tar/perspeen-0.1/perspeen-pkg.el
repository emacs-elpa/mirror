;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspeen" "0.1"
  "An Emacs package for multi-workspace."
  ()
  :url "https://github.com/seudut/perspeen"
  :commit "30ee14339cf8fe2e59e5384085afee3f8eb58dda"
  :revdesc "30ee14339cf8"
  :keywords '("lisp")
  :authors '(("Peng Li" . "seudut@gmail.com"))
  :maintainers '(("Peng Li" . "seudut@gmail.com")))
