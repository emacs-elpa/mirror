;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyim-wbdict" "0.3.0"
  "Some wubi dicts for pyim."
  '((pyim "3.7"))
  :url "https://github.com/tumashu/pyim-wbdict"
  :commit "2766bf0dd8514226cd8aac1ab9402af603b96d06"
  :revdesc "2766bf0dd851"
  :keywords '("convenience" "chinese" "pinyin" "input-method" "complete")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
