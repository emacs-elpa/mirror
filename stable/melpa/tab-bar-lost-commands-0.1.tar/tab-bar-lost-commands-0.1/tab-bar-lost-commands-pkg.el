;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tab-bar-lost-commands" "0.1"
  "The \"lost commands\" of the tab bar."
  '((emacs         "27.1")
    (tab-bar-utils "0.1"))
  :url "https://github.com/fritzgrabo/tab-bar-lost-commands"
  :commit "fb21baf23a6b890283cc1bf8bea245f3024608bf"
  :revdesc "fb21baf23a6b"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "me@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "me@fritzgrabo.com")))
