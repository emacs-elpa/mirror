;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metal-archives" "0.4"
  "List future releases using Metal-Archives API."
  '((emacs   "26.3")
    (alert   "1.2")
    (ht      "2.3")
    (request "0.2.2"))
  :url "https://github.com/seblemaguer/metal-archives.el"
  :commit "da7c1efcc3d4859019de8fa030899fe191e33608"
  :revdesc "da7c1efcc3d4"
  :keywords '("lisp" "calendar")
  :authors '(("Sébastien Le Maguer" . "lemagues@tcd.ie"))
  :maintainers '(("Sébastien Le Maguer" . "lemagues@tcd.ie")))
