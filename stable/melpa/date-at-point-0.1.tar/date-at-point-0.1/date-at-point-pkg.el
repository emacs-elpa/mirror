;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "date-at-point" "0.1"
  "Add `date' to `thing-at-point' function."
  ()
  :url "https://gitorious.org/alezost-emacs/date-at-point"
  :commit "662f8350a83311503dc0aae47a28752f9f1270c9"
  :revdesc "662f8350a833"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
