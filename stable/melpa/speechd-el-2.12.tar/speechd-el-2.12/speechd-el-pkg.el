;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speechd-el" "2.12"
  "Client to speech synthesizers and Braille displays."
  ()
  :url "https://github.com/brailcom/speechd-el"
  :commit "ac7497e394bf7d46e0b2c27570f5507f6a50a157"
  :revdesc "ac7497e394bf"
  :authors '(("Milan Zamazal" . "pdm@zamazal.org"))
  :maintainers '(("Milan Zamazal" . "pdm@zamazal.org")))
