;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kerl" "0.1"
  "Emacs integration for kerl."
  ()
  :url "https://github.com/correl/kerl.el"
  :commit "e237b0ad797c59de2b7b9724d889bf544aac35a8"
  :revdesc "e237b0ad797c"
  :keywords '("tools")
  :authors '(("Correl Roush" . "correl@gmail.com"))
  :maintainers '(("Correl Roush" . "correl@gmail.com")))
