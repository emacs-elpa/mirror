;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-light-theme" "2.0"
  "Visual Studio IDE light theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-light-theme"
  :commit "0e0d53d595249fa716f0a12fba3c44622132bce3"
  :revdesc "0e0d53d59524")
