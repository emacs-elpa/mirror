;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-auto-readme" "1.0.1"
  "Auto-display README file in Dired buffers."
  '((emacs         "29.1")
    (markdown-mode "2.5"))
  :url "https://github.com/amno1/dired-auto-readme"
  :commit "4a57b4adfaeeadcf24bc73d3e90256e53aa2e93d"
  :revdesc "4a57b4adfaee"
  :keywords '("tools" "convenience"))
