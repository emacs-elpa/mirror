;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cloud-theme" "0.1"
  "A light theme based on Material palette."
  ()
  :url "https://github.com/vallyscode/cloud-theme"
  :commit "254c486a4d38c1d1dbe24db4018653ece59cd6b5"
  :revdesc "254c486a4d38"
  :keywords '("faces" "theme")
  :authors '(("Valerii Lysenko" . "vallyscode@gmail.com"))
  :maintainers '(("Valerii Lysenko" . "vallyscode@gmail.com")))
