;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imenu-extra" "0.0.1"
  "Add extra items into existing imenu items."
  '((emacs "25.1"))
  :url "https://github.com/redguardtoo/imenu-extra"
  :commit "2bd6d28fa25ef8f9b477cad9d8d806ce9fbb9d52"
  :revdesc "2bd6d28fa25e"
  :keywords '("convenience")
  :authors '(("Chen Bin" . "chenbinDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmailDOTcom")))
