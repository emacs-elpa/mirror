;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective-exwm" "0.2.0"
  "Better integration for perspective.el and EXWM."
  '((emacs       "27.1")
    (burly       "0.2-pre")
    (exwm        "0.26")
    (perspective "2.17"))
  :url "https://github.com/SqrtMinusOne/perspective-exwm.el"
  :commit "01d51f5c92a30b65e8346582ed1ce6513570bb0a"
  :revdesc "01d51f5c92a3"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
