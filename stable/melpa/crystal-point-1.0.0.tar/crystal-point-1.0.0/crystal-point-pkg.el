;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crystal-point" "1.0.0"
  "Dynamically update the cursor color to match face foreground color at point."
  '((emacs "24.4"))
  :url "https://github.com/laluxx/crystal-point"
  :commit "d53eec48e03ef4e835dffb235271e646be3e3d25"
  :revdesc "d53eec48e03e"
  :keywords '("convenience" "cursor" "faces"))
