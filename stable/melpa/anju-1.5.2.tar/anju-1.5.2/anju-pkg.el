;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "1.5.2"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "a0d65606071dba7259d6c1ca96bf66c7b1bebab5"
  :revdesc "a0d65606071d"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
