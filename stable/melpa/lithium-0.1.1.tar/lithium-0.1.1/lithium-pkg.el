;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lithium" "0.1.1"
  "Lightweight modal interfaces."
  '((emacs "25.1"))
  :url "https://github.com/countvajhula/lithium"
  :commit "8d97cec32fe724750ef5dd85626e49dcf436deaf"
  :revdesc "v0.1.1-0-g8d97cec32fe7"
  :keywords '("convenience" "emulations" "lisp" "tools")
  :authors '(("Siddhartha Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Siddhartha Kasivajhula" . "sid@countvajhula.com")))
