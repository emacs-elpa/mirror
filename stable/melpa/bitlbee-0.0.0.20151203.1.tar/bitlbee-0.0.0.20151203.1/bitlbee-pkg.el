;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitlbee" "0.0.0.20151203.1"
  "Help get Bitlbee (http://www.bitlbee.org) up and running."
  ()
  :url "https://github.com/pjones/bitlbee-el"
  :commit "f3342da46b0864ae8db4e82b553d9e617b090534"
  :revdesc "f3342da46b08")
