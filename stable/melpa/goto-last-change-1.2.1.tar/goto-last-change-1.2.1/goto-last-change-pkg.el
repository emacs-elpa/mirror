;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-last-change" "1.2.1"
  "Move point through buffer-undo-list positions."
  ()
  :url "https://github.com/camdez/goto-last-change.el"
  :commit "58b0928bc255b47aad318cd183a5dce8f62199cc"
  :revdesc "v1.2.1-0-g58b0928bc255"
  :keywords '("convenience")
  :authors '(("Kevin Rodgers" . "ihs_4664@yahoo.com"))
  :maintainers '(("Kevin Rodgers" . "ihs_4664@yahoo.com")))
