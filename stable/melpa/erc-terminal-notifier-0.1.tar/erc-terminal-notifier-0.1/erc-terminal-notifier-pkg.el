;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-terminal-notifier" "0.1"
  "ERC Nick highlight with terminal-notifier."
  ()
  :url "https://github.com/julienXX/"
  :commit "8ed1cfb26eb71fda6257c05d743baed6e8c5a593"
  :revdesc "8ed1cfb26eb7"
  :keywords '("erc" "terminal-notifier" "nick")
  :authors '(("Julien Blanchard" . "julien@sideburns.eu"))
  :maintainers '(("Julien Blanchard" . "julien@sideburns.eu")))
