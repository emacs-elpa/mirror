;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pikchr-mode" "0.0.0.20241127.21"
  "A major mode for the pikchr diagram markup language."
  '((emacs "27.1"))
  :url "https://github.com/kljohann/pikchr-mode"
  :commit "27b5d06d6f55b4db45b9fc96d614f1dce8ee70fa"
  :revdesc "27b5d06d6f55"
  :keywords '("languages")
  :authors '(("Johann Klähn" . "johann@jklaehn.de"))
  :maintainers '(("Johann Klähn" . "johann@jklaehn.de")))
