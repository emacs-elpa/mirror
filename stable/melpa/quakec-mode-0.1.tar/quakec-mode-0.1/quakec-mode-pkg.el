;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quakec-mode" "0.1"
  "Major mode for QuakeC."
  '((emacs "27.1"))
  :url "https://github.com/vkazanov/quakec-mode"
  :commit "8ac72909fff5135f544012ad3df45d2d890634bd"
  :revdesc "8ac72909fff5"
  :keywords '("games" "languages"))
