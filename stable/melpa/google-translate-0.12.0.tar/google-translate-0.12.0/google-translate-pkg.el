;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "google-translate" "0.12.0"
  "Emacs interface to Google Translate."
  ()
  :url "https://github.com/atykhonov/google-translate"
  :commit "ba027ff85352b989abac29b0efba1811b870ebec"
  :revdesc "ba027ff85352"
  :keywords '("convenience")
  :authors '(("Oleksandr Manzyuk" . "manzyuk@gmail.com"))
  :maintainers '(("Andrey Tykhonov" . "atykhonov@gmail.com")))
