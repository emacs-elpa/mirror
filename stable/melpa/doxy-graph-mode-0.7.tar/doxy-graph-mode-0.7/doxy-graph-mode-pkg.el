;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doxy-graph-mode" "0.7"
  "Links source code editing with doxygen call graphs."
  '((emacs "26.3"))
  :url "https://github.com/gustavopuche/doxy-graph-mode"
  :commit "bef2011e5af3fce82d5bed2281eaa2b5aa68fe32"
  :revdesc "bef2011e5af3"
  :keywords '("languages" "all")
  :authors '(("Gustavo Puche" . "gustavo.puche@gmail.com"))
  :maintainers '(("Gustavo Puche" . "gustavo.puche@gmail.com")))
