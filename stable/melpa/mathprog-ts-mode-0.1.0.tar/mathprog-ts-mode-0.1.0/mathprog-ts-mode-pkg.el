;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mathprog-ts-mode" "0.1.0"
  "Major mode for MathProg."
  '((emacs "29.1"))
  :url "https://github.com/smoeding/mathprog-ts-mode"
  :commit "f9d9cd8ec221d79fd6c557d8f697bf7a62be8ca7"
  :revdesc "f9d9cd8ec221"
  :keywords '("languages")
  :authors '(("Stefan Möding" . "stm@kill-9.net"))
  :maintainers '(("Stefan Möding" . "stm@kill-9.net")))
