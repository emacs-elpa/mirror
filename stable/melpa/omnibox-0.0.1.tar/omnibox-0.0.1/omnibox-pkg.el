;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "omnibox" "0.0.1"
  "Selection package."
  '((emacs "26.1")
    (dash  "2.13"))
  :url "https://github.com/sebastiencs/omnibox"
  :commit "8fc310c9dfc8760aa5bbe84c6b3ebbd5fb0f603d"
  :revdesc "8fc310c9dfc8"
  :keywords '("completion" "selection")
  :authors '(("Sebastien Chapuis" . "sebastien@chapu.is"))
  :maintainers '(("Sebastien Chapuis" . "sebastien@chapu.is")))
