;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-loading-notifier" "0.3.0"
  "Notify a package is being loaded."
  '((emacs "25"))
  :url "https://github.com/tttuuu888/package-loading-notifier"
  :commit "bc06ba97a0537aa202f277e5597ac96ca39307ab"
  :revdesc "bc06ba97a053"
  :keywords '("convenience" "faces" "config" "startup")
  :authors '(("SeungKi Kim" . "tttuuu888@gmail.com"))
  :maintainers '(("SeungKi Kim" . "tttuuu888@gmail.com")))
