;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ini" "1.0"
  "Converting between INI files and association lists."
  '((emacs "24.4"))
  :url "https://github.com/EsaLaine/ini.el"
  :commit "deadc49c2ca7a0bb11358bce58e68c5868d28316"
  :revdesc "deadc49c2ca7")
