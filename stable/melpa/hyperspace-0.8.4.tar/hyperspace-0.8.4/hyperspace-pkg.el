;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperspace" "0.8.4"
  "Get there from here."
  '((emacs "25")
    (s     "1.12.0"))
  :url "https://github.com/ieure/hyperspace-el"
  :commit "5fdd680dc2e7b8a064cfdf93d6948546ff51afc2"
  :revdesc "0.8.4-0-g5fdd680dc2e7"
  :keywords '("tools" "convenience")
  :authors '(("Ian Eure" . "ian@retrospec.tv"))
  :maintainers '(("Ian Eure" . "ian@retrospec.tv")))
