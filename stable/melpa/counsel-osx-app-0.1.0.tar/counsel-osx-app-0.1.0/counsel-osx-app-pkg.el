;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-osx-app" "0.1.0"
  "Launch osx applications via ivy interface."
  '((ivy "0.8.0"))
  :url "https://github.com/d12frosted/flyspell-correct"
  :commit "7c9463d496771721643bdff9357c5f998bff054e"
  :revdesc "7c9463d49677"
  :authors '(("Boris Buliga" . "d12frosted@gmail.com"))
  :maintainers '(("Boris Buliga" . "d12frosted@gmail.com")))
