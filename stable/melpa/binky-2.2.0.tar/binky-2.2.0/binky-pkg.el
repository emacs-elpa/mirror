;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "binky" "2.2.0"
  "Jump between points like a rabbit."
  '((emacs "29.1")
    (dash  "2.19.1"))
  :url "https://github.com/eki3z/binky.el"
  :commit "29f2492366ced8ff13802faf4a1c6df5e0c9cb07"
  :revdesc "29f2492366ce"
  :keywords '("convenience")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
