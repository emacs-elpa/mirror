;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rutils" "0.0.2"
  "R utilities with transient."
  '((emacs     "26.1")
    (ess       "18.10.1")
    (transient "0.3.0"))
  :url "https://github.com/ShuguangSun/rutils.el"
  :commit "e39ca3c953ef395f28176f740ebf500d62edb429"
  :revdesc "e39ca3c953ef"
  :keywords '("convenience")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
