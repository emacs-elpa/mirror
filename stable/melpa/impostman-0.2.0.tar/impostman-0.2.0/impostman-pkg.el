;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "impostman" "0.2.0"
  "Import Postman collections."
  '((emacs "27.1"))
  :url "https://github.com/flashcode/impostman"
  :commit "fe8646959223a8b4dbd733aa66cf1a675332d9cf"
  :revdesc "v0.2.0-0-gfe8646959223"
  :keywords '("tools")
  :authors '(("Sébastien Helleu" . "flashcode@flashtux.org"))
  :maintainers '(("Sébastien Helleu" . "flashcode@flashtux.org")))
