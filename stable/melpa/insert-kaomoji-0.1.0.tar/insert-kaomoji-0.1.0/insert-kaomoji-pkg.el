;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insert-kaomoji" "0.1.0"
  "Easily insert kaomojis."
  '((emacs "24.4"))
  :url "https://git.sr.ht/~zge/kaomoji.el"
  :commit "5f9553d82455a80ecccf7181c62871e818085b76"
  :revdesc "5f9553d82455"
  :keywords '("wp")
  :authors '(("Philip K." . "philip@warpmail.net"))
  :maintainers '(("Philip K." . "philip@warpmail.net")))
