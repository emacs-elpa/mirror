;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zenity-color-picker" "0.1.0"
  "Insert and adjust colors using Zenity."
  '((emacs "24.4"))
  :url "https://bitbucket.org/Soft/zenity-color-picker.el"
  :commit "69f843f99ec1b24a89ab52c1fcc78c1b1ea85029"
  :revdesc "69f843f99ec1"
  :keywords '("colors")
  :authors '(("Samuel Laurén" . "samuel.lauren@iki.fi"))
  :maintainers '(("Samuel Laurén" . "samuel.lauren@iki.fi")))
