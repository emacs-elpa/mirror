;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "babel" "1.7"
  "Interface to web translation services such as Babelfish."
  ()
  :url "https://github.com/juergenhoetzel/babel"
  :commit "a6028ec6780f22b5b15c4458d968f7b49be3974b"
  :revdesc "a6028ec6780f"
  :keywords '("translation" "web")
  :authors '(("Juergen Hoetzel" . "juergen@hoetzel.info")
             ("Eric Marsden" . "emarsden@laas.fr"))
  :maintainers '(("Juergen Hoetzel" . "juergen@hoetzel.info")
                 ("Eric Marsden" . "emarsden@laas.fr")))
