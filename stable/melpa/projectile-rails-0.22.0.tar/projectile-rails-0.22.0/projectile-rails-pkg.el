;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-rails" "0.22.0"
  "Minor mode for Rails projects based on projectile-mode."
  '((emacs       "24.3")
    (projectile  "0.12.0")
    (inflections "1.1")
    (inf-ruby    "2.2.6")
    (f           "0.13.0")
    (rake        "0.3.2")
    (dash        "2.18.1"))
  :url "https://github.com/asok/projectile-rails"
  :commit "6a18ada3566ab2cb795129e3dfca2a32cc413fb8"
  :revdesc "6a18ada3566a"
  :keywords '("rails" "projectile")
  :authors '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com"))
  :maintainers '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com")))
