;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-jump-helm-line" "0.5.0"
  "Ace-jump to a candidate in helm window."
  '((avy  "0.4.0")
    (helm "1.6.3"))
  :url "https://github.com/cute-jumper/ace-jump-helm-line"
  :commit "8779050e4794279946892b6a156d0086554a9c9e"
  :revdesc "8779050e4794"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
