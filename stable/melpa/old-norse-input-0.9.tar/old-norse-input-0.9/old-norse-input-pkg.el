;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "old-norse-input" "0.9"
  "An input method for Old Norse."
  ()
  :url "https://github.com/david-christiansen/emacs-old-norse-input"
  :commit "11b968e5c5331b130b20c869853074702c219982"
  :revdesc "11b968e5c533"
  :keywords '("languages")
  :authors '(("David Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Christiansen" . "david@davidchristiansen.dk")))
