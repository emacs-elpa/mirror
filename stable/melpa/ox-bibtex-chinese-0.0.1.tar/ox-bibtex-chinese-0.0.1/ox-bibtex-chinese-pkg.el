;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-bibtex-chinese" "0.0.1"
  "Let ox-bibtex work well for Chinese users."
  '((emacs "24.4"))
  :url "https://github.com/tumashu/ox-bibtex-chinese.git"
  :commit "431c9dfebc309078cfcb0fc4b5585731ad9e53ee"
  :revdesc "431c9dfebc30"
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
