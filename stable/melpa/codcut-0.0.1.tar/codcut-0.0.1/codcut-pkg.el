;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codcut" "0.0.1"
  "Share pieces of code to Codcut."
  ()
  :url "https://github.com/codcut/codcut-emacs"
  :commit "d611b3725f91c5490655492f859e01a27a355a67"
  :revdesc "d611b3725f91"
  :keywords '("comm" "tools" "codcut" "share")
  :authors '(("Diego Pasquali" . "hello@dgopsq.space"))
  :maintainers '(("Diego Pasquali" . "hello@dgopsq.space")))
