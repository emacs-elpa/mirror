;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fish-completion" "1.2"
  "Fish completion for pcomplete (shell and Eshell)."
  '((emacs "25.1"))
  :url "https://gitlab.com/Ambrevar/emacs-fish-completion"
  :commit "10384881817b5ae38cf6197a077a663420090d2c"
  :revdesc "10384881817b"
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
