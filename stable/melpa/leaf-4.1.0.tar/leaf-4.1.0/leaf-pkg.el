;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf" "4.1.0"
  "Simplify your init.el configuration, extended use-package."
  '((emacs "24.4"))
  :url "https://github.com/conao3/leaf.el"
  :commit "0841ab466a1542868b5448bb375ac9f0c33e2b3f"
  :revdesc "0841ab466a15"
  :keywords '("lisp" "settings")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
