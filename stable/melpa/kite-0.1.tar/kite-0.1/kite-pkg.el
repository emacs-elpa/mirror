;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kite" "0.1"
  "WebKit inspector front-end."
  '((json      "1.2")
    (websocket "0.93.1"))
  :url "https://github.com/jscheid/kite"
  :commit "3deba10285791a3dc8063498f68267b048c035c1"
  :revdesc "3deba1028579"
  :keywords '("tools")
  :authors '(("Julian Scheid" . "julians37@gmail.com"))
  :maintainers '(("Julian Scheid" . "julians37@gmail.com")))
