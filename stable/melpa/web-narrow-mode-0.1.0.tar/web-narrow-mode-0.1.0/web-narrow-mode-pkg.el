;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "web-narrow-mode" "0.1.0"
  "[No description available]."
  '((web-mode "14.0.27"))
  :url "https://github.com/Qquanwei/web-narrow-mode"
  :commit "6eb9eca60bd6ef0e840ee0cb500171132557647b"
  :revdesc "6eb9eca60bd6"
  :authors '(("Qquanwei" . "quanwei9958@126.com"))
  :maintainers '(("Johan Andersson" . "quanwei9958@126.com")))
