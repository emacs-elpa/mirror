;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinboard-api" "0.1"
  "Rudimentary http://pinboard.in integration."
  ()
  :url "https://github.com/danieroux/pinboard-api-el"
  :commit "89a759688a0806af1eae06414c5baebec8cd2a04"
  :revdesc "89a759688a08"
  :keywords '("pinboard" "www")
  :authors '(("Danie Roux" . "danie@danieroux.com"))
  :maintainers '(("Danie Roux" . "danie@danieroux.com")))
