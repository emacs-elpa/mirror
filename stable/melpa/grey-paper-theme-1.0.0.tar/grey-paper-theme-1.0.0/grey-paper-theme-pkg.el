;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grey-paper-theme" "1.0.0"
  "The \"Grey paper\" theme."
  ()
  :url "https://github.com/gugod/grey-paper-theme"
  :commit "87d536a54766660cd397779343343a9ff44c872c"
  :revdesc "87d536a54766"
  :authors '(("Kang-min Liu" . "gugod@gugod.org"))
  :maintainers '(("Kang-min Liu" . "gugod@gugod.org")))
