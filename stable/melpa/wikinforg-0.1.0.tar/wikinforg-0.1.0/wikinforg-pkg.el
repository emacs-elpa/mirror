;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wikinforg" "0.1.0"
  "Org-mode wikinfo integration."
  '((emacs   "27.1")
    (wikinfo "0.0.0")
    (org     "9.3"))
  :url "https://github.com/progfolio/wikinforg"
  :commit "3db72753c43f9ba31ac7cc49a8d7b31d329e2dc0"
  :revdesc "3db72753c43f"
  :keywords '("org" "convenience")
  :authors '(("Nicholas Vollmer" . "progfolio@protonmail.com"))
  :maintainers '(("Nicholas Vollmer" . "progfolio@protonmail.com")))
