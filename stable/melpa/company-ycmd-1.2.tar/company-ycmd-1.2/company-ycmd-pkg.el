;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ycmd" "1.2"
  "Company-mode backend for ycmd."
  '((ycmd      "1.2")
    (company   "0.9.3")
    (deferred  "0.5.1")
    (s         "1.11.0")
    (dash      "2.13.0")
    (let-alist "1.0.5")
    (f         "0.19.0"))
  :url "https://github.com/abingham/emacs-ycmd"
  :commit "d042a673b4d717c3ca9d641f120bfe16c994c740"
  :revdesc "d042a673b4d7"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com")
             ("Peter Vasil" . "mail@petervasil.net"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")
                 ("Peter Vasil" . "mail@petervasil.net")))
