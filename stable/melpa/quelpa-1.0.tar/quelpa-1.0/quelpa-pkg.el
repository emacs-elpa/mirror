;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quelpa" "1.0"
  "Emacs Lisp packages built directly from source."
  '((emacs "25.1"))
  :url "https://github.com/quelpa/quelpa"
  :commit "f1fc228f217be692eaae2d53f51966ce922d6a32"
  :revdesc "f1fc228f217b"
  :keywords '("tools" "package" "management" "build" "source" "elpa"))
