;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cake-inflector" "1.1.1"
  "Lazy porting CakePHP infrector.php to el."
  '((s "1.9.0"))
  :url "https://github.com/k1LoW/emacs-cake-inflector"
  :commit "40bf11890842ba305954528694e1c39a8b73737b"
  :revdesc "40bf11890842"
  :authors '((nil . "k1low[at]101000lab[dot]org"))
  :maintainers '((nil . "k1low[at]101000lab[dot]org")))
