;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "equake" "0.999111"
  "Drop-down console for (e)shell & terminal emulation."
  '((emacs "27.1")
    (dash  "2.14.1"))
  :url "https://github.com/emacsomancer/equake"
  :commit "19ed6f8b7319b56030d996c8c5b9d209b80f95da"
  :revdesc "19ed6f8b7319"
  :keywords '("convenience" "frames" "terminals" "tools" "window-system")
  :authors '(("Benjamin Slade" . "LfLg.gg.Lx.f.xx@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "LfLg.gg.Lx.f.xx@lambda-y.net")))
