;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pest-mode" "0.1.0"
  "Major mode for editing Pest files."
  '((emacs "26.3"))
  :url "https://github.com/ksqsf/pest-mode"
  :commit "43447a2c70f98edd1139005e32f437d3f142442b"
  :revdesc "v0.1.0-0-g43447a2c70f9"
  :keywords '("languages")
  :authors '(("ksqsf" . "i@ksqsf.moe"))
  :maintainers '(("ksqsf" . "i@ksqsf.moe")))
