;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mls" "0.2.2"
  "Multi-line shell for (i)Python."
  '((emacs  "27.1")
    (compat "29.1"))
  :url "https://github.com/jdtsmith/python-mls"
  :commit "821b93ff7c94a13090598c22fd92bd19b5ad951b"
  :revdesc "821b93ff7c94"
  :keywords '("languages" "processes"))
