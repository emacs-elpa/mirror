;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitlab-snip-helm" "0.0.2"
  "Gitlab snippets api helm package."
  '((emacs "25")
    (dash  "2.12.0")
    (helm  "3.2"))
  :url "https://gitlab.com/sasanidas/gitlab-snip-helm"
  :commit "5fe0a66642da6f4e7ba9e1e3a96572c7f1876e37"
  :revdesc "5fe0a66642da"
  :keywords '("tools" "files" "convenience")
  :authors '(("Fermin MF" . "fmfs@posteo.net"))
  :maintainers '(("Fermin MF" . "fmfs@posteo.net")))
