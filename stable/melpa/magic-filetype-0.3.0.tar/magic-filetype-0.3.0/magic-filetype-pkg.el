;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magic-filetype" "0.3.0"
  "Enhance filetype major mode."
  '((emacs "24")
    (s     "1.9.0"))
  :url "https://github.com/zonuexe/magic-filetype.el"
  :commit "019494add5ff02dd36cb3f500142fc51125522cc"
  :revdesc "019494add5ff"
  :keywords '("emulations" "vim" "ft" "file" "magic-mode")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
