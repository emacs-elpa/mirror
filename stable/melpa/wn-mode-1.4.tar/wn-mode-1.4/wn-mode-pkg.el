;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wn-mode" "1.4"
  "Numeric window switching shortcuts."
  '((emacs "24"))
  :url "https://github.com/luismbo/wn-mode"
  :commit "6e7029b0d5773a79914a289937be068784931cad"
  :revdesc "6e7029b0d577"
  :keywords '("buffers" "windows" "switching-windows")
  :maintainers '(("Luís Oliveira" . "luismbo@gmail.com")))
