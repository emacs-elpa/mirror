;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ample-theme" "0.3.0"
  "Calm Dark Theme for Emacs."
  ()
  :url "https://github.com/jordonbiondo/ample-theme"
  :commit "33691c93ee302690e41f631f82083bcc15d229e8"
  :revdesc "33691c93ee30"
  :keywords '("theme" "dark")
  :authors '(("Jordon Biondo" . "jordonbiondo@gmail.com"))
  :maintainers '(("Jordon Biondo" . "jordonbiondo@gmail.com")))
