;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "audacious" "1.0"
  "Emacs interface to control audacious."
  '((helm  "3.6.2")
    (emacs "24.4"))
  :url "https://github.com/shishimaru/audacious.el"
  :commit "5eb5fbfaf113f0324a7fa2f6757b0815f3f1e571"
  :revdesc "5eb5fbfaf113"
  :authors '(("Hitoshi Uchida" . "hitoshi.uchida@gmail.com"))
  :maintainers '(("Hitoshi Uchida" . "hitoshi.uchida@gmail.com")))
