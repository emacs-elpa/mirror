;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js3-mode" "1.1.0"
  "An improved JavaScript editing mode."
  ()
  :url "https://github.com/tamzinblake/js3-mode"
  :commit "5ccda46ba39998a74bd724fdffb34634be5b6563"
  :revdesc "v1.1.0-0-g5ccda46ba399"
  :keywords '("javascript" "languages")
  :authors '(("Thom Blake" . "(webmaster@thomblake.com)"))
  :maintainers '(("Thom Blake" . "(webmaster@thomblake.com)")))
