;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idle-highlight-in-visible-buffers-mode" "0.2.0"
  "Highlight the word the point is on."
  ()
  :url "https://github.com/ignacy/idle-highlight-in-visible-buffers"
  :commit "8d8de309d5bd4b035c01bf7f0cfc6e079c79d898"
  :revdesc "8d8de309d5bd"
  :keywords '("convenience"))
