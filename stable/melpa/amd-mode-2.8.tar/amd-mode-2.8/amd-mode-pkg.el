;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amd-mode" "2.8"
  "Minor mode for handling JavaScript AMD module requirements."
  '((emacs        "25")
    (projectile   "20161008.47")
    (s            "1.9.0")
    (f            "0.16.2")
    (seq          "2.16")
    (makey        "0.3")
    (js2-mode     "20140114")
    (js2-refactor "0.6.1"))
  :url "https://github.com/NicolasPetton/amd-mode.el"
  :commit "977b53e28b3141408fff4814be8b67ee23650cac"
  :revdesc "2.8-0-g977b53e28b31"
  :keywords '("javascript" "amd" "projectile")
  :authors '(("Nicolas Petton" . "petton.nicolas@gmail.com"))
  :maintainers '(("Nicolas Petton" . "petton.nicolas@gmail.com")))
