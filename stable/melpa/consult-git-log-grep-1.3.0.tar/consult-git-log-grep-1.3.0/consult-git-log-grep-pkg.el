;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-git-log-grep" "1.3.0"
  "Consult integration for git log grep."
  '((emacs   "28.1")
    (consult "1.9"))
  :url "https://github.com/Ghosty141/consult-git-log-grep"
  :commit "5b1669ebaff9a91000ea185264cfcb850885d21f"
  :revdesc "5b1669ebaff9"
  :keywords '("git" "convenience"))
