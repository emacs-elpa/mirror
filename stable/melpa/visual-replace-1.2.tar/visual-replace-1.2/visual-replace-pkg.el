;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-replace" "1.2"
  "A prompt for replace-string and query-replace."
  '((emacs "26.1"))
  :url "https://github.com/szermatt/visual-replace"
  :commit "64fce4fd7d3df297be52045992e44591d49f4d52"
  :revdesc "64fce4fd7d3d"
  :keywords '("convenience" "matching" "replace")
  :authors '(("Stephane Zermatten" . "szermatt@gmail.com"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
