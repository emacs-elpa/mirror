;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rbs-mode" "0.3.3"
  "A major mode for RBS."
  '((emacs "25.3"))
  :url "https://github.com/ybiquitous/rbs-mode"
  :commit "c88a53a1981c301a65fa21de225708085d087b7e"
  :revdesc "c88a53a1981c"
  :keywords '("languages"))
