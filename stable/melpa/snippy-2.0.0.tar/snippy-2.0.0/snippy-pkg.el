;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snippy" "2.0.0"
  "Vscode snippet support with Yasnippet."
  '((emacs     "30.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/MiniApollo/snippy"
  :commit "6d4e049eae9dd07e84db0d7badeb201415bf46f8"
  :revdesc "v2.0.0-0-g6d4e049eae9d"
  :keywords '("convenience" "emulations")
  :authors '(("Mark Surmann" . "surmannmark@gmail.com"))
  :maintainers '(("Mark Surmann" . "surmannmark@gmail.com")))
