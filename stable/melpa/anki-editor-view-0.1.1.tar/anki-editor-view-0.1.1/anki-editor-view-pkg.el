;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor-view" "0.1.1"
  "Open Anki notes in Emacs."
  '((emacs "25.1"))
  :url "https://gitlab.com/vherrmann/anki-editor-view"
  :commit "5bf671691768c9bd418658032822c122d9a7628d"
  :revdesc "5bf671691768"
  :authors '(("Valentin Herrmann" . "me@valentin-herrmann.de"))
  :maintainers '(("Valentin Herrmann" . "me@valentin-herrmann.de")))
