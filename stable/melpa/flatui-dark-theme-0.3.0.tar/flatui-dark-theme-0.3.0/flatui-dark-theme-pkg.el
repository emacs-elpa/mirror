;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatui-dark-theme" "0.3.0"
  "Dark color theme with colors from https://flatuicolors.com/."
  '((emacs "24"))
  :url "https://github.com/theasp/flatui-dark-theme"
  :commit "af5c84e2a2810748cc71a68ec7ba333097cc1f63"
  :revdesc "af5c84e2a281"
  :keywords '("color" "theme" "dark" "flatui" "faces")
  :authors '(("Andrew Phillips" . "theasp@gmail.com"))
  :maintainers '(("Andrew Phillips" . "theasp@gmail.com")))
