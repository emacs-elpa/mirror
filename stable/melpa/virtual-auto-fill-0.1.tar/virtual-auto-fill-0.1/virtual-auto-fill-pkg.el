;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "virtual-auto-fill" "0.1"
  "Readably display text without adding line breaks."
  '((emacs "25.2")
    (,     "(adaptive-wrap 0.7)")
    (,     "(visual-fill-column 1.9)")
    (,     "(diminish 0.45)"))
  :url "https://github.com/luisgerhorst/virtual-auto-fill"
  :commit "00c6a61eb9e3857c5b9f47e4f58b74a2522ce3be"
  :revdesc "00c6a61eb9e3"
  :keywords '("minor")
  :authors '(("Luis Gerhorst" . "virtual-auto-fill@luisgerhorst.de"))
  :maintainers '(("Luis Gerhorst" . "virtual-auto-fill@luisgerhorst.de")))
