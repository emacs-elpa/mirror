;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flash-region" "1.0"
  "Flash a region."
  ()
  :url "https://github.com/Fuco1/flash-region"
  :commit "213d5056e206873c5daf2813566fd75c442298a2"
  :revdesc "213d5056e206"
  :keywords '("utility")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
