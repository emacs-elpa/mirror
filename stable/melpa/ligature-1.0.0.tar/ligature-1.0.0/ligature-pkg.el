;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ligature" "1.0.0"
  "Display typographical ligatures in major modes."
  '((emacs "28"))
  :url "https://www.github.com/mickeynp/ligature.el"
  :commit "117c9e617350a55afef4848a55219c6c00ec3178"
  :revdesc "v1.0.0-0-g117c9e617350"
  :keywords '("tools" "faces")
  :authors '(("Mickey Petersen" . "mickey@masteringemacs.org"))
  :maintainers '(("Mickey Petersen" . "mickey@masteringemacs.org")))
