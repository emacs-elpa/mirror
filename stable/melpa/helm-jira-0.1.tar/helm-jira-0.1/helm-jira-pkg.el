;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-jira" "0.1"
  "Helm bindings for JIRA/Bitbucket/stash."
  '((emacs  "24.4")
    (cl-lib "0.5")
    (helm   "1.9.9"))
  :url "https://github.com/DeX3/general.el"
  :commit "7b9769caca195de8f2ea0bb6cd27c3bbab136d7e"
  :revdesc "7b9769caca19"
  :keywords '("helm" "jira" "bitbucket" "stash")
  :authors '(("Roman Decker" . "romandotdeckeratgmaildotcom"))
  :maintainers '(("Roman Decker" . "romandotdeckeratgmaildotcom")))
