;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "filelock" "0.1"
  "Functions for manipulating file locks programmatically."
  '((emacs  "0")
    (cl-lib "0")
    (f      "0"))
  :url "https://github.com/DarwinAwardWinner/emacs-filelock"
  :commit "36999afcf517529416df2e18b2d955cdb67b56cb"
  :revdesc "36999afcf517"
  :keywords '("extensions" "files" "tools"))
