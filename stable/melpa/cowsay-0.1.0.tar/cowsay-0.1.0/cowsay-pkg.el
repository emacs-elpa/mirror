;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cowsay" "0.1.0"
  "Poorly drawn ASCII cartoons saying things."
  '((emacs "24.3"))
  :url "https://github.com/lassik/emacs-cowsay"
  :commit "60dab2ee943b26752424821cf18b2d352488c468"
  :revdesc "60dab2ee943b"
  :keywords '("games")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
