;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-goggles" "0.0.1"
  "Add a visual hint to evil operations."
  '((emacs "24")
    (evil  "1.0.0"))
  :url "https://github.com/edkolev/evil-goggles"
  :commit "dc4ce17b65d89906050a7110cfd683823ebe2585"
  :revdesc "dc4ce17b65d8"
  :keywords '("emulations" "evil" "vim" "visual")
  :authors '(("edkolev" . "evgenysw@gmail.com"))
  :maintainers '(("edkolev" . "evgenysw@gmail.com")))
