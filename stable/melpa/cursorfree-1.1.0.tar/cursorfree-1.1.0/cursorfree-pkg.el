;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cursorfree" "1.1.0"
  "Complex editing through voice."
  '((emacs "29.1")
    (phony "2.0.0"))
  :url "https://github.com/ErikPrantare/cursorfree.el"
  :commit "6029fed944fe99d4eec6660f69483d16ac0307c0"
  :revdesc "6029fed944fe"
  :keywords '("convenience")
  :authors '(("Erik Präntare" . "erik@prantare.xyz"))
  :maintainers '(("Erik Präntare" . "erik@prantare.xyz")))
