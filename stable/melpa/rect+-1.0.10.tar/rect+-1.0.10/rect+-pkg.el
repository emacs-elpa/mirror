;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rect+" "1.0.10"
  "Extensions to rect.el."
  ()
  :url "https://github.com/mhayashi1120/Emacs-rectplus"
  :commit "299b742faa0bc4448e0d5fe9cb98ab1eb93b8dcc"
  :revdesc "299b742faa0b"
  :keywords '("extensions" "data" "tools")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
