;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "peacock-theme" "20141116"
  "An Emacs 24 theme based on Peacock (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "9c4beebfb1772ff218a1a6d80ba899a40348a49a"
  :revdesc "9c4beebfb177")
