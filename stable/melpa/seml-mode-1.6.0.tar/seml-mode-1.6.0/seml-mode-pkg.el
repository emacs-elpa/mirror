;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seml-mode" "1.6.0"
  "Major-mode for SEML, S-Expression Markup Language, file."
  '((emacs        "25")
    (simple-httpd "1.5")
    (htmlize      "1.5")
    (web-mode     "16.0"))
  :url "https://github.com/conao3/seml-mode"
  :commit "1f8bda7e5a4a36212f968b462cfc31ce53c6db85"
  :revdesc "1f8bda7e5a4a"
  :keywords '("lisp" "html")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
