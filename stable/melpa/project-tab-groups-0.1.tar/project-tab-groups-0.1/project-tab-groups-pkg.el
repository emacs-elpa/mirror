;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-tab-groups" "0.1"
  "Support a \"one tab group per project\" workflow."
  '((emacs "28"))
  :url "https://github.com/fritzgrabo/project-tab-groups"
  :commit "bf8c4a42db80fb6f3289188f1d56ea1343b70ce7"
  :revdesc "bf8c4a42db80"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
