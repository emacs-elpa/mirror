;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "math-preview" "5.1.1"
  "Preview TeX math equations inline."
  '((emacs "26.1")
    (json  "1.4")
    (dash  "2.18.0")
    (s     "1.12.0"))
  :url "https://gitlab.com/matsievskiysv/math-preview"
  :commit "620de35fc8cf940eba5a567767eac2288708d8cb"
  :revdesc "620de35fc8cf"
  :keywords '("convenience"))
