;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-manager" "0.2.0"
  "Contextual terminal management."
  '((dash  "2.12.0")
    (emacs "24.4"))
  :url "https://www.github.com/IvanMalison/term-manager"
  :commit "31a3d16ba5a4f9e6f4bc52275eaedf55a96154a8"
  :revdesc "31a3d16ba5a4"
  :keywords '("terminals" "tools")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
