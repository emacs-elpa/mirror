;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toggle-term" "2.1"
  "Quickly toggle persistent term and shell buffers."
  '((emacs "25.1"))
  :url "https://github.com/justinlime/toggle-term.el"
  :commit "ebfce6283e53fda7f69ccda73109a02b646623af"
  :revdesc "ebfce6283e53"
  :keywords '("frames" "convenience" "terminals"))
