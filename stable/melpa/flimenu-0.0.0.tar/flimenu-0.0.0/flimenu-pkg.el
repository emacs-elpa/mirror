;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flimenu" "0.0.0"
  "Flatten imenu automatically."
  '((dash   "2.10.0")
    (emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/IvanMalison/flimenu"
  :commit "1e94e072f2e789e9aae4159820e28b202da21a60"
  :revdesc "1e94e072f2e7"
  :keywords '("imenu" "browse" "structure" "hook" "mode")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
