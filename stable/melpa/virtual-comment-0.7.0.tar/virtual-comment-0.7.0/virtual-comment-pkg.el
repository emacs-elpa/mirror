;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "virtual-comment" "0.7.0"
  "Virtual Comments."
  '((emacs "26.1"))
  :url "https://github.com/thanhvg/emacs-virtual-comment"
  :commit "1d4284874aeea3ce7dc8ad11abefd535d6ffd7e3"
  :revdesc "1d4284874aee"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
