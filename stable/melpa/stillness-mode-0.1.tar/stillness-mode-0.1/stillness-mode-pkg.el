;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stillness-mode" "0.1"
  "Prevent windows from jumping on minibuffer activation."
  '((emacs "26.1")
    (dash  "2.18.0"))
  :url "https://github.com/neeasade/stillness-mode.el"
  :commit "b30362d7be0e4f5d9a43350fac970c0627435859"
  :revdesc "b30362d7be0e"
  :keywords '("convenience")
  :authors '(("neeasade" . "neeasade@users.noreply.github.com"))
  :maintainers '(("neeasade" . "neeasade@users.noreply.github.com")))
