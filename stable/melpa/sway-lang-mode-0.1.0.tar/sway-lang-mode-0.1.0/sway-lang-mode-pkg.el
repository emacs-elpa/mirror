;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sway-lang-mode" "0.1.0"
  "Major mode for sway."
  '((emacs     "25.1")
    (lsp-mode  "6.0")
    (rust-mode "1.0.5"))
  :url "https://github.com/hhamud/sway-mode"
  :commit "7823f801c4b7c57f63adfa0cc5ecfd60321de1a6"
  :revdesc "7823f801c4b7"
  :keywords '("languages"))
