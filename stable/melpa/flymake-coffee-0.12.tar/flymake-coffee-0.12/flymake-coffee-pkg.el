;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-coffee" "0.12"
  "A flymake handler for coffee script."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-coffee"
  :commit "d4ef325255ea36d1dd622f29284fe72c3fc9abc0"
  :revdesc "d4ef325255ea"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
