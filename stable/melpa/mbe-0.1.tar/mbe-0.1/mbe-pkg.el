;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mbe" "0.1"
  "Macros by Example."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/ijp/mbe.el"
  :commit "b022030d6e26198bb8a93a5b0bfe7aa891cd59ec"
  :revdesc "v0.1-0-gb022030d6e26"
  :keywords '("tools" "macros")
  :authors '(("Ian Price" . "ianprice90@googlemail.com"))
  :maintainers '(("Ian Price" . "ianprice90@googlemail.com")))
