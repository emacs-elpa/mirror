;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "look-dired" "20151110.1832"
  "Extensions to look-mode for dired buffers."
  '((look-mode "1.0"))
  :url "https://github.com/vapniks/look-dired"
  :commit "5b2afe910a904d13674103f5264c6bcdbb9f9fb2"
  :revdesc "5b2afe910a90"
  :keywords '("convenience")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
