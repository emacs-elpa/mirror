;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thumb-through" "0.3"
  "Plain text reader of HTML documents."
  ()
  :url "https://github.com/apg/thumb-through"
  :commit "f97c2deba0cf6ea90c86a94550d8dc4c543aabde"
  :revdesc "f97c2deba0cf"
  :keywords '("html"))
