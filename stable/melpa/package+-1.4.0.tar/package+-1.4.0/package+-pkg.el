;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package+" "1.4.0"
  "Extensions for the package library."
  '((emacs "24.3"))
  :url "https://github.com/zenspider/package"
  :commit "2729bfd012c53733d3e00267d81d849ce5aa8e2d"
  :revdesc "2729bfd012c5"
  :keywords '("extensions" "tools")
  :authors '(("Ryan Davis" . "ryand-ruby@zenspider.com"))
  :maintainers '(("Ryan Davis" . "ryand-ruby@zenspider.com")))
