;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ciel" "0.0.1"
  "A command that is clone of \"ci\" in vim."
  '((emacs "24"))
  :url "https://github.com/cs14095/ciel.el"
  :commit "9dbfb2a986c045703fc4f501a3f3f0c0627bd1b0"
  :revdesc "9dbfb2a986c0"
  :keywords '("convinience")
  :authors '(("Takuma Matsushita" . "cs14095@gmail.com"))
  :maintainers '(("Takuma Matsushita" . "cs14095@gmail.com")))
