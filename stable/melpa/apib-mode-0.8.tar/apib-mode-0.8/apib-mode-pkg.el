;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apib-mode" "0.8"
  "Major mode for API Blueprint files."
  '((markdown-mode "2.1"))
  :url "https://github.com/w-vi/apib-mode"
  :commit "c6dd05201f6eb9295736d8668a79a7510d11159e"
  :revdesc "c6dd05201f6e"
  :keywords '("tools" "api-blueprint")
  :authors '(("Vilibald Wanča" . "vilibald@wvi.cz"))
  :maintainers '(("Vilibald Wanča" . "vilibald@wvi.cz")))
