;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.3.1"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "de73191feea2823d1b2599d96ea0f41f63b77dc8"
  :revdesc "hyperbole-9.3.1-0-gde73191feea2"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")
                 ("Mats Lidell" . "matsl@gnu.org")))
