;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cybercafe-theme" "0.3.3"
  "Cybercafe color theme."
  '((emacs "24.1"))
  :url "https://github.com/gboncoffee/cybercafe-emacs-theme"
  :commit "62346a69e59a9d19883e081c58cc4bce44dd0aef"
  :revdesc "62346a69e59a"
  :keywords '("faces")
  :authors '((nil . "GabrieldeBritogabrielgbrito@icloud.com"))
  :maintainers '((nil . "GabrieldeBritogabrielgbrito@icloud.com")))
