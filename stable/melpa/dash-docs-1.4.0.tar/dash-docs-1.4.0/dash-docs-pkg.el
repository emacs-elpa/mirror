;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dash-docs" "1.4.0"
  "Offline documentation browser using Dash docsets."
  '((emacs  "24.4")
    (cl-lib "0.5")
    (async  "1.9.3"))
  :url "https://github.com/areina/helm-dash"
  :commit "fcde53fd006928fe68380d2ee5139a9c46dea5df"
  :revdesc "fcde53fd0069"
  :keywords '("docs")
  :authors '(("Raimon Grau" . "raimonster@gmail.com")
             ("Toni Reina" . "areina0@gmail.com")
             ("Bryan Gilbert" . "bryan@bryan.sh"))
  :maintainers '(("Raimon Grau" . "raimonster@gmail.com")
                 ("Toni Reina" . "areina0@gmail.com")
                 ("Bryan Gilbert" . "bryan@bryan.sh")))
