;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "list-environment" "0.1"
  "A tabulated process environment editor."
  ()
  :url "https://github.com/dgtized/list-environment.el"
  :commit "fa177c71863777f92a8508b568d4026e12879a78"
  :revdesc "fa177c718637"
  :keywords '("processes" "unix")
  :authors '(("Charles L.G. Comstock" . "dgtized@gmail.com"))
  :maintainers '(("Charles L.G. Comstock" . "dgtized@gmail.com")))
