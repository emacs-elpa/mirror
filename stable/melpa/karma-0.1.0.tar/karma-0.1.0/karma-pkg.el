;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "karma" "0.1.0"
  "Karma Test Runner Emacs Integration."
  ()
  :url "https://github.com/tonini/karma.el"
  :commit "f4ee856e7f59649e9d9021c46f872f9b4f5b7e6e"
  :revdesc "f4ee856e7f59"
  :keywords '("javascript" "js" "karma" "testing"))
