;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exec-in-buffer" "0.0.1"
  "Choose programs to execute on buffers in projects."
  ()
  :url "https://github.com/arteen1000/exec-in-buffer"
  :commit "552e4eaedcac6f7e5eed103a305da5404d788d7b"
  :revdesc "552e4eaedcac"
  :keywords '("tools" "c" "c++" "formatting" "projects")
  :authors '(("Arteen Abrishami" . "arteen@ucla.edu"))
  :maintainers '(("Arteen Abrishami" . "arteen@ucla.edu")))
