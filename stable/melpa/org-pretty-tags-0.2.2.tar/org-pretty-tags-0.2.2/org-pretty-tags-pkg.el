;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-pretty-tags" "0.2.2"
  "Surrogates for tags."
  '((emacs "25"))
  :url "https://gitlab.com/marcowahl/org-pretty-tags"
  :commit "549fa6969660dcf0cf9bca5b7341d0cb48ec3b77"
  :revdesc "549fa6969660"
  :keywords '("reading" "outlines")
  :authors '(("Marco Wahl" . "marcowahlsoft@gmail.com"))
  :maintainers '(("Marco Wahl" . "marcowahlsoft@gmail.com")))
