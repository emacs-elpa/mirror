;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "desktop+" "0.2"
  "Handle special buffers when saving & restoring sessions."
  '((emacs "24.4")
    (dash  "2.11.0")
    (f     "0.17.2"))
  :url "https://github.com/ffevotte/desktop-plus"
  :commit "a9cb8dd0af5071d9f148211b408c54306239381c"
  :revdesc "a9cb8dd0af50"
  :authors '(("François Févotte" . "fevotte@gmail.com"))
  :maintainers '(("François Févotte" . "fevotte@gmail.com")))
