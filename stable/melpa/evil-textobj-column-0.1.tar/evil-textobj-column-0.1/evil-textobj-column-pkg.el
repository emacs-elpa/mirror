;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-column" "0.1"
  "Provides column text objects."
  '((names "0.5")
    (emacs "24")
    (evil  "0"))
  :url "https://github.com/noctuid/evil-textobj-column"
  :commit "82f6a1c04e643e00630806c608dba7aa94862246"
  :revdesc "82f6a1c04e64"
  :keywords '("evil" "column" "text-object")
  :authors '(("Lit Wakefield" . "noct@openmailbox.org"))
  :maintainers '(("Lit Wakefield" . "noct@openmailbox.org")))
