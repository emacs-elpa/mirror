;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iwd-manager" "0.2"
  "Manage IWD via the D-Bus interface."
  '((emacs   "26.1")
    (promise "1.1"))
  :url "https://github.com/sarg/wpa-manager.el"
  :commit "e947dff1f5593b3b01b380cc195108649392b89a"
  :revdesc "e947dff1f559"
  :authors '(("Sergey Trofimov" . "sarg@sarg.org.ru"))
  :maintainers '(("Sergey Trofimov" . "sarg@sarg.org.ru")))
