;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grapnel" "0.5.3"
  "HTTP request lib with flexible callback dispatch."
  ()
  :url "http://www.github.com/leathekd/grapnel"
  :commit "7387234eb3f0285a490fddb1e06a4bf029719fb7"
  :revdesc "7387234eb3f0"
  :authors '(("David Leatherman" . "leathekd@gmail.com"))
  :maintainers '(("David Leatherman" . "leathekd@gmail.com")))
