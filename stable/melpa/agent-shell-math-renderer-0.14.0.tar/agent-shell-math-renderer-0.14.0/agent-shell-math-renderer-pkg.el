;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.14.0"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.67.1")
    (latex-to-svg-backend "0.15.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "31b99b470764eda3906fa985e49a051ee380bc57"
  :revdesc "v0.14.0-0-g31b99b470764"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
