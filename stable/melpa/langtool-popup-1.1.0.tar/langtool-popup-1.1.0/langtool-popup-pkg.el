;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "langtool-popup" "1.1.0"
  "Popup message extension for langtool.el."
  '((emacs    "25.1")
    (popup    "0.5.9")
    (langtool "2.3.2"))
  :url "https://github.com/mhayashi1120/Emacs-langtool"
  :commit "e0666f000c11571f96582f0a1dd75d6e29e74703"
  :revdesc "e0666f000c11"
  :keywords '("docs")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
