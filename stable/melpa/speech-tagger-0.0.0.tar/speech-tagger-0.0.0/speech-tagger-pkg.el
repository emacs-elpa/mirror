;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speech-tagger" "0.0.0"
  "[No description available]."
  ()
  :url "https://github.com/cosmicexplorer/speech-tagger"
  :commit "e6595bd0eea93ede1534c536c1746c9cf763b73c"
  :revdesc "e6595bd0eea9")
