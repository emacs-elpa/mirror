;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-ruby" "2.9.0"
  "Run a Ruby process in a buffer."
  '((emacs "26.1"))
  :url "https://github.com/nonsequitur/inf-ruby"
  :commit "b8076aad10dfb0ba1e3a8b0d39c2b370dbe96ab0"
  :revdesc "b8076aad10df"
  :keywords '("languages" "ruby")
  :authors '(("Cornelius Mika" . "cornelius.mika@gmail.com")
             ("Dmitry Gutov" . "dgutov@yandex.ru")
             ("Kyle Hargraves" . "pd@krh.me"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
