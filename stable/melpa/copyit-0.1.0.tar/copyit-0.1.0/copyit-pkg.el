;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copyit" "0.1.0"
  "Copy it, yank anything!."
  '((emacs "24.3")
    (s     "1.9.0"))
  :url "https://github.com/zonuexe/emacs-copyit"
  :commit "c4f2c28e5b6270e8e3364341619f1154bb4e682e"
  :revdesc "c4f2c28e5b62"
  :keywords '("convenience" "yank" "clipboard")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
