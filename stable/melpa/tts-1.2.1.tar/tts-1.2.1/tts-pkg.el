;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tts" "1.2.1"
  "Text-to-Speech (TTS)."
  '((emacs "29.1"))
  :url "https://github.com/DiogoDoreto/emacs-tts"
  :commit "315cec02dd3c90516165a84231820f151ac7fcdd"
  :revdesc "315cec02dd3c"
  :keywords '("convenience" "languages" "multimedia" "tools")
  :authors '(("Diogo Doreto" . "diogo@doreto.com.br"))
  :maintainers '(("Diogo Doreto" . "diogo@doreto.com.br")))
