;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "narumi" "1.0.0"
  "A dashboard that displays a ramdom sampled image."
  '((emacs "26.1"))
  :url "https://github.com/nryotaro/narumi"
  :commit "12d0a32d962a077780a0aa6f88d75c314e7c4641"
  :revdesc "12d0a32d962a")
