;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.51.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "02d0e3743dbe1a8c607adcfdc526367d798f4c23"
  :revdesc "02d0e3743dbe"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
