;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stock-tracker" "0.2.0"
  "Track stock price."
  '((emacs "27.1")
    (dash  "2.16.0")
    (async "1.9.5"))
  :url "https://github.com/beacoder/stock-tracker"
  :commit "d3482bf03e738d70396412e2437da534b9059176"
  :revdesc "d3482bf03e73"
  :keywords '("convenience" "stock" "finance")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
