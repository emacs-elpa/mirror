;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shift-text" "0.3"
  "Move the region in 4 directions, in a way similar to Eclipse's."
  '((cl-lib "1.0")
    (es-lib "0.3"))
  :url "https://github.com/sabof/shift-text"
  :commit "d75b27a3de130ae78ca44d4cf776d757681185fc"
  :revdesc "d75b27a3de13")
