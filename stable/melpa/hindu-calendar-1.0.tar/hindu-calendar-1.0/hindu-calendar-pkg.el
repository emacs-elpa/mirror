;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hindu-calendar" "1.0"
  "A simplified arithmetic Hindu calendar (panchanga)."
  '((emacs "24.3"))
  :url "https://github.com/bdsatish/hindu-calendar"
  :commit "7d46e8257de360643c52773f5696c752f4d9e2b3"
  :revdesc "7d46e8257de3"
  :keywords '("calendar" "panchanga" "hindu" "indian")
  :authors '(("B.D.Satish" . "bdsatish@gmail.com"))
  :maintainers '(("B.D.Satish" . "bdsatish@gmail.com")))
