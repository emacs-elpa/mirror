;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-review" "0.3.0"
  "Re:VIEW Back-End for Org Export Engine."
  '((emacs "26.1")
    (org   "9"))
  :url "https://github.com/masfj/ox-review"
  :commit "470297cbe833c65fd3c191de30fa0442ff7f4e45"
  :revdesc "470297cbe833"
  :keywords '("outlines" "hypermedia"))
