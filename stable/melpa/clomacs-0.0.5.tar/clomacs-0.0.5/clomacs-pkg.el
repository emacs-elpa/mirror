;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clomacs" "0.0.5"
  "Simplifies Emacs Lisp interaction with Clojure."
  '((emacs        "24.3")
    (cider        "0.22.1")
    (s            "1.12.0")
    (simple-httpd "1.4.6"))
  :url "https://github.com/clojure-emacs/clomacs"
  :commit "ada167954911bf1631ea73537b4b496f35f99a73"
  :revdesc "v0.0.5-0-gada167954911"
  :keywords '("clojure" "interaction")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
