;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gemtext-mode" "1.0"
  "Major mode for Gemtext-formatted text."
  '((emacs "29.1"))
  :url "https://sr.ht/~arjca/gemtext-mode.el/"
  :commit "b928efc85dcfae6f968f6f98fa82ea8b802a6376"
  :revdesc "b928efc85dcf"
  :keywords '("languages" "gemtext" "gemini")
  :authors '(("Antoine Aubé" . "courriel@arjca.fr"))
  :maintainers '(("Antoine Aubé" . "courriel@arjca.fr")))
