;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "logstash-conf" "0.4"
  "Basic mode for editing logstash configuration."
  ()
  :url "https://github.com/Wilfred/logstash-conf.el"
  :commit "652dddecf19f3e39a36055823e44fcffc5b44aeb"
  :revdesc "652dddecf19f"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
