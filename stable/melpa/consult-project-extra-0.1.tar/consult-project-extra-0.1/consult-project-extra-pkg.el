;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-project-extra" "0.1"
  "Consult integration for project.el."
  '((emacs   "27.1")
    (consult "0.15"))
  :url "https://github.com/Qkessler/consult-project-extra"
  :commit "fee931a63317bcc183c34a84b758db561db3f2dd"
  :revdesc "fee931a63317"
  :keywords '("convenience" "project" "management"))
