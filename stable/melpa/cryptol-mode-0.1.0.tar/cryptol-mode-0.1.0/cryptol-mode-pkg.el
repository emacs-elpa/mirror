;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cryptol-mode" "0.1.0"
  "Cryptol major mode for Emacs."
  ()
  :url "https://github.com/thoughtpolice/cryptol-mode"
  :commit "a54d000d24757fad2a91ae2853b16a97ebe52771"
  :revdesc "v0.1.0-0-ga54d000d2475"
  :keywords '("cryptol" "cryptography")
  :authors '(("Austin Seipp" . "aseipp[@at]pobox[dot]com"))
  :maintainers '(("Austin Seipp" . "aseipp[@at]pobox[dot]com")))
