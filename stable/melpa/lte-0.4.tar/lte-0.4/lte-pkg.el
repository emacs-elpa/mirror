;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lte" "0.4"
  "Large Table Edition in Org and Markdown buffers."
  '((emacs         "29.1")
    (org           "9.6")
    (edit-indirect "0.1.13"))
  :url "https://github.com/fredericgiquel/lte.el"
  :commit "011c86d9fb72d00105293efabef4756274d851b4"
  :revdesc "011c86d9fb72"
  :authors '(("Frédéric Giquel" . "frederic.giquel@laposte.net"))
  :maintainers '(("Frédéric Giquel" . "frederic.giquel@laposte.net")))
