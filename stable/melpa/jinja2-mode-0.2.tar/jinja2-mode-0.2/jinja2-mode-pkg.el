;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinja2-mode" "0.2"
  "A major mode for jinja2."
  ()
  :url "https://github.com/paradoxxxzero/jinja2-mode"
  :commit "cfaa7bbe7bb290cc500440124ce89686f3e26f86"
  :revdesc "cfaa7bbe7bb2")
