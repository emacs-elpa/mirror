;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recompile-on-save" "1.1"
  "Trigger recompilation on file save."
  '((dash "1.1.0"))
  :url "https://github.com/maio/recompile-on-save.el"
  :commit "64803886e28b55f99ce813466797b7c8a1036c68"
  :revdesc "64803886e28b"
  :keywords '("convenience" "files" "processes" "tools")
  :authors '(("Marian Schubert" . "marian.schubert@gmail.com"))
  :maintainers '(("Marian Schubert" . "marian.schubert@gmail.com")))
