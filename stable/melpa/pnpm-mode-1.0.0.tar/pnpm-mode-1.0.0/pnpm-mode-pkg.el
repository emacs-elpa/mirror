;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pnpm-mode" "1.0.0"
  "Minor mode for working with pnpm projects."
  '((emacs "24.1"))
  :url "https://github.com/rajasegar/pnpm-mode"
  :commit "fb671704a4a470e1aaf8f70bb18654bf9b814cbe"
  :revdesc "fb671704a4a4"
  :keywords '("convenience" "project" "javascript" "node" "npm" "pnpm")
  :authors '(("Rajasegar Chandran" . "rajasegar.c@gmail.com"))
  :maintainers '(("Rajasegar Chandran" . "rajasegar.c@gmail.com")))
