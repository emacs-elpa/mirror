;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel-evil" "3.0"
  "Extension for kubel to provide evil keybindings."
  '((kubel "1.0")
    (evil  "1.0")
    (emacs "25.3"))
  :url "https://github.com/abrochard/kubel"
  :commit "1b405d8756ffc7c8f1e11450d6f07ffde38fe351"
  :revdesc "1b405d8756ff"
  :keywords '("kubernetes" "k8s" "tools" "processes" "evil" "keybindings"))
