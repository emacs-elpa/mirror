;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.63.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "c70c72c9aec57fc019847ec7b9ef4dfc256d1580"
  :revdesc "c70c72c9aec5"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
