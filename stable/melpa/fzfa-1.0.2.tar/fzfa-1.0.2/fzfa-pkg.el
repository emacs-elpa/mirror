;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0.2"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.2"))
  :url "https://github.com/jojojames/fzfa"
  :commit "96312c040acc8c1aed14e25762f92e8ef30d276b"
  :revdesc "96312c040acc"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
