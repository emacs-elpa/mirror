;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pkl-mode" "1.0.3"
  "Major mode for editing Pkl files."
  '((emacs "24.3"))
  :url "https://github.com/sin-ack/pkl-mode"
  :commit "c57fe374a9c57eee6432d0b449e410ab8dc40a89"
  :revdesc "c57fe374a9c5"
  :keywords '("languages" "pkl")
  :authors '(("sin-ack" . "sin-ack@protonmail.com"))
  :maintainers '(("sin-ack" . "sin-ack@protonmail.com")))
