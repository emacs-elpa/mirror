;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tawny-mode" "3.0.0"
  "Ontology Editing with Tawny-OWL."
  '((cider "0.12")
    (emacs "25"))
  :url "https://github.com/phillord/tawny-owl"
  :commit "5366ed3d12e7272e7a404040d7199b0a560f25a8"
  :revdesc "5366ed3d12e7"
  :authors '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
  :maintainers '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk")))
