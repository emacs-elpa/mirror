;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "biome" "0.1.0"
  "Bountiful Interface to Open Meteo for Emacs."
  '((emacs "27.1"))
  :url "https://github.com/SqrtMinusOne/biome"
  :commit "59fcb13df2b27fde04f2b23f5b9f146abd252e5b"
  :revdesc "59fcb13df2b2"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
