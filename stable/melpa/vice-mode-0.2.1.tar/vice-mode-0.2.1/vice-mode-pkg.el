;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vice-mode" "0.2.1"
  "VIm-like Commands Extension."
  '((emacs "29.1"))
  :url "https://github.com/gpapadok/vice"
  :commit "1de53ed04d7c2f084e6177e53e18d72e9716cb68"
  :revdesc "v0.2.1-0-g1de53ed04d7c"
  :keywords '("convenience" "emulations")
  :authors '(("Giorgos Papadokostakis" . "giorgos.papadokostakis@proton.me"))
  :maintainers '(("Giorgos Papadokostakis" . "giorgos.papadokostakis@proton.me")))
