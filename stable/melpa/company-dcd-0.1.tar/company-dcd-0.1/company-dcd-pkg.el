;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-dcd" "0.1"
  "Auto Completion source for dcd for GNU Emacs."
  '((company          "0.9")
    (flycheck-dmd-dub "0.7")
    (yasnippet        "0.8")
    (popwin           "0.7"))
  :url "https://github.com/tsukimizake/company-dcd"
  :commit "6ca49fae68e4b4c94bded9d9cb3bc5c89b60848c"
  :revdesc "6ca49fae68e4"
  :keywords '("languages")
  :authors '(("tsukimizake" . "shomasd@gmail.com"))
  :maintainers '(("tsukimizake" . "shomasd@gmail.com")))
