;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aes" "1.0"
  "Implementation of AES."
  ()
  :url "https://github.com/Sauermann/emacs-aes"
  :commit "b834673297a3468eeebb1b72d7c4736ffe6094ce"
  :revdesc "b834673297a3"
  :keywords '("data" "tools")
  :authors '(("Markus Sauermann" . "emacs-aes@sauermann-consulting.de"))
  :maintainers '(("Markus Sauermann" . "emacs-aes@sauermann-consulting.de")))
