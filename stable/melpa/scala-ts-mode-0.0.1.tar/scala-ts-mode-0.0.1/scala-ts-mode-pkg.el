;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scala-ts-mode" "0.0.1"
  "Scala Tree-Sitter Mode."
  '((emacs "29.2"))
  :url "https://github.com/KaranAhlawat/scala-ts-mode"
  :commit "1aadf2bc570f1530a6f82d734f00d064c821a828"
  :revdesc "1aadf2bc570f"
  :keywords '("scala" "languages" "tree-sitter")
  :authors '(("Karan Ahlawat" . "ahlawatkaran12@gmail.com"))
  :maintainers '(("Karan Ahlawat" . "ahlawatkaran12@gmail.com")))
