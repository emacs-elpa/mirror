;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghostel" "0.57.0"
  "Consult integration for ghostel."
  '((emacs   "28.1")
    (consult "1.5")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "a269cce7d1f583a64712a7d7ee2218e728b3e505"
  :revdesc "a269cce7d1f5"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
