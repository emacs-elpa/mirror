;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "efar" "1.29"
  "FAR-like file manager."
  '((emacs "26.1"))
  :url "https://github.com/suntsov/efar"
  :commit "ee10a6770b0523f25152fbe8fc3409fdb5f70544"
  :revdesc "ee10a6770b05"
  :keywords '("files")
  :authors '(("Vladimir Suntsov" . "vladimir@suntsov.online"))
  :maintainers '((nil . "vladimir@suntsov.online")))
