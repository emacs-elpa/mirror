;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nswbuff" "1.3"
  "Quick switching between buffers."
  '((emacs "25.1"))
  :url "https://github.com/joostkremers/nswbuff"
  :commit "fa9dcf131697ea7af066e11a1edcc881c397e07f"
  :revdesc "fa9dcf131697"
  :keywords '("extensions" "convenience")
  :authors '(("David Ponce" . "david@dponce.com")
             ("Kahlil HODGSON" . "dorge@tpg.com.au")
             ("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
