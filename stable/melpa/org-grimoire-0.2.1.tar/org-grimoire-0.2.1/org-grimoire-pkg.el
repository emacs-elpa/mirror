;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-grimoire" "0.2.1"
  "Emacs-native static site generator."
  '((emacs "30.2")
    (org   "9.7.11"))
  :url "https://github.com/spiperac/org-grimoire"
  :commit "5622795eb943f529af03af04ced49d613dad1d77"
  :revdesc "v0.2.1-0-g5622795eb943"
  :keywords '("files" "hypermedia" "outlines" "text")
  :authors '(("Strahinja Piperac" . "sp@spiperac.dev"))
  :maintainers '(("Strahinja Piperac" . "sp@spiperac.dev")))
