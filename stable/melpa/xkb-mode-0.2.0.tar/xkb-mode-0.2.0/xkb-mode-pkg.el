;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xkb-mode" "0.2.0"
  "Major mode for editing X Keyboard Extension (XKB) files."
  '((emacs "25.1"))
  :url "https://github.com/captainflasmr/xkb-mode"
  :commit "b1de5233dc12749a97ad6a63d86b921bf1e33d3b"
  :revdesc "b1de5233dc12"
  :keywords '("convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
