;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "omni-quotes" "0.5.1"
  "Random quotes displayer."
  '((dash     "2.8")
    (omni-log "0.4.0")
    (f        "0.19.0")
    (s        "1.11.0")
    (ht       "2.1"))
  :url "https://github.com/AdrieanKhisbe/omni-quotes.el"
  :commit "cfc7b7f01628a5d57384820d1096de4541e67cdf"
  :revdesc "cfc7b7f01628"
  :keywords '("convenience")
  :authors '(("Adrien Becchis" . "adriean.khisbe@live.fr"))
  :maintainers '(("Adrien Becchis" . "adriean.khisbe@live.fr")))
