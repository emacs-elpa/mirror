;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-eask" "0.1.0"
  "Eask support in Flymake."
  '((emacs        "26.1")
    (flymake-easy "0.1"))
  :url "https://github.com/emacs-eask/flymake-eask"
  :commit "5e1a3efa93e823da95ac4c1e79ab3812c112e6aa"
  :revdesc "5e1a3efa93e8"
  :keywords '("lisp" "eask")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
