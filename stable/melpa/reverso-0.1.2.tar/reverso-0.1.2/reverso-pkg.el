;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reverso" "0.1.2"
  "Translation, grammar checking, context search."
  '((emacs     "27.1")
    (transient "0.3.7")
    (request   "0.3.2"))
  :url "https://github.com/SqrtMinusOne/reverso.el"
  :commit "47812d7738047277e2ab365c45a9512e8258422c"
  :revdesc "47812d773804"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
