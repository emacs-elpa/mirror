;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "peek-mode" "0.1"
  "Serve buffers live over HTTP with elnode backend."
  '((elnode "0.9.8.1"))
  :url "https://github.com/erikriverson/peek-mode"
  :commit "17a73ec6edd808dbf63aa045b72f62d79432c00d"
  :revdesc "17a73ec6edd8"
  :authors '(("Erik Iverson" . "erik@sigmafield.org"))
  :maintainers '(("Erik Iverson" . "erik@sigmafield.org")))
