;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ewm" "0.1.0"
  "Window manager."
  '((emacs     "26.1")
    (eyebrowse "0.7.8"))
  :url "https://github.com/laluxx/ewm"
  :commit "4bef9db7c54066200c8ac845d24b72ffdd30d862"
  :revdesc "4bef9db7c540"
  :keywords '("windows" "convenience"))
