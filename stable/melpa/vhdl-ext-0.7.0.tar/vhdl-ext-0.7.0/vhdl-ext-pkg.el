;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ext" "0.7.0"
  "VHDL Extensions."
  '((emacs        "29.1")
    (vhdl-ts-mode "0.3.2")
    (lsp-mode     "8.0.0")
    (ag           "0.48")
    (ripgrep      "0.4.0")
    (hydra        "0.15.0")
    (flycheck     "32")
    (async        "1.9.7"))
  :url "https://github.com/gmlarumbe/vhdl-ext"
  :commit "5a3513d2f26ace017e9fab7141754ff5bdebb0eb"
  :revdesc "5a3513d2f26a"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
