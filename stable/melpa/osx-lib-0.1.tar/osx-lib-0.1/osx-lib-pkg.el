;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-lib" "0.1"
  "Basic functions for Apple/OSX."
  '((emacs "24.4"))
  :url "https://github.com/raghavgautam/osx-lib"
  :commit "dcde41c7e0de66b528a30b148ba95fe5673341f1"
  :revdesc "dcde41c7e0de"
  :keywords '("apple" "applescript" "osx" "finder" "emacs" "elisp" "vpn" "speech")
  :authors '(("Raghav Kumar Gautam" . "raghav@apache.org"))
  :maintainers '(("Raghav Kumar Gautam" . "raghav@apache.org")))
