;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "teleport" "0.0.2"
  "Integration for tsh (goteleport.com)."
  '((emacs "28.1")
    (dash  "2.18.0"))
  :url "https://github.com/caramelhooves/teleport.el"
  :commit "0cda2233170109fa87a9ff97a79fb315b039f91e"
  :revdesc "0cda22331701"
  :keywords '("tools")
  :authors '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainers '(("Caramel Hooves" . "caramel.hooves@protonmail.com")))
