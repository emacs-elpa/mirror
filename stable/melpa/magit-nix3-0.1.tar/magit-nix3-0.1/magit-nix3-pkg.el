;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-nix3" "0.1"
  "Nix3.el integration for Magit."
  '((emacs   "27.1")
    (nix3    "0.1")
    (promise "1.1"))
  :url "https://github.com/emacs-twist/nix3.el"
  :commit "bd708a67401324e8992acdec0edc3170419b3745"
  :revdesc "bd708a674013"
  :keywords '("processes")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
