;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "session" "2.2"
  "Use variables, registers and buffer places across sessions."
  ()
  :url "http://emacs-session.sourceforge.net/"
  :commit "722e5673c93521aa3bf4ca082d48009438e6c5cb"
  :revdesc "722e5673c935"
  :keywords '("session" "session management" "desktop" "data" "tools")
  :authors '(("Christoph Wedler" . "wedler@users.sourceforge.net"))
  :maintainers '(("Christoph Wedler" . "wedler@users.sourceforge.net")))
