;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persp-fr" "0.0.5"
  "In persp-mode, show perspective list in the GUI window title."
  '((emacs      "25.1")
    (persp-mode "2.9.6")
    (dash       "2.13.0"))
  :url "https://github.com/rocher/persp-fr"
  :commit "1adbb6a9f9a4db580a9b7ed8b4091738e01345e6"
  :revdesc "1adbb6a9f9a4"
  :keywords '("perspectives" "workspace" "windows" "convenience")
  :authors '(("Francesc Rocher" . "francesc.rocher@gmail.com"))
  :maintainers '(("Francesc Rocher" . "francesc.rocher@gmail.com")))
