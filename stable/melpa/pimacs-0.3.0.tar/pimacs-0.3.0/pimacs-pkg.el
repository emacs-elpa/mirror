;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.3.0"
  "Emacs Client for Pi."
  '((emacs         "29.1")
    (compat        "31.0")
    (markdown-mode "2.8")
    (timeout       "2.1.7")
    (pcre2el       "1.12")
    (spinner       "1.7")
    (transient     "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "67f40203ba742399276d7842ad529fd46076aec5"
  :revdesc "67f40203ba74"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
