;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-fringe-status" "1.0.0"
  "Show last status in fringe."
  ()
  :url "http://projects.ryuslash.org/eshell-fringe-status/"
  :commit "047e9b9c75a39ac9f903bab937918165261d44f8"
  :revdesc "047e9b9c75a3"
  :authors '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainers '(("Tom Willemse" . "tom@ryuslash.org")))
