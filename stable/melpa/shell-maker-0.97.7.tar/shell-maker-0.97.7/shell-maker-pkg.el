;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.97.7"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "fc5fd0ef732f816c38fa4840e988eaa6707839e7"
  :revdesc "fc5fd0ef732f")
