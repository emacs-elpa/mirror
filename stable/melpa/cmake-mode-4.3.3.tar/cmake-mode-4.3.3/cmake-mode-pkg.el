;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-mode" "4.3.3"
  "Major-mode for editing CMake sources."
  '((emacs "24.1"))
  :commit "06cc1d04d8d5a4e13abdadfe20f6937787b1968e"
  :revdesc "v4.3.3-0-g06cc1d04d8d5")
