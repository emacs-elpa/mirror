;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liso-theme" "2.1"
  "Eclectic Dark Theme for GNU Emacs."
  ()
  :url "https://github.com/caisah/liso-theme"
  :commit "d92ca29debf559999bf22f352fddd303618221f9"
  :revdesc "d92ca29debf5"
  :keywords '("theme" "themes")
  :authors '(("Vlad Piersec" . "vlad.piersec@gmail.com"))
  :maintainers '(("Vlad Piersec" . "vlad.piersec@gmail.com")))
