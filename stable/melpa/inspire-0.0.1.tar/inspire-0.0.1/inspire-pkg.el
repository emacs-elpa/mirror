;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inspire" "0.0.1"
  "Emacs interface for inspirehep.net."
  '((emacs "27.1"))
  :url "https://github.com/Simon-Lin/inspire.el"
  :commit "7f57cb5ea11b359c80c6bede0bbd45b8390c94f9"
  :revdesc "7f57cb5ea11b"
  :keywords '("extensions" "tex")
  :authors '(("Simon Lin" . "n.sibetz@gmail.com"))
  :maintainers '(("Simon Lin" . "n.sibetz@gmail.com")))
