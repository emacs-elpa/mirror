;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pulseaudio-control" "0.1"
  "Use `pactl' to manage PulseAudio volumes."
  ()
  :url "https://github.com/flexibeast/pulseaudio-control"
  :commit "b5d51bf63c85cb2048cad8943a3c47406351309c"
  :revdesc "b5d51bf63c85"
  :keywords '("multimedia" "hardware" "sound" "pulseaudio")
  :authors '(("Alexis" . "flexibeast@gmail.com"))
  :maintainers '(("Alexis" . "flexibeast@gmail.com")))
