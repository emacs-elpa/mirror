;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smiles-mode" "0.0.1"
  "Major mode for SMILES."
  ()
  :commit "5494a0d13a32fb96f052b83ac3f07c6fc102a8bc"
  :revdesc "5494a0d13a32"
  :keywords '("smiles")
  :authors '((nil . "JohnKitchinjkitchin@andrew.cmu.edu"))
  :maintainers '((nil . "JohnKitchinjkitchin@andrew.cmu.edu")))
