;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rg" "2.4.0"
  "A search tool based on ripgrep."
  '((emacs     "26.1")
    (transient "0.9.2")
    (wgrep     "2.1.10"))
  :url "https://github.com/dajva/rg.el"
  :commit "b123ac91b86f0ec5479934b0569d9e612fe1e2d5"
  :revdesc "b123ac91b86f"
  :keywords '("matching" "tools")
  :authors '(("David Landell" . "david.landell@sunnyhill.email")
             ("Roland McGrath" . "roland@gnu.org"))
  :maintainers '(("David Landell" . "david.landell@sunnyhill.email")
                 ("Roland McGrath" . "roland@gnu.org")))
