;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-dash" "0.1.3"
  "Browse dash docsets using Ivy."
  '((emacs           "24.4")
    (dash            "2.12.1")
    (dash-functional "1.2.0")
    (helm-dash       "1.3.0")
    (counsel         "0.8.0"))
  :url "https://github.com/nathankot/counsel-dash"
  :commit "a342340bbd8e50e4d1015e0b91d8ecd8f6cdf9f2"
  :revdesc "a342340bbd8e"
  :keywords '("dash" "ivy" "counsel")
  :authors '(("Nathan Kot" . "nk@nathankot.com"))
  :maintainers '(("Nathan Kot" . "nk@nathankot.com")))
