;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cypher-mode" "0.0.6"
  "Major mode for editing cypher scripts."
  ()
  :url "https://github.com/fxbois/cypher-mode"
  :commit "a1ea5bb768e810ea38d93f83f6ac8b6697942882"
  :revdesc "a1ea5bb768e8"
  :keywords '("cypher" "graph")
  :authors '(("François-Xavier Bois" . "fxboisATGoogleMailService")))
