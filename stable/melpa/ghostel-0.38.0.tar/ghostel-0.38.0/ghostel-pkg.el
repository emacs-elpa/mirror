;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.38.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b6d7b37353572bf92d04c8de5abced3ef68a0304"
  :revdesc "b6d7b3735357"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
