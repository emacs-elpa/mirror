;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuzzy" "0.3"
  "Fuzzy Matching."
  ()
  :url "https://github.com/auto-complete/fuzzy-el"
  :commit "122939ee0a82efa1bcf405de3134debe34e4a0b6"
  :revdesc "v0.3-0-g122939ee0a82"
  :keywords '("convenience")
  :authors '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainers '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com")))
