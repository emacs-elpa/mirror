;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-rtags" "0.1"
  "RTags completion back-end for ivy."
  '((ivy   "0.7.0")
    (rtags "2.9"))
  :url "http://rtags.net"
  :commit "8e12f2f4ae77343d40851cde0b9bfabe9e7769d0"
  :revdesc "8e12f2f4ae77"
  :authors '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
             ("Anders Bakken" . "agbakken@gmail.com"))
  :maintainers '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
                 ("Anders Bakken" . "agbakken@gmail.com")))
