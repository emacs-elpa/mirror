;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-launch" "0.2"
  "Use dired as a launcher."
  ()
  :url "https://github.com/thomp/dired-launch"
  :commit "acf8a3dec14e68934d7d7ef0b867e347ce5d81e9"
  :revdesc "acf8a3dec14e"
  :keywords '("dired" "launch"))
