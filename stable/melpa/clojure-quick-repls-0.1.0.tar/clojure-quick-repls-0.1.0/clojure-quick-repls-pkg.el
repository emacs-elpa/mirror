;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-quick-repls" "0.1.0"
  "Quickly create Clojure and ClojureScript repls for a project."
  '((cider "0.8.1")
    (dash  "2.9.0"))
  :url "https://github.com/symfrog/clojure-quick-repls"
  :commit "90f82e294cfdfb65231adc456177580cd69bfc00"
  :revdesc "90f82e294cfd"
  :keywords '("languages" "clojure" "cider" "clojurescript"))
