;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "0.1.4"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "30.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "1b5555f2de25bddb7d57d2aa8144f59759e48dac"
  :revdesc "1b5555f2de25"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
