;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "2.3.0"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "3a5ca54f63a1c8688ca580e77f06a1065283f0e7"
  :revdesc "3a5ca54f63a1"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
