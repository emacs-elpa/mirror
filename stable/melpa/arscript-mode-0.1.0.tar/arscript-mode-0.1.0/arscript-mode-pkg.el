;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arscript-mode" "0.1.0"
  "Major mode for editing arscript files."
  '((emacs "25.1"))
  :url "https://github.com/captainflasmr/arscript-mode"
  :commit "b325cae3b8ec5c528a42044f225d31e2bbaabde6"
  :revdesc "b325cae3b8ec"
  :keywords '("convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
