;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mssql" "0.1"
  "MSSQL LSP bindings."
  '((emacs        "25.1")
    (lsp-mode     "6.2")
    (dash         "2.14.1")
    (f            "0.20.0")
    (ht           "2.0")
    (lsp-treemacs "0.1"))
  :url "https://github.com/emacs-lsp/lsp-mssql"
  :commit "e16e91d6a2a6cdb406ee9b98cfb47f7a32e41d61"
  :revdesc "e16e91d6a2a6"
  :keywords '("data" "languages")
  :authors '(("Ivan Yonchovski" . "yyoncho@gmail.com"))
  :maintainers '(("Ivan Yonchovski" . "yyoncho@gmail.com")))
