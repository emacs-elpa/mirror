;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-languagetool" "0.4.2"
  "Flycheck support for LanguageTool."
  '((emacs    "27.1")
    (flycheck "0.14"))
  :url "https://github.com/emacs-languagetool/flycheck-languagetool"
  :commit "59dc7467425bda99aeb7fb16b4b0926070701d60"
  :revdesc "59dc7467425b"
  :keywords '("convenience" "grammar" "check")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com")
             ("Peter Oliver" . "git@mavit.org.uk"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Peter Oliver" . "git@mavit.org.uk")))
