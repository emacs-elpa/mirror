;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ninetyfive" "0.1.0"
  "NinetyFive -*- lexical-binding: t;."
  '((emacs     "26.1")
    (websocket "1.12"))
  :url "https://github.com/ninetyfive.gg/ninetyfive.el"
  :commit "0211bbd61f90f4e5e7cd91af5b593b587d0c9fc2"
  :revdesc "0211bbd61f90"
  :keywords '("completion"))
