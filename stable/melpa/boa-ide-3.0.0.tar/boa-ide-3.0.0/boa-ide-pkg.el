;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boa-ide" "3.0.0"
  "Mode for boa language files."
  '((boa-sc-data "2.0.0")
    (boa-mode    "1.4.4"))
  :url "https://github.com/boalang/syntax-highlight"
  :commit "315bdfd564c21a9da12821bfb4a9f36c86ec2de8"
  :revdesc "315bdfd564c2"
  :keywords '("boa" "msr" "language")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
