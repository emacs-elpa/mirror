;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sproto-mode" "0.1"
  "Major mode for editing sproto."
  ()
  :url "https://github.com/m2q1n9/sproto-mode"
  :commit "06ee714b02312b4041e09bff7496b4ac85aa102e"
  :revdesc "06ee714b0231"
  :keywords '("sproto"))
