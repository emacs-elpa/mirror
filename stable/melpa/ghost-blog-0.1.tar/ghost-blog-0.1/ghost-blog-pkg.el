;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghost-blog" "0.1"
  "A package to manage Ghost blog."
  '((markdown-mode "1.0"))
  :url "https://github.com/javaguirre/ghost-blog"
  :commit "d57933533a24d41363fcff830ad2916e0dfcb5a3"
  :revdesc "d57933533a24"
  :keywords '("ghost" "blog")
  :authors '(("Javier Aguirre" . "hello@javaguirre.net"))
  :maintainers '(("Javier Aguirre" . "hello@javaguirre.net")))
