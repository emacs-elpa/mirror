;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weather-scout" "0.0.1"
  "Description."
  '((emacs   "27.1")
    (persist "0.6.1"))
  :url "https://github.com/hsolg/emacs-weather-scout"
  :commit "26da0be3ae1c6eb5a48b8d31cb673056edca7452"
  :revdesc "26da0be3ae1c"
  :authors '(("Henrik Solgaard" . "henrik.solgaard@gmail.com"))
  :maintainers '(("Henrik Solgaard" . "henrik.solgaard@gmail.com")))
