;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dircmp" "1"
  "Compare and sync directories."
  ()
  :url "https://github.com/matthewlmcclure/dircmp-mode"
  :commit "391d1a5bdda2f3ae01448548befe4e490ca579e6"
  :revdesc "391d1a5bdda2"
  :keywords '("unix" "tools"))
