;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mode-line-idle" "0.4"
  "Evaluate mode line content when idle."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-mode-line-idle"
  :commit "f1224688be854183ebe939876f6ac8372d3e9679"
  :revdesc "f1224688be85"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
