;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forecast" "0.8"
  "Weather forecasts."
  '((emacs "24.4"))
  :url "https://dev.gkayaalp.com/elisp/index.html#forecast-el"
  :commit "ebb2778052aeaf737adebc003957cb48cb01135e"
  :revdesc "ebb2778052ae"
  :keywords '("weather" "forecast")
  :authors '(("Göktuğ Kayaalp" . "self@gkayaalp.com"))
  :maintainers '(("Göktuğ Kayaalp" . "self@gkayaalp.com")))
