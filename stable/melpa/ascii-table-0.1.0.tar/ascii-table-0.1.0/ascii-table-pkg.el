;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ascii-table" "0.1.0"
  "Interactive ASCII table."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/lassik/emacs-ascii-table"
  :commit "59087709fb94ebcea68ca9e8d9c199c6642bf1cc"
  :revdesc "59087709fb94"
  :keywords '("help" "tools")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
