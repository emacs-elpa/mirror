;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timer-revert" "0.1"
  "Minor mode to revert buffer for a given time interval."
  ()
  :url "https://github.com/yyr/timer-revert"
  :commit "31ad8d94b85807cd9f63fcba0c90c3e9a9515fa2"
  :revdesc "31ad8d94b858"
  :keywords '("timer" "revert" "auto-revert.")
  :maintainers '((nil . "hi@yagnesh.org")))
