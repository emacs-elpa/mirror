;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-sidebar" "0.4"
  "Helpful sidebar for Org buffers."
  '((emacs            "26.1")
    (s                "1.10.0")
    (dash             "2.18")
    (org              "9.0")
    (org-ql           "0.2")
    (org-super-agenda "1.0"))
  :url "https://github.com/alphapapa/org-sidebar"
  :commit "324987d71b0f2842ac7cae74e534b490603cce67"
  :revdesc "v0.4-0-g324987d71b0f"
  :keywords '("hypermedia" "outlines" "org" "agenda")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
