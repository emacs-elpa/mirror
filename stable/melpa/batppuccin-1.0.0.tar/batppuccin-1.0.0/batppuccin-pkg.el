;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "batppuccin" "1.0.0"
  "Shared infrastructure for Batppuccin themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/batppuccin-emacs"
  :commit "cc5241879121b30f395327659a3224a91b104a9a"
  :revdesc "cc5241879121"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
