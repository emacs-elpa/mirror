;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mandoku" "0.3"
  "A tool to access repositories of premodern Chinese texts."
  '((org "8"))
  :url "http://www.mandoku.org"
  :commit "ba93999a7ff2b5ca2bbe1ff6d93a482774676cb2"
  :revdesc "ba93999a7ff2"
  :keywords '("convenience")
  :authors '(("Christian Wittern" . "cwittern@gmail.com"))
  :maintainers '(("Christian Wittern" . "cwittern@gmail.com")))
