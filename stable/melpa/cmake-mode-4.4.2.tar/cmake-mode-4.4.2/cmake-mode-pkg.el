;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-mode" "4.4.2"
  "Major-mode for editing CMake sources."
  '((emacs "24.1"))
  :commit "c162d6852d09a82cf87ff0cda6a23abc775dfdb6"
  :revdesc "v4.4.2-0-gc162d6852d09")
