;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "add-hooks" "3.1.1"
  "Functions for setting multiple hooks."
  ()
  :url "https://github.com/nickmccurdy/add-hooks"
  :commit "a1043b7cdb1ea98055a2c99f8d37584a553ca362"
  :revdesc "a1043b7cdb1e"
  :keywords '("lisp")
  :authors '(("Nick McCurdy" . "nick@nickmccurdy.com"))
  :maintainers '(("Nick McCurdy" . "nick@nickmccurdy.com")))
