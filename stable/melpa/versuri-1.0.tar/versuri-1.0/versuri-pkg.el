;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "versuri" "1.0"
  "[No description available]."
  '((emacs    "26.1")
    (request  "0.3.0")
    (anaphora "1.0.4")
    (elquery  "0.1.0")
    (s        "1.12.0")
    (ivy      "0.11.0"))
  :url "https://github.com/mihaiolteanu/versuri/"
  :commit "048d59d2ef13983cbdd24ba7e7e1c9ae47ba8581"
  :revdesc "048d59d2ef13"
  :keywords '("music")
  :authors '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainers '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm")))
