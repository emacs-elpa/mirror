;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.9.1"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.66.1")
    (latex-to-svg-backend "0.8.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "f8c1cea05448701884ea125c877f0337bba0214e"
  :revdesc "v0.9.1-0-gf8c1cea05448"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
