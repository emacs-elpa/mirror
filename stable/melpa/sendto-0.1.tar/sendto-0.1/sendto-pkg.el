;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sendto" "0.1"
  "Send the region content to a function."
  '((org   "8.0")
    (emacs "24.4"))
  :url "https://github.com/lujun9972/sendto.el"
  :commit "daf782517f6770c6bf130970eab39975462b57ac"
  :revdesc "daf782517f67"
  :keywords '("convenience" "region")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
