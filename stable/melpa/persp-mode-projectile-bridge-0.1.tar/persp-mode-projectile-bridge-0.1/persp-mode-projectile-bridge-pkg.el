;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persp-mode-projectile-bridge" "0.1"
  "Persp-mode + projectile integration."
  '((persp-mode "0")
    (projectile "0"))
  :url "https://github.com/Bad-ptr/persp-mode-projectile-bridge.el"
  :commit "be59cd6ae69ee55b344c05f1b3c8d3a0363439cb"
  :revdesc "be59cd6ae69e"
  :keywords '("persp-mode" "projectile")
  :authors '(("Constantin Kulikov" . "zxnotdead@gmail.com"))
  :maintainers '(("Constantin Kulikov" . "zxnotdead@gmail.com")))
