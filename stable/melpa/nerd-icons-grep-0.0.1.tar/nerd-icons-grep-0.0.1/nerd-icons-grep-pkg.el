;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons-grep" "0.0.1"
  "Add nerd-icons to grep-mode."
  '((emacs "30.1"))
  :url "https://github.com/hron/nerd-icons-grep-mode"
  :commit "6a3782324b0aac28afe226bbc82cff6c09fbe836"
  :revdesc "6a3782324b0a"
  :keywords '("tools" "grep" "nerd-icons")
  :authors '(("Aleksei Gusev" . "aleksei.gusev@gmail.com"))
  :maintainers '(("Aleksei Gusev" . "aleksei.gusev@gmail.com")))
