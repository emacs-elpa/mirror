;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-itunes" "0.0.1"
  "[No description available]."
  ()
  :url "https://github.com/daschwa/helm-itunes"
  :commit "9342ee9f03ebe86d3275c5635dbb15f00a39a282"
  :revdesc "9342ee9f03eb"
  :authors '(("Adam Schwartz" . "adam@adamschwartz.io"))
  :maintainers '(("Adam Schwartz" . "adam@adamschwartz.io")))
