;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "historian" "20170111"
  "Persistently store selected minibuffer candidates."
  '((emacs "24.4"))
  :url "https://github.com/PythonNut/historian.el"
  :commit "ad00b4a6bd296f42cb03664055caa07c21ad0883"
  :revdesc "ad00b4a6bd29"
  :keywords '("convenience" "helm" "ivy")
  :authors '(("PythonNut" . "pythonnut@pythonnut.com"))
  :maintainers '(("PythonNut" . "pythonnut@pythonnut.com")))
