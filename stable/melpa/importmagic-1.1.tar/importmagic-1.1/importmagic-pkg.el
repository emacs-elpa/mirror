;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "importmagic" "1.1"
  "Fix Python imports using importmagic."
  '((f     "0.11.0")
    (epc   "0.1.0")
    (emacs "24.3"))
  :url "https://github.com/anachronic/importmagic.el"
  :commit "c0360a8146ca65565a7fa66c6d72986edd916dd5"
  :revdesc "v1.1-0-gc0360a8146ca"
  :keywords '("languages" "convenience")
  :authors '(("Nicolás Salas V." . "nikosalas@gmail.com"))
  :maintainers '(("Nicolás Salas V." . "nikosalas@gmail.com")))
