;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ssh-agency" "0.4.1"
  "Manage ssh-agent from Emacs."
  '((emacs "24.4")
    (dash  "2.10.0"))
  :url "https://github.com/magit/ssh-agency"
  :commit "a5377e4317365a3d5442e06d5c255d4a7c7618db"
  :revdesc "0.4.1-0-ga5377e431736"
  :authors '(("Noam Postavsky" . "npostavs@user.sourceforge.net"))
  :maintainers '(("Noam Postavsky" . "npostavs@user.sourceforge.net")))
