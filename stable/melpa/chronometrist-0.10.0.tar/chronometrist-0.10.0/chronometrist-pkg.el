;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chronometrist" "0.10.0"
  "Friendly and powerful personal time tracker and analyzer."
  '((emacs "27.1")
    (dash  "2.16.0")
    (seq   "2.20")
    (ts    "0.2"))
  :url "https://tildegit.org/contrapunctus/chronometrist"
  :commit "2c1274147475b552716de7cecd7a9fd46e578e46"
  :revdesc "2c1274147475"
  :keywords '("calendar")
  :authors '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainers '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de")))
