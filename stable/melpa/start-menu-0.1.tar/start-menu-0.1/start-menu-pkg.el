;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "start-menu" "0.1"
  "Start-menu for executing external program like the start menu in windows."
  '((cl-lib "0.5"))
  :url "https://github.com/lujun9972/el-start-menu"
  :commit "317b5d62f97cd05e2e293e876d9461df5e0ced08"
  :revdesc "317b5d62f97c"
  :keywords '("convenience" "menu")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
