;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "r-autoyas" "0.28"
  "Provides automatically created yasnippets for R function argument lists."
  ()
  :url "https://github.com/mlf176f2/r-autoyas.el"
  :commit "563254f01ce530ca4c9be1f23395e3fd7d520ff9"
  :revdesc "v0.28-0-g563254f01ce5"
  :keywords '("r" "yasnippet"))
