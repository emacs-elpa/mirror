;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "0.1.0"
  "An MCP server for Emacs."
  '((emacs       "30.1")
    (http-server "0.1.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "8c315e5388319bd2a3718c73e35d5f400f24cf68"
  :revdesc "8c315e538831"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
