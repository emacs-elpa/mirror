;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-butt-mode" "2.0.4"
  "Slim Lisp Butts."
  '((emacs "25"))
  :url "https://gitlab.com/marcowahl/lisp-butt-mode"
  :commit "2b719baf0ccba79e28fcb3c2633c4849d976ac23"
  :revdesc "2.0.4-0-g2b719baf0ccb"
  :keywords '("lisp")
  :authors '(("Marco Wahl" . "marcowahlsoft@gmail.com"))
  :maintainers '(("Marco Wahl" . "marcowahlsoft@gmail.com")))
