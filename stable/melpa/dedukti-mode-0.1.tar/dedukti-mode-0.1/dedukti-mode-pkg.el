;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dedukti-mode" "0.1"
  "Basics syntax highlighting for Dedukti files in GNU Emacs."
  ()
  :url "https://github.com/rafoo/dedukti-mode"
  :commit "237dc40a3902cd859ae200ed6712b0dddd137d67"
  :revdesc "237dc40a3902")
