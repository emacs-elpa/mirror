;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "info-buffer" "0.2"
  "Display info topics in separate buffers."
  ()
  :url "http://www.github.com/llvilanova/info-buffer"
  :commit "d35dad6e766c6e2ddb8dc6acb4ce5b6e10fbcaa7"
  :revdesc "d35dad6e766c"
  :keywords '("docs" "info")
  :authors '(("Lluís Vilanova" . "vilanova@ac.upc.edu"))
  :maintainers '(("Lluís Vilanova" . "vilanova@ac.upc.edu")))
