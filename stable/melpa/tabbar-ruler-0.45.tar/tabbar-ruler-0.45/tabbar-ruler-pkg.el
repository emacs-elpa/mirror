;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabbar-ruler" "0.45"
  "Pretty tabbar, autohide, use both tabbar/ruler."
  '((tabbar "2.0.1"))
  :url "https://github.com/mlf176f2/tabbar-ruler.el"
  :commit "7df2e4814018e84ef9261d04a2ade8168a44e3d7"
  :revdesc "7df2e4814018"
  :keywords '("tabbar" "ruler mode" "menu" "tool bar."))
