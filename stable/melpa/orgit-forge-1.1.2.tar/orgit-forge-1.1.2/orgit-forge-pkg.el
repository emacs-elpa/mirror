;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit-forge" "1.1.2"
  "Org links to Forge issue buffers."
  '((emacs    "29.1")
    (compat   "30.1")
    (cond-let "0.2")
    (forge    "0.6")
    (magit    "4.5")
    (org      "9.8")
    (orgit    "2.1"))
  :url "https://github.com/magit/orgit-forge"
  :commit "8e4496d7f7f84fab3e36d10883386c02f43a67e7"
  :revdesc "v1.1.2-0-g8e4496d7f7f8"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev")))
