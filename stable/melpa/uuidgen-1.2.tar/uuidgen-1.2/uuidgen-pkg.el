;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uuidgen" "1.2"
  "Provides various UUID generating functions."
  ()
  :url "https://github.com/kanru/uuidgen-el"
  :commit "7b728c1d92e196c3acf87a004949335cfc18eab3"
  :revdesc "v1.2-0-g7b728c1d92e1"
  :keywords '("extensions" "lisp" "tools")
  :authors '(("Kan-Ru Chen" . "kanru@kanru.info"))
  :maintainers '(("Kan-Ru Chen" . "kanru@kanru.info")))
