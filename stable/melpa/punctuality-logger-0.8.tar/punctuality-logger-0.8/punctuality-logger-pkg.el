;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "punctuality-logger" "0.8"
  "Punctuality logger for Emacs."
  ()
  :url "https://gitlab.com/elzair/punctuality-logger"
  :commit "708cae8e67dbae293c7c4be0ca5e49d76fac6714"
  :revdesc "708cae8e67db"
  :keywords '("reminder" "calendar")
  :authors '(("Philip Woods" . "elzairthesorcerer@gmail.com"))
  :maintainers '(("Philip Woods" . "elzairthesorcerer@gmail.com")))
