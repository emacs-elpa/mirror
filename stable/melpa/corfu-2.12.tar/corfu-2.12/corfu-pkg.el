;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.12"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "f6306d8c5ba540e75c208c8069b3b677de48a183"
  :revdesc "2.12-0-gf6306d8c5ba5"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
