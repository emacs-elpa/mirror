;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-lib-babel" "1.0"
  "Helm insertion of babel function references."
  '((cl-lib "0.5")
    (org    "8")
    (emacs  "24.3"))
  :url "https://github.com/dfeich/helm-lib-babel.el"
  :commit "8208c1bc9f25c598f3a296744a2a3de58884e0ff"
  :revdesc "8208c1bc9f25"
  :keywords '("convenience")
  :authors '(("Derek Feichtinger" . "dfeich@gmail.com"))
  :maintainers '(("Derek Feichtinger" . "dfeich@gmail.com")))
