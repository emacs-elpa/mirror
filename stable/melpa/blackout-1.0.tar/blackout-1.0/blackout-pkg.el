;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blackout" "1.0"
  "Better mode lighter overriding."
  '((emacs "26"))
  :url "https://github.com/raxod502/blackout"
  :commit "87822abd1ed46411368ef91752a7f51c0ef2aee0"
  :revdesc "87822abd1ed4"
  :keywords '("extensions")
  :authors '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainers '(("Radon Rosborough" . "radon.neon@gmail.com")))
