;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fold-this" "0.3.0"
  "Just fold this region please."
  ()
  :url "https://github.com/magnars/fold-this.el"
  :commit "90b41d7b588ab1c3295bf69f7dd87bf31b543a6a"
  :revdesc "0.3.0-0-g90b41d7b588a"
  :keywords '("convenience")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
