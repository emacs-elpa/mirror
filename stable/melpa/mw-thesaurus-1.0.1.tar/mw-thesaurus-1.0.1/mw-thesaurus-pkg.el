;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mw-thesaurus" "1.0.1"
  "Merriam-Webster Thesaurus."
  '((emacs   "25")
    (request "0.3.0")
    (dash    "2.16.0"))
  :url "https://github.com/agzam/mw-thesaurus.el"
  :commit "96f02694bc28f31c2a280a05d47e6ff589f525f3"
  :revdesc "96f02694bc28"
  :keywords '("wp" "matching"))
