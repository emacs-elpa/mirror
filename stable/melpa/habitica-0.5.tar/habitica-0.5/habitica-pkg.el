;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "habitica" "0.5"
  "Interface for habitica.com."
  ()
  :url "https://github.com/abrochard/emacs-habitica"
  :commit "30d53bc81d816c7255a549913e7fb2083fdcb6e8"
  :revdesc "30d53bc81d81"
  :keywords '("habitica" "todo"))
