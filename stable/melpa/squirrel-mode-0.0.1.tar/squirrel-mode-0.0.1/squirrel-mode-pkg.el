;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "squirrel-mode" "0.0.1"
  "A major mode for the Squirrel programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/squirrel-mode"
  :commit "9d3b339bcfbef87f8c6a9c8e733433f2c12ec008"
  :revdesc "9d3b339bcfbe"
  :keywords '("files" "squirrel"))
