;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-modeline" "0.1"
  "Show the git status of the current file in the modeline."
  '((emacs "26.1"))
  :url "https://github.com/djangoliv/git-modeline"
  :commit "7dbf6735ea4598595fe3ffb93441fee29fd4ea2a"
  :revdesc "0.1-0-g7dbf6735ea45"
  :keywords '("vc" "tools" "convenience")
  :authors '(("djangoliv" . "olivier.giorgis@quantstack.net"))
  :maintainers '(("djangoliv" . "olivier.giorgis@quantstack.net")))
