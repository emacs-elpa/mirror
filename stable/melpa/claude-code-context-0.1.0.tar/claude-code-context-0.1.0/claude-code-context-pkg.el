;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claude-code-context" "0.1.0"
  "Share Emacs context with Claude Code."
  '((emacs "27.1"))
  :url "https://github.com/lhoersten/claude-code-context"
  :commit "55d2fc1b3fe8e03fd6f5941017494534b374782a"
  :revdesc "55d2fc1b3fe8"
  :keywords '("tools" "ai" "convenience")
  :authors '(("Luke Hoersten" . "Luke@Hoersten.org"))
  :maintainers '(("Luke Hoersten" . "Luke@Hoersten.org")))
