;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-intellij" "0.1"
  "Intellij lsp client."
  '((emacs    "25.1")
    (lsp-mode "4.1"))
  :url "https://github.com/Ruin0x11/lsp-intellij"
  :commit "20fb9f58dcbfdaab55a8fe89ba7fa0c64e72192e"
  :revdesc "20fb9f58dcbf"
  :keywords '("java" "kotlin")
  :authors '(("Ruin0x11" . "ipickering2@gmail.com"))
  :maintainers '(("Ruin0x11" . "ipickering2@gmail.com")))
