;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.52.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "20cf11e7b6f44342b20c3f0b7838f7c9f357ee62"
  :revdesc "20cf11e7b6f4"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
