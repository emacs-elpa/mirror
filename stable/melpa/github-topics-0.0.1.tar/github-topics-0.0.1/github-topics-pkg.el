;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-topics" "0.0.1"
  "Lookup PRs matching a query."
  '((emacs "29.4")
    (ts    "0.3"))
  :url "https://github.com/agzam/github-topics"
  :commit "3d44a9449d4d568f9d325020a4e7c1228ee47b08"
  :revdesc "3d44a9449d4d"
  :keywords '("vc" "matching" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
