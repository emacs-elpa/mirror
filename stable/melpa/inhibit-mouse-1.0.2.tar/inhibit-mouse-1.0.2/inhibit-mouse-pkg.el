;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inhibit-mouse" "1.0.2"
  "Deactivate mouse input (alternative to disable-mouse)."
  '((emacs "24.1"))
  :url "https://github.com/jamescherti/inhibit-mouse.el"
  :commit "89e009898dca46e07fed5fb313eb7bcdeb9d9714"
  :revdesc "1.0.2-0-g89e009898dca"
  :keywords '("convenience"))
