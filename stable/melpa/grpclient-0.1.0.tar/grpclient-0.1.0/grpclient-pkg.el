;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grpclient" "0.1.0"
  "Grpcurl interactive builder."
  ()
  :url "https://github.com/Prikaz98/grpclient.el"
  :commit "d42f2459ec4d7996ecf6024aa3e53bd97aa218de"
  :revdesc "d42f2459ec4d"
  :keywords '("grpc" "grpcurl" "tools")
  :authors '(("Ivan Prikaznov" . "prikaznov555@gmail.com"))
  :maintainers '(("Ivan Prikaznov" . "prikaznov555@gmail.com")))
