;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-grep" "1.2.3"
  "Interactively-editable recursive grep implementation in elisp."
  '((cl-lib "0.1")
    (emacs  "24.4"))
  :url "https://github.com/zk-phi/phi-grep"
  :commit "a87104861b4115a41755bd3794f655690a8973f9"
  :revdesc "a87104861b41")
