;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cangjie" "0.7.4"
  "Retrieve cangjie code for han characters."
  '((emacs "24.4")
    (s     "1.12.0")
    (dash  "2.14.1")
    (f     "0.2.0"))
  :url "https://github.com/kisaragi-hiu/cangjie.el"
  :commit "b34a28dd06bd95a16b655f1917227925975314bc"
  :revdesc "b34a28dd06bd"
  :keywords '("convenience" "writing")
  :authors '(("Kisaragi Hiu" . "mail@kisaragi-hiu.com"))
  :maintainers '(("Kisaragi Hiu" . "mail@kisaragi-hiu.com")))
