;;; avk-emacs-themes.el --- various themes by Alex V. Koval

;; Copyright (C) 2015 Alex V. Koval

;; Author: Alex V. Koval <alex@koval.kharkov.ua>
;; Maintainer: Alex V. Koval <alex@koval.kharkov.ua>
;; Homepage: https://github.com/avkoval/avk-emacs-themes
;; Created: 14th June 2015
;; Package-Version: 0.2
;; Package-Revision: d8c91d67c78d
;; Keywords: theme

;;; Commentary:
;;
;; Various themes by Alex V. Koval.

;; Code:

(provide 'avk-emacs-themes)

;;; avk-emacs-themes.el ends here
