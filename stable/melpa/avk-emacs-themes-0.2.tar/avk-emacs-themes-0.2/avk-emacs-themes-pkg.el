;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avk-emacs-themes" "0.2"
  "Various themes by Alex V. Koval."
  ()
  :url "https://github.com/avkoval/avk-emacs-themes"
  :commit "d8c91d67c78d90d04f2cda01ded019c6931250d6"
  :revdesc "d8c91d67c78d"
  :keywords '("theme")
  :authors '(("Alex V. Koval" . "alex@koval.kharkov.ua"))
  :maintainers '(("Alex V. Koval" . "alex@koval.kharkov.ua")))
