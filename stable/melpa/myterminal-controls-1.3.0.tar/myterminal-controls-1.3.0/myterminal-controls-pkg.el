;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "myterminal-controls" "1.3.0"
  "Quick toggle controls at a key-stroke."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "http://ismail.teamfluxion.com"
  :commit "df144b269bc274162602e50c692be20ac9b90547"
  :revdesc "df144b269bc2"
  :keywords '("convenience" "shortcuts")
  :authors '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com"))
  :maintainers '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com")))
