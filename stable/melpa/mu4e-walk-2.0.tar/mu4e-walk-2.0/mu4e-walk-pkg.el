;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-walk" "2.0"
  "Send email addresses for a walk."
  '((emacs "29.1"))
  :url "https://codeberg.org/timmli/mu4e-walk"
  :commit "9fb9efd3b99a06ac75535a1cd6630515f1a632ca"
  :revdesc "9fb9efd3b99a"
  :keywords '("convenience" "mail")
  :authors '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de"))
  :maintainers '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de")))
