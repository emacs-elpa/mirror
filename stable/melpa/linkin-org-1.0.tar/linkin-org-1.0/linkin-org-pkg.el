;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linkin-org" "1.0"
  "[No description available]."
  ()
  :url "https://github.com/Judafa/linkin-org"
  :commit "506aea0cf65f1801858c43c3f6323dcd4be17ba3"
  :revdesc "506aea0cf65f"
  :authors '(("Julien Dallot" . "judafa@protonmail.com"))
  :maintainers '(("Julien Dallot" . "judafa@protonmail.com")))
