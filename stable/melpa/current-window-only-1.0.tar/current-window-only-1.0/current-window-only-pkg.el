;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "current-window-only" "1.0"
  "Open things only in the current window."
  '((emacs "25.1"))
  :url "https://github.com/FrostyX/current-window-only"
  :commit "7883c1a0cb8ea3aad465bb31f768c3fdaac0a031"
  :revdesc "7883c1a0cb8e"
  :keywords '("frames")
  :authors '(("Jakub Kadlčík" . "frostyx@email.cz"))
  :maintainers '(("Jakub Kadlčík" . "frostyx@email.cz")))
