;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wwg" "0.1.1"
  "Writer word goals."
  '((emacs "25.1"))
  :url "https://github.com/ag91/writer-word-goals"
  :commit "77435ca396e7cc2685f4962e959070dbe1f70db1"
  :revdesc "77435ca396e7"
  :keywords '("wp")
  :authors '((nil . "Andreaandrea-dev@hotmail.com"))
  :maintainers '((nil . "Andreaandrea-dev@hotmail.com")))
