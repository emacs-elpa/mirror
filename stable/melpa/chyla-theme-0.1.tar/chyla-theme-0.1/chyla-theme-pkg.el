;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chyla-theme" "0.1"
  "The chyla.org color theme for Emacs."
  ()
  :url "https://github.com/chyla/ChylaThemeForEmacs"
  :commit "5ff7f6ccee41454681c9541da4d0a5d8eed1dd89"
  :revdesc "5ff7f6ccee41"
  :authors '(("Adam Chyła https://chyla.org/" . "adam@chyla.org"))
  :maintainers '(("Adam Chyła https://chyla.org/" . "adam@chyla.org")))
