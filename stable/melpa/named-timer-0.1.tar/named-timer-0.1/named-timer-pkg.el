;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "named-timer" "0.1"
  "Named timers for Emacs Lisp."
  ()
  :url "https://github.com/DarwinAwardWinner/emacs-named-timer"
  :commit "a71655b6af179fb2ae40bfadf81cb9f0e0298e2d"
  :revdesc "a71655b6af17")
