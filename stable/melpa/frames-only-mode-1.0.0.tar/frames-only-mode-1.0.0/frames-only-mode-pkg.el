;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frames-only-mode" "1.0.0"
  "Use frames instead of Emacs windows."
  '((emacs "24.4")
    (seq   "2.3"))
  :url "https://github.com/davidshepherd7/frames-only-mode"
  :commit "5a2947d797a5d6f74d3a9c97f8c0ab6cff115b28"
  :revdesc "5a2947d797a5"
  :keywords '("frames" "windows")
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
