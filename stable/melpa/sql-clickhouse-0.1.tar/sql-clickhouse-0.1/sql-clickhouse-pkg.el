;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sql-clickhouse" "0.1"
  "Support ClickHouse as SQL interpreter."
  '((emacs "24"))
  :url "https://github.com/leethargo/sql-clickhouse"
  :commit "de7dbb82849e685733ee0eac5a442fe29ca4d873"
  :revdesc "de7dbb82849e"
  :authors '(("Robert Schwarz" . "mail@rschwarz.net"))
  :maintainers '(("Robert Schwarz" . "mail@rschwarz.net")))
