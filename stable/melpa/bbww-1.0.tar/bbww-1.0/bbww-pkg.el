;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbww" "1.0"
  "Improved word-jumping functions."
  '((mwim  "1.0")
    (emacs "24.3"))
  :url "http://chud.wtf"
  :commit "79b252d0cb84c867765f3632fd98ff22190d3e02"
  :revdesc "79b252d0cb84"
  :keywords '("convenience" "files"))
