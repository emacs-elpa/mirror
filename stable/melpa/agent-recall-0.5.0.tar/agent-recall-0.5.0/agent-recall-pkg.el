;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "0.5.0"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "b6e4adcabacf4a17d9b7da5afa876a641ba6b518"
  :revdesc "b6e4adcabacf"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
