;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-mairix" "0.1"
  "Counsel interface for Mairix."
  '((emacs   "26.1")
    (counsel "0.13.1"))
  :url "https://git.sr.ht/~ane/counsel-mairix"
  :commit "7afd70693e54be81b8c9d9e37b21589aa455fccd"
  :revdesc "7afd70693e54"
  :keywords '("mail" "searching")
  :authors '(("Antoine Kalmbach" . "ane@iki.fi"))
  :maintainers '(("Antoine Kalmbach" . "ane@iki.fi")))
