;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dtk" "0.2"
  "Access SWORD content via diatheke."
  ()
  :url "https://github.com/dtk01/dtk.el"
  :commit "a4fa28f903e47f2194ee6b1db57c05b749558397"
  :revdesc "a4fa28f903e4"
  :keywords '("hypermedia"))
