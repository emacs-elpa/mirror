;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "just-ts-mode" "0.1.9"
  "Justfile editing mode."
  '((emacs "29.1"))
  :url "https://github.com/leon-barrett/just-ts-mode.el"
  :commit "9dd136bc809de85fa66a4665312eb0f55b1c8094"
  :revdesc "9dd136bc809d"
  :keywords '("files" "languages" "tools" "treesitter")
  :authors '(("Leon Barrett" . "(leon@barrettnexus.com)"))
  :maintainers '(("Leon Barrett" . "(leon@barrettnexus.com)")))
