;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frimacs" "1.0"
  "An environment for the FriCAS computer algebra system."
  '((emacs "26.1"))
  :url "https://github.com/pdo/frimacs"
  :commit "fc23ccc6b431bc6b6f6ab91fb6291bca38962d67"
  :revdesc "fc23ccc6b431"
  :keywords '("fricas" "computer algebra" "extensions" "tools")
  :authors '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainers '(("Paul Onions" . "paul.onions@acm.org")))
