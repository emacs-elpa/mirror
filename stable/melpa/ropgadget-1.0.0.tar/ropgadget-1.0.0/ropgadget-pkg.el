;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ropgadget" "1.0.0"
  "Display and filter ROP gadgets of a binary."
  '((emacs     "24.4")
    (transient "0.3.6"))
  :url "https://github.com/Dragoncraft89/ropgadget-el"
  :commit "9d82152f9ae5a10d63c62eb7e0f1665631dc76b1"
  :revdesc "9d82152f9ae5"
  :keywords '("tools" "ctf" "pwn" "rop"))
