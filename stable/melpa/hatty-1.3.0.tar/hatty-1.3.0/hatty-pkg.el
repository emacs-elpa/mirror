;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hatty" "1.3.0"
  "Query positions through hats."
  '((emacs "29.1"))
  :url "https://github.com/ErikPrantare/hatty.el"
  :commit "20e6a92abd997c655e263cd32d7b5b0550dea409"
  :revdesc "20e6a92abd99"
  :keywords '("convenience"))
