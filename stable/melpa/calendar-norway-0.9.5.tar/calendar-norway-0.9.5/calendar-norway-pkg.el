;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calendar-norway" "0.9.5"
  "Norwegian calendar."
  ()
  :url "https://github.com/unhammer/calendar-norway.el"
  :commit "4dd8c38ef30ad45931c8ae7bcdfd720c3fcffffc"
  :revdesc "0.9.5-0-g4dd8c38ef30a"
  :keywords '("calendar" "norwegian" "localization")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
