;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpunit" "0.17.1"
  "Launch PHP unit tests using phpunit."
  '((s        "1.12.0")
    (f        "0.19.0")
    (pkg-info "0.6")
    (cl-lib   "0.5")
    (emacs    "24.3"))
  :url "https://github.com/nlamirault/phpunit.el"
  :commit "4212307bbcfd8accd2abfa7e4ab55a6751a0b11b"
  :revdesc "4212307bbcfd"
  :keywords '("tools" "php" "tests" "phpunit")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
             ("Eric Hansen" . "hansen.c.eric@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
                 ("Eric Hansen" . "hansen.c.eric@gmail.com")))
