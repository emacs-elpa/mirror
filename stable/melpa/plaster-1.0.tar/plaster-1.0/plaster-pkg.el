;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plaster" "1.0"
  "Pasting to a plaster host with Emacs buffers."
  '((emacs "24"))
  :url "https://github.com/shirakumo/plaster/"
  :commit "fc934aac85413b80c3f67ccf92da54ee5f9a7cbe"
  :revdesc "fc934aac8541"
  :keywords '("convenience" "usability")
  :authors '(("Nicolas Hafner" . "shinmera@tymoon.eu"))
  :maintainers '(("Nicolas Hafner" . "shinmera@tymoon.eu")))
