;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "girly-notebook-theme" "1.2.1"
  "A light theme with vivid colours and cursive text."
  '((emacs "26.1"))
  :url "https://github.com/melissaboiko/girly-notebook-theme"
  :commit "e27603d5afb2b60714b8acef61f3477d11c34e00"
  :revdesc "1.2.1-0-ge27603d5afb2"
  :authors '(("elilla&" . "elilla@transmom.love"))
  :maintainers '(("elilla&" . "elilla@transmom.love")))
