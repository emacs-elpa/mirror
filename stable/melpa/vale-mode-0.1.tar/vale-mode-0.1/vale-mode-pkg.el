;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vale-mode" "0.1"
  "[No description available]."
  ()
  :url "https://github.com/jaybosamiya/vale-mode.el"
  :commit "a07d0963ab805af26490ad47408a0a8b12f5f8bf"
  :revdesc "a07d0963ab80"
  :keywords '("convenience" "languages")
  :authors '(("Jay Bosamiya" . "jaybosamiya@gmail.com"))
  :maintainers '(("Jay Bosamiya" . "jaybosamiya@gmail.com")))
