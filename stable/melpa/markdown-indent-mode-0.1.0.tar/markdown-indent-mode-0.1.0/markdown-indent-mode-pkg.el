;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-indent-mode" "0.1.0"
  "Dynamic indentation for Markdown."
  '((emacs "28.1"))
  :url "https://github.com/whhone/markdown-indent-mode"
  :commit "19bf4086f4fbde82819984a7af01bfb5b95e91b1"
  :revdesc "19bf4086f4fb"
  :authors '(("Wai Hon Law" . "whhone@gmail.com"))
  :maintainers '(("Wai Hon Law" . "whhone@gmail.com")))
