;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-blame" "0.1.0"
  "Show blame messages with sideline."
  '((emacs    "27.1")
    (sideline "0.1.0")
    (vc-msg   "1.1.1"))
  :url "https://github.com/emacs-sideline/sideline-blame"
  :commit "c3721eeb01cea8acc520c60b9c0a802c39114c6e"
  :revdesc "c3721eeb01ce"
  :keywords '("sideline" "blame")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
