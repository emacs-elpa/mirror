;;; sideline-blame.el --- Show blame messages with sideline  -*- lexical-binding: t; -*-

;; Copyright (C) 2022  Shen, Jen-Chieh

;; Author: Shen, Jen-Chieh <jcs090218@gmail.com>
;; Maintainer: Shen, Jen-Chieh <jcs090218@gmail.com>
;; URL: https://github.com/emacs-sideline/sideline-blame
;; Package-Version: 0.1.0
;; Package-Revision: c3721eeb01ce
;; Package-Requires: ((emacs "27.1") (sideline "0.1.0") (vc-msg "1.1.1"))
;; Keywords: sideline blame

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Show blame messages with sideline.
;;

;;; Code:

(require 'sideline)
(require 'vc-msg)

(defgroup sideline-blame nil
  "Show blame messages with sideline."
  :prefix "sideline-blame-"
  :group 'tool
  :link '(url-link :tag "Repository" "https://github.com/emacs-sideline/sideline-blame"))

(defcustom sideline-blame-author-format "%s, "
  "Format string for author name."
  :type 'string
  :group 'sideline-blame)

(defcustom sideline-blame-datetime-format "%b %d %Y %H:%M:%S "
  "Format string for datetime."
  :type 'string
  :group 'sideline-blame)

(defcustom sideline-blame-commit-format "◉ %s"
  "Format string for commit message."
  :type 'string
  :group 'sideline-blame)

(defcustom sideline-blame-uncommitted-author-name "Unknown"
  "Message for commits where you are author."
  :type 'string
  :group 'sideline-blame)

(defcustom sideline-blame-uncommitted-message "Uncommitted changes"
  "Message for uncommitted lines."
  :type 'string
  :group 'sideline-blame)

;;;###autoload
(defun sideline-blame (command)
  "Backend for sideline.

Argument COMMAND is required in sideline backend."
  (cl-case command
    (`candidates (cons :async #'sideline-blame--get-message))))

(defun sideline-blame--get-message (callback &rest _)
  "Return the message.

Execute CALLBACK to display with sideline."
  (when-let*
      ((plugin (vc-msg-find-plugin))
       (current-file (funcall vc-msg-get-current-file-function))
       (executer (plist-get plugin :execute))
       (formatter (plist-get plugin :format))
       (commit-info (and current-file
                         (funcall executer
                                  current-file
                                  (funcall vc-msg-get-line-num-function)
                                  (funcall vc-msg-get-version-function))))
       (id (plist-get commit-info :id)))
    (let* ((uncommitted (zerop (string-to-number id)))
           (author (if uncommitted sideline-blame-uncommitted-author-name
                     (plist-get commit-info :author)))
           (time (string-to-number (plist-get commit-info :author-time)))
           (summary (if uncommitted sideline-blame-uncommitted-message
                      (plist-get commit-info :summary))))
      (funcall callback
               (list (concat (format sideline-blame-author-format author)
                             (format-time-string sideline-blame-datetime-format time)
                             (format sideline-blame-commit-format summary)))))))

(provide 'sideline-blame)
;;; sideline-blame.el ends here
