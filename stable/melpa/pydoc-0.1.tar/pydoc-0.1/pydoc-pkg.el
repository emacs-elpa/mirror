;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pydoc" "0.1"
  "Functional, syntax highlighted pydoc navigation."
  ()
  :url "https://github.com/statmobile/pydoc"
  :commit "5392248e33d83ef05d3b2809b0c6b207786b2644"
  :revdesc "5392248e33d8"
  :keywords '("pydoc" "python")
  :authors '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainers '(("Brian J. Lopes" . "statmobile@gmail.com")))
