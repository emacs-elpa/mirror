;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evalator" "1.0.0"
  "Package for interactive transformation of data with helm."
  '((helm-core "1.9.1"))
  :url "http://www.github.com/seanirby/evalator"
  :commit "edf3840f5aa025cf38d0c2677b2f88f59079409e"
  :revdesc "edf3840f5aa0"
  :keywords '("languages" "elisp" "helm")
  :maintainers '(("Sean Irby" . "sean.t.irby@gmail.com")))
