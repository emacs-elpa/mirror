;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-elpa" "0.0.1"
  "Build and publish ELPA repositories with GitHub Pages."
  '((package-build "1.0")
    (commander     "0.7.0")
    (git           "0.1.1"))
  :url "https://github.com/10sr/github-elpa"
  :commit "c5960375ed5d67465412be7eb0ac558082feebc7"
  :revdesc "c5960375ed5d"
  :authors '(("10sr" . "8slashes+el@gmail.com"))
  :maintainers '(("10sr" . "8slashes+el@gmail.com")))
