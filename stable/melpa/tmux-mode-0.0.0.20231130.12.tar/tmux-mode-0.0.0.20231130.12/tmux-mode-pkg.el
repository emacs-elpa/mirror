;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tmux-mode" "0.0.0.20231130.12"
  "Major mode for tmux configuration."
  '((emacs "26.1"))
  :url "https://github.com/nverno/tmux-mode"
  :commit "ee50d02721600c4b31cdafbb9f2ecc5becf1a5f6"
  :revdesc "ee50d0272160"
  :keywords '("languages" "tmux" "config")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
