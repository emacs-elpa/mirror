;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-swift" "2.0"
  "Flycheck extension for Apple's Swift."
  '((emacs    "24.4")
    (flycheck "0.25"))
  :url "https://github.com/swift-emacs/flycheck-swift"
  :commit "822d1415eabfd464adc52063f9c44da1c87f0ff9"
  :revdesc "822d1415eabf"
  :keywords '("languages" "swift")
  :authors '(("Chris Barrett" . "chris.d.barrett@me.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.com")
             ("Arthur Evstifeev" . "lod@pisem.net"))
  :maintainers '(("Chris Barrett" . "chris.d.barrett@me.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.com")
                 ("Arthur Evstifeev" . "lod@pisem.net")))
