;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marquee-header" "0.1.0"
  "Code interface for displaying marquee in header."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/marquee-header"
  :commit "1fee5bbec486d0755954f5cafda67f342dc7daa1"
  :revdesc "1fee5bbec486"
  :keywords '("wp" "animation" "marquee")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
