;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotation" "2.9.0"
  "Functions for annotating text with faces and help bubbles."
  ()
  :url "https://github.com/agda/agda"
  :commit "da046d6903b7f587f5add669650e52f378f57834"
  :revdesc "v2.9.0-0-gda046d6903b7")
