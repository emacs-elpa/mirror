;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comware-router-mode" "0.5"
  "Major mode for editing Comware configuration files."
  '((dash  "2.16.0")
    (emacs "24.3"))
  :url "https://github.com/daviderestivo/comware-router-mode"
  :commit "4347f270dbd1132c857ee4ae49d0891eb95e80fe"
  :revdesc "4347f270dbd1"
  :keywords '("convenience" "faces")
  :authors '(("Davide Restivo" . "davide.restivo@yahoo.it"))
  :maintainers '(("Davide Restivo" . "davide.restivo@yahoo.it")))
