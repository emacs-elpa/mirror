;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brewpage" "0.1.2"
  "Publish buffers/regions to brewpage.app."
  '((emacs "27.1"))
  :url "https://github.com/kochetkov-ma/brewpage-emacs"
  :commit "abf78cb39613aa2190daa4f72ac6cb08c54b487f"
  :revdesc "0.1.2-0-gabf78cb39613"
  :keywords '("tools" "convenience")
  :authors '(("Maksim Kochetkov" . "maksim.kochetkov@finagra.com"))
  :maintainers '(("Maksim Kochetkov" . "maksim.kochetkov@finagra.com")))
