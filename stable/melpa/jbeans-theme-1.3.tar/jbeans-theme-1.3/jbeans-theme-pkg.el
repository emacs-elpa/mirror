;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jbeans-theme" "1.3"
  "Jbeans theme for GNU Emacs 24 (deftheme)."
  '((emacs "24"))
  :url "https://github.com/synic/jbeans-emacs"
  :commit "1b98a41e183f234da197d9362a036f594b69b12e"
  :revdesc "1b98a41e183f"
  :authors '(("Adam Olsen" . "arolsen@gmail.com"))
  :maintainers '(("Adam Olsen" . "arolsen@gmail.com")))
