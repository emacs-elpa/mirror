;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.91.2"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "11f4a9913e7625f122625dd89d668ad5c93cf151"
  :revdesc "11f4a9913e76")
