;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-quickhelp" "2.3.0"
  "Popup documentation for completion candidates."
  '((emacs   "24.4")
    (company "0.8.9")
    (pos-tip "0.4.6"))
  :url "https://www.github.com/expez/company-quickhelp"
  :commit "b2953c725654650677e3d66eaeec666826d5f65f"
  :revdesc "2.3.0-0-gb2953c725654"
  :keywords '("company" "popup" "documentation" "quickhelp")
  :authors '(("Lars Andersen" . "expez@expez.com"))
  :maintainers '(("Lars Andersen" . "expez@expez.com")))
