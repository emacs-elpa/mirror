;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notink-theme" "1.0"
  "A custom theme inspired by e-ink displays."
  '((emacs "24"))
  :url "https://github.com/MetroWind/notink-theme"
  :commit "691e6e79bed73f7f58a02ef73c4a6e7e11cf25b8"
  :revdesc "691e6e79bed7"
  :keywords '("lisp")
  :authors '(("MetroWind" . "chris.corsair@gmail.com"))
  :maintainers '(("MetroWind" . "chris.corsair@gmail.com")))
