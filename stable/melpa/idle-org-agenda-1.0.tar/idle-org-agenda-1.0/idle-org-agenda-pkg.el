;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idle-org-agenda" "1.0"
  "A package that shows your agenda when Emacs is idle."
  ()
  :url "https://github.com/enisozgen/idle-org-agenda"
  :commit "727316f38e75ee8bbf8aca3278ff164522360ac9"
  :revdesc "727316f38e75"
  :keywords '("org" "org-mode" "org-agenda" "calendar")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("Enis zgen" . "mail@enisozgen.com")))
