;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-ycmd" "0.0.1"
  "Ivy interface to ycmd."
  '((ycmd  "1.3")
    (emacs "24")
    (ivy   "0.10.0"))
  :url "https://github.com/abingham/emacs-ivy-ycmd"
  :commit "dae4414fecdb058f7865b0f93152590f35c95a64"
  :revdesc "dae4414fecdb"
  :keywords '("tools")
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
