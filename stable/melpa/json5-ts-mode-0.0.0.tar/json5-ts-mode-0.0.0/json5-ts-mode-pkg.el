;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "json5-ts-mode" "0.0.0"
  "Major mode for JSON5."
  '((emacs "29.1"))
  :url "https://github.com/dochang/json5-ts-mode"
  :commit "21233ff6386529be26d147d46681119918a9451a"
  :revdesc "21233ff63865"
  :keywords '("json5" "languages" "tree-sitter")
  :authors '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainers '(("ZHANG Weiyi" . "dochang@gmail.com")))
