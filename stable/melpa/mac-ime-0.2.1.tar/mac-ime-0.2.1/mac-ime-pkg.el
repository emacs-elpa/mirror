;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mac-ime" "0.2.1"
  "NSEvent hook for macOS input method."
  '((emacs "27.1"))
  :url "https://github.com/ma0001/mac-ime"
  :commit "136f9521526e3b2bf9254a992332f043ee58eba1"
  :revdesc "v0.2.1-0-g136f9521526e"
  :keywords '("i18n" "convenience"))
