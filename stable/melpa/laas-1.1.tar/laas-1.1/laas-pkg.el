;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "laas" "1.1"
  "A bundle of as-you-type LaTeX snippets."
  '((emacs     "26.3")
    (auctex    "11.88")
    (aas       "1.1")
    (yasnippet "0.14"))
  :url "https://github.com/tecosaur/LaTeX-auto-activating-snippets"
  :commit "b372f9a44bea03cce09b20cd2409e3ae3fa2d651"
  :revdesc "b372f9a44bea"
  :keywords '("tools" "tex")
  :authors '(("Yoav Marco TEC" . "https://github.com/tecosaur"))
  :maintainers '(("Yoav Marco" . "yoavm448@gmail.com")))
