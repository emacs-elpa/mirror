;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-gitlab" "0.8.0"
  "Ivy interface to Gitlab."
  '((s      "1.9.0")
    (dash   "2.9.0")
    (ivy    "0.8.0")
    (gitlab "0.8"))
  :url "https://github.com/nlamirault/emacs-gitlab"
  :commit "a1c1441ff5ffb290e695eb9ac05431e9385578f4"
  :revdesc "a1c1441ff5ff"
  :keywords '("gitlab" "ivy")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
