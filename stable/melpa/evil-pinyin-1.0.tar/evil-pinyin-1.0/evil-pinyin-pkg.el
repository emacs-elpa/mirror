;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-pinyin" "1.0"
  "Evil search Chinese characters by pinyin."
  '((emacs     "25")
    (names     "0.5")
    (evil      "1")
    (pinyinlib "0.1.1"))
  :url "https://github.com/laishulu/evil-pinyin"
  :commit "197e133d450a85c094c5d75f3ef4653ee5fe4747"
  :revdesc "197e133d450a"
  :keywords '("extensions"))
