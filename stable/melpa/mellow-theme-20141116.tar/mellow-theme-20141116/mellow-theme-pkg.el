;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mellow-theme" "20141116"
  "An Emacs 24 theme based on Mellow (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "fa4a534ae338c6b1787b9f4b0d34f9cb282ed761"
  :revdesc "fa4a534ae338")
