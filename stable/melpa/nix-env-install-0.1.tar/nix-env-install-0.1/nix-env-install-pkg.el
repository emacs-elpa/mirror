;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-env-install" "0.1"
  "Install packages using nix-env."
  '((emacs "25.1"))
  :url "https://github.com/akirak/nix-env-install"
  :commit "bd430a3cc2654d393ac9a48477bcb494b8dfc273"
  :revdesc "bd430a3cc265"
  :keywords '("processes" "tools")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
