;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-incoming" "0.1"
  "Sort incoming PDFs into your org files."
  '((emacs    "24.4")
    (dash     "2.19.1")
    (datetime "0.7.2")
    (s        "1.13.1"))
  :url "https://github.com/tinloaf/org-incoming"
  :commit "0eca164ebc45eb85962eef092f72151e8090d348"
  :revdesc "0eca164ebc45"
  :keywords '("files")
  :authors '(("Lukas Barth" . "mail@tinloaf.de"))
  :maintainers '(("Lukas Barth" . "mail@tinloaf.de")))
