;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boogie-friends" "0.1"
  "A collection of programming modes for Boogie, Dafny, and Z3 (SMTLIB v2)."
  ()
  :url "https://github.com/boogie-org/boogie-friends/"
  :commit "6d179bb98b99e24cb83ed2fc4d9801491785407f"
  :revdesc "6d179bb98b99"
  :keywords '("convenience" "languages")
  :authors '(("Clément Pit--Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit--Claudel" . "clement.pitclaudel@live.com")))
