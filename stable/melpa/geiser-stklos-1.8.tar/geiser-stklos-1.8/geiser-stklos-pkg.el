;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-stklos" "1.8"
  "STklos Scheme implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.16"))
  :url "https://gitlab.com/emacs-geiser/stklos"
  :commit "3358d0cc01436bd8f71a500175db2716e75b2eed"
  :revdesc "3358d0cc0143"
  :keywords '("languages" "stklos" "scheme" "geiser")
  :authors '(("Jeronimo Pellegrini" . "(j_p@aleph0.info)"))
  :maintainers '(("Jeronimo Pellegrini" . "(j_p@aleph0.info)")))
