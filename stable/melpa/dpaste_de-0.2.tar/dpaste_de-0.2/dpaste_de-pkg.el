;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dpaste_de" "0.2"
  "Emacs mode to paste to dpaste.de."
  '((web "0.3.7"))
  :url "https://github.com/theju/dpaste_de.el"
  :commit "ab041443884a7a4bfdc81b055688821e8efc9b02"
  :revdesc "ab041443884a"
  :keywords '("pastebin")
  :authors '(("Thejaswi Puthraya" . "thejaswi.puthraya@gmail.com"))
  :maintainers '(("Thejaswi Puthraya" . "thejaswi.puthraya@gmail.com")))
