;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacs-everywhere" "0.3.0"
  "System-wide popup windows for quick edits."
  '((emacs "28.1"))
  :url "https://github.com/tecosaur/emacs-everywhere"
  :commit "10bf72a616eae8c4c89025bfebb062f761c869f7"
  :revdesc "10bf72a616ea"
  :keywords '("convenience" "frames")
  :authors '(("TEC" . "https://github.com/tecosaur"))
  :maintainers '(("TEC" . "contact@tecosaur.net")))
