;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jar-manifest-mode" "0.0.1"
  "[No description available]."
  ()
  :url "https://github.com/omajid/jar-manifest-mode"
  :commit "e9e0f8ef9865e712a1bdaca9727e7600c8ea0421"
  :revdesc "e9e0f8ef9865"
  :keywords '("convenience" "languages")
  :authors '(("Omair Majid" . "omair.majid@gmail.com"))
  :maintainers '(("Omair Majid" . "omair.majid@gmail.com")))
