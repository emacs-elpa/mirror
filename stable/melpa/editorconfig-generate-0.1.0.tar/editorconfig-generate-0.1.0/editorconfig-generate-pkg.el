;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "editorconfig-generate" "0.1.0"
  "Generate .editorconfig from Buffers."
  ()
  :url "https://github.com/10sr/emacs-lisp/blob/master/editorconfig-generate.el"
  :commit "f9316eb248002e283ef48bbcbeb5d1f69a1d54b5"
  :revdesc "f9316eb24800"
  :keywords '("utility" "editorconfig")
  :authors '(("10sr" . "8.slashes@gmail.com"))
  :maintainers '(("10sr" . "8.slashes@gmail.com")))
