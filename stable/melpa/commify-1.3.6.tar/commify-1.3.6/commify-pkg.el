;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "commify" "1.3.6"
  "Toggle grouping commas in numbers."
  '((s "1.9.0"))
  :url "https://github.com/ddoherty03/commify"
  :commit "35e2438eb7feeb28273c4920376fcf296cc83283"
  :revdesc "35e2438eb7fe"
  :keywords '("convenience" "editing" "numbers" "grouping" "commas")
  :authors '(("Daniel E. Doherty" . "ded-commify@ddoherty.net"))
  :maintainers '(("Daniel E. Doherty" . "ded-commify@ddoherty.net")))
