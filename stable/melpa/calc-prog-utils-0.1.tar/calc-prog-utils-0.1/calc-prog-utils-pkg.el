;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calc-prog-utils" "0.1"
  "Calc programmers utilities."
  '((emacs "24.1"))
  :url "https://github.com/Jesse-Millwood/calc-prog"
  :commit "cf2049b1770fef1ac1f8e8a45b128524bdc53598"
  :revdesc "cf2049b1770f"
  :keywords '("tools" "convenience"))
