;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc-popup" "0.1"
  "Mozc with popup."
  ()
  :url "https://github.com/d5884/mozc-popup"
  :commit "4f6df6ecec4e7bc89efa0877302600a7089671ad"
  :revdesc "4f6df6ecec4e"
  :keywords '("i18n" "extentions")
  :authors '(("Daisuke Kobayashi" . "d5884jp@gmail.com"))
  :maintainers '(("Daisuke Kobayashi" . "d5884jp@gmail.com")))
