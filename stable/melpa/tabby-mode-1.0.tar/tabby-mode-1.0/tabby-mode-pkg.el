;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabby-mode" "1.0"
  "Minor mode for the Tabby AI coding assistant."
  '((emacs "25.1"))
  :url "https://github.com/ragnard/tabby-mode"
  :commit "cc20756851f55c7c2ddfcc110555d14e96fbd4c5"
  :revdesc "cc20756851f5"
  :keywords '("tools" "convenience")
  :authors '(("Ragnar Dahlén" . "r.dahlen@gmail.com"))
  :maintainers '(("Ragnar Dahlén" . "r.dahlen@gmail.com")))
