;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-sitter-ess-r" "1.0"
  "R with tree-sitter."
  '((emacs             "26.1")
    (ess               "18.10.1")
    (tree-sitter       "0.12.1")
    (tree-sitter-langs "0.12.0"))
  :url "https://github.com/ShuguangSun/tree-sitter-ess-r"
  :commit "9669c00f3d3463e6769725af74c392891e269eed"
  :revdesc "9669c00f3d34"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
