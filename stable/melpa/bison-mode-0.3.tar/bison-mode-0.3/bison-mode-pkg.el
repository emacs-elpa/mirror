;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bison-mode" "0.3"
  "Major mode for editing bison, yacc and lex files."
  ()
  :url "https://github.com/Wilfred/bison-mode"
  :commit "1193903e36adf6770b673c3936ac0fbdac609b95"
  :revdesc "1193903e36ad"
  :keywords '("bison-mode" "yacc-mode")
  :authors '(("Eric Beuscher" . "beuscher@eecs.tulane.edu"))
  :maintainers '(("Eric Beuscher" . "beuscher@eecs.tulane.edu")))
