;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-git" "0.0.0.20110508.8"
  "Show git status in ibuffer column."
  ()
  :url "https://github.com/jrockway/ibuffer-git"
  :commit "d326319c05ddb8280885b31f9094040c1b365876"
  :revdesc "d326319c05dd"
  :keywords '("convenience")
  :authors '(("Jonathan Rockway" . "jon@jrock.us"))
  :maintainers '(("Jonathan Rockway" . "jon@jrock.us")))
