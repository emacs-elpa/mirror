;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elescope" "0.2"
  "Seach and clone projects from the minibuffer."
  '((emacs   "25.1")
    (ivy     "0.10")
    (request "0.3")
    (seq     "2.0"))
  :url "https://github.com/freesteph/elescope"
  :commit "7711f7e34d04ea52a258f69ee0c94ef1240c5655"
  :revdesc "7711f7e34d04"
  :keywords '("vc")
  :authors '(("Stéphane Maniaci" . "stephane.maniaci@gmail.com"))
  :maintainers '(("Stéphane Maniaci" . "stephane.maniaci@gmail.com")))
