;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "planet-theme" "0.1"
  "[No description available]."
  '((emacs "24.1"))
  :url "https://github.com/cmack/emacs-planet-theme"
  :commit "c7720d639f4fc6661aa337cfa2ae18abf59be371"
  :revdesc "c7720d639f4f"
  :keywords '("themes")
  :authors '(("Charlie McMackin" . "charlie.mac@gmail.com"))
  :maintainers '(("Charlie McMackin" . "charlie.mac@gmail.com")))
