;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eros" "0.1.0"
  "Evaluation Result OverlayS for Emacs Lisp."
  ()
  :url "https://github.com/xiongtx/eros"
  :commit "aa5772cde3b7a1a70537afd8412ab600f8d48951"
  :revdesc "aa5772cde3b7"
  :keywords '("convenience" "lisp")
  :authors '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com"))
  :maintainers '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com")))
