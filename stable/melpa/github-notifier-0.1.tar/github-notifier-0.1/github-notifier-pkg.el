;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-notifier" "0.1"
  "Displays your GitHub notifications unread count in mode-line."
  '((emacs "24"))
  :url "https://github.com/xuchunyang/github-notifier.el"
  :commit "f8d011ebef9f626a94a27b5576c8ed06e6ff8987"
  :revdesc "f8d011ebef9f"
  :keywords '("github" "mode-line")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
