;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "desktop-environment" "0.5.0"
  "Helps you control your GNU/Linux computer."
  '((emacs "25.1"))
  :url "https://gitlab.petton.fr/DamienCassou/desktop-environment"
  :commit "9da8f4bddb78668085a7fc367f9021549f9e5f70"
  :revdesc "9da8f4bddb78"
  :authors '(("Damien Cassou" . "damien@cassou.me")
             ("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")
                 ("Nicolas Petton" . "nicolas@petton.fr")))
