;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redtt" "0.0.1"
  "Major mode for editing redtt proofs and interacting with redtt."
  '((emacs "25.3"))
  :url "https://github.com/RedPRL/redtt"
  :commit "38f14b2c9980e9b7dc0805aa55f0f5ca7f06d4b4"
  :revdesc "38f14b2c9980"
  :keywords '("languages")
  :authors '(("Jonathan Sterling" . "jon@jonmsterling.com"))
  :maintainers '(("Jonathan Sterling" . "jon@jonmsterling.com")))
