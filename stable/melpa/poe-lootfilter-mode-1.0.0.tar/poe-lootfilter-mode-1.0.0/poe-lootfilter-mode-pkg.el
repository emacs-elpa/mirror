;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poe-lootfilter-mode" "1.0.0"
  "Major mode for editing Path of Exile lootfilters."
  '((emacs "24.3"))
  :url "https://github.com/jdodds/poe-lootfilter-mode"
  :commit "5ef06684cb2b17b090ee1f303c2b789fa71bc106"
  :revdesc "1.0.0-0-g5ef06684cb2b"
  :keywords '("languages" "games")
  :authors '(("Jeremiah Dodds" . "jeremiah.dodds@gmail.com"))
  :maintainers '(("Jeremiah Dodds" . "jeremiah.dodds@gmail.com")))
