;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "interval-list" "0.1"
  "Interval list data structure for 1D selections."
  '((dash "2.4.0"))
  :url "https://github.com/Fuco1/interval-list"
  :commit "cd0103147261bdb1a66395593d3cbfaab98cc6a3"
  :revdesc "cd0103147261"
  :keywords '("extensions" "data structure")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
