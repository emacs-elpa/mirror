;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jist" "0.0.1"
  "Manage gists from emacs."
  '((magit   "20141005.643")
    (request "0.2.0"))
  :url "https://github.com/emacs-pe/jist.el"
  :commit "6bfea4ddafd0a09922b4b7036c178c0cef725bd6"
  :revdesc "6bfea4ddafd0"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
