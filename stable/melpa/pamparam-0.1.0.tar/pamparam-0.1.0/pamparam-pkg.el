;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pamparam" "0.1.0"
  "Simple and fast flashcards."
  '((emacs        "24.3")
    (lispy        "0.26.0")
    (worf         "0.1.0")
    (hydra        "0.13.4")
    (ivy-posframe "0.5.5"))
  :url "https://github.com/abo-abo/pamparam"
  :commit "cbc737a2576220cf7197bc8136baea35ce97449e"
  :revdesc "cbc737a25762"
  :keywords '("outlines" "hypermedia" "flashcards" "memory")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
