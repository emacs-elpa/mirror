;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-autopair" "0.3"
  "Automatically insert pair braces and quotes, insertion conditions & actions are highly customizable."
  ()
  :url "https://github.com/uk-ar/flex-autopair.el"
  :commit "0184a539b874e20938418e4dbeaec0665129bf46"
  :revdesc "0184a539b874"
  :keywords '("keyboard" "input")
  :authors '(("Yuuki Arisawa" . "yuuki.ari@gmail.com"))
  :maintainers '(("Yuuki Arisawa" . "yuuki.ari@gmail.com")))
