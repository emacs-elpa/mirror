;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fillcode" "1.0.1"
  "Fill (wrap) function calls and expressions in source code."
  ()
  :url "https://snarfed.org/fillcode"
  :commit "7f59feb1c19a60c074f192226969f44d2665429c"
  :revdesc "7f59feb1c19a"
  :authors '(("Ryan Barrett" . "fillcode@ryanb.org"))
  :maintainers '(("Ryan Barrett" . "fillcode@ryanb.org")))
