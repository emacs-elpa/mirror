;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aurora-config-mode" "0.0.2"
  "Major mode for Apache Aurora configuration files."
  ()
  :url "https://github.com/bdd/aurora-config.el"
  :commit "0a7ca7987c3a0824e25470389c7d25c337a81593"
  :revdesc "v0.0.2-0-g0a7ca7987c3a"
  :keywords '("languages" "configuration")
  :authors '(("Berk D. Demir" . "bdd@mindcast.org"))
  :maintainers '(("Berk D. Demir" . "bdd@mindcast.org")))
