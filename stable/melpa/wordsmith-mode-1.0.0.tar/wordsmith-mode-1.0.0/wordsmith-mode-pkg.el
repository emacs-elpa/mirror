;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wordsmith-mode" "1.0.0"
  "Syntax analysis and NLP text-processing in Emacs (OSX-only)."
  ()
  :url "https://github.com/emacsattic/wordsmith-mode"
  :commit "41b10f2fe3589da9812395cb417c3dcf906f0969"
  :revdesc "1.0.0-0-g41b10f2fe358"
  :authors '(("istib" . "istib@thebati.net"))
  :maintainers '(("istib" . "istib@thebati.net")))
