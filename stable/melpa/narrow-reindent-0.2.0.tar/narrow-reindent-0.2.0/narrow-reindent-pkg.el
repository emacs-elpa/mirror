;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "narrow-reindent" "0.2.0"
  "Defines a minor mode to left-align narrowed regions."
  '((emacs "24.4"))
  :url "https://github.com/emallson/narrow-reindent.el"
  :commit "87466aac4dbeb79597124dd077bf5c704872fd3d"
  :revdesc "87466aac4dbe"
  :authors '(("J David Smith" . "emallson@atlanis.net"))
  :maintainers '(("J David Smith" . "emallson@atlanis.net")))
