;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "4.2.1"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "df353e34a8623f7bd1171ebe6f612a5be2996290"
  :revdesc "v4.2.1-0-gdf353e34a862"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
