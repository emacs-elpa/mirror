;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tbx2org" "0.1"
  "Tinderbox to org-mode conversion."
  '((dash "2.5.0")
    (s    "1.8.0"))
  :url "https://github.com/istib/helm-mode-manager"
  :commit "cddd51f3eeaf26cc565ff803389f8ae2c2936317"
  :revdesc "cddd51f3eeaf"
  :keywords '("org-mode"))
