;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "api-credit" "1.1.2"
  "AI API balance in the modeline."
  '((emacs "25.1"))
  :url "https://github.com/OverbearingPearl/api-credit"
  :commit "5ab4bcb5617952ab47362e82ec8eb5854e82fbbc"
  :revdesc "5ab4bcb56179"
  :keywords '("comm" "convenience")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
