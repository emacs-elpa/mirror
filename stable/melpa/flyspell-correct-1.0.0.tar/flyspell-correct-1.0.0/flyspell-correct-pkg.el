;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyspell-correct" "1.0.0"
  "Correcting words with flyspell via custom interface."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/flyspell-correct"
  :commit "a5a41c0f3a7881bd3eba07bee424ecb7c7d5061e"
  :revdesc "v1.0.0-0-ga5a41c0f3a78"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
