;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cinspect" "0.0.0.20150716.72"
  "Use cinspect to look at the CPython source of builtins and other C objects!."
  '((emacs              "24")
    (cl-lib             "0.5")
    (deferred           "0.3.1")
    (python-environment "0.0.2"))
  :url "https://github.com/inlinestyle/cinspect-mode"
  :commit "4e199a90f89b335cccda1518aa0963e0a1d4fbab"
  :revdesc "4e199a90f89b"
  :keywords '("python")
  :authors '(("Ben Yelsey" . "ben.yelsey@gmail.com"))
  :maintainers '(("Ben Yelsey" . "ben.yelsey@gmail.com")))
