;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embrace" "0.1.4"
  "Add/Change/Delete pairs based on `expand-region'."
  '((cl-lib        "0.5")
    (expand-region "0.10.0"))
  :url "https://github.com/cute-jumper/embrace.el"
  :commit "dd5da196e5bcc5e6d87e1937eca0c21da4334ef2"
  :revdesc "dd5da196e5bc"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
