;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indentinator" "1.0.0"
  "Automatically indent code."
  '((emacs "25.1"))
  :url "https://github.com/xendk/indentinator.el"
  :commit "96f569f917ff662638a6b2eb54d4fd5f4e731246"
  :revdesc "v1.0.0-0-g96f569f917ff"
  :keywords '("convenience")
  :authors '(("Thomas Fini Hansen" . "xen@xen.dk"))
  :maintainers '(("Thomas Fini Hansen" . "xen@xen.dk")))
