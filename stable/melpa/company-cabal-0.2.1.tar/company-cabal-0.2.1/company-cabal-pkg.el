;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-cabal" "0.2.1"
  "Company-mode cabal backend."
  '((cl-lib  "0.5")
    (company "0.8.0")
    (emacs   "24"))
  :url "https://github.com/iquiw/company-cabal"
  :commit "f458de88cad16ed48a605e8347e56433e73dcef8"
  :revdesc "f458de88cad1"
  :authors '(("Iku Iwasa" . "iku.iwasa@gmail.com"))
  :maintainers '(("Iku Iwasa" . "iku.iwasa@gmail.com")))
