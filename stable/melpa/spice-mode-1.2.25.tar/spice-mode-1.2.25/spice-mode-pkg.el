;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spice-mode" "1.2.25"
  "Major mode for SPICE."
  '((emacs "24.3"))
  :url "http://spice-mode.4t.com/"
  :commit "0c50835d15f0a39cfd50aba3a26b919f919f707c"
  :revdesc "0c50835d15f0"
  :keywords '("spice" "spice2g6" "spice3" "eldo" "hspice" "layla" "mondriaan" "fasthenry" "cdl" "spectre compatibility" "netlist editing")
  :authors '(("Geert A. M. Van der Plas 1999-" . "geert_vanderplas@email.com")
             ("Emmanuel Rouat 1997-" . "emmanuel.rouat@wanadoo.fr")
             ("MIT AI Lab 1994" . "cvieri@ai.mit.edu"))
  :maintainers '(("Geert A. M. Van der Plas" . "geert_vanderplas@email.com")))
