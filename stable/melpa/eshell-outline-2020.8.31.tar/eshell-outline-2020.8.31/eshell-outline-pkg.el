(define-package "eshell-outline" "2020.8.31" "Enhanced outline-mode for Eshell"
  '((emacs "25.1"))
  :commit "45311744f38dea4f750b382068c0b720568449b1" :authors
  '(("Jamie Beardslee" . "jdb@jamzattack.xyz"))
  :maintainers
  '(("Jamie Beardslee" . "jdb@jamzattack.xyz"))
  :maintainer
  '("Jamie Beardslee" . "jdb@jamzattack.xyz")
  :keywords
  '("unix" "eshell" "outline" "convenience")
  :url "https://git.jamzattack.xyz/eshell-outline")
;; Local Variables:
;; no-byte-compile: t
;; End:
