;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-metadata" "0.9"
  "Edit embedded metadata."
  '((exiftool "0"))
  :url "https://codeberg.org/mxpi/edit-metadata"
  :commit "b34573bca9a72a7570780ae9aaf0d92f9f8f22ec"
  :revdesc "b34573bca9a7"
  :keywords '("files" "multimedia")
  :authors '(("Michael Piotrowski" . "mxp@dynalabs.de"))
  :maintainers '(("Michael Piotrowski" . "mxp@dynalabs.de")))
