;;; edit-metadata.el --- Edit embedded metadata  -*- lexical-binding:t -*-

;; Copyright ® 2026 Michael Piotrowski

;; Author: Michael Piotrowski <mxp@dynalabs.de>
;; Created: 2026-01-23
;; Package-Version: 0.9
;; Package-Revision: b34573bca9a7
;; Package-Requires: ((exiftool))
;; Keywords: files multimedia

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; A simple interface (based on `widget') for editing metadata in
;; images and other file types supported by ExifTool.

;;; Code:

(require 'exiftool)
(require 'widget)
(require 'image-dired)

(eval-when-compile
  (require 'wid-edit))

(defvar-keymap edit-metadata-mode-keymap
  :parent widget-keymap
  "C-c C-a" #'edit-metadata-add-tag
  "C-c C-c" #'edit-metadata-write-file-and-quit
  "C-c C-k" #'quit-window
  "C-c C-t" #'edit-metadata-goto-tag
  "C-x C-s" #'edit-metadata-write-file)

(defvar-keymap edit-metadata-field-keymap
  :parent widget-field-keymap
  "C-c C-a" #'edit-metadata-add-tag
  "C-c C-c" #'edit-metadata-write-file-and-quit
  "C-c C-k" #'quit-window
  "C-c C-t" #'edit-metadata-goto-tag
  "C-x C-s" #'edit-metadata-write-file)

(defgroup edit-metadata-mode nil
  "Edit metadata of files."
  :group 'files)

(defcustom edit-metadata-immediate-write nil
  "If non-nil, immediately write changes to the file when pressing
RET in a field."
  :type 'boolean)

(defvar-local edit-metadata-file nil
  "File associated with the metadata.")

(defvar-local edit-metadata-mimetype nil
  "MIME type of the file associated with the metadata.")

(defvar-local edit-metadata-error nil
  "ExifTool error message.")

(defvar-local edit-metadata-relevant-tags nil
  "The subset of tags (without prefix) from `edit-metadata-tags'
relevant for the current file.")

(defvar-local edit-metadata-current-tags nil
  "List of tags currently used in the buffer.

This is used for `edit-metadata-goto-tag'.")

(defvar-local edit-metadata-widgets '()
  "The widgets used in the buffer.")

(defcustom edit-metadata-tags
  '(("application/pdf" . ("Author" "CreateDate" "Keywords" "Subject" "Language"
                          "PDFVersion" "Title" "MWG:Copyright" "MWG:Description"
                          "XMP:Source" "XMP:WebStatement"))
    ("image/.*" . ("MWG:Copyright" "MWG:Creator" "MWG:DateTimeOriginal"
                   "MWG:Description" "MWG:Rating" "XMP:Source"
                   "XMP:WebStatement"))
    ("video/.*" . ("MWG:Copyright" "MWG:Creator" "MWG:DateTimeOriginal"
                   "MWG:Description" "MWG:Rating" "XMP:Source"
                   "XMP:WebStatement"))
    ("audio/.*" . ("Title" "Artist" "Date" "Album" "TrackNumber" "Albumartist"
                   "Releasecountry" "Label" "Website" "Genre" "Catalognumber"
                   "Language"))
    (".*" . ("FileName")))
  "Alist of tags that should be displayed for certain filetypes.

The keys are regular expressions that are matched against the value of the MIMEType tag."
  :type '(alist :key-type string
                :value-type (repeat string)))

(defun edit-metadata-field-action ()
  (interactive)
  (when edit-metadata-immediate-write
    (edit-metadata-write-file))
  (widget-forward 1))

(defun edit-metadata-revert ()
  "Reload metadata from the current file."
  (interactive)
  (edit-metadata-find-file edit-metadata-file))

(defun edit-metadata-goto-tag (tag)
  "Jump to tag TAG."
  (interactive
   (let ((completion-ignore-case t))
     (list (completing-read "Tag: " edit-metadata-current-tags nil t nil nil))))

  (save-restriction
    (goto-char (point-min))
    (re-search-forward (concat "^" edit-metadata-marker "? *" (regexp-quote tag)))
    ;; (beginning-of-line)
    (widget-forward 1)))

(defun edit-metadata-add-tag (tag)
  "Add new tag TAG.

Prompts the user to select a tag to add, adds a corresponding
field, and places the point in the field.  Only tags from
`edit-metadata-tags' that are not already in use are offered for
selection.  Note, however, that lang-alt tags (e.g.,
“Description-fr”) must be listed in `edit-metadata-tags' in order
to insert them using `edit-metadata-add-tag'."
  (interactive
   (let ((completion-ignore-case t)
         (exclude edit-metadata-current-tags)) ; why is this needed!?
     (list
      (completing-read "Add Tag: " edit-metadata-relevant-tags
       (lambda (elt) (not (member elt exclude))) ; Offer only as yet unused tags
       t)))
   edit-metadata-mode)

  (goto-char (point-min))
  (goto-char edit-metadata-last-pos)

  (push `(,tag . ,(edit-metadata--make-field tag ""))
        edit-metadata-widgets)

  (setq-local edit-metadata-last-pos (point))
  (push tag edit-metadata-current-tags)

  (widget-setup)
  (widget-backward 1))

;;;###autoload
(defun edit-metadata-dired-edit ()
  "[HACK] Rough approximation of a command for use in `dired-mode'.

If several files are marked, only the first one is opened.  It
should work like `image-dired-dired-edit-comment-and-tags'."
  (interactive nil dired-mode)
  (let ((files (dired-get-marked-files)))
    (edit-metadata-find-file (first files))))

;;;###autoload
(defun edit-metadata-image-dired-edit ()
  "[HACK] Rough approximation of a command for `image-dired-thumbnail-mode'.

This function doesn't handle marked files.  This should probably
be done similarly to, e.g., `image-dired-tag-thumbnail'.  See also
the Info node `(emacs) Image-Dired')."
  (interactive nil image-dired-thumbnail-mode)
  ;;(image-dired--with-marked
  (edit-metadata-find-file (image-dired-original-file-name));;)
)

;;;###autoload
(defun edit-metadata-find-file-at-point ()
  "Edit the metadata of the file referred to by the filename at
point.

Contrary to `find-file-at-point', this function does not ask for
confirmation: it directly opens the metadata edit buffer if the
file exists."
  (interactive)
  (let ((filename (thing-at-point-file-at-point)))
    (if filename (edit-metadata-find-file filename)
      (user-error "No name of an existing file at point"))))

;;;###autoload
(defun edit-metadata-find-file (file)
  "Edit the metadata of FILE."
  (interactive "fFile: ")

  ;; We only need to check whether the file exists and is readable
  ;; when called non-interactively
    (let ((edit-metadata-file (expand-file-name file)))
      (unless (called-interactively-p #'interactive)
        (unless (and (file-exists-p edit-metadata-file)
                     (file-regular-p edit-metadata-file)
                     (file-readable-p edit-metadata-file))
          (user-error "No such file, or file not readable: %s" edit-metadata-file))))
  
  (switch-to-buffer "*edit-metadata-metadata*")
  (kill-all-local-variables)
    (if (not (eq major-mode 'edit-metadata-mode))
      (edit-metadata-mode))
  (let ((inhibit-read-only t))
    (erase-buffer))
  (remove-overlays)

  (setq edit-metadata-file (expand-file-name file))
  (widget-insert "\n")

  ;; Show a thumbnail of the file.  This relies on functions from
  ;; Image-Dired.  If no thumbnail exists, it is generated on the fly.
  ;; However, this only works for image files (including PDF
  ;; documents), but [FIXME] not for other media types supported by ExifTool,
  ;; e.g., video and audio.

  ;; Maybe we can take inspiration from Ready Player Mode
  ;; <https://github.com/xenodium/ready-player> and Dired Preview
  ;; <https://protesilaos.com/emacs/dired-preview>.
  (let (thumb-file img)
    (setq thumb-file (image-dired-thumb-name file)
          img (create-image thumb-file))

    (unless (file-exists-p thumb-file)
      (image-dired-create-thumb (expand-file-name file) thumb-file))

    (insert-image img))

  (widget-insert " ")
  (widget-create 'file-link file)
  (widget-insert "\n\n")
  
  (let* ((metadata (sort (exiftool-read edit-metadata-file)
                         (lambda (x y) (string< (car x) (car y)))))
         (mimetype (or (cdr (assoc "MIMEType" metadata)) "UNKNOWN"))
         (tags (mapcar (lambda (tagname) (string-trim tagname "^.*?:"))
                             (flatten-tree
                              (seq-keep (lambda (entry)
                                          (when (string-match-p (car entry) mimetype)
                                            (cdr entry)))
                                        edit-metadata-tags)))
               ))

    (setq edit-metadata-mimetype mimetype)
    (setq edit-metadata-relevant-tags tags)
    
    (dolist (item metadata)
      (let ((tag (car item))
            (value (cdr item)))
        (when (or (member (car item) tags)
                  ;; XMP dc lang-alt tags.  This ensures that they're
                  ;; read even if not explicitly specified in
                  ;; `edit-metadata-tags', but in order to be able to
                  ;; add them, they must nevertheless be listed there.
                  (string-match
                   (concat (regexp-opt '("Description" "Rights" "Title") nil) "-.+")
                   (car item)))
          ;; (print (car item)))
          (push
           `(,tag . ,(edit-metadata--make-field tag value))
           edit-metadata-widgets)
          (push tag edit-metadata-current-tags)
          (when (string-match "Date" tag) (widget-insert "\n"))
          )))
        
    (setq edit-metadata-error (or (cdr (assoc "Error" metadata)) "")))

  (setq-local edit-metadata-last-pos (point))     ; position of last field [HACK]

  ;;
  
  (widget-insert "\n")
  (widget-create 'push-button 
                 :notify (lambda (&rest ignore) (quit-window))
                 :button-face 'custom-button
                 :format "%[ %t %]"
                 :tag "Cancel")
  (widget-insert " ")
  (widget-create 'push-button
                 :notify (lambda (&rest ignore) (edit-metadata-write-file-and-quit))
                 :button-face 'custom-button
                 :format "%[ %t %]"
                 :tag "Save")
  
  (use-local-map edit-metadata-mode-keymap)
  
  ;;

  (widget-setup)

  (setq-local header-line-format
              '((:eval (substitute-command-keys
                        " Go to tag \\[edit-metadata-goto-tag]"))
                (:eval (substitute-command-keys
                        ", add tag \\[edit-metadata-add-tag]"))
                (:eval (substitute-command-keys
                        ", save \\[edit-metadata-write-file-and-quit]"))
                (:eval (substitute-command-keys
                        ", cancel \\[quit-window]"))
                "   "
                (:propertize
                 ((:eval
                   (when (not (string= edit-metadata-error "")) "⚠ "))
                  edit-metadata-error)
                 face error)))

  (beginning-of-line))

(defun edit-metadata-write-file ()
  "Write metadata tag values to the file."
  (interactive)

  ;; [DEBUG]
  ;; (print (mapcar (lambda (item)
  ;;                  `(,(car item) . ,(widget-value (cdr item))))
  ;;                edit-metadata-widgets))
  (apply #'exiftool-write edit-metadata-file
         (mapcar (lambda (item) `(,(car item) . ,(widget-value (cdr item)))) edit-metadata-widgets)))

(defun edit-metadata-write-file-and-quit ()
  (interactive)
  (edit-metadata-write-file)
  (quit-window))

(defun edit-metadata--make-field (tag value)
  (widget-create 'editable-field
                 :tag tag
                 :format (concat (propertize (string-pad tag 16) 'face 'bold) " %v")
                 :keymap edit-metadata-field-keymap
                 :size (when (string-match "Date" tag) 25)
                 :valid-regexp (if (string-match "Date" tag) "^[0-9: ]+$" "")
                 :action (lambda (widget &rest ignore)
                           (message "action")
                           (if (widget-apply widget :validate)
                               (error "The date is not valid: %s!" (widget-get widget :error))
                             (message "%s is ok!" (widget-value widget))
                             (widget-forward 1)))
                 :help-echo tag ; [TODO]
                 (or value "")))

(define-derived-mode edit-metadata-mode
  nil "edit-metadata"
  "Edited embedded metadata.
\\{edit-metadata-mode-keymap}
See the customization group `edit-metadata-mode' for options."
  :interactive nil
  :group 'edit-metadata-mode)

(provide 'edit-metadata)

;;; edit-metadata ends here
