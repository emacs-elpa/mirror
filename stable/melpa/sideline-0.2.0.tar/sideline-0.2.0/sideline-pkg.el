;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline" "0.2.0"
  "Show information on the side."
  '((emacs "27.1")
    (ht    "2.4"))
  :url "https://github.com/emacs-sideline/sideline"
  :commit "795673c66bb77e6edc46e2667612924f9faaa828"
  :revdesc "795673c66bb7"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
