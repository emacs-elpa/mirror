;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab-themes" "1.0"
  "A carefully contructed custom theme."
  '((emacs "24"))
  :url "https://github.com/MetroWind/lab-theme"
  :commit "e9799e81a4624384510fb742f60562b2922f55ff"
  :revdesc "e9799e81a462"
  :keywords '("lisp")
  :authors '(("MetroWind" . "chris.corsair@gmail.com"))
  :maintainers '(("MetroWind" . "chris.corsair@gmail.com")))
