;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "govc" "0.54.0"
  "Interface to govc for managing VMware ESXi and vCenter."
  '((emacs       "24.3")
    (dash        "1.5.0")
    (s           "1.9.0")
    (magit-popup "2.0.50")
    (json-mode   "1.6.0"))
  :url "https://github.com/vmware/govmomi/tree/main/govc/emacs"
  :commit "df7c057af6c06430955ce56d6f04b7e49138f9b3"
  :revdesc "v0.54.0-0-gdf7c057af6c0"
  :keywords '("convenience"))
