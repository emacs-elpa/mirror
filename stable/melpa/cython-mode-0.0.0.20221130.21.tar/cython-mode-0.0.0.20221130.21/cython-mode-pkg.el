;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cython-mode" "0.0.0.20221130.21"
  "Major mode for editing Cython files."
  ()
  :url "https://github.com/cython/emacs-cython-mode"
  :commit "3e4790559d3168fe992cf2aa62f01423038cedb5"
  :revdesc "3e4790559d31")
