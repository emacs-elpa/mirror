;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lines-at-once" "0.1.0"
  "Insert multiple lines at once."
  '((emacs "25"))
  :url "https://github.com/jiahaowork/lines-at-once.el"
  :commit "e1353a8f3d656286adb31533b6b6b6542e1c64cb"
  :revdesc "e1353a8f3d65"
  :keywords '("abbrev" "tools")
  :authors '(("Jiahao Li" . "jiahaowork@gmail.com"))
  :maintainers '(("Jiahao Li" . "jiahaowork@gmail.com")))
