;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-archive" "0.3"
  "Git supported code archive and reference for org-mode."
  '((emacs "24.3"))
  :url "https://github.com/mschuldt/code-archive"
  :commit "1ad9af6679d0294c3056eab9cad673f29c562721"
  :revdesc "1ad9af6679d0"
  :authors '(("Michael Schuldt" . "mbschuldt@gmail.com"))
  :maintainers '(("Michael Schuldt" . "mbschuldt@gmail.com")))
