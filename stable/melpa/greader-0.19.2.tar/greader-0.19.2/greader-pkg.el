;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "0.19.2"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "78a62fb16f4922e34404e93b103a7e009fdecfa9"
  :revdesc "v0.19.2-0-g78a62fb16f49"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
