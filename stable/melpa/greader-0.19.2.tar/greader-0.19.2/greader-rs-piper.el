;;; greader-rs-piper.el --- greader backend using greader-rs with Piper TTS  -*- lexical-binding: t; -*-

;; Copyright (C) 2017-2026  Free Software Foundation, Inc.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;; greader backend that calls greader-rs with --backend=piper.
;; Requires greader-rs compiled with the `piper' feature and a Piper
;; voice model (.onnx + .onnx.json) configured in
;; `greader-rs-piper-model'.

;;; Code:

(require 'greader-rs-common)
(defvar greader-backends)

(defgroup greader-rs-piper
  nil
  "greader backend: greader-rs Piper neural TTS engine."
  :group 'greader)

(defcustom greader-rs-piper-model ""
  "Path to the Piper voice model config file (.onnx.json).
The corresponding .onnx weights file must be in the same directory."
  :type 'string
  :tag "Piper model config path")

(defcustom greader-rs-piper-rate 130
  "Default speech rate in words per minute for the Piper backend."
  :type 'integer
  :tag "greader-rs piper rate")

(defcustom greader-rs-piper-pre-silence 50
  "Silence prepended before each sentence, in milliseconds."
  :type 'integer
  :group 'greader-rs-piper)

(defcustom greader-rs-piper-post-silence 200
  "Silence appended after each sentence, in milliseconds."
  :type 'integer
  :group 'greader-rs-piper)

(defcustom greader-rs-piper-fade 10
  "Fade-in and fade-out duration, in milliseconds."
  :type 'integer
  :group 'greader-rs-piper)

;;;###autoload
(defun greader-rs-piper (command &optional arg)
  "greader backend function for greader-rs with the Piper engine.
COMMAND is a symbol; ARG depends on the command."
  (pcase command
    ('executable
     greader-rs-executable)
    ('backend-flag
     "--backend=piper")
    ('extra
     (if (and greader-rs-piper-model (not (string-empty-p greader-rs-piper-model)))
         (append (list "--backend=piper"
                       (concat "--model=" (expand-file-name greader-rs-piper-model))
                       "--stdin"
                       (format "--pre-silence=%d" greader-rs-piper-pre-silence)
                       (format "--post-silence=%d" greader-rs-piper-post-silence)
                       (format "--fade=%d" greader-rs-piper-fade))
                 (greader-rs-common-flags))
       (error "greader-rs-piper: `greader-rs-piper-model' is not set")))
    ('rate
     (cond
      ((eq arg 'value) greader-rs-piper-rate)
      (arg
       (setq-local greader-rs-piper-rate arg)
       (concat "-s" (number-to-string arg)))
      (t
       (concat "-s" (number-to-string greader-rs-piper-rate)))))
    ('get-rate
     greader-rs-piper-rate)
    ('audio-write
     (let ((text (car arg))
           (filename (cadr arg)))
       (unless (and greader-rs-piper-model
                    (not (string-empty-p greader-rs-piper-model)))
         (error "greader-rs-piper: `greader-rs-piper-model' is not set"))
       (call-process greader-rs-executable
                     nil "*greader-rs-output*" nil
                     "--backend=piper"
                     (concat "--model=" (expand-file-name greader-rs-piper-model))
                     (concat "-s" (number-to-string greader-rs-piper-rate))
                     "-w" filename
                     text)))
    ;; Piper models have no central voice registry.
    ('set-voice  'not-implemented)
    ('save-voice 'not-implemented)
    ('lang       nil)
    ('punctuation nil)
    (_ 'not-implemented)))

(put 'greader-rs-piper 'greader-backend-name "greader-rs-piper")

(add-to-list 'greader-backends 'greader-rs-piper t)

(provide 'greader-rs-piper)
;;; greader-rs-piper.el ends here
