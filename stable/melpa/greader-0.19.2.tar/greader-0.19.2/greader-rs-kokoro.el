;;; greader-rs-kokoro.el --- greader backend using greader-rs with Kokoro TTS  -*- lexical-binding: t; -*-

;; Copyright (C) 2017-2026  Free Software Foundation, Inc.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;; greader backend that calls greader-rs with --backend=kokoro.
;; Requires greader-rs compiled with the `kokoro' feature and the Kokoro
;; ONNX model + voices file configured via `greader-rs-kokoro-model' and
;; `greader-rs-kokoro-voices'.

;;; Code:

(require 'greader-rs-common)
(defvar greader-backends)

(defgroup greader-rs-kokoro
  nil
  "greader backend: greader-rs Kokoro neural TTS engine."
  :group 'greader)

(defcustom greader-rs-kokoro-model ""
  "Path to the Kokoro ONNX model file (kokoro-v1.0.onnx)."
  :type 'string
  :tag "Kokoro model path")

(defcustom greader-rs-kokoro-voices ""
  "Path to the Kokoro voices file (voices-v1.0.bin)."
  :type 'string
  :tag "Kokoro voices path")

(defcustom greader-rs-kokoro-voice "af_heart"
  "Default voice name for the Kokoro backend.
Voice names follow the pattern {lang}{gender}_{name}, e.g.
\"af_sarah\" (American female), \"im_nicola\" (Italian male)."
  :type 'string
  :tag "Kokoro voice")

(defcustom greader-rs-kokoro-rate 175
  "Default speech rate in words per minute for the Kokoro backend."
  :type 'integer
  :tag "greader-rs kokoro rate")

(defcustom greader-rs-kokoro-pre-silence 50
  "Silence prepended before each sentence, in milliseconds."
  :type 'integer
  :group 'greader-rs-kokoro)

(defcustom greader-rs-kokoro-post-silence 200
  "Silence appended after each sentence, in milliseconds."
  :type 'integer
  :group 'greader-rs-kokoro)

(defcustom greader-rs-kokoro-fade 10
  "Fade-in and fade-out duration, in milliseconds."
  :type 'integer
  :group 'greader-rs-kokoro)

(defun greader-rs-kokoro--check-paths ()
  "Signal an error if the model or voices path is not configured."
  (unless (and greader-rs-kokoro-model
               (not (string-empty-p greader-rs-kokoro-model)))
    (error "greader-rs-kokoro: `greader-rs-kokoro-model' is not set"))
  (unless (and greader-rs-kokoro-voices
               (not (string-empty-p greader-rs-kokoro-voices)))
    (error "greader-rs-kokoro: `greader-rs-kokoro-voices' is not set")))

(defun greader-rs-kokoro--model-flags ()
  "Return the --model and --voices flags for the Kokoro backend."
  (list (concat "--model=" (expand-file-name greader-rs-kokoro-model))
        (concat "--voices=" (expand-file-name greader-rs-kokoro-voices))))

(defun greader-rs-kokoro--list-voices ()
  "Return a list of voice names from the Kokoro voices file.
Calls `greader-rs --backend kokoro --list-voices'."
  (greader-rs-kokoro--check-paths)
  (with-temp-buffer
    (apply #'call-process greader-rs-executable nil t nil
           "--backend=kokoro"
           (append (greader-rs-kokoro--model-flags)
                   '("--list-voices")))
    (goto-char (point-min))
    (let (voices)
      (while (not (eobp))
        (let ((line (string-trim (buffer-substring-no-properties
                                  (line-beginning-position)
                                  (line-end-position)))))
          ;; Lines are "name\tlanguage"; we want the name.
          (when (string-match "\\([^\t]+\\)" line)
            (push (match-string 1 line) voices)))
        (forward-line 1))
      (nreverse voices))))

;;;###autoload
(defun greader-rs-kokoro (command &optional arg)
  "greader backend function for greader-rs with the Kokoro engine.
COMMAND is a symbol; ARG depends on the command."
  (pcase command
    ('executable
     greader-rs-executable)
    ('backend-flag
     "--backend=kokoro")
    ('extra
     (greader-rs-kokoro--check-paths)
     (append (list "--backend=kokoro"
                   "--stdin")
             (greader-rs-kokoro--model-flags)
             (list (format "--pre-silence=%d" greader-rs-kokoro-pre-silence)
                   (format "--post-silence=%d" greader-rs-kokoro-post-silence)
                   (format "--fade=%d" greader-rs-kokoro-fade))
             (greader-rs-common-flags)))
    ('lang
     (if arg
         (progn
           (setq-local greader-rs-kokoro-voice arg)
           (concat "-v" arg))
       (when greader-rs-kokoro-voice
         (concat "-v" greader-rs-kokoro-voice))))
    ('rate
     (cond
      ((eq arg 'value) greader-rs-kokoro-rate)
      (arg
       (setq-local greader-rs-kokoro-rate arg)
       (concat "-s" (number-to-string arg)))
      (t
       (concat "-s" (number-to-string greader-rs-kokoro-rate)))))
    ('get-rate
     greader-rs-kokoro-rate)
    ('get-language
     (when greader-rs-kokoro-voice
       ;; Derive 2-letter ISO code from voice name prefix.
       (pcase (substring greader-rs-kokoro-voice 0 1)
         ((or "a" "b" "e") "en")
         ("f" "fr")
         ("h" "hi")
         ("i" "it")
         ("j" "ja")
         ("p" "pt")
         ("z" "zh")
         (_ "en"))))
    ('punctuation nil)
    ('set-voice
     (completing-read "Voice: "
                      (greader-rs-kokoro--list-voices) nil t))
    ('save-voice
     (customize-save-variable 'greader-rs-kokoro-voice arg))
    ('audio-write
     (let ((text (car arg))
           (filename (cadr arg)))
       (greader-rs-kokoro--check-paths)
       (apply #'call-process greader-rs-executable
              nil "*greader-rs-output*" nil
              "--backend=kokoro"
              (append (greader-rs-kokoro--model-flags)
                      (list
                       (concat "-s" (number-to-string greader-rs-kokoro-rate))
                       (concat "-v" greader-rs-kokoro-voice)
                       "-w" filename
                       text)))))
    (_ 'not-implemented)))

(put 'greader-rs-kokoro 'greader-backend-name "greader-rs-kokoro")

(add-to-list 'greader-backends 'greader-rs-kokoro t)

(provide 'greader-rs-kokoro)
;;; greader-rs-kokoro.el ends here
