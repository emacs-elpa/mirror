;;; greader-rs-common.el --- Shared configuration for greader-rs backends  -*- lexical-binding: t; -*-

;; Copyright (C) 2017-2026  Free Software Foundation, Inc.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;;; Commentary:
;; Shared configuration for all greader-rs backends.
;;
;; Use `greader-rs-install' to build or download the greader-rs binary.
;; When cargo is available, it builds from source with platform-appropriate
;; features.  Otherwise, it downloads a prebuilt binary from GitLab Releases.

;;; Code:

(require 'url)

(declare-function find-library-name "find-func")
(declare-function greader-call-backend "greader")

(defgroup greader-rs nil
  "Common settings for greader-rs native TTS backends."
  :group 'greader)

(defcustom greader-rs-executable
  (expand-file-name
   "greader-rs/target/release/greader-rs"
   (file-name-directory (or load-file-name
                             (find-library-name "greader-rs-common"))))
  "Path to the greader-rs binary.
All greader-rs backends share this single executable."
  :type 'string
  :group 'greader-rs)

(defun greader-rs-available-p ()
  "Return non-nil if the greader-rs binary is installed and executable."
  (and (stringp greader-rs-executable)
       (file-executable-p greader-rs-executable)))


;; ---------------------------------------------------------------------------
;; Installation
;; ---------------------------------------------------------------------------

(defconst greader-rs--gitlab-release-url
  "https://gitlab.com/michelangelo-rodriguez/greader/-/releases/permalink/latest/downloads"
  "Base URL for downloading prebuilt greader-rs binaries from GitLab Releases.")

(defun greader-rs--source-dir ()
  "Return the greader-rs Cargo project directory.
This is the `greader-rs/' subdirectory next to the Elisp source files."
  (expand-file-name
   "greader-rs"
   (file-name-directory (or load-file-name
                             (find-library-name "greader-rs-common")))))

(defun greader-rs--platform ()
  "Return a cons (OS . ARCH) for the current platform.
OS is \"darwin\" or \"linux\".  ARCH is \"aarch64\" or \"x86_64\"."
  (let ((os (pcase system-type
              ('darwin "darwin")
              ((or 'gnu/linux 'gnu) "linux")
              (_ (error "Unsupported OS: %s" system-type))))
        (arch (let ((m (string-trim
                        (shell-command-to-string "uname -m"))))
                (pcase m
                  ((or "arm64" "aarch64") "aarch64")
                  ((or "x86_64" "amd64") "x86_64")
                  (_ (error "Unsupported architecture: %s" m))))))
    (cons os arch)))

(defun greader-rs--platform-features ()
  "Return the Cargo feature string appropriate for the current OS.
macOS gets espeak,mac,piper,kokoro.
Linux gets espeak,speechd,piper,kokoro."
  (pcase system-type
    ('darwin "espeak,mac,piper,kokoro")
    ((or 'gnu/linux 'gnu) "espeak,speechd,piper,kokoro")
    (_ "espeak,piper,kokoro")))

(defun greader-rs--cargo-executable ()
  "Return the path to cargo, or nil if not found."
  (executable-find "cargo"))

(defun greader-rs--asset-name ()
  "Return the GitLab release asset name for this platform."
  (let ((plat (greader-rs--platform)))
    (format "greader-rs-%s-%s" (car plat) (cdr plat))))

(defun greader-rs--download-binary ()
  "Download a prebuilt greader-rs binary from GitLab Releases.
Places it at the path specified by `greader-rs-executable'."
  (let* ((asset (greader-rs--asset-name))
         (url (format "%s/%s" greader-rs--gitlab-release-url asset))
         (dest greader-rs-executable)
         (dest-dir (file-name-directory dest)))
    (unless (file-directory-p dest-dir)
      (make-directory dest-dir t))
    (message "Downloading %s ..." url)
    (url-copy-file url dest t)
    (set-file-modes dest #o755)
    (message "Downloaded greader-rs to %s" dest)))

(defun greader-rs--cargo-build (features)
  "Build greader-rs from source with FEATURES using cargo.
FEATURES is a comma-separated string of Cargo feature names."
  (let* ((source-dir (greader-rs--source-dir))
         (default-directory source-dir)
         (buf (get-buffer-create "*greader-rs-build*")))
    (with-current-buffer buf
      (erase-buffer))
    (message "Building greader-rs with features: %s ..." features)
    (let ((exit-code
           (call-process "cargo" nil buf nil
                         "build" "--release"
                         "--no-default-features"
                         "--features" features)))
      (if (zerop exit-code)
          (message "greader-rs built successfully.")
        (pop-to-buffer buf)
        (error "Cargo build failed (exit %d).  See *greader-rs-build*"
               exit-code)))))

(defun greader-rs--verify-binary ()
  "Verify that the greader-rs binary is functional.
Return non-nil on success."
  (and (file-executable-p greader-rs-executable)
       (zerop (call-process greader-rs-executable nil nil nil "--help"))))

;;;###autoload
(defun greader-rs-install ()
  "Install the greader-rs binary.
If cargo is available, build from source with the appropriate
features for this platform.  Otherwise, download a prebuilt binary
from GitLab Releases.

Note: when building from source, the compilation is synchronous and
may take several minutes.  Emacs will be unresponsive until the build
finishes.

With a prefix argument, force a rebuild/redownload even if the
binary already exists."
  (interactive)
  (when (and (not current-prefix-arg)
             (greader-rs-available-p))
    (user-error "greader-rs is already installed at %s.  \
Use C-u M-x greader-rs-install to force reinstall"
                greader-rs-executable))
  (let ((cargo (greader-rs--cargo-executable)))
    (if cargo
        (greader-rs--cargo-build (greader-rs--platform-features))
      (greader-rs--download-binary)))
  (if (greader-rs--verify-binary)
      (message "greader-rs is ready at %s" greader-rs-executable)
    (error "greader-rs binary verification failed.  \
Check %s" greader-rs-executable)))

(defcustom greader-rs-config-file nil
  "Path to a TOML configuration file for greader-rs.
Per-backend sections ([espeak], [mac], [piper]) can override
the audio timing defaults.  CLI flags take precedence."
  :type '(choice (const nil) string)
  :group 'greader-rs)

(defun greader-rs-common-config-flag ()
  "Return a list containing the --config flag, or nil if not set."
  (when greader-rs-config-file
    (list (format "--config=%s" (expand-file-name greader-rs-config-file)))))

(defcustom greader-rs-audio-device nil
  "Audio output device for greader-rs backends.
nil means use the system default device.  Set to the exact device name
as returned by `greader-rs-list-audio-devices'.
With a prefix argument, `greader-rs-set-audio-device' saves this value
to `custom-file' via `customize-save-variable'."
  :type '(choice (const nil) string)
  :group 'greader-rs)

(defun greader-rs-list-audio-devices ()
  "Return available audio output device names for the current greader-rs backend.
Calls the greader-rs binary with --backend=X --list-audio-devices so that
each backend can use its own native enumeration (e.g. CoreAudio on macOS)."
  (let ((backend-flag (greader-call-backend 'backend-flag nil)))
    (with-temp-buffer
      (apply #'call-process greader-rs-executable nil t nil
             (append (when (and backend-flag (not (eq backend-flag 'not-implemented)))
                       (list backend-flag))
                     '("--list-audio-devices")))
      (goto-char (point-min))
      (let (devices)
        (while (not (eobp))
          (let ((line (string-trim (buffer-substring-no-properties
                                    (line-beginning-position)
                                    (line-end-position)))))
            (unless (string-empty-p line)
              (push line devices)))
          (forward-line 1))
        (nreverse devices)))))

(defconst greader-rs--system-device-label "system"
  "Label shown in the device picker to mean \"use the system default\".")

(defun greader-rs-set-audio-device (device)
  "Select the audio output device for greader-rs backends.
DEVICE is the device name as returned by `greader-rs-list-audio-devices',
or the special value \"system\" to restore the system default.
With a prefix argument, save the selection as the new global default
via `customize-save-variable'."
  (interactive
   (list
    (completing-read "Audio device: "
                     (cons greader-rs--system-device-label
                           (greader-rs-list-audio-devices))
                     nil t)))
  (let ((value (if (equal device greader-rs--system-device-label)
                   nil
                 device)))
    (setq-local greader-rs-audio-device value)
    (when current-prefix-arg
      (customize-save-variable 'greader-rs-audio-device value))
    (message "greader-rs audio device: %s"
             (or value "system default"))))

(defun greader-rs-common-audio-device-flag ()
  "Return a list containing --audio-device, or nil if not set."
  (when (and greader-rs-audio-device
             (not (string-empty-p greader-rs-audio-device)))
    (list (format "--audio-device=%s" greader-rs-audio-device))))

(defcustom greader-rs-encoding "auto"
  "Input encoding for greader-rs stdin mode.
\"auto\" (default) tries UTF-8 first, then falls back to
Windows-1252 (a superset of ISO-8859-1).  Any WHATWG encoding
label is accepted (e.g. \"utf-8\", \"iso-8859-2\", \"koi8-r\")."
  :type 'string
  :group 'greader-rs)

(defun greader-rs-common-encoding-flag ()
  "Return a list containing the --encoding flag, or nil if \"auto\"."
  (when (and greader-rs-encoding
             (not (string-equal greader-rs-encoding "auto")))
    (list (format "--encoding=%s" greader-rs-encoding))))

(defun greader-rs-common-flags ()
  "Return common extra flags for all greader-rs backends.
Combines the --config, --audio-device, and --encoding flags."
  (append (greader-rs-common-config-flag)
          (greader-rs-common-audio-device-flag)
          (greader-rs-common-encoding-flag)))

;; ---------------------------------------------------------------------------
;; Custom backend definitions
;; ---------------------------------------------------------------------------

(defvar greader-rs-custom-backends nil
  "Alist of custom backend specifications.
Each entry is (NAME . PLIST) where PLIST contains the keyword
arguments passed to `greader-rs-define-custom-backend'.  This alist
can be serialized to TOML for Rust-side consumption.")

(defun greader-rs-custom--text-mode-string (mode)
  "Convert a text-mode specification MODE to a CLI string.
MODE is the symbol `positional', `file', or a list (flag \"--text\")."
  (pcase mode
    ('positional "positional")
    ('file "file")
    (`(flag ,flag) (format "flag:%s" flag))
    (_ "positional")))

(defun greader-rs-custom--arg-order-string (order)
  "Convert an arg-order specification ORDER to a CLI string.
ORDER is the symbol `flags-first' (default) or `positionals-first'."
  (if (eq order 'positionals-first)
      "positionals-first"
    "flags-first"))

(defun greader-rs-custom--build-flags (spec)
  "Build the list of --custom-* CLI flags from backend SPEC plist."
  (let ((program (plist-get spec :program))
        (name (plist-get spec :name))
        (rate-flag (plist-get spec :rate-flag))
        (voice-flag (plist-get spec :voice-flag))
        (punct-flag (plist-get spec :punct-flag))
        (wav-flag (plist-get spec :wav-flag))
        (list-voices-flag (plist-get spec :list-voices-flag))
        (text-mode (or (plist-get spec :text-mode) 'positional))
        (arg-style (or (plist-get spec :arg-style) "separate"))
        (arg-order (or (plist-get spec :arg-order) 'flags-first))
        (extra-args (plist-get spec :extra-args)))
    (append
     (list "--backend=custom"
           (format "--custom-program=%s" (expand-file-name program))
           (format "--custom-name=%s" name))
     (when rate-flag
       (list (format "--custom-rate-flag=%s" rate-flag)))
     (when voice-flag
       (list (format "--custom-voice-flag=%s" voice-flag)))
     (when punct-flag
       (list (format "--custom-punct-flag=%s" punct-flag)))
     (when wav-flag
       (list (format "--custom-wav-flag=%s" wav-flag)))
     (when list-voices-flag
       (list (format "--custom-list-voices-flag=%s" list-voices-flag)))
     (list (format "--custom-text-mode=%s"
                   (greader-rs-custom--text-mode-string text-mode))
           (format "--custom-arg-style=%s"
                   (if (symbolp arg-style)
                       (symbol-name arg-style)
                     arg-style))
           (format "--custom-arg-order=%s"
                   (greader-rs-custom--arg-order-string arg-order)))
     (mapcar (lambda (a) (format "--custom-extra=%s" a))
             (or extra-args '())))))

(defun greader-rs-custom--write-toml (file)
  "Write all custom backend definitions to TOML FILE.
Each backend in `greader-rs-custom-backends' becomes a [custom.NAME]
section that greader-rs can read via --config."
  (with-temp-file file
    (dolist (entry greader-rs-custom-backends)
      (let* ((name (car entry))
             (spec (cdr entry))
             (program (plist-get spec :program))
             (rate-flag (plist-get spec :rate-flag))
             (voice-flag (plist-get spec :voice-flag))
             (punct-flag (plist-get spec :punct-flag))
             (wav-flag (plist-get spec :wav-flag))
             (list-voices-flag (plist-get spec :list-voices-flag))
             (text-mode (or (plist-get spec :text-mode) 'positional))
             (arg-style (or (plist-get spec :arg-style) "separate"))
             (extra-args (plist-get spec :extra-args)))
        (insert (format "[custom.%s]\n" name))
        (insert (format "program = %S\n" program))
        (when rate-flag (insert (format "rate_flag = %S\n" rate-flag)))
        (when voice-flag (insert (format "voice_flag = %S\n" voice-flag)))
        (when punct-flag (insert (format "punct_flag = %S\n" punct-flag)))
        (when wav-flag
          (insert (format "wav_flag = %S\n"
                          (if (symbolp wav-flag)
                              (symbol-name wav-flag)
                            wav-flag))))
        (when list-voices-flag
          (insert (format "list_voices_flag = %S\n" list-voices-flag)))
        (insert (format "text_mode = %S\n"
                        (greader-rs-custom--text-mode-string text-mode)))
        (insert (format "arg_style = %S\n"
                        (if (symbolp arg-style)
                            (symbol-name arg-style)
                          arg-style)))
        (insert (format "arg_order = %S\n"
                        (greader-rs-custom--arg-order-string
                         (or (plist-get spec :arg-order) 'flags-first))))
        (when extra-args
          (insert (format "extra_args = [%s]\n"
                          (mapconcat (lambda (a) (format "%S" a))
                                     extra-args ", "))))
        (insert "\n")))))

(defmacro greader-rs-define-custom-backend (name &rest body)
  "Define a custom greader-rs backend named NAME.

NAME is an unquoted symbol used as the backend identifier.
BODY is a property list with these keys:

  :program           STRING   External TTS program (required).
  :rate-flag         STRING   CLI flag for speech rate (e.g. \"-s\").
  :voice-flag        STRING   CLI flag for voice/language (e.g. \"-v\").
  :punct-flag        STRING   CLI flag for punctuation (e.g. \"--punct\").
  :wav-flag          VALUE    CLI flag for WAV output (e.g. \"-w\"), or
                              the symbol `positional' if the output path
                              is a positional argument (e.g. kokoro-tts).
                              When set, the backend supports stdin mode
                              and audio-write.
  :list-voices-flag  STRING   CLI flag for listing voices.
  :text-mode         SYMBOL   How text is passed: `positional' (default),
                              `file' (write to temp file, pass path),
                              or (flag \"--text\").
  :arg-style         STRING   How flags combine with values: \"separate\"
                              (default), \"equals\", or \"flag-only\".
  :arg-order         SYMBOL   Order of flags vs. positional arguments:
                              `flags-first' (default) or `positionals-first'.
  :extra-args        LIST     Extra arguments always passed to the program.
  :default-rate      INTEGER  Default speech rate in WPM (default 175).
  :default-language  STRING   Default language (default \"en\").
  :pre-silence       INTEGER  Default pre-silence in ms (default 50).
  :post-silence      INTEGER  Default post-silence in ms (default 400).
  :fade              INTEGER  Default fade in ms (default 10).

Example:

  (greader-rs-define-custom-backend pico
    :program \"pico2wave\"
    :voice-flag \"-l\"
    :wav-flag \"-w\"
    :arg-style \"separate\"
    :default-language \"it-IT\")"
  (let* ((name-str (symbol-name name))
         (prefix (concat "greader-rs-" name-str))
         (fn-sym (intern prefix))
         (lang-sym (intern (concat prefix "-language")))
         (rate-sym (intern (concat prefix "-rate")))
         (punct-sym (intern (concat prefix "-punctuation")))
         (pre-silence-sym (intern (concat prefix "-pre-silence")))
         (post-silence-sym (intern (concat prefix "-post-silence")))
         (fade-sym (intern (concat prefix "-fade")))
         (flags-fn (intern (concat prefix "--custom-flags")))
         (group-sym (intern prefix))
         ;; Extract plist values at macro-expansion time.
         (program (plist-get body :program))
         (rate-flag (plist-get body :rate-flag))
         (voice-flag (plist-get body :voice-flag))
         (punct-flag (plist-get body :punct-flag))
         (wav-flag (plist-get body :wav-flag))
         (list-voices-flag (plist-get body :list-voices-flag))
         (text-mode (or (plist-get body :text-mode) 'positional))
         (arg-style (or (plist-get body :arg-style) "separate"))
         (arg-order (or (plist-get body :arg-order) 'flags-first))
         (extra-args (plist-get body :extra-args))
         (default-rate (or (plist-get body :default-rate) 175))
         (default-language (or (plist-get body :default-language) "en"))
         (pre-silence (or (plist-get body :pre-silence) 50))
         (post-silence (or (plist-get body :post-silence) 400))
         (fade (or (plist-get body :fade) 10))
         (stdin-p (not (null wav-flag)))
         ;; Build the spec plist for storage.
         (spec `(:name ,name-str :program ,program
                       ,@(when rate-flag `(:rate-flag ,rate-flag))
                       ,@(when voice-flag `(:voice-flag ,voice-flag))
                       ,@(when punct-flag `(:punct-flag ,punct-flag))
                       ,@(when wav-flag `(:wav-flag ,wav-flag))
                       ,@(when list-voices-flag
                           `(:list-voices-flag ,list-voices-flag))
                       :text-mode ,text-mode
                       :arg-style ,arg-style
                       :arg-order ,arg-order
                       ,@(when extra-args `(:extra-args ,extra-args)))))
    (unless program
      (error "greader-rs-define-custom-backend: :program is required"))
    `(progn
       ;; Store the spec for TOML serialization.
       (setf (alist-get ,name-str greader-rs-custom-backends
                        nil nil #'equal)
             ',spec)

       ;; Customization group.
       (defgroup ,group-sym nil
         ,(format "greader backend: greader-rs %s custom engine." name-str)
         :group 'greader-rs)

       ;; Defcustom variables.
       (defcustom ,lang-sym ,default-language
         ,(format "Default voice/language for the %s backend." name-str)
         :type 'string
         :group ',group-sym)

       (defcustom ,rate-sym ,default-rate
         ,(format "Default speech rate in WPM for the %s backend." name-str)
         :type 'integer
         :group ',group-sym)

       (defcustom ,punct-sym nil
         ,(format "Non-nil means read punctuation aloud (%s backend)." name-str)
         :type 'boolean
         :group ',group-sym)

       (defcustom ,pre-silence-sym ,pre-silence
         ,(format "Silence before each sentence in ms (%s backend)." name-str)
         :type 'integer
         :group ',group-sym)

       (defcustom ,post-silence-sym ,post-silence
         ,(format "Silence after each sentence in ms (%s backend)." name-str)
         :type 'integer
         :group ',group-sym)

       (defcustom ,fade-sym ,fade
         ,(format "Fade-in/out duration in ms (%s backend)." name-str)
         :type 'integer
         :group ',group-sym)

       ;; Helper: return the static --custom-* flags.
       (defun ,flags-fn ()
         ,(format "Return the --custom-* CLI flags for the %s backend." name-str)
         (greader-rs-custom--build-flags ',spec))

       ;; Backend function.
       ;;;###autoload
       (defun ,fn-sym (command &optional arg)
         ,(format "greader backend function for greader-rs with custom %s engine.
COMMAND is a symbol; ARG depends on the command." name-str)
         (pcase command
           ('executable
            greader-rs-executable)
           ('backend-flag
            "--backend=custom")
           ('extra
            (append (,flags-fn)
                    (list ,@(when stdin-p '("--stdin"))
                          (format "--pre-silence=%d" ,pre-silence-sym)
                          (format "--post-silence=%d" ,post-silence-sym)
                          (format "--fade=%d" ,fade-sym))
                    (greader-rs-common-flags)))
           ('lang
            (if arg
                (progn
                  (setq-local ,lang-sym arg)
                  (concat "-v" arg))
              (when ,lang-sym
                (concat "-v" ,lang-sym))))
           ('rate
            (cond
             ((eq arg 'value) ,rate-sym)
             (arg
              (setq-local ,rate-sym arg)
              (concat "-s" (number-to-string arg)))
             (t
              (concat "-s" (number-to-string ,rate-sym)))))
           ('get-rate
            ,rate-sym)
           ('get-language
            ,lang-sym)
           ('punctuation
            ,(if punct-flag
                 `(pcase arg
                    ((or 'toggle 'yes 'no)
                     (setq-local ,punct-sym (not ,punct-sym))
                     (if ,punct-sym "--punct" nil))
                    ('nil
                     (when ,punct-sym "--punct")))
               'nil))
           ('set-voice
            ,(if list-voices-flag
                 `(with-temp-buffer
                    (apply #'call-process greader-rs-executable nil t nil
                           (append (,flags-fn) '("--list-voices")))
                    (goto-char (point-min))
                    (let (voices)
                      (while (not (eobp))
                        (let ((line (string-trim
                                     (buffer-substring-no-properties
                                      (line-beginning-position)
                                      (line-end-position)))))
                          (when (string-match "\\([^\t]+\\)" line)
                            (push (match-string 1 line) voices)))
                        (forward-line 1))
                      (completing-read "Voice: " (nreverse voices) nil t)))
               ''not-implemented))
           ('save-voice
            (customize-save-variable ',lang-sym arg))
           ('audio-write
            ,(if wav-flag
                 `(let ((text (car arg))
                        (filename (cadr arg)))
                    (apply #'call-process greader-rs-executable
                           nil "*greader-rs-output*" nil
                           (append
                            (,flags-fn)
                            (list
                             (concat "-s" (number-to-string ,rate-sym))
                             (concat "-v" ,lang-sym)
                             "-w" filename
                             text))))
               ''not-implemented))
           (_ 'not-implemented)))

       ;; Registration.
       (put ',fn-sym 'greader-backend-name ,prefix)
       (add-to-list 'greader-backends ',fn-sym t)

       ',fn-sym)))

(provide 'greader-rs-common)
;;; greader-rs-common.el ends here
