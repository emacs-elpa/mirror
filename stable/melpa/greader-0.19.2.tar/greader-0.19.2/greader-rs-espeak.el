;;; greader-rs-espeak.el --- greader backend using greader-rs with espeak-ng  -*- lexical-binding: t; -*-

;; Copyright (C) 2017-2026  Free Software Foundation, Inc.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;; greader backend that calls greader-rs with --backend=espeak.
;; greader-rs must be compiled and available; see `greader-rs-executable'.

;;; Code:

(require 'greader-rs-common)
(defvar greader-backends)

(defgroup greader-rs-espeak
  nil
  "greader backend: greader-rs espeak-ng engine."
  :group 'greader)

(defcustom greader-rs-espeak-language "en"
  "Default voice/language for the espeak-ng backend.
Pass any identifier accepted by espeak-ng (e.g. \"en\", \"it\", \"en/en-gb\")."
  :type 'string
  :tag "greader-rs espeak language")

(defcustom greader-rs-espeak-rate 175
  "Default speech rate in words per minute."
  :type 'integer
  :tag "greader-rs espeak rate")

(defcustom greader-rs-espeak-punctuation nil
  "Non-nil means read punctuation aloud."
  :type 'boolean
  :tag "greader-rs espeak punctuation")

(defcustom greader-rs-espeak-pre-silence 50
  "Silence prepended before each sentence, in milliseconds."
  :type 'integer
  :group 'greader-rs-espeak)

(defcustom greader-rs-espeak-post-silence 400
  "Silence appended after each sentence, in milliseconds."
  :type 'integer
  :group 'greader-rs-espeak)

(defcustom greader-rs-espeak-fade 10
  "Fade-in and fade-out duration, in milliseconds."
  :type 'integer
  :group 'greader-rs-espeak)

(defun greader-rs-espeak--list-voices ()
  "Return a list of voice identifiers.
Calls `greader-rs --backend espeak --list-voices'."
  (with-temp-buffer
    (call-process greader-rs-executable nil t nil
                  "--backend=espeak" "--list-voices")
    (goto-char (point-min))
    (let (voices)
      (while (not (eobp))
        (let ((line (string-trim (buffer-substring-no-properties
                                  (line-beginning-position)
                                  (line-end-position)))))
          ;; Lines are "identifier\tname"; we want the identifier.
          (when (string-match "\\([^\t]+\\)" line)
            (push (match-string 1 line) voices)))
        (forward-line 1))
      (nreverse voices))))

;;;###autoload
(defun greader-rs-espeak (command &optional arg)
  "greader backend function for greader-rs with the espeak-ng engine.
COMMAND is a symbol; ARG depends on the command."
  (pcase command
    ('executable
     greader-rs-executable)
    ('backend-flag
     "--backend=espeak")
    ('extra
     (append (list "--backend=espeak" "--stdin"
                   (format "--pre-silence=%d" greader-rs-espeak-pre-silence)
                   (format "--post-silence=%d" greader-rs-espeak-post-silence)
                   (format "--fade=%d" greader-rs-espeak-fade))
             (greader-rs-common-flags)))
    ('lang
     (if arg
         (progn
           (setq-local greader-rs-espeak-language arg)
           (concat "-v" arg))
       (when greader-rs-espeak-language
         (concat "-v" greader-rs-espeak-language))))
    ('rate
     (cond
      ((eq arg 'value) greader-rs-espeak-rate)
      (arg
       (setq-local greader-rs-espeak-rate arg)
       (concat "-s" (number-to-string arg)))
      (t
       (concat "-s" (number-to-string greader-rs-espeak-rate)))))
    ('get-rate
     greader-rs-espeak-rate)
    ('get-language
     (when greader-rs-espeak-language
       (let ((id greader-rs-espeak-language))
         ;; espeak identifiers: "it", "en", "roa/it", "en/en-gb".
         ;; Extract the 2-letter code after the last slash, or from
         ;; the start if no slash.
         (when (string-match "/\\([a-z]\\{2\\}\\)" id)
           (setq id (match-string 1 id)))
         (if (string-match "\\`\\([a-z]\\{2\\}\\)" id)
             (match-string 1 id)
           id))))
    ('punctuation
     (pcase arg
       ((or 'toggle 'yes 'no)
        (setq-local greader-rs-espeak-punctuation
                    (not greader-rs-espeak-punctuation))
        (if greader-rs-espeak-punctuation "--punct" nil))
       ('nil
        (when greader-rs-espeak-punctuation "--punct"))))
    ('set-voice
     (completing-read "Language: "
                      (greader-rs-espeak--list-voices) nil t))
    ('save-voice
     (customize-save-variable 'greader-rs-espeak-language arg))
    ('audio-write
     (let ((text (car arg))
           (filename (cadr arg)))
       (call-process greader-rs-executable
                     nil "*greader-rs-output*" nil
                     "--backend=espeak"
                     (concat "-s" (number-to-string greader-rs-espeak-rate))
                     (concat "-v" greader-rs-espeak-language)
                     "-w" filename
                     text)))
    (_ 'not-implemented)))

(put 'greader-rs-espeak 'greader-backend-name "greader-rs-espeak")

(add-to-list 'greader-backends 'greader-rs-espeak t)

(provide 'greader-rs-espeak)
;;; greader-rs-espeak.el ends here
