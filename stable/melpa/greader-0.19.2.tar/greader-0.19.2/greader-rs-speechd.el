;;; greader-rs-speechd.el --- greader backend using greader-rs with Speech Dispatcher  -*- lexical-binding: t; -*-

;; Copyright (C) 2017-2026  Free Software Foundation, Inc.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;; greader backend that calls greader-rs with --backend=speechd.
;; Requires greader-rs compiled with the `speechd' feature and a
;; running Speech Dispatcher daemon.

;;; Code:

(require 'greader-rs-common)
(defvar greader-backends)

(defgroup greader-rs-speechd
  nil
  "greader backend: greader-rs Speech Dispatcher engine."
  :group 'greader)

(defcustom greader-rs-speechd-voice ""
  "Default synthesis voice name for the Speech Dispatcher backend.
Empty string means use the Speech Dispatcher default."
  :type 'string
  :tag "greader-rs speechd voice")

(defcustom greader-rs-speechd-rate 175
  "Default speech rate in words per minute."
  :type 'integer
  :tag "greader-rs speechd rate")

(defcustom greader-rs-speechd-punctuation nil
  "Non-nil means read punctuation aloud."
  :type 'boolean
  :tag "greader-rs speechd punctuation")

(defvar-local greader-rs-speechd-language nil
  "2-letter ISO 639-1 language code for the current speechd voice.
Set automatically when a voice is selected via `set-voice'.")

(defun greader-rs-speechd--list-voices ()
  "Return an alist of (NAME . LANG) for voices from greader-rs speechd.
Lines from the binary are \"name\\tlanguage\"."
  (with-temp-buffer
    (call-process greader-rs-executable nil t nil
                  "--backend=speechd" "--list-voices")
    (goto-char (point-min))
    (let (voices)
      (while (not (eobp))
        (let ((line (string-trim (buffer-substring-no-properties
                                  (line-beginning-position)
                                  (line-end-position)))))
          (when (string-match "\\([^\t]+\\)\t\\([^\t]*\\)" line)
            (push (cons (match-string 1 line) (match-string 2 line))
                  voices)))
        (forward-line 1))
      (nreverse voices))))

;;;###autoload
(defun greader-rs-speechd (command &optional arg)
  "greader backend function for greader-rs with the Speech Dispatcher engine.
COMMAND is a symbol; ARG depends on the command."
  (pcase command
    ('executable
     greader-rs-executable)
    ('backend-flag
     "--backend=speechd")
    ('extra
     "--backend=speechd")
    ('lang
     (if arg
         (progn
           (setq-local greader-rs-speechd-voice arg)
           (concat "-v" arg))
       (when (and greader-rs-speechd-voice
                  (not (string-empty-p greader-rs-speechd-voice)))
         (concat "-v" greader-rs-speechd-voice))))
    ('rate
     (cond
      ((eq arg 'value) greader-rs-speechd-rate)
      (arg
       (setq-local greader-rs-speechd-rate arg)
       (concat "-s" (number-to-string arg)))
      (t
       (concat "-s" (number-to-string greader-rs-speechd-rate)))))
    ('get-rate
     greader-rs-speechd-rate)
    ('get-language
     (or greader-rs-speechd-language 'not-implemented))
    ('punctuation
     (pcase arg
       ((or 'toggle 'yes 'no)
        (setq-local greader-rs-speechd-punctuation
                    (not greader-rs-speechd-punctuation))
        (if greader-rs-speechd-punctuation "--punct" nil))
       ('nil
        (when greader-rs-speechd-punctuation "--punct"))))
    ('set-voice
     (let* ((voices (greader-rs-speechd--list-voices))
            (names (mapcar #'car voices))
            (chosen (completing-read "Voice: " names nil t))
            (lang (cdr (assoc chosen voices))))
       (setq-local greader-rs-speechd-language
                   (when (and lang (string-match "\\`\\([a-z]\\{2\\}\\)" lang))
                     (match-string 1 lang)))
       chosen))
    ('save-voice
     (customize-save-variable 'greader-rs-speechd-voice arg))
    ;; Speech Dispatcher does not support WAV file output.
    ('audio-write 'not-implemented)
    (_ 'not-implemented)))

(put 'greader-rs-speechd 'greader-backend-name "greader-rs-speechd")

(add-to-list 'greader-backends 'greader-rs-speechd t)

(provide 'greader-rs-speechd)
;;; greader-rs-speechd.el ends here
