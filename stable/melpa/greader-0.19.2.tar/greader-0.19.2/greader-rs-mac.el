;;; greader-rs-mac.el --- greader backend using greader-rs with AVSpeechSynthesizer  -*- lexical-binding: t; -*-

;; Copyright (C) 2017-2026  Free Software Foundation, Inc.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;; greader backend that calls greader-rs with --backend=mac.
;; Requires greader-rs compiled with the `mac' feature on macOS.
;; Uses AVSpeechSynthesizer in-process; no `say' binary is needed.

;;; Code:

(require 'greader-rs-common)
(defvar greader-backends)

(defgroup greader-rs-mac
  nil
  "greader backend: greader-rs AVSpeechSynthesizer engine (macOS)."
  :group 'greader)

(defcustom greader-rs-mac-voice nil
  "Default voice for the macOS AVSpeechSynthesizer backend.
nil means use the system default voice.
Set to a voice name (e.g. \"Alex\") or an AVSpeechSynthesisVoice
identifier (e.g. \"com.apple.voice.compact.it-IT.Alice\")."
  :type '(choice (const :tag "System default" nil)
                 (string :tag "Voice name or identifier"))
  :tag "greader-rs mac voice")

(defcustom greader-rs-mac-rate 185
  "Default speech rate in words per minute."
  :type 'integer
  :tag "greader-rs mac rate")

(defcustom greader-rs-mac-pre-silence 50
  "Silence prepended before each sentence, in milliseconds."
  :type 'integer
  :group 'greader-rs-mac)

(defcustom greader-rs-mac-post-silence 200
  "Silence appended after each sentence, in milliseconds."
  :type 'integer
  :group 'greader-rs-mac)

(defcustom greader-rs-mac-fade 1
  "Fade-in and fade-out duration, in milliseconds."
  :type 'integer
  :group 'greader-rs-mac)

(defun greader-rs-mac--extract-language (identifier)
  "Extract a 2-letter ISO 639-1 language code from a voice IDENTIFIER.
For example, \"com.apple.voice.compact.it-IT.Alice\" yields \"it\"."
  (when (and identifier
             (string-match "\\b\\([a-z]\\{2\\}\\)-[A-Z]\\{2\\}\\b" identifier))
    (match-string 1 identifier)))

(defun greader-rs-mac--voice-quality (identifier)
  "Extract a human-readable quality tag from a voice IDENTIFIER.
For example, \"com.apple.eloquence.it-IT.Reed\" yields \"Eloquence\",
\"com.apple.voice.premium.it-IT.Emma\" yields \"Premium\"."
  (cond
   ((string-match "com\\.apple\\.eloquence\\." identifier) "Eloquence")
   ((string-match "com\\.apple\\.voice\\.premium\\." identifier) "Premium")
   ((string-match "com\\.apple\\.voice\\.enhanced\\." identifier) "Enhanced")
   ((string-match "com\\.apple\\.voice\\.compact\\." identifier) "Compact")
   ((string-match "com\\.apple\\." identifier) "Apple")
   (t "Other")))

(defun greader-rs-mac--list-voices ()
  "Return an alist of (DISPLAY . IDENTIFIER) for all available voices.
DISPLAY is \"Name (locale, quality)\" for human readability; IDENTIFIER
is the AVSpeechSynthesisVoice identifier passed to `-v', which
unambiguously selects the voice.
Calls `greader-rs --backend mac --list-voices'."
  (with-temp-buffer
    (call-process greader-rs-executable nil t nil
                  "--backend=mac" "--list-voices")
    (goto-char (point-min))
    (let ((pairs (list (cons "system" "system"))))
      (while (not (eobp))
        (let ((line (string-trim (buffer-substring-no-properties
                                  (line-beginning-position)
                                  (line-end-position)))))
          ;; Lines are "name\tlocale\tidentifier".
          (when (string-match "\\([^\t]+\\)\t\\([^\t]+\\)\t\\(.+\\)" line)
            (let* ((name (match-string 1 line))
                   (lang (match-string 2 line))
                   (id   (match-string 3 line))
                   (quality (greader-rs-mac--voice-quality id)))
              (push (cons (format "%s (%s, %s)" name lang quality) id)
                    pairs))))
        (forward-line 1))
      (nreverse pairs))))

;;;###autoload
(defun greader-rs-mac (command &optional arg)
  "greader backend for greader-rs with the macOS AVSpeechSynthesizer engine.
COMMAND is a symbol; ARG depends on the command."
  (pcase command
    ('executable
     greader-rs-executable)
    ('backend-flag
     "--backend=mac")
    ('extra
     (append (list "--backend=mac" "--stdin"
                   (format "--pre-silence=%d" greader-rs-mac-pre-silence)
                   (format "--post-silence=%d" greader-rs-mac-post-silence)
                   (format "--fade=%d" greader-rs-mac-fade))
             (greader-rs-common-flags)))
    ('lang
     (if arg
         (progn
           (setq-local greader-rs-mac-voice
                       (if (equal arg "system") nil arg))
           (when greader-rs-mac-voice (concat "-v" greader-rs-mac-voice)))
       (when greader-rs-mac-voice
         (concat "-v" greader-rs-mac-voice))))
    ('rate
     (cond
      ((eq arg 'value) greader-rs-mac-rate)
      (arg
       (setq-local greader-rs-mac-rate arg)
       (concat "-s" (number-to-string arg)))
      (t
       (concat "-s" (number-to-string greader-rs-mac-rate)))))
    ('get-rate
     greader-rs-mac-rate)
    ('get-language
     (or (greader-rs-mac--extract-language greader-rs-mac-voice)
         'not-implemented))
    ('punctuation
     ;; AVSpeechSynthesizer has no punctuation control.
     nil)
    ('set-voice
     (let* ((voices (greader-rs-mac--list-voices))
            (display (completing-read "Voice: " voices nil t))
            (voice (cdr (assoc display voices))))
       (setq-local greader-rs-mac-voice
                   (if (equal voice "system") nil voice))
       voice))
    ('save-voice
     (customize-save-variable 'greader-rs-mac-voice arg))
    ('audio-write
     (let ((text (car arg))
           (filename (cadr arg))
           (extra-args
            (delq nil
                  (list (when greader-rs-mac-voice
                          (concat "-v" greader-rs-mac-voice))))))
       (apply #'call-process greader-rs-executable
              nil "*greader-rs-output*" nil
              "--backend=mac"
              (concat "-s" (number-to-string greader-rs-mac-rate))
              (append extra-args (list "-w" filename text)))))
    (_ 'not-implemented)))

(put 'greader-rs-mac 'greader-backend-name "greader-rs-mac")

(add-to-list 'greader-backends 'greader-rs-mac t)

(provide 'greader-rs-mac)
;;; greader-rs-mac.el ends here
