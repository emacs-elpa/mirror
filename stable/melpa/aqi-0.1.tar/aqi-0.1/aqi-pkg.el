;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aqi" "0.1"
  "Air quality data from the World Air Quality Index."
  '((emacs     "25.1")
    (request   "0.3")
    (let-alist "0.0"))
  :url "https://github.com/zzkt/aqi"
  :commit "31bfbefa91a0414b722ac2cfe83db07eb18389e8"
  :revdesc "31bfbefa91a0"
  :keywords '("air quality" "aqi" "pollution" "weather" "data")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
