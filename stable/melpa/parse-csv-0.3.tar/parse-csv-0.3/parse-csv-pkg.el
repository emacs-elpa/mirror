;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parse-csv" "0.3"
  "Parse strings with CSV fields into s-expressions."
  ()
  :url "https://github.com/mrc/el-csv"
  :commit "dc31201af8868aa98f055de055ee7aa5fae266dd"
  :revdesc "dc31201af886"
  :keywords '("csv")
  :authors '(("Matt Curtis" . "matt.r.curtis@gmail.com"))
  :maintainers '(("Matt Curtis" . "matt.r.curtis@gmail.com")))
