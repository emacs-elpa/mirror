;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-pollen" "0.2"
  "Company-mode completion backend for pollen."
  '((company "0.9.0"))
  :url "https://github.com/lijunsong/pollen-mode"
  :commit "0383ccba353af5e5536afcaedefc0e20191686ae"
  :revdesc "0383ccba353a"
  :keywords '("languages" "pollen" "pollenpub" "company")
  :authors '(("Junsong Li" . "ljs.darkfishATGMAIL")))
