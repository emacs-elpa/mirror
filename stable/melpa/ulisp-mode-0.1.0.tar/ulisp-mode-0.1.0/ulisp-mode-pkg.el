;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ulisp-mode" "0.1.0"
  "Major mode for editing and evaluate uLisp."
  '((emacs "25.1"))
  :url "https://github.com/deadblackclover/ulisp-mode"
  :commit "7951c886c5d276cd038bba7c2dc22b4414dad919"
  :revdesc "7951c886c5d2"
  :keywords '("languages")
  :authors '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com"))
  :maintainers '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com")))
