;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "system-idle" "0.3.0"
  "Poll the system-wide idle time."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/system-idle"
  :commit "598445de14924258f6a3a63cbc8b4cef10dee9d1"
  :revdesc "0.3.0-0-g598445de1492"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
