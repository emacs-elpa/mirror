;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwim-shell-command" "0.62.2"
  "Shell commands with DWIM behaviour."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/dwim-shell-command"
  :commit "7d1c45aa2bc782c448cadd989dc776c2e5f83514"
  :revdesc "7d1c45aa2bc7")
