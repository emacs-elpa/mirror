;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-dashboard" "1.0"
  "[No description available]."
  ()
  :url "https://github.com/bard/org-dashboard"
  :commit "e9a0d7a533142a0a070827cdad6946df4f1370d2"
  :revdesc "e9a0d7a53314"
  :keywords '("outlines" "calendar")
  :authors '(("Massimiliano Mirra" . "hyperstruct@gmail.com"))
  :maintainers '(("Massimiliano Mirra" . "hyperstruct@gmail.com")))
