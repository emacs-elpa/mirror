;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "0.1.0"
  "Sayid nREPL middleware client."
  '((cider "0.21.0"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "985837897ca6f9bc5f1d1b1414ad15554a60d3b3"
  :revdesc "985837897ca6"
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bill Piel" . "bill@billpiel.com")))
