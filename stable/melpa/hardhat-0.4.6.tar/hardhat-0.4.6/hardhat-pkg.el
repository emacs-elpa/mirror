;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hardhat" "0.4.6"
  "Protect against clobbering user-writable files."
  '((ignoramus "0.7.0"))
  :url "https://github.com/rolandwalker/hardhat"
  :commit "9038a49ab55cd4c502cf7f07ed0d1b9b6bc3626e"
  :revdesc "v0.4.6-0-g9038a49ab55c"
  :keywords '("convenience")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
