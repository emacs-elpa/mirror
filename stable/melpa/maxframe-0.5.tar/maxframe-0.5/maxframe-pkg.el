;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maxframe" "0.5"
  "[No description available]."
  ()
  :url "https://github.com/rmm5t/maxframe.el"
  :commit "4f1dbbe68048864037eae277b9280b90fd701ff1"
  :revdesc "4f1dbbe68048"
  :keywords '("display" "frame" "window" "maximize"))
