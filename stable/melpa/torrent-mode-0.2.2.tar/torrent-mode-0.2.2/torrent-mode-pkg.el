;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "torrent-mode" "0.2.2"
  "Display torrent files in a tabulated view."
  '((emacs     "26.1")
    (tablist   "1.0")
    (bencoding "1.0"))
  :url "https://github.com/sarg/torrent-mode.el"
  :commit "a35a7c193b638207de0a266e8ded6e4e8a54505e"
  :revdesc "a35a7c193b63"
  :authors '(("Sergey Trofimov" . "sarg@sarg.org.ru"))
  :maintainers '(("Sergey Trofimov" . "sarg@sarg.org.ru")))
