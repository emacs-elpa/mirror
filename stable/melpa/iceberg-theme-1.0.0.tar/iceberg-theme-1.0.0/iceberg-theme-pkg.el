;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iceberg-theme" "1.0.0"
  "Well-designed, eye-friendly, dark blue color scheme."
  '((emacs           "26.1")
    (solarized-theme "1.3"))
  :url "https://github.com/conao3/iceberg-theme.el"
  :commit "04b8d04c30276a471b37ff93d73409508e88d295"
  :revdesc "04b8d04c3027"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
