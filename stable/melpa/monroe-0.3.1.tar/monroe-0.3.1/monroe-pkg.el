;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monroe" "0.3.1"
  "Yet another client for nREPL."
  ()
  :url "http://www.github.com/sanel/monroe"
  :commit "0b9b043f042145bf62969add7ec476ea51da7cbd"
  :revdesc "0b9b043f0421"
  :keywords '("languages" "clojure" "nrepl" "lisp")
  :authors '(("Sanel Zukan" . "sanelz@gmail.com"))
  :maintainers '(("Sanel Zukan" . "sanelz@gmail.com")))
