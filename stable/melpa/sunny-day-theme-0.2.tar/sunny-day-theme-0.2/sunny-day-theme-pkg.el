;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sunny-day-theme" "0.2"
  "Emacs24 theme with a light background."
  ()
  :url "https://github.com/mswift42/sunny-day-theme"
  :commit "3bfaf75f8ae66b1db16990378cf3e4aca88dd48d"
  :revdesc "3bfaf75f8ae6")
