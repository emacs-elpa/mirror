;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "platformio-mode" "0.3.0"
  "PlatformIO integration."
  '((emacs      "25.1")
    (async      "1.9.0")
    (projectile "0.13.0"))
  :url "https://github.com/zachmassia/platformio-mode"
  :commit "e7bde6fec31b57ffe1c0a98cd29477d5baea30f3"
  :revdesc "e7bde6fec31b"
  :authors '(("Zach Massia" . "zmassia@gmail.com")
             ("Dante Catalfamo" . "dante@lambda.cx"))
  :maintainers '(("Zach Massia" . "zmassia@gmail.com")
                 ("Dante Catalfamo" . "dante@lambda.cx")))
