;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "req-package" "1.2"
  "A use-package wrapper for package runtime dependencies management."
  '((use-package "1.0")
    (dash        "2.7.0")
    (log4e       "0.2.0")
    (ht          "0"))
  :url "https://github.com/edvorg/req-package"
  :commit "0c0ac7451149dac6bfda2adfe959d1df1c273de6"
  :revdesc "0c0ac7451149"
  :keywords '("dotemacs" "startup" "speed" "config" "package")
  :authors '(("Edward Knyshov" . "edvorg@gmail.com"))
  :maintainers '(("Edward Knyshov" . "edvorg@gmail.com")))
