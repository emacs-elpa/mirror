;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-superstar" "1.6.0"
  "Prettify headings and plain lists in Org mode."
  '((org   "9.1.9")
    (emacs "26.1"))
  :url "https://github.com/integral-dw/org-superstar-mode"
  :commit "6320fc8be629a2e79b46f2271061d3503f65ff1d"
  :revdesc "6320fc8be629"
  :keywords '("faces" "outlines")
  :authors '(("D. Williams" . "d.williams@posteo.net"))
  :maintainers '(("D. Williams" . "d.williams@posteo.net")))
