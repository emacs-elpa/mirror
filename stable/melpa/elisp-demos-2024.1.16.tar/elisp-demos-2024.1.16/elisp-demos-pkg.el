;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-demos" "2024.1.16"
  "Elisp API Demos."
  '((emacs "24.4"))
  :url "https://github.com/xuchunyang/elisp-demos"
  :commit "bf22eddd42c8fcc52648d2cafd842f120d4dc591"
  :revdesc "bf22eddd42c8"
  :keywords '("lisp" "docs"))
