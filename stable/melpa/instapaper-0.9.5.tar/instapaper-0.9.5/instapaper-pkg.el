;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "instapaper" "0.9.5"
  "[No description available]."
  ()
  :url "htts://bitbucket.org/jfm/emacs-instapaper"
  :commit "4714ed1b014615f8213e6f93637e4ec1d9d5a37a"
  :revdesc "4714ed1b0146"
  :authors '(("Jason F. McBrayer" . "jmcbray@carcosa.net"))
  :maintainers '(("Jason F. McBrayer" . "jmcbray@carcosa.net")))
