;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-at-point" "0.1"
  "Context sensitive project search."
  '((emacs   "26.2")
    (counsel "0.13.0"))
  :url "https://gitlab.com/ideasman42/emacs-counsel-at-point"
  :commit "942cf8e5475c10c80b69f6ac38feecf4137fba6b"
  :revdesc "942cf8e5475c"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
