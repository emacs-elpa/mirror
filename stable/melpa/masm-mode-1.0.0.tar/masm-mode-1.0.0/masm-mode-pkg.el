;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "masm-mode" "1.0.0"
  "[No description available]."
  '((emacs "24.3"))
  :url "https://github.com/YiGeeker/masm-mode"
  :commit "2fc35aac925ad1bbdaabe71ff7907b584f231d3a"
  :revdesc "2fc35aac925a"
  :authors '(("YiGeeker" . "zyfchinese@yeah.net"))
  :maintainers '(("YiGeeker" . "zyfchinese@yeah.net")))
