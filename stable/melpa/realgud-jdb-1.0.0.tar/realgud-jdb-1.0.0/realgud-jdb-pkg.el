;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-jdb" "1.0.0"
  "Realgud front-end to older nodejs \"node debug\"."
  '((realgud       "1.4.5")
    (load-relative "1.2")
    (cl-lib        "0.5")
    (emacs         "25"))
  :url "https://github.com/realgud/realgud-jdb"
  :commit "8b0f1e01b8744b8a461fd12b0a228c382265b506"
  :revdesc "8b0f1e01b874"
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
