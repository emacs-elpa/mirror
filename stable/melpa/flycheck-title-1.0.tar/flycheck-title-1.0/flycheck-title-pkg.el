;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-title" "1.0"
  "Show flycheck errors in the frame title."
  '((flycheck "30")
    (emacs    "24"))
  :url "https://github.com/Wilfred/flycheck-title"
  :commit "2b7a11c39420e517a07d0c95126455c1617f2c61"
  :revdesc "2b7a11c39420"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
