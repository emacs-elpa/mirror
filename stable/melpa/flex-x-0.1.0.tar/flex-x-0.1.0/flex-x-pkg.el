;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-x" "0.1.0"
  "Extended flex completion style."
  '((emacs "30.1"))
  :url "https://github.com/nobu43/flex-x"
  :commit "a27218727bbd54194bc11b4fdc4dafd9abd2f19c"
  :revdesc "a27218727bbd"
  :keywords '("convenience" "matching"))
