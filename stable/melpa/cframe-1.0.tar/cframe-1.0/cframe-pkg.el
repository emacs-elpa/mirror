;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cframe" "1.0"
  "Customize a frame and fast switch size and positions."
  '((emacs         "26")
    (buffer-manage "0.11")
    (dash          "2.17.0"))
  :url "https://github.com/plandes/cframe"
  :commit "d0f8b36cce8a9f2e1caa373e8c336c16d092c2ad"
  :revdesc "v1.0-0-gd0f8b36cce8a"
  :keywords '("frames"))
