;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aas" "1.1"
  "Snippet expansions mid-typing."
  '((emacs "26.3"))
  :url "https://github.com/ymarco/auto-activating-snippets"
  :commit "5d83f76823bc0b86d5270277b57a627f3af427a1"
  :revdesc "5d83f76823bc"
  :keywords '("abbrev" "tools")
  :authors '(("Yoav Marco" . "yoavm448@gmail.com"))
  :maintainers '(("Yoav Marco" . "yoavm448@gmail.com")))
