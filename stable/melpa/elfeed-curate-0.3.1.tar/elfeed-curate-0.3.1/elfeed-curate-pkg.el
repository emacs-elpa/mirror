;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-curate" "0.3.1"
  "Elfeed entry curation."
  '((emacs  "27.1")
    (elfeed "3.4.1"))
  :url "https://github.com/rnadler/elfeed-curate"
  :commit "e56c24eda719f0c827955ae555bce702e1c74db0"
  :revdesc "v0.3.1-0-ge56c24eda719"
  :keywords '("news")
  :authors '(("Robert Nadler" . "robert.nadler@gmail.com"))
  :maintainers '(("Robert Nadler" . "robert.nadler@gmail.com")))
