;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-nix" "0.1"
  "Simple org-babel support for nix."
  ()
  :url "https://codeberg.org/theesm/ob-nix"
  :commit "442eb04bc1d17f14c96fdecdb2ebe068235183b2"
  :revdesc "442eb04bc1d1"
  :keywords '("literate programming" "nix")
  :authors '(("Wilko Meyer" . "w-devel@wmeyer.eu"))
  :maintainers '(("Wilko Meyer" . "w-devel@wmeyer.eu")))
