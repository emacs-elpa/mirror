;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-switcher" "1.1.0"
  "Provide fast switching between shell buffers."
  '((emacs "24"))
  :url "https://github.com/DamienCassou/shell-switcher"
  :commit "4c96dc27afb519bdbf7bbe42d49a51497f078192"
  :revdesc "v1.1.0-0-g4c96dc27afb5"
  :keywords '("emacs" "package" "elisp" "shell" "eshell" "term" "switcher")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
