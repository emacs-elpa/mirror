;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-z" "0.1"
  "Show z directory list with helm.el support."
  '((helm "1.0"))
  :url "https://github.com/zonkyy/helm-z"
  :commit "295b354c86734b9e02dc8cef09a79e5372ec08e5"
  :revdesc "295b354c8673"
  :keywords '("helm" "dired" "z")
  :authors '(("yynozk" . "yynozk@gmail.com"))
  :maintainers '(("yynozk" . "yynozk@gmail.com")))
