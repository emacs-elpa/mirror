;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slideview" "0.6.1"
  "File slideshow."
  ()
  :url "https://github.com/mhayashi1120/Emacs-slideview/raw/master/slideview.el"
  :commit "ec2340e7b0e74201206d14e3eaef1e77149f122d"
  :revdesc "ec2340e7b0e7"
  :keywords '("files")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
