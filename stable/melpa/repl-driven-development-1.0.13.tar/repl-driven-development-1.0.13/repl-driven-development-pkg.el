;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repl-driven-development" "1.0.13"
  "Send arbitrary code to a REPL in the background."
  '((s              "1.12.0")
    (f              "0.20.0")
    (lf             "1.0")
    (dash           "2.16.0")
    (eros           "0.1.0")
    (bind-key       "2.4.1")
    (emacs          "29")
    (f              "0.20.0")
    (devdocs        "0.5")
    (pulsar         "1.0.1")
    (peg            "1.0.1")
    (hierarchy      "0.6.0")
    (json-navigator "0.1.1"))
  :url "http://alhassy.com/repl-driven-development"
  :commit "8877f692112459095649735ac4d023248b3905ae"
  :revdesc "8877f6921124"
  :keywords '("repl-driven-development" "rdd" "repl" "lisp" "eval" "java" "python" "ruby" "programming" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
