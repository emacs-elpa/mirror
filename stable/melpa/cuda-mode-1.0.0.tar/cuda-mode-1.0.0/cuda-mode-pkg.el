;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cuda-mode" "1.0.0"
  "NVIDIA CUDA Major Mode."
  ()
  :url "https://github.com/chachi/cuda-mode"
  :commit "c8cf7d92b8039cdd0bd525c258ab42f49a0f91cf"
  :revdesc "1.0.0-0-gc8cf7d92b803"
  :keywords '("c" "languages")
  :authors '(("Jack Morrison" . "jackmorrison1@gmail.com"))
  :maintainers '(("Jack Morrison" . "jackmorrison1@gmail.com")))
