;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-consult" "1.0"
  "Consult integration for zk."
  '((emacs   "27.1")
    (zk      "0.4")
    (consult "0.14"))
  :url "https://github.com/localauthor/zk"
  :commit "ad82465a4a65fba7cff07da419455947507080cc"
  :revdesc "ad82465a4a65"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
