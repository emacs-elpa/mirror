;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-msg-prefix" "0.1.0"
  "Insert commit message prefix (issue number)."
  '((emacs "24")
    (s     "1.10.0")
    (dash  "2.9.0"))
  :url "https://github.com/kidd/git-msg-prefix.el"
  :commit "c6acf10b014607f1541a398206208e568a4714e4"
  :revdesc "c6acf10b0146"
  :keywords '("vc" "tools")
  :authors '(("Raimon Grau" . "raimonster@gmail.com"))
  :maintainers '(("Raimon Grau" . "raimonster@gmail.com")))
