;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-grammarly" "0.2.3"
  "Grammarly support for Flycheck."
  '((emacs     "25.1")
    (flycheck  "0.14")
    (grammarly "0.3.0"))
  :url "https://github.com/jcs-elpa/flycheck-grammarly"
  :commit "64e8ffc0ddf05586398a49ae2ad5704cae6eb4c8"
  :revdesc "64e8ffc0ddf0"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
