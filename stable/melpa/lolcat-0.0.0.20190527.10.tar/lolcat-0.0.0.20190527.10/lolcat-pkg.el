;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lolcat" "0.0.0.20190527.10"
  "Rainbows and unicorns!."
  '((emacs "24.3"))
  :url "https://github.com/xuchunyang/lolcat.el"
  :commit "4855e587a3b9681c077dac4b9f166dd860f439a4"
  :revdesc "4855e587a3b9"
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
