;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertica" "0.1.0"
  "Vertica SQL mode extension."
  '((sql "3.0"))
  :url "https://github.com/r0man/vertica-el"
  :commit "3fbcb7d63c3c3e2a70ab122b9e3d7467e8d68982"
  :revdesc "3fbcb7d63c3c"
  :keywords '("sql" "vertica")
  :authors '(("Roman Scherer" . "roman@burningswell.com"))
  :maintainers '(("Roman Scherer" . "roman@burningswell.com")))
