;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mutype" "0.1.0"
  "Type into stillness."
  '((emacs "25.1"))
  :url "https://github.com/suxiaogang223/mutype"
  :commit "74e59fece04af2a27f965c3ef1e5ed863eecf2b3"
  :revdesc "v0.1.0-0-g74e59fece04a"
  :keywords '("convenience" "typing"))
