;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projector" "0.3.3"
  "Lightweight library for managing project-aware shell and command buffers."
  '((alert  "1.1")
    (cl-lib "0.5"))
  :url "https://github.com/waymondo/projector.el"
  :commit "1d0f2d307591ea50888d31dcae7e463e2ada1316"
  :revdesc "1d0f2d307591"
  :authors '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainers '(("Justin Talbott" . "justin@waymondo.com")))
