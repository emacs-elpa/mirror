;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jg-quicknav" "1.4.0"
  "Quickly navigate the file system to find a file."
  '((s      "1.9.0")
    (cl-lib "0.5"))
  :url "https://github.com/jeffgran/jg-quicknav"
  :commit "989e9f7748d9bc315f87a04606dc97fb9a0c0290"
  :revdesc "989e9f7748d9"
  :keywords '("navigation")
  :authors '(("Jeff Gran" . "jeff@jeffgran.com"))
  :maintainers '(("Jeff Gran" . "jeff@jeffgran.com")))
