;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcache" "0.5.1"
  "Persistent caching for Emacs."
  '((emacs "25.1"))
  :url "https://github.com/sigma/pcache"
  :commit "e2f17133e624237f852a3b8c0d7c136252cb8c1a"
  :revdesc "e2f17133e624"
  :keywords '("extensions")
  :authors '(("Yann Hodique" . "yann.hodique@gmail.com"))
  :maintainers '(("Yann Hodique" . "yann.hodique@gmail.com")))
