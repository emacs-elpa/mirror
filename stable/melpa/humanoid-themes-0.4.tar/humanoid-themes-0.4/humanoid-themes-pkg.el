;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "humanoid-themes" "0.4"
  "Color themes with a dark and light variant."
  '((emacs "27.1"))
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes"
  :commit "7dd4fe1211e0af187ae9ad4db6d5bea9e3e944f9"
  :revdesc "0.4-0-g7dd4fe1211e0"
  :keywords '("faces" "color" "theme"))
