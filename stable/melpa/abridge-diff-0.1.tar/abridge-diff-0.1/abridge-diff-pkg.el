;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abridge-diff" "0.1"
  "[No description available]."
  ()
  :url "https://github.com/jdtsmith/abridge-diff"
  :commit "449f0d688f3ee44e53f3c9b62595022c5aad8cc7"
  :revdesc "449f0d688f3e")
