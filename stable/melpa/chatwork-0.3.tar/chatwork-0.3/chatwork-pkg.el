;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatwork" "0.3"
  "ChatWork client for Emacs."
  ()
  :url "https://github.com/ataka/chatwork"
  :commit "fea231d479f06bf40dbfcf45de143eecc9ed744c"
  :revdesc "0.3-0-gfea231d479f0"
  :keywords '("web")
  :authors '(("Masayuki Ataka" . "masayuki.ataka@gmail.com"))
  :maintainers '(("Masayuki Ataka" . "masayuki.ataka@gmail.com")))
