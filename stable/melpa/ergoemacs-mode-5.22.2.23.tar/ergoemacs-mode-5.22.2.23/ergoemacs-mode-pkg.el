;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ergoemacs-mode" "5.22.2.23"
  "Emacs mode based on common modern interface and ergonomics."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/ergoemacs/ergoemacs-mode"
  :commit "757475874a840f99b20c56182c7199257b6ae477"
  :revdesc "757475874a84"
  :keywords '("convenience")
  :authors '(("Xah Lee" . "xah@xahlee.org")
             ("David Capello" . "davidcapello@gmail.com")
             ("Matthew L. Fidler" . "matthew.fidler@gmail.com")
             ("Kim F. Storm -- CUA approach for C-x and C-c" . "storm@cua.dk"))
  :maintainers '(("Matthew L. Fidler" . "matthew.fidler@gmail.com")))
