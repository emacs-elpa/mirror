;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autumn-light-theme" "1.0.0"
  "A light color theme with muted, autumnal colors."
  ()
  :url "https://github.com/aalpern/emacs-color-theme-autumn-light"
  :commit "652c79880981d4b5b0ff97387f43355adc89bd8a"
  :revdesc "652c79880981"
  :keywords '("color" "theme")
  :authors '(("Adam Alpern" . "adam.alpern@gmail.com"))
  :maintainers '(("Adam Alpern" . "adam.alpern@gmail.com")))
