;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-toggle" "0.1.5"
  "Show dired as sidebar and will not create new buffers when changing dir."
  ()
  :url "https://github.com/fasheng/dired-toggle"
  :commit "5bcdd9f13c0b0149c5125004e93bc2dfd22f3fce"
  :revdesc "5bcdd9f13c0b"
  :keywords '("dired" "sidebar")
  :authors '(("Xu FaSheng" . "fasheng.xu@gmail.com")))
