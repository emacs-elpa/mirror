;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.2"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "84c9d9a9685f07b6988a618f11920ca063474fc8"
  :revdesc "84c9d9a9685f"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
