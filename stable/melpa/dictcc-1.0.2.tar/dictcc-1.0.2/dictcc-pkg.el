;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dictcc" "1.0.2"
  "Look up translations on dict.cc."
  '((emacs  "24.4")
    (cl-lib "0.5")
    (ivy    "0.10.0"))
  :url "https://github.com/martenlienen/dictcc.el"
  :commit "33df7c64ee5bb9faf77a4b80cd123d35a15ad706"
  :revdesc "33df7c64ee5b"
  :keywords '("convenience")
  :authors '(("Marten Lienen" . "marten.lienen@gmail.com"))
  :maintainers '(("Marten Lienen" . "marten.lienen@gmail.com")))
