;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient-extras-a2ps" "0.1.0"
  "A transient interface to a2ps."
  '((emacs "28.0"))
  :url "https://git.sr.ht/~swflint/transient-extras-a2ps"
  :commit "9eb875f875b8708975060fa5c85b1e2812361267"
  :revdesc "9eb875f875b8"
  :keywords '("printer" "transient" "syntax-highlighting")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
