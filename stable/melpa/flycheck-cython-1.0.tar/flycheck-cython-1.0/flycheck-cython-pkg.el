;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-cython" "1.0"
  "Support Cython in flycheck."
  '((flycheck "0.26"))
  :url "https://github.com/lbolla/emacs-flycheck-cython"
  :commit "2d4c1eebaac13ce2a4101ca0a9a38e35db6fab20"
  :revdesc "2d4c1eebaac1"
  :authors '(("Lorenzo Bolla" . "lbolla@gmail.com"))
  :maintainers '(("Lorenzo Bolla" . "lbolla@gmail.com")))
