;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-fetch" "4.0.0"
  "Show system information in Neofetch-like style (eg CPU, RAM)."
  '((emacs "25.1"))
  :url "https://gitlab.com/xgqt/emacs-el-fetch"
  :commit "a1ae3704de96e6d622a67faacfae7a5993f96699"
  :revdesc "4.0.0-0-ga1ae3704de96"
  :keywords '("games")
  :authors '(("Maciej Barć" . "xgqt@xgqt.org"))
  :maintainers '(("Maciej Barć" . "xgqt@xgqt.org")))
