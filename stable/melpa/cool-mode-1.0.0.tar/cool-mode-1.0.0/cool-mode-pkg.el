;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cool-mode" "1.0.0"
  "Major mode for cool compiler language."
  '((emacs "25"))
  :url "https://github.com/nverno/cool-mode"
  :commit "e53d351903ad0e394ee636efafb47214655712f0"
  :revdesc "e53d351903ad"
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
