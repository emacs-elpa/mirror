;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ignoramus" "0.7.4"
  "Ignore backups, build files, et al."
  ()
  :url "https://github.com/rolandwalker/ignoramus"
  :commit "00385fcd0d42de3a470f61c1fdbe7e19fbef9c5b"
  :revdesc "v0.7.4-0-g00385fcd0d42"
  :keywords '("convenience" "tools")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
