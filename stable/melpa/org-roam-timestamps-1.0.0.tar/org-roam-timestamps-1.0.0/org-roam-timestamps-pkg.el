;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-timestamps" "1.0.0"
  "Keep track of modification times for org-roam."
  '((emacs    "26.1")
    (org-roam "2.0.0"))
  :url "https://github.com/thomas/org-roam-timestamps"
  :commit "7f01f56faaa40b9dff49abfed9d96dc21c489b31"
  :revdesc "7f01f56faaa4"
  :keywords '("calendar" "outlines" "files")
  :authors '(("Thomas F. K. Jorna" . "https://github.com/thomas"))
  :maintainers '(("Thomas F. K. Jorna" . "jorna@jtrialerror.com")))
