;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "essgd" "0.1"
  "Show R plots from ESS within a buffer."
  '((websocket "1.15")
    (ess       "24.1.1")
    (emacs     "29.1"))
  :url "https://github.com/sje30/essgd"
  :commit "b4aa0edf72ce56f16e5605c35aaf2f2ef67e5358"
  :revdesc "b4aa0edf72ce"
  :authors '(("Stephen Eglen" . "sje30@cam.ac.uk"))
  :maintainers '(("Stephen Eglen" . "sje30@cam.ac.uk")))
