;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-anki" "4.0.5"
  "Synchronize org-mode entries to Anki."
  '((emacs   "27.1")
    (request "0.3.2")
    (dash    "2.17")
    (promise "1.1"))
  :url "https://github.com/eyeinsky/org-anki"
  :commit "fa5e66fc96a25477780b13cec1fca391260da81e"
  :revdesc "fa5e66fc96a2"
  :keywords '("outlines" "flashcards" "memory")
  :authors '(("Markus Läll" . "markus.l2ll@gmail.com"))
  :maintainers '(("Markus Läll" . "markus.l2ll@gmail.com")))
