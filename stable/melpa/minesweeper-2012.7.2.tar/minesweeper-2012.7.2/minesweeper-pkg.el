;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minesweeper" "2012.7.2"
  "Play minesweeper in Emacs."
  ()
  :url "https://bitbucket.org/zck/minesweeper.el"
  :commit "a0f3f5f731ec227b7e8ef43e85ed8d79b83c839d"
  :revdesc "a0f3f5f731ec"
  :keywords '("game" "fun" "minesweeper" "inane" "diversion")
  :authors '(("Zachary Kanfer" . "zkanfer@gmail.com"))
  :maintainers '(("Zachary Kanfer" . "zkanfer@gmail.com")))
