;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nocomments-mode" "0.1.3"
  "Minor mode that makes comments invisible."
  ()
  :url "https://github.com/Lindydancer/nocomments-mode"
  :commit "aaa9ef1042e0084fb774b3ee4274e1f8edb4d35e"
  :revdesc "aaa9ef1042e0")
