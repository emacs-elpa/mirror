;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iplayer" "0.1"
  "Browse and download BBC TV/radio shows."
  ()
  :url "https://github.com/csrhodes/iplayer-el"
  :commit "48b664e36e1a8e37eeb3eee80b91ff7126ed449a"
  :revdesc "v0.1-0-g48b664e36e1a"
  :keywords '("multimedia" "bbc")
  :authors '(("Christophe Rhodes" . "csr21@cantab.net"))
  :maintainers '(("Christophe Rhodes" . "csr21@cantab.net")))
