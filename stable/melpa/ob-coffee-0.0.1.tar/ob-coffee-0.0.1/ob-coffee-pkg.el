;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-coffee" "0.0.1"
  "Org-babel functions for coffee-script evaluation."
  '((org "8"))
  :url "https://github.com/zweifisch/ob-coffee"
  :commit "940cc2db1f5eae8763e9df5dbbd419699c35dee2"
  :revdesc "940cc2db1f5e"
  :keywords '("org" "babel" "coffee-script")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
