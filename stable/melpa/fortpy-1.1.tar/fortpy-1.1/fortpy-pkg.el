;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fortpy" "1.1"
  "A Fortran auto-completion for Emacs."
  '((epc                "0.1.0")
    (auto-complete      "1.4")
    (python-environment "0.0.2")
    (pos-tip            "0.4.5"))
  :url "https://github.com/rosenbrockc/fortpy-el"
  :commit "ca240bc40041eba3a95f29e49c582f5080ae2f46"
  :revdesc "ca240bc40041"
  :authors '(("Conrad Rosenbrock" . "rosenbrockcatgmail.com"))
  :maintainers '(("Conrad Rosenbrock" . "rosenbrockcatgmail.com")))
