;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xml+" "0.0.0"
  "Utilities for xml and html trees."
  '((cl   "0")
    (dash "0"))
  :url "https://github.com/bddean/xml-plus"
  :commit "e6a4944ee474396dd058379997d6712a1c16a458"
  :revdesc "e6a4944ee474"
  :keywords '("xml" "html")
  :authors '(("Ben Dean" . "bendean837@gmail.com"))
  :maintainers '(("Ben Dean" . "bendean837@gmail.com")))
