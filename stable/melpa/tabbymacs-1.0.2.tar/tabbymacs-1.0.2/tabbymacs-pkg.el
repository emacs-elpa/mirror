;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabbymacs" "1.0.2"
  "Inline AI code completions via Tabby LSP."
  '((emacs "28.1"))
  :url "https://github.com/Bastillan/tabbymacs"
  :commit "32b8c40774515c940a02c78874cf928b356478de"
  :revdesc "32b8c4077451"
  :keywords '("tools" "languages" "inline completions" "tabby" "llm")
  :authors '(("Jędrzej Kędzierski" . "kedzierski.jedrzej@gmail.com"))
  :maintainers '(("Jędrzej Kędzierski" . "kedzierski.jedrzej@gmail.com")))
