;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.98.4"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.3")
    (acp         "0.20.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "426d57ee074de89432ecf8b41a7b71a9ec685c37"
  :revdesc "426d57ee074d")
