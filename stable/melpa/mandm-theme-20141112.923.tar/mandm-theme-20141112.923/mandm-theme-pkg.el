;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mandm-theme" "20141112.923"
  "An mandm pastel color theme for Emacs."
  ()
  :url "https://github.com/bbatsov/mandm-emacs"
  :commit "163ac2a2c23fe2e5ab44239d3b428815afe6d310"
  :revdesc "163ac2a2c23f"
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
