;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "litable" "0.0.0.20240321.82"
  "Dynamic evaluation replacement with emacs."
  '((dash "2.6.0"))
  :url "https://github.com/Fuco1/litable"
  :commit "b83b1283ea6642ab82f536f1f3b280160404ff6b"
  :revdesc "b83b1283ea66"
  :keywords '("lisp")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
