;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-tail" "0.1.0"
  "Read recent output from various sources."
  '((emacs "25.1")
    (helm  "2.7.0"))
  :url "https://github.com/akirak/helm-tail"
  :commit "1b5a492ac9d0a896d1c7304d4b73d329934136c0"
  :revdesc "1b5a492ac9d0"
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
