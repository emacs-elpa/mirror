;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-symbol" "1.3"
  "Automatic and manual symbol highlighting."
  ()
  :url "http://nschum.de/src/emacs/highlight-symbol/"
  :commit "6136dac6d4328c19077a838dfbae2efc4caa4db2"
  :revdesc "1.3-0-g6136dac6d432"
  :keywords '("faces" "matching")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
