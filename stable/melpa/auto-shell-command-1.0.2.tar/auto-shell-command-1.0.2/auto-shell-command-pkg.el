;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-shell-command" "1.0.2"
  "Run the shell command asynchronously that you specified when you save the file."
  '((deferred "20130312")
    (popwin   "20130329"))
  :url "https://github.com/ongaeshi/auto-shell-command"
  :commit "59d4abce779a3ce3e920592bf5696b54b2e192c7"
  :revdesc "59d4abce779a"
  :keywords '("shell" "save" "async" "deferred" "auto"))
