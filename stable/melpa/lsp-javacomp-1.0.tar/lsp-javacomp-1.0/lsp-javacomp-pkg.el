;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-javacomp" "1.0"
  "Java support for lsp-mode."
  '((emacs    "25.1")
    (lsp-mode "2.0"))
  :url "https://github.com/tigersoldier/lsp-javacomp"
  :commit "07151517f1fc6117471f96d2a9674ab34df61d8d"
  :revdesc "07151517f1fc"
  :keywords '("java"))
