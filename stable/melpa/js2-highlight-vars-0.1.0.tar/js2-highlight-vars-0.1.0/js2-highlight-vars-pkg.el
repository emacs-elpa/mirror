;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js2-highlight-vars" "0.1.0"
  "Highlight occurrences of the variable under cursor."
  '((js2-mode "20150909"))
  :url "http://mihai.bazon.net/projects/editing-javascript-with-emacs-js2-mode/js2-highlight-vars-mode"
  :commit "bf38d12cf65eebc8b81866fd03f6a0389bb2a9ed"
  :revdesc "v0.1.0-0-gbf38d12cf65e"
  :authors '(("Mihai Bazon" . "mihai.bazon@gmail.com"))
  :maintainers '(("Mihai Bazon" . "mihai.bazon@gmail.com")))
