;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "form-feed" "0.2.3"
  "Display ^L glyphs as horizontal lines."
  ()
  :url "https://depp.brause.cc/form-feed"
  :commit "7ae9703577d6d58026d0248d59c89e84f658824b"
  :revdesc "7ae9703577d6"
  :keywords '("faces")
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
