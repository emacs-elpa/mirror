;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paste-of-code" "0.0.1"
  "Paste code on https://paste.ofcode.org."
  '((request "0.2.0"))
  :url "https://github.com/spebern/paste-of-code.el"
  :commit "d54403a340333b399571a9c0b725404f6449db01"
  :revdesc "d54403a34033"
  :keywords '("lisp")
  :authors '(("Bernhard Specht" . "bernhard@specht.net"))
  :maintainers '(("Bernhard Specht" . "bernhard@specht.net")))
