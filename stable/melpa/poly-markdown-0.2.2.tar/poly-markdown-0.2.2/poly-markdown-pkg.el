;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-markdown" "0.2.2"
  "Polymode for markdown-mode."
  '((emacs         "25")
    (polymode      "0.2.2")
    (markdown-mode "2.3"))
  :url "https://github.com/polymode/poly-markdown"
  :commit "1536cf0c32f71d5cd05c90f7905905e38006e95d"
  :revdesc "1536cf0c32f7"
  :keywords '("emacs"))
