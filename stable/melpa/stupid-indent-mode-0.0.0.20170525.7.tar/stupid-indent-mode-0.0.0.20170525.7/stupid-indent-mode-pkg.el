;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stupid-indent-mode" "0.0.0.20170525.7"
  "Plain stupid indentation minor mode."
  ()
  :commit "3295e7de5e2cfddc3bf0e462e852bf58972f5d70"
  :revdesc "3295e7de5e2c"
  :authors '(("Mihai Bazon" . "mihai.bazon@gmail.com"))
  :maintainers '(("Mihai Bazon" . "mihai.bazon@gmail.com")))
