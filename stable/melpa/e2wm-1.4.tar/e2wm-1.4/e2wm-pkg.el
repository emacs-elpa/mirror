;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2wm" "1.4"
  "Simple window manager for emacs."
  '((window-layout "1.4"))
  :url "https://github.com/kiwanami/emacs-window-manager"
  :commit "4353d3394c77a49f8f0291c239858c8c5e877549"
  :revdesc "4353d3394c77"
  :keywords '("tools" "window manager")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net"))
  :maintainers '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net")))
