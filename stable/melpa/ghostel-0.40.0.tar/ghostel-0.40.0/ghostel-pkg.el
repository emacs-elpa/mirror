;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.40.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "1ed93a4b799e744657849ea5940b13d373c4ee4f"
  :revdesc "1ed93a4b799e"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
