;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darkman" "1.1.0"
  "Seamless integration with Darkman."
  '((emacs "28.1"))
  :url "https://darkman.grtcdr.tn"
  :commit "fa80face9fb6e6c13dc2a0d84631d770fbef71fe"
  :revdesc "1.1.0-0-gfa80face9fb6"
  :keywords '("convenience")
  :authors '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainers '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")))
