;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minitest" "0.9.2"
  "An Emacs mode for ruby minitest files."
  '((dash "1.0.0"))
  :url "https://github.com/arthurnn/minitest-emacs"
  :commit "97d7d1760b24e117ffd163531b0f57fd4321677b"
  :revdesc "97d7d1760b24")
