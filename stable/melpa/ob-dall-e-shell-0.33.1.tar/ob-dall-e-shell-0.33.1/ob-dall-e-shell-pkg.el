;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-dall-e-shell" "0.33.1"
  "Org babel functions for DALL-E evaluation."
  '((emacs        "27.1")
    (dall-e-shell "0.43.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "53ce6324cb1644842402252f2feb62de599839f7"
  :revdesc "53ce6324cb16")
