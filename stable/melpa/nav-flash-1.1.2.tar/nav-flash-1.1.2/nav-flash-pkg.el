;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nav-flash" "1.1.2"
  "Briefly highlight the current line."
  ()
  :url "https://github.com/rolandwalker/nav-flash"
  :commit "2e31f32085757e1dfdd8ec78e9940fd1c88750de"
  :revdesc "v1.1.2-0-g2e31f3208575"
  :keywords '("extensions" "navigation" "interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
