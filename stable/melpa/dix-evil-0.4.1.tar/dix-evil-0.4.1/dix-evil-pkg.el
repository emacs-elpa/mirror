;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dix-evil" "0.4.1"
  "Optional evil-integration with dix.el."
  '((dix  "0.3.0")
    (evil "1.0.7"))
  :url "http://wiki.apertium.org/wiki/Emacs"
  :commit "b973de948deb7aa2995b1895e1e62bbe3129b5a5"
  :revdesc "0.4.1-0-gb973de948deb"
  :keywords '("languages")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
