;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglotx" "0.1.3"
  "Native LSP multiplexer for Eglot."
  '((emacs   "29.1")
    (eglot   "1.24")
    (jsonrpc "1.0.29"))
  :url "https://github.com/cxa/eglotx"
  :commit "0b9358ada0ca1de382c54edc2a3e1b8b6a451603"
  :revdesc "v0.1.3-0-g0b9358ada0ca"
  :keywords '("tools" "languages")
  :authors '(("CHEN Xian'an" . "xianan.chen@gmail.com"))
  :maintainers '(("CHEN Xian'an" . "xianan.chen@gmail.com")))
