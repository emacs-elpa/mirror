;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-search-dired" "1.1.1"
  "Interactive filtering for dired powered by phi-search."
  '((phi-search "2.2.0"))
  :url "http://hins11.yu-yake.com/"
  :commit "162a5e4507c72512affae22744bb606a906d4193"
  :revdesc "162a5e4507c7")
