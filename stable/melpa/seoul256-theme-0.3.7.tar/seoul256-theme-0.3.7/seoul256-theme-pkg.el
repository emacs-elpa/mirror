;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seoul256-theme" "0.3.7"
  "Low-contrast color scheme based on Seoul Colors."
  '((emacs "24.3"))
  :url "https://github.com/anandpiyer/seoul256-emacs"
  :commit "8e76d0207489964ef780420723d49e409f68f7d1"
  :revdesc "8e76d0207489"
  :keywords '("theme")
  :authors '(("Anand Iyer" . "anand.ucb@gmail.com"))
  :maintainers '(("Anand Iyer" . "anand.ucb@gmail.com")))
