;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-vnu" "0.1"
  "Flymake extension for Vmu."
  '((emacs "26.1"))
  :url "https://github.com/theneosloth"
  :commit "d3e3377a2b5a36b80a236d9a5640c9666aafc6a8"
  :revdesc "d3e3377a2b5a"
  :keywords '("languages" "vnu" "html" "flymake")
  :authors '(("Stefan Kuznetsov" . "skuznetsov@posteo.net"))
  :maintainers '(("Stefan Kuznetsov" . "skuznetsov@posteo.net")))
