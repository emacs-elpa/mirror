;;; flymake-vnu.el --- Flymake extension for Vmu. -*- lexical-binding: t -*-

;; Copyright (C) 2018 Stefan Kuznetsov

;; Authors: Stefan Kuznetsov <skuznetsov@posteo.net>
;; Maintainer: Stefan Kuznetsov <skuznetsov@posteo.net>
;; URL: https://github.com/theneosloth
;; Package-Version: 0.1
;; Package-Revision: d3e3377a2b5a
;; Package-Requires: ((emacs "26.1"))
;; Keywords: languages vnu html flymake

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;; Flymake extension for Vnu.
;; (with-eval-after-load 'flymake
;;   (flymake-vnu-setup))
;;; Code:

(require 'flymake)

;;; Flymake


(defcustom flymake-vnu-jar nil
  "Location of the vnu executable."
  :type '(file :must-match t)
  :group 'flymake-vnu)

(defvar-local flymake-vnu--process nil
  "Buffer-local process started for linting the buffer.")

;; Pretty much just copy pasted from the example backend
;; https://www.gnu.org/software/emacs/manual/html_node/flymake/Backend-functions.html#Backend-functions
(defun vnu-flymake (report-fn &rest _args)
  "VNU backend for Flymake.  Check for problems, then call REPORT-FN with results."
  (unless (executable-find "java")
    (error "Cannot find the java executable"))

  (unless (and flymake-vnu-jar (file-exists-p flymake-vnu-jar))
    (error "Cannot find the vnu checker jar file"))

  (let* ((source (current-buffer))
	 (filename (buffer-file-name source)))
    (save-restriction
      (widen)
      (setq
       flymake-vnu--process
       (make-process
        :name "vnu-flymake"
        :noquery t
        :connection-type 'pipe
        :buffer (generate-new-buffer " *vnu-flymake*")
        :command (list "java" "-jar" (expand-file-name flymake-vnu-jar) filename)
        :sentinel
        (lambda (proc _event)
          (when (eq 'exit (process-status proc))
            (unwind-protect
                (if (with-current-buffer source (eq proc flymake-vnu--process))
                    (with-current-buffer (process-buffer proc)
                      (goto-char (point-min))
                      (cl-loop
                       while (search-forward-regexp
                              ;; Example output:
                              ;; FILEPATH/test.html":7.3-7.7: error: Unclosed element “bdy”.
                              "^.*html\":\\([0-9]+\\)\\.\\([0-9]+\\)-\\([0-9]+\\)\\.\\([0-9]+\\):\\(.*\\):\\(.*\\)$"
                              nil t)
		       for severity = (match-string 5)
                       for msg = (match-string 6)
                       ;; TODO: Provide a precise diag region
                       for (beg . end) = (flymake-diag-region
                                          source
                                          (string-to-number (match-string 1))
					  (string-to-number (match-string 2)))
                       for type = (if (string-match "warning" severity)
                                      :warning
                                    :error)
                       collect (flymake-make-diagnostic source
                                                        beg
                                                        end
                                                        type
                                                        msg)
                       into diags
                       finally (funcall report-fn diags)))
                  (flymake-log :warning "Canceling obsolete check %s"
                               proc))
              (kill-buffer (process-buffer proc))))))))))


;;;###autoload
(defun flymake-vnu-setup ()
  "Set up Flymake for Vnu."
  (interactive)
  (add-hook 'html-mode-hook #'flymake-vnu-add-hook))

(defun flymake-vnu-add-hook ()
  "Add `flymake-vnu-lint' to `flymake-diagnostic-functions'."
  (add-hook 'flymake-diagnostic-functions 'vnu-flymake nil t))

(provide 'flymake-vnu)
;;; flymake-vnu.el ends here
