;;; org-shoplist.el --- Eat the world

;; Copyright (C) 2017 Free Software Foundation, Inc.

;; Author: lordnik22
;; Package-Version: 1.0.0
;; Package-Revision: 1a68902fe046
;; Package-Requires: ((org "9.0.6"))
;; Keywords: org-mode, shopping list, moneyflow
;; URL: https://github.com/lordnik22

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;; Commentary:
;; There is nothing done, yet.
;;; Code:
;; Will follow...
(provide 'org-shoplist)
;;; org-shoplist.el ends here
