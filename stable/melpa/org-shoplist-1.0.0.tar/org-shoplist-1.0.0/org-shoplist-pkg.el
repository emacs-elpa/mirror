;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-shoplist" "1.0.0"
  "Eat the world."
  '((org "9.0.6"))
  :url "https://github.com/lordnik22"
  :commit "1a68902fe0465b5d799ced8e5ad608afc6c1eb56"
  :revdesc "1a68902fe046"
  :keywords '("org-mode" "shopping list" "moneyflow"))
