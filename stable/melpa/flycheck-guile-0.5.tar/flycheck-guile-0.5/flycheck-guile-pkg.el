;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-guile" "0.5"
  "A Flycheck checker for GNU Guile."
  '((emacs    "25.1")
    (flycheck "0.22")
    (geiser   "0.20"))
  :url "https://github.com/flatwhatson/flycheck-guile"
  :commit "16c869ec2212dfaeb98f31710667199e4d702515"
  :revdesc "16c869ec2212"
  :authors '(("Ricardo Wurmus" . "rekado@elephly.net"))
  :maintainers '(("Andrew Whatson" . "whatson@tailcall.au")))
