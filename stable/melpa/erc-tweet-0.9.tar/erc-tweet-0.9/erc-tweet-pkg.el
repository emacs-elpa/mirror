;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-tweet" "0.9"
  "Shows text of a tweet when an url is posted in erc buffers."
  '((url-queue "1"))
  :url "https://github.com/kidd/erc-tweet.el"
  :commit "da8b0dbb1a87d2136bd7f28299f8071195438d90"
  :revdesc "da8b0dbb1a87"
  :keywords '("extensions")
  :authors '(("Raimon Grau" . "raimonster@gmail.com"))
  :maintainers '(("Raimon Grau" . "raimonster@gmail.com")))
