;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-read-only" "0.0.1"
  "Automatically make the buffer to read-only -*-."
  ()
  :url "https://github.com/zonuexe/auto-read-only.el"
  :commit "964671a9b7fb1ed80b14c9a3579665beb6deefbd"
  :revdesc "964671a9b7fb"
  :keywords '("files" "convenience")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
