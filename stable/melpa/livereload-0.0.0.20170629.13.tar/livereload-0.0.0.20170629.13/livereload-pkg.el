;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "livereload" "0.0.0.20170629.13"
  "Livereload server."
  '((emacs     "25")
    (websocket "1.8"))
  :url "https://github.com/joaotavora/emacs-livereload"
  :commit "1e501d7e46dbd476c2c7cc9d20b5ac9d41fb1955"
  :revdesc "1e501d7e46db"
  :keywords '("convenience")
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
