;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xquery-mode" "0.1.0"
  "A simple mode for editing xquery programs."
  ()
  :url "https://github.com/xquery-mode/xquery-mode"
  :commit "5d27a06e3d4d6bf9def90ac6c854295009ea1a67"
  :revdesc "5d27a06e3d4d")
