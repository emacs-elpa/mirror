;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yatex" "1.84"
  "Yet Another tex-mode for emacs //野鳥//."
  ()
  :commit "b00018b5a0b487be347d1abf944f8ae165c5a50b"
  :revdesc "yatex-1.84-0-mb00018b5a0b4")
