;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-cells" "0.5"
  "Lightweight notebooks with support for ipynb files."
  '((emacs  "27.1")
    (compat "29.1"))
  :url "https://github.com/astoff/code-cells.el"
  :commit "caffb420be106cebbdfe4474ed0507a601603f83"
  :revdesc "caffb420be10"
  :keywords '("convenience" "outlines")
  :authors '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers '(("Augusto Stoffel" . "arstoffel@gmail.com")))
