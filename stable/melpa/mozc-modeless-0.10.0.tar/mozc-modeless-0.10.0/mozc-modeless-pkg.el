;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc-modeless" "0.10.0"
  "Modeless Japanese input with Mozc."
  '((emacs "29.0")
    (mozc  "0"))
  :url "https://github.com/kiyoka/mozc-modeless-emacs"
  :commit "9c90e8fadb7cff4993edfe4748c4d9c501a4979f"
  :revdesc "9c90e8fadb7c"
  :keywords '("i18n" "input-method")
  :authors '(("Kiyoka Nishiyama" . "kiyokap@gmail.com"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyokap@gmail.com")))
