;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-beautify-theme" "0.3.1"
  "A sub-theme to make org-mode more beautiful."
  ()
  :url "https://github.com/jonnay/org-beautify-theme"
  :commit "7b7a7cbd4f25f77e8bd81783f517b2b182220fd9"
  :revdesc "7b7a7cbd4f25"
  :keywords '("org" "theme")
  :authors '(("Jonathan Arkell" . "jonnay@jonnay.net"))
  :maintainers '(("Jonathan Arkell" . "jonnay@jonnay.net")))
