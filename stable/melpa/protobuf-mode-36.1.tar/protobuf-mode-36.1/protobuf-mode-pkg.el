;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "protobuf-mode" "36.1"
  "Major mode for editing protocol buffers."
  ()
  :url "https://github.com/protocolbuffers/protobuf"
  :commit "f377bfefc5e2cfab68b816903c25b23e091c439d"
  :revdesc "v36.1-0-gf377bfefc5e2"
  :keywords '("google" "protobuf" "languages")
  :authors '(("Alexandre Vassalotti" . "alexandre@peadrop.com"))
  :maintainers '(("Alexandre Vassalotti" . "alexandre@peadrop.com")))
