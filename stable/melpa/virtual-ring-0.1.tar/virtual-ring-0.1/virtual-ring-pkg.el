;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "virtual-ring" "0.1"
  "Fixed size rings with virtual rotation."
  '((emacs "25.1"))
  :url "https://github.com/countvajhula/virtual-ring"
  :commit "ded8cf97a234d2e9bf5bdaa405aca20659e0d40d"
  :revdesc "v0.1-0-gded8cf97a234"
  :authors '(("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
