;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lfe-mode" "2.2.0"
  "Lisp Flavoured Erlang mode."
  ()
  :url "https://github.com/rvirding/lfe"
  :commit "716a6959e4f02d200273fdabb7e1900e0a4c6a8e"
  :revdesc "716a6959e4f0")
