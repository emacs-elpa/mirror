;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-config" "1.0.2"
  "Find and evaluate .dir-config.el (dir-locals alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/dir-config.el"
  :commit "985e86dd79cd661493f3858d172d7452c6fb440e"
  :revdesc "1.0.2-0-g985e86dd79cd"
  :keywords '("convenience"))
