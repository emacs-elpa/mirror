;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ir-black-theme" "1.0.1"
  "Port of ir-black theme."
  ()
  :url "https://github.com/jmdeldin/ir-black-theme.el"
  :commit "b1ca1d0778e3e6228ff756e7fdaf5f5982000fa2"
  :revdesc "b1ca1d0778e3"
  :keywords '("faces")
  :authors '(("Jon-Michael Deldin" . "dev@jmdeldin.com"))
  :maintainers '(("Jon-Michael Deldin" . "dev@jmdeldin.com")))
