;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "android-env" "0.1"
  "Helper functions for working in android."
  '((emacs "24.1"))
  :url "https://github.com/fernando-jascovich/android-env.el"
  :commit "9f8112b236d464f4285fbd9c892b35d8d542922f"
  :revdesc "9f8112b236d4"
  :keywords '("android" "gradle" "java" "tools" "convenience"))
