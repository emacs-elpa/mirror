;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bibclean-format" "0.0.2"
  "Reformat BibTeX and Scribe using bibclean."
  '((emacs       "24.3")
    (reformatter "0.3"))
  :url "https://github.com/peterwvj/bibclean-format"
  :commit "b4003950a925d1c659bc359ab5e88e4441775d77"
  :revdesc "b4003950a925"
  :keywords '("languages")
  :authors '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com"))
  :maintainers '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com")))
