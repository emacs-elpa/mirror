;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "0.4"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benjaminor/kkp"
  :commit "d3a64e0d98a717e0634e1dc294dad4ae4dc7f5f2"
  :revdesc "d3a64e0d98a7"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
