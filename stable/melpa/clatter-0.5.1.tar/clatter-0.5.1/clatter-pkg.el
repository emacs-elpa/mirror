;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.5.1"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "190ea8ca7b5b1102db2d13f594592d4cedea689b"
  :revdesc "190ea8ca7b5b"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
