;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marcopolo" "0.3.0"
  "Emacs client for Docker API."
  '((s        "1.9.0")
    (dash     "2.9.0")
    (pkg-info "0.5.0")
    (request  "0.1.0"))
  :url "https://github.com/nlamirault/marcopolo"
  :commit "ce6ad40d7feab0568924e3bd9659b76e3eecd55e"
  :revdesc "0.3.0-0-gce6ad40d7fea"
  :keywords '("docker")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
