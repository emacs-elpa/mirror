;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mark-yank" "2.0.0"
  "Set region to the last yank."
  '((emacs "24.4"))
  :url "https://github.com/mkleehammer/mark-yank"
  :commit "d34095c9e4196521c49dd80c07cde49f7d6d9644"
  :revdesc "d34095c9e419"
  :authors '(("Michael Kleehammer" . "michael@kleehammer.com"))
  :maintainers '(("Michael Kleehammer" . "michael@kleehammer.com")))
