;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vyper-mode" "0.0.1"
  "Vyper mode for Emacs."
  '((emacs "24.3"))
  :url "https://github.com/ralexstokes/vyper-mode"
  :commit "92870f3b2d7d16557ab06a54b8b94028c9aab268"
  :revdesc "92870f3b2d7d"
  :keywords '("languages")
  :authors '(("Alex Stokes" . "r.alex.stokes@gmail.com"))
  :maintainers '(("Alex Stokes" . "r.alex.stokes@gmail.com")))
