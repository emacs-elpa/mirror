;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "java-imports" "0.1.0"
  "Code for dealing with Java imports."
  '((emacs  "24.4")
    (s      "1.10.0")
    (pcache "0.3.2"))
  :url "http://www.github.com/dakrone/emacs-java-imports"
  :commit "275f354c245df741b45e88d085660722e81a12be"
  :revdesc "0.1.0-0-g275f354c245d"
  :keywords '("java")
  :authors '(("Lee Hinman" . "lee@writequit.org"))
  :maintainers '(("Lee Hinman" . "lee@writequit.org")))
