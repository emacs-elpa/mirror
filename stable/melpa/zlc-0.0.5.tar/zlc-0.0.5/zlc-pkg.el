;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zlc" "0.0.5"
  "Provides zsh like completion system to Emacs."
  ()
  :url "https://github.com/mooz/emacs-zlc"
  :commit "224790312447a66782b0b4569597b4db0377b9ee"
  :revdesc "224790312447"
  :keywords '("matching" "convenience")
  :authors '(("mooz" . "stillpedant@gmail.com"))
  :maintainers '(("mooz" . "stillpedant@gmail.com")))
