;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spotify" "0.3.4"
  "Control the spotify application from emacs."
  '((cl-lib "0.5"))
  :url "https://github.com/remvee/spotify-el"
  :commit "29577cf1188161f98b8358c149aaf47b2c137902"
  :revdesc "0.3.4-0-g29577cf11881"
  :keywords '("convenience"))
