;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hgignore-mode" "0.1.20150329"
  "A major mode for editing hgignore files."
  ()
  :url "https://github.com/omajid/hgignore-mode"
  :commit "442c0183c4a7db528f02d0436a3bd099dda0915f"
  :revdesc "442c0183c4a7"
  :keywords '("convenience" "vc" "hg")
  :authors '(("Omair Majid" . "omair.majid@gmail.com"))
  :maintainers '(("Omair Majid" . "omair.majid@gmail.com")))
