;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remark-mode" "2.1.0"
  "Major mode for the remark slideshow tool."
  '((emacs         "25.1")
    (markdown-mode "2.0"))
  :url "https://github.com/torgeir/remark-mode.el"
  :commit "5a2a702d2af8fd007ae02237d5824356d0c1acc6"
  :revdesc "5a2a702d2af8"
  :keywords '("remark" "slideshow" "markdown" "hot reload")
  :authors '((nil . "@torgeir"))
  :maintainers '((nil . "@torgeir")))
