;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "basic-c-compile" "1.5.9"
  "Quickly create a Makefile, compile and run C."
  '((cl-lib "0.5"))
  :url "https://github.com/nick96/basic-c-compile"
  :commit "e599ef45c0ab6b4995be8b72c1e778d1ee4b4a07"
  :revdesc "e599ef45c0ab"
  :keywords '("c" "makefile" "compilation" "convenience")
  :authors '(("Nick Spain" . "nicholas.spain96@gmail.com"))
  :maintainers '(("Nick Spain" . "nicholas.spain96@gmail.com")))
