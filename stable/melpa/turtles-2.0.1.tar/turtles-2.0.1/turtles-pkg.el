;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "turtles" "2.0.1"
  "Screen-grabbing test utility."
  '((emacs  "26.1")
    (compat "30.0.1.0"))
  :url "https://github.com/szermatt/turtles"
  :commit "c46eb01d73601449f8ae48786bb8f22d17f137da"
  :revdesc "c46eb01d7360"
  :keywords '("testing" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
