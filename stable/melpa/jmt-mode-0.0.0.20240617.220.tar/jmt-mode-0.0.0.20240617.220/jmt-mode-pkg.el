;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jmt-mode" "0.0.0.20240617.220"
  "JMT Mode."
  '((emacs "27.1"))
  :url "http://reluk.ca/project/Java/Emacs/"
  :commit "278db38c30bd556793c9ce0c939045e95dbb6f32"
  :revdesc "278db38c30bd"
  :keywords '("languages" "c")
  :authors '(("Michael Allan" . "mike@reluk.ca"))
  :maintainers '(("Michael Allan" . "mike@reluk.ca")))
