;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stem-english" "2.140226"
  "- routines for stemming English word."
  '((emacs "24.3"))
  :url "https://github.com/kawabata/stem-english"
  :commit "7f5aa1b96c3cd7a0898a374f446c1e0f51936d29"
  :revdesc "7f5aa1b96c3c"
  :keywords '("text")
  :authors '(("Tsuchiya Masatoshi" . "tsuchiya@pine.kuee.kyoto-u.ac.jp"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
