;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "0.5.2"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.3"))
  :url "https://github.com/kmontag/macher"
  :commit "eb9c108e400fe8bbb3c8724f45ef6bd0d2a2ae33"
  :revdesc "eb9c108e400f"
  :keywords '("convenience" "gptel" "llm"))
