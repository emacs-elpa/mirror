;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-powershell" "0.0.0.20250220.19"
  "Org-babel functions for powershell evaluation."
  '((emacs "26.1"))
  :url "https://github.com/rkiggen/ob-powershell"
  :commit "1ba2f3bff0fcb8f4c58ddf534d5bf23bf52a87ca"
  :revdesc "1ba2f3bff0fc"
  :keywords '("powershell" "shell" "execute" "outlines" "processes")
  :authors '(("Rob Kiggen" . "robby.kiggen@essential-it.be")
             ("Pedro Morais" . "fpvmorais@gmail.com"))
  :maintainers '(("Mois Moshev" . "mois.moshev@bottleshipvfx.com")))
