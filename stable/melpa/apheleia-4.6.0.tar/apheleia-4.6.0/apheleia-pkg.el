;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "4.6.0"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "d97806bf2b5b72f1e3df01e9a045a4d242906b65"
  :revdesc "d97806bf2b5b"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
