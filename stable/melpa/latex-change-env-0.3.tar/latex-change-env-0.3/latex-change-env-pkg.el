;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-change-env" "0.3"
  "Change in and out of LaTeX environments."
  '((emacs  "27.1")
    (auctex "13.1"))
  :url "https://gitlab.com/slotThe/change-env"
  :commit "19d422cbe5944b13dccb7606f86b8520ed709e8f"
  :revdesc "19d422cbe594"
  :keywords '("convenience" "tex")
  :authors '(("Tony Zorman" . "soliditsallgood@mailbox.org"))
  :maintainers '(("Tony Zorman" . "soliditsallgood@mailbox.org")))
