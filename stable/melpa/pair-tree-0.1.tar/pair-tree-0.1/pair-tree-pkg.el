;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pair-tree" "0.1"
  "Visualize a list."
  '((emacs "27.1")
    (dash  "2.17.0"))
  :url "https://github.com/zainab-ali/pair-tree"
  :commit "7e9700b92b7f84db788ab44219dcf76189ccd310"
  :revdesc "7e9700b92b7f"
  :keywords '("lisp" "tools")
  :authors '(("Zainab Ali" . "zainab@kebab-ca.se"))
  :maintainers '(("Zainab Ali" . "zainab@kebab-ca.se")))
