;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard-ls" "0.3.0"
  "Display files/directories in current directory on Dashboard."
  '((emacs     "24.3")
    (dashboard "1.2.5"))
  :url "https://github.com/emacs-dashboard/dashboard-ls"
  :commit "5c6a11bfda542892775b5c55c8430773cc82b3c9"
  :revdesc "5c6a11bfda54"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
