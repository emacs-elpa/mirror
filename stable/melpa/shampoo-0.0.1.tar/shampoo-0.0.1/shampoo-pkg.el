;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shampoo" "0.0.1"
  "Shampoo, a remote Smalltalk developemnt."
  ()
  :url "https://github.com/dmatveev/shampoo-emacs"
  :commit "9bf488ad4025beef6eef63d2d5b72bc1c9b9e142"
  :revdesc "9bf488ad4025")
