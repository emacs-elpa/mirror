;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "decl" "1.0.8"
  "Library for organizing code declaratively."
  '((dash   "2.5.0")
    (emacs  "24.3")
    (cl-lib "0.3"))
  :url "https://github.com/preetpalS/decl.el"
  :commit "20afeb13df1b4eff0d7c7910f1c69d32677654b5"
  :revdesc "20afeb13df1b")
