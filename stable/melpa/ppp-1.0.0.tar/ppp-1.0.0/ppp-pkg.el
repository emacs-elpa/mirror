;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ppp" "1.0.0"
  "Extended pretty printer for Emacs Lisp."
  '((emacs "26"))
  :url "https://github.com/conao3/ppp.el"
  :commit "6aabd694bcc66775c6a4328fa653a83e39791252"
  :revdesc "6aabd694bcc6"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
