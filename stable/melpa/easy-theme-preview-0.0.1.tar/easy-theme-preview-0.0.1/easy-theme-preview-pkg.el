;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-theme-preview" "0.0.1"
  "Easily preview themes."
  '((emacs "24.3"))
  :url "https://git.sr.ht/~ayys/theme-preview-mode.el"
  :commit "1269b92c78c6a64e39416aa916a60346a101e91c"
  :revdesc "1269b92c78c6"
  :keywords '("theme" "convenience" "utility")
  :authors '(("Ayush Jha" . "ayys@duck.com"))
  :maintainers '(("Ayush Jha" . "ayys@duck.com")))
