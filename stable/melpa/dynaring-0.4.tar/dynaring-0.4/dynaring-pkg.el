;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dynaring" "0.4"
  "A dynamically sized ring structure."
  '((emacs "25.1"))
  :url "https://github.com/countvajhula/dynaring"
  :commit "42333fcb734f675cab5d25d1b9d142d502914388"
  :revdesc "0.4-0-g42333fcb734f"
  :authors '(("Mike Mattie" . "codermattie@gmail.com")
             ("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
