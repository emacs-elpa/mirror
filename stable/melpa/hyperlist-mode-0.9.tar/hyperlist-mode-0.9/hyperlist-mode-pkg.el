;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperlist-mode" "0.9"
  "A major-mode for viewing Hyperlists."
  '((emacs "24"))
  :url "https://github.com/vifon/hyperlist-mode"
  :commit "468892e0700c363df7b331aa8d58f26d8ef2285a"
  :revdesc "468892e0700c"
  :keywords '("outlines"))
