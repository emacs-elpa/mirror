;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "drupal-spell" "0.2.2"
  "Aspell extra dictionary for Drupal."
  ()
  :url "https://github.com/arnested/drupal-spell"
  :commit "a69f5e3b62c4c0da74ce26c1d00d5b8f7395e4ae"
  :revdesc "0.2.2-0-ga69f5e3b62c4"
  :keywords '("wp")
  :authors '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainers '(("Arne Jørgensen" . "arne@arnested.dk")))
