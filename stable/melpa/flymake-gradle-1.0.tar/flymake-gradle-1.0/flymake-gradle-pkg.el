;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-gradle" "1.0"
  "Flymake extension for Gradle."
  '((emacs "26.1"))
  :url "https://github.com/jojojames/flymake-gradle"
  :commit "64fc4b35ce8de9cd71d074765909a1d312c5b47b"
  :revdesc "64fc4b35ce8d"
  :keywords '("languages" "gradle")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
