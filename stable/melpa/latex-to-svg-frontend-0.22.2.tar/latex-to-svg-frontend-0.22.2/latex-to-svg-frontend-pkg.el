;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "0.22.2"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.15.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "4bd14405ab5c12bf4f7507402371d70b5c5ed063"
  :revdesc "v0.22.2-0-g4bd14405ab5c"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
