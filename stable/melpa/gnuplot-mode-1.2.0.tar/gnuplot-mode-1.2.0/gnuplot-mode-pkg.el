;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot-mode" "1.2.0"
  "Major mode for editing gnuplot scripts."
  ()
  :url "https://github.com/mkmcc/gnuplot"
  :commit "1a3152324aa6dc7233bfbe8e03f9fbd9c0ed8af0"
  :revdesc "1a3152324aa6"
  :keywords '("gnuplot" "plotting")
  :authors '(("Mike McCourt" . "mkmcc@astro.berkeley.edu"))
  :maintainers '(("Mike McCourt" . "mkmcc@astro.berkeley.edu")))
