;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qso" "1.0.1"
  "Customizable, Dynamic Amateur Radio QSO Logging."
  '((emacs "25.1"))
  :url "https://github.com/K6SM/Emacs-QSO-Logger"
  :commit "20a718153335335be7148a44c91ee1c444d4bc5f"
  :revdesc "20a718153335"
  :keywords '("lisp"))
