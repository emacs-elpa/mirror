;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evalator-clojure" "1.0.0"
  "Clojure evaluation context for evalator via CIDER."
  '((cider    "0.10.0")
    (evalator "1.0.0"))
  :url "http://www.github.com/seanirby/evalator-clojure"
  :commit "1022e34cef59445049dc714bdf16a0acca77e902"
  :revdesc "1022e34cef59"
  :keywords '("languages" "clojure" "cider" "helm")
  :maintainers '(("Sean Irby" . "sean.t.irby@gmail.com")))
