;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-compilation" "2.11"
  "Run a ruby process in a compilation buffer."
  '((inf-ruby "2.2.1"))
  :url "https://github.com/eschulte/rinari"
  :commit "e2ed2fa55ac3435a86b1cf6a4f2d29aebc309135"
  :revdesc "e2ed2fa55ac3"
  :keywords '("test" "convenience"))
