;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "space-theming" "0.1.0"
  "Easilly override theme faces."
  ()
  :url "https://github.com/p3r7/space-theming"
  :commit "83637279ac448f2b1811f23f9da1311ae893738a"
  :revdesc "83637279ac44"
  :keywords '("faces"))
