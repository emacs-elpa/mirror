;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smartscan" "1.0.0"
  "Jumps between other symbols found at point."
  ()
  :url "https://github.com/mickeynp/smart-scan"
  :commit "ddcd1ca1f365e2438d70fcb339d883bbb0be5c48"
  :revdesc "v1.0.0-0-gddcd1ca1f365"
  :keywords '("extensions")
  :authors '(("Mickey Petersen" . "mickey@masteringemacs.org"))
  :maintainers '(("Mickey Petersen" . "mickey@masteringemacs.org")))
