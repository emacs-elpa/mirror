;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "secretaria" "0.2.9"
  "A personal assistant based on org-mode."
  '((emacs "24.4")
    (alert "1.2")
    (s     "1.12")
    (f     "0.19.0"))
  :url "https://gitlab.com/shackra/secretaria"
  :commit "91c56311b48a26aa6ef5a113b0a828e174059b0a"
  :revdesc "91c56311b48a"
  :keywords '("org" "convenience")
  :authors '(("Jorge Araya Navarro" . "jorge@esavara.cr"))
  :maintainers '(("Jorge Araya Navarro" . "jorge@esavara.cr")))
