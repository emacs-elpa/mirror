;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browsel" "0.93"
  "WebSocket bridge to a Chrome/Firefox extension."
  '((emacs     "27.1")
    (websocket "1.13")
    (org       "9.4"))
  :url "https://github.com/dmgerman/browsel"
  :commit "18027f0502e6d7a842615729738bb33747fa1e7e"
  :revdesc "18027f0502e6"
  :keywords '("comm" "tools" "browser" "org")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
