;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "2.13"
  "An Org-social client."
  '((emacs            "30.1")
    (org              "9.0")
    (request          "0.3.0")
    (seq              "2.20")
    (emojify          "1.2")
    (async-http-queue "0.1"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "1dbc252a45881388f9f7cbbf51d5bfd5c0a80d80"
  :revdesc "1dbc252a4588"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
