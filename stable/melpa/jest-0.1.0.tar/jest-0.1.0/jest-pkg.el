;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jest" "0.1.0"
  "Helpers to run jest."
  '((emacs "24.4"))
  :url "https://github.com/emiller/emacs-jest/"
  :commit "847036f6c12bc673a28b7d2dd72573032212c6a2"
  :revdesc "847036f6c12b"
  :keywords '("jest" "javascript" "testing")
  :authors '(("Edmund Miller" . "edmund.a.miller@gmail.com"))
  :maintainers '(("Edmund Miller" . "edmund.a.miller@gmail.com")))
