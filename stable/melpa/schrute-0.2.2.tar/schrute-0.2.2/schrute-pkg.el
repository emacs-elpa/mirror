;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "schrute" "0.2.2"
  "Help you remember there is a better way to do something."
  '((emacs "24.3"))
  :url "https://bitbucket.org/shackra/dwight-k.-schrute"
  :commit "08ab6565fa94f3a8016163fe6f7be1932af1156b"
  :revdesc "08ab6565fa94"
  :keywords '("convenience")
  :authors '(("Jorge Araya Navarro" . "elcorreo@deshackra.com"))
  :maintainers '(("Jorge Araya Navarro" . "elcorreo@deshackra.com")))
