;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-perspeen" "0.1.2"
  "Helm interface for perspeen."
  '((perspeen "0.1.0")
    (helm     "2.5.0"))
  :url "https://github.com/jimo1001/helm-perspeen"
  :commit "aec145d5196aed1689563d138a2aa37b139e1759"
  :revdesc "aec145d5196a"
  :keywords '("projects" "lisp"))
