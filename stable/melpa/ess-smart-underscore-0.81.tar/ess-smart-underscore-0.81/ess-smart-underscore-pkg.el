;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-smart-underscore" "0.81"
  "Ess Smart Underscore."
  '((ess "0"))
  :url "https://github.com/mlf176f2/ess-smart-underscore.el"
  :commit "ed4b37e8976124a182196a721068a8e334b6aa97"
  :revdesc "ed4b37e89761"
  :keywords '("ess" "underscore"))
