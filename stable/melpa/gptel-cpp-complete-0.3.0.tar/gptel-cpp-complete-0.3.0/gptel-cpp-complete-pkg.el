;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-cpp-complete" "0.3.0"
  "GPTel-powered C++ completion."
  '((emacs "30.1")
    (eglot "1.19")
    (gptel "0.9.8"))
  :url "https://github.com/beacoder/gptel-cpp-complete"
  :commit "6bc912b4de1b55d30c00c370742217ec593112da"
  :revdesc "6bc912b4de1b"
  :keywords '("programming" "convenience")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
