;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.50.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5143313e07ba8a6b095f85154e6345f87479d63e"
  :revdesc "5143313e07ba"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
