;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "khalel" "0.1.16"
  "Import, edit and create calendar events through khal."
  '((emacs "27.1"))
  :url "https://gitlab.com/hperrey/khalel"
  :commit "3691b4545eaef5a246f020f57bd0f843cc9c84ef"
  :revdesc "3691b4545eae"
  :keywords '("event" "calendar" "ics" "khal")
  :authors '(("Hanno Perrey" . "http://gitlab.com/hperrey"))
  :maintainers '(("Hanno Perrey" . "hanno@hoowl.se")))
