;;; gh.el --- Github API client libraries

;; Copyright (C) 2011  Yann Hodique

;; Author: Yann Hodique <yhodique@gmail.com>
;; Keywords:

;; This file is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 2, or (at your option)
;; any later version.

;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with GNU Emacs; see the file COPYING.  If not, write to
;; the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
;; Boston, MA 02111-1307, USA.

;; Package-Version: 1.0.1
;; Package-Revision: fa8d65f4ddc3

;;; Commentary:

;;

;;; Code:

(require 'gh-gist)
(require 'gh-pulls)
(require 'gh-issues)
(require 'gh-users)

(provide 'gh)
;;; gh.el ends here

;; Local Variables:
;; indent-tabs-mode: nil
;; End:
