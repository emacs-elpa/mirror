;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gh" "1.0.1"
  "Github API client libraries."
  ()
  :url "https://github.com/sigma/gh.el"
  :commit "fa8d65f4ddc390d256eb76dd3f7e3afae02f23e7"
  :revdesc "fa8d65f4ddc3"
  :authors '(("Yann Hodique" . "yhodique@gmail.com"))
  :maintainers '(("Yann Hodique" . "yhodique@gmail.com")))
