;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gh" "1.0.1"
  "A GitHub library for Emacs."
  '((emacs   "25.1")
    (pcache  "0.4.2")
    (logito  "0.1")
    (marshal "0.9.0"))
  :url "https://github.com/sigma/gh.el"
  :commit "fa8d65f4ddc390d256eb76dd3f7e3afae02f23e7"
  :revdesc "fa8d65f4ddc3"
  :authors '(("Yann Hodique" . "yhodique@gmail.com"))
  :maintainers '(("Yann Hodique" . "yhodique@gmail.com")))
