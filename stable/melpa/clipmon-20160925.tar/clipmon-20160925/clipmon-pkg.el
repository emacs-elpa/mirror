;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clipmon" "20160925"
  "Clipboard monitor - watch system clipboard, add changes to kill ring/autoinsert."
  ()
  :url "https://github.com/bburns/clipmon"
  :commit "fe22b6b7ec558692bf0049f459893270a2607c95"
  :revdesc "fe22b6b7ec55"
  :keywords '("convenience")
  :authors '(("Brian Burns" . "bburns.km@gmail.com"))
  :maintainers '(("Brian Burns" . "bburns.km@gmail.com")))
