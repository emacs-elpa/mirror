;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-chez" "0.18"
  "Chez and Geiser talk to each other."
  '((emacs  "26.1")
    (geiser "0.19"))
  :url "https://gitlab.com/emacs-geiser/chez"
  :commit "04ab4387fed68659f21377dbe74513edac2fd134"
  :revdesc "04ab4387fed6"
  :keywords '("languages" "chez" "scheme" "geiser")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
