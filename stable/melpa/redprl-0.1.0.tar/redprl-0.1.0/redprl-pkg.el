;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redprl" "0.1.0"
  "Major mode for editing RedPRL proofs and interacting with RedPRL."
  '((emacs "24.3"))
  :url "https://github.com/RedPRL/sml-redprl"
  :commit "d06d39486348a74981b2c4c4c2ed3af95b01d5ca"
  :revdesc "d06d39486348"
  :keywords '("languages")
  :authors '(("Jonathan Sterling" . "jon@jonmsterling.com"))
  :maintainers '(("Jonathan Sterling" . "jon@jonmsterling.com")))
