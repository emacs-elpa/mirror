;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "0.1.0"
  "Spaced repetition in plain text."
  '((emacs "30.2"))
  :url "https://github.com/Duncan-Britt/srs"
  :commit "016812768cf4f3d641729e90e951a0075b95cd21"
  :revdesc "016812768cf4"
  :keywords '("hypermedia" "srs" "memory"))
