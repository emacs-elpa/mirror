;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hutch" "0.1.0"
  "AI code review for magit."
  '((emacs   "30.1")
    (magit   "4.0")
    (gptel   "0.9.9.3")
    (svg-lib "0.3"))
  :url "https://github.com/adjaecent/magit-hutch"
  :commit "63430c4082dfbace6d1e7b7f76577b190c74be80"
  :revdesc "63430c4082df")
