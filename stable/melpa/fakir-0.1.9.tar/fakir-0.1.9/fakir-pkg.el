;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fakir" "0.1.9"
  "Fakeing bits of Emacs."
  '((noflet "0.0.8")
    (dash   "1.3.2")
    (kv     "0.0.19"))
  :url "https://github.com/nicferrier/emacs-fakir"
  :commit "3c84f3a40b890ed2090d112256216204cccf47a4"
  :revdesc "3c84f3a40b89"
  :keywords '("lisp" "tools")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
