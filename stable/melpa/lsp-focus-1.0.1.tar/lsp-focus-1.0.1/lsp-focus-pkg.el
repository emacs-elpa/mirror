;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-focus" "1.0.1"
  "Focus.el support for lsp-mode."
  '((focus    "0.1.1")
    (lsp-mode "6.1"))
  :url "https://github.com/emacs-lsp/lsp-focus"
  :commit "30a19e9d616b341e41469b141e86ff825070cb67"
  :revdesc "30a19e9d616b"
  :keywords '("languages" "lsp-mode"))
