;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mark-tools" "0.3"
  "Some simple tools to access the mark-ring in Emacs."
  ()
  :url "https://github.com/stsquad/emacs-mark-tools"
  :commit "0e7ac2522ac84155cab341dc49f7f0b81067133c"
  :revdesc "0e7ac2522ac8"
  :authors '(("Alex Bennée" . "alex@bennee.com"))
  :maintainers '(("Alex Bennée" . "alex@bennee.com")))
