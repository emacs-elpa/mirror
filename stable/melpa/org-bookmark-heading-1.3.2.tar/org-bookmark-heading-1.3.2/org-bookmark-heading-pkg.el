;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bookmark-heading" "1.3.2"
  "Emacs bookmark support for Org mode."
  '((emacs  "25.1")
    (compat "29.1.4.5"))
  :url "https://github.com/alphapapa/org-bookmark-heading"
  :commit "c7c7dcc52d3ad78084ea15e95bd7f6037bf02543"
  :revdesc "v1.3.2-0-gc7c7dcc52d3a"
  :keywords '("hypermedia" "outlines")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
