;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-preview-html" "0.3.1"
  "Automatically preview org-exported HTML files within Emacs."
  '((emacs "25.1")
    (org   "8.0"))
  :url "https://github.com/jakebox/org-preview-html"
  :commit "3032721b3bf887d72a4f6016be639fe137b1e09e"
  :revdesc "3032721b3bf8"
  :keywords '("org" "convenience" "outlines")
  :authors '(("Jake B" . "jakebox0@protonmail.com"))
  :maintainers '(("Jake B" . "jakebox0@protonmail.com")))
