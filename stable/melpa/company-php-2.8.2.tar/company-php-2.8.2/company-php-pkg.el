;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-php" "2.8.2"
  "A company back-end for PHP."
  '((cl-lib      "0.5")
    (ac-php-core "2.0")
    (company     "0.9"))
  :url "https://github.com/xcwen/ac-php"
  :commit "579063ac92f3cba9816edd31f24c759aac3a64b2"
  :revdesc "v2.8.2-0-g579063ac92f3"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
