;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "encourage-mode" "0.0.1"
  "Encourages you in your work. :D."
  '((emacs "24.4"))
  :url "https://github.com/halbtuerke/encourage"
  :commit "f2880c6847fb192fbce8f3c372ed84d47d34f056"
  :revdesc "f2880c6847fb"
  :keywords '("fun")
  :authors '(("Patrick Mosby" . "patrick@schreiblogade.de"))
  :maintainers '(("Patrick Mosby" . "patrick@schreiblogade.de")))
