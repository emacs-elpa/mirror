;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simplenote2" "3.0.0"
  "Interact with simple-note.appspot.com."
  '((request-deferred "0.2.0"))
  :url "https://github.com/alpha22jp/simplenote2.el"
  :commit "070aa311b0a08b530394c53d0c52c6438efbc20c"
  :revdesc "070aa311b0a0"
  :keywords '("simplenote")
  :authors '(("alpha22jp" . "alpha22jp@gmail.com"))
  :maintainers '(("alpha22jp" . "alpha22jp@gmail.com")))
