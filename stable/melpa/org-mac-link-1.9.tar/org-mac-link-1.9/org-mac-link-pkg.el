;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mac-link" "1.9"
  "Insert org-mode links to items selected in various Mac apps."
  '((emacs "27.1"))
  :url "https://gitlab.com/aimebertrand/org-mac-link"
  :commit "edf9f6f7254f72be939daf92942f76f44b72d32d"
  :revdesc "edf9f6f7254f"
  :keywords '("files" "wp" "url" "org")
  :authors '(("Anthony Lander" . "anthony.lander@gmail.com")
             ("John Wiegley" . "johnw@gnu.org")
             ("Christopher Suckling" . "sucklingatgmaildotcom")
             ("Daniil Frumin" . "difrumin@gmail.com")
             ("Alan Schmitt" . "alan.schmitt@polytechnique.org")
             ("Mike McLean" . "mike.mclean@pobox.com"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
