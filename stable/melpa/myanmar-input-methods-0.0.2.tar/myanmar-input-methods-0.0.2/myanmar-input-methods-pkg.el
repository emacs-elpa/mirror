;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "myanmar-input-methods" "0.0.2"
  "Emacs Input Method for Myanmar."
  ()
  :url "https://github.com/yelinkyaw/emacs-myanmar-input-methods"
  :commit "f1c780706e29c38884a3617d3eac20701a89007a"
  :revdesc "f1c780706e29"
  :keywords '("myanmar" "unicode" "keyboard")
  :authors '(("Ye Lin Kyaw" . "yelinkyaw@gmail.com"))
  :maintainers '(("Ye Lin Kyaw" . "yelinkyaw@gmail.com")))
