;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.84"
  "Unified interface for AI coding backends."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "c8838a691160987744493db80aff07df3436c10e"
  :revdesc "c8838a691160"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
