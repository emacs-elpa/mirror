;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wotd" "0.1.0"
  "Fetch word-of-the-day from multiple online sources."
  '((emacs "24.4")
    (org   "8.2.10"))
  :url "https://github.com/cute-jumper/emacs-word-of-the-day"
  :commit "8820a5dc5ff893b6b158cf96351613f259aa8546"
  :revdesc "8820a5dc5ff8"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
