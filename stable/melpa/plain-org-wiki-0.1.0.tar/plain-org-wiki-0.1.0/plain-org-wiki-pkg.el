;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plain-org-wiki" "0.1.0"
  "Simple jump-to-org-files in a directory package."
  ()
  :url "https://github.com/abo-abo/plain-org-wiki"
  :commit "beb887df1105a6659a3a49044103795cf3aa1155"
  :revdesc "beb887df1105"
  :keywords '("completion")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
