;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "farmhouse-themes" "1.1"
  "Farmhouse Themes, dark and light versions."
  ()
  :url "https://github.com/emacsorphanage/farmhouse-themes"
  :commit "30c763d01611dad88f1a1ff88451431e2629016d"
  :revdesc "v1.1-0-g30c763d01611"
  :authors '(("Matthew Lyon" . "matthew@lyonheart.us"))
  :maintainers '(("Matthew Lyon" . "matthew@lyonheart.us")))
