;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-notebook" "1.1"
  "Ease the use of org-mode as a notebook."
  '((emacs  "24")
    (org    "8")
    (cl-lib "0.5"))
  :url "https://github.com/Rahi374/org-notebook"
  :commit "5c7e978e6c973d040942e2127cb30024d54ea0d2"
  :revdesc "5c7e978e6c97"
  :keywords '("convenience" "tools")
  :authors '(("Paul Elder" . "paul.elder@amanokami.net"))
  :maintainers '(("Paul Elder" . "paul.elder@amanokami.net")))
