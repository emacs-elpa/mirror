;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "skewer-reload-stylesheets" "0.3.0"
  "Live-edit CSS, SCSS, Less, and friends."
  '((skewer-mode "1.5.3"))
  :url "https://github.com/NateEag/skewer-reload-stylesheets"
  :commit "2034aae7989a9d16339aec05b6c224ed7fed5800"
  :revdesc "2034aae7989a"
  :authors '(("Nate Eagleson" . "nate@nateeag.com"))
  :maintainers '(("Nate Eagleson" . "nate@nateeag.com")))
