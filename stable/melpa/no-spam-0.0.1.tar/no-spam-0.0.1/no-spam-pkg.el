;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-spam" "0.0.1"
  "Add repeat delays to commands."
  '((emacs "25.1"))
  :url "https://github.com/mamapanda/no-spam"
  :commit "04484a154926da611a0d41734a4b005ddd73611e"
  :revdesc "04484a154926"
  :keywords '("keyboard" "tools")
  :authors '(("Daniel Phan" . "daniel.phan36@gmail.com"))
  :maintainers '(("Daniel Phan" . "daniel.phan36@gmail.com")))
