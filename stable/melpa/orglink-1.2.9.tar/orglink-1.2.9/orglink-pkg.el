;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orglink" "1.2.9"
  "Use Org Mode links in other modes."
  '((emacs  "26.1")
    (compat "30.1")
    (org    "9.7")
    (seq    "2.24"))
  :url "https://github.com/tarsius/orglink"
  :commit "0de830edc6ffc0b07b95284f545ffe7d7c37dfb8"
  :revdesc "v1.2.9-0-g0de830edc6ff"
  :keywords '("hypermedia")
  :authors '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev")))
