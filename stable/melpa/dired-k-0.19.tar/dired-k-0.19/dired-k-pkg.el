;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-k" "0.19"
  "Highlight dired buffer by file size, modified time, git status."
  '((emacs "24.3"))
  :url "https://github.com/syohex/emacs-dired-k"
  :commit "3f0b9315f87b0f930d51089e311d41282d5f8b15"
  :revdesc "3f0b9315f87b"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
