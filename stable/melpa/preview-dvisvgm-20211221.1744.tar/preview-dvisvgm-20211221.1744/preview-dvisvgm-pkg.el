;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "preview-dvisvgm" "20211221.1744"
  "SVG output for LaTeX preview."
  '((emacs  "27.1")
    (auctex "13.0.12"))
  :url "https://github.com/TobiasZawada/preview-dvisvgm"
  :commit "df3b809d2f4663a091f34f964e823cd068bdd2e6"
  :revdesc "df3b809d2f46"
  :keywords '("tex")
  :authors '(("Tobias Zawada" . "i@tn-home.de"))
  :maintainers '(("Tobias Zawada" . "i@tn-home.de")))
