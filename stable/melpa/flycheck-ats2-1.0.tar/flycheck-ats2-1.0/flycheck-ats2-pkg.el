;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-ats2" "1.0"
  "Flycheck: ATS2 support."
  '((emacs    "24.1")
    (flycheck "0.22"))
  :url "https://github.com/drvink/flycheck-ats2"
  :commit "80f7447e9cae091e8467258c7c0191ad68ae9407"
  :revdesc "80f7447e9cae"
  :keywords '("convenience" "tools" "languages")
  :authors '(("Mark Laws" . "mdl@60hz.org"))
  :maintainers '(("Mark Laws" . "mdl@60hz.org")))
