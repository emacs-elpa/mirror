;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-hide-dotfiles" "0.1"
  "Hde dotfiles in dired."
  '((emacs "25.1"))
  :url "https://github.com/mattiasb/.emacs.d"
  :commit "32cf3b6f90dc56f6ff271c28d827aab303bc6221"
  :revdesc "v0.1-0-g32cf3b6f90dc"
  :keywords '("files")
  :authors '(("Mattias Bengtsson" . "mattias.jc.bengtsson@gmail.com"))
  :maintainers '(("Mattias Bengtsson" . "mattias.jc.bengtsson@gmail.com")))
