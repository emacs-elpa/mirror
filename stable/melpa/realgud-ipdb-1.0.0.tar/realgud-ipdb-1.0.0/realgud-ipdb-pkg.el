;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-ipdb" "1.0.0"
  "Realgud front-end to ipdb."
  '((realgud "1.4.5")
    (emacs   "24"))
  :url "https://github.com/rocky/realgud-ipdb"
  :commit "ba41636ac4102bdc9d28a5ae7177b3792be55933"
  :revdesc "ba41636ac410")
