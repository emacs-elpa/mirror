;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "j-mode" "1.1.1"
  "Major mode for editing J programs."
  ()
  :url "https://github.com/zellio/j-mode"
  :commit "caa55dfaae01d1875380929826952c2b3ef8a653"
  :revdesc "v1.1.1-0-gcaa55dfaae01"
  :keywords '("j" "langauges")
  :authors '(("Zachary Elliott" . "ZacharyElliott1@gmail.com"))
  :maintainers '(("Zachary Elliott" . "ZacharyElliott1@gmail.com")))
