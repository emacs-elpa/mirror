;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-secretario-elfeed" "0.0.1"
  "[No description available]."
  '((emacs  "27.1")
    (cl-lib "0.5")
    (org-ql "0.6-pre"))
  :url "https://git.sr.ht/~zetagon/el-secretario"
  :commit "fad42831d2fcebd3554f0580bd0bf8af6551b9d2"
  :revdesc "fad42831d2fc"
  :authors '(("Leo Okawa Ericson" . "http://github/Zetagon"))
  :maintainers '(("Leo" . "github@relevant-information.com")))
