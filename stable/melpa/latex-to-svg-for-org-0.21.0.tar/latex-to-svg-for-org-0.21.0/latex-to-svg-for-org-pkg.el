;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-org" "0.21.0"
  "Preview Org LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.21.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "cb2be59737281784c242501c9486c742403ab026"
  :revdesc "v0.21.0-0-gcb2be5973728"
  :keywords '("tex" "org" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
