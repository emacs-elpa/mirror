;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uptimes" "3.8"
  "Track and display Emacs session uptimes."
  '((cl-lib "0.5")
    (emacs  "24"))
  :url "https://github.com/davep/uptimes.el"
  :commit "29ae6585eeed5a00719b2e52f5ae1082087c1778"
  :revdesc "29ae6585eeed"
  :keywords '("processes" "uptime")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
