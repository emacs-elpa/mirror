;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dynamic-graphs" "1.1"
  "Manipulation with graphviz graphs."
  '((emacs "26.1"))
  :url "https://github.com/zellerin/dynamic-graphs"
  :commit "ca4a9e5c915ed7cf477ca62ebe062f7aae11fc11"
  :revdesc "ca4a9e5c915e"
  :keywords '("tools")
  :authors '(("Tomas Zellerin" . "tomas@zellerin.cz"))
  :maintainers '(("Tomas Zellerin" . "tomas@zellerin.cz")))
