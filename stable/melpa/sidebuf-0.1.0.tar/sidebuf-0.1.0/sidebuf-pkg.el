;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sidebuf" "0.1.0"
  "Buffer list sidebar panel."
  '((emacs "27.1"))
  :url "https://github.com/rain-64/sidebuf"
  :commit "f3fea1df92f1b2edb16736d4f50df9734675450a"
  :revdesc "f3fea1df92f1"
  :keywords '("convenience" "buffers")
  :authors '(("rain-64" . "https://github.com/rain-64"))
  :maintainers '(("rain-64" . "https://github.com/rain-64")))
