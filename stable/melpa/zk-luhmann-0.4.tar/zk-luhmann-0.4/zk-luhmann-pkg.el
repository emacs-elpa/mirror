;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-luhmann" "0.4"
  "Support for Luhmann-style IDs in zk."
  '((emacs    "25.1")
    (zk       "0.7")
    (zk-index "0.10"))
  :url "https://github.com/localauthor/zk-luhmann"
  :commit "55eef9712984deab320fb1a952c0624af2988128"
  :revdesc "55eef9712984"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
