;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "find-file-in-repository" "1.2"
  "Quickly find files in a git, mercurial or other repository."
  ()
  :url "https://github.com/hoffstaetter/find-file-in-repository"
  :commit "8b888f85029a2ff9159a724b42aeacdb051c3420"
  :revdesc "8b888f85029a"
  :keywords '("files" "convenience" "repository" "project" "source control")
  :authors '(("Samuel Hoffstaetter" . "samuel@hoffstaetter.com"))
  :maintainers '(("Samuel Hoffstaetter" . "samuel@hoffstaetter.com")))
