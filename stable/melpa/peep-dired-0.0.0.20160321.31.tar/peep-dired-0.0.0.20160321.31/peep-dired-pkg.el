;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "peep-dired" "0.0.0.20160321.31"
  "Peep at files in another window from dired buffers."
  ()
  :url "https://github.com/asok/peep-dired"
  :commit "12d7e52cd5ae29fd828db0bf1fbf648020077145"
  :revdesc "12d7e52cd5ae"
  :keywords '("files" "convenience")
  :authors '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com"))
  :maintainers '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com")))
