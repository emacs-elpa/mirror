;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acme-theme" "1.0.0"
  "A color theme for Emacs based on Acme & Sam from Plan 9."
  ()
  :url "https://github.com/ianyepan/acme-emacs-theme"
  :commit "680b2022445861e3e9030a96d9fe587188d778c8"
  :revdesc "680b20224458")
