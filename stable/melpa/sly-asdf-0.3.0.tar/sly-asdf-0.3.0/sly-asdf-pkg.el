;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly-asdf" "0.3.0"
  "ASDF system support for SLY."
  '((emacs "24.3")
    (sly   "1.0.0-beta2")
    (popup "0.5.3"))
  :url "https://github.com/mmgeorge/sly-asdf"
  :commit "c1fa52dadb2f453243dc522203b7a883adef63fb"
  :revdesc "c1fa52dadb2f"
  :keywords '("languages" "lisp" "sly" "asdf")
  :maintainers '(("Matt George" . "mmge93@gmail.com")))
