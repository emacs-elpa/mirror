;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cabledolphin" "0.1"
  "Capture Emacs network traffic."
  '((emacs "24.4")
    (seq   "1.0"))
  :url "https://github.com/legoscia/cabledolphin"
  :commit "2157c8fc3d411fec688d9eb3768dadd88026aa15"
  :revdesc "2157c8fc3d41"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainers '(("Magnus Henoch" . "magnus.henoch@gmail.com")))
