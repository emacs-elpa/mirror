;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-init-viewer" "0.1.0"
  "Record viewer for el-init."
  '((emacs    "24")
    (cl-lib   "0.5")
    (ctable   "0.1.2")
    (dash     "2.10.0")
    (anaphora "1.0.0")
    (el-init  "0.1.4"))
  :url "https://github.com/HKey/el-init-viewer"
  :commit "dcc595ba51b5aff972292278aa528c7ddb46f1b5"
  :revdesc "dcc595ba51b5"
  :authors '(("Hiroki YAMAKAWA" . "s06139@gmail.com"))
  :maintainers '(("Hiroki YAMAKAWA" . "s06139@gmail.com")))
