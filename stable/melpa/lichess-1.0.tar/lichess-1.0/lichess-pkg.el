;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "1.0"
  "Client for Lichess.org."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "572a6a353e2113c8a95564b9bea1f2896e6d3dab"
  :revdesc "572a6a353e21"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
