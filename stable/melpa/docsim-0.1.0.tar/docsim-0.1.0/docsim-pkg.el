;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docsim" "0.1.0"
  "Find notes that are textually similar to this one."
  '((emacs "24.4")
    (org   "8.0"))
  :url "https://github.com/hrs/docsim.el"
  :commit "3870a3015c94b5d0a9b2094c467e55b70699dd5e"
  :revdesc "3870a3015c94"
  :authors '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainers '(("Harry R. Schwartz" . "hello@harryrschwartz.com")))
