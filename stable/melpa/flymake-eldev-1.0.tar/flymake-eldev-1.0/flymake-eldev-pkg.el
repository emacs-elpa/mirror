;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-eldev" "1.0"
  "Eldev support in Flymake."
  '((dash  "2.17")
    (emacs "28.1"))
  :url "https://github.com/emacs-eldev/flymake-eldev"
  :commit "947d3f43d19ddf67dffcaa3ba66c51ce1077dda7"
  :revdesc "947d3f43d19d"
  :keywords '("tools" "convenience")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
