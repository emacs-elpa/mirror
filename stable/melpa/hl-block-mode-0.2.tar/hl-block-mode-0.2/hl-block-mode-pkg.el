;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-block-mode" "0.2"
  "Highlighting nested blocks."
  '((emacs "26.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-block-mode"
  :commit "760e02b5fd66812e701c12292a1f00bde3c1c46c"
  :revdesc "760e02b5fd66"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
