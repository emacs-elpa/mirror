;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "czech-holidays" "0.0.1"
  "Adds a list of Czech public holidays to Emacs calendar."
  ()
  :url "https://github.com/chkhd/czech-holidays"
  :commit "2ced0017301345d03bc050390ecde47aa80e992f"
  :revdesc "2ced00173013"
  :keywords '("calendar")
  :authors '(("David Chkhikvadze" . "david.chk@outlook.com"))
  :maintainers '(("David Chkhikvadze" . "david.chk@outlook.com")))
