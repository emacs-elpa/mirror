;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fetch" "0.1.2"
  "Fetch and unpack resources."
  ()
  :url "https://github.com/crshd/fetch.el"
  :commit "a9525fffce79ca71e23873db4735795a9954d9bb"
  :revdesc "a9525fffce79"
  :authors '(("Christian 'crshd' Brassat" . "christian.brassat@gmail.com"))
  :maintainers '(("Christian 'crshd' Brassat" . "christian.brassat@gmail.com")))
