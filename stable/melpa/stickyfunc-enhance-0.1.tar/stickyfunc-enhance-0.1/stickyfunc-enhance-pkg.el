;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stickyfunc-enhance" "0.1"
  "A refactoring tool based on Semantic parser framework."
  '((emacs "24.3"))
  :url "https://github.com/tuhdo/semantic-stickyfunc-enhance"
  :commit "59d00f1fe2116a76af0be64ad78e8ea90936279b"
  :revdesc "59d00f1fe211"
  :keywords '("c" "languages" "tools")
  :authors '(("Do Hoang" . "tuhdo1710@gmail.com")))
