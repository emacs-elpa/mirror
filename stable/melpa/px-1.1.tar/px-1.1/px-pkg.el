;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "px" "1.1"
  "Preview inline latex in any mode."
  ()
  :url "https://github.com/aaptel/preview-latex"
  :commit "0c52f7933eab3ca1642ab0df151db9950430c9e2"
  :revdesc "0c52f7933eab"
  :authors '(("Aurélien Aptel" . "aurelien.aptel@gmail.com"))
  :maintainers '(("Aurélien Aptel" . "aurelien.aptel@gmail.com")))
