;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "molar-mass" "1.0"
  "Calculates molar mass of a molecule."
  '((emacs "24.3"))
  :url "https://github.com/sergiruiztrepat/molar-mass.el"
  :commit "5b7d1d0004d27580e980fe8532658cd09174342e"
  :revdesc "5b7d1d0004d2"
  :keywords '("convenience" "chemistry"))
