;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whois" "0.4.1"
  "Syntax highlighted domain name queries using system whois."
  '((emacs "24"))
  :url "https://github.com/lassik/emacs-whois"
  :commit "d4466b296721fa94b2ceab1c51bc9bfd8bbf4e0a"
  :revdesc "d4466b296721"
  :keywords '("network" "comm")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
