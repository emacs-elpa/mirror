;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rings" "1.0.1"
  "Buffer rings. Like tabs, but better."
  ()
  :url "https://github.com/konr/rings"
  :commit "0fddda6a790fe91d54285485ad87db64cc3fe279"
  :revdesc "0fddda6a790f"
  :keywords '("utilities" "productivity"))
