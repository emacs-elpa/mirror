;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rubocopfmt" "0.5.1"
  "Minor-mode to format Ruby code with RuboCop on save."
  '((cl-lib "0.5"))
  :url "https://github.com/jimeh/rubocopfmt.el"
  :commit "b180786c007e6f4c2f2a9673a13fb0651d012f76"
  :revdesc "0.5.1-0-gb180786c007e"
  :keywords '("convenience" "wp" "edit" "ruby" "rubocop"))
