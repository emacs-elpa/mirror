;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flappymacs" "0.1.0"
  "Flappybird clone for emacs."
  ()
  :url "https://github.com/taksatou/flappymacs"
  :commit "3e8802831f5c688300ea1df82ce453dd519b1e2b"
  :revdesc "3e8802831f5c"
  :keywords '("games"))
