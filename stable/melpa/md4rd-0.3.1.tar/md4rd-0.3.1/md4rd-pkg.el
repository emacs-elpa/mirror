;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "md4rd" "0.3.1"
  "Mode for reddit (browse it)."
  '((emacs     "25.1")
    (hierarchy "0.7.0")
    (request   "0.3.0")
    (cl-lib    "0.6.1")
    (dash      "2.12.0")
    (s         "1.12.0")
    (tree-mode "1.0.0"))
  :url "https://github.com/ahungry/md4rd"
  :commit "443c8059af4925d11c93a1293663165c52472f08"
  :revdesc "443c8059af49"
  :keywords '("ahungry" "reddit" "browse" "news")
  :authors '(("Matthew Carter" . "m@ahungry.com"))
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
