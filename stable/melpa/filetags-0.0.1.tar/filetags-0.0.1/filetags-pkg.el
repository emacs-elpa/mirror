;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "filetags" "0.0.1"
  "Package to manage filetags in filename."
  ()
  :url "https://github.com/DerBeutlin/filetags.el"
  :commit "eda735933f60e3a34bb7e6ba7963f30ddfa4b309"
  :revdesc "eda735933f60"
  :keywords '("convenience" "files")
  :authors '(("Max Beutelspacher" . "max@MACS"))
  :maintainers '(("Max Beutelspacher" . "max@MACS")))
