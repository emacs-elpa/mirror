;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "messages-are-flowing" "0.1"
  "Visible indication when composing \"flowed\" emails."
  ()
  :url "https://github.com/legoscia/messages-are-flowing"
  :commit "649061753b67b24c54a2eaadc8b3218cafae7376"
  :revdesc "649061753b67"
  :keywords '("mail")
  :authors '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainers '(("Magnus Henoch" . "magnus.henoch@gmail.com")))
