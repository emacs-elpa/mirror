;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-macos-theme" "1.7"
  "Color theme inspired by the macOS UI."
  '((emacs "27.1"))
  :url "https://gitlab.com/aimebertrand/timu-macos-theme"
  :commit "699df447695f82b576e9ce9ccb633319b6d5bfc3"
  :revdesc "699df447695f"
  :keywords '("faces" "themes")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
