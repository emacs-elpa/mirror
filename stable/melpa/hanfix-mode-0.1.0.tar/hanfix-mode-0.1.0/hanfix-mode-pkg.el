;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hanfix-mode" "0.1.0"
  "Korean grammar checker."
  '((emacs "30.2"))
  :url "https://github.com/ntalbs/hanfix-mode"
  :commit "24d1df6da336e4a9fd66657b41cae4ee9f6a0297"
  :revdesc "24d1df6da336"
  :keywords '("convenience" "wp")
  :authors '(("ntalbs" . "ntalbsen@gmail.com"))
  :maintainers '(("ntalbs" . "ntalbsen@gmail.com")))
