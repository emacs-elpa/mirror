;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "1.1.4"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "22d2d8a92b8d8cd0532c8382dcfe7df405f1563a"
  :revdesc "1.1.4-0-g22d2d8a92b8d"
  :keywords '("frames"))
