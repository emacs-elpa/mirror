;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "procress" "0.3.0"
  "Process progress."
  '((emacs "28.0"))
  :url "https://github.com/haji-ali/procress.git"
  :commit "376c1e109ca5ba58e95e63e4796a9de809fb5e6e"
  :revdesc "376c1e109ca5"
  :keywords '("compile" "progress" "tex" "svg")
  :authors '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com")))
