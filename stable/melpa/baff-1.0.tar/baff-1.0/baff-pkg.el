;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "baff" "1.0"
  "Create a byte array from a file."
  '((emacs "24.1"))
  :url "https://github.com/dave-f/baff/"
  :commit "d03ffb079d8efca52f1e40e4b220ee9d1cc25058"
  :revdesc "d03ffb079d8e"
  :keywords '("convenience" "usability")
  :authors '(("Dave Footitt" . "dave.footitt@gmail.com"))
  :maintainers '(("Dave Footitt" . "dave.footitt@gmail.com")))
