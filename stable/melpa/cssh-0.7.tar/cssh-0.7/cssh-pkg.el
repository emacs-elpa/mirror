;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cssh" "0.7"
  "Clusterssh implementation for emacs."
  ()
  :url "http://pgsql.tapoueh.org/elisp"
  :commit "4d11070e6e374f2f5c8d58acb2bee392f28a828a"
  :revdesc "4d11070e6e37"
  :keywords '("clusterssh" "ssh" "cssh")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
