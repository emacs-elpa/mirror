;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-zoxide" "0.1.0"
  "Jump to zoxide directories with Consult."
  '((emacs   "29.1")
    (consult "2.0"))
  :url "https://github.com/agzam/consult-zoxide.el"
  :commit "d6b270cf021b558981bb9cf7503d84096195af79"
  :revdesc "d6b270cf021b"
  :keywords '("convenience" "files" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
