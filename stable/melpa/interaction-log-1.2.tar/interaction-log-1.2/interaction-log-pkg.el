;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "interaction-log" "1.2"
  "Exhaustive log of interactions with Emacs."
  ()
  :url "https://github.com/michael-heerdegen/interaction-log.el"
  :commit "1950cbb32ccdaeb041142846f16c4371c1157050"
  :revdesc "1950cbb32ccd"
  :keywords '("convenience")
  :authors '(("Michael Heerdegen" . "michael_heerdegen@web.de"))
  :maintainers '(("Michael Heerdegen" . "michael_heerdegen@web.de")))
