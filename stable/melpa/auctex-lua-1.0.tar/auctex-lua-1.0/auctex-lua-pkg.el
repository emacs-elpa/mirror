;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auctex-lua" "1.0"
  "Lua editing support for AUCTeX."
  ()
  :url "https://github.com/vermiculus/auctex-lua"
  :commit "c1d1d81fe5ada4a61ebfd7c33226584e46c56e3f"
  :revdesc "c1d1d81fe5ad"
  :keywords '("latex" "lua")
  :authors '(("Sean Allred" . "(seallred@smcm.edu)"))
  :maintainers '(("Sean Allred" . "(seallred@smcm.edu)")))
