;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly-named-readtables" "0.1"
  "Automatically parse in-readtable forms in Lisp buffers."
  '((sly "1.0.0-beta-2"))
  :url "https://github.com/joaotavora/sly-named-readtables"
  :commit "2a0b471f2322e1383115d99adda0bb3a2410ba9a"
  :revdesc "2a0b471f2322"
  :keywords '("lisp")
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
