;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apache-mode" "2.2.0"
  "Major mode for editing Apache httpd configuration files."
  ()
  :url "https://github.com/emacs-php/apache-mode"
  :commit "354f9302a8d805ac80d846adcd1cef10830b3d51"
  :revdesc "354f9302a8d8"
  :keywords '("languages" "faces")
  :authors '(("Karl Chen" . "quarl@nospam.quarl.org"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
