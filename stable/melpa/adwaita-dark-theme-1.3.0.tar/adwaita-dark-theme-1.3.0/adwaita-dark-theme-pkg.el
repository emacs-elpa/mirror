;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adwaita-dark-theme" "1.3.0"
  "A dark color scheme inspired by Adwaita."
  '((emacs "27.1"))
  :url "https://gitlab.com/jessieh/adwaita-dark-theme"
  :commit "0907961986a582ded514d54a8bfdf691f7bfaf86"
  :revdesc "0907961986a5"
  :keywords '("mode-line" "faces")
  :authors '(("Jessie Hildebrandt" . "jessieh.net"))
  :maintainers '(("Jessie Hildebrandt" . "jessieh.net")))
