;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdb-mode" "1.0"
  "[No description available]."
  ()
  :url "http://bondxray.org/software/pdb-mode/"
  :commit "369db113450738a6fe4991be43bf639100297cb4"
  :revdesc "369db1134507"
  :keywords '("data" "pdb")
  :authors '((nil . "charles.bond@uwa.edu.au"))
  :maintainers '((nil . "aix.bing@gmail.com")))
