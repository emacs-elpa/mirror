;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ipe" "1.1"
  "Insert, Update and Delete PAIRs using overlays."
  '((emacs "24.3"))
  :url "https://github.com/BriansEmacs/insert-pair-edit.el"
  :commit "4939aef5446721d89fc18d4d707ce424f002b11b"
  :revdesc "4939aef54467"
  :keywords '("convenience" "tools")
  :authors '(("Brian Kavanagh (concat \"Brians.Emacs\" \"gmail.com\"" . "\"@\" "))
  :maintainers '(("Brian Kavanagh (concat \"Brians.Emacs\" \"gmail.com\"" . "\"@\" ")))
