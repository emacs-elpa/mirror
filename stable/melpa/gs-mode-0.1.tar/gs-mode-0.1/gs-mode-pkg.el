;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gs-mode" "0.1"
  "Major mode for editing GrADS script files."
  ()
  :url "https://github.com/yyr/emacs-grads"
  :commit "0e5ab6c8c918ff86aeab80030abd75bdbc62b3d1"
  :revdesc "0e5ab6c8c918"
  :keywords '("grads" "script" "major-mode")
  :authors '(("Joe Wielgosz" . "joew@cola.iges.org"))
  :maintainers '(("Joe Wielgosz" . "joew@cola.iges.org")))
