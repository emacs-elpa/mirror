;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "date-field" "0.0.1"
  "Date widget."
  '((dash       "2.9.0")
    (log4e      "0.2.0")
    (yaxception "0.3.2"))
  :url "https://github.com/aki2o/emacs-date-field"
  :commit "11c9170d1f7b343233f7716d4c0a62be024c1654"
  :revdesc "11c9170d1f7b"
  :keywords '("widgets")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
