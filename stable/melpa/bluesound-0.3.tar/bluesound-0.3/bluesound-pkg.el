;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesound" "0.3"
  "Play, pause, resume music on a Bluesound player."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~rwv/bluesound-el/"
  :commit "60d7f422483bd7f3cf23983160e28ecff9c14b38"
  :revdesc "0.3-0-g60d7f422483b"
  :keywords '("convenience" "multimedia"))
