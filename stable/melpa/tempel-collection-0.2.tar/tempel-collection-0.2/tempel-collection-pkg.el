;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel-collection" "0.2"
  "Collection of templates for Tempel."
  '((tempel "0.5")
    (emacs  "27.1"))
  :url "https://github.com/Crandel/tempel-collection"
  :commit "7ef22ea7aaf699632a1d02d47a9a505ae8bc52c3"
  :revdesc "7ef22ea7aaf6"
  :keywords '("tools")
  :authors '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
             ("Max Penet" . "mpenetr@s-exp.com")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
                 ("Max Penet" . "mpenetr@s-exp.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
