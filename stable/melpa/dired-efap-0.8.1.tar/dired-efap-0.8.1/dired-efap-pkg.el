;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-efap" "0.8.1"
  "Edit Filename At Point in a dired buffer."
  ()
  :url "https://github.com/juan-leon/dired-efap"
  :commit "360b369cb19998c6730ee1debfbec3edb7f349a9"
  :revdesc "360b369cb199"
  :keywords '("dired" "environment" "files" "renaming")
  :authors '(("Juan-Leon Lahoz" . "juanleon1@gmail.com"))
  :maintainers '(("Juan-Leon Lahoz" . "juanleon1@gmail.com")))
