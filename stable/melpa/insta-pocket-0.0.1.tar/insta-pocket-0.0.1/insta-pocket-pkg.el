;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insta-pocket" "0.0.1"
  "Instapaper client."
  '((emacs "29.1")
    (oauth "1.11"))
  :url "https://github.com/thanhvg/emacs-insta-pocket"
  :commit "7a62c7168fdd167a63bb48b75c258f9cf8b3172f"
  :revdesc "7a62c7168fdd"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
