;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-prettify-mode" "1.0"
  "Hide `if err != nil' and other statements in Go in an informative way."
  ()
  :url "https://git.sr.ht/~snyssfx/go-prettify-mode.el"
  :commit "a7bb10f2ee5bb9706a5ee2a95bec426ab8edef6a"
  :revdesc "a7bb10f2ee5b"
  :keywords '("languages" "go" "tools")
  :authors '(("Gleb Zakharov" . "snyssfx@posteo.net"))
  :maintainers '(("Gleb Zakharov" . "snyssfx@posteo.net")))
