;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocaml-ts-mode" "0.1.0"
  "Tree-sitter support for OCaml."
  '((emacs "29.1"))
  :url "https://github.com/dmitrig/ocaml-ts-mode"
  :commit "2e33e7687965a2f41861658a28fbf0b7502152c3"
  :revdesc "2e33e7687965"
  :keywords '("ocaml" "languages" "tree-sitter"))
