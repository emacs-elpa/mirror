;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-annotate" "0.0.5"
  "Annotate files or buffers with LLMs."
  '((emacs  "29.1")
    (compat "30.1.0.0")
    (gptel  "0.9.9.5"))
  :url "https://github.com/karthink/gptel-annotate"
  :commit "8be94959fd29b90b98f9f54faabfc07b50795540"
  :revdesc "8be94959fd29"
  :keywords '("comm")
  :authors '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com")))
