;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chronometrist-goal" "0.2.1"
  "Adds support for time goals to Chronometrist."
  '((emacs         "25.1")
    (alert         "1.2")
    (chronometrist "0.5.0"))
  :url "https://github.com/contrapunctus-1/chronometrist"
  :commit "e651821d0f64830235232082a8295e86a173574b"
  :revdesc "e651821d0f64"
  :keywords '("calendar")
  :authors '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainers '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr")))
