;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "private-diary" "1.1"
  "Maintain a private diary in Emacs."
  '((emacs "24.0")
    (epg   "0"))
  :url "https://github.com/cacology/private-diary"
  :commit "664bedb63a67b4a964b03223bbac6ad55db7c299"
  :revdesc "664bedb63a67"
  :keywords '("diary" "encryption")
  :authors '(("James P. Ascher" . "jpa4q@virginia.edu"))
  :maintainers '(("James P. Ascher" . "jpa4q@virginia.edu")))
