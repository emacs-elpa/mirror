;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-dabbrev" "1.1"
  "Like dabbrev-expand with preview and popup menu."
  '((emacs "24")
    (popup "0.5.3"))
  :url "https://github.com/jrosdahl/fancy-dabbrev"
  :commit "158e1e54055cafe5da9122a59519e8b3ed1057cf"
  :revdesc "158e1e54055c"
  :authors '(("Joel Rosdahl" . "joel@rosdahl.net"))
  :maintainers '(("Joel Rosdahl" . "joel@rosdahl.net")))
