;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timecop" "0.0.1"
  "Freeze Time for testing."
  '((cl-lib          "0.5")
    (datetime-format "0.0.1"))
  :url "https://github.com/zonuexe/emacs-datetime"
  :commit "3a1871613facc928ff250ed8f12fbc7073e46b75"
  :revdesc "3a1871613fac"
  :keywords '("datetime" "testing")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
