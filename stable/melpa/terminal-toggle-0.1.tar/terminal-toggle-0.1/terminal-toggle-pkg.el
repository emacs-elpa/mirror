;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "terminal-toggle" "0.1"
  "Simple pop-up terminal."
  '((emacs  "24")
    (popwin "1.0.0"))
  :url "https://github.com/mtekman/terminal-toggle.el"
  :commit "eeb4d8ae4d1eeab4df7d2e8ea298d1a39235a171"
  :revdesc "eeb4d8ae4d1e"
  :keywords '("outlines"))
