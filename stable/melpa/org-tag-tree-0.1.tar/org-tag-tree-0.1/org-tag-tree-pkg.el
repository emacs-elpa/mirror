;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-tree" "0.1"
  "Define Org-mode tag hierarchies from Org subtrees."
  '((emacs "28.1")
    (org   "9.0"))
  :url "https://github.com/p-snow/org-tag-tree"
  :commit "af2b574dbddac0f73cc03bfb15acfe675f622f83"
  :revdesc "af2b574dbdda"
  :keywords '("outlines" "convenience")
  :authors '(("p-snow" . "public@p-snow.org"))
  :maintainers '(("p-snow" . "public@p-snow.org")))
