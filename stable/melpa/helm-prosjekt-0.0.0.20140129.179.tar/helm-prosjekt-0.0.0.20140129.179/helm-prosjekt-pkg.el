;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-prosjekt" "0.0.0.20140129.179"
  "Helm integration for prosjekt."
  '((prosjekt "0.3")
    (helm     "1.5.9"))
  :url "https://github.com/abingham/prosjekt"
  :commit "f94f970c2d375e0973b66ba99b29c7aa42fd550f"
  :revdesc "f94f970c2d37"
  :authors '(("Sohail Somani" . "sohail@taggedtype.net"))
  :maintainers '(("Sohail Somani" . "sohail@taggedtype.net")))
