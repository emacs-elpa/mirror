;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tetris-60" "0.1.0"
  "Retro ASCII Tetris for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/suxiaogang223/tetris-60"
  :commit "639de3f0f373dce78fd7246c1dca8985095b6349"
  :revdesc "639de3f0f373"
  :keywords '("games"))
