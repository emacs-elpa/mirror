;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vdirel" "0.2.0"
  "Manipulate vdir (i.e., vCard) repositories."
  '((emacs     "24.4")
    (org-vcard "0.1.0")
    (helm      "1.7.0")
    (seq       "1.11"))
  :url "https://github.com/DamienCassou/vdirel"
  :commit "4232676e93ca5ace8e51f6605bec223c3205beea"
  :revdesc "4232676e93ca"
  :keywords '("vdirsyncer" "vdir" "vcard" "carddav" "contact" "addressbook" "helm")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
