;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-gnitset" "0.1"
  "Run your Python tests any way you'd like."
  ()
  :url "https://www.github.com/quodlibetor/py-gnitset"
  :commit "5be543b80c27a2e4332b890f2266ef6ee36a82f8"
  :revdesc "5be543b80c27"
  :authors '(("Brandon W Maister" . "quodlibetor@gmail.com"))
  :maintainers '(("Brandon W Maister" . "quodlibetor@gmail.com")))
