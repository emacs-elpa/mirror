;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-xcdoc" "0.0.1"
  "Search Xcode Document by docsetutil and eww with helm interface."
  '((helm "1.5"))
  :url "https://github.com/fujimisakari/emacs-helm-xcdoc"
  :commit "343dafc30ec4bda8f3833add91cb5c5eb22d33d9"
  :revdesc "343dafc30ec4"
  :authors '(("Ryo Fujimoto" . "fujimisakri@gmail.com"))
  :maintainers '(("Ryo Fujimoto" . "fujimisakri@gmail.com")))
