;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskpaper-mode" "1.0"
  "Major mode for working with TaskPaper files."
  ()
  :url "https://github.com/saf-dmitry/taskpaper-mode"
  :commit "169dab1eb632e5ac5e34608be2df4e9854368180"
  :revdesc "169dab1eb632"
  :keywords '("outlines" "notetaking" "task management" "productivity" "taskpaper")
  :authors '(("Dmitry Safronov" . "saf.dmitry@gmail.com"))
  :maintainers '(("Dmitry Safronov" . "saf.dmitry@gmail.com")))
