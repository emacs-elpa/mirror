;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sexy-theme" "0.1"
  "Sexy color theme for Emacs 24+."
  ()
  :url "https://github.com/bgcicca/sexy-theme"
  :commit "f0d90f52650b7fa31503945c8637099de5ee6ee7"
  :revdesc "f0d90f52650b"
  :authors '(("Bruno Ciccarino" . "brunociccarinoo@gmail.com"))
  :maintainers '(("Bruno Ciccarino" . "brunociccarinoo@gmail.com")))
