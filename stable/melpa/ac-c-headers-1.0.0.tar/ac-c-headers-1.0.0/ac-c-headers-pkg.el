;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-c-headers" "1.0.0"
  "Auto-complete source for C headers."
  '((auto-complete "1.3.1"))
  :url "http://zk-phi.gitub.io/"
  :commit "7b4b613ed40342cb5613127738d281c58084d0ac"
  :revdesc "7b4b613ed403")
