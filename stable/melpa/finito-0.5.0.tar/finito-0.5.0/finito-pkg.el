;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "finito" "0.5.0"
  "View and collect books."
  '((emacs     "27.1")
    (dash      "2.17.0")
    (request   "0.3.2")
    (f         "0.2.0")
    (s         "1.12.0")
    (transient "0.3.0")
    (graphql   "0.1.1")
    (async     "1.9.3"))
  :url "https://github.com/LaurenceWarne/finito.el"
  :commit "5e20777922aafb6afc2ddac8f4a62cd0c1ed987d"
  :revdesc "v0.5.0-0-g5e20777922aa"
  :keywords '("outlines"))
