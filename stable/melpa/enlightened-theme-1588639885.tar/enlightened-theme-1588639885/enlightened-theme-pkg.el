;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enlightened-theme" "1588639885"
  "An Emacs 24 theme based on enlightened (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "252b29e63a59167363b99ab7fb35af7699212986"
  :revdesc "252b29e63a59")
