;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "suggestion-box" "0.0.1"
  "Show tooltip on the cursor."
  '((emacs "25.1")
    (popup "0.5.3"))
  :url "https://github.com/yuutayamada/suggestion-box-el"
  :commit "46ea9c43c69abbc8bc9ff6119c4e5b92320bae91"
  :revdesc "46ea9c43c69a"
  :keywords '("convenience")
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
