;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-virtualenv" "2.4.0"
  "Automatically activate Python virtualenvs based on project directory."
  '((cl-lib "0.5"))
  :url "https://github.com/marcwebbie/auto-virtualenv"
  :commit "0b6ba18f0b449a40e9ff438b4e910b58b8804282"
  :revdesc "v2.4.0-0-g0b6ba18f0b44"
  :keywords '("python" "virtualenv" "environment" "tools" "projects")
  :authors '(("Marcwebbie" . "marcwebbie@gmail.com"))
  :maintainers '(("Marcwebbie" . "marcwebbie@gmail.com")))
