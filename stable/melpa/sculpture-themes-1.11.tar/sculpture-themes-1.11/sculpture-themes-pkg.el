;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "1.11"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "8fa20dc87a86ea4576debb38a75d71f1ee6ae273"
  :revdesc "8fa20dc87a86"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
