;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loop" "1.3"
  "Friendly imperative loop structures."
  ()
  :url "https://github.com/Wilfred/loop.el"
  :commit "c3598bd3ad0677f66e061b3ba51a05d05275283e"
  :revdesc "c3598bd3ad06"
  :keywords '("loop" "while" "for each" "break" "continue")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
