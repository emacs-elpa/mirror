;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cycle-at-point" "0.2"
  "Cycle (rotate) the thing under the cursor."
  '((emacs      "29.1")
    (recomplete "0.2"))
  :url "https://codeberg.org/ideasman42/emacs-cycle-at-point"
  :commit "83d94733fd8ed64f2ba40f4e1df7ecbfe8260e51"
  :revdesc "83d94733fd8e"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
