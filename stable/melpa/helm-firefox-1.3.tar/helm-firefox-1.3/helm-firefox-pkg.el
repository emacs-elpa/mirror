;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-firefox" "1.3"
  "Firefox bookmarks."
  '((helm   "1.5")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/emacs-helm/helm-firefox"
  :commit "0ad34b7b5abc485a86cae6920c14de861cbeb085"
  :revdesc "v1.3-0-g0ad34b7b5abc")
