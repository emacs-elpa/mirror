;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "one" "1.1"
  "Static Site Generator for org-mode users."
  '((emacs   "28.1")
    (jack    "1.0")
    (htmlize "1.57"))
  :url "https://github.com/tonyaldon/one.el"
  :commit "fa52cf0144f89eabee06f598b021a37087c69670"
  :revdesc "fa52cf0144f8"
  :keywords '("hypermedia" "outlines")
  :authors '(("Tony Aldon" . "tony@tonyaldon.com"))
  :maintainers '(("Tony Aldon" . "tony@tonyaldon.com")))
