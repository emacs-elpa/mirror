;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-sync-mode" "0.5.0"
  "Sync your git repositories on save."
  '((emacs       "29.1")
    (async-await "0"))
  :url "https://github.com/justinbarclay/git-sync-mode"
  :commit "abdb08a7fd262d8bec4c967338e7715e43119499"
  :revdesc "v0.5.0-0-gabdb08a7fd26"
  :keywords '("vc" "convenience")
  :authors '(("Justin Barclay" . "github@justincbarclay.ca"))
  :maintainers '(("Justin Barclay" . "github@justincbarclay.ca")))
