;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epic" "0.2"
  "Evernote Picker for Cocoa Emacs."
  '((htmlize "1.47"))
  :url "https://github.com/yoshinari-nomura/epic"
  :commit "891433a23a4bea1da66efaf2cdeb4608a8da0d2d"
  :revdesc "891433a23a4b"
  :keywords '("evernote" "applescript")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
