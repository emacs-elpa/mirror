;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keypress-multi-event" "1.0"
  "Perform different actions for the same keypress."
  '((emacs "24.3"))
  :url "https://www.github.com/Boruch_Baum/emacs-keypress-multi-event"
  :commit "9de65a27e10d8ae47aa6d28c02c3eb82ee8c0b2e"
  :revdesc "9de65a27e10d"
  :keywords '("abbrev" "convenience" "wp" "keyboard")
  :authors '(("Boruch Baum" . "boruch_baum@gmx.com"))
  :maintainers '(("Boruch Baum" . "boruch_baum@gmx.com")))
