;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-bibtex" "0.6.2"
  "Org Roam meets BibTeX."
  '((emacs             "27.2")
    (org-roam          "2.0.0")
    (bibtex-completion "2.0.0"))
  :url "https://github.com/org-roam/org-roam-bibtex"
  :commit "070a7a732cf38f51245116ddd41aad8ac697c3b0"
  :revdesc "070a7a732cf3"
  :keywords '("bib" "hypermedia" "outlines" "wp")
  :authors '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
             ("Leo Vivier" . "leo.vivier+dev@gmail.com"))
  :maintainers '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
                 ("Leo Vivier" . "leo.vivier+dev@gmail.com")))
