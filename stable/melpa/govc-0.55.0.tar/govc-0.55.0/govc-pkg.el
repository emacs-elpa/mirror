;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "govc" "0.55.0"
  "Interface to govc for managing VMware ESXi and vCenter."
  '((emacs       "24.3")
    (dash        "1.5.0")
    (s           "1.9.0")
    (magit-popup "2.0.50")
    (json-mode   "1.6.0"))
  :url "https://github.com/vmware/govmomi/tree/main/govc/emacs"
  :commit "cb2d98b50e63532939817ffb86ca87fe748ff3f0"
  :revdesc "v0.55.0-0-gcb2d98b50e63"
  :keywords '("convenience"))
