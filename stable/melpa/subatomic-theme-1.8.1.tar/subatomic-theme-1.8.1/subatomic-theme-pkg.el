;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "subatomic-theme" "1.8.1"
  "Low contrast bluish color theme."
  ()
  :url "https://github.com/cryon/subatomic"
  :commit "6a4086af748b1ecb27f6ba2aa2614988db16d594"
  :revdesc "1.8.1-0-g6a4086af748b"
  :keywords '("color-theme" "blue" "low contrast")
  :authors '(("John Olsson" . "john@cryon.se"))
  :maintainers '(("John Olsson" . "john@cryon.se")))
