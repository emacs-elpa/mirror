;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-ameba" "0.1.0"
  "Add support for Ameba to Flycheck."
  '((flycheck "30"))
  :url "https://github.com/veelenga/ameba.el"
  :commit "ca5faaa0d5115dc2c301e06e062e653a7b9cb927"
  :revdesc "ca5faaa0d511"
  :keywords '("tools" "crystal" "ameba"))
