;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wolfram" "1.2"
  "Wolfram Alpha Integration."
  ()
  :url "https://github.com/hsjunnesson/wolfram.el"
  :commit "a172712d5045834f5434cca2843a7c3506805db8"
  :revdesc "a172712d5045"
  :keywords '("math")
  :authors '(("Hans Sjunnesson" . "hans.sjunnesson@gmail.com"))
  :maintainers '(("Hans Sjunnesson" . "hans.sjunnesson@gmail.com")))
