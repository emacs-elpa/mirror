;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lazy-ruff" "0.3.1"
  "Integration with the Ruff Python linter/formatter."
  '((emacs "24.3")
    (org   "9.1"))
  :url "https://github.com/christophermadsen/emacs-lazy-ruff"
  :commit "4eeea363a133e0e7ed7c02a5e2f1f7b63a78c3f4"
  :revdesc "4eeea363a133"
  :keywords '("languages" "tools"))
