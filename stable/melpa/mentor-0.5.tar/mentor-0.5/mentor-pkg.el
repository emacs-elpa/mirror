;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mentor" "0.5"
  "Frontend for the rTorrent bittorrent client."
  '((emacs    "25.1")
    (xml-rpc  "1.6.15")
    (seq      "1.11")
    (async    "1.9.3")
    (url-scgi "0.7"))
  :url "https://github.com/skangas/mentor"
  :commit "480602f2ec5467aa2418ee98b328fb85d3b58d0c"
  :revdesc "0.5-0-g480602f2ec54"
  :keywords '("comm" "processes" "bittorrent")
  :authors '(("Stefan Kangas" . "stefankangas@gmail.com"))
  :maintainers '(("Stefan Kangas" . "stefankangas@gmail.com")))
