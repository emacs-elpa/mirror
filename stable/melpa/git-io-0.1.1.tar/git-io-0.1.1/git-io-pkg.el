;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-io" "0.1.1"
  "Git.io integration for emacs."
  ()
  :url "https://github.com/tejasbubane/emacs-git-io"
  :commit "3e0fe1d4efb6dbbdf777d82e22cbc7619ca4c64d"
  :revdesc "3e0fe1d4efb6"
  :keywords '("url-shortener" "git-io")
  :authors '(("Tejas Bubane" . "tejasbubane@gmail.com"))
  :maintainers '(("Tejas Bubane" . "tejasbubane@gmail.com")))
