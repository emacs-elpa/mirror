;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cacoo" "2.1.2"
  "Minor mode for Cacoo (http://cacoo.com)."
  ()
  :url "https://github.com/kiwanami/emacs-cacoo/"
  :commit "c2e6a8830144810cd4e51de3646cb8200bcebbc6"
  :revdesc "c2e6a8830144"
  :keywords '("convenience" "diagram")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net"))
  :maintainers '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net")))
