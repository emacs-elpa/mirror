;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redpen-paragraph" "0.42"
  "RedPen interface."
  '((emacs  "24")
    (cl-lib "0.5")
    (json   "1.4"))
  :url "https://github.com/karronoli/redpen-paragraph.el"
  :commit "f9569bc8e2993dea0f83cba5738a35ce32f82424"
  :revdesc "f9569bc8e299"
  :keywords '("document" "proofreading" "help"))
