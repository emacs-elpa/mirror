;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neil" "0.3.69"
  "Companion for Babashka Neil."
  '((emacs "27.1"))
  :url "https://github.com/babashka/neil"
  :commit "fa793214d7820e6763108c942e9cf16e1cd2db96"
  :revdesc "fa793214d782"
  :keywords '("convenience" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
