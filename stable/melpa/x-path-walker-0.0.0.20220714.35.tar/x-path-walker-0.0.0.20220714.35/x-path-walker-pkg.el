;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x-path-walker" "0.0.0.20220714.35"
  "Navigation feature for JSON/XML/HTML based on path (imenu like)."
  '((helm-core "3.6.0"))
  :url "https://github.com/Lompik/x-path-walker"
  :commit "c91deaaba0d5cc9018008a39c96222deacba3868"
  :revdesc "c91deaaba0d5"
  :keywords '("convenience")
  :authors '((nil . "lompik@ArchOrion"))
  :maintainers '((nil . "lompik@ArchOrion")))
