;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brf" "2.4"
  "Brf-mode provides features from the legendary editor Brief."
  '((fringe-helper "0.1.1")
    (emacs         "24.4"))
  :url "https://bitbucket.org/MikeWoolley/brf-mode"
  :commit "4751ce5c76f53d4e3e6a658461651a4f3ce35045"
  :revdesc "v2.04-0-g4751ce5c76f5"
  :keywords '("brief" "crisp" "emulations")
  :authors '(("Mike Woolley" . "mike@bulsara.com"))
  :maintainers '(("Mike Woolley" . "mike@bulsara.com")))
