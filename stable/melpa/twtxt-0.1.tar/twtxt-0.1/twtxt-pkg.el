;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "twtxt" "0.1"
  "Client twtxt."
  '((request "0.2.0"))
  :url "https://codeberg.org/deadblackclover/twtxt-el"
  :commit "6e9d990073ca35d8c91b2f3d8f290b9f116de185"
  :revdesc "6e9d990073ca"
  :keywords '("news")
  :authors '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com"))
  :maintainers '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com")))
