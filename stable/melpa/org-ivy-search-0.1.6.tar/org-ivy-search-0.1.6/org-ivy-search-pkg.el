;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ivy-search" "0.1.6"
  "Full text search for org files powered by ivy."
  '((emacs  "25.1")
    (ivy    "0.10.0")
    (org    "0.10.0")
    (beacon "1.3.4"))
  :url "https://github.com/beacoder/org-ivy-search"
  :commit "7f2afd8c196e3723ae6ac4dd229367ece9acd3bf"
  :revdesc "7f2afd8c196e"
  :keywords '("convenience" "tool" "org")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
