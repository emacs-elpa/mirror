;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arduino-cli-mode" "201001"
  "Arduino-CLI command wrapper."
  '((emacs "25.1"))
  :url "https://github.com/motform/arduino-cli-mode"
  :commit "da0abb99fe977ad1ac350486becd096ecb7dfb4d"
  :revdesc "da0abb99fe97"
  :keywords '("extensions" "processes" "arduino"))
