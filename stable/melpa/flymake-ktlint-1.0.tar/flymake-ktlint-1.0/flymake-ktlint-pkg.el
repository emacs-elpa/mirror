;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ktlint" "1.0"
  "Flymake extension for Ktlint."
  '((emacs   "26.1")
    (flymake "0.3"))
  :url "https://github.com/jojojames/flymake-ktlint"
  :commit "43332d2e08e5f9c7ed71c4ff54b788f86c20774c"
  :revdesc "43332d2e08e5"
  :keywords '("languages" "ktlint")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
