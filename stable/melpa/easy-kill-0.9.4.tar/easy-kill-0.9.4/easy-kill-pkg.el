;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-kill" "0.9.4"
  "Kill & mark things easily."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/leoliu/easy-kill"
  :commit "2a6309d98aa6b71df6bbbcdf15cab3187c521a6b"
  :revdesc "2a6309d98aa6"
  :keywords '("killing" "convenience")
  :authors '(("Leo Liu" . "sdl.web@gmail.com"))
  :maintainers '(("Leo Liu" . "sdl.web@gmail.com")))
