;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-tube-mpv" "0.15"
  "Control mpv from Elfeed."
  '((emacs       "27.1")
    (elfeed-tube "0.10")
    (mpv         "0.2.0"))
  :url "https://github.com/karthink/elfeed-tube"
  :commit "7e1409e41628d61d8197ca248d910182ae4fc520"
  :revdesc "7e1409e41628"
  :keywords '("news" "hypermedia")
  :authors '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com")))
