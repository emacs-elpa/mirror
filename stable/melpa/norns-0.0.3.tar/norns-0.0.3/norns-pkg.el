;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "norns" "0.0.3"
  "Interactive development environment for monome norns."
  '((emacs     "27.1")
    (dash      "2.17.0")
    (s         "1.12.0")
    (f         "0.20.0")
    (request   "0.3.2")
    (websocket "1.13")
    (lua-mode  "20221218.605"))
  :url "https://github.com/p3r7/norns.el"
  :commit "cb7da7c63bbd5470f8856c865fc0443447eeb0c2"
  :revdesc "cb7da7c63bbd"
  :keywords '("processes" "terminals"))
