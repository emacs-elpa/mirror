;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-alias" "1.7.0"
  "An alternative to gnus-posting-styles."
  ()
  :url "https://github.com/hexmode/gnus-alias"
  :commit "cf1783a9294bc2f72bfafcaea288c159c4e3dee5"
  :revdesc "cf1783a9294b"
  :keywords '("personality" "identity" "news" "mail" "gnus")
  :authors '(("Joe Casadonte" . "emacs@northbound-train.com"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
