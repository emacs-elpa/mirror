;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "merlin-eldoc" "1.3"
  "Eldoc for OCaml and Reason."
  '((emacs  "24.4")
    (merlin "3.0"))
  :url "https://github.com/khady/merlin-eldoc"
  :commit "bbb1a10f2131c09a7f7f844d4da98efd77f927ae"
  :revdesc "bbb1a10f2131"
  :keywords '("merlin" "ocaml" "languages" "eldoc")
  :authors '(("Louis Roché" . "louis@louisroche.net"))
  :maintainers '(("Louis Roché" . "louis@louisroche.net")))
