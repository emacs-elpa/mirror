;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-notmuch" "2.1.4"
  "Links to notmuch messages."
  '((emacs   "29.1")
    (compat  "31.0")
    (notmuch "0.39")
    (org     "9.8"))
  :url "https://github.com/tarsius/ol-notmuch"
  :commit "fba0b5790a4c9aafeab69fd329776d0b4afa9aac"
  :revdesc "v2.1.4-0-gfba0b5790a4c"
  :keywords '("hypermedia" "mail")
  :authors '(("Matthieu Lemerre" . "racin@free.fr"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ol-notmuch@jonas.bernoulli.dev")))
