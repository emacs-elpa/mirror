;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-vocabulary" "1.0"
  "Help you to create vocabulary card in Anki."
  '((emacs             "24.4")
    (s                 "1.0")
    (youdao-dictionary "0.4")
    (AnkiConnect       "1.0"))
  :url "https://github.com/lujun9972/anki-vocabulary.el"
  :commit "5d6abc071a1aa80b9cf04ba82e207be898630347"
  :revdesc "5d6abc071a1a"
  :keywords '("lisp" "anki" "translator" "chinese")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
