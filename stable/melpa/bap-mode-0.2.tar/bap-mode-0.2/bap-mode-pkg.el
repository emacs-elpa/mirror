;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bap-mode" "0.2"
  "Major-mode for BAP's IR."
  ()
  :url "https://github.com/fkie-cad/bap-mode"
  :commit "5e0570a4d70003aea451232358c0adb2d1a813fc"
  :revdesc "5e0570a4d700"
  :keywords '("languages")
  :authors '(("Thomas Barabosch" . "http://github/tbarabosch"))
  :maintainers '(("Thomas Barabosch" . "thomas.barabosch@fkie.fraunhofer.de")))
