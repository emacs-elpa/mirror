;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pkg-config" "0.3"
  "Configure flycheck using pkg-config."
  '((dash     "2.8.0")
    (s        "1.9.0")
    (flycheck "29"))
  :url "https://github.com/Wilfred/flycheck-pkg-config"
  :commit "b76b24ea1f4800f5fb96ce9c6c4788e0e63133d3"
  :revdesc "b76b24ea1f48"
  :keywords '("flycheck")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
