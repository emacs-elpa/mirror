;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-region" "0.3.0"
  "Select region as vim."
  '((expand-region "20140127"))
  :url "https://github.com/ongaeshi/emacs-vim-region"
  :commit "e5359cc584a0cfa9270a76866a5eff7d3f44eb3d"
  :revdesc "e5359cc584a0"
  :authors '(("ongaeshi" . "ongaeshi0621@gmail.com"))
  :maintainers '(("ongaeshi" . "ongaeshi0621@gmail.com")))
