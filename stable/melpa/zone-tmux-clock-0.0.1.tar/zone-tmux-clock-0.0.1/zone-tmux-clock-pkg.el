;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zone-tmux-clock" "0.0.1"
  "Zone out with a tmux style clock."
  '((emacs "24.3"))
  :url "https://depp.brause.cc/zone-tmux-clock"
  :commit "f8158aad57730e1611a3994cf921037770753d72"
  :revdesc "f8158aad5773"
  :keywords '("games")
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
