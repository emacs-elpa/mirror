;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-d2" "0.0.3"
  "Org-babel functions for d2."
  '((emacs "24.1"))
  :url "https://github.com/xcapaldi/ob-d2"
  :commit "be7dbf497732caaf17c420c19c08d0323725305d"
  :revdesc "be7dbf497732"
  :keywords '("languages"))
