;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hardcore-mode" "0.1.0"
  "Disable arrow keys + optionally backspace and return."
  ()
  :url "https://github.com/magnars/hardcore-mode.el"
  :commit "5ab75594a7a0ca236e2ac87882ee439ff6155d96"
  :revdesc "0.1.0-0-g5ab75594a7a0"
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
