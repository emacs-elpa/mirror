;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spacemacs-theme" "0.3"
  "Color theme with a dark and light versions."
  ()
  :commit "e04d1f21107a1565861625209bb9c46a7aa43cc5"
  :revdesc "e04d1f21107a")
