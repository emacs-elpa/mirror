;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sparkweather" "0.1.2"
  "Weather forecasts with sparklines."
  '((emacs "29.1"))
  :url "https://github.com/aglet/sparkweather"
  :commit "99b096e4c4c4181d45d8fb77faf8698249287ac8"
  :revdesc "99b096e4c4c4"
  :keywords '("convenience" "weather")
  :authors '(("Robin Stephenson" . "robin@aglet.net"))
  :maintainers '(("Robin Stephenson" . "robin@aglet.net")))
