;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-fly-indent-mode" "0.1.0"
  "Indent Emacs Lisp on the fly."
  '((emacs "25"))
  :url "https://github.com/jiahaowork/el-fly-indent-mode.el"
  :commit "309ee65d4c5d3c39f734ff16781a20a5d9c9c1a7"
  :revdesc "309ee65d4c5d"
  :keywords '("lisp" "languages")
  :authors '(("Jiahao Li" . "jiahaowork@gmail.com"))
  :maintainers '(("Jiahao Li" . "jiahaowork@gmail.com")))
