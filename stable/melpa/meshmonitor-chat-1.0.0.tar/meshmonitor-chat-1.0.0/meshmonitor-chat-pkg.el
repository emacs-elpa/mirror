;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meshmonitor-chat" "1.0.0"
  "Chat client for MeshMonitor (Meshtastic)."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/meshmonitor-chat.el"
  :commit "fbfe05c77cb4dcc758c11ebd0f9358d766d4c972"
  :revdesc "fbfe05c77cb4"
  :keywords '("comm")
  :authors '(("Andros Fenollosa" . "andros@fenollosa.email"))
  :maintainers '(("Andros Fenollosa" . "andros@fenollosa.email")))
