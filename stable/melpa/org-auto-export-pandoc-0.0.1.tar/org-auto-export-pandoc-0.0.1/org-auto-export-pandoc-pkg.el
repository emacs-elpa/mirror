;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-auto-export-pandoc" "0.0.1"
  "Support for the Foo programming language."
  '((ox-pandoc "0"))
  :url "https://example.com/foo"
  :commit "caba13b56e32ba49ab9eca01a60b7e6edcdbb786"
  :revdesc "caba13b56e32"
  :keywords '("languages")
  :authors '(("Yonggan" . "yonggan@obco.pro"))
  :maintainers '(("Yonggan" . "yonggan@obco.pro")))
