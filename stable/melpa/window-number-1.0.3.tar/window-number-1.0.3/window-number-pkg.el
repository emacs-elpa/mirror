;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "window-number" "1.0.3"
  "Select windows by numbers."
  ()
  :url "http://www.emacswiki.org/emacs/download/window-number.el"
  :commit "f248c7ee6e6426112af3706df3127949c3bf671f"
  :revdesc "f248c7ee6e64"
  :keywords '("windows")
  :authors '(("Johann Myrkraverk Oskarsson" . "myrkraverk@users.sourceforge.net"))
  :maintainers '(("Nik Nyby" . "niknyby@riseup.net")
                 ("Johann Myrkraverk Oskarsson" . "myrkraverk@users.sourceforge.net")
                 ("Andy Stewart" . "lazycat.manatee@gmail.com")))
