;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "now-playing" "1.1.1"
  "Interface for the macOS Music app."
  '((emacs     "30.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/now-playing"
  :commit "2bd837f9cd0c5e5a7a5a73c980536421ff21f462"
  :revdesc "2bd837f9cd0c"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
