;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lexic" "0.0.1"
  "A major mode to find out more about words."
  '((emacs "26.3")
    (dash  "2.17.0"))
  :url "https://github.com/tecosaur/lexic"
  :commit "e6aadc6b694cb7fc3ecd69c105d342f88cc0b372"
  :revdesc "e6aadc6b694c"
  :authors '(("pluskid" . "pluskid@gmail.com")
             ("gucong" . "gucong43216@gmail.com")
             ("TEC" . "tec@tecosaur.com"))
  :maintainers '(("TEC" . "tec@tecosaur.com")))
