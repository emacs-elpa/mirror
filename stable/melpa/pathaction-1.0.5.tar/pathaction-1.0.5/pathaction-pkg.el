;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "1.0.5"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "6e2ac33aa9a386ff310510a5fec1168751408f4e"
  :revdesc "1.0.5-0-g6e2ac33aa9a3"
  :keywords '("tools" "processes" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
