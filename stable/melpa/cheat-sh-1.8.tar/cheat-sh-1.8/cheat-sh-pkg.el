;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cheat-sh" "1.8"
  "Interact with cheat.sh."
  '((emacs "25.1"))
  :url "https://github.com/davep/cheat-sh.el"
  :commit "bd970d7c576b8720d63a1e7fd88ea8a943f2160b"
  :revdesc "bd970d7c576b"
  :keywords '("docs" "help")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
