;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hungarian-holidays" "0.0.1"
  "Adds a list of Hungarian public holidays to Emacs calendar."
  ()
  :url "https://github.com/gergelypolonkai/hungarian-holidays"
  :commit "653108769279499d84a79267c90e640d98823872"
  :revdesc "653108769279"
  :keywords '("calendar")
  :authors '(("Gergely Polonkai" . "gergely@polonkai.eu"))
  :maintainers '(("Gergely Polonkai" . "gergely@polonkai.eu")))
