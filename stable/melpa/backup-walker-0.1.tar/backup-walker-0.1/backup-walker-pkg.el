;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "backup-walker" "0.1"
  "Quickly traverse all backups of a file."
  ()
  :url "https://github.com/lewang/backup-walker"
  :commit "149a4e579d970558eb0e52116fa2799c14e9b075"
  :revdesc "149a4e579d97")
