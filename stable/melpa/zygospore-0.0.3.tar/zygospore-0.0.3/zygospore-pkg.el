;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zygospore" "0.0.3"
  "Reversible C-x 1 (delete-other-windows)."
  ()
  :url "https://github.com/louiskottmann/zygospore.el"
  :commit "1af5ee663f5a7aa08d96a77cacff834dcdf55ea8"
  :revdesc "0.0.3-0-g1af5ee663f5a"
  :authors '(("Louis Kottmann" . "louis.kottmann@gmail.com"))
  :maintainers '(("Louis Kottmann" . "louis.kottmann@gmail.com")))
