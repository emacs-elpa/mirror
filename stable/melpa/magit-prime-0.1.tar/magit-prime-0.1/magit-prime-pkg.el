;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-prime" "0.1"
  "Prime cache before Magit refresh."
  '((emacs "27.1")
    (magit "3.0.0"))
  :url "https://github.com/Azkae/magit-prime"
  :commit "9b089bb1659748be077e7eab5a3846c28cf49af2"
  :revdesc "9b089bb16597"
  :authors '(("Romain Ouabdelkader" . "romain.ouabdelkader@gmail.com"))
  :maintainers '(("Romain Ouabdelkader" . "romain.ouabdelkader@gmail.com")))
