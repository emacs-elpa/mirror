;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dfmt" "0.1.0"
  "[No description available]."
  ()
  :url "https://github.com/qsimpleq/elisp-dfmt"
  :commit "0bbf80c2e602abef5665f9c497615a58f448aeb5"
  :revdesc "0bbf80c2e602"
  :keywords '("tools" "convenience" "languages" "dlang")
  :maintainers '(("Kirill Babikhin" . "qsimpleq")))
