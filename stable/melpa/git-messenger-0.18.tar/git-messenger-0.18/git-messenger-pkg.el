;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-messenger" "0.18"
  "Pop up last commit information of current line."
  '((emacs "24.3")
    (popup "0.5.0"))
  :url "https://github.com/syohex/emacs-git-messenger"
  :commit "9297464c010dd8a2d584ac8e012876856655a8b5"
  :revdesc "9297464c010d"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
