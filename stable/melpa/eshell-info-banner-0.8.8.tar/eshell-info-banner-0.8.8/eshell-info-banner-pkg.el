;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-info-banner" "0.8.8"
  "System information as your Eshell banner."
  '((emacs "25.1")
    (s     "1"))
  :url "https://github.com/Phundrak/eshell-info-banner.el"
  :commit "27b0be266beaedd594bf0022582567454107af5f"
  :revdesc "27b0be266bea"
  :authors '(("Lucien Cartier-Tilet" . "lucien@phundrak.com"))
  :maintainers '(("Lucien Cartier-Tilet" . "lucien@phundrak.com")))
