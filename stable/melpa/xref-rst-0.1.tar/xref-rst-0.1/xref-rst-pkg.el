;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xref-rst" "0.1"
  "Lookup reStructuredText symbols."
  '((emacs "26.1"))
  :url "https://gitlab.com/ideasman42/emacs-xref-rst"
  :commit "3e7360553f46461cbcacdb18cbb7a214d55b89f7"
  :revdesc "3e7360553f46"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
