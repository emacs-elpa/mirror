;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mips-mode" "1.2.0"
  "Major-mode for MIPS assembly."
  '((emacs "25.1"))
  :url "https://github.com/hlissner/emacs-mips-mode"
  :commit "98795cdc81979821ac35d9f94ce354cd99780c67"
  :revdesc "v1.2.0-0-g98795cdc8197"
  :keywords '("languages" "mips" "assembly")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
