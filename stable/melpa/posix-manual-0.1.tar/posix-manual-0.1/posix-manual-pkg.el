;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "posix-manual" "0.1"
  "POSIX manual page lookup."
  '((emacs "24"))
  :url "https://github.com/lassik/emacs-posix-manual"
  :commit "ebaacd7266ae7a66605317f57b9f42e9cfb2ce1e"
  :revdesc "0.1-0-gebaacd7266ae"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
