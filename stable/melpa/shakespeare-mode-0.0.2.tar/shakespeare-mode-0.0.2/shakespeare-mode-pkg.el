;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shakespeare-mode" "0.0.2"
  "A major mode for editing Shakespearean templates."
  ()
  :url "https://github.com/CodyReichert/shakespeare-mode"
  :commit "c442eeea9d585e1b1fbb8813e33d47feec348a57"
  :revdesc "v0.0.2-0-gc442eeea9d58"
  :keywords '("shakespeare" "hamlet" "lucius" "julius" "mode"))
