;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-library" "0.1"
  "Use org-mode to manage the code blocks."
  ()
  :url "https://github.com/lujun9972/code-library"
  :commit "45928d61d373e987c617ac743076cbb946356078"
  :revdesc "45928d61d373"
  :keywords '("lisp" "code")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
