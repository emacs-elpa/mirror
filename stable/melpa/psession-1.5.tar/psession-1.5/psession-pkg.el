;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "psession" "1.5"
  "Persistent save of elisp objects."
  '((emacs  "24")
    (cl-lib "0.5")
    (async  "1.9.3"))
  :url "https://github.com/thierryvolpiatto/psession"
  :commit "702d20897c0839568201bc6921d5f0f80b8778c0"
  :revdesc "v1.5-0-g702d20897c08"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")))
