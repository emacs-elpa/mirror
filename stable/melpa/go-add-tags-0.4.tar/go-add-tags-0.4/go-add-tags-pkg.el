;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-add-tags" "0.4"
  "Add field tags for struct fields."
  '((emacs "24.3")
    (s     "1.11.0"))
  :url "https://github.com/syohex/emacs-go-add-tags"
  :commit "54879945e46a0884c5f93d7fd6c866a9cdf401ac"
  :revdesc "54879945e46a"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
