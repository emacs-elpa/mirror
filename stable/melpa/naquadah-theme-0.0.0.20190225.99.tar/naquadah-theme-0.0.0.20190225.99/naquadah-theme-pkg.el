;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "naquadah-theme" "0.0.0.20190225.99"
  "A theme based on Tango color set."
  ()
  :url "https://github.com/jd/naquadah-theme"
  :commit "430c3b7bd51922cb616b3f60301f4e2604816ed8"
  :revdesc "430c3b7bd519"
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")))
