;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-anaconda" "0.2.0"
  "Anaconda backend for company-mode."
  '((company       "0.8.0")
    (anaconda-mode "0.1.1")
    (cl-lib        "0.5.0")
    (dash          "2.6.0")
    (s             "1.9"))
  :url "https://github.com/proofit404/anaconda-mode"
  :commit "182a8fdabc01630f255beeb2708728c0cd5c6316"
  :revdesc "182a8fdabc01"
  :authors '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers '(("Artem Malyshev" . "proofit404@gmail.com")))
