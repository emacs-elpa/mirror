;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ll-debug" "2.0.4"
  "Low level debug tools."
  '((emacs "24.3"))
  :url "https://github.com/replrep/ll-debug"
  :commit "f551a7e1d5ecd64608db744d0f0e24aa0b8645fe"
  :revdesc "f551a7e1d5ec"
  :keywords '("abbrev" "convenience" "tools" "c" "lisp")
  :authors '(("Claus Brunzema" . "mail@cbrunzema.de"))
  :maintainers '(("Claus Brunzema" . "mail@cbrunzema.de")))
