;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-project" "0.2.0"
  "Terminal management for project.el."
  '((emacs        "28.1")
    (term-manager "0.1.0"))
  :url "https://www.github.com/IvanMalison/term-manager"
  :commit "31a3d16ba5a4f9e6f4bc52275eaedf55a96154a8"
  :revdesc "31a3d16ba5a4"
  :keywords '("project" "tools" "terminals" "vc")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com")
             ("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")
                 ("ROCKTAKEY" . "rocktakey@gmail.com")))
