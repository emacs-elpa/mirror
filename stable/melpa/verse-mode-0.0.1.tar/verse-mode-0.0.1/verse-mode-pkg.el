;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verse-mode" "0.0.1"
  "Major mode for Epic's Verse language (UEFN)."
  '((emacs "26.1"))
  :url "https://github.com/sness23/verse-mode"
  :commit "003170808ead4b62cd032da33c7efbe6e4659478"
  :revdesc "003170808ead"
  :keywords '("languages" "tools")
  :authors '(("Steven Ness" . "sness@sness.net"))
  :maintainers '(("Steven Ness" . "sness@sness.net")))
