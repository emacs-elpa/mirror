;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "extempore-mode" "1.0"
  "Emacs major mode for Extempore source files."
  ()
  :url "https://github.com/extemporelang/extempore-emacs-mode"
  :commit "da6357cec74e3b92f1483d55efdfef1552e216ea"
  :revdesc "da6357cec74e"
  :keywords '("extempore")
  :authors '(("Ben Swift" . "ben@benswift.me"))
  :maintainers '(("Ben Swift" . "ben@benswift.me")))
