;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tco" "0.3"
  "Tail-call optimisation for Emacs lisp."
  '((dash  "1.2.0")
    (emacs "24"))
  :url "https://github.com/Wilfred/tco.el"
  :commit "e304122d66952d572cbed740e2def3abed1a1a7c"
  :revdesc "e304122d6695"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
