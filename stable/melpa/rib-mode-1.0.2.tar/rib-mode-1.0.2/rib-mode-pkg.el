;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rib-mode" "1.0.2"
  "RenderMan® Interface Bytestream (RIB) Major Mode."
  '((emacs "24"))
  :url "https://github.com/blezek/rib-mode"
  :commit "4172e902fd66f235184c0eb6db7fd4a73dbd0866"
  :revdesc "4172e902fd66"
  :authors '(("Remik Ziemlinski and Daniel Blezek" . "daniel.blezek@gmail.com"))
  :maintainers '(("Remik Ziemlinski and Daniel Blezek" . "daniel.blezek@gmail.com")))
