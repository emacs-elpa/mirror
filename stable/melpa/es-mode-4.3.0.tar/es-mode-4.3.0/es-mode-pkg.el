;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "es-mode" "4.3.0"
  "A major mode for editing Elasticsearch queries."
  '((dash   "2.11.0")
    (cl-lib "0.5")
    (spark  "1.0"))
  :url "http://www.github.com/dakrone/es-mode"
  :commit "996730ebce57d810d2c275c7fadb11c2b1134dea"
  :revdesc "4.3.0-0-g996730ebce57"
  :keywords '("elasticsearch")
  :authors '(("Lee Hinman" . "lee@writequit.org"))
  :maintainers '(("Lee Hinman" . "lee@writequit.org")))
