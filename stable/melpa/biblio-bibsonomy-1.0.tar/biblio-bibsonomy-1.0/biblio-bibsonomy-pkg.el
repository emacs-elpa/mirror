;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "biblio-bibsonomy" "1.0"
  "Lookup and import bibliographic entries from Bibsonomy."
  '((emacs       "24")
    (biblio-core "0.2"))
  :url "https://github.com/andreasjansson/biblio-bibsonomy/"
  :commit "7509260efeb54d719739072e6d5169f8fb0ef394"
  :revdesc "7509260efeb5"
  :keywords '("bibliography" "bibtex" "bibsonomy"))
