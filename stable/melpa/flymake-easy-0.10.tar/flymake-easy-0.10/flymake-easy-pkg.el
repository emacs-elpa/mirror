;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-easy" "0.10"
  "Helpers for easily building flymake checkers."
  ()
  :url "https://github.com/purcell/flymake-easy"
  :commit "2a24f260cdc3b9c8f9263b653a475d90efa1d392"
  :revdesc "2a24f260cdc3"
  :keywords '("convenience" "internal")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
