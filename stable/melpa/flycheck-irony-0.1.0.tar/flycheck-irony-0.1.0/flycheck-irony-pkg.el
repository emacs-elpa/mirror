;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-irony" "0.1.0"
  "Flycheck: C/C++ support via Irony."
  '((emacs    "24.1")
    (flycheck "0.22")
    (irony    "0.2.0"))
  :url "https://github.com/Sarcasm/flycheck-irony/"
  :commit "34940ae5ab8f4c721d9c1118ebfc3496d7e67a84"
  :revdesc "34940ae5ab8f"
  :keywords '("convenience" "tools" "c")
  :authors '(("Guillaume Papin" . "guillaume.papin@epitech.eu"))
  :maintainers '(("Guillaume Papin" . "guillaume.papin@epitech.eu")))
