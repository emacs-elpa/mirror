;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elot" "2.1.0"
  "Emacs Literate Ontology Tool (ELOT)."
  '((emacs "30.1"))
  :url "https://github.com/johanwk/elot"
  :commit "62e4ce56610caf2336a19f23418bea819c1e36b7"
  :revdesc "v2.1.0-0-g62e4ce56610c"
  :keywords '("languages" "outlines" "tools" "org" "ontology")
  :authors '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com"))
  :maintainers '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com")))
