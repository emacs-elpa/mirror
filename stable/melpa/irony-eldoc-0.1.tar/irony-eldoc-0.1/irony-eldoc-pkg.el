;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "irony-eldoc" "0.1"
  "[No description available]."
  '((emacs  "24")
    (cl-lib "0.5")
    (irony  "0.1"))
  :url "https://github.com/ikirill/irony-eldoc"
  :commit "1a1241a4ad26a8bb94f652ac125996efc53c4539"
  :revdesc "1a1241a4ad26"
  :keywords '("c" "c++" "objc" "convenience" "tools")
  :authors '(("Kirill Ignatiev" . "github.com/ikirill"))
  :maintainers '(("Kirill Ignatiev" . "github.com/ikirill")))
