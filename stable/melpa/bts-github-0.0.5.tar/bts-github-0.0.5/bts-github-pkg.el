;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bts-github" "0.0.5"
  "A plugin of bts.el for GitHub."
  '((bts "0.0.1")
    (gh  "0.8.2"))
  :url "https://github.com/aki2o/emacs-bts-github"
  :commit "57c23f2b842f6775f0bbbdff97eeec78474be6bc"
  :revdesc "57c23f2b842f"
  :keywords '("convenience")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
