;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macrostep-geiser" "0.2.0"
  "Macrostep for `geiser'."
  '((emacs     "24.4")
    (macrostep "0.9")
    (geiser    "0.12"))
  :url "https://github.com/nbfalcon/macrostep-geiser"
  :commit "7927651b188cac07113bce5b2cd0de12b2b082f7"
  :revdesc "7927651b188c"
  :keywords '("languages" "scheme"))
