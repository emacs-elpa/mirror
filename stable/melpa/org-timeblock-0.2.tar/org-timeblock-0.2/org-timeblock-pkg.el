;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timeblock" "0.2"
  "Interactive SVG calendar for orgmode tasks."
  '((emacs  "28.1")
    (compat "29.1.4.1")
    (org    "9.0")
    (svg    "1.1"))
  :url "https://github.com/ichernyshovvv/org-timeblock"
  :commit "830479285fef28e57d5024c4475a77e7ef1b73a7"
  :revdesc "830479285fef"
  :keywords '("org" "calendar" "timeblocking" "agenda")
  :authors '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainers '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com")))
