;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-explore" "4.0"
  "Explore and visualise Denote files."
  '((emacs  "29.1")
    (denote "4.0")
    (dash   "2.19.1"))
  :url "https://github.com/pprevos/denote-explore/"
  :commit "bd5b6db435b93a2c6da694b196b4b41c5b17f68a"
  :revdesc "bd5b6db435b9"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
