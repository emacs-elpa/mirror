;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-utils" "0.1.0"
  "Buffer-manipulation utility functions."
  ()
  :url "https://github.com/rolandwalker/buffer-utils"
  :commit "b4d325543e25518d725a2122b49cd72a0d6a079a"
  :revdesc "v0.1.0-0-gb4d325543e25"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
