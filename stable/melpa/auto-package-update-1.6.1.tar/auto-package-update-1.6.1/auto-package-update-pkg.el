;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-package-update" "1.6.1"
  "Automatically update Emacs packages."
  '((emacs "24.4")
    (dash  "2.1.0"))
  :url "https://github.com/rranelli/auto-package-update.el"
  :commit "cdef79f9fc6f8347fdd05664978fb9a948ea0410"
  :revdesc "cdef79f9fc6f"
  :keywords '("package" "update"))
