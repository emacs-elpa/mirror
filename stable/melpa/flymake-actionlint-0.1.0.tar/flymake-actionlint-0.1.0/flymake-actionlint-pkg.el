;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-actionlint" "0.1.0"
  "A Flymake handler for actionlint."
  '((emacs        "24.1")
    (flymake-easy "0.0.0"))
  :url "https://github.com/ROCKTAKEY/flymake-actionlint"
  :commit "59d1f17a52bd48ad39f18900c8c77255f9f37718"
  :revdesc "v0.1.0-0-g59d1f17a52bd"
  :keywords '("convenience")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
