;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "django-snippets" "0.0.0.20131229.56"
  "Yasnippets for django."
  '((yasnippet "0.8.0"))
  :url "https://github.com/myfreeweb/django-mode"
  :commit "f1e6fea8878bebc9bc0b761376a14cd5c9feda0f"
  :revdesc "f1e6fea8878b"
  :authors '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
