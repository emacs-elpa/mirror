;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-org-roam" "0.1"
  "Consult integration for org-roam."
  '((emacs "24.4"))
  :url "https://github.com/jgru/consult-org-roam"
  :commit "5ed4caa436483ec2fcf2ff7665bc6402b4a15f45"
  :revdesc "5ed4caa43648"
  :authors '(("jgru" . "https://github.com/jgru"))
  :maintainers '(("jgru" . "https://github.com/jgru")))
