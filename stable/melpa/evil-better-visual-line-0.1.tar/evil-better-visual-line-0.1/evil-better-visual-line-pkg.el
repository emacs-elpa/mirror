;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-better-visual-line" "0.1"
  "Gj and gk visual line mode fix."
  '((evil "1.2.13"))
  :url "https://github.com/yourfin/evil-better-visual-line"
  :commit "05e8270ae62e71b652513407c561b136c258f04c"
  :revdesc "05e8270ae62e"
  :keywords '("evil" "vim" "motion")
  :authors '((nil . "nuckollspatgmail.com"))
  :maintainers '((nil . "nuckollspatgmail.com")))
