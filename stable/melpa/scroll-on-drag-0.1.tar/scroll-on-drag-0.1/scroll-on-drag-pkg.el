;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scroll-on-drag" "0.1"
  "Interactive scrolling."
  '((emacs "26.2"))
  :url "https://github.com/ideasman42/emacs-scroll-on-drag"
  :commit "a668537a8da77e4425b6a4110bdaba598a295f9e"
  :revdesc "a668537a8da7"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
