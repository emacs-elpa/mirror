;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tab-group" "0.1"
  "Grouped tabs and their tabbar."
  ()
  :url "https://github.com/tarao/tab-group-el"
  :commit "bbad074ef91d5436c0ab12bec6ccfc86e0961460"
  :revdesc "bbad074ef91d"
  :keywords '("convenience" "tabs")
  :authors '(("INA Lintaro" . "tarao.gnnatgmail.com"))
  :maintainers '(("INA Lintaro" . "tarao.gnnatgmail.com")))
