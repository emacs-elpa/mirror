;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clj-deps-new" "1.1"
  "Create clojure projects from templates."
  '((emacs     "25.1")
    (transient "0.3.7"))
  :url "https://github.com/jpe90/emacs-deps-new"
  :commit "0ac29c008395ab2d9ad411b6f800b1f2a0a3e983"
  :revdesc "0ac29c008395"
  :authors '(("jpe90" . "eskinjp@gmail.com"))
  :maintainers '(("jpe90" . "eskinjp@gmail.com")))
