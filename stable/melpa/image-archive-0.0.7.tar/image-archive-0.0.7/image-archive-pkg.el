;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "image-archive" "0.0.7"
  "Image thumbnails in archive file with non-blocking."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/mhayashi1120/Emacs-image-archive/raw/master/image-archive.el"
  :commit "699e967fa7b1dfcce2bf2ec878e74f4238bb6e45"
  :revdesc "699e967fa7b1"
  :keywords '("multimedia")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
