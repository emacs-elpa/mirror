;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "svgo" "1.0.3"
  "SVG optimization with SVGO."
  '((emacs "26.2"))
  :url "https://github.com/hupf/svgo.el/"
  :commit "9b01cc9eb1fdf2731cd2b931a7dfe1f601b70786"
  :revdesc "9b01cc9eb1fd"
  :keywords '("tools")
  :authors '(("Mathis Hofer" . "mathis@fsfe.org"))
  :maintainers '(("Mathis Hofer" . "mathis@fsfe.org")))
