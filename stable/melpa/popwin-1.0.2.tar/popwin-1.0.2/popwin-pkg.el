;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popwin" "1.0.2"
  "Popup Window Manager."
  '((emacs "24.3"))
  :url "https://github.com/emacsorphanage/popwin"
  :commit "215d6cb509b11c63394a20666565cd9e9b2c2eab"
  :revdesc "215d6cb509b1"
  :keywords '("convenience")
  :authors '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainers '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com")))
