;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eta" "0.1"
  "Standard and multi dispatch key bind; -*-."
  '((emacs "25.1"))
  :url "https://www.github.com/zcaudate/eta"
  :commit "0313130a9544c5a7df8ffcd02c7eb21c6246a44e"
  :revdesc "0313130a9544"
  :keywords '("convenience" "usability"))
