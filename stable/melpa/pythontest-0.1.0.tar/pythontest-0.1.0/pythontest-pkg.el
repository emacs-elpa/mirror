;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pythontest" "0.1.0"
  "Testing executor for python."
  '((emacs "29.1"))
  :url "https://github.com/erickgnavar/pythontest.el"
  :commit "d4a928ac20b80350f1860bf44f3791bcd9348864"
  :revdesc "d4a928ac20b8"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
