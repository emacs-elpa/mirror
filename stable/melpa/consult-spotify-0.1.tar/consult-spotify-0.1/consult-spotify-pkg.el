;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-spotify" "0.1"
  "Spotify queries using consult."
  '((emacs      "26.1")
    (consult    "0.5")
    (marginalia "0.3")
    (espotify   "0.1"))
  :url "https://codeberg.org/jao/espotify"
  :commit "2d37ff1a59b5c842902f5ebc10d3d0debff7ac9e"
  :revdesc "2d37ff1a59b5"
  :keywords '("media")
  :authors '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
