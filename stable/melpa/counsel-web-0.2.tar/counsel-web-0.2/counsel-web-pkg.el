;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-web" "0.2"
  "Search the Web using Ivy."
  '((emacs   "24.5")
    (counsel "0.13.0")
    (request "0.3.0"))
  :url "https://github.com/mnewt/counsel-web"
  :commit "9fae9c089d2d6bbac1a063581719f953b9d29ef0"
  :revdesc "9fae9c089d2d"
  :keywords '("convenience" "hypermedia")
  :authors '(("Matthew Sojourner Newton" . "matt@mnewton.com"))
  :maintainers '(("Matthew Sojourner Newton" . "matt@mnewton.com")))
