;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "1.0.0"
  "Shared infrastructure for Tokyo Night themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "17856a5d0184512c165f06b32e0749230318086a"
  :revdesc "17856a5d0184"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
