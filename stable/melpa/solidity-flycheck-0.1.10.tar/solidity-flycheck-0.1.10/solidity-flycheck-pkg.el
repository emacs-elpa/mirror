;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solidity-flycheck" "0.1.10"
  "Flycheck integration for solidity emacs mode."
  '((flycheck      "32-cvs")
    (solidity-mode "0.1.9"))
  :url "https://github.com/ethereum/emacs-solidity"
  :commit "93412f211fad7dfc3b02aa226856fc52b6a15c22"
  :revdesc "93412f211fad"
  :keywords '("languages" "solidity" "flycheck")
  :authors '(("Lefteris Karapetsas" . "lefteris@refu.co"))
  :maintainers '(("Lefteris Karapetsas" . "lefteris@refu.co")))
