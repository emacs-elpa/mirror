;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pumpkin-spice-theme" "0.1.0"
  "Spice up your day with a delightful pumpkin colored theme."
  '((emacs      "27.1")
    (autothemer "0.2"))
  :url "https://cicadas.surf/cgit/pumpkin-spice-theme.git"
  :commit "e87ad63bcf39cdde7b26bf5f1e30c899b0c6005c"
  :revdesc "e87ad63bcf39"
  :keywords '("faces" "theme" "halloween" "pumpkin")
  :authors '(("Grant Shangreaux" . "shoshin@cicadas.surf"))
  :maintainers '(("Grant Shangreaux" . "shoshin@cicadas.surf")))
