;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emc" "0.42"
  "Invoking a C/C++ (et al.) build toolchain from ELisp."
  '((delight "1.7")
    (emacs   "29.1"))
  :url "https://github.com/marcoxa/emc"
  :commit "0515a79a0b64acca54c5ff6531ee149a733a819a"
  :revdesc "0515a79a0b64"
  :keywords '("extensions" "c" "lisp" "building tools" "development" "deployment.")
  :authors '(("Marco Antoniotti" . "marcoxa[at]gmail.com"))
  :maintainers '(("Marco Antoniotti" . "marcoxa[at]gmail.com")))
