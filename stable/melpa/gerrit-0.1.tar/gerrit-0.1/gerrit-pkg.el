;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gerrit" "0.1"
  "Gerrit integration @ IMS."
  '((emacs "25.1"))
  :url "https://github.com/thisch/gerrit.el"
  :commit "7c37a6d2236f3108456134feb0916a8b04c356ca"
  :revdesc "7c37a6d2236f"
  :keywords '("extensions")
  :authors '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainers '(("Thomas Hisch" . "t.hisch@gmail.com")))
