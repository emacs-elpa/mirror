;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ros" "1.0.0"
  "Description."
  '((emacs "24.3"))
  :url "https://github.com/DerBeutlin/ros.el"
  :commit "63d46cefa8552b59556dcb4af0849253dc501ee9"
  :revdesc "63d46cefa855"
  :keywords '("symbol’s" "value" "as" "variable" "is" "void:" "finder-known-keywords")
  :authors '(("Max Beutelspacher" . "https://github.com/mtb"))
  :maintainers '(("Max Beutelspacher" . "max@beutelspacher.eu")))
