;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcmpl-args" "0.1.3"
  "Enhanced shell command completion."
  '((emacs "25.1"))
  :url "https://github.com/JonWaltman/pcmpl-args.el"
  :commit "5f2943fd70d94065496c52d21f05eb89028637cc"
  :revdesc "5f2943fd70d9"
  :keywords '("abbrev" "completion" "convenience" "processes" "terminals" "unix")
  :authors '(("Jonathan Waltman" . "jonathan.waltman@gmail.com"))
  :maintainers '(("Jonathan Waltman" . "jonathan.waltman@gmail.com")))
