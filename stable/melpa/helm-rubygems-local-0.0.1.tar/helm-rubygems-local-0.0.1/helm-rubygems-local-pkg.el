;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-rubygems-local" "0.0.1"
  "Installed local rubygems find-file for helm."
  ()
  :url "https://github.com/f-kubotar/helm-rubygems-local"
  :commit "39dde4c623e53a5cb7581ab50be51ad968f912e9"
  :revdesc "39dde4c623e5"
  :authors '(("hadashiA" . "dev@hadashikick.jp"))
  :maintainers '(("hadashiA" . "dev@hadashikick.jp")))
