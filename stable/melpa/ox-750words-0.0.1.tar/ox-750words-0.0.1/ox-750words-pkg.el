;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-750words" "0.0.1"
  "Org mode exporter for 750words.com."
  '((emacs "24.3"))
  :url "https://github.com/zzamboni/750words-client"
  :commit "655563ec04dfb29d8cba6f23dd8412c2c32bb502"
  :revdesc "655563ec04df"
  :keywords '("files" "org" "writing")
  :authors '(("Diego Zamboni" . "https://github.com/zzamboni"))
  :maintainers '(("Diego Zamboni" . "diego@zzamboni.org")))
