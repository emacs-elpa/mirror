;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "0.1.0"
  "Insert SPDX license header."
  '((emacs "24.1"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "9eb1c6664b27a9d9bfbd336c26fea775f108419e"
  :revdesc "9eb1c6664b27"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
