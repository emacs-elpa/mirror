;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc-cand-posframe" "0.1"
  "Posframe frontend for mozc.el."
  '((emacs    "26.1")
    (posframe "0.5.0")
    (mozc     "0"))
  :url "https://github.com/akirak/mozc-posframe"
  :commit "a55cbbc8e1ee197a17a784fa7f6bccbf8ba45877"
  :revdesc "a55cbbc8e1ee"
  :keywords '("mule" "multilingual" "input method" "tooltip")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
