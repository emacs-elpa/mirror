;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.4.0"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "0f55c96b6649872155d5486acb749710b3726e4a"
  :revdesc "v2.4.0-0-g0f55c96b6649"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
