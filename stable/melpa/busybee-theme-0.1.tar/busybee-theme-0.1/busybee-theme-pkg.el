;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "busybee-theme" "0.1"
  "Port of vim's mustang theme."
  ()
  :url "https://github.com/mswift42/busybee-theme"
  :commit "7e4af8178b57e2b924c6c99134c7c51ab2c4ce9b"
  :revdesc "7e4af8178b57")
