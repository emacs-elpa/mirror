;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-indent" "1.0.0"
  "Indent-lint frontend for flycheck."
  '((emacs       "24.4")
    (indent-lint "0.0.1")
    (flycheck    "31"))
  :url "https://github.com/conao3/indent-lint.el"
  :commit "5601a716d4daeb444642736ddef420cbc1047968"
  :revdesc "5601a716d4da"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
