;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "network-watch" "1.0"
  "Support for intermitent network connectivity."
  '((emacs "24.3"))
  :url "https://github.com/jamiguet/ja-network"
  :commit "2b48c765bd2d33099c92ee2c64eb581a211407d4"
  :revdesc "2b48c765bd2d"
  :keywords '("unix" "tools" "hardware" "lisp")
  :authors '(("Juan Amiguet Vercher" . "jamiguet@gmail.com"))
  :maintainers '(("Juan Amiguet Vercher" . "jamiguet@gmail.com")))
