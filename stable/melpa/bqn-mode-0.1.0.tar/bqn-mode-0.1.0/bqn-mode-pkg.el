;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bqn-mode" "0.1.0"
  "Emacs mode for BQN."
  '((emacs "24.3"))
  :url "https://github.com/museoa/bqn-mode"
  :commit "6fd508d383643f488110744aa7c2a9f107059374"
  :revdesc "6fd508d38364"
  :authors '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainers '(("Marshall Lochbaum" . "mwlochbaum@gmail.com")))
