;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rum-mode" "1.2"
  "Major mode for Rum programming language."
  '((emacs "24"))
  :url "https://github.com/rumlang/rum-mode"
  :commit "881fda4dd47108255c08661a9589bb1c5ba6bc05"
  :revdesc "881fda4dd471"
  :keywords '("rum" "languages" "lisp")
  :authors '(("Avelino" . "t@avelino.xxx"))
  :maintainers '(("Avelino" . "t@avelino.xxx")))
