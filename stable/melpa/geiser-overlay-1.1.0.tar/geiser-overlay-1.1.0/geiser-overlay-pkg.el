;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-overlay" "1.1.0"
  "Overlay Scheme evaluation results."
  '((emacs  "24.4")
    (geiser "0.31"))
  :url "https://github.com/port19x/geiser-overlay"
  :commit "6e2eaf7e10130a6d782e40bf42c97be63ba3b71f"
  :revdesc "6e2eaf7e1013"
  :keywords '("lisp" "scheme")
  :authors '(("port19" . "port19@port19.xyz"))
  :maintainers '(("port19" . "port19@port19.xyz")))
