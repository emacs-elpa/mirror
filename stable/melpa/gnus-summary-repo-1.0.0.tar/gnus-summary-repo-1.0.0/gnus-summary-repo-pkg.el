;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-summary-repo" "1.0.0"
  "Import and export files between IMAP and local by using GNUS."
  '((emacs "25"))
  :url "https://github.com/TxGVNN/gnus-summary-repo"
  :commit "3968667bfded60fbbf33f2fba3170e2b6501ec43"
  :revdesc "1.0.0-0-g3968667bfded"
  :keywords '("gnus" "repository")
  :authors '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers '(("Giap Tran" . "txgvnn@gmail.com")))
