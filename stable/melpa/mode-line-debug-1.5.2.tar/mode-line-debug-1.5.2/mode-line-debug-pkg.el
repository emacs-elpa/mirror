;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mode-line-debug" "1.5.2"
  "Show status of debug-on-error in mode-line."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/mode-line-debug"
  :commit "a6c26f9d8b574edd3001b8abc6c4801048428385"
  :revdesc "v1.5.2-0-ga6c26f9d8b57"
  :keywords '("convenience" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.mode-line-debug@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.mode-line-debug@jonas.bernoulli.dev")))
