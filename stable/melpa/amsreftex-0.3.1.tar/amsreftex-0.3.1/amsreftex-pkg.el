;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amsreftex" "0.3.1"
  "Add amsrefs bibliography support for reftex."
  '((emacs "25.1"))
  :url "https://github.com/franburstall/amsreftex"
  :commit "4c379074ca73796291b9d4e681a4fa52be835ad7"
  :revdesc "4c379074ca73"
  :keywords '("tex")
  :authors '(("Fran Burstall" . "fran.burstall@gmail.com"))
  :maintainers '(("Fran Burstall" . "fran.burstall@gmail.com")))
