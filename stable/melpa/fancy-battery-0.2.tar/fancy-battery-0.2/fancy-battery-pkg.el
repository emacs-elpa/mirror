;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-battery" "0.2"
  "Fancy battery display."
  '((emacs "24.1"))
  :url "https://github.com/lunaryorn/fancy-battery.el"
  :commit "5b8115bbeb67c52d4202a12dcd5726fb66e0a1ff"
  :revdesc "0.2-0-g5b8115bbeb67"
  :keywords '("convenience" "tools" "hardware")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
