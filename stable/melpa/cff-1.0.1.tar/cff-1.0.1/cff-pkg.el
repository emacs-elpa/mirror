;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cff" "1.0.1"
  "Search of the C/C++ file header by the source and vice versa."
  '((cl-lib "0.5")
    (emacs  "24"))
  :url "https://github.com/fourier/eff"
  :commit "32eac6d3607961b7eaa2090cf75e7dcedc2cf0c0"
  :revdesc "32eac6d36079"
  :keywords '("find-file")
  :authors '(("Alexey Veretennikov" . "alexeydotveretennikovatgmaildotcom"))
  :maintainers '(("Alexey Veretennikov" . "alexeydotveretennikovatgmaildotcom")))
