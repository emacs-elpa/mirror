;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blog-minimal" "0.1"
  "A very simple static site generator based on org mode."
  '((ht           "1.5")
    (simple-httpd "1.4.6")
    (mustache     "0.22")
    (s            "1.11.0")
    (org          "9.0.3"))
  :url "https://github.com/thiefuniverse/blog-minimal"
  :commit "4fb4a70fb800a74620b161db94bafbab93604354"
  :revdesc "4fb4a70fb800"
  :keywords '("blog" "org")
  :authors '(("Thank Fly" . "thiefuniverses@gmail.com"))
  :maintainers '(("Thank Fly" . "thiefuniverses@gmail.com")))
