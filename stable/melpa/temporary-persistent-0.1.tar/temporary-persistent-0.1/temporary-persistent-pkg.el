;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "temporary-persistent" "0.1"
  "Keep temp notes buffers persistent -*- lexical-binding: t."
  '((emacs "24.3")
    (names "20151201.0")
    (dash  "2.12.1"))
  :url "https://github.com/kostafey/temporary-persistent"
  :commit "65628a46fb35675c7bd218a3abeb5d2f96807067"
  :revdesc "65628a46fb35"
  :keywords '("temp" "buffers" "notes")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
