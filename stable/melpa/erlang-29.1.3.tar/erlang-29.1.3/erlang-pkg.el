;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "29.1.3"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "7b8fb15471dbd48099aef8ab676d0784cf6d9291"
  :revdesc "OTP-29.1.3-0-g7b8fb15471db"
  :keywords '("erlang" "languages" "processes"))
