;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-assistant" "1.5"
  "Org babel extension for Chat Assistant APIs."
  '((emacs    "28.1")
    (uuidgen  "1.2")
    (deferred "0.5.1")
    (s        "1.12.0")
    (dash     "2.19.1")
    (ht       "0.9"))
  :url "https://github.com/tyler-dodge/org-assistant"
  :commit "3fd329251cc82294cf416518c49830bea69382ea"
  :revdesc "3fd329251cc8"
  :keywords '("convenience")
  :authors '(("Tyler Dodge" . "(tyler@tdodge.consulting)"))
  :maintainers '(("Tyler Dodge" . "(tyler@tdodge.consulting)")))
