;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "icl-mode" "0.1.0"
  "Support for IEEE 1687 ICL/PDL."
  '((emacs "25.2"))
  :url "https://github.com/CeleritasCelery/icl-mode"
  :commit "54dbe8f4d071e431c7003ba754741697e9797976"
  :revdesc "54dbe8f4d071"
  :authors '(("Troy Hinckley" . "troy.hinckley@dabrev.com"))
  :maintainers '(("Troy Hinckley" . "troy.hinckley@dabrev.com")))
