;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crux" "0.6.1"
  "A Collection of Ridiculously Useful eXtensions."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/crux"
  :commit "c0cab0b0423fadf63bdf0f08bd2b74eb0139b893"
  :revdesc "c0cab0b0423f"
  :keywords '("convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
