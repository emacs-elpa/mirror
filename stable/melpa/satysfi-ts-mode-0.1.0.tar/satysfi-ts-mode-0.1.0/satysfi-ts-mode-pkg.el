;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "satysfi-ts-mode" "0.1.0"
  "A tree-sitter based major-mode for SATySFi."
  '((emacs "29.1"))
  :url "https://github.com/Kyure-A/satysfi-ts-mode"
  :commit "9bd6b90a28c2b478dc7fbee98d624c39a54b42d2"
  :revdesc "9bd6b90a28c2"
  :keywords '("languages")
  :authors '(("Kyure_A" . "twitter.com/kyureq"))
  :maintainers '(("Kyure_A" . "twitter.com/kyureq")))
