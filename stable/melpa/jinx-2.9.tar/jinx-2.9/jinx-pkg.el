;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "2.9"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "270866399c959a583caec0115d7dbc069f01ff29"
  :revdesc "2.9-0-g270866399c95"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
