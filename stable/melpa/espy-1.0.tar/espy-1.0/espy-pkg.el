;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "espy" "1.0"
  "Emacs Simple Password Yielder."
  '((emacs "24"))
  :url "https://github.com/walseb/espy"
  :commit "d6757bbecc7ad578cfcc9158e2d88553da7437a1"
  :revdesc "d6757bbecc7a"
  :keywords '("convenience")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
