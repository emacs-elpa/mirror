;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jade-schema-mode" "0.0.1"
  "A major-mode for navigating Jade Platform schema files."
  '((emacs "26.3"))
  :url "https://github.com/danjacka/jade-schema-mode"
  :commit "a2b16762f5c1f795edb58723d0a18fbd07d7857f"
  :revdesc "a2b16762f5c1"
  :keywords '("languages" "tools")
  :authors '(("Dan Jacka" . "danjacka@gmail.com"))
  :maintainers '(("Dan Jacka" . "danjacka@gmail.com")))
