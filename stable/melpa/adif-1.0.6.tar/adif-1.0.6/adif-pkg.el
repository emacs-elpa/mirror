;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adif" "1.0.6"
  "Major mode for viewing and editing ADIF log files."
  '((emacs "25.1"))
  :url "https://github.com/K6SM/adif-mode"
  :commit "f886a36589d49bb843e2531170a8363af915b7f9"
  :revdesc "f886a36589d4"
  :keywords '("comm" "hamradio" "adif" "logging"))
