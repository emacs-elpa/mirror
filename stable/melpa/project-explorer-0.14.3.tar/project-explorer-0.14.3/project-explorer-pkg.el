;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-explorer" "0.14.3"
  "A project explorer sidebar."
  '((cl-lib     "0.3")
    (es-lib     "0.3")
    (es-windows "0.1")
    (emacs      "24"))
  :url "https://github.com/sabof/project-explorer"
  :commit "7c2cc86a81f679dda355110f916366b64893a5d4"
  :revdesc "7c2cc86a81f6")
