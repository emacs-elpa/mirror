;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "direnv" "2.2.0"
  "Support for direnv."
  '((emacs "25.1")
    (dash  "2.12.0"))
  :url "https://github.com/wbolster/emacs-direnv"
  :commit "bd161f38621d1a9e4d70c9bafab9b7e3520f00b2"
  :revdesc "2.2.0-0-gbd161f38621d"
  :keywords '("direnv" "environment" "processes" "unix" "tools")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
