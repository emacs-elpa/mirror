;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pythonic" "0.2.0"
  "Utility functions for writing pythonic emacs package."
  '((emacs "25.1")
    (s     "1.9")
    (f     "0.17.2"))
  :url "https://github.com/proofit404/pythonic"
  :commit "e0e5cc882f2f1316268ec461a34d4be8abc313b7"
  :revdesc "e0e5cc882f2f"
  :authors '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers '(("Artem Malyshev" . "proofit404@gmail.com")))
