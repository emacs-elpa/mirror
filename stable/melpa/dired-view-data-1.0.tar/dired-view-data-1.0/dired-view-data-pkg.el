;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-view-data" "1.0"
  "View data from dired via ESS and R."
  '((emacs         "26.1")
    (ess           "18.10.1")
    (ess-view-data "1.0"))
  :url "https://github.com/ShuguangSun/dired-view-data"
  :commit "c865c34536d9c3140ce647f03c8b7498b46e935c"
  :revdesc "c865c34536d9"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
