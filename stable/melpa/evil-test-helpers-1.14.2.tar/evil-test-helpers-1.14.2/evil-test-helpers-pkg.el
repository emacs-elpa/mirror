;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-test-helpers" "1.14.2"
  "Unit test helpers for Evil."
  '((evil "1.14.2"))
  :url "https://github.com/emacs-evil/evil"
  :commit "162a94cbce4f2c09fa7dd6bd8ca56080cb0ab63b"
  :revdesc "162a94cbce4f"
  :authors '(("Vegard ye" . "vegard_oyeathotmail.com"))
  :maintainers '(("Vegard ye" . "vegard_oyeathotmail.com")))
