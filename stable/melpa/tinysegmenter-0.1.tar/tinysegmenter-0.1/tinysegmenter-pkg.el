;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tinysegmenter" "0.1"
  "Super compact Japanese tokenizer in Javascript ported to emacs lisp."
  ()
  :url "https://github.com/myuhe/tinysegmenter.el"
  :commit "de1b13bbb5a1863813c392c2f90831e32403e9fd"
  :revdesc "de1b13bbb5a1"
  :keywords '("convenience")
  :authors '(("lugecy" . "lugecy@gmail.com")))
