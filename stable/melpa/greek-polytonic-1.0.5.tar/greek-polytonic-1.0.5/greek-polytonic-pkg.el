;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greek-polytonic" "1.0.5"
  "Quail package for inputting polytonic Greek."
  '((emacs "24"))
  :url "https://github.com/jhanschoo/greek-polytonic"
  :commit "5e2c5128bef569a214991cdfe5e43d0ebf7aa7d7"
  :revdesc "5e2c5128bef5"
  :keywords '("i18n" "multilingual" "input method" "greek")
  :authors '(("Johannes Choo" . "jhanschoo@gmail.com"))
  :maintainers '(("Johannes Choo" . "jhanschoo@gmail.com")))
