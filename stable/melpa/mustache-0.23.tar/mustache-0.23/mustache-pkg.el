;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mustache" "0.23"
  "A mustache templating library in emacs lisp."
  '((ht   "0.9")
    (s    "1.3.0")
    (dash "1.2.0"))
  :url "https://github.com/Wilfred/mustache.el"
  :commit "b0ea352813592424164520a49e86c04600242752"
  :revdesc "b0ea35281359"
  :keywords '("mustache" "template")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
