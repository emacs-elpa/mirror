;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-emmet" "0.0.0.20160713.13"
  "Helm sources for emmet-mode's snippets."
  '((helm       "1.0")
    (emmet-mode "1.0.2"))
  :url "https://github.com/yasuyk/helm-emmet"
  :commit "f0364e736b10cf44232053a78de04133a88185ae"
  :revdesc "f0364e736b10"
  :keywords '("convenience" "helm" "emmet")
  :authors '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
