;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "samskritam" "0.2.1"
  "Show samskrit word definitions."
  '((emacs "28.1"))
  :url "https://github.com/thapakrish/samskritam"
  :commit "07fd19057dc8122c6f7174bcd9b36ce711375385"
  :revdesc "07fd19057dc8"
  :keywords '("samskrit" "sanskrit" "संस्कृत" "dictionary" "devanagari" "convenience" "language")
  :authors '(("Krishna Thapa" . "thapakrish@gmail.com"))
  :maintainers '(("Krishna Thapa" . "thapakrish@gmail.com")))
