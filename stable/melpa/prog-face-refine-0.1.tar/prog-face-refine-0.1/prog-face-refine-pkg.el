;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prog-face-refine" "0.1"
  "Refine faces for programming modes."
  '((emacs "28.0"))
  :url "https://codeberg.org/ideasman42/emacs-prog-face-refine"
  :commit "c99853ad732784e27300bdb70d4f1aa59c1f6476"
  :revdesc "c99853ad7327"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
