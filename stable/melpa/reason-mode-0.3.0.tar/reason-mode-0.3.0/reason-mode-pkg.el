;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reason-mode" "0.3.0"
  "A major emacs mode for editing Reason (based on rust-mode)."
  '((emacs "24.0"))
  :url "https://github.com/arichiardi/reason-mode"
  :commit "6b53815a0405be1f364a082d22fe5c900409a01a"
  :revdesc "0.3.0-0-g6b53815a0405"
  :keywords '("languages" "ocaml"))
