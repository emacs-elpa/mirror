;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loc-changes" "1.1"
  "Helps users and programs keep track of positions even after buffer changes."
  ()
  :url "https://github.com/rocky/emacs-loc-changes"
  :commit "8447baff7cb4839ef8d1d747a14e5da85d0cee5b"
  :revdesc "8447baff7cb4")
