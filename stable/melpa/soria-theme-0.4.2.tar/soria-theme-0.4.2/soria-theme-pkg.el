;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soria-theme" "0.4.2"
  "A xoria256 theme with some colors from openSUSE."
  '((emacs "25.1"))
  :url "https://github.com/mssola/soria"
  :commit "c5275d02fcc9f6af2cfebd69bcf69f8cdccbe3ab"
  :revdesc "v0.4.2-0-gc5275d02fcc9"
  :keywords '("faces")
  :authors '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainers '(("Miquel Sabaté Solà" . "mikisabate@gmail.com")))
