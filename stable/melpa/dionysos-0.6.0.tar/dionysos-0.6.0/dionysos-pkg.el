;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dionysos" "0.6.0"
  "Dionysos, a music player for Emacs."
  '((libmpdee "2.1.0")
    (alert    "1.2")
    (s        "1.11.0")
    (dash     "2.12.1")
    (pkg-info "0.5.0")
    (cl-lib   "0.5"))
  :url "https://github.com/nlamirault/dionysos"
  :commit "98bc789d20e41020d6e62d63d3c78f8032fa4bf2"
  :revdesc "98bc789d20e4"
  :keywords '("music")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
