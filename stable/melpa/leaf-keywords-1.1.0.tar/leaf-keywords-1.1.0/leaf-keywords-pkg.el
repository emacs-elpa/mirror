;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-keywords" "1.1.0"
  "Additional keywords for leaf.el."
  '((emacs "24.4"))
  :url "https://github.com/conao3/leaf-keywords.el"
  :commit "9352716f153582cdf801a13e17dc04cfcd2bb951"
  :revdesc "9352716f1535"
  :keywords '("lisp" "settings")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
