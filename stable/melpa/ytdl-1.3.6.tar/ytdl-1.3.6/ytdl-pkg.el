;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ytdl" "1.3.6"
  "Emacs Interface for youtube-dl."
  '((emacs     "26.1")
    (async     "1.9.4")
    (transient "0.2.0")
    (dash      "2.17.0"))
  :url "https://gitlab.com/tuedachu/ytdl"
  :commit "23da64f5c38b8cb83dbbadf704171b86cc0fa937"
  :revdesc "23da64f5c38b"
  :keywords '("comm" "multimedia")
  :authors '(("Arnaud Hoffmann" . "tuedachu@gmail.com"))
  :maintainers '(("Arnaud Hoffmann" . "tuedachu@gmail.com")))
