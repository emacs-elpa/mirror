;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "supersonic" "0.7.3"
  "Music client for Subsonic servers and Music Assistant."
  '((emacs     "28.1")
    (transient "0.2")
    (aio       "1.2"))
  :url "https://github.com/systemfreund/supersonic.el"
  :commit "92b332e02568413c7465c1116adfc3619ce2b130"
  :revdesc "92b332e02568"
  :keywords '("multimedia")
  :authors '(("systemfreund" . "github@o9z.de"))
  :maintainers '(("systemfreund" . "github@o9z.de")))
