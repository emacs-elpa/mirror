;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nice-org-html" "1.2"
  "Prettier org-to-html export."
  '((emacs   "25.1")
    (s       "1.13.0")
    (dash    "2.19.1")
    (htmlize "1.58")
    (uuidgen "1.0"))
  :url "https://github.com/ewantown/nice-org-html"
  :commit "2efaa1b304dfe3bad68574a103e1f766913c6fb9"
  :revdesc "2efaa1b304df"
  :keywords '("org" "org-export" "html" "css" "js" "tools")
  :authors '(("Ewan Townshend" . "ewan@etown.dev"))
  :maintainers '(("Ewan Townshend" . "ewan@etown.dev")))
