;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "1.2.3"
  "Beautify Org Links."
  '((emacs      "28.1")
    (nerd-icons "0.0.1")
    (fb2-reader "0.1.1")
    (qrencode   "1.2"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "c77338cfac89a41f90eafea80d11d8134e8096f4"
  :revdesc "c77338cfac89"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
