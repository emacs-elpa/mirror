;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "openfoam" "0.13"
  "OpenFOAM files and directories."
  '((emacs "25.1"))
  :url "https://github.com/ralph-schleicher/emacs-openfoam"
  :commit "7808319de0326aa293636df6c213467c279ff1ea"
  :revdesc "openfoam-0.13-0-g7808319de032"
  :keywords '("languages")
  :authors '(("Ralph Schleicher" . "rs@ralph-schleicher.de"))
  :maintainers '(("Ralph Schleicher" . "rs@ralph-schleicher.de")))
