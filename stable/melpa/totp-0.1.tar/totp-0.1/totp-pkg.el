;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "totp" "0.1"
  "Time-based One-time Password (TOTP) in elisp."
  '((emacs "27.1"))
  :url "https://github.com/juergenhoetzel/emacs-totp"
  :commit "e390d96b6ec07606f5d7579777b6c95a5503e81f"
  :revdesc "e390d96b6ec0"
  :keywords '("tools")
  :authors '(("Jürgen Hötzel" . "juergen@hoetzel.info"))
  :maintainers '(("Jürgen Hötzel" . "juergen@hoetzel.info")))
