;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "0.5.0"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "1da8d9384c42f559d41d6564e90c03c28b777387"
  :revdesc "1da8d9384c42"
  :keywords '("wp" "convenience"))
