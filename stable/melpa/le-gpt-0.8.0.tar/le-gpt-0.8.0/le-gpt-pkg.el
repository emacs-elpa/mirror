;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "le-gpt" "0.8.0"
  "Emacs on steroids with GPT."
  '((emacs         "28.1")
    (markdown-mode "2.6"))
  :url "https://github.com/AnselmC/le-gpt.el"
  :commit "79662c6a8846a6c667ab6d3521c70050e01b9538"
  :revdesc "79662c6a8846"
  :keywords '("openai" "anthropic" "deepseek" "gpt" "claude" "language" "copilot" "convenience" "tools" "llm")
  :authors '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainers '(("Anselm Coogan" . "anselm.coogan@gmail.com")))
