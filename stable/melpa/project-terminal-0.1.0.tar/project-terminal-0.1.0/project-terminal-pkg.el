;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-terminal" "0.1.0"
  "Per-project terminal management."
  '((emacs   "28.1")
    (project "0.6.0"))
  :url "https://github.com/cowboyd/project-terminal"
  :commit "8558151c62dd84947ac6cdc2d7f41e96f73e9d3a"
  :revdesc "8558151c62dd"
  :keywords '("terminals" "projects" "convenience"))
