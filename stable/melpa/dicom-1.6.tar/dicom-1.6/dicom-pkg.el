;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "1.6"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/dicom"
  :commit "5db856bd206ac899ecd5378eb3cb655b310397f5"
  :revdesc "1.6-0-g5db856bd206a"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
