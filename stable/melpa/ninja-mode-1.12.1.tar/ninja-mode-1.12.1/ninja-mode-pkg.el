;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ninja-mode" "1.12.1"
  "Major mode for editing .ninja files."
  '((emacs "24"))
  :url "https://github.com/ninja-build/ninja"
  :commit "2daa09ba270b0a43e1929d29b073348aa985dfaa"
  :revdesc "2daa09ba270b")
