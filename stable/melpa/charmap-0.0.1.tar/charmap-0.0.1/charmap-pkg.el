;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "charmap" "0.0.1"
  "Unicode table for Emacs."
  ()
  :url "https://github.com/lateau/charmap"
  :commit "165193d91ef96f563ae8366ed4c1a2df5a4eaed2"
  :revdesc "165193d91ef9"
  :keywords '("unicode" "character" "ucs")
  :authors '(("Daehyub Kim" . "lateau@gmail.com"))
  :maintainers '(("Daehyub Kim" . "lateau@gmail.com")))
