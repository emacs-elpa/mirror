;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-flyspell" "0.1.3"
  "Jump to and correct spelling errors using `ace-jump-mode' and flyspell."
  '((avy "0.4.0"))
  :url "https://github.com/cute-jumper/ace-flyspell"
  :commit "044d38fb8eb390ef1f51cf92cfe5c4ffd103044c"
  :revdesc "044d38fb8eb3"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
