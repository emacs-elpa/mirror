;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-recent-headings" "0.1"
  "Jump to recently used Org headings."
  '((emacs    "25.1")
    (org      "9.0.5")
    (dash     "2.13.0")
    (frecency "0.1"))
  :url "https://github.com/alphapapa/org-recent-headings"
  :commit "01633b51ac3958b41cc6c79e6d3714047a91c1e9"
  :revdesc "0.1-0-g01633b51ac39"
  :keywords '("hypermedia" "outlines" "org")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
