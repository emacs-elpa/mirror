;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "owcmd" "0.1"
  "Run a single command in the other window."
  '((emacs "26.3"))
  :url "https://github.com/fishyfriend/owcmd"
  :commit "f83b166f9c17a9c97f0d3c745ae2cf88dfdf9715"
  :revdesc "f83b166f9c17"
  :keywords '("convenience")
  :authors '(("Jacob First" . "jacob.first@member.fsf.org"))
  :maintainers '(("Jacob First" . "jacob.first@member.fsf.org")))
