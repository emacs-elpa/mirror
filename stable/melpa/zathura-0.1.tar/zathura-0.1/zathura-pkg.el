;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zathura" "0.1"
  "Summary."
  '((emacs "24.3"))
  :url "https://codeberg.org/treflip/zathura.el"
  :commit "75d7f6e779b8be61e401f321f9210738d9e1688a"
  :revdesc "75d7f6e779b8"
  :keywords '("convenience"))
