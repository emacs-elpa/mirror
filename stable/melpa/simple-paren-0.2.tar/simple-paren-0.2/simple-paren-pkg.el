;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-paren" "0.2"
  "Non-electrical insert paired delimiter, wrap."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/andreas-roehler/simple-paren"
  :commit "b73f9da8ca59085529b529ce6558f979d98cd158"
  :revdesc "b73f9da8ca59"
  :keywords '("convenience"))
