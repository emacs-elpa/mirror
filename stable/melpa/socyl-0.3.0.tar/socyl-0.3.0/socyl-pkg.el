;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "socyl" "0.3.0"
  "Frontend for several search tools."
  '((s        "1.11.0")
    (dash     "2.12.0")
    (pkg-info "0.5.0")
    (cl-lib   "0.5"))
  :url "https://github.com/nlamirault/socyl"
  :commit "fcc0deda5b6c39d25e48e7da2a0ae73295193ea8"
  :revdesc "fcc0deda5b6c"
  :keywords '("ripgrep" "sift" "ack" "pt" "ag" "grep" "search")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
