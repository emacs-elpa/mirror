;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xmltokf" "0.2.3"
  "Functional wrappers around xmltok."
  '((emacs "25.1"))
  :url "https://github.com/paddymcall/xmltokf.el"
  :commit "b241550af98c7c367803d0fa34735c7aa0eb352c"
  :revdesc "b241550af98c"
  :keywords '("text" "hypermedia" "languages" "xml"))
