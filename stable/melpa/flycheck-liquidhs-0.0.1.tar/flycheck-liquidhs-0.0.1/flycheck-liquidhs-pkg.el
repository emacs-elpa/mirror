;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-liquidhs" "0.0.1"
  "A flycheck checker for Haskell using liquid (i.e. liquidhaskell)."
  '((flycheck "0.15"))
  :url "https://github.com/ucsd-progsys/liquidhaskell/flycheck-liquid.el"
  :commit "c0c3bbccb789517f369cc3afe5342ae6f4511943"
  :revdesc "c0c3bbccb789"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Ranjit Jhala" . "jhala@cs.ucsd.edu"))
  :maintainers '(("Ranjit Jhala" . "jhala@cs.ucsd.edu")))
