;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crontab-mode" "0.1"
  "Major mode for crontab(5)."
  '((emacs "24.3"))
  :url "https://github.com/emacs-pe/crontab-mode"
  :commit "3d58001b76687122a2928c641a3a73911470c5cd"
  :revdesc "3d58001b7668"
  :keywords '("languages")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
