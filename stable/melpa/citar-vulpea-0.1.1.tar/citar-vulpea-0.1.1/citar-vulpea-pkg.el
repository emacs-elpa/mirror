;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-vulpea" "0.1.1"
  "Minor mode integrating Citar and Vulpea."
  '((emacs  "27.2")
    (citar  "1.4")
    (vulpea "2.0"))
  :url "https://github.com/fabcontigiani/citar-vulpea"
  :commit "0b261859f447853e434b7d7bb26889e4e2996389"
  :revdesc "0b261859f447"
  :keywords '("bibliography" "notes" "vulpea")
  :authors '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com"))
  :maintainers '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com")))
