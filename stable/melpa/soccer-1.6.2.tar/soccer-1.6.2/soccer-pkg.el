;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soccer" "1.6.2"
  "Fixtures, results, table etc for soccer."
  '((emacs "26.1")
    (dash  "2.19.1"))
  :url "https://github.com/md-arif-shaikh/soccer"
  :commit "36d22b2acda00d203288cf5b4cc1d8df567f57d6"
  :revdesc "36d22b2acda0"
  :keywords '("games" "soccer" "football")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
