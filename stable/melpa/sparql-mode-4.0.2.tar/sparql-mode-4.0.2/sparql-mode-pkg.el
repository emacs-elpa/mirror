;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sparql-mode" "4.0.2"
  "Edit and interactively evaluate SPARQL queries."
  '((cl-lib "0.5")
    (emacs  "24.3"))
  :url "https://github.com/ljos/sparql-mode"
  :commit "2837b97244111515c61fb3823c1479bc126a458b"
  :revdesc "2837b9724411"
  :authors '(("Craig Andera" . "canderaatwangderadotcom"))
  :maintainers '(("Bjarte Johansen" . "BjartedotJohansenatgmaildotcom")))
