;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "0.46"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (compat    "31")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "d13fd40e2a546ec654a24ad450d052f9eebe8904"
  :revdesc "d13fd40e2a54"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
