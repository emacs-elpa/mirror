;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weather-metno" "0.1.0"
  "Weather data from met.no in Emacs."
  '((emacs  "24")
    (cl-lib "0.3"))
  :url "https://github.com/ruediger/weather-metno-el"
  :commit "b59680c1ab908b32513954034ba894dfb8564dd8"
  :revdesc "b59680c1ab90"
  :keywords '("comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.de"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.de")))
