;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh-embark" "3.0"
  "Embark Actions for consult-gh."
  '((emacs          "29.4")
    (consult        "2.0")
    (consult-gh     "3.0")
    (embark-consult "1.1")
    (which-key      "3.6.0"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "2b625a0331c9a92c67fef8ea2e694b28d5006421"
  :revdesc "2b625a0331c9"
  :keywords '("matching" "git" "repositories" "forges" "completion"))
