;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-phpstan" "0.9.0"
  "Flymake backend for PHP using PHPStan."
  '((emacs   "26.1")
    (phpstan "0.8.2"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "206573c8de58654384823765dcca636c9e35e909"
  :revdesc "206573c8de58"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
