;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "750words" "0.0.1"
  "Emacs integration for 750words.com."
  '((emacs "24.3"))
  :url "https://github.com/zzamboni/750words-client"
  :commit "40211645e3d87213e65f694594f1f011f3564e88"
  :revdesc "40211645e3d8"
  :keywords '("org" "writing")
  :authors '(("Diego Zamboni" . "https://github.com/zzamboni"))
  :maintainers '(("Diego Zamboni" . "diego@zzamboni.org")))
