;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-commit" "0.2.0"
  "Generate commit message with gptel."
  '((emacs "27.1")
    (gptel "0.9.8"))
  :url "https://github.com/lakkiy/gptel-commit"
  :commit "4ca046eca5e57b42c0886062e10c02611234e186"
  :revdesc "4ca046eca5e5"
  :keywords '("vc" "convenience")
  :authors '(("Liu Bo" . "liubolovelife@gmail.com"))
  :maintainers '(("Liu Bo" . "liubolovelife@gmail.com")))
