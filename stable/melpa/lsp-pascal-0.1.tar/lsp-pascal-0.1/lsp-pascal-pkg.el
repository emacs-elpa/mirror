;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-pascal" "0.1"
  "LSP client for Pascal."
  '((emacs    "24.4")
    (lsp-mode "6.3"))
  :url "https://github.com/arjanadriaanse/lsp-pascal"
  :commit "9b65bf9e923b1459d1feb1d7528e5855e7bd4ef2"
  :revdesc "9b65bf9e923b"
  :keywords '("languages" "tools")
  :authors '(("Arjan Adriaanse" . "arjan@adriaan.se"))
  :maintainers '(("Arjan Adriaanse" . "arjan@adriaan.se")))
