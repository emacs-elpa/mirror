;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "molecule" "0.1"
  "Simple wrapper for molecule."
  '((emacs "25.1"))
  :url ": https://git.daemons.it/drymer/molecule.el"
  :commit "cf61098fc3cfc1e6136789d9d589f0a8f5f5803b"
  :revdesc "cf61098fc3cf"
  :keywords '(":" "languages" "terminals")
  :authors '(("drymer" . "drymer[AT]autistici.org"))
  :maintainers '(("drymer" . "drymer[AT]autistici.org")))
