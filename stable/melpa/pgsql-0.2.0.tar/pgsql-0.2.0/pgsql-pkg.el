;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "0.2.0"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "b45ec8ca91bf053f1da3dc024ce71bea73f50ec3"
  :revdesc "v0.2.0-0-gb45ec8ca91bf"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
