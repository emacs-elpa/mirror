;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-indent-plus" "1.0.0"
  "Evil textobjects based on indentation."
  '((evil "0"))
  :url "https://github.com/TheBB/evil-indent-textobject-plus"
  :commit "fee4bfc5ebf15172715a1f7f9341654f8f2aab4b"
  :revdesc "fee4bfc5ebf1"
  :keywords '("convenience" "evil")
  :authors '(("Eivind Fonn" . "evfonn@gmail.com"))
  :maintainers '(("Eivind Fonn" . "evfonn@gmail.com")))
