;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geeknote" "0.2"
  "Use Evernote in Emacs through geeknote."
  '((emacs "24"))
  :url "https://github.com/avendael/emacs-geeknote"
  :commit "e946f2e2711954d651713c1bbf17a2619fdf6d55"
  :revdesc "e946f2e27119"
  :keywords '("evernote" "geeknote" "note" "emacs-evernote" "evernote-mode"))
