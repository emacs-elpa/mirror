;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fd-dired" "0.1.0"
  "Find-dired alternative using fd."
  ()
  :url "https://github.com/yqrashawn/fd-dired"
  :commit "d90ec902f417c194e44697f73a9d6cbfd0cf7216"
  :revdesc "d90ec902f417"
  :keywords '("tools" "fd" "find" "dired")
  :authors '(("Rashawn Zhang" . "namy.19@gmail.com"))
  :maintainers '(("Rashawn Zhang" . "namy.19@gmail.com")))
