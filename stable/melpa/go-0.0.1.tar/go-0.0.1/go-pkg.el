;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go" "0.0.1"
  "Play GO, translate and transfer between GO back ends."
  '((emacs "24"))
  :url "http://eschulte.github.io/el-go/"
  :commit "9d026ddcc0f269c556910cc70b274c13498853e5"
  :revdesc "9d026ddcc0f2"
  :keywords '("game" "go" "sgf")
  :authors '(("Eric Schulte" . "schulte.eric@gmail.com"))
  :maintainers '(("Eric Schulte" . "schulte.eric@gmail.com")))
