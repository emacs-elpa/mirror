;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wal-mode" "1.0"
  "A major mode for the WAL programming language."
  '((emacs "25.1"))
  :url "https://github.com/LucasKl/wal-major-mode"
  :commit "38dd5a882edfbcb9df094f37abf478f627e0f4ce"
  :revdesc "38dd5a882edf"
  :keywords '("languages")
  :authors '(("Lucas Klemmer" . "lucas.klemmer@jku.at"))
  :maintainers '(("Lucas Klemmer" . "lucas.klemmer@jku.at")))
