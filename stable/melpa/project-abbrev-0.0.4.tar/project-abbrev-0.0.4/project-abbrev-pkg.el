;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-abbrev" "0.0.4"
  "Customize abbreviation expansion in the project."
  '((emacs "25.1"))
  :url "https://github.com/jcs-elpa/project-abbrev"
  :commit "7b5749eae33eda576da3293dc386794c1248bb48"
  :revdesc "7b5749eae33e"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
