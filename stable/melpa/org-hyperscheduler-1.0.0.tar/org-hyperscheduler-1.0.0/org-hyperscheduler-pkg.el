;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-hyperscheduler" "1.0.0"
  "UI (web) representation of org-agenda."
  '((emacs     "27.1")
    (websocket "1.13"))
  :url "https://github.com/dmitrym0/org-hyperscheduler"
  :commit "252f9412520fb703de96a81061766c74943cd06f"
  :revdesc "252f9412520f"
  :keywords '("org-mode" "calendar")
  :authors '(("Dmitry Markushevich" . "dmitrym@gmail.com"))
  :maintainers '(("Dmitry Markushevich" . "dmitrym@gmail.com")))
