;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bibliothek" "0.2.0"
  "Managing a digital library of PDFs."
  '((emacs     "24.4")
    (pdf-tools "0.70")
    (a         "0.1.0alpha4"))
  :url "http://gkayaalp.com/emacs.html#bibliothek.el"
  :commit "c34b0dfc48081affd20cae7e9f318ed83b611176"
  :revdesc "c34b0dfc4808"
  :keywords '("tools")
  :authors '(("Göktuğ Kayaalp" . "self@gkayaalp.com"))
  :maintainers '(("Göktuğ Kayaalp" . "self@gkayaalp.com")))
