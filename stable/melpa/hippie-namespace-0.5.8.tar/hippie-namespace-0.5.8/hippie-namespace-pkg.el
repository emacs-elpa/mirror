;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hippie-namespace" "0.5.8"
  "Special treatment for namespace prefixes in hippie-expand."
  ()
  :url "https://github.com/rolandwalker/hippie-namespace"
  :commit "79a662dfe9e61341e071b879f4f9101ca027ad10"
  :revdesc "v0.5.8-0-g79a662dfe9e6"
  :keywords '("convenience" "lisp" "tools" "completion")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
