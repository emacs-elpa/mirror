;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jetbrains" "0.0.2"
  "JetBrains IDE bridge."
  '((emacs  "24.3")
    (cl-lib "0.5")
    (f      "0.17"))
  :url "https://github.com/emacs-php/jetbrains.el"
  :commit "38e136079f3f2ddbe0e8b7dec01cf6b515e897d8"
  :revdesc "38e136079f3f"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
