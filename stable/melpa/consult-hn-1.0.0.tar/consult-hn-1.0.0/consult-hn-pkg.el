;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-hn" "1.0.0"
  "Hackernews search with Consult."
  '((emacs   "29.4")
    (consult "2.0")
    (ts      "0.3"))
  :url "https://github.com/agzam/consult-hn"
  :commit "fde491debce7061876aa4bce9a6991d31bfeee27"
  :revdesc "fde491debce7"
  :keywords '("search" "extensions")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
