;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-eldev" "1.2"
  "Eldev support in Flycheck."
  '((flycheck "32")
    (dash     "2.17")
    (emacs    "24.4"))
  :url "https://github.com/flycheck/flycheck-eldev"
  :commit "8a6ef42f38208e27d55771459ad884ced0d35b6a"
  :revdesc "8a6ef42f3820"
  :keywords '("tools" "convenience")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
