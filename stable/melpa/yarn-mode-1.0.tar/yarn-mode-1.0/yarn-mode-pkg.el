;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yarn-mode" "1.0"
  "Major mode for yarn.lock files."
  '((emacs "24.3"))
  :url "https://github.com/anachronic/yarn-mode"
  :commit "99891000efe31214b065fa9446cd5e68c5c42ed8"
  :revdesc "v1.0-0-g99891000efe3"
  :keywords '("convenience")
  :authors '(("Nicolás Salas V." . "nikosalas@gmail.com"))
  :maintainers '(("Nicolás Salas V." . "nikosalas@gmail.com")))
