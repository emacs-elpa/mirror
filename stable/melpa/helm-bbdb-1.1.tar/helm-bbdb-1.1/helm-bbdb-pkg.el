;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bbdb" "1.1"
  "Helm interface for bbdb."
  '((helm "1.5")
    (bbdb "3.1.2"))
  :url "https://github.com/emacs-helm/helm-bbdb"
  :commit "20513422102fea4c08a0433d728a7783bb4968c8"
  :revdesc "v1.1-0-g20513422102f")
