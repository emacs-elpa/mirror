;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-css-colorguard" "0.20.1"
  "Detect similar colors in CSS."
  '((flycheck "0.22")
    (emacs    "24"))
  :url "https://github.com/Simplify/flycheck-css-colorguard/"
  :commit "d42f5e17d9991604da2200afd4af2e1cc48533f0"
  :revdesc "d42f5e17d999"
  :keywords '("flycheck" "css" "colorguard")
  :authors '(("Saša Jovanić" . "info@simplify.ba"))
  :maintainers '(("Saša Jovanić" . "info@simplify.ba")))
