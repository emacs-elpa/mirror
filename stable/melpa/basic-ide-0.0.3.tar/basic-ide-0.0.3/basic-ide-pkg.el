;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "basic-ide" "0.0.3"
  "BASIC IDE c64."
  '((emacs      "25")
    (basic-mode "0.4.2")
    (company    "0.9.12")
    (flycheck   "0.22")
    (dash       "2.12.0")
    (f          "0.17.0"))
  :url "https://gitlab.com/sasanidas/emacs-c64-basic-ide"
  :commit "5bfd5f91b9f91e46158e0419c6bb5c350e7684a1"
  :revdesc "5bfd5f91b9f9"
  :keywords '("languages" "basic")
  :authors '(("Fermin MF" . "fmfs@posteo.net"))
  :maintainers '(("Fermin MF" . "fmfs@posteo.net")))
