;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.74.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "26969ef21808218a439d6bb86face1333ae76169"
  :revdesc "26969ef21808")
