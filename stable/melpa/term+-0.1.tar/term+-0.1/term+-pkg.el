;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term+" "0.1"
  "Term-mode enhancement."
  ()
  :url "https://github.com/tarao/term+-el"
  :commit "84a8993cf3dd7631cd955099b72809015f94d8bc"
  :revdesc "84a8993cf3dd"
  :keywords '("terminal" "emulation")
  :authors '(("INA Lintaro" . "tarao.gnnatgmail.com"))
  :maintainers '(("INA Lintaro" . "tarao.gnnatgmail.com")))
