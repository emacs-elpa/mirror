;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-mode" "4.4.5"
  "Major-mode for editing CMake sources."
  '((emacs "24.1"))
  :commit "aa4fae824a02a175c4a11653d7a851a948f0c004"
  :revdesc "v4.4.5-0-gaa4fae824a02")
