;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yari" "0.8"
  "Yet Another RI interface for Emacs."
  ()
  :url "https://github.com/hron/yari.el"
  :commit "a2cb9656ee5dfe1fc2ee3854f3079a1c8e85dbe9"
  :revdesc "a2cb9656ee5d"
  :keywords '("tools")
  :authors '(("Aleksei Gusev" . "aleksei.gusev@gmail.com"))
  :maintainers '(("Aleksei Gusev" . "aleksei.gusev@gmail.com")))
