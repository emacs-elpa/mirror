;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oldlace-theme" "0.1"
  "Emacs 24 theme with a light background."
  '((emacs "24"))
  :url "https://github.com/mswift42/oldlace-theme"
  :commit "cb58278b2bd341e4bc3a874d5fbaa79634e482a6"
  :revdesc "cb58278b2bd3")
