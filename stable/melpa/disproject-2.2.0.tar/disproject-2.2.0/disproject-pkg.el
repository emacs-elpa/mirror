;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "2.2.0"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.9.2"))
  :url "https://github.com/aurtzy/disproject"
  :commit "de25aad37999c14fa232b8f0b9cac8954037a1df"
  :revdesc "v2.2.0-0-gde25aad37999"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
