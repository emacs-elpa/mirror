;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "web-server" "0.1.2"
  "Emacs Web Server."
  '((emacs "24.3"))
  :url "https://github.com/eschulte/emacs-web-server"
  :commit "33afdb46e1cd61251736816d965495525b36c9cd"
  :revdesc "33afdb46e1cd"
  :keywords '("http" "server" "network")
  :authors '(("Eric Schulte" . "schulte.eric@gmail.com"))
  :maintainers '(("Eric Schulte" . "schulte.eric@gmail.com")))
