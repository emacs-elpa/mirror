;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gscholar-bibtex" "0.3.3"
  "Retrieve BibTeX from Google Scholar and other online sources(ACM, IEEE, DBLP)."
  ()
  :url "https://github.com/cute-jumper/gscholar-bibtex"
  :commit "ba4ce159e385d695d8560e8b06b3cbe48424861c"
  :revdesc "ba4ce159e385"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
