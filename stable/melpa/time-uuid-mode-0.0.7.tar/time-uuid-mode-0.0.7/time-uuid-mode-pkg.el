;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-uuid-mode" "0.0.7"
  "Minor mode for previewing time uuids as an overlay."
  '((emacs "27.1"))
  :url "https://github.com/RobertPlant/time-uuid-mode"
  :commit "4f4bbe01127eba738195adf61463d6992dfb1e08"
  :revdesc "4f4bbe01127e"
  :keywords '("extensions" "convenience" "data" "tools")
  :authors '(("Robert Plant" . "rob@robertplant.io"))
  :maintainers '(("Robert Plant" . "rob@robertplant.io")))
