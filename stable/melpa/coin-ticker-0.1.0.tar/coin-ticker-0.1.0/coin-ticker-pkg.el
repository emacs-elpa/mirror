;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coin-ticker" "0.1.0"
  "Show a cryptocurrency price ticker."
  '((request "0.3.0")
    (emacs   "25"))
  :url "https://github.com/eklitzke/coin-ticker-mode"
  :commit "e9bc63af5d57eac888352ca91dd39dd7a676753f"
  :revdesc "e9bc63af5d57"
  :keywords '("news")
  :authors '(("Evan Klitzke" . "evan@eklitzke.org"))
  :maintainers '(("Evan Klitzke" . "evan@eklitzke.org")))
