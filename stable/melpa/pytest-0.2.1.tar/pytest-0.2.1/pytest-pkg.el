;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pytest" "0.2.1"
  "Easy Python test running in Emacs."
  ()
  :url "http://bitbucket.org/elarson/pytest.el"
  :commit "c5c4658e511bb8783de479a9b82ac5a030f656f3"
  :revdesc "c5c4658e511b"
  :keywords '("pytest" "python" "testing"))
