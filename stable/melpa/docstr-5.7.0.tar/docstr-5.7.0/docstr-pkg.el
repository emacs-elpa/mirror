;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docstr" "5.7.0"
  "A document string minor mode."
  '((emacs "24.4")
    (s     "1.9.0"))
  :url "https://github.com/jcs-elpa/docstr"
  :commit "63b0460a4785b4b4aee5cc072b52fb2d3a7eef6e"
  :revdesc "63b0460a4785"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
