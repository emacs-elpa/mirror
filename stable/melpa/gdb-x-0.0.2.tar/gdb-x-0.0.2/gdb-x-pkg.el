;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdb-x" "0.0.2"
  "Improve GDB-MI user interface."
  '((emacs "29.1"))
  :url "https://codeberg.org/pastor/gdb-x"
  :commit "7e03680f7b5a001341d1892daa69bc32fcf75113"
  :revdesc "7e03680f7b5a"
  :keywords '("extensions")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@outlook.es"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@outlook.es")))
