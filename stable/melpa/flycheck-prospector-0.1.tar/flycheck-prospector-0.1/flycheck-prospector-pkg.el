;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-prospector" "0.1"
  "Support prospector in flycheck."
  '((flycheck "0.18"))
  :url "https://github.com/chocoelho/flycheck-prospector"
  :commit "2f61b2180296d74607605c001e2969b97d732710"
  :revdesc "2f61b2180296"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
