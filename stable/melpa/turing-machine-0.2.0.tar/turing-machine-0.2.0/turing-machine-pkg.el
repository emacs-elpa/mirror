;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "turing-machine" "0.2.0"
  "Single-tape Turing machine simulator."
  '((emacs "24.4"))
  :url "https://github.com/therockmandolinist/turing-machine"
  :commit "ad1dccc9c445f9e4465e1c67cbbfea9583153047"
  :revdesc "ad1dccc9c445"
  :keywords '("turing" "machine" "simulation")
  :authors '(("Diego A. Mundo" . "diegoamundo@gmail.com"))
  :maintainers '(("Diego A. Mundo" . "diegoamundo@gmail.com")))
