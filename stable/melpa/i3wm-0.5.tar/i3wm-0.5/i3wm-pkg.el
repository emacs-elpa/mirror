;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "i3wm" "0.5"
  "I3wm integration library for emacs."
  '((cl-lib "0.5")
    (json   "0"))
  :url "https://git.flintfam.org/swflint/emacs-i3wm"
  :commit "f6989fbbca270bc0d5c74023ea28d5ef7e840a7d"
  :revdesc "f6989fbbca27"
  :keywords '("i3")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
