;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markup-faces" "1.0.0"
  "Collection of faces for markup language modes."
  ()
  :url "https://github.com/sensorflo/markup-faces"
  :commit "c43612633c6c161857a3bab5752ae192bb03f5f3"
  :revdesc "c43612633c6c"
  :keywords '("wp" "faces")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Florian Kaufmann" . "sensorflo@gmail.com")))
