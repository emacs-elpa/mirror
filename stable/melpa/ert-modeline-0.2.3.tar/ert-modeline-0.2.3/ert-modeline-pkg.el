;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-modeline" "0.2.3"
  "Displays ert test results in the modeline."
  '((s          "1.3.1")
    (dash       "1.2.0")
    (emacs      "24.1")
    (projectile "0.9.1"))
  :url "https://github.com/chrisbarrett/ert-modeline"
  :commit "d0bbe38b9edc8e94a4a931b4123784976776e934"
  :revdesc "d0bbe38b9edc"
  :keywords '("tools" "tests" "convenience")
  :authors '(("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainers '(("Chris Barrett" . "chris.d.barrett@me.com")))
