;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ng2-mode" "0.2.2"
  "Major modes for editing Angular 2."
  '((typescript-mode "0.1"))
  :url "https://github.com/AdamNiederer/ng2-mode"
  :commit "57e6e4e388624853bc3b79bf5b17d2663ce26fa5"
  :revdesc "0.2.2-0-g57e6e4e38862"
  :keywords '("typescript" "angular" "angular2" "template")
  :authors '(("Adam Niederer" . "adam.niederer@gmail.com"))
  :maintainers '(("Adam Niederer" . "adam.niederer@gmail.com")))
