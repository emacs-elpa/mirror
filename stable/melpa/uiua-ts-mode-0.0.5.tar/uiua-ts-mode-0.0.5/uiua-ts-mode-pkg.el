;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uiua-ts-mode" "0.0.5"
  "Uiua treesiter mode."
  '((emacs     "29.1")
    (uiua-mode "0.0.5"))
  :url "https://github.com/crmsnbleyd/uiua-mode"
  :commit "43bd93f8ae1452632cf8a3c2674ee05ab763ee47"
  :revdesc "43bd93f8ae14"
  :keywords '("languages" "uiua"))
