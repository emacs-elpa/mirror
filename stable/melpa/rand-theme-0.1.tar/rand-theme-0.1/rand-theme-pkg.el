;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rand-theme" "0.1"
  "Random Emacs theme at start-up!."
  ()
  :url "https://github.com/gopar/rand-theme"
  :commit "0901bf0fb2680a0f41d87754c9a3f7728760b19f"
  :revdesc "0901bf0fb268")
