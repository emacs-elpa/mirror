;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elscreen-tab" "1.1.0"
  "Minor mode to display tabs of elscreen in a dedicated buffer."
  '((emacs    "26")
    (elscreen "20180321")
    (dash     "2.14.1"))
  :url "https://github.com/aki-s/elscreen-tab"
  :commit "6ad77f972bde05e4e3d44f0d33b68ac41655e5f1"
  :revdesc "1.1.0-0-g6ad77f972bde"
  :keywords '("tools" "extensions")
  :authors '(("Aki Syunsuke" . "sunny.day.dev@gmail.com"))
  :maintainers '(("Aki Syunsuke" . "sunny.day.dev@gmail.com")))
