;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-factory" "0.0.1"
  "Minor mode for Ruby test object generation libraries."
  '((inflections "1.1"))
  :url "https://github.com/sshaw/ruby-factory-mode"
  :commit "ccd7c8500e8357ecde55adafde865a45026ed3dd"
  :revdesc "ccd7c8500e83"
  :keywords '("ruby" "rails" "convenience")
  :authors '(("Skye Shaw" . "skye.shaw@gmail.com"))
  :maintainers '(("Skye Shaw" . "skye.shaw@gmail.com")))
