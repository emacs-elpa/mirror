;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clel" "0.8.6"
  "Runtime library for ClojureElisp."
  '((emacs "28.1"))
  :url "https://github.com/BuddhiLW/clojure-elisp"
  :commit "f0494ba0f39b4d21579b45d94fe607f526dff88e"
  :revdesc "f0494ba0f39b"
  :keywords '("languages" "lisp" "clojure")
  :authors '(("Pedro G. Branquinho" . "pedrogbranquinho@gmail.com"))
  :maintainers '(("Pedro G. Branquinho" . "pedrogbranquinho@gmail.com")))
