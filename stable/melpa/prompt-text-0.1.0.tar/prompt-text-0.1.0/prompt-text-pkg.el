;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prompt-text" "0.1.0"
  "Various information in minibuffer prompt."
  ()
  :url "https://github.com/10sr/prompt-text-el"
  :commit "bb9265ebfada42d0e3c67c809665e1e5d980691e"
  :revdesc "bb9265ebfada"
  :keywords '("utility" "minibuffer")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
