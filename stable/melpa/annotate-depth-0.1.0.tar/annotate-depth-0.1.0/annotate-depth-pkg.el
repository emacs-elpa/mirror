;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotate-depth" "0.1.0"
  "Annotate buffer if indentation depth is beyond threshold."
  ()
  :url "https://github.com/netromdk/annotate-depth"
  :commit "95ac9e6602c3553b1f1fb0e74c53273d41101207"
  :revdesc "95ac9e6602c3"
  :keywords '("convenience")
  :authors '(("Morten Slot Kristensen" . "mskATnullpointerDOTdk"))
  :maintainers '(("Morten Slot Kristensen" . "mskATnullpointerDOTdk")))
