;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docbook-snippets" "0.0.0.20150714.19"
  "Yasnippets for DocBook."
  '((yasnippet "0.8.0"))
  :url "https://github.com/jhradilek/emacs-docbook-snippets"
  :commit "b06297fdec039a541aaa6312cb328a11062cfab4"
  :revdesc "b06297fdec03"
  :keywords '("snippets" "docbook")
  :authors '(("Jaromir Hradilek" . "jhradilek@gmail.com"))
  :maintainers '(("Jaromir Hradilek" . "jhradilek@gmail.com")))
