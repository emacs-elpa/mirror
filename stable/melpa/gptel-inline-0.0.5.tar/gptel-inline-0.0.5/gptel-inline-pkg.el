;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-inline" "0.0.5"
  "Persistent gptel session that follows you around."
  '((emacs  "29.1")
    (compat "30.1.0.0")
    (gptel  "0.9.9.5"))
  :url "https://github.com/karthink/gptel-inline"
  :commit "2b19ee86c0e9602f5fa3faeb610f9f88c9edc11a"
  :revdesc "2b19ee86c0e9"
  :keywords '("comm")
  :authors '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com")))
