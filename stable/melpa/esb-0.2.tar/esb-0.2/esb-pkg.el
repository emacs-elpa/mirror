;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esb" "0.2"
  "Emacs Simple Bookmark."
  '((emacs "27.1"))
  :url "https://github.com/0xhenrique/esb"
  :commit "180bf50bb9a5299ebbe51afefe5b4f81999016a1"
  :revdesc "180bf50bb9a5"
  :authors '(("Henrique Marques" . "hm2030master@proton.me"))
  :maintainers '(("Henrique Marques" . "hm2030master@proton.me")))
