;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alan-mode" "1.0.0"
  "Major mode for editing M-industries Alan files."
  '((flycheck "32")
    (emacs    "25.1"))
  :url "https://github.com/M-industries/AlanForEmacs"
  :commit "0089e7c874c6d35e55be6ecd479ada2b97688a1f"
  :revdesc "0089e7c874c6"
  :keywords '("alan" "languages")
  :authors '(("Paul van Dam" . "pvandam@m-industries.com"))
  :maintainers '(("Paul van Dam" . "pvandam@m-industries.com")))
