;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-project" "2.1"
  "Group ibuffer's list by project or any function."
  '((emacs "25.1"))
  :url "https://github.com/muffinmad/emacs-ibuffer-project"
  :commit "2483d2dbd715c4bd892d1fbc968a17a01888cb2d"
  :revdesc "2483d2dbd715"
  :keywords '("tools")
  :authors '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com"))
  :maintainers '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com")))
