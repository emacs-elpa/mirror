;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "language-detection" "0.1.0"
  "Automatic language detection from code snippets."
  ()
  :url "https://github.com/andreasjansson/language-detection"
  :commit "ff441f701c74c938ae52657deb9e1d0056b3f9c0"
  :revdesc "ff441f701c74")
