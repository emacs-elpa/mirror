;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "axe" "0.0.1"
  "AWS Extensions."
  '((emacs   "25.1")
    (request "0.3.2")
    (hmac    "1.0"))
  :url "https://github.com/cniles/axe"
  :commit "bb597c8beb7ef2ac27f7f19e14245e1880144226"
  :revdesc "bb597c8beb7e"
  :authors '(("Craig Niles" . "niles.catgmail.com"))
  :maintainers '(("Craig Niles" . "niles.catgmail.com")))
