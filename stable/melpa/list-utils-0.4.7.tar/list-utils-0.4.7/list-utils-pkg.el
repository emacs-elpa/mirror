;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "list-utils" "0.4.7"
  "List-manipulation utility functions."
  ()
  :url "https://github.com/rolandwalker/list-utils"
  :commit "bbea0e7cc7ab7d96e7f062014bde438aa8ffcd43"
  :revdesc "v0.4.7-0-gbbea0e7cc7ab"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
