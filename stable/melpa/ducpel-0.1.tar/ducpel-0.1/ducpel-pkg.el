;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ducpel" "0.1"
  "Logic game with sokoban elements."
  '((cl-lib "0.5"))
  :url "https://github.com/alezost/ducpel"
  :commit "ece785baaa102bd2e9d54257af3a92bacc5757bc"
  :revdesc "ece785baaa10"
  :keywords '("games")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
