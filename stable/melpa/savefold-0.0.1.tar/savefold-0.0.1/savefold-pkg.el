;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "savefold" "0.0.1"
  "Persistence for various folding systems."
  '((emacs "28.2"))
  :url "https://github.com/jcfk/savefold.el"
  :commit "9e07d56a0d37d9e2ea2cb5fe6d11a7b3d1d88f77"
  :revdesc "9e07d56a0d37"
  :keywords '("convenience")
  :authors '(("Jacob Fong" . "jacobcfong@gmail.com"))
  :maintainers '(("Jacob Fong" . "jacobcfong@gmail.com")))
