;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mqr" "0.2.3"
  "Multi-dimensional query and replace."
  '((emacs "24.4"))
  :url "https://github.com/calancha/multi-replace"
  :commit "4ade19d4620b8b61340290bf63fa56d5e493859f"
  :revdesc "4ade19d4620b"
  :keywords '("convenience" "extensions" "lisp")
  :authors '(("Tino Calancha" . "tino.calancha@gmail.com"))
  :maintainers '(("Tino Calancha" . "tino.calancha@gmail.com")))
