;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-convert" "1.0.0"
  "Convert many format to leaf format."
  '((emacs         "26.1")
    (leaf          "3.6.0")
    (leaf-keywords "1.1.0"))
  :url "https://github.com/conao3/leaf-convert.el"
  :commit "960e3af4a2793d96b2711c083585408b710bdaea"
  :revdesc "960e3af4a279"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
