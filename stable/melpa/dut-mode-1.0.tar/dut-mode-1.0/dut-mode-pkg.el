;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dut-mode" "1.0"
  "Major mode for the Dut programming language."
  ()
  :url "https://github.com/dut-lang/dut-mode"
  :commit "bf0e1fd3067ec22f04792313ea8ffc6fdbbae015"
  :revdesc "bf0e1fd3067e"
  :keywords '("languages" "gut"))
