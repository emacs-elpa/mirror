;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "capnp-mode" "1.5.0"
  "Major mode for editing Capn' Proto Files."
  ()
  :url "https://github.com/capnproto/capnproto"
  :commit "373e61ec89e2359f1c362e9b2eadc552f4779306"
  :revdesc "373e61ec89e2"
  :authors '(("Brian Taylor" . "el.wubo@gmail.com"))
  :maintainers '(("Brian Taylor" . "el.wubo@gmail.com")))
