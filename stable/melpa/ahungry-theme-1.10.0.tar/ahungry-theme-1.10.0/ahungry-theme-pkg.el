;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ahungry-theme" "1.10.0"
  "Ahungry color theme for Emacs.  Make sure to (load-theme 'ahungry)."
  '((emacs "24"))
  :url "https://github.com/ahungry/color-theme-ahungry"
  :commit "45bf75f17752c8e8dd4c8a4531c0aa419cdccb84"
  :revdesc "45bf75f17752"
  :keywords '("ahungry" "palette" "color" "theme" "emacs" "color-theme" "deftheme")
  :authors '(("Matthew Carter" . "m@ahungry.com"))
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
