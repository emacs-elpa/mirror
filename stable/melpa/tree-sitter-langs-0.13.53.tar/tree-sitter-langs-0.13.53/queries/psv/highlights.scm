; inherits: tsv

"|" @punctuation.delimiter
