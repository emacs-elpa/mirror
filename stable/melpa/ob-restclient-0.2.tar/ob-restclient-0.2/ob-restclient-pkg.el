;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-restclient" "0.2"
  "Org-babel functions for restclient-mode."
  '((restclient "0"))
  :url "http://orgmode.org"
  :commit "c2686286b7d17fc8c059c7a5b301142718fdf2de"
  :revdesc "c2686286b7d1"
  :keywords '("literate programming" "reproducible research"))
