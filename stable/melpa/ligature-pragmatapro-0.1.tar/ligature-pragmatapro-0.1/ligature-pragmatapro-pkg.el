;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ligature-pragmatapro" "0.1"
  "PragmataPro support for ligature.el."
  '((emacs    "28")
    (ligature "1.0"))
  :url "https://gitlab.com/wavexx/ligature-pragmatapro.el"
  :commit "65fba1af02cb174b3cde90506a43bb63cb9a8e81"
  :revdesc "65fba1af02cb"
  :keywords '("faces" "fonts" "ligatures" "programming-ligatures")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
