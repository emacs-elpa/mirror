;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaesar-pbkdf2" "0.9.1"
  "PBKDF2 extension for kaesar.el."
  '((emacs "25.1"))
  :url "https://github.com/mhayashi1120/Emacs-kaesar"
  :commit "75655238e0dcdb77a74d685cc4f3368fcd284020"
  :revdesc "75655238e0dc"
  :keywords '("data")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
