; inherits: typescript,jsx

