;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-tree-sitter" "0.5"
  "Provides evil textobjects using tree-sitter."
  '((emacs "25.1"))
  :url "https://github.com/meain/evil-textobj-tree-sitter"
  :commit "cf25134c3af3aece61f866ae42bc7ab3714b59ea"
  :revdesc "cf25134c3af3"
  :keywords '("evil" "tree-sitter" "text-object" "convenience"))
