;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "0.16.0"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "168aca0ea6f6db9ec0085f4e958a06de5aea6f76"
  :revdesc "v0.16.0-0-g168aca0ea6f6"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
