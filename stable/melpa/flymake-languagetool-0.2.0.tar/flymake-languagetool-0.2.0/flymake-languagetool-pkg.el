;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-languagetool" "0.2.0"
  "Flymake support for LanguageTool."
  '((emacs "27.1")
    (s     "1.9.0"))
  :url "https://github.com/emacs-languagetool/flymake-languagetool"
  :commit "f0f105ab11fd1de1379baef91fcd46e6c2464dca"
  :revdesc "f0f105ab11fd"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
