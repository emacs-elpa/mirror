;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-ring" "0.1"
  "Structured and configurable repetition."
  '((emacs        "25.1")
    (virtual-ring "0.1")
    (pubsub       "0.1")
    (mantra       "0.1"))
  :url "https://github.com/countvajhula/repeat-ring"
  :commit "0d436ddcf67e698f3afac7c430559ace8e646314"
  :revdesc "v0.1-0-g0d436ddcf67e"
  :authors '(("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
