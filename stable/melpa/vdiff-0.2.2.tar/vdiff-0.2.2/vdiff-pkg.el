;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vdiff" "0.2.2"
  "A diff tool similar to  vimdiff."
  '((emacs "24.4")
    (hydra "0.13.0"))
  :url "https://github.com/justbur/emacs-vdiff"
  :commit "f55acdbfcbb14e463d0850cfd041614c7002669e"
  :revdesc "f55acdbfcbb1"
  :keywords '("diff")
  :authors '(("Justin Burkett" . "justin@burkett.cc"))
  :maintainers '(("Justin Burkett" . "justin@burkett.cc")))
