;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modern-sh" "0.0.1"
  "Minor mode for shell script writing."
  '((emacs "24.3"))
  :url "https://github.com/damon-kwok/modern-sh"
  :commit "3a19c7f7893f4910b4e3d45c7dfac01979747076"
  :revdesc "3a19c7f7893f"
  :keywords '("languages" "programming")
  :authors '(("Damon Kwok" . "damon-kwok@outlook.com"))
  :maintainers '(("Damon Kwok" . "damon-kwok@outlook.com")))
