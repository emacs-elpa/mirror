;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prisma-ts-mode" "1.0.0"
  "Major mode for prisma using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/prisma-ts-mode"
  :commit "5eff148a35964c61c3ce3c073ef4eb06985f28e6"
  :revdesc "5eff148a3596"
  :keywords '("prisma" "languages" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
