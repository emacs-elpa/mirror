;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghostel" "0.65.0"
  "Consult integration for ghostel."
  '((emacs   "28.1")
    (consult "1.5")
    (ghostel "0.64.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "9fd6310a71d1eb8a863767452e2fac30f76801fb"
  :revdesc "9fd6310a71d1"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
