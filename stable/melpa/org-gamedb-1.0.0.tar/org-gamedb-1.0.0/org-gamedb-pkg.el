;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-gamedb" "1.0.0"
  "A game API client to work with org-mode."
  ()
  :url "https://github.com/repelliuss/org-gamedb"
  :commit "c67114fb7a97012e5c14e05abf9d110fbd9aabd3"
  :revdesc "c67114fb7a97"
  :keywords '("org" "game" "api")
  :authors '(("repelliuss" . "https://github.com/repelliuss"))
  :maintainers '(("repelliuss" . "repelliuss@gmail.com")))
