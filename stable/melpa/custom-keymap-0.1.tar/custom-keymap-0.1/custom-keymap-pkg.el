;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "custom-keymap" "0.1"
  "Configure user key sequence bindings from a custom variable."
  '((emacs "29.3"))
  :url "https://github.com/viandant/custom-keymap"
  :commit "5a8e2b6b65e2aa249e592eb6bb22ccd8a9dfe5ca"
  :revdesc "5a8e2b6b65e2"
  :keywords '("internal" "keymap" "keyboard" "customization")
  :authors '(("Viandant" . "viandant@langenst.de"))
  :maintainers '(("Viandant" . "viandant@langenst.de")))
