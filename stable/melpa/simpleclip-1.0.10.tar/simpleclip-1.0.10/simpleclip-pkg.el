;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simpleclip" "1.0.10"
  "Simplified access to the system clipboard."
  ()
  :url "https://github.com/rolandwalker/simpleclip"
  :commit "d327abe0522b9b9a26e005eae5ffa4c34ea2ba0a"
  :revdesc "v1.0.10-0-gd327abe0522b"
  :keywords '("convenience")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
