;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mocker" "0.5.0"
  "Mocking framework for emacs."
  '((emacs "25.1"))
  :url "https://github.com/sigma/mocker.el"
  :commit "5d739d5170ff42e841cd2755b68151918052da2b"
  :revdesc "5d739d5170ff"
  :keywords '("lisp" "testing")
  :authors '(("Yann Hodique" . "yann.hodique@gmail.com"))
  :maintainers '(("Yann Hodique" . "yann.hodique@gmail.com")))
