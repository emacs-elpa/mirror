;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sql-presto" "1.0.4"
  "[No description available]."
  '((emacs "24.4"))
  :url "https://github.com/kat-co/sql-prestodb"
  :commit "bcda455e300a1af75c7bb805882329bc844703b2"
  :revdesc "bcda455e300a"
  :keywords '("sql" "presto" "database")
  :authors '(("Katherine Cox-Buday" . "cox.katherine.e@gmail.com"))
  :maintainers '(("Katherine Cox-Buday" . "cox.katherine.e@gmail.com")))
