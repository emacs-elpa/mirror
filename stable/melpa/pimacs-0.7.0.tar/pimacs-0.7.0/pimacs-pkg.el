;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.7.0"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "675853a9eacfdfd628e3ff090690afeb08f43e47"
  :revdesc "675853a9eacf"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
