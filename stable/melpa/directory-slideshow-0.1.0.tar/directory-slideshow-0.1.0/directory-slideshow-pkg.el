;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "directory-slideshow" "0.1.0"
  "Simple slideshows from files."
  '((emacs "29.4"))
  :url "https://github.com/Duncan-Britt/directory-slideshow"
  :commit "03e7e55817bf8da8bc4aac46d03d58036f5b5dfa"
  :revdesc "03e7e55817bf"
  :keywords '("multimedia"))
