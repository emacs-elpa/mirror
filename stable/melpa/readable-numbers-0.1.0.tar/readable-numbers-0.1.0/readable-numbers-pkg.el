;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "readable-numbers" "0.1.0"
  "Visually separate long integers."
  '((emacs "24.1"))
  :url "https://github.com/Titan-C/cardano.el"
  :commit "a3ebdcdd91d32f044b68541a00e162396e4acb38"
  :revdesc "a3ebdcdd91d3"
  :authors '(("Oscar Najera" . "https://oscarnajera.com"))
  :maintainers '(("Oscar Najera" . "hi@oscarnajera.com")))
