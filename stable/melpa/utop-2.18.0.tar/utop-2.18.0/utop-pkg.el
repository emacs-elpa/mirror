;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "utop" "2.18.0"
  "Universal toplevel for OCaml."
  '((emacs "26"))
  :url "https://github.com/ocaml-community/utop"
  :commit "9abebebc0de224638b0510263b9ed2992c96c72c"
  :revdesc "2.18.0-0-g9abebebc0de2"
  :keywords '("ocaml" "languages")
  :authors '(("Jeremie Dimino" . "jeremie@dimino.org"))
  :maintainers '(("Jeremie Dimino" . "jeremie@dimino.org")))
