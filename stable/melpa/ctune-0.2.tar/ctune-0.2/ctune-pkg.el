;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ctune" "0.2"
  "Tune out CC Mode Noise Macros."
  '((emacs "26.1"))
  :url "https://github.com/maurooaranda/ctune"
  :commit "d7643461f5aa33cc04e4d808123e4ed1d85500ee"
  :revdesc "v0.2-0-gd7643461f5aa"
  :keywords '("c" "convenience")
  :authors '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers '(("Mauro Aranda" . "maurooaranda@gmail.com")))
