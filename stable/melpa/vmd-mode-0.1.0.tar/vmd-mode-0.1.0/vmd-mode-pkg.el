;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vmd-mode" "0.1.0"
  "Really Realtime Markdown previews for Emacs using a vmd subprocess."
  ()
  :url "https://github.com/blak3mill3r/vmd-mode.el"
  :commit "fbdf7e11177bf3f899b49d20c761b7677197a739"
  :revdesc "fbdf7e11177b"
  :keywords '("markdown" "preview" "live" "vmd")
  :authors '(("Blake Miller" . "blak3mill3r@gmail.com"))
  :maintainers '(("Blake Miller" . "blak3mill3r@gmail.com")))
