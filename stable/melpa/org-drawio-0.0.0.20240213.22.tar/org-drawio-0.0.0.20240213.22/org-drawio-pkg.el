;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-drawio" "0.0.0.20240213.22"
  "Convert and include drawio image to orgmode."
  '((org   "9.6.6")
    (emacs "28.1"))
  :url "https://github.com/kimim/org-drawio"
  :commit "6b25d0ecf7de364da96c96da30a995df8a4cb835"
  :revdesc "6b25d0ecf7de"
  :keywords '("multimedia" "convenience")
  :authors '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainers '(("Kimi Ma" . "kimi.im@outlook.com")))
