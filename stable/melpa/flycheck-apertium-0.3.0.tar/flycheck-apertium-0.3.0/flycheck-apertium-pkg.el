;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-apertium" "0.3.0"
  "Apertium checkers in flycheck."
  '((flycheck "0.25"))
  :url "http://wiki.apertium.org/wiki/Emacs"
  :commit "e146ab1b929c50450ba0708e1bdd9fed85606964"
  :revdesc "v0.3.0-0-ge146ab1b929c"
  :keywords '("convenience" "tools" "xml")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer+apertium@mm.st"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer+apertium@mm.st")))
