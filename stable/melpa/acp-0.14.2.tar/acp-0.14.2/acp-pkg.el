;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "0.14.2"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "4d7d58dc39870e9390e94617e13d7ada175d7945"
  :revdesc "4d7d58dc3987")
