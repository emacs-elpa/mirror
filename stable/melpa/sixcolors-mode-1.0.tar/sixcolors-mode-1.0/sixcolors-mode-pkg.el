;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sixcolors-mode" "1.0"
  "A customizable horizontal scrollbar."
  '((emacs "27.1"))
  :url "https://github.com/mastro35/sixcolors-mode"
  :commit "558ec1f4032b3435a8156ff3bd8016b4fd510e21"
  :revdesc "558ec1f4032b"
  :keywords '("convenience" "colors")
  :authors '(("Davide Mastromatteo" . "mastro35@gmail.com"))
  :maintainers '(("Davide Mastromatteo" . "mastro35@gmail.com")))
