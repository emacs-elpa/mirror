;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "utimeclock" "0.1"
  "Utility for time tracking."
  '((emacs "24.4"))
  :url "https://gitlab.com/ideasman42/emacs-utimeclock"
  :commit "d8ae53ad3b81802d1a943fceb99d11f083224930"
  :revdesc "d8ae53ad3b81"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
