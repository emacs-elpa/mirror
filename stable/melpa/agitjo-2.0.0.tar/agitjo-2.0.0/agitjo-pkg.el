;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agitjo" "2.0.0"
  "Manage Forgejo PRs with AGit-Flow."
  '((emacs         "30.1")
    (magit         "4.3.8")
    (markdown-mode "2.7")
    (transient     "0.9.1"))
  :url "https://codeberg.org/halvin/agitjo"
  :commit "47f20e04ed09724b0859cade3cb52eae31274c13"
  :revdesc "v2.0.0-0-g47f20e04ed09"
  :keywords '("convenience" "vc" "tools")
  :authors '(("Alvin Hsu" . "aurtzy@gmail.com"))
  :maintainers '(("Alvin Hsu" . "aurtzy@gmail.com")))
