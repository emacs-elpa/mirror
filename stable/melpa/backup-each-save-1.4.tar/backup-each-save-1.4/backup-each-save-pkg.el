;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "backup-each-save" "1.4"
  "Backup each savepoint of a file."
  ()
  :url "https://github.com/conornash/backup-each-save"
  :commit "aa3c955f5be2761f415369895f1683599de9c58a"
  :revdesc "aa3c955f5be2"
  :authors '(("Benjamin Rutt" . "brutt@bloomington.in.us"))
  :maintainers '(("Benjamin Rutt" . "brutt@bloomington.in.us")))
