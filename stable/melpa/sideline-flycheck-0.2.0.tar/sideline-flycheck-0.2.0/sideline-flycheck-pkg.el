;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-flycheck" "0.2.0"
  "Show flycheck errors with sideline."
  '((emacs    "28.1")
    (sideline "0.1.1")
    (flycheck "0.14")
    (ht       "2.4"))
  :url "https://github.com/emacs-sideline/sideline-flycheck"
  :commit "886b0d923aeaac5e6e4cd4ab42ee6a6a18553907"
  :revdesc "886b0d923aea"
  :keywords '("convenience" "flycheck")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
