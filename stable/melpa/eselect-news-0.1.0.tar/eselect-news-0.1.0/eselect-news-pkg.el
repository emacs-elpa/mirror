;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eselect-news" "0.1.0"
  "Read Gentoo eselect news in Emacs."
  '((emacs "27.1"))
  :url "https://github.com/marcin/emacs-eselect-news"
  :commit "ab4ecb45eef2a612fc24e4658289082eecddda60"
  :revdesc "v0.1.0-0-gab4ecb45eef2"
  :keywords '("tools" "convenience"))
