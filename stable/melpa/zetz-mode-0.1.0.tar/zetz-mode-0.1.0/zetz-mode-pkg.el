;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zetz-mode" "0.1.0"
  "A major mode for the ZetZ programming language."
  '((emacs "25.1")
    (dash  "2.17.0")
    (hydra "0.15.0"))
  :url "https://github.com/damon-kwok/zetz-mode"
  :commit "03a566b213e52da540818559f1b7bbb8400abb88"
  :revdesc "03a566b213e5"
  :keywords '("languages" "programming")
  :authors '(("Damon Kwok" . "damon-kwok@outlook.com"))
  :maintainers '(("Damon Kwok" . "damon-kwok@outlook.com")))
