;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iso-639" "1.1.0"
  "ISO 639."
  '((emacs "27.1"))
  :url "https://codeberg.org/tomenzgg/emacs-iso-639"
  :commit "d55dbbea5291dd41de4ccd9662f6dfd610feacb5"
  :revdesc "d55dbbea5291"
  :keywords '("tools" "multilingual" "language" "iso-639")
  :authors '(("Jean Libète" . "tomenzgg@mail.mayfirst.org"))
  :maintainers '(("Jean Libète" . "tomenzgg@mail.mayfirst.org")))
