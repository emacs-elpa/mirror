;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ietf-docs" "1.0"
  "Fetch, Cache and Load IETF documents."
  '((thingatpt "0"))
  :url "https://github.com/choppsv1/ietf-docs"
  :commit "768907bdee1df2f5ddad2ca72d5e1fa26ef0f4f7"
  :revdesc "768907bdee1d"
  :keywords '("ietf" "rfc")
  :authors '(("Christian E. Hopps" . "chopps@gmail.com"))
  :maintainers '(("Christian E. Hopps" . "chopps@gmail.com")))
