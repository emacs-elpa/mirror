;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "0.37.0"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.8.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "0194b15ec957a6ce4be2ff49c4c485f648f86d0d"
  :revdesc "0194b15ec957"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
