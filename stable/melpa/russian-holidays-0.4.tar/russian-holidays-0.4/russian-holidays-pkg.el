;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-holidays" "0.4"
  "Russian holidays for the calendar."
  ()
  :url "https://github.com/grafov/russian-holidays"
  :commit "b285a30f29d85c48e3ea4eb93972d34a090c167b"
  :revdesc "b285a30f29d8"
  :authors '(("Alexander I.Grafov" . "siberian@laika.name"))
  :maintainers '(("Alexander I.Grafov" . "siberian@laika.name")))
