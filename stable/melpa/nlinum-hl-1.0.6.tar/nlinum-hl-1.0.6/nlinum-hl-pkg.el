;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nlinum-hl" "1.0.6"
  "Heal nlinum's line numbers."
  '((emacs  "24.4")
    (nlinum "1.7")
    (cl-lib "0.5"))
  :url "https://github.com/hlissner/emacs-nlinum-hl"
  :commit "dc6b365a58e06c7d637a76a31c71a40b20da8b56"
  :revdesc "dc6b365a58e0"
  :keywords '("nlinum" "highlight" "current" "line" "faces")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "henrik@lissner.net")))
