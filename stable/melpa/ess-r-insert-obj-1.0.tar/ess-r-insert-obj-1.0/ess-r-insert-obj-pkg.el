;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-r-insert-obj" "1.0"
  "ESS complete insert value."
  '((emacs "26.1")
    (ess   "18.10.1"))
  :url "https://github.com/ShuguangSun/ess-r-insert-obj"
  :commit "a3b9339a066ecf0b4e13b123c2034c2ad0235a6a"
  :revdesc "a3b9339a066e"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
