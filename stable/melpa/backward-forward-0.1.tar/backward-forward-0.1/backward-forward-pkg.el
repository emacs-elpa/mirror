;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "backward-forward" "0.1"
  "Simple navigation backwards and forwards across marks."
  '((emacs "24.5"))
  :url "https://gitlab.com/vancan1ty/emacs-backward-forward"
  :commit "1a0c5a66313b1bc68efbf908ae8a1cfe21bff733"
  :revdesc "1a0c5a66313b"
  :keywords '("navigation" "backward" "forward")
  :authors '(("Currell Berry" . "currellberry@gmail.com"))
  :maintainers '(("Currell Berry" . "currellberry@gmail.com")))
