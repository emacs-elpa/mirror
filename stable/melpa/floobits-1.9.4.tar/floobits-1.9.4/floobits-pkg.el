;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "floobits" "1.9.4"
  "Floobits plugin for real-time collaborative editing."
  '((json      "1.2")
    (highlight "0"))
  :url "https://github.com/Floobits/floobits-emacs"
  :commit "93b3317fb6c842efe165e54c8a32bf51d436837d"
  :revdesc "93b3317fb6c8"
  :keywords '("comm" "tools"))
