;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-command" "0.2.0"
  "Yet another Git interface."
  '((term-run     "0.1.4")
    (with-editor  "2.3.1")
    (git-ps1-mode "0.2.0"))
  :url "https://github.com/10sr/git-command-el"
  :commit "6cc5c17ca3cc1967b5402bb9a0538fb90933428d"
  :revdesc "6cc5c17ca3cc"
  :keywords '("utility" "git")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
