;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-haskell-multi" "0.3"
  "Syntax-check haskell-mode using both ghc and hlint."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-haskell-multi"
  :commit "d2c9aeffd33440d360c1ea0c5aef6d1f171599f9"
  :revdesc "d2c9aeffd334"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
