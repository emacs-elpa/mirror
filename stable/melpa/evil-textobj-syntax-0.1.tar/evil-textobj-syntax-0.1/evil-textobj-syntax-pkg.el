;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-syntax" "0.1"
  "Provides syntax text objects."
  '((names "0.5")
    (emacs "24")
    (evil  "0"))
  :url "https://github.com/laishulu/evil-textobj-syntax"
  :commit "2d9ba8c75c754b409aea7469f46a5cfa52a872f3"
  :revdesc "2d9ba8c75c75"
  :keywords '("evil" "syntax" "highlight" "text-object"))
