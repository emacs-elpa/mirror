;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transfer-sh" "2.1"
  "Simple interface for sending buffer contents to transfer.sh."
  '((emacs "25.1")
    (async "1.0"))
  :url "https://github.com/SRoskamp.transfer-sh.el"
  :commit "05473d14c01d563a491b14705acf56f2f0301181"
  :revdesc "05473d14c01d"
  :keywords '("comm" "convenience" "files")
  :authors '(("S. Roskamp" . "steffen.roskamp@gmail.com")
             ("A. Hoffmann" . "tuedachu@gmail.com"))
  :maintainers '(("S. Roskamp" . "steffen.roskamp@gmail.com")
                 ("A. Hoffmann" . "tuedachu@gmail.com")))
