;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symbolword-mode" "1.0"
  "[No description available]."
  ()
  :url "https://github.com/ncaq/symbolword-mode"
  :commit "273dece5b04f7abc4c35048b2f64f04b33774b87"
  :revdesc "273dece5b04f")
