;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mykie" "0.3.1"
  "Command multiplexer: Register multiple functions to a keybind."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/yuutayamada/mykie-el"
  :commit "ab8f7549f9018c26278d101af1b90997c9e5e0b3"
  :revdesc "ab8f7549f901"
  :keywords '("emacs" "configuration" "keybind")
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
