;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebib" "2.51.1"
  "A BibTeX database manager."
  '((parsebib "6.0")
    (emacs    "27.1")
    (compat   "29.1.4.3"))
  :url "http://joostkremers.github.io/ebib/"
  :commit "248e9274804a656a13abc50214963586113a2158"
  :revdesc "248e9274804a"
  :keywords '("text" "bibtex")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
