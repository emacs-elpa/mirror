;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ggtags" "0.8.13"
  "Emacs frontend to GNU Global source code tagging system."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/leoliu/ggtags"
  :commit "17a121af1b375a6a5c5acec52f2ffd2b9715d244"
  :revdesc "17a121af1b37"
  :keywords '("tools" "convenience")
  :authors '(("Leo Liu" . "sdl.web@gmail.com"))
  :maintainers '(("Leo Liu" . "sdl.web@gmail.com")))
