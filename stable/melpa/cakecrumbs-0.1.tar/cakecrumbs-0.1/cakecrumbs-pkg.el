;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cakecrumbs" "0.1"
  "Show parents on header for HTML/Jade/Sass/Stylus."
  '((emacs "24.4"))
  :url "https://github.com/kuanyui/hexo.el"
  :commit "de771bd2e0f2928b4c6d36d6e07e487de9674574"
  :revdesc "de771bd2e0f2"
  :keywords '("languages")
  :authors '(("ono hiroko" . "kuanyui.github.io"))
  :maintainers '(("ono hiroko" . "kuanyui.github.io")))
