;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cquery" "20180122.1"
  "Cquery client for lsp-mode."
  '((emacs    "25.1")
    (lsp-mode "3.4")
    (dash     "0.13"))
  :url "https://github.com/jacobdufault/cquery"
  :commit "f20cbafc57871f1ec84ec63fdf087497d4f8b054"
  :revdesc "f20cbafc5787"
  :keywords '("languages" "lsp" "c++"))
