;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sunburn-theme" "1.0"
  "A low contrast color theme for Emacs."
  ()
  :url "https://github.com/mvarela/Sunburn-Theme"
  :commit "d64700c2b87a5b7305d202cd3ab2c03e1b04d0fe"
  :revdesc "d64700c2b87a"
  :authors '(("Martín Varela" . "(martin@varela.fi)"))
  :maintainers '(("Martín Varela" . "(martin@varela.fi)")))
