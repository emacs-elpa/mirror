;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tea-time" "0.0.0.20120331.13"
  "Simple timer package, useful to make perfect tea."
  ()
  :url "https://github.com/konzeptual/tea-time"
  :commit "1f6cf0bdd27c5eb3508989c5095427781f858eca"
  :revdesc "1f6cf0bdd27c"
  :keywords '("timer" "tea-time")
  :authors '(("konsty" . "antipin.konstantin@googlemail.com"))
  :maintainers '(("Gabriel Saldana" . "gsaldana@gmail.com")))
