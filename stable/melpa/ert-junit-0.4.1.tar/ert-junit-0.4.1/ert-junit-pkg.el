;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-junit" "0.4.1"
  "JUnit XML reports from ert results."
  '((ert   "0")
    (emacs "23.4"))
  :url "http://bitbucket.org/olanilsson/ert-junit"
  :commit "65f91c35b088b87943dbbbe7e1ce354bc9bc0992"
  :revdesc "v0.4.1-0-g65f91c35b088"
  :keywords '("tools" "test" "unittest" "ert")
  :authors '(("Ola Nilsson" . "ola.nilsson@gmail.com"))
  :maintainers '(("Ola Nilsson" . "ola.nilsson@gmail.com")))
