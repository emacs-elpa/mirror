;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "astro-ts-mode" "3.0.2"
  "Major mode for editing Astro templates."
  '((emacs "30"))
  :url "https://github.com/Sorixelle/astro-ts-mode"
  :commit "1d24c9d399dee4cfea6ed9b49d8e08891665e16c"
  :revdesc "v3.0.2-0-g1d24c9d399de"
  :keywords '("languages")
  :authors '(("Ruby Iris Juric" . "ruby@srxl.me"))
  :maintainers '(("Ruby Iris Juric" . "ruby@srxl.me")))
