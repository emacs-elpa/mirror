;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "igist" "1.8.2"
  "List, create, update and delete GitHub gists."
  '((emacs     "29.1")
    (ghub      "4.2.2")
    (transient "0.8.5"))
  :url "https://github.com/KarimAziev/igist"
  :commit "0735363f6b24910655e42e086e3a82ca5267dfc0"
  :revdesc "0735363f6b24"
  :keywords '("tools")
  :authors '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers '(("Karim Aziiev" . "karim.aziiev@gmail.com")))
