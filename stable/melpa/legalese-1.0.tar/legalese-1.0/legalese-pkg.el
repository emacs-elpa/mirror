;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "legalese" "1.0"
  "Add legalese to your program files."
  ()
  :url "https://github.com/jorgenschaefer/legalese"
  :commit "68a48e77ce24a5159086f9d5bf4cbdef3f18459a"
  :revdesc "68a48e77ce24"
  :keywords '("convenience")
  :authors '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainers '(("Jorgen Schaefer" . "forcer@forcix.cx")))
