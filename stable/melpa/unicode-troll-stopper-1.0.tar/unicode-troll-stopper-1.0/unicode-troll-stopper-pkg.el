;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-troll-stopper" "1.0"
  "[No description available]."
  '((dash "2.12.0"))
  :url "https://github.com/camsaul/emacs-unicode-troll-stopper"
  :commit "f095a2eb7aff254ad7c04532690692bb153d40e2"
  :revdesc "f095a2eb7aff"
  :keywords '("unicode")
  :authors '(("Cam Saül" . "cammsaul@gmail.com"))
  :maintainers '(("Cam Saül" . "cammsaul@gmail.com")))
