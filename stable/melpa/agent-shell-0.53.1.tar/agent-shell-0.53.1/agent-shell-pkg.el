;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.53.1"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b576fcdc8971e3d9eb5960e4ab23beb895c15b18"
  :revdesc "b576fcdc8971")
