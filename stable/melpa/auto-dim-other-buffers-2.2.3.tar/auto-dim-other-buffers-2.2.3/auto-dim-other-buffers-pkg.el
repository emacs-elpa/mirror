;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-dim-other-buffers" "2.2.3"
  "Makes windows without focus less prominent."
  '((emacs "27.1"))
  :url "https://github.com/mina86/auto-dim-other-buffers.el"
  :commit "ce10da580513a2969d14e894d9be658ffa855e0d"
  :revdesc "ce10da580513"
  :keywords '("faces")
  :authors '(("Michal Nazarewicz" . "mina86@mina86.com"))
  :maintainers '(("Michal Nazarewicz" . "mina86@mina86.com")))
