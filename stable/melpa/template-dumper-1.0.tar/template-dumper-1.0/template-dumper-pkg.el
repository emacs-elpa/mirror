;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "template-dumper" "1.0"
  "Create files from yasnippet templates."
  '((emacs     "28.1")
    (yasnippet "0.14.0")
    (f         "0.20.0"))
  :url "https://resultsmotivated.com/"
  :commit "d6470bdfce0f055cfbaf3391b51b7393e8cb8c79"
  :revdesc "d6470bdfce0f"
  :keywords '("yasnippet" "templating" "convenience" "tools"))
