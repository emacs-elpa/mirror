;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cask-mode" "0.1"
  "Major mode for editing Cask files."
  '((emacs "24.3"))
  :url "https://github.com/Wilfred/cask-mode"
  :commit "5203b1beac4dd2ee07a6e993bc86719f5f35dbbf"
  :revdesc "5203b1beac4d"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
