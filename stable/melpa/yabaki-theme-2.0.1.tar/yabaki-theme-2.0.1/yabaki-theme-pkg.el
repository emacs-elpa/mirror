;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yabaki-theme" "2.0.1"
  "Yabaki, the cast shadow."
  '((emacs "27.1"))
  :url "https://codeberg.org/seahorse/yabaki-theme"
  :commit "209f2be321509dac00631fff1b0f7ea01ba382de"
  :revdesc "209f2be32150"
  :authors '(("David Goudou" . "david.goudou@gmail.com"))
  :maintainers '(("David Goudou" . "david.goudou@gmail.com")))
