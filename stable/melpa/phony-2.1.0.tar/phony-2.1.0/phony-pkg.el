;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phony" "2.1.0"
  "Define voice commands."
  '((emacs      "29.1")
    (simulacrum "2.0.0"))
  :url "https://github.com/ErikPrantare/phony.el"
  :commit "0cdf57b3b7fd9ba083cd2150078f79d74bf199af"
  :revdesc "0cdf57b3b7fd"
  :keywords '("files")
  :authors '(("Erik Präntare" . "erik@prantare.xyz"))
  :maintainers '(("Erik Präntare" . "erik@prantare.xyz")))
