;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-gt" "0.4"
  "Improvements for org-roam."
  '((emacs    "30.1")
    (org      "9.8")
    (org-roam "2.2.2"))
  :url "https://github.com/dmgerman/org-roam-gt"
  :commit "a19aafe2de37c4501d0e21d33ff5b13abcde2268"
  :revdesc "a19aafe2de37"
  :keywords '("outlines" "hypermedia")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
