;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-aws" "1.0.0"
  "Manage AWS EC2 server instances directly from Emacs."
  '((helm "1.5.3"))
  :url "https://github.com/istib/helm-aws"
  :commit "172a4a3427d31c999e27e9ee06aa8e3822364a8c"
  :revdesc "1.0.0-0-g172a4a3427d3")
