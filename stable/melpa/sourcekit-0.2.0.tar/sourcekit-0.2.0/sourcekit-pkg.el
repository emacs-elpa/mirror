;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sourcekit" "0.2.0"
  "Library to interact with sourcekittendaemon."
  '((emacs           "24.3")
    (dash            "2.12.1")
    (dash-functional "1.2.0")
    (request         "0.2.0"))
  :url "https://github.com/nathankot/company-sourcekit"
  :commit "8ba62ac25bf533b7f148f333bcb5c1db799f749b"
  :revdesc "8ba62ac25bf5"
  :keywords '("tools" "processes")
  :authors '(("Nathan Kot" . "nk@nathankot.com"))
  :maintainers '(("Nathan Kot" . "nk@nathankot.com")))
