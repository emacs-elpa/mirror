;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "todotxt" "0.2.5"
  "A major mode for editing todo.txt files."
  ()
  :url "https://github.com/rpdillon/todotxt.el"
  :commit "b51f7fa1357d2cbc1b72b10d15f8c6f009ce5a46"
  :revdesc "b51f7fa1357d"
  :keywords '("todo.txt" "todotxt" "todotxt.el")
  :authors '(("Rick Dillon" . "rpdillon@killring.org"))
  :maintainers '(("Rick Dillon" . "rpdillon@killring.org")))
