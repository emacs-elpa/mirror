;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kibit-helper" "0.1.1"
  "Conveniently use the Kibit Leiningen plugin from Emacs."
  '((s     "0.8")
    (emacs "24"))
  :url "http://www.github.com/brunchboy/kibit-helper"
  :commit "ec5f154db3bb0c838e86f527353f08644cede926"
  :revdesc "ec5f154db3bb"
  :keywords '("languages" "clojure" "kibit")
  :authors '(("James Elliott" . "james@brunchboy.com"))
  :maintainers '(("James Elliott" . "james@brunchboy.com")))
