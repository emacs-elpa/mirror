;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bookmark-in-project" "0.2"
  "Bookmark access within a project."
  '((emacs "27.1"))
  :url "https://codeberg.org/ideasman42/emacs-bookmark-in-project"
  :commit "b3255afd8bddd0e6705fa2556205bf1c1192fc37"
  :revdesc "b3255afd8bdd"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
