;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prometheus-mode" "0.0.1"
  "Major modes for Prometheus files."
  '((emacs "24.3"))
  :url "https://hoeg.com"
  :commit "bd0dc65cd08469b734bd9dc0e0e8d8345d3f0877"
  :revdesc "bd0dc65cd084"
  :keywords '("languages")
  :authors '(("Peter Hoeg" . "(peter@hoeg.com)"))
  :maintainers '(("Peter Hoeg" . "(peter@hoeg.com)")))
