;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dpkg-dev-el" "37.1"
  "Startup file for the debian-el package."
  ()
  :commit "54b137309b078ec39f4b982368c500df04d4bd5f"
  :revdesc "37.1-0-g54b137309b07")
