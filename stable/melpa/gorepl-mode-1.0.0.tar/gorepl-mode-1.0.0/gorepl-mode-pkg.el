;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gorepl-mode" "1.0.0"
  "Go REPL Interactive Development in top of Gore."
  '((emacs "24"))
  :url "http://www.github.com/manute/gorepl-mode"
  :commit "17e025951f5964a0542a4b353ddddbc734c01eed"
  :revdesc "17e025951f59"
  :keywords '("languages" "go" "golang" "gorepl")
  :authors '(("Manuel Alonso" . "manuteali@gmail.com"))
  :maintainers '(("Manuel Alonso" . "manuteali@gmail.com")))
