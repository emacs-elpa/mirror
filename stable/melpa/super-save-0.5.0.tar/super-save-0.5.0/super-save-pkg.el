;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "super-save" "0.5.0"
  "Auto-save buffers, based on your activity."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/super-save"
  :commit "c7bcc9d9ce048995b9bb4216069e07209c13aa05"
  :revdesc "c7bcc9d9ce04"
  :keywords '("convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
