;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "1.5"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "60cc1b9d0a7a0026c20a7446072cf94e3b1f63c7"
  :revdesc "v1.5-0-g60cc1b9d0a7a"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
