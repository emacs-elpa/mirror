;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-R" "0.2.2"
  "Various polymodes for R language."
  '((emacs         "25")
    (polymode      "0.2.2")
    (poly-markdown "0.2.2")
    (poly-noweb    "0.2.2"))
  :url "https://github.com/polymode/poly-R"
  :commit "51ffeb6ec45dd44eafa4d22ad2d6150cc4b248fc"
  :revdesc "51ffeb6ec45d"
  :keywords '("languages" "multi-modes"))
