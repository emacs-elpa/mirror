;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-bashate" "1.0.4"
  "A Flymake backend for bashate, a Bash scripts style checker."
  '((flymake-quickdef "1.0.0")
    (emacs            "27.1"))
  :url "https://github.com/jamescherti/flymake-bashate.el"
  :commit "c599d3c15c6f174a54c1f3d0081311758e682089"
  :revdesc "1.0.4-0-gc599d3c15c6f"
  :keywords '("tools"))
