;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.47.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "a2fe16d781de7b2e2eafb3d9139987a57cded319"
  :revdesc "a2fe16d781de"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
