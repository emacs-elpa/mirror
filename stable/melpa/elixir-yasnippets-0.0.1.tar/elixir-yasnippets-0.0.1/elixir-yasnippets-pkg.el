;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elixir-yasnippets" "0.0.1"
  "Yasnippets for Elixir."
  '((yasnippet "0.8.0"))
  :url "https://github.com/hisea/elixir-yasnippets"
  :commit "6b55c88ce483932f226b6bca0212b589d1d393ea"
  :revdesc "6b55c88ce483"
  :keywords '("snippets")
  :authors '(("Yinghai Zhao" . "zyinghai@gmail.com"))
  :maintainers '(("Yinghai Zhao" . "zyinghai@gmail.com")))
