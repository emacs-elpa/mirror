;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-desktop-notify" "1.4"
  "Gnus Desktop Notification global minor mode."
  '((gnus "1.0"))
  :url "http://www.thregr.org/~wavexx/hacks/gnus-desktop-notify/"
  :commit "210c70f0021ee78e724f1d8e00ca96e1e99928ca"
  :revdesc "1.4-0-g210c70f0021e"
  :authors '(("Yuri D'Elia" . "wavexxATthregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexxATthregr.org")))
