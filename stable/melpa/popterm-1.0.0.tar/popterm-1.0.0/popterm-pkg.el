;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "1.0.0"
  "Posframe terminal toggler with smart backends."
  '((emacs    "28.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "32d671c7964fae303ddbc490bfcbdc66fbccaf16"
  :revdesc "32d671c7964f"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
