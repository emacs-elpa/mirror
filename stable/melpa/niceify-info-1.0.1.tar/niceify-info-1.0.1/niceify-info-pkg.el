;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "niceify-info" "1.0.1"
  "Improve usability of Info pages."
  ()
  :url "https://github.com/aaron-em/niceify-info.el"
  :commit "66b45916f1994e16ee023d29fa7cf8fec48078f1"
  :revdesc "66b45916f199")
