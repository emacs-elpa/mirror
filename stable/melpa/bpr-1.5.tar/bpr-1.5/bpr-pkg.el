;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bpr" "1.5"
  "Background Process Runner."
  '((emacs "24"))
  :url "https://github.com/ilya-babanov/emacs-bpr"
  :commit "f606e1946afb2808166e5a2a37fbcfa1a13739ef"
  :revdesc "f606e1946afb"
  :keywords '("background" "async" "process" "management")
  :authors '(("Ilya Babanov" . "ilya-babanov@ya.ru"))
  :maintainers '(("Ilya Babanov" . "ilya-babanov@ya.ru")))
