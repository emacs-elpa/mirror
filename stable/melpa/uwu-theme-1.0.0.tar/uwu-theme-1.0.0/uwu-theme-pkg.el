;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uwu-theme" "1.0.0"
  "[No description available]."
  ()
  :url "https://github.com/kborling/uwu.el"
  :commit "04435d60a1c68fa48f08a087a00f29c6b9da005d"
  :revdesc "04435d60a1c6"
  :keywords '("custom themes" "faces")
  :authors '(("Kevin Borling" . "https://github.com/kborling"))
  :maintainers '(("Kevin Borling" . "https://github.com/kborling")))
