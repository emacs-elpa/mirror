;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "0.2"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "17b7efd212fbc905d2e1fb15561ec6b0fc1060fc"
  :revdesc "17b7efd212fb"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
