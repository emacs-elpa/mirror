;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-import" "1.0"
  "Import Javascript files from your current project or dependencies."
  '((emacs      "24.4")
    (f          "20160815.1253")
    (projectile "20160830.138")
    (dash       "20160820.501"))
  :url "https://github.com/jakoblind/js-import"
  :commit "903ef899d0c0fe6a5d6b4b1a54136661cc297413"
  :revdesc "903ef899d0c0"
  :keywords '("tools")
  :authors '(("Jakob Lind" . "399339+jakoblind@users.noreply.github.com"))
  :maintainers '(("Jakob Lind" . "399339+jakoblind@users.noreply.github.com")))
