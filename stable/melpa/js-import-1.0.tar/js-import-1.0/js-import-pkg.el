;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-import" "1.0"
  "Import Javascript files from your current project or dependencies."
  '((emacs      "24.4")
    (f          "20160815.1253")
    (projectile "20160830.138")
    (dash       "20160820.501"))
  :url "https://github.com/jakoblind/js-import"
  :commit "e8181404685490c849ee92fb1f4e8440fc743512"
  :revdesc "e81814046854"
  :keywords '("tools")
  :authors '(("Jakob Lind" . "karl.jakob.lind@gmail.com"))
  :maintainers '(("Jakob Lind" . "karl.jakob.lind@gmail.com")))
