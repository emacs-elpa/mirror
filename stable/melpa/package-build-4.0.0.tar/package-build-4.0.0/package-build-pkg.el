;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "4.0.0"
  "Tools for assembling a package archive."
  '((emacs "25.1"))
  :url "https://github.com/melpa/package-build"
  :commit "0598e92cd61aa5196f78576fac7675bcff4ab217"
  :revdesc "4.0.0-0-g0598e92cd61a"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoul.li")
             ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
                 ("Steve Purcell" . "steve@sanityinc.com")
                 ("Jonas Bernoulli" . "jonas@bernoul.li")
                 ("Phil Hagelberg" . "technomancy@gmail.com")))
