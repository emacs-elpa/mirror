;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "show-css" "1.1"
  "Show the css of the html attribute the cursor is on."
  ()
  :url "https://github.com/8cylinder/showcss-mode"
  :commit "5138db88ff4641b7cc45edec9a7db95199baec56"
  :revdesc "5138db88ff46"
  :keywords '("hypermedia")
  :authors '(("Sheldon McGrandle" . "developer@rednemesis.com"))
  :maintainers '(("Sheldon McGrandle" . "developer@rednemesis.com")))
