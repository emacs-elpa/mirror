;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient-extras-lp" "1.0.1"
  "A transient interface to lp."
  '((emacs            "28.1")
    (transient-extras "1.0.0"))
  :url "https://github.com/haji-ali/transient-extras.git"
  :commit "3f086b5418340d8a28ee4f1b53398c52603bd080"
  :revdesc "3f086b541834"
  :keywords '("convenience")
  :authors '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com")))
