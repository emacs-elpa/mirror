;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wikinfo" "0.0.0"
  "Scrape Wikipedia Infoboxes."
  '((emacs "26.1"))
  :url "https://github.com/progfolio/wikinfo"
  :commit "15785618b7b80c8b918727290fecefffa300498b"
  :revdesc "15785618b7b8"
  :keywords '("org" "convenience")
  :authors '(("Nicholas Vollmer" . "progfolio@protonmail.com"))
  :maintainers '(("Nicholas Vollmer" . "progfolio@protonmail.com")))
