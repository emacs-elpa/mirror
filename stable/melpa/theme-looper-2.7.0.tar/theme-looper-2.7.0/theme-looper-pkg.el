;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "theme-looper" "2.7.0"
  "Loop thru the available color-themes."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "http://ismail.teamfluxion.com"
  :commit "6bc170097f1dfb7ea4db91544c5ab653279e15cd"
  :revdesc "6bc170097f1d"
  :keywords '("convenience" "color-themes")
  :authors '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com"))
  :maintainers '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com")))
