;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "totp-auth" "1.1"
  "RFC6238 TOTP."
  '((emacs  "27.1")
    (base32 "0.1"))
  :url "https://gitlab.com/fledermaus/totp.el"
  :commit "927257e97a602b6979a75028e8417bf1499582d4"
  :revdesc "927257e97a60"
  :keywords '("2fa" "two-factor" "totp" "otp" "password" "comm")
  :authors '(("Vivek Das Mohapatra" . "vivek@etla.org"))
  :maintainers '(("Vivek Das Mohapatra" . "vivek@etla.org")))
