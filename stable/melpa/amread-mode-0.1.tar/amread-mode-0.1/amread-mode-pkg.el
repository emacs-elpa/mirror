;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amread-mode" "0.1"
  "A minor mode helper user reading."
  '((emacs "24"))
  :url "https://github.com/stardiviner/amread-mode"
  :commit "65fa01da31d2ca9af812b6b7d23c216039449132"
  :revdesc "65fa01da31d2"
  :keywords '("read")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
