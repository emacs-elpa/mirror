;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rspec-mode" "1.11"
  "Enhance ruby-mode for RSpec."
  '((ruby-mode "1.0")
    (cl-lib    "0.4"))
  :url "https://github.com/pezra/rspec-mode"
  :commit "e289e52ec4b3aa1caf35957d721e5568eca2a3bb"
  :revdesc "e289e52ec4b3"
  :keywords '("rspec" "ruby"))
