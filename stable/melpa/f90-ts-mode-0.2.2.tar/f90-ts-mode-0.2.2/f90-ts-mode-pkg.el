;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f90-ts-mode" "0.2.2"
  "Tree-sitter based Fortran 90 mode."
  '((emacs "30.1"))
  :url "https://github.com/mscfd/emacs-f90-ts-mode"
  :commit "6c3e40cad1fc459b5c4084ce21e748a0a4145612"
  :revdesc "v0.2.2-0-g6c3e40cad1fc"
  :keywords '("languages" "treesitter" "fortran")
  :authors '(("Martin Stein" . "mscfd@gmx.net"))
  :maintainers '(("Martin Stein" . "mscfd@gmx.net")))
