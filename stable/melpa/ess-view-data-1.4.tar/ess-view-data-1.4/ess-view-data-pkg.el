;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-view-data" "1.4"
  "View Data."
  '((emacs    "26.1")
    (ess      "18.10.1")
    (csv-mode "1.12"))
  :url "https://github.com/ShuguangSun/ess-view-data"
  :commit "fddf070b51dbcbf7fa060a9998e676e8d0c15e1d"
  :revdesc "fddf070b51db"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
