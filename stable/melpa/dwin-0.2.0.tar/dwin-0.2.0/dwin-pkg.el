;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwin" "0.2.0"
  "Navigate and arrange desktop windows."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/lsth/dwin"
  :commit "aed6438f22783c5590ad5e3ac71575b70a9d64ed"
  :revdesc "v0.2.0-0-gaed6438f2278"
  :keywords '("frames" "processes" "convenience")
  :authors '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de"))
  :maintainers '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de")))
