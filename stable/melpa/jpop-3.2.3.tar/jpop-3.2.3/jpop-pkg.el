;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jpop" "3.2.3"
  "Lightweight project cacheing and navigation framework."
  '((emacs "24")
    (dash  "2.11.0"))
  :url "https://github.com/domtronn/jpop"
  :commit "f3eed65e54dc2daaa7678e6eb169d35c4a7d1e63"
  :revdesc "f3eed65e54dc"
  :keywords '("project" "convenience")
  :authors '(("Dom Charlesworth" . "dgc336@gmail.com"))
  :maintainers '(("Dom Charlesworth" . "dgc336@gmail.com")))
