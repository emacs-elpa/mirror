;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spell-fu" "0.3"
  "Fast & light spelling highlighter."
  '((emacs "26.2"))
  :url "https://gitlab.com/ideasman42/emacs-spell-fu"
  :commit "ddad489f2c87467480520502a93e682f81bfac18"
  :revdesc "ddad489f2c87"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
