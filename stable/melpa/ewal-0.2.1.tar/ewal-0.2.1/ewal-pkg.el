;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ewal" "0.2.1"
  "A pywal-based theme generator."
  '((emacs "25.1"))
  :url "https://gitlab.com/jjzmajic/ewal"
  :commit "732a2f4abb480f9f5a3249af822d8eb1e90324e3"
  :revdesc "732a2f4abb48"
  :keywords '("faces"))
