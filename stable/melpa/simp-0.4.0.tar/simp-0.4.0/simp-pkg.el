;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simp" "0.4.0"
  "Simple project defenition, chiefly for file finding, and grepping."
  ()
  :url "https://github.com/re5et/simp"
  :commit "18a59d45dbd648e3e701856866e8e1a30f1d2c85"
  :revdesc "18a59d45dbd6"
  :keywords '("project" "grep" "find"))
