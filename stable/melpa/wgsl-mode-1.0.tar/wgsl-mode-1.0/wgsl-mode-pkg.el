;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wgsl-mode" "1.0"
  "Syntax coloring for GAL."
  ()
  :url "https://github.com/acowley/wgsl-mode"
  :commit "9d9042af183f35549cb86b970e80e3bf3181b4be"
  :revdesc "9d9042af183f"
  :keywords '("wgsl" "c"))
