;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-repo-todo" "0.0.3"
  "Simple repository todo management with org-mode."
  ()
  :url "https://github.com/waymondo/org-repo-todo"
  :commit "cba6145c6821fd2bbd96a1c9ef2346c281b76ad2"
  :revdesc "cba6145c6821"
  :keywords '("convenience")
  :authors '(("justin talbott" . "justin@waymondo.com"))
  :maintainers '(("justin talbott" . "justin@waymondo.com")))
