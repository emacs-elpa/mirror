;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fyure" "0.0.1"
  "An interface to fix Japanese hyoki-yure."
  ()
  :url "https://github.com/mooz/fyure"
  :commit "c0af676da4e0cc77ba959bd1beb2d904658a05a0"
  :revdesc "c0af676da4e0"
  :keywords '("languages")
  :authors '(("Masafumi Oyamada" . "stillpedant@gmail.com"))
  :maintainers '(("Masafumi Oyamada" . "stillpedant@gmail.com")))
