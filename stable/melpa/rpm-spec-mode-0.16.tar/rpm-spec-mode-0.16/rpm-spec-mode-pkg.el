;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rpm-spec-mode" "0.16"
  "RPM spec file editing commands for Emacs/XEmacs."
  ()
  :url "https://github.com/Thaodan/rpm-spec-mode"
  :commit "7d06d19a31e888b932da6c8202ff2c73f42703a1"
  :revdesc "7d06d19a31e8"
  :keywords '("unix" "languages")
  :authors '((nil . "stig@bjorlykke.org"))
  :maintainers '((nil . "stig@bjorlykke.org")))
