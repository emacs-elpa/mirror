;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "synonymous" "1.0"
  "[No description available]."
  '((cl-lib  "0.5")
    (request "0.2.0"))
  :url "https://github.com/toroidal-code/cycle-themes.el"
  :commit "c6cf8eb6a26f516dccb127e5c81e62ea17173391"
  :revdesc "c6cf8eb6a26f"
  :keywords '("utility")
  :authors '(("Katherine Whitlock" . "toroidalcode@gmail.com"))
  :maintainers '(("Katherine Whitlock" . "toroidalcode@gmail.com")))
