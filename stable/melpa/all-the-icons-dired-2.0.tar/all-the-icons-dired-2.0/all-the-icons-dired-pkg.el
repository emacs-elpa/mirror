;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "all-the-icons-dired" "2.0"
  "Shows icons for each file in dired mode."
  '((emacs         "24.4")
    (all-the-icons "2.2.0"))
  :url "https://github.com/wyuenho/all-the-icons-dired"
  :commit "a758766878b6e8b9eaaf41d68599a2df99e37f48"
  :revdesc "a758766878b6"
  :keywords '("files" "icons" "dired")
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
