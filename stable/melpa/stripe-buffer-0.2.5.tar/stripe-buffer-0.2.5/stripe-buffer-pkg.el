;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripe-buffer" "0.2.5"
  "Use a different background for even and odd lines."
  '((cl-lib "1.0"))
  :url "https://github.com/sabof/stripe-buffer"
  :commit "d9f009b92cf16fe2c40cd92b8f842a3872e6c190"
  :revdesc "d9f009b92cf1"
  :authors '(("Andy Stewart" . "lazycat.manatee@gmail.com"))
  :maintainers '(("sabof" . "esabof@gmail.com")))
