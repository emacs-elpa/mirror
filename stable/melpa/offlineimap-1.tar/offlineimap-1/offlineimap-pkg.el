;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "offlineimap" "1"
  "Run OfflineIMAP from Emacs."
  ()
  :url "http://julien.danjou.info/offlineimap-el.html"
  :commit "646482203aacdf847d57d0a96263fddcfc33fb61"
  :revdesc "v1-0-g646482203aac"
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")))
