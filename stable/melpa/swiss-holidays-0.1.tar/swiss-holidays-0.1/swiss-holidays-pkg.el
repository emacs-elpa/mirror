;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swiss-holidays" "0.1"
  "Swiss holidays for the calendar."
  ()
  :url "https://github.com/egli/swiss-holidays"
  :commit "5323fb2b68ae9dc22b1a47cfb3ad9566f0adda73"
  :revdesc "5323fb2b68ae"
  :authors '(("Christian Egli" . "christian.egli@alumni.ethz.ch"))
  :maintainers '(("Christian Egli" . "christian.egli@alumni.ethz.ch")))
