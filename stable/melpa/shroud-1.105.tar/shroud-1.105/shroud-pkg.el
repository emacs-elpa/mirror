;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shroud" "1.105"
  "Shroud secrets."
  '((emacs           "25")
    (epg             "1.0.0")
    (s               "1.6.0")
    (bui             "1.2.0")
    (dash            "2.15.0")
    (dash-functional "2.15.0"))
  :url "https://github.com/o-nly/emacs-shroud"
  :commit "f758d497f87afd847126d2e69b2f7ba10a5bbbfa"
  :revdesc "1.105-0-gf758d497f87a"
  :keywords '("tools" "password")
  :authors '(("Amar Singh" . "nly@disroot.org"))
  :maintainers '(("Amar Singh" . "nly@disroot.org")))
