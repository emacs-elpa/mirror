;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "skewer-mode" "1.8.0"
  "Live browser JavaScript, CSS, and HTML interaction."
  ()
  :url "https://github.com/skeeto/skewer-mode"
  :commit "a10955db9ef95b0243ee31bcd30a6fb07ce5302b"
  :revdesc "1.8.0-0-ga10955db9ef9"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
