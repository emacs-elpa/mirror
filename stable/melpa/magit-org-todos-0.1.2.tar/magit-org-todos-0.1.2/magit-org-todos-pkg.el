;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-org-todos" "0.1.2"
  "Add local todo items to the magit status buffer."
  '((magit "2.0.0")
    (emacs "24"))
  :url "https://github.com/danielma/magit-org-todos"
  :commit "0bfa36bbc50e62de0a3406031cb93e2f57dcdc55"
  :revdesc "0bfa36bbc50e"
  :keywords '("org-mode" "magit" "tools"))
