;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "savekill" "20140418.2152"
  "Save kill ring to disk."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/download/savekill.el"
  :commit "67fc94e3d8fe8ce3ca16f90518f6a46479b63e34"
  :revdesc "67fc94e3d8fe"
  :keywords '("tools")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
