;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coverlay" "3.0.2"
  "Test coverage overlays."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/twada/coverlay.el"
  :commit "0beae208d0e7d746a94385428bd61aa5cd7ea828"
  :revdesc "v3.0.2-0-g0beae208d0e7"
  :keywords '("coverage" "overlay")
  :authors '(("Takuto Wada" . "takuto.wadaatgmailcom"))
  :maintainers '(("Takuto Wada" . "takuto.wadaatgmailcom")))
