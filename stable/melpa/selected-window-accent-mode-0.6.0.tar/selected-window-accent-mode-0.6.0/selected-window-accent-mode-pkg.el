;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-accent-mode" "0.6.0"
  "Accent Selected Window."
  '((emacs              "25.1")
    (visual-fill-column "0.0"))
  :url "https://github.com/captainflasmr/selected-window-accent-mode"
  :commit "e83efa67c4a9d1935c657a15b4487102cb6655de"
  :revdesc "e83efa67c4a9"
  :keywords '("convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
