;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "init-dir" "0.2.1"
  "Init directory instead of just a single file."
  '((emacs          "27.1")
    (benchmark-init "1.2"))
  :url "https://github.com/chaosemer/init-dir"
  :commit "fd3da1d7a4caf337eebf53de5cd6f5cadad00537"
  :revdesc "fd3da1d7a4ca"
  :keywords '("extensions" "internal")
  :authors '(("Jared Finder" . "jared@finder.org"))
  :maintainers '(("Jared Finder" . "jared@finder.org")))
