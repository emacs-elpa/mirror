;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dokuwiki-mode" "0.1.1"
  "Major mode for DokuWiki document."
  ()
  :url "https://github.com/kai2nenobu/emacs-dokuwiki-mode"
  :commit "e4e116f6fcc373e3f5937c1a7daa5c2c9c6d3fa1"
  :revdesc "v0.1.1-0-ge4e116f6fcc3"
  :keywords '("hypermedia" "text" "dokuwiki")
  :authors '(("Tsunenobu Kai" . "kai2nenobu@gmail.com"))
  :maintainers '(("Tsunenobu Kai" . "kai2nenobu@gmail.com")))
