;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-embrace" "0.1.1"
  "Evil integration of embrace.el."
  '((emacs         "24.4")
    (embrace       "0.1.0")
    (evil-surround "0"))
  :url "https://github.com/cute-jumper/evil-embrace.el"
  :commit "4379adea032b25e359d01a36301b4a5afdd0d1b7"
  :revdesc "4379adea032b"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
