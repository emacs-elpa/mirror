;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sass-mode" "3.0.18"
  "Major mode for editing Sass files."
  '((haml-mode "3.0.15"))
  :url "https://github.com/nex3/haml/tree/master"
  :commit "26a66e331b507fb420e3bb7d0a6a8fbb04294343"
  :revdesc "26a66e331b50"
  :keywords '("markup" "language" "css"))
