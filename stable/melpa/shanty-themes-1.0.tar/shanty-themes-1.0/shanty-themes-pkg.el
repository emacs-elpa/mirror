;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shanty-themes" "1.0"
  "The themes for digital workers."
  '((emacs "27.2"))
  :url "https://github.com/qhga/shanty-themes"
  :commit "1817b65fdb36a8a09b4b1e6e06fe7172acf219bb"
  :revdesc "1817b65fdb36"
  :keywords '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :authors '(("Philip Gaber" . "phga@posteo.de"))
  :maintainers '(("Philip Gaber" . "phga@posteo.de")))
