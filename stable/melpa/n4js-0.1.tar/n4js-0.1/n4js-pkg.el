;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "n4js" "0.1"
  "Neo4j Shell for Emacs."
  '((emacs "24"))
  :url "https://github.com/tmtxt/n4js.el"
  :commit "6f8816be33b079d503ab592f865c0f084a371218"
  :revdesc "6f8816be33b0"
  :keywords '("neo4j" "shell" "comint")
  :authors '(("TruongTx" . "me@truongtx.me"))
  :maintainers '(("TruongTx" . "me@truongtx.me")))
