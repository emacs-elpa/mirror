;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.5.25.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "ba1733c992340e69919a60815041ccf7bacc5215"
  :revdesc "ba1733c99234"
  :keywords '("languages"))
