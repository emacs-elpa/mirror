;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-atool" "1.3.0"
  "Pack/unpack files with atool on dired."
  '((emacs "24"))
  :url "https://github.com/HKey/dired-atool"
  :commit "c01e0a79c952a29db17c262c9ce8a90632b04b3a"
  :revdesc "c01e0a79c952"
  :keywords '("files")
  :authors '(("Hiroki YAMAKAWA" . "s06139@gmail.com"))
  :maintainers '(("Hiroki YAMAKAWA" . "s06139@gmail.com")))
