;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "third-time" "1.3.0"
  "Third Time: A Better Way to Work."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~swflint/busylight"
  :commit "d1e0e146c298de0114035b19c9c4f990db7f1ae5"
  :revdesc "v1.3.0-0-gd1e0e146c298"
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
