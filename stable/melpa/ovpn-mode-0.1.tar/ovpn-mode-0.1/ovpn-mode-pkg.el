;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ovpn-mode" "0.1"
  "An openvpn management mode."
  '((emacs "24"))
  :url "https://github.com/anticomputer/ovpn-mode"
  :commit "a492387141e29fcfc33ea0430736853d59d01a0d"
  :revdesc "a492387141e2"
  :keywords '("comm")
  :authors '(("Bas Alberts" . "bas@anti.computer"))
  :maintainers '(("Bas Alberts" . "bas@anti.computer")))
