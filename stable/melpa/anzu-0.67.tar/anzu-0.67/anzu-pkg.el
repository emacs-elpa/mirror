;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anzu" "0.67"
  "Show number of matches in mode-line while searching."
  '((emacs "25.1"))
  :url "https://github.com/emacsorphanage/anzu"
  :commit "be015183090dbe8fe5f9eeb26ddf469af3ee360c"
  :revdesc "be015183090d"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("LemonBreezes" . "look@strawberrytea.xyz")))
