;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recentf-remove-sudo-tramp-prefix" "0.0.0"
  "Normalise recentf history."
  '((emacs "24.4"))
  :url "https://github.com/ncaq/recentf-remove-sudo-tramp-prefix"
  :commit "58b75c1f37f9858f424b089e8542d0bae9df71f6"
  :revdesc "58b75c1f37f9"
  :authors '(("ncaq" . "ncaq@ncaq.net"))
  :maintainers '(("ncaq" . "ncaq@ncaq.net")))
