;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "untappd" "0.0.2"
  "Display your latest Untappd feed."
  '((emacs   "26.1")
    (request "0.3.2")
    (emojify "1.2.1"))
  :url "https://github.com/smallwat3r/untappd.el"
  :commit "78b9b30e42135917ac68c9b3caab4984b3f491e2"
  :revdesc "78b9b30e4213"
  :authors '(("Matthieu Petiteau" . "matt@smallwat3r.com"))
  :maintainers '(("Matthieu Petiteau" . "matt@smallwat3r.com")))
