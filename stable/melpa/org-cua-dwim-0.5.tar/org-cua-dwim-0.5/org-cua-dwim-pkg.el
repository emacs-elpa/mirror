;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-cua-dwim" "0.5"
  "Org-mode and Cua mode compatibility layer."
  ()
  :url "https://github.com/mattfidler/org-cua-dwim.el"
  :commit "05abd34cb81c58e6c189ea71ffff193729e179eb"
  :revdesc "05abd34cb81c"
  :keywords '("org-mode" "cua-mode"))
