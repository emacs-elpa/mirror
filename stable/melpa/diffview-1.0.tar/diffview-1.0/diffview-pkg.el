;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diffview" "1.0"
  "View diffs in side-by-side format."
  ()
  :url "https://github.com/mgalgs/diffview-mode"
  :commit "471dc36af93e68849bf2da0db991e186283b3546"
  :revdesc "471dc36af93e"
  :keywords '("convenience" "diff")
  :authors '(("Mitchel Humpherys" . "mitch.special@gmail.com"))
  :maintainers '(("Mitchel Humpherys" . "mitch.special@gmail.com")))
