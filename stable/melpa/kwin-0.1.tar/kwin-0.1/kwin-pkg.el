;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kwin" "0.1"
  "Communcate with the KWin window manager."
  ()
  :url "https://github.com/Tass/kwin-minor-mode"
  :commit "7b42094aaa1fc6dde43b1f82ff1bb3b8afefc98d"
  :revdesc "7b42094aaa1f")
