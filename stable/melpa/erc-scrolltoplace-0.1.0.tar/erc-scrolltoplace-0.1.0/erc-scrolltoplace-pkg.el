;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-scrolltoplace" "0.1.0"
  "An Erc module to scrolltobottom better with keep-place."
  '((emacs                   "24.0")
    (switch-buffer-functions "0.0.1"))
  :url "https://github.com/jgkamat/erc-scrolltoplace"
  :commit "7539654e4a72edcc5bba07a101961e5bf0a9d449"
  :revdesc "0.1.0-0-g7539654e4a72"
  :keywords '("erc" "module" "comm" "scrolltobottom" "keep-place")
  :authors '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainers '(("Jay Kamat" . "jaygkamat@gmail.com")))
