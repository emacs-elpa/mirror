;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "1.1.0"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.0.0")
    (vui    "0.1"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "fdd6749cb4a252a369e09dd1c76d01f063b44d8b"
  :revdesc "v1.1.0-0-gfdd6749cb4a2"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
