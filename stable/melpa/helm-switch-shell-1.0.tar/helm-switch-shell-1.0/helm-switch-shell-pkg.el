;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-switch-shell" "1.0"
  "A Helm source for switching between shell buffers."
  '((emacs  "25")
    (cl-lib "0.5")
    (helm   "2.8.8")
    (dash   "2.16.0")
    (s      "1.12.0"))
  :url "https://github.com/jamesnvc/helm-switch-shell"
  :commit "f510314a37001f93dfdc01fe8cd0e59edc545725"
  :revdesc "f510314a3700"
  :keywords '("matching" "processes" "terminals" "tools")
  :authors '(("James N. V. Cash" . "james.cash@occasionallycogent.com"))
  :maintainers '(("James N. V. Cash" . "james.cash@occasionallycogent.com")))
