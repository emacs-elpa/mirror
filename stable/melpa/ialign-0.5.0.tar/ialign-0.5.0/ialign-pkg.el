;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ialign" "0.5.0"
  "Visual align-regexp."
  '((emacs "25.1"))
  :url "https://github.com/mkcms/interactive-align"
  :commit "fd1ad6bae74961e0b6bdf0bd15e6d9679186aaed"
  :revdesc "v0.5.0-0-gfd1ad6bae749"
  :keywords '("tools" "editing" "align" "interactive")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
