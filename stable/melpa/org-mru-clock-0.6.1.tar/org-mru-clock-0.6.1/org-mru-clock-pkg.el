;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mru-clock" "0.6.1"
  "Clock in/out of tasks with completion and persistent history."
  '((emacs "26.1"))
  :url "https://github.com/unhammer/org-mru-clock"
  :commit "454d317bf772a616cb76cf2212f111c7977016a2"
  :revdesc "v0.6.1-0-g454d317bf772"
  :keywords '("convenience" "calendar")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
