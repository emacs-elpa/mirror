;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gist" "1.4.0"
  "Emacs integration for gist.github.com."
  '((emacs "24.1")
    (gh    "0.10.0"))
  :url "https://github.com/defunkt/gist.el"
  :commit "a03f142455e8b39f77fbd57ee1c1e44478c1f9e2"
  :revdesc "a03f142455e8"
  :keywords '("tools")
  :authors '(("Yann Hodique" . "yann.hodique@gmail.com"))
  :maintainers '(("Yann Hodique" . "yann.hodique@gmail.com")))
