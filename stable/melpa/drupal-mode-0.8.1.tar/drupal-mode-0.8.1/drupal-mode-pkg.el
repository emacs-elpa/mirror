;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "drupal-mode" "0.8.1"
  "Advanced minor mode for Drupal development."
  '((php-mode "1.5.0"))
  :url "https://github.com/arnested/drupal-mode"
  :commit "a353f8bdf3ed98f76b9418afbbc4ef17b5552647"
  :revdesc "0.8.1-0-ga353f8bdf3ed"
  :keywords '("programming" "php" "drupal")
  :authors '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainers '(("Arne Jørgensen" . "arne@arnested.dk")))
