;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xkcd" "1.1"
  "View xkcd from Emacs."
  '((json "1.3"))
  :url "https://github.com/vibhavp/emacs-xkcd"
  :commit "2c538d41a9728939cc5e8292faa78ed50997877d"
  :revdesc "2c538d41a972"
  :keywords '("xkcd" "webcomic")
  :authors '(("Vibhav Pant" . "vibhavp@gmail.com"))
  :maintainers '(("Vibhav Pant" . "vibhavp@gmail.com")))
