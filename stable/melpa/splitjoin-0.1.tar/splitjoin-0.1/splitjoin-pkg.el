;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "splitjoin" "0.1"
  "Splitjoin."
  '((cl-lib "0.5"))
  :url "https://github.com/syohex/emacs-splitjoin"
  :commit "0eb91e7beec915065cd6c00ceaca180a64d85cda"
  :revdesc "0eb91e7beec9"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
