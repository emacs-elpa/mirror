;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sexp-diff" "0.0"
  "Diff sexps based on Levenshtein-like edit distance."
  '((emacs "25"))
  :url "https://github.com/xuchunyang/sexp-diff.el"
  :commit "b3754541a4c9cd620c34ec307e595ecbf20ea023"
  :revdesc "b3754541a4c9"
  :keywords '("lisp"))
