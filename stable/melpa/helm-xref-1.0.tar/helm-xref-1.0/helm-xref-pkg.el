;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-xref" "1.0"
  "Helm interface for xref results."
  '((emacs "25.1")
    (helm  "1.9.4"))
  :url "https://github.com/brotzeit/helm-xref"
  :commit "9764eabd50c40b009073c7ef64e3a71d0d066d0b"
  :revdesc "9764eabd50c4"
  :authors '(("Fritz Stelzer" . "brotzeitmacher@gmail.com"))
  :maintainers '(("Fritz Stelzer" . "brotzeitmacher@gmail.com")))
