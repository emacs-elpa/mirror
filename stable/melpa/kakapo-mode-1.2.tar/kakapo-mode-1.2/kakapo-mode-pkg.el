;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kakapo-mode" "1.2"
  "TABS (hard or soft) for indentation (leading whitespace), and SPACES for alignment."
  '((cl-lib "0.5"))
  :url "https://github.com/listx/kakapo-mode"
  :commit "fe3d579867f7465cd3ad04f29b4b2b3b820edc01"
  :revdesc "v1.2-0-gfe3d579867f7"
  :keywords '("indentation"))
