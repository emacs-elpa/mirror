;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-gradle" "1.0"
  "Flycheck extension for Gradle."
  '((emacs    "25.1")
    (flycheck "0.25"))
  :url "https://github.com/jojojames/flycheck-gradle"
  :commit "5c2e7d8632e4b1bea47a0508cd3a3f73b39cc4ad"
  :revdesc "5c2e7d8632e4"
  :keywords '("languages" "gradle")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
