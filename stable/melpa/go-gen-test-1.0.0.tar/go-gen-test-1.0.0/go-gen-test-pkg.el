;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-gen-test" "1.0.0"
  "Generate tests for go code."
  '((emacs "24.3")
    (s     "1.12"))
  :url "https://github.com/s-kostyaev/go-gen-test"
  :commit "b5c63dfefe468048d06e6aa9f19b0dac6d4fdf2d"
  :revdesc "b5c63dfefe46"
  :keywords '("languages")
  :authors '(("Sergey Kostyaev" . "feo.me@ya.ru"))
  :maintainers '(("Sergey Kostyaev" . "feo.me@ya.ru")))
