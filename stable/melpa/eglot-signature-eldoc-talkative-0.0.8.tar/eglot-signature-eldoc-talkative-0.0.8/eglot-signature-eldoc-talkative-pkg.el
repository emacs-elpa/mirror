;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-signature-eldoc-talkative" "0.0.8"
  "Make Eglot make ElDoc echo docs."
  '((emacs   "29.1")
    (eglot   "1.16")
    (eldoc   "1.14.0")
    (jsonrpc "1.0.23"))
  :url "https://codeberg.org/mekeor/eglot-signature-eldoc-talkative"
  :commit "44cd2d7e9947e8766a95b4fcf68a82538b06f614"
  :revdesc "44cd2d7e9947"
  :keywords '("convenience" "documentation" "eglot" "eldoc" "languages" "lsp")
  :authors '(("João Távora" . "joaotavora@gmail.com")
             ("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
