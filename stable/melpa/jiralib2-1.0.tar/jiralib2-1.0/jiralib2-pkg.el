;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jiralib2" "1.0"
  "Provide connectivity to JIRA REST services."
  '((emacs   "25")
    (request "0.3"))
  :url "https://github.com/nyyManni/ejira"
  :commit "0e10150a71690b0d082c3216d262110cc7cf16eb"
  :revdesc "0e10150a7169"
  :keywords '("calendar" "data" "org" "jira")
  :authors '(("Henrik Nyman" . "henrikjohannesnyman@gmail.com"))
  :maintainers '(("Henrik Nyman" . "henrikjohannesnyman@gmail.com")))
