;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tempus" "0.1.0"
  "Enhance Org time tracking."
  '((emacs "27.1"))
  :url "https://github.com/rul/org-tempus"
  :commit "9e9661d0c0b3b8c5951cf0b84f8e410b9aa7b6f2"
  :revdesc "9e9661d0c0b3"
  :keywords '("calendar")
  :authors '(("Raul Benencia" . "id@rbenencia.name"))
  :maintainers '(("Raul Benencia" . "id@rbenencia.name")))
