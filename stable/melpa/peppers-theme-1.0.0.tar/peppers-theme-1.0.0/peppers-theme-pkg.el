;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "peppers-theme" "1.0.0"
  "Custom dark theme based on modus framework."
  ()
  :url "https://codeberg.org/joar/peppers-theme"
  :commit "4b4d8d6daed155bdf6e1252a5adf9f726cb080a4"
  :revdesc "4b4d8d6daed1"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Joar von Arndt" . "joarxpablo@vonarndt.se"))
  :maintainers '(("Joar von Arndt" . "joarxpablo@vonarndt.se")))
