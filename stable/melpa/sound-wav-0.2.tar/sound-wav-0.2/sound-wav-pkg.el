;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sound-wav" "0.2"
  "Play wav file."
  '((deferred "0.3.1")
    (cl-lib   "0.5"))
  :url "https://github.com/syohex/emacs-sound-wav"
  :commit "2a8c8a9bd797dfbf4a0aa1c023a464b803227ff8"
  :revdesc "2a8c8a9bd797"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
