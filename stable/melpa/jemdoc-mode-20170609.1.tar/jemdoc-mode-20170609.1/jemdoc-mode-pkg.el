;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jemdoc-mode" "20170609.1"
  "Major mode for editing jemdoc files."
  '((emacs "24.3"))
  :url "https://github.com/drdv/jemdoc-mode"
  :commit "315ffa164a49a78aafc5ae5aeb32b001be2e5e6e"
  :revdesc "315ffa164a49"
  :keywords '("convenience" "usability")
  :authors '(("Dimitar Dimitrov" . "mail.mitko@gmail.com"))
  :maintainers '(("Dimitar Dimitrov" . "mail.mitko@gmail.com")))
