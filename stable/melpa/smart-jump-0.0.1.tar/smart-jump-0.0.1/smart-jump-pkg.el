;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-jump" "0.0.1"
  "Smart go to definition."
  '((emacs "25.1"))
  :url "https://github.com/jojojames/smart-jump"
  :commit "c5a22ae80f37863fa2dce40069cb39ea54182295"
  :revdesc "c5a22ae80f37"
  :keywords '("tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
