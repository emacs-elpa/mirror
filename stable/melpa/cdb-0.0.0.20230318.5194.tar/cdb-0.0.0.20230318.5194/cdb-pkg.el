;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cdb" "0.0.0.20230318.5194"
  "Constant database (cdb) reader for Emacs Lisp."
  ()
  :url "https://github.com/skk-dev/ddskk"
  :commit "3820fa6bb0d53132aafb611a643c1e41e444052b"
  :revdesc "3820fa6bb0d5"
  :keywords '("cdb")
  :authors '(("Yusuke Shinyama" . "yusukeatcs.nyu.edu")))
