;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spaceline-all-the-icons" "1.4.0"
  "A Spaceline theme using All The Icons."
  '((emacs         "24.4")
    (all-the-icons "2.6.0")
    (spaceline     "2.0.0")
    (memoize       "1.0.1"))
  :url "https://github.com/domtronn/spaceline-all-the-icons.el"
  :commit "7eafe2d7a81f8d10e03498bdcc3bec0ea50f905d"
  :revdesc "7eafe2d7a81f"
  :keywords '("convenience" "lisp" "tools")
  :authors '(("Dominic Charlesworth" . "dgc336@gmail.com"))
  :maintainers '(("Dominic Charlesworth" . "dgc336@gmail.com")))
