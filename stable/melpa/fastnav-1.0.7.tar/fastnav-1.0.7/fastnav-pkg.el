;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fastnav" "1.0.7"
  "Fast navigation and editing routines."
  ()
  :url "https://github.com/gleber/fastnav.el"
  :commit "54626e9e7cc7be5bc2bd01732e95ed2afc2312a1"
  :revdesc "54626e9e7cc7"
  :keywords '("nav" "fast" "fastnav" "navigation")
  :authors '(("Zsolt Terek" . "zsolt@google.com"))
  :maintainers '(("Zsolt Terek" . "zsolt@google.com")))
