;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jupyter-ascending" "0.1.0"
  "Edit Jupyter Notebooks from Emacs."
  '((emacs  "29.4")
    (python "0.28"))
  :url "https://github.com/Duncan-Britt/jupyter-ascending"
  :commit "b3fd0e0df19624f527fa70ae7c05d7323453b31c"
  :revdesc "b3fd0e0df196"
  :keywords '("jupyter" "notebook" "python"))
