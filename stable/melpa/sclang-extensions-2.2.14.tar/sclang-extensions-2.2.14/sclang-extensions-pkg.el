;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sclang-extensions" "2.2.14"
  "Extensions for the SuperCollider Emacs mode."
  '((auto-complete "1.4.0")
    (s             "1.3.1")
    (dash          "1.2.0")
    (emacs         "24.1"))
  :url "https://github.com/chrisbarrett/sclang-extensions"
  :commit "76d9d585a1071946c755221cc82130c072eb96b5"
  :revdesc "76d9d585a107"
  :keywords '("sclang" "supercollider" "languages" "tools")
  :authors '(("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainers '(("Chris Barrett" . "chris.d.barrett@me.com")))
