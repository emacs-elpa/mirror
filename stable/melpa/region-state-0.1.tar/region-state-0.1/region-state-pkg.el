;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "region-state" "0.1"
  "Show the number of chars/lines or rows/columns in the region."
  ()
  :url "https://github.com/xuchunyang/region-state.el"
  :commit "549c5f19e828f9dba3de611b40eba31ae96b0d1c"
  :revdesc "549c5f19e828"
  :keywords '("convenience")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
