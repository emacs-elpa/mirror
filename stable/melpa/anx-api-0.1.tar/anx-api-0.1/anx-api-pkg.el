;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anx-api" "0.1"
  "Interact with the AppNexus API from Emacs."
  ()
  :url "https://github.com/rmloveland/emacs-appnexus-api"
  :commit "c9353300eb5fc62d1e1743a800f031c1b7443bf6"
  :revdesc "c9353300eb5f"
  :keywords '("convenience" "json" "rest" "api" "appnexus"))
