;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flx-isearch" "20141313"
  "Flex matching with flx in isearch."
  ()
  :url "https://github.com/pythonnut/flx-isearch"
  :commit "3eba6cd5ca214f3e2f97bcd418df0941056c89fb"
  :revdesc "3eba6cd5ca21"
  :keywords '("convenience" "search" "flx")
  :authors '(("PythonNut" . "pythonnut@pythonnut.com"))
  :maintainers '(("PythonNut" . "pythonnut@pythonnut.com")))
