;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "requirejs" "1.1"
  "Requirejs import manipulation and source traversal."
  '((js2-mode "20150713")
    (popup    "0.5.3")
    (s        "1.9.0")
    (cl-lib   "0.5"))
  :url "https://github.com/syohex/requirejs-emacs"
  :commit "7d73453653b6b97cca59fcde8d529b5a228fbc01"
  :revdesc "7d73453653b6"
  :keywords '("javascript" "requirejs")
  :authors '(("Joe Heyming" . "joeheyming@gmail.com"))
  :maintainers '(("Joe Heyming" . "joeheyming@gmail.com")))
