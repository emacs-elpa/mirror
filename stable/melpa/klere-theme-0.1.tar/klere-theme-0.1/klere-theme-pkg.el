;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "klere-theme" "0.1"
  "A dark Emacs theme with lambent color highlights and incremental grays."
  '((emacs "24"))
  :url "https://codeberg.org/tomenzgg/emacs-klere-theme"
  :commit "104eb7200e09ed3ca5e9e96ade2449d49c32f619"
  :revdesc "104eb7200e09")
