;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eloud" "0.0.0.20190706.94"
  "A lightweight, interactive screen reader."
  '((emacs "24.4"))
  :url "https://github.com/smythp/eloud"
  :commit "b8f4af1f652268d73281de91fb333b5984970847"
  :revdesc "b8f4af1f6522"
  :keywords '("extensions")
  :authors '(("Patrick Smyth" . "patricksmyth01@gmail.com"))
  :maintainers '(("Patrick Smyth" . "patricksmyth01@gmail.com")))
