;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "automoji" "2.3"
  "Discord-like emoji completion."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/Dev380/automoji-el"
  :commit "a31ce7471ffadd05c361ddbccd95f3b3b2c067c3"
  :revdesc "a31ce7471ffa"
  :keywords '("completion" "emoji"))
