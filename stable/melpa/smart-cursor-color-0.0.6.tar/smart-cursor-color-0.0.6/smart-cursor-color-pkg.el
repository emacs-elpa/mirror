;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-cursor-color" "0.0.6"
  "Change cursor color dynamically."
  ()
  :url "https://github.com/7696122/smart-cursor-color/"
  :commit "bdc28ee789e341aa94c8a7e73b7386d07c5bd520"
  :revdesc "bdc28ee789e3"
  :keywords '("cursor" "color" "face"))
