;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-org" "1.0"
  "Helm for org headlines and keywords completion."
  '((helm  "3.3")
    (emacs "24.4"))
  :url "https://github.com/emacs-helm/helm-org"
  :commit "3a20d0eca0e95943cd9fdd40882cec65628f4a67"
  :revdesc "v1.0-0-g3a20d0eca0e9"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")))
