;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-elfeed" "1.0"
  "Helm interface for Elfeed."
  '((emacs  "29.1")
    (helm   "3.9.6")
    (elfeed "3.4.2"))
  :url "https://codeberg.org/timmli/helm-elfeed"
  :commit "09c35bc1c068cce1b09ed22b60da32509ad318a4"
  :revdesc "09c35bc1c068"
  :keywords '("matching")
  :authors '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de"))
  :maintainers '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de")))
