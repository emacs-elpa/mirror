;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "datomic-snippets" "0.1.0"
  "Yasnippets for Datomic."
  '((s    "1.4.0")
    (dash "1.2.0"))
  :url "https://github.com/magnars/datomic-snippets"
  :commit "eaeed09a78986f8709b0dab705e1845185d08065"
  :revdesc "eaeed09a7898"
  :keywords '("snippets")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
