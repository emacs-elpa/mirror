;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-enbox" "0.1.4"
  "Surround a string with box-drawing characters."
  '((string-utils    "0.3.2")
    (ucs-utils       "0.7.6")
    (persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/unicode-enbox"
  :commit "ff313f6778bb96481c0ee3291b07a7db46f21ff5"
  :revdesc "v0.1.4-0-gff313f6778bb"
  :keywords '("extensions" "interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
