;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-annex" "1.1"
  "Mode for easy editing of git-annex'd files."
  ()
  :url "https://github.com/jwiegley/git-annex-el"
  :commit "7d41775a1709b5754a7779e9f64f15d336ea5c8c"
  :revdesc "v1.1-0-g7d41775a1709"
  :keywords '("files" "data" "git" "annex")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("John Wiegley" . "jwiegley@gmail.com")))
