;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "caser" "0.1"
  "Change text casing from camelCase to dash-case to snake_case."
  '((emacs "24.1"))
  :url "https://hg.sr.ht/~zck/caser.el"
  :commit "8c7461f48ec7c187a7042e10cf7972fda40347cc"
  :revdesc "8c7461f48ec7")
