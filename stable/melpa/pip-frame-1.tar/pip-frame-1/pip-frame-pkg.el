;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pip-frame" "1"
  "Display and manage a PIP frame."
  '((emacs "25.1"))
  :url "https://git.zamazal.org/pdm/pip-frame"
  :commit "57a18de9aacca1aeb26e191336ef2533212abcf1"
  :revdesc "57a18de9aacc"
  :keywords '("frames")
  :authors '(("Milan Zamazal" . "pdm@zamazal.org"))
  :maintainers '(("Milan Zamazal" . "pdm@zamazal.org")))
