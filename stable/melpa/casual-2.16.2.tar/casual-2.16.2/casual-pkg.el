;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "2.16.2"
  "Transient user interfaces for various modes."
  '((emacs     "30.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "f2977bc97e0e80f5b6ea817f016e739e4f64b6e1"
  :revdesc "f2977bc97e0e"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
