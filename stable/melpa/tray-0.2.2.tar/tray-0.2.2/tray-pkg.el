;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tray" "0.2.2"
  "Various transient menus."
  '((emacs     "30.1")
    (compat    "31.1")
    (transient "0.13"))
  :url "https://github.com/tarsius/tray"
  :commit "e2a79114029d369f02dd9da55800b4b6e995adea"
  :revdesc "v0.2.2-0-ge2a79114029d"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.tray@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.tray@jonas.bernoulli.dev")))
