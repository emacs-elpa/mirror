;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chapel-mode" "0.0.1"
  "A major mode for the Chapel programming language."
  '((emacs "25.1")
    (dash  "2.17.0")
    (hydra "0.15.0"))
  :url "https://github.com/damon-kwok/chapel-mode"
  :commit "583436b40aad42587a5d423e477eec4e0767a50b"
  :revdesc "583436b40aad"
  :keywords '("languages" "programming")
  :authors '(("Damon Kwok" . "damon-kwok@outlook.com"))
  :maintainers '(("Damon Kwok" . "damon-kwok@outlook.com")))
