;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elscreen-buffer-group" "1.0.1"
  "Elscreen buffer group."
  '((emacs    "24.3")
    (elscreen "0")
    (cl-lib   "0.5"))
  :url "https://github.com/jeffgran/elscreen-buffer-group"
  :commit "1a10af95355a8db004b49d12a0ae5c2238404e67"
  :revdesc "1a10af95355a"
  :keywords '("buffer")
  :authors '(("Jeff Gran" . "jeff@jeffgran.com"))
  :maintainers '(("Jeff Gran" . "jeff@jeffgran.com")))
