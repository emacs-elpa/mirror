;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotation" "2.8.0.2"
  "Functions for annotating text with faces and help bubbles."
  ()
  :url "https://github.com/agda/agda"
  :commit "cccf42fa88eae25ccbe2623f489021d2075f6f73"
  :revdesc "v2.8.0.2-0-gcccf42fa88ea")
