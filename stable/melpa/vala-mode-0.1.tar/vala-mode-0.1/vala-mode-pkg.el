;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vala-mode" "0.1"
  "Vala mode derived mode."
  ()
  :url "https://github.com/rrthomas/vala-mode"
  :commit "68220403c5abada41b8f9eccc7fc154eafd60162"
  :revdesc "68220403c5ab"
  :keywords '("vala" "languages" "oop")
  :maintainers '(("tienne BERSAC" . "bersace03@laposte.net")))
