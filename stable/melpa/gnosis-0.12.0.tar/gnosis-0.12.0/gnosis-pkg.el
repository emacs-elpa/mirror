;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "0.12.0"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "847727f08329bbcea9e22bfc53578f9d3a13697c"
  :revdesc "847727f08329"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
