;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "contextual-menubar" "1.0.0"
  "Display the menubar only on a graphical display."
  ()
  :url "https://github.com/aaronjensen/contextual-menubar"
  :commit "cc2e7c952b59401188b81d84be81dead9d0da3db"
  :revdesc "1.0.0-0-gcc2e7c952b59"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
