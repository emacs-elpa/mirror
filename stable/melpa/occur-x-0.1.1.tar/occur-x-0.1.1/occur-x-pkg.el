;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occur-x" "0.1.1"
  "Extra functionality for occur."
  ()
  :url "https://github.com/juan-leon/occur-x"
  :commit "6cb44a5026c17bf77cef1e5198054489e77f98c3"
  :revdesc "6cb44a5026c1"
  :keywords '("occur" "search" "convenience")
  :authors '(("Juan-Leon Lahoz" . "juanleon1@gmail.com"))
  :maintainers '(("Juan-Leon Lahoz" . "juanleon1@gmail.com")))
