;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyramid" "0.1"
  "Minor mode for working with pyramid projects."
  '((emacs    "25.2")
    (pythonic "0.1.1")
    (tablist  "0.70"))
  :url "https://github.com/dakra/pyramid.el"
  :commit "59d7ec03dcb1968160ac1dfe3c979cc83fe0fe4b"
  :revdesc "59d7ec03dcb1"
  :keywords '("python" "pyramid" "pylons" "convenience" "tools" "processes")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
