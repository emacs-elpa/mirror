;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu2tex" "1.2"
  "[No description available]."
  ()
  :url "https://github.com/cdominik/mu2tex"
  :commit "87d13b479d8ffb4078cccaa2f6213bb82733246b"
  :revdesc "87d13b479d8f"
  :keywords '("tex")
  :authors '(("Carsten Dominik" . "dominik@.uva.nl"))
  :maintainers '(("Carsten Dominik" . "dominik@.uva.nl")))
