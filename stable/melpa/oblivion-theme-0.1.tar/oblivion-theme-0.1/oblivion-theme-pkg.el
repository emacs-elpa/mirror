;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oblivion-theme" "0.1"
  "A port of GEdit oblivion theme."
  '((emacs "24.1"))
  :url "https://gitlab.com/ideasman42/emacs-oblivion-theme"
  :commit "3a1d67637ea4a6099a62de45842b8c5e4440ede4"
  :revdesc "3a1d67637ea4"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
