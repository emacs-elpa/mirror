;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebib-sidecar" "1.9.2"
  "Sidecar to show formatted reference of current Ebib Entry."
  '((emacs                      "28.1")
    (citeproc                   "0.9.4")
    (universal-sidecar          "1.5.1")
    (universal-sidecar-citeproc "1.0.0")
    (ebib                       "2.39"))
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar"
  :commit "3b6bd928f7adb840e62a63dd5bf1236ece912b13"
  :revdesc "3b6bd928f7ad"
  :keywords '("bib")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
