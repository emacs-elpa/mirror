;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "twig-mode" "0.1"
  "A major mode for twig."
  ()
  :url "https://github.com/moljac024/twig-mode"
  :commit "51bcd41666a234119a855b9fd348d3dae7832de1"
  :revdesc "51bcd41666a2")
