;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-pop" "2.2.0"
  "Generate, popup (& optionally backup) scratch buffer(s)."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "52863c9c7bed1210fdebdfc1e962e9af3dc4cbc4"
  :revdesc "52863c9c7bed")
