;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojars" "1.2.0"
  "Clojars.org search interface."
  '((request-deferred "0.2.0"))
  :url "https://github.com/joshuamiller/clojars.el"
  :commit "c78e4d5ddacda064c253e2b38d1c35188aa1ad71"
  :revdesc "c78e4d5ddacd"
  :keywords '("docs" "help" "tools")
  :authors '(("Joshua Miller" . "josh@joshmiller.io"))
  :maintainers '(("Joshua Miller" . "josh@joshmiller.io")))
