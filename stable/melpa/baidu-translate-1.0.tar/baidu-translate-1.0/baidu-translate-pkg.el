;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "baidu-translate" "1.0"
  "An plugin using baidu-translate-api."
  ()
  :url "https://github.com/liShiZhensPi/baidu-translate"
  :commit "e979a06a289e0f31163cd43d4bdf24abeb983306"
  :revdesc "e979a06a289e"
  :keywords '("docs")
  :authors '((nil . "LiShizhengsu4017@gmail.com"))
  :maintainers '((nil . "LiShizhengsu4017@gmail.com")))
