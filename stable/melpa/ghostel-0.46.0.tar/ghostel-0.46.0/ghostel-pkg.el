;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.46.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "cba5fa4c0d1913eef77bcea5bab2555536adf53f"
  :revdesc "cba5fa4c0d19"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
