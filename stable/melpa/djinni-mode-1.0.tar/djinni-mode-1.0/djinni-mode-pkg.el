;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "djinni-mode" "1.0"
  "Major-mode for editing Djinni files."
  '((emacs "24.4"))
  :url "https://github.com/danielmartin/djinni-mode"
  :commit "f1e3cc7dc91019e390e0ade984ee1029f4b15000"
  :revdesc "f1e3cc7dc910"
  :keywords '("djinni"))
