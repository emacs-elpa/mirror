;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pixie-mode" "0.1.0"
  "Major mode for Pixie-lang."
  '((clojure-mode "3.0.1"))
  :url "https://github.com/johnwalker/pixie-mode"
  :commit "e3d48aa083993aa70a5b8073a51739e2d11ad52f"
  :revdesc "e3d48aa08399"
  :authors '(("John Walker" . "john.lou.walker@gmail.com"))
  :maintainers '(("John Walker" . "john.lou.walker@gmail.com")))
