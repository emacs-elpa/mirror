;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yasnippet-capf" "0.0.3"
  "Yasnippet Completion At Point Function."
  '((emacs     "25.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/elken/yasnippet-capf"
  :commit "84bfa7a946a94ed227284a04a90e37976de32c3f"
  :revdesc "84bfa7a946a9"
  :authors '(("Ellis Kenyő" . "me@elken.dev"))
  :maintainers '(("Ellis Kenyő" . "me@elken.dev")))
