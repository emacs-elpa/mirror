;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-stan" "10.2.0"
  "Add Stan support for Flycheck."
  '((emacs     "25.1")
    (flycheck  "0.16.0")
    (stan-mode "10.1.0"))
  :url "https://github.com/stan-dev/stan-mode/tree/master/flycheck-stan"
  :commit "2dd330604563d143031fc8ffd516266217aa1f9b"
  :revdesc "2dd330604563"
  :keywords '("c" "languages")
  :authors '(("Jeffrey Arnold" . "jeffrey.arnold@gmail.com")
             ("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu"))
  :maintainers '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu")))
