;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dream-theme" "1.0"
  "Maximalist Nordic/Zenburn-inspired color theme."
  '((emacs "26.1"))
  :url "https://github.com/djcb/dream-theme"
  :commit "62caa37d5f1ddb1187ee0b9e7dd9833679cc5eb5"
  :revdesc "62caa37d5f1d"
  :authors '(("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl"))
  :maintainers '(("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl")))
