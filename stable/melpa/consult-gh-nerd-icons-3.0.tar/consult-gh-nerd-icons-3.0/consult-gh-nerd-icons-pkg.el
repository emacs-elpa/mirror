;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh-nerd-icons" "3.0"
  "Nerd icons Integration for consult-gh."
  '((emacs      "29.4")
    (nerd-icons "0.1.0")
    (consult-gh "3.0"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "2b625a0331c9a92c67fef8ea2e694b28d5006421"
  :revdesc "2b625a0331c9"
  :keywords '("matching" "git" "repositories" "completion"))
