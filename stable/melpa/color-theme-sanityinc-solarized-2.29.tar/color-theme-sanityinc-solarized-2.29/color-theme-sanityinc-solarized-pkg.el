;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-sanityinc-solarized" "2.29"
  "A version of Ethan Schoonover's Solarized themes."
  ()
  :url "https://github.com/purcell/color-theme-sanityinc-solarized"
  :commit "554e941131d009c0a5d7129ed96796182b4cc590"
  :revdesc "554e941131d0"
  :keywords '("themes")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
