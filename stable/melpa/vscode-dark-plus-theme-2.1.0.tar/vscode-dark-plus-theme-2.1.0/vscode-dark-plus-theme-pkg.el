;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vscode-dark-plus-theme" "2.1.0"
  "Default Visual Studio Code Dark+ theme."
  ()
  :url "https://github.com/ianpan870102/vscode-dark-plus-emacs-theme"
  :commit "37f16729ee196dbfc533b02adea3d2129bdd8585"
  :revdesc "37f16729ee19")
