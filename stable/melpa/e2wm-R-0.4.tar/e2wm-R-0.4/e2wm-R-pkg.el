;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2wm-R" "0.4"
  "Some e2wm plugin and perspective for GNU R."
  '((e2wm "1.2"))
  :url "https://github.com/emacsattic/e2wm-R"
  :commit "fe17906bf48324032a1beaec9af32b9b49ea9125"
  :revdesc "0.4-0-gfe17906bf483"
  :keywords '("window manager" "convenience" "e2wm"))
