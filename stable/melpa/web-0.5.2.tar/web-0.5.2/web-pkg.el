;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "web" "0.5.2"
  "Useful HTTP client."
  '((dash "2.9.0")
    (s    "1.5.0"))
  :url "https://github.com/nicferrier/emacs-web"
  :commit "aaa2d0754c4f83cf7e7d6e1a6189c70bc4a78cfc"
  :revdesc "aaa2d0754c4f"
  :keywords '("lisp" "http" "hypermedia")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
