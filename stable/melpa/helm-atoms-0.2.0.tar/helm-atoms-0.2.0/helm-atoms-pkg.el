;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-atoms" "0.2.0"
  "Reverse variable lookup using Helm."
  '((emacs "25.1")
    (helm  "2.0"))
  :url "https://github.com/dantecatalfamo/helm-atoms"
  :commit "ccada39339b296f70fd28769c07796fb84d17e28"
  :revdesc "ccada39339b2")
