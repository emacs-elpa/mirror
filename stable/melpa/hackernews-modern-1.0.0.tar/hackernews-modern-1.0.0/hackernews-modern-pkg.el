;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hackernews-modern" "1.0.0"
  "Hacker News client with modern widget UI."
  '((emacs              "28.1")
    (visual-fill-column "2.2"))
  :url "https://git.andros.dev/andros/hackernews-modern-el"
  :commit "94a20b9ac5cef2e98be059a28de59d8fe18bdd91"
  :revdesc "94a20b9ac5ce"
  :keywords '("comm" "hypermedia" "news")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
