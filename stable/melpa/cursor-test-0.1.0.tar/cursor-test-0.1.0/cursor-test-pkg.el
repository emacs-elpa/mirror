;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cursor-test" "0.1.0"
  "Testing library for cursor position in emacs."
  '((cl  "0")
    (ert "0"))
  :url "https://github.com/ainame/cursor-test.el"
  :commit "143e481537375024cb3bcae82b1863e4de22598c"
  :revdesc "143e48153737")
