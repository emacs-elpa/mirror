;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jq-ts-mode" "1.0.0"
  "Tree-sitter support for jq buffers."
  '((emacs "29.1"))
  :url "https://github.com/nverno/jq-ts-mode"
  :commit "a965ea23e8169aebfc7bc855038993a5fb435e26"
  :revdesc "a965ea23e816"
  :keywords '("jq" "languages" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
