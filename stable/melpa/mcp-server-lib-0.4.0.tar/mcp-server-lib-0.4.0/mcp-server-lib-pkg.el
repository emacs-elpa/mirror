;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp-server-lib" "0.4.0"
  "Model Context Protocol server library."
  '((emacs "27.1"))
  :url "https://github.com/laurynas-biveinis/mcp-server-lib.el"
  :commit "f7c34f5ab6ae4620cfa88a25ef9cbd47313322e4"
  :revdesc "0.4.0-0-gf7c34f5ab6ae"
  :keywords '("comm" "tools")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
