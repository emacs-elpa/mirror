;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-call-tree" "20151116.1603"
  "Analyze source code based on font-lock text-properties."
  ()
  :url "http://www.emacswiki.org/emacs/download/simple-call-tree.el"
  :commit "5314c3c99f8ed021afc0f1693792b4ae9727ca3f"
  :revdesc "5314c3c99f8e"
  :keywords '("programming")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
