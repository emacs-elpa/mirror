;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rvm" "1.4.2"
  "Emacs integration for rvm."
  ()
  :url "http://www.emacswiki.org/emacs/RvmEl"
  :commit "16617c1fc7c0513e514cd658a93b5e5be2ff618f"
  :revdesc "16617c1fc7c0"
  :keywords '("ruby" "rvm")
  :authors '(("Yves Senn" . "yves.senn@gmx.ch"))
  :maintainers '(("Yves Senn" . "yves.senn@gmx.ch")))
