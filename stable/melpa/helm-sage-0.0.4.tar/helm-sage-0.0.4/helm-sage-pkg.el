;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-sage" "0.0.4"
  "A helm extension for sage-shell-mode."
  '((cl-lib          "0.5")
    (helm            "1.5.6")
    (sage-shell-mode "0.0.8"))
  :url "https://github.com/stakemori/helm-sage"
  :commit "b42b4ba5fd1b17c4b54c30376a053281686beeb8"
  :revdesc "b42b4ba5fd1b"
  :keywords '("sage" "math" "helm")
  :authors '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainers '(("Sho Takemori" . "stakemorii@gmail.com")))
