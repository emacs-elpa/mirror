;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fit-text-scale" "1.1.4"
  "Fit text by scaling."
  '((emacs "25.1"))
  :url "https://gitlab.com/marcowahl/fit-text-scale"
  :commit "ba63f0591c3be1644ee7ee972430c74b5d346579"
  :revdesc "ba63f0591c3b"
  :keywords '("convenience")
  :authors '(("Marco Wahl" . "marcowahlsoft@gmail.com"))
  :maintainers '(("Marco Wahl" . "marcowahlsoft@gmail.com")))
