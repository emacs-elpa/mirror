;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lockfile-mode" "0.1.0"
  "Major mode for .lock files."
  '((emacs "25.1"))
  :url "https://github.com/preetpalS/emacs-lockfile-mode"
  :commit "b0631b8e2c823467dd9cf49abacee151e95270b3"
  :revdesc "b0631b8e2c82")
