;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "c2-mode" "0.1.0"
  "Major mode for C2 programming language."
  '((emacs "24.3"))
  :url "https://github.com/easimonenko/c2-mode"
  :commit "8ae4d35bde9887d8bd8ccb8bdf3c67d41728219f"
  :revdesc "8ae4d35bde98"
  :keywords '("languages" "c2")
  :authors '(("Evgeny Simonenko" . "easimonenko@gmail.com"))
  :maintainers '(("Evgeny Simonenko" . "easimonenko@gmail.com")))
