;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-eask" "0.1.0"
  "Eask support in Flycheck."
  '((emacs    "26.1")
    (flycheck "0.14"))
  :url "https://github.com/emacs-eask/flycheck-eask"
  :commit "ca1de9d55c99c91971857f0c37abfb3da90dd012"
  :revdesc "ca1de9d55c99"
  :keywords '("lisp" "eask")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
