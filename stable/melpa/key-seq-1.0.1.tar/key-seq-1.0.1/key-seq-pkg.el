;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-seq" "1.0.1"
  "Map pairs of sequentially pressed keys to commands."
  '((key-chord "0.6"))
  :url "https://github.com/vlevit/key-seq.el"
  :commit "e29b083a6427d061638749194fc249ef69ad2cc0"
  :revdesc "e29b083a6427"
  :keywords '("convenience" "keyboard" "keybindings")
  :authors '(("Vyacheslav Levit" . "dev@vlevit.org"))
  :maintainers '(("Vyacheslav Levit" . "dev@vlevit.org")))
