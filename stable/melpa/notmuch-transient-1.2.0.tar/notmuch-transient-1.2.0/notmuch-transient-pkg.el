;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-transient" "1.2.0"
  "Command dispatchers for Notmuch."
  '((emacs     "29.1")
    (compat    "30.1")
    (notmuch   "0.39")
    (transient "0.12"))
  :url "https://github.com/tarsius/notmuch-transient"
  :commit "582ebaab67d3c59ec002ae23e0072e4ac9a2f13a"
  :revdesc "v1.2.0-0-g582ebaab67d3"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev")))
