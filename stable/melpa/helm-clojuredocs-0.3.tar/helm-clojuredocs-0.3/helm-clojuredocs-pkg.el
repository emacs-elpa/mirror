;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-clojuredocs" "0.3"
  "Search for help in clojuredocs.org."
  '((edn  "1.1.2")
    (helm "1.5.7"))
  :url "https://github.com/mbuczko/helm-clojuredocs"
  :commit "5a7f0f2cb401be0b09e73262a1c18265ab9a3cea"
  :revdesc "5a7f0f2cb401"
  :keywords '("helm" "clojure")
  :authors '(("Michal Buczko" . "michal.buczko@gmail.com"))
  :maintainers '(("Michal Buczko" . "michal.buczko@gmail.com")))
