;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "0.1.0"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.1")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "ff277f2de37f08682f3569341de8a37658dc3667"
  :revdesc "ff277f2de37f"
  :keywords '("tools" "processes"))
