;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-review" "0.0.7"
  "Perform code review from Github, Gitlab, and Bitbucket Cloud."
  '((emacs         "25.1")
    (closql        "1.2.0")
    (magit         "3.0.0")
    (a             "1.0.0")
    (ghub          "3.5.1")
    (uuidgen       "1.2")
    (deferred      "0.5.1")
    (markdown-mode "2.4")
    (forge         "0.3.0")
    (emojify       "1.2"))
  :url "https://github.com/wandersoncferreira/code-review"
  :commit "9cf84cd867d27433e0c8097f0d33cb3ade64f5ca"
  :revdesc "9cf84cd867d2"
  :keywords '("git" "tools" "vc")
  :authors '(("Wanderson Ferreira" . "https://github.com/wandersoncferreira"))
  :maintainers '(("Wanderson Ferreira" . "wand@hey.com")))
