;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-org" "1.0.3"
  "Evil keybindings for org-mode."
  '((emacs "24.4")
    (evil  "1.0"))
  :url "https://github.com/Somelauw/evil-org-mode.git"
  :commit "a496778cb37b05e0ba44de7700391cfacb02709b"
  :revdesc "a496778cb37b"
  :keywords '("evil" "vim-emulation" "org-mode" "key-bindings" "presets"))
