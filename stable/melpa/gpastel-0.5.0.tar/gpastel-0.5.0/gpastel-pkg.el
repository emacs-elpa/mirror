;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpastel" "0.5.0"
  "Integrates GPaste with the kill-ring."
  '((emacs "25.1"))
  :url "https://gitlab.petton.fr/DamienCassou/desktop-environment"
  :commit "8a5522b274f79d55d7c9a0b2aaf062526f9253c7"
  :revdesc "8a5522b274f7"
  :keywords '("tools")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
