;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-ack" "1.0"
  "A front-end for ack."
  ()
  :url "http://nschum.de/src/emacs/full-ack/"
  :commit "0aef4be1686535f83217cafb1524818071bd8325"
  :revdesc "1.0-0-g0aef4be16865"
  :keywords '("tools" "matching")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
