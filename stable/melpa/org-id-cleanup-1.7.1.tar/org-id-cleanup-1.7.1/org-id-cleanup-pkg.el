;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-id-cleanup" "1.7.1"
  "Interactively find, present and maybe clean up unused IDs of org-id."
  '((org   "9.3")
    (dash  "2.12")
    (emacs "26.3"))
  :url "https://github.com/marcIhm/org-id-cleanup"
  :commit "73d3f750d236dd486b8bcc07c88bfda9ce5b384e"
  :revdesc "1.7.1-0-g73d3f750d236"
  :authors '(("Marc Ihm" . "marc@ihm.name"))
  :maintainers '(("Marc Ihm" . "marc@ihm.name")))
