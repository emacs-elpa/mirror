;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.4.2"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.5.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "47e8841304a4b9d91cd9c93f48c2cf954fd7e367"
  :revdesc "v3.4.2-0-g47e8841304a4"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
