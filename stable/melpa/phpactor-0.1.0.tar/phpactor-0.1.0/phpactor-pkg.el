;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpactor" "0.1.0"
  "Interface to Phpactor."
  '((emacs  "24.3")
    (cl-lib "0.5")
    (f      "0.17"))
  :url "https://github.com/emacs-php/phpactor.el"
  :commit "61e4eab638168b7034eef0f11e35a89223fa7687"
  :revdesc "61e4eab63816"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
