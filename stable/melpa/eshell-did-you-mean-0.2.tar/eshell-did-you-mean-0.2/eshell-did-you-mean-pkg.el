;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-did-you-mean" "0.2"
  "Command not found (\"did you mean…\" feature) in Eshell."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/xuchunyang/eshell-did-you-mean"
  :commit "80cd8c4b186a2fb29621cf634bcf2bcd914f1e3d"
  :revdesc "80cd8c4b186a"
  :keywords '("eshell")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
