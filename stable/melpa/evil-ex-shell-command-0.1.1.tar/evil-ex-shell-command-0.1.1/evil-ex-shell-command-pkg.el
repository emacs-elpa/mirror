;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ex-shell-command" "0.1.1"
  "Invoke shell-command right from evil-ex."
  '((emacs "24.4")
    (evil  "1.1.0"))
  :url "https://github.com/yqrashawn/evil-ex-shell-command"
  :commit "a6ca6d27c07f6a0807abfb5b8f8865f1d17f54aa"
  :revdesc "a6ca6d27c07f"
  :keywords '("tools" "shell-command" "evil")
  :authors '(("Rashawn Zhang" . "namy.19@gmail.com"))
  :maintainers '(("Rashawn Zhang" . "namy.19@gmail.com")))
