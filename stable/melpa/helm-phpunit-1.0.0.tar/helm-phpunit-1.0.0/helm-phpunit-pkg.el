;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-phpunit" "1.0.0"
  "Helm integration for phpunit.el."
  '((helm    "0.0.0")
    (phpunit "0.7.0"))
  :url "https://github.com/eric-hansen/phpunit-helm"
  :commit "990704aed281118d32a92e4e7d198ea51d4dfab6"
  :revdesc "990704aed281"
  :keywords '("phpunit" "helm" "php")
  :authors '(("Eric Hansen" . "hansen.c.eric@gmail.com"))
  :maintainers '(("Eric Hansen" . "hansen.c.eric@gmail.com")))
