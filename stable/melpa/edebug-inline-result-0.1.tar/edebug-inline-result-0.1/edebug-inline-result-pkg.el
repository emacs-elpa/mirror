;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edebug-inline-result" "0.1"
  "Show Edebug result inline."
  '((emacs  "25")
    (cl-lib "0.5"))
  :url "https://www.github.com/stardiviner/edebug-inline-result"
  :commit "26eb2c37f596be4b03ee5bf4e482d12254c0aeec"
  :revdesc "26eb2c37f596"
  :keywords '("extensions" "lisp" "tools")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
