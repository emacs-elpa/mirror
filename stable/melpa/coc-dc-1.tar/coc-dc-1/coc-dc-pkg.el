;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coc-dc" "1"
  "A Clash of Clans damage calculator."
  '((emacs "27.2")
    (hydra "0.14.0"))
  :url "https://github.com/S0mbr3/coc-damage-calculator"
  :commit "3308e537932a42c63c372ea4407bf525d5eb4f8c"
  :revdesc "3308e537932a"
  :keywords '("games")
  :authors '(("S0mbr3" . "0xf2f@proton.me"))
  :maintainers '(("S0mbr3" . "0xf2f@proton.me")))
