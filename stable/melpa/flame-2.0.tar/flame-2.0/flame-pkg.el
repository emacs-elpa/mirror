;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flame" "2.0"
  "Automatic generation of flamage, as if we needed more."
  ()
  :url "https://github.com/mschuldt/flame"
  :commit "4cebdac0c5f9eacd584ec42d57824b26b2091d28"
  :revdesc "4cebdac0c5f9"
  :keywords '("games")
  :authors '(("Ian G. Batten" . "batten@uk.ac.bham.multics")
             ("Noah Friedman" . "friedman@splode.com"))
  :maintainers '(("Noah Friedman" . "friedman@splode.com")))
