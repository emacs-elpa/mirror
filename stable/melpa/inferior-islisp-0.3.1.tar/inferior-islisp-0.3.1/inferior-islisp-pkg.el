;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inferior-islisp" "0.3.1"
  "Run inferior ISLisp processes."
  '((emacs       "26.3")
    (islisp-mode "0.2"))
  :url "https://gitlab.com/sasanidas/islisp-mode"
  :commit "18258f7134cfd8e0bd12538351b3cd23ae44cec1"
  :revdesc "18258f7134cf"
  :keywords '("islisp" "lisp" "programming")
  :maintainers '(("Fermin Munoz" . "fmfs@posteo.net")))
