;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "structurizr" "1.0"
  "Major mode for Structurizr DSL."
  '((emacs "29.1"))
  :url "https://github.com/papadakis-k/structurizr.el"
  :commit "ba6484d48b6c8177cdaf3d8b51766b5a9b1f91eb"
  :revdesc "ba6484d48b6c"
  :keywords '("languages"))
