;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ansi" "0.4.1"
  "Turn string into ansi strings."
  '((s    "1.6.1")
    (dash "1.5.0"))
  :url "https://github.com/rejeep/ansi"
  :commit "a042c5954453bab9a74177e2b78ad17a824caebc"
  :revdesc "a042c5954453"
  :keywords '("color" "ansi")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
