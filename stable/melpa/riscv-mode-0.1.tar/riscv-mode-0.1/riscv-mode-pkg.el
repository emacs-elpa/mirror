;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "riscv-mode" "0.1"
  "Major-mode for RISC-V assembly."
  '((emacs "24.4"))
  :url "https://github.com/AdamNiederer/riscv-mode"
  :commit "46537e92ea821b7b2292282e184d80a6dd7c0155"
  :revdesc "46537e92ea82"
  :keywords '("riscv" "assembly")
  :authors '(("Adam Niederer" . "https://github.com/AdamNiederer")))
