;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eno" "1.1"
  "Goto/copy/cut any word/symbol/line in view, similar to ace-jump/easymotion."
  '((dash          "2.9.0")
    (edit-at-point "1.0"))
  :url "https://github.com/enoson/eno.el"
  :commit "20228ca8e4393e75ee94617606100618ab6b8324"
  :revdesc "20228ca8e439"
  :authors '((nil . "e.enoson@gmail.com"))
  :maintainers '((nil . "e.enoson@gmail.com")))
