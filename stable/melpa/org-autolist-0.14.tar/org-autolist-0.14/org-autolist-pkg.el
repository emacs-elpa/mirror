;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-autolist" "0.14"
  "Improved list management in org-mode."
  ()
  :url "https://github.com/calvinwyoung/org-autolist"
  :commit "c82d1e83e982b5f0c106b8800e5b0cfd5f73fdc1"
  :revdesc "c82d1e83e982"
  :keywords '("lists" "checklists" "org-mode"))
