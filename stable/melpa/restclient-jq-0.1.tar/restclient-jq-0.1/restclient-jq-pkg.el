;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restclient-jq" "0.1"
  "Support for setting restclient vars from jq expressions."
  '((restclient "20200502.831")
    (jq-mode    "0.4.1")
    (emacs      "24.4"))
  :url "https://github.com/pashky/restclient.el"
  :commit "537ac592d662c5a4c5d622a91edb402a66eef2fd"
  :revdesc "537ac592d662"
  :keywords '("tools" "comm" "http" "jq")
  :authors '(("Cameron Dorrat" . "cdorrat@gmail.com"))
  :maintainers '(("Cameron Dorrat" . "cdorrat@gmail.com")))
