;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sourcepawn-mode" "0.2"
  "SourcePawn major mode for emacs."
  ()
  :url "http://gammalevel.com/teamfortress2/sourcepawn-mode"
  :commit "00a2170d267b5d3db71c3c00502871c138c1d5dd"
  :revdesc "v0.2-0-g00a2170d267b"
  :authors '(("Aaron Griffith" . "aargri@gmail.com"))
  :maintainers '(("Aaron Griffith" . "aargri@gmail.com")))
