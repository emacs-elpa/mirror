;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-re-reveal-ref" "1.0.0"
  "Citations and bibliography for org-re-reveal."
  '((emacs         "25.1")
    (org-ref       "1.1.1")
    (org-re-reveal "0.9.3"))
  :url "https://gitlab.com/oer/org-re-reveal-ref"
  :commit "abcd622e4edaa5e4480bcd1e7e4953f67c90e036"
  :revdesc "abcd622e4eda"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "bibliography"))
