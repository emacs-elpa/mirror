;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exercism" "0.0.0"
  "(Unofficial) Emacs integration for https://exercism.org."
  '((emacs       "25")
    (dash        "2.19.1")
    (a           "1.0.0")
    (request     "0.3.2")
    (async       "1.9.6")
    (async-await "1.1")
    (persist     "0.5")
    (transient   "0.3.7"))
  :url "https://github.com/anonimitoraf/exercism.el"
  :commit "ae165a7414c8453655238b30ca87de2d79c6838f"
  :revdesc "ae165a7414c8"
  :keywords '("exercism" "convenience")
  :authors '(("Rafael Nicdao" . "https://github.com/anonimito"))
  :maintainers '(("Rafael Nicdao" . "nicdaoraf@gmail.com")))
