;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-vertical-mode" "0.1.6"
  "Makes ido-mode display vertically."
  ()
  :url "https://github.com/gempesaw/ido-vertical-mode.el"
  :commit "c3e0514405ba5c15b5527e7f8e2d42dff259788f"
  :revdesc "c3e0514405ba"
  :keywords '("convenience")
  :maintainers '(("Daniel Gempesaw" . "gempesaw@gmail.com")))
