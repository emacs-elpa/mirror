;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xwiki-mode" "0.0.1"
  "Major mode for xwiki-formatted text."
  '((emacs "27.1"))
  :url "https://github.com/ackerleytng/xwiki-mode"
  :commit "2200e85fc11b5f8fd09f4ed1b7cfe61df7fe8c47"
  :revdesc "2200e85fc11b"
  :keywords '("xwiki")
  :authors '(("Ackerley Tng" . "ackerleytng@gmail.com"))
  :maintainers '(("Ackerley Tng" . "ackerleytng@gmail.com")))
