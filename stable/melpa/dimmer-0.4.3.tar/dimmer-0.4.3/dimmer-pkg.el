;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dimmer" "0.4.3"
  "Visually highlight the selected buffer."
  '((emacs "25.1"))
  :url "https://github.com/gonewest818/dimmer.el"
  :commit "a5b697580e5aed6168b571ae3d925753428284f8"
  :revdesc "a5b697580e5a"
  :keywords '("faces" "editing"))
