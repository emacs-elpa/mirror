;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moe-theme" "1.0.1"
  "[No description available]."
  ()
  :url "https://github.com/kuanyui/moe-theme.el"
  :commit "01d00a8d75b19f641b639ba23793cdd507c61f05"
  :revdesc "01d00a8d75b1"
  :keywords '("themes")
  :authors '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainers '(("kuanyui" . "azazabc123@gmail.com")))
