;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "airline-themes" "1.8"
  "Vim-airline themes for emacs powerline."
  '((powerline "2.3"))
  :url "https://github.com/AnthonyDiGirolamo/airline-themes"
  :commit "5ea031bcbdf665afea7e47e519a49e2c33978833"
  :revdesc "5ea031bcbdf6"
  :keywords '("evil" "mode-line" "powerline" "airline" "themes")
  :authors '(("Anthony DiGirolamo" . "anthony.digirolamo@gmail.com"))
  :maintainers '(("Anthony DiGirolamo" . "anthony.digirolamo@gmail.com")))
