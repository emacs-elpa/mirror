;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grails-mode" "2.1"
  "Minor-mode that adds some Grails project management to a grails project."
  ()
  :url "http://blog.wolfman.com"
  :commit "99eaf70720e4a6337fbd5acb68ae45cc1779bdc4"
  :revdesc "99eaf70720e4"
  :keywords '("languages")
  :authors '(("Jim Morris" . "morris@wolfman.com"))
  :maintainers '(("Russel Winder" . "russel@winder.org.uk")))
