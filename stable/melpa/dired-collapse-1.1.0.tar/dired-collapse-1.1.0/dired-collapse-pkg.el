;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-collapse" "1.1.0"
  "Collapse unique nested paths in dired listing."
  '((dash "2.10.0")
    (f    "0.19.0"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "2aeee2c2087c15062a14ed496831bd563a82b8c7"
  :revdesc "2aeee2c2087c"
  :keywords '("files")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
