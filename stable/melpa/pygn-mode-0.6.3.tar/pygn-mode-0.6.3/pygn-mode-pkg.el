;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pygn-mode" "0.6.3"
  "Major-mode for chess PGN files, powered by Python."
  '((emacs             "26.1")
    (tree-sitter       "0.15.2")
    (tree-sitter-langs "0.12.242")
    (uci-mode          "0.5.4")
    (nav-flash         "1.0.0")
    (ivy               "0.10.0"))
  :url "https://github.com/dwcoates/pygn-mode"
  :commit "3f1ce4efd1c34b9fc347c848eb4426bfcc851118"
  :revdesc "v0.6.3-0-g3f1ce4efd1c3"
  :keywords '("data" "games" "chess"))
