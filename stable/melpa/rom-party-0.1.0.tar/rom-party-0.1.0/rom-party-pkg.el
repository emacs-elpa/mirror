;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rom-party" "0.1.0"
  "Bomb Party... in Emacs."
  '((emacs  "28")
    (dash   "2.17.0")
    (f      "0.2.0")
    (s      "1.12.0")
    (ht     "2.3")
    (extmap "1.3")
    (compat "29.1.4.4")
    (async  "1.9.7"))
  :url "https://github.com/LaurenceWarne/rom-party.el"
  :commit "ba72981a8e6a07896da45e5ac31ee943f881fc7f"
  :revdesc "0.1.0-0-gba72981a8e6a")
