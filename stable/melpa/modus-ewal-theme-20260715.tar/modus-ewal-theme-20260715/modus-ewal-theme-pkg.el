;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-ewal-theme" "20260715"
  "Modus theme that uses pywal colors powered by ewal."
  '((emacs        "25.1")
    (modus-themes "5.2.0")
    (ewal         "0.2.1"))
  :url "https://github.com/deadendpl/modus-ewal-theme"
  :commit "75f4cbe730d16407f0251d3c45297bb83d31f6db"
  :revdesc "75f4cbe730d1"
  :keywords '("faces" "theme")
  :authors '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me"))
  :maintainers '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me")))
