;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg-marginalia" "1.1.5"
  "Show Epkg information in completion annotations."
  '((emacs      "28.1")
    (compat     "31.0")
    (cond-let   "1.1")
    (epkg       "4.2")
    (marginalia "2.11"))
  :url "https://github.com/emacscollective/epkg-marginalia"
  :commit "e789ebff7af97f193e38cc3d5636dd55022973b8"
  :revdesc "v1.1.5-0-ge789ebff7af9"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev")))
