;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scf-mode" "0.1"
  "Shorten file-names in compilation type buffers."
  ()
  :url "https://github.com/lewang/le_emacs_libs/blob/master/scf-mode.el"
  :commit "4849be890eddc6fd8132fbdecf2558296fffb4d1"
  :revdesc "4849be890edd"
  :keywords '("compilation"))
