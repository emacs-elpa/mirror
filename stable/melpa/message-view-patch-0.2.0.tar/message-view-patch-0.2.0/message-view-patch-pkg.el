;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "message-view-patch" "0.2.0"
  "Colorize patch-like emails in mu4e."
  '((emacs "24.4")
    (magit "3.0.0"))
  :url "https://github.com/seanfarley/message-view-patch"
  :commit "e5b462512dbf85d8a59506776a796966f6f48727"
  :revdesc "e5b462512dbf"
  :keywords '("extensions" "mu4e" "gnus"))
