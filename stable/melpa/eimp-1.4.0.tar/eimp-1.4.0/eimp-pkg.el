;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eimp" "1.4.0"
  "Emacs Image Manipulation Package."
  ()
  :url "https://github.com/nicferrier/eimp"
  :commit "2e7536fe6d8f7faf1bad7a8ae37faba0162c3b4f"
  :revdesc "2e7536fe6d8f"
  :keywords '("files" "frames")
  :authors '(("Matthew P. Hodges" . "MPHodges@member.fsf.org"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
