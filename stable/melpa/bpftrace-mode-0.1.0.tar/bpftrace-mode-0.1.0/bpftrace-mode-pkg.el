;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bpftrace-mode" "0.1.0"
  "Major mode for editing bpftrace script files."
  '((emacs "24.0"))
  :url "https://gitlab.com/jgkamat/bpftrace-mode"
  :commit "89c5bfcc68567622aef8eabb0f3d00a98005405d"
  :revdesc "89c5bfcc6856"
  :keywords '("highlight")
  :authors '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainers '(("Jay Kamat" . "jaygkamat@gmail.com")))
