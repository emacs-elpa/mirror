;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quarto-mode" "0.0.3"
  "A (poly)mode for https://quarto.org."
  '((emacs         "25.1")
    (polymode      "0.2.2")
    (poly-markdown "0.2.2")
    (markdown-mode "2.3")
    (request       "0.3.2"))
  :url "https://github.com/quarto-dev/quarto-emacs"
  :commit "769a4ec178f8ad3e0c87b1ee23e64616ee161b02"
  :revdesc "769a4ec178f8"
  :keywords '("languages" "multi-modes"))
