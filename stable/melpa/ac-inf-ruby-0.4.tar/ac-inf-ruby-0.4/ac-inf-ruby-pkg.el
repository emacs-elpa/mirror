;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-inf-ruby" "0.4"
  "Enable auto-complete in inf-ruby sessions."
  '((inf-ruby      "2.3.2")
    (auto-complete "1.4"))
  :url "https://github.com/purcell/ac-inf-ruby"
  :commit "3e22b66d3d3e2712a0fe783b5cdd0583a0d4c318"
  :revdesc "3e22b66d3d3e"
  :keywords '("languages" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
