;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyim-cangjiedict" "0.0.3"
  "Some cangjie dicts for pyim."
  '((pyim "3.7"))
  :url "https://github.com/cor5corpii/pyim-cangjiedict"
  :commit "2742edcfb60328793fc983bd4a0dedc88f550ec1"
  :revdesc "2742edcfb603"
  :keywords '("convenience" "chinese" "pinyin" "input-method" "cangjie")
  :authors '(("Yuanchen Xie" . "xieych@outlook.com"))
  :maintainers '(("Yuanchen Xie" . "xieych@outlook.com")))
