;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quelpa-leaf" "0.0.1"
  "Quelpa handler for leaf."
  '((emacs  "24.3")
    (quelpa "1.0")
    (leaf   "4.1.0"))
  :url "https://github.com/jcs-elpa/quelpa-leaf"
  :commit "d367e3cd54d9ac949569f4cb7c0ff092a76391ab"
  :revdesc "d367e3cd54d9"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
