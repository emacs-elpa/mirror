;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paren-face" "1.2.5"
  "A face for parentheses in lisp modes."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/paren-face"
  :commit "f9e2f30366937223fc71611f2590c802d577bd22"
  :revdesc "v1.2.5-0-gf9e2f3036693"
  :keywords '("faces" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev")))
