;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-spotlight" "0.2.0"
  "Consult interface to macOS mdfind (Spotlight)."
  '((emacs   "28.1")
    (consult "2.0"))
  :url "https://github.com/guibor/consult-spotlight"
  :commit "c6d8cb34e223608708c5424e4d03d04d6d6648f7"
  :revdesc "c6d8cb34e223"
  :keywords '("matching" "files" "convenience")
  :authors '(("MDF" . "sguibor@gmail.com"))
  :maintainers '(("MDF" . "sguibor@gmail.com")))
