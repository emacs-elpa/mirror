;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anybar" "0.1.0"
  "[No description available]."
  ()
  :url "https://github.com/tie-rack/anybar-el"
  :commit "987d19b9a2ba7fe3e20bcbef9ea78d64648fc3ff"
  :revdesc "987d19b9a2ba"
  :keywords '("anybar")
  :authors '(("Christopher Shea" . "cmshea@gmail.com"))
  :maintainers '(("Christopher Shea" . "cmshea@gmail.com")))
