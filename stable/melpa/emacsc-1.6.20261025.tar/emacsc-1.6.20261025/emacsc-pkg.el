;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsc" "1.6.20261025"
  "Helper for emacsc(1)."
  ()
  :url "https://github.com/knu/emacsc"
  :commit "ee29327b6f4617fbd68e49ea91f9d4bfc9d65225"
  :revdesc "v1.6.20261025-0-gee29327b6f46"
  :keywords '("tools")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
