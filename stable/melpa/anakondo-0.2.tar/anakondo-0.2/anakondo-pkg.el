;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anakondo" "0.2"
  "Adds clj-kondo based Clojure[Script] editing facilities."
  '((emacs      "26.3")
    (projectile "2.1.0"))
  :url "https://github.com/didibus/anakondo"
  :commit "b9ea996c651c43722a5e577f61b5f823f222d864"
  :revdesc "b9ea996c651c"
  :keywords '("clojure" "clojurescript" "cljc" "clj-kondo" "completion" "languages" "tools")
  :authors '(("Didier A." . "didibus@users.noreply.github.com"))
  :maintainers '(("Didier A." . "didibus@users.noreply.github.com")))
