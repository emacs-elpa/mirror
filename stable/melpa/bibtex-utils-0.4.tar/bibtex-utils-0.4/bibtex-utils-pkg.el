;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bibtex-utils" "0.4"
  "Provides utilities for extending BibTeX mode."
  ()
  :url "https://github.com/plantarum/bibtex-utils"
  :commit "1b25796ac9e6546b46daea861f1bf3d3031cebca"
  :revdesc "1b25796ac9e6"
  :keywords '("bibtex")
  :authors '(("Tyler Smith" . "tyler@plantarum.ca"))
  :maintainers '(("Tyler Smith" . "tyler@plantarum.ca")))
