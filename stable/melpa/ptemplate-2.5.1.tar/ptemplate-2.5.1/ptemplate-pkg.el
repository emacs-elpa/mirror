;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ptemplate" "2.5.1"
  "Project templates."
  '((emacs     "25.1")
    (yasnippet "0.13.0"))
  :url "https://github.com/nbfalcon/ptemplate"
  :commit "921ee97c5643ed1a7c1904a90c1f8b8535261b34"
  :revdesc "921ee97c5643"
  :authors '(("Nikita Bloshchanevich" . "nikblos@outlook.com"))
  :maintainers '(("Nikita Bloshchanevich" . "nikblos@outlook.com")))
