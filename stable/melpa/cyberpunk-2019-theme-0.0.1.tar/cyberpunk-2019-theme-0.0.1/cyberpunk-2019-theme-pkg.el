;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cyberpunk-2019-theme" "0.0.1"
  "A retina-scorching cyberpunk theme."
  ()
  :url "https://github.com/the-frey/cyberpunk-2019"
  :commit "2d8d7b6d6953a66a1f94e1ff4ada80d6f3cf464e"
  :revdesc "2d8d7b6d6953"
  :keywords '("cyberpunk" "theme"))
