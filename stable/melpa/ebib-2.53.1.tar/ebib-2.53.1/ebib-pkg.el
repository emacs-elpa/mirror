;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebib" "2.53.1"
  "A BibTeX database manager."
  '((parsebib "6.0")
    (emacs    "27.1")
    (compat   "29.1.4.3"))
  :url "http://joostkremers.github.io/ebib/"
  :commit "db249ecc8dadb1d7a26053c6464df62c82facebb"
  :revdesc "db249ecc8dad"
  :keywords '("text" "bibtex")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
