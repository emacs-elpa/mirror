;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pkg-overview" "1.0"
  "Make org documentation from elisp source file."
  ()
  :url "https://github.com/Boruch-Baum/emacs-pkg-overview"
  :commit "c957d3dddb93d1ce78ddd4c9bd13430fc42902e4"
  :revdesc "c957d3dddb93"
  :keywords '("docs" "help" "lisp" "maint" "outlines" "tools")
  :authors '(("Boruch Baum" . "boruch_baum@gmx.com"))
  :maintainers '(("Boruch Baum" . "boruch_baum@gmx.com")))
