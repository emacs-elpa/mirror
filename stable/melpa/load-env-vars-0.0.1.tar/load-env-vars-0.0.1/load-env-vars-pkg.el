;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "load-env-vars" "0.0.1"
  "Load environment variables from files."
  ()
  :url "https://github.com/diasjorge/emacs-load-env-vars"
  :commit "b2535359ae38a93dfd3c4e4035caab41ba33dbfd"
  :revdesc "b2535359ae38"
  :keywords '("lisp")
  :authors '(("Jorge Dias" . "jorge@mrdias.com"))
  :maintainers '(("Jorge Dias" . "jorge@mrdias.com")))
