;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "which-key" "3.6.0"
  "Display available keybindings in popup."
  '((emacs "24.4"))
  :url "https://github.com/justbur/emacs-which-key"
  :commit "1217db8c6356659e67b35dedd9f5f260c06f6e99"
  :revdesc "1217db8c6356"
  :authors '(("Justin Burkett" . "justin@burkett.cc"))
  :maintainers '(("Justin Burkett" . "justin@burkett.cc")))
