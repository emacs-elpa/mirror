;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "show-font-mode" "0.1"
  "Show font at point on mode line."
  '((emacs "25.1"))
  :url "https://github.com/melissaboiko/show-font-mode"
  :commit "25ad59d8bb1e40370f15cf5f8e043a418ea1f43f"
  :revdesc "25ad59d8bb1e"
  :keywords '("faces" "i18n" "unicode" "fonts" "fontsets")
  :authors '(("Melissa Boiko" . "melissa@namakajiri.net"))
  :maintainers '(("Melissa Boiko" . "melissa@namakajiri.net")))
