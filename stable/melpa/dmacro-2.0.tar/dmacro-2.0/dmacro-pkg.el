;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dmacro" "2.0"
  "Repeated detection and execution of key operation."
  ()
  :url "https://github.com/emacs-jp/dmacro"
  :commit "c9219b47be20616e5be082ce30c927b84279ae24"
  :revdesc "c9219b47be20"
  :keywords '("convenience")
  :authors '(("Toshiyuki Masui" . "masui@ptiecan.com"))
  :maintainers '(("Toshiyuki Masui" . "masui@ptiecan.com")))
