;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-clang" "0.1"
  "Auto Completion source for clang for GNU Emacs."
  ()
  :url "https://github.com/brianjcj/auto-complete-clang"
  :commit "0a53b38e7d94b0f3469fbeea4c1a37fc3a1cd173"
  :revdesc "0a53b38e7d94"
  :keywords '("completion" "convenience")
  :authors '(("Brian Jiang" . "brianjcj@gmail.com"))
  :maintainers '(("Brian Jiang" . "brianjcj@gmail.com")))
