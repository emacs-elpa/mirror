;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smartscan" "0.2"
  "Jumps between other symbols found at point."
  ()
  :url "https://github.com/mickeynp/smart-scan"
  :commit "13c9fd6c0e38831f78dec55051e6b4a643963176"
  :revdesc "0.2-0-g13c9fd6c0e38"
  :keywords '("extensions")
  :authors '(("Mickey Petersen" . "mickey@masteringemacs.org"))
  :maintainers '(("Mickey Petersen" . "mickey@masteringemacs.org")))
