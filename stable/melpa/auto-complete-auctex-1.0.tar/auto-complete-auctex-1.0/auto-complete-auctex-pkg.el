;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-auctex" "1.0"
  "Auto-completion for auctex."
  ()
  :url "https://github.com/emacsattic/auto-complete-auctex"
  :commit "9ff50aa0b7d066ee04fe58a769e60a0604d913f7"
  :revdesc "9ff50aa0b7d0"
  :authors '(("Christopher Monsanto" . "chris@monsan.to"))
  :maintainers '(("Christopher Monsanto" . "chris@monsan.to")))
