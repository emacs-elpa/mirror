;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-rss" "0.0.1"
  "RSS 2.0 Back-End for Org Export Engine."
  '((emacs "26.1")
    (org   "9.3"))
  :url "https://github.com/benedicthw/ox-rss.git"
  :commit "09fb4c92d99e0ce077dfe26beac0754f70f0fc64"
  :revdesc "09fb4c92d99e"
  :keywords '("org" "wp" "blog" "feed" "rss")
  :authors '(("Bastien Guerry" . "bzg@gnu.org"))
  :maintainers '(("Benedict Wang" . "foss@bhw.name")))
