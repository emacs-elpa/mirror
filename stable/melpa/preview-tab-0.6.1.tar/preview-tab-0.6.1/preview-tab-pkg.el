;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "preview-tab" "0.6.1"
  "Temporary file buffers, like VS Code's preview tab."
  '((emacs "27.1"))
  :url "https://github.com/ismd/preview-tab.el"
  :commit "07cd13e5b999544a9da90a1f6d673628c3444b3a"
  :revdesc "07cd13e5b999"
  :keywords '("convenience" "files")
  :authors '(("Vladimir Kosteley" . "github@ismd.dev"))
  :maintainers '(("Vladimir Kosteley" . "github@ismd.dev")))
