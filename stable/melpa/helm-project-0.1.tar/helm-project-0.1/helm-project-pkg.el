;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-project" "0.1"
  "Helm source for project management."
  '((emacs "28.1")
    (helm  "3.9.0"))
  :url "https://github.com/cmccloud/helm-project"
  :commit "56d62e7bc3ac26d5dc3197847f1e06906d6d63d1"
  :revdesc "56d62e7bc3ac")
