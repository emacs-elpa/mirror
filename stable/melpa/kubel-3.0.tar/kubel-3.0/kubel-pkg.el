;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel" "3.0"
  "Control Kubernetes with limited permissions."
  '((transient "0.1.0")
    (emacs     "25.3")
    (dash      "2.12.0")
    (s         "1.2.0")
    (yaml-mode "0.0.14"))
  :url "https://github.com/abrochard/kubel"
  :commit "1b405d8756ffc7c8f1e11450d6f07ffde38fe351"
  :revdesc "1b405d8756ff"
  :keywords '("kubernetes" "k8s" "tools" "processes"))
