;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-grep" "1.3.3"
  "Kind of M-x rgrep adapted for Org mode."
  '((emacs "26.1"))
  :url "https://sr.ht/~minshall/org-grep/"
  :commit "715f91a61a0c01eaaff4d0e61656060e3d175abb"
  :revdesc "1.3.3-0-g715f91a61a0c"
  :authors '(("François Pinard" . "pinard@iro.umontreal.ca"))
  :maintainers '(("Greg Minshall" . "minshall@umich.edu")))
