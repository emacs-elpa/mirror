;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amx" "3.4"
  "Alternative M-x with extra features."
  '((emacs "24.4")
    (s     "0"))
  :url "https://github.com/DarwinAwardWinner/amx/"
  :commit "37f9c7ae55eb0331b27200fb745206fc58ceffc0"
  :revdesc "37f9c7ae55eb"
  :keywords '("convenience" "usability" "completion")
  :authors '(("Ryan C. Thompson" . "rct@thompsonclan.org")
             ("Cornelius Mika" . "cornelius.mika@gmail.com"))
  :maintainers '(("Ryan C. Thompson" . "rct@thompsonclan.org")))
