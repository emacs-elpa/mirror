;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-toggle-sudo" "1.0"
  "Browse directory with sudo privileges."
  ()
  :url "https://github.com/renard/dired-toggle-sudo"
  :commit "02449dbda4e168f99fe5352c9628df5d39e11483"
  :revdesc "v1.0-0-g02449dbda4e1"
  :keywords '("emacs" "dired")
  :authors '(("Sebastien Gross" . "seb•ɑƬ•chezwam•ɖɵʈ•org"))
  :maintainers '(("Sebastien Gross" . "seb•ɑƬ•chezwam•ɖɵʈ•org")))
