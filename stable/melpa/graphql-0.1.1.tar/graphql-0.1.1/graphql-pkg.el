;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphql" "0.1.1"
  "GraphQL utilities."
  '((emacs "25"))
  :url "https://github.com/vermiculus/graphql.el"
  :commit "672dd9ebd7e67d8089388b0c484cd650e76565f3"
  :revdesc "0.1.1-0-g672dd9ebd7e6"
  :keywords '("hypermedia" "tools" "lisp")
  :authors '(("Sean Allred" . "code@seanallred.com"))
  :maintainers '(("Sean Allred" . "code@seanallred.com")))
