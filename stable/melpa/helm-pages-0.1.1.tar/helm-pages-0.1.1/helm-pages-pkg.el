;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-pages" "0.1.1"
  "Pages in current buffer as Helm datasource."
  '((helm   "1.6.5")
    (emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/david-christiansen/helm-pages"
  :commit "e334ca3312e51d6fdfa989df5d3ebe683d673c0e"
  :revdesc "e334ca3312e5"
  :keywords '("convenience" "helm" "outlines")
  :authors '(("David Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Christiansen" . "david@davidchristiansen.dk")))
