;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "duplicate-thing" "0.2"
  "Duplicate current line & selection."
  ()
  :url "https://github.com/ongaeshi/duplicate-thing"
  :commit "42b8010fc6cc3a333a5bc6328020d30d3239e57d"
  :revdesc "42b8010fc6cc"
  :keywords '("command" "duplicate" "line" "selection"))
