;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-attach-screenshot" "0.9"
  "Screenshots integrated with org attachment dirs."
  '((emacs "24.3"))
  :url "https://github.com/dfeich/org-screenshot"
  :commit "a63c6288425505bb035dc962acd0de3c55d50eb1"
  :revdesc "a63c62884255"
  :keywords '("org" "multimedia")
  :authors '(("Derek Feichtinger" . "derek.feichtinger@psi.ch"))
  :maintainers '(("Derek Feichtinger" . "derek.feichtinger@psi.ch")))
