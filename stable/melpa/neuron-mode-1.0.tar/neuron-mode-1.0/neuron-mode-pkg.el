;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neuron-mode" "1.0"
  "Major mode for editing zettelkasten notes using neuron."
  '((emacs         "26.3")
    (f             "0.20.0")
    (s             "1.12.0")
    (markdown-mode "2.3")
    (company       "0.9.13"))
  :url "https://github.com/felko/neuron-mode"
  :commit "3f86d26fb2006e82c673a5bf122594820a4842d8"
  :revdesc "3f86d26fb200"
  :keywords '("outlines")
  :authors '(("felko" . "http://github/felko"))
  :maintainers '(("felko" . "http://github/felko")))
