;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-py-mode" "4.13.3"
  "Live Coding in Python."
  '((emacs "24.3"))
  :url "http://donkirkby.github.io/live-py-plugin/"
  :commit "e7fdd3e28550e6983a301437e837836fecae3d3a"
  :revdesc "e7fdd3e28550"
  :keywords '("live" "coding"))
