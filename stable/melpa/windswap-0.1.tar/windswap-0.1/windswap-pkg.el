;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "windswap" "0.1"
  "Like windmove, but swaps buffers while moving point."
  '((emacs "24.3"))
  :url "https://github.com/purcell/windswap"
  :commit "33d59d371843d5a72a4327e318382ff27ee15674"
  :revdesc "33d59d371843"
  :keywords '("frames" "convenience")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
