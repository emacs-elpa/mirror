;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bonjourmadame" "0.6"
  "Say \"Hello ma'am!\"."
  ()
  :url "https://github.com/pierre-lecocq/bonjourmadame"
  :commit "836fe5f710b0c6226f5ed246c30f5adc86f7260f"
  :revdesc "836fe5f710b0")
