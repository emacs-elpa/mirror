;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "0.1.0"
  "Minor mode to format JS code on file save."
  '((emacs "28.1"))
  :url "https://github.com/prettier/prettier-emacs"
  :commit "83bc736b8ad630943281ca6fcafa88beed486ea2"
  :revdesc "83bc736b8ad6"
  :keywords '("convenience" "wp" "edit" "js"))
