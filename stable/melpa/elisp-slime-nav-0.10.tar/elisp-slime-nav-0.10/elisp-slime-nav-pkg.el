;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-slime-nav" "0.10"
  "Make M-. and M-, work in elisp like they do in slime."
  '((emacs  "24.1")
    (cl-lib "0.2"))
  :url "https://github.com/purcell/elisp-slime-nav"
  :commit "9ab52362600af9f97f1590f05a295538025170b3"
  :revdesc "9ab52362600a"
  :keywords '("languages" "navigation" "slime" "elisp" "emacs-lisp")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
