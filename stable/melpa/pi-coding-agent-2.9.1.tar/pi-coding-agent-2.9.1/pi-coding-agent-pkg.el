;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "2.9.1"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.3.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "ebb07bd15ac7ddbbe29580c42fd3015e57755433"
  :revdesc "v2.9.1-0-gebb07bd15ac7"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
