;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-rainbow" "0.0.3"
  "Extended file highlighting according to its type."
  '((dash              "2.5.0")
    (dired-hacks-utils "0.0.1"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "cab59f335430f86a5c94cc9d8812d5f4f8d843f6"
  :revdesc "cab59f335430"
  :keywords '("files")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
