;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-vimish-fold" "0.3"
  "Integrate vimish-fold with evil."
  '((emacs       "24.4")
    (evil        "1.0.0")
    (vimish-fold "0.2.0"))
  :url "https://github.com/alexmurray/evil-vimish-fold"
  :commit "4db872d12274fdddf7c6e9d01cf68cbad9cfcf15"
  :revdesc "4db872d12274"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
