;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "29.1.1"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "ad05823719d77c8faee87348ea39513d4e2f99c5"
  :revdesc "OTP-29.1.1-0-gad05823719d7"
  :keywords '("erlang" "languages" "processes"))
