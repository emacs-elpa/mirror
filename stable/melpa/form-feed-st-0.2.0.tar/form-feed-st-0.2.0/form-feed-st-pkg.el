;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "form-feed-st" "0.2.0"
  "Display ^L glyphs as horizontal lines."
  '((emacs "25.1"))
  :url "https://github.com/leodag/form-feed-st"
  :commit "fa26c59db10c0bbe3f9ed9eca03f299e62d7cf7a"
  :revdesc "fa26c59db10c"
  :keywords '("faces"))
