;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "c0-mode" "0.1"
  "C0 mode derived mode."
  ()
  :url "https://github.com/catern/c0-mode"
  :commit "d8e25756df79f690c80b2ae7deb663a8a17146ab"
  :revdesc "d8e25756df79"
  :keywords '("c0" "languages"))
