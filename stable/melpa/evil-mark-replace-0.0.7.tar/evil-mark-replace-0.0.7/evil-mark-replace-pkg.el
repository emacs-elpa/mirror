;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-mark-replace" "0.0.7"
  "Replace the thing in buffer and defun."
  '((evil "1.15.0"))
  :url "https://github.com/redguardtoo/evil-mark-replace"
  :commit "3221d2c3b304a1cb825f6c79da4d418a8233dcc2"
  :revdesc "3221d2c3b304"
  :keywords '("convenience"))
