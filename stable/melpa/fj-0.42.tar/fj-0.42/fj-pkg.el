;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "0.42"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "9e28ba39004614de44aa52bd4e429658afbc3f93"
  :revdesc "9e28ba390046"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
