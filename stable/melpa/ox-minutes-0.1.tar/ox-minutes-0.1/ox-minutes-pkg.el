;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-minutes" "0.1"
  "Plain text backend for Org for Meeting Minutes."
  ()
  :url "https://github.com/kaushalmodi/ox-minutes"
  :commit "8edd0d5e2c7783d06f8ce062e6a7578066c71382"
  :revdesc "8edd0d5e2c77"
  :keywords '("org" "exporter" "notes")
  :authors '(("Kaushal Modi" . "kaushal.modi@gmail.com"))
  :maintainers '(("Kaushal Modi" . "kaushal.modi@gmail.com")))
