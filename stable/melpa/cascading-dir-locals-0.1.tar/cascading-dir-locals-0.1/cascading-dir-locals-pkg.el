;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cascading-dir-locals" "0.1"
  "Apply all (!) .dir-locals.el from root to current directory."
  '((emacs "26.1"))
  :url "https://github.com/fritzgrabo/cascading-dir-locals"
  :commit "b55c535a639ad91d77ecf4ecf3f5b05a60c7f794"
  :revdesc "b55c535a639a"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "me@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "me@fritzgrabo.com")))
