;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-sql-mode" "1.1"
  "SQL code blocks evaluated by sql-mode."
  '((emacs "24.4"))
  :url "https://github.com/nikclayton/ob-sql-mode"
  :commit "8d36d312bec4a742bec8890373948a888cac18de"
  :revdesc "8d36d312bec4"
  :keywords '("languages" "org" "org-babel" "sql")
  :authors '((nil . "NikClaytonnik@google.com"))
  :maintainers '((nil . "NikClaytonnik@google.com")))
