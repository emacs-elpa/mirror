;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wildcharm-light-theme" "0.7"
  "Port of vim-wildcharm (light) colorscheme."
  '((emacs "24.1"))
  :url "https://github.com/habamax/wildcharm-theme"
  :commit "ab0ed9cc5b4a285cddef52b193c26a979e1dcd08"
  :revdesc "ab0ed9cc5b4a"
  :authors '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers '(("Maxim Kim" . "habamax@gmail.com")))
