;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "2.0.2"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "97f27eced151f95e6ba303298074847bc524c937"
  :revdesc "97f27eced151"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
