;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpa-audit" "0.4"
  "Handy functions for inspecting and comparing package archives."
  ()
  :url "https://github.com/purcell/elpa-audit"
  :commit "a7a1806278c73ea6cb6d235714e7bc8088971df5"
  :revdesc "a7a1806278c7"
  :keywords '("maint")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
