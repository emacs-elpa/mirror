;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insert-esv" "0.1.0"
  "Insert ESV Bible passages."
  '((emacs "24.3"))
  :url "https://github.com/sam030820/insert-esv/"
  :commit "8a09629bfafa87f8cd75e92fee6655cfa8be67f2"
  :revdesc "8a09629bfafa"
  :keywords '("convenience"))
