;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-ffuf" "0.9"
  "Babel funcitons for ffuf."
  '((emacs "28.1"))
  :url "https://github.com/daniel-ts/ob-ffuf"
  :commit "928960b369059fdf92322a172edea73c638cf125"
  :revdesc "928960b36905"
  :keywords '("comm" "tools")
  :maintainers '(("Daniel Tschertkow" . "daniel.tschertkow@posteo.de")))
