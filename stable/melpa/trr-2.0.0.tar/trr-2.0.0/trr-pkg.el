;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trr" "2.0.0"
  "A type-writing training program on GNU Emacs."
  ()
  :url "https://github.com/kawabata/emacs-trr"
  :commit "7500ae0a05a3e26888949208afcd0185cc1b1404"
  :revdesc "v2.0.0-0-g7500ae0a05a3"
  :keywords '("games" "faces")
  :authors '(("YAMAMOTO Hirotaka" . "ymmt@is.s.u-tokyo.ac.jp")
             ("KATO Kenji" . "kato@suri.co.jp")
             ("INAMURA You" . "inamura@icot.or.jp"))
  :maintainers '(("YAMAMOTO Hirotaka" . "ymmt@is.s.u-tokyo.ac.jp")
                 ("KATO Kenji" . "kato@suri.co.jp")
                 ("INAMURA You" . "inamura@icot.or.jp")))
