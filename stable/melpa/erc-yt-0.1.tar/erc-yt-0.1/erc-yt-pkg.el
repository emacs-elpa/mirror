;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-yt" "0.1"
  "An erc module to display youtube links nicely."
  '((dash "2.10.0"))
  :url "https://github.com/yhvh/erc-yt"
  :commit "b4b77c9e7ad214d41a519998bf2b89655c05ec42"
  :revdesc "b4b77c9e7ad2"
  :keywords '("multimedia")
  :authors '(("William Stevenson" . "yhvh2000@gmail.com"))
  :maintainers '(("William Stevenson" . "yhvh2000@gmail.com")))
