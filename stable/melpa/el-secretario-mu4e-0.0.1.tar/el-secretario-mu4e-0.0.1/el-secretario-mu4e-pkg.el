;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-secretario-mu4e" "0.0.1"
  "[No description available]."
  '((emacs  "27.1")
    (cl-lib "0.5")
    (org-ql "0.6-pre"))
  :url "https://git.sr.ht/~zetagon/el-secretario"
  :commit "55723bf7e14a2d6df5d273d6975b5cbf082e49de"
  :revdesc "55723bf7e14a"
  :authors '(("Leo Okawa Ericson" . "http://github/Zetagon"))
  :maintainers '(("Leo" . "github@relevant-information.com")))
