;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-skk" "0.1"
  "Auto-complete-mode source for DDSKK a.k.a Japanese input method."
  '((auto-complete "1.3.1"))
  :url "https://github.com/myuhe/ac-skk.el"
  :commit "6b45821904ac3109dd206827feef178de7b277d9"
  :revdesc "6b45821904ac"
  :keywords '("convenience" "auto-complete")
  :authors '(("lugecy" . "https://twitter.com/lugecy")))
