;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.89.4"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0195679fa9e661d012a97b8cfd1fcdc577d8496f"
  :revdesc "0195679fa9e6")
