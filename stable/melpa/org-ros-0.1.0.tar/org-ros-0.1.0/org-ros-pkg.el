;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ros" "0.1.0"
  "Rahul's Org-Mode Screenshot."
  '((emacs "24.1"))
  :url "https://github.com/LionyxML/ros"
  :commit "7f3671e6b61e6d94ee408f286a8f9c5f585278a2"
  :revdesc "7f3671e6b61e"
  :authors '(("Rahul Martim Juliato" . "rahul.juliato@gmail.com"))
  :maintainers '(("Rahul Martim Juliato" . "rahul.juliato@gmail.com")))
