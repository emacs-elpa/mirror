;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dune" "3.23.1"
  "Integration with the dune build system."
  ()
  :url "https://github.com/ocaml/dune"
  :commit "6f6eee69eda59e355bae2ca4e3ad1af678271883"
  :revdesc "3.23.1-0-g6f6eee69eda5")
