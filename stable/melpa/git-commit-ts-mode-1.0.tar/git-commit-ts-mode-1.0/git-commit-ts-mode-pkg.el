;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-commit-ts-mode" "1.0"
  "Tree-sitter support for Git commit messages."
  '((emacs "29.1"))
  :url "https://github.com/danilshvalov/git-commit-ts-mode"
  :commit "dedd10ca24bf4943516c1aecf0523c98f9fac57f"
  :revdesc "dedd10ca24bf"
  :keywords '("tree-sitter" "git")
  :authors '(("Daniil Shvalov" . "daniil.shvalov@gmail.com"))
  :maintainers '(("Daniil Shvalov" . "daniil.shvalov@gmail.com")))
