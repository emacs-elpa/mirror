;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "malyon" "20161204"
  "Mode to execute z code files version 3, 5, 8."
  ()
  :url "https://github.com/speedenator/malyon"
  :commit "895f968cbb9705b7db8655810601cabb40a27ecb"
  :revdesc "895f968cbb97"
  :keywords '("games" "emulations")
  :authors '(("Peter Ilberg" . "peter.ilberg@gmail.com"))
  :maintainers '(("Erik Selberg" . "erik@selberg.org")))
