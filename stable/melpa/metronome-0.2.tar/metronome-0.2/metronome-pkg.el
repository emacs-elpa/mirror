;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metronome" "0.2"
  "A simple metronome."
  '((emacs "25.1"))
  :url "https://gitlab.com/jagrg/metronome"
  :commit "4df48a46ba51f65ad57931716ec82ec3bd49745f"
  :revdesc "4df48a46ba51"
  :authors '(("Jonathan Gregory" . "jgrgatautisticidotorg"))
  :maintainers '(("Jonathan Gregory" . "jgrgatautisticidotorg")))
