;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bril-mode" "0.0.1"
  "Major mode for Bril text format."
  '((emacs "27.1"))
  :url "https://github.com/nverno/bril-mode"
  :commit "e07e7d6a50e49740baafe264b12ccb34554195ee"
  :revdesc "e07e7d6a50e4"
  :keywords '("languages" "bril")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
