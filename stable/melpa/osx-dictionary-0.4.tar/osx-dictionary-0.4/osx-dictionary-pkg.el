;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-dictionary" "0.4"
  "Interface for OSX Dictionary.app."
  '((cl-lib "0.5"))
  :url "https://github.com/xuchunyang/osx-dictionary.el"
  :commit "0e5e5f1b0077a62673855889d529dd4f0cc8f665"
  :revdesc "0e5e5f1b0077"
  :keywords '("mac" "dictionary")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
