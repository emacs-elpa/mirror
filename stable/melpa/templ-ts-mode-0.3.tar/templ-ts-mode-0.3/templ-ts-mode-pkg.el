;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "templ-ts-mode" "0.3"
  "Major mode for editing Templ files."
  '((emacs "29.1"))
  :url "https://github.com/danderson/templ-ts-mode"
  :commit "f1df396a5db1d9aef9a3f7fb72be1d0c33e32366"
  :revdesc "f1df396a5db1"
  :keywords '("languages")
  :authors '(("David Anderson" . "dave@natulte.net"))
  :maintainers '(("David Anderson" . "dave@natulte.net")))
