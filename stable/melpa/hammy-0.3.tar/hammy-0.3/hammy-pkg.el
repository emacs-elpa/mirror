;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hammy" "0.3"
  "Programmable, interactive interval timers."
  '((emacs   "28.1")
    (svg-lib "0.2.5")
    (ts      "0.2.2"))
  :url "https://github.com/alphapapa/hammy.el"
  :commit "d5d154060bb13e9b61d74a83b25a12238973099d"
  :revdesc "v0.3-0-gd5d154060bb1"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
