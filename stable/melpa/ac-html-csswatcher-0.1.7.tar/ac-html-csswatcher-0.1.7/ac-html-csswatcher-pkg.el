;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-html-csswatcher" "0.1.7"
  "Css/less class/id completion with `ac-html' or `company-web'."
  '((web-completion-data "0.1"))
  :url "https://github.com/osv/ac-html-csswatcher"
  :commit "dadc3c595cf1708291096c03987f1981f3cabc6b"
  :revdesc "dadc3c595cf1"
  :keywords '("html" "css" "less" "auto-complete")
  :authors '(("Olexandr Sydorchuck" . "olexandr.syd@gmail.com"))
  :maintainers '(("Olexandr Sydorchuck" . "olexandr.syd@gmail.com")))
