;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-snipe" "2.0.8"
  "Emulate vim-sneak & vim-seek."
  '((emacs  "24.4")
    (evil   "1.2.12")
    (cl-lib "0.5"))
  :url "https://github.com/hlissner/evil-snipe"
  :commit "dc62ac317fd29f018e9785c1b3b7dd7ad57b3938"
  :revdesc "dc62ac317fd2"
  :keywords '("emulation" "vim" "evil" "sneak" "seek")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "henrik@lissner.net")))
