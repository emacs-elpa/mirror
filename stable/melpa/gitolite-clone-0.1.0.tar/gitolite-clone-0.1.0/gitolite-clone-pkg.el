;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitolite-clone" "0.1.0"
  "Clone gitolite repositories from a completing list."
  '((dash   "2.10.0")
    (s      "1.9.0")
    (pcache "0.3.1"))
  :url "https://github.com/IvanMalison/gitolite-cloone"
  :commit "aaf0f2b8752332ae951c247399011b71df22eb43"
  :revdesc "aaf0f2b87523"
  :keywords '("gitolite" "clone" "git")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
