;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macports" "0.1.0"
  "A porcelain for MacPorts."
  '((emacs "28.1"))
  :url "https://github.com/amake/.emacs.d"
  :commit "134fd20c86e8a10ae02bd25e2a90b193a0a4615b"
  :revdesc "134fd20c86e8")
