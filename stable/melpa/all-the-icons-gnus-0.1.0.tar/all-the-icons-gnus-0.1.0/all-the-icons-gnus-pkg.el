;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "all-the-icons-gnus" "0.1.0"
  "Shows icons for in Gnus."
  '((emacs         "24.4")
    (dash          "2.13.0")
    (all-the-icons "3.1.0"))
  :url "https://github.com/nlamirault/all-the-icons-gnus"
  :commit "0686216a2628c2d508fd13df3ab85d415790225c"
  :revdesc "0686216a2628"
  :keywords '("gnus" "icons" "dired")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
