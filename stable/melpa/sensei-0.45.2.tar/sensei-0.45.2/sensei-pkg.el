;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sensei" "0.45.2"
  "A client for sensei."
  '((emacs      "27.1")
    (projectile "2.5.0")
    (request    "0.3.2"))
  :url "https://abailly.github.io/sensei"
  :commit "3129584a6b4b57cbf0e4769dcb8efcc21d8bc821"
  :revdesc "3129584a6b4b"
  :keywords '("hypermedia")
  :authors '(("Arnaud Bailly" . "arnaud@pankzsoft.com"))
  :maintainers '(("Arnaud Bailly" . "arnaud@pankzsoft.com")))
