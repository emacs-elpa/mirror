;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-forge-prs" "0.1"
  "Generate PR descriptions for forge using gptel."
  '((emacs "28.1")
    (magit "4.0")
    (forge "0.3")
    (gptel "0.9"))
  :url "https://github.com/ArthurHeymans/gptel-forge-prs"
  :commit "6aa4183a1eba89172e40c518c0c22c4b772fc393"
  :revdesc "6aa4183a1eba"
  :keywords '("forge" "vc" "convenience" "llm" "pull-request"))
