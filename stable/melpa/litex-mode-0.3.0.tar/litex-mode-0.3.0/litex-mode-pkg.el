;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "litex-mode" "0.3.0"
  "Minor mode for converting lisp to LaTeX."
  '((cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/Atreyagaurav/litex-mode"
  :commit "bad847232a9453db76a9a1de024bdcf4ed1e97e2"
  :revdesc "bad847232a94"
  :keywords '("calculator" "lisp" "latex")
  :authors '(("Gaurav Atreya" . "allmanpride@gmail.com"))
  :maintainers '(("Gaurav Atreya" . "allmanpride@gmail.com")))
