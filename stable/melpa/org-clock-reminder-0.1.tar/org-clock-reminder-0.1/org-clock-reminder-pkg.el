;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-reminder" "0.1"
  "Reminds current clocking task or its absence."
  '((emacs "26.1"))
  :url "https://github.com/inickey/org-clock-reminder"
  :commit "da596a6c26c48f13bfbfa6acd28528104018e66c"
  :revdesc "da596a6c26c4"
  :keywords '("calendar" "convenience")
  :authors '(("Nikolay Brovko" . "i@nickey.ru"))
  :maintainers '(("Nikolay Brovko" . "i@nickey.ru")))
