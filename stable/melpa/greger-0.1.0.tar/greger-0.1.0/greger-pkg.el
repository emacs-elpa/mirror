;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greger" "0.1.0"
  "Chat with language models."
  '((emacs  "28.0")
    (parsec "0.1.3"))
  :url "https://github.com/andreasjansson/greger.el"
  :commit "c5fb493ace0bfbc4e4285ed706da793415b37548"
  :revdesc "c5fb493ace0b"
  :authors '(("Andreas Jansson" . "andreas@jansson.me.uk"))
  :maintainers '(("Andreas Jansson" . "andreas@jansson.me.uk")))
