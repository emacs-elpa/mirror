;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nyx-theme" "0.1"
  "Dark theme."
  '((emacs "24"))
  :url "https://github.com/GuidoSchmidt/emacs-nyx-theme"
  :commit "afe2b8c3b5421b4c292d182dcf77079b278e93d8"
  :revdesc "afe2b8c3b542"
  :keywords '("themes" "dark-theme")
  :maintainers '(("Guido Schmidt" . "guido.schmidt.2912@gmail.com")))
