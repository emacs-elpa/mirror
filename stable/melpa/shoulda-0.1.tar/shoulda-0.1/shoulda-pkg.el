;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shoulda" "0.1"
  "Shoulda test support for ruby."
  ()
  :url "https://github.com/marcwebbie/shoulda.el"
  :commit "01154189f9b63c49b5d322d7febad142fac5fb97"
  :revdesc "01154189f9b6"
  :keywords '("ruby" "tests")
  :authors '(("Marcwebbie" . "marcwebbie@gmail.com"))
  :maintainers '(("Marcwebbie" . "marcwebbie@gmail.com")))
