;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edbi" "0.1.2"
  "Database independent interface for Emacs."
  ()
  :url "https://github.com/kiwanami/emacs-edbi"
  :commit "39b833d2e51ae5ce66ebdec7c5425ff0d34e02d2"
  :revdesc "39b833d2e51a"
  :keywords '("database" "epc")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net")))
