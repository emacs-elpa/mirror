;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edbi" "0.1.2"
  "Emacs Database Interface."
  '((concurrent "0.3.1")
    (ctable     "0.1.1")
    (epc        "0.1.1"))
  :url "https://github.com/kiwanami/emacs-edbi"
  :commit "39b833d2e51ae5ce66ebdec7c5425ff0d34e02d2"
  :revdesc "39b833d2e51a"
  :keywords '("database" "epc")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net")))
