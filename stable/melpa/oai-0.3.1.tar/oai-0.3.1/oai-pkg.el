;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "0.3.1"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "d6f990c575e8a082e67d86895aaf3596f0035693"
  :revdesc "d6f990c575e8"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
