;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotated-completing-read" "0.1"
  "Completing-read with aligned annotations."
  '((emacs "29.1")
    (dash  "2.19"))
  :url "https://github.com/tychoish/dot-emacs"
  :commit "b35b1d541898f66b8cd52171c9b9946c59e435ba"
  :revdesc "b35b1d541898"
  :keywords '("convenience" "matching"))
