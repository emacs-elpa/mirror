;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-jedi" "1.2.2"
  "Lsp client plugin for Python Jedi Language Server."
  '((emacs    "25.1")
    (lsp-mode "6.0"))
  :url "https://github.com/fredcamps/lsp-jedi"
  :commit "5e3eb3e160c2d38b8bd2b5cd3b86fa4f823f9330"
  :revdesc "5e3eb3e160c2"
  :keywords '("language-server" "tools" "python" "jedi" "ide")
  :authors '(("Fred Campos" . "fred.tecnologia@gmail.com")))
