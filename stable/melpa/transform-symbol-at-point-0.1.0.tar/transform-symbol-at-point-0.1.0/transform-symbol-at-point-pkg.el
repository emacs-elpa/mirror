;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transform-symbol-at-point" "0.1.0"
  "Transforming your symbols at point."
  '((emacs     "24")
    (s         "1.12.0")
    (transient "0.3.7"))
  :url "https://github.com/waymondo/transform-symbol-at-point"
  :commit "bd04027c7a2fe9272455abfdaa4b292e62bdc3f3"
  :revdesc "bd04027c7a2f"
  :keywords '("convenience" "tools"))
