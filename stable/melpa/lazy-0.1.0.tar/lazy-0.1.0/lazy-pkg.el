;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lazy" "0.1.0"
  "Lazy evaluation library."
  ()
  :url "https://github.com/conao3/lazy.el"
  :commit "74ca7fb9f7a4a11563f34ef2a5a3809df1935c86"
  :revdesc "74ca7fb9f7a4"
  :keywords '("lisp" "lazy")
  :authors '((nil . "chuntaro@sakura-games.jp"))
  :maintainers '((nil . "chuntaro@sakura-games.jp")))
