;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pacfiles-mode" "1.2"
  "The pacnew and pacsave merging tool."
  '((emacs "26.1"))
  :url "https://github.com/UndeadKernel/pacfiles-mode"
  :commit "a613d1d88dba4cb293ecaf42a9aeff7d8a3ce8aa"
  :revdesc "a613d1d88dba"
  :keywords '("files" "pacman" "arch" "pacnew" "pacsave" "update" "linux")
  :authors '(("Carlos G. Cordero" . "http://github/UndeadKernel"))
  :maintainers '(("Carlos G. Cordero" . "pacfiles@binarycharly.com")))
