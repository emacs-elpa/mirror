;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphene-meta-theme" "0.0.6"
  "Integrated theming for common packages."
  ()
  :url "https://github.com/rdallasgray/graphene"
  :commit "8e75528529f460b1b5910467c4fc1f516e1a57b9"
  :revdesc "0.0.6-0-g8e75528529f4"
  :keywords '("defaults")
  :authors '(("Robert Dallas Gray" . "mail@robertdallasgray.com"))
  :maintainers '(("Robert Dallas Gray" . "mail@robertdallasgray.com")))
