;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.7.20.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "c863fbe2b99094c49ee3cbc97bfc843ec2f6e505"
  :revdesc "c863fbe2b990"
  :keywords '("languages"))
