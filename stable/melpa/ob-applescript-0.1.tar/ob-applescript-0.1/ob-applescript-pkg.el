;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-applescript" "0.1"
  "Org-babel functions for template evaluation."
  ()
  :url "https://github.com/stig/ob-applescript.el"
  :commit "05927f19a1153118feed2f445a6d2889e40319bd"
  :revdesc "05927f19a115"
  :keywords '("literate programming" "reproducible research" "mac"))
