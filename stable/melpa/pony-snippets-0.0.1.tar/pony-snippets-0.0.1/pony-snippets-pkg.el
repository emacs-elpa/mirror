;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pony-snippets" "0.0.1"
  "Yasnippets for Pony."
  '((yasnippet "0.8.0"))
  :url "https://github.com/seantallen/pony-snippets"
  :commit "56018b23a11563c6766ed706024b22aa5a4556b4"
  :revdesc "56018b23a115"
  :keywords '("snippets" "pony"))
