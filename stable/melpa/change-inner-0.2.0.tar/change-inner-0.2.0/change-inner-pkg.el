;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "change-inner" "0.2.0"
  "Change contents based on semantic units."
  '((expand-region "0.7"))
  :url "https://github.com/magnars/change-inner.el"
  :commit "e830afa46585dfc4942ad96b9df48fe0d0891509"
  :revdesc "e830afa46585"
  :keywords '("convenience" "extensions")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
