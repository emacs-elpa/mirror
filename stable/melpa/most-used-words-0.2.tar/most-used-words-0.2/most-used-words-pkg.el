;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "most-used-words" "0.2"
  "Display most used words in buffer."
  '((emacs "24.3"))
  :url "https://github.com/udyantw/most-used-words"
  :commit "90c09da92b30c6497e9141f0edfe7842440c4d53"
  :revdesc "90c09da92b30"
  :keywords '("convenience" "wp")
  :authors '(("Udyant Wig" . "udyant.wig@gmail.com"))
  :maintainers '(("Udyant Wig" . "udyant.wig@gmail.com")))
