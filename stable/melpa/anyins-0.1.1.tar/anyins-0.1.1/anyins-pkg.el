;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anyins" "0.1.1"
  "Insert content at multiple places from shell command or kill-ring."
  ()
  :url "https://github.com/antham/anyins"
  :commit "1ff4673ca197c9bf64c65f718573bf7d478fc562"
  :revdesc "1ff4673ca197"
  :keywords '("insert" "rectangular")
  :authors '(("Anthony HAMON" . "hamon.anth@gmail.com"))
  :maintainers '(("Anthony HAMON" . "hamon.anth@gmail.com")))
