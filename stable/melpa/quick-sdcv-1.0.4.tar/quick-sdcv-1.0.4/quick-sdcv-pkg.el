;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "1.0.4"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "43385cddb1e0cad978ac007079f33a788cc5457a"
  :revdesc "1.0.4-0-g43385cddb1e0"
  :keywords '("docs" "startdict" "sdcv"))
