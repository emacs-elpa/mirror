;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.10.19.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "ed498f3ec3500706322fe761a69513d72a8e9a70"
  :revdesc "ed498f3ec350"
  :keywords '("languages"))
