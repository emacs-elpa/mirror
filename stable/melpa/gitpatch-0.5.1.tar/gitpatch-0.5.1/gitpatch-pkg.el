;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitpatch" "0.5.1"
  "Git-format patch toolkit."
  '((emacs "24.3"))
  :url "https://github.com/tumashu/gitpatch"
  :commit "94d40a2ee2b7cd7b209546ea02568079176b0034"
  :revdesc "94d40a2ee2b7"
  :keywords '("convenience")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
