;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gvpr-mode" "0.1.0"
  "A major mode offering basic syntax coloring for gvpr scripts."
  ()
  :url "https://raw.github.com/rodw/gvpr-lib/master/extra/gvpr-mode.el"
  :commit "1fb539b8227200f75d7eeb9706a236f805159a63"
  :revdesc "1fb539b82272"
  :keywords '("graphviz" "gv" "dot" "gvpr" "graph")
  :authors '(("Rod Waldhoff" . "r.waldhoff@gmail.com"))
  :maintainers '(("Rod Waldhoff" . "r.waldhoff@gmail.com")))
