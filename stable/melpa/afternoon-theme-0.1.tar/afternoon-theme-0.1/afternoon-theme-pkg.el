;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "afternoon-theme" "0.1"
  "Dark color theme with a deep blue background."
  '((emacs "24.1"))
  :url "https://github.com/osener/emacs-afternoon-theme"
  :commit "b58731c3b0bbaac9d3ed8d5ae900063df5db090d"
  :revdesc "b58731c3b0bb"
  :keywords '("themes")
  :authors '(("Ozan Sener" . "ozan@ozansener.com"))
  :maintainers '(("Ozan Sener" . "ozan@ozansener.com")))
