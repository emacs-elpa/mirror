;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cdlatex" "4.7"
  "Fast input methods for LaTeX environments and math."
  ()
  :url "https://github.com/cdominik/cdlatex"
  :commit "b7183c2200392b6d85fca69390f4a65fac7a7b19"
  :revdesc "b7183c220039"
  :keywords '("tex")
  :authors '(("Carsten Dominik" . "carsten.dominik@gmail.com"))
  :maintainers '(("Carsten Dominik" . "carsten.dominik@gmail.com")))
