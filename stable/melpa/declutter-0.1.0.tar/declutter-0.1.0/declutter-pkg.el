;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "declutter" "0.1.0"
  "Read html content and paywall sites without clutter."
  ()
  :url "http://www.github.com/sanel/declutter"
  :commit "426760126ab2d8300059cc9d2d808b7eb4ce9c7c"
  :revdesc "426760126ab2"
  :keywords '("html" "web browser")
  :authors '(("Sanel Zukan" . "sanelz@gmail.com"))
  :maintainers '(("Sanel Zukan" . "sanelz@gmail.com")))
