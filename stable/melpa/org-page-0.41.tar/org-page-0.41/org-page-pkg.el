;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-page" "0.41"
  "Static site generator based on org mode."
  ()
  :url "https://github.com/kelvinh/org-page"
  :commit "09febf89d8dcb226aeedf8164169b31937b64439"
  :revdesc "09febf89d8dc"
  :keywords '("org-mode" "convenience" "beautify")
  :authors '(("Kelvin Hu" . "iniDOTkelvinATgmailDOTcom"))
  :maintainers '(("Kelvin Hu" . "iniDOTkelvinATgmailDOTcom")))
