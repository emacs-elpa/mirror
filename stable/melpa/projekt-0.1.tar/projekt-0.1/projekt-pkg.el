;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projekt" "0.1"
  "Some kind of staging for CVS."
  '((emacs "24"))
  :url "https://github.com/tekai/projekt"
  :commit "107232c191375b59d065354470d0af83062e2a4c"
  :revdesc "107232c19137"
  :authors '(("Engelke Eschner" . "tekai@gmx.li"))
  :maintainers '(("Engelke Eschner" . "tekai@gmx.li")))
