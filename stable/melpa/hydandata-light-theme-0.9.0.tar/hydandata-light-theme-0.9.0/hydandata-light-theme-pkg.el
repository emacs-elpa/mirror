;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hydandata-light-theme" "0.9.0"
  "A light color theme that is easy on your eyes."
  ()
  :url "https://github.com/chkhd/hydandata-light-theme"
  :commit "3b9bb5f213029a8331818b1d670194ef26d9505a"
  :revdesc "3b9bb5f21302"
  :keywords '("color-theme" "theme")
  :authors '(("David Chkhikvadze" . "david.chk@outlook.com"))
  :maintainers '(("David Chkhikvadze" . "david.chk@outlook.com")))
