;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pip-requirements" "0.5"
  "A major mode for editing pip requirements files."
  '((dash "2.8.0"))
  :url "https://github.com/Wilfred/pip-requirements.el"
  :commit "93e0595f037e3a95c1c1cd6f00f7e052a9a25912"
  :revdesc "93e0595f037e"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
