;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-lint" "1.0.0"
  "Async indentation checker."
  '((emacs       "26.1")
    (async-await "1.0")
    (async       "1.9.4"))
  :url "https://github.com/conao3/indent-lint.el"
  :commit "5601a716d4daeb444642736ddef420cbc1047968"
  :revdesc "5601a716d4da"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
