;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jekyll-modes" "0.0.1"
  "Major modes (markdown and HTML) for authoring Jekyll content."
  '((polymode "0.2"))
  :url "https://github.com/fred-o/jekyll-modes"
  :commit "b3611287cb568e76509f9b737650bd5574364f75"
  :revdesc "b3611287cb56"
  :keywords '("docs")
  :authors '(("Fredrik Appelberg" . "fredrik@milgrim.local"))
  :maintainers '(("Fredrik Appelberg" . "fredrik@milgrim.local")))
