;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "deno-fmt" "0.2.0"
  "Minor mode for using deno fmt on save."
  '((emacs "24"))
  :url "https://github.com/russell/deno-emacs"
  :commit "6378966f448a3b9b5ae98af58cd13a031bd26702"
  :revdesc "6378966f448a"
  :authors '(("Russell Clarey" . "http://github/rclarey"))
  :maintainers '(("Russell Clarey" . "http://github/rclarey")))
