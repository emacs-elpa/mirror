;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-suggest" "0.0.0.20200911.30"
  "Company-mode back-end for search engine suggests."
  '((company "0.9.0")
    (emacs   "25.1"))
  :url "https://github.com/juergenhoetzel/company-suggest"
  :commit "1c89c9de3852f07ce28b0bedf1fbf56fe6eedcdc"
  :revdesc "1c89c9de3852"
  :keywords '("completion" "convenience")
  :authors '(("Jürgen Hötzel" . "juergen@archlinux.org"))
  :maintainers '(("Jürgen Hötzel" . "juergen@archlinux.org")))
