;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gh-md" "0.1.1"
  "Render markdown using the Github api."
  '((emacs "24"))
  :url "https://github.com/emacs-pe/gh-md.el"
  :commit "693cb0dcadff70e813e1a9d303d227aff7898557"
  :revdesc "693cb0dcadff"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
