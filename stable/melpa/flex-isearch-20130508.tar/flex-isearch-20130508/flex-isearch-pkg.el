;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-isearch" "20130508"
  "Flex matching (like ido) in isearch."
  ()
  :url "https://bitbucket.org/jpkotta/flex-isearch"
  :commit "454806c5627d7013f7053a97e2c5550ff8346344"
  :revdesc "454806c5627d"
  :keywords '("convenience" "search")
  :authors '(("Jonathan Kotta" . "jpkotta@gmail.com"))
  :maintainers '(("Jonathan Kotta" . "jpkotta@gmail.com")))
