;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-growthforecast" "0.0.0.20140120.12"
  "Helm extensions for growthforecast."
  '((helm "1.5.9"))
  :url "https://github.com/daic-h/helm-growthforecast"
  :commit "0f94ac090d6c354058ad89a86e5c18385c136d9b"
  :revdesc "0f94ac090d6c"
  :authors '(("Daichi Hirata" . "daichi.hirat@gmail.com"))
  :maintainers '(("Daichi Hirata" . "daichi.hirat@gmail.com")))
