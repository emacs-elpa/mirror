;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iscroll" "1.0.0"
  "Smooth scrolling over images."
  '((emacs "26.0"))
  :url "https://github.com/casouri/iscroll"
  :commit "b31c3a787920a8a20d9ca1a694418b73ddc39c54"
  :revdesc "b31c3a787920"
  :keywords '("convenience" "image")
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
