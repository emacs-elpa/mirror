;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "1.0.1"
  "Integration for the command-line tool `fasd'."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "fe0d6c611ec995e2f59b23d45af3b8b28244703b"
  :revdesc "1.0.1-0-gfe0d6c611ec9"
  :keywords '("convenience"))
