;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-variable" "0.0.2"
  "Store project local variables."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/zonuexe/projectile-variable"
  :commit "8d348ac70bdd6dc320c13a12941b32b38140e264"
  :revdesc "8d348ac70bdd"
  :keywords '("project" "convenience")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
