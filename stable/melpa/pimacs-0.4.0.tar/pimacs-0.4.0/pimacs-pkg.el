;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.4.0"
  "Emacs Client for Pi."
  '((emacs         "29.1")
    (compat        "31.0")
    (markdown-mode "2.8")
    (timeout       "2.1.7")
    (pcre2el       "1.12")
    (spinner       "1.7")
    (transient     "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "2b88c7d5f0fcdd2e540a8d42ddd150ccf7ba3be0"
  :revdesc "2b88c7d5f0fc"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
