;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modular-config" "0.0.5"
  "Organize your config into small and loadable modules."
  '((emacs "24.3"))
  :url "https://github.com/SidharthArya/modular-config.el"
  :commit "3c78fde6b7c53857c712408691427536d3c891bc"
  :revdesc "3c78fde6b7c5"
  :keywords '("startup" "lisp" "tools")
  :authors '(("Sidharth Arya" . "sidhartharya10@gmail.com"))
  :maintainers '(("Sidharth Arya" . "sidhartharya10@gmail.com")))
