;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-denote" "2.2.1"
  "Minor mode integrating Citar and Denote."
  '((emacs  "28.1")
    (citar  "1.4")
    (denote "2.0")
    (dash   "2.19.1"))
  :url "https://github.com/pprevos/citar-denote"
  :commit "4586e030445ff40a4939fe0ecc1aae667825052d"
  :revdesc "4586e030445f"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
