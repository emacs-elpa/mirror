;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-emms" "1.3"
  "Emms for Helm."
  '((helm   "1.5")
    (emms   "0.0")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/emacs-helm/helm-emms"
  :commit "d7da090af0f63b92c5d735197992c732adbeef3d"
  :revdesc "v1.3-0-gd7da090af0f6")
