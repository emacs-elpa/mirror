;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wasp-mode" "0.0.1"
  "A major mode for the Wasp programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/wasp-mode"
  :commit "905cd18b74346e960df6f5d675bc45c908cef7b6"
  :revdesc "905cd18b7434"
  :keywords '("files" "wasp"))
