;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-after-load" "0.1"
  "[No description available]."
  ()
  :url "https://github.com/pd/easy-after-load"
  :commit "914fbf05ca84e988ae971f4955c124b03228f544"
  :revdesc "914fbf05ca84")
