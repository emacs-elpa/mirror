;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sozluk" "1.0.0"
  "An online Turkish dictionary."
  '((emacs "27.1")
    (dash  "2.11.0"))
  :url "https://github.com/isamert/sozluk.el"
  :commit "65e4bf64f5115b86b8cabe596586c3aea25e4710"
  :revdesc "65e4bf64f511"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
