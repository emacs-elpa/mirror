;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "almost-mono-themes" "1.0.0"
  "Almost monochromatic color themes."
  '((emacs "24"))
  :url "https://github.com/cryon/almost-mono-themes"
  :commit "dda909ec58b77767ce981812c6a41fce4167f9b0"
  :revdesc "dda909ec58b7"
  :keywords '("faces")
  :authors '(("John Olsson" . "john@cryon.se"))
  :maintainers '(("John Olsson" . "john@cryon.se")))
