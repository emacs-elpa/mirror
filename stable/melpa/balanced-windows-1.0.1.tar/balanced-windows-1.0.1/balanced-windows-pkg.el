;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "balanced-windows" "1.0.1"
  "Keep windows balanced."
  '((emacs "25"))
  :url "https://github.com/wbolster/emacs-balanced-windows"
  :commit "1da5354ad8a9235d13928e2ee0863f3642ccdd13"
  :revdesc "1.0.1-0-g1da5354ad8a9"
  :keywords '("convenience")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
