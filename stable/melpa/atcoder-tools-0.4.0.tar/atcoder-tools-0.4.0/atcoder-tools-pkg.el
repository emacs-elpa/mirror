;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atcoder-tools" "0.4.0"
  "An atcoder-tools client."
  '((emacs "26")
    (f     "0.20")
    (s     "1.12"))
  :url "https://github.com/sei40kr/atcoder-tools"
  :commit "780fabbe5b3c890b3ae764e26b188603be294daa"
  :revdesc "780fabbe5b3c"
  :keywords '("extensions" "tools")
  :authors '(("Seong Yong-ju" . "sei40kr@gmail.com"))
  :maintainers '(("Seong Yong-ju" . "sei40kr@gmail.com")))
