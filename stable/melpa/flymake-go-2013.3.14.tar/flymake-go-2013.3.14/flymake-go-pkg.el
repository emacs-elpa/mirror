;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-go" "2013.3.14"
  "A flymake handler for go-mode files."
  '((flymake "0.4.13"))
  :url "https://github.com/robert-zaremba/flymake-go"
  :commit "d2036ece024ad8dbc43a3a94f0b4a36b4f95b5ed"
  :revdesc "d2036ece024a"
  :keywords '("go" "flymake")
  :authors '(("Michael Fellinger" . "michael@iron.io")
             ("Robert Zaremba" . "robert.marek.zaremba@wp.eu"))
  :maintainers '(("Michael Fellinger" . "michael@iron.io")
                 ("Robert Zaremba" . "robert.marek.zaremba@wp.eu")))
