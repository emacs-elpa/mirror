;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "1.7.6"
  "A set of eye pleasing themes."
  '((emacs      "26.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "34e66cd23407abfee60153dd39f4701ba37e1861"
  :revdesc "34e66cd23407"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
