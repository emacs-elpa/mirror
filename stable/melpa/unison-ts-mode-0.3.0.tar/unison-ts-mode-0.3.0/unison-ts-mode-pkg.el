;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison-ts-mode" "0.3.0"
  "Tree-sitter support for Unison."
  '((emacs "29.1"))
  :url "https://github.com/fmguerreiro/unison-ts-mode"
  :commit "626e1575386f9ed996004ecce2e5672cc2583c18"
  :revdesc "v0.3.0-0-g626e1575386f"
  :keywords '("languages" "unison" "tree-sitter")
  :authors '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com"))
  :maintainers '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com")))
