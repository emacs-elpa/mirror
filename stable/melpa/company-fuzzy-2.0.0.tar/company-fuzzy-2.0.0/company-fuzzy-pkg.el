;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-fuzzy" "2.0.0"
  "Fuzzy matching for `company-mode'."
  '((emacs   "26.1")
    (company "0.8.12")
    (s       "1.12.0")
    (ht      "2.0"))
  :url "https://github.com/jcs-elpa/company-fuzzy"
  :commit "a359f5556ee1c989f6c111e35ab6be81c609f52c"
  :revdesc "a359f5556ee1"
  :keywords '("matching" "auto-complete" "complete" "fuzzy")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
