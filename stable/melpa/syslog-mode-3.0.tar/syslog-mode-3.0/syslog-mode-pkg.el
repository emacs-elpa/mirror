;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syslog-mode" "3.0"
  "Major-mode for viewing log files & strace output."
  '((hide-lines "20130623")
    (ov         "20150311"))
  :url "https://github.com/vapniks/syslog-mode"
  :commit "014d78269daa99937fb4fa8f5d34e2b3eb368a5f"
  :revdesc "3.0-0-g014d78269daa"
  :keywords '("unix")
  :authors '(("Harley Gorrell" . "harley@panix.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
