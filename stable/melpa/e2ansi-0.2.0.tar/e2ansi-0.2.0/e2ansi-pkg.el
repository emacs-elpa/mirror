;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2ansi" "0.2.0"
  "Syntax highlighting for `less', powered by Emacs."
  '((face-explorer "0.0.6"))
  :url "https://github.com/Lindydancer/e2ansi"
  :commit "53c9c2aff5bf66864446a02a75e2e431aaef59d5"
  :revdesc "53c9c2aff5bf"
  :keywords '("faces" "languages"))
