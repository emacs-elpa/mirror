;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-ycmd" "1.2"
  "Flycheck integration for ycmd."
  '((emacs     "24")
    (dash      "2.13.0")
    (flycheck  "0.22")
    (ycmd      "1.2")
    (let-alist "1.0.5"))
  :url "https://github.com/abingham/emacs-ycmd"
  :commit "d042a673b4d717c3ca9d641f120bfe16c994c740"
  :revdesc "d042a673b4d7"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
