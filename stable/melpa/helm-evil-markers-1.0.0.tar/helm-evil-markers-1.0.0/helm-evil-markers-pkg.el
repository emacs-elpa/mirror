;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-evil-markers" "1.0.0"
  "Show evil markers with helm."
  '((emacs "24.4")
    (helm  "2.0.0")
    (evil  "1.2.10"))
  :url "https://github.com/xueeinstein/helm-evil-markers"
  :commit "29f9288a73370f26fe431db1472ed948bd63190d"
  :revdesc "29f9288a7337"
  :keywords '("extensions"))
