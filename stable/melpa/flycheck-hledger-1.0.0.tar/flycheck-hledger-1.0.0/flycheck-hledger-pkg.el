;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-hledger" "1.0.0"
  "Flycheck module to check hledger journals."
  '((emacs    "27.1")
    (flycheck "31"))
  :url "https://github.com/DamienCassou/flycheck-hledger/"
  :commit "87ed9d4ce448f84f10a5348d8d89d9467ee720ff"
  :revdesc "v1.0.0-0-g87ed9d4ce448"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
