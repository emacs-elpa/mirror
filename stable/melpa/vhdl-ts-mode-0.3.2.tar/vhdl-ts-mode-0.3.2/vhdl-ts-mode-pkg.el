;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ts-mode" "0.3.2"
  "VHDL Tree-sitter major mode."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/vhdl-ts-mode"
  :commit "9da613a72aa7caaa32b11f4de6f2e778bfb9376c"
  :revdesc "9da613a72aa7"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
