;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-babel-eval-in-repl" "1.6"
  "Eval org-mode babel code blocks in various REPLs."
  '((eval-in-repl "0.9.2")
    (matlab-mode  "3.3.6")
    (ess          "16.10")
    (emacs        "24"))
  :url "https://github.com/diadochos/org-babel-eval-in-repl"
  :commit "3591f062873de2d64cc6f83b3555d030506e6ee7"
  :revdesc "3591f062873d"
  :keywords '("literate programming" "reproducible research" "async execution")
  :authors '(("Takeshi Teshima" . "diadochos.developer@gmail.com"))
  :maintainers '(("Takeshi Teshima" . "diadochos.developer@gmail.com")))
