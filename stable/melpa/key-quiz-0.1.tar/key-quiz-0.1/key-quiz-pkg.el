;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-quiz" "0.1"
  "Emacs Keys Quiz."
  '((emacs "26"))
  :url "https://github.com/federicotdn/key-quiz"
  :commit "f706a20903efa9a9f58e0f4f36adafd8c584c473"
  :revdesc "f706a20903ef"
  :keywords '("games")
  :authors '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers '(("Federico Tedin" . "federicotedin@gmail.com")))
