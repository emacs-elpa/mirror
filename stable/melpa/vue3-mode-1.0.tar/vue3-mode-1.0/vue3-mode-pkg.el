;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vue3-mode" "1.0"
  "Syntax highlighting for modern Vue.js 3."
  '((polymode      "0")
    (vue-html-mode "0"))
  :url "https://github.com/vsalvino/vue3-mode"
  :commit "fa3a0e024a15ffac86307ae3a2b92190498c53cb"
  :revdesc "fa3a0e024a15"
  :keywords '("languages" "vue")
  :authors '(("Vince Salvino" . "mvsalvino@gmail.com"))
  :maintainers '(("Vince Salvino" . "mvsalvino@gmail.com")))
