;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asciidoc-mode" "0.1.0"
  "Major mode for AsciiDoc markup."
  '((emacs "30.1"))
  :url "https://github.com/bbatsov/asciidoc-mode"
  :commit "4b5e89bedc0453e63147e08cdd759cbf2e31be26"
  :revdesc "4b5e89bedc04"
  :keywords '("text" "asciidoc" "languages" "tree-sitter")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
