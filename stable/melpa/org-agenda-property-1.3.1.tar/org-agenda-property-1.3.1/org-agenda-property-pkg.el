;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-agenda-property" "1.3.1"
  "Display org properties in the agenda buffer."
  '((emacs "24.2"))
  :url "https://github.com/Bruce-Connor/org-agenda-property"
  :commit "2ff628a14a3e758863bbd88fba4db9f77fd2c3a8"
  :revdesc "2ff628a14a3e"
  :keywords '("calendar")
  :authors '(("Artur Malabarba" . "bruce.connor.am@gmail.com"))
  :maintainers '(("Artur Malabarba" . "bruce.connor.am@gmail.com")))
