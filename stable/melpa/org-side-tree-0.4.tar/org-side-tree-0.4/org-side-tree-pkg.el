;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-side-tree" "0.4"
  "Navigate Org outlines in side window tree."
  '((emacs "27.2"))
  :url "https://github.com/localauthor/org-side-tree"
  :commit "c9ba0edb9628081f93a8f7c992cc05ba21e2f1fa"
  :revdesc "c9ba0edb9628"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
