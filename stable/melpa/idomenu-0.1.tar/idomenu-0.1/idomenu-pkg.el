;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idomenu" "0.1"
  "Imenu tag selection with ido."
  ()
  :url "https://github.com/birkenfeld/idomenu"
  :commit "5daaf7e06e4704ae43c825488109d7eb8c049321"
  :revdesc "5daaf7e06e47"
  :keywords '("extensions" "convenience")
  :authors '(("Georg Brandl" . "georg@python.org"))
  :maintainers '(("Georg Brandl" . "georg@python.org")))
