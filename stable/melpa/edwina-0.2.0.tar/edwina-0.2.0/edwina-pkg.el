;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edwina" "0.2.0"
  "Dynamic window manager."
  '((emacs "25"))
  :url "https://github.com/ajgrf/edwina"
  :commit "cc0a039a400e8ef07b0d96d2169f1407e0af107a"
  :revdesc "cc0a039a400e"
  :keywords '("convenience")
  :authors '(("Alex Griffin" . "a@ajgrf.com"))
  :maintainers '(("Alex Griffin" . "a@ajgrf.com")))
