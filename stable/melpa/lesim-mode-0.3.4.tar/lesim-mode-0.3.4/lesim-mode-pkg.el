;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lesim-mode" "0.3.4"
  "Major mode for Learning Simulator scripts."
  '((emacs "28.1"))
  :url "https://github.com/drghirlanda/lesim-mode"
  :commit "214989864d3499f5c6e96dfa67ba7b3cf06a085e"
  :revdesc "214989864d34"
  :keywords '("languages" "faces")
  :authors '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainers '(("Stefano Ghirlanda" . "drghirlanda@gmail.com")))
