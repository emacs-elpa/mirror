;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-grimoire" "0.1.0"
  "Emacs-native static site generator."
  '((emacs "30.2")
    (org   "9.7.11"))
  :url "https://github.com/spiperac/org-grimoire"
  :commit "0a15e6be54ded80882b4b25d00c48c29b34f4692"
  :revdesc "v0.1.0-0-g0a15e6be54de"
  :keywords '("files" "hypermedia" "outlines" "text")
  :authors '(("Strahinja Piperac" . "sp@spiperac.dev"))
  :maintainers '(("Strahinja Piperac" . "sp@spiperac.dev")))
