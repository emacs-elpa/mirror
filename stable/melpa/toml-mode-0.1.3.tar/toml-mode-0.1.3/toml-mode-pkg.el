;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml-mode" "0.1.3"
  "Mojor mode for editing TOML files."
  ()
  :url "https://github.com/dryman/toml-mode"
  :commit "57e6bd69c9e842f8c630f288fbbe06285eb0109f"
  :revdesc "57e6bd69c9e8"
  :keywords '("data" "toml")
  :authors '(("Felix Chern" . "idryman@gmail.com"))
  :maintainers '(("Felix Chern" . "idryman@gmail.com")))
