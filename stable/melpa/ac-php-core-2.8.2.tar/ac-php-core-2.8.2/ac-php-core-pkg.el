;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "2.8.2"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "579063ac92f3cba9816edd31f24c759aac3a64b2"
  :revdesc "v2.8.2-0-g579063ac92f3"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
