;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-mff" "1.2.0"
  "Mouse Follows Focus."
  '((emacs "25"))
  :url "https://github.com/ieure/exwm-mff"
  :commit "c3a132164ea5fdcaa9df49d8a115eab0481ee342"
  :revdesc "c3a132164ea5"
  :keywords '("unix")
  :authors '(("Ian Eure" . "public@lowbar.fyi"))
  :maintainers '(("Ian Eure" . "public@lowbar.fyi")))
