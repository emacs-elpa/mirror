;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eyuml" "0.1.0"
  "Write textual uml diagram from emacs using yuml.me."
  '((request "0.2.0")
    (s       "1.8.0"))
  :url "https://github.com/antham/eyuml"
  :commit "8357061024604ff91c5a5d2b6e5936016f0b832f"
  :revdesc "835706102460"
  :keywords '("uml")
  :authors '(("Anthony HAMON" . "hamon.anth@gmail.com"))
  :maintainers '(("Anthony HAMON" . "hamon.anth@gmail.com")))
