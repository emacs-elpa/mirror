;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sweetgreen" "0.5"
  "Order Salads from sweetgreen.com."
  '((dash    "2.12.1")
    (helm    "1.5.6")
    (request "0.2.0")
    (cl-lib  "0.5"))
  :url "https://www.github.com/CestDiego/sweetgreen.el"
  :commit "e40d2821ff941695e50a9b003a8c96d32c19bfdc"
  :revdesc "v0.5-0-ge40d2821ff94"
  :keywords '("salad" "food" "sweetgreen" "request")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")))
