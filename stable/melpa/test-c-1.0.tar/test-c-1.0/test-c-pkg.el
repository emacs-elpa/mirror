;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-c" "1.0"
  "Quickly test c code."
  ()
  :url "https://github.com/aaptel/test-c"
  :commit "44a7e9618f2516944e360fd01320ee555ce0ca3d"
  :revdesc "44a7e9618f25"
  :authors '(("Aurélien Aptel" . "aurelien.aptel@gmail.com"))
  :maintainers '(("Aurélien Aptel" . "aurelien.aptel@gmail.com")))
