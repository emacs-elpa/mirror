;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-grammalecte" "2.5"
  "Integrate Grammalecte with Flycheck."
  '((emacs    "29.1")
    (flycheck "32"))
  :url "https://git.umaneti.net/flycheck-grammalecte/"
  :commit "4b50d794a88d31c43023bed78f1815673f0c8890"
  :revdesc "v2.5-0-g4b50d794a88d"
  :keywords '("i18n" "text")
  :authors '(("Guilhem Doulcier" . "guilhem.doulcier@espci.fr")
             ("tienne Pflieger" . "etienne@pflieger.bzh")))
