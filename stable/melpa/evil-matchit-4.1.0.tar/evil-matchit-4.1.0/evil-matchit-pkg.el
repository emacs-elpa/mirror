;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-matchit" "4.1.0"
  "Vim matchit ported to Evil."
  '((emacs "27.1"))
  :url "https://github.com/redguardtoo/evil-matchit"
  :commit "8d0bca76ed9958fc5ad460e6085175c83695bbdb"
  :revdesc "8d0bca76ed99"
  :keywords '("matchit" "vim" "evil")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
