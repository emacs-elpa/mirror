;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clean-kill-ring" "2.6"
  "Keep the kill ring clean."
  '((emacs "24.4"))
  :url "https://github.com/NicholasBHubbard/clean-kill-ring.el"
  :commit "60172fc644d68c55b1c15c7fe1a09a63589a1d43"
  :revdesc "60172fc644d6"
  :keywords '("kill-ring" "convenience")
  :authors '(("Nicholas Hubbard" . "nicholashubbard@posteo.net"))
  :maintainers '(("Nicholas Hubbard" . "nicholashubbard@posteo.net")))
