;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mode-icons" "0.4.0"
  "Show icons for modes."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "http://ryuslash.org/projects/mode-icons.html"
  :commit "37581ed911e4469f773ddfb7b40a85592d323b76"
  :revdesc "0.4.0-0-g37581ed911e4"
  :keywords '("multimedia")
  :authors '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainers '(("Tom Willemse" . "tom@ryuslash.org")))
