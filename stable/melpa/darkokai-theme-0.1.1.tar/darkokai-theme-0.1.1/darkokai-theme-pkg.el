;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darkokai-theme" "0.1.1"
  "A darker variant on Monokai."
  ()
  :url "https://github.com/sjrmanning/darkokai"
  :commit "94f845d0194bfd45e6a3c17222bba19aece9dd63"
  :revdesc "94f845d0194b")
