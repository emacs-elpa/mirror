;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime-volleyball" "1.1"
  "An SVG Slime Volleyball Game."
  ()
  :url "https://github.com/fitzsim/slime-volleyball"
  :commit "159b5c0f40b109e3854e94b89ec5383854c46ae3"
  :revdesc "v1.1-0-g159b5c0f40b1"
  :keywords '("games")
  :authors '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org"))
  :maintainers '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org")))
