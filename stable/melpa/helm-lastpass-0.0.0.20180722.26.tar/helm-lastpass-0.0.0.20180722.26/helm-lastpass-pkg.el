;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-lastpass" "0.0.0.20180722.26"
  "Helm interface of LastPass."
  '((emacs "25.1")
    (helm  "2.0")
    (csv   "2.1"))
  :url "https://github.com/xuchunyang/helm-lastpass"
  :commit "82e1ffb6ae77d9d9e29c398eb013cd20ce963f77"
  :revdesc "82e1ffb6ae77"
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
