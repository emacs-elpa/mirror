;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotation" "2.8.0"
  "Functions for annotating text with faces and help bubbles."
  ()
  :url "https://github.com/agda/agda"
  :commit "3d04bacca842729f9c0869b9287256321b5f450f"
  :revdesc "v2.8.0-0-g3d04bacca842")
