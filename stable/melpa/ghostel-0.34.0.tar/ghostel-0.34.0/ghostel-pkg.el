;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.34.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f7800f6430b6ab85dbfc2db2129625e8a28ac17e"
  :revdesc "f7800f6430b6"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
