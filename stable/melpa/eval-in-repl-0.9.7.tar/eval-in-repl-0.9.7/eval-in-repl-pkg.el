;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eval-in-repl" "0.9.7"
  "Consistent ESS-like eval interface for various REPLs."
  '((dash       "0.0.0")
    (paredit    "0.0.0")
    (ace-window "0.0.0"))
  :url "https://github.com/kaz-yos/eval-in-repl"
  :commit "c8e5f31a2476c922857d921e367b6a2320ce5a6f"
  :revdesc "c8e5f31a2476"
  :keywords '("tools" "convenience")
  :authors '(("Kazuki YOSHIDA" . "kazukiyoshida@mail.harvard.edu"))
  :maintainers '(("Kazuki YOSHIDA" . "kazukiyoshida@mail.harvard.edu")))
