;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wisp-mode" "1.0.13"
  "Tools for wisp: the Whitespace-to-Lisp preprocessor."
  '((emacs "24.4"))
  :url "http://www.draketo.de/english/wisp"
  :commit "de5543e8e0b3bf05f3db552e71e0ed52169f0307"
  :revdesc "v1.0.13-0-mde5543e8e0b3"
  :keywords '("languages" "lisp" "scheme")
  :authors '(("Arne Babenhauserheide" . "arne_bab@web.de"))
  :maintainers '(("Arne Babenhauserheide" . "arne_bab@web.de")))
