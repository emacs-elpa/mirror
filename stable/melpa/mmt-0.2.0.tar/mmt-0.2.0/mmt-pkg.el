;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mmt" "0.2.0"
  "Missing macro tools for Emacs Lisp."
  '((emacs  "24.1")
    (cl-lib "0.3"))
  :url "https://github.com/mrkkrp/mmt"
  :commit "f7db836a10720ee50217012e7e2597ebcf624f90"
  :revdesc "f7db836a1072"
  :keywords '("macro" "emacs-lisp")
  :authors '(("Mark Karpov" . "markkarpov@openmailbox.org"))
  :maintainers '(("Mark Karpov" . "markkarpov@openmailbox.org")))
