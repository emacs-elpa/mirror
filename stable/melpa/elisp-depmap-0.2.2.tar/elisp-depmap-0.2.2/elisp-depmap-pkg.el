;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-depmap" "0.2.2"
  "Generate an elisp dependency map in graphviz."
  '((emacs "26.1")
    (dash  "20250312.1307"))
  :url "https://github.com/mtekman/elisp-depmap.el"
  :commit "eacd4a331e553cf3b1f39fa32fa1a7516517d4c3"
  :revdesc "eacd4a331e55"
  :keywords '("outlines"))
