;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iflipb" "1.6"
  "Interactively flip between recently visited buffers."
  ()
  :url "https://github.com/jrosdahl/iflipb"
  :commit "67e33073b4f42de9fc4df76bc04ec8b31aca02ea"
  :revdesc "1.6-0-g67e33073b4f4"
  :authors '(("Joel Rosdahl" . "joel@rosdahl.net"))
  :maintainers '(("Joel Rosdahl" . "joel@rosdahl.net")))
