;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hg-histedit" "20190609"
  "Edit HG histedit files."
  '((emacs       "25.1")
    (with-editor "20190511.1157"))
  :url "https://github.com/jojojames/hg-histedit"
  :commit "4f3ce96eb0f485a61917fc065f8b37535f720fdb"
  :revdesc "4f3ce96eb0f4"
  :keywords '("mercurial" "hg" "emacs" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
