;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-moccur" "2.71"
  "Multi-buffer occur (grep) mode."
  ()
  :url "http://www.bookshelf.jp/elc/color-moccur.el"
  :commit "0b622b649b63fe7e3f01dba995037337f8e9c344"
  :revdesc "0b622b649b63"
  :keywords '("convenience")
  :authors '(("Akihisa" . "akihisa@mail.ne.jp"))
  :maintainers '(("Akihisa" . "akihisa@mail.ne.jp")))
