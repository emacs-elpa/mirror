;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sml-modeline" "0.5"
  "Show position in a scrollbar like way in mode-line."
  ()
  :url "http://bazaar.launchpad.net/~nxhtml/nxhtml/main/annotate/head%3A/util/sml-modeline.el"
  :commit "d2f9f70174c4cf68c67eb3bb8088235735e34d9a"
  :revdesc "d2f9f70174c4")
