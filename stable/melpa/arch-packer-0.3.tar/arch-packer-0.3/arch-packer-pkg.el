;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arch-packer" "0.3"
  "Arch Linux package management frontend."
  '((emacs "25.1")
    (s     "1.11.0")
    (async "1.9.2")
    (dash  "2.12.0"))
  :url "https://github.com/brotzeitmacher/arch-packer"
  :commit "afb9447cba6b2f840ca4f81a89643081b2e773e5"
  :revdesc "afb9447cba6b"
  :authors '(("Fritz Stelzer" . "brotzeitmacher@gmail.com"))
  :maintainers '(("Fritz Stelzer" . "brotzeitmacher@gmail.com")))
