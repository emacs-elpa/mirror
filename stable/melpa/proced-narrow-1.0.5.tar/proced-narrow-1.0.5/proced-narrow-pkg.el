;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proced-narrow" "1.0.5"
  "Live-narrowing of search results for proced."
  '((seq   "2.20")
    (emacs "24"))
  :url "https://github.com/travisjeffery/proced-narrow"
  :commit "df5cce50b3d1219b23d28e23cbf68e0c7807a15c"
  :revdesc "df5cce50b3d1"
  :keywords '("processes" "proced")
  :authors '(("Travis Jeffery" . "tj@travisjeffery.com"))
  :maintainers '(("Travis Jeffery" . "tj@travisjeffery.com")))
