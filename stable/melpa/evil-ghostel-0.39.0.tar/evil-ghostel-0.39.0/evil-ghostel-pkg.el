;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "0.39.0"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.8.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "92bfcc57dc85f254ce95dcb51dbdd2411fea5f02"
  :revdesc "92bfcc57dc85"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
