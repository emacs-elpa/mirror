;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mode-line-path" "0.1.0"
  "Abbreviate file paths in the mode line."
  '((emacs "28.1"))
  :url "https://github.com/arthurgleckler/mode-line-path"
  :commit "5abaa19194469647031c52cb8f0e64b16d7f9427"
  :revdesc "5abaa1919446"
  :keywords '("convenience")
  :authors '(("Arthur A. Gleckler" . "melpa4aag@speechcode.com"))
  :maintainers '(("Arthur A. Gleckler" . "melpa4aag@speechcode.com")))
