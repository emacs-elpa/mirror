;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yesterbox" "0.2"
  "Count number of inbox messages by day."
  '((emacs "24.3"))
  :url "https://github.com/sje30/yesterbox"
  :commit "45d1314f0988aa4b6a664831969bd6f8f1d8eaaa"
  :revdesc "45d1314f0988"
  :keywords '("mail")
  :authors '(("Stephen J. Eglen" . "sje30@cam.ac.uk"))
  :maintainers '(("Stephen J. Eglen" . "sje30@cam.ac.uk")))
