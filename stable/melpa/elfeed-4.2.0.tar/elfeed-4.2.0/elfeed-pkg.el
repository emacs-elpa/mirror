;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.2.0"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "737c1d6d2649b1ff82c5e2d2d9891a7caeac3835"
  :revdesc "4.2.0-0-g737c1d6d2649"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
