;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stock-ticker" "0.1"
  "Show stock prices in mode line."
  '((s               "1.9.0")
    (dash            "2.10.0")
    (dash-functional "1.2.0")
    (cl-lib          "0.3")
    (emacs           "24"))
  :url "https://github.com/hagleitn/stock-ticker"
  :commit "7d7a977aab42c76256ff2f902a6eabbe676afb6a"
  :revdesc "7d7a977aab42"
  :keywords '("comms"))
