;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-wordcloud" "0.1"
  "Generate a word cloud."
  '((emacs  "28.1")
    (denote "4.1.3"))
  :url "https://codeberg.org/treflip/denote-wordcloud"
  :commit "f41a41e391fa4131e91fc0e58814962cc3310f1c"
  :revdesc "f41a41e391fa"
  :keywords '("files" "help")
  :authors '(("Alexander Kuzmin" . "treflcrew@gmail.org"))
  :maintainers '(("Alexander Kuzmin" . "treflcrew@gmail.org")))
