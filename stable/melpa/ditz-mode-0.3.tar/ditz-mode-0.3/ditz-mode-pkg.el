;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ditz-mode" "0.3"
  "Emacs interface to Ditz issue tracking system."
  ()
  :commit "0551468fc738470e4bbce28f036347273a864bb9"
  :revdesc "0.3-0-m0551468fc738"
  :keywords '("tools")
  :authors '(("Glenn Hutchings" . "zondo42@googlemail.com"))
  :maintainers '(("Glenn Hutchings" . "zondo42@googlemail.com")))
