;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-x" "0.3.1"
  "Extra convenience features for project.el."
  '((emacs "27.1"))
  :url "https://github.com/vmargb/project-x"
  :commit "e6a308d86367160ada4e89900015a37ccf3c7e1b"
  :revdesc "e6a308d86367"
  :keywords '("project" "convenience" "session" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("vmargb" . "https://github.com/vmargb")))
