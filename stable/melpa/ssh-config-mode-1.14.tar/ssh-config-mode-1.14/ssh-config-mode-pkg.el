;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ssh-config-mode" "1.14"
  "Mode for fontification of ~/.ssh/config."
  '((emacs "24.3"))
  :url "https://github.com/jhgorrell/ssh-config-mode-el"
  :commit "f57450bdf0e2cc8126529d52cba2ae927d5113b3"
  :revdesc "f57450bdf0e2"
  :keywords '("comm" "files")
  :authors '(("Harley Gorrell" . "harley@panix.com"))
  :maintainers '(("Harley Gorrell" . "harley@panix.com")))
