;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dianyou" "0.0.3"
  "Search and analyze mails in Gnus."
  '((emacs "24.4"))
  :url "https://github.com/redguardtoo/dianyou"
  :commit "1a1fe6da3196f91db7b76b6c552ca4f2629e36bf"
  :revdesc "1a1fe6da3196"
  :keywords '("mail")
  :authors '(("Chen Bin" . "chenbinDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmailDOTcom")))
