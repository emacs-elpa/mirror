;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "attrap" "1.2"
  "ATtempt To Repair At Point."
  '((dash  "2.12.0")
    (emacs "25.1")
    (f     "0.19.0")
    (s     "1.11.0"))
  :url "https://github.com/jyp/attrap"
  :commit "2cb8d146635a4e1fb92a027551253629c6f55a1b"
  :revdesc "2cb8d146635a"
  :keywords '("programming" "tools")
  :authors '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com"))
  :maintainers '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com")))
