;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddgr" "0.1"
  "DuckDuckGo search."
  '((emacs "27.1"))
  :url "https://github.com/necaris/ddgr.el"
  :commit "5757df2d050b9d789459366f9b2caa39337188e9"
  :revdesc "5757df2d050b"
  :keywords '("comm" "duckduckgo" "search" "web")
  :authors '(("Rami Chowdhury" . "rami.chowdhury@gmail.com"))
  :maintainers '(("Rami Chowdhury" . "rami.chowdhury@gmail.com")))
