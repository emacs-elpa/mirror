;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gsettings" "1.0.0"
  "GSettings (Gnome) helpers."
  '((emacs    "24.3")
    (dash     "2.16.0")
    (gvariant "1.0.0")
    (s        "1.12.0"))
  :url "https://github.com/wbolster/emacs-gsettings"
  :commit "1dd9a6a3036d76d8e680b2764c35b31bf5e6aff7"
  :revdesc "1.0.0-0-g1dd9a6a3036d"
  :keywords '("languages")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
