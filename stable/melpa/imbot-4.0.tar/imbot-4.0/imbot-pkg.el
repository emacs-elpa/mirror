;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "4.0"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "929efe2e1e9bc6cfa8ce64d981cd9236cd8f9aae"
  :revdesc "929efe2e1e9b"
  :keywords '("convenience" "input method" "dbus"))
