;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org2blog" "1.1.18"
  "Blog from Org mode to WordPress."
  '((emacs          "29.4")
    (htmlize        "1.56")
    (hydra          "0.15.0")
    (xml-rpc        "1.6.15")
    (writegood-mode "2.2.0")
    (metaweblog     "1.1.18"))
  :url "https://github.com/org2blog/org2blog"
  :commit "175244a0b7dae8211cf42c17a51c35e9236eda71"
  :revdesc "v1.1.18-0-g175244a0b7da"
  :keywords '("comm" "convenience" "outlines" "wp")
  :authors '(("Puneeth Chaganti" . "punchagan+org2blog@gmail.com"))
  :maintainers '(("Grant Rettke" . "grant@wisdomandwonder.com")))
