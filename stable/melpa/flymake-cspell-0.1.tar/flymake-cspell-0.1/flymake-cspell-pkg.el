;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-cspell" "0.1"
  "A Flymake backend for CSpell."
  '((emacs "26.1"))
  :url "https://github.com/fritzgrabo/flymake-cspell"
  :commit "5ab6e6f7724dd37b98c325ceefffdd6c0bcb91b8"
  :revdesc "5ab6e6f7724d"
  :keywords '("wp")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
