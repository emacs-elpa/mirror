;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bencode" "1.0"
  "Bencode encoding / decoding."
  '((emacs "26.1"))
  :url "https://github.com/skeeto/emacs-bencode"
  :commit "b6f8e1c1fecbbde9dfd62c3216307ac4413ab185"
  :revdesc "b6f8e1c1fecb"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
