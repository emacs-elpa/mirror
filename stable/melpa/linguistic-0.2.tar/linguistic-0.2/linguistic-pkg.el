;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linguistic" "0.2"
  "A package for basic linguistic analysis."
  ()
  :url "https://github.com/andcarnivorous/linguistic"
  :commit "18e28a7e54efb140c17e16836bc5dac766c9522e"
  :revdesc "18e28a7e54ef"
  :keywords '("linguistics" "text analysis" "matching")
  :authors '(("Andrew Favia" . "drewlinguistics01atgmaildotcom"))
  :maintainers '(("Andrew Favia" . "drewlinguistics01atgmaildotcom")))
