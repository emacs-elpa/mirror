;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soft-stone-theme" "0.2"
  "Emacs 24 theme with a light background."
  '((emacs "24"))
  :url "https://github.com/mswift42/soft-stone-theme"
  :commit "b45f35a5cafa634241b30d957b7a0a8f3ad51f47"
  :revdesc "b45f35a5cafa")
