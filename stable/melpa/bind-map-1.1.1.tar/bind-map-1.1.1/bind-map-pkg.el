;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bind-map" "1.1.1"
  "Bind personal keymaps in multiple locations."
  '((emacs "24.3"))
  :url "https://github.com/justbur/emacs-bind-map"
  :commit "bf4181e3a41463684adfffc6c5c305b30480e30f"
  :revdesc "bf4181e3a414"
  :authors '(("Justin Burkett" . "justin@burkett.cc"))
  :maintainers '(("Justin Burkett" . "justin@burkett.cc")))
