;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plsense" "0.4.7"
  "Provide interface for PlSense that is a development tool for Perl."
  '((auto-complete "1.4.0")
    (log4e         "0.2.0")
    (yaxception    "0.2.0"))
  :url "https://github.com/aki2o/emacs-plsense"
  :commit "f6fb22607a5252b2556d2e7fa14f1bcab5d9747a"
  :revdesc "f6fb22607a52"
  :keywords '("perl" "completion")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
