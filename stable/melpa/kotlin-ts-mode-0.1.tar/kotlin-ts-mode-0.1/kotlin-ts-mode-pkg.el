;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kotlin-ts-mode" "0.1"
  "A mode for editing Kotlin files based on tree-sitter."
  '((emacs "29"))
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode"
  :commit "0ea89e94d3901dd430de54ebccf834d09208986d"
  :revdesc "0ea89e94d390"
  :authors '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers '(("Alex Figl-Brick" . "alex@alexbrick.me")))
