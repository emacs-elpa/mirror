;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elhome" "0.9.1"
  "A framework for a \"home\" Emacs configuration."
  '((initsplit "20120630"))
  :url "https://github.com/demyanrogozhin/elhome"
  :commit "eeb34a937c79a9ab78be984d8f9042b68b3ba6ff"
  :revdesc "eeb34a937c79"
  :keywords '("lisp")
  :authors '(("Dave Abrahams" . "dave@boostpro.com"))
  :maintainers '(("Demyan Rogozhin" . "demyan.rogozhin@gmail.com")))
