;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-habit-stats" "0.1"
  "Display info about habits."
  '((emacs "25.1"))
  :url "https://github.com/ml729/org-habit-stats/"
  :commit "bd77e7d8cab4451e9aa949b453284063a9333148"
  :revdesc "bd77e7d8cab4"
  :keywords '("calendar" "org-mode" "org-habit" "habits" "stats" "statistics" "charts" "graphs"))
