;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-emoticons" "0.1"
  "Shortcuts for common unicode emoticons."
  ()
  :url "https://github.com/hagleitn/unicode-emoticons"
  :commit "de062652f701fe391c7172b18bc37c31d28b1d3e"
  :revdesc "de062652f701"
  :keywords '("games" "entertainment" "comms"))
