;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sync-recentf" "1.0"
  "Synchronize the recent files list between Emacs instances."
  ()
  :url "https://github.com/ffevotte/sync-recentf"
  :commit "34a676ac6991382d0c28fd4c772b8b7db53cf522"
  :revdesc "34a676ac6991"
  :keywords '("recentf")
  :authors '(("François Févotte" . "fevotte@gmail.com"))
  :maintainers '(("François Févotte" . "fevotte@gmail.com")))
