;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gif-screencast" "1.2"
  "One-frame-per-action GIF recording."
  '((emacs "25.1"))
  :url "https://gitlab.com/ambrevar/emacs-gif-screencast"
  :commit "fa81e915c256271fa10b807a2935d5eaa4700dff"
  :revdesc "fa81e915c256"
  :keywords '("multimedia" "screencast")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
