;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jonprl-mode" "0.0.1"
  "A major mode for editing JonPRL files."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/david-christiansen/jonprl-mode"
  :commit "0dde2d03b0fab8e286ebebbca012f8b96f049efd"
  :revdesc "0dde2d03b0fa"
  :keywords '("languages")
  :authors '(("David Raymond Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Raymond Christiansen" . "david@davidchristiansen.dk")))
