;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "waher-theme" "20141115.2020"
  "Emacs 24 theme based on waher for st2 by dduckster."
  '((emacs "24.1"))
  :url "https://github.com/jasonm23/emacs-waher-theme"
  :commit "60d31519fcfd8e797723d47961b255ae2f2e2c0a"
  :revdesc "60d31519fcfd"
  :authors '(("Jasonm23" . "jasonm23@gmail.com"))
  :maintainers '(("Jasonm23" . "jasonm23@gmail.com")))
