;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-elixir" "2.3.0"
  "Run an interactive Elixir shell."
  '((emacs "25.1"))
  :url "https://github.com/J3RN/inf-elixir"
  :commit "857210b83f3c6a68673222c1271c40cb0b5641bc"
  :revdesc "857210b83f3c"
  :keywords '("languages" "processes" "tools")
  :authors '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainers '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com")))
