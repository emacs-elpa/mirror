;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sublimity" "20160629"
  "Smooth-scrolling, minimap and distraction-free mode."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "ee9c9fbb92b8fc0c191e5e8640477e251b602bf9"
  :revdesc "ee9c9fbb92b8")
