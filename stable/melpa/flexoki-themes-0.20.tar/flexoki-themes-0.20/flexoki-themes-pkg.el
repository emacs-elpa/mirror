;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flexoki-themes" "0.20"
  "An inky color scheme for prose and code."
  '((emacs "27.1"))
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme"
  :commit "1b871e57e989d58a793cbfef7b4996a6bd47ba9f"
  :revdesc "1b871e57e989"
  :keywords '("faces" "theme")
  :authors '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers '(("Andrew Jose" . "arnav.jose@gmail.com")))
