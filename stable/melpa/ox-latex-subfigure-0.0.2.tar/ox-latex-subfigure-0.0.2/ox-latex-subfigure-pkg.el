;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-latex-subfigure" "0.0.2"
  "Subfigure for latex export."
  ()
  :url "https://github.com/linktohack/ox-latexty-subfigure"
  :commit "b7445849ae1f16b4b28f7a080301a0a61edf1c83"
  :revdesc "b7445849ae1f"
  :keywords '("ox" "latex" "subfigure" "org" "org-mode")
  :authors '(("Quang Linh LE" . "linktohack@gmail.com"))
  :maintainers '(("Quang Linh LE" . "linktohack@gmail.com")))
