;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-imports" "20180325.1"
  "Insert go import statement given package name."
  ()
  :url "https://github.com/yasushi-saito/go-imports"
  :commit "7955b820668af7380e65b418e66e445729ea8ef3"
  :revdesc "7955b820668a"
  :keywords '("tools" "go" "import"))
