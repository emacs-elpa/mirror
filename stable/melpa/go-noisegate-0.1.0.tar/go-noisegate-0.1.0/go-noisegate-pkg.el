;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-noisegate" "0.1.0"
  "Emacs plugin for Noise Gate."
  '((emacs "24.4"))
  :url "https://github.com/go-noisegate/go-noisegate.el"
  :commit "78b0f280841dbc833ed5411a293095f0affdaad7"
  :revdesc "78b0f280841d"
  :keywords '("languages" "go" "test"))
