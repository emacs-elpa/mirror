;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "0.5.5"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "0ccfffef530802698447ce4f549477e724ab8710"
  :revdesc "0ccfffef5308"
  :keywords '("languages"))
