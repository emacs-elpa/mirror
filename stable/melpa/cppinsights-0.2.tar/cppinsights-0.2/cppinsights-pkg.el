;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cppinsights" "0.2"
  "Integration with cppinsights tool."
  '((emacs "28.1"))
  :url "https://github.com/chrischen3121/cppinsights.el"
  :commit "3d9586af70400987382349154bd3ad05ebe2b454"
  :revdesc "3d9586af7040"
  :keywords '("c++" "tools" "cppinsights")
  :authors '(("Chris Chen" . "chrischen@ignity.xyz"))
  :maintainers '(("Chris Chen" . "chrischen@ignity.xyz")))
