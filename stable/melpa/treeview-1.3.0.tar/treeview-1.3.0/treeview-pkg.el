;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treeview" "1.3.0"
  "A generic tree navigation library."
  '((emacs "29.1"))
  :url "https://github.com/tilmanrassy/emacs-treeview"
  :commit "f8b678ba1dd52171002585bfc13921a509658af3"
  :revdesc "v1.3.0-0-gf8b678ba1dd5"
  :keywords '("lisp" "tools" "internal" "convenience")
  :authors '(("Tilman Rassy" . "tilman.rassy@googlemail.com"))
  :maintainers '(("Tilman Rassy" . "tilman.rassy@googlemail.com")))
