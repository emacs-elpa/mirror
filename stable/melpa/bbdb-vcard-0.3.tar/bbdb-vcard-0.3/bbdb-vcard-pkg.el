;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbdb-vcard" "0.3"
  "VCard import/export for BBDB."
  ()
  :url "https://github.com/trebb/bbdb-vcard"
  :commit "9e11fafef1a94bc6395bd1eeacd00f94848ac560"
  :revdesc "0.3-0-g9e11fafef1a9"
  :keywords '("data" "calendar" "mail" "news")
  :authors '(("Bert Burgemeister" . "trebbu@googlemail.com"))
  :maintainers '(("Bert Burgemeister" . "trebbu@googlemail.com")))
