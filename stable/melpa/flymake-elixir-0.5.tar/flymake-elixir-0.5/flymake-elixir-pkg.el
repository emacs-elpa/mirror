;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-elixir" "0.5"
  "A flymake handler for elixir-mode .ex files."
  ()
  :url "https://github.com/syl20bnr/flymake-elixir"
  :commit "3810566cffe35d04cc3f01e27fe397d68d52f802"
  :revdesc "3810566cffe3"
  :authors '(("Sylvain Benner" . "syl20bnr@gmail.com"))
  :maintainers '(("Sylvain Benner" . "syl20bnr@gmail.com")))
