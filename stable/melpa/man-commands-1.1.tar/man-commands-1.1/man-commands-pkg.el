;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "man-commands" "1.1"
  "Add interactive commands for every manpages installed in your computer."
  ()
  :url "https://github.com/nflath/man-commands"
  :commit "0a5091bf1d27eb2c220c90b8e20cffd0784a2211"
  :revdesc "0a5091bf1d27"
  :authors '(("Nathaniel Flath" . "nflath@gmail.com"))
  :maintainers '(("Nathaniel Flath" . "nflath@gmail.com")))
