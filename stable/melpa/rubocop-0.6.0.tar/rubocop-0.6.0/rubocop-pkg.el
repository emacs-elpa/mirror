;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rubocop" "0.6.0"
  "An Emacs interface for RuboCop."
  '((emacs "24"))
  :url "https://github.com/bbatsov/rubocop-emacs"
  :commit "608a3c1dccab9a3af467ce75d94dedfbfd37b21d"
  :revdesc "608a3c1dccab"
  :keywords '("project" "convenience"))
