;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.1"))
  :url "https://github.com/jojojames/fzfa"
  :commit "83a11c5dcbbe7720fdb8cde971247d53911939aa"
  :revdesc "83a11c5dcbbe"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
