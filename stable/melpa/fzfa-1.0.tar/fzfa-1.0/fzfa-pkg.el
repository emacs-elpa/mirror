;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "0.3"))
  :url "https://github.com/jojojames/fzf-async"
  :commit "7efa40b29c0e720a3be54a54dd7ccf8a43a2ae4f"
  :revdesc "7efa40b29c0e"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
