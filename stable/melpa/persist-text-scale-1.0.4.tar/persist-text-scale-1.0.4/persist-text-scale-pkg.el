;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "1.0.4"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "8098af6ba9ff251d19f9e41b39c84f7b9b758f26"
  :revdesc "1.0.4-0-g8098af6ba9ff"
  :keywords '("convenience"))
