;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-dbus" "1.1.0"
  "Monitor org-clock from outside Emacs."
  '((emacs "28.1")
    (org   "9.6.0"))
  :url "https://github.com/pjones/org-clock-db"
  :commit "5c418f60e5b0b5bc0e0071cf127e592dccf26d97"
  :revdesc "v1.1.0-0-g5c418f60e5b0"
  :keywords '("org")
  :authors '(("Peter J. Jones" . "pjones@devalot.com"))
  :maintainers '(("Peter J. Jones" . "pjones@devalot.com")))
