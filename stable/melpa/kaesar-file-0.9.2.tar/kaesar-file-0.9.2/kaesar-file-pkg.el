;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaesar-file" "0.9.2"
  "AES encrypt/decrypt file."
  '((emacs  "24.3")
    (kaesar "0.1.1"))
  :url "https://github.com/mhayashi1120/Emacs-kaesar"
  :commit "75655238e0dcdb77a74d685cc4f3368fcd284020"
  :revdesc "75655238e0dc"
  :keywords '("data" "files")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
