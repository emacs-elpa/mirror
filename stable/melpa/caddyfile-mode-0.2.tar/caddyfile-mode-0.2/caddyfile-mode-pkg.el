;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "caddyfile-mode" "0.2"
  "Major mode for Caddy configuration files."
  '((emacs "24.3"))
  :url "https://github.com/Schnouki/caddyfile-mode/"
  :commit "b0371063adc18d3cbd6dd673ea4fe39d27825d1b"
  :revdesc "v0.2-0-gb0371063adc1"
  :keywords '("languages")
  :authors '(("Thomas Jost" . "schnouki@schnouki.net"))
  :maintainers '(("Thomas Jost" . "schnouki@schnouki.net")))
