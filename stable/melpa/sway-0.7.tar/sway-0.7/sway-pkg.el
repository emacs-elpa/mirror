;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sway" "0.7"
  "Communication with the Sway window manager."
  '((emacs "28.1"))
  :url "https://github.com/thblt/sway.el"
  :commit "425005713af1e9269f1d5b5221fb4ea3046f52e4"
  :revdesc "0.7-0-g425005713af1"
  :keywords '("frames")
  :authors '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainers '(("Thibault Polge" . "thibault@thb.lt")))
