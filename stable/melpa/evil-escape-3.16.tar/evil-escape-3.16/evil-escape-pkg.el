;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-escape" "3.16"
  "Escape from anything with a customizable key sequence."
  '((emacs  "24")
    (evil   "1.0.9")
    (cl-lib "0.5"))
  :url "https://github.com/emacsorphanage/evil-escape"
  :commit "3c335a5709b1abb08687960038746b36add465f9"
  :revdesc "3c335a5709b1"
  :keywords '("convenience" "editing" "evil")
  :authors '(("Sylvain Benner" . "sylvain.benner@gmail.com"))
  :maintainers '(("Sylvain Benner" . "sylvain.benner@gmail.com")))
