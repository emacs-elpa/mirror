;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scihub" "0.1"
  "Sci-Hub integration."
  '((emacs "25"))
  :url "https://github.com/emacs-pe/scihub.el"
  :commit "a32e8f47961d606c1315a972f2dab4d3a61945af"
  :revdesc "a32e8f47961d"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
