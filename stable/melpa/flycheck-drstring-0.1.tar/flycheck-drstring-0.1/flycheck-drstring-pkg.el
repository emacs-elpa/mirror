;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-drstring" "0.1"
  "Doc linting for Swift using DrString."
  '((flycheck "0.25"))
  :url "https://github.com/danielmartin/flycheck-drstring"
  :commit "9d677e2e05bfd179fe3cff998703bf2ebff366a1"
  :revdesc "9d677e2e05bf"
  :authors '(("Daniel Martín" . "mardani29@yahoo.es"))
  :maintainers '(("Daniel Martín" . "mardani29@yahoo.es")))
