;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "list-unicode-display" "0.1"
  "Search for and list unicode characters by name."
  '((cl-lib "0.5"))
  :url "https://github.com/purcell/list-unicode-display"
  :commit "59770cf3572bd36c3e9ba044846dc420c0dca09b"
  :revdesc "59770cf3572b"
  :keywords '("convenience")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
