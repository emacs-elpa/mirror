;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pine-script-mode" "3.5.4"
  "Major mode for TradingView Pine Script v6 and older."
  '((emacs "24"))
  :url "https://github.com/ericcrosson/pine-script-mode"
  :commit "203ba62b1c36620dc59a85c5f6084037db48b146"
  :revdesc "203ba62b1c36"
  :keywords '("extensions")
  :authors '(("Eric Crosson" . "eric.s.crosson@utexas.edu"))
  :maintainers '(("Eric Crosson" . "eric.s.crosson@utexas.edu")))
