;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abl-mode" "0.9.4"
  "Python TDD minor mode."
  ()
  :url "https://github.com/afroisalreadyinu/abl-mode"
  :commit "e918290b279112c367787ac704398d66759e5298"
  :revdesc "e918290b2791"
  :authors '(("Ulas Tuerkmen" . "ulas.tuerkmenatgmaildotcom"))
  :maintainers '(("Ulas Tuerkmen" . "ulas.tuerkmenatgmaildotcom")))
