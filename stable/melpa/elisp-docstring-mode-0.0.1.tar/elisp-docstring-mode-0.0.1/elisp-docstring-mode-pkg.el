;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-docstring-mode" "0.0.1"
  "Major mode for editing elisp docstrings."
  ()
  :url "https://github.com/Fuco1/elisp-docstring-mode"
  :commit "dc9bd423d954db2dcd64ae20bc57e0057215780d"
  :revdesc "dc9bd423d954"
  :keywords '("languages")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
