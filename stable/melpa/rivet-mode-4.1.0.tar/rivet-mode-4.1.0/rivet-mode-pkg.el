;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rivet-mode" "4.1.0"
  "A minor mode for editing Apache Rivet files."
  '((emacs    "24")
    (web-mode "16"))
  :url "https://gitlab.com/thornjad/rivet-mode"
  :commit "6cf58cf04fee933113857af07414b3f27c24b505"
  :revdesc "6cf58cf04fee")
