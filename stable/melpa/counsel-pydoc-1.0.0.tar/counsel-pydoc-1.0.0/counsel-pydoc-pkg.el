;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-pydoc" "1.0.0"
  "Run pydoc with counsel."
  '((emacs  "24.3")
    (swiper "0.9.0"))
  :url "https://github.com/co-dh/pydoc_utils"
  :commit "f38341260655e5dead1b4ccdde438c6c857ea9bc"
  :revdesc "f38341260655"
  :keywords '("completion" "matching")
  :authors '(("Hao" . "Deng(denghao8888@gmail.com)"))
  :maintainers '(("Hao" . "Deng(denghao8888@gmail.com)")))
