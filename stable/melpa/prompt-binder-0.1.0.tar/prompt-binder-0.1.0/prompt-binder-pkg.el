;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prompt-binder" "0.1.0"
  "Bind LLM prompts to key chords and editor context."
  '((emacs "24.3")
    (llm   "0.26.0"))
  :url "https://github.com/tracym"
  :commit "abdbe7f081b694fab79dbb1114fa6228010bed2c"
  :revdesc "abdbe7f081b6"
  :keywords '("llm" "tools" "prompt"))
