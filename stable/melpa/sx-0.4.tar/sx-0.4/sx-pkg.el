;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sx" "0.4"
  "StackExchange client. Ask and answer questions on Stack Overflow, Super User, and the likes."
  '((emacs         "24.1")
    (cl-lib        "0.5")
    (json          "1.3")
    (markdown-mode "2.0")
    (let-alist     "1.0.3"))
  :url "https://github.com/vermiculus/sx.el/"
  :commit "4892f45746fb217d059f4fa074a237c5bac7dd6c"
  :revdesc "4892f45746fb"
  :keywords '("help" "hypermedia" "tools")
  :authors '(("Sean Allred" . "code@seanallred.com"))
  :maintainers '(("Sean Allred" . "code@seanallred.com")))
