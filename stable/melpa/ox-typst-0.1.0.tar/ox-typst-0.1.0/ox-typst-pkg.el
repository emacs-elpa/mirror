;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-typst" "0.1.0"
  "Typst Back-End for Org Export Engine."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://github.com/jmpunkt/ox-typst"
  :commit "1930b42defbb06da79f58ec2e44fdf92f2596c30"
  :revdesc "1930b42defbb"
  :keywords '("text" "org" "typst"))
