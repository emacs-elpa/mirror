;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-shell" "0.0.0.20161125.20"
  "Major mode for an inferior Julia shell."
  '((julia-mode "0.3"))
  :url "https://github.com/dennisog/julia-shell-mode"
  :commit "583a0b2ca20461ab4356929fd0f2212c22341b69"
  :revdesc "583a0b2ca204"
  :authors '(("Dennis Ogbe" . "dogbe@purdue.edu"))
  :maintainers '(("Dennis Ogbe" . "dogbe@purdue.edu")))
