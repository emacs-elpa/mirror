;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thanks" "1.0"
  "Say thanks to the authors of all your installed packages."
  '((emacs "25.1")
    (gh    "20230825"))
  :url "https://github.com/FrostyX/thanks"
  :commit "f2d6473ea3a3ed5608b4f9b6982865a20286ad9b"
  :revdesc "f2d6473ea3a3"
  :keywords '("tools")
  :authors '(("Jakub Kadlčík" . "frostyx@email.cz"))
  :maintainers '(("Jakub Kadlčík" . "frostyx@email.cz")))
