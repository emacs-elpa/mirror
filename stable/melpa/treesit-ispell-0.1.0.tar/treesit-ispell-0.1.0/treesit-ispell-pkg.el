;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-ispell" "0.1.0"
  "Run ispell on tree-sitter text nodes."
  '((emacs "29.1"))
  :url "https://github.com/erickgnavar/treesit-ispell.el"
  :commit "e1572b408ea49490f5abc5f0bb8852dfe30331e5"
  :revdesc "e1572b408ea4"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
