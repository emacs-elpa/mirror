;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-w3m" "1.0"
  "W3m bookmark - helm interface."
  '((helm   "1.5")
    (w3m    "0.0")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/emacs-helm/helm-w3m"
  :commit "280673470672c9fbc57fd6a91defeb9f6641fc8a"
  :revdesc "v1.0-0-g280673470672")
