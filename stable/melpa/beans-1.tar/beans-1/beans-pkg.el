;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beans" "1"
  "Major mode for Beans grammar."
  '((emacs "24.3"))
  :url "https://github.com/TheBlackBeans/emacs-beans"
  :commit "d63c9eb6a7e74760d0cddbc6f0b7ac34e2e402ce"
  :revdesc "d63c9eb6a7e7")
