;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "all-the-icons-nerd-fonts" "0.2"
  "Nerd font integration for all-the-icons."
  '((emacs         "28.0")
    (all-the-icons "5.0")
    (nerd-icons    "0.0.1"))
  :url "https://github.com/mohkale/all-the-icons-nerd-fonts"
  :commit "a400dd82d612d403ab2f70ec90e64dab3c942b5d"
  :revdesc "a400dd82d612"
  :keywords '("convenience" "lisp")
  :authors '(("Mohsin Kaleem" . "mohkale@gmail.com"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@gmail.com")))
