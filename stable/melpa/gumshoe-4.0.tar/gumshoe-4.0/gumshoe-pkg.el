;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gumshoe" "4.0"
  "Scoped spatial and temporal POINT movement tracking."
  '((emacs "27.1"))
  :url "https://github.com/Overdr0ne/gumshoe"
  :commit "331e365834963db8890001800cd9d6933252922e"
  :revdesc "331e36583496"
  :keywords '("tools"))
