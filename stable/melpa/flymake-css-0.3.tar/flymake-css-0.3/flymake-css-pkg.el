;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-css" "0.3"
  "Flymake support for css using csslint."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-css"
  :commit "3e56d47d3c53e39741aa4f702bb9fb827cce22ed"
  :revdesc "3e56d47d3c53"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
