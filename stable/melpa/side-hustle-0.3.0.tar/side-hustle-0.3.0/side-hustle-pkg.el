;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "side-hustle" "0.3.0"
  "Hustle through Imenu in a side window."
  '((emacs "24.4")
    (seq   "2.20"))
  :url "https://github.com/rnkn/side-hustle"
  :commit "0ac8dfa02ddd33cfa0e3cff834b68e32185db9ee"
  :revdesc "0ac8dfa02ddd"
  :keywords '("convenience")
  :authors '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainers '(("Paul W. Rankin" . "hello@paulwrankin.com")))
