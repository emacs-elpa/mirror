;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-ansi" "0.2"
  "Display diff's using alternative diffing tools."
  '((emacs "27.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi"
  :commit "71336e614e3150c47c58f99f2df10a3af73370ac"
  :revdesc "71336e614e31"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
