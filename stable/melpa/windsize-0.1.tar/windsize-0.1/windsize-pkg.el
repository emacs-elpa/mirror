;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "windsize" "0.1"
  "Simple, intuitive window resizing."
  ()
  :url "https://github.com/grammati/windsize"
  :commit "014b0836f9ffe45fa7e0ccc84576fbef74815a59"
  :revdesc "014b0836f9ff"
  :keywords '("window" "resizing" "convenience")
  :authors '(("Chris Perkins" . "chrisperkins99@gmail.com"))
  :maintainers '(("Chris Perkins" . "chrisperkins99@gmail.com")))
