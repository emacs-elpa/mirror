;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sauron" "0.10"
  "A frame tracking events inside and outside your emacs buffers."
  ()
  :url "https://github.com/djcb/sauron"
  :commit "a9877f0efa9418c41d25002b58d1c2f8c69ec975"
  :revdesc "a9877f0efa94"
  :keywords '("comm" "frames")
  :authors '(("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl"))
  :maintainers '(("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl")))
