;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yang-mode" "0.9.9"
  "Major mode for editing YANG files."
  ()
  :url "https://github.com/mbj4668/yang-mode"
  :commit "4b4ab4d4a79d37d6c31c6ea7cccbc425e0b1eded"
  :revdesc "4b4ab4d4a79d"
  :authors '(("Martin Bjorklund" . "mbj4668@gmail.com"))
  :maintainers '(("Martin Bjorklund" . "mbj4668@gmail.com")))
