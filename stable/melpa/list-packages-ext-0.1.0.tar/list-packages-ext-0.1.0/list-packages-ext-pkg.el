;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "list-packages-ext" "0.1.0"
  "Extras for list-packages."
  '((s               "1.6.0")
    (ht              "1.5.0")
    (persistent-soft "0.8.6"))
  :url "https://github.com/laynor/list-packages-ext"
  :commit "344719b313c208c644490f8f1130e21405402f05"
  :revdesc "344719b313c2"
  :keywords '("convenience" "tools")
  :authors '(("Alessandro Piras" . "laynor@gmail.com"))
  :maintainers '(("Alessandro Piras" . "laynor@gmail.com")))
