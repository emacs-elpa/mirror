;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "make-it-so" "0.1.0"
  "Transform file with Makefile recipes."
  ()
  :url "https://github.com/abo-abo/make-it-so"
  :commit "7940510ad4e6c1c3acc807f8d6b5a719c470f8b4"
  :revdesc "7940510ad4e6"
  :keywords '("make" "dired")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
