;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "1.32.2"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.31.1")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "b98cb4a904b70def4f21050d5d202005ee00b3b4"
  :revdesc "b98cb4a904b7"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
