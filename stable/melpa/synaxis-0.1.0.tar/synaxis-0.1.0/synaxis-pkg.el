;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "synaxis" "0.1.0"
  "Feed reader with SQLite storage."
  '((emacs        "29.1")
    (keymap-popup "0.2.1"))
  :url "https://codeberg.org/thanosapollo/synaxis"
  :commit "2bb622ffe4b8cd746baac2297a208ef6908b2193"
  :revdesc "2bb622ffe4b8"
  :keywords '("news" "hypermedia" "rss" "atom")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
