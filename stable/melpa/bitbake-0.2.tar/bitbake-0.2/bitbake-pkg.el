;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbake" "0.2"
  "Running bitbake from emacs."
  '((emacs    "25")
    (dash     "2.6.0")
    (polymode "20260505.1803")
    (s        "1.10.0"))
  :url "https://github.com/danielcmccarthy/bitbake-el"
  :commit "2fb57e5c0d016da90d4f8f8049a56a240cf8a1a3"
  :revdesc "2fb57e5c0d01"
  :keywords '("tools" "convenience"))
