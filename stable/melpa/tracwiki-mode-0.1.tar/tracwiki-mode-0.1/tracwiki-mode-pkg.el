;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tracwiki-mode" "0.1"
  "Emacs Major mode for working with Trac."
  ()
  :url "https://github.com/merickson/tracwiki-mode"
  :commit "d2e54b73fe0eb8563b6b3defe9a52335fd500aca"
  :revdesc "d2e54b73fe0e"
  :keywords '("trac" "wiki" "tickets")
  :authors '(("Matthew Erickson" . "peawee@peawee.net"))
  :maintainers '(("Matthew Erickson" . "peawee@peawee.net")))
