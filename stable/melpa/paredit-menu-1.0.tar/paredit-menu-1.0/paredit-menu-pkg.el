;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paredit-menu" "1.0"
  "Adds a menu to paredit.el as memory aid."
  ()
  :url "https://github.com/phillord/paredit-menu"
  :commit "fa35e0f60e50f755860947d3a27e840d309a375b"
  :revdesc "fa35e0f60e50"
  :keywords '("paredit")
  :authors '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
  :maintainers '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk")))
