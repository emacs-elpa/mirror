;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recover-buffers" "1.0"
  "Revisit all buffers from an auto-save file."
  ()
  :url "https://github.com/tripleee/recover-buffers"
  :commit "a1db7f084977697081da3497628e3514e032b966"
  :revdesc "1.0-0-ga1db7f084977"
  :authors '(("era eriksson" . "http://www.iki.fi/era"))
  :maintainers '(("era eriksson" . "http://www.iki.fi/era")))
