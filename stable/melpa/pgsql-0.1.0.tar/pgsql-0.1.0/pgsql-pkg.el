;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "0.1.0"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "e672f64520040c96d667d7a1861ebd7b3953c8e2"
  :revdesc "e672f6452004"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
