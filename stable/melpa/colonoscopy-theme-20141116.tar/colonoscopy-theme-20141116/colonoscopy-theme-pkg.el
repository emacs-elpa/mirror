;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colonoscopy-theme" "20141116"
  "An Emacs 24 theme based on Colonoscopy (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "77dee0a1f0c2277f037e9a810fe95612d1638898"
  :revdesc "77dee0a1f0c2")
