;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "0.0.1"
  "Agentic LLM use for gptel."
  '((emacs "28.1")
    (gptel "0.9.9")
    (yaml  "1.2.0"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "5688a121c4f351cbb5640f8d42e22a2f3570228b"
  :revdesc "5688a121c4f3"
  :keywords '("convenience" "tools"))
