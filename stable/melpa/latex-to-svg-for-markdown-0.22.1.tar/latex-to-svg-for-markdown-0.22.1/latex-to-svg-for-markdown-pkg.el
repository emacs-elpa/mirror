;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-markdown" "0.22.1"
  "Preview Markdown LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.22.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "5138b537e57cf1e994956b146309551886b29e89"
  :revdesc "v0.22.1-0-g5138b537e57c"
  :keywords '("tex" "markdown" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
