;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inkpot-theme" "0.1"
  "Port of vim's inkpot theme."
  ()
  :url "https://github.com/siovan/emacs24-inkpot.git"
  :commit "de745de9ab7f67431a5ce493a63be68d408ec40e"
  :revdesc "de745de9ab7f"
  :authors '(("Sarah Iovan" . "sarah@hwaetageek.com"))
  :maintainers '(("Sarah Iovan" . "sarah@hwaetageek.com")))
