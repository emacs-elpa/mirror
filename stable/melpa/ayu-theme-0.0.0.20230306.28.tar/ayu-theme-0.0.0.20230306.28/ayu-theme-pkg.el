;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ayu-theme" "0.0.0.20230306.28"
  "Ayu theme."
  '((emacs "24.1"))
  :url "https://github.com/vutran1710/Ayu-Theme-Emacs"
  :commit "dc325520c1202463a0f05d4ece1644109830fef4"
  :revdesc "dc325520c120"
  :keywords '("lisp" "theme" "emacs"))
