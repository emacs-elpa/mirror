;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verb" "3.2.0"
  "Organize and send HTTP requests."
  '((emacs "26.3"))
  :url "https://github.com/federicotdn/verb"
  :commit "81aa67dffb17b3d88b35f16787aa3292d5761abb"
  :revdesc "3.2.0-0-g81aa67dffb17"
  :keywords '("tools")
  :authors '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers '(("Federico Tedin" . "federicotedin@gmail.com")))
