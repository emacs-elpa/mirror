;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "horoscope" "2.0"
  "Generate horoscopes."
  '((emacs "24"))
  :url "https://github.com/mschuldt/horoscope.el"
  :commit "78b728d78b19c973661d304e96d5306a0c1fbce3"
  :revdesc "78b728d78b19"
  :keywords '("extensions" "games")
  :authors '(("Bob Manson" . "manson@cygnus.com"))
  :maintainers '(("Noah Friedman" . "friedman@prep.ai.mit.edu")))
