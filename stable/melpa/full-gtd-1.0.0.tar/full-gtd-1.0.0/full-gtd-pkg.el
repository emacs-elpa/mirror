;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "1.0.0"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "27.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "f824e725ebb1df05b918f866c60dec74dbb0f18a"
  :revdesc "f824e725ebb1"
  :keywords '("outlines" "tools" "convenience" "org" "todo" "gtd" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
