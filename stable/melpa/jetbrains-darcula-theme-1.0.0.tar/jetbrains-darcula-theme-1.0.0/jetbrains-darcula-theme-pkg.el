;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jetbrains-darcula-theme" "1.0.0"
  "A complete port of the default JetBrains Darcula theme."
  ()
  :url "https://github.com/ianpan870102/jetbrains-darcula-emacs-theme"
  :commit "05ee1876d58e7858b4526bdcd3ed5ef5e0a67ddf"
  :revdesc "05ee1876d58e")
