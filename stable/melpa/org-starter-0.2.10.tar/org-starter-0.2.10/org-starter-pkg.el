;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-starter" "0.2.10"
  "A basic configuration framework for org mode."
  '((emacs "25.1")
    (dash  "2.18"))
  :url "https://github.com/akirak/org-starter"
  :commit "cd9c5c0402de941299d1c8901f26a8f24d755022"
  :revdesc "cd9c5c0402de"
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
