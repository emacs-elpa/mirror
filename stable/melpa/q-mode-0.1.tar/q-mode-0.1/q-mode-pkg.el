;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.1"
  "A q editing mode."
  ()
  :url "https://github.com/psaris/q-mode"
  :commit "cb377632ea39af608b838184f84bd6578f2d0e7f"
  :revdesc "cb377632ea39"
  :keywords '("faces" "files" "q"))
