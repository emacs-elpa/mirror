;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-cstyle" "0.1"
  "Integrate cstyle with flycheck."
  '((flycheck "0.24")
    (emacs    "24.4"))
  :url "https://github.com/alexmurray/flycheck-cstyle"
  :commit "8272047325f403e70bebb5ab6bed6eb43a3e6da4"
  :revdesc "8272047325f4"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
