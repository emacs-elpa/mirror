;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "libelcouch" "0.11.0"
  "Communication with CouchDB."
  '((emacs   "26.1")
    (request "0.3.0"))
  :url "https://gitlab.petton.fr/elcouch/libelcouch/"
  :commit "5ae35266c9a2eb33f0c708bc8c0687339cee9133"
  :revdesc "5ae35266c9a2"
  :keywords '("tools")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
