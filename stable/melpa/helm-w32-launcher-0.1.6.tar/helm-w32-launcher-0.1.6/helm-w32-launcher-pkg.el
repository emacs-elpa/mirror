;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-w32-launcher" "0.1.6"
  "Start Menu entry launcher using Helm."
  '((emacs  "24")
    (helm   "1.6.5")
    (cl-lib "0.5"))
  :url "https://github.com/Fanael/helm-w32-launcher"
  :commit "01aa370a32900e7521330fba495474f2aa435e19"
  :revdesc "01aa370a3290"
  :authors '(("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers '(("Fanael Linithien" . "fanael4@gmail.com")))
