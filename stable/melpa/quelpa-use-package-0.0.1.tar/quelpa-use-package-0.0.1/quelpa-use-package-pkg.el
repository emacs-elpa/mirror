;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quelpa-use-package" "0.0.1"
  "Quelpa handler for use-package."
  '((emacs       "25.1")
    (quelpa      "0")
    (use-package "2"))
  :url "https://github.com/quelpa/quelpa-use-package"
  :commit "00ce667293c7cd5dc79d4b6077785fcc57455775"
  :revdesc "00ce667293c7"
  :keywords '("package" "management" "elpa" "use-package"))
