;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ember-yasnippets" "0.0.1"
  "Snippets for Ember.js development."
  '((yasnippet "0.8.0"))
  :url "https://github.com/ronco/ember-yasnippets.el"
  :commit "873d73f3276d8c5ef0a0361ee61357121246b138"
  :revdesc "873d73f3276d"
  :keywords '("tools" "abbrev" "languages")
  :authors '(("Ron White" . "ronco@costite.com"))
  :maintainers '(("Ron White" . "ronco@costite.com")))
