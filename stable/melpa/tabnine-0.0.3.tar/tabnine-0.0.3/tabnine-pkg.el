;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabnine" "0.0.3"
  "An unofficial TabNine package with TabNine Chat supported."
  '((emacs        "27.1")
    (dash         "2.16.0")
    (s            "1.12.0")
    (editorconfig "0.9.1")
    (vterm        "0.0.2")
    (language-id  "0.5.1")
    (transient    "0.4.0"))
  :url "https://github.com/shuxiao9058/tabnine/"
  :commit "4d5aab7a129a560690c4219d1bcee9b0a0eb760a"
  :revdesc "4d5aab7a129a"
  :keywords '("convenience")
  :authors '(("Aaron Ji" . "shuxiao9058@gmail.com")
             ("Tommy Xiang" . "tommyx058@gmail.com")
             ("John Gong" . "gjtzone@hotmail.com"))
  :maintainers '(("Aaron Ji" . "shuxiao9058@gmail.com")
                 ("Tommy Xiang" . "tommyx058@gmail.com")
                 ("John Gong" . "gjtzone@hotmail.com")))
