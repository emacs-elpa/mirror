;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ref-prettify" "0.2"
  "Prettify org-ref citation links."
  '((emacs             "24.3")
    (org-ref           "3.0")
    (bibtex-completion "1.0.0"))
  :url "https://github.com/alezost/org-ref-prettify.el"
  :commit "14abce24eeb98ae22437446cfb95fa595cf0be27"
  :revdesc "14abce24eeb9"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com")
             ("Vitus Schäfftlein" . "vitusschaefftlein@live.de"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")
                 ("Vitus Schäfftlein" . "vitusschaefftlein@live.de")))
