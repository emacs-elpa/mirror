;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "3.0.6"
  "Display documentation for mouse hover."
  '((emacs    "27.1")
    (posframe "1.4.0")
    (eglot    "1.8"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "79e47a4099cd4f9144a1636d8353a07b614c0c0a"
  :revdesc "79e47a4099cd"
  :keywords '("tools" "languages" "convenience" "mouse" "hover")
  :authors '(("Huang Feiyu" . "sibadake1@163.com"))
  :maintainers '(("Huang Feiyu" . "sibadake1@163.com")))
