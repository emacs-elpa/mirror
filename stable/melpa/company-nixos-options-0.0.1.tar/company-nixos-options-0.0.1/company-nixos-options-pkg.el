;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-nixos-options" "0.0.1"
  "Company Backend for nixos-options."
  '((company       "0.8.0")
    (nixos-options "0.0.1")
    (cl-lib        "0.5.0"))
  :url "http://www.github.com/travisbhartwell/nix-emacs/"
  :commit "5fc8fa29bea9dd8e9c822af92f9bc6ddc223635f"
  :revdesc "5fc8fa29bea9"
  :keywords '("unix")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com")
             ("Travis B. Hartwell" . "nafai@travishartwell.net"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")
                 ("Travis B. Hartwell" . "nafai@travishartwell.net")))
