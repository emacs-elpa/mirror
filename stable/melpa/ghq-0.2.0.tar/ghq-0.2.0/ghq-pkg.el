;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghq" "0.2.0"
  "Ghq interface for emacs."
  '((emacs "26.1")
    (dash  "2.18.0")
    (s     "1.7.0"))
  :url "https://github.com/lafrenierejm/emacs-ghq"
  :commit "a5de31e0e37a4a61bf5f425cece2a1e209498977"
  :revdesc "a5de31e0e37a"
  :keywords '("ghq")
  :authors '(("Roman Coedo" . "romancoedo@gmail.com"))
  :maintainers '(("Roman Coedo" . "romancoedo@gmail.com")))
