;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vsh-mode" "1.0"
  "Alternate PTY interface for complex terminal sessions."
  ()
  :url "https://github.com/hardenedapple/vsh"
  :commit "7eaeea379f2e9bfcdc0f932d3603ea6019508d89"
  :revdesc "7eaeea379f2e"
  :keywords '("processes")
  :authors '(("Matthew Malcomson" . "hardenedapple@gmail.com"))
  :maintainers '(("Matthew Malcomson" . "hardenedapple@gmail.com")))
