;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.6.29.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "9880e775fcc11eb57d59f1d6847d1dc8c8da8a14"
  :revdesc "9880e775fcc1"
  :keywords '("languages"))
