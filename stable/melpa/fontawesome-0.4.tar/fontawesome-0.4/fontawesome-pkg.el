;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fontawesome" "0.4"
  "Fontawesome utility."
  '((helm-core "1.7.7")
    (emacs     "24.4"))
  :url "https://github.com/syohex/emacs-fontawesome"
  :commit "72b4f2f83c7fdacd225aee58f93acefc53166626"
  :revdesc "72b4f2f83c7f"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
