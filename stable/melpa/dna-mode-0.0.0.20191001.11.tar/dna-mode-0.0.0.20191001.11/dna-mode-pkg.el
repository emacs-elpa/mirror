;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dna-mode" "0.0.0.20191001.11"
  "A major mode for editing dna sequences."
  ()
  :url "http://www.mahalito.net/~harley/elisp/dna-mode.el"
  :commit "7a48393fcf0015eed2368fcb89b3091c9d029dc4"
  :revdesc "7a48393fcf00"
  :keywords '("dna" "emacs" "editing")
  :authors '(("Harley Gorrell" . "harley@panix.com"))
  :maintainers '(("Harley Gorrell" . "harley@panix.com")))
