;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imgbb" "20180518"
  "Simple image upload client for imgbb.com."
  '((emacs   "24")
    (request "0.3.0"))
  :url "https://github.com/ecraven/imgbb.el"
  :commit "8e864587cdb5b88994a96b9cd1fa946807de868d"
  :revdesc "8e864587cdb5"
  :keywords '("extensions")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Peter" . "craven@gmx.net")))
