;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mallard-mode" "0.3.0"
  "Major mode for editing Mallard files."
  ()
  :url "https://github.com/jhradilek/emacs-mallard-mode"
  :commit "152cd44d53c881457fe57c1aba77e8e2fca4d1b0"
  :revdesc "v0.3.0-0-g152cd44d53c8"
  :keywords '("xml" "mallard")
  :authors '(("Jaromir Hradilek" . "jhradilek@gmail.com"))
  :maintainers '(("Jaromir Hradilek" . "jhradilek@gmail.com")))
