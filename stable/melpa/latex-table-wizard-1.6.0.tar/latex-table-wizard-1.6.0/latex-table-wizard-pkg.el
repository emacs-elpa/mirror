;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-table-wizard" "1.6.0"
  "Magic editing of LaTeX tables."
  '((emacs     "27.1")
    (auctex    "12.1")
    (transient "0.3.7"))
  :url "https://github.com/enricoflor/latex-table-wizard"
  :commit "0ccd242ba521ed3b323d1dc84f49febe80b2eec7"
  :revdesc "0ccd242ba521"
  :keywords '("convenience" "tex")
  :authors '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers '(("Enrico Flor" . "enrico@eflor.net")))
