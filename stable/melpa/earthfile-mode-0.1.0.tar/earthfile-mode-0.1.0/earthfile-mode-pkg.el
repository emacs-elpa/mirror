;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "earthfile-mode" "0.1.0"
  "Major mode for editing Earthly file."
  '((emacs "26"))
  :url "https://github.com/earthly/earthly-mode"
  :commit "16f262dbeec1e0b9f7f3a6a7cbafbed76e39d8d8"
  :revdesc "16f262dbeec1"
  :authors '(("Thanabodee Charoenpiriyakij" . "wingyminus@gmail.com"))
  :maintainers '(("Thanabodee Charoenpiriyakij" . "wingyminus@gmail.com")))
