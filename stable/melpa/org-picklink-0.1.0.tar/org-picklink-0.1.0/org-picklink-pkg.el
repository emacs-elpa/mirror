;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-picklink" "0.1.0"
  "Pick a headline link from org-agenda."
  '((emacs "24"))
  :url "https://github.com/tumashu/org-picklink"
  :commit "126b0f44f31fec569729df1faf25bd3be9d381f0"
  :revdesc "126b0f44f31f"
  :keywords '("convenience")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
