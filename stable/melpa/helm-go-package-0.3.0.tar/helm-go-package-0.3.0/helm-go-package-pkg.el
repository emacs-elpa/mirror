;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-go-package" "0.3.0"
  "Helm sources for Go programming language's package."
  '((emacs     "24.4")
    (helm-core "2.2.1")
    (go-mode   "1.4.0")
    (deferred  "0.4.0"))
  :url "https://github.com/yasuyk/helm-go-package"
  :commit "7db5ea9ce97502152a6bb1fe38f8fabb5a49abd2"
  :revdesc "7db5ea9ce975"
  :authors '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
