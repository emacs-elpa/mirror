;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "efinger" "1.0.1"
  "Finger client and .plan feed reader."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/efinger.el"
  :commit "16b6ae5b450b953f07c073a4a8c86a4257d86db4"
  :revdesc "16b6ae5b450b"
  :keywords '("comm")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
