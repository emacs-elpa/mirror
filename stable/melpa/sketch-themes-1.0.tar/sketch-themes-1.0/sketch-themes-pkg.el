;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sketch-themes" "1.0"
  "Sketch color themes."
  '((emacs "26.1"))
  :url "https://github.com/dawranliou/emacs.d/themes"
  :commit "df8182628052bf55e7779fb6967383629059b5c0"
  :revdesc "df8182628052"
  :keywords '("faces")
  :authors '(("Daw-Ran Liou" . "hi@dawranliou.com"))
  :maintainers '(("Daw-Ran Liou" . "hi@dawranliou.com")))
