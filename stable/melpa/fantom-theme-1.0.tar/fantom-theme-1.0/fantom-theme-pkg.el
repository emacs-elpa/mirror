;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fantom-theme" "1.0"
  "Emacs theme with a dark background."
  '((emacs "24.1"))
  :url "https://github.com/adsva/fantom-emacs-theme"
  :commit "70cef2886ca90c93bcafc869bcc77bad1e390c33"
  :revdesc "70cef2886ca9")
