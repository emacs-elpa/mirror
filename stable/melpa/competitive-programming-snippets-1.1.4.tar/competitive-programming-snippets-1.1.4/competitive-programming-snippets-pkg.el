;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "competitive-programming-snippets" "1.1.4"
  "Competitive Programming snippets for Yasnippet."
  '((emacs     "26")
    (yasnippet "0.8.0"))
  :url "https://github.com/sei40kr/competitive-programming-snippets"
  :commit "b0245fcbabf035d89b80150add5d6a47859ab555"
  :revdesc "b0245fcbabf0"
  :keywords '("tools")
  :authors '(("Seong Yong-ju" . "sei40kr@gmail.com"))
  :maintainers '(("Seong Yong-ju" . "sei40kr@gmail.com")))
