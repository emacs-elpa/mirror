;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nash-mode" "0.1"
  "Nash major mode."
  ()
  :url "https://github.com/tiago4orion/nash-mode.el"
  :commit "f1173b136555fff7d29f0db6bff58ed7e70ace2a"
  :revdesc "f1173b136555"
  :keywords '("nash" "languages"))
