;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "related-files" "0.3.0"
  "Easily find files related to the current one."
  '((emacs "28.2"))
  :url "https://www.gnu.org/software/emacs/"
  :commit "4085ed9c235983e530da24cb1fbe33a5b7928ab3"
  :revdesc "v0.3.0-0-g4085ed9c2359"
  :keywords '("tools")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
