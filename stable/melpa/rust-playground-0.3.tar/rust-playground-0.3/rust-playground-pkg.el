;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rust-playground" "0.3"
  "Local Rust playground for short code snippets."
  '((emacs "24.3"))
  :url "https://github.com/grafov/rust-playground"
  :commit "092c8b11d62dea23953a004744833092bac85fe1"
  :revdesc "092c8b11d62d"
  :keywords '("tools" "rust")
  :authors '(("Alexander I.Grafov + all the contributors" . "grafov@gmail.com"))
  :maintainers '(("Alexander I.Grafov + all the contributors" . "grafov@gmail.com")))
