;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eping" "0.1.1"
  "Ping websites to check internet connectivity."
  '((emacs "25.1")
    (dash  "2.12.0")
    (s     "1.12.0"))
  :url "https://github.com/sean-hut/eping"
  :commit "0d5d80dd0c76f0d46a3565d940a2b0ed955dfd0a"
  :revdesc "0.1.1-0-g0d5d80dd0c76"
  :keywords '("comm" "processes" "terminals" "unix")
  :authors '(("Sean Hutchings" . "seanhut@yandex.com"))
  :maintainers '(("Sean Hutchings" . "seanhut@yandex.com")))
