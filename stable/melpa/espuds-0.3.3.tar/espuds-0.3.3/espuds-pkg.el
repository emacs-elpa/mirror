;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "espuds" "0.3.3"
  "Ecukes step definitions."
  '((s    "1.7.0")
    (dash "2.2.0")
    (f    "0.12.1"))
  :url "https://github.com/ecukes/espuds"
  :commit "1405972873339e056517217136de4ad3202d744a"
  :revdesc "140597287333"
  :keywords '("test")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
