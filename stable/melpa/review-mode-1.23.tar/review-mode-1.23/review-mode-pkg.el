;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "review-mode" "1.23"
  "Major mode for ReVIEW."
  ()
  :url "https://github.com/kmuto/review-el"
  :commit "5b2e01f7e07b0ba6776eb0555ef386026bcb62d0"
  :revdesc "5b2e01f7e07b"
  :authors '(("Kenshi Muto" . "kmuto@kmuto.jp"))
  :maintainers '(("Kenshi Muto" . "kmuto@kmuto.jp")))
