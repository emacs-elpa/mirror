;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-fuzzy-find" "0.2"
  "Find file using Fuzzy Search."
  '((emacs "24.1")
    (helm  "1.7.0"))
  :url "https://github.com/xuchunyang/helm-fuzzy-find"
  :commit "5995aa680c47498a530c59ccee6ebcf5a7790478"
  :revdesc "5995aa680c47"
  :keywords '("helm" "fuzzy" "find" "file")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
