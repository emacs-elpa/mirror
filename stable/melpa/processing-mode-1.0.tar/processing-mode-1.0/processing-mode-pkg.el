;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "processing-mode" "1.0"
  "Major mode for Processing 2.0."
  '((yasnippet "0.8.0"))
  :url "https://github.com/ptrv/processing2-emacs"
  :commit "228bc56369675787d60f637223b50ce3a1afebbd"
  :revdesc "228bc5636967"
  :keywords '("languages" "snippets")
  :authors '(("Peter Vasil" . "mail@petervasil.net"))
  :maintainers '(("Peter Vasil" . "mail@petervasil.net")))
