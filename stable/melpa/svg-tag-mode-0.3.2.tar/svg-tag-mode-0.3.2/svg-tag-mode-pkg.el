;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "svg-tag-mode" "0.3.2"
  "Replace keywords with SVG tags."
  '((emacs   "27.1")
    (svg-lib "0.2"))
  :url "https://github.com/rougier/svg-tag-mode"
  :commit "3b07983614bee0195534e7a8a6dcfab757da4f0b"
  :revdesc "3b07983614be"
  :keywords '("convenience")
  :authors '(("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr"))
  :maintainers '(("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr")))
