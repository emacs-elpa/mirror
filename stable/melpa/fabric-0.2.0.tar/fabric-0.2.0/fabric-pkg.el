;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fabric" "0.2.0"
  "Launch Fabric using Emacs."
  ()
  :url "https://github.com/nlamirault/fabric.el"
  :commit "004934318f63d8cf955022f87b2c33eb97ada280"
  :revdesc "0.2.0-0-g004934318f63"
  :keywords '("python" "fabric")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@chmouel.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@chmouel.com")))
