;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "media-thumbnail" "1.0.0"
  "Utility package to provide media icons."
  '((emacs "28.1"))
  :url "https://github.com/jojojames/media-thumbnail"
  :commit "5f0c4cdd5e4a5d0ba8149ed4882d62b2444c385d"
  :revdesc "5f0c4cdd5e4a"
  :keywords '("files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
