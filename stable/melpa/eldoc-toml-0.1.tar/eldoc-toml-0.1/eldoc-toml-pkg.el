;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-toml" "0.1"
  "TOML table name at point for ElDoc."
  '((emacs "24.4"))
  :url "https://github.com/it-is-wednesday/eldoc-toml"
  :commit "8123b5d0fb876de3e38474d517e41aa6a7d3a9d4"
  :revdesc "8123b5d0fb87"
  :keywords '("data")
  :authors '(("Ma'or Kadosh" . "git@avocadosh.xyz"))
  :maintainers '(("Ma'or Kadosh" . "git@avocadosh.xyz")))
