;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nsis-mode" "0.44"
  "NSIS-mode."
  ()
  :url "https://github.com/mlf176f2/nsis-mode"
  :commit "f1bf701c37680553c8f51462e0829d0dd6c53187"
  :revdesc "v0.44-0-gf1bf701c3768"
  :keywords '("nsis"))
