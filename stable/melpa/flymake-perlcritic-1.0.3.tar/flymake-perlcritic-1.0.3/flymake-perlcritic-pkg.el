;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-perlcritic" "1.0.3"
  "Flymake handler for Perl to invoke Perl::Critic."
  '((flymake "0.3"))
  :url "https://github.com/illusori/emacs-flymake-perlcritic"
  :commit "0692d6ad5495f6e5438bde0a10345829b8e1def8"
  :revdesc "0692d6ad5495"
  :authors '(("Sam Graham" . "libflymake-perlcritic-emacsBLAHBLAHillusori.co.uk"))
  :maintainers '(("Sam Graham" . "libflymake-perlcritic-emacsBLAHBLAHillusori.co.uk")))
