;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "turtles" "2.1.0"
  "Screen-grabbing test utility."
  '((emacs  "26.1")
    (compat "30.0.1.0"))
  :url "https://github.com/szermatt/turtles"
  :commit "bf85a56c96bd35320ef509cfa2872c9db9943919"
  :revdesc "bf85a56c96bd"
  :keywords '("testing" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
