;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erefactor" "0.7.0"
  "Emacs-Lisp refactoring utilities."
  '((cl-lib "0.3"))
  :url "https://github.com/mhayashi1120/Emacs-erefactor"
  :commit "fde3fd42c815c76e8015f69518a92f6bfcfde990"
  :revdesc "fde3fd42c815"
  :keywords '("extensions" "tools" "maint")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
