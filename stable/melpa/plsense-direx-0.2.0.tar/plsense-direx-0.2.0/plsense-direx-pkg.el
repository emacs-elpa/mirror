;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plsense-direx" "0.2.0"
  "Perl Package Explorer."
  '((direx      "0.1alpha")
    (plsense    "0.3.2")
    (log4e      "0.2.0")
    (yaxception "0.3.2"))
  :url "https://github.com/aki2o/plsense-direx"
  :commit "8a2f465264c74e04524cc789cdad0190ace43f6c"
  :revdesc "8a2f465264c7"
  :keywords '("perl" "convenience")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
