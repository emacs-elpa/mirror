;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kill-ring-search" "1.1"
  "Incremental search for the kill ring."
  ()
  :url "http://nschum.de/src/emacs/kill-ring-search/"
  :commit "3a5bc1767f742c91aa788df79ecec836a0946edb"
  :revdesc "1.1-0-g3a5bc1767f74"
  :keywords '("convenience" "matching")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
