;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-docstring-toggle" "1.1.0"
  "Toggle Lisp docstring visibility."
  '((emacs "29.1"))
  :url "https://github.com/gggion/lisp-docstring-toggle"
  :commit "75a7a3f7cbdaacca99f9452aae9e38f46db883ae"
  :revdesc "75a7a3f7cbda"
  :keywords '("lisp" "docs" "editing"))
