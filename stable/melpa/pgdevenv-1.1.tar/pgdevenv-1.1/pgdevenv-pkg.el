;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgdevenv" "1.1"
  "Manage your PostgreSQL development envs."
  ()
  :url "https://github.com/dimitri/pgdevenv-el"
  :commit "91b766925ad38788b19d5295e898bd4987d85f50"
  :revdesc "91b766925ad3"
  :keywords '("emacs" "postgresql" "development" "environment" "shell" "debug" "gdb")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
