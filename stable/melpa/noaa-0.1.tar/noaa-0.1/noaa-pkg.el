;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noaa" "0.1"
  "Get NOAA weather data."
  '((request "0.2.0")
    (cl-lib  "0.5")
    (emacs   "24"))
  :url "https://github.com/thomp/************************"
  :commit "fc48a3d328fe3fc73fb88a66ca3da47a4308e60a"
  :revdesc "fc48a3d328fe"
  :keywords '("noaa" "weather" "http"))
