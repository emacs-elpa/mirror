;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "harvest" "0.3.8"
  "Harvest integration."
  '((swiper "0.7.0")
    (hydra  "0.13.0")
    (s      "1.11.0"))
  :url "https://github.com/kostajh/harvest.el"
  :commit "69041907bdca68d3ab6802e08ec698c3448f28a1"
  :revdesc "69041907bdca"
  :keywords '("harvest")
  :authors '(("Kosta Harlan" . "kosta@kostaharlan.net"))
  :maintainers '(("Kosta Harlan" . "kosta@kostaharlan.net")))
