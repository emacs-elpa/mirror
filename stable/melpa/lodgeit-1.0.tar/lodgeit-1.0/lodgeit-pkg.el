;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lodgeit" "1.0"
  "Paste to a lodgeit powered pastebin."
  '((s "1.9.0"))
  :url "https://github.com/ionrock/lodgeit-el"
  :commit "4a5822316acbfddebbb1a672bbdcb37ae6ecff7a"
  :revdesc "4a5822316acb"
  :keywords '("pastebin" "lodgeit")
  :authors '(("Eric Larson" . "eric@ionrock.org"))
  :maintainers '(("Eric Larson" . "eric@ionrock.org")))
