;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moonbit-ts-mode" "0.1.0"
  "MoonBit tree-sitter major mode."
  '((emacs "29.1"))
  :url "https://github.com/moonbit-community/moonbit-ts-mode"
  :commit "7bb360893d89ae28c9033c034cff5266ba9eee3f"
  :revdesc "7bb360893d89"
  :keywords '("languages" "tree-sitter"))
