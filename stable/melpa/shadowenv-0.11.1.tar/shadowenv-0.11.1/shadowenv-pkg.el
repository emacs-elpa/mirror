;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shadowenv" "0.11.1"
  "Shadowenv integration."
  '((emacs "24"))
  :url "https://github.com/Shopify/shadowenv.el"
  :commit "d5af6c0af6dcf2bad78fba919bf5b2d3feccbba1"
  :revdesc "d5af6c0af6dc"
  :keywords '("shadowenv" "tools")
  :authors '(("Dante Catalfamo" . "dante.catalfamo@shopify.com"))
  :maintainers '(("Dante Catalfamo" . "dante.catalfamo@shopify.com")))
