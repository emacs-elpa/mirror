;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reazon" "0.4.1"
  "MiniKanren for Emacs."
  '((emacs "26"))
  :url "https://github.com/nickdrozd/reazon"
  :commit "21a4218538eee90af66c20519457efeb5b319e22"
  :revdesc "21a4218538ee"
  :keywords '("languages" "extensions" "lisp")
  :authors '(("Nick Drozd" . "nicholasdrozd@gmail.com"))
  :maintainers '(("Nick Drozd" . "nicholasdrozd@gmail.com")))
