;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sequences" "0.1.0"
  "Ports of some Clojure sequence functions."
  '((emacs "24"))
  :url "https://github.com/timvisher/sequences.el"
  :commit "6147bd8ba2a6e03d66066d508f64ee3f918e2e7a"
  :revdesc "6147bd8ba2a6"
  :keywords '("convenience")
  :authors '(("Tim Visher" . "tim.visher@gmail.com"))
  :maintainers '(("Tim Visher" . "tim.visher@gmail.com")))
