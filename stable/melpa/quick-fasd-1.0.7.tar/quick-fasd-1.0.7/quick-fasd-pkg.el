;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "1.0.7"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "c8e6b88679a7b57a76d02f72b29e1e471e32b100"
  :revdesc "1.0.7-0-gc8e6b88679a7"
  :keywords '("convenience" "files" "tools"))
