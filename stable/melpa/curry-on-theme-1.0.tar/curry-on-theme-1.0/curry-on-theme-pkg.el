;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "curry-on-theme" "1.0"
  "A low contrast color theme."
  '((emacs "24"))
  :url "https://github.com/mvarela/Curry-On-Theme"
  :commit "0d4093edeb9b94950b5debfaec9a17d2e7aedd54"
  :revdesc "0d4093edeb9b"
  :authors '(("Martín Varela" . "(martin@varela.fi)"))
  :maintainers '(("Martín Varela" . "(martin@varela.fi)")))
