;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-menu" "0.1.1"
  "Library providing avy-powered popup menu."
  '((emacs "24.3")
    (avy   "0.3.0"))
  :url "https://github.com/mrkkrp/avy-menu"
  :commit "71b71e64900d0637e17013781042e086e9bf56e7"
  :revdesc "71b71e64900d"
  :keywords '("popup" "menu")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
