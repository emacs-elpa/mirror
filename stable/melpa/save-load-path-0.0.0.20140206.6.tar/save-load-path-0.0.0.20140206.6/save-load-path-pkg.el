;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "save-load-path" "0.0.0.20140206.6"
  "Save load-path and reuse it to test."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/download/save-load-path.el"
  :commit "6cb763a37e2b8af505bff2bcd11fd49c9ea04d66"
  :revdesc "6cb763a37e2b"
  :keywords '("lisp")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
