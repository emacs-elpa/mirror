;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sml-ts-mode" "1.0.0"
  "SML major-mode using tree-sitter."
  '((emacs    "29.1")
    (sml-mode "6.12"))
  :url "https://github.com/nverno/sml-ts-mode"
  :commit "b8cefd128ffe8890cc6bf58decc12174d7b9016c"
  :revdesc "b8cefd128ffe"
  :keywords '("sml" "languages" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
