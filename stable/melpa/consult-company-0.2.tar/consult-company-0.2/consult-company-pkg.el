;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-company" "0.2"
  "Consult frontend for company."
  '((emacs   "27.1")
    (company "0.9")
    (consult "0.9"))
  :url "https://github.com/mohkale/consult-company"
  :commit "5d8275bff131ce2aaa678dd46aac345eb4fc8b27"
  :revdesc "5d8275bff131"
  :authors '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("mohsin kaleem" . "mohkale@kisara.moe")))
