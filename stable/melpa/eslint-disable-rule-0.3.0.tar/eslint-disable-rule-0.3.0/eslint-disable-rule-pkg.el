;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eslint-disable-rule" "0.3.0"
  "Commands to add JS comments disabling eslint rules."
  '((emacs "27.2"))
  :url "https://github.com/DamienCassou/eslint-disable-rule"
  :commit "642ead124172dd470e8ab59fd0645597dc9d8e66"
  :revdesc "642ead124172"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
