;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hound" "1.1.0"
  "Display hound search results in a compilation window."
  '((request "0.2.0")
    (cl-lib  "0.5"))
  :url "https://github.com/ryoung786/hound.el"
  :commit "28cb804d99f9240d690d60098644e4300336b5fa"
  :revdesc "v1.1.0-0-g28cb804d99f9")
