;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gams-ac" "1.1"
  "Auto-complete source file for GAMS mode."
  '((auto-complete "1.0")
    (gams-mode     "4.0"))
  :url "https://github.com/ShiroTakeda/gams-ac"
  :commit "befe20065589653c5b7ffc61fc6598314653e2fb"
  :revdesc "befe20065589"
  :keywords '("languages" "tools" "gams-mode" "auto-complete"))
