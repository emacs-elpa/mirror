;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ctest" "1.0"
  "Run ctest from within emacs."
  ()
  :url "https://github.com/danlamanna/helm-ctest"
  :commit "922e3b1644616914ae788490449ae1f57ed6ddba"
  :revdesc "922e3b164461"
  :keywords '("helm" "ctest")
  :authors '(("Dan LaManna" . "me@danlamanna.com"))
  :maintainers '(("Dan LaManna" . "me@danlamanna.com")))
