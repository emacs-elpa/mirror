;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "1.0.0"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu"
  :commit "7e5bd92e4aa4444cd3167de2dccf24a891011720"
  :revdesc "v1.0.0-0-g7e5bd92e4aa4"
  :keywords '("convenience" "tools"))
