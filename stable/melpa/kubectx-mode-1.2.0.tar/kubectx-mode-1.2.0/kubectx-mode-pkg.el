;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubectx-mode" "1.2.0"
  "Change kubectl context/namespace and show in mode line."
  '((emacs "24"))
  :url "https://github.com/terjesannum/emacs-kubectx-mode"
  :commit "f08687ae5403eb18bbeffc6dafdfde469bdb9a36"
  :revdesc "f08687ae5403"
  :keywords '("tools" "kubernetes")
  :authors '(("Terje Sannum" . "terje@offpiste.org"))
  :maintainers '(("Terje Sannum" . "terje@offpiste.org")))
