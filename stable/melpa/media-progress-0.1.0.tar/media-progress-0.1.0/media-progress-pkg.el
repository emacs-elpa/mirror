;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "media-progress" "0.1.0"
  "Display position where media player stopped."
  ()
  :url "https://github.com/jumper047/media-progress"
  :commit "3bdf2cc841c1408efc2bb86c2d8e5e68da02451a"
  :revdesc "3bdf2cc841c1"
  :keywords '("files" "convenience")
  :authors '(("Dmitriy Pshonko" . "http://github.com/jumper047"))
  :maintainers '(("Dmitriy Pshonko" . "http://github.com/jumper047")))
