;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "0xc" "0.1"
  "Base conversion made easy."
  '((emacs "24.4"))
  :url "https://github.com/AdamNiederer/0xc"
  :commit "814704d539de12361bc6eb2cf1b67ba9cc3983fe"
  :revdesc "814704d539de"
  :keywords '("base" "conversion")
  :authors '(("Adam Niederer" . "adam.niederer@gmail.com"))
  :maintainers '(("Adam Niederer" . "adam.niederer@gmail.com")))
