;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-hdevtools" "0.3"
  "A flycheck checker for Haskell using hdevtools."
  '((flycheck "0.15"))
  :url "https://github.com/flycheck/flycheck-hdevtools"
  :commit "fbf90b9a7d2d90f69ac55b57d18f0f4a47afed61"
  :revdesc "fbf90b9a7d2d"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
