;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nubox" "1.0.0"
  "Tao of EMACS grayscale color theme."
  ()
  :url "https://github.com/martijnat/nubox"
  :commit "ca764658ebb3d741f2e1628996bd6fb1b3f90600"
  :revdesc "ca764658ebb3"
  :keywords '("faces")
  :authors '(("Martijn Terpstra" . "bigmartijn@gmail.com"))
  :maintainers '(("Martijn Terpstra" . "bigmartijn@gmail.com")))
