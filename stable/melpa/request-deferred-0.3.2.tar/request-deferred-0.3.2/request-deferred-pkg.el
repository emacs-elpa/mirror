;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "request-deferred" "0.3.2"
  "Wrap request.el by deferred."
  '((deferred "0.3.1")
    (request  "0.2.0"))
  :url "https://github.com/tkf/emacs-request"
  :commit "22efefeaa394f6deef957818f5c5332061c88d1c"
  :revdesc "22efefeaa394"
  :authors '(("Takafumi Arakaki" . "aka.tkfatgmail.com"))
  :maintainers '(("Takafumi Arakaki" . "aka.tkfatgmail.com")))
