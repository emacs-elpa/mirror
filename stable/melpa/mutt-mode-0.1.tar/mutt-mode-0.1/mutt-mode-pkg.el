;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mutt-mode" "0.1"
  "Major mode for editing mutt configuration."
  '((emacs "24"))
  :url "https://gitlab.com/flexw/mutt-mode"
  :commit "b23c94a8019c840726a783aa51370be6a52b6243"
  :revdesc "b23c94a8019c"
  :keywords '("languages")
  :authors '(("Felix Weilbach" . "felix.weilbach@t-online.de"))
  :maintainers '(("Felix Weilbach" . "felix.weilbach@t-online.de")))
