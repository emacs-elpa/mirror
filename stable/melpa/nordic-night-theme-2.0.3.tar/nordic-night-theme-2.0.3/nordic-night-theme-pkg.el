;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nordic-night-theme" "2.0.3"
  "A darker, more colorful version of the lovely Nord theme."
  '((emacs "24.1"))
  :url "https://codeberg.org/ashton314/nordic-night"
  :commit "608af63b232a8f743277cf274803eddb95c7dcd0"
  :revdesc "608af63b232a"
  :authors '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers '(("Ashton Wiersdorf" . "mail@wiersdorf.dev")))
