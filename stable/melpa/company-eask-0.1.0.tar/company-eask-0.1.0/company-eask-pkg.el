;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-eask" "0.1.0"
  "Company backend for Eask-file."
  '((emacs   "26.1")
    (company "0.8.0")
    (eask    "0.1.0"))
  :url "https://github.com/emacs-eask/company-eask"
  :commit "27f0a46259427df6a29f352b9bf1079812c3f7bf"
  :revdesc "27f0a4625942"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
