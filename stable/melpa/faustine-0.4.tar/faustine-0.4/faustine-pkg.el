;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faustine" "0.4"
  "Edit, visualize, build and run Faust code."
  '((emacs      "24.3")
    (faust-mode "0.3"))
  :url "https://bitbucket.org/yassinphilip/faustine"
  :commit "f186461e2bc38ec8ae38bd5ab727cc769218a168"
  :revdesc "v0.4-0-gf186461e2bc3"
  :keywords '("languages" "faust")
  :authors '(("Yassin Philip" . "xaccrocheur@gmail.com"))
  :maintainers '(("Yassin Philip" . "xaccrocheur@gmail.com")))
