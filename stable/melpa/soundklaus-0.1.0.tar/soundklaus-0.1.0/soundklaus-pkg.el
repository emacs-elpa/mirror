;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soundklaus" "0.1.0"
  "Play SoundCloud music in Emacs via EMMS."
  '((s        "1.6.0")
    (dash     "1.5.0")
    (pkg-info "0.4"))
  :url "https://github.com/r0man/soundklaus.el"
  :commit "dcf16cfde032c05d7bc54f776c708a5407a2d92f"
  :revdesc "dcf16cfde032"
  :keywords '("soundcloud" "music" "emms")
  :authors '(("r0man" . "roman@burningswell.com"))
  :maintainers '(("r0man" . "roman@burningswell.com")))
