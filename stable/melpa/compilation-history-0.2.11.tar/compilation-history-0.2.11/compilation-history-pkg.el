;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compilation-history" "0.2.11"
  "Track compilation history in SQLite."
  '((emacs "29.1"))
  :url "https://github.com/djgoku/compilation-history"
  :commit "1b79c506872de004120f7d3f85da24c80a4e3b68"
  :revdesc "1b79c506872d"
  :keywords '("processes" "tools")
  :authors '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com"))
  :maintainers '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com")))
