;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-narrow" "0.9.5"
  "Narrow-to-region with more eye candy."
  ()
  :url "https://github.com/Bruce-Connor/fancy-narrow"
  :commit "c0f70b4333d4764323b7154e37a378adb1610ab7"
  :revdesc "c0f70b4333d4"
  :keywords '("faces" "convenience")
  :authors '(("Artur Malabarba" . "bruce.connor.am@gmail.com"))
  :maintainers '(("Artur Malabarba" . "bruce.connor.am@gmail.com")))
