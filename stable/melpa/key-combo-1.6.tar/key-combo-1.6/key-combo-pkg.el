;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-combo" "1.6"
  "Map key sequence to commands."
  ()
  :url "https://github.com/uk-ar/key-combo"
  :commit "0bc0cf6466a4257047a21a6d01913e92e6862165"
  :revdesc "0bc0cf6466a4"
  :keywords '("keyboard" "input")
  :authors '(("Yuuki Arisawa" . "yuuki.ari@gmail.com"))
  :maintainers '(("Vitalie Spinu" . "spinuvit@gmail.com")))
