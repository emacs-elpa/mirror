;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-plsense" "0.2.0"
  "Company backend for Perl."
  '((company "0.9.3")
    (cl-lib  "0.5.0")
    (dash    "2.12.0")
    (s       "1.12")
    (emacs   "24"))
  :url "https://github.com/CeleritasCelery/company-plsense"
  :commit "00f0baa70502b8412627316f72fc8b27ae7a1106"
  :revdesc "00f0baa70502"
  :authors '(("Troy Hinckley" . "troy.hinckley@gmail.com"))
  :maintainers '(("Troy Hinckley" . "troy.hinckley@gmail.com")))
