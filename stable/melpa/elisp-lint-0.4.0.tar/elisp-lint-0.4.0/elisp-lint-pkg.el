;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-lint" "0.4.0"
  "Basic linting for Emacs Lisp."
  '((emacs        "24.4")
    (dash         "2.15.0")
    (package-lint "0.11"))
  :url "https://github.com/gonewest818/elisp-lint/"
  :commit "2b645266be8010a6a49c6d0ebf6a3ad5bd290ff4"
  :revdesc "2b645266be80"
  :keywords '("lisp" "maint" "tools")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com")))
