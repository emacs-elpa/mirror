;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lark-mode" "0.0.1"
  "Major mode for editing Lark parser code."
  ()
  :url "https://github.com/taquangtrung/lark-mode"
  :commit "2a92c8177cbad76eadf8ef31f80fcb26ee96b999"
  :revdesc "2a92c8177cba"
  :keywords '("parser" "lark" "python"))
