;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-rfc" "1"
  "RFC Back-End for Org Export Engine."
  '((emacs "24"))
  :url "https://github.com/choppsv1/org-rfc-export"
  :commit "a8df6fedd2615464513883fd060e84962be83cab"
  :revdesc "a8df6fedd261"
  :keywords '("org" "rfc" "wp" "xml")
  :authors '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainers '(("Christian Hopps" . "chopps@gmail.com")))
