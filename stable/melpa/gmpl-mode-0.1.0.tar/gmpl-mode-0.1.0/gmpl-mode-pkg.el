;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gmpl-mode" "0.1.0"
  "Major mode for editing GMPL(MathProg) files."
  ()
  :url "https://github.com/cute-jumper/gmpl-mode"
  :commit "25d20f9d24594e85cb6f80d35d7c73b7e82cbc71"
  :revdesc "25d20f9d2459"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
