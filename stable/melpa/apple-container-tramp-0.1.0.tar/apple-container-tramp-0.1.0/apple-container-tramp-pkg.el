;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apple-container-tramp" "0.1.0"
  "TRAMP integration for apple container."
  '((emacs "24.3"))
  :url "https://github.com/major1201/apple-container-tramp.el"
  :commit "fbe4e8a9f0db4d29720aaf734d68ba40100513ba"
  :revdesc "fbe4e8a9f0db")
