;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morgentau-theme" "1.0"
  "Tango-based custom theme."
  '((emacs "24"))
  :url "https://github.com/morgentau-theme/morgentau-theme.el"
  :commit "f9a6e7e552cbe10f44921ec7497640633a93a810"
  :revdesc "f9a6e7e552cb"
  :keywords '("theme" "dark" "faces"))
