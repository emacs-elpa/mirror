;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-flymake" "0.1.7"
  "Helm interface for flymake."
  '((helm "1.0"))
  :url "https://github.com/tam17aki"
  :commit "afb1089d6a0dc9a63bc2aa1df19d80830cc33c6a"
  :revdesc "afb1089d6a0d"
  :authors '(("Akira Tamamori" . "tamamori5917@gmail.com"))
  :maintainers '(("Akira Tamamori" . "tamamori5917@gmail.com")))
