;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vline" "1.11"
  "Show vertical line (column highlighting) mode."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/vline.el"
  :commit "bc29e08c8e04845fb0e09155fe8f5212862f0a92"
  :revdesc "bc29e08c8e04"
  :keywords '("faces" "editing" "emulating")
  :authors '(("Taiki SUGAWARA" . "buzz.taiki@gmail.com"))
  :maintainers '(("Taiki SUGAWARA" . "buzz.taiki@gmail.com")))
