;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly-overlay" "1.0.1"
  "Overlay Common Lisp evaluation results."
  '((emacs "24.4")
    (sly   "1.0"))
  :url "https://git.sr.ht/~fosskers/sly-overlay"
  :commit "ed831fb4c2e7d97894e9ae59853afffb8d9a78bc"
  :revdesc "ed831fb4c2e7"
  :keywords '("lisp")
  :authors '(("Colin Woodbury" . "colin@fosskers.ca"))
  :maintainers '(("Colin Woodbury" . "colin@fosskers.ca")))
