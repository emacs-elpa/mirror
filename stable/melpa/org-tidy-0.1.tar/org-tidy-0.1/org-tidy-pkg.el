;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tidy" "0.1"
  "A minor mode to tidy org-mode buffers."
  '((emacs "27.1"))
  :url "https://github.com/jxq0/org-tidy"
  :commit "46e86f805d2dc87c239f4d8f27471dd5d0e29703"
  :revdesc "46e86f805d2d"
  :keywords '("convenience" "org")
  :authors '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainers '(("Xuqing Jia" . "jxq@jxq.me")))
