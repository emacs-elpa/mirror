;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "foggy-night-theme" "0.1"
  "Theme."
  '((emacs "24"))
  :url "https://github.com/mswift42/foggy-night-theme"
  :commit "2c983b3a61b20f79e4ba9cf7309697ca1f32b553"
  :revdesc "2c983b3a61b2")
