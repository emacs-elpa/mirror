;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syntactic-close" "0.1"
  "Insert closing delimiter."
  ()
  :url "https://github.com/emacs-berlin/syntactic-close"
  :commit "10a13d7132f176ecdffa371e576a0d1ce76f55ba"
  :revdesc "10a13d7132f1"
  :keywords '("languages" "lisp"))
