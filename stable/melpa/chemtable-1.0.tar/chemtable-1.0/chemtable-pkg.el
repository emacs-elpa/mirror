;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chemtable" "1.0"
  "Periodic table of the elements."
  '((emacs "24.1"))
  :url "https://github.com/sergiruiztrepat/chemtable"
  :commit "e0c127c0c8005ab43f26effda11296d0b6abe5d5"
  :revdesc "e0c127c0c800"
  :keywords '("convenience" "chemistry"))
