;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-edit-mode" "0.6.1"
  "Edit results of counsel commands in-place."
  '((emacs   "26.1")
    (ht      "2.3")
    (s       "1.12.0")
    (counsel "0.10.0"))
  :url "https://github.com/tyler-dodge/counsel-edit-mode"
  :commit "75563c48135a4f52230d08e818e35d72fd55c2a4"
  :revdesc "75563c48135a"
  :keywords '("convenience" "matching"))
