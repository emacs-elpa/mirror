;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "micgoline" "1.0.0"
  "Modeline configuration library for powerline."
  '((emacs     "24.3")
    (powerline "2.3"))
  :url "https://github.com/yzprofile/micgoline"
  :commit "98552c887762ba4b585398074bfab3f095854b50"
  :revdesc "98552c887762"
  :keywords '("mode-line" "powerline" "theme")
  :authors '(("yzprofile" . "yzprofiles@gmail.com"))
  :maintainers '(("yzprofile" . "yzprofiles@gmail.com")))
