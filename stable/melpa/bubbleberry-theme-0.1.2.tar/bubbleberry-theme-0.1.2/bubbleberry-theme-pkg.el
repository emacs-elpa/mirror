;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bubbleberry-theme" "0.1.2"
  "A theme based on LightTable for Emacs24."
  '((emacs "24.1"))
  :url "https://github.com/jasonm23/emacs-bubbleberry-theme"
  :commit "be93b5f54b59c34714a054e65a59a216e7a68296"
  :revdesc "be93b5f54b59"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
