;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ouroboros" "0.1.2"
  "Ouroboros network mini-protocol."
  '((emacs  "27.1")
    (dash   "2.19.0")
    (cbor   "0.2.5")
    (bech32 "0.2.1"))
  :url "https://github.com/Titan-C/cardano.el"
  :commit "cf85424b305e8f89debb756dc67eebc84639f711"
  :revdesc "cf85424b305e"
  :authors '(("Oscar Najera" . "https://oscarnajera.com"))
  :maintainers '(("Oscar Najera" . "hi@oscarnajera.com")))
