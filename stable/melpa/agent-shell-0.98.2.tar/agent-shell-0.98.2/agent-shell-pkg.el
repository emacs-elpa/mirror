;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.98.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.3")
    (acp         "0.20.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "086096f6ebcc9971a8c9273e427e0ac697ec304c"
  :revdesc "086096f6ebcc")
