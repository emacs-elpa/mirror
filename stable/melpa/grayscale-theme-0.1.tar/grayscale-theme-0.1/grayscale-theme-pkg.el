;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grayscale-theme" "0.1"
  "[No description available]."
  ()
  :url "https://github.com/belak/emacs-grayscale-theme"
  :commit "93d9b3cd562147d3198652896e90d8c21aeb83e4"
  :revdesc "93d9b3cd5621"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
