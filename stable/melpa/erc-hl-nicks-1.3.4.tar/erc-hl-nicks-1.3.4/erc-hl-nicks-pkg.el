;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-hl-nicks" "1.3.4"
  "ERC nick highlighter that ignores uniquifying chars when colorizing."
  ()
  :url "http://www.github.com/leathekd/erc-hl-nicks"
  :commit "a67fe361c8f2aa20fc235447fbb898f424b51439"
  :revdesc "a67fe361c8f2"
  :authors '(("David Leatherman" . "leathekd@gmail.com"))
  :maintainers '(("David Leatherman" . "leathekd@gmail.com")))
