;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vtm" "1.0.0"
  "Manages vterm buffers with configuration files."
  ()
  :url "https://github.com/laishulu/emacs-vterm-manager"
  :commit "0d6bdcdda17896f5ef79907017eafad0536755d5"
  :revdesc "0d6bdcdda178"
  :keywords '("convenience"))
