;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "1.1.1"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "bd5d63f5fb75f98f699b2e7bc5f4903b52426121"
  :revdesc "bd5d63f5fb75"
  :keywords '("outlines" "tools" "convenience" "org" "todo" "gtd" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
