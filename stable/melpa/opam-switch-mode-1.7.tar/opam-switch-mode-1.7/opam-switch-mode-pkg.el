;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "opam-switch-mode" "1.7"
  "Select OCaml opam switches via a menu."
  '((emacs "25.1"))
  :url "https://github.com/ProofGeneral/opam-switch-mode"
  :commit "71612b9a307c640d2fa662b266787647a3a5075a"
  :revdesc "1.7-0-g71612b9a307c"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
