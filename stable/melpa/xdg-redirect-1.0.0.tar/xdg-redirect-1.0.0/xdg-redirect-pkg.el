;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xdg-redirect" "1.0.0"
  "Redirect Emacs files to XDG directories."
  '((emacs "27.1"))
  :url "https://github.com/francisco-colaco/xdg-redirect"
  :commit "268aa5a921f67d7a4eed065fe65576e1804e9a28"
  :revdesc "268aa5a921f6"
  :keywords '("convenience")
  :authors '(("Francisco Miguel Colaço" . "francisco.colaco@gmail.com"))
  :maintainers '(("Francisco Miguel Colaço" . "francisco.colaco@gmail.com")))
