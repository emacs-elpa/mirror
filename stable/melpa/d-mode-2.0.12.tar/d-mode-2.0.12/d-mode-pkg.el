;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "d-mode" "2.0.12"
  "D Programming Language major mode for (X)Emacs."
  '((emacs "25.1"))
  :url "https://github.com/Emacs-D-Mode-Maintainers/Emacs-D-Mode"
  :commit "024aca97d07e72bf3500fb6bf0cdf50c4992a741"
  :revdesc "024aca97d07e"
  :keywords '("d" "programming" "language" "emacs" "cc-mode")
  :maintainers '(("Russel Winder" . "russel@winder.org.uk")
                 ("Vladimir Panteleev" . "vladimir@thecybershadow.net")))
