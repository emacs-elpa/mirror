;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-safari" "0.1"
  "Helm interface for Safari Bookmarks and History."
  '((helm  "1.9.1")
    (emacs "24"))
  :url "https://github.com/xuchunyang/helm-safari"
  :commit "4be2c8a5c5b487a4bcf372abc772f3bfdc39cd6c"
  :revdesc "4be2c8a5c5b4"
  :keywords '("tools")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
