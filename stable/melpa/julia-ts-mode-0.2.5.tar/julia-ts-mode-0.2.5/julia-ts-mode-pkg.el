;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-ts-mode" "0.2.5"
  "Major mode for Julia source code using tree-sitter."
  '((emacs      "29")
    (julia-mode "0.4"))
  :url "https://github.com/ronisbr/julia-ts-mode"
  :commit "1c5b01753bee57de2d480a80c2b267009ac93e9a"
  :revdesc "1c5b01753bee"
  :keywords '("julia" "languages" "tree-sitter"))
