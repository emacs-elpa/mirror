;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occurx-mode" "0.1"
  "Occur-like filtering of buffers with rx patterns."
  '((emacs "25.1")
    (rbit  "0.1"))
  :url "https://github.com/k32/snabbkaffe-mode"
  :commit "86525c256328b90f36542187655cd7f9ff9cb8d2"
  :revdesc "86525c256328"
  :keywords '("logs" "occur")
  :authors '(("k32" . "example@example.com"))
  :maintainers '(("k32" . "example@example.com")))
