;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "literate-elisp" "0.8"
  "Literate program to write elisp codes in org mode."
  '((cl-lib "0.6")
    (emacs  "24.4"))
  :url "https://github.com/jingtaozf/literate-elisp"
  :commit "af7256e46b42cb954e16f9dec3511687697d9704"
  :revdesc "af7256e46b42"
  :keywords '("lisp" "docs" "extensions" "tools")
  :authors '(("Jingtao Xu" . "jingtaozf@gmail.com"))
  :maintainers '(("Jingtao Xu" . "jingtaozf@gmail.com")))
