;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "omtose-phellack-themes" "0.2.0"
  "Two dark themes, with cold blusish touch."
  '((emacs "24"))
  :url "http:/github.com/franksn/omtose-darker/"
  :commit "88b74750c2b76750d0fff14a76212a281b824498"
  :revdesc "88b74750c2b7")
