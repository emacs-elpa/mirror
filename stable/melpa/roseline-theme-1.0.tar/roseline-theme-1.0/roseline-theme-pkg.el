;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "roseline-theme" "1.0"
  "Roseline theme."
  ()
  :url "https://github.com/madara123pain/unique-emacs-theme-pack"
  :commit "e6e7a36c43bee1bf1c690ec3df2a5640b5a829bd"
  :revdesc "e6e7a36c43be"
  :authors '(("Omer Arif" . "omerarifkhan.official123@gmail.com"))
  :maintainers '(("Omer Arif" . "omerarifkhan.official123@gmail.com")))
