;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-mit" "0.15"
  "MIT/GNU Scheme's implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.18"))
  :url "https://gitlab.com/emacs-geiser/mit"
  :commit "4e90e9ae815e89f3540fb9644e6016c663ef5765"
  :revdesc "4e90e9ae815e"
  :keywords '("languages" "mit" "scheme" "geiser")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
