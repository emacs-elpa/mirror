;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "0.4"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "d46c02edbdbd9f070b0492ffbe9f4ceea3322737"
  :revdesc "d46c02edbdbd"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
