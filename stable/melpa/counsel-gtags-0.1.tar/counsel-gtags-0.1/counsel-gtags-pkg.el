;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-gtags" "0.1"
  "Ivy for GNU global."
  '((emacs   "24.3")
    (counsel "0.8.0"))
  :url "https://github.com/syohex/emacs-counsel-gtags"
  :commit "8066dd4cd6eb157345fb43788bacf2c5d746b497"
  :revdesc "8066dd4cd6eb"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
