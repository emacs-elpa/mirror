;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp" "0.1.0"
  "Model Context Protocol."
  '((emacs   "29.4")
    (jsonrpc "1.0.16"))
  :url "https://github.com/lizqwerscott/mcp.el"
  :commit "771a3b76282dd2fd9cf80633ab8f5a7a3b848020"
  :revdesc "771a3b76282d"
  :keywords '("ai" "mcp")
  :authors '(("lizqwer scott" . "lizqwerscott@gmail.com"))
  :maintainers '(("lizqwer scott" . "lizqwerscott@gmail.com")))
