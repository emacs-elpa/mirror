;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modelica-mode" "2.0.0"
  "Major mode for editing Modelica files."
  '((emacs "27.1"))
  :url "https://github.com/modelica-tools/modelica-mode"
  :commit "291f1bb8147693e21054722757f1e2cef4b27d12"
  :revdesc "291f1bb81476"
  :keywords '("languages" "continuous system modeling"))
