;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnatune" "0.5.1"
  "Browse magnatune's music catalog."
  '((dash "2.9.0")
    (s    "1.9.0"))
  :url "https://github.com/eikek/magnatune.el"
  :commit "8c625effad68f8e361f7a89807217c862c29050c"
  :revdesc "8c625effad68")
