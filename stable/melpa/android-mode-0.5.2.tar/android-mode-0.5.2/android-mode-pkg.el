;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "android-mode" "0.5.2"
  "Minor mode for Android application development."
  ()
  :url "https://github.com/remvee/android-mode"
  :commit "d5332e339a1f5e30559a53feffb8442ca79265d6"
  :revdesc "0.5.2-0-gd5332e339a1f"
  :keywords '("tools" "processes"))
