;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "expui-icons" "0.3.1"
  "Icons from IntelliJ's New UI."
  '((emacs "29.1"))
  :url "https://github.com/wwulfric/expui-icons"
  :commit "7f84ff6e5610dac385900bc0fb75d0c6f3613052"
  :revdesc "7f84ff6e5610"
  :keywords '("convenience" "files")
  :authors '(("Lufei Wang" . "wwulfric@gmail.com"))
  :maintainers '(("Lufei Wang" . "wwulfric@gmail.com")))
