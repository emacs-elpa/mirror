;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "0.49"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (compat    "31")
    (fedi      "0.5")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "c5306b1cbd10cd63c0c656eb27b3e4a8250b9928"
  :revdesc "c5306b1cbd10"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
