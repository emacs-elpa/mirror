;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "makefile-executor" "20230224"
  "Commands for conveniently running makefile targets."
  '((emacs "27.1")
    (dash  "2.11.0")
    (f     "0.11.0")
    (s     "1.10.0"))
  :url "https://github.com/Olivia5k/makefile-executor.el"
  :commit "d1d98eaf522a767561f6c7cbd8d2526be58b3ec5"
  :revdesc "d1d98eaf522a"
  :keywords '("processes")
  :authors '(("Olivia Thiderman" . "olivia@thiderman.org"))
  :maintainers '(("Olivia Thiderman" . "olivia@thiderman.org")))
