;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-semantic-hl" "0.1"
  "Semantic Syntax Highlighting for Lisp Languages."
  '((emacs "27.1"))
  :url "https://github.com/calsys456/lisp-semantic-hl.el"
  :commit "c22c6af91283e728516c7c0e7cf08c869805dbd3"
  :revdesc "c22c6af91283"
  :keywords '("languages" "lisp" "maint")
  :authors '(("The Calendrical System" . "us@calsys.org"))
  :maintainers '(("The Calendrical System" . "us@calsys.org")))
