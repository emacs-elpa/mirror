;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-identity" "0.2.1"
  "Identity management for (ma)git."
  '((emacs "25.1")
    (dash  "2.10")
    (hydra "0.14")
    (f     "0.20"))
  :url "https://github.com/akirak/git-identity.el"
  :commit "e7da2b3e3a5a790311431e3263b00df41d335136"
  :revdesc "e7da2b3e3a5a"
  :keywords '("git" "vc" "convenience")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
