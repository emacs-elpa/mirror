;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kiwix" "1.0.2"
  "Searching offline Wikipedia through Kiwix."
  '((emacs   "24.4")
    (request "0.3.0"))
  :url "https://github.com/stardiviner/kiwix.el"
  :commit "86c163cbc0515e9e516f05e809796087b1d3ba8d"
  :revdesc "v1.0.2-0-g86c163cbc051"
  :keywords '("kiwix" "wikipedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
