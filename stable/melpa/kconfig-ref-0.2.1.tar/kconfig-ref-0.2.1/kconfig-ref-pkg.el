;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kconfig-ref" "0.2.1"
  "A simple package for looking up kconfig symbol quickly."
  '((emacs      "24.4")
    (projectile "2.7.0"))
  :url "https://github.com/seokbeomkim/kconfig-ref"
  :commit "d2f27295053805c5ef4eea5f74e1920f4a24cb25"
  :revdesc "d2f272950538"
  :keywords '("tools" "kconfig" "linux" "kernel")
  :authors '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainers '(("Jason Kim" . "sukbeom.kim@gmail.com")))
