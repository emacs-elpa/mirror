;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sunshine" "0.1"
  "Provide weather and forecast information."
  '((cl-lib "0.5"))
  :url "https://github.com/aaronbieber/sunshine.el"
  :commit "3f424738b094dfcc0d529454d35f7feed803916e"
  :revdesc "3f424738b094"
  :keywords '("tools" "weather")
  :authors '(("Aaron Bieber" . "aaron@aaronbieber.com"))
  :maintainers '(("Aaron Bieber" . "aaron@aaronbieber.com")))
