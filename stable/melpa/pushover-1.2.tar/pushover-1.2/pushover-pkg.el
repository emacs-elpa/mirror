;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pushover" "1.2"
  "Pushover API Access."
  '((cl-lib "0.5"))
  :url "https://github.com/swflint/pushover.el"
  :commit "30b8f167545bcb8c6abd32073da016c792743abd"
  :revdesc "30b8f167545b"
  :keywords '("notifications")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
