;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gruber-darker-ayu-theme" "1.0"
  "Gruber Darker + Ayu Dark color theme for Emacs."
  ()
  :url "https://github.com/Hadi493/gruber-darker-ayu-theme"
  :commit "292c4903b6c77ae81f1caf86541ac2fba70441f8"
  :revdesc "292c4903b6c7"
  :authors '(("Hadi Alam" . "hadialam493@gmail.com"))
  :maintainers '(("Hadi Alam" . "hadialam493@gmail.com")))
