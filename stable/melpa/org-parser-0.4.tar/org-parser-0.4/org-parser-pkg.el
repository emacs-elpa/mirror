;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-parser" "0.4"
  "Parse org files into structured datatypes."
  '((emacs "25.1")
    (dash  "2.12.0")
    (ht    "2.1"))
  :url "https://bitbucket.org/zck/org-parser.el"
  :commit "9f85e7c0a6f89b05fc642179632537d6cdf9bbb9"
  :revdesc "9f85e7c0a6f8"
  :keywords '("files" "outlines" "tools"))
