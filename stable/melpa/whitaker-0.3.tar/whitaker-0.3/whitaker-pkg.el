;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whitaker" "0.3"
  "Comint interface for Whitaker's Words."
  '((dash "2.10.0"))
  :url "https://github.com/Fuco1/whitaker"
  :commit "28172edce0f727f0f7f17d8ba71d5510d877bb45"
  :revdesc "28172edce0f7"
  :keywords '("processes")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
