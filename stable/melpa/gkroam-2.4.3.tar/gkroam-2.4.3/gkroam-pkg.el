;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gkroam" "2.4.3"
  "A lightweight org-mode Roam Research replica."
  '((emacs   "26.3")
    (db      "0.0.6")
    (company "0.9.10"))
  :url "https://github.com/Kinneyzhang/gkroam"
  :commit "2552444f1037240cce4f459bff3ac2b1f331bbb6"
  :revdesc "2552444f1037"
  :keywords '("org" "convenience")
  :authors '(("Kinney Zhang" . "kinneyzhang666@gmail.com"))
  :maintainers '(("Kinney Zhang" . "kinneyzhang666@gmail.com")))
