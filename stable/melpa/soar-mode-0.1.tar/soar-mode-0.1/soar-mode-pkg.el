;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soar-mode" "0.1"
  "A major mode for the Soar language."
  ()
  :url "https://github.com/adeschamps/soar-mode"
  :commit "10b580a69600ed1231f2afbefdb34c9e4bb34182"
  :revdesc "10b580a69600"
  :keywords '("languages" "soar"))
