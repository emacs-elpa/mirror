;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tagged" "0.0.4"
  "Dynamic block for tagged org-mode todos."
  '((s     "1.13.0")
    (dash  "2.19.1")
    (emacs "28.1")
    (org   "9.5.2"))
  :url "https://github.com/gizmomogwai/org-tagged"
  :commit "c2cd03bc86af55689964424988d724158348903d"
  :revdesc "v0.0.4-0-gc2cd03bc86af"
  :keywords '("org-mode" "org" "gtd" "tools")
  :authors '(("Christian Köstlin" . "christian.koestlin@gmail.com"))
  :maintainers '(("Christian Köstlin" . "christian.koestlin@gmail.com")))
