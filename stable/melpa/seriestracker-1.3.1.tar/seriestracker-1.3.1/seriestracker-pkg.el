;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seriestracker" "1.3.1"
  "Series tracker."
  '((dash      "2.12.1")
    (transient "0.3.2")
    (emacs     "27.1"))
  :url "https://www.github.com/MaximeWack/seriesTracker"
  :commit "49b1e7a822c973c48007dc6461577ee68124ddc8"
  :revdesc "49b1e7a822c9"
  :keywords '("multimedia")
  :authors '(("Maxime Wack" . "contactatmaximewackdotcom"))
  :maintainers '(("Maxime Wack" . "contactatmaximewackdotcom")))
