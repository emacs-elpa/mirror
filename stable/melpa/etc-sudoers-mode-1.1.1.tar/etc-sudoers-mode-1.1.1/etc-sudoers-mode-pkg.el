;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "etc-sudoers-mode" "1.1.1"
  "Edit Sudo security policies."
  '((sudo-edit   "0")
    (with-editor "0"))
  :url "https://gitlab.com/mavit/etc-sudoers-mode/"
  :commit "133f342e7a249ed4b3e3983e6d8bf541bae05c4b"
  :revdesc "133f342e7a24"
  :keywords '("languages")
  :authors '(("Peter Oliver" . "git@mavit.org.uk"))
  :maintainers '(("Peter Oliver" . "git@mavit.org.uk")))
