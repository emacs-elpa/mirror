;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokei" "0.2.1"
  "Display codebase statistics."
  '((emacs         "27.1")
    (magit-section "3.3.0"))
  :url "https://github.com/nagy/tokei.el"
  :commit "b16b05c9bbddd046300725d0eb4f45b38677b2fb"
  :revdesc "b16b05c9bbdd"
  :authors '(("Daniel Nagy" . "https://github.com/nagy"))
  :maintainers '(("Daniel Nagy" . "danielnagy@posteo.de")))
