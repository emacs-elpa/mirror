;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grip-mode" "2.5.0"
  "Instant GitHub-flavored Markdown/Org preview using grip."
  '((emacs "24.4"))
  :url "https://github.com/seagle0128/grip-mode"
  :commit "31c03ec19b4fbef95be00a586171e0c26a330966"
  :revdesc "31c03ec19b4f"
  :keywords '("convenience" "markdown" "preview")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
