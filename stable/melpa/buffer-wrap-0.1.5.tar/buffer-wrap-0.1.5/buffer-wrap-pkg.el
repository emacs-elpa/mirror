;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-wrap" "0.1.5"
  "Wrap the beginning and the end of buffer."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/buffer-wrap"
  :commit "2b12ed29cbcd733ad21d91475d1fcbd4092c604e"
  :revdesc "2b12ed29cbcd"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
