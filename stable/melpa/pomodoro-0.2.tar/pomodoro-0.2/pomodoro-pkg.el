;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pomodoro" "0.2"
  "A timer for the Pomodoro Technique."
  ()
  :url "https://github.com/baudtack/pomodoro.el"
  :commit "2c53618a460460163ab8489046af39f82f8801eb"
  :revdesc "2c53618a4604"
  :authors '(("David Kerschner" . "dkerschner@gmail.com"))
  :maintainers '(("David Kerschner" . "dkerschner@gmail.com")))
