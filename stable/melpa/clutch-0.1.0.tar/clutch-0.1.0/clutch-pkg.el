;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.1.0"
  "Interactive database client for Emacs."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "264d6d988a599fd0b5ae7d6ac0ff0aa9fa7d7f89"
  :revdesc "264d6d988a59"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
