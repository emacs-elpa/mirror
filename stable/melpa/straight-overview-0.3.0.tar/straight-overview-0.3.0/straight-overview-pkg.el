;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "straight-overview" "0.3.0"
  "Selective upgrade UI for straight.el packages."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/straight-overview"
  :commit "02ba4061c1534a46f0354109bd2e5bdf6dc4f2c0"
  :revdesc "v0.3.0-0-g02ba4061c153"
  :keywords '("convenience" "tools" "vc")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
