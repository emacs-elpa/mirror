;;; lyrics.el --- Show lyrics                         -*- lexical-binding: t -*-

;; Copyright (c) 2015 Mario Rodas <marsam@users.noreply.github.com>

;; Author: Mario Rodas <marsam@users.noreply.github.com>
;; URL: https://github.com/emacs-pe/lyrics.el
;; Keywords: convenience
;; Package-Version: 0.0.1
;; Package-Revision: 54ee0d9a87cb
;; Package-Requires: ((emacs "25") (seq "2.15"))

;; This file is NOT part of GNU Emacs.

;;; License:

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; `lyrics.el' interface to download and display songs lyrics.
;;
;; Usage:
;;
;;     M-x lyrics

;;; Code:
(eval-when-compile
  (require 'cl-lib)
  (require 'subr-x)
  (defvar url-http-end-of-headers))

(require 'dom)
(require 'seq)
(require 'url-util)


(defgroup lyrics nil
  "Show lyrics."
  :prefix "lyrics-"
  :group 'multimedia)

(defcustom lyrics-directory (expand-file-name "~/.lyrics")
  "Directory where to the lyrics will be stored.

It defaults to `~/.lyrics' since other MPD clients \(e.g.  ncmpc\)
also use that location."
  :type '(directory :must-match t)
  :group 'lyrics)

(defcustom lyrics-normalize-title-p t
  "Whether to normalize lyrics.

Normalization is only applied when `lyrics' is called interactively."
  :type 'boolean
  :group 'lyrics)

(defcustom lyrics-normalize-function 'lyrics-capitalize
  "Function used to normalize a lyrics artist and title."
  :type 'function
  :group 'lyrics)

(defvar lyrics-backends nil)

(defcustom lyrics-backend 'lyrics-lyricswiki
  "Function used to get lyrics.

This function should receive three parameters: Artist, Song,
Buffer \(optional\), and ultimately call `lyrics-show' to show
the lyrics."
  :type 'function
  :type (append '(choice)
                (mapcar (lambda (x) (list 'const :tag (car x) (cdr x))) lyrics-backends))
  :group 'lyrics)

(defface lyrics-face-song
  '((t :inherit font-lock-constant-face))
  "Face for song titles."
  :group 'lyrics)

(defface lyrics-face-artist
  '((t :inherit font-lock-constant-face))
  "Face for song artist."
  :group 'lyrics)

(defface lyrics-face-lyrics
  '((t :inherit default))
  "Face for song lyrics."
  :group 'lyrics)

(defface lyrics-face-item
  '((t :weight bold))
  "Face for lyrics item."
  :group 'lyrics)

(defvar-local lyrics-song nil)
(defvar-local lyrics-artist nil)

(defvar lyrics-song-history nil)
(defvar lyrics-artist-history nil)
(defvar lyrics-buffer-name "*Lyrics*")
(defvar lyrics-newlines-separator 1)

(defconst lyrics-node-tag-ignore '(comment script))

(defun lyrics-capitalize (string)
  "Capitalize a STRING."
  ;; XXX: Obviously this is grammatically incomplete https://english.stackexchange.com/a/91
  (cl-labels ((title (str)
                     (concat (upcase (substring str 0 1)) (downcase (substring str 1)))))
    (string-join (mapcar #'title (split-string string)) " ")))

(defun lyrics-clean-blank-lines (string)
  "Clean duplicate blank lines from STRING."
  (replace-regexp-in-string (rx (= 2 "\n" (? space))) "\n" string))

(defun lyrics-cache-filename (artist song)
  "Return a filename used to cache lyrics from a ARTIST SONG."
  (let ((lyrics-file (concat artist " - " song ".txt")))
    (expand-file-name lyrics-file lyrics-directory)))

(defun lyrics-node-text (node &optional separator)
  "Return all the text bits from NODE concatenated by SEPARATOR."
  (string-join (cl-remove-if-not 'stringp (dom-children node)) (or separator " ")))

(defun lyrics-node-texts (node &optional separator)
  "Return all textual data under NODE concatenated with SEPARATOR in-between.

Similar to `dom-texts' but ignores `lyrics-node-tag-ignore' tags."
  (string-join (mapcar
                (lambda (elem)
                  (cond
                   ((stringp elem) elem)
                   ((eq (dom-tag elem) 'br) "\n")
                   ((member (dom-tag elem) lyrics-node-tag-ignore) "")
                   (t (lyrics-node-texts elem separator))))
                (dom-children node))
               (or separator " ")))

(defun lyrics-save (artist song lyrics)
  "Save ARTIST SONG LYRICS in `lyrics-directory'."
  (condition-case err
      (with-temp-buffer
        (insert lyrics)
        (write-region nil nil (lyrics-cache-filename artist song) nil 0))
    (file-error (message (error-message-string err)))))

(defun lyrics-show (artist song lyrics &optional buffer save)
  "Show ARTIST SONG LYRICS in a BUFFER.

If SAVE is non nil will save the lyrics into the `lyrics-directory'."
  (and save (lyrics-save artist song lyrics))
  (with-current-buffer (get-buffer-create (or buffer lyrics-buffer-name))
    (let ((inhibit-read-only t))
      (erase-buffer)
      (insert (format "%s\t\t%s\n" (propertize "Song:" 'face 'lyrics-face-item) (propertize song 'face 'lyrics-face-song))
              (format "%s\t\t%s\n" (propertize "Artist:" 'face 'lyrics-face-item) (propertize artist 'face 'lyrics-face-artist))
              (make-string lyrics-newlines-separator ?\n)
              (propertize lyrics 'face 'lyrics-face-lyrics))
      (goto-char (point-min))
      (lyrics-show-mode)
      (setq lyrics-song song
            lyrics-artist artist)
      (display-buffer (current-buffer)))))

(defun lyrics-show-revert-buffer (_ignore-auto noconfirm)
  "Revert an lyrics buffer.

The function receives two arguments _IGNORE-AUTO and NOCONFIRM,
which are the arguments that `revert-buffer' received."
  (let ((old-pos (point)))
    (when (or noconfirm
              (y-or-n-p (format "Reload lyrics for song \"%s - %s\"? " lyrics-artist lyrics-song)))
      (message "Loading lyrics for song \"%s - %s\"?" lyrics-artist lyrics-song)
      (lyrics lyrics-artist lyrics-song (current-buffer))
      (force-mode-line-update)
      (goto-char old-pos))))

(defvar lyrics-show-mode-map
  (let ((map (make-sparse-keymap)))
    (set-keymap-parent map special-mode-map)
    (define-key map (kbd "j") #'next-line)
    (define-key map (kbd "k") #'previous-line)
    (define-key map (kbd "/") #'isearch-forward)
    map)
  "Local keymap for `lyrics-show-mode' buffers.")

(define-derived-mode lyrics-show-mode special-mode "Lyrics"
  "A major mode for showing lyrics.

\\{lyrics-show-mode-map}"
  (setq buffer-auto-save-file-name nil
        truncate-lines t
        buffer-read-only t
        mode-line-buffer-identification
        (list (default-value 'mode-line-buffer-identification)
              " {" 'lyrics-song " - " 'lyrics-artist "}"))
  (setq-local revert-buffer-function #'lyrics-show-revert-buffer))


;;; Lyrics wiki
(add-to-list 'lyrics-backends '("Lyrics Wiki" . lyrics-lyricswiki))

(defun lyrics-lyricswiki (artist song &optional buffer)
  "Process lyrics for ARTIST SONG in BUFFER."
  (let ((url (concat "http://lyrics.wikia.com/api.php"
                     "?fmt=xml"
                     "&action=lyrics"
                     "&song=" (url-hexify-string (replace-regexp-in-string " " "_" song))
                     "&artist=" (url-hexify-string (replace-regexp-in-string " " "_" artist)))))
    (url-retrieve url #'lyrics-lyricswiki-api-callback (list artist song buffer))))

(defun lyrics-lyricswiki-api-callback (status artist song &optional buffer)
  "Check if STATUS is erred.

Callback lyrics wiki ARTIST SONG in BUFFER."
  (if (plist-get status :error)
      (message (error-message-string (plist-get status :error)))
    (let* ((tree (with-current-buffer (current-buffer)
                   (goto-char url-http-end-of-headers)
                   (libxml-parse-xml-region (1+ (point)) (point-max))))
           (lyrics (cadr (assoc-default 'lyrics (cddr tree))))
           (lyrics-url (cadr (assoc-default 'url (cddr tree)))))
      (if (string= lyrics "Not found")
          (message "Not lyrics found for: %s - %s" artist song)
        (lyrics-lyricswiki-extract lyrics-url artist song buffer)))))

(defun lyrics-lyricswiki-extract (url artist song &optional buffer)
  "Display lyrics lyrics-wiki URL ARTIST SONG in BUFFER."
  (url-retrieve url (lambda (status)
                      (if (plist-get status :error)
                          (message (error-message-string (plist-get status :error)))
                        (let* ((dom (with-current-buffer (current-buffer)
                                      (goto-char url-http-end-of-headers)
                                      (libxml-parse-html-region (1+ (point)) (point-max))))
                               (node (dom-by-class dom "lyricbox"))
                               (lyrics (string-trim (lyrics-clean-blank-lines (lyrics-node-texts node "\n")))))
                          (lyrics-show artist song lyrics buffer 'save))))))


;;; AZLyrics
(add-to-list 'lyrics-backends '("AZLyrics" . lyrics-azlyrics))

(defun lyrics-azlyrics (artist song &optional buffer)
  "Process lyrics for ARTIST SONG in BUFFER using AZLyrics."
  (let ((url (format "http://www.azlyrics.com/lyrics/%s/%s.html"
                     (downcase (replace-regexp-in-string "[[:space:]]+" "" artist))
                     (downcase (replace-regexp-in-string "[[:space:]]+" "" song)))))
    (url-retrieve url #'lyrics-azlyrics-page-callback (list artist song buffer))))

(defun lyrics-azlyrics-page-callback (status artist song &optional buffer)
  "Check if STATUS is erred.

Callback AZLyrics ARTIST SONG in BUFFER."
  (if (plist-get status :error)
      (message (error-message-string (plist-get status :error)))
    (let* ((dom (with-current-buffer (current-buffer)
                  (goto-char url-http-end-of-headers)
                  (libxml-parse-html-region (1+ (point)) (point-max))))
           (node (seq-find (lambda (node)
                             ;; XXX: text from the first 'div' node which
                             ;; doesn't have any attribute
                             (and (not (stringp node))
                                  (eq (dom-tag node) 'div)
                                  (null (dom-attributes node))))
                           (dom-children (dom-by-class dom "col-xs-12 col-lg-8 text-center"))))
           (lyrics (string-trim (lyrics-clean-blank-lines (lyrics-node-texts node "\n")))))
      (lyrics-show artist song lyrics buffer 'save))))


;;; MusixMatch
(add-to-list 'lyrics-backends '("MusixMatch" . lyrics-musixmatch))

(defun lyrics-musixmatch (artist song &optional buffer)
  "Process lyrics for ARTIST SONG in BUFFER using AZLyrics."
  (let ((url (format "https://www.musixmatch.com/lyrics/%s/%s"
                     (replace-regexp-in-string "[[:space:]]+" "-" (replace-regexp-in-string "-" "" artist))
                     (replace-regexp-in-string "[[:space:]]+" "-" (replace-regexp-in-string "-" "" song)))))
    (url-retrieve url #'lyrics-musixmatch-page-callback (list artist song buffer))))

(defun lyrics-musixmatch-page-callback (status artist song &optional buffer)
  "Check if STATUS is erred.

Callback AZLyrics ARTIST SONG in BUFFER."
  (if (plist-get status :error)
      (message (error-message-string (plist-get status :error)))
    (let* ((dom (with-current-buffer (current-buffer)
                  (goto-char url-http-end-of-headers)
                  (libxml-parse-html-region (1+ (point)) (point-max))))
           (nodes (dom-by-class dom "mxm-lyrics__content"))
           (lyrics (string-trim (string-join (mapcar #'lyrics-node-texts nodes) "\n\n"))))
      (lyrics-show artist song lyrics buffer 'save))))


;;;###autoload
(defun lyrics (artist song &optional buffer)
  "Browse lyrics wiki from ARTIST SONG in BUFFER."
  (interactive (if (and (not current-prefix-arg) lyrics-artist lyrics-song)
                   (list lyrics-artist lyrics-song)
                 (list (read-string "Artist: " lyrics-artist 'lyrics-artist-history)
                       (read-string "Song: " lyrics-song 'lyrics-song-history))))
  (and (called-interactively-p 'any)
       lyrics-normalize-title-p
       (functionp lyrics-normalize-function)
       (setq song (funcall lyrics-normalize-function song)
             artist (funcall lyrics-normalize-function artist)))
  (if (file-exists-p (lyrics-cache-filename artist song))
      (let ((lyrics (with-temp-buffer
                      (insert-file-contents (lyrics-cache-filename artist song))
                      (buffer-string))))
        (lyrics-show artist song lyrics buffer))
    (funcall lyrics-backend artist song buffer)))

(provide 'lyrics)

;;; lyrics.el ends here
