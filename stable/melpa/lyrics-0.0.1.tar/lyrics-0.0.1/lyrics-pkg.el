;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lyrics" "0.0.1"
  "Show lyrics."
  '((emacs "25")
    (seq   "2.15"))
  :url "https://github.com/emacs-pe/lyrics.el"
  :commit "54ee0d9a87cb78bef4607487ab588ff9c5c4554c"
  :revdesc "54ee0d9a87cb"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
