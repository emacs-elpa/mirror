;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gobgen" "0.0.1"
  "Generate GObject descendants using a detailed form."
  ()
  :url "https://github.com/gergelypolonkai/gobgen.el"
  :commit "0df95b3adebb7d6a216d0aa6598304a2a3e613d5"
  :revdesc "0df95b3adebb"
  :keywords '("gobject" "glib" "gtk" "helper" "utilities")
  :authors '(("Gergely Polonkai" . "gergely@polonkai.eu"))
  :maintainers '(("Gergely Polonkai" . "gergely@polonkai.eu")))
