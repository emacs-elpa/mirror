;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paxedit" "1.1.8"
  "Structured, Context Driven LISP Editing and Refactoring."
  '((cl-lib  "0.5")
    (paredit "23"))
  :url "https://github.com/promethial/paxedit"
  :commit "644eb7036a475fbcba4de5d46d6940b1e8ef33cd"
  :revdesc "644eb7036a47"
  :keywords '("lisp" "refactoring" "context"))
