;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "streak" "3.0.0"
  "Track a daily streak in your Mode Line."
  '((emacs "27.1"))
  :url "https://github.com/fosskers/streak"
  :commit "61723ebe656bc681fc87ad6d86fb9dfca2b2730a"
  :revdesc "61723ebe656b"
  :keywords '("calendar")
  :authors '(("Colin Woodbury" . "https://www.fosskers.ca"))
  :maintainers '(("Colin Woodbury" . "colin@fosskers.ca")))
