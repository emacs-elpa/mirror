;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jtags" "0.98.0"
  "Enhanced tags functionality for Java development."
  ()
  :url "http://jtags.sourceforge.net"
  :commit "46ff683a3b452729364d9f2fcb86b3f020d9baac"
  :revdesc "46ff683a3b45"
  :keywords '("languages" "tools")
  :authors '(("Alexander Baltatzis" . "alexander@baltatzis.com")
             ("Johan Dykstrom" . "jody4711-sf@yahoo.se"))
  :maintainers '(("Johan Dykstrom" . "jody4711-sf@yahoo.se")))
