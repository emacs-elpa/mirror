;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-ascii-mode" "0.1"
  "Visualize ascii code (small integer) on buffer."
  '((dash "2.10"))
  :url "https://github.com/Dewdrops/visual-ascii-mode"
  :commit "280b7c754d4c34fd01b93f967da3054728177e1c"
  :revdesc "280b7c754d4c"
  :keywords '("presentation")
  :authors '(("Dewdrops" . "v_v_4474@126.com"))
  :maintainers '(("Dewdrops" . "v_v_4474@126.com")))
