;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebnf-mode" "1.0.0"
  "Major mode for EBNF files."
  '((emacs "25.1"))
  :url "https://github.com/nverno/ebnf-mode"
  :commit "9bc7242557dcef797afdcb4a50c70bf153aa221d"
  :revdesc "9bc7242557dc"
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
