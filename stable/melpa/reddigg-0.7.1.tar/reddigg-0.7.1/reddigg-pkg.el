;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reddigg" "0.7.1"
  "A reader for redditt."
  '((emacs   "26.3")
    (promise "1.1")
    (ht      "2.3")
    (org     "9.2"))
  :url "https://github.com/thanhvg/emacs-reddigg"
  :commit "cae4026c72c9e7e36c365d16141c5c2cc79f2712"
  :revdesc "cae4026c72c9"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
