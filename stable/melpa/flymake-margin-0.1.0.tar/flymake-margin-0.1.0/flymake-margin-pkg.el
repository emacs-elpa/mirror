;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-margin" "0.1.0"
  "Sets flymake to work with margin instead of fringes."
  '((emacs "29.1"))
  :url "https://github.com/LionyxML/flymake-margin"
  :commit "4eeac9a9b876bbd1b59919a8ce87840d67ffd318"
  :revdesc "4eeac9a9b876"
  :keywords '("flymake" "margin" "tui"))
