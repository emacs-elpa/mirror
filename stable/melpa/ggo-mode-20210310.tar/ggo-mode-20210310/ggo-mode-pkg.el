;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ggo-mode" "20210310"
  "Gengetopt major mode."
  ()
  :url "https://github.com/mkjunker/ggo-mode"
  :commit "6a7617b5af3d13029e4d680a375e8107c40d0fac"
  :revdesc "6a7617b5af3d"
  :keywords '("extensions" "convenience" "local")
  :authors '(("Matthew K. Junker" . "junker@alum.mit.edu"))
  :maintainers '(("Matthew K. Junker" . "junker@alum.mit.edu")))
