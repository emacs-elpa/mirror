;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "semantic-thrift" "0.0.1"
  "Thrift LALR parser for Emacs."
  ()
  :url "not distributed yet"
  :commit "41abf320b146dbf3f86f51b0586f79018412616e"
  :revdesc "41abf320b146"
  :authors '((nil . "GuanghuiXugh_xu@qq.com"))
  :maintainers '((nil . "GuanghuiXugh_xu@qq.com")))
