;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "5.3.2"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (treepy   "0.1.3"))
  :url "https://github.com/magit/ghub"
  :commit "c282b2fcaa35ee871a465b79f7d8bdb5afaa50dd"
  :revdesc "v5.3.2-0-gc282b2fcaa35"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
