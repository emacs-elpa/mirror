;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-asciidoc" "0.0.0.20261023.102"
  "AsciiDoc Back-End for Org Export Engine."
  '((org "8.1"))
  :url "https://github.com/yashi/org-asciidoc"
  :commit "1e5ee727ae7b0a05614c7c9ef6e4c986a8a2a692"
  :revdesc "1e5ee727ae7b"
  :keywords '("org" "asciidoc")
  :authors '(("Yasushi SHOJI" . "yasushi.shoji@gmail.com"))
  :maintainers '(("Yasushi SHOJI" . "yasushi.shoji@gmail.com")))
