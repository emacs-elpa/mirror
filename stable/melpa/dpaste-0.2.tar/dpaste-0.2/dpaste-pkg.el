;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dpaste" "0.2"
  "Emacs integration for dpaste.com."
  ()
  :url "https://github.com/gregnewman/dpaste.el"
  :commit "436a794496abbaa56d8633716b31ac49d66f4407"
  :revdesc "436a794496ab"
  :keywords '("paste" "pastie" "pastebin" "dpaste" "python")
  :authors '(("Greg Newman" . "grep@20seven.org")
             ("Guilherme Gondim" . "semente@taurinus.org"))
  :maintainers '(("Greg Newman" . "greg@20seven.org")))
