;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gandalf-theme" "0.1"
  "Gandalf color theme."
  ()
  :url "https://github.com/ptrv/gandalf-theme-emacs"
  :commit "51364444a190e5e2749f53187c6cbb10312eb227"
  :revdesc "51364444a190"
  :keywords '("color" "theme")
  :authors '(("Peter Vasil" . "mail@petervasil.net"))
  :maintainers '(("Peter Vasil" . "mail@petervasil.net")))
