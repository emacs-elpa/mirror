;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-dash" "0.5"
  "Consult front-end for dash-docs."
  '((emacs     "27.2")
    (dash-docs "1.4.0")
    (consult   "0.16"))
  :url "https://codeberg.org/ravi/consult-dash"
  :commit "f9ccd7da2eeaffbb30ac490bef3c8f7161dff828"
  :revdesc "f9ccd7da2eea"
  :keywords '("consult" "dash" "docs")
  :authors '(("Ravi R Kiran" . "lists.ravi@gmail.com"))
  :maintainers '(("Ravi R Kiran" . "lists.ravi@gmail.com")))
