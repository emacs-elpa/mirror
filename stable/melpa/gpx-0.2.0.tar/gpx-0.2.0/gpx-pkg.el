;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpx" "0.2.0"
  "Major mode for GPX files."
  '((emacs "27.1"))
  :url "https://github.com/mkcms/gpx-mode"
  :commit "f9a34cf11a41b991ae93cce34a0b6fc3b2050f4a"
  :revdesc "v0.2.0-0-gf9a34cf11a41"
  :keywords '("data" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
