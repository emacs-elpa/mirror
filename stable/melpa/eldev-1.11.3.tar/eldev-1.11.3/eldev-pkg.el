;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "1.11.3"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "aa35aa9f41e2f12647df240d21769fe51008f8c7"
  :revdesc "aa35aa9f41e2"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
