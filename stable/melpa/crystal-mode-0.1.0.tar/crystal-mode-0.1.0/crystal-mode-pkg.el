;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crystal-mode" "0.1.0"
  "Major mode for editing Crystal files."
  '((emacs "24.4"))
  :url "https://github.com/crystal-lang-tools/emacs-crystal-mode"
  :commit "0fe6815201bebe4c5ff6857bd541d95b05132b10"
  :revdesc "0fe6815201be"
  :keywords '("languages" "crystal"))
