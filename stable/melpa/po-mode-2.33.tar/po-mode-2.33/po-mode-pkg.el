;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "po-mode" "2.33"
  "Major mode for GNU gettext PO files."
  '((emacs "23"))
  :commit "6b49cd88523aa4363adbc9eafe4111e611d322d1"
  :revdesc "6b49cd88523a"
  :keywords '("i18n" "gettext"))
