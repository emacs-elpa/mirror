;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ledger" "0.1.0"
  "Transaction Auto-Completion for Beancount & other Ledger-Likes."
  '((company "0.8.0"))
  :url "https://github.com/debanjum/company-ledger"
  :commit "2f061eb750defd21f6ad3ed3a72b384225b75fea"
  :revdesc "2f061eb750de"
  :keywords '("ledger" "beancount" "company" "auto-complete")
  :authors '(("Debanjum Singh Solanky" . "debanjumATgmailDOTcom"))
  :maintainers '(("Debanjum Singh Solanky" . "debanjumATgmailDOTcom")))
