;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-auto-commit" "0.1"
  "Auto-committing feature for your repository."
  ()
  :url "https://github.com/thisirs/vc-auto-commit.git"
  :commit "f4d11c9dd845fc7905f8f39a738b15b046d06c9f"
  :revdesc "f4d11c9dd845"
  :keywords '("vc" "convenience")
  :authors '(("Sylvain Rousseau" . "thisirsatgmaildotcom"))
  :maintainers '(("Sylvain Rousseau" . "thisirsatgmaildotcom")))
