;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zetteldeft" "0.3"
  "Turn deft into a zettelkasten system."
  '((emacs "25.1")
    (deft  "0.8"))
  :url "https://efls.github.io/zetteldeft/"
  :commit "271ea573b0a4f265d16108db2ec7c928f3e9aa31"
  :revdesc "271ea573b0a4"
  :keywords '("deft" "zettelkasten" "zetteldeft" "wp" "files")
  :authors '(("EFLS" . "EliasStorms"))
  :maintainers '(("EFLS" . "EliasStorms")))
