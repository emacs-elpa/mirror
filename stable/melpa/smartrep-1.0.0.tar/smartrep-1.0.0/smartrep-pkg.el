;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smartrep" "1.0.0"
  "Support sequential operation which omitted prefix keys."
  ()
  :url "https://github.com/myuhe/smartrep.el"
  :commit "0b73bf3d1a3c795671bfee0a36cecfaa54729446"
  :revdesc "0b73bf3d1a3c"
  :keywords '("convenience")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
