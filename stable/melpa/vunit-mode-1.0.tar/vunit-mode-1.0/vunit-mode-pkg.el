;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vunit-mode" "1.0"
  "VUnit Runner Interface."
  '((hydra "0.14.0")
    (emacs "24.3"))
  :url "https://github.com/embed-me"
  :commit "c8b5647ba2d902c45fdd1ee6a5bc0fb8a255c928"
  :revdesc "c8b5647ba2d9"
  :keywords '("vunit" "python" "tools")
  :authors '(("Lukas Lichtl" . "support@embed-me.com"))
  :maintainers '(("Lukas Lichtl" . "support@embed-me.com")))
