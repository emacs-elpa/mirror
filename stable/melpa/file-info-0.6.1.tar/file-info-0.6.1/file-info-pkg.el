;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "file-info" "0.6.1"
  "Show pretty information about current file."
  '((emacs            "28.1")
    (hydra            "0.15.0")
    (browse-at-remote "0.15.0"))
  :url "https://github.com/artawower/file-info.el"
  :commit "c6892a0d3bab0c10c85f2fbdfe859547cd051eb8"
  :revdesc "c6892a0d3bab"
  :authors '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers '(("Artur Yaroshenko" . "artawower@protonmail.com")))
