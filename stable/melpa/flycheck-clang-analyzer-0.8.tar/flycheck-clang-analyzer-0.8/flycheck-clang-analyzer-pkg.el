;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-clang-analyzer" "0.8"
  "Integrate Clang Analyzer with flycheck."
  '((flycheck "0.24")
    (emacs    "24.4"))
  :url "https://github.com/alexmurray/flycheck-clang-analyzer"
  :commit "0c9b6e4626cd5376037464f8d6b8c64aa32768ee"
  :revdesc "0c9b6e4626cd"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
