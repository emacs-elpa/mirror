;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnome-screencast" "1.4"
  "Use Gnome screen recording functionality using elisp."
  '((emacs "25"))
  :url "https://github.com/juergenhoetzel/gnome-screencast.el"
  :commit "261844a88c75f10d98b60577ac8121fcd6721564"
  :revdesc "261844a88c75"
  :keywords '("tools" "multimedia")
  :authors '(("Jürgen Hötzel" . "juergen@hoetzel.info"))
  :maintainers '(("Jürgen Hötzel" . "juergen@hoetzel.info")))
