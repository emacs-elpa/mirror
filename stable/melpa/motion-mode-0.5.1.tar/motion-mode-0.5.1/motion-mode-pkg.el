;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "motion-mode" "0.5.1"
  "Major mode for RubyMotion enviroment."
  '((flymake-easy   "0.7")
    (flymake-cursor "1.0.2"))
  :url "https://github.com/ainame/motion-mode"
  :commit "c678b3d163b06920075cd687e28627e99c1155b4"
  :revdesc "c678b3d163b0")
