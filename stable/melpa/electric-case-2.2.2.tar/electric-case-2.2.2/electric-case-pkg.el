;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-case" "2.2.2"
  "Insert camelCase, snake_case words without \"Shift\"ing."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "ee203023a6391d5ecf43ea9bc962e3e75617b405"
  :revdesc "ee203023a639")
