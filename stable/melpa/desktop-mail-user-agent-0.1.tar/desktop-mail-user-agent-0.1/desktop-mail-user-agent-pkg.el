;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "desktop-mail-user-agent" "0.1"
  "Call OS default mail program to compose mail."
  '((emacs "24.3"))
  :url "https://github.com/lassik/emacs-desktop-mail-user-agent"
  :commit "6b665208bd9471cd8e4b4a81237b22c93a734528"
  :revdesc "0.1-0-g6b665208bd94"
  :keywords '("mail")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
