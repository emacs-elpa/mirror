;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ta" "1.5"
  "A tool to deal with Chinese homophonic characters."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/kuanyui/ta.el"
  :commit "9226afbe7abbefb825844ef3ba4ca15f1934cfc2"
  :revdesc "9226afbe7abb"
  :keywords '("tools")
  :authors '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainers '(("kuanyui" . "azazabc123@gmail.com")))
