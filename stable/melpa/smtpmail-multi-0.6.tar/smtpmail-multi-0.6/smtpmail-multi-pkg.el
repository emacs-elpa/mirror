;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smtpmail-multi" "0.6"
  "Use different smtp servers for sending mail."
  ()
  :url "https://github.com/vapniks/smtpmail-multi"
  :commit "21885f6f7ec46facb64fafc2caa2be01caa4b6db"
  :revdesc "21885f6f7ec4"
  :keywords '("comm")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
