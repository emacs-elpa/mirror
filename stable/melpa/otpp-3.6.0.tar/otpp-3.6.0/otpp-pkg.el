;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "3.6.0"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "7f3257d8da96a380ca88406e80d60d71e31e5e0e"
  :revdesc "7f3257d8da96"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
