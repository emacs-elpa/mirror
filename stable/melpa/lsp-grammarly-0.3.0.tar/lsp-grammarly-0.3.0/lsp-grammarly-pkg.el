;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-grammarly" "0.3.0"
  "LSP Clients for Grammarly."
  '((emacs     "27.1")
    (lsp-mode  "6.1")
    (grammarly "0.3.0")
    (request   "0.3.0")
    (s         "1.12.0")
    (ht        "2.3"))
  :url "https://github.com/emacs-grammarly/lsp-grammarly"
  :commit "fe47a75700dc4f16ec4ff77d6d0306f39566464b"
  :revdesc "fe47a75700dc"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
