;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-hl-todo" "1.0"
  "Display hl-todo keywords in flycheck."
  '((emacs    "25.1")
    (hl-todo  "0")
    (flycheck "0"))
  :url "https://github.com/alvarogonzalezsotillo/flycheck-hl-todo"
  :commit "0babe6abe1347e789594a5edfb07513ec2547024"
  :revdesc "0babe6abe134"
  :keywords '("convenience")
  :authors '(("lvaro González Sotillo" . "alvarogonzalezsotillo@gmail.com"))
  :maintainers '(("lvaro González Sotillo" . "alvarogonzalezsotillo@gmail.com")))
