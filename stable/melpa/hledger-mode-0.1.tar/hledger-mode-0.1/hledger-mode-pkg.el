;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hledger-mode" "0.1"
  "[No description available]."
  '((json "1.4"))
  :url "https://github.com/narendraj9/hledger-mode"
  :commit "6f97728700644be6ba862ae573d948631d1c13d9"
  :revdesc "6f9772870064"
  :keywords '("hledger")
  :authors '(("Narendra Joshi" . "narendraj9@gmail.com"))
  :maintainers '(("Narendra Joshi" . "narendraj9@gmail.com")))
