;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monotropic-theme" "0.1"
  "Monotropic Theme."
  '((emacs "24"))
  :url "https://github.com/caffo/monotropic-theme"
  :commit "95bf15e96b1529f051adf011889dc3d963f5492e"
  :revdesc "95bf15e96b15")
