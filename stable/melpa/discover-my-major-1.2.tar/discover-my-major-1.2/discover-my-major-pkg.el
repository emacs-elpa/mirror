;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "discover-my-major" "1.2"
  "Discover key bindings and their meaning for the current Emacs major mode."
  '((makey "0.2"))
  :url "https://github.com/steckerhalter/discover-my-major"
  :commit "d66319bdd32fe800a93e7134e6b9cf58847e5682"
  :revdesc "d66319bdd32f"
  :keywords '("discover" "help" "major-mode" "keys"))
