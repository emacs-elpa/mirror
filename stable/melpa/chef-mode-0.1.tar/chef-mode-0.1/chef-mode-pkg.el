;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chef-mode" "0.1"
  "Minor mode for editing an opscode chef repository."
  ()
  :url "https://github.com/mpasternacki/chef-mode"
  :commit "533d3ce51cbac1cd9dbcdeb67e6402980ecf14fb"
  :revdesc "533d3ce51cba"
  :keywords '("chef" "knife")
  :authors '(("Maciej Pasternacki" . "maciej@pasternacki.net"))
  :maintainers '(("Maciej Pasternacki" . "maciej@pasternacki.net")))
