;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "academic-phrases" "0.0.1"
  "Bypass that mental block, when writing your academic papers."
  ()
  :url "https://github.com/nashamri/academic-phrases"
  :commit "50a6c4735e4c2dc6d89a16a8a3ff09a208d3f2da"
  :revdesc "50a6c4735e4c"
  :keywords '("academic" "papers")
  :authors '(("Nasser Alshammari" . "designernasser@gmail.com"))
  :maintainers '(("Nasser Alshammari" . "designernasser@gmail.com")))
