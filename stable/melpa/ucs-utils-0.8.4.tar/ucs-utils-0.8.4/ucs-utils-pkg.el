;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ucs-utils" "0.8.4"
  "Utilities for Unicode characters."
  '((persistent-soft "0.8.8")
    (pcache          "0.2.3")
    (list-utils      "0.4.2"))
  :url "https://github.com/rolandwalker/ucs-utils"
  :commit "cbfd42f822bf5717934fa2d92060e6e24a813433"
  :revdesc "v0.8.4-0-gcbfd42f822bf"
  :keywords '("i18n" "extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
