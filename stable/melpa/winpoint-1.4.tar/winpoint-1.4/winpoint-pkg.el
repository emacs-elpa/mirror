;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winpoint" "1.4"
  "Remember buffer positions per-window, not per buffer."
  ()
  :url "https://github.com/jorgenschaefer/winpoint"
  :commit "b32ab55f7b8797b9b042a8a89d89d6f79bc356a9"
  :revdesc "b32ab55f7b87"
  :keywords '("convenience")
  :authors '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainers '(("Jorgen Schaefer" . "forcer@forcix.cx")))
