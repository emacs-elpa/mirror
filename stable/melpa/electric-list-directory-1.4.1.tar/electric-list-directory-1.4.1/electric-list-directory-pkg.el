;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-list-directory" "1.4.1"
  "Lightweight popup directory browser."
  '((emacs "26.1"))
  :url "https://github.com/kshartman/electric-directory-list"
  :commit "2e0d4342146f1c033a1dba54e814961649810a5f"
  :revdesc "v1.4.1-0-g2e0d4342146f"
  :keywords '("files" "convenience")
  :authors '(("K. Shane Hartman" . "shane@ai.mit.edu"))
  :maintainers '(("K. Shane Hartman" . "shane@ai.mit.edu")))
