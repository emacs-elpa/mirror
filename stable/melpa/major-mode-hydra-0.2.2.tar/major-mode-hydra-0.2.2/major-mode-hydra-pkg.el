;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "major-mode-hydra" "0.2.2"
  "Major mode keybindings managed by Hydra."
  '((dash         "2.15.0")
    (pretty-hydra "0.2.2")
    (emacs        "25"))
  :url "https://github.com/jerrypnz/major-mode-hydra.el"
  :commit "bba876b86f0b80495004bf185b2b1f6083a1ff3a"
  :revdesc "0.2.2-0-gbba876b86f0b"
  :authors '(("Jerry Peng" . "pr2jerry@gmail.com"))
  :maintainers '(("Jerry Peng" . "pr2jerry@gmail.com")))
