;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyinlib" "0.1.1"
  "Convert first letter of Pinyin to Simplified/Traditional Chinese characters."
  ()
  :url "https://github.com/cute-jumper/pinyinlib.el"
  :commit "39943d226c2a42a9013421a0b4b6d5d3696bf234"
  :revdesc "39943d226c2a"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
