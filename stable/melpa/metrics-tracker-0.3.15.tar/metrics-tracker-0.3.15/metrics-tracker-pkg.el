;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metrics-tracker" "0.3.15"
  "Generate reports of personal metrics from diary entries."
  '((emacs "24.4")
    (seq   "2.3"))
  :url "https://github.com/ianxm/emacs-tracker"
  :commit "02dbffa9b7a920d989e7261709c64c6f54a380b2"
  :revdesc "02dbffa9b7a9"
  :keywords '("calendar")
  :authors '(("Ian Martins" . "ianxm@jhu.edu"))
  :maintainers '(("Ian Martins" . "ianxm@jhu.edu")))
