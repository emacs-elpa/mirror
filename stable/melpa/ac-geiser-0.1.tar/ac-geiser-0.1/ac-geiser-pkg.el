;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-geiser" "0.1"
  "Emacs auto-complete backend for geiser."
  '((geiser        "0.5")
    (auto-complete "1.4"))
  :url "https://github.com/xiaohanyu/ac-geiser"
  :commit "0e2e36532336f27e3dc3b01fff55ad1a4329817d"
  :revdesc "v0.1-0-g0e2e36532336"
  :authors '(("Xiao Hanyu" . "xiaohanyu1988@gmail.com"))
  :maintainers '(("Xiao Hanyu" . "xiaohanyu1988@gmail.com")))
