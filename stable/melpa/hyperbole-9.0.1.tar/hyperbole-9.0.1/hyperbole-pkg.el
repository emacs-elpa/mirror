;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.0.1"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.1"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b36debbea873c2360a6782abcce084f78c0c9ff2"
  :revdesc "b36debbea873"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Mats Lidell" . "matsl@gnu.org")))
