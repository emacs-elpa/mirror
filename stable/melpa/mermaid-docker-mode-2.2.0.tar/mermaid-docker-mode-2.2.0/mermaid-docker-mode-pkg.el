;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mermaid-docker-mode" "2.2.0"
  "Render mermaid graphs with Docker service."
  '((emacs        "26.1")
    (mermaid-mode "20230517.1527+"))
  :url "https://github.com/KeyWeeUsr/mermaid-docker-mode"
  :commit "ce5f941cdb1bb360872bd5f80574a50d23f85531"
  :revdesc "2.2.0-0-gce5f941cdb1b"
  :keywords '("convenience" "docker" "mermaid" "mmd" "graph" "design" "jpg" "image" "api")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
