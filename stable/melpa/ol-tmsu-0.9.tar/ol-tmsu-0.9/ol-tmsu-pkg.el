;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-tmsu" "0.9"
  "Org-mode links to TMSU queries."
  '((emacs "28.1"))
  :url "https://github.com/vifon/tmsu.el"
  :commit "2c44c1d391375fb2230f192e634d0f9006c172f8"
  :revdesc "2c44c1d39137"
  :keywords '("files" "outlines" "hypermedia"))
