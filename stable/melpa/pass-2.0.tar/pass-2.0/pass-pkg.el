;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pass" "2.0"
  "Major mode for password-store.el."
  '((emacs              "25")
    (password-store     "2.1.0")
    (password-store-otp "0.1.5")
    (f                  "0.17"))
  :url "https://github.com/NicolasPetton/pass"
  :commit "35e3f86e96878520e690513cdbc1b2753b173e72"
  :revdesc "35e3f86e9687"
  :keywords '("password-store" "password" "keychain")
  :authors '(("Nicolas Petton" . "petton.nicolas@gmail.com")
             ("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Nicolas Petton" . "petton.nicolas@gmail.com")
                 ("Damien Cassou" . "damien@cassou.me")))
