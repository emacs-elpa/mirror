;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-keg" "0.0.1"
  "Flycheck for Keg project."
  '((emacs    "24.3")
    (flycheck "0.1"))
  :url "https://github.com/conao3/keg.el"
  :commit "cebf09a160283d41f8343e1cf063ccaac11dd69c"
  :revdesc "cebf09a16028"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
