;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-lsi" "1.0.0"
  "Add memo to directory and show it in dired."
  '((emacs "26.1"))
  :url "https://github.com/conao3/dired-lsi.el"
  :commit "8170d7711254af18cbf1397d681fd331363a17d8"
  :revdesc "8170d7711254"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
