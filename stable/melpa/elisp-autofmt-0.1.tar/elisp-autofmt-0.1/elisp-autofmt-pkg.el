;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-autofmt" "0.1"
  "Emacs lisp auto-format."
  '((emacs "26.2"))
  :url "https://github.com/ideasman42/emacs-elisp-autofmt"
  :commit "9b0b8966be03e5d8f86f3556a9fdee02069c7ac2"
  :revdesc "9b0b8966be03"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
