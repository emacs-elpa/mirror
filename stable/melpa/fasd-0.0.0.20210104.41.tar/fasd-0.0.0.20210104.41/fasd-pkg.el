;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fasd" "0.0.0.20210104.41"
  "Emacs integration for the command-line productivity booster `fasd'."
  ()
  :url "https://framagit.org/steckerhalter/emacs-fasd"
  :commit "c1d92553f33ebb018135c698db1a6d7f86731a26"
  :revdesc "c1d92553f33e"
  :keywords '("cli" "bash" "zsh" "autojump"))
