;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-img" "0.0.1"
  "[No description available]."
  ()
  :url "https://github.com/l3msh0/helm-img"
  :commit "7311114b94fb85fb46a34f370e8e4df4501c1431"
  :revdesc "7311114b94fb"
  :keywords '("convenience")
  :authors '(("l3msh0" . "l3msh0_at_gmail.com")))
