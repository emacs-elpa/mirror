;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "windwow" "0.1"
  "Simple workspace management."
  '((dash   "2.13.0")
    (cl-lib "0.6.1"))
  :url "github.com/vijumathew/windwow"
  :commit "44e28e36ce15ea59158c1991990b902ff5843424"
  :revdesc "44e28e36ce15"
  :keywords '("frames")
  :authors '(("Viju Mathew" . "viju.jm@gmail.com"))
  :maintainers '(("Viju Mathew" . "viju.jm@gmail.com")))
