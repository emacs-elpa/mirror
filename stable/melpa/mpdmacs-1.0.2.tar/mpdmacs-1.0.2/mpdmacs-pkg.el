;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpdmacs" "1.0.2"
  "A lightweight MPD client."
  '((emacs "29.1")
    (elmpd "1.0"))
  :url "https://github.com/sp1ff/mpdmacs"
  :commit "22c56517d870343e44d61909dbff1f4b69b85b5e"
  :revdesc "1.0.2-0-g22c56517d870"
  :keywords '("comm")
  :authors '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainers '(("Michael Herstine" . "sp1ff@pobox.com")))
