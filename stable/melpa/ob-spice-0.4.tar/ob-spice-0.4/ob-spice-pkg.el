;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-spice" "0.4"
  "Org-babel functions for spice evaluation."
  ()
  :url "http://tiagoweber.github.io"
  :commit "116c3e3a9bff90c62e294b2e0dfd72950bfc65a1"
  :revdesc "116c3e3a9bff")
