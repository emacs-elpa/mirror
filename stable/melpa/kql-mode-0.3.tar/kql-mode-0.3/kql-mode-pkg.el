;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kql-mode" "0.3"
  "Major mode for highlighting KQL."
  '((emacs "26.1"))
  :url "https://gitlab.com/aimebertrand/kql-mode"
  :commit "3833e5d0c95ceca9b1b5ecc3ef379d184b734f04"
  :revdesc "3833e5d0c95c"
  :keywords '("files" "languages" "azure" "entra" "kql" "faces" "syntax" "major-mode"))
