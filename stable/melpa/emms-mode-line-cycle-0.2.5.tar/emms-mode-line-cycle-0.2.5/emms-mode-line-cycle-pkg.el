;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms-mode-line-cycle" "0.2.5"
  "Display the emms mode line as a ticker."
  '((emacs "24")
    (emms  "4.0"))
  :url "https://github.com/momomo5717/emms-mode-line-cycle"
  :commit "2c2f395e484a1d345050ddd61ff5fab71a92a6bc"
  :revdesc "0.2.5-0-g2c2f395e484a"
  :keywords '("emms" "mode-line"))
