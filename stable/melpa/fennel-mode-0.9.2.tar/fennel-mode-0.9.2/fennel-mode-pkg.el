;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fennel-mode" "0.9.2"
  "A major-mode for editing Fennel code."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~technomancy/fennel-mode"
  :commit "14c853c1bef5da29c5e56830bdd6d2b88fe4be57"
  :revdesc "0.9.2-0-g14c853c1bef5"
  :keywords '("languages" "tools"))
