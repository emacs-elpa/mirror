;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "protobuf-mode" "35.1"
  "Major mode for editing protocol buffers."
  ()
  :url "https://github.com/protocolbuffers/protobuf"
  :commit "35cd01f9fe9afbeea38cc7b979a3b6bfcde82c03"
  :revdesc "v35.1-0-g35cd01f9fe9a"
  :keywords '("google" "protobuf" "languages")
  :authors '(("Alexandre Vassalotti" . "alexandre@peadrop.com"))
  :maintainers '(("Alexandre Vassalotti" . "alexandre@peadrop.com")))
