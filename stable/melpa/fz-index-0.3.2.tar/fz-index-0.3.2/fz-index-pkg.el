;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fz-index" "0.3.2"
  "Sublime-style fuzzy file open with a native index."
  '((emacs "28.1"))
  :url "https://github.com/uppet/fz-index"
  :commit "089aee4d2a2f9420bda719fbfbbd33f0dd00b9dc"
  :revdesc "089aee4d2a2f"
  :keywords '("files" "matching" "convenience")
  :authors '(("Joyer Huang" . "collger@gmail.com"))
  :maintainers '(("Joyer Huang" . "collger@gmail.com")))
