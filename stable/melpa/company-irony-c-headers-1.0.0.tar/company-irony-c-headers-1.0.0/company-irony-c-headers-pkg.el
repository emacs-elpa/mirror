;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-irony-c-headers" "1.0.0"
  "Company mode backend for C/C++ header files with Irony."
  '((cl-lib  "0.5")
    (company "0.9.0")
    (irony   "0.2.0"))
  :url "https://github.com/hotpxl/company-irony-c-headers"
  :commit "ba304fe7eebdff90bbc7dea063b45b82638427fa"
  :revdesc "v1.0.0-0-gba304fe7eebd"
  :keywords '("c" "company")
  :authors '(("Yutian Li" . "hotpxless@gmail.com"))
  :maintainers '(("Yutian Li" . "hotpxless@gmail.com")))
