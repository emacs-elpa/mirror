;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browser-gt" "0.95"
  "WebSocket bridge to a Chrome/Firefox extension."
  '((emacs     "27.1")
    (websocket "1.13")
    (org       "9.8"))
  :url "https://github.com/dmgerman/browser-gt"
  :commit "9b2f76b34ca406253d109029da57f4b6d215e532"
  :revdesc "9b2f76b34ca4"
  :keywords '("comm" "tools" "browser" "org")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
