;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jit-lock-stealth-progress" "0.1"
  "JIT lock stealth mode-line progress."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-jit-lock-stealth-progress"
  :commit "e4219797a0132559e7711307fc2caeb3b700dc56"
  :revdesc "e4219797a013"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
