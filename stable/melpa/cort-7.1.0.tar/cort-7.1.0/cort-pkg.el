;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cort" "7.1.0"
  "Simplify extended unit test framework."
  '((emacs "24.4")
    (ansi  "0.4"))
  :url "https://github.com/conao3/cort.el"
  :commit "a2d5ac5639e43dd73b5dbfa5bd011b7760b126fd"
  :revdesc "a2d5ac5639e4"
  :keywords '("test" "lisp")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
