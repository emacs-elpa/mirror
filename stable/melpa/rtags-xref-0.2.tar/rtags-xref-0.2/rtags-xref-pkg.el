;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rtags-xref" "0.2"
  "RTags backend for xref.el."
  '((emacs "25.1")
    (rtags "3.37"))
  :url "http://rtags.net"
  :commit "3931a69bbc8d59d00bc2d2b02b4d5e453bc97d7f"
  :revdesc "3931a69bbc8d")
