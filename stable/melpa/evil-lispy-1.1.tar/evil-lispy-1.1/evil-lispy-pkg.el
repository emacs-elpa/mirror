;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-lispy" "1.1"
  "Precision Lisp editing with Evil and Lispy."
  '((lispy "0.26.0")
    (evil  "1.2.12")
    (hydra "0.13.5"))
  :url "https://github.com/sp3ctum/evil-lispy"
  :commit "040a7ee130c2403a1d6dac591b94b202bb48e186"
  :revdesc "040a7ee130c2"
  :keywords '("lisp")
  :authors '(("Brandon Carrell" . "brandoncarrell@gmail.com")
             ("Mika Vilpas" . "mika.vilpas@gmail.com"))
  :maintainers '(("Brandon Carrell" . "brandoncarrell@gmail.com")
                 ("Mika Vilpas" . "mika.vilpas@gmail.com")))
