;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-backup-ivy" "1.1"
  "An ivy interface to git-backup."
  '((ivy        "0.12.0")
    (git-backup "0.0.1")
    (emacs      "25.1"))
  :url "https://github.com/walseb/git-backup-ivy"
  :commit "0d4dde3e62a2b1159e50c114e1d7aa3ab2a1394a"
  :revdesc "0d4dde3e62a2"
  :keywords '("backup" "convenience" "files" "tools" "vc")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
