;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elysium" "0.0.1"
  "Automatically apply LLM-created code-suggestions."
  '((emacs "27.1")
    (gptel "0.9.0"))
  :url "https://github.com/lanceberge/elysium/"
  :commit "c53afa442bc02a8b9002744f93ee8806187ed381"
  :revdesc "c53afa442bc0"
  :authors '(("Lance Bergeron" . "bergeron.lance6@gmail.com"))
  :maintainers '(("Lance Bergeron" . "bergeron.lance6@gmail.com")))
