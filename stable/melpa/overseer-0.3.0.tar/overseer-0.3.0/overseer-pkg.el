;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overseer" "0.3.0"
  "Ert-runner Integration Into Emacs."
  '((emacs    "24")
    (dash     "2.10.0")
    (pkg-info "0.4"))
  :url "http://www.github.com/tonini/overseer.el"
  :commit "cf532a4e373e3da2077ccbaa48d4bfacd14661ba"
  :revdesc "cf532a4e373e"
  :authors '(("Samuel Tonini" . "tonini.samuel@gmail.com"))
  :maintainers '(("Samuel Tonini" . "tonini.samuel@gmail.com")))
