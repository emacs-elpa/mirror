;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comint-histories" "2.3"
  "Many comint histories."
  '((emacs "29.1")
    (f     "0.21.0"))
  :url "https://github.com/NicholasBHubbard/comint-histories"
  :commit "da9dddafa825a40cd1e25261bb088701c08a80d8"
  :revdesc "da9dddafa825"
  :keywords '("convenience" "processes" "terminals")
  :authors '(("Nicholas Hubbard" . "nicholashubbard@posteo.net"))
  :maintainers '(("Nicholas Hubbard" . "nicholashubbard@posteo.net")))
