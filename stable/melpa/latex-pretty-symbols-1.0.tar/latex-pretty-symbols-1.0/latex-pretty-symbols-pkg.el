;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-pretty-symbols" "1.0"
  "Show many latex commands as their unicode counterparts."
  ()
  :url "https://github.com/epa095/latex-pretty-symbols.el"
  :commit "3f580f1a3a1125633d9a74b661ff5410629c3974"
  :revdesc "3f580f1a3a11"
  :keywords '("convenience" "display"))
