;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "duplexer" "0.2.0"
  "Handle conflicts between local minor modes and reuse rules."
  '((emacs "29.1")
    (dash  "2.19.1"))
  :url "https://github.com/liuyinz/duplexer.el"
  :commit "883e9e24f1c7bb7132c1eac0bf5bedf78081058f"
  :revdesc "883e9e24f1c7"
  :keywords '("tools")
  :authors '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers '(("liuyinz" . "liuyinz95@gmail.com")))
