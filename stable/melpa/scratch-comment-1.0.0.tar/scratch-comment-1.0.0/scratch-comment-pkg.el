;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-comment" "1.0.0"
  "Insert Elisp result as comment in scratch buffer."
  '((emacs "26.1"))
  :url "https://github.com/conao3/scratch-comment.el"
  :commit "d62665ecbeb05d1f92761af185736609278ffba2"
  :revdesc "d62665ecbeb0"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
