;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quiet" "0.1"
  "Disconnect from the online world for a while."
  ()
  :url "https://github.com/zzkt/quiet"
  :commit "aa3a6e039dbc9437e7dd178a6596d43cf19293eb"
  :revdesc "0.1-0-gaa3a6e039dbc"
  :keywords '("convenience" "quiet" "distraction" "network" "detachment" "offline")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
