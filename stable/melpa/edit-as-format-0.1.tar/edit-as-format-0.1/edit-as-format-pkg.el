;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-as-format" "0.1"
  "Edit document as other format."
  '((emacs         "26.1")
    (edit-indirect "0.1.5"))
  :url "https://github.com/etern/edit-as-format"
  :commit "8b7892a41333d2993f208d78f2bde44eda6d3421"
  :revdesc "8b7892a41333"
  :keywords '("files" "outlines" "convenience")
  :authors '(("Xiaobing Jing" . "jingxiaobing@gmail.com"))
  :maintainers '(("Xiaobing Jing" . "jingxiaobing@gmail.com")))
