;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinot" "0.1"
  "Emacs interface to pinot-search."
  ()
  :url "https://github.com/tkf/emacs-pinot-search"
  :commit "f84eda5d35b88d4b4bead18152dfdfeff52349f8"
  :revdesc "f84eda5d35b8"
  :authors '(("Takafumi Arakaki" . "aka.tkfatgmail.com"))
  :maintainers '(("Takafumi Arakaki" . "aka.tkfatgmail.com")))
