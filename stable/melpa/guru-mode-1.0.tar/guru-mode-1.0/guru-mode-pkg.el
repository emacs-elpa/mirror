;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guru-mode" "1.0"
  "Become an Emacs guru."
  ()
  :url "https://github.com/bbatsov/guru-mode"
  :commit "9d0aff6cda6d3d78d5102f07f813b9fca6f0ab7b"
  :revdesc "9d0aff6cda6d"
  :keywords '("convenience"))
