;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghci-completion" "0.1.3"
  "Completion for GHCi commands in inferior-haskell buffers."
  ()
  :url "https://github.com/manzyuk/ghci-completion"
  :commit "82e9a8cb3479bdd23c1291bb8a8f85843e548cd5"
  :revdesc "82e9a8cb3479"
  :keywords '("convenience")
  :authors '(("Oleksandr Manzyuk" . "manzyuk@gmail.com"))
  :maintainers '(("Oleksandr Manzyuk" . "manzyuk@gmail.com")))
