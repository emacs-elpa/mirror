;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-stages" "1.1.0"
  "Highlight staged (quasi-quoted) expressions."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "58913d60a093f4068fd1faaafd91bacd6495a244"
  :revdesc "58913d60a093")
