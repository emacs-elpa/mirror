;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hackernews-modern" "1.7.1"
  "Hacker News client with modern widget UI."
  '((emacs              "28.1")
    (transient          "0.5.0")
    (visual-fill-column "2.2")
    (async-http-queue   "0.1.0"))
  :url "https://git.andros.dev/andros/hackernews-modern-el"
  :commit "7952b961292ca3cf0adc0c2f3bf934b1efb63516"
  :revdesc "7952b961292c"
  :keywords '("comm" "hypermedia" "news")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
