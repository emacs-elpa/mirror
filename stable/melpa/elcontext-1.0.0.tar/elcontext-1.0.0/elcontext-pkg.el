;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elcontext" "1.0.0"
  "[No description available]."
  ()
  :url "https://github.com/rollacaster/elcontext"
  :commit "abbb5cfa04d8ad3385a7c390d48668bd947531de"
  :revdesc "abbb5cfa04d8"
  :keywords '("context" "time" "timespan" "location" "gps" "action"))
