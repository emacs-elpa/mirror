;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latvian-holidays" "1.0.0"
  "Latvian holidays for the calendar."
  ()
  :url "https://github.com/ashumilov/latvian-holidays"
  :commit "994662f8663305eb874efc49daf0eedfaf46e9a0"
  :revdesc "994662f86633"
  :keywords '("calendar")
  :authors '(("Alexander Shumilov" . "alexander.shumilov@me.com"))
  :maintainers '(("Alexander Shumilov" . "alexander.shumilov@me.com")))
