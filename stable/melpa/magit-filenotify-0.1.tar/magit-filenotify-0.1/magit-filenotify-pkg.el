;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-filenotify" "0.1"
  "Refresh status buffer when git tree changes."
  '((magit "1.3.0")
    (emacs "24.4"))
  :url "https://github.com/ruediger/magit-filenotify"
  :commit "575c4321f61fb8f25e4779f9ffd4514ac086ae96"
  :revdesc "575c4321f61f"
  :keywords '("tools")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.de"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.de")))
