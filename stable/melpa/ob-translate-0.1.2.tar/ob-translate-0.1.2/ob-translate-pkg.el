;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-translate" "0.1.2"
  "Translation of text blocks in org-mode."
  '((google-translate "0.4")
    (org              "8"))
  :url "https://github.com/krisajenkins/ob-translate"
  :commit "6b39cc1a94a1071107a4391684b1bffb5b9826f3"
  :revdesc "6b39cc1a94a1"
  :keywords '("org" "babel" "translate" "translation")
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
