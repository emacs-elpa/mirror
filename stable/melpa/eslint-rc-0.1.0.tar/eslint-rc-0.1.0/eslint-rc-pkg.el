;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eslint-rc" "0.1.0"
  "Minor mode for eslint to use local rc rules."
  '((emacs      "24")
    (eslint-fix "0.1.0"))
  :url "https://github.com/jjuliano/eslint-rc-emacs"
  :commit "7eb243cde1e70fc8cbe9d7c0de29c90f8eb2fa8d"
  :revdesc "7eb243cde1e7"
  :keywords '("convenience" "edit" "js" "ts" "rc" "eslintrc" "eslint-rc" "eslint" "eslint-fix")
  :authors '(("Joel Bryan Juliano" . "joelbryandotjulianoatgmaildotcom"))
  :maintainers '(("Joel Bryan Juliano" . "joelbryandotjulianoatgmaildotcom")))
