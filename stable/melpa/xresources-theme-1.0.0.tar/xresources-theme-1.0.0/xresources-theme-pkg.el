;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xresources-theme" "1.0.0"
  "Use your .Xresources as your emacs theme."
  ()
  :url "https://github.com/martenlienen/xresources-theme"
  :commit "5239acb51aa2dfa89a207e57012108d8fcf60562"
  :revdesc "5239acb51aa2"
  :keywords '("xresources" "theme")
  :authors '(("Marten Lienen" . "marten.lienen@gmail.com"))
  :maintainers '(("Marten Lienen" . "marten.lienen@gmail.com")))
