;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noccur" "0.2"
  "Run multi-occur on project/dired files."
  ()
  :url "https://github.com/NicolasPetton/noccur.el"
  :commit "6cc02ce07178a61ae38a849f80472c01969272bc"
  :revdesc "6cc02ce07178"
  :keywords '("convenience")
  :authors '(("Nicolas Petton" . "petton.nicolas@gmail.com"))
  :maintainers '(("Nicolas Petton" . "petton.nicolas@gmail.com")))
