;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tree-slide-pauses" "0.1.0"
  "Bring the \\pause Beamer to org-tree-slide!."
  '((emacs          "24.4")
    (org-tree-slide "2.8.4"))
  :url "https://github.com/cnngimenez/org-tree-slide-pauses"
  :commit "80d6e9279fad10bcff15fbce75726bb002da73c0"
  :revdesc "80d6e9279fad"
  :keywords '("convenience" "org-mode" "presentation"))
