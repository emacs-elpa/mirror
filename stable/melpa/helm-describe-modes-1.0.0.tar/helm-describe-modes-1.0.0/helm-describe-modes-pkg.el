;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-describe-modes" "1.0.0"
  "Helm interface to major and minor modes."
  '((helm   "1.9")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/emacs-helm/helm-describe-modes"
  :commit "c9ee5e1be4f463c44db1edca1da2795a016cb101"
  :revdesc "c9ee5e1be4f4"
  :keywords '("docs" "convenience")
  :authors '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com"))
  :maintainers '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com")))
