;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ext" "0.8.0"
  "VHDL Extensions."
  '((emacs        "29.1")
    (vhdl-ts-mode "0.3.3")
    (lsp-mode     "8.0.0")
    (rg           "2.3.0")
    (hydra        "0.15.0")
    (flycheck     "32")
    (async        "1.9.7"))
  :url "https://github.com/gmlarumbe/vhdl-ext"
  :commit "22fa38698bdf106194c02a6d2e3830d8685437fb"
  :revdesc "22fa38698bdf"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
