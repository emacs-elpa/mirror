;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wwtime" "1.5"
  "Insert a time of day with appropriate world-wide localization."
  ()
  :url "https://github.com/ndw/wwtime"
  :commit "6722d3c19e867c6bd68b23c059f297a4aaa95e18"
  :revdesc "6722d3c19e86"
  :keywords '("time")
  :authors '(("Norman Walsh" . "ndw@nwalsh.com"))
  :maintainers '(("Norman Walsh" . "ndw@nwalsh.com")))
