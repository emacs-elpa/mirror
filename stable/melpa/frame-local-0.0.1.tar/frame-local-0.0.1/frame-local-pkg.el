;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frame-local" "0.0.1"
  "Variables local to a frame."
  '((emacs "25.1"))
  :url "https://github.com/sebastiencs/frame-local"
  :commit "c033827becff562d9717f34c23f6f3a1033809ea"
  :revdesc "c033827becff"
  :keywords '("frames" "tools" "local" "lisp")
  :authors '(("Sebastien Chapuis" . "sebastien@chapu.is"))
  :maintainers '(("Sebastien Chapuis" . "sebastien@chapu.is")))
