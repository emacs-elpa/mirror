;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-haskell" "0.8"
  "Flycheck: Automatic Haskell configuration."
  '((emacs        "24.3")
    (flycheck     "0.25")
    (haskell-mode "13.7")
    (dash         "2.4.0")
    (seq          "1.11")
    (let-alist    "1.0.1"))
  :url "https://github.com/flycheck/flycheck-haskell"
  :commit "ee3401d97cc5e8edc216f2369e9dea3d363e462c"
  :revdesc "0.8-0-gee3401d97cc5"
  :keywords '("tools" "convenience")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
