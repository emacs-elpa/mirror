;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pebble-mode" "0.3"
  "A major mode for pebble."
  ()
  :url "https://github.com/ArneBab/pebble-mode"
  :commit "970ad88b100d608d97c7f4a3523ffb63032191e3"
  :revdesc "970ad88b100d")
