;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcap-mode" "0.2"
  "Major mode for working with PCAP files."
  '((emacs "24.3"))
  :url "https://github.com/apconole/pcap-mode"
  :commit "ea2d641af1a51dacf790446517ef4dea26b52d57"
  :revdesc "ea2d641af1a5"
  :keywords '("pcap" "packets" "tcpdump" "wireshark" "tshark")
  :authors '(("Aaron Conole" . "aconole@bytheb.org"))
  :maintainers '(("Aaron Conole" . "aconole@bytheb.org")))
