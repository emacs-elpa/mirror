;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.14"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "75be36fe63e78c63ac71c32039ab07836bd532ac"
  :revdesc "2.14-0-g75be36fe63e7"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
