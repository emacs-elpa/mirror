;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wgrep-deadgrep" "2.3.0"
  "Writable deadgrep buffer and apply the changes to files."
  '((wgrep "2.3.0"))
  :url "https://github.com/mhayashi1120/Emacs-wgrep/raw/master/wgrep-deadgrep.el"
  :commit "3584e9ba43287d712e0c17df5328211c174e9c60"
  :revdesc "3584e9ba4328"
  :keywords '("grep" "edit" "extensions")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")
             ("Iku Iwasa" . "iku.iwasa@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")
                 ("Iku Iwasa" . "iku.iwasa@gmail.com")))
