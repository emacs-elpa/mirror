;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pretty-mode" "2.0.3"
  "Redisplay parts of the buffer as pretty symbols."
  ()
  :url "https://github.com/akatov/pretty-mode"
  :commit "4ba8fceb7dd733361ed975d80ac2caa3612fa78b"
  :revdesc "4ba8fceb7dd7"
  :keywords '("pretty" "unicode" "symbols")
  :authors '(("Arthur Danskin" . "arthurdanskin@gmail.com"))
  :maintainers '(("Dmitri Akatov" . "akatov@gmail.com")))
