;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdb-capf" "1.0"
  "Completion-at-point function for python debugger."
  '((emacs "25.1"))
  :url "https://github.com/muffinmad/emacs-pdb-capf"
  :commit "a26734a72cdead7686305d3686238106d3d6c553"
  :revdesc "a26734a72cde"
  :keywords '("languages" "abbrev" "convenience")
  :authors '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com"))
  :maintainers '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com")))
