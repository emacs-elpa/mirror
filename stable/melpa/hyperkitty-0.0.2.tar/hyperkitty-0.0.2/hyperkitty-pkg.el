;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperkitty" "0.0.2"
  "Emacs interface for Hyperkitty archives."
  '((request "0.3.2")
    (emacs   "25.1"))
  :url "https://github.com/maxking/hyperkitty.el"
  :commit "fcb923616e69d8f72c2f4a666d381a6a66bc12bc"
  :revdesc "v0.0.2-0-gfcb923616e69"
  :keywords '("mail" "hyperkitty" "mailman")
  :authors '(("Abhilash Raj" . "maxking@asynchronous.in"))
  :maintainers '(("Abhilash Raj" . "maxking@asynchronous.in")))
