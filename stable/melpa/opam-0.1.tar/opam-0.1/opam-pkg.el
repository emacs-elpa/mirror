;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "opam" "0.1"
  "OPAM tools."
  '((emacs "24.1"))
  :url "https://github.com/lunaryorn/opam.el"
  :commit "83fb2850d29ec792754e0af18b015e089aad2695"
  :revdesc "0.1-0-g83fb2850d29e"
  :keywords '("convenience")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
