;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "world-time-mode" "0.0.6"
  "Show whole days of world-time diffs."
  ()
  :url "https://github.com/nicferrier/emacs-world-time-mode"
  :commit "ce7a3b45c87eb24cfe61eee453175d64f741d7cc"
  :revdesc "ce7a3b45c87e"
  :keywords '("tools" "calendar")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
