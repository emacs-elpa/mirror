;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stylefmt" "0.0.2"
  "Stylefmt interface."
  ()
  :url "https://github.com/KeenS/stylefmt.el"
  :commit "c98e7fc79c42d1b12586471b6177bd93f321a69d"
  :revdesc "c98e7fc79c42"
  :keywords '("style" "code" "formatter"))
