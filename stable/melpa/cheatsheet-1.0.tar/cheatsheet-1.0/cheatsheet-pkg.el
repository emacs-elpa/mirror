;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cheatsheet" "1.0"
  "Helps you to create your own cheatsheet and start using emacs plugins without learning keys."
  '((emacs "24"))
  :url "https://github.com/darksmile/cheatsheet/"
  :commit "9ef3ff09fea26b184033ff552b6dddb9bcd4e23f"
  :revdesc "9ef3ff09fea2"
  :keywords '("convenience" "usability")
  :authors '(("Shirin Nikita" . "shirin.nikita@gmail.com"))
  :maintainers '(("Shirin Nikita" . "shirin.nikita@gmail.com")))
