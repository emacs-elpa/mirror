;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-jump-buffer" "0.4.1"
  "Fast buffer switching extension to `avy'."
  '((avy  "0.4.0")
    (dash "2.4.0"))
  :url "https://github.com/waymondo/ace-jump-buffer"
  :commit "02797c22c10a817dbbdfbd8fddceeba6c4f0499a"
  :revdesc "02797c22c10a"
  :authors '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainers '(("Justin Talbott" . "justin@waymondo.com")))
