;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apropospriate-theme" "0.2.0"
  "A colorful, low-contrast, light & dark theme set for Emacs with a fun name."
  ()
  :url "https://github.com/waymondo/apropospriate-theme"
  :commit "17ec6fc0f43f7c0bcb970e2b71b8674891a464c7"
  :revdesc "17ec6fc0f43f")
