;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apropospriate-theme" "0.2.0"
  "[No description available]."
  ()
  :url "https://github.com/waymondo/apropospriate-theme"
  :commit "17ec6fc0f43f7c0bcb970e2b71b8674891a464c7"
  :revdesc "17ec6fc0f43f")
