;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sbt-mode" "2.0.0"
  "Interactive support for sbt projects."
  '((emacs "24.4"))
  :url "https://github.com/ensime/emacs-sbt-mode"
  :commit "e658af140547cbef495c33535c7f694a501d318c"
  :revdesc "v2.0.0-0-ge658af140547"
  :keywords '("languages"))
