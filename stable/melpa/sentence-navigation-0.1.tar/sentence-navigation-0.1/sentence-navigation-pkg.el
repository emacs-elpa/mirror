;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sentence-navigation" "0.1"
  "Commands to navigate one-spaced sentences."
  '((cl-lib "0.5"))
  :url "https://github.com/angelic-sedition/emacs-sentence-navigation"
  :commit "7c1d74ec6aeacded6c388f009719b365ae47e0f6"
  :revdesc "7c1d74ec6aea"
  :keywords '("sentence" "evil")
  :authors '(("Lit Wakefield" . "nocturnal.artifice@gmail.com"))
  :maintainers '(("Lit Wakefield" . "nocturnal.artifice@gmail.com")))
