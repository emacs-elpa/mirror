;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lit-ts-mode" "0.1.0"
  "Lit-aware JS/TS modes with tree-sitter support."
  '((emacs                     "30.1")
    (template-literals-ts-mode "0.1.0"))
  :url "https://github.com/ispringle/lit-ts-mode"
  :commit "b5fd0b08659df7837853b68e78005b6db9fe2965"
  :revdesc "b5fd0b08659d"
  :keywords '("languages" "javascript" "typescript" "tree-sitter" "lit"))
