;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.92.1"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "830e15cc1bdc6bdea89b95e6a4f80f82d1436960"
  :revdesc "830e15cc1bdc")
