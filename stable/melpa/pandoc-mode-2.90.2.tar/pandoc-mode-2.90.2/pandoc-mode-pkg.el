;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pandoc-mode" "2.90.2"
  "Minor mode for interacting with Pandoc."
  ()
  :url "http://joostkremers.github.io/pandoc-mode/"
  :commit "a131a553f48db71b0a051b6bc1d713627b2de3d9"
  :revdesc "a131a553f48d"
  :keywords '("text" "pandoc")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
