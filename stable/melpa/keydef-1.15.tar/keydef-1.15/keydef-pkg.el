;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keydef" "1.15"
  "A simpler way to define keys, with kbd syntax."
  ()
  :url "https://github.com/emacsorphanage/keydef"
  :commit "dff2be9f58d12d8c6a490ad0c1b2b10b55528dc0"
  :revdesc "1.15-0-gdff2be9f58d1"
  :keywords '("convenience" "lisp" "customization" "keyboard" "keys")
  :authors '(("Michael John Downes" . "mjd@ams.org"))
  :maintainers '(("Michael John Downes" . "mjd@ams.org")))
