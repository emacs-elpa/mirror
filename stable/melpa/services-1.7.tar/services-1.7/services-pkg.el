;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "services" "1.7"
  "Services database access functions."
  '((cl-lib "0.5"))
  :url "https://github.com/davep/services.el"
  :commit "514e4095e8964c4d0f38c4f3ad6c692e86d12faa"
  :revdesc "514e4095e896"
  :keywords '("convenience" "net" "services")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
