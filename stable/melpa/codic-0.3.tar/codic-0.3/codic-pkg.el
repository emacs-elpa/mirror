;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codic" "0.3"
  "Search Codic (codic.jp) naming dictionaries."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/syohex/emacs-codic"
  :commit "52bbb6997ef4ab9fb7fea43bbfff7f04671aa557"
  :revdesc "52bbb6997ef4"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
