;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verona-mode" "0.0.1"
  "A major mode for the Verona programming language."
  '((dash                  "2.17.0")
    (hydra                 "0.15.0")
    (hl-todo               "3.1.2")
    (yafolding             "0.4.1")
    (yasnippet             "0.14.0")
    (rainbow-delimiters    "2.1.4")
    (fill-column-indicator "1.90"))
  :url "https://github.com/damon-kwok/verona-mode"
  :commit "58b8fda7f4b424e50df4ead2d70e6cd6bbe15028"
  :revdesc "58b8fda7f4b4"
  :keywords '("languages" "programming")
  :authors '(("Damon Kwok" . "damon-kwok@outlook.com"))
  :maintainers '(("Damon Kwok" . "damon-kwok@outlook.com")))
