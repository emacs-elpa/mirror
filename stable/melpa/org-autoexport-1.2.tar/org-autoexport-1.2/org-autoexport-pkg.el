;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-autoexport" "1.2"
  "Auto-export org file on save."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://git.sr.ht/~zondo/org-autoexport"
  :commit "0cd22707014f3ee14da6fa823b3991e2ebddf0dc"
  :revdesc "0cd22707014f"
  :keywords '("org" "wp")
  :authors '(("Glenn Hutchings" . "zondo42@gmail.com"))
  :maintainers '(("Glenn Hutchings" . "zondo42@gmail.com")))
