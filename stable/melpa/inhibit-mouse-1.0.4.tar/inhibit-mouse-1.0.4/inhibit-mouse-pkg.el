;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inhibit-mouse" "1.0.4"
  "Deactivate mouse input (alternative to disable-mouse)."
  '((emacs "24.1"))
  :url "https://github.com/jamescherti/inhibit-mouse.el"
  :commit "86cae75bbb771ea6be6269b925c39761be12b065"
  :revdesc "1.0.4-0-g86cae75bbb77"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
