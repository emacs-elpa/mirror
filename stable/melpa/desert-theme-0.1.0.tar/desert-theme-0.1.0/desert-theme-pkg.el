;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "desert-theme" "0.1.0"
  "A warm earthy port of Vim's desert theme."
  '((emacs "24.1"))
  :url "https://github.com/yourname/desert-theme"
  :commit "aba214d59eb1945f2aa4e62e64a2cff8bd883ab5"
  :revdesc "aba214d59eb1"
  :keywords '("faces" "theme" "vim" "desert")
  :authors '(("Your Name" . "you@example.com"))
  :maintainers '(("Your Name" . "you@example.com")))
