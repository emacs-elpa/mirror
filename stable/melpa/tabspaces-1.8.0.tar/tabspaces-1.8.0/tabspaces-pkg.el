;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "1.8.0"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://github.com/mclear-tools/tabspaces"
  :commit "ea95efb5b2ef265e3c48059801554042ab0813b3"
  :revdesc "ea95efb5b2ef"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
