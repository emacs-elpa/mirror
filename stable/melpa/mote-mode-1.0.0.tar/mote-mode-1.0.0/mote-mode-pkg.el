;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mote-mode" "1.0.0"
  "Mote minor mode."
  '((ruby-mote "1.0"))
  :url "http://inkel.github.com/mote-mode/"
  :commit "60fba6da9e753e0ce3f4990569b193a58b9ca8f7"
  :revdesc "60fba6da9e75"
  :authors '(("Leandro López" . "inkel.ar@gmail.com"))
  :maintainers '(("Leandro López" . "inkel.ar@gmail.com")))
