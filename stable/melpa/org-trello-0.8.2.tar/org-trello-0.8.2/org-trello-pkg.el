;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-trello" "0.8.2"
  "Minor mode to synchronize org-mode buffer and trello board."
  '((dash             "2.12.1")
    (dash-functional  "2.12.1")
    (s                "1.11.0")
    (deferred         "0.4.0")
    (request-deferred "0.2.0"))
  :url "https://github.com/org-trello/org-trello"
  :commit "4ddc257fe24e97c01e12b247568581ff255f0e8d"
  :revdesc "0.8.2-0-g4ddc257fe24e"
  :keywords '("org-mode" "trello" "sync" "org-trello")
  :authors '(("Antoine R. Dumont" . "antoine.romain.dumont@gmail.com"))
  :maintainers '(("Antoine R. Dumont" . "antoine.romain.dumont@gmail.com")))
