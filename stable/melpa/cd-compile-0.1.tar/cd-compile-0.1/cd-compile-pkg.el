;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cd-compile" "0.1"
  "Run compile in a specific directory."
  ()
  :url "https://github.com/jamienicol/emacs-cd-compile"
  :commit "a6f3dc2caa28893e26e48eb11a2a06e87f61cc4d"
  :revdesc "a6f3dc2caa28"
  :authors '(("Jamie Nicol" . "jamie@thenicols.net"))
  :maintainers '(("Jamie Nicol" . "jamie@thenicols.net")))
