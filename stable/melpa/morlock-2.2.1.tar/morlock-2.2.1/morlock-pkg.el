;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morlock" "2.2.1"
  "More font-lock keywords for elisp."
  '((emacs "29.1"))
  :url "https://github.com/emacsattic/morlock"
  :commit "1033ba0206deb01995d1c0074a5d60da38d1f576"
  :revdesc "v2.2.1-0-g1033ba0206de"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev")))
