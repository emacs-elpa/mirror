;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.55.1"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.1")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d354db516b6ce8ddc00461e547adc2bae3b07d9d"
  :revdesc "d354db516b6c")
