;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "general" "0.1"
  "Convenience wrappers for keybindings."
  '((emacs  "24.4")
    (dash   "2.11.0")
    (cl-lib "0.5"))
  :url "https://github.com/noctuid/general.el"
  :commit "13f5a7653fe635d94bac643225e9db76585f57b3"
  :revdesc "13f5a7653fe6"
  :keywords '("vim" "evil" "leader" "keybindings" "keys")
  :authors '(("Fox Kiester" . "noct@openmailbox.org"))
  :maintainers '(("Fox Kiester" . "noct@openmailbox.org")))
