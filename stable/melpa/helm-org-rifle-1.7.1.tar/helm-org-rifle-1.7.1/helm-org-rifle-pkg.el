;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-org-rifle" "1.7.1"
  "Rifle through your Org files."
  '((emacs "24.4")
    (dash  "2.12")
    (f     "0.18.1")
    (helm  "1.9.4")
    (s     "1.10.0"))
  :url "https://github.com/alphapapa/helm-org-rifle"
  :commit "263f56d70112f5d0496684c89a2aa07959e0a95f"
  :revdesc "1.7.1-0-g263f56d70112"
  :keywords '("hypermedia" "outlines")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
