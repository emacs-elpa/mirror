;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "focus" "1.0.1"
  "Dim the font color of text in surrounding sections."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/larstvei/Focus"
  :commit "2507ec4ec5a9402647ef85540669db1815520c15"
  :revdesc "2507ec4ec5a9"
  :authors '(("Lars Tveito" . "larstvei@ifi.uio.no"))
  :maintainers '(("Lars Tveito" . "larstvei@ifi.uio.no")))
