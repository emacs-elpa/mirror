;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "feature-mode" "0.6.2"
  "Major mode for editing Gherkin (i.e. Cucumber) user stories."
  '((emacs "28.1"))
  :url "https://github.com/freesteph/cucumber.el"
  :commit "76c91c05d15aca7732315b46dd3dcc13ec5235fd"
  :revdesc "76c91c05d15a")
