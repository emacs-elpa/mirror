;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-inline-pdfcomment" "1.0.2"
  "Export Support for Inline Tasks as PDF Comments."
  '((emacs "24.4"))
  :url "https://git.sr.ht/~swflint/org-inline-pdfcomment"
  :commit "0ff90ae65ba2948b44b02174f29d1fa12a0675ed"
  :revdesc "v1.0.2-0-g0ff90ae65ba2"
  :keywords '("docs" "text")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
