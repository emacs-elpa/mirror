;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meson-mode" "0.4"
  "Major mode for the Meson build system files."
  '((emacs "26.1"))
  :url "https://github.com/wentasah/meson-mode"
  :commit "c8f4fbf075bb5db2bc0872afe02af2edac075e4e"
  :revdesc "v0.4-0-gc8f4fbf075bb"
  :keywords '("languages" "tools")
  :authors '(("Michal Sojka" . "sojkam1@fel.cvut.cz"))
  :maintainers '(("Michal Sojka" . "sojkam1@fel.cvut.cz")))
