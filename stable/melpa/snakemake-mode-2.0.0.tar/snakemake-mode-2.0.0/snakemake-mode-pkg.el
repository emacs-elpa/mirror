;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snakemake-mode" "2.0.0"
  "Major mode for editing Snakemake files."
  '((emacs     "26.1")
    (transient "0.3.0"))
  :url "https://git.kyleam.com/snakemake-mode/about"
  :commit "78abd82f34a71b3fff7aa869de1b07a082f1f351"
  :revdesc "v2.0.0-0-g78abd82f34a7"
  :keywords '("tools")
  :authors '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainers '(("Kyle Meyer" . "kyle@kyleam.com")))
