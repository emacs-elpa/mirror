;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "1.0.1"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "5082e3492a7f760cda3c2764f4b9a38b18bd44f3"
  :revdesc "1.0.1-0-g5082e3492a7f"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
