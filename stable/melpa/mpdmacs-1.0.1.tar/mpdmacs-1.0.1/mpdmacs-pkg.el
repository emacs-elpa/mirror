;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpdmacs" "1.0.1"
  "A lightweight MPD client."
  '((emacs "29.1")
    (elmpd "0.3"))
  :url "https://github.com/sp1ff/mpdmacs"
  :commit "e11d46925ce711de37352fb0a243a2cb55f873a3"
  :revdesc "1.0.1-0-ge11d46925ce7"
  :keywords '("comm")
  :authors '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainers '(("Michael Herstine" . "sp1ff@pobox.com")))
