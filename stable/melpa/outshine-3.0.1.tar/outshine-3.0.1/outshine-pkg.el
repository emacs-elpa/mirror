;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outshine" "3.0.1"
  "Outline with outshine outshines outline."
  '((outorg "2.0")
    (cl-lib "0.5"))
  :url "https://github.com/alphapapa/outshine"
  :commit "3edf0c61e94d36d174120c8080a98023e30a58a2"
  :revdesc "v3.0.1-0-g3edf0c61e94d"
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
