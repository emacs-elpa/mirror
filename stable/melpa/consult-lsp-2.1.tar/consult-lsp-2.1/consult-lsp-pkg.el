;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-lsp" "2.1"
  "LSP-mode Consult integration."
  '((emacs    "27.1")
    (lsp-mode "5.0")
    (consult  "1.9")
    (f        "0.20.0"))
  :url "https://github.com/gagbo/consult-lsp"
  :commit "fb8ca4e91487d4f4bd15df55863d04e4cbf71f1c"
  :revdesc "fb8ca4e91487"
  :keywords '("tools" "completion" "lsp"))
