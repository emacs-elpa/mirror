;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "find-by-pinyin-dired" "0.0.3"
  "Find file by first PinYin character of Chinese Hanzi."
  '((pinyinlib "0.1.0"))
  :url "https://github.com/redguardtoo/find-by-pinyin-dired"
  :commit "2c48434637bd63840fca4d2c6cf9ebd5dd44658f"
  :revdesc "2c48434637bd"
  :keywords '("hanzi" "chinese" "dired" "find" "file" "pinyin")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
