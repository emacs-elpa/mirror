;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.2.3"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "32ca0ac5cbdcee537ff991d803d26269e8e36e53"
  :revdesc "1.2.3-0-g32ca0ac5cbdc"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
