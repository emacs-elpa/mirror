;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "1.11.0"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://codeberg.org/mclear-tools/tabspaces"
  :commit "22aede80ba79532148cd2d210f76a02f6abcfd9f"
  :revdesc "22aede80ba79"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
