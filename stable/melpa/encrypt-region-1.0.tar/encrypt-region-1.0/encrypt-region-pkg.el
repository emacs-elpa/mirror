;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "encrypt-region" "1.0"
  "Encrypts and decrypts regions."
  '((emacs "26.1"))
  :url "https://github.com/cgshep/encrypt-region"
  :commit "76d4e621c188467bfb9608ab9662215e7352cd77"
  :revdesc "v1.0-0-g76d4e621c188"
  :keywords '("tools" "convenience")
  :authors '(("Carlton Shepherd" . "carlton@linux.com"))
  :maintainers '(("Carlton Shepherd" . "carlton@linux.com")))
