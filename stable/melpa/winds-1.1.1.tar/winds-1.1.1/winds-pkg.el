;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winds" "1.1.1"
  "Window configuration switcher grouped by workspaces."
  '((emacs "25.1"))
  :url "https://github.com/Javyre/winds.el"
  :commit "8f2ac788a3d5b5123ed98b8b10c56f809c67817e"
  :revdesc "8f2ac788a3d5"
  :keywords '("convenience")
  :authors '(("Javier A. Pollak" . "javi.po.123@gmail.com"))
  :maintainers '(("Javier A. Pollak" . "javi.po.123@gmail.com")))
