;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xwidgete" "0.3"
  "[No description available]."
  '((emacs "25"))
  :url "https://github.com/tuhdo/semantic-refactor"
  :commit "2a4caaef25875996d35697ceed060a817a4c8b9f"
  :revdesc "2a4caaef2587"
  :keywords '("xwidgete" "tools")
  :authors '(("Do Hoang" . "tuhdo1710@gmail.com")))
