;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "0.13.0"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.4.4"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "6335a1c796ae4510a4c335f00e9b8d3eac7985a5"
  :revdesc "6335a1c796ae"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
