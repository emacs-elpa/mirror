;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-clojuredocs" "0.1"
  "Search for help in clojuredocs.org."
  '((edn "1.1.2")
    (ivy "0.12.0"))
  :url "https://github.com/wandersoncferreira/ivy-clojuredocs"
  :commit "7c099f590bef99b20b92f985dac5dbdca3b88434"
  :revdesc "7c099f590bef"
  :keywords '("ivy" "clojure")
  :authors '(("Wanderson Ferreira" . "iagwanderson@gmail.com"))
  :maintainers '(("Wanderson Ferreira" . "iagwanderson@gmail.com")))
