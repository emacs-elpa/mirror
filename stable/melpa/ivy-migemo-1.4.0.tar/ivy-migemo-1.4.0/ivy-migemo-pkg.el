;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-migemo" "1.4.0"
  "Use migemo on ivy."
  '((emacs   "24.3")
    (ivy     "0.13.0")
    (migemo  "1.9.2")
    (nadvice "0.3"))
  :url "https://github.com/ROCKTAKEY/ivy-migemo"
  :commit "2d44f7bbc1eb5f95162db889b889488b65bc0042"
  :revdesc "2d44f7bbc1eb"
  :keywords '("matching")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
