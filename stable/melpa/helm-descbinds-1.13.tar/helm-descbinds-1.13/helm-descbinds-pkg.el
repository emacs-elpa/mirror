;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-descbinds" "1.13"
  "A convenient `describe-bindings' with `helm'."
  '((helm "1.5"))
  :url "https://github.com/emacs-helm/helm-descbinds"
  :commit "6d5ddc11e6cef86548bd6b3e0d840112d602659c"
  :revdesc "v1.13-0-g6d5ddc11e6ce"
  :keywords '("helm" "help")
  :authors '(("Taiki SUGAWARA" . "buzz.taiki@gmail.com"))
  :maintainers '(("Taiki SUGAWARA" . "buzz.taiki@gmail.com")))
