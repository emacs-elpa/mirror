;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "govc" "0.55.1"
  "Interface to govc for managing VMware ESXi and vCenter."
  '((emacs       "24.3")
    (dash        "1.5.0")
    (s           "1.9.0")
    (magit-popup "2.0.50")
    (json-mode   "1.6.0"))
  :url "https://github.com/vmware/govmomi/tree/main/govc/emacs"
  :commit "1e372f1c01953d43fe4d573eb60f33f7e3d3aa41"
  :revdesc "v0.55.1-0-g1e372f1c0195"
  :keywords '("convenience"))
