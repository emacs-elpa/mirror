;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elscreen-mew" "1.0.2"
  "ElScreen Add-On for Mew."
  '((elscreen "20120413.807"))
  :url "https://github.com/masutaka/elscreen-mew"
  :commit "89871fad690ae161dc076e16ef481b1965612077"
  :revdesc "1.0.2-0-g89871fad690a"
  :authors '(("Takashi Masuda" . "masutaka.net@gmail.com"))
  :maintainers '(("Takashi Masuda" . "masutaka.net@gmail.com")))
