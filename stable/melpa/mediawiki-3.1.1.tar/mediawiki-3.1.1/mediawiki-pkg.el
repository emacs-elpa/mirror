;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "3.1.1"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "afae2890503222e4964bd6ed60e756498a267628"
  :revdesc "3.1.1-0-gafae28905032"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
