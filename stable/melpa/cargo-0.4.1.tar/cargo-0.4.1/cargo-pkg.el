;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cargo" "0.4.1"
  "Emacs Minor Mode for Cargo, Rust's Package Manager."
  '((emacs     "24.3")
    (rust-mode "0.2.0"))
  :url "https://github.com/kwrooijen/cargo.el"
  :commit "b0487f95a7de7a1d6f03cdd05220f633977d65a2"
  :revdesc "b0487f95a7de"
  :keywords '("tools")
  :authors '(("Kevin W. van Rooijen" . "kevin.van.rooijen@attichacker.com"))
  :maintainers '(("Kevin W. van Rooijen" . "kevin.van.rooijen@attichacker.com")))
