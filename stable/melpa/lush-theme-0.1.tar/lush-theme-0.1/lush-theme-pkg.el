;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lush-theme" "0.1"
  "A Dark Theme with strong colors for Emacs24."
  ()
  :url "https://github.com/andre-richter/emacs-lush-theme"
  :commit "18b12889fcc8c778ddb01f90823d2ec033bfbd63"
  :revdesc "18b12889fcc8"
  :keywords '("theme" "dark" "strong colors")
  :authors '(("Andre Richter" . "andre.o.richter@gmail.com"))
  :maintainers '(("Andre Richter" . "andre.o.richter@gmail.com")))
