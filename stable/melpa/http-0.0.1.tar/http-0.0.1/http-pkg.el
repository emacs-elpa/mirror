;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http" "0.0.1"
  "An HTTP client for Emacs."
  '((s       "1.9.0")
    (request "0.2.0"))
  :url "https://github.com/emacs-pe/http.el"
  :commit "21694a85f4eaeac7441c88427fc95c1ec87e8313"
  :revdesc "21694a85f4ea"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
