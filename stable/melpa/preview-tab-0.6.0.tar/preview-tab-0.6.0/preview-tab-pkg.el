;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "preview-tab" "0.6.0"
  "Temporary file buffers, like VS Code's preview tab."
  '((emacs "27.1"))
  :url "https://github.com/ismd/preview-tab.el"
  :commit "650a571544003cbf630dc35fda52ddff3f8caacf"
  :revdesc "650a57154400"
  :keywords '("convenience" "files")
  :authors '(("Vladimir Kosteley" . "github@ismd.dev"))
  :maintainers '(("Vladimir Kosteley" . "github@ismd.dev")))
