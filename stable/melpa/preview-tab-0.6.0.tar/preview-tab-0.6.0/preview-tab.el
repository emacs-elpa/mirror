;;; preview-tab.el --- Temporary file buffers, like VS Code's preview tab  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Vladimir Kosteley

;; Author: Vladimir Kosteley <github@ismd.dev>
;; Assisted-by: Claude:claude-opus-5
;; Package-Version: 0.6.0
;; Package-Revision: 650a57154400
;; URL: https://github.com/ismd/preview-tab.el
;; Keywords: convenience, files
;; Package-Requires: ((emacs "27.1"))
;; SPDX-License-Identifier: GPL-3.0-or-later

;; This file is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 3, or (at your option)
;; any later version.
;;
;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Browsing a project in Emacs leaves a trail of buffers behind.  Every file you
;; glanced at from the file tree, every definition you jumped to, every grep hit
;; you opened stays in the buffer list forever.
;;
;; VS Code solves this with the preview tab: a file opened by browsing goes into
;; a single italicised tab, the next such file replaces it, and the tab only
;; becomes permanent once you edit it.  `preview-tab-mode' brings that to Emacs.
;;
;; Enable it and the commands in `preview-tab-commands' -- file managers, xref,
;; grep, consult and friends -- open files into one temporary buffer:
;;
;;     (preview-tab-mode 1)
;;
;; The preview buffer is killed when the next preview replaces it, and it turns
;; into an ordinary buffer as soon as you edit it or run `preview-tab-keep'.
;; A buffer that was already open is never demoted to a preview, and a preview
;; that is modified, visible in another window, or running a process is never
;; killed -- it becomes an ordinary buffer instead.
;;
;; Two commands are provided beyond the mode itself:
;;
;;   `preview-tab-find-file'  visit a file as a preview instead of for good --
;;                            the deliberate "just let me look at it"
;;                            counterpart to `find-file'
;;   `preview-tab-keep'       keep the current preview buffer for good
;;
;; Typing a file name is taken as a deliberate act and opens the file for good,
;; as in VS Code.  Set `preview-tab-include-named-files' if you would rather
;; `find-file' previewed too.
;;
;; The current preview is marked in the mode line: the buffer path is italicised
;; and a small indicator is shown.  Both are configurable; see
;; `preview-tab-slant-faces' and `preview-tab-indicator'.  Under
;; `tab-line-mode' the preview's tab is italicised too, whether or not it is
;; the selected one.

;;; Code:

(require 'face-remap)
(require 'seq)


;;;; State

(defvar preview-tab-buffer nil
  "The buffer currently held open as a preview, or nil.")

(defvar-local preview-tab--previewing nil
  "Non-nil when this buffer is the preview buffer.")

(defvar-local preview-tab--face-cookies nil
  "Cookies from `face-remap-add-relative' slanting the mode line.")

(defvar preview-tab--busy nil
  "Non-nil while a command from `preview-tab-commands' is on the stack.
Keeps the outermost command in charge when they nest, as when
`compile-goto-error' calls `next-error'.")

(defvar preview-tab--advised nil
  "Commands `preview-tab-mode' actually advised when it was turned on.
Turning the mode off has to undo exactly what turning it on did, and reading
`preview-tab-commands' a second time would not: nothing stops it from having
changed in between, and any command dropped from it would keep the advice for
the rest of the session.")

(defvar preview-tab--indicator-cache nil
  "Rendered mode-line marker.
`nerd-icons' resolves a name by scanning an alist of several thousand
entries, which is far too slow to redo on every redisplay.")

(defvar preview-tab--icon-warned nil
  "Value of `preview-tab-icon' the user has already been warned about.
The marker is built from inside redisplay, which runs without end: a name
`nerd-icons' has no icon for has to be reported once, not once a frame.")

(defvar preview-tab--mode-line-entry
  '(preview-tab--previewing (:eval (preview-tab--indicator)))
  "Construct `preview-tab-mode' adds to `mode-line-misc-info'.
`mode-line-misc-info' is part of the default `mode-line-format' and of
doom-modeline's `main' mode line, so this shows up either way.")


;;;; Customization

(defgroup preview-tab nil
  "Temporary file buffers, in the spirit of VS Code's preview tab."
  :group 'convenience
  :prefix "preview-tab-"
  :link '(url-link "https://github.com/ismd/preview-tab.el"))

(defvar preview-tab-mode)

(defun preview-tab--set-and-refresh (symbol value)
  "Set SYMBOL to VALUE, restarting `preview-tab-mode' if it is on.
Used as a `defcustom' setter for options that are only read when the mode is
turned on.  `bound-and-true-p' matters here: `defcustom' runs its setter while
the file is still loading, before `define-minor-mode' has defined the
variable."
  (set-default symbol value)
  (when (bound-and-true-p preview-tab-mode)
    (preview-tab-mode -1)
    (preview-tab-mode 1)))

(defun preview-tab--set-indicator (symbol value)
  "Set SYMBOL to VALUE and invalidate the cached mode-line marker."
  (set-default symbol value)
  (setq preview-tab--indicator-cache nil))

(defcustom preview-tab-commands
  '(;; file managers
    dired-find-file
    dired-find-alternate-file
    dired-find-file-other-window
    treemacs-visit-node-no-split
    treemacs-visit-node-in-most-recently-used-window
    ;; version control
    magit-diff-visit-file
    magit-diff-visit-file-other-window
    magit-diff-visit-file-other-frame
    magit-diff-visit-worktree-file
    magit-diff-visit-worktree-file-other-window
    magit-diff-visit-worktree-file-other-frame
    ;; code navigation
    xref-goto-xref
    xref-find-definitions
    xref-find-references
    ;; search results and diagnostics
    compile-goto-error
    next-error
    previous-error
    first-error
    flymake-goto-diagnostic
    consult-ripgrep
    consult-grep
    consult-git-grep
    consult-flymake
    ;; Doom Emacs jumps
    +lookup/definition
    +lookup/implementations
    +lookup/references
    +lookup/type-definition
    ;; Doom Emacs searches.  The `+default/' commands are the ones users
    ;; reach for; each dispatches to the `+vertico/', `+ivy/' or `+helm/'
    ;; command of whichever completion module is enabled.  Those are listed
    ;; too, for configurations that bind them directly -- reached through a
    ;; dispatcher they are a no-op, because the outer command already owns
    ;; the preview.
    +default/search-cwd
    +default/search-other-cwd
    +default/search-project
    +default/search-other-project
    +default/search-project-for-symbol-at-point
    +default/search-emacsd
    +default/search-notes-for-symbol-at-point
    +default/org-notes-search
    +vertico/project-search
    +vertico/project-search-from-cwd
    +ivy/project-search
    +ivy/project-search-from-cwd
    +helm/project-search
    +helm/project-search-from-cwd)
  "Commands whose file visits are treated as temporary previews.

Commands from packages that are not installed are harmless: advice attaches
to the bare symbol and takes effect if the package is ever loaded.  This is
why third-party commands can be listed here by default.

Only files opened while the command itself runs are picked up.  A command
that hands the visit off to a timer, a process filter or `post-command-hook'
has already returned by the time the file appears, and its buffer stays an
ordinary one.

Changing this list while the mode is on only takes effect through the
customize machinery -- `setopt', `customize-set-variable', the Customize
interface -- because that is what reattaches the advice.  A plain `setq'
or `add-to-list' will not.

Note that `find-file' is deliberately absent.  Like VS Code, which does not
preview from Quick Open either, typing a file name is taken as a deliberate
act; use `preview-tab-find-file' when you want the other behaviour once, or
`preview-tab-include-named-files' when you want it always.  Doom's
`+lookup/file' is absent for the same reason, as is `org-roam-node-find',
and both go along with that option.  So is `+default/search-buffer', which
searches the buffer you are already in and opens nothing."
  :type '(repeat function)
  :set #'preview-tab--set-and-refresh
  :group 'preview-tab)

(defconst preview-tab--named-file-commands
  '(find-file
    find-file-other-window
    find-file-other-frame
    magit-find-file
    magit-find-file-other-window
    magit-find-file-other-frame
    +lookup/file
    org-roam-node-find)
  "Commands `preview-tab-include-named-files' takes in when it is on.")

(defcustom preview-tab-include-named-files nil
  "Whether files you open by naming them are previewed too.

Off by default, because naming a file is a deliberate act -- see
`preview-tab-commands'.  Turn it on and `find-file' and `magit-find-file'
preview, each along with the variant that opens in another window and the
one that opens in another frame.

These are advised alongside `preview-tab-commands', so everything said
there applies here too -- including that changing this while the mode is
on only takes effect through the customize machinery.

Turning this on reaches further than the commands it names.  Much of Emacs
opens files by calling `find-file' itself, so `project-find-file',
`recentf-open-files' and jumping to a file register start previewing as
well.  That is the same instinct one step out, but it is worth knowing
before you switch it on.

Doom's `+lookup/file' comes along too.  It resolves whatever path is at
point and, failing anything more specific, hands off to `find-file-at-point'
-- naming a file by pointing at it, which is the same deliberate act.

So does `org-roam-node-find', which names a note by its title.  It has to
be taken in by name: it visits the note with `find-file-noselect', which
nothing here advises, so turning this on would not reach it otherwise.  A
title with no note behind it starts an Org capture instead, and the new
note stays an ordinary buffer -- see `preview-tab--adopt'.

`magit-find-file' previews only the worktree version of a file.  Asked
for a revision it builds a read-only blob buffer, which visits no file on
disk and is left alone, exactly as in a Magit diff.  If you want
`find-file' without it, leave this off and put `find-file' in
`preview-tab-commands' instead."
  :type 'boolean
  :set #'preview-tab--set-and-refresh
  :group 'preview-tab)

(defcustom preview-tab-slant-faces
  '(;; vanilla Emacs
    mode-line-buffer-id
    ;; doom-modeline splits the path across all of these, and which ones it
    ;; uses depends on `doom-modeline-buffer-file-name-style'
    doom-modeline-project-parent-dir
    doom-modeline-project-dir
    doom-modeline-project-root-dir
    doom-modeline-buffer-path
    doom-modeline-buffer-file
    ;; centaur-tabs
    centaur-tabs-selected
    centaur-tabs-selected-modified)
  "Faces italicised in a buffer while it is a preview.

The list covers several mode lines at once on purpose.  Remapping a face
that the current mode line never draws, or that is not even defined, costs
nothing and fails silently, so there is no need to detect which mode line
is in use.

The remapping is buffer-local, though, so it only reaches what is drawn
for the preview buffer itself.  That is all a mode line ever is, but not
all a tab line is: a tab line draws other buffers' tabs too, and the
window drawing them never sees the preview's remapping.  No tab-line face
is listed here for that reason -- `tab-line-mode' is handled by
`preview-tab-tab-line-face' instead, which slants the preview's tab in
every window, selected or not.  It needs Emacs 28.1, where
`tab-line-tab-face-functions' arrived; on Emacs 27 the tabs simply are
not slanted.

Centaur-tabs is listed, but it has the same limitation for the same
reason: only the tab of the window showing the preview is slanted."
  :type '(repeat face)
  :set #'preview-tab--set-and-refresh
  :group 'preview-tab)

(defcustom preview-tab-indicator 'auto
  "What to show in the mode line for a preview buffer.

`auto'   the icon when `nerd-icons' is available, the label otherwise
`icon'   the icon only, nothing if `nerd-icons' is missing
`label'  the text label only
`both'   the icon followed by the label
nil      no marker; the italicised path is the only cue"
  :type '(choice (const :tag "Icon if available, else label" auto)
                 (const :tag "Icon only" icon)
                 (const :tag "Label only" label)
                 (const :tag "Icon and label" both)
                 (const :tag "No marker" nil))
  :set #'preview-tab--set-indicator
  :group 'preview-tab)

(defcustom preview-tab-icon "nf-md-eye_outline"
  "Name of the `nerd-icons' Material Design icon marking a preview buffer.
Used when `preview-tab-indicator' asks for an icon.  The `nerd-icons'
package is optional; without it the label is shown instead.  A name that
package has no icon for draws nothing, and says so in the *Warnings*
buffer."
  :type 'string
  :set #'preview-tab--set-indicator
  :group 'preview-tab)

(defcustom preview-tab-label "PREVIEW"
  "Text marking a preview buffer in the mode line.
Used when `preview-tab-indicator' asks for a label."
  :type 'string
  :set #'preview-tab--set-indicator
  :group 'preview-tab)

(defface preview-tab-indicator
  '((t (:inherit (mode-line-buffer-id italic) :weight normal)))
  "Face for the preview marker's text label in the mode line."
  :group 'preview-tab)

(defun preview-tab--commands-to-advise ()
  "Return every command the mode should take over.
`preview-tab-commands', and the `find-file' family as well when
`preview-tab-include-named-files' is on.  `seq-uniq' rather than
`delete-dups': a command named in both must be advised once, and the
result has to be a fresh list -- the destructive one would splice a cons
out of the caller's own list, or out of the constant behind the option."
  (seq-uniq (append preview-tab-commands
                    (and preview-tab-include-named-files
                         preview-tab--named-file-commands))))


;;;; The mode-line marker

(defun preview-tab--icon-table ()
  "Return the `nerd-icons' table of Material Design icon names, or nil.
It is the alist that package looks a name up in -- `nerd-icons-mdicon'
and `nerd-icons-mdicon-data' come of one macro there, so the table read
here is the one drawing would read.  Nil says there is no `nerd-icons' to
be had, which is no verdict on any name and must not be taken for one.

`nerd-icons-mdicon' can be bound to nothing more than an autoload --
`use-package' :commands leaves one, as does a hand-written `autoload' --
and the table does not exist until the file behind it has been loaded.
Calling the icon function used to do that loading as a side effect; the
name has to be vetted before it is called now, so the loading is done
here, deliberately, instead.

Only ever called once `nerd-icons-mdicon' is bound: a `require' on the
off-chance would load the package for users who never asked for it."
  (unless (fboundp 'nerd-icons-mdicon-data)
    (require 'nerd-icons nil t))
  (and (fboundp 'nerd-icons-mdicon-data)
       (nerd-icons-mdicon-data)))

(defun preview-tab--warn-unknown-icon (name)
  "Report that `nerd-icons' has no Material Design icon called NAME."
  (display-warning 'preview-tab
                   (format-message
                    "`preview-tab-icon' is %S, which names no icon in the \
`nerd-icons' Material Design set, so no icon is drawn"
                    name)))

(defun preview-tab--icon ()
  "Return `preview-tab-icon' as `nerd-icons' draws it, or nil.
Nil while there is no `nerd-icons' -- the label stands in for the icon
then -- and nil for a name it has no icon for, which is a misconfigured
`preview-tab-icon' and is reported, once per name.  The two are told
apart: a table that is not there yet is no verdict on the name, and
reporting one would be crying wolf at a name that draws perfectly well
the moment the package is loaded.

The name is vetted against the table before it is drawn because
`nerd-icons-mdicon' signals on one it does not know, and this is reached
from inside redisplay, where nothing would catch that signal.  Redisplay
is no place to report the mistake either, a warning being a buffer to
display, so the report is left to a timer and reaches the user from the
command loop."
  (when (fboundp 'nerd-icons-mdicon)
    (let ((table (preview-tab--icon-table)))
      (cond ((null table) nil)
            ((assoc preview-tab-icon table)
             (nerd-icons-mdicon preview-tab-icon))
            (t (unless (equal preview-tab-icon preview-tab--icon-warned)
                 (setq preview-tab--icon-warned preview-tab-icon)
                 (run-with-timer 0 nil #'preview-tab--warn-unknown-icon
                                 preview-tab-icon))
               nil)))))

(defun preview-tab--indicator ()
  "Return the mode-line marker for a preview buffer."
  (or preview-tab--indicator-cache
      (let* ((want-icon (and (memq preview-tab-indicator '(auto icon both))
                             preview-tab-icon))
             (icon (and want-icon (preview-tab--icon)))
             (label (and preview-tab-label
                         (or (memq preview-tab-indicator '(label both))
                             (and (eq preview-tab-indicator 'auto) (not icon)))
                         (propertize preview-tab-label
                                     'face 'preview-tab-indicator)))
             (marker (cond ((and icon label) (concat " " icon " " label))
                           (icon (concat " " icon))
                           (label (concat " " label))
                           (t ""))))
        ;; A missing icon is worth recomputing only while `nerd-icons' has
        ;; yet to be loaded, since loading it is what would change the
        ;; answer.  Once its table is there the answer is settled either
        ;; way -- a name in it draws the same icon every time, a name that
        ;; is not draws nothing every time -- until the option changes,
        ;; and the setter behind it clears this.  The table, not the icon
        ;; function: that one can be bound to a bare autoload, with the
        ;; answer still to come.
        (when (or (not want-icon) (fboundp 'nerd-icons-mdicon-data))
          (setq preview-tab--indicator-cache marker))
        marker)))


;;;; The tab-line marker

;; Public, and autoloaded, for one reason: `tab-line-tab-face-functions' is a
;; `defcustom'.  A user who opens it in Customize while the mode is on is shown
;; this function as part of the value, and saving it writes the symbol to their
;; custom file -- from where redisplay will call it at the next startup, before
;; anything has pulled this package in.  A name a user can be handed like that
;; is part of the interface whatever we would rather call it.
;;;###autoload
(defun preview-tab-tab-line-face (tab _tabs face buffer-p _selected-p)
  "Return FACE italicised when TAB stands for the preview buffer.
TAB is a buffer when BUFFER-P is non-nil, and otherwise an alist holding
one under the key `buffer' -- `tab-line-tabs-function' is free to hand
out either shape, and a group tab holds no buffer at all.

A member of `tab-line-tab-face-functions', which is the only thing that
reaches a tab as some *other* window draws it.  The face remapping behind
`preview-tab-slant-faces' cannot: it is buffer-local, so it applies just
where the preview buffer is the one on display.  That slants the tab
while it is selected and drops the slant the moment you switch away,
which is the whole reason this exists."
  (let ((buffer (if buffer-p tab (cdr (assq 'buffer tab)))))
    ;; `buffer-live-p' first: this runs inside redisplay, where a signal is
    ;; very unwelcome, and a tab may well name a buffer that has since been
    ;; killed -- which is exactly what `buffer-local-value' objects to.
    (if (and (buffer-live-p buffer) (preview-tab-buffer-p buffer))
        `(:inherit (italic ,face))
      face)))

;; The other way round would be `tab-line-cache-key-function': add preview
;; standing to the key, via `add-function', and each window's cache would
;; invalidate itself exactly when it had to.  A correct key has to cover every
;; tab, though -- any of them may be the preview, not just the window's own
;; buffer -- so it would mean a `mapcar' over the tabs on every redisplay of
;; every tab line, against one sweep per change here.  Previews change rarely
;; and redisplay runs constantly, so this way round is the cheaper one, at the
;; price of clearing more caches than strictly had to go.
(defun preview-tab--refresh ()
  "Redraw the mode lines and tab lines that mark a preview buffer.
`force-mode-line-update' alone is not enough once tab lines are in play:
tab-line keeps each window's rendered tabs in a window parameter, and the
cache key it builds knows nothing about previews, so a tab whose standing
has just changed would go on being drawn the way it already was."
  (if (fboundp 'tab-line-force-update)
      ;; It clears every window's cache and forces the update itself.
      (tab-line-force-update t)
    ;; `tab-line-force-update' only arrived in Emacs 30.1, while the cache it
    ;; clears has been there since 28.1 -- so on 28 and 29 the tabs need
    ;; clearing by hand, or a preview that has just changed standing keeps the
    ;; face it was drawn with.  This is precisely what that function does.  On a
    ;; version with no cache to speak of it leaves an unread window parameter
    ;; behind and nothing else.
    (walk-windows (lambda (window)
                    (set-window-parameter window 'tab-line-cache nil))
                  'no-mini t)
    (force-mode-line-update t)))


;;;; Preview bookkeeping

(defun preview-tab-buffer-p (&optional buffer)
  "Return non-nil if BUFFER is the preview buffer.
BUFFER defaults to the current buffer."
  (buffer-local-value 'preview-tab--previewing (or buffer (current-buffer))))

(defun preview-tab--promote (&optional buffer)
  "Turn BUFFER into an ordinary, permanent buffer.
BUFFER defaults to the current buffer.  Also used as a buffer-local
`first-change-hook', which is why the argument is optional."
  (with-current-buffer (or buffer (current-buffer))
    (when preview-tab--previewing
      (setq preview-tab--previewing nil)
      (remove-hook 'first-change-hook #'preview-tab--promote t)
      (remove-hook 'kill-buffer-hook #'preview-tab--forget t)
      (mapc #'face-remap-remove-relative preview-tab--face-cookies)
      (setq preview-tab--face-cookies nil)
      (preview-tab--refresh))
    (when (eq (current-buffer) preview-tab-buffer)
      (setq preview-tab-buffer nil))))

(defun preview-tab--forget ()
  "Forget the current buffer as it is killed.
Buffer-local `kill-buffer-hook'.  A preview killed from outside this package
-- `C-x k', `kill-some-buffers', a mode tidying up after itself -- would
otherwise leave a dead buffer pinned in `preview-tab-buffer'."
  (when (eq (current-buffer) preview-tab-buffer)
    (setq preview-tab-buffer nil)))

(defun preview-tab--disposable-p (buffer)
  "Return non-nil if BUFFER is a preview that may be killed."
  (and (buffer-live-p buffer)
       (buffer-local-value 'preview-tab--previewing buffer)
       (not (buffer-modified-p buffer))
       (not (get-buffer-window buffer t))
       (not (get-buffer-process buffer))))

(defun preview-tab--retire (buffer)
  "Kill BUFFER if it is a disposable preview, otherwise keep it for good.
A preview that survives -- visible elsewhere, modified, or running a
process -- must not stay marked as one.  Only one preview is tracked at a
time, so once the next one takes over nothing would ever come back for
this buffer: it would sit there italicised and flagged forever, never
killed and never kept."
  (when (buffer-live-p buffer)
    ;; The global `kill-buffer-query-functions' are suppressed on purpose: this
    ;; runs from a timer, where a prompt would come out of nowhere, and their
    ;; usual grounds for objecting -- a live process, unsaved changes -- are
    ;; already covered above.  A buffer-local one is out of reach of the
    ;; binding, though, so `kill-buffer' can still turn the kill down after we
    ;; have decided to go ahead.  Whatever the reason, a buffer that survives
    ;; must not be left flagged.
    (unless (and (preview-tab--disposable-p buffer)
                 (let ((kill-buffer-query-functions nil))
                   (kill-buffer buffer)))
      (preview-tab--promote buffer))))

(defun preview-tab--mark (buffer)
  "Make BUFFER the preview buffer, retiring the previous one."
  (let ((old preview-tab-buffer))
    (setq preview-tab-buffer buffer)
    (with-current-buffer buffer
      ;; Inside the `unless', not after it: re-marking the buffer that is
      ;; already the preview changes nothing to draw, and browsing commands do
      ;; that constantly -- `next-error' down a list of hits in one file is
      ;; nothing but re-marks.  `preview-tab--refresh' is not free.
      (unless preview-tab--previewing
        (setq preview-tab--previewing t)
        (add-hook 'first-change-hook #'preview-tab--promote nil t)
        (add-hook 'kill-buffer-hook #'preview-tab--forget nil t)
        (setq preview-tab--face-cookies
              (mapcar (lambda (face) (face-remap-add-relative face 'italic))
                      preview-tab-slant-faces))
        (preview-tab--refresh)))
    (when (and old (not (eq old buffer)))
      ;; The old preview is still on screen right now; let redisplay swap it out
      ;; before deciding what to do with it.
      (run-at-time 0 nil #'preview-tab--retire old))))

(defun preview-tab--adopt (known)
  "Make the preview out of whatever file has been visited since KNOWN.
KNOWN is the `buffer-list' from before the command ran."
  (let* ((new (seq-filter (lambda (buf)
                            (and (buffer-file-name buf)
                                 (not (memq buf known))))
                          (buffer-list)))
         ;; A command may open more than one file -- a hook reading something,
         ;; a language server warming up a workspace.  The one on screen is the
         ;; one that was asked for.  Failing that, `buffer-list' is
         ;; most-recently-used first, so take the front.
         (opened (or (seq-find (lambda (buf) (get-buffer-window buf t)) new)
                     (car new)))
         (shown (window-buffer (selected-window))))
    (cond
     ;; A file buffer that did not exist before: this is the preview -- unless
     ;; the command has already edited it.  Editing is what makes a preview
     ;; permanent, and `first-change-hook' will not say so for an edit that
     ;; came first.  Nor for one made through an indirect buffer, which is how
     ;; Org capture writes a new note: the hook runs in the buffer being
     ;; typed in, not in the one visiting the file.  Marked anyway, the note
     ;; would be killed by the next preview as soon as it had been saved.
     (opened (unless (buffer-modified-p opened)
               (preview-tab--mark opened)))
     ;; Revisiting the current preview keeps it a preview.  Anything else was
     ;; already open, and stays permanent.
     ((eq shown preview-tab-buffer) (preview-tab--mark shown)))))

(defun preview-tab--invoke (fn args interactive)
  "Apply FN to ARGS, as an interactive call when INTERACTIVE.
`:around' advice sits between `call-interactively' and the command, and
`called-interactively-p' cannot see past it.  Commands that ask -- to decide
whether to message, or how much to prompt for -- would otherwise quietly
behave as though they had been called from Lisp."
  (if interactive
      (apply #'funcall-interactively fn args)
    (apply fn args)))

(defun preview-tab--call (fn args &optional interactive)
  "Apply FN to ARGS, then treat any file it opened as the preview buffer.
INTERACTIVE says the call came from `call-interactively'; see
`preview-tab--invoke'.

Reached through `preview-tab--advice' for `preview-tab-commands', and
directly from `preview-tab-find-file', which previews on request whether
or not the mode is on."
  (if preview-tab--busy
      (preview-tab--invoke fn args interactive)
    (let ((known (buffer-list))
          (preview-tab--busy t))
      ;; `unwind-protect', not `prog1'.  A command that reaches the file and
      ;; then signals -- a stale xref location, an erroring hook, plain C-g --
      ;; would otherwise leave the buffer open and tracked by nobody, which is
      ;; the one outcome this package exists to avoid.
      (unwind-protect
          (preview-tab--invoke fn args interactive)
        (preview-tab--adopt known)))))

(defun preview-tab--advice (fn &rest args)
  "Around advice on `preview-tab-commands': preview the file FN opens.
Applies FN to ARGS untouched while the mode is off.  The mode is the single
source of truth: advice that outlives it -- attached by hand, or resolved
late on a command whose package had not loaded yet -- must not go on marking
and killing buffers behind the user's back."
  ;; Read it here, in the frame `call-interactively' actually entered.
  (let ((interactive (called-interactively-p 'any)))
    (if preview-tab-mode
        (preview-tab--call fn args interactive)
      (preview-tab--invoke fn args interactive))))


;;;; Commands

;;;###autoload
(defun preview-tab-find-file (filename &optional wildcards)
  "Visit FILENAME as a preview instead of for good.
Ordinary `find-file' opens a file to keep, as in VS Code; this is the
deliberate \"just let me look at it\" counterpart.  FILENAME and WILDCARDS
are read exactly as `find-file' reads them.

A file that is already open keeps the standing it has.  Like the browsing
commands, this never demotes a buffer you have got open to a preview, which
would put a buffer you deliberately kept in line to be killed."
  (interactive (find-file-read-args "Preview file: "
                                    (confirm-nonexistent-file-or-buffer)))
  (preview-tab--call #'find-file (list filename wildcards)))

;;;###autoload
(defun preview-tab-keep ()
  "Keep the current buffer around, cancelling its preview status."
  (interactive)
  (if preview-tab--previewing
      (progn
        (preview-tab--promote)
        (message "Buffer kept"))
    (message "Not a preview buffer")))


;;;; The mode

;;;###autoload
(define-minor-mode preview-tab-mode
  "Open browsed files in a single temporary buffer, like VS Code's preview tab.

While this mode is on, the commands in `preview-tab-commands' visit files
into one preview buffer.  Opening the next one kills it; editing it, or
running `preview-tab-keep', turns it into an ordinary buffer.

Turning the mode off removes the advice and makes every preview buffer
permanent."
  :global t
  :group 'preview-tab
  (setq preview-tab--indicator-cache nil)
  (if preview-tab-mode
      (progn
        (setq preview-tab--advised (preview-tab--commands-to-advise))
        (dolist (cmd preview-tab--advised)
          (advice-add cmd :around #'preview-tab--advice))
        ;; Not `add-to-list' and `setq': `mode-line-misc-info' can be
        ;; buffer-local, and those would then edit whichever buffer happened to
        ;; be current instead of the value every buffer inherits.
        (unless (member preview-tab--mode-line-entry
                        (default-value 'mode-line-misc-info))
          (setq-default mode-line-misc-info
                        (append (default-value 'mode-line-misc-info)
                                (list preview-tab--mode-line-entry))))
        ;; Load tab-line rather than reaching for the variable blind: `add-hook'
        ;; on an unbound symbol would define it as nil, and the `defvar' in
        ;; tab-line.el would then decline to install its own default -- costing
        ;; the user the modified and special tab markers.  It has been built in
        ;; since Emacs 27.1; the hook itself only arrived in 28.1, and where
        ;; it is missing the tabs are simply left unslanted.
        (when (and (require 'tab-line nil t)
                   (boundp 'tab-line-tab-face-functions))
          (add-hook 'tab-line-tab-face-functions #'preview-tab-tab-line-face)))
    (dolist (cmd preview-tab--advised)
      (advice-remove cmd #'preview-tab--advice))
    (setq preview-tab--advised nil)
    ;; Guarded for the same reason the `add-hook' above is, and it is
    ;; `remove-hook' that makes the guard necessary: its first act on an
    ;; unbound hook is to define it as nil.  On Emacs 27, where tab-line has
    ;; no such variable, turning the mode off would otherwise create one --
    ;; and a later Emacs reading that saved value would find tab-line's own
    ;; defaults gone.
    (when (boundp 'tab-line-tab-face-functions)
      (remove-hook 'tab-line-tab-face-functions #'preview-tab-tab-line-face))
    (setq-default mode-line-misc-info
                  (remove preview-tab--mode-line-entry
                          (default-value 'mode-line-misc-info)))
    (dolist (buf (buffer-list))
      (preview-tab--promote buf))))

(provide 'preview-tab)
;;; preview-tab.el ends here
