;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frecentf" "0.2"
  "Pervasive recentf using frecency."
  '((emacs    "26.1")
    (frecency "0.1-pre")
    (persist  "0.4"))
  :url "https://launchpad.net/frecentf.el"
  :commit "1d87ac7ddf94971a64d0af8a0c8f1231a726aa6b"
  :revdesc "1d87ac7ddf94"
  :keywords '("files" "maint")
  :authors '(("Felipe Lema" . "felipel@mortemale.org"))
  :maintainers '(("Felipe Lema" . "felipel@mortemale.org")))
