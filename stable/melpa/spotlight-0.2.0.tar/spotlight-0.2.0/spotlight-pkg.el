;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spotlight" "0.2.0"
  "Search files with Mac OS X spotlight."
  '((emacs   "24.1")
    (swiper  "0.4.0")
    (counsel "0.1.0"))
  :url "http://www.pragmaticemacs.com"
  :commit "588ceabce30ef3069af1389391b51402a79cdd41"
  :revdesc "588ceabce30e"
  :keywords '("search")
  :authors '(("Ben Maughan" . "benmaughan@gmail.com"))
  :maintainers '(("Ben Maughan" . "benmaughan@gmail.com")))
