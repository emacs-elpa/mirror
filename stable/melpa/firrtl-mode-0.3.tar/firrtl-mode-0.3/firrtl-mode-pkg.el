;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firrtl-mode" "0.3"
  "Mode for working with FIRRTL files."
  '((emacs "24.3"))
  :url "https://github.com/ibm/firrtl-mode"
  :commit "ffd65e2903059bfb14869d4375d87a995ea0d068"
  :revdesc "ffd65e290305"
  :keywords '("languages" "firrtl")
  :authors '(("Schuyler Eldridge" . "schuyler.eldridge@ibm.com"))
  :maintainers '(("Schuyler Eldridge" . "schuyler.eldridge@ibm.com")))
