;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-mu4e" "0.0.8"
  "Evil-based key bindings for mu4e."
  '((emacs "24.4")
    (dash  "2.12.0")
    (evil  "1.2.10"))
  :url "https://github.com/JorisE/evil-mu4e"
  :commit "c03a0e11afda3092eb1461be09fa6a61ebc0e4f6"
  :revdesc "c03a0e11afda"
  :authors '(("Joris Engbers" . "info@jorisengbers.nl"))
  :maintainers '(("Joris Engbers" . "info@jorisengbers.nl")))
