;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-indent" "0.1"
  "Highlight irregular indentation."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/ikirill/hl-indent"
  :commit "f20fceb8f27a5f5da9453a2c812f1042f514edaf"
  :revdesc "f20fceb8f27a"
  :keywords '("convenience" "faces")
  :authors '(("Kirill Ignatiev" . "github.com/ikirill"))
  :maintainers '(("Kirill Ignatiev" . "github.com/ikirill")))
