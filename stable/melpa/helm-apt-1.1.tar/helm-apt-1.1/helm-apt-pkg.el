;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-apt" "1.1"
  "Helm interface for Debian/Ubuntu packages (apt-*)."
  '((helm  "3.9.5")
    (emacs "25.1"))
  :url "https://github.com/emacs-helm/helm-apt"
  :commit "f020465c18908efe00807e1e0f828a3766fc6916"
  :revdesc "v1.1-0-gf020465c1890"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
