;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asciidoc-mode" "0.4.0"
  "Major mode for AsciiDoc markup."
  '((emacs "30.1"))
  :url "https://github.com/bbatsov/asciidoc-mode"
  :commit "aa836bb0aa25427914ef3a938ed218aedd9123d9"
  :revdesc "aa836bb0aa25"
  :keywords '("text" "asciidoc" "languages" "tree-sitter")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
