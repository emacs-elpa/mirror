;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sws-mode" "1.0.0"
  "(S)ignificant (W)hite(S)pace mode."
  ()
  :url "https://github.com/brianc/jade-mode"
  :commit "4e7a20db492719062f40b225ed730ed50be5db56"
  :revdesc "v1.0.0-0-g4e7a20db4927")
