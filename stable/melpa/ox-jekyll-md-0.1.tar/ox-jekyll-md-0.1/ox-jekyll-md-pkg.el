;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-jekyll-md" "0.1"
  "Export Jekyll articles using org-mode."
  ()
  :url "https://github.com/gonsie/ox-jekyll-md"
  :commit "d56cbf500823cd7f9422906cd29831d223f92a52"
  :revdesc "d56cbf500823"
  :keywords '("org" "jekyll")
  :authors '(("Elsa Gonsiorowski" . "gonsie@me.com"))
  :maintainers '(("Elsa Gonsiorowski" . "gonsie@me.com")))
