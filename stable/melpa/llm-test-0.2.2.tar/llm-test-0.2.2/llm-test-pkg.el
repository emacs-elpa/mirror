;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "0.2.2"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "44eca75d1dc0d429d5fd29270b38ef132dabfadc"
  :revdesc "44eca75d1dc0"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
