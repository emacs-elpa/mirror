;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperstitional-themes" "3.13"
  "Weird themes with incremental palettes."
  '((emacs "24.1"))
  :url "https://github.com/precompute/hyperstitional-themes"
  :commit "0177bf058868d292b20ad0747123b22f9bf98aca"
  :revdesc "0177bf058868"
  :authors '(("precompute" . "git@precompute.net"))
  :maintainers '(("precompute" . "git@precompute.net")))
