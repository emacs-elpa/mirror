;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hybrid-reverse-theme" "0.1.0"
  "Emacs theme with material color scheme."
  '((emacs "24"))
  :url "https://github.com/riyyi/emacs-hybrid-reverse"
  :commit "30eaf21f53861cbdf0a4fd75ede2bf7a9ef3dc84"
  :revdesc "30eaf21f5386")
