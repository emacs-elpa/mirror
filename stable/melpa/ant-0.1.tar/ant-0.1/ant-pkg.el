;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ant" "0.1"
  "Helpers for compiling with ant."
  ()
  :url "https://github.com/apg/ant-el"
  :commit "deaafad550a392e17c6b8b195b70da7f53e71854"
  :revdesc "deaafad550a3"
  :keywords '("compilation" "ant" "java"))
