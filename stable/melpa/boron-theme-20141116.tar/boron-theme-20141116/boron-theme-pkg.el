;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boron-theme" "20141116"
  "An Emacs 24 theme based on Boron (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "d074b0d5907bf79c98ca87e3966e80c9823b4852"
  :revdesc "d074b0d5907b")
