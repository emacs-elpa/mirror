;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-jslint" "0.23"
  "Flymake support for javascript using jslint."
  ()
  :url "https://github.com/purcell/flymake-jslint"
  :commit "30693f75059bab53a9d2eb676c68751f4d8b091c"
  :revdesc "30693f75059b"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
