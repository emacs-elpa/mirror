;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aggressive-indent" "1.10.0"
  "Minor mode to aggressively keep your code always indented."
  '((emacs "24.3"))
  :url "https://github.com/Malabarba/aggressive-indent-mode"
  :commit "cb416faf61c46977c06cf9d99525b04dc109a33c"
  :revdesc "cb416faf61c4"
  :keywords '("indent" "lisp" "maint" "tools")
  :authors '(("Artur Malabarba" . "emacs@endlessparentheses.com"))
  :maintainers '(("Artur Malabarba" . "emacs@endlessparentheses.com")))
