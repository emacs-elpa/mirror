;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ack-menu" "0.1.0"
  "A menu-based front-end for ack."
  ()
  :url "https://github.com/chumpage/ack-menu"
  :commit "5b2eb12fbc744e8a95aef83b791c3f6228bd9e9c"
  :revdesc "5b2eb12fbc74"
  :keywords '("tools" "matching"))
