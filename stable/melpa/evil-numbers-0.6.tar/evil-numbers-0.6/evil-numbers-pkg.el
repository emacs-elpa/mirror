;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-numbers" "0.6"
  "Increment/decrement numbers like in VIM."
  '((emacs "24.1"))
  :url "https://github.com/juliapath/evil-numbers"
  :commit "13294fdbd1928dec2a87ee71294dec28aeefe280"
  :revdesc "0.6-0-g13294fdbd192"
  :keywords '("convenience" "tools")
  :authors '(("Michael Markert" . "markert.michael@googlemail.com"))
  :maintainers '(("Julia Path" . "julia@jpath.de")))
