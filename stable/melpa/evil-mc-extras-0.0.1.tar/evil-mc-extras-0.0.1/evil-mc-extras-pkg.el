;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-mc-extras" "0.0.1"
  "Extra functionality for evil-mc."
  '((emacs   "24.3")
    (evil    "1.2.12")
    (cl-lib  "0.5")
    (evil-mc "0.0.2"))
  :url "https://github.com/gabesoft/evil-mc-extras"
  :commit "0e6fca71302dc6e925b251da9a474f3bdd33106f"
  :revdesc "0e6fca71302d"
  :keywords '("evil" "editing" "multiple-cursors" "vim" "evil-multiple-cursors" "evil-mc" "evil-mc-extras")
  :authors '(("Gabriel Adomnicai" . "gabesoft@gmail.com"))
  :maintainers '(("Gabriel Adomnicai" . "gabesoft@gmail.com")))
