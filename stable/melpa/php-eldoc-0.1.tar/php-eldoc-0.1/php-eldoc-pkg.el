;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-eldoc" "0.1"
  "Eldoc backend for php."
  ()
  :url "https://github.com/sabof/php-eldoc"
  :commit "4be9d69de0a529ed4d0c14d6c36568a47632d274"
  :revdesc "4be9d69de0a5")
