;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tray" "0.1.8"
  "Various transient menus."
  '((emacs     "28.1")
    (compat    "30.1")
    (transient "0.12"))
  :url "https://github.com/tarsius/tray"
  :commit "b77e046b173008a95f9ba37f4d34c088f5f0a8ab"
  :revdesc "v0.1.8-0-gb77e046b1730"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.tray@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.tray@jonas.bernoulli.dev")))
