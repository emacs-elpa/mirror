;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "align-cljlet" "0.4"
  "Space align various Clojure forms."
  '((clojure-mode "1.11.5"))
  :url "https://github.com/gstamp/align-cljlet"
  :commit "15a0a593cb6c7ee5b0796d73ea8d67d222e1d573"
  :revdesc "15a0a593cb6c"
  :authors '(("Glen Stampoultzis" . "gstampgmail.com")
             ("Reid D McKenzie" . "https://github.com/arrdem"))
  :maintainers '(("Glen Stampoultzis" . "gstampgmail.com")
                 ("Reid D McKenzie" . "https://github.com/arrdem")))
