;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sequed" "2.0"
  "Major mode for FASTA format DNA alignments."
  '((emacs "25.2"))
  :url "https://github.com/brannala/sequed"
  :commit "d8b76c47db7de52118ab9217dac7d3308d4df9cc"
  :revdesc "d8b76c47db7d"
  :authors '(("Bruce Rannala" . "brannala@ucdavis.edu"))
  :maintainers '(("Bruce Rannala" . "brannala@ucdavis.edu")))
