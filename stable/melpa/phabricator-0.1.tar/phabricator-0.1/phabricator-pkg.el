;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phabricator" "0.1"
  "Phabricator/Arcanist helpers for Emacs."
  '((emacs "24.1"))
  :url "https://github.com/ajtulloch/phabricator.el"
  :commit "3f38381367af30e5038192439706f01493eae5f7"
  :revdesc "3f38381367af"
  :keywords '("phabricator" "arcanist" "diffusion"))
