;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-python-pyflakes" "0.9"
  "A flymake handler for python-mode files using pyflakes (or flake8)."
  '((flymake-easy "0.8"))
  :url "https://github.com/purcell/flymake-python-pyflakes"
  :commit "78806a25b0f01f03df4210a79a6eaeec59511d7a"
  :revdesc "78806a25b0f0"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
