;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php" "2.8.3"
  "Auto Completion source for PHP."
  '((ac-php-core   "2.0")
    (auto-complete "1.4.0")
    (yasnippet     "0.8.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "feafc8b066e600e18367f0fa15ad9cc261626789"
  :revdesc "v2.8.3-0-gfeafc8b066e6"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
