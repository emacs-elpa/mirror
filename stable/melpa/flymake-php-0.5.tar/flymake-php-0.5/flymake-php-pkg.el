;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-php" "0.5"
  "A flymake handler for php-mode files."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-php"
  :commit "91f867e209011af31a2ca2d8f6874b994403bcb2"
  :revdesc "91f867e20901"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
