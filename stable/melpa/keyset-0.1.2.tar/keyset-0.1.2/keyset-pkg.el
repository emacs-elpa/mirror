;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keyset" "0.1.2"
  "A small library for structuring key bindings."
  '((dash   "2.8.0")
    (cl-lib "0.5"))
  :url "https://github.com/HKey/keyset"
  :commit "25658ef79d26971ce41d9df207dff58d38daa091"
  :revdesc "25658ef79d26"
  :authors '(("Hiroki YAMAKAWA" . "s06139@gmail.com"))
  :maintainers '(("Hiroki YAMAKAWA" . "s06139@gmail.com")))
