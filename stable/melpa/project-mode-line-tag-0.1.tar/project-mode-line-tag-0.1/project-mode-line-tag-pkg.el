;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-mode-line-tag" "0.1"
  "Display a buffer's project in its mode line."
  '((emacs "25.1"))
  :url "https://github.com/fritzgrabo/project-mode-line-tag"
  :commit "ed6adf9287d2aa526d85451623f1aa281cfa7e0a"
  :revdesc "ed6adf9287d2"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "me@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "me@fritzgrabo.com")))
