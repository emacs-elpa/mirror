;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-backspace" "0.1.0"
  "[No description available]."
  ()
  :url "https://github.com/itome/smart-backspace"
  :commit "29c569491d12bc8a271c89f3a3dcc5558e2366ce"
  :revdesc "29c569491d12"
  :authors '(("George Kettleborough" . "g.kettleborough@member.fsf.org"))
  :maintainers '(("George Kettleborough" . "g.kettleborough@member.fsf.org")))
