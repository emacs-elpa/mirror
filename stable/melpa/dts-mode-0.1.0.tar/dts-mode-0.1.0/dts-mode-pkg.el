;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dts-mode" "0.1.0"
  "A major emacs mode for editing Devicetree source code."
  ()
  :url "https://github.com/bgamari/dts-mode"
  :commit "c31adb4420a428c34971a9e9a2555244af912f93"
  :revdesc "c31adb4420a4"
  :authors '(("Ben Gamari" . "ben@smart-cactus.org"))
  :maintainers '(("Ben Gamari" . "ben@smart-cactus.org")))
