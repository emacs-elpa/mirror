;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-filter" "0.0.2"
  "Ibuffer-like filtering for dired."
  '((dash              "2.5.0")
    (dired-hacks-utils "0.0.1"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "659bfe8412c16fc644baafaa136beca7684421e7"
  :revdesc "659bfe8412c1"
  :keywords '("files")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
