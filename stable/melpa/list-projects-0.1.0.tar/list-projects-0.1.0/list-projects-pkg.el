;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "list-projects" "0.1.0"
  "[No description available]."
  ()
  :url "https://github.com/MatthewTromp/list-projects"
  :commit "40cf9fbe55bba256d9b03f299b95b855790ed1d2"
  :revdesc "40cf9fbe55bb")
