;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "currency-convert" "0.1.0"
  "Currency converter."
  '((emacs "24.4"))
  :url "https://github.com/lassik/emacs-currency-convert"
  :commit "0b12614956085444d73c47bc308c02cef0f64f97"
  :revdesc "0b1261495608"
  :keywords '("comm" "convenience" "i18n")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
