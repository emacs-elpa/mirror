;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alchemist" "1.8.2"
  "Elixir tooling integration into Emacs."
  '((elixir-mode "2.2.5")
    (dash        "2.11.0")
    (emacs       "24.4")
    (company     "0.8.0")
    (pkg-info    "0.4"))
  :url "http://www.github.com/tonini/alchemist.el"
  :commit "34caeed1bd231c7dfa8d2b9aa5c5de2b2a059601"
  :revdesc "34caeed1bd23"
  :keywords '("languages" "elixir" "elixirc" "mix" "hex" "alchemist")
  :authors '(("Samuel Tonini" . "tonini.samuel@gmail.com"))
  :maintainers '(("Samuel Tonini" . "tonini.samuel@gmail.com")))
