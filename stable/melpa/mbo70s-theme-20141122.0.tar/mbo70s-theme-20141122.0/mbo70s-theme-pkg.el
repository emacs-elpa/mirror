;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mbo70s-theme" "20141122.0"
  "70s style palette, with similarities to mbo theme."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "d50414697760896dbe6b06d2a00c271c16e0e4a2"
  :revdesc "d50414697760")
