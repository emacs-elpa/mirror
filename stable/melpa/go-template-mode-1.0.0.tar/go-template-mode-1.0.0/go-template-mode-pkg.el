;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-template-mode" "1.0.0"
  "Major mode for Go templates."
  '((emacs "28.1"))
  :url "https://codeberg.org/rch/go-template-mode"
  :commit "f33b953f5301d079463b428393efcd83767a128c"
  :revdesc "f33b953f5301"
  :keywords '("languages" "tools")
  :authors '(("Robert Charusta" . "rch-public@posteo.net"))
  :maintainers '(("Robert Charusta" . "rch-public@posteo.net")))
