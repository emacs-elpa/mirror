;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-column-faces" "1.2.1"
  "Faces for individual mu4e columns."
  '((emacs "25.3"))
  :url "https://github.com/Alexander-Miller/mu4e-column-faces"
  :commit "1bbb646ea07deb1bd2daa4c6eb36e0f65aac40b0"
  :revdesc "1bbb646ea07d"
  :authors '(("Alexander Miller" . "alexanderm@web.de"))
  :maintainers '(("Alexander Miller" . "alexanderm@web.de")))
