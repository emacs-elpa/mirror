;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reverse-im" "0.0.8"
  "Reverse mapping for non-default system layouts."
  '((emacs "25.1")
    (seq   "2.23"))
  :url "https://github.com/a13/reverse-im.el"
  :commit "41f47d5ccab77d42cc2e1a89a09d0dc2410e9eb4"
  :revdesc "41f47d5ccab7"
  :keywords '("i18n")
  :authors '(("Juri Linkov" . "juri@jurta.org"))
  :maintainers '(("Juri Linkov" . "juri@jurta.org")))
