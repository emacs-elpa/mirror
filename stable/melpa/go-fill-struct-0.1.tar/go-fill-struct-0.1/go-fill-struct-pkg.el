;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-fill-struct" "0.1"
  "Fill struct for golang."
  '((emacs "24"))
  :url "https://github.com/s-kostyaev/go-fill-struct"
  :commit "3c97c92e78f3629a7a1069404c7c641881c16d0e"
  :revdesc "3c97c92e78f3"
  :keywords '("tools")
  :authors '(("Sergey Kostyaev" . "feo.me@ya.ru"))
  :maintainers '(("Sergey Kostyaev" . "feo.me@ya.ru")))
