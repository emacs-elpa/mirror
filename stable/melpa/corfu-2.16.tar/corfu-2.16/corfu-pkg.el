;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.16"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "b468efac023dda39332acc943edc9895c80b5a6f"
  :revdesc "2.16-0-gb468efac023d"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
