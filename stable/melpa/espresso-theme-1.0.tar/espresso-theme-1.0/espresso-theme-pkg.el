;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "espresso-theme" "1.0"
  "Espresso Tutti Colori port for Emacs."
  ()
  :url "https://github.com/mkhl/color-theme-espresso"
  :commit "832e945f4fe4706cfdb2503d88380e0a5d73748c"
  :revdesc "832e945f4fe4"
  :authors '(("Martin Kühl" . "purl.org/net/mkhl"))
  :maintainers '(("Martin Kühl" . "purl.org/net/mkhl")))
