;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-mode" "1.1.1.1"
  "A mode to manage tree widgets."
  ()
  :url "https://github.com/emacsorphanage/tree-mode"
  :commit "9c31a8396df021611a602234c5d2c16fe9014dce"
  :revdesc "9c31a8396df0"
  :keywords '("help" "convenience" "widget")
  :authors '((nil . "wenbinye@163.com"))
  :maintainers '((nil . "wenbinye@163.com")))
