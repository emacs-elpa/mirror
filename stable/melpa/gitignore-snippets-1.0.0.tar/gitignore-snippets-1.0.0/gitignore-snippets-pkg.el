;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitignore-snippets" "1.0.0"
  "Gitignore.io templates for Yasnippet."
  '((emacs     "26")
    (yasnippet "0.8.0"))
  :url "https://github.com/sei40kr/gitignore-snippets"
  :commit "ab09655192d56ae2fecc04365d6299c4e1db5007"
  :revdesc "ab09655192d5"
  :keywords '("tools")
  :authors '(("Seong Yong-ju" . "sei40kr@gmail.com"))
  :maintainers '(("Seong Yong-ju" . "sei40kr@gmail.com")))
