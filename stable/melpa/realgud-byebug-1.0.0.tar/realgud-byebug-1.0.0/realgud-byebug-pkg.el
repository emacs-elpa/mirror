;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-byebug" "1.0.0"
  "Realgud front-end to the Ruby byebug debugger."
  '((realgud "1.4.3")
    (cl-lib  "0.5")
    (emacs   "24"))
  :url "https://github.com/rocky/realgud-byebug"
  :commit "2779d8975fd1557aacd4c5bda9c17b8460e8c45c"
  :revdesc "2779d8975fd1")
