;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-aspell" "0.1.0"
  "Aspell backend for flymake."
  '((emacs "26.0"))
  :url "https://github.com/leotaku/flycheck-aspell"
  :commit "56f836f3e038f6d96dece5eaa7beb0e477fd5ffc"
  :revdesc "56f836f3e038"
  :keywords '("flymake" "spell" "aspell")
  :authors '(("Leo Gaskin" . "leo.gaskin@brg-feldkirchen.at"))
  :maintainers '(("Leo Gaskin" . "leo.gaskin@brg-feldkirchen.at")))
