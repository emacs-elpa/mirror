;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "0.5.0"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "30.2")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "244faa624d1866a7084304501b5de2a894b99762"
  :revdesc "v0.5.0-0-g244faa624d18"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
