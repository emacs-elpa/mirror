;;; output.clj -- Output & formatting clojure functions for ejc-sql.

;;; Copyright © 2013-2023 - Kostafey <kostafey@gmail.com>

;;; This program is free software; you can redistribute it and/or modify
;;; it under the terms of the GNU General Public License as published by
;;; the Free Software Foundation; either version 2, or (at your option)
;;; any later version.
;;;
;;; This program is distributed in the hope that it will be useful,
;;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;;; GNU General Public License for more details.
;;;
;;; You should have received a copy of the GNU General Public License
;;; along with this program; if not, write to the Free Software Foundation,
;;; Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.  */

(ns ejc-sql.output
  (:require [clojure.string :as s]
            [clojure.java.io :refer [file writer]]
            [ejc-sql.lib :refer [*max-column-width* dml? simple-join windows?]])
  (:import (java.io File IOException)
           (org.apache.commons.lang3 StringUtils)
           (org.hibernate.engine.jdbc.internal BasicFormatterImpl
                                               DDLFormatterImpl)))

(def ^:dynamic *add-outside-borders* true)

(def ^:dynamic *null-text*
  "The text of a NULL value: none, as psql and Emacs show it, or NULL, as
  the MCP server does, to tell it from an empty string."
  "")

(def ^:dynamic *ascii-borders*
  "Draw the borders of ASCII whatever `use-unicode` says, as the MCP server
  does: a line of `-` takes the agent fewer tokens than one of box-drawing
  characters."
  false)

(defn get-log-dir
  "The query log directory: `ejc-sql` in `%AppData%` on Windows,
  `~/.ejc-sql/log` elsewhere, or the `ejc-sql.log-dir` system property, which
  the tests set to keep off the user's log."
  []
  (let [home (System/getProperty "user.home")]
    (if-let [dir (System/getProperty "ejc-sql.log-dir")]
      (file dir)
      (if windows?
        (file (or (System/getenv "AppData") home) "ejc-sql")
        (file home ".ejc-sql" "log")))))

(defn get-log-file [& [create-new]]
  (loop [xs (take 100 (range))]
    (when xs
      (let [prev-day (first xs)
            log-file (file
                      (get-log-dir)
                      (format "%s.log"
                              (.format
                               (new java.text.SimpleDateFormat
                                    "yyyy-MM-dd")
                               (let [cal (java.util.Calendar/getInstance)]
                                 (.setTime cal (new java.util.Date))
                                 (.add cal java.util.Calendar/DATE
                                       (if prev-day (- prev-day) 0))
                                 (.getTime cal)))))]
        (if (or create-new (.exists log-file))
          log-file
          (recur (next xs)))))))

(defn print-log-file-path []
  (print (.getAbsolutePath (or (get-log-file) (get-log-dir)))))

(def log-queries
  "Write the queries to the query log, see `set-log-queries`."
  (atom true))

(defn set-log-queries
  "Turn the query log on, or off with nil. Off, `log-sql` writes nothing,
  the queries of the agents included."
  [val]
  (reset! log-queries (boolean val)))

(defn log-sql
  "Append `sql` to the query log of today, unless `log-queries` is off.
  A log that can't be written is reported to stderr, the query runs anyway."
  [sql]
  (when @log-queries
    (try
      (let [^File log-file (get-log-file true)
            is-new-file (not (.exists log-file))]
        (when is-new-file
          (.mkdirs (File. (.getParent log-file)))
          (.createNewFile log-file))
        (with-open [wrtr (writer log-file :append true)]
          (when is-new-file
            (.write wrtr (str "-- -*- mode: sql; -*-\n"
                              "-- Local Variables:\n"
                              "-- eval: (ejc-sql-mode)\n"
                              "-- End:\n")))
          (.write wrtr (str (simple-join 50 "-") " "
                            (.format (new java.text.SimpleDateFormat
                                          "yyyy.MM.dd HH:mm:ss.S")
                                     (new java.util.Date))
                            " " (simple-join 2 "-") "\n" sql "\n"))))
      (catch IOException e
        (binding [*out* *err*]
          (println "ejc-sql: can't write the query log:" (.getMessage e)))))))

(def fetch-size
  "Limit number of records to output."
  (atom 50))

(def max-rows
  "Limit number of records to contain in ResultSet."
  (atom 99))

(def show-too-many-rows-message
  "Output message in case of ResultSet is bigger than `fetch-size`."
  (atom true))

(def column-width-limit
  "Limit number of chars per column to output."
  (atom 30))

(defn set-fetch-size
  "Set limit for number of records to output. When nil no limit.
  Passed to the JDBC driver a hint as to the number of rows that should be
  fetched from the database when more rows are needed for ResultSet objects
  generated by a Statement."
  [val]
  (reset! fetch-size (or val 0)))

(defn set-max-rows
  "Set limit for number of records to contain in ResultSet. When nil no limit.
  Sets the limit for the maximum number of rows that any ResultSet object
  generated by a Statement object can contain to the given number."
  [val]
  (reset! max-rows (or val 0)))

(defn set-show-too-many-rows-message
  [val]
  (reset! show-too-many-rows-message (or val false)))

(defn set-column-width-limit
  "Set limit for number of chars per column to output. When nil no limit."
  [val]
  (reset! column-width-limit val))

(defn rotate-table
  "Rotate result set to show fields list vertically.
  Applied to single-record result set.
  E.g. transtofm from: a | b | c into: a | 1
                       --+---+--       b | 2
                       1 | 2 | 3       c | 3"
  [data]
  (apply mapv vector data))

(def use-unicode (atom false))

(defn set-use-unicode
  "Set using unicode for grid borders."
  [val]
  (reset! use-unicode val))

(defn u? [unicode-str ascii-str]
  (if (and @use-unicode (not *ascii-borders*)) unicode-str ascii-str))

(defn print-maps
  "Prints a collection of maps in a textual table. Prints table headings
   ks, and then a line of output for each row, corresponding to the keys
   in ks. If ks are not specified, use the keys of the first item in rows."
  ([ks rows add-borders]
   (when (seq rows)
     (let [widths (map
                   (fn [k]
                     (apply max (count (str k))
                            (map #(count (str (get % k))) rows)))
                   ks)
           spacers (map #(apply str (repeat % (u? "─" "-"))) widths)
           fmts (map #(str "%-" % "s") widths)
           fmt-row (fn [leader divider trailer row]
                     (str (if add-borders leader "")
                          (apply str
                                 (interpose
                                  divider
                                  (for [[col fmt]
                                        (map vector (map #(get row %) ks) fmts)]
                                    (format fmt (str col)))))
                          (if add-borders trailer "")))
           aob *add-outside-borders*]
       (println (fmt-row (if aob (u? "│ " "| ") "") (u? " │ " " | ") (if aob (u? " │" " |") "")
                         (zipmap ks (map name ks))))
       (println (fmt-row (if aob (u? "├─" "|-") "") (u? "─┼─" "-+-") (if aob (u? "─┤" "-|") "")
                         (zipmap ks spacers)))
       (doseq [row rows]
         (println (fmt-row (if aob (u? "│ " "| ") "") (u? " │ " " | ") (if aob (u? " │" " |") "") row))))))
  ([rows add-borders]
   (print-maps (keys (first rows)) rows add-borders)))

(defn trim-max-width [x]
  (let [s (str x)]
    (if (and *max-column-width*
             (> *max-column-width* 0)
             (> (count s) *max-column-width*))
      (str (subs s 0 (- *max-column-width* 3)) "...")
      s)))

(defn min-not-zero [x y]
  (min (if (> x 0) x y)
       (if (> y 0) y x)))

(defn- cjk-chars-count
  "Return count of CJK characters in string: of the block
  `Character$UnicodeBlock/CJK_UNIFIED_IDEOGRAPHS`, U+4E00..U+9FFF, checked
  as a range of primitive chars. It's run on every character of a table,
  and `Character$UnicodeBlock/of` looks the block up."
  [^String text]
  (loop [i 0
         n 0]
    (if (< i (.length text))
      (recur (inc i) (let [c (int (.charAt text i))]
                       ;; Not (<= 0x4E00 c 0x9FFF): its three arguments
                       ;; are boxed.
                       (if (and (<= 0x4E00 c) (<= c 0x9FFF))
                         (inc n)
                         n)))
      n)))

(defn- string-length
  "Return string length, given that CJK characters have a length of 2."
  [^String text]
  (+ (.length text) (cjk-chars-count text)))

(defn- pad
  "`text` followed by spaces up to `width`, given that CJK characters have
  a length of 2. Unlike `format` with a width, it parses no pattern."
  [text width]
  (let [n (- width (string-length text))]
    (if (pos? n)
      (str text (apply str (repeat n \space)))
      text)))

(defn- pad-left
  "Spaces up to `width` followed by `text`, as `pad` counts them."
  [text width]
  (let [n (- width (string-length text))]
    (if (pos? n)
      (str (apply str (repeat n \space)) text)
      text)))

(defn- fraction-length
  "The length of the fraction of the number `text`, its `.` included, 0 if
  it has none."
  [^String text]
  (let [i (.indexOf text (int \.))]
    (if (neg? i) 0 (- (.length text) i))))

(defn- number-columns
  "For each column of `rows`: the length of the longest fraction of its
  numbers, for a column of numbers and NULLs, nil for any other column."
  [rows]
  (when (seq rows)
    (apply map
           (fn [& values]
             (when (and (some number? values)
                        (every? #(or (nil? %) (number? %)) values))
               (apply max (map #(fraction-length (str %))
                               (filter number? values)))))
           rows)))

(defn- cell-text
  "The text of the `value` of a column, cut to `*max-column-width*`. A
  number is never cut, and in a column of numbers it's followed by spaces
  up to the `fraction` length of the column: right-aligned, the numbers
  then have their `.` one under another."
  [value fraction]
  (cond
    (nil? value) *null-text*
    (number? value) (let [text (str value)]
                      (if fraction
                        (str text (apply str (repeat (- fraction
                                                        (fraction-length text))
                                                     \space)))
                        text))
    :else (trim-max-width value)))

(defn- one-line
  "`text` with its line breaks and tabs replaced by spaces, to align the
  columns. Most values have none, and `.indexOf` finds it out several
  times faster than the regex replacement."
  [^String text]
  (if (or (<= 0 (.indexOf text (int \newline)))
          (<= 0 (.indexOf text (int \return)))
          (<= 0 (.indexOf text (int \tab))))
    (s/replace text #"\r\n|[\r\n\t]" " ")
    text))

(defn print-table
  "Converts a seq of seqs to a textual table. Uses the first seq as the table
  headings and the remaining seqs as rows."
  ([rows limit]
   (when (seq rows)
     (let [row-limit (or limit (min-not-zero @max-rows @fetch-size))
           [rows msg] (if (and row-limit
                               (> row-limit 0)
                               ;; Since `rows` parameter contains a header
                               ;; `row` 1 should be added to `row-limit`.
                               (> (count rows) (+ row-limit 1)))
                        [(take (+ row-limit 1) rows)
                         (when @show-too-many-rows-message
                           (format "Too many rows. Only %s from %s%s are shown."
                                   row-limit
                                   (min-not-zero @max-rows (- (count rows) 1))
                                   (if (and @max-rows
                                            (> @max-rows 0)
                                            (> (- (count rows) 1) @max-rows))
                                     "+" "")))]
                        [rows ""])
           [headers rows] [(map name (first rows)) (rest rows)]
           aob *add-outside-borders*
           [rows rotated] (if (and (not aob)
                                   (= (count rows) 1)
                                   (> (count (first rows)) 1))
                            ;; Rotatate result set table representation
                            ;; if it has 1 row and many columns.
                            [(rotate-table [headers (first rows)]) true]
                            [rows false])
           [single-column-and-row
            cell-value] (when-let [single-cell? (and (= (count rows) 1)
                                                     (= (count (first rows)) 1))]
                          [single-cell? (or (ffirst rows) *null-text*)])
           fractions (when-not (or rotated single-column-and-row)
                       (number-columns rows))
           [headers rows] (if (or rotated single-column-and-row)
                            ;; Do not restrict column width if result
                            ;; set has only 1 row or 1 column & 1 row.
                            [headers
                             (map (fn [row] (map #(if (nil? %) *null-text* %)
                                                 row))
                                  rows)]
                            [(map trim-max-width headers)
                             (map #(map cell-text % fractions) rows)])
           rn #"(\r\n)|\n|\r"
           nl (System/getProperty "line.separator")
           rows (for [row rows]
                  (map #(if (string? %)
                          (if single-column-and-row
                            ;; In case of only 1 column & 1 row unify
                            ;; newline separators to system line break.
                            (s/replace % rn nl)
                            (one-line %))
                          ;; Do not remove newline separators if result
                          ;; set cell is not a string.
                          %)
                       row))
           widths (if single-column-and-row
                    (list
                     (apply max
                            (cons
                             (string-length (first headers))
                             (if (string? cell-value)
                               (map string-length (s/split cell-value rn))
                               (list (string-length (str cell-value)))))))
                    (for [col (rotate-table (conj rows headers))]
                      (apply max (map #(string-length (str %)) col))))
           spacers (map #(apply str (repeat % (u? "─" "-"))) widths)
           fmts (if (and rotated (not aob))
                  ;; Remove trailing spaces for data column of single-row
                  ;; result if no outer borders required.
                  (list #(pad % (first widths)) identity)
                  ;; Numbers to the right, their headers too.
                  (map (fn [w fraction]
                         (if fraction #(pad-left % w) #(pad % w)))
                       widths
                       (or fractions (repeat nil))))
           fmt-row (fn [leader divider trailer row]
                     (str leader
                          (apply str (interpose
                                      divider
                                      (for [[col fmt] (map vector row fmts)]
                                        (fmt (str col)))))
                          trailer))]
       (when (not-empty msg)
         (println msg)
         (println))
       (when (not rotated)
         (println (fmt-row (if aob (u? "│ " "| ") "") (u? " │ " " | ") (if aob (u? " │" " |") "") headers))
         (println (fmt-row (if aob (u? "├─" "|-") "") (u? "─┼─" "-+-") (if aob (u? "─┤" "-|") "") spacers)))
       (doseq [row (if (and aob single-column-and-row (string? cell-value))
                     (map list (s/split cell-value (re-pattern nl)))
                     rows)]
         (println (fmt-row (if aob (u? "│ " "| ") "") (u? " │ " " | ") (if aob (u? " │" " |") "") row))))))
  ([rows] (print-table rows @fetch-size)))

(defn unify-str
  "Concatenate stings, unify newline separators to the system line break."
  [& s]
  (if (empty? (filter not-empty s))
    ""
    (apply str (map #(s/replace %
                                #"(\r\n)|\n|\r"
                                (System/getProperty "line.separator"))
                    s))))

(defn format-sql [sql]
  (s/trim
   (let [sql (s/trim sql)]
     (.format (if (dml? sql)
                (BasicFormatterImpl.)
                (DDLFormatterImpl.))
              sql))))

(defn format-sql-print
  "SQL should be printed to provide cross-platform newline handling."
  [sql]
  (print (format-sql sql)))

(defn format-sql-if-required [sql]
  (if (> (StringUtils/countMatches sql "\n") 1)
    sql
    (format-sql sql)))

(defn write-result-file [text & {:keys [result-file
                                        append]
                                 :or {append false}}]
  (spit result-file text :append append)
  result-file)

(defn clear-result-file [& {:keys [result-file]}]
  (write-result-file "" :result-file result-file))
