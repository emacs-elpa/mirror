;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idris-mode" "1.0"
  "Major mode for editing Idris code."
  '((emacs     "24")
    (prop-menu "0.1")
    (cl-lib    "0.5"))
  :url "https://github.com/idris-hackers/idris-mode"
  :commit "b77eadd8ac2048d5c882b4464bd9673e45dd6a59"
  :revdesc "b77eadd8ac20"
  :keywords '("languages"))
