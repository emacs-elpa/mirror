;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-rtags" "0.5"
  "RTags back-end for company."
  '((emacs   "24.3")
    (company "0.8.1"))
  :url "http://rtags.net"
  :commit "8e12f2f4ae77343d40851cde0b9bfabe9e7769d0"
  :revdesc "8e12f2f4ae77"
  :authors '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
             ("Anders Bakken" . "agbakken@gmail.com"))
  :maintainers '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
                 ("Anders Bakken" . "agbakken@gmail.com")))
