;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-quoted" "0.1"
  "Highlight Lisp quotes and quoted symbols."
  '((emacs "24"))
  :url "https://github.com/Fanael/highlight-quoted"
  :commit "cdd7164f9ad3a9929387c08af641ef6f5f013f4f"
  :revdesc "cdd7164f9ad3"
  :authors '(("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers '(("Fanael Linithien" . "fanael4@gmail.com")))
