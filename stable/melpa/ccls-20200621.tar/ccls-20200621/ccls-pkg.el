;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ccls" "20200621"
  "Ccls client for lsp-mode."
  '((emacs    "25.1")
    (lsp-mode "6.3.1")
    (dash     "2.14.1"))
  :url "https://github.com/MaskRay/emacs-ccls"
  :commit "fa1ef15f061fe53b03a86fb97a368cf59f6318e0"
  :revdesc "fa1ef15f061f"
  :keywords '("languages" "lsp" "c++"))
