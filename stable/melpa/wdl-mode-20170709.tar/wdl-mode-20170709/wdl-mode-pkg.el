;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wdl-mode" "20170709"
  "WDL (Workflow Definition Language) major mode."
  ()
  :url "https://github.com/zhanxw/wdl-mode"
  :commit "5cc51c5eecb513d5ffeae8ec579c395a2dab1a6d"
  :revdesc "5cc51c5eecb5"
  :keywords '("languages")
  :authors '(("Xiaowei Zhan" . "zhanxw@gmail.com"))
  :maintainers '(("Xiaowei Zhan" . "zhanxw@gmail.com")))
