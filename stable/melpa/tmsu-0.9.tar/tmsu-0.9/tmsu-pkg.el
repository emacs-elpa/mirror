;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tmsu" "0.9"
  "A basic TMSU interface."
  '((emacs "28.1"))
  :url "https://github.com/vifon/tmsu.el"
  :commit "a2bf2e8c48232964d6317cc77a95ea98a9d3dc7d"
  :revdesc "a2bf2e8c4823"
  :keywords '("files"))
