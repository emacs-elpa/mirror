;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-color-mode-line" "0.3"
  "Change mode line color with Flycheck status."
  '((flycheck "0.15")
    (dash     "1.2")
    (emacs    "24.1"))
  :url "https://github.com/flycheck/flycheck-color-mode-line"
  :commit "c85319f8d2579e770c9060bfef11bedc1370d8be"
  :revdesc "c85319f8d257"
  :keywords '("convenience" "language" "tools")
  :authors '(("Sylvain Benner" . "sylvain.benner@gmail.com"))
  :maintainers '(("Sylvain Benner" . "sylvain.benner@gmail.com")))
