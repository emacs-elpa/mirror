;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-semicolon" "0.2.1"
  "Insert semicolon smartly."
  '((emacs "25"))
  :url "https://github.com/iquiw/smart-semicolon"
  :commit "c11096679dbed3875c37413337ee490ee7951b63"
  :revdesc "c11096679dbe"
  :authors '(("Iku Iwasa" . "iku.iwasa@gmail.com"))
  :maintainers '(("Iku Iwasa" . "iku.iwasa@gmail.com")))
