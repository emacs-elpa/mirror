;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elchacha" "1.0.4"
  "Elisp ChaCha20 implementation."
  '((emacs "25.1"))
  :url "https://github.com/KeyWeeUsr/elchacha"
  :commit "e6e71b8b25eafefd23c33d0d9cb820c4eb646ff6"
  :revdesc "1.0.4-0-ge6e71b8b25ea"
  :keywords '("convenience" "elchacha")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
