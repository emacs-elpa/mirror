;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-multi-wiki" "0.4.0"
  "Multiple wikis based on Org mode."
  '((emacs  "26.1")
    (dash   "2.12")
    (s      "1.12")
    (org-ql "0.4")
    (org    "9.3"))
  :url "https://github.com/akirak/org-multi-wiki"
  :commit "80791ea872939df0578dc3a2992a2f7fd5618971"
  :revdesc "80791ea87293"
  :keywords '("org" "outlines" "files")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
