;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bech32" "0.2.1"
  "Bech32 library."
  '((emacs "26.1"))
  :url "https://github.com/Titan-C/cardano.el"
  :commit "badbf267fa488df1cb87809ed234ebd67786f2f8"
  :revdesc "badbf267fa48"
  :authors '(("Oscar Najera" . "https://oscarnajera.com"))
  :maintainers '(("Oscar Najera" . "hi@oscarnajera.com")))
