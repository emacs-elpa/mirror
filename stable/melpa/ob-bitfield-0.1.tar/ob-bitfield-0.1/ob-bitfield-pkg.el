;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-bitfield" "0.1"
  "Babel Functions for bitfield."
  ()
  :url "https://github.com/gsingh93/ob-bitfield"
  :commit "4b54dbf366edad28ab53c97859fade751c1ec808"
  :revdesc "4b54dbf366ed")
