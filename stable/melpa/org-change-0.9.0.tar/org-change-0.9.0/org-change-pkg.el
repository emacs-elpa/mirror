;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "0.9.0"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "0caa38b0772664d647dfa76ee237006bb59ba72c"
  :revdesc "0caa38b07726"
  :keywords '("wp" "convenience"))
