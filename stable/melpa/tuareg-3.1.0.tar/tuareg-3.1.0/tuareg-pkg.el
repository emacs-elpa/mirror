;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tuareg" "3.1.0"
  "OCaml mode."
  '((emacs "26.3"))
  :url "https://github.com/ocaml/tuareg"
  :commit "29ed86896e24c9d9d9855cf05ab7a6166a030250"
  :revdesc "3.1.0-0-g29ed86896e24"
  :keywords '("ocaml" "languages")
  :authors '(("Albert Cohen" . "Albert.Cohen@inria.fr")
             ("Sam Steingold" . "sds@gnu.org")
             ("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
             ("Till Varoquaux" . "till@pps.jussieu.fr")
             ("Sean McLaughlin" . "seanmcl@gmail.com")
             ("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainers '(("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
                 ("Stefan Monnier" . "monnier@iro.umontreal.ca")))
