;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "torus" "2.2"
  "A buffer groups manager."
  '((emacs "26")
    (duo   "0"))
  :url "https://github.com/chimay/torus"
  :commit "2fa2c92bf2c66d87ddcd519277e469f67c6615a9"
  :revdesc "v2.2-0-g2fa2c92bf2c6"
  :keywords '("files" "buffers" "groups" "persistent" "history" "layout" "tabs"))
