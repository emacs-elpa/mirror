;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fpga" "0.3.0"
  "FPGA & ASIC Utils."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/fpga"
  :commit "9f014c09d132f60fe5fe76356acf78affa2e2bdc"
  :revdesc "9f014c09d132"
  :keywords '("tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
