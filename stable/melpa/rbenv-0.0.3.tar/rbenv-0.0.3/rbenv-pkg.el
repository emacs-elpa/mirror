;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rbenv" "0.0.3"
  "Emacs integration for rbenv."
  ()
  :url "https://github.com/senny/rbenv.el"
  :commit "a613ee1941efa48ef5321bad39ac1ed8ad1540b8"
  :revdesc "v0.0.3-0-ga613ee1941ef"
  :keywords '("ruby" "rbenv")
  :authors '(("Yves Senn" . "yves.senn@gmail.com"))
  :maintainers '(("Yves Senn" . "yves.senn@gmail.com")))
