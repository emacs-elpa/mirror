;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smbc" "0.2.1"
  "View SMBC from Emacs."
  ()
  :url "https://github.com/sakshamsharma/emacs-smbc"
  :commit "c377b806118d82140197d9cb1095548477e00497"
  :revdesc "c377b806118d"
  :keywords '("smbc" "webcomic")
  :authors '(("Saksham Sharma" . "saksham0808@gmail.com"))
  :maintainers '(("Saksham Sharma" . "saksham0808@gmail.com")))
