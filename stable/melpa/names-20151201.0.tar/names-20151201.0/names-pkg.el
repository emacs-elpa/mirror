;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "names" "20151201.0"
  "Namespaces for emacs-lisp. Avoid name clobbering without hiding symbols."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/Malabarba/names"
  :commit "00862c57ae6363ba86d1e5ce138929a1b6d5c7e6"
  :revdesc "00862c57ae63"
  :keywords '("extensions" "lisp")
  :authors '(("Artur Malabarba" . "emacs@endlessparentheses.com"))
  :maintainers '(("Artur Malabarba" . "emacs@endlessparentheses.com")))
