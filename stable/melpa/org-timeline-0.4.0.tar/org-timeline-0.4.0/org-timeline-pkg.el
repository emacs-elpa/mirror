;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timeline" "0.4.0"
  "Add graphical view of agenda to agenda buffer."
  '((dash  "2.13.0")
    (emacs "24.3"))
  :url "https://github.com/Fuco1/org-timeline/"
  :commit "55cafb5512a174c3898aaacd71ab58832b9fe321"
  :revdesc "55cafb5512a1"
  :keywords '("calendar")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
