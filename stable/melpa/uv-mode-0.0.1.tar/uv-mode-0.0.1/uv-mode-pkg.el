;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uv-mode" "0.0.1"
  "Integrate uv with python-mode."
  '((emacs    "25.1")
    (pythonic "0.1.0"))
  :url "https://github.com/z80/uv-mode"
  :commit "1d7c658f1c60a5fed13bc17e313f7a42f76ae553"
  :revdesc "1d7c658f1c60"
  :authors '(("z80" . "z80@ophy.xyz"))
  :maintainers '(("z80" . "z80@ophy.xyz")))
