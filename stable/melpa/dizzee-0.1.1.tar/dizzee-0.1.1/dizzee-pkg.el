;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dizzee" "0.1.1"
  "Utilities for managing subprocesses in Emacs."
  ()
  :url "https://github.com/davidmiller/dizzee"
  :commit "7e1851e425dbea15c8a9bec2ac25ec0128ceacea"
  :revdesc "7e1851e425db"
  :keywords '("emacs" "processes")
  :authors '(("David Miller" . "david@deadpansincerity.com"))
  :maintainers '(("David Miller" . "david@deadpansincerity.com")))
