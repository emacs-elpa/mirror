;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "4.0.4"
  "Light cornsilk theme with warm, earthy colors."
  '((emacs        "28.1")
    (modus-themes "5.0.0"))
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "468d7d4fafc8f8fe8515ac0454561121619e1129"
  :revdesc "468d7d4fafc8"
  :keywords '("faces" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
