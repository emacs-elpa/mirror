;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "run-command-recipes" "0.1.0"
  "Start pack of recipes to `run-command' inside Emacs using only one command."
  '((emacs       "25.1")
    (dash        "2.18.0")
    (f           "0.20.0")
    (run-command "1.0.0"))
  :url "https://github.com/semenInRussia/emacs-run-command-recipes"
  :commit "19e56a1d1275704a2cca01f6cc05535bed182d1c"
  :revdesc "19e56a1d1275"
  :keywords '("extensions" "run-command")
  :authors '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainers '(("semenInRussia" . "hrams205@gmail.com")))
