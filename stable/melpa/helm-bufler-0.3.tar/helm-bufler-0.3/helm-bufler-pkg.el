;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bufler" "0.3"
  "Helm source for Bufler."
  '((emacs  "26.3")
    (bufler "0.2-pre")
    (helm   "1.9.4"))
  :url "https://github.com/alphapapa/bufler.el"
  :commit "3a6176d0e074bb00ea8b3fef4f7e03957a3ea058"
  :revdesc "v0.3-0-g3a6176d0e074"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
