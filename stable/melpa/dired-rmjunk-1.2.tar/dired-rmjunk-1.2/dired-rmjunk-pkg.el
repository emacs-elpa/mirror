;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-rmjunk" "1.2"
  "A home directory cleanup utility for Dired."
  ()
  :url "https://git.sr.ht/~jakob/dired-rmjunk"
  :commit "6a9fa6a35498e53e8c57282e3b08dedc896d880d"
  :revdesc "v1.2-0-g6a9fa6a35498"
  :keywords '("files" "matching")
  :authors '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org"))
  :maintainers '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org")))
