;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guess-language" "0.0.1"
  "Automatically detect human language."
  '((cl-lib "0.5"))
  :url "https://github.com/tmalsburg/guess-language.el"
  :commit "43eb329c06ac5a39ce79d4f5d4bc7690a4d60353"
  :revdesc "43eb329c06ac"
  :authors '(("Titus von der Malsburg" . "malsburg@posteo.de"))
  :maintainers '(("Titus von der Malsburg" . "malsburg@posteo.de")))
