;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shadchen" "1.2"
  "Pattern matching for elisp."
  ()
  :url "https://github.com/VincentToups/shadchen-el"
  :commit "9c9b56a7b94d41d94d935c7abc111243f5fb683a"
  :revdesc "9c9b56a7b94d")
