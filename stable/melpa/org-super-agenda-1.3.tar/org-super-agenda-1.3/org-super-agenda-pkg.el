;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-super-agenda" "1.3"
  "Supercharge your agenda."
  '((emacs  "26.1")
    (compat "29.1.4.1")
    (s      "1.10.0")
    (dash   "2.13")
    (org    "9.0")
    (ht     "2.2")
    (ts     "0.2"))
  :url "https://github.com/alphapapa/org-super-agenda"
  :commit "0d7851e1b4bfa278a0ceca99f0130a795a825103"
  :revdesc "v1.3-0-g0d7851e1b4bf"
  :keywords '("hypermedia" "outlines" "org" "agenda")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
