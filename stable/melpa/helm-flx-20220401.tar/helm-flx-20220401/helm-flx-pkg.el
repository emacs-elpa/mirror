;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-flx" "20220401"
  "Sort helm candidates by flx score."
  '((emacs "24.4")
    (helm  "1.7.9")
    (flx   "0.5"))
  :url "https://github.com/PythonNut/helm-flx"
  :commit "27dd9e3ce385a3ca15092150e65781de14b5b00b"
  :revdesc "27dd9e3ce385"
  :keywords '("convenience" "helm" "fuzzy" "flx")
  :authors '(("Jonathan Hayase" . "jonathan.hayase@gmail.com"))
  :maintainers '(("Jonathan Hayase" . "jonathan.hayase@gmail.com")))
