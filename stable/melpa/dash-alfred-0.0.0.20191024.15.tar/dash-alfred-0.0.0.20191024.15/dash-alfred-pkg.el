;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dash-alfred" "0.0.0.20191024.15"
  "Search Dash documentation via Dash-Alfred-Workflow."
  '((emacs "25.1"))
  :url "https://github.com/xuchunyang/dash-alfred.el"
  :commit "fcd21bd6c7eb5cd31377be970406ff3d2454bd5c"
  :revdesc "fcd21bd6c7eb"
  :keywords '("docs"))
