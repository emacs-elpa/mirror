;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard-hackernews" "0.0.1"
  "Hacker News Client for dashboard; -*- lexical-binding: t -*-;."
  '((dashboard "1.2.5")
    (request   "0.3.0"))
  :url "https://github.com/hyakt/emacs-dashboard-hackernews"
  :commit "d6ca1b9ebab8723dcda1fb5f6c87fd8e34ae0932"
  :revdesc "d6ca1b9ebab8"
  :authors '(("Hayato KAJIYAMA" . "kaji1216@gmail.com"))
  :maintainers '(("Hayato KAJIYAMA" . "kaji1216@gmail.com")))
