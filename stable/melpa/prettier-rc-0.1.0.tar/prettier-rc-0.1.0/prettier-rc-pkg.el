;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-rc" "0.1.0"
  "Use local rc rules with prettier."
  '((emacs       "24.3")
    (prettier-js "0.1.0"))
  :url "https://github.com/jjuliano/prettier-rc-emacs"
  :commit "eaef4cd76094c7351a2da508b4bc3b25966d0da6"
  :revdesc "eaef4cd76094"
  :keywords '("convenience" "edit" "js" "ts" "rc" "prettierrc" "prettier-rc" "prettier" "prettier-js")
  :authors '(("Joel Bryan Juliano" . "joelbryandotjulianoatgmaildotcom"))
  :maintainers '(("Joel Bryan Juliano" . "joelbryandotjulianoatgmaildotcom")))
