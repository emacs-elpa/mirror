;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-daily-reflection" "0.3111"
  "Concurrent display of org(-roam) dailies."
  '((emacs  "26.1")
    (org    "9.4")
    (compat "30.0.0.0"))
  :url "https://github.com/emacsomancer/org-daily-reflection"
  :commit "292c6e5713680dd81b887689f176ab0ca3815f88"
  :revdesc "292c6e571368"
  :keywords '("convenience" "frames" "terminals" "tools" "window-system")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
