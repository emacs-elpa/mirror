;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keyswap" "0.1.1"
  "Swap bindings between key pairs."
  '((emacs "24.3"))
  :url "https://github.com/hardenedapple/keyswap.el"
  :commit "b10fc9f55f7f0f6b6852b49a301739e85c17aead"
  :revdesc "b10fc9f55f7f"
  :keywords '("convenience")
  :authors '(("Matthew Malcomson" . "hardenedapple@gmail.com"))
  :maintainers '(("Matthew Malcomson" . "hardenedapple@gmail.com")))
