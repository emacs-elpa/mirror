;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-open" "0.0.1"
  "Open files from dired using using custom actions."
  '((dash "2.5.0"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "49176344e85ef09c6242696cb9c144077577573a"
  :revdesc "49176344e85e"
  :keywords '("lisp")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
