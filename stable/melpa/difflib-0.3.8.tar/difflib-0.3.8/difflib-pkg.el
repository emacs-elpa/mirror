;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difflib" "0.3.8"
  "Helpers for computing deltas between sequences."
  '((emacs      "24.4")
    (cl-generic "0.3")
    (ht         "2.2")
    (s          "1.12.0"))
  :url "https://github.com/dieggsy/difflib.el"
  :commit "b08850251812d71e62fd6956081299590acdf37b"
  :revdesc "b08850251812"
  :keywords '("matching" "tools" "string")
  :authors '(("Diego A. Mundo" . "diegoamundo@gmail.com"))
  :maintainers '(("Diego A. Mundo" . "diegoamundo@gmail.com")))
