;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "history" "1.0.0"
  "History utility for source code navigation."
  '((emacs "24.3"))
  :url "https://github.com/boyw165/history"
  :commit "adef53ecc2f6067bb61f020a2b66c5185a51632d"
  :revdesc "adef53ecc2f6")
