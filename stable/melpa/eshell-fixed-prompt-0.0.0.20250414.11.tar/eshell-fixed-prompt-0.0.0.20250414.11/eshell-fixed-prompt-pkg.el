;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-fixed-prompt" "0.0.0.20250414.11"
  "Restrict eshell to a single fixed prompt."
  '((emacs "25")
    (s     "1.11.0"))
  :url "https://github.com/mallt/eshell-fixed-prompt-mode"
  :commit "f495a7bdf0f5da87e9eb3021862aa8e2ec578948"
  :revdesc "f495a7bdf0f5"
  :authors '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com"))
  :maintainers '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com")))
