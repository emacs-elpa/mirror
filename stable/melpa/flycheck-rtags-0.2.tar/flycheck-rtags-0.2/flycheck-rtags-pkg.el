;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-rtags" "0.2"
  "RTags Flycheck integration."
  '((emacs    "24")
    (flycheck "0.23")
    (rtags    "2.9"))
  :url "http://rtags.net"
  :commit "8e12f2f4ae77343d40851cde0b9bfabe9e7769d0"
  :revdesc "8e12f2f4ae77"
  :authors '(("Christian Schwarzgruber" . "c.schwarzgruber.cs@gmail.com"))
  :maintainers '(("Christian Schwarzgruber" . "c.schwarzgruber.cs@gmail.com")))
