;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-expose-emphasis-markers" "0.21"
  "Automatically show hidden org emphasis markers."
  '((emacs "29.1"))
  :url "https://github.com/lorniu/org-expose-emphasis-markers"
  :commit "ba81ff4866326dae63b5eecf2643abb444de32a3"
  :revdesc "ba81ff486632"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
