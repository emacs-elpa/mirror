;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "p4" "12.0"
  "Simple Perforce-Emacs Integration."
  ()
  :url "https://github.com/gareth-rees/p4.el"
  :commit "39add88ae2f83375c525930b61e08394a7974320"
  :revdesc "39add88ae2f8"
  :authors '(("Gareth Rees" . "gdr@garethrees.org"))
  :maintainers '(("Gareth Rees" . "gdr@garethrees.org")))
