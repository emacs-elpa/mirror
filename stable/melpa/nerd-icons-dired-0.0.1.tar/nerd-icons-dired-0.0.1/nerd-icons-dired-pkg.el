;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons-dired" "0.0.1"
  "Shows icons for each file in dired mode."
  '((emacs "24.4"))
  :url "https://github.com/rainstormstudio/nerd-icons-dired"
  :commit "df3bf73ab6181b5d6b5defd7e2ef021f31054432"
  :revdesc "df3bf73ab618"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")))
