;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clay" "1.5"
  "Emacs commands Clay - literate in Clojure."
  '((emacs "26.1")
    (cider "1.0"))
  :url "https://github.com/scicloj/clay.el"
  :commit "5d5512e67e7dd4b7b7ffae070517948cb1ad82e4"
  :revdesc "5d5512e67e7d"
  :keywords '("lisp"))
