;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chordpro-mode" "2.6.0"
  "Major mode for ChordPro lead sheet file format."
  '((emacs  "29.1")
    (compat "29.1.4.1"))
  :url "https://git.sr.ht/~breatheoutbreathein/chordpro-mode.el/"
  :commit "c4167676831c790240610cfb4b5bbef93b5ddd49"
  :revdesc "2.6.0-0-gc4167676831c"
  :keywords '("convenience")
  :authors '(("Howard Ding" . "hading2@gmail.com"))
  :maintainers '(("Howard Ding" . "hading2@gmail.com")))
