;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eval-expr" "0.0.0.20120619.2"
  "Enhanced eval-expression command."
  ()
  :url "https://github.com/jwiegley/eval-expr"
  :commit "a0e69e83de41df8dbccefc1962ab4f02206a3328"
  :revdesc "a0e69e83de41"
  :keywords '("lisp" "extensions")
  :authors '(("Noah Friedman" . "friedman@splode.com"))
  :maintainers '((nil . "friedman@splode.com")))
