;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-recoll" "1.0.0"
  "Recoll queries using consult."
  '((emacs   "26.1")
    (consult "2.0"))
  :url "https://codeberg.org/jao/consult-recoll"
  :commit "eddbc7ba70439881e4781fa73fb0fb240e02fd3b"
  :revdesc "eddbc7ba7043"
  :keywords '("docs" "convenience")
  :authors '(("Jose A Ortega Ruiz" . "jao@gnu.org"))
  :maintainers '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
