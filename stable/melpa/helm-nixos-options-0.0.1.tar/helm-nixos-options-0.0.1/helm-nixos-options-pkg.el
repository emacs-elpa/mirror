;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-nixos-options" "0.0.1"
  "Helm Interface for nixos-options."
  '((nixos-options "0.0.1")
    (helm          "1.5.6"))
  :url "http://www.github.com/travisbhartwell/nix-emacs/"
  :commit "5fc8fa29bea9dd8e9c822af92f9bc6ddc223635f"
  :revdesc "5fc8fa29bea9"
  :keywords '("unix")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com")
             ("Travis B. Hartwell" . "nafai@travishartwell.net"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")
                 ("Travis B. Hartwell" . "nafai@travishartwell.net")))
