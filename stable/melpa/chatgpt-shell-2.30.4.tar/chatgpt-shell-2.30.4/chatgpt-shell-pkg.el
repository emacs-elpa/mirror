;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "2.30.4"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.82.3")
    (transient   "0.9.3"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "7a91afaddcb33ce2bd933844fa312fd89b3a47bd"
  :revdesc "7a91afaddcb3")
