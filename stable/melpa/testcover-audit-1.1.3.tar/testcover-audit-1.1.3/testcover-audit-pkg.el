;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "testcover-audit" "1.1.3"
  "Quantitative coverage statistics for testcover.el."
  '((emacs   "29.4")
    (project "0.9.8"))
  :url "https://github.com/OverbearingPearl/testcover-audit"
  :commit "519d6bf1b7839bf755c6a79ec3f85b71fa9113a6"
  :revdesc "519d6bf1b783"
  :keywords '("tools")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
