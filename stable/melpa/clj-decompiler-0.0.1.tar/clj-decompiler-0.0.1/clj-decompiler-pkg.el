;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clj-decompiler" "0.0.1"
  "Clojure Java decompiler expansion."
  '((emacs        "26.1")
    (clojure-mode "5.12")
    (cider        "0.18.0"))
  :url "http://www.github.com/bsless/clj-decompiler.el"
  :commit "1feccad7931e748627c32cf22e12f914705c6460"
  :revdesc "1feccad7931e"
  :keywords '("languages" "clojure" "cider" "java" "decompiler")
  :authors '(("Ben Sless" . "ben.sless@gmail.com"))
  :maintainers '(("Ben Sless" . "ben.sless@gmail.com")))
