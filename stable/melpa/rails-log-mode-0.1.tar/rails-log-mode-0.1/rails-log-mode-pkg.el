;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rails-log-mode" "0.1"
  "Major mode for viewing Rails log files."
  ()
  :url "https://github.com/ananthakumaran/rails-log-mode"
  :commit "15d371d1f8443c098cf77e9961e5010cc8dfb880"
  :revdesc "15d371d1f844"
  :keywords '("rails" "log")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
