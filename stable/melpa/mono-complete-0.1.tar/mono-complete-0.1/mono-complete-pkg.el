;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mono-complete" "0.1"
  "Completion suggestions with multiple back-ends."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-mono-complete"
  :commit "eda613656bdf64760a593c73d36c706f6bfa7939"
  :revdesc "eda613656bdf"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
