;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abyss-theme" "0.7.2"
  "A dark theme with contrasting colours."
  '((emacs "24"))
  :url "https://github.com/mgrbyte/emacs-abyss-theme"
  :commit "6eb2b5735808ea96a36fc7abf741fc3bbf1b6ee4"
  :revdesc "v0.7.2-0-g6eb2b5735808"
  :keywords '("theme" "dark" "contrasting colours")
  :authors '(("Matt Russell" . "mgrbyte@member.fsf.org"))
  :maintainers '(("Matt Russell" . "mgrbyte@member.fsf.org")))
