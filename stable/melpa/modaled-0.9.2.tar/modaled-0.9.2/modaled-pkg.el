;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modaled" "0.9.2"
  "Build your own minor modes for modal editing."
  '((emacs "25.1"))
  :url "https://github.com/DCsunset/modaled"
  :commit "b8808c97b8720843c562800f0bfd71484781e87b"
  :revdesc "v0.9.2-0-gb8808c97b872"
  :keywords '("convenience" "modal-editing"))
