;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcsv" "1.4.0"
  "Parser of csv."
  '((emacs "25.1"))
  :url "https://github.com/mhayashi1120/Emacs-pcsv"
  :commit "aa421d12c0da0adb9bc74a050a591dcbabf934ae"
  :revdesc "aa421d12c0da"
  :keywords '("data")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
