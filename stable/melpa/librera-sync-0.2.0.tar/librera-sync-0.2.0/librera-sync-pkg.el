;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "librera-sync" "0.2.0"
  "Sync document's position with Librera Reader for Android."
  '((emacs "26.1")
    (f     "0.17")
    (dash  "2.12.0"))
  :url "https://github.com/jumper047/librera-sync"
  :commit "911a8a64ed369037653fbe39e06ef4b4423b28fb"
  :revdesc "911a8a64ed36"
  :keywords '("multimedia" "sync")
  :authors '(("Dmitriy Pshonko" . "jumper047@gmail.com"))
  :maintainers '(("Dmitriy Pshonko" . "jumper047@gmail.com")))
