;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kusanagi-theme" "0.1.1"
  "Ghost in the Shell inspired dark theme built on Modus."
  '((emacs        "30.1")
    (modus-themes "5.0.0"))
  :url "https://github.com/LionyxML/kusanagi-theme"
  :commit "db50fec23553c5028c19463bfcf983036ed15552"
  :revdesc "db50fec23553"
  :keywords '("faces" "themes")
  :authors '(("Rahul Martim Juliato" . "rahul.juliato@gmail.com"))
  :maintainers '(("Rahul Martim Juliato" . "rahul.juliato@gmail.com")))
