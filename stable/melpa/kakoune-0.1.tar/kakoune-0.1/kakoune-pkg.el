;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kakoune" "0.1"
  "A simulation, but not emulation, of kakoune, in emacs."
  '((ryo-modal        "0.4")
    (multiple-cursors "1.4")
    (expand-region    "0.11.0"))
  :url "https://github.com/jmorag/kakoune.el"
  :commit "08da0f7a0ddf4fbb0f3f1c99d16ddea1dff5ca12"
  :revdesc "08da0f7a0ddf"
  :authors '(("Joseph Morag" . "jm4157@columbia.edu"))
  :maintainers '(("Joseph Morag" . "jm4157@columbia.edu")))
