;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-patch-changelog" "0.1.0"
  "Git format-patch for emacs-devel."
  '((emacs "25.1")
    (magit "2.90.1"))
  :url "https://github.com/dickmao/magit-patch-changelog"
  :commit "676a6d07fac613ef1879d355a0eac82828e3e9a6"
  :revdesc "676a6d07fac6"
  :keywords '("git" "tools" "vc")
  :authors '(("dickmao" . "githubid:dickmao"))
  :maintainers '(("dickmao" . "githubid:dickmao")))
