;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "utop" "2.17.0"
  "Universal toplevel for OCaml."
  '((emacs "26"))
  :url "https://github.com/ocaml-community/utop"
  :commit "918cd14b1e1e78f23010ade3accd628680e96d28"
  :revdesc "2.17.0-0-g918cd14b1e1e"
  :keywords '("ocaml" "languages")
  :authors '(("Jeremie Dimino" . "jeremie@dimino.org"))
  :maintainers '(("Jeremie Dimino" . "jeremie@dimino.org")))
