;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-pry" "1.0.0"
  "Realgud front-end to the Ruby pry debugger."
  '((realgud       "1.4.5")
    (load-relative "1.2")
    (cl-lib        "0.5")
    (emacs         "24"))
  :url "https://github.com/rocky/realgud-pry"
  :commit "500bef62369ef1ad876afd99db383c23196e1355"
  :revdesc "500bef62369e")
