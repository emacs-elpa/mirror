;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xtest" "1.1.0"
  "Simple Testing with Emacs & ERT."
  '((cl-lib "0.5"))
  :url "https://github.com/promethial/xtest"
  :commit "b227414d714e7baddef79bd306a43024b9a34d45"
  :revdesc "b227414d714e"
  :keywords '("testing" "ert"))
