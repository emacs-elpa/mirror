;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sq" "0.3.0"
  "Bindings for Sequoia PGP's cli."
  '((emacs "24.1"))
  :url "https://gitlab.com/sequoia-pgp/sqel"
  :commit "2871a8d0680ceb1d8de28a52bd8b2241d0691c02"
  :revdesc "v0.3.0-0-g2871a8d0680c"
  :keywords '("tools" "data" "mail")
  :authors '(("Justus Winter" . "justus@sequoia-pgp.org"))
  :maintainers '(("Justus Winter" . "justus@sequoia-pgp.org")))
