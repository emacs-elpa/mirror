;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sxiv" "0.4.1"
  "Run the sxiv image viewer."
  '((dash  "2.16.0")
    (emacs "25.1"))
  :url "https://gitlab.com/contrapunctus/sxiv.el"
  :commit "a531a7596e307a218beb8ff77893eeae61284f6e"
  :revdesc "a531a7596e30"
  :keywords '("multimedia")
  :authors '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainers '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr")))
