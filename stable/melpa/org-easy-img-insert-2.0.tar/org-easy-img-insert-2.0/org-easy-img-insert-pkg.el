;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-easy-img-insert" "2.0"
  "[No description available]."
  '((emacs "24.4"))
  :url "https://github.com/tashrifsanil/org-easy-img-insert"
  :commit "8096468e25c9af25ef7ef78fe0be6fc854a3dffb"
  :revdesc "8096468e25c9"
  :keywords '("convenience" "hypermedia" "files")
  :authors '(("Tashrif Sanil" . "tashrifsanil@kloke-source.com"))
  :maintainers '(("Tashrif Sanil" . "tashrifsanil@kloke-source.com")))
