;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphql-ts-mode" "0.1.0"
  "Tree-sitter support for GraphQL."
  '((emacs "29.1"))
  :url "https://sr.ht/~joram/graphql-ts-mode/"
  :commit "7e9eaf5aab4706974cfcdc469e7fbc5bb9d8f26e"
  :revdesc "7e9eaf5aab47"
  :keywords '("languages" "graphql" "tree-sitter")
  :authors '(("Joram Schrijver" . "i@joram.io"))
  :maintainers '(("Joram Schrijver" . "i@joram.io")))
