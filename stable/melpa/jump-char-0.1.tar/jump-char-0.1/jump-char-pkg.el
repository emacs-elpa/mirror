;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jump-char" "0.1"
  "Navigation isearch."
  ()
  :url "https://github.com/lewang/jump-char"
  :commit "204cb033137dd719791e5555cdc9feff817d5cf5"
  :revdesc "204cb033137d")
