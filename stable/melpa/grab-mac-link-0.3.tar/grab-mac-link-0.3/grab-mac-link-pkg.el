;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grab-mac-link" "0.3"
  "Grab link from Mac Apps and insert it into Emacs."
  '((emacs "24"))
  :url "https://github.com/xuchunyang/grab-mac-link.el"
  :commit "9b47cbe126a0735fa447a3c5e1e8ba80a7ef8d26"
  :revdesc "9b47cbe126a0"
  :keywords '("mac" "hyperlink"))
