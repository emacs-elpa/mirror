;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lastfm" "1.2"
  "Last.fm API for Emacs Lisp."
  '((emacs    "26.1")
    (request  "0.3.0")
    (anaphora "1.0.4")
    (memoize  "1.1")
    (elquery  "0.1.0")
    (s        "1.12.0"))
  :url "https://github.com/mihaiolteanu/lastfm.el/"
  :commit "96568f07324ba32804be9352016956694923f5f3"
  :revdesc "96568f07324b"
  :keywords '("multimedia" "api")
  :authors '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainers '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm")))
