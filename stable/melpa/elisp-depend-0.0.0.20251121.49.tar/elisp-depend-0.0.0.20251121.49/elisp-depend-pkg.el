;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-depend" "0.0.0.20251121.49"
  "Parse depend libraries of elisp file."
  ()
  :url "https://github.com/emacsorphanage/elisp-depend"
  :commit "c604eee1a86a297cd13c0235ebde1431dcad59d2"
  :revdesc "c604eee1a86a"
  :authors '((nil . "AndyStewartlazycat.manatee@gmail.com")
             ("Tehom" . "TomBretontehom@panix.com")
             ("Michael Heerdegen" . "michael_heerdegen@web.de"))
  :maintainers '((nil . "AndyStewartlazycat.manatee@gmail.com")
                 ("Tehom" . "TomBretontehom@panix.com")
                 ("Michael Heerdegen" . "michael_heerdegen@web.de")))
