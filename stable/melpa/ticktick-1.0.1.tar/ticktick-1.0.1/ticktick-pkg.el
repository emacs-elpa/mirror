;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ticktick" "1.0.1"
  "Sync Org Mode tasks with TickTick."
  '((emacs        "27.1")
    (request      "0.3.0")
    (simple-httpd "1.5.0"))
  :url "https://github.com/polhuang/ticktick.el"
  :commit "83692995ff14cf61b97ec7f68693c214c56b566b"
  :revdesc "v1.0.1-0-g83692995ff14"
  :keywords '("tools" "ticktick" "org" "tasks" "todo"))
