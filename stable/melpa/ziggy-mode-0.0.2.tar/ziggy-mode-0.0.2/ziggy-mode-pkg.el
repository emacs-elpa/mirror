;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ziggy-mode" "0.0.2"
  "Major mode for Ziggy, a data serialization language."
  '((emacs "29.1"))
  :url "https://github.com/robbielyman/ziggy-mode"
  :commit "5d67e9af8b7ffd83400675f123e69891969b0099"
  :revdesc "5d67e9af8b7f"
  :authors '(("2024 Robbie Lyman" . "rb.lymn@gmail.com"))
  :maintainers '(("2024 Robbie Lyman" . "rb.lymn@gmail.com")))
