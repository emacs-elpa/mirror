;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "1.5.1"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "b7587aecc099e15116e7b180cdcfa2d9f86c4e8a"
  :revdesc "b7587aecc099"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
