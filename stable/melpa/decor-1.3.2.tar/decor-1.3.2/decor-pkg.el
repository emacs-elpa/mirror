;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "decor" "1.3.2"
  "Modify visual decorations."
  '((emacs "24.1"))
  :url "https://github.com/KeyWeeUsr/decor"
  :commit "fa91fd8dabc7e98d7c0fc5e01400aae90966b38d"
  :revdesc "1.3.2-0-gfa91fd8dabc7"
  :keywords '("convenience" "window" "decoration" "distraction" "xprop" "xwayland")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
