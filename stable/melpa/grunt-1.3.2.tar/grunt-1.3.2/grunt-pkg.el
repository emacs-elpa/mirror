;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grunt" "1.3.2"
  "Some glue to stick Emacs and Gruntfiles together."
  '((dash       "2.9.0")
    (ansi-color "3.4.2"))
  :url "https://github.com/gempesaw/grunt.el"
  :commit "e27dbb6b3de9b36c7fb28f69aa06b4b2ea32d4b9"
  :revdesc "1.3.2-0-ge27dbb6b3de9"
  :keywords '("convenience" "grunt")
  :authors '(("Daniel Gempesaw" . "dgempesaw@sharecare.com"))
  :maintainers '(("Daniel Gempesaw" . "dgempesaw@sharecare.com")))
