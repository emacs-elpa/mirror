;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lispy" "0.27.0"
  "Vi-like Paredit."
  ()
  :url "https://github.com/abo-abo/lispy"
  :commit "9c41bc011ae570283cb286659f75d12d38d437ea"
  :revdesc "9c41bc011ae5"
  :keywords '("lisp")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
