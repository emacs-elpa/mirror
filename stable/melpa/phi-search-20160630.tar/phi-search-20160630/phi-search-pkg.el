;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-search" "20160630"
  "Another incremental search & replace, compatible with \"multiple-cursors\"."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "40b86bfe9ae15377fbee842b1de3d93c2eb7dd69"
  :revdesc "40b86bfe9ae1")
