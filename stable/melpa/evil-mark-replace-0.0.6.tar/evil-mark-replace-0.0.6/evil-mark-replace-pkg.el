;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-mark-replace" "0.0.6"
  "Replace the thing in marked area."
  '((evil "1.14.0"))
  :url "https://github.com/redguardtoo/evil-mark-replace"
  :commit "217d5b507aa11dd0b334d5c3e1f74ac1fc2f66a4"
  :revdesc "217d5b507aa1"
  :keywords '("convenience")
  :authors '(("Chen Bin" . "chenbinDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmailDOTcom")))
