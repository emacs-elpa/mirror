;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gomacro-mode" "0.1.0"
  "Gomacro mode and Go REPL integration for Emacs."
  '((emacs "24.4"))
  :url "https://github.com/storvik/gomacro-mode"
  :commit "ac7316d6ecf3029e2d75f6a190880f1556c8bf55"
  :revdesc "ac7316d6ecf3"
  :keywords '("gomacro" "repl" "languages" "tools" "processes"))
