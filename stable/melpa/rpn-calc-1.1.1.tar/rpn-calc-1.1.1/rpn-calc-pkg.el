;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rpn-calc" "1.1.1"
  "Quick RPN calculator for hackers."
  '((popup "0.4"))
  :url "http://hins11.yu-yake.com/"
  :commit "ae4bf0dd8a922ea41b228fac81dee2c10b11982a"
  :revdesc "ae4bf0dd8a92")
