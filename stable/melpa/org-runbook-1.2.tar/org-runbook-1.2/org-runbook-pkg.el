;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-runbook" "1.2"
  "Org mode for runbooks."
  ()
  :url "https://github.com/tyler-dodge/org-runbook"
  :commit "253c2876446650249d59ac35200b373a0aee4e68"
  :revdesc "253c28764466"
  :keywords '("convenience" "processes" "terminals" "files"))
