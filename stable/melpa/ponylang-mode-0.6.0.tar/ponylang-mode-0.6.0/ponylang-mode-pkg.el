;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ponylang-mode" "0.6.0"
  "A major mode for the Pony programming language."
  '((emacs                 "25.1")
    (dash                  "2.17.0")
    (hydra                 "0.15.0")
    (hl-todo               "3.1.2")
    (yafolding             "0.4.1")
    (yasnippet             "0.14.0")
    (company-ctags         "0.0.4")
    (rainbow-delimiters    "2.1.4")
    (fill-column-indicator "1.90"))
  :url "https://github.com/ponylang/ponylang-mode"
  :commit "ebf9c096b26ec1708acc7c84e96998d2b83cb548"
  :revdesc "ebf9c096b26e"
  :keywords '("languages" "programming")
  :authors '(("Sean T Allen" . "sean@monkeysnatchbanana.com"))
  :maintainers '(("Sean T Allen" . "sean@monkeysnatchbanana.com")))
