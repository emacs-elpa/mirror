;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-occasional" "0.1.0"
  "Use ido where you choose."
  ()
  :url "https://github.com/abo-abo/ido-occasional"
  :commit "6058a6b4fa82cc6dc3580638264e8f1a3b799560"
  :revdesc "6058a6b4fa82"
  :keywords '("completion")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
