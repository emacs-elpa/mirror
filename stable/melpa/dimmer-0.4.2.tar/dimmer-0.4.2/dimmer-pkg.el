;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dimmer" "0.4.2"
  "Visually highlight the selected buffer."
  '((emacs "25.1"))
  :url "https://github.com/gonewest818/dimmer.el"
  :commit "e45bf2d064a8ecdea2b4caf646ece2d0adc1d84e"
  :revdesc "e45bf2d064a8"
  :keywords '("faces" "editing"))
