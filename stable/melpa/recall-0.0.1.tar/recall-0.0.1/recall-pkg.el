;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recall" "0.0.1"
  "Recall Emacs process history."
  '((emacs "29.1"))
  :url "https://github.com/svaante/recall"
  :commit "5561e035325d488774931708a50a236fb7236d93"
  :revdesc "5561e035325d"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
