;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asm-blox" "0.4.1"
  "Programming game involving WAT."
  '((emacs "26.1")
    (yaml  "0.5.1"))
  :url "https://github.com/zkry/asm-blox"
  :commit "5517efb1e186139197a2d348b7339a72dd379af8"
  :revdesc "5517efb1e186"
  :keywords '("games"))
