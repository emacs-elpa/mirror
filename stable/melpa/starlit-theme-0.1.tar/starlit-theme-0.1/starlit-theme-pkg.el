;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "starlit-theme" "0.1"
  "Deep blue dark theme with bright colors from the starlit sky."
  '((emacs "24.1"))
  :url "https://github.com/SFTtech/starlit-emacs"
  :commit "3dc4db53a2efb2c46b846564484dd78ef6c1dbff"
  :revdesc "3dc4db53a2ef"
  :keywords '("faces")
  :authors '(("Jonas Jelten" . "jj@sft.lol"))
  :maintainers '(("Jonas Jelten" . "jj@sft.lol")))
