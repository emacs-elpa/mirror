;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-fit" "1.0"
  "Fit a column in an Org Mode table."
  '((emacs "24.4"))
  :url "https://github.com/tbanel/orgtblfit/blob/master/README.org"
  :commit "5798f47406a390a6dd6c675dbc67b883b3147597"
  :revdesc "5798f47406a3"
  :keywords '("data" "extensions"))
