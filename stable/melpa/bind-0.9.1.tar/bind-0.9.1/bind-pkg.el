;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bind" "0.9.1"
  "Bind commands to keys."
  '((emacs "25.1"))
  :url "https://github.com/repelliuss/bind"
  :commit "2a9b8c4eb0b58c0058da1387811edc8436da49c4"
  :revdesc "2a9b8c4eb0b5"
  :authors '(("repelliuss" . "https://github.com/repelliuss"))
  :maintainers '(("repelliuss" . "repelliuss@gmail.com")))
