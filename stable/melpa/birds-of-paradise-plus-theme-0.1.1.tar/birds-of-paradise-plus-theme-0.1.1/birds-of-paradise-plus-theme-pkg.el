;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "birds-of-paradise-plus-theme" "0.1.1"
  "A brown/orange light-on-dark theme for Emacs 24 (deftheme)."
  ()
  :url "https://github.com/jimeh/birds-of-paradise-plus-theme.el"
  :commit "ba2c4443388a73f2c5e2de0c24d3106676aeb6fa"
  :revdesc "v0.1.1-0-gba2c4443388a"
  :keywords '("themes")
  :authors '(("Jim Myhrberg" . "contact@jimeh.me"))
  :maintainers '(("Jim Myhrberg" . "contact@jimeh.me")))
