;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-hadolint" "0.0.1"
  "Flymake backend for hadolint."
  '((emacs "26.1"))
  :url "https://github.com/buzztaiki/flymake-hadolint"
  :commit "4e29c99e1b2267b320fb9721be6c3d5041945647"
  :revdesc "4e29c99e1b22"
  :keywords '("convenience" "processes" "docker" "flymake")
  :authors '(("Taiki Sugawara" . "buzz.taiki@gmail.com"))
  :maintainers '(("Taiki Sugawara" . "buzz.taiki@gmail.com")))
