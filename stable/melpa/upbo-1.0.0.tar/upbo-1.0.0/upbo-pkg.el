;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "upbo" "1.0.0"
  "Karma Test Runner Emacs Integration ;;;."
  '((dash  "2.13.0")
    (emacs "24"))
  :url "https://github.com/shiren"
  :commit "1ef42ecc4428c23fabf5fe83ef935b5150d538cb"
  :revdesc "1ef42ecc4428"
  :keywords '("javascript" "js" "testing" "karma"))
