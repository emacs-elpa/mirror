;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-youtube" "0.3.2"
  "Query YouTube and play videos in your browser."
  '((request "0.2.0")
    (ivy     "0.8.0")
    (cl-lib  "0.5"))
  :url "https://github.com/squiter/ivy-youtube"
  :commit "23e1089d4c4fc32db20df14ba10078aabf117e87"
  :revdesc "23e1089d4c4f"
  :keywords '("youtube" "multimedia" "mpv" "vlc"))
