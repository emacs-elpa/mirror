;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "1.0.0"
  "Mason."
  '((emacs "30.1")
    (yaml  "1.2.0"))
  :url "https://github.com/deirn/mason.el"
  :commit "437ae2b168e19497cb79e0a2947487c6a602583f"
  :revdesc "437ae2b168e1"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
