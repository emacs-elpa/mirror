;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.65.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "9fd6310a71d1eb8a863767452e2fac30f76801fb"
  :revdesc "9fd6310a71d1"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
