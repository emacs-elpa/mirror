;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pubsub" "0.1"
  "A basic publish/subscribe system."
  '((emacs "24.1"))
  :url "https://github.com/countvajhula/pubsub"
  :commit "84b57d3a3d166b73dfe79acf254fab2938f473f4"
  :revdesc "v0.1-0-g84b57d3a3d16"
  :authors '(("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
