;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-jump-mode" "3.0"
  "A quick cursor location minor mode."
  '((emacs "24.4"))
  :url "https://github.com/winterTTr/ace-jump-mode"
  :commit "ff87418b4af284af93a0b666967e442a52a35628"
  :revdesc "v3.0-0-gff87418b4af2"
  :keywords '("convenience" "motion" "location" "cursor")
  :authors '(("winterTTr" . "winterTTr@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
