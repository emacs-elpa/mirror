;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-exwm" "0.0.2"
  "Helm for EXWM buffers."
  '((emacs "25.2")
    (helm  "2.8.5")
    (exwm  "0.15"))
  :url "https://github.com/emacs-helm/helm-exwm"
  :commit "00ddb4d2a127087a0b99f0a440562bd54408572d"
  :revdesc "00ddb4d2a127"
  :keywords '("helm" "exwm")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
