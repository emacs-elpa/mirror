;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "switch-window" "1.6.2"
  "A *visual* way to switch window."
  '((emacs "24"))
  :url "https://github.com/dimitri/switch-window"
  :commit "204f9fc1a39868a2d16ab9370a142c8c9c7a0943"
  :revdesc "204f9fc1a398"
  :keywords '("convenience")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org")
             ("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")
                 ("Feng Shu" . "tumashu@163.com")))
