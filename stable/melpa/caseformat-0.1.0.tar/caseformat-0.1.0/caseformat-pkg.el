;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "caseformat" "0.1.0"
  "Format based letter case converter."
  '((emacs  "24")
    (cl-lib "0.5")
    (dash   "2.12.1")
    (s      "1.10.0"))
  :url "https://github.com/HKey/caseformat"
  :commit "72707c9f0f0819b4e2aa45876432a293aa07f814"
  :revdesc "72707c9f0f08"
  :keywords '("convenience")
  :authors '(("Hiroki YAMAKAWA" . "s06139@gmail.com"))
  :maintainers '(("Hiroki YAMAKAWA" . "s06139@gmail.com")))
