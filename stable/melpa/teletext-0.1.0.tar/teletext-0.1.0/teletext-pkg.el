;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "teletext" "0.1.0"
  "Teletext broadcast viewer."
  '((emacs "24.3"))
  :url "https://github.com/lassik/emacs-teletext"
  :commit "d08a6b60a09bfd44baea951a080ddd66164de353"
  :revdesc "d08a6b60a09b"
  :keywords '("comm" "help" "hypermedia")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
