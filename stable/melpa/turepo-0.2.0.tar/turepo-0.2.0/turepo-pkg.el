;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "turepo" "0.2.0"
  "Open git repository in browser."
  '((emacs "28.1"))
  :url "https://github.com/swarnimcodes/turepo"
  :commit "4d75992fce9a78b4b8a2baedefc856d5a248576a"
  :revdesc "4d75992fce9a"
  :keywords '("vc" "git" "convenience" "github")
  :authors '(("Swarnim Barapatre" . "swarnim14.9@hotmail.com"))
  :maintainers '(("Swarnim Barapatre" . "swarnim14.9@hotmail.com")))
