;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-linenote" "1.1.3"
  "A package inspired by VSCode Linenote."
  '((emacs         "29.1")
    (projectile    "2.8.0")
    (vertico       "1.7")
    (eldoc         "1.11")
    (lsp-mode      "9.0.0")
    (fringe-helper "1.0.1"))
  :url "https://github.com/seokbeomKim/org-linenote"
  :commit "407d2ac834d1de82dd1e37f4642f74a81cf03350"
  :revdesc "407d2ac834d1"
  :keywords '("tools" "note" "org")
  :authors '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainers '(("Jason Kim" . "sukbeom.kim@gmail.com")))
