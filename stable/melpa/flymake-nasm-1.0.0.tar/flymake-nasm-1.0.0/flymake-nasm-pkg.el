;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-nasm" "1.0.0"
  "A flymake handler for asm-mode files using nasm."
  '((flymake-quickdef "1.0.0")
    (emacs            "26.1"))
  :url "https://github.com/juergenhoetzel/flymake-nasm"
  :commit "5a1d7668674181aa3202f8221d00dc32c4f69da8"
  :revdesc "5a1d76686741"
  :keywords '("tools" "languages")
  :authors '(("Jürgen Hötzel" . "juergen@hoetzel.info")))
