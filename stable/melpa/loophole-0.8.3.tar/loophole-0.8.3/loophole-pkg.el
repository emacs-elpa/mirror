;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loophole" "0.8.3"
  "Manage temporary key bindings."
  '((emacs "27.1"))
  :url "https://github.com/0x60df/loophole"
  :commit "24acca1a45d987093561f7294b7b1d1f738f23af"
  :revdesc "24acca1a45d9"
  :keywords '("convenience")
  :authors '(("0x60DF" . "0x60df@gmail.com"))
  :maintainers '(("0x60DF" . "0x60df@gmail.com")))
