;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "playonline" "0.1.2"
  "Play code with online playgrounds."
  '((emacs   "24.4")
    (json    "1.2")
    (dash    "2.1")
    (request "0.2"))
  :url "https://github.com/twlz0ne/playonline.el"
  :commit "1a784f91cba686c65daa32d146bbe5f959016bf8"
  :revdesc "1a784f91cba6"
  :keywords '("tools")
  :authors '(("Gong Qijian" . "gongqijian@gmail.com"))
  :maintainers '(("Gong Qijian" . "gongqijian@gmail.com")))
