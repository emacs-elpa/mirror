;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scroll-on-jump" "0.3"
  "Scroll when jumping to a new point."
  '((emacs "26.2"))
  :url "https://codeberg.org/ideasman42/emacs-scroll-on-jump"
  :commit "a9b785d3a3dfd94800d7541353a8a6c7961e209a"
  :revdesc "a9b785d3a3df"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
