;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "professional-theme" "20140914.1533"
  "Emacs port of Vim's professional theme."
  ()
  :url "https://github.com/juanjux/professional-theme"
  :commit "008710002adc229cdd46b61a4f198dde6770ee68"
  :revdesc "008710002adc"
  :keywords '("theme" "light" "professional")
  :authors '(("Juanjo Alvarez" . "juanjo@juanjoalvarez.net"))
  :maintainers '(("Juanjo Alvarez" . "juanjo@juanjoalvarez.net")))
