;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-php-noverify" "0.1.0"
  "Flycheck checker for PHP Noverify linter."
  '((flycheck "0.22"))
  :url "https://github.com/Junker/flycheck-php-noverify0"
  :commit "b7f91cf20c1888cc1b584488871cf7d7769fcbf8"
  :revdesc "b7f91cf20c18")
