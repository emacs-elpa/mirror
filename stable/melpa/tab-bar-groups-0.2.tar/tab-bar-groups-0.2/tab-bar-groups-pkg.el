;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tab-bar-groups" "0.2"
  "Tab groups for the tab bar."
  '((emacs "27.1")
    (s     "1.12.0"))
  :url "https://github.com/fritzgrabo/tab-bar-groups"
  :commit "6d5925db48168ef947fcecfcadb517b1de384b2c"
  :revdesc "6d5925db4816"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "me@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "me@fritzgrabo.com")))
