;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-video-thumbnail" "0.1.0"
  "Display video thumbnails from dired."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/dired-video-thumbnail"
  :commit "316c668e93e07176201f493d85dcdb7fcf8d682e"
  :revdesc "316c668e93e0"
  :keywords '("multimedia" "files" "dired"))
