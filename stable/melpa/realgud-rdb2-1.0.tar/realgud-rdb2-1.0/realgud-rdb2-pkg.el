;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-rdb2" "1.0"
  "A modular front-end for interacting with external debuggers."
  '((realgud "0"))
  :url "https://github.com/ko1/debugger2"
  :commit "9aaa5e6f33accf966416a83f3dbe5b334c73f79b"
  :revdesc "9aaa5e6f33ac")
