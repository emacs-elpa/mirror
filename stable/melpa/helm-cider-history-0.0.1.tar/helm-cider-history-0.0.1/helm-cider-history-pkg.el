;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-cider-history" "0.0.1"
  "Show cider input history in helm."
  '((helm  "1.4.0")
    (cider "0.9.0"))
  :url "https://github.com/Kungi/helm-cider-history"
  :commit "0fe0502b2224c739656268ba1345ba30026c4e2b"
  :revdesc "0fe0502b2224"
  :keywords '("convenience")
  :authors '(("Andreas Klein" . "git@kungi.org"))
  :maintainers '(("Andreas Klein" . "git@kungi.org")))
