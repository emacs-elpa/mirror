;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recursive-narrow" "20140801.1400"
  "Narrow-to-region that operates recursively."
  ()
  :url "https://github.com/nflath/recursive-narrow"
  :commit "ad7d8b2be578dd6a0a0c91313171c0043827c1bd"
  :revdesc "ad7d8b2be578"
  :authors '(("Nathaniel Flath" . "flat0103@gmail.com"))
  :maintainers '(("Nathaniel Flath" . "flat0103@gmail.com")))
