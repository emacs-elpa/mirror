;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bury-successful-compilation" "0.1.2"
  "Bury the *compilation* buffer after successful compilation."
  ()
  :url "https://github.com/EricCrosson/bury-successful-compilation"
  :commit "064817b44a431476305099301311def0a2d9d543"
  :revdesc "064817b44a43"
  :keywords '("compilation")
  :authors '(("Eric Crosson" . "esc@ericcrosson.com"))
  :maintainers '(("Eric Crosson" . "esc@ericcrosson.com")))
