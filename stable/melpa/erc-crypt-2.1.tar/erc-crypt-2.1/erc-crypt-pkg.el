;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-crypt" "2.1"
  "Symmetric Encryption for ERC."
  '((cl-lib "0.5"))
  :url "https://github.com/atomontage/erc-crypt"
  :commit "6d158b39ea2833b753858153eb110da9b8a40fc4"
  :revdesc "6d158b39ea28"
  :keywords '("comm")
  :authors '(("xristos" . "xristos@sdf.org"))
  :maintainers '(("xristos" . "xristos@sdf.org")))
