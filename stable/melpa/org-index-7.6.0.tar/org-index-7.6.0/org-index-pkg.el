;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-index" "7.6.0"
  "Ranked and incremental search among selected org-headlines."
  '((org   "9.3")
    (dash  "2.12")
    (s     "1.12")
    (emacs "26.3"))
  :url "https://github.com/marcIhm/org-index"
  :commit "ccef23d8318bcccd1638f5b85176475c85275f83"
  :revdesc "7.6.0-0-gccef23d8318b"
  :authors '(("Marc Ihm" . "marc@ihm.name"))
  :maintainers '(("Marc Ihm" . "marc@ihm.name")))
