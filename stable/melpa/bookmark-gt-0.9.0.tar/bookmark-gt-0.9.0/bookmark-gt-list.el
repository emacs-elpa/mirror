;;; bookmark-gt-list.el --- Bookmarks-gt list buffer  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Daniel M. German <dmg@turingmachine.org>

;; Author: Daniel M. German <dmg@turingmachine.org>
;; Maintainer: Daniel M. German <dmg@turingmachine.org>
;; Assisted-by: Claude:claude-opus-4-7
;; Keywords: convenience, matching, hypermedia
;; URL: https://github.com/dmgerman/bookmark-gt

;; SPDX-License-Identifier: GPL-3.0-or-later
;;
;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; The `*Bookmarks-gt List*' buffer, implemented on top of
;; `tabulated-list-mode'.  Columns: Mark, Name, Type, Tags,
;; Location.  Sort headers, mark / flag-for-deletion / execute,
;; jump-same-window / jump-other-window, filter (`/'), edit-in-
;; place (rename / edit tags / edit annotation) all use built-in
;; tabulated-list machinery — no advice on any other package.
;;
;; Filter registry (`bookmark-gt-filter-alist') and sort registry
;; (`bookmark-gt-sort-alist') are plain alists; see their defvar
;; docstrings for the entry shape.

;;; Code:

(require 'bookmark)
(require 'seq)
(require 'tabulated-list)
(require 'bookmark-gt-core)
(require 'bookmark-gt-tags)
(require 'bookmark-gt-handlers)

;; Optional-mode ephemeral refreshers, called from
;; `bookmark-gt-list--revert' (`g') when their mode is on.
(declare-function bookmark-gt-browser-tabs-refresh
                  "bookmark-gt-browser-tabs")
(declare-function bookmark-gt-auto-update-tick
                  "bookmark-gt-auto-update")
;; Bulk setter behind `bookmark-gt-list-toggle-auto-update', which
;; checks `fboundp' before calling.
(declare-function bookmark-gt-auto-update-set
                  "bookmark-gt-auto-update" (record flag &optional no-notify))

;;;; Customization

(defcustom bookmark-gt-list-name-width 32
  "Width of the Name column in the bookmark list buffer."
  :type 'integer
  :group 'bookmark-gt)

(defcustom bookmark-gt-list-type-width 12
  "Width of the Type column in the bookmark list buffer."
  :type 'integer
  :group 'bookmark-gt)

(defcustom bookmark-gt-list-tags-width 24
  "Width of the Tags column in the bookmark list buffer."
  :type 'integer
  :group 'bookmark-gt)

(defcustom bookmark-gt-list-group-width 6
  "Width of the Group column in the bookmark list buffer."
  :type 'integer
  :group 'bookmark-gt)

(defcustom bookmark-gt-list-buffer-name "*Bookmarks-gt List*"
  "Name of the bookmark list buffer."
  :type 'string
  :group 'bookmark-gt)

(defcustom bookmark-gt-list-deletion-mark ?D
  "Character shown for bookmarks queued for deletion."
  :type 'character
  :group 'bookmark-gt)

(defcustom bookmark-gt-list-default-show-temp t
  "Default value of `bookmark-gt-list--show-temp' for new list buffers.
When nil, temporary bookmarks are omitted from the list
display (they remain in `bookmark-alist').  Toggle per-buffer
with `bookmark-gt-list-show-temp'."
  :type 'boolean
  :group 'bookmark-gt)

(defcustom bookmark-gt-list-selection-mark ?*
  "Character used to select a bookmark for bulk actions."
  :type 'character
  :group 'bookmark-gt)

;;;; State persistence

(defcustom bookmark-gt-list-persist-state nil
  "Non-nil to persist list-buffer view state across Emacs sessions.
When enabled, the sort column, `show-temp' toggle, and active
filters are written to `bookmark-gt-list-state-file' whenever
they change and on `kill-emacs-hook', and re-read the next time
`bookmark-gt-list-mode' is entered.  Selection marks and point
are not persisted.

When nil (the default) the state file is neither read nor
written.  In-session state — the sort key, filters, and
`show-temp' toggle set in a live buffer — is still preserved
across repeated invocations of `bookmark-gt-list' regardless
of this setting."
  :type 'boolean
  :group 'bookmark-gt)

(defcustom bookmark-gt-list-state-file
  (locate-user-emacs-file "bookmark-gt-list-state")
  "File that persists list-buffer view state across Emacs sessions.
Only consulted when `bookmark-gt-list-persist-state' is
non-nil.  Contains a single alist with keys `sort-key',
`show-temp', and `filters'."
  :type 'file
  :group 'bookmark-gt)

(defvar bookmark-gt-list--state nil
  "In-memory copy of the persisted list-buffer view state.
Alist with keys `sort-key' (cons of column-name and reversep),
`show-temp' (boolean), and `filters' (alist of (FILTER-KEY .
ARG)).  Loaded from `bookmark-gt-list-state-file' on first
`bookmark-gt-list-mode' entry when
`bookmark-gt-list-persist-state' is non-nil.")

(defvar bookmark-gt-list--state-loaded nil
  "Non-nil once the state file has been read this session.
Prevents re-reading on subsequent mode entries.  Reset by
disabling and re-enabling `bookmark-gt-mode'.")

;;;; Filter registry

(defvar bookmark-gt-filter-alist nil
  "Filter registry for the bookmark list buffer.
Each entry is (KEY :name STRING :reader FN :predicate FN :doc STRING).
The :reader takes no arguments and returns whatever argument
:predicate needs; :predicate is called as (RECORD ARG) and
returns non-nil to include RECORD.")

;;;; Sort registry

(defvar bookmark-gt-sort-alist nil
  "Sort registry.
Each entry is (KEY :name STRING :comparator FN :doc STRING).
:comparator takes two records and returns non-nil when the
first should sort before the second.")

;;;; Buffer-local state
;;
;; Every variable below is a process-scoped resource: bounded to
;; the buffer's lifetime and cleared on buffer kill.  No
;; per-bookmark fact is stored here — those live on the record.

(defvar-local bookmark-gt-list--filters nil
  "Alist of active filters in this buffer ((KEY . ARG) ...).")

(defvar-local bookmark-gt-list--show-temp
    bookmark-gt-list-default-show-temp
  "When nil, temporary bookmarks are omitted from this list's display.
`bookmark-alist' is unchanged; only the rendered entries are
filtered.  Toggled by `bookmark-gt-list-show-temp'.")

(defvar-local bookmark-gt-list--marks nil
  "Hash table `bookmark-gt-id' → mark character for this buffer.
Values are the mark char (`bookmark-gt-list-selection-mark' or
`bookmark-gt-list-deletion-mark').  A missing key is unmarked.

Keyed by id rather than by record: this hash is the only piece
of list state that outlives a render.  The `tabulated-list' ids
are rebuilt from `bookmark-alist' every time, so they are never
stale, but a record cons kept here would be replaced whenever
the bookmark file is reloaded — which happens without asking
when it changed on disk — and every mark would be lost.

Interactive mark commands mutate the hash and patch buffer
character 0 directly for speed.")

(defun bookmark-gt-list--mark-key (record)
  "Return the key RECORD is marked under, or nil when it has no id.
Every record has an id by the time the buffer renders:
`bookmark-gt-list--entries' runs `bookmark-gt-ensure-ids' first."
  (bookmark-gt-id-of record))

;;;; Rendering

(defun bookmark-gt-list--render-tags (record)
  "Return a display string for RECORD's tags, truncated to fit."
  (let* ((tags (bookmark-gt-tags-of record))
         (joined (mapconcat #'identity tags ", ")))
    (truncate-string-to-width joined bookmark-gt-list-tags-width nil nil t)))

(defun bookmark-gt-list--render-location (record)
  "Return a display string for RECORD's location.
Reads via `bookmark-gt-filename-of' (which treats the bookmark+
placeholder as absent) and `bookmark-gt-url-of' (which accepts
both `url' and `location' props)."
  (or (bookmark-gt-filename-of record)
      (bookmark-gt-url-of record)
      ""))

(defun bookmark-gt-list--auto-update-glyph (record)
  "Return \"^\" when RECORD carries the `auto-update' property, else \" \"."
  (if (bookmark-prop-get record 'auto-update) "^" " "))

(defun bookmark-gt-list--temp-glyph (record)
  "Return \"t\" when RECORD is a temporary bookmark, else \" \".
The check reads `bookmark-gt-temp-key' directly so the column
lights up for records created by either bookmark-gt or the old
bookmark+ package (both use the `bmkp-temp' alist key)."
  (if (bookmark-prop-get record bookmark-gt-temp-key) "t" " "))

(defun bookmark-gt-list--missing-file-p (record)
  "Return non-nil when RECORD has a `filename' but no file exists there.
Remote (Tramp) filenames are skipped — probing them would
require a network round-trip, too slow for a list render."
  (let ((f (bookmark-gt-filename-of record)))
    (and f
         (not (file-remote-p f))
         (not (file-exists-p f)))))

(defun bookmark-gt-list--name-faces (record)
  "Return the face (or `face-list') to apply to RECORD's Name column.
Composes the type face from the handler registry with
`bookmark-gt-face-missing-file' when the record's file is
absent.  Temp records get the row-wide tint via
`bookmark-gt-list--tint-row-after-print' instead."
  (let ((type-face (bookmark-gt-handler-face record))
        (missing-p (bookmark-gt-list--missing-file-p record)))
    (cond
     ((and type-face missing-p) (list 'bookmark-gt-face-missing-file
                                      type-face))
     (missing-p                 'bookmark-gt-face-missing-file)
     (type-face                 type-face)
     (t                         nil))))

(defun bookmark-gt-list--tint-row-after-print (id _cols)
  "Tint the just-printed row with `bookmark-gt-face-temp' when ID is temp.
Attached as `:after' advice on `tabulated-list-print-entry' so
the tint spans the whole row (data cells and inter-column
padding).  Gated by `derived-mode-p' so it does nothing in
other tabulated-list buffers."
  (when (and (derived-mode-p 'bookmark-gt-list-mode)
             id
             (bookmark-gt-temp-p id))
    (let ((inhibit-read-only t))
      (save-excursion
        (forward-line -1)
        (add-face-text-property (line-beginning-position)
                                (line-end-position)
                                'bookmark-gt-face-temp
                                t)))))

(advice-add 'tabulated-list-print-entry :after
            #'bookmark-gt-list--tint-row-after-print)

(defun bookmark-gt-list--mark-string (record)
  "Return RECORD's mark as a 1-char string.
Looks up the buffer-local hash `bookmark-gt-list--marks'; when
no mark is stored, returns a single space."
  (let ((ch (and bookmark-gt-list--marks
                 (gethash (bookmark-gt-list--mark-key record) bookmark-gt-list--marks))))
    (if ch (char-to-string ch) " ")))

(defun bookmark-gt-list--entry-vector (record)
  "Return the tabulated-list vector for RECORD.
Reads the mark cell from `bookmark-gt-list--marks' so marks
survive re-render as long as the record cons is unchanged."
  (let* ((raw-name (bookmark-gt-display-name-of record))
         (name (truncate-string-to-width raw-name
                                         bookmark-gt-list-name-width
                                         nil nil t))
         (raw-type (bookmark-gt-handler-name record))
         (type (truncate-string-to-width raw-type
                                         bookmark-gt-list-type-width
                                         nil nil t))
         (raw-group (bookmark-gt-group-name
                     (bookmark-gt-handler-group record)))
         (group (propertize
                 (truncate-string-to-width (or raw-group "")
                                           bookmark-gt-list-group-width
                                           nil nil t)
                 'face 'bookmark-gt-face-group))
         (faces (bookmark-gt-list--name-faces record)))
    (vector (bookmark-gt-list--mark-string record)
            (bookmark-gt-list--auto-update-glyph record)
            (bookmark-gt-list--temp-glyph record)
            (if faces (propertize name 'face faces) name)
            type
            group
            (bookmark-gt-list--render-tags record)
            (bookmark-gt-list--render-location record))))

(defun bookmark-gt-list--apply-filters (records)
  "Return RECORDS narrowed by every filter in `bookmark-gt-list--filters'."
  (seq-filter
   (lambda (record)
     (seq-every-p
      (lambda (filter)
        (let* ((entry (alist-get (car filter) bookmark-gt-filter-alist))
               (predicate (plist-get entry :predicate)))
          (or (null predicate)
              (funcall predicate record (cdr filter)))))
      bookmark-gt-list--filters))
   records))

(defun bookmark-gt-list--entries ()
  "Compute `tabulated-list-entries' for the current buffer.
Applies `bookmark-gt-list--filters', then omits temp records
from the display when `bookmark-gt-list--show-temp' is nil.
The underlying `bookmark-alist' is not modified.  The record
itself is used as the tabulated-list ID so mutations survive
sorting."
  (bookmark-gt-ensure-ids)
  (let ((records (bookmark-gt-list--apply-filters bookmark-alist)))
    (unless bookmark-gt-list--show-temp
      (setq records (seq-remove #'bookmark-gt-temp-p records)))
    ;; One index for the whole render: each row asks for its
    ;; display name, and answering that by scanning the alist per
    ;; row would be quadratic in the number of bookmarks.
    (bookmark-gt-with-name-index
      (mapcar (lambda (record)
                (list record (bookmark-gt-list--entry-vector record)))
              records))))

;;;; State-file persistence

(defun bookmark-gt-list--state-load ()
  "Read `bookmark-gt-list-state-file' into `bookmark-gt-list--state'.
Sets `bookmark-gt-list--state-loaded' to t whether or not the
file existed.  A missing or unreadable file, or a read error,
leaves the state alist nil (defaults apply)."
  (setq bookmark-gt-list--state-loaded t)
  (when (and bookmark-gt-list-persist-state
             bookmark-gt-list-state-file
             (file-readable-p bookmark-gt-list-state-file))
    (with-demoted-errors "bookmark-gt-list: state read failed: %S"
      (with-temp-buffer
        (insert-file-contents bookmark-gt-list-state-file)
        (goto-char (point-min))
        (let ((v (read (current-buffer))))
          (when (listp v)
            (setq bookmark-gt-list--state v)))))))

(defun bookmark-gt-list--state-capture ()
  "Return an alist of the current buffer's persisted view state."
  (list (cons 'sort-key  tabulated-list-sort-key)
        (cons 'show-temp bookmark-gt-list--show-temp)
        (cons 'filters   bookmark-gt-list--filters)))

(defun bookmark-gt-list--state-apply ()
  "Apply `bookmark-gt-list--state' to the current buffer.
No-op when the state alist is empty."
  (when-let* ((v (alist-get 'sort-key bookmark-gt-list--state)))
    (setq tabulated-list-sort-key v))
  (when (assq 'show-temp bookmark-gt-list--state)
    (setq bookmark-gt-list--show-temp
          (alist-get 'show-temp bookmark-gt-list--state)))
  (setq bookmark-gt-list--filters
        (alist-get 'filters bookmark-gt-list--state)))

(defun bookmark-gt-list-save-state ()
  "Write the current list-buffer view state to `bookmark-gt-list-state-file'.
Reads state from the live `*Bookmarks-gt List*' buffer if one
exists; otherwise from `bookmark-gt-list--state'.  No-op when
`bookmark-gt-list-persist-state' is nil."
  (interactive)
  (when (and bookmark-gt-list-persist-state
             bookmark-gt-list-state-file)
    (let* ((buf (get-buffer bookmark-gt-list-buffer-name))
           (state (if (buffer-live-p buf)
                      (with-current-buffer buf
                        (bookmark-gt-list--state-capture))
                    bookmark-gt-list--state)))
      (with-demoted-errors "bookmark-gt-list: state write failed: %S"
        (with-temp-file bookmark-gt-list-state-file
          (let ((print-level nil)
                (print-length nil))
            (insert ";;; bookmark-gt list-buffer state  -*- lexical-binding: t; -*-\n")
            (prin1 state (current-buffer))
            (insert "\n")))))))

(defun bookmark-gt-list--state-changed ()
  "Recapture the buffer's view state and persist it.
Called from every command that changes sort, filters, or the
`show-temp' toggle.  Persistence itself is gated by
`bookmark-gt-list-persist-state'."
  (setq bookmark-gt-list--state (bookmark-gt-list--state-capture))
  (bookmark-gt-list-save-state))

(defun bookmark-gt-list--tabulated-sort-observer (&rest _)
  "Persist state after `tabulated-list-sort' reorders a column.
Attached as `:after' advice by `bookmark-gt-mode'.  A no-op in
buffers not derived from `bookmark-gt-list-mode'."
  (when (derived-mode-p 'bookmark-gt-list-mode)
    (bookmark-gt-list--state-changed)))

;;;; Mode + keymap

(defvar-keymap bookmark-gt-list-mode-map
  :doc "Keymap for `bookmark-gt-list-mode'."
  :parent tabulated-list-mode-map
  "RET"   #'bookmark-gt-list-jump
  "o"     #'bookmark-gt-list-jump-other-window
  "C-o"   #'bookmark-gt-list-jump-other-window
  "TAB"   #'bookmark-gt-list-preview
  "^"     #'bookmark-gt-list-toggle-auto-update
  "T"     #'bookmark-gt-list-toggle-temp
  "H"     #'bookmark-gt-list-show-temp
  "i"   #'bookmark-gt-list-describe-record
  "s"   #'bookmark-gt-list-sort-cycle
  "m"   #'bookmark-gt-list-mark
  "u"   #'bookmark-gt-list-unmark
  "U"   #'bookmark-gt-list-unmark-all
  "d"   #'bookmark-gt-list-flag-for-deletion
  "x"   #'bookmark-gt-list-execute-deletions
  "r"   #'bookmark-gt-list-rename
  "R"   #'bookmark-gt-list-relocate
  "t e" #'bookmark-gt-list-edit-tags
  "t a" #'bookmark-gt-list-add-tags
  "t r" #'bookmark-gt-list-remove-tags
  "a"   #'bookmark-gt-list-edit-annotation
  "/"   #'bookmark-gt-list-filter-by
  "V"   #'bookmark-gt-list-reset-view
  "g"     #'revert-buffer
  "C-x C-s" #'bookmark-save
  "q"     #'quit-window)

(define-derived-mode bookmark-gt-list-mode tabulated-list-mode "Bookmarks-gt"
  "Major mode for the bookmark-gt list buffer.

Each row shows one bookmark record from `bookmark-alist',
narrowed by any active filter and by the show-temp toggle.

Commands are grouped by scope:

  Row-scoped commands act on the record on the current line.
  Selection-scoped commands act on every row marked with
  `bookmark-gt-list-selection-mark', falling back to the record
  on the current line when no row is marked.
  Buffer-scoped commands act on the whole list or on the set
  of rows flagged for deletion.

Marks are bounded by what the buffer displays.  No command
reaches a row hidden by a filter or by
`\\[bookmark-gt-list-show-temp]', and hidden rows keep their
marks for when the view widens.

Marker columns (three single-character indicators before Name):

  \" \"   Selection / deletion mark on this row.  See the
        row-scoped mark commands below.

  \"^\"   Auto-update indicator, lit when the record carries the
        `auto-update' alist key.  Under
        `bookmark-gt-auto-update-mode' the record's position is
        refreshed to the visiting buffer's point on every idle
        tick.

  \"t\"   Temporary indicator, lit when the record carries the
        `bmkp-temp' alist key.  Temporary records are excluded
        from `bookmark-save' output.

Row-scoped commands (act on the bookmark at point):
  \\[bookmark-gt-list-jump] jump (same window)
  \\[bookmark-gt-list-jump-other-window] jump (other window)
  \\[bookmark-gt-list-preview] preview in another window
  \\[bookmark-gt-list-rename] rename
  \\[bookmark-gt-list-relocate] relocate (change filename or URL)
  \\[bookmark-gt-list-edit-annotation] edit annotation
  \\[bookmark-gt-list-mark] mark for a bulk action
  \\[bookmark-gt-list-unmark] clear the mark
  \\[bookmark-gt-list-flag-for-deletion] flag for deletion
  \\[bookmark-gt-list-describe-record] describe (pretty-print raw record)

Selection-scoped commands (act on every marked row, or on the
bookmark at point when no row is marked):
  \\[bookmark-gt-list-edit-tags] edit tags (editable CSV; add and remove)
  \\[bookmark-gt-list-add-tags] add tags (sequential reader; append only)
  \\[bookmark-gt-list-remove-tags] remove tags (completion over the tags present)
  \\[bookmark-gt-list-toggle-auto-update] toggle `auto-update'
  \\[bookmark-gt-list-toggle-temp] toggle temp

A toggle over several marked rows sets all of them to the same
value: on unless every marked row is already on, in which case
all are turned off.

A selection is bounded by what the buffer displays: rows hidden
by a filter or by `\\[bookmark-gt-list-show-temp]' are not acted
on and keep their marks.  When the filter hides the whole
selection the command fails rather than falling back to the
bookmark at point.

Completing any of these commands deselects the rows it acted
on, so the next one starts from a clean slate.  Ending a tag
reader without entering anything changes nothing and leaves the
selection in place.

Buffer-scoped commands:
  \\[bookmark-gt-list-execute-deletions] delete the flagged rows the view shows
  \\[bookmark-gt-list-unmark-all] clear every mark
  \\[bookmark-gt-list-filter-by] filter (by-type / by-tag / by-name-regexp / unfilter)
  \\[bookmark-gt-list-show-temp] toggle display of temporary bookmarks
  \\[bookmark-gt-list-sort-cycle] cycle the sort column
  \\[bookmark-gt-list-reset-view] reset sort, filters, and `show-temp' to defaults
  \\[revert-buffer] revert (refresh, then redraw)
  \\[bookmark-save] save the bookmark file
  \\[quit-window] quit

Sorting: click a column header, or press `S' for column-at-point sort.

\\{bookmark-gt-list-mode-map}"
  (setq tabulated-list-format
        `[("*"  1 bookmark-gt-list--sort-by-mark)
          ("^"  1 ,(bookmark-gt-list--sort-by-record-flag 'auto-update))
          ("t"  1 ,(bookmark-gt-list--sort-by-record-flag
                    bookmark-gt-temp-key))
          ("Name"     ,bookmark-gt-list-name-width t)
          ("Type"     ,bookmark-gt-list-type-width t)
          ("Group"    ,bookmark-gt-list-group-width
                      bookmark-gt-list--sort-by-group)
          ("Tags"     ,bookmark-gt-list-tags-width t)
          ("Location" 0 t)])
  ;; No padding: column 0 IS the mark column now.  The mark char
  ;; lands at buffer position 0 of each row and aligns exactly with
  ;; the "*" header.
  (setq tabulated-list-padding 0)
  (setq bookmark-gt-list--marks (make-hash-table :test #'eq))
  (setq tabulated-list-sort-key '("Name" . nil))
  (setq tabulated-list-entries #'bookmark-gt-list--entries)
  (setq-local revert-buffer-function #'bookmark-gt-list--revert)
  (setq-local bookmark-make-record-function
              #'bookmark-gt-list--make-record)
  (unless bookmark-gt-list--state-loaded
    (bookmark-gt-list--state-load))
  (bookmark-gt-list--state-apply)
  (tabulated-list-init-header))

;;;; Refresh

(defun bookmark-gt-list--name-at-point ()
  "Return the visible name of the record at point, or nil."
  (when-let* ((rec (tabulated-list-get-id)))
    (bookmark-gt-display-name-of rec)))

(defun bookmark-gt-list--goto-name (name)
  "Move point to the first row whose visible name equals NAME.
No-op when NAME is nil; falls back to `point-min' when no row
matches."
  (when name
    (goto-char (point-min))
    (let ((found nil))
      (while (and (not (eobp)) (not found))
        (let ((rec (tabulated-list-get-id)))
          (if (and rec
                   (equal (bookmark-gt-display-name-of rec) name))
              (setq found t)
            (forward-line 1))))
      (unless found (goto-char (point-min))))))

(defun bookmark-gt-list--redraw-preserving-point ()
  "Redraw and keep point on the same row.
Falls back to name-lookup when the record cons has been
replaced, and restores the row's visual offset from
`window-start'."
  (let* ((win (get-buffer-window (current-buffer)))
         (visual-line (and win
                           (count-lines (window-start win)
                                        (line-beginning-position))))
         (old-name (bookmark-gt-list--name-at-point)))
    (tabulated-list-print t)
    (unless (tabulated-list-get-id)
      (bookmark-gt-list--goto-name old-name))
    (when (and win visual-line
               (window-live-p win))
      (with-selected-window win
        (recenter visual-line)))))

;;;###autoload
(defun bookmark-gt-list-refresh (&rest _)
  "Redraw every live `bookmark-gt-list-mode' buffer.
Callable directly, and used as the observer on
`bookmark-gt-record-changed-hook' (extra hook arguments are ignored)."
  (dolist (buf (buffer-list))
    (with-current-buffer buf
      (when (derived-mode-p 'bookmark-gt-list-mode)
        (let ((inhibit-read-only t))
          (bookmark-gt-list--redraw-preserving-point))))))

;;;; Interactive entry point

;;;###autoload
(defun bookmark-gt-list ()
  "Display the bookmark-gt list buffer.
When the buffer already exists and is in `bookmark-gt-list-mode',
reuse it: sort key, filters, `show-temp' toggle, and marks are
preserved and the buffer is redrawn from the current
`bookmark-alist'.  When creating the buffer, initial view state
comes from `bookmark-gt-list-state-file' when
`bookmark-gt-list-persist-state' is enabled, otherwise from the
mode defaults."
  (interactive)
  (bookmark-maybe-load-default-file)
  (bookmark-gt-enforce-same-name-policy)
  (bookmark-gt-list--refresh-ephemeral)
  (let ((buf (get-buffer-create bookmark-gt-list-buffer-name)))
    (with-current-buffer buf
      (unless (derived-mode-p 'bookmark-gt-list-mode)
        (bookmark-gt-list-mode))
      (tabulated-list-print t))
    (pop-to-buffer-same-window buf)))

(defun bookmark-gt-list--refresh-ephemeral ()
  "Rebuild the ephemeral sources whose opt-in modes are enabled.
Browser tabs and auto-update positions describe state outside
`bookmark-alist', so they are rebuilt when the list is about to
be read — both when it is opened and when it is reverted.

Opening matters as much as reverting: nothing else populates tab
records between one read and the next, so a list opened without
this shows whatever the last refresh left, or nothing at all in
a session where no jump has happened yet."
  (when (bound-and-true-p bookmark-gt-browser-tabs-mode)
    (bookmark-gt-browser-tabs-refresh))
  (when (bound-and-true-p bookmark-gt-auto-update-mode)
    (bookmark-gt-auto-update-tick)))

(defun bookmark-gt-list--revert (&rest _args)
  "Revert function for the bookmark-gt list buffer.
Refreshes ephemeral sources that are currently enabled, then
redraws."
  (bookmark-gt-enforce-same-name-policy)
  (bookmark-gt-list--refresh-ephemeral)
  (bookmark-gt-list--redraw-preserving-point))

;;;; Cursor → record lookup

(defun bookmark-gt-list--record-at-point ()
  "Return the bookmark record on the current line, or nil."
  (tabulated-list-get-id))

(defun bookmark-gt-list--require-record ()
  "Return the record on the current line, signalling if none."
  (or (bookmark-gt-list--record-at-point)
      (user-error "No bookmark on this line")))

(defun bookmark-gt-list--visible-marked (char)
  "Return the displayed records whose mark is CHAR.
Walks the rendered rows, so the result is ordered as the rows
appear and covers only what the buffer currently displays: a
marked record hidden by an active filter or by the `show-temp'
toggle is not returned, and neither is one deleted since the
mark was set.  Its mark is left in the hash, so lifting the
filter brings the record back still marked.

`bookmark-gt-list--collect-marked' can provide neither
property — it walks `bookmark-gt-list--marks', whose hash order
is arbitrary and which knows nothing about what is displayed.
It remains the right call when the question is what carries a
mark at all, rather than what the user can currently see."
  (save-excursion
    (goto-char (point-min))
    (let (records)
      (while (not (eobp))
        (let ((record (tabulated-list-get-id)))
          (when (and record
                     (eq (gethash (bookmark-gt-list--mark-key record)
                                  bookmark-gt-list--marks)
                         char))
            (push record records)))
        (forward-line 1))
      (nreverse records))))

(defun bookmark-gt-list--hidden-marked-count (char)
  "Return how many records marked CHAR the current view hides."
  (- (length (bookmark-gt-list--collect-marked char))
     (length (bookmark-gt-list--visible-marked char))))

(defun bookmark-gt-list--marked-records ()
  "Return the displayed records carrying the selection mark."
  (bookmark-gt-list--visible-marked bookmark-gt-list-selection-mark))

(defun bookmark-gt-list--records-to-act-on ()
  "Return the records a selection-scoped command should act on.
The marked rows when any displayed row carries
`bookmark-gt-list-selection-mark', otherwise a one-element list
holding the record at point.

Bounded by what the buffer displays: a command acts on the
visible marked rows and never reaches a record the current
filter hides.

Signals when a selection exists but the current filter hides
all of it.  Acting on the record at point there would apply the
command to a bookmark the user did not select, and reporting
success over an empty selection would suggest the marked
bookmarks had been dealt with; both are worse than refusing.
Also signals when nothing is marked and no row is at point."
  (or (bookmark-gt-list--marked-records)
      (let ((hidden (bookmark-gt-list--hidden-marked-count
                     bookmark-gt-list-selection-mark)))
        (when (> hidden 0)
          (user-error
           "No selected bookmarks in this view (%d hidden by the filter)"
           hidden))
        (list (bookmark-gt-list--require-record)))))

(defun bookmark-gt-list--clear-selection (records)
  "Remove the selection mark from RECORDS in this buffer.
Only RECORDS are deselected, never the whole hash: a record
marked while the list was unfiltered but hidden by the filter
in force now was not acted on, so its mark stays for when the
filter is lifted.  Deletion flags are kept too — they are
consumed by `bookmark-gt-list-execute-deletions', not by the
selection-scoped commands.

Does not redraw; the caller's `bookmark-gt--after-mutation'
repaints the mark column from the hash."
  (dolist (record records)
    (when (eq (gethash (bookmark-gt-list--mark-key record) bookmark-gt-list--marks)
              bookmark-gt-list-selection-mark)
      (remhash (bookmark-gt-list--mark-key record) bookmark-gt-list--marks))))

(defun bookmark-gt-list--finish (records &optional message)
  "Complete a selection-scoped command over RECORDS.
Deselects RECORDS so the next command does not silently inherit
them, notifies observers once for the whole batch, and reports
MESSAGE when several records were acted on — for a single
record the underlying mutator already reports."
  (bookmark-gt-list--clear-selection records)
  (bookmark-gt--after-mutation (car records))
  (when (and message (cdr records))
    (message "%s" message)))

;;;; Marks
;;
;; Selection marks live in `bookmark-gt-list--marks' (buffer-local
;; hash: id → char).  Interactive commands mutate the hash and
;; patch character 0 of the current buffer line directly for speed;
;; re-renders (sort, revert) read the hash to populate cell 0 of
;; the entry vector, so marks survive them.

(defun bookmark-gt-list--set-mark-at-point (char)
  "Store CHAR as the mark for the record at point.
CHAR = ?\\s clears the mark (removes the hash entry).  The
buffer's first character on the current line is patched
directly so the display updates without a full re-render.

The replacement preserves the `tabulated-list-id' and
`tabulated-list-entry' text properties on char 0 — without
this, `tabulated-list-get-id' on a marked row would return
nil."
  (let* ((record (tabulated-list-get-id))
         (id (and record (bookmark-gt-list--mark-key record))))
    (when id
      (if (eq char ?\s)
          (remhash id bookmark-gt-list--marks)
        (puthash id char bookmark-gt-list--marks))
      (save-excursion
        (beginning-of-line)
        (let ((inhibit-read-only t)
              (props (text-properties-at (point))))
          (delete-char 1)
          (insert (apply #'propertize (string char) props)))))))

(defun bookmark-gt-list--mark-forward (char arg)
  "Set CHAR as the mark for the next ARG rows starting here.
Moves point forward one line per row marked.  Negative ARG
walks backward."
  (let* ((n (abs (or arg 1)))
         (step (if (and arg (< arg 0)) -1 1)))
    (dotimes (_ n)
      (when (tabulated-list-get-id)
        (bookmark-gt-list--set-mark-at-point char))
      (forward-line step))))

(defun bookmark-gt-list-mark (&optional arg)
  "Mark the current bookmark and move down ARG lines (default 1)."
  (interactive "p" bookmark-gt-list-mode)
  (bookmark-gt-list--mark-forward bookmark-gt-list-selection-mark
                                  (or arg 1)))

(defun bookmark-gt-list-flag-for-deletion (&optional arg)
  "Flag the current bookmark for deletion and move down ARG lines."
  (interactive "p" bookmark-gt-list-mode)
  (bookmark-gt-list--mark-forward bookmark-gt-list-deletion-mark
                                  (or arg 1)))

(defun bookmark-gt-list-unmark (&optional arg)
  "Remove any mark from the current bookmark and move down ARG lines."
  (interactive "p" bookmark-gt-list-mode)
  (bookmark-gt-list--mark-forward ?\s (or arg 1)))

(defun bookmark-gt-list-unmark-all ()
  "Remove every mark from the buffer."
  (interactive nil bookmark-gt-list-mode)
  (clrhash bookmark-gt-list--marks)
  (tabulated-list-print t))

(defun bookmark-gt-list--collect-marked (char)
  "Return records whose stored mark equals CHAR.
Skips hash entries whose id is no longer in `bookmark-alist'
\(stale from a since-deleted record)."
  (let (records)
    (maphash (lambda (id mark)
               (when (eq mark char)
                 (when-let* ((record (seq-find
                                      (lambda (r)
                                        (eq (bookmark-gt-id-of r) id))
                                      bookmark-alist)))
                   (push record records))))
             bookmark-gt-list--marks)
    records))

(defun bookmark-gt-list-execute-deletions ()
  "Delete the displayed bookmarks flagged for deletion.
Bounded by what the buffer shows, like the selection-scoped
commands: a row flagged with `bookmark-gt-list-deletion-mark'
and then hidden by a filter or by `show-temp' is not deleted and
keeps its flag.  Deleting a record the user cannot see, from a
count they cannot check against the rows in front of them, is
not recoverable.

Signals when flags exist but the view hides all of them, rather
than reporting that there is nothing to delete."
  (interactive nil bookmark-gt-list-mode)
  (let ((flagged (bookmark-gt-list--visible-marked
                  bookmark-gt-list-deletion-mark)))
    (unless flagged
      (let ((hidden (bookmark-gt-list--hidden-marked-count
                     bookmark-gt-list-deletion-mark)))
        (when (> hidden 0)
          (user-error
           "No flagged bookmarks in this view (%d hidden by the filter)"
           hidden)))
      (user-error "No bookmarks flagged for deletion"))
    (unless (yes-or-no-p (format "Delete %d bookmark(s)? "
                                 (length flagged)))
      (user-error "Aborted"))
    (dolist (record flagged)
      (bookmark-gt-delete-record record)
      (remhash (bookmark-gt-list--mark-key record) bookmark-gt-list--marks))
    (bookmark-gt--after-mutation (car flagged) 'delete)
    (message "Deleted %d bookmark(s)" (length flagged))))

;;;; Jump

(defun bookmark-gt-list-jump ()
  "Jump to the bookmark on the current line."
  (interactive nil bookmark-gt-list-mode)
  (let ((record (bookmark-gt-list--require-record)))
    (bookmark-gt-jump-record record)))

(defun bookmark-gt-list-jump-other-window ()
  "Jump to the bookmark on the current line in another window."
  (interactive nil bookmark-gt-list-mode)
  (let ((record (bookmark-gt-list--require-record)))
    (bookmark-gt-jump-record record #'switch-to-buffer-other-window)))

(defun bookmark-gt-list-preview ()
  "Preview the bookmark on the current line in another window.
Uses the handler's `:preview' when the registry entry
provides one; otherwise `bookmark-jump-other-window'.  Point
is restored to the list."
  (interactive nil bookmark-gt-list-mode)
  (let* ((record (bookmark-gt-list--require-record))
         (entry (bookmark-gt-handler-classify record))
         (preview-fn (plist-get (cdr entry) :preview)))
    (save-selected-window
      (if preview-fn
          (funcall preview-fn record)
        (bookmark-jump-other-window (car record))))))

;;;; Edit in place

(defun bookmark-gt-list-rename (new-name)
  "Rename the bookmark on the current line to NEW-NAME.
The current name is pre-filled in the minibuffer as editable
initial content, so the common case is to edit a few
characters rather than retype the whole name."
  (interactive
   (let ((record (bookmark-gt-list--require-record)))
     (list (read-from-minibuffer
            "Rename to: "
            (bookmark-gt-display-name-of record))))
   bookmark-gt-list-mode)
  (let ((record (bookmark-gt-list--require-record)))
    ;; Renaming into a name already in use follows the same policy
    ;; as creating one: refused, rather than silently suffixed.
    (unless (equal new-name (bookmark-name-from-full-record record))
      (bookmark-gt--check-name-available new-name (cdr record)))
    (bookmark-gt-rename-record record new-name)))

(defun bookmark-gt-list-relocate ()
  "Relocate the bookmark on the current line.
Dispatches to `bookmark-gt-relocate' with the row's record, so
the relocation cannot apply to a different bookmark sharing its
name.  File bookmarks get file-name completion; URL bookmarks
get a plain string prompt."
  (interactive nil bookmark-gt-list-mode)
  (let ((record (bookmark-gt-list--require-record)))
    (bookmark-gt-relocate record)))

(defun bookmark-gt-list-edit-tags ()
  "Edit the tag list on the marked bookmarks, or the one at point.
Prompts with the current tags as an editable comma-separated
string; the resulting list replaces the tags on every record
acted on.  Add tags by typing them after a comma; remove tags by
deleting them from the string.

With rows marked, the prompt is seeded with the union of their
tags, and the edited list replaces the tags on all of them."
  (interactive nil bookmark-gt-list-mode)
  (let* ((records (bookmark-gt-list--records-to-act-on))
         (current (bookmark-gt--normalize-tags
                   (seq-mapcat #'bookmark-gt-tags-of records)))
         (initial (mapconcat #'identity current ", "))
         (input   (read-from-minibuffer
                   (format-prompt (if (cdr records)
                                      (format "Tags for %d bookmarks"
                                              (length records))
                                    "Tags")
                                  initial)
                   initial))
         (tags    (bookmark-gt--normalize-tags
                   (split-string input "[,\n]" t "\\s-+"))))
    (dolist (record records)
      (bookmark-gt-tags-set record tags t))
    (bookmark-gt-list--finish
     records (format "Set tags on %d bookmarks" (length records)))))

(defun bookmark-gt-list-add-tags ()
  "Add tag(s) to the marked bookmarks, or the one at point.
Existing tags are kept; the new tag(s) are unioned in via
`bookmark-gt-tags-add'.  Empty input ends the reader without
adding anything."
  (interactive nil bookmark-gt-list-mode)
  (let* ((records (bookmark-gt-list--records-to-act-on))
         (new     (bookmark-gt-tags-read
                   (if (cdr records)
                       (format "Add tags to %d bookmarks"
                               (length records))
                     "Add tags"))))
    ;; Empty input leaves the selection in place: nothing was
    ;; changed, so there is nothing to deselect.
    (when new
      (dolist (record records)
        (bookmark-gt-tags-add record new t))
      (bookmark-gt-list--finish
       records (format "Added tags to %d bookmarks" (length records))))))

(defun bookmark-gt-list-remove-tags ()
  "Remove tag(s) from the marked bookmarks, or the one at point.
Completion is restricted to the tags actually present on the
records acted on — the union of their tags when several rows are
marked, so a tag needs to be on only one of them to be offered.
A tag absent from a given record leaves that record unchanged.
Empty input ends the reader without removing anything."
  (interactive nil bookmark-gt-list-mode)
  (let* ((records (bookmark-gt-list--records-to-act-on))
         (current (bookmark-gt--normalize-tags
                   (seq-mapcat #'bookmark-gt-tags-of records))))
    (unless current
      (user-error (if (cdr records)
                      "None of the marked bookmarks has tags"
                    "Bookmark has no tags")))
    (let ((doomed (bookmark-gt-tags-read
                   (if (cdr records)
                       (format "Remove tags from %d bookmarks"
                               (length records))
                     "Remove tags")
                   nil current)))
      (when doomed
        (dolist (record records)
          (bookmark-gt-tags-remove record doomed t))
        (bookmark-gt-list--finish
         records
         (format "Removed tags from %d bookmarks" (length records)))))))

(defun bookmark-gt-list-edit-annotation ()
  "Edit the annotation of the bookmark on the current line."
  (interactive nil bookmark-gt-list-mode)
  (let ((record (bookmark-gt-list--require-record)))
    (bookmark-edit-annotation (car record))))

(defun bookmark-gt-list--toggle-target (records predicate)
  "Return the value a bulk toggle of PREDICATE should set on RECORDS.
Nil when every record already satisfies PREDICATE, t otherwise.
A mixed selection is made uniformly on by the first invocation
and uniformly off by the next, so both target states stay
reachable without depending on where point sits — point need
not be inside the marked set at all.  With one record this is
plain negation."
  (not (seq-every-p predicate records)))

(defun bookmark-gt-list-toggle-auto-update ()
  "Toggle `auto-update' on the marked bookmarks, or the one at point.
With several rows marked, all of them are set to the same
value: on unless every one of them already has the property, in
which case all are turned off."
  (interactive nil bookmark-gt-list-mode)
  (unless (fboundp 'bookmark-gt-auto-update-set)
    (user-error "The bookmark-gt-auto-update module is not loaded"))
  (let* ((records (bookmark-gt-list--records-to-act-on))
         ;; Read the property directly rather than through
         ;; `bookmark-gt-auto-update-p', matching
         ;; `bookmark-gt-list--auto-update-glyph': the list buffer
         ;; renders the column without requiring that module.
         (flag (bookmark-gt-list--toggle-target
                records (lambda (r) (bookmark-prop-get r 'auto-update)))))
    (dolist (record records)
      (bookmark-gt-auto-update-set record flag t))
    (bookmark-gt-list--finish records)
    (message "%s auto-update on %s"
             (if flag "Enabled" "Disabled")
             (if (cdr records)
                 (format "%d bookmarks" (length records))
               (format "%S" (car (car records)))))))

(defun bookmark-gt-list-toggle-temp ()
  "Toggle the temp property on the marked bookmarks, or the one at point.
A temp bookmark is excluded from `bookmark-save' output while
`bookmark-gt-mode' is on.

With several rows marked, all of them are set to the same
value: temp unless every one of them is already temp, in which
case all are made permanent."
  (interactive nil bookmark-gt-list-mode)
  (let* ((records (bookmark-gt-list--records-to-act-on))
         (flag (bookmark-gt-list--toggle-target
                records #'bookmark-gt-temp-p)))
    (dolist (record records)
      (bookmark-gt-temp-set record flag t))
    (bookmark-gt-list--finish records)
    ;; The loop counts each state change but suppresses the
    ;; auto-save; one save covers the whole batch.
    (bookmark-gt--maybe-auto-save)
    (message "%s temp on %s"
             (if flag "Set" "Cleared")
             (if (cdr records)
                 (format "%d bookmarks" (length records))
               (format "%S" (car (car records)))))))

(defun bookmark-gt-list-show-temp ()
  "Toggle display of temporary bookmarks in this list buffer.
Buffer-local; initial default from
`bookmark-gt-list-default-show-temp'.  Temporary bookmarks
remain in `bookmark-alist' regardless of this setting."
  (interactive nil bookmark-gt-list-mode)
  (setq bookmark-gt-list--show-temp (not bookmark-gt-list--show-temp))
  (bookmark-gt-list--redraw-preserving-point)
  (bookmark-gt-list--state-changed)
  (message "Temporary bookmarks: %s"
           (if bookmark-gt-list--show-temp "shown" "hidden")))

(defun bookmark-gt-list-reset-view ()
  "Reset this buffer's sort, filters, and `show-temp' to defaults.
Sort returns to Name ascending, filters clear, and `show-temp'
returns to `bookmark-gt-list-default-show-temp'.  Persists the
reset to `bookmark-gt-list-state-file' when
`bookmark-gt-list-persist-state' is enabled."
  (interactive nil bookmark-gt-list-mode)
  (setq bookmark-gt-list--filters nil)
  (setq bookmark-gt-list--show-temp bookmark-gt-list-default-show-temp)
  (setq tabulated-list-sort-key '("Name" . nil))
  (tabulated-list-init-header)
  (tabulated-list-print t)
  (bookmark-gt-list--state-changed)
  (message "View reset."))

(defcustom bookmark-gt-list-record-buffer-name "*Bookmark-gt Record*"
  "Name of the buffer that displays a single bookmark's record."
  :type 'string
  :group 'bookmark-gt)

;;;; Sort predicates for the marker columns
;;
;; Both `auto-update' and `bmkp-temp' are record-backed flags, so
;; sorting by them is straightforward — the predicate reads the
;; alist directly.  Records with the flag set come first (so the
;; flagged rows cluster at the top); ties fall back to display
;; name for a stable order.
;;
;; The `*' selection column is not sortable: its state lives in
;; `tabulated-list-mode's padding area, not in the record, and
;; `tabulated-list-print' wipes the padding on every re-render.
;; Sorting by `*' would thus be lossy in both directions.

(defun bookmark-gt-list--sort-by-mark (a b)
  "Sort A before B: deletion-flagged first, then selected, then unmarked.
Reads `bookmark-gt-list--marks' — mark state lives in that
hash, not in the record."
  (let* ((rank
          (lambda (record)
            (let ((m (and bookmark-gt-list--marks
                          (gethash (bookmark-gt-list--mark-key record)
                                   bookmark-gt-list--marks))))
              (cond
               ((eq m bookmark-gt-list-deletion-mark)  2)
               ((eq m bookmark-gt-list-selection-mark) 1)
               (t                                       0)))))
         (ra (funcall rank (car a)))
         (rb (funcall rank (car b))))
    (if (= ra rb)
        (string< (bookmark-gt-display-name-of (car a))
                 (bookmark-gt-display-name-of (car b)))
      (> ra rb))))

(defun bookmark-gt-list--sort-by-group (a b)
  "Sort A before B by their group's display name, ties by record name."
  (let* ((ga (bookmark-gt-group-name (bookmark-gt-handler-group (car a))))
         (gb (bookmark-gt-group-name (bookmark-gt-handler-group (car b)))))
    (if (equal ga gb)
        (string< (bookmark-name-from-full-record (car a))
                 (bookmark-name-from-full-record (car b)))
      (string< (or ga "") (or gb "")))))

(defun bookmark-gt-list--sort-by-record-flag (prop)
  "Return a comparator that puts records carrying PROP before others.
Ties break by display name for stability."
  (lambda (a b)
    (let* ((ra (car a))
           (rb (car b))
           (fa (and (bookmark-prop-get ra prop) t))
           (fb (and (bookmark-prop-get rb prop) t)))
      (cond
       ((and fa (not fb)) t)
       ((and fb (not fa)) nil)
       (t (string< (bookmark-gt-display-name-of ra)
                   (bookmark-gt-display-name-of rb)))))))

(defun bookmark-gt-list--sortable-columns ()
  "Return the ordered names of sortable columns in `tabulated-list-format'.
A column is sortable when its third element (the sort predicate)
is non-nil.  Order matches the visual left-to-right layout, which
is the order `bookmark-gt-list-sort-cycle' rotates through."
  (let (out)
    (dotimes (i (length tabulated-list-format))
      (let ((col (aref tabulated-list-format i)))
        (when (nth 2 col)
          (push (car col) out))))
    (nreverse out)))

(defun bookmark-gt-list-sort-cycle ()
  "Cycle the sort column to the next sortable column.
Considers only columns whose `tabulated-list-format' entry has
a non-nil sort predicate.  Ascending only — no direction
toggle."
  (interactive nil bookmark-gt-list-mode)
  (let* ((cols (bookmark-gt-list--sortable-columns))
         (_ (unless cols
              (user-error "No sortable columns in this buffer")))
         (current (car-safe tabulated-list-sort-key))
         (idx (or (seq-position cols current #'equal) -1))
         (next (nth (mod (1+ idx) (length cols)) cols)))
    (setq tabulated-list-sort-key (cons next nil))
    (tabulated-list-init-header)
    (tabulated-list-print t)
    (bookmark-gt-list--state-changed)
    (message "Sorted by: %s" next)))

(defun bookmark-gt-list-describe-record ()
  "Pretty-print the raw record of the bookmark on the current line.
The record's name string is copied without text properties
before printing, so the bookmark+ `bmkp-full-record' snapshot
that some packages attach to the name as a text property does
not appear inline in the pretty-printed output."
  (interactive nil bookmark-gt-list-mode)
  (let* ((record (bookmark-gt-list--require-record))
         (clean (cons (substring-no-properties (car record))
                      (cdr record)))
         (buf (get-buffer-create bookmark-gt-list-record-buffer-name)))
    (with-current-buffer buf
      (setq buffer-read-only nil)
      (erase-buffer)
      (insert (format ";; Record for bookmark: %S\n;;\n" (car clean)))
      (pp clean (current-buffer))
      (goto-char (point-min))
      (emacs-lisp-mode)
      (view-mode 1))
    (display-buffer buf)))

;;;; Filter

(defun bookmark-gt-list-filter-by (key)
  "Add a filter to the current buffer, chosen from `bookmark-gt-filter-alist'.
The special KEY `unfilter' clears every active filter."
  (interactive
   (let ((choices (cons '(unfilter
                          :name "Unfilter"
                          :doc "Clear every active filter.")
                        bookmark-gt-filter-alist)))
     (list (intern (completing-read
                    "Filter by: "
                    (mapcar (lambda (e) (symbol-name (car e))) choices)
                    nil t))))
   bookmark-gt-list-mode)
  (cond
   ((eq key 'unfilter)
    (setq bookmark-gt-list--filters nil))
   (t
    (let* ((entry (alist-get key bookmark-gt-filter-alist))
           (reader (plist-get entry :reader))
           (arg (funcall reader)))
      (setq bookmark-gt-list--filters
            (cons (cons key arg)
                  (assq-delete-all key bookmark-gt-list--filters))))))
  (bookmark-gt-list--state-changed)
  (revert-buffer))

;;;; Built-in filter entries

(add-to-list 'bookmark-gt-filter-alist
             (cons 'by-type
                   (list :name "Type"
                         :reader
                         (lambda ()
                           (intern
                            (completing-read
                             "Type: "
                             ;; Dedupe by :type — the handler registry
                             ;; is keyed by handler symbol and many
                             ;; entries share a type (URL has three
                             ;; handler-symbol aliases, browser-tab has
                             ;; three, etc.).
                             (let ((seen (make-hash-table :test #'eq))
                                   candidates)
                               (dolist (e bookmark-gt-handler-alist)
                                 (let ((type (plist-get (cdr e) :type)))
                                   (unless (gethash type seen)
                                     (puthash type t seen)
                                     (push (symbol-name type) candidates))))
                               (nreverse candidates))
                             nil t)))
                         :predicate (lambda (record type-key)
                                      (eq (bookmark-gt-handler-type record)
                                          type-key))
                         :doc "Show only bookmarks of the chosen type.")))

(add-to-list 'bookmark-gt-filter-alist
             (cons 'by-group
                   (list :name "Group"
                         :reader
                         (lambda ()
                           (intern
                            (completing-read
                             "Group: "
                             (mapcar (lambda (e) (symbol-name (car e)))
                                     bookmark-gt-group-alist)
                             nil t)))
                         :predicate (lambda (record group)
                                      (eq (bookmark-gt-handler-group record)
                                          group))
                         :doc "Show only bookmarks in the chosen group.")))

(add-to-list 'bookmark-gt-filter-alist
             (cons 'by-tag
                   (list :name "Tag"
                         :reader (lambda ()
                                   (completing-read
                                    "Tag: "
                                    (bookmark-gt-tags-list)
                                    nil t))
                         :predicate (lambda (record tag)
                                      (bookmark-gt-has-tag-p record tag))
                         :doc "Show only bookmarks carrying the chosen tag.")))

(add-to-list 'bookmark-gt-filter-alist
             (cons 'by-name-regexp
                   (list :name "Name regexp"
                         :reader (lambda ()
                                   (read-regexp "Name matches"))
                         :predicate (lambda (record regexp)
                                      (string-match-p
                                       regexp
                                       (bookmark-gt-display-name-of record)))
                         :doc "Show only bookmarks whose name matches a regexp.")))

;;;; Built-in sort entries
;;
;; Registered for completeness — tabulated-list itself sorts using
;; the column's own comparator string function.  The sort registry
;; is the public seam for future dispatch (mark-by, jump-order,
;; etc.) that would take a comparator by symbol.

(add-to-list 'bookmark-gt-sort-alist
             (cons 'name
                   (list :name "Name"
                         :comparator
                         (lambda (a b)
                           (string< (bookmark-gt-display-name-of a)
                                    (bookmark-gt-display-name-of b)))
                         :doc "Alphabetical by name.")))

(add-to-list 'bookmark-gt-sort-alist
             (cons 'type
                   (list :name "Type"
                         :comparator
                         (lambda (a b)
                           (string< (bookmark-gt-handler-name a)
                                    (bookmark-gt-handler-name b)))
                         :doc "Alphabetical by type name.")))

;;;; View bookmarks — save/restore the list buffer's filters + sort + show-temp

(bookmark-gt-handler-register
 '(bookmark-gt-handler-view-jump)
 (list :type 'bookmark-gt-view :name "BkView" :group 'other
       :face 'bookmark-gt-face-view :narrow-char ?V
       :doc "Saved view of the *Bookmarks-gt List* buffer."))

(defun bookmark-gt-handler-view-jump (bookmark)
  "Restore the list buffer view saved in BOOKMARK.
Reads `filters', `sort-key', and `show-temp' from the record,
opens the list buffer if needed, applies the saved state, and
redraws."
  (let ((filters   (bookmark-prop-get bookmark 'filters))
        (sort-key  (bookmark-prop-get bookmark 'sort-key))
        (show-temp (bookmark-prop-get bookmark 'show-temp)))
    (bookmark-gt-list)
    (with-current-buffer bookmark-gt-list-buffer-name
      (setq bookmark-gt-list--filters filters)
      (setq tabulated-list-sort-key sort-key)
      (setq bookmark-gt-list--show-temp show-temp)
      (bookmark-gt-list--redraw-preserving-point))))

(defun bookmark-gt-list--make-record ()
  "Return a bookmark record describing the current list-buffer view.
Installed as `bookmark-make-record-function' by
`bookmark-gt-list-mode', so `M-x bookmark-gt-create' in the list
buffer stores a view bookmark that restores the current
filters, sort, and show-temp when jumped."
  `("View"
    (defaults "View")
    (handler   . bookmark-gt-handler-view-jump)
    (filters   . ,bookmark-gt-list--filters)
    (sort-key  . ,tabulated-list-sort-key)
    (show-temp . ,bookmark-gt-list--show-temp)))

(provide 'bookmark-gt-list)


;; Local Variables:
;; package-lint-main-file: "bookmark-gt.el"
;; End:

;;; bookmark-gt-list.el ends here
