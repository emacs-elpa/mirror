;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bookmark-gt" "0.9.0"
  "Records-only bookmark manager."
  '((emacs "30.1"))
  :url "https://github.com/dmgerman/bookmark-gt"
  :commit "da6f785ce23273cab4e0b8ad2a6659b13de816fd"
  :revdesc "da6f785ce232"
  :keywords '("convenience" "matching" "hypermedia")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
