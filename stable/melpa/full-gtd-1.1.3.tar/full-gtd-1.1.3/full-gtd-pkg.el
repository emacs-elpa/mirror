;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "1.1.3"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "87efa971955fe8f8f50a63abb69e64a35ea45646"
  :revdesc "87efa971955f"
  :keywords '("outlines" "tools" "convenience" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
