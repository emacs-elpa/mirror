;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-outlook" "0.11"
  "Outlook org."
  ()
  :url "https://github.com/mlf176f2/org-outlook.el"
  :commit "070c37d017ccb71d94c3c69c99632fa6570ec2cc"
  :revdesc "v0.11-0-g070c37d017cc"
  :keywords '("org-outlook"))
