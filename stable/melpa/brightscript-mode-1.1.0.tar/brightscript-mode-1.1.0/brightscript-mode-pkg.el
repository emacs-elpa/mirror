;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brightscript-mode" "1.1.0"
  "Major mode for editing Brightscript files."
  '((emacs "26.3"))
  :url "https://github.com/viseztrance/brightscript-mode"
  :commit "025d6f5a70752c62a28d4f86c053a283b3898a49"
  :revdesc "025d6f5a7075"
  :keywords '("languages")
  :authors '(("Daniel Mircea" . "daniel@viseztrance.com"))
  :maintainers '((nil . "daniel@viseztrance.com")))
