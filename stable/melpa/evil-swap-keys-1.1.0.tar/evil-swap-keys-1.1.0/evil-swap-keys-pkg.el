;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-swap-keys" "1.1.0"
  "Intelligently swap keys on text input with evil."
  '((emacs "24.4"))
  :url "https://github.com/wbolster/evil-swap-keys"
  :commit "889672ad0d35ab062c52d9d84b22de4ac49753f3"
  :revdesc "1.1.0-0-g889672ad0d35"
  :keywords '("convenience" "data" "languages" "tools")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
