;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-guide" "20160630"
  "Show vertical lines to guide indentation."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "feb207cb5610f351c7cdcf266e0c99117b2f786c"
  :revdesc "feb207cb5610")
