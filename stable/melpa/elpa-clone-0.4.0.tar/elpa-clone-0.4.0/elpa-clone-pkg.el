;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpa-clone" "0.4.0"
  "Clone ELPA archive."
  '((emacs "24.4"))
  :url "https://github.com/dochang/elpa-clone"
  :commit "dfbb68ac183b8c3e6e370c45032790ed7cf52165"
  :revdesc "0.4.0-0-gdfbb68ac183b"
  :keywords '("comm" "elpa" "clone" "mirror")
  :authors '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainers '(("ZHANG Weiyi" . "dochang@gmail.com")))
