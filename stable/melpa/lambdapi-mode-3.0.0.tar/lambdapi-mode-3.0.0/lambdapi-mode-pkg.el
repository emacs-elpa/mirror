;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambdapi-mode" "3.0.0"
  "A major mode for editing Lambdapi source code."
  '((emacs             "27.1")
    (eglot             "1.6")
    (math-symbol-lists "1.2.1")
    (highlight         "20190710.1527"))
  :url "https://github.com/Deducteam/lambdapi"
  :commit "f73c64dbeebf850ecc3384d64f0dbf93a1ea6acd"
  :revdesc "3.0.0-0-gf73c64dbeebf"
  :keywords '("languages")
  :maintainers '(("Deducteam" . "dedukti-dev@inria.fr")))
