;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "watch-buffer" "1.0.1"
  "Run a shell command when saving a buffer."
  ()
  :url "https://github.com/mjsteger/watch-buffer"
  :commit "a01cf15608c5bf91df253104053041ca1afdf411"
  :revdesc "a01cf15608c5"
  :keywords '("automation" "convenience")
  :authors '(("Michael Steger" . "mjsteger1@gmail.com"))
  :maintainers '(("Michael Steger" . "mjsteger1@gmail.com")))
