;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esqlite" "0.3.1"
  "Manipulate sqlite file from Emacs."
  '((pcsv "1.3.3"))
  :url "https://github.com/mhayashi1120/Emacs-esqlite"
  :commit "27d5ae46de9819e60d832f849f50b5b88b23b985"
  :revdesc "27d5ae46de98"
  :keywords '("data")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
