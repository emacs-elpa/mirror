;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conan" "0.0.1"
  "Generate flags for  for c++ using conan 2.0."
  '((emacs "29.1")
    (s     "1.7.0")
    (f     "0.20.0"))
  :url "https://github.com/Carl2/conan-elisp"
  :commit "c9ba867e09944349f19b7c1716b6302aeb7a40f3"
  :revdesc "c9ba867e0994"
  :keywords '("tools"))
