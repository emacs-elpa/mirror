;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-cmake" "0.2.1"
  "A cmake backend for project.el."
  '((emacs "30.1"))
  :url "https://github.com/lucius-martius/project-cmake"
  :commit "e177dfff76c03fc8f589c8070c9b1a945b2f8851"
  :revdesc "e177dfff76c0"
  :keywords '("tools" "convenience")
  :authors '(("Lucius Martius" . "lucius.martius@mailbox.org"))
  :maintainers '(("Lucius Martius" . "lucius.martius@mailbox.org")))
