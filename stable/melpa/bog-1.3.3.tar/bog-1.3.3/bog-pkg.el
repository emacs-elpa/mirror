;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bog" "1.3.3"
  "Extensions for research notes in Org mode."
  '((cl-lib "0.5"))
  :url "https://github.com/kyleam/bog"
  :commit "6bea27368b0010e04fb7c7894064251940eb21b0"
  :revdesc "v1.3.3-0-g6bea27368b00"
  :keywords '("bib" "outlines")
  :authors '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainers '(("Kyle Meyer" . "kyle@kyleam.com")))
