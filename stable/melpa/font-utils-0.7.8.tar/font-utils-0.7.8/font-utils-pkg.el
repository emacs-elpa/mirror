;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "font-utils" "0.7.8"
  "Utility functions for working with fonts."
  '((persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/font-utils"
  :commit "9192d3f8ee6a4e75f34c3fed10378674cc2b11d3"
  :revdesc "v0.7.8-0-g9192d3f8ee6a"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
