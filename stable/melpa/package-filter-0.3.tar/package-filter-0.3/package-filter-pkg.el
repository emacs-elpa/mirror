;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-filter" "0.3"
  "Special handling for package.el."
  ()
  :url "https://github.com/milkypostman/package-filter"
  :commit "7fe765ec27a1557617923c348fab0223e93a8c44"
  :revdesc "7fe765ec27a1"
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net"))
  :maintainers '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")))
