;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "css-eldoc" "0.0.0.20220415.55"
  "An eldoc-mode plugin for CSS source code."
  ()
  :url "https://github.com/zenozeng/css-eldoc"
  :commit "73ebf9757a043b56b7d3b5befec5a38e6754b9e5"
  :revdesc "73ebf9757a04"
  :authors '(("Zeno Zeng" . "zenoes@qq.com"))
  :maintainers '(("Zeno Zeng" . "zenoes@qq.com")))
