;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alt-codes" "0.0.5"
  "Insert alt codes using meta key."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/alt-codes"
  :commit "b36c2b2bccc628da1579016381d5c3195c9e12b2"
  :revdesc "b36c2b2bccc6"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
