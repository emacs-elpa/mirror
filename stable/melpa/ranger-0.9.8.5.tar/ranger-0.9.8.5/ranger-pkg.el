;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ranger" "0.9.8.5"
  "Make dired more like ranger."
  '((emacs "24.4"))
  :url "https://github.com/ralesi/ranger"
  :commit "584e4ae8cce1c54a44b40dd4c77fbb2f06d73ecb"
  :revdesc "584e4ae8cce1"
  :keywords '("files" "convenience")
  :authors '(("Rich Alesi" . "https://github.com/ralesi"))
  :maintainers '(("Rich Alesi" . "https://github.com/ralesi")))
