;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pronto" "1.0"
  "Compilation mode for pronto."
  ()
  :url "https://github.com/julianrubisch/pronto.el"
  :commit "ac01ca8c21db54c4f2fd231cb7f800f5a120d291"
  :revdesc "ac01ca8c21db"
  :keywords '("processes" "tools")
  :authors '(("Julian Rubisch" . "julian@julianrubisch.at"))
  :maintainers '(("Julian Rubisch" . "julian@julianrubisch.at")))
