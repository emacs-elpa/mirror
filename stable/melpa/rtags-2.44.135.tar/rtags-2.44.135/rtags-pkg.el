;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rtags" "2.44.135"
  "A front-end for rtags."
  '((emacs "24.3"))
  :url "https://github.com/Andersbakken/rtags"
  :commit "a0b315437da7f17d6c04e33234833e3baa474562"
  :revdesc "a0b315437da7"
  :authors '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
             ("Anders Bakken" . "agbakken@gmail.com"))
  :maintainers '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
                 ("Anders Bakken" . "agbakken@gmail.com")))
