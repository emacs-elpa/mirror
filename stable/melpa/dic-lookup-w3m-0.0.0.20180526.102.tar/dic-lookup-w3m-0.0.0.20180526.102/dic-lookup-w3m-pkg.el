;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dic-lookup-w3m" "0.0.0.20180526.102"
  "Look up dictionaries on the Internet."
  '((w3m  "20120723.324")
    (stem "20120826"))
  :url "https://github.com/emacsattic/dic-lookup-w3m"
  :commit "3254ab10cbf0078c7162557dd1f68dac28459cf9"
  :revdesc "3254ab10cbf0"
  :keywords '("emacs-w3m" "w3m" "dictionary"))
