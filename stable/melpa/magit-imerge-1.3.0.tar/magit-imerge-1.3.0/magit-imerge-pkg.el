;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-imerge" "1.3.0"
  "Magit extension for git-imerge."
  '((emacs "26.1")
    (magit "4.0.0"))
  :url "https://github.com/magit/magit-imerge"
  :commit "a4981f6944ff341c1b60b7b47babea625ec37d99"
  :revdesc "v1.3.0-0-ga4981f6944ff"
  :keywords '("vc" "tools")
  :authors '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainers '(("Kyle Meyer" . "kyle@kyleam.com")))
