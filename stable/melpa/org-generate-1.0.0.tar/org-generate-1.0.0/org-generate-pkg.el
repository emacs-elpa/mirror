;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-generate" "1.0.0"
  "Generate template files/folders from org document."
  '((emacs    "26.1")
    (org      "9.3")
    (mustache "0.23"))
  :url "https://github.com/conao3/org-generate.el"
  :commit "0c25f12cd25d835428dece427f26df53f1d60ce3"
  :revdesc "0c25f12cd25d"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
