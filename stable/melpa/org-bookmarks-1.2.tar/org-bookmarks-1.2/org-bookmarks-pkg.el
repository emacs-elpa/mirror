;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bookmarks" "1.2"
  "Manage bookmarks in Org mode."
  '((emacs "26.1"))
  :url "https://repo.or.cz/org-bookmarks.git"
  :commit "340319879d43e0a90c8f29f2b896ce28a69ec205"
  :revdesc "340319879d43"
  :keywords '("outline" "matching" "hypermedia" "org")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
