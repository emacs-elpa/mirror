;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-onenote" "0.1.0"
  "Export org-mode document to onenote."
  '((oauth2  "0.11")
    (request "0.2.0")
    (org     "8.2.10"))
  :url "https://github.com/ifree/org-onenote"
  :commit "20469ff51edd2adca9ed88eb6c267d66dd832c2c"
  :revdesc "20469ff51edd"
  :keywords '("tools" "docs" "org-mode" "onenote")
  :authors '(("Frei Zhang" . "ifree0@gmail.com"))
  :maintainers '(("Frei Zhang" . "ifree0@gmail.com")))
