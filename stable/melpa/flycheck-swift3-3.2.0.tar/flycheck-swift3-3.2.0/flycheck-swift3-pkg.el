;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-swift3" "3.2.0"
  "Flycheck: Swift support for Apple swift-mode."
  '((emacs    "25.1")
    (flycheck "26"))
  :url "https://github.com/GyazSquare/flycheck-swift3"
  :commit "14cb83c71a03bb7ae0952ee1707783219fda980e"
  :revdesc "14cb83c71a03"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Goichi Hirakawa" . "gooichi@gyazsquare.com"))
  :maintainers '(("Goichi Hirakawa" . "gooichi@gyazsquare.com")))
