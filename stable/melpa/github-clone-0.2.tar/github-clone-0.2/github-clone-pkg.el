;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-clone" "0.2"
  "Fork and clone github repos."
  '((gh    "0.7.2")
    (magit "1.2.0")
    (emacs "24"))
  :url "https://github.com/dgtized/github-clone.el"
  :commit "ab048cf49d9ebda73acae803bc44e731e629d540"
  :revdesc "ab048cf49d9e"
  :keywords '("vc" "tools")
  :authors '(("Charles L.G. Comstock" . "dgtized@gmail.com"))
  :maintainers '(("Charles L.G. Comstock" . "dgtized@gmail.com")))
