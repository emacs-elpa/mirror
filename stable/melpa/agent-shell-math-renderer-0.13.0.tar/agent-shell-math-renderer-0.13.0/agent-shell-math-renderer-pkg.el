;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.13.0"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.66.1")
    (latex-to-svg-backend "0.14.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "4d92db00a8430726d63ab50c4b5d8fc03fcd2620"
  :revdesc "v0.13.0-0-g4d92db00a843"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
