;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "0.17.0"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.10.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "30e67e3db55f17c17a6cb2e11618b518cd98543e"
  :revdesc "v0.17.0-0-g30e67e3db55f"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
