;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vimgolf" "0.10.3"
  "VimGolf interface for the One True Editor."
  ()
  :url "https://github.com/timvisher/vimgolf.el"
  :commit "78e91f810a1b49d68ef19565e1c6513c84855e1e"
  :revdesc "78e91f810a1b"
  :keywords '("games" "vimgolf" "vim")
  :authors '(("Tim Visher" . "tim.visher@gmail.com"))
  :maintainers '(("Tim Visher" . "tim.visher@gmail.com")))
