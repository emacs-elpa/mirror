;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "2.8"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "987b9f90eb10df53c34c0f4972469875c1e93203"
  :revdesc "2.8-0-g987b9f90eb10"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
