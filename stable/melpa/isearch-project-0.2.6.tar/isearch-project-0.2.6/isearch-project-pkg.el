;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "isearch-project" "0.2.6"
  "Incremental search through the whole project."
  '((emacs "26.1")
    (f     "0.20.0"))
  :url "https://github.com/jcs-elpa/isearch-project"
  :commit "1077b395e1c34a734120faf1f3a7feae6dc4d9c5"
  :revdesc "1077b395e1c3"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
