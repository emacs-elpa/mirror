;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weblorg" "0.1.2"
  "Static Site Generator for org-mode."
  '((templatel "0.1.6")
    (emacs     "26.1"))
  :url "https://emacs.love/weblorg"
  :commit "0f8ec7e9065b2962c93209ee30b46f91843e2815"
  :revdesc "0f8ec7e9065b"
  :authors '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainers '(("Lincoln Clarete" . "lincoln@clarete.li")))
