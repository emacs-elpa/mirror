;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lxc" "0.0.1"
  "Lxc integration with Emacs."
  ()
  :url "https://github.com/nicferrier/emacs-lxc"
  :commit "728f06d63e4b364f2c8bb036f441b7ebc123a2ec"
  :revdesc "728f06d63e4b"
  :keywords '("processes")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
