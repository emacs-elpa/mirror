;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tumble" "1.5"
  "An Tumblr mode for Emacs."
  ()
  :url "https://github.com/febuiles/tumble"
  :commit "a1db6dac5720b9f468a79e0efce04f77c0a458e3"
  :revdesc "1.5-0-ga1db6dac5720"
  :keywords '("tumblr")
  :authors '(("Federico Builes" . "federico.builes@gmail.com"))
  :maintainers '(("Federico Builes" . "federico.builes@gmail.com")))
