;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-c-yasnippet" "0.6.7"
  "Helm source for yasnippet.el."
  '((helm-core "1.7.7")
    (yasnippet "0.8.0")
    (cl-lib    "0.3"))
  :url "https://github.com/emacs-jp/helm-c-yasnippet"
  :commit "1fa400233ba8e990066c47cca1e2af64bd192d4d"
  :revdesc "0.6.7-0-g1fa400233ba8"
  :keywords '("convenience" "emulation")
  :authors '(("Kenji.I" . "ken.imakaado@gmail.com"))
  :maintainers '(("Kenji.I" . "ken.imakaado@gmail.com")))
