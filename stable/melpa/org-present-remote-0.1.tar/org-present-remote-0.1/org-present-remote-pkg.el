;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-present-remote" "0.1"
  "A web-based remote control for org-present."
  '((org-present "9")
    (elnode      "0.9"))
  :url "https://gitlab.com/duncan-bayne/org-present-remote"
  :commit "bac6c29e3fc9e8225fe8ee3d1d30c718a965aa6b"
  :revdesc "bac6c29e3fc9"
  :keywords '("comm" "docs")
  :authors '(("Duncan Bayne" . "duncan@bayne.id.au"))
  :maintainers '(("Duncan Bayne" . "duncan@bayne.id.au")))
