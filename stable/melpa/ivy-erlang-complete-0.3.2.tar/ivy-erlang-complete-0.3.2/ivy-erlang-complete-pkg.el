;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-erlang-complete" "0.3.2"
  "Erlang completion at point using ivy."
  ()
  :url "https://github.com/s-kostyaev/ivy-erlang-complete"
  :commit "7d60ed111dbfd34ab6ec1b07c06e2d16a5380b9a"
  :revdesc "7d60ed111dbf"
  :keywords '("languages" "tools")
  :authors '(("Sergey Kostyaev" . "feo.me@ya.ru"))
  :maintainers '(("Sergey Kostyaev" . "feo.me@ya.ru")))
