;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-erlang-complete" "0.3.2"
  "Erlang context sensitive completion at point using ivy. It also support xref and eldoc."
  '((async   "1.9")
    (counsel "0.11.0")
    (ivy     "0.11.0")
    (erlang  "19.2")
    (emacs   "25.1"))
  :url "https://github.com/s-kostyaev/ivy-erlang-complete"
  :commit "7d60ed111dbfd34ab6ec1b07c06e2d16a5380b9a"
  :revdesc "7d60ed111dbf"
  :keywords '("languages" "tools")
  :authors '(("Sergey Kostyaev" . "feo.me@ya.ru"))
  :maintainers '(("Sergey Kostyaev" . "feo.me@ya.ru")))
