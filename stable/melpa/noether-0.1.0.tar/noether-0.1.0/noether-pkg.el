;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noether" "0.1.0"
  "A modeline which plays hide and seek."
  '((posframe "0")
    (seq      "0"))
  :url "https://devheroes.codes/lxsameer/noether"
  :commit "fef92ec1bdfd14dc4322570786b119195f5b96c4"
  :revdesc "fef92ec1bdfd"
  :keywords '("frames" "modeline")
  :authors '(("Sameer Rahmani" . "lxsameer@gnu.org"))
  :maintainers '(("Sameer Rahmani" . "lxsameer@gnu.org")))
