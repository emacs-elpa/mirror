;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stock-tracker" "0.1.6"
  "Track stock price."
  '((emacs "27.1")
    (dash  "2.16.0")
    (async "1.9.5"))
  :url "https://github.com/beacoder/stock-tracker"
  :commit "58018a1747273df23dec08ec5d318da1960428c1"
  :revdesc "58018a174727"
  :keywords '("convenience" "stock" "finance")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
