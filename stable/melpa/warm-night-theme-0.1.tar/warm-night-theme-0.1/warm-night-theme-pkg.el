;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "warm-night-theme" "0.1"
  "Emacs 24 theme with a dark background."
  '((emacs "24"))
  :url "https://github.com/mswift42/warm-night-theme"
  :commit "4836bdda204c24eaa02d497bd367f6d3d3c12249"
  :revdesc "4836bdda204c")
