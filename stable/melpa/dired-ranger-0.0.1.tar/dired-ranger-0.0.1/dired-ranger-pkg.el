;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-ranger" "0.0.1"
  "Implementation of useful ranger features for dired."
  '((dash "2.7.0"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "31dde6cd1fd58bbfa01adc52f833bd0e0e18ee60"
  :revdesc "31dde6cd1fd5"
  :keywords '("files")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
