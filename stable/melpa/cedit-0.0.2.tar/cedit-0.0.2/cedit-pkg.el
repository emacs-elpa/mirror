;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cedit" "0.0.2"
  "Paredit-like commands for c-like languages."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "a697d74da244ec47dded4dcd4df1d61de6cfefc5"
  :revdesc "a697d74da244")
