;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mkdown" "0.1"
  "Pretty Markdown previews based on mkdown.com."
  ()
  :url "https://github.com/ajtulloch/mkdown.el"
  :commit "b883a967f54aa959b386f26ad9545875beecd254"
  :revdesc "b883a967f54a"
  :keywords '("markdown"))
