;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pocket-lib" "0.1"
  "Library for accessing getpocket.com API."
  '((emacs   "25.1")
    (request "0.2")
    (dash    "2.13.0")
    (kv      "0.0.19")
    (s       "1.12.0"))
  :url "https://github.com/alphapapa/pocket-lib.el"
  :commit "ef3bcf452129b74e7b82265f6c08f9569fd19515"
  :revdesc "ef3bcf452129"
  :keywords '("pocket")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
