;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "2.7.4"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "5ce8bdf4886ee275d56a238a9786296ee4697500"
  :revdesc "2.7.4-0-g5ce8bdf4886e"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
