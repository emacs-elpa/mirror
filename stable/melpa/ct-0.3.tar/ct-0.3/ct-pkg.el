;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ct" "0.3"
  "Color Tools - a color api."
  '((emacs "26.1")
    (dash  "2.18.0")
    (hsluv "1.0.0"))
  :url "https://github.com/neeasade/ct.el"
  :commit "1c1ce11b31ff1efe7f1be3b525d6b4e89d4cdf95"
  :revdesc "1c1ce11b31ff"
  :keywords '("convenience" "color" "theming" "rgb" "hsv" "hsl" "lab" "oklab" "background"))
