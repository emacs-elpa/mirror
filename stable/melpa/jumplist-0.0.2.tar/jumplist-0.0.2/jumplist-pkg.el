;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jumplist" "0.0.2"
  "Jump like vim jumplist or ex jumplist."
  '((cl-lib "0.5"))
  :url "https://github.com/ganmacs/jumplist"
  :commit "c482d137d95bc5e1bcd790cdbde25b7f729b2502"
  :revdesc "c482d137d95b"
  :keywords '("jumplist" "vim")
  :authors '(("ganmacs" . "ganmacs_at_gmail.com"))
  :maintainers '(("ganmacs" . "ganmacs_at_gmail.com")))
