;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osa" "1.0"
  "OSA (JavaScript / AppleScript) bridge."
  '((emacs "25.1"))
  :url "https://github.com/atomontage/osa"
  :commit "71849bfad44dae1c8a2ad4e0598379bcc6be5d95"
  :revdesc "71849bfad44d"
  :keywords '("extensions")
  :authors '(("xristos" . "xristos@sdf.org"))
  :maintainers '(("xristos" . "xristos@sdf.org")))
