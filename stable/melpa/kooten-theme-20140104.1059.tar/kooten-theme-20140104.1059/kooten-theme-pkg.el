;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kooten-theme" "20140104.1059"
  "Dark color theme."
  '((emacs "24.1"))
  :url "https://github.com/kootenpv/emacs-kooten-theme"
  :commit "ada5cdac51f277f1c1fd09e36822282f276212c9"
  :revdesc "ada5cdac51f2"
  :keywords '("themes")
  :authors '(("Pascal van Kooten" . "kootenpv@gmail.com"))
  :maintainers '(("Pascal van Kooten" . "kootenpv@gmail.com")))
