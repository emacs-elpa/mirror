;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calc-at-point" "1.0"
  "Perform calculations at point or over selection."
  '((emacs "26")
    (dash  "2.17.0"))
  :url "https://github.com/walseb/calc-at-point"
  :commit "1365ce19752e572a4114239f859169c135f0a5ae"
  :revdesc "1365ce19752e"
  :keywords '("convenience")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
