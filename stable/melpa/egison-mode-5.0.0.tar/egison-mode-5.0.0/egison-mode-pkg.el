;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "egison-mode" "5.0.0"
  "Egison editing mode."
  ()
  :url "https://github.com/egisatoshi/egison/blob/master/emacs/egison-mode.el"
  :commit "3a5b520c6b5bc4a78523573d06e3be887e02d1dd"
  :revdesc "3a5b520c6b5b"
  :authors '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainers '(("Satoshi Egi" . "egisatoshi@gmail.com")))
