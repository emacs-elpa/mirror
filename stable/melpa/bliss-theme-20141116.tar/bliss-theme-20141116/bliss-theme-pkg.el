;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bliss-theme" "20141116"
  "An Emacs 24 theme based on Bliss (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "a44cb4804f77b8e7497f88abfabcd960aaf3516f"
  :revdesc "a44cb4804f77")
