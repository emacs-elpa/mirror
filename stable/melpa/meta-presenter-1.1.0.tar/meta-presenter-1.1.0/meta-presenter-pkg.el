;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meta-presenter" "1.1.0"
  "A simple multi-file presentation tool for Emacs."
  ()
  :url "http://ismail.teamfluxion.com"
  :commit "3d8c762a7dd7ac39032a3601bd6a717f206e670d"
  :revdesc "3d8c762a7dd7"
  :keywords '("productivity" "presentation")
  :authors '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com"))
  :maintainers '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com")))
