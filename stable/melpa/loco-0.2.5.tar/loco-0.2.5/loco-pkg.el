;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loco" "0.2.5"
  "Enter complex key sequences with ease!."
  '((emacs "29.1"))
  :url "https://github.com/csmclaren/loco"
  :commit "eb9f89221d10b946482a79493d63a6fac15fb9fc"
  :revdesc "v0.2.5-0-geb9f89221d10"
  :keywords '("abbrev" "convenience")
  :authors '(("Chris McLaren" . "csmclaren@me.com"))
  :maintainers '(("Chris McLaren" . "csmclaren@me.com")))
