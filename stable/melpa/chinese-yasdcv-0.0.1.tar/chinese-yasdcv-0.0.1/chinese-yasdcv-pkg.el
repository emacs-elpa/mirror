;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chinese-yasdcv" "0.0.1"
  "Yet another sdcv emacs frontend (sdcv: Console version of StarDict program)."
  ()
  :url "https://github.com/tumashu/chinese-yasdcv"
  :commit "73d41c41be0ee357de26d0cf5b5d691c8ddb2c2f"
  :revdesc "73d41c41be0e"
  :authors '(("Feng Shu" . "tumashu@gmail.com"))
  :maintainers '(("Feng Shu" . "tumashu@gmail.com")))
