;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-autoexport" "1.4"
  "Auto-export org file on save."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://git.sr.ht/~zondo/org-autoexport"
  :commit "3a23950fc11c98a484a9884a18205d5ac1611854"
  :revdesc "3a23950fc11c"
  :keywords '("org" "wp")
  :authors '(("Glenn Hutchings" . "zondo42@gmail.com"))
  :maintainers '(("Glenn Hutchings" . "zondo42@gmail.com")))
