;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-manager" "1.0.0"
  "Configuration manager for leaf based init.el."
  '((emacs        "26.1")
    (leaf         "4.1")
    (leaf-convert "1.0")
    (ppp          "2.1"))
  :url "https://github.com/conao3/leaf-manager.el"
  :commit "f2ae35e02ebe218daa3076a0e9d83b4feadfbb0a"
  :revdesc "f2ae35e02ebe"
  :keywords '("convenience" "leaf")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
