;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tsort" "1.0.0"
  "Topological sort for Emacs Lisp."
  '((emacs "25.1"))
  :url "https://github.com/ehawkvu/tsort.el"
  :commit "9907e2762ecf73ff1b976c7d92d3108e7b10c96a"
  :revdesc "9907e2762ecf"
  :keywords '("algorithm" "tools")
  :authors '(("Ethan Hawk" . "ethan.hawk@valpo.edu"))
  :maintainers '(("Ethan Hawk" . "ethan.hawk@valpo.edu")))
