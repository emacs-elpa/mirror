;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cheerilee" "0.4"
  "Toolkit library."
  '((xelb "0.1"))
  :url "https://github.com/Vannil/cheerilee.el"
  :commit "c914f8e8dc1808234c856e1c1db7972bdf5fa224"
  :revdesc "c914f8e8dc18"
  :keywords '("multimedia" "tools")
  :authors '(("Alessio Vanni" . "vannilla@firemail.cc"))
  :maintainers '(("Alessio Vanni" . "vannilla@firemail.cc")))
