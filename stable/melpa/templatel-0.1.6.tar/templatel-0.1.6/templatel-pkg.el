;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "templatel" "0.1.6"
  "Templating language;."
  '((emacs "25.1"))
  :url "https://clarete.li/templatel"
  :commit "8374097a129b2cd13c449568f95ee7380b36b307"
  :revdesc "8374097a129b"
  :authors '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainers '(("Lincoln Clarete" . "lincoln@clarete.li")))
