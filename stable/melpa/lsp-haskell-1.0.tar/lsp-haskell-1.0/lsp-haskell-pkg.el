;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-haskell" "1.0"
  "Haskell support for lsp-mode."
  '((lsp-mode     "2.0")
    (haskell-mode "1.0"))
  :url "https://github.com/emacs-lsp/lsp-haskell"
  :commit "f02b23da1e1966e6865b5d6296535d8f3f31c71c"
  :revdesc "f02b23da1e19"
  :keywords '("haskell"))
