;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fstar-mode" "0.9.4.0"
  "Support for F* programming."
  '((emacs "24.3")
    (dash  "2.11"))
  :url "https://github.com/FStarLang/fstar.el"
  :commit "3a9be64827bbed8e34d38803b5c44d8d4f6cd688"
  :revdesc "3a9be64827bb"
  :keywords '("convenience" "languages")
  :authors '(("Clément Pit--Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit--Claudel" . "clement.pitclaudel@live.com")))
