;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paren-completer" "20150711.1523"
  "Automatically, language agnostically, fill in delimiters."
  '((emacs "24.3"))
  :url "https://github.com/MatthewBregg/paren-completer"
  :commit "2296117fe04339051a71d16d61bbdab32b4bdd63"
  :revdesc "2296117fe043"
  :keywords '("convenience"))
