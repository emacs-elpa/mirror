;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyai" "1.0.0"
  "Haskell Yet Another Indentation."
  '((cl-lib "0.5")
    (emacs  "24"))
  :url "https://github.com/iquiw/hyai"
  :commit "7c644d31f62943c75ccf5a772e43450b462cc08f"
  :revdesc "7c644d31f629"
  :authors '(("Iku Iwasa" . "iku.iwasa@gmail.com"))
  :maintainers '(("Iku Iwasa" . "iku.iwasa@gmail.com")))
