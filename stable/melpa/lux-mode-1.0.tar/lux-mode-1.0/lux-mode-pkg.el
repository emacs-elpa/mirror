;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lux-mode" "1.0"
  "Major mode for editing lux files."
  '((emacs "24.3"))
  :url "https://github.com/hawk/lux"
  :commit "382412b2a0b392a98f174ae04a32c4ced896f101"
  :revdesc "382412b2a0b3")
