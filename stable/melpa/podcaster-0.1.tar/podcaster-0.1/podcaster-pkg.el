;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "podcaster" "0.1"
  "Emacs podcast client."
  '((helm   "1.0")
    (cl-lib "0.5"))
  :url "https://github.com/syohex/emacs-podcaster"
  :commit "54cef2772d881723a3e50ac0793f0240b21446d0"
  :revdesc "54cef2772d88"
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
