;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transwin" "0.1.4"
  "Make window/frame transparent."
  '((emacs "24.3"))
  :url "https://github.com/jcs-elpa/transwin"
  :commit "ed0156a98b6fce94da9045bdffe369f390b70c0c"
  :revdesc "ed0156a98b6f"
  :keywords '("frames" "window" "transparent")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
