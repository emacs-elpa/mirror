;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aws-ec2" "0.0.3"
  "Manage AWS EC2 instances."
  '((emacs "24.4")
    (dash  "2.12.1")
    (tblui "0.1.0"))
  :url "https://github.com/Yuki-Inoue/aws.el"
  :commit "5601d4f268fc34b86a02ca90cde7d3771619a368"
  :revdesc "5601d4f268fc"
  :authors '(("Yuki Inoue" . "inouetakahiroki_at_gmail.com"))
  :maintainers '(("Yuki Inoue" . "inouetakahiroki_at_gmail.com")))
