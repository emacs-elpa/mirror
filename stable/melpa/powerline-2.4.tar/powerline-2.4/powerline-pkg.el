;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "powerline" "2.4"
  "Rewrite of Powerline."
  '((cl-lib "0.2"))
  :url "https://github.com/milkypostman/powerline/"
  :commit "d3dcfc57a36111d8e0b037d90c6ffce85ce071b2"
  :revdesc "d3dcfc57a361"
  :keywords '("mode-line")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net"))
  :maintainers '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")))
