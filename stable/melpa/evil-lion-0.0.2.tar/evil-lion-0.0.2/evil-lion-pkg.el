;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-lion" "0.0.2"
  "Evil align operator, port of vim-lion."
  '((emacs "24")
    (evil  "1.0.0"))
  :url "https://github.com/edkolev/evil-lion"
  :commit "dd732c1471ecc9f6d964b214b7b6a5ac9f08178e"
  :revdesc "dd732c1471ec"
  :keywords '("emulations" "evil" "vim")
  :authors '(("edkolev" . "evgenysw@gmail.com"))
  :maintainers '(("edkolev" . "evgenysw@gmail.com")))
