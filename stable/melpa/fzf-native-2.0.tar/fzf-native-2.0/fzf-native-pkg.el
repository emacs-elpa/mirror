;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "2.0"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "83d70f20d24ffd47ab28b65deb8972ae8c11928c"
  :revdesc "83d70f20d24f"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
