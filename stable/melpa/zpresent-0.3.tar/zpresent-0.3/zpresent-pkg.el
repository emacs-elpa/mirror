;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zpresent" "0.3"
  "Simple presentation mode based on org files."
  '((emacs      "25.1")
    (org-parser "0.3")
    (dash       "2.13.0"))
  :url "https://bitbucket.org/zck/zpresent.el"
  :commit "2df6a39a2a1bd660bda37e2f068a300d729580b2"
  :revdesc "2df6a39a2a1b"
  :keywords '("comm"))
