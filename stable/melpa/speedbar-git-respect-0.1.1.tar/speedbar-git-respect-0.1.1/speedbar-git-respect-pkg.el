;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speedbar-git-respect" "0.1.1"
  "Particular respect git repo in speedbar."
  '((f     "0.8.0")
    (emacs "25.1"))
  :url "https://github.com/ukari/speedbar-git-respect"
  :commit "9663b7d71385041fdd7488d74d54cb6c4e05b74a"
  :revdesc "0.1.1-0-g9663b7d71385"
  :authors '(("Muromi Ukari" . "chendianbuji@gmail.com"))
  :maintainers '(("Muromi Ukari" . "chendianbuji@gmail.com")))
