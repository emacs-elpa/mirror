;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "0.2.0"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.2.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "aa52369a626a64db090d1b7a2af2377ca5db9c71"
  :revdesc "aa52369a626a"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
