;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elark" "0.0.0.20261025.151"
  "Emacs interface to Lark/Feishu via lark-cli."
  '((emacs       "29.1")
    (org-lark    "0.2")
    (shell-maker "0.97.5"))
  :url "https://github.com/bbw9n/elark"
  :commit "eafcccfa3b78079fa61223e757435e4f55e4fd23"
  :revdesc "eafcccfa3b78"
  :keywords '("comm" "tools" "agent")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
