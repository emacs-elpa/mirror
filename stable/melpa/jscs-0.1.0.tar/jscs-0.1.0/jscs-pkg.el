;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jscs" "0.1.0"
  "Apply JSCS indentation rules to JS modes."
  '((emacs "24.1"))
  :url "https://github.com/papaeye/emacs-jscs-indent"
  :commit "4ae0ef368da737941628aacec6e713e376f4fae2"
  :revdesc "4ae0ef368da7"
  :keywords '("languages" "convenience")
  :authors '(("papaeye" . "papaeye@gmail.com"))
  :maintainers '(("papaeye" . "papaeye@gmail.com")))
