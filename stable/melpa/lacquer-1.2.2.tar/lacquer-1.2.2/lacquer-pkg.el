;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lacquer" "1.2.2"
  "Switch theme/font by selecting from a cache."
  '((emacs "25.2"))
  :url "https://github.com/zakudriver/lacquer"
  :commit "ebdb531f5b7cb691751e468942e28921a9dcc98f"
  :revdesc "ebdb531f5b7c"
  :keywords '("tools")
  :authors '(("zakudriver" . "zy.hua1122@gmail.com"))
  :maintainers '(("zakudriver" . "zy.hua1122@gmail.com")))
