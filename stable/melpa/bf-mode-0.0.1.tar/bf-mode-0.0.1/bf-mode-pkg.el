;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bf-mode" "0.0.1"
  "Browse file persistently on dired."
  ()
  :url "https://github.com/emacs-jp/bf-mode"
  :commit "908896e25130720493a135bb49ca56be13b549af"
  :revdesc "908896e25130"
  :keywords '("convenience")
  :maintainers '(("myuhe" . "yuhei.maeda_at_gmail.com")))
