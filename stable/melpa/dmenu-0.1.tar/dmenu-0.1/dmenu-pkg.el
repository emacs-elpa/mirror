;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dmenu" "0.1"
  "Use ido to simulate the dmenu command line program."
  ()
  :url "https://github.com/lujun9972/el-dmenu"
  :commit "cb73c64b1f0c82c6fc92980260acb6b3ad58db8f"
  :revdesc "cb73c64b1f0c"
  :keywords '("convenience" "usability")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
