;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amaranth-dark-theme" "0.1.0"
  "Amaranth Dark theme."
  ()
  :url "https://github.com/a9sk/amaranth-dark-theme"
  :commit "dd9e214be984c264ffd4217cb73857ceaa9679b1"
  :revdesc "dd9e214be984"
  :authors '(("Emiliano Rizzonelli" . "emiliano.rizzonelli@proton.me"))
  :maintainers '(("Emiliano Rizzonelli" . "emiliano.rizzonelli@proton.me")))
