;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grove" "0.1.0"
  "Obsidian-like note-taking for org files."
  '((emacs "29.1"))
  :url "https://github.com/jonathanchu/grove"
  :commit "ff5389c2066a84fd3dfde0af1626e73783cbf2cb"
  :revdesc "ff5389c2066a"
  :keywords '("notes" "org-mode" "tools")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
