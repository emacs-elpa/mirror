;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shelldon" "1.0"
  "A friendly little shell in the minibuffer."
  '((emacs "27.1"))
  :url "https://github.com/Overdr0ne/shelldon"
  :commit "be50d40a20dc565dd893d3b3f41f337be8033ff1"
  :revdesc "be50d40a20dc"
  :keywords '("tools" "convenience")
  :authors '(("overdr0ne" . "scmorris.dev@gmail.com"))
  :maintainers '(("overdr0ne" . "scmorris.dev@gmail.com")))
