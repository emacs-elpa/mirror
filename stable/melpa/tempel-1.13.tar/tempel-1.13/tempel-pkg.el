;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "1.13"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/tempel"
  :commit "ab6d67c2e8abcb9bd20bfe56cba930a5ea093ae0"
  :revdesc "1.13-0-gab6d67c2e8ab"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
