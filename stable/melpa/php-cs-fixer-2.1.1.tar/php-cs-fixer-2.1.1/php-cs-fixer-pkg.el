;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-cs-fixer" "2.1.1"
  "The php-cs-fixer wrapper."
  '((cl-lib "0.5"))
  :url "https://github.com/OVYA/php-cs-fixer"
  :commit "710208cc2efc2e241d1e7421b3c2581d46a81a5c"
  :revdesc "710208cc2efc"
  :keywords '("languages" "php"))
