;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flower" "0.4.7"
  "Emacs task tracker client."
  '((emacs   "24.4")
    (clomacs "0.0.3"))
  :url "https://github.com/PositiveTechnologies/flower"
  :commit "0d5dd8b9b844adab1a1b7a9641daa9e98918712c"
  :revdesc "0d5dd8b9b844"
  :keywords '("hypermedia" "outlines" "tools" "vc")
  :authors '(("Sergey Sobko" . "SSobko@ptsecurity.com"))
  :maintainers '(("Sergey Sobko" . "SSobko@ptsecurity.com")))
