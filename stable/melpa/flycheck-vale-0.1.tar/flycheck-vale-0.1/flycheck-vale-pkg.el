;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-vale" "0.1"
  "Flycheck integration for vale."
  '((emacs    "24")
    (flycheck "0.22")
    (cl-lib   "0.5"))
  :url "https://github.com/abingham/flycheck-vale"
  :commit "d51f1db28d43c9df7f8ef74382a2e079e67ec667"
  :revdesc "d51f1db28d43"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
