;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-dictionary" "1.0.0"
  "Helm source for looking up dictionaries."
  ()
  :url "https://github.com/emacs-helm/helm-dictionary"
  :commit "33234e56b50b62095f90c6bddcbf759ddd76de0a"
  :revdesc "33234e56b50b"
  :authors '(("Titus von der Malsburg" . "malsburg@posteo.de"))
  :maintainers '(("Titus von der Malsburg" . "malsburg@posteo.de")))
