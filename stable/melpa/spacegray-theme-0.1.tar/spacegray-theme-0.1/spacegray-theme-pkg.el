;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spacegray-theme" "0.1"
  "A Hyperminimal UI Theme for Emacs."
  '((emacs "24.1"))
  :url "https://github.com/bruce/emacs-spacegray-theme"
  :commit "2980bc6645ae5defff3357347836b5ee39df8147"
  :revdesc "2980bc6645ae"
  :keywords '("themes")
  :authors '(("Bruce Williams" . "brwcodes@gmail.com"))
  :maintainers '(("Bruce Williams" . "brwcodes@gmail.com")))
