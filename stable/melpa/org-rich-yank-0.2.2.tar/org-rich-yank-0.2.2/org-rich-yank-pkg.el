;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-rich-yank" "0.2.2"
  "Paste with org-mode markup and link to source."
  '((emacs "24.4"))
  :url "https://github.com/unhammer/org-rich-yank"
  :commit "0a74fb742fcdf9560d954b40e2f49551476dee4f"
  :revdesc "v0.2.2-0-g0a74fb742fcd"
  :keywords '("convenience" "hypermedia" "org")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
