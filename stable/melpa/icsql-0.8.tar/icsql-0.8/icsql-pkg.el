;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "icsql" "0.8"
  "Interactive iSQL iteraface to ciSQL."
  '((emacs          "26")
    (choice-program "0.13")
    (buffer-manage  "0.12"))
  :url "https://github.com/plandes/icsql"
  :commit "4521e9d2debef7687bfd26a664479f0c46688a36"
  :revdesc "v0.8-0-g4521e9d2debe"
  :keywords '("isql" "sql" "rdbms" "data"))
