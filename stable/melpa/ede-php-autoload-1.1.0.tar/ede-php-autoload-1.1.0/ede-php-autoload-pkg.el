;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ede-php-autoload" "1.1.0"
  "Simple EDE PHP Project."
  ()
  :url "https://github.com/stevenremot/ede-php-autoload"
  :commit "28a989232c276ee7fc5112c9050b1c29f628be9f"
  :revdesc "28a989232c27"
  :keywords '("php" "project" "ede")
  :authors '(("Steven Rémot" . "steven.remot@gmail.com")
             ("original code for C++ by Eric M. Ludlam" . "eric@siege-engine.com"))
  :maintainers '(("Steven Rémot" . "steven.remot@gmail.com")
                 ("original code for C++ by Eric M. Ludlam" . "eric@siege-engine.com")))
