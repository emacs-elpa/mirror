;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-credo" "0.1.0"
  "Flycheck checker for elixir credo."
  '((flycheck "29"))
  :url "https://github.com/aaronjensen/flycheck-credo"
  :commit "c9f3565ca6503844135fa7b273228d27abe7002c"
  :revdesc "c9f3565ca650"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
