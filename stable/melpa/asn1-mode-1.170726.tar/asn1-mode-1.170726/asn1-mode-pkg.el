;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asn1-mode" "1.170726"
  "ASN.1/GDMO mode for GNU Emacs."
  '((emacs "24.3"))
  :url "https://github.com/kawabata/asn1-mode/"
  :commit "60a3192c2f1c34e839b153699b7ce3dac12af0db"
  :revdesc "60a3192c2f1c"
  :keywords '("languages" "processes" "tools")
  :authors '(("Taichi Kawabata" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi Kawabata" . "kawabata.taichi_at_gmail.com")))
