;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "window-jump" "0.1.0"
  "Move left/right/up/down through your windows."
  ()
  :url "https://github.com/chumpage/chumpy-windows"
  :commit "2ad3dc03807623d5e608387d7f529697abb6fbdc"
  :revdesc "2ad3dc038076"
  :keywords '("windows" "navigation"))
