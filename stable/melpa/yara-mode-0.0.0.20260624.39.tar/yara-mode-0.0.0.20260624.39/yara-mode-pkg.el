;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yara-mode" "0.0.0.20260624.39"
  "Major mode for editing yara rule file."
  '((emacs "24"))
  :url "not distributed yet"
  :commit "dc6eb93198c081c579300521d25199625e375530"
  :revdesc "dc6eb93198c0"
  :keywords '("yara")
  :authors '((nil . "binjo.cn@gmail.com"))
  :maintainers '((nil . "binjo.cn@gmail.com")))
