;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insert-char-preview" "0.1"
  "Insert Unicode char."
  '((emacs "24.1")
    (ht    "2.2"))
  :url "https://gitlab.com/matsievskiysv/insert-char-preview"
  :commit "6a8d67b61b6853e5a5241e5585f9d23e2d04cb83"
  :revdesc "6a8d67b61b68"
  :keywords '("convenience"))
