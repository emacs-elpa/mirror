;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unisonlang-mode" "0.2.0"
  "Simple major mode for editing Unison."
  '((emacs "25.1"))
  :url "https://github.com/unison-mode-emacs"
  :commit "f793430068ade1b0a2d744aaa45f569c9dec9085"
  :revdesc "f793430068ad"
  :keywords '("languages"))
