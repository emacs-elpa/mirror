;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-vterm" "0.1"
  "Vterm for visual commands in eshell."
  '((emacs "27")
    (vterm "0.0.1"))
  :url "https://github.com/iostapyshyn/eshell-vterm"
  :commit "1b762ec595760e3041a9df5fc0a2d3a8719bdc14"
  :revdesc "1b762ec59576"
  :keywords '("eshell" "vterm" "terminal" "shell" "visual")
  :authors '(("Illia Ostapyshyn" . "ilya.ostapyshyn@gmail.com"))
  :maintainers '(("Illia Ostapyshyn" . "ilya.ostapyshyn@gmail.com")))
