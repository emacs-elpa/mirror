;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abgaben" "1.1.2"
  "Review and correct assignments received by mail."
  '((pdf-tools "0.80")
    (f         "0.19.0")
    (s         "1.11.0"))
  :url "http://arne.chark.eu/"
  :commit "966bfcfdd3b2e288576ffe363d676ad282902090"
  :revdesc "966bfcfdd3b2"
  :keywords '("mail" "outlines" "convenience")
  :authors '(("Arne Köhn" . "arne@chark.eu"))
  :maintainers '(("Arne Köhn" . "arne@chark.eu")))
