;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dactyl-mode" "0.0.1"
  "Major mode for editing Pentadactyl config files."
  ()
  :url "https://github.com/luxbock/dactyl-mode"
  :commit "d8b5a13d895a1f8031e30c1043f3539e34baa0ac"
  :revdesc "d8b5a13d895a"
  :keywords '("languages" "vim")
  :authors '(("Alpha Tan" . "alphatan.zh@gmail.com"))
  :maintainers '(("Alpha Tan" . "alphatan.zh@gmail.com")))
