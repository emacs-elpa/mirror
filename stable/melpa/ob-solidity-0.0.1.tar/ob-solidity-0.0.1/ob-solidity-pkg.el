;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-solidity" "0.0.1"
  "Org-babel functions for solidity evaluation."
  ()
  :url "https://github.com/hrkrshnn/ob-solidity"
  :commit "d0ffe51b4fa02f5bff59e2e3c3f70f01255c28a9"
  :revdesc "d0ffe51b4fa0"
  :keywords '("solidity" "literate programming" "reproducible research"))
