;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "systemtap-mode" "0.2"
  "A mode for SystemTap."
  ()
  :url "https://github.com/ruediger/systemtap-mode"
  :commit "934c73e0188d82a8d99164ead5a7e89b9ee47718"
  :revdesc "934c73e0188d"
  :keywords '("tools" "languages")
  :maintainers '((nil . "ruediger@c-plusplus.de")))
