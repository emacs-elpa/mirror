;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sticky-scroll-mode" "1.0.1"
  "Sticky scrolling."
  '((emacs "29.4"))
  :url "https://github.com/jclasley/sticky-mode"
  :commit "4c8cad80f63ce23eb35c9955824b7f07812ee0fc"
  :revdesc "4c8cad80f63c"
  :keywords '("convenience" "extensions" "tools")
  :authors '(("Jon Lasley" . "jon.lasley+sticky@gmail.com"))
  :maintainers '(("Jon Lasley" . "jon.lasley+sticky@gmail.com")))
