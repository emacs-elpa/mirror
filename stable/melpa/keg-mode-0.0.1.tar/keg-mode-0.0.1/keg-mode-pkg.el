;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keg-mode" "0.0.1"
  "Major mode for editing Keg files."
  '((emacs "24.4"))
  :url "https://github.com/conao3/keg.el"
  :commit "c8f38f4d11505568524df715dafdf36f89805347"
  :revdesc "c8f38f4d1150"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
