;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "journalctl-mode" "1.1"
  "Sample major mode for  viewing output journalctl."
  '((emacs "27.1"))
  :url "https://github.com/SebastianMeisel/journalctl-mode"
  :commit "aef9162171118ef8e6ab411b26b763c9c6ea9e2f"
  :revdesc "aef916217111"
  :keywords '("unix")
  :authors '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainers '(("Sebastian Meisel" . "sebastian.meisel@gmail.com")))
