;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-gnus" "0.4"
  "Access gnus groups or servers using ido."
  '((gnus "5.13"))
  :url "https://github.com/vapniks/ido-gnus"
  :commit "8b9151a0606aad9444878bba4e6d837d85d9d165"
  :revdesc "8b9151a0606a"
  :keywords '("comm")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
