;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-emoji" "1.0"
  "Select emojis with Helm."
  '((emacs "29.1")
    (helm  "3.9.6"))
  :url "https://codeberg.org/timmli/helm-emoji"
  :commit "b331826f067159da7c1c08e1ede334d8cfb22c87"
  :revdesc "b331826f0671"
  :keywords '("convenience")
  :authors '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de"))
  :maintainers '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de")))
