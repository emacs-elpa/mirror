;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ledger" "0.1"
  "Make `ledger-mode' more `evil'."
  '((evil "1.0.0"))
  :url "https://github.com/atheriel/evil-ledger"
  :commit "4d657fb587064c65d8c7cf7e9bced277a9e07d0e"
  :revdesc "4d657fb58706"
  :keywords '("evil" "vim-emulation")
  :authors '(("Aaron Jacobs" . "atheriel@gmail.com"))
  :maintainers '(("Aaron Jacobs" . "atheriel@gmail.com")))
