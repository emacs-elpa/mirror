;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spray" "0.0.2"
  "A speed reading mode."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "393b04a8e7fc11e063bff0e56acfc835884ebd87"
  :revdesc "393b04a8e7fc")
