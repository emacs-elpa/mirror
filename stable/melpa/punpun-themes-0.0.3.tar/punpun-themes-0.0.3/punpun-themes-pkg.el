;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "punpun-themes" "0.0.3"
  "A set of bleak themes."
  '((emacs "24.1"))
  :url "https://depp.brause.cc/punpun-themes"
  :commit "a0b26442293e7afc6fd2ba9be199fc7b4f5138e3"
  :revdesc "a0b26442293e"
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
