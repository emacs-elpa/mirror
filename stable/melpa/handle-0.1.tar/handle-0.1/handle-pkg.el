;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "handle" "0.1"
  "A handle for things."
  '((emacs "24.4"))
  :url "https://gitlab.com/jjzmajic/handle"
  :commit "e0246c72dbf764c3dc7151b484c2848383def50a"
  :revdesc "e0246c72dbf7"
  :keywords '("convenience"))
