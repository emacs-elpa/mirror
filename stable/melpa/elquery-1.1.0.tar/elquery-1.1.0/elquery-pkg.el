;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elquery" "1.1.0"
  "The HTML library for elisp."
  '((emacs "25.1")
    (dash  "2.13.0"))
  :url "https://github.com/AdamNiederer/elquery"
  :commit "8d82d0d3005d6ec6d1e7fcd7f26abb1a165cc79a"
  :revdesc "8d82d0d3005d"
  :keywords '("html" "hypermedia" "tools" "webscale"))
