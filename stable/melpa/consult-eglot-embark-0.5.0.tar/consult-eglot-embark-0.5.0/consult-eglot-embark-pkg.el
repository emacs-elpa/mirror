;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-eglot-embark" "0.5.0"
  "Embark integration for `consult-eglot'."
  '((emacs          "27.1")
    (consult-eglot  "0.3")
    (embark-consult "1.0"))
  :url "https://github.com/mohkale/consult-eglot"
  :commit "b71499f4b93bfea4e2005564c25c5bb0f9e73199"
  :revdesc "b71499f4b93b"
  :keywords '("tools" "completion" "lsp")
  :authors '(("mohsin kaleem" . "mohkale@kisara.moe")))
