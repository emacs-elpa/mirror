;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "svelte-mode" "1.0.5"
  "Emacs major mode for Svelte."
  '((emacs "26.1"))
  :url "https://github.com/leafOfTree/svelte-mode"
  :commit "f9fda07bc4d697b8121d73ca5e6893a4d0fa4fee"
  :revdesc "f9fda07bc4d6"
  :keywords '("wp" "languages")
  :authors '(("Leaf" . "leafvocation@gmail.com"))
  :maintainers '(("Leaf" . "leafvocation@gmail.com")))
