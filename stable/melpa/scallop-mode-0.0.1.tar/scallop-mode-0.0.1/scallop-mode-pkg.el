;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scallop-mode" "0.0.1"
  "Major mode for editing Scallop programming language."
  ()
  :url "https://github.com/taquangtrung/emacs-scallop-mode"
  :commit "9df5f7a4ed51343699c24aeced2230907a93492b"
  :revdesc "9df5f7a4ed51"
  :keywords '("languages"))
