;;; scallop-mode.el --- Major mode for editing Scallop programming language.

;; Copyright © 2025, by Ta Quang Trung

;; Author: Ta Quang Trung
;; Package-Version: 0.0.1
;; Package-Revision: 9df5f7a4ed51
;; Created: 14 May, 2025
;; Keywords: languages
;; Homepage: https://github.com/taquangtrung/emacs-scallop-mode

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; Emacs major mode for editing source code of the Scallop programming language
;; (https://www.scallop-lang.org/)

;; Features:
;; - Syntax highlighting.
;; - Automatic code indentation.

;; Installation:
;; - Automatic package installation from Melpa.
;; - Manual installation by putting the `scallop-mode.el' file in Emacs' load path.

;;; Code:

(require 'rx)

(defconst scallop-keywords
  '("type"
    "rel")
  "List of Scallop keywords.")

(defconst scallop-special-constants
  '("inf"
    "nan"
    "true"
    "false")
  "List of Scallop special constants.")

(defconst scallop-special-operators
  '(":-")
  "List of Scallop special operators.")

(defconst scallop-special-types
  '("String"
    "usize")
  "List of Scallop special types.")

;;;;;;;;;;;;;;;;;;;;;;;;;
;; Syntax highlighting

(defvar scallop-syntax-table
  (let ((syntax-table (make-syntax-table)))
    ;; C++ style comment "// ..."
    (modify-syntax-entry ?\/ ". 124" syntax-table)
    (modify-syntax-entry ?* ". 23b" syntax-table)
    (modify-syntax-entry ?\n ">" syntax-table)
    syntax-table)
  "Syntax table for `scallop-mode'.")

(defvar scallop-keywords-regexp
  (concat
   (rx symbol-start)
   (regexp-opt scallop-keywords t)
   (rx symbol-end))
  "Regular expression to match Scallop keywords.")

(defvar scallop-special-constants-regexp
  (concat
   (rx symbol-start)
   (regexp-opt scallop-special-constants t)
   (rx symbol-end))
  "Regular expression to match Scallop special constants.")

(defvar scallop-special-operators-regexp
  (concat
   (rx symbol-start)
   (regexp-opt scallop-special-operators t)
   (rx symbol-end))
  "Regular expression to match Scallop special operators.")

(defvar scallop-special-types-regexp
  (concat
   (rx symbol-start)
   (regexp-opt scallop-special-types t)
   (rx symbol-end))
  "Regular expression to match Scallop special types.")

(defun scallop--match-regexp (re limit)
  "Generic regular expression matching wrapper for RE with a given LIMIT."
  (re-search-forward re
                     limit ; search bound
                     t     ; no error, return nil
                     nil   ; do not repeat
                     ))

(defun scallop--match-relation-name (limit)
  "Search the buffer forward until LIMIT matching relation names.
Highlight the 1st result."
  (scallop--match-regexp
   (concat
    (rx symbol-start) "\\([a-zA-Z0-9_]+\\)" (rx symbol-end)
    "[[:space:]]*\\((\\|\\[[^\\[]*\\](\\)")
   limit))

(defconst scallop-font-locks
  (list
   `(,scallop-keywords-regexp . font-lock-keyword-face)
   `(,scallop-special-constants-regexp . font-lock-constant-face)
   `(,scallop-special-operators-regexp . font-lock-operator-face)
   `(,scallop-special-types-regexp . font-lock-type-face)
   '(scallop--match-relation-name (1 font-lock-function-name-face)))
  "Font lock settings for `scallop-mode'.")

;;;;;;;;;;;;;;;;;;
;;; Indentation

(defun scallop-indent-line (&optional indent)
  "Indent the current line according to the Scallop syntax, or supply INDENT."
  (interactive "P")
  (let ((pos (- (point-max) (point)))
        (indent (or indent (scallop--calculate-indentation)))
        (shift-amount nil)
        (beg (progn (beginning-of-line) (point))))
    (skip-chars-forward " \t")
    (if (null indent)
        (goto-char (- (point-max) pos))
      (setq shift-amount (- indent (current-column)))
      (unless (zerop shift-amount)
        (delete-region beg (point))
        (indent-to indent))
      (when (> (- (point-max) pos) (point))
        (goto-char (- (point-max) pos))))))

(defun scallop--calculate-indentation ()
  "Calculate the indentation of the current line."
  (let (indent)
    (save-excursion
      (back-to-indentation)
      (let* ((ppss (syntax-ppss))
             (depth (car ppss))
             (paren-start-pos (cadr ppss))
             (base (* tab-width depth)))
        (unless (= depth 0)
          (setq indent base)
          (cond ((looking-at "\s*[})]")
                 ;; closing a block or a parentheses pair
                 (setq indent (- base tab-width)))
                ((looking-at "\s*:=")
                 ;; indent for multiple-line assignment
                 (setq indent (+ base (* 2 tab-width))))
                ((looking-back "\s*:=\s*\n\s*")
                 ;; indent for multiple-line assignment
                 (setq indent (+ base (* 2 tab-width))))))))
    indent))

;;;;;;;;;;;;;;;;;;;;;;;;;;
;;; Major mode settings

;;;###autoload
(define-derived-mode scallop-mode prog-mode
  "scallop-mode"
  "Major mode for editing source code of the Scallop programming language."
  :syntax-table scallop-syntax-table

  ;; Syntax highlighting
  (setq font-lock-defaults '(scallop-font-locks))

  ;; Indentation
  (setq-local indent-tabs-mode nil)
  (setq-local indent-line-function #'scallop-indent-line)

  ;; Set comment command
  (setq-local comment-start "//")
  (setq-local comment-end "")
  (setq-local comment-multi-line nil)
  (setq-local comment-use-syntax t))

;;;###autoload
(add-to-list 'auto-mode-alist '("\\.scallop\\'" . scallop-mode))

;; Finally export the `scallop-mode'
(provide 'scallop-mode)

;;; scallop-mode.el ends here
