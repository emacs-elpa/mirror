;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "revbufs" "1.2"
  "[No description available]."
  ()
  :url "http://www.neilvandyke.org/revbufs/"
  :commit "74dc21949fe0f910e92b8e4e85318c8fb0b7c86a"
  :revdesc "1.2-0-g74dc21949fe0"
  :authors '(("Neil Van Dyke" . "neil@neilvandyke.org"))
  :maintainers '(("Neil Van Dyke" . "neil@neilvandyke.org")))
