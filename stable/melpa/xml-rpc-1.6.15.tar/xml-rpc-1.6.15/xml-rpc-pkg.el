;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xml-rpc" "1.6.15"
  "An elisp implementation of clientside XML-RPC."
  ()
  :url "https://github.com/xml-rpc-el/xml-rpc-el"
  :commit "8020ccd176986d8e49e0bb5dd9f4e756cf12eafc"
  :revdesc "8020ccd17698"
  :keywords '("xml" "rpc" "network")
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
