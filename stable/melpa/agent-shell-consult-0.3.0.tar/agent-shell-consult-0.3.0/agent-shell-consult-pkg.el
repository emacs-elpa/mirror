;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-consult" "0.3.0"
  "Consult UI for agent-shell."
  '((emacs       "28.1")
    (agent-shell "0.83.4")
    (acp         "0.18.1"))
  :url "https://github.com/Gleek/agent-shell-consult"
  :commit "0d1304205254df6908e2ed62a9973e5474aa1daf"
  :revdesc "0d1304205254"
  :keywords '("convenience" "processes" "tools"))
