;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-browse-commit" "0.1.0"
  "Browse pull/merge requests from magit-blame."
  '((emacs "25.1")
    (magit "3.0.0")
    (s     "1.12.0"))
  :url "https://github.com/angeldswang/magit-browse-commit"
  :commit "7bdfea6c88f2d9cbbc1e71eb93e4ea4bc54fcb1f"
  :revdesc "7bdfea6c88f2"
  :keywords '("vc" "tools" "git")
  :authors '(("Angeldswang" . "angeldswang@gmail.com"))
  :maintainers '(("Angeldswang" . "angeldswang@gmail.com")))
