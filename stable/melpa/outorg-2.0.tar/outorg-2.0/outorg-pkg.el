;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outorg" "2.0"
  "Org-style comment editing."
  ()
  :url "https://github.com/tj64/outorg"
  :commit "e946cda497bae53fca6fa1579910237e216170bf"
  :revdesc "e946cda497ba"
  :authors '(("Thorsten Jolitz" . "tjolitzATgmailDOTcom"))
  :maintainers '(("Thorsten Jolitz" . "tjolitzATgmailDOTcom")))
