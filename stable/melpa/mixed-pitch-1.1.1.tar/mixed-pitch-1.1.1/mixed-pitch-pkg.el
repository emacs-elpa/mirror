;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mixed-pitch" "1.1.1"
  "Use a variable pitch, keeping fixed pitch where it's sensible."
  '((emacs "24.3"))
  :url "https://gitlab.com/jabranham/mixed-pitch"
  :commit "beb22e85f6073a930f7338a78bd186e3090abdd7"
  :revdesc "beb22e85f607"
  :authors '(("J. Alexander Branham" . "branham@utexas.edu"))
  :maintainers '(("J. Alexander Branham" . "branham@utexas.edu")))
