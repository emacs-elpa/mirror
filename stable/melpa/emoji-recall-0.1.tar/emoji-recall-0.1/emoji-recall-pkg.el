;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emoji-recall" "0.1"
  "How many emoji can you recall from memory?."
  ()
  :url "https://github.com/lujun9972/emoji-recall.el"
  :commit "c466367365e4e70a627f4ef8aeec118fdc0290f9"
  :revdesc "c466367365e4"
  :keywords '("game")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
