;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcmpl-homebrew" "0.97.4"
  "Pcomplete for homebrew."
  ()
  :url "https://github.com/suzzvv/pcmpl-homebrew"
  :commit "c2fbc7eaff72721a703df2c9fddbf811191d9ba8"
  :revdesc "c2fbc7eaff72"
  :keywords '("pcomplete" "homebrew" "tools" "cask" "services")
  :authors '(("zwild" . "judezhao@outlook.com"))
  :maintainers '(("zwild" . "judezhao@outlook.com")))
