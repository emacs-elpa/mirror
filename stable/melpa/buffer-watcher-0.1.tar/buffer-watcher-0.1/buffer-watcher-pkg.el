;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-watcher" "0.1"
  "Makes it easy to run shell scripts per filetype/directory when a buffer is saved."
  '((f "0.16.2"))
  :url "https://github.com/NicolasPetton/buffer-watcher"
  :commit "353d76882c65d44341b6f28bd86279dda00c3440"
  :revdesc "0.1-0-g353d76882c65"
  :authors '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")))
