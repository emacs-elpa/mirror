;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "battery-notifier" "0.2.2"
  "Notify when battery capacity is low."
  '((alert "1.3"))
  :url "https://github.com/jasonmj/battery-notifier"
  :commit "ae2043db954e131d9de7347ab1a6107fd07e8893"
  :revdesc "ae2043db954e"
  :keywords '("hardware" "battery")
  :authors '(("Jason Johnson" . "(jason@fullsteamlabs.com)"))
  :maintainers '(("Jason Johnson" . "(jason@fullsteamlabs.com)")))
