;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-markdown" "0.18.1"
  "Preview Markdown LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.18.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "1944a44ddf02d1507b381ffdf9460a9f248b5d63"
  :revdesc "v0.18.1-0-g1944a44ddf02"
  :keywords '("tex" "markdown" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
