;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hive" "0.1.1"
  "Hive SQL mode extension."
  '((sql "3.0"))
  :url "https://github.com/r0man/hive-el"
  :commit "8178395fa6dbae91e70b62a7cf4bd074a593c485"
  :revdesc "8178395fa6db"
  :keywords '("sql" "hive")
  :authors '(("Roman Scherer" . "roman@burningswell.com"))
  :maintainers '(("Roman Scherer" . "roman@burningswell.com")))
