;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "0.0.2"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "c6ccb0fce8a13442d3f86d6daa5dcf753dc5a877"
  :revdesc "v0.0.2-0-gc6ccb0fce8a1"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
