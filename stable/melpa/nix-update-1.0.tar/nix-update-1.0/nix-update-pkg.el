;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-update" "1.0"
  "[No description available]."
  ()
  :url "https://github.com/jwiegley/nix-update-el"
  :commit "4d8b4c33dcc006e9138065226bc9374836060ab0"
  :revdesc "4d8b4c33dcc0"
  :keywords '("nix")
  :authors '(("John Wiegley" . "johnw@newartisans.com"))
  :maintainers '(("John Wiegley" . "johnw@newartisans.com")))
