;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phony" "4.0.0"
  "Define voice commands."
  '((emacs      "29.1")
    (simulacrum "2.0.0"))
  :url "https://github.com/ErikPrantare/phony.el"
  :commit "ac14a68b3a9affa9791c79dc52a961336c318405"
  :revdesc "ac14a68b3a9a"
  :keywords '("convenience")
  :authors '(("Erik Präntare" . "erik@prantare.xyz"))
  :maintainers '(("Erik Präntare" . "erik@prantare.xyz")))
