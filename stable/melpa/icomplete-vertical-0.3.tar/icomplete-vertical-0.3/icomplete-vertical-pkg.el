;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "icomplete-vertical" "0.3"
  "Display icomplete candidates vertically."
  '((emacs "25.1"))
  :url "https://github.com/oantolin/icomplete-vertical"
  :commit "a4c65f213bd3d8be94fe8cb28ecf7ff3b44405d1"
  :revdesc "a4c65f213bd3"
  :keywords '("convenience" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
