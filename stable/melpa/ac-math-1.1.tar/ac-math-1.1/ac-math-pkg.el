;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-math" "1.1"
  "Auto-complete sources for input of mathematical symbols and latex tags."
  '((auto-complete     "1.4")
    (math-symbol-lists "1.0"))
  :url "https://github.com/vitoshka/ac-math"
  :commit "89478063dead68894f0d27687b63896633048c6f"
  :revdesc "89478063dead"
  :keywords '("latex" "auto-complete" "unicode" "symbols"))
