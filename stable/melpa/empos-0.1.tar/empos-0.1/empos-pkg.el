;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empos" "0.1"
  "Locate bibtex citations from within emacs."
  ()
  :url "https://github.com/dimalik/empos/"
  :commit "57c161146fd333bb1ec8955cafc148dec5d71f84"
  :revdesc "57c161146fd3"
  :keywords '("citations" "reference" "bibtex" "reftex")
  :authors '(("Dimitris Alikaniotis" . "da352[at]cam.ac.uk"))
  :maintainers '(("Dimitris Alikaniotis" . "da352[at]cam.ac.uk")))
