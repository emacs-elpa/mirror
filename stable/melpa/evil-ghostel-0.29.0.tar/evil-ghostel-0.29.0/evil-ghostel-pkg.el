;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "0.29.0"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.8.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "cd32af7bd6b9c827701a62ed8f0c3bc705800f13"
  :revdesc "cd32af7bd6b9"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
