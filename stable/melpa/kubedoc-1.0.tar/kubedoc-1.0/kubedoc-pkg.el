;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubedoc" "1.0"
  "Kubernetes API Documentation."
  '((emacs "27.1"))
  :url "https://github.com/r0bobo/kubedoc.el/"
  :commit "a409bad1adc1b7499c8b282a994448db00dffb83"
  :revdesc "a409bad1adc1"
  :keywords '("docs" "help" "tools")
  :authors '(("Dean Lindqvist Todevski" . "https://github.com/r0bobo")))
