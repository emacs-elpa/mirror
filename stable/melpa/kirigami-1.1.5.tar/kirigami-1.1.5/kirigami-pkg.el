;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.1.5"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "77e967baf830aa411404ed695826f0b589bdc28a"
  :revdesc "1.1.5-0-g77e967baf830"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
