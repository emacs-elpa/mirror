;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nixos-options" "0.0.1"
  "Interface for browsing and completing NixOS options."
  '((emacs "24")
    (json  "1.4"))
  :url "http://www.github.com/travisbhartwell/nix-emacs/"
  :commit "5fc8fa29bea9dd8e9c822af92f9bc6ddc223635f"
  :revdesc "5fc8fa29bea9"
  :keywords '("unix")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com")
             ("Travis B. Hartwell" . "nafai@travishartwell.net"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")
                 ("Travis B. Hartwell" . "nafai@travishartwell.net")))
