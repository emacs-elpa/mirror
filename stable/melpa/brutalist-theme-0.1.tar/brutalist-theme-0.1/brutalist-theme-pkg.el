;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brutalist-theme" "0.1"
  "Brutalist theme."
  ()
  :url "https://git.madhouse-project.org/algernon/brutalist-theme.el"
  :commit "f64ccd93e4459980b2f930ab05df91efe4515777"
  :revdesc "f64ccd93e445"
  :authors '(("Marian Schubert & Gergely Nagy" . "marian.schubert@gmail.com"))
  :maintainers '(("Marian Schubert & Gergely Nagy" . "marian.schubert@gmail.com")))
