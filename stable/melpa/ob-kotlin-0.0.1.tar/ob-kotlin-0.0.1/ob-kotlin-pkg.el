;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-kotlin" "0.0.1"
  "Org-babel functions for kotlin evaluation."
  '((org "8"))
  :url "https://github.com/zweifisch/ob-kotlin"
  :commit "432a2d7963c5081ebc9e7cdc0eb7d3429fca85ee"
  :revdesc "432a2d7963c5"
  :keywords '("org" "babel" "kotlin")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
