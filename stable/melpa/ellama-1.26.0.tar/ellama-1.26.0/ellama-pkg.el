;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "1.26.0"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.30.2")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "bbee2a0d5badabb447583e54d436bc300de4b791"
  :revdesc "bbee2a0d5bad"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
