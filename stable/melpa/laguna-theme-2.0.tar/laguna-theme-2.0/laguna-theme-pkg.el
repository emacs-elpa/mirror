;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "laguna-theme" "2.0"
  "An updated blue-green Laguna Theme."
  ()
  :url "https://github.com/HenryNewcomer/laguna-theme"
  :commit "3a8665ac1fcca3d333ab2adf231f45126bc02211"
  :revdesc "3a8665ac1fcc"
  :authors '(("Henry Newcomer" . "a.cliche.email@gmail.com"))
  :maintainers '(("Henry Newcomer" . "a.cliche.email@gmail.com")))
