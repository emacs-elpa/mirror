;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-tmux" "0.1.5"
  "Babel Support for Interactive Terminal."
  '((emacs "25.1")
    (seq   "2.3")
    (s     "1.9.0"))
  :url "https://github.com/ahendriksen/ob-tmux"
  :commit "8886f31291e979b41215f3eb97670732efffea34"
  :revdesc "8886f31291e9"
  :keywords '("literate programming" "interactive shell" "tmux"))
