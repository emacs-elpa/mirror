;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "current-word-highlight" "1.0.4"
  "Highlight the current word minor mode."
  ()
  :url "https://github.com/kijimaD/current-word-highlight"
  :commit "d82441c85773bec2bc41eb3c5778659f0be31a61"
  :revdesc "d82441c85773"
  :keywords '("highlight" "face" "convenience" "word")
  :authors '(("Kijima Daigo" . "norimaking777@gmail.com"))
  :maintainers '(("Kijima Daigo" . "norimaking777@gmail.com")))
