;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evenok" "0.12.1"
  "Themes with perceptively evenly distributed colors."
  '((emacs "28.1"))
  :url "https://codeberg.org/mekeor/evenok"
  :commit "5fc6494c4efba2bb0615e3e5c813f5425be21ec7"
  :revdesc "5fc6494c4efb"
  :keywords '("faces" "theme")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
