;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-arduino" "0.1.0"
  "Company-mode for Arduino."
  '((emacs         "24.1")
    (company       "0.8.0")
    (irony         "0.1.0")
    (cl-lib        "0.5")
    (company-irony "0.1.0"))
  :url "https://github.com/yuutayamada/company-arduino"
  :commit "953f0c1f4ccbd675ee67c705278d8dfcb32f5e55"
  :revdesc "953f0c1f4ccb"
  :keywords '("convenience" "development" "company")
  :authors '(("Yuta Yamada" . "sleepboy.zzz@gmail.com"))
  :maintainers '(("Yuta Yamada" . "sleepboy.zzz@gmail.com")))
