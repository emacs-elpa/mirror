;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unify-opening" "2.2.0"
  "Unify the mechanism to open files."
  '((emacs "24.4"))
  :url "https://github.com/DamienCassou/unify-opening"
  :commit "4c6e3447e203a51af116a2117e88d41114950205"
  :revdesc "4c6e3447e203"
  :authors '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainers '(("Damien Cassou" . "damien.cassou@gmail.com")))
