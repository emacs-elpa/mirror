;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "newspeak-mode" "1.0"
  "Major mode for the Newspeak programming language."
  ()
  :url "https://github.com/danielsz/newspeak-mode"
  :commit "3986d9687cec6cc36958bbd6b8923447f405980d"
  :revdesc "3986d9687cec"
  :maintainers '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com")))
