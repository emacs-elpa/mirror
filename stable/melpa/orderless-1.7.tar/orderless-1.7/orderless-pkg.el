;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orderless" "1.7"
  "Completion style for matching regexps in any order."
  '((emacs  "27.1")
    (compat "31"))
  :url "https://github.com/oantolin/orderless"
  :commit "cebe19e3cf0f30604d1ed1bfaa74fff21a4e89a5"
  :revdesc "1.7-0-gcebe19e3cf0f"
  :keywords '("matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
