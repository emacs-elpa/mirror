;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "1.11.1"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "ff1e8269fca7e2ee2e50774ade3ce88b79e78cfc"
  :revdesc "ff1e8269fca7"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
