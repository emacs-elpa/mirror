;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitlab" "0.8.0"
  "Emacs client for Gitlab."
  '((s        "1.9.0")
    (dash     "2.9.0")
    (pkg-info "0.5.0")
    (request  "0.1.0"))
  :url "https://github.com/nlamirault/emacs-gitlab"
  :commit "a1c1441ff5ffb290e695eb9ac05431e9385578f4"
  :revdesc "a1c1441ff5ff"
  :keywords '("gitlab")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
