;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "madhat2r-theme" "0.1"
  "Color theme with a dark and light versions."
  '((emacs "24"))
  :url "https://github.com/madhat2r/madhat2r-theme"
  :commit "69411decc3eb86dcd2354366b81d49e772dafc9b"
  :revdesc "69411decc3eb"
  :keywords '("color" "theme"))
