;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fast-scroll" "0.0.5"
  "Some utilities for faster scrolling over large buffers."
  '((emacs  "25.1")
    (cl-lib "0.6.1"))
  :url "https://github.com/ahungry/fast-scroll"
  :commit "0f78d1039e5394a6b57d186189a89937453c7002"
  :revdesc "0f78d1039e53"
  :keywords '("ahungry" "convenience" "fast" "scroll" "scrolling")
  :authors '(("Matthew Carter" . "m@ahungry.com"))
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
