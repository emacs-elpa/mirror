;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "84cbf2eb506b95c0363f0a4341805371e3fe1d77"
  :revdesc "84cbf2eb506b"
  :keywords '("faces" "files" "q"))
