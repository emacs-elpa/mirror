;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kivy-mode" "2.3.1"
  "Emacs major mode for editing Kivy files."
  ()
  :url "https://github.com/kivy/kivy"
  :commit "20d74dcd30f143abbd1aa94c76bafc5bd934d5bd"
  :revdesc "2.3.1-0-g20d74dcd30f1"
  :authors '(("Dean Serenevy" . "dean@serenevy.net"))
  :maintainers '(("Dean Serenevy" . "dean@serenevy.net")))
