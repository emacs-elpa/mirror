;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuff" "0.1"
  "Find files with findutils."
  ()
  :url "https://github.com/joelmo/fuff"
  :commit "6509bd136794efdce6a68925a1698b1bf7de1abe"
  :revdesc "6509bd136794"
  :keywords '("files" "project" "convenience"))
