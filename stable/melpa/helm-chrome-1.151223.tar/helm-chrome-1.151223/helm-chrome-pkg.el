;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-chrome" "1.151223"
  "Helm interface for Chrome bookmarks."
  '((helm   "1.5")
    (cl-lib "0.3")
    (emacs  "24"))
  :url "https://github.com/kawabata/helm-chrome"
  :commit "da91c66f83c86b93e18b18091daa3abe22dc2e10"
  :revdesc "da91c66f83c8"
  :keywords '("tools")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
