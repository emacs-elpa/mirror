;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.2"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazelbuild/emacs-bazel-mode"
  :commit "ecacde94a1402346944d2c01f5a87a25a510490e"
  :revdesc "ecacde94a140"
  :keywords '("build tools" "languages"))
