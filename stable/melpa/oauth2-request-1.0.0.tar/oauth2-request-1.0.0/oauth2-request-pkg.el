;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oauth2-request" "1.0.0"
  "OAuth2 request package interface."
  '((emacs   "26.1")
    (oauth2  "0.14")
    (request "0.3"))
  :url "https://github.com/conao3/oauth2-request.el"
  :commit "86ff048635e002b00e23d6bed2ec6f36c17bca8e"
  :revdesc "86ff048635e0"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
