;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "expenses" "0.2.0"
  "Record and view expenses."
  '((emacs "26.1")
    (dash  "2.19.1")
    (ht    "2.3"))
  :url "https://github.com/md-arif-shaikh/expenses"
  :commit "e668666770858e92de83d8217c7e384de3ba1e34"
  :revdesc "e66866677085"
  :keywords '("expense tracking" "convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
