;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chee" "0.3.0"
  "Interface to chee using dired and image-dired."
  '((dash "2.12.1")
    (s    "1.10.0")
    (f    "0.18.2"))
  :url "https://github.com/eikek/chee/tree/release/0.3.0/emacs"
  :commit "beeaa5bb2ce92f1a745440c7ff7468e5f6524701"
  :revdesc "release/0.3.0-0-gbeeaa5bb2ce9")
