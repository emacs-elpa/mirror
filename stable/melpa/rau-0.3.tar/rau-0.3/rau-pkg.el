;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rau" "0.3"
  "Wayland Window Manager based on River."
  '((emacs "31.1")
    (lgr   "0.1.0"))
  :url "https://github.com/thkoch2001/rau"
  :commit "174229a92f5464b1d46a48da18cf35c85cca8505"
  :revdesc "174229a92f54"
  :keywords '("frames")
  :authors '(("Thomas Koch" . "thomas@koch.ro"))
  :maintainers '(("Thomas Koch" . "thomas@koch.ro")))
