;;; rau.el --- Wayland Window Manager based on River -*- lexical-binding: t -*-

;; Copyright (C) 2026 Thomas Koch

;; Author: Thomas Koch <thomas@koch.ro>
;; Package-Version: 0.3
;; Package-Revision: 174229a92f54
;; Keywords: frames
;; URL: https://github.com/thkoch2001/rau
;; Package-Requires: ((emacs "31.1")
;;                    (lgr "0.1.0"))

;;; Commentary:
;; Rau is a Wayland Window Manager based on Emacs and River in pure Elisp.  The
;; heavy lifting is provided by River, written in Zig and thus fast while the
;; opinionated parts like Window placement, Keybindings and Focus management
;; are written in Elisp and are thus easy to customize.

;;; History:
;; This package is based on <https://codeberg.org/tazjin/reka>. The major
;; difference is that reka uses Rust code to bind to libwayland while rau uses
;; the ewc.el library of Michael Bauer to implement wayland communication.

;;; SPDX-License-Identifier: GPL-3.0-or-later

;;; Code:

(require 'cl-lib)
(require 'ewc)
(require 'lgr)
(require 'map)          ; needed for `map' pcase pattern
(require 'pcase)
(require 'seq)
(require 'subr-x)


;;; Configuration and state

(defgroup rau nil
  "Rau - Emacs swimming in the river."
  :group 'environment
  :prefix "rau-")

(defcustom rau-ready-hook nil
  "Hook run when rau is ready.  At the moment this means that all global
Wayland objects have been registered."
  :type 'hook)

(defvar rau--lgr nil
  "lgr instance for rau, assigned in rau-enable.")

(defvar rau--state nil
  "Current global rau WM state.")

(defvar rau--fe-state nil
  "Current global rau WM front-end state.")

;;; State structs

(cl-defstruct (rau--output (:constructor rau--output-make))
  "State for a River output."
  (dimensions '(0 . 0))
  ;; emacs frame-id
  (frame-id nil)
  (fullscreen-window-wl nil :type (or null ewc-object))
  (ls-output-wl nil :type ewc-object)
  (position '(0 . 0)))

(cl-defstruct (rau--ls-output (:constructor rau--ls-output-make))
  "State for a River output."
  (output-wl nil :type ewc-object)
  (non-excl-position '(0 . 0))
  (non-excl-dimensions '(0 . 0)))

(defconst rau--tag-outputframe :rau--frame
  "Tag for `river-window-v1' objects that are Emacs frames.")

(defconst rau--tag-external :rau--external
  "Tag for `river-window-v1' objects that are external windows.")

(defconst rau--tag-floating :rau--floating
  "Tag for `river-window-v1' objects that are floating.")

(cl-defstruct (rau--window (:constructor rau--window-make))
  "State for a River window."
  actual-dimensions
  app-id
  (dimensions-hint-max '(0 . 0))
  (dimensions-hint-min '(0 . 0))
  ;; edges only for external, tiled windows
  edges
  ;; emacs frame-id, either the own for emacs output frame or of the
  ;; containing frame for tiled external window
  frame-id
  (node-wl nil :type ewc-object)
  parent-wl
  pid
  title)

(cl-defstruct (rau--seat (:constructor rau--seat-make))
  "State for a River seat."
  (ls-seat-wl nil :type ewc-object))

(cl-defstruct (rau--binding (:constructor rau--binding-make))
  "State for one global XKB binding."
  event
  key
  keysym
  modifiers
  needs-focus
  layout
  allow-when-locked)

(cl-defstruct (rau--state (:constructor rau--state-make))
  "Holds the state of the rau Wayland client."
  (client nil :type ewc-client)
  session-locked

  ;;; Focus tracking.
  ;; id of ewc-object for which the last focus request was sent
  ;; This could be a focus_window or a focus_shell_surface request
  (focus-last-id -1)

  ;; task queue: list of (FN ARGS...).
  ;; TODO: move to rau--fe-state
  task-queue
  task-timer

  manage-dirty-timer

  ;; manage queue: list of (ewc-object 'request args) for the next manage
  ;; cycle
  manage-queue)

(cl-defstruct (rau--fe-state (:constructor rau--fe-state-make))
  last-send-state
  )

(ewc-define-data-accessors rau--output)
(ewc-define-data-accessors rau--ls-output)
(ewc-define-data-accessors rau--window)
(ewc-define-data-accessors rau--seat)
(ewc-define-data-accessors rau--binding)

;;; Data access helpers

(defun rau--outframe-wl-output-wl (frame-wl)
  (when-let* ((frame-id (rau--window-wl-frame-id frame-wl))
              (client (rau--state-client rau--state)))
    (cl-find frame-id
             (ewc-objects client 'river-output-v1)
             :key #'rau--output-wl-frame-id)))

(defun rau--frame-wl-for-extwin-wl (window-wl)
  "Return the Emacs outputframe window-wl displaying external
WINDOW-WL."
  (when-let* ((client (rau--state-client rau--state))
              (outputframes (ewc-objects client rau--tag-outputframe))
              (frame-id (rau--window-wl-frame-id window-wl)))
    (cl-loop for frame-wl in outputframes
             if (eq frame-id (rau--window-wl-frame-id frame-wl))
             return frame-wl)))

(defun rau--dimensions-for-window-wl (window-wl)
  (pcase-let (((and edges `(,left ,top ,right ,bottom))
               (rau--window-wl-edges window-wl)))
    (when (and edges (all 'integerp edges))
      `(,(- right left) . ,(- bottom top)))))

(defun rau--dimensions-for-outputframe (output-wl)
  "Get dimensions from output-wl or its ls-output-wl non-exclusive-area."
  (if-let* ((ls-output-wl (rau--output-wl-ls-output-wl output-wl))
            (non-excl-dimensions (rau--ls-output-wl-non-excl-dimensions ls-output-wl))
            ((not (equal '(0 . 0) non-excl-dimensions))))
      non-excl-dimensions
    (rau--output-wl-dimensions output-wl)))

(defun rau--position-for-outputframe (output-wl)
  "Get position from output-wl or its ls-output-wl non-exclusive-area."
  (if-let* ((ls-output-wl (rau--output-wl-ls-output-wl output-wl))
            (non-excl-position (rau--ls-output-wl-non-excl-position ls-output-wl))
            ((not (equal '(0 . 0) non-excl-position))))
      non-excl-position
    (rau--output-wl-position output-wl)))

(defun rau--window-id-for-emacs-window (emacs-window)
  "Return window-wl for any EMACS-WINDOW rau-mode or not.
For a window with a rau-mode buffer return window-wl pointing to an
external window. For all other buffers return the window-wl of the emacs
frame."
  (if-let* ((buffer (window-buffer emacs-window))
            (window-id (buffer-local-value 'rau--window-id buffer)))
      window-id
    (let ((emacs-frame (window-frame emacs-window)))
      (frame-parameter emacs-frame 'rau--window-id))))

(defun rau--buffer-for-window-id (window-id)
  (cl-find window-id
           (buffer-list)
           :key (lambda (b) (buffer-local-value 'rau--window-id b))))

(defun rau--emacs-window-for-window-id (window-id)
  "Return Emacs window associated with WINDOW-WL."
  (when-let* ((buffer (rau--buffer-for-window-id window-id)))
    (get-buffer-window buffer 'visible)))

;;; Emacs integration, interaction

(defun rau--make-outputframe-parameters ()
  "Return alist of frame parameters with unique name as expected by title
event handler."
  `((name . ,(make-temp-name "rau-frame-"))
    (undecorated . t)
    (window-system . pgtk)
    ;; avoid showing the same rau buffer twice
    (buffer-predicate . rau--buffer-predicate)))

(defun rau--make-buffer-name (app-id title)
  "Return a buffer name string using APP-ID and TITLE."
  (let ((title-trunc (if (> (length title) 40)
                         (format "%s…" (substring title 0 40))
                       title)))
    (if app-id (concat title-trunc " - " app-id)
      title-trunc)))

;; Major mode for rau-managed buffers
(defvar-local rau--window-id nil
  "Wayland window id for this `rau-mode' buffer.")

(define-derived-mode rau-mode special-mode "Rau"
  "Major mode for buffers representing windows managed by rau."
  :group 'rau
  (setq-local buffer-read-only t)
  (add-hook 'kill-buffer-query-functions #'rau--buffer-killed nil t)
  (scroll-bar-mode 0)
  (setq-local left-fringe-width 0
              right-fringe-width 0))

;;; Protocol loading

(eval-and-compile
  (defconst rau--protocol-basenames
    '(("wayland" wl-display wl-registry)
      "river-window-management-v1"
      "river-xkb-bindings-v1"
      "river-layer-shell-v1")
    "Wayland protocols used by rau.")

  (defun rau--protocol-dir ()
    "Return the protocol directory next to the rau.el source.
The location is resolved relative to rau.el itself, not the file that
happens to be loading, so `rau--read-protocols' expands correctly even
when used from other files (e.g. tests)."
    (let* ((rau-file
            (cond
             ;; rau.el is currently being loaded.
             ((and load-file-name
                   (member (file-name-nondirectory load-file-name)
                           '("rau.el" "rau.elc")))
              load-file-name)
             ;; rau.el is currently being byte-compiled.
             ((and (bound-and-true-p byte-compile-current-file)
                   (member (file-name-nondirectory byte-compile-current-file)
                           '("rau.el" "rau.elc")))
              byte-compile-current-file)
             ;; Expansion originates from some other file: find rau.el
             ;; on the load path.
             (t
              (or (locate-file "rau" load-path '(".el" ".elc"))
                  (error "Rau: cannot locate rau.el; add its directory to `load-path'")))))
           (rau-dir (file-name-directory (expand-file-name rau-file))))
      (expand-file-name "protocol" rau-dir)))

  (defun rau--protocol-file (basename)
    "Return the absolute XML file path for protocol BASENAME."
    (expand-file-name (concat basename ".xml")
                      (rau--protocol-dir)))

  (defmacro rau--read-protocols ()
  "Expand to an `ewc-read' form with protocol paths and interface filters."
  `(ewc-read
    ,@(mapcar
       (lambda (spec)
         (let ((spec (ensure-list spec)))
           (cons (rau--protocol-file (car spec))
                 (cdr spec))))
       rau--protocol-basenames))))

(defconst rau--global-binds
  '("river_window_manager_v1"
    "river_xkb_bindings_v1"
    "river_layer_shell_v1")
  "Wayland globals that rau binds.")

(defconst rau--edges-all 15
  "River Edges::all() bitmask.")

;;; Basic helpers

(defvar rau--propagate-errors nil
  "See rau--condition-case.")

(defmacro rau--condition-case (location &rest body)
  "Wrap BODY in a condition-case unless `rau--propagate-errors' is non-nil.
LOCATION identifies where the error occurred."
  `(if rau--propagate-errors
       (progn ,@body)
     (condition-case err
         (progn ,@body)
       (error (message "Error at %s: %S" ,location err)))))

(cl-defmacro rau--do (tag obj state &body body)
  "Iterate over the ewc objects in STATE tagged with TAG.
TAG is a form that evaluates to or is an ewc-object tag, for example
`rau--tag-external', `rau--tag-outputframe', or `'river-output-v1'.

STATE is evaluated once and bound to that same name within BODY."
  (declare (indent 1))
  (unless (symbolp state)
    (error "rau--do: STATE slot must be a symbol, got: %S" state))
  `(let ((,state ,state))
     (dolist (,obj (ewc-objects (rau--state-client ,state) ,tag))
       ,@body)))

(defun rau--remove (object-wl)
  "Remove object from ewc objects table.
See also `rau-on-wl-display-delete-id'."
  (ewc-object-remove (rau--state-client rau--state) object-wl))

(defun rau--request (object-wl request &optional arguments)
  "Send REQUEST on OBJECT-WL (or id) using the current rau Wayland client."
  (let* ((client (rau--state-client rau--state))
         (o
          (if (ewc-object-p object-wl)
              object-wl
            (ewc-object-get client object-wl))))
    (ewc-request client o request arguments)))

;;; task queue
(defun rau--tasks-execute ()
  "Execute tasks enqueued by event listeners."
  (let ((tasks (nreverse (rau--state-task-queue rau--state))))
    (setf (rau--state-task-queue rau--state) nil)
    (while-let ((task (pop tasks)))
      (let ((fn (car task))
            (args (cdr task)))
        (rau--condition-case
         (format "task %s" fn)
         (apply fn args))))))

(defun rau--tasks-schedule-execution ()
  "Schedule task processing if not already scheduled."
  (unless (rau--state-task-timer rau--state)
    (setf (rau--state-task-timer rau--state)
          (run-at-time
           0 nil
           (lambda ()
             (setf (rau--state-task-timer rau--state) nil)
             (rau--tasks-execute))))))

(defun rau--tasks-enqueue (fn &rest args)
  "Queue FN with ARGS for execution by rau--tasks-execute.
Also schedule the task execution timer if not yet done so.  Only to be
used in event listeners."
  (push `(,fn . ,args) (rau--state-task-queue rau--state))
  (rau--tasks-schedule-execution))

(defun rau--task-assign-emacs-frame (output-id)
  "Find initial frame or create one and set OUTPUT-ID in frame-parameter."
  (let ((emacs-frame
         (or
          ;; search the initial frame
          (cl-loop for f in (frame-list)
                   for name = (frame-parameter f 'name)
                   for is_rau_frame = (string-prefix-p "rau-frame-" name)
                   for is_assigned = (frame-parameter f 'rau--output-id)
                   if (and is_rau_frame (not is_assigned)) return f)
          (make-frame (rau--make-outputframe-parameters)))))
    (set-frame-parameter emacs-frame 'rau--output-id output-id))
  (rau--send-fe-ui-state))

(defun rau--task-delete-frame (frame-id)
  "Delete frame by FRAME-ID."
  (lgr-info rau--lgr "task delete frame with frame-id %S" frame-id)
  (when-let* ((emacs-frame (frame-by-id frame-id)))
    (delete-frame emacs-frame)))

(defun rau--task-kill-buffer (window-id)
  "Remove kill inhibiting hook and kill."
  (when-let* ((buffer (rau--buffer-for-window-id window-id)))
    (with-current-buffer buffer
      (remove-hook 'kill-buffer-query-functions #'rau--buffer-killed t))
    (kill-buffer buffer)))

(defun rau--task-link-emacs-frame-to-window (title window-id)
  (let ((emacs-frame
         (cl-find title (frame-list)
                  :test #'equal
                  :key (lambda (f) (frame-parameter f 'name)))))
    (unless emacs-frame
      (error "No emacs frame found for wayland window. id=%d title=%s." window-id title))

    (set-frame-parameter emacs-frame 'rau--window-id window-id)
    (rau--send-fe-ui-state)))

(defun rau--task-minimize-window (window-id)
  (when-let* ((buffer (rau--buffer-for-window-id window-id)))
    (bury-buffer buffer)))

(defun rau--task-rename-buffer (window-id name)
  "Rename buffer for external window with data taken from
WINDOW-WL."
  (when-let* ((buffer (rau--buffer-for-window-id window-id)))
    (with-current-buffer buffer
      (rename-buffer name t))))

(defun rau--task-setup-new-external-window (window-id)
  "Create Rau mode buffer for WINDOW-WL."
  (let ((buffer (get-buffer-create (make-temp-name "rau-external-")))
        (window-wl (ewc-object-get (rau--state-client rau--state) window-id)))
    (with-current-buffer buffer
      (rau-mode)
      (setq-local rau--window-id window-id)
      (unless (display-buffer buffer)
        (error "display-buffer failed for window %d buffer %S." window-id buffer)))))

(defun rau--task-consume-key-event (event needs-focus)
  "Forward EVENT to emacs and setup to recover focus if NEEDS-FOCUS."
  (push (cons t event) unread-command-events)
  (when needs-focus
    (add-hook 'post-command-hook #'rau--recover-focus-after-binding-pressed)))

;;; Manage cycle preparation

(defun rau--mark-manage-dirty ()
  "Mark that a new manage sequence is needed."
  (unless (rau--state-manage-dirty-timer rau--state)
    (setf (rau--state-manage-dirty-timer rau--state)
          (run-at-time
           0 nil
           (lambda ()
             (setf (rau--state-manage-dirty-timer rau--state) nil)
             (rau--condition-case
              "request-manage-dirty"
              (when-let* ((client (rau--state-client rau--state))
                          (wm-wl (ewc-first-object client
                                                   'river-window-manager-v1)))
                (rau--request wm-wl 'manage-dirty))))))))

(defun rau--manage-enqueue (ewc-object request &optional args)
  "Enqueue REQUEST on EWC-OBJECT (or id) with ARGS for next manage cycle."
  (push `(,ewc-object ,request ,args) (rau--state-manage-queue rau--state))
  (rau--mark-manage-dirty))

;;; Focus

(defun rau--request-focus (target-wl &optional force)
  "Request focus for TARGET-WL.
Queues the focus-window request and updates Emacs state.  If FORCE is
non-nil, bypass the comparission with focus-last-id from rau--state for
situations where focus changed without us knowing (session-lock, layer surface)."
  (when-let* ((target-id (ewc-object-id target-wl))
              ((or force
                   (not (eq target-id (rau--state-focus-last-id rau--state)))))
              (client (rau--state-client rau--state))
              (seat-wl (ewc-first-object client 'river-seat-v1)))
    (lgr-debug rau--lgr "request focus-window id=%d title=%s"
               target-id
               (rau--window-wl-title target-wl))

    ;; Queue the actual Wayland focus request
    (rau--manage-enqueue seat-wl 'focus-window `((window . ,target-id)))
    (setf (rau--state-focus-last-id rau--state) target-id)

    ;; Queue the layer-shell default output update
    (when-let* ((frame-wl (if (ewc-object-tagged-p target-wl rau--tag-external)
                              (rau--frame-wl-for-extwin-wl target-wl)
                            target-wl))
                (output-wl (rau--outframe-wl-output-wl frame-wl))
                (ls-output-wl (rau--output-wl-ls-output-wl output-wl)))
      (rau--manage-enqueue ls-output-wl 'set-default))

    ;; Let Emacs select the underlying emacs-window for the external window
    (when-let* (((ewc-object-tagged-p target-wl rau--tag-external))
                (emacs-window (rau--emacs-window-for-window-id target-id)))
      (select-window emacs-window 'norecord))))

(defun rau--request-focus-by-id (&optional target-id force)
  "Request focus for the window with TARGET-ID or the last focused.
See `rau--request-focus' for details on FORCE."
  (let ((id (or target-id (rau--state-focus-last-id rau--state))))
    (when-let* (id
                ((not (equal -1 id)))
                (client (rau--state-client rau--state))
                (target-wl (ewc-object-get client id)))
      (rau--request-focus target-wl force))))

;;; Keybindings

(defconst rau--modifier-bits
  '((shift   . 1)
    (control . 4)
    (meta    . 8)
    (super   . 64)
    (hyper   . 128))
  "Modifier bits as per river_seat_v1.modifiers / XKB.")

(defun rau--key-to-xkb (key-string)
  "Decompose KEY-STRING into (EVENT KEY MODIFIERS)."
  (let* ((event (aref (kbd key-string) 0))
         (basic (event-basic-type event))
         (mods (seq-keep (lambda (mod)
                           (alist-get mod rau--modifier-bits))
                         (event-modifiers event)))
         (key (if (characterp basic) basic (symbol-name basic))))
    (list event key (apply #'logior mods))))

(defun rau--parse-keys (keys)
  "Parse KEYS into a list of rau--binding structs. See `rau-bind-keys'."
  (let ((seen (make-hash-table :test #'equal))
        (result nil))
    (dolist (item keys)
      (let ((elements (if (stringp item) (list item) item))
            keys flags)
        (while-let ((elt (pop elements)))
          (cond
           ((stringp elt)
            (push elt keys))
           ((eq :layout elt)
            (unless elements
              (error ":layout requires a layout number"))
            (push (cons elt (pop elements)) flags))
           ((memq elt '(:needs-focus :allow-when-locked))
            (push (cons elt t) flags))
           ((keywordp elt)
            (error "unknown flag %S" elt))
           (t
            (error "Unexpected element in key binding spec: %S" elt))))
        (dolist (key keys)
          (when (gethash key seen)
            (error "Duplicate key binding: %s" key))
          (puthash key t seen)
          (let ((xkb (rau--key-to-xkb key)))
            (push (rau--binding-make
                   :event (cl-first xkb)
                   :key key
                   :keysym (rau--resolve-keysym (cl-second xkb))
                   :modifiers (cl-third xkb)
                   :needs-focus   (cdr (assq :needs-focus flags))
                   :allow-when-locked (cdr (assq :allow-when-locked flags))
                   :layout        (cdr (assq :layout flags)))
                  result)))))
    (nreverse result)))

(defvar rau--xkb-keysym-alist
  '(("iso-lefttab" . #xFE20)
    ("return" . #xFF0D)
    ("escape" . #xFF1B)
    ("backspace" . #xFF08)
    ("tab" . #xFF09)
    ("space" . #x020)
    ("delete" . #xFFFF)
    ("home" . #xFF50)
    ("left" . #xFF51)
    ("up" . #xFF52)
    ("right" . #xFF53)
    ("down" . #xFF54)
    ("prior" . #xFF55)
    ("pageup" . #xFF55)
    ("next" . #xFF56)
    ("pagedown" . #xFF56)
    ("end" . #xFF57)
    ("insert" . #xFF63)
    ("begin" . #xFF58)
    ("select" . #xFF60)
    ("print" . #xFF61)
    ("execute" . #xFF62)
    ("pause" . #xFF13)
    ("scroll" . #xFF14)
    ("sysrq" . #xFF15)
    ("f1" . #xFFBE)
    ("f2" . #xFFBF)
    ("f3" . #xFFC0)
    ("f4" . #xFFC1)
    ("f5" . #xFFC2)
    ("f6" . #xFFC3)
    ("f7" . #xFFC4)
    ("f8" . #xFFC5)
    ("f9" . #xFFC6)
    ("f10" . #xFFC7)
    ("f11" . #xFFC8)
    ("f12" . #xFFC9)
    ("xf86monbrightnessup"   . #x1008FF02)
    ("xf86monbrightnessdown" . #x1008FF03)
    ("audioraisevolume" . #x1008FF13)
    ("audiolowervolume" . #x1008FF11)
    ("audiomute"        . #x1008FF12)
    ("audioplay"        . #x1008FF14)
    ("audiostop"        . #x1008FF15)
    ("audiopause"       . #x1008FF31)
    ("audionext"        . #x1008FF17)
    ("audioprev"        . #x1008FF16)
    ("homepage"  . #x1008FF18)
    ("mail"      . #x1008FF19)
    ("search"    . #x1008FF1B)
    ("favorites" . #x1008FF30)
    ("launcha"   . #x1008FF52)
    ("explorer"  . #x1008FF5D)
    ("display"   . #x1008FF85)
    ("tools"     . #x1008FF89)
    ("wlan"      . #x1008FF95)
    ("audiomicmute" . #x1008FFB2)
    )
  "Small fallback table mapping key names to XKB keysyms. See
X11/XF86keysym.h.")

(defun rau--utf32-to-keysym (cp)
  "Convert Unicode codepoint CP to an XKB keysym."
  (cond
   ((not (integerp cp)) 0)
   ((and (>= cp #x20) (<= cp #x7e)) cp)
   ((and (>= cp #xa0) (<= cp #xff)) cp)
   ((> cp 0) (+ #x01000000 cp))
   (t 0)))

(defun rau--resolve-keysym (key)
  "Resolve KEY to an XKB keysym.
KEY may be an integer codepoint, a symbol, or a string key name."
  (cond
   ((integerp key)
    (rau--utf32-to-keysym key))

   ((symbolp key)
    (rau--resolve-keysym (symbol-name key)))

   ((stringp key)
    (or (and (length= key 1)
             (rau--utf32-to-keysym (aref key 0)))
        (alist-get (downcase key)
                   rau--xkb-keysym-alist
                   nil nil #'equal)
        (user-error "Could not resolve %s to an XKB keysym" key)))
   (t (error "Key should be an integer, symbol or string"))))

(defun rau--bind-parsed-keys (parsed-keys)
  "Actually bind PARSED-KEYS.  See `rau-bind-keys' for the public function."
  (when-let* ((client (rau--state-client rau--state))
              (xkb-bindings-wl (ewc-first-object client 'river-xkb-bindings-v1))
              (seat-wl (ewc-first-object client 'river-seat-v1))
              (seat-id (ewc-object-id seat-wl))
              )
    (let ((existing-bindings
           (mapcar #'ewc-object-data (ewc-objects client 'river-xkb-binding-v1))))
      (dolist (binding parsed-keys)
        (dolist (existing existing-bindings)
          (message "binding: %S" binding)
          (message "existing: %S" existing)
          (when (or (equal (rau--binding-key binding)
                           (rau--binding-key existing))
                    (and
                     (equal (rau--binding-keysym binding)
                            (rau--binding-keysym existing))
                     (equal (rau--binding-modifiers binding)
                            (rau--binding-modifiers existing))))
            (error "Key binding %s already exists: %s"
                   (rau--binding-key binding)
                   (rau--binding-key existing))))
        (let ((binding-wl (ewc-object-add client 'river-xkb-binding-v1)))
          (setf (ewc-object-data binding-wl) binding)
          (rau--request xkb-bindings-wl 'get-xkb-binding
                        `((seat . ,seat-id)
                          (keysym . ,(rau--binding-keysym binding))
                          (modifiers . ,(rau--binding-modifiers binding))
                          (id . ,(ewc-object-id binding-wl))))
          (when-let* ((layout (rau--binding-layout binding)))
            (rau--manage-enqueue
             binding-wl
             'set-layout-override
             `((layout . ,layout))))
          (rau--manage-enqueue
           binding-wl
           'enable))))))

(defun rau-bind-keys (keys)
  "Bind KEYS to always be sent to Emacs.  KEYS is a list either of strings
acceptable to `kbd' or of lists of strings and one or more of the
following keywords:

- :allow-when-locked - keys are also active when the session is locked,
   e.g. Volume or Brightness control
- :needs-focus - focus should be temporarily given to Emacs
- :layout LAYOUT-NR - 0 indexed layout override

Example:

(\"s-e\" \"s-f\"
  (\"s-d\" \"C-h\" :needs-focus)
  (:allow-when-locked \"M-x\" :needs-focus)
  (:allow-when-locked \"s-c\" \"s-z\" :layout 2))

This function should be run from the `rau-ready-hook'."
  (unless rau--state
    (error "Rau has not yet been started."))
  (let ((parsed-keys (rau--parse-keys keys)))
    (rau--bind-parsed-keys parsed-keys)))

(defun rau--global-unset-key-if (key command)
  "Unset KEY in the global map if it is currently bound to COMMAND."
  (when-let* ((kbd-key (kbd key))
              ((eq (lookup-key global-map kbd-key) command)))
    (global-unset-key kbd-key)))

;;; Emacs handler functions for hooks

(defun rau--focus-change-allowed-p ()
  "Non-nil when no interactive command or edit is in progress."
  (and (not this-command)
       (length= unread-command-events 0)
       (length= (this-single-command-keys) 0)
       (zerop (minibuffer-depth))
       (zerop (recursion-depth))))

(defun rau--update-focus-request (&rest args)
  "Reconcile Wayland focus with the selected window."
  (lgr-debug rau--lgr "update-focus-request %S" args)
  (when-let* (((rau--focus-change-allowed-p))
              (emacs-window (selected-window))
              (target-id (rau--window-id-for-emacs-window emacs-window)))
    (rau--request-focus-by-id target-id)))

(defun rau--recover-focus-after-binding-pressed ()
  "Give focus back to external window after it was given to Emacs to handle
a keybinding pressed event. This function is meant to be bound to
post-command-hook in the enqueued command of the pressed event handler."
  (lgr-debug rau--lgr "recover focus. not t-c=%S u-c-e=%d t-s-c-k=%d m-d=%d r-d=%d"
             (not this-command)
             (length unread-command-events)
             (length (this-single-command-keys))
             (minibuffer-depth)
             (recursion-depth))
  (when (and (length= unread-command-events 0)
             (zerop (minibuffer-depth))
             (zerop (recursion-depth)))
    (lgr-debug rau--lgr "recover focus. removing post-command-hook.")
    (remove-hook 'post-command-hook #'rau--recover-focus-after-binding-pressed)
    (when-let* ((window-id (buffer-local-value 'rau--window-id (current-buffer)))
                ((/= window-id (rau--state-focus-last-id rau--state))))
      (lgr-debug rau--lgr "recover focus. focusing window-id=%d title=%s"
                 window-id
                 (buffer-name))
      (rau--request-focus-by-id window-id))))

(defun rau--buffer-killed ()
  "Request closing of the associated Wayland window when a rau buffer is killed."
  (when rau--window-id
    (rau--manage-enqueue rau--window-id 'close)
    (rau--mark-manage-dirty)
    nil))

(defun rau--window-configuration-change-handler ()
  "Schedule a river manage cycle and thus a reconciliation cycle.
This is necessary for external windows to resize when the minibuffer
expands.  This needs to be added to the global hook since local hooks
don't get called for windows that disappear.  Also
window-size-change-functions does not get called when minibuffer expands
and thus minibuffer ends up below external window."
  (rau--mark-manage-dirty))


;;; Other Emacs config functions: advices, predicates

(defun rau--buffer-predicate (buffer)
  "Buffer predicate to avoid accidentally showing the same rau BUFFER twice."
  (or (not (with-current-buffer buffer (derived-mode-p 'rau-mode)))
      (not (get-buffer-window buffer t))))

(defun rau--split-window-advice (new-window)
  "Advice window splits to always display another buffer."
  (with-selected-window new-window
    (with-current-buffer (window-buffer)
      (when (derived-mode-p 'rau-mode)
        (switch-to-buffer (other-buffer)))))
  new-window)

(defun rau--set-window-buffer-advice (orig win buf &rest r)
  "Avoid double-display of rau buffers, by stealing them.
Note that displaying the same buffer in two different tabs, for example,
is completely valid."
  (with-current-buffer buf
    (when (derived-mode-p 'rau-mode)
      (dolist (other (get-buffer-window-list buf nil 'visible))
        (unless (eq (or win (selected-window)) other)
          (with-selected-window other
            (switch-to-buffer (other-buffer)))))))
  (apply orig win buf r))

;;; Fullscreen toggle

(defun rau--fullscreen-exit (window-wl output-wl)
  "Exit fullscreen for WINDOW-WL on OUTPUT-WL.
Also resets the fullscreen-window-wl slot of OUTPUT-WL to nil.  When
switching fullscreen between windows, call this before
`rau--fullscreen-enter'."
  (rau--manage-enqueue window-wl 'inform-not-fullscreen)
  (rau--manage-enqueue window-wl 'exit-fullscreen)
  (when-let* ((dimensions (rau--dimensions-for-window-wl window-wl)))
    (rau--manage-enqueue window-wl 'propose-dimensions
                         `((width . ,(car dimensions))
                           (height . ,(cdr dimensions)))))
  (setf (rau--output-wl-fullscreen-window-wl output-wl) nil))

(defun rau--fullscreen-enter (window-wl output-wl)
  "Enter fullscreen for WINDOW-WL on OUTPUT-WL."
  (rau--manage-enqueue window-wl 'inform-fullscreen)
  (rau--manage-enqueue window-wl 'fullscreen
                       `((output . ,(ewc-object-id output-wl))))
  (setf (rau--output-wl-fullscreen-window-wl output-wl) window-wl))

(defun rau-toggle-fullscreen ()
  "Toggle fullscreen for the currently focused external window."
  (interactive)
  (if-let* ((window-id (buffer-local-value 'rau--window-id (current-buffer)))
            (window-wl (ewc-object-get (rau--state-client rau--state) window-id))
            (frame-wl (rau--frame-wl-for-extwin-wl window-wl))
            (output-wl (rau--outframe-wl-output-wl frame-wl)))
      (let ((current-fs (rau--output-wl-fullscreen-window-wl output-wl)))
        (if current-fs
            (rau--fullscreen-exit current-fs output-wl)
          (rau--fullscreen-enter window-wl output-wl)))
    (message "Fullscreen requested, but nothing is focused")))

;;; Layer shell attachment helpers

(defun rau--ensure-ls-output (output-wl)
  "Create a layer-shell output object for OUTPUT-WL if possible."
  (when-let* (((null (rau--output-wl-ls-output-wl output-wl)))
              (client (rau--state-client rau--state))
              (ls-wl (ewc-first-object client 'river-layer-shell-v1))
              (ls-output-wl
               (ewc-object-add client 'river-layer-shell-output-v1)))
    (setf (rau--output-wl-ls-output-wl output-wl) ls-output-wl
          (ewc-object-data ls-output-wl) (rau--ls-output-make :output-wl output-wl))
    (rau--request ls-wl 'get-output
                  `((id . ,(ewc-object-id ls-output-wl))
                    (output . ,(ewc-object-id output-wl))))))

(defun rau--ensure-ls-seat (seat-wl)
  "Create a layer-shell seat object for the current seat if possible."
  (when-let* (((null (rau--seat-wl-ls-seat-wl seat-wl)))
              (client (rau--state-client rau--state))
              (ls-wl (ewc-first-object client 'river-layer-shell-v1))
              (ls-seat-wl
               (ewc-object-add client 'river-layer-shell-seat-v1)))
    (setf (rau--seat-wl-ls-seat-wl seat-wl) ls-seat-wl)
    (rau--request ls-wl 'get-seat
                   `((id . ,(ewc-object-id ls-seat-wl))
                     (seat . ,(ewc-object-id seat-wl))))
    (rau--tasks-enqueue #'run-hooks 'rau-ready-hook)))

;;; Listeners

;; Order event listeners by their order in the protocol definitions!

;;;; wayland protocol
;;;; wl-display listeners
(defun rau--on-wl-display-error (_display-wl args)
  (pcase-let (((map object-id code message) args))
    (message "wl_display error: object-id=%d code=%d message=%s"
             object-id
             code
             (ewc-to-utf8 message))
    (when-let* ((client (rau--state-client rau--state))
                (object (ewc-object-get client object-id)))
      (message "object id=%d interface=%s tags=%S"
               object-id
               (ewc-object-interface object)
               (ewc-object-tags object)))))

(defun rau--on-wl-display-delete-id (_display-wl args)
  "Server acknowledges deletion of object created by client.
Note that server does not send this event for objects created by
server (e.g. window, output). Thus object removal must be done at the
point where also the destroy request is sent."
  (pcase-let (((map id) args)
              (client (rau--state-client rau--state)))
    (ewc-object-remove-id client id)))

;;;; wl-registry listeners
(defun rau--on-wl-registry-global (registry-wl args)
  (pcase-let (((map name interface version) args))
    (when-let* ((ifsym (intern (string-replace "_" "-" interface)))
                (client (rau--state-client rau--state))
                ((member interface rau--global-binds))
                (xml-version (ewc-interface-version client ifsym))
                (bind-version
                 (if xml-version (min version xml-version) version))
                (global (ewc-object-add client ifsym)))

      (lgr-debug rau--lgr "rau: binding global %s version %s" interface bind-version)
      (rau--request registry-wl 'bind
                     `((name . ,name)
                       (interface-len . ,(1+ (string-bytes interface)))
                       (interface . ,interface)
                       (version . ,bind-version)
                       (id . ,(ewc-object-id global))))
      (pcase ifsym
        ('river-layer-shell-v1
         ;; Attach layer-shell objects to existing outputs/seats in STATE."
         (rau--do 'river-output-v1 output-wl rau--state
                  (rau--ensure-ls-output output-wl))
         (rau--do 'river-seat-v1 seat-wl rau--state
                   (rau--ensure-ls-seat seat-wl)))))))

;;;; river-window-management-v1 Protocol
;;;; river-window-manager-v1 listeners
(defun rau--on-river-window-manager-v1-unavailable (_wm-wl _)
  (message "rau: WM event unavailable"))

(defun rau--on-river-window-manager-v1-finished (_wm-wl _)
  (message "rau: WM event finished"))

(defun rau--on-river-window-manager-v1-manage-start (wm-wl _)
  (rau--tasks-enqueue #'rau--manage-queue-send)
  (rau--tasks-enqueue #'rau--reconcile-frames)
  (rau--tasks-enqueue #'rau--reconcile-windows)

  (rau--tasks-enqueue #'rau--request wm-wl 'manage-finish))

(defun rau--on-river-window-manager-v1-render-start (wm-wl _)
  (rau--tasks-enqueue #'rau--render-frames)
  (rau--tasks-enqueue #'rau--render-windows)
  (rau--tasks-enqueue #'rau--request wm-wl 'render-finish))

(defun rau--on-river-window-manager-v1-session-locked (_wm-wl _)
  (setf (rau--state-session-locked rau--state) t))

(defun rau--on-river-window-manager-v1-session-unlocked (_wm-wl _)
  (setf (rau--state-session-locked rau--state) nil)
  (rau--request-focus-by-id nil t))

(defun rau--on-river-window-manager-v1-window (_wm-wl args)
  (pcase-let* (((map id) args)
               (client (rau--state-client rau--state))
               (window-wl (ewc-object-add client
                                          'river-window-v1
                                          id))
               (node-wl (ewc-object-add client 'river-node-v1))
               (window-data (rau--window-make :node-wl node-wl)))
    (setf (ewc-object-data window-wl) window-data)
    (rau--request window-wl 'get-node
                  `((id . ,(ewc-object-id node-wl))))))

(defun rau--on-river-window-manager-v1-output (_wm-wl args)
  (pcase-let* (((map id) args)
               (client (rau--state-client rau--state))
               (output-wl (ewc-object-add client 'river-output-v1 id)))
    (setf (ewc-object-data output-wl) (rau--output-make))
    (rau--tasks-enqueue #'rau--task-assign-emacs-frame id)
    (rau--ensure-ls-output output-wl)))

(defun rau--on-river-window-manager-v1-seat (_wm-wl args)
  (pcase-let (((map id) args)
              (client (rau--state-client rau--state)))
    (if (ewc-first-object client 'river-seat-v1)
        (message "rau does not support multi-seat")
      (let* ((seat-wl (ewc-object-add client 'river-seat-v1 id)))
        (setf (ewc-object-data seat-wl) (rau--seat-make))
        (rau--ensure-ls-seat seat-wl)))))

;;;; river-window-v1 listeners
(defun rau--on-river-window-v1-closed (window-wl _)
  (when-let* (((ewc-object-tagged-p window-wl rau--tag-external)))
    (rau--tasks-enqueue #'rau--task-kill-buffer (ewc-object-id window-wl)))
  (when-let* ((node-wl (rau--window-wl-node-wl window-wl)))
    (rau--tasks-enqueue #'rau--request node-wl 'destroy))
  (rau--tasks-enqueue #'rau--request window-wl 'destroy)
  (rau--tasks-enqueue #'rau--remove window-wl)

  ;; Reset fullscreen on output if window was fullscreen.
  (when (ewc-object-tagged-p window-wl rau--tag-external)
    (rau--do 'river-output-v1 output-wl rau--state
      (when (eq (rau--output-wl-fullscreen-window-wl output-wl) window-wl)
        (setf (rau--output-wl-fullscreen-window-wl output-wl) nil)))))

(defun rau--on-river-window-v1-dimensions-hint (window-wl args)
  (pcase-let (((map min-width min-height max-width max-height) args))
    (setf (rau--window-wl-dimensions-hint-min window-wl) `(,min-width . ,min-height)
          (rau--window-wl-dimensions-hint-max window-wl) `(,max-width . ,max-height))))

(defun rau--on-river-window-v1-dimensions (window-wl args)
  (pcase-let (((map width height) args))
    (setf (rau--window-wl-actual-dimensions window-wl) `(,width . ,height))))

(defun rau--on-river-window-v1-app-id (window-wl args)
  (pcase-let (((map app-id) args))
    (when-let* ((app-id (ewc-to-utf8 app-id)))
      (setf (rau--window-wl-app-id window-wl) app-id))))

(defun rau--maybe-new-outputframe-window (window-wl title)
  (unless (ewc-object-tagged-p window-wl rau--tag-outputframe)
    (lgr-debug rau--lgr "Discovered new Emacs frame by title: %s" title)
    (ewc-object-tag (rau--state-client rau--state)
                    window-wl rau--tag-outputframe)
    (rau--manage-enqueue window-wl 'inform-maximized)
    (rau--manage-enqueue window-wl 'set-tiled `((edges . ,rau--edges-all)))
    (let ((node-wl (rau--window-wl-node-wl window-wl)))
      (rau--manage-enqueue node-wl 'place-bottom))

    (rau--tasks-enqueue #'rau--task-link-emacs-frame-to-window
                        title
                        (ewc-object-id window-wl))))

(defun rau--maybe-new-external-window (window-wl title)
  (unless (ewc-object-tagged-p window-wl rau--tag-external)
    (lgr-debug rau--lgr "Discovered new regular external window with title %s." title)
    (when (not (null (rau--window-wl-parent-wl window-wl)))
      (ewc-object-tag (rau--state-client rau--state)
                      window-wl rau--tag-floating))
    (ewc-object-tag (rau--state-client rau--state)
                    window-wl rau--tag-external)
    (rau--tasks-enqueue #'rau--task-setup-new-external-window (ewc-object-id window-wl))))

(defun rau--on-river-window-v1-title (window-wl args)
  "Handle title event for WINDOW-WL.
Also categorizes the window based on the title prefix into Emacs
outputframe or external window."
  (pcase-let* (((map title) args)
               (title (ewc-to-utf8 title)))
    (setf (rau--window-wl-title window-wl) title)

    (if (string-prefix-p "rau-frame-" title)
        (rau--maybe-new-outputframe-window window-wl title)
      (rau--maybe-new-external-window window-wl title))

    ;; Handle title updates for already categorized objects
    (when-let* (((ewc-object-tagged-p window-wl rau--tag-external))
                (name (rau--make-buffer-name
                       (rau--window-wl-app-id window-wl)
                       title)))
      (rau--tasks-enqueue #'rau--task-rename-buffer
                          (ewc-object-id window-wl)
                          name))))

(defun rau--on-river-window-v1-parent (window-wl args)
  (pcase-let* (((map object) args)
               (client (rau--state-client rau--state)))
    (when-let* ((parent-wl (ewc-object-get client object)))
      (setf (rau--window-parent-wl window-wl) parent-wl)
      (when-let* (((ewc-object-tagged-p window-wl rau--tag-external)))
        (ewc-object-tag client rau--tag-floating)))))

(defun rau--on-river-window-v1-fullscreen-requested (window-wl args)
  (when (ewc-object-tagged-p window-wl rau--tag-external)
    (pcase-let* (((map output) args)
                 (output-wl
                  ;; Find output for fullscreen window
                  ;; 1. optional event arg output
                  ;; 2. output showing window-wl
                  ;; 3. TODO: output currently having focus
                  (or (ewc-object-get (rau--state-client rau--state) output)
                      (when-let*
                          ((frame-wl (rau--frame-wl-for-extwin-wl window-wl)))
                        (rau--outframe-wl-output-wl frame-wl)))))
      (if (not output-wl)
          (message "Fullscreen requested, but no output found")
        (let ((current-fs (rau--output-wl-fullscreen-window-wl output-wl)))
          (when (and current-fs (not (eq current-fs window-wl)))
            (rau--fullscreen-exit current-fs output-wl)))
        (rau--fullscreen-enter window-wl output-wl)))))

(defun rau--on-river-window-v1-exit-fullscreen-requested (window-wl _)
  (rau--do 'river-output-v1 output-wl rau--state
    (when (eq (rau--output-wl-fullscreen-window-wl output-wl) window-wl)
      (rau--fullscreen-exit window-wl output-wl))))

(defun rau--on-river-window-v1-minimize-requested (window-wl _)
  (when-let* (((ewc-object-tagged-p window-wl rau--tag-external)))
    (rau--tasks-enqueue #'rau--task-minimize-window (ewc-object-id window-wl))))

(defun rau--on-river-window-v1-unreliable-pid (window-wl args)
  (pcase-let* (((map unreliable-pid) args))
    (setf (rau--window-wl-pid window-wl) unreliable-pid)))

;;;; river-output-v1 listeners
(defun rau--on-river-output-v1-removed (output-wl _)
  ;; TODO: check whether we lost focus
  (let ((client (rau--state-client rau--state)))
    (when-let* ((frame-id (rau--output-wl-frame-id output-wl)))
      (rau--tasks-enqueue #'rau--task-delete-frame frame-id))
    ;; TODO: also enqueue the below three actions, look out for race conditions
    (when-let* ((ls-output-wl (rau--output-wl-ls-output-wl output-wl)))
      (rau--request ls-output-wl 'destroy))
    (rau--request output-wl 'destroy)
    (ewc-object-remove client output-wl)))

;; TODO: listener for wl_output, e.g. to get monitor names

(defun rau--on-river-output-v1-position (output-wl args)
  (pcase-let (((map x y) args))
    (setf (rau--output-wl-position output-wl) `(,x . ,y))))

(defun rau--on-river-output-v1-dimensions (output-wl args)
  (pcase-let (((map width height) args))
    (setf (rau--output-wl-dimensions output-wl) `(,width . ,height))))

;;;; river-seat-v1 listener
(defun rau--on-river-seat-v1-window-interaction (_seat-wl args)
  (pcase-let* (((map window) args))
    (lgr-debug rau--lgr "window interaction with %d" window)
    (rau--request-focus-by-id window)))

;;;; river-xkb-bindings-v1 protocol
;;;; river-xkb-binding-v1 listeners
(defun rau--on-river-xkb-binding-v1-pressed (binding-wl _)
  (unless (and (rau--state-session-locked rau--state)
               (not (rau--binding-wl-allow-when-locked binding-wl)))
    (let* ((event (rau--binding-wl-event binding-wl))
           (needs-focus (rau--binding-wl-needs-focus binding-wl)))
      (rau--tasks-enqueue #'rau--task-consume-key-event event needs-focus)

      ;; If focus is with external window then switch to underlying emacs
      ;; frame such that following keypresses go to emacs
      (when-let* (needs-focus
                  (window-id (rau--state-focus-last-id rau--state))
                  (client (rau--state-client rau--state))
                  (window-wl (ewc-object-get client window-id))
                  ((ewc-object-tagged-p window-wl rau--tag-external))
                  (target-wl (rau--frame-wl-for-extwin-wl window-wl)))
        (lgr-debug rau--lgr "switch focus to emacs frame for key pressed.")
        (rau--request-focus target-wl)))))

;;;; river-layer-shell-v1 protocol
;;;; river-layer-shell-output-v1 listeners
(defun rau--on-river-layer-shell-output-v1-non-exclusive-area (ls-output-wl args)
  (pcase-let (((map x y width height) args))
    (setf (rau--ls-output-wl-non-excl-position ls-output-wl) `(,x . ,y)
          (rau--ls-output-wl-non-excl-dimensions ls-output-wl) `(,width . ,height))))

;;;; river-layer-shell-seat-v1 listeners
(defun rau--on-river-layer-shell-seat-v1-focus-none (_ls-seat-wl _)
  "Give focus back to the last window that had it."
  (rau--request-focus-by-id nil t))

;;; Manage cycle

(defun rau--reconcile-frames ()
  "Ensure each output gets one maximized Emacs frame."
  (let ((client (rau--state-client rau--state)))
    (rau--do 'river-output-v1 output-wl rau--state
      (lgr-trace rau--lgr "reconcile output: id=%d." (ewc-object-id output-wl))
      (if-let* ((frame-id (rau--output-wl-frame-id output-wl))
                (frame-wl (cl-find
                           frame-id
                           (ewc-objects client rau--tag-outputframe)
                           :key #'rau--window-wl-frame-id)))
          (let ((dimensions (rau--dimensions-for-outputframe output-wl)))
            (lgr-trace rau--lgr "frame found: id=%d." (ewc-object-id frame-wl))
            (rau--request frame-wl
                          'propose-dimensions
                          `((width . ,(car dimensions))
                            (height . ,(cdr dimensions)))))

        (lgr-debug rau--lgr "no frame found for output, waiting for client state.")))))

(defun rau--reconcile-window-floating (window-wl)
  (rau--request window-wl 'set-tiled '((edges . 0)))
  ;; propose 0, allow window do decide its own dimensions
  (rau--request window-wl 'propose-dimensions '((width . 0) (height . 0)))
  (rau--request window-wl 'use-csd))

(defun rau--reconcile-window-tiled (window-wl)
  (rau--request window-wl
                'set-tiled
                `((edges . ,rau--edges-all)))
  (when-let* ((dimensions (rau--dimensions-for-window-wl window-wl)))
    (rau--request window-wl
                  'propose-dimensions
                  `((width . ,(car dimensions))
                    (height . ,(cdr dimensions))))))

(defun rau--reconcile-windows ()
  "Close killed windows and propose dimensions for active windows."
  (rau--do rau--tag-external window-wl rau--state
    (if (ewc-object-tagged-p window-wl rau--tag-floating)
        (rau--reconcile-window-floating window-wl)
      (rau--reconcile-window-tiled window-wl))))

(defun rau--manage-queue-send ()
  "Run the manage-sequence reconciliation."
  (rau--condition-case
   "reconcile-manage-requests"
   (let ((manage-requests (nreverse (rau--state-manage-queue rau--state))))
     (setf (rau--state-manage-queue rau--state) nil)
     (dolist (request manage-requests)
       (rau--request (nth 0 request) (nth 1 request) (nth 2 request))))))

;;; Render cycle

(defun rau--render-frames ()
  "Run the render-sequence reconciliation for frames."
  (rau--do rau--tag-outputframe frame-wl rau--state
           (when-let* ((node-wl (rau--window-wl-node-wl frame-wl))
                       (output-wl (rau--outframe-wl-output-wl frame-wl))
                       (position (rau--position-for-outputframe output-wl)))
             (lgr-trace rau--lgr "render frame %d for output %d."
                      (ewc-object-id frame-wl)
                      (ewc-object-id output-wl))
             (rau--request node-wl 'set-position
                           `((x . ,(car position))
                             (y . ,(cdr position)))))))

(defun rau--render-window-floating (window-wl)
  (when-let* ((node-wl (rau--window-wl-node-wl window-wl)))
    (rau--request window-wl 'show)
    (rau--request node-wl 'place-top)))

(defun rau--render-window-tiled (window-wl)
  (when-let* ((node-wl (rau--window-wl-node-wl window-wl)))
    (if-let* ((frame-wl (rau--frame-wl-for-extwin-wl window-wl))
              (output-wl (rau--outframe-wl-output-wl frame-wl))
              (frame-node-wl (rau--window-wl-node-wl frame-wl))
              (frame-node-id (ewc-object-id frame-node-wl)))
        (pcase-let* ((`(,left ,top ,_right ,_bottom)
                      (rau--window-wl-edges window-wl))
                     (position (rau--position-for-outputframe output-wl))
                     (dimensions (rau--window-wl-actual-dimensions window-wl))
                     (clip (or dimensions (rau--dimensions-for-window-wl window-wl))))
          (rau--request window-wl 'show)

          (rau--request node-wl 'set-position
                        `((x . ,(+ left (car position)))
                          (y . ,(+ top (cdr position)))))

          ;; Place window above the Emacs outputframe window but not at the top
          ;; In theory this should leave the top for floating windows
          (rau--request node-wl 'place-above `((other . ,frame-node-id)))

          (rau--request window-wl 'set-clip-box
                        `((x . 0)
                          (y . 0)
                          (width . ,(car clip))
                          (height . ,(cdr clip)))))

      (rau--request window-wl 'hide))))

(defun rau--render-windows ()
  "Run the render-sequence reconciliation for windows."
  (rau--do rau--tag-external window-wl rau--state
    (if (ewc-object-tagged-p window-wl rau--tag-floating)
        (rau--render-window-floating window-wl)
      (rau--render-window-tiled window-wl))))

(defun rau--update-fe-ui-state (state)
  ;; TODO here we could build a visibility diff to send show and hide only when necessary
  (rau--do rau--tag-external window-wl rau--state
    (setf (rau--window-wl-edges window-wl) nil
          (rau--window-wl-frame-id window-wl) nil))
  (let ((extwins (alist-get 'extwins state))
        (outframes (alist-get 'outframes state))
        (client (rau--state-client rau--state)))
    (dolist (win extwins)
      (when-let* ((window-id (alist-get 'window-id win))
                  (window-wl (ewc-object-get client window-id)))
        (setf (rau--window-wl-edges window-wl) (alist-get 'edges win)
              (rau--window-wl-frame-id window-wl) (alist-get 'frame-id win))))
    (dolist (outframe outframes)
      (let* ((window-id (alist-get 'window-id outframe))
             (output-id (alist-get 'output-id outframe))
             (frame-id (alist-get 'frame-id outframe))
             (window-wl (ewc-object-get client window-id))
             (output-wl (ewc-object-get client output-id)))
        (when window-wl
          (setf (rau--window-wl-frame-id window-wl) frame-id))
        (when output-wl
          (setf (rau--output-wl-frame-id output-wl) frame-id))))))
  ;; TODO mark-manage-dirty?

;;; Emacs client side code
(defun rau--fe-ui-state ()
  (let (outframes extwins)
    (dolist (f (frame-list))
      (let ((frame-id (frame-id f))
            (window-id (frame-parameter f 'rau--window-id))
            (output-id (frame-parameter f 'rau--output-id)))
        (when (or window-id output-id)
          (push `((frame-id . ,frame-id)
                  (window-id . ,window-id)
                  (output-id . ,output-id))
                outframes))
        (dolist (w (window-list f))
          (when-let* ((buffer (window-buffer w))
                      (window-id (buffer-local-value 'rau--window-id buffer)))
            (push `((window-id . ,window-id)
                    (frame-id . ,frame-id)
                    ;; (name . ,(buffer-name buffer)) ; only for debugging
                    (edges . ,(window-inside-absolute-pixel-edges w)))
                  extwins)))))
    `((outframes . ,(sort outframes :key #'cdar))
      (extwins . ,(sort extwins :key #'cdar)))))

(defun rau--send-fe-ui-state ()
  (let ((new-state (rau--fe-ui-state))
        (last-state (rau--fe-state-last-send-state rau--fe-state)))
    (if (equal new-state last-state)
        (lgr-trace rau--lgr "new-state and last-state equal, not sending.")
      (rau--update-fe-ui-state new-state)
      (setf (rau--fe-state-last-send-state rau--fe-state) new-state))))

(defun rau--window-state-change-handler ()
  (rau--send-fe-ui-state)
  (rau--update-focus-request)

  ;; Schedule a river manage cycle and thus a reconciliation cycle.
  ;; This is necessary for external windows to resize when the minibuffer
  ;; expands.  This needs to be added to the global hook since local hooks
  ;; don't get called for windows that disappear.  Also
  ;; window-size-change-functions does not get called when minibuffer expands
  ;; and thus minibuffer ends up below external window.
  (rau--mark-manage-dirty))

;;; Startup
;; NOTE: No need for rau-disable since this Emacs process is serving as a
;; Window Manager and disabling rau while keeping the Emacs process running
;; would result in an unresponsive user environment.
;;;###autoload
(defun rau-enable ()
  "Enable the rau window manager for river.
Call this function once when starting Emacs inside of river."
  (unless (eq window-system 'pgtk)
    (user-error "Rau requires a pgtk Emacs on Wayland"))

  (when rau--fe-state
    (user-error "Rau is already running"))
  (setq rau--fe-state (rau--fe-state-make)
        rau--lgr (lgr-get-logger "rau"))

  (unless confirm-kill-emacs
    (setq confirm-kill-emacs #'yes-or-no-p))
  (rau--global-unset-key-if "C-x C-c" 'save-buffers-kill-terminal)
  (rau--global-unset-key-if "C-z" 'suspend-frame)
  (rau--global-unset-key-if "C-x C-z" 'suspend-frame)

  ;; TODO: this is a hack for lack of ability to figure out alignment ...
  (menu-bar-mode 0)
  (tool-bar-mode 0)

  (advice-add 'split-window-below :filter-return #'rau--split-window-advice)
  (advice-add 'split-window-right :filter-return #'rau--split-window-advice)
  (advice-add 'set-window-buffer :around #'rau--set-window-buffer-advice)

  (message "Launching rau (pure Elisp) ...")
  (unless (= 1 (length (frame-list)))
    (user-error "There should be exactly one frame when starting Rau."))

  (modify-frame-parameters nil (rau--make-outputframe-parameters))

  (let* ((interfaces (rau--read-protocols))
         (client (ewc-start interfaces "rau--on-")))
    (setq rau--state (rau--state-make :client client)))

  (add-hook 'window-state-change-hook #'rau--window-state-change-handler))

;;; Hacks to avoid rau to freeze, TODO find an alternative

(defun x-popup-menu(_position _menu)
  (message "x-popup-menu does not work with rau and is therefor overwritten.")
  nil)

(defun popup-menu(_menu &optional _position _prefix _from-menu-bar)
  (message "popup-menu does not work with rau and is therefor overwritten.")
  nil)

(defun x-popup-dialog(_position _contents &optional _header)
  (message "x-popup-dialog does not work with rau and is therefor overwritten.")
  nil)

(defun display-popup-menus-p (&optional _display)
  nil)

(provide 'rau)
;;; rau.el ends here
