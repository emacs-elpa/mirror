;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-flow" "1.0"
  "Support Flow in flycheck."
  '((flycheck "0.18"))
  :url "https://github.com/lbolla/emacs-flycheck-flow"
  :commit "f29f836ad777596ea0e6582c0c9ff8e47bc07cd2"
  :revdesc "f29f836ad777"
  :authors '(("Lorenzo Bolla" . "lbolla@gmail.com"))
  :maintainers '(("Lorenzo Bolla" . "lbolla@gmail.com")))
