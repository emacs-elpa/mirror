;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "immaterial-theme" "0.10.0"
  "A family of themes loosely based on material colors."
  '((emacs        "29")
    (modus-themes "5.0.0"))
  :url "https://github.com/petergardfjall/emacs-immaterial-theme"
  :commit "c478e875d9949a0b8341fa146ea9a408997623f5"
  :revdesc "c478e875d994"
  :keywords '("themes"))
