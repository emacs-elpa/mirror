;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-xref" "0.1"
  "Ivy interface for xref results."
  '((emacs "25.1")
    (ivy   "0.10.0"))
  :url "https://github.com/alexmurray/ivy-xref"
  :commit "86d2e425541f6b3d4a06439388d187924b181641"
  :revdesc "86d2e425541f"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
