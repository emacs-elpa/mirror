;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frontside-javascript" "1.0.0"
  "JS  development that just work™️."
  '((emacs                 "25.1")
    (add-node-modules-path "1.2.0")
    (company               "0.9.2")
    (flycheck              "20201228.2104")
    (js2-mode              "20201220")
    (js2-refactor          "0.9.0")
    (rjsx-mode             "0.5.0")
    (tide                  "4.0.2")
    (web-mode              "17")
    (lsp-mode              "20220124"))
  :url "https://github.com/thefrontside/frontmacs"
  :commit "18816534a977fbd28848389b58c22b6538cfdeec"
  :revdesc "18816534a977"
  :keywords '("files" "tools")
  :authors '(("Frontside Engineering" . "engineering@frontside.com"))
  :maintainers '(("Frontside Engineering" . "engineering@frontside.com")))
