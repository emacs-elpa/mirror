;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flash" "0.1.0"
  "Flash-style navigation for Emacs."
  '((emacs "27.1"))
  :url "https://github.com/chestnykh/flash"
  :commit "c3ab7b29443ba4997d04e6e1a132ceba418d5d35"
  :revdesc "c3ab7b29443b"
  :keywords '("convenience" "navigation"))
