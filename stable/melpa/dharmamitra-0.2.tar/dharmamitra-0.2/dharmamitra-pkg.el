;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dharmamitra" "0.2"
  "Sanskrit/Pāli/Tibetan/Chinese analysis via dharmamitra.org."
  '((emacs "26.1"))
  :url "https://github.com/dharmamitra/dharmamitra-emacs"
  :commit "22fce5b642a806671fa059c53dc249ba9ad99220"
  :revdesc "v0.2-0-g22fce5b642a8"
  :keywords '("languages" "tools"))
