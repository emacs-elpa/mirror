;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bookmarks-extractor" "0.1"
  "Extract bookmarks from Org mode."
  '((emacs "26.1"))
  :url "https://github.com/jxq0/org-bookmarks-extractor"
  :commit "279927bce005b03e7874b450468b24473bcc1861"
  :revdesc "279927bce005"
  :keywords '("convenience" "org")
  :authors '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainers '(("Xuqing Jia" . "jxq@jxq.me")))
