;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emamux" "0.14"
  "Interact with tmux."
  '((emacs "24.3"))
  :url "https://github.com/syohex/emacs-emamux"
  :commit "573dd1cf18584a1fd240efb16c7726b6fd790b73"
  :revdesc "573dd1cf1858"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
