;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.69.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.95.3")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "fa20e538559281bb990014470dcad43c6d297b51"
  :revdesc "fa20e5385592")
