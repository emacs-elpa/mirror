;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-import-check" "0.2"
  "Finds the unused python imports using importchecker."
  ()
  :url "https://github.com/psibi/emacs-py-import-check"
  :commit "77600955fe833f0d44f4c4937013369dec76d931"
  :revdesc "77600955fe83"
  :keywords '("python" "import" "check")
  :authors '(("Sibi" . "sibi@psibi.in"))
  :maintainers '(("Sibi" . "sibi@psibi.in")))
