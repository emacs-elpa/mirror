;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mind-map" "0.4"
  "Creates a directed graph from org-mode files."
  '((emacs "24")
    (dash  "1.8.0")
    (org   "8.2.10"))
  :url "https://github.com/theodorewiles/org-mind-map/org-mind-map.el"
  :commit "477701b15cb0c8ed7f021ca76a4cb1a7d9ad6aa5"
  :revdesc "477701b15cb0"
  :keywords '("orgmode" "extensions" "graphviz" "dot")
  :authors '(("Ted Wiles" . "theodore.wiles@gmail.com"))
  :maintainers '(("Ted Wiles" . "theodore.wiles@gmail.com")))
