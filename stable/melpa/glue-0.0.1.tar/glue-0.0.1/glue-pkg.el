;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "glue" "0.0.1"
  "Emacs - Common Lisp interop."
  '((emacs "24.1"))
  :url "https://git.sr.ht/~hajovonta/glue/"
  :commit "7649e30bf7cdd43323a40e5330132f0e42f50a24"
  :revdesc "7649e30bf7cd"
  :keywords '("lisp" "emacs" "common" "lisp" "cl")
  :authors '(("Gabor Poczkodi" . "hajovonta@gmail.com"))
  :maintainers '(("Gabor Poczkodi" . "hajovonta@gmail.com")))
