;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertica-snippets" "0.1.0"
  "Yasnippets for AWS."
  '((yasnippet "0.8.0"))
  :url "https://github.com/baron42bba/vertica-snippets"
  :commit "48724e6102177c2e4f1c5d15a161c33c843f1fbd"
  :revdesc "48724e610217"
  :keywords '("snippets"))
