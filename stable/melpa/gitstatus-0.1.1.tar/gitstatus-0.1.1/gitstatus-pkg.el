;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitstatus" "0.1.1"
  "Common front-end for `gitstatusd'."
  '((emacs "25.1"))
  :url "https://github.com/igorepst/gitstatus-el"
  :commit "c3e30341d0add9728010e566b9eb031c76414b47"
  :revdesc "c3e30341d0ad"
  :keywords '("tools" "processes")
  :authors '(("Igor Epstein" . "igorepst@gmail.com"))
  :maintainers '(("Igor Epstein" . "igorepst@gmail.com")))
