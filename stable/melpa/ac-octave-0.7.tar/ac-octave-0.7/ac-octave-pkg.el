;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-octave" "0.7"
  "An auto-complete source for Octave."
  '((auto-complete "1.4.0"))
  :url "https://github.com/coldnew/ac-octave"
  :commit "6d09b94a86f43de84c60e9a699b5e1be61c0f138"
  :revdesc "6d09b94a86f4"
  :keywords '("octave" "auto-complete" "completion")
  :authors '(("coldnew" . "coldnew.tw@gmail.com"))
  :maintainers '(("coldnew" . "coldnew.tw@gmail.com")))
