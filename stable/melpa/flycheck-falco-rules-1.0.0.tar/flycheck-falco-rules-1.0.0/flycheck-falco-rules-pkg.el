;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-falco-rules" "1.0.0"
  "On-the-fly syntax checking for falco rules files."
  '((emacs     "24.3")
    (flycheck  "0.25")
    (let-alist "1.0.1"))
  :url "https://github.com/falcosecurity/flycheck-falco-rules"
  :commit "1ad301d497ade9556327053ca571ee51bf0c0633"
  :revdesc "1ad301d497ad"
  :keywords '("tools" "convenience"))
