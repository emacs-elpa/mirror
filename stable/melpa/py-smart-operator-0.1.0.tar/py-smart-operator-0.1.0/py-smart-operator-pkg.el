;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-smart-operator" "0.1.0"
  "Smart-operator for python-mode."
  '((python-mode "0")
    (s           "1.9.0"))
  :url "https://github.com/rmuslimov/py-smart-operator"
  :commit "bde5f11497d7d3d054564d31d0f6530699e58c9e"
  :revdesc "bde5f11497d7"
  :keywords '("python" "convenience" "smart-operator")
  :authors '(("Rustem Muslimov" . "r.muslimov@gmail.com"))
  :maintainers '(("Rustem Muslimov" . "r.muslimov@gmail.com")))
