;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-snooze" "0.1.0"
  "Snooze your code, doc and feed."
  '((emacs "24.4"))
  :url "https://github.com/xueeinstein/org-snooze.el"
  :commit "6d30b0dcdfe9538e4400e49046291b7d07274164"
  :revdesc "6d30b0dcdfe9"
  :keywords '("extensions"))
