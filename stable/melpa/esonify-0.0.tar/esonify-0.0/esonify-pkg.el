;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esonify" "0.0"
  "Sonify your code."
  '((deferred "0.3.1")
    (cl-lib   "0.5"))
  :url "https://github.com/oflatt/esonify"
  :commit "5decb75fc591ded409f3f9a6477d8ed81e7ef269"
  :revdesc "5decb75fc591"
  :authors '(("Oliver Flatt" . "oflatt@gmail.com"))
  :maintainers '(("Oliver Flatt" . "oflatt@gmail.com")))
