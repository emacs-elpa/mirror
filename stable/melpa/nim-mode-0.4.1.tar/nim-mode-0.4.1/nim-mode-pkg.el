;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nim-mode" "0.4.1"
  "A major mode for the Nim programming language."
  '((emacs     "24.4")
    (epc       "0.1.1")
    (let-alist "1.0.1")
    (commenter "0.5.1")
    (flycheck  "28"))
  :url "https://github.com/nim-lang/nim-mode"
  :commit "86abed21b9b718ac65cc167f208e0bd5b92c79ed"
  :revdesc "86abed21b9b7"
  :keywords '("nim" "languages")
  :maintainers '(("Simon Hafner" . "hafnersimon@gmail.com")))
