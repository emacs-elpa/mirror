;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-slack" "0.1.1"
  "Slack Exporter for org-mode."
  '((org    "9.1.4")
    (ox-gfm "1.0"))
  :url "https://github.com/titaniumbones/ox-slack"
  :commit "96d90914e6df1a0141657fc51f1dc5bb8f1da6bd"
  :revdesc "96d90914e6df"
  :keywords '("org" "slack" "outlines"))
