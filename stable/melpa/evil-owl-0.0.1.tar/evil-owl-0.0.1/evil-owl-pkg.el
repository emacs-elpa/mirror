;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-owl" "0.0.1"
  "Preview evil registers and marks before using them."
  '((emacs "25.1")
    (evil  "1.2.13"))
  :url "https://github.com/mamapanda/evil-owl"
  :commit "24c5f43df375194386344e69bc720ea3986c9510"
  :revdesc "24c5f43df375"
  :keywords '("emulations" "evil" "visual")
  :authors '(("Daniel Phan" . "daniel.phan36@gmail.com"))
  :maintainers '(("Daniel Phan" . "daniel.phan36@gmail.com")))
