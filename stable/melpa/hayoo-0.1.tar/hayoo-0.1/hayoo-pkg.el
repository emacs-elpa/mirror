;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hayoo" "0.1"
  "Query hayoo and show results in a tabulated buffer."
  '((json "1.3"))
  :url "https://github.com/benma/hayoo.el/"
  :commit "cfeb849f24a591f986488d10089c9e9fae551c5e"
  :revdesc "cfeb849f24a5"
  :keywords '("hayoo" "haskell")
  :authors '(("Marko Bencun" . "mbencun@gmail.com"))
  :maintainers '(("Marko Bencun" . "mbencun@gmail.com")))
