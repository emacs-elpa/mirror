;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "benchstat" "1.0.0"
  "Proper benchmarking made simple."
  ()
  :url "https://github.com/Quasilyte/benchstat.el"
  :commit "b39a97f3072c2d3c1d3f86790b9e134d05b8d7e6"
  :revdesc "v1.0.0-0-gb39a97f3072c"
  :keywords '("lisp")
  :authors '(("Iskander Sharipov" . "quasilyte@gmail.com"))
  :maintainers '(("Iskander Sharipov" . "quasilyte@gmail.com")))
