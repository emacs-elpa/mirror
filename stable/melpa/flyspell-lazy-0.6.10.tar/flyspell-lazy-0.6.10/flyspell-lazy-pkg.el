;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyspell-lazy" "0.6.10"
  "Improve flyspell responsiveness using idle timers."
  ()
  :url "https://github.com/rolandwalker/flyspell-lazy"
  :commit "31786fe04a4732d2f845e1c7e96fcb030182ef10"
  :revdesc "v0.6.10-0-g31786fe04a47"
  :keywords '("spelling")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
