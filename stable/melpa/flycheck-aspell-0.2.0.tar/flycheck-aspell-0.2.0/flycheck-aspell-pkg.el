;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-aspell" "0.2.0"
  "Aspell checker for flycheck."
  '((flycheck "28.0")
    (emacs    "25.1"))
  :url "https://github.com/leotaku/flycheck-aspell"
  :commit "d84409c709670488b00ae3272fa43235058df2fe"
  :revdesc "d84409c70967"
  :keywords '("flycheck" "spell" "aspell")
  :authors '(("Leo Gaskin" . "leo.gaskin@brg-feldkirchen.at"))
  :maintainers '(("Leo Gaskin" . "leo.gaskin@brg-feldkirchen.at")))
