;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "v-mode" "0.0.1"
  "A major mode for the V programming language."
  '((dash                  "2.17.0")
    (hydra                 "0.15.0")
    (hl-todo               "3.1.2")
    (yafolding             "0.4.1")
    (yasnippet             "0.14.0")
    (rainbow-delimiters    "2.1.4")
    (fill-column-indicator "1.90"))
  :url "https://github.com/damon-kwok/v-mode"
  :commit "b1d0b8a6853cfe63d17162f5bdc7460591ef04d4"
  :revdesc "b1d0b8a6853c"
  :keywords '("languages" "programming")
  :authors '(("Damon Kwok" . "damon-kwok@outlook.com"))
  :maintainers '(("Damon Kwok" . "damon-kwok@outlook.com")))
