;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.2.1"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "91a08995a0559136b1802ebd489d9512ee824bb2"
  :revdesc "1.2.1-0-g91a08995a055"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
