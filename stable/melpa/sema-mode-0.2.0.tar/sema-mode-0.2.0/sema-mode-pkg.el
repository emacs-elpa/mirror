;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sema-mode" "0.2.0"
  "Major mode for editing Sema files."
  '((emacs "25.1"))
  :url "https://github.com/sema-lisp/emacs-sema"
  :commit "308b0075837a63fc49c2787e3255a5afa317831f"
  :revdesc "v0.2.0-0-g308b0075837a"
  :keywords '("languages" "lisp")
  :authors '(("Helge Sverre" . "helge.sverre@gmail.com"))
  :maintainers '(("Helge Sverre" . "helge.sverre@gmail.com")))
