;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timeout" "2.1.7"
  "Throttle or debounce Elisp functions."
  '((emacs "24.4"))
  :url "https://github.com/karthink/timeout"
  :commit "b1212984709c4b50c509ef6d3bd959951e5dcc91"
  :revdesc "b1212984709c"
  :keywords '("convenience" "extensions")
  :authors '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com")))
