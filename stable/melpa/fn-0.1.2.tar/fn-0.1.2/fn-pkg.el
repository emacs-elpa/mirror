;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fn" "0.1.2"
  "Concise anonymous functions for Emacs Lisp."
  '((emacs           "24")
    (cl-lib          "0.5")
    (dash            "2.12.1")
    (dash-functional "1.2.0"))
  :url "https://github.com/troyp/fn.el"
  :commit "2842e3c6d1b5c96184fa638c37b25ce5b347a1a6"
  :revdesc "0.1.2-0-g2842e3c6d1b5"
  :keywords '("functional"))
