;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "0.19.0"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "29f3188319c5881f1bf9c34ea46bfc13a46578d9"
  :revdesc "v0.19.0-0-g29f3188319c5"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
