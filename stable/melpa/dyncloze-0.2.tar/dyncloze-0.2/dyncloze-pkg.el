;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dyncloze" "0.2"
  "Language alternatives self-testing."
  '((emacs "25.1")
    (dash  "2.18"))
  :url "https://github.com/ahyatt/dyncloze"
  :commit "fe5baf6d324800779f80f5c6298a56e2dcb87598"
  :revdesc "fe5baf6d3248"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
