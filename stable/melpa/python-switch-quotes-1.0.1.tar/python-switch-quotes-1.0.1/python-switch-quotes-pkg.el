;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-switch-quotes" "1.0.1"
  "Cycle between ' and \" quotes in python strings."
  '((emacs "24.3"))
  :url "https://github.com/werehuman/python-switch-quotes"
  :commit "1d5d233c5da9d7668d15b45ae872fb641bfb0b0e"
  :revdesc "1d5d233c5da9"
  :keywords '("python" "tools" "convenience")
  :authors '(("Vladimir Lagunov" . "lagunov.vladimir@gmail.com"))
  :maintainers '(("Vladimir Lagunov" . "lagunov.vladimir@gmail.com")))
