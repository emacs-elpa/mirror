;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minimal-session-saver" "0.6.2"
  "Very lean session saver."
  ()
  :url "https://github.com/rolandwalker/minimal-session-saver"
  :commit "aaba48a8525e1310b221eeb96763304c22e9a4b4"
  :revdesc "v0.6.2-0-gaaba48a8525e"
  :keywords '("tools" "frames" "project")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
