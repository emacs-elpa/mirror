;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-d-unittest" "0.0.0.20260810.36"
  "Add D unittest support to flycheck."
  '((flycheck "0.21-cvs1")
    (dash     "1.4.0"))
  :url "https://github.com/tom-tan/flycheck-d-unittest/"
  :commit "4ebaabedfd52d63d7e4f62c8dce279eaef635e45"
  :revdesc "4ebaabedfd52"
  :keywords '("flycheck" "d")
  :authors '(("Tomoya Tanjo" . "ttanjo@gmail.com"))
  :maintainers '(("Tomoya Tanjo" . "ttanjo@gmail.com")))
