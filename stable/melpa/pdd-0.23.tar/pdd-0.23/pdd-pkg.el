;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "0.23"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "8f7516510459477c2ff368a7fde4cc68cead2402"
  :revdesc "8f7516510459"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
