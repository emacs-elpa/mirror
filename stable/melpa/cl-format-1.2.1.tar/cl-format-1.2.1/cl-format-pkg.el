;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cl-format" "1.2.1"
  "CL format routine."
  ()
  :url "https://gitlab.com/akater/elisp-cl-format"
  :commit "42b662d27eefa458c1a39bea1836d6ada740b863"
  :revdesc "1.2.1-0-g42b662d27eef"
  :keywords '("extensions")
  :authors '(("Andreas Politz" . "politza@fh-trier.de"))
  :maintainers '(("akater" . "nuclearspace@gmail.com")))
