;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "heroku" "1.0.1"
  "Like Magit but for Heroku CLI."
  '((emacs     "27.2")
    (transient "0.3.7")
    (dash      "2.19.1")
    (s         "1.13.0")
    (ts        "0.2.2"))
  :url "https://github.com./licht1stein/heroku.el"
  :commit "b76db3801d759baece7865b238e99e494506dbeb"
  :revdesc "b76db3801d75"
  :keywords '("heroku" "devops" "convenience"))
