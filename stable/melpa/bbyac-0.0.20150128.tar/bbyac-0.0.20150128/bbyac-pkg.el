;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbyac" "0.0.20150128"
  "Type a little Bit, and Bang! You Are Completed."
  '((browse-kill-ring "1.3"))
  :url "https://github.com/baohaojun/bbyac"
  :commit "720477cfc963c3b78d268496848684be21765fd6"
  :revdesc "720477cfc963"
  :keywords '("abbrev")
  :authors '(("Bao Haojun" . "baohaojun@gmail.com"))
  :maintainers '(("Bao Haojun" . "baohaojun@gmail.com")))
