;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-spotify" "0.1"
  "Search spotify with ivy/counsel."
  '((emacs   "26.1")
    (spotify "0.1")
    (ivy     "0.10"))
  :url "https://codeberg.org/jao/espotify"
  :commit "6be41542eb59918effc937cb86cc6fd84d281bc7"
  :revdesc "6be41542eb59"
  :keywords '("multimedia")
  :authors '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
