;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "teacode-expand" "0.0.1"
  "Expansion of text by TeaCode program."
  '((emacs "24.4"))
  :url "https://github.com/raguay/TeaCode-Expand"
  :commit "5799e4ef4aae6653c056760c39a1693935e96264"
  :revdesc "5799e4ef4aae"
  :keywords '("lisp")
  :authors '(("Richard Guay" . "raguay@customct.com"))
  :maintainers '(("Richard Guay" . "raguay@customct.com")))
