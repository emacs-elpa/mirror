;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "c-eval" "0.1.0"
  "Compile and run one-off C code snippets."
  '((emacs "24.5"))
  :url "https://github.com/lassik/emacs-c-eval"
  :commit "18de1ecf9bac88080fe12d61e43ca9ba47a036de"
  :revdesc "18de1ecf9bac"
  :keywords '("c" "languages")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
