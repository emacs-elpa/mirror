;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atl-long-lines" "0.2.0"
  "Turn off truncate-lines when the line is long."
  '((emacs "24.3"))
  :url "https://github.com/jcs-elpa/atl-long-lines"
  :commit "4d340ee74e1aa37a7204acddb8826684b57337c5"
  :revdesc "4d340ee74e1a"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
