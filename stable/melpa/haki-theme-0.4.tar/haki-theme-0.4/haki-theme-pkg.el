;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haki-theme" "0.4"
  "An elegant, high-contrast dark theme in modern sense."
  '((emacs "27.1"))
  :url "https://github.com/idlip/haki"
  :commit "90b09a56cefe43f970ea0afcee97e646e7c7b744"
  :revdesc "90b09a56cefe"
  :keywords '("faces" "theme" "accessibility"))
