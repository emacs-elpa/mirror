;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdownfmt" "0.1.0"
  "Format markdown using markdownfmt."
  '((emacs "24"))
  :url "https://github.com/nlamirault/emacs-markdownfmt"
  :commit "bb3c80421acdb8eab847d6ceddc8c0573a5cb73a"
  :revdesc "bb3c80421acd"
  :keywords '("markdown")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
