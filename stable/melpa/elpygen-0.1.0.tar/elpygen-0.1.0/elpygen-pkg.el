;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpygen" "0.1.0"
  "Implement a function or a method."
  '((emacs     "25")
    (yasnippet "0.8.0"))
  :url "https://github.com/vkazanov/elpygen"
  :commit "9cf97f108da2ce2cec879319fb5edc1c161f965f"
  :revdesc "9cf97f108da2"
  :keywords '("python" "languages" "tools")
  :authors '(("Vladimir Kazanov" . "vkazanov@inbox.ru"))
  :maintainers '(("Vladimir Kazanov" . "vkazanov@inbox.ru")))
