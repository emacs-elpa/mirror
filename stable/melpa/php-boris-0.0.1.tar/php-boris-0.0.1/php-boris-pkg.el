;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-boris" "0.0.1"
  "Run boris php REPL."
  ()
  :url "https://github.com/tomterl/php-boris"
  :commit "4bb7e4d34d9906ddce688205eb24cafe634c6d06"
  :revdesc "4bb7e4d34d99"
  :keywords '("php" "commint" "repl" "boris")
  :maintainers '(("Tom Regner" . "tom@goochesa.de")))
