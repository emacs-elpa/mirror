;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddskk-posframe" "1.0.0"
  "Show Henkan tooltip for ddskk via posframe."
  '((emacs "26.1")
    (ddskk "16.2.50"))
  :url "https://github.com/conao3/ddskk-posframe.el"
  :commit "322a9ef8cdb7416dd137e7d2b1be1120126c05fc"
  :revdesc "322a9ef8cdb7"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
