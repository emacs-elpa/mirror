;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-swiftui" "0.11.1"
  "Org babel functions for SwiftUI evaluation."
  '((emacs      "25.1")
    (swift-mode "8.2.0")
    (org        "9.2.0"))
  :url "https://github.com/xenodium/ob-swiftui"
  :commit "82154e06ae335ee6669b3c4d344759a0302efab2"
  :revdesc "82154e06ae33")
