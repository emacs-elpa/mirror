;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "c-eldoc" "0.7"
  "Helpful description of the arguments to C functions."
  ()
  :url "https://github.com/nflath/c-eldoc"
  :commit "f05f0d25ba1a76db6262ac2f17649ea05b71d4c7"
  :revdesc "f05f0d25ba1a"
  :authors '(("Nathaniel Flath" . "flat0103@gmail.com"))
  :maintainers '(("Nathaniel Flath" . "flat0103@gmail.com")))
