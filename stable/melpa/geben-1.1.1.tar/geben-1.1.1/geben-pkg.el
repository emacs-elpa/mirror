;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geben" "1.1.1"
  "DBGp protocol frontend, a script debugger."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/ahungry/geben"
  :commit "003abd23a7468daa133dfbc7ef85d0d61a0410dc"
  :revdesc "003abd23a746"
  :keywords '("c" "comm" "tools")
  :authors '(("Matthew Carter" . "m@ahungry.com"))
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
