;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dakrone-theme" "0.0.2"
  "Dakrone's custom dark theme."
  ()
  :url "https://github.com/dakrone/dakrone-theme"
  :commit "19db025f75961e9b92c67564e44a3cb8d6939f53"
  :revdesc "19db025f7596"
  :keywords '("color" "themes")
  :authors '(("Lee Hinman" . "lee_AT_writequit.org"))
  :maintainers '(("Lee Hinman" . "lee_AT_writequit.org")))
