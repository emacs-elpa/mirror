;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "royal-hemlock-theme" "1.6"
  "Soothing royal-blue light-theme."
  '((emacs "24"))
  :url "https://github.com/vs-123/royal-hemlock-theme"
  :commit "27d69b424358bedf4b2809ad237ea8a80b7c8add"
  :revdesc "27d69b424358"
  :keywords '("color" "theme" "faces"))
