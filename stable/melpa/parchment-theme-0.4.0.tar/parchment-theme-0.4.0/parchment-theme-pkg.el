;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parchment-theme" "0.4.0"
  "Light theme inspired by Acme and Leuven."
  '((autothemer "0.2"))
  :url "https://github.com/ajgrf/parchment"
  :commit "c90665145573f5e314ede1b7df3bb732e30f4bcd"
  :revdesc "c90665145573"
  :authors '(("Alex Griffin" . "a@ajgrf.com"))
  :maintainers '(("Alex Griffin" . "a@ajgrf.com")))
