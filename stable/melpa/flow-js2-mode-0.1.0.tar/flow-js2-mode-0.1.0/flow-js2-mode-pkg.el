;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flow-js2-mode" "0.1.0"
  "Support for flow annotations in js2-mode."
  ()
  :url "https://github.com/Fuco1/flow-js2-mode"
  :commit "b353722126db2f874efb2ae481bfb9cf9e072896"
  :revdesc "b353722126db"
  :keywords '("languages" "extensions")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
