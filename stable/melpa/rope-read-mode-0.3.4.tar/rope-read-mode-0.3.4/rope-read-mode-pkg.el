;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rope-read-mode" "0.3.4"
  "Rearrange lines to read text smoothly."
  ()
  :url "https://github.com/marcowahl/rope-read-mode"
  :commit "71e475ab35555e0a1eca26d73acf1ced911e422e"
  :revdesc "0.3.4-0-g71e475ab3555"
  :keywords '("reading" "convenience" "chill")
  :authors '(("Marco Wahl" . "marcowahlsoft@gmail.com"))
  :maintainers '(("Marco Wahl" . "marcowahlsoft@gmail.com")))
