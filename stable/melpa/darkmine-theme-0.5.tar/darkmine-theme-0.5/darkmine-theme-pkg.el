;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darkmine-theme" "0.5"
  "Yet another emacs dark color theme."
  ()
  :url "https://github.com/pierre-lecocq/darkmine-theme"
  :commit "9e7359d4e2330ccbc8d139536051d1894a0a8969"
  :revdesc "9e7359d4e233"
  :authors '(("Pierre Lecocq" . "pierre.lecocq@gmail.com"))
  :maintainers '(("Pierre Lecocq" . "pierre.lecocq@gmail.com")))
