;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hippie-expand-slime" "0.1"
  "Hook slime's completion into hippie-expand."
  ()
  :url "https://github.com/purcell/hippie-expand-slime"
  :commit "de31fbc9f9d55891a006463bcee7670b47084015"
  :revdesc "de31fbc9f9d5"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
