;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime-repl-ansi-color" "0.1"
  "Turn on ANSI colors in REPL output;."
  '((emacs "24")
    (slime "2.3.1"))
  :url "https://gitlab.com/augfab/slime-repl-ansi-color"
  :commit "98f95346c529496bccd7dd634e6fca08c45f1137"
  :revdesc "98f95346c529"
  :keywords '("lisp")
  :authors '(("Max Mikhanosa" . "max@openchat.com"))
  :maintainers '(("Augustin Fabre" . "augustin@augfab.fr")))
