;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.1.0"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "28623572a52a9c7ed96c36438853ca8fd69064a1"
  :revdesc "hyperbole-9.1.0-0-g28623572a52a"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")
                 ("Mats Lidell" . "matsl@gnu.org")))
