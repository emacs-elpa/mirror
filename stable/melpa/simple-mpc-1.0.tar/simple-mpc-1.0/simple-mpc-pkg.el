;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-mpc" "1.0"
  "[No description available]."
  ()
  :url "https://github.com/jorenvo/simple-mpc"
  :commit "55a51a6ca94accac8f02f48a5b38130d3e1901db"
  :revdesc "55a51a6ca94a"
  :keywords '("multimedia" "mpd" "mpc")
  :authors '(("Joren Van Onder" . "joren.vanonder@gmail.com"))
  :maintainers '(("Joren Van Onder" . "joren.vanonder@gmail.com")))
