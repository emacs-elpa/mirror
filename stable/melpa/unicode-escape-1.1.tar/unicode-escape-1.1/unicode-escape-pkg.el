;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-escape" "1.1"
  "Escape/Unescape unicode notations."
  '((emacs "24")
    (names "20151201.0")
    (dash  "2.12.1"))
  :url "https://github.com/kosh04/unicode-escape.el"
  :commit "b9cee7af45be62119b97033dc639bd1b5ed858f3"
  :revdesc "1.1-0-gb9cee7af45be"
  :keywords '("i18n" "unicode")
  :authors '(("KOBAYASHI Shigeru" . "shigeru.kb@gmail.com"))
  :maintainers '(("KOBAYASHI Shigeru" . "shigeru.kb@gmail.com")))
