;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "todoist" "1.1"
  "Extension for interacting and managing todoist tasks."
  '((dash      "2.15.0")
    (transient "0.1.0")
    (org       "8.3.5")
    (emacs     "25.3"))
  :url "https://github.com/abrochard/emacs-todoist"
  :commit "d79b4ea4ea4891635966bfc2c769484d2916be80"
  :revdesc "d79b4ea4ea48"
  :keywords '("todoist" "task" "todo" "comm"))
