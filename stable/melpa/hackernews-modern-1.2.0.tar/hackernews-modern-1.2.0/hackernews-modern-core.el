;;; hackernews-modern-core.el --- Shared definitions for hackernews-modern -*- lexical-binding: t -*-

;; Copyright (C) 2012-2025 The Hackernews.el Authors

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Customization options, faces, API URLs, shared buffer state and
;; rendering helpers used by the other hackernews-modern files.

;;; Code:

(require 'browse-url)
(require 'cus-edit)
(require 'url)
(require 'json)
(require 'widget)
(require 'wid-edit)
(require 'cl-lib)
(require 'seq)

;;;; Customization ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defgroup hackernews-modern nil
  "Hacker News client with modern widget UI."
  :group 'external
  :prefix "hackernews-modern-")

(defcustom hackernews-modern-items-per-page 20
  "Default number of stories to retrieve in one go."
  :package-version '(hackernews-modern . "0.4.0")
  :type 'integer)

(defcustom hackernews-modern-default-feed "top"
  "Default story feed to load.
See `hackernews-modern-feed-names' for supported feed types."
  :package-version '(hackernews-modern . "0.4.0")
  :type '(choice (const :tag "Top stories"  "top")
                 (const :tag "New stories"  "new")
                 (const :tag "Best stories" "best")
                 (const :tag "Ask stories"  "ask")
                 (const :tag "Show stories" "show")
                 (const :tag "Job stories"  "job")))

(defcustom hackernews-modern-suppress-url-status t
  "Whether to suppress messages controlled by `url-show-status'.
When nil, `url-show-status' determines whether certain status
messages are displayed when retrieving online data.  This is
suppressed by default so that the hackernews-modern progress reporter is
not interrupted."
  :package-version '(hackernews-modern . "0.4.0")
  :type 'boolean)

(defcustom hackernews-modern-display-width 80
  "Maximum width for displaying hackernews-modern content."
  :package-version '(hackernews-modern . "0.8.0")
  :type 'integer)

(defcustom hackernews-modern-enable-emojis nil
  "Whether to display emojis in the interface.
When non-nil, feed navigation buttons and comment counts will
include emoji icons for visual enhancement."
  :package-version '(hackernews-modern . "0.8.0")
  :type 'boolean)

(defcustom hackernews-modern-preserve-point t
  "Whether to preserve point when loading more stories.
When nil, point is placed on first new item retrieved."
  :package-version '(hackernews-modern . "0.4.0")
  :type 'boolean)

(defcustom hackernews-modern-internal-browser-function
  (if (functionp 'eww-browse-url)
      #'eww-browse-url
    #'browse-url-text-emacs)
  "Function to load a given URL within Emacs.
See `browse-url-browser-function' for some possible options."
  :package-version '(hackernews-modern . "0.4.0")
  :type (cons 'radio (butlast (cdr (custom-variable-type
                                    'browse-url-browser-function)))))

(defcustom hackernews-modern-comments-in-browser nil
  "Whether to open comments in the browser instead of an Emacs buffer.
When nil, comments are fetched and displayed as a threaded tree
in a dedicated buffer."
  :package-version '(hackernews-modern . "1.1.0")
  :type 'boolean)

(defcustom hackernews-modern-before-render-hook ()
  "Hook called before rendering any new items."
  :package-version '(hackernews-modern . "0.4.0")
  :type 'hook)

(defcustom hackernews-modern-after-render-hook ()
  "Hook called after rendering any new items.
The position of point will not have been affected by the render."
  :package-version '(hackernews-modern . "0.4.0")
  :type 'hook)

(defcustom hackernews-modern-finalize-hook ()
  "Hook called as final step of loading any new items.
The position of point may have been adjusted after the render,
buffer-local feed state will have been updated and the hackernews-modern
buffer will be current and displayed in the selected window."
  :package-version '(hackernews-modern . "0.4.0")
  :type 'hook)

;;;; Faces ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defface hackernews-modern-link
  '((t :inherit link :underline nil))
  "Face used for story title links."
  :package-version '(hackernews-modern . "0.4.0"))

(defface hackernews-modern-comment-count
  '((t :inherit hackernews-modern-link))
  "Face used for comment counts."
  :package-version '(hackernews-modern . "0.4.0"))

(defface hackernews-modern-score
  '((t :inherit default))
  "Face used for the score of a story."
  :package-version '(hackernews-modern . "0.4.0"))

(defface hackernews-modern-logo
  '((t :foreground "#ff6600" :height 1.5))
  "Face used for the \"Y\" in the Hacker News logo."
  :package-version '(hackernews-modern . "0.8.0"))

(defface hackernews-modern-title-text
  '((t :foreground "#ff6600" :height 1.3))
  "Face used for the \"Hacker News\" title text."
  :package-version '(hackernews-modern . "0.8.0"))

(defface hackernews-modern-separator
  '((t :foreground "#666666"))
  "Face used for horizontal separator lines."
  :package-version '(hackernews-modern . "0.8.0"))

(defface hackernews-modern-score-modern
  '((t :foreground "#ff6600"))
  "Face used for story scores."
  :package-version '(hackernews-modern . "0.8.0"))

(defface hackernews-modern-author
  '((t :foreground "#0066cc"))
  "Face used for author names."
  :package-version '(hackernews-modern . "0.8.0"))

(defface hackernews-modern-feed-indicator
  '((t :foreground "#ff6600"))
  "Face used for the current feed indicator."
  :package-version '(hackernews-modern . "0.8.0"))

(defface hackernews-modern-comment-indent
  '((t :inherit hackernews-modern-separator))
  "Face used for the vertical bar that indents nested comments."
  :package-version '(hackernews-modern . "1.1.0"))

(defface hackernews-modern-comment-time
  '((t :inherit shadow))
  "Face used for the age of a comment."
  :package-version '(hackernews-modern . "1.1.0"))

(defface hackernews-modern-own-author
  '((t :inherit hackernews-modern-author :weight bold))
  "Face used for the name of the logged in user in comments."
  :package-version '(hackernews-modern . "1.2.0"))

(defface hackernews-modern-comment-code
  '((t :inherit fixed-pitch))
  "Face used for code blocks inside comments."
  :package-version '(hackernews-modern . "1.1.0"))

;;;; Constants ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defconst hackernews-modern-api-version "v0"
  "Currently supported version of the Hacker News API.")

(defconst hackernews-modern-api-format
  (format "https://hacker-news.firebaseio.com/%s/%%s.json"
          hackernews-modern-api-version)
  "Format of targeted Hacker News API URLs.")

(defconst hackernews-modern-algolia-item-format
  "https://hn.algolia.com/api/v1/items/%s"
  "Format of Algolia Hacker News API item URLs.
Unlike the official API, it returns the whole comment tree of an
item in a single request.")

(defconst hackernews-modern-site-item-format "https://news.ycombinator.com/item?id=%s"
  "Format of Hacker News website item URLs.")

(defconst hackernews-modern-site-host "news.ycombinator.com"
  "Host of the Hacker News website, used for login and posting.")

;;;; Shared state ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar-local hackernews-modern--comments-id nil
  "ID of the item whose comments are shown in the current buffer.")

(defvar-local hackernews-modern--comments-items nil
  "Hash table of the items shown in the current comments buffer.")

;;;; URL helpers ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--comments-url (id)
  "Return Hacker News website URL for item with ID."
  (format hackernews-modern-site-item-format id))

(defun hackernews-modern--format-api-url (fmt &rest args)
  "Construct a Hacker News API URL.
The result of passing FMT and ARGS to `format' is substituted in
`hackernews-modern-api-format'."
  (format hackernews-modern-api-format (apply #'format fmt args)))

(defun hackernews-modern--item-url (id)
  "Return Hacker News API URL for item with ID."
  (hackernews-modern--format-api-url "item/%s" id))

(defun hackernews-modern--site-url (path)
  "Return the Hacker News website URL for PATH."
  (format "https://%s/%s" hackernews-modern-site-host path))

(defun hackernews-modern--user-url (user)
  "Return Hacker News API URL for USER."
  (hackernews-modern--format-api-url "user/%s" user))

(defun hackernews-modern--algolia-item-url (id)
  "Return Algolia Hacker News API URL for item with ID."
  (format hackernews-modern-algolia-item-format id))

;;;; UI helpers ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defconst hackernews-modern--separator-char ?-
  "Character used for horizontal separators.")

(defun hackernews-modern--string-separator ()
  "Return a separator string of `hackernews-modern-display-width' dashes."
  (make-string hackernews-modern-display-width hackernews-modern--separator-char))

(defun hackernews-modern--insert-separator ()
  "Insert a horizontal separator line."
  (insert "\n")
  (insert (propertize (hackernews-modern--string-separator)
                      'face 'hackernews-modern-separator))
  (insert "\n\n"))

(defun hackernews-modern--insert-logo ()
  "Insert the Hacker News logo."
  (insert "\n")
  (insert (propertize "Y " 'face 'hackernews-modern-logo))
  (insert (propertize "Hacker News" 'face 'hackernews-modern-title-text))
  (insert "\n\n"))

(defun hackernews-modern--time-ago (time)
  "Return a human readable age for the Unix timestamp TIME."
  (let ((seconds (- (float-time) time))
        (units '((31536000 . "year") (2592000 . "month") (86400 . "day")
                 (3600 . "hour") (60 . "minute"))))
    (or (cl-loop for (size . name) in units
                 for count = (floor seconds size)
                 when (>= count 1)
                 return (format "%d %s%s ago" count name (if (= count 1) "" "s")))
        "just now")))

;;;; HTML ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(autoload 'xml-substitute-special "xml")

(defun hackernews-modern--decode-entities (string)
  "Replace HTML character references in STRING with their characters."
  (xml-substitute-special
   (replace-regexp-in-string
    "&#\\([xX]?\\)\\([0-9a-fA-F]+\\);"
    (lambda (match)
      (string (string-to-number (match-string 2 match)
                                (if (string-empty-p (match-string 1 match)) 10 16))))
    string t t)))

(defun hackernews-modern--insert-html-text (text faces)
  "Insert TEXT with HTML entities decoded and FACES applied."
  (unless (string-empty-p text)
    (insert (propertize (hackernews-modern--decode-entities text) 'face faces))))

(defun hackernews-modern--insert-html (html)
  "Insert HTML from a Hacker News item as formatted text.
Only the small subset of tags used by Hacker News is handled:
paragraphs, links, italics and code blocks."
  (let ((start (point))
        (pos 0)
        (faces '()))
    (while (string-match "<\\(/?\\)\\([a-zA-Z]+\\)\\([^>]*\\)>" html pos)
      (let ((tag-start (match-beginning 0))
            (tag-end   (match-end 0))
            (closing   (string= (match-string 1 html) "/"))
            (tag       (downcase (match-string 2 html)))
            (attrs     (match-string 3 html)))
        (hackernews-modern--insert-html-text (substring html pos tag-start) faces)
        (setq pos tag-end)
        (pcase tag
          ("p" (unless (or closing (= (point) start))
                 (insert (if (bolp) "\n" "\n\n"))))
          ("i" (if closing
                   (setq faces (remq 'italic faces))
                 (push 'italic faces)))
          ("code" (if closing
                      (setq faces (remq 'hackernews-modern-comment-code faces))
                    (push 'hackernews-modern-comment-code faces)))
          ("pre" (unless (bolp) (insert "\n")))
          ("a" (unless closing
                 (let* ((href (and (string-match "href=\"\\([^\"]*\\)\"" attrs)
                                   (hackernews-modern--decode-entities
                                    (match-string 1 attrs))))
                        (close (or (string-match "</a>" html pos) (length html)))
                        (label (hackernews-modern--decode-entities
                                (replace-regexp-in-string
                                 "<[^>]*>" "" (substring html pos close)))))
                   (if href
                       (widget-create 'url-link
                                      :format "%[%t%]"
                                      :tag label
                                      :help-echo href
                                      href)
                     (insert label))
                   (setq pos (min (length html) (+ close 4)))))))))
    (hackernews-modern--insert-html-text (substring html pos) faces)))

(defun hackernews-modern--html-excerpt (html)
  "Return the beginning of HTML as plain text quoted with \"> \"."
  (with-temp-buffer
    (insert (truncate-string-to-width
             (hackernews-modern--decode-entities
              (replace-regexp-in-string
               "<[^>]*>" ""
               (replace-regexp-in-string "<p>" " " (or html ""))))
             240 nil nil "..."))
    (let ((fill-column 72)
          (fill-prefix "> "))
      (goto-char (point-min))
      (insert "> ")
      (fill-region (point-min) (point-max)))
    (buffer-string)))

(defun hackernews-modern--text-to-html (text)
  "Convert TEXT written for Hacker News to the HTML it stores.
Paragraphs are separated by blank lines and paragraphs whose lines
are all indented by two spaces are code blocks."
  (mapconcat
   (lambda (paragraph)
     (let ((escaped (replace-regexp-in-string
                     ">" "&gt;"
                     (replace-regexp-in-string
                      "<" "&lt;"
                      (replace-regexp-in-string "&" "&amp;" paragraph)))))
       (if (seq-every-p (lambda (line) (string-prefix-p "  " line))
                        (split-string paragraph "\n"))
           (concat "<pre><code>" escaped "\n</code></pre>")
         escaped)))
   (split-string text "\n[ \t]*\n" t)
   "<p>"))

(provide 'hackernews-modern-core)

;;; hackernews-modern-core.el ends here
