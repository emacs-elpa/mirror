;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-latex" "0.22.0"
  "Preview LaTeX math as SVG in LaTeX buffers."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.22.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "b74cb8a99a49751c2ceb099185b128f6a15c0fe4"
  :revdesc "v0.22.0-0-gb74cb8a99a49"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
