;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "readline-complete" "1.0"
  "Offers completions in shell mode."
  ()
  :url "https://github.com/monsanto/readline-complete.el"
  :commit "31adf7cbe34ff555f543a689c816367ff37ec2ec"
  :revdesc "31adf7cbe34f"
  :authors '(("Christopher Monsanto" . "chris@monsan.to"))
  :maintainers '(("Christopher Monsanto" . "chris@monsan.to")))
