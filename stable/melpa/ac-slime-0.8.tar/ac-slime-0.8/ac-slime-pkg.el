;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-slime" "0.8"
  "An auto-complete source using slime completions."
  '((auto-complete "1.4")
    (slime         "2.9")
    (cl-lib        "0.5"))
  :url "https://github.com/purcell/ac-slime"
  :commit "df6c4e88b5ba2d15d47a651ecf7edc0986624112"
  :revdesc "df6c4e88b5ba"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
