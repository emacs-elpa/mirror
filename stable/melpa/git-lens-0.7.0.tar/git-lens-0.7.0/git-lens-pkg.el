;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-lens" "0.7.0"
  "Show new, deleted or modified files in branch."
  '((emacs "24.4"))
  :url "https://github.com/pidu/git-lens"
  :commit "ea49e2e005af977a08331f8caa8f64d102b3b932"
  :revdesc "ea49e2e005af"
  :keywords '("vc" "convenience")
  :authors '(("Peter Stiernström" . "peter@stiernstrom.se"))
  :maintainers '(("Peter Stiernström" . "peter@stiernstrom.se")))
