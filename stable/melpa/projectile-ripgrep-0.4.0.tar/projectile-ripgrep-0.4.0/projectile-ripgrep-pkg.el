;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-ripgrep" "0.4.0"
  "Run ripgrep with Projectile."
  '((ripgrep    "0.3.0")
    (projectile "0.14.0"))
  :url "https://github.com/nlamirault/ripgrep.el"
  :commit "73595f1364f2117db49e1e4a49290bd6d430e345"
  :revdesc "73595f1364f2"
  :keywords '("ripgrep" "projectile")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
