;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-systemd" "0.0.1"
  "Helm's systemd interface."
  '((emacs       "24.4")
    (helm        "1.9.2")
    (with-editor "0"))
  :url "https://github.com/Lompik/helm-systemd"
  :commit "303f77cd78cc012862bb1a4b0937558a64b885e8"
  :revdesc "303f77cd78cc"
  :keywords '("convenience")
  :authors '((nil . "lompik@oriontabArch"))
  :maintainers '((nil . "lompik@oriontabArch")))
