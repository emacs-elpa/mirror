;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "planemo-mode" "0.3"
  "Minor mode for editing Galaxy XML files."
  '((emacs "27.1")
    (dash  "2.17.0"))
  :url "https://gitlab.com/mtekman/planemo-mode.el"
  :commit "5e49dae443edbcf5a26498d7f57b9d9cd8ba3b67"
  :revdesc "5e49dae443ed"
  :keywords '("outlines"))
