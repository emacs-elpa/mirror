;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bulletproof" "0.3"
  "Automatic plain list bullet cycling."
  '((emacs "27.1"))
  :url "https://github.com/pondersson/org-bulletproof"
  :commit "c9d09ff91a8d637ad8c2975bc39288a0e26c98ec"
  :revdesc "c9d09ff91a8d"
  :keywords '("outlines" "convenience")
  :authors '(("Pontus Andersson" . "pondersson@gmail.com"))
  :maintainers '(("Pontus Andersson" . "pondersson@gmail.com")))
