;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-chrome-control" "1.0"
  "Control Chrome tabs with Helm (macOS only)."
  '((emacs     "25.1")
    (helm-core "3.0"))
  :url "https://github.com/xuchunyang/helm-chrome-control"
  :commit "47d7739047d898039bd2ab5bb4038eaf3f88b62b"
  :revdesc "47d7739047d8")
