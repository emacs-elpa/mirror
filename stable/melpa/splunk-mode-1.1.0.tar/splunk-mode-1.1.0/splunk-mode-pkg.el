;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "splunk-mode" "1.1.0"
  "Major Mode for editing Splunk SPL source code."
  '((emacs "27.1"))
  :url "https://github.com/jakewilliami/splunk-mode/"
  :commit "fbc0b5faa2f33a3656f7c549ed9f064a01530dc9"
  :revdesc "1.1.0-0-gfbc0b5faa2f3"
  :keywords '("languages" "splunk" "mode")
  :authors '(("Jake Ireland" . "jakewilliami@icloud.com"))
  :maintainers '(("Jake Ireland" . "jakewilliami@icloud.com")))
