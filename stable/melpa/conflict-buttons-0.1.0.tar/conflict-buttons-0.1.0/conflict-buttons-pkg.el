;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conflict-buttons" "0.1.0"
  "Clickable buttons for smerge-mode conflicts."
  '((emacs "26.1"))
  :url "https://github.com/yourusername/conflict-buttons"
  :commit "0af93ada76e58a7dc3d94b687ee456f5b067d765"
  :revdesc "0af93ada76e5"
  :keywords '("vc" "tools" "convenience")
  :authors '(("Your Name" . "your.email@example.com"))
  :maintainers '(("Your Name" . "your.email@example.com")))
