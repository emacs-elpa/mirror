;;; example-config.el --- Example configurations for conflict-buttons  -*- lexical-binding: t; -*-

;;; Commentary:

;; This file contains example configurations for conflict-buttons.
;; Choose the setup that best fits your workflow.

;;; Code:

;;; ============================================================
;;; Basic Setup
;;; ============================================================

;; Minimal configuration - enable globally
(require 'conflict-buttons)
(conflict-buttons-global-mode 1)

;;; ============================================================
;;; Use-package Setup
;;; ============================================================

;; For users of use-package
(use-package conflict-buttons
  :load-path "~/.emacs.d/lisp/conflict-buttons"
  :config
  (conflict-buttons-global-mode 1))

;;; ============================================================
;;; Straight.el Setup
;;; ============================================================

;; For users of straight.el (update the :repo to match your GitHub username)
(use-package conflict-buttons
  :straight (:host github :repo "yourusername/conflict-buttons")
  :config
  (conflict-buttons-global-mode 1))

;;; ============================================================
;;; Manual Hook Setup
;;; ============================================================

;; If you prefer manual control instead of global mode
(require 'conflict-buttons)
(add-hook 'smerge-mode-hook #'conflict-buttons-setup)

;;; ============================================================
;;; Customization Examples
;;; ============================================================

;; Use ASCII style buttons instead of Unicode
(setq conflict-buttons-style 'ascii)

;; Change the separator between buttons
(setq conflict-buttons-separator " · ")

;; Customize button colors
(custom-set-faces
 '(conflict-buttons-button-face
   ((t (:foreground "#61AFEF" :weight bold))))
 '(conflict-buttons-button-hover-face
   ((t (:background "#E5C07B" :foreground "#282C34" :weight bold)))))

;;; ============================================================
;;; Advanced Configuration
;;; ============================================================

;; Complete setup with custom styling (Doom Emacs / One Dark theme colors)
(use-package conflict-buttons
  :config
  (conflict-buttons-global-mode 1)
  (setq conflict-buttons-style 'unicode
        conflict-buttons-separator " | ")
  (custom-set-faces
   '(conflict-buttons-button-face
     ((t (:foreground "#98C379" :weight bold :underline nil))))
   '(conflict-buttons-button-hover-face
     ((t (:background "#61AFEF" :foreground "#282C34" :weight bold))))))

;;; ============================================================
;;; Integration with Magit
;;; ============================================================

;; conflict-buttons works automatically with Magit's smerge integration
;; No additional configuration needed - just enable conflict-buttons-global-mode

;; Optional: Add a keybinding to toggle conflict-buttons in a buffer
(with-eval-after-load 'smerge-mode
  (define-key smerge-mode-map (kbd "C-c ^ b") #'conflict-buttons-mode))

;;; ============================================================
;;; Lazy Loading Setup
;;; ============================================================

;; Load conflict-buttons only when needed (saves startup time)
(use-package conflict-buttons
  :defer t
  :hook (smerge-mode . conflict-buttons-mode))

;;; ============================================================
;;; Terminal Emacs Setup
;;; ============================================================

;; For terminal Emacs users (buttons won't be clickable, but still visible)
;; You can navigate to them and press RET to activate
(use-package conflict-buttons
  :config
  (conflict-buttons-global-mode 1)
  ;; Use ASCII style for better terminal compatibility
  (setq conflict-buttons-style 'ascii))

;;; example-config.el ends here
