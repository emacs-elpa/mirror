;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsql" "4.3.6"
  "High-level SQL database front-end."
  '((emacs "26.1"))
  :url "https://github.com/magit/emacsql"
  :commit "2fe6d4562b32a170a750d5e80514fbb6b6694803"
  :revdesc "v4.3.6-0-g2fe6d4562b32"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev")))
