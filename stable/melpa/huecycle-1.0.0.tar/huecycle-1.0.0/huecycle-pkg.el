;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "huecycle" "1.0.0"
  "Idle color animation."
  '((emacs "27.1"))
  :url "https://github.com/pnor/huecycle"
  :commit "c343b2085dea11b820d4da6c6183e1102ec08698"
  :revdesc "c343b2085dea"
  :keywords '("faces")
  :authors '(("Phillip O'Reggio" . "https://github.com/pnor")))
