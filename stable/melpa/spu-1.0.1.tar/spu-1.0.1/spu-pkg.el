;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spu" "1.0.1"
  "Silently upgrade package in the background."
  '((emacs  "24.4")
    (signal "1.0")
    (timp   "1.2.0"))
  :url "https://github.com/mola-T/spu"
  :commit "a7dadda5566f5f8d785e8f9540cfcbbfb58eb47d"
  :revdesc "a7dadda5566f"
  :keywords '("convenience" "package")
  :authors '(("Mola-T" . "Mola@molamola.xyz"))
  :maintainers '(("Mola-T" . "Mola@molamola.xyz")))
