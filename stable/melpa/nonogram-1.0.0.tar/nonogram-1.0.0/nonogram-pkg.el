;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nonogram" "1.0.0"
  "Play nonogram (picross) puzzles with SVG graphics."
  '((emacs "27.1"))
  :url "https://git.andros.dev/andros/nonogram.el"
  :commit "ca916d3720484dae9a2e2e7fb53907bd24bd6efd"
  :revdesc "ca916d372048"
  :keywords '("games")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
