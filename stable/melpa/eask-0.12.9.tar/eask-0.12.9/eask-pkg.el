;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "0.12.9"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "4ef950a951ef3a1b6c6f6f75f30c10576e4248e1"
  :revdesc "4ef950a951ef"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
