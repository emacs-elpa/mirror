;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calibredb" "2.14.0"
  "Yet another calibre client."
  '((emacs     "29.1")
    (org       "9.3")
    (transient "0.1.0")
    (s         "1.12.0")
    (dash      "2.17.0")
    (request   "0.3.3")
    (esxml     "0.3.7"))
  :url "https://github.com/chenyanming/calibredb.el"
  :commit "926add4f17c1d367d4ea89c33049d2c12ffd7410"
  :revdesc "926add4f17c1"
  :keywords '("tools")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
