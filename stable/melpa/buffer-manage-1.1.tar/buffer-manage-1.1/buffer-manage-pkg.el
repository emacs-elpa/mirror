;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-manage" "1.1"
  "Manage buffers."
  '((emacs          "26.1")
    (choice-program "0.13")
    (dash           "2.17.0"))
  :url "https://github.com/plandes/buffer-manage"
  :commit "819bbfd9ae2f028361f484bc3b60d751623a2df5"
  :revdesc "v1.1-0-g819bbfd9ae2f"
  :keywords '("internal" "maint"))
