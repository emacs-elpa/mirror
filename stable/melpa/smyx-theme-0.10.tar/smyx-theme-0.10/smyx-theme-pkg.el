;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smyx-theme" "0.10"
  "Smyx Color Theme."
  ()
  :url "https://github.com/tacit7/smyx"
  :commit "eb4da5ea3dfe865f6b082187a4f7bf449524f0fe"
  :revdesc "eb4da5ea3dfe"
  :keywords '("color" "theme" "smyx")
  :authors '(("Uriel G Maldonado" . "uriel781@gmail.com"))
  :maintainers '(("Uriel G Maldonado" . "uriel781@gmail.com")))
