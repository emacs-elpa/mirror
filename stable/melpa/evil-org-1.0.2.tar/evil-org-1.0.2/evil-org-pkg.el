;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-org" "1.0.2"
  "Evil keybindings for org-mode."
  '((emacs "24.4")
    (evil  "1.0"))
  :url "https://github.com/Somelauw/evil-org-mode.git"
  :commit "9d4be14118bf27094a30dbff349b815f098aacbf"
  :revdesc "9d4be14118bf"
  :keywords '("evil" "vim-emulation" "org-mode" "key-bindings" "presets"))
