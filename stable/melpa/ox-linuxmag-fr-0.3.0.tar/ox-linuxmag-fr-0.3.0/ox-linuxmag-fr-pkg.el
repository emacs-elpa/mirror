;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-linuxmag-fr" "0.3.0"
  "Org-mode exporter for the French GNU/Linux Magazine."
  '((emacs "28.1"))
  :url "https://github.com/DamienCassou/ox-linuxmag-fr"
  :commit "2c06d5441e9e67c3ce419bc84b1d4612f64ff40b"
  :revdesc "0.3.0-0-g2c06d5441e9e"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
