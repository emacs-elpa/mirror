;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-rtm" "0.3"
  "Interactive Emacs mode for Remember The Milk."
  ()
  :url "https://codeberg.org/mbunkus/simple-rtm"
  :commit "c1f779840eb91e35370a0416385873c8b16b0b0e"
  :revdesc "c1f779840eb9"
  :keywords '("remember" "the" "milk" "productivity" "todo")
  :authors '(("Moritz Bunkus" . "morit@bunkus.org"))
  :maintainers '(("Moritz Bunkus" . "morit@bunkus.org")))
