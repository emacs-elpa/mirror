;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forge-llm" "0.1.0"
  "LLM integration for generating PR descriptions in Forge."
  '((emacs "25.1")
    (forge "0.3.0")
    (llm   "0.16.1"))
  :url "https://gitlab.com/rogs/forge-llm"
  :commit "b5532bc4454f1dff924c0cb3f67db484f315a0f5"
  :revdesc "b5532bc4454f"
  :keywords '("convenience" "forge" "git" "llm" "github" "gitlab" "pull-request")
  :authors '(("Roger Gonzalez" . "roger@rogs.me"))
  :maintainers '(("Roger Gonzalez" . "roger@rogs.me")))
