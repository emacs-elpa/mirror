;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-nix-shell" "0.3.2"
  "Org local nix-shell."
  '((emacs "27.1")
    (org   "9.4"))
  :url "https://github.com/AntonHakansson/"
  :commit "d9843aa0f62a39b9938a89388e25129ecb39a4cc"
  :revdesc "d9843aa0f62a"
  :keywords '("processes" "outlines")
  :maintainers '(("Anton Hakansson" . "anton@hakanssn.com")))
