;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-vulpea" "0.3.1"
  "Use Consult in tandem with Vulpea."
  '((emacs   "28.1")
    (vulpea  "2.0.0")
    (consult "2.2"))
  :url "https://github.com/fabcontigiani/consult-vulpea"
  :commit "9a8423390c94eca5583ef81bf0582c7161f63563"
  :revdesc "9a8423390c94"
  :keywords '("convenience" "notes" "vulpea")
  :authors '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com"))
  :maintainers '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com")))
