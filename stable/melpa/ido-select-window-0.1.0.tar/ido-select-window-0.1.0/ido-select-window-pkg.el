;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-select-window" "0.1.0"
  "[No description available]."
  '((emacs "24.1"))
  :url "https://github.com/pjones/ido-select-window"
  :commit "14f204e5e8fad97d19534dd0d92c2b922f9c19cd"
  :revdesc "14f204e5e8fa"
  :authors '(("Peter Jones" . "pjones@devalot.com"))
  :maintainers '(("Peter Jones" . "pjones@devalot.com")))
