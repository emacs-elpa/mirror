;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cucumber-goto-step" "0.0.1"
  "Jump to cucumber step definition."
  '((pcre2el "1.5"))
  :url "http://orthogonal.me"
  :commit "bd8902f42f2c285fdfc842d14378f91ffccdd1c9"
  :revdesc "bd8902f42f2c"
  :authors '(("Glen Stampoultzis" . "gstamp@gmail.com"))
  :maintainers '(("Glen Stampoultzis" . "gstamp@gmail.com")))
