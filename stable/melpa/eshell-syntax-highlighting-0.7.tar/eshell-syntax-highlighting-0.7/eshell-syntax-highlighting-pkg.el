;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-syntax-highlighting" "0.7"
  "Highlight eshell commands."
  '((emacs "25.1"))
  :url "https://github.com/akreisher/eshell-syntax-highlighting"
  :commit "8f8ab503359cd4570db2b46ebeed59085d619208"
  :revdesc "8f8ab503359c"
  :keywords '("convenience")
  :authors '(("Alex Kreisher" . "akreisher18@gmail.com"))
  :maintainers '(("Alex Kreisher" . "akreisher18@gmail.com")))
