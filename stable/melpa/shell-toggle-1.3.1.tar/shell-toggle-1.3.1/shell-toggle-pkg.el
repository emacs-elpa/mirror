;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-toggle" "1.3.1"
  "Toggle to and from the shell buffer."
  ()
  :url "https://github.com/knu/shell-toggle.el"
  :commit "9820b0ad6f22c700759555aae8a454a7dc5a46b3"
  :revdesc "9820b0ad6f22"
  :keywords '("processes")
  :authors '(("Mikael Sjödin" . "mic@docs.uu.se")
             ("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Mikael Sjödin" . "mic@docs.uu.se")
                 ("Akinori MUSHA" . "knu@iDaemons.org")))
