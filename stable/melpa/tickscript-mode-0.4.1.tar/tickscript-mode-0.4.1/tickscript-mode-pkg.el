;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tickscript-mode" "0.4.1"
  "A major mode for Tickscript files."
  '((emacs "24.1"))
  :url "https://github.com/msherry/tickscript-mode"
  :commit "6e7564593d7735acc9f3fa670ec6512991cb73a1"
  :revdesc "0.4.1-0-g6e7564593d77"
  :keywords '("languages")
  :authors '(("Marc Sherry" . "msherry@gmail.com"))
  :maintainers '(("Marc Sherry" . "msherry@gmail.com")))
