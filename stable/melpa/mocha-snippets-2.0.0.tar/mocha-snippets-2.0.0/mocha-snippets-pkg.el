;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mocha-snippets" "2.0.0"
  "Yasnippets for the Mocha JS Testing Framework."
  '((yasnippet "0.8.0"))
  :url "https://github.com/cowboyd/mocha-snippets.el"
  :commit "361a3809f755577406e109b9e44d473dfa7c08e0"
  :revdesc "361a3809f755"
  :keywords '("test" "javascript")
  :authors '(("Charles Lowell" . "cowboyd@frontside.io"))
  :maintainers '(("Charles Lowell" . "cowboyd@frontside.io")))
