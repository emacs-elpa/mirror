;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "itasca" "1.0"
  "Major modes for Itasca software data files."
  '((emacs "24"))
  :url "https://github.com/jkfurtney/itasca-emacs/"
  :commit "f38ae35c5cc17e7e3ad86c9e586812bd0ba997cc"
  :revdesc "f38ae35c5cc1"
  :keywords '("itasca" "flac" "3dec" "udec" "flac3d" "pfc" "pfc2d" "pfc3d" "fish")
  :authors '(("Jason Furtney" . "jkfurtney@gmail.com"))
  :maintainers '(("Jason Furtney" . "jkfurtney@gmail.com")))
