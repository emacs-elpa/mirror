;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufshow" "0.1.0"
  "[No description available]."
  ()
  :url "https://github.com/pjones/bufshow"
  :commit "d8424e412d63dcc721c64fbd2ddd2420a03b4e8b"
  :revdesc "d8424e412d63"
  :authors '(("Peter Jones" . "pjones@pmade.com"))
  :maintainers '(("Peter Jones" . "pjones@pmade.com")))
