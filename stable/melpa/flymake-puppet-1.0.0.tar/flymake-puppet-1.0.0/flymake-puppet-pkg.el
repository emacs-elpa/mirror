;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-puppet" "1.0.0"
  "[No description available]."
  '((flymake-easy "0.9"))
  :url "https://github.com/benprew/flymake-puppet"
  :commit "7e507fa8400ead5c59cdae027e4f612c946a28ec"
  :revdesc "7e507fa8400e")
