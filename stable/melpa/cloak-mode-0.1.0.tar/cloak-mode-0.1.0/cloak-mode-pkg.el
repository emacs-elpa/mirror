;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cloak-mode" "0.1.0"
  "A minor mode to cloak sensitive values."
  '((emacs "27.1"))
  :url "https://github.com/erickgnavar/cloak-mode"
  :commit "0875535b283987ee2d4ee64d45a5ab11351c60ad"
  :revdesc "0875535b2839"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
