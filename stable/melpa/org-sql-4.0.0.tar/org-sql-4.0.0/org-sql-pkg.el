;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-sql" "4.0.0"
  "Org-Mode SQL converter."
  '((emacs  "27.1")
    (s      "1.13")
    (f      "0.20.0")
    (dash   "2.19.1")
    (org-ml "5.8.8"))
  :url "https://github.com/ndwarshuis/org-sql"
  :commit "80bea9996de7fa8bc7ff891a91cfaff91111dcd8"
  :revdesc "80bea9996de7"
  :keywords '("org-mode" "data")
  :authors '(("Nathan Dwarshuis" . "natedwarshuis@gmail.com"))
  :maintainers '(("Nathan Dwarshuis" . "natedwarshuis@gmail.com")))
