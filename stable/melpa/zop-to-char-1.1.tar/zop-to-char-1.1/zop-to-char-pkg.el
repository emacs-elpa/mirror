;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zop-to-char" "1.1"
  "A replacement of zap-to-char."
  '((cl-lib "0.5"))
  :url "https://github.com/thierryvolpiatto/zop-to-char"
  :commit "816ea90337db0545a2f0a5079f4d7b3a2822af7d"
  :revdesc "v1.1-0-g816ea90337db"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")))
