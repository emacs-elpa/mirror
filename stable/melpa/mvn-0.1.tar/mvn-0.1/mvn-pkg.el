;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mvn" "0.1"
  "Helpers for compiling with maven."
  ()
  :url "https://github.com/apg/mvn-el"
  :commit "d95ee05b701386a3b81886de29734e4df983e66c"
  :revdesc "d95ee05b7013"
  :keywords '("compilation" "maven" "java"))
