;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-dp" "1"
  "Declarative Local Programming with Org Elements."
  '((cl-lib "0.5"))
  :url "https://github.com/tj64/org-dp"
  :commit "d740c2065120f71762c48877da1a31dea881e98e"
  :revdesc "d740c2065120"
  :authors '(("Thorsten Jolitz" . "tjolitzATgmailDOTcom"))
  :maintainers '(("Thorsten Jolitz" . "tjolitzATgmailDOTcom")))
