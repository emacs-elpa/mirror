;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-search" "0.0.1"
  "Clone repositories by searching github."
  '((magit "2.1.0")
    (gh    "1.0.0"))
  :url "https://github.com/IvanMalison/github-search"
  :commit "1a5c1f8291f4d41e57367a8522699cb08eea8fc4"
  :revdesc "1a5c1f8291f4"
  :keywords '("github" "search" "clone" "api" "gh" "magit")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
