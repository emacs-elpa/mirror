;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-git-autofetch" "0.1.2"
  "Automatically fetch git repositories."
  '((emacs      "25.1")
    (projectile "0.14.0")
    (alert      "1.2"))
  :url "https://github.com/andrmuel/projectile-git-autofetch"
  :commit "4a3eba7658a52c6e955d5f7085cd3fd62b53b9c6"
  :revdesc "4a3eba7658a5"
  :keywords '("tools" "vc")
  :authors '(("Andreas Müller" . "code@0x7.ch"))
  :maintainers '(("Andreas Müller" . "code@0x7.ch")))
