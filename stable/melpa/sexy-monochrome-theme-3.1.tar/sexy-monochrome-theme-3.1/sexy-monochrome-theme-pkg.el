;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sexy-monochrome-theme" "3.1"
  "A sexy dark Emacs >= 24 theme for your sexy code."
  ()
  :url "https://github.com/voloyev/sexy-monochrome-theme"
  :commit "f64714a176d9212c9fa82355dd8ec89587ce13f0"
  :revdesc "f64714a176d9"
  :keywords '("themes")
  :authors '(("Volodymyr Yevtushenko" . "vol.yevtushenko@ukr.net"))
  :maintainers '(("Volodymyr Yevtushenko" . "vol.yevtushenko@ukr.net")))
