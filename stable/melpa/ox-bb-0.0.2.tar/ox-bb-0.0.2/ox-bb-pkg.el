;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-bb" "0.0.2"
  "BBCode Back-End for Org Export Engine."
  '((emacs "24.4")
    (org   "8.0"))
  :url "https://github.com/mmitch/ox-bb"
  :commit "4d0a3ea6c4509ecb73a288da11140b588a902e76"
  :revdesc "4d0a3ea6c450"
  :keywords '("bbcode" "org" "export" "outlines")
  :authors '(("Christian Garbs" . "mitch@cgarbs.de"))
  :maintainers '(("Christian Garbs" . "mitch@cgarbs.de")))
