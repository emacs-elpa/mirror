;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "signal" "1.0"
  "Advance hook."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/mola-T/signal"
  :commit "dbfd93dc255eb97f9ac484035ec6cf3eab71de08"
  :revdesc "dbfd93dc255e"
  :keywords '("internal" "lisp" "processes" "tools")
  :authors '(("Mola-T" . "Mola@molamola.xyz"))
  :maintainers '(("Mola-T" . "Mola@molamola.xyz")))
