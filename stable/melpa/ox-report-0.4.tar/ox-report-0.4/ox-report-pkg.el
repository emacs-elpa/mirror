;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-report" "0.4"
  "Export your org file to minutes report PDF file."
  '((emacs   "24.4")
    (org-msg "0"))
  :url "https://github.com/DarkBuffalo/ox-report"
  :commit "1e730396b8b7aa5101b3e3f538d6d4c15514f415"
  :revdesc "1e730396b8b7"
  :keywords '("org" "outlines" "report" "exporter" "meeting" "minutes")
  :authors '(("Matthias David" . "matthias@gnu.re"))
  :maintainers '(("Matthias David" . "matthias@gnu.re")))
