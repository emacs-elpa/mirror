;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soothe-theme" "2.1.8"
  "A dark colorful theme."
  '((emacs      "24.3")
    (autothemer "0.2"))
  :url "https://github.com/emacsfodder/emacs-soothe-theme"
  :commit "d8aee0fca549d535ebb7b5fd1a8017f12925d16b"
  :revdesc "d8aee0fca549"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
