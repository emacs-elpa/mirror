;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bibslurp" "0.0.2"
  "Retrieve BibTeX entries from NASA ADS."
  '((s    "1.6.0")
    (dash "1.5.0"))
  :url "https://github.com/mkmcc/bibslurp"
  :commit "597361013befaacb6a44fbf5a7000ea5c764d4dd"
  :revdesc "597361013bef"
  :keywords '("bibliography" "nasa ads")
  :authors '(("Mike McCourt" . "mkmcc@astro.berkeley.edu"))
  :maintainers '(("Mike McCourt" . "mkmcc@astro.berkeley.edu")))
