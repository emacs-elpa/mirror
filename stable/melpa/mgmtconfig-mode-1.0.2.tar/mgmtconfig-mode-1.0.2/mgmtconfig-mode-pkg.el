;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mgmtconfig-mode" "1.0.2"
  "Mgmt configuration management language."
  '((emacs "24.3"))
  :url "https://github.com/purpleidea/mgmt/misc/emacs"
  :commit "2a08fa18cd3d0ba4a6433bdd9c4c0f3e85ed7528"
  :revdesc "1.0.2-0-g2a08fa18cd3d"
  :keywords '("languages")
  :authors '(("Peter Oliver" . "mgmtconfig@mavit.org.uk"))
  :maintainers '(("Mgmt contributors" . "https://github.com/purpleidea/mgmt")))
