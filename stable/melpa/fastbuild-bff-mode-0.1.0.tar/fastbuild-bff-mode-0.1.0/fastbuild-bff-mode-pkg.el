;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fastbuild-bff-mode" "0.1.0"
  "Major mode for FASTBuild BFF files."
  '((emacs "26.1"))
  :url "https://github.com/pbibergal/fastbuild-bff-mode"
  :commit "d42a661a2a2bcbb762fc9b06bf9085a1e99c272d"
  :revdesc "d42a661a2a2b"
  :keywords '("languages" "tools" "build")
  :authors '(("Pavel Bibergal" . "cyberkm@gmail.com"))
  :maintainers '(("Pavel Bibergal" . "cyberkm@gmail.com")))
