;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "racket-mode" "1"
  "Racket editing, REPL, and more."
  '((emacs "25.1"))
  :url "https://www.racket-mode.com/"
  :commit "74999273195dfeed98bfbe63114df1002e53eee6"
  :revdesc "74999273195d")
