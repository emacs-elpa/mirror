;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "veri-kompass" "0.2"
  "Verilog codebase navigation facility for GNU Emacs."
  '((emacs  "25")
    (cl-lib "0.5"))
  :url "https://gitlab.com/koral/veri-kompass"
  :commit "70e0770e17cdcb3bbe432675c936a83bc51f6a3c"
  :revdesc "70e0770e17cd"
  :keywords '("languages" "extensions" "verilog" "hardware" "rtl")
  :maintainers '((nil . "andrea_corallo@yahoo.it")))
