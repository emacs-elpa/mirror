;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lavender-theme" "20141116"
  "An Emacs 24 theme based on Lavender (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "b4868e156dc27ec866d9996152d1ab1281fb9e6b"
  :revdesc "b4868e156dc2")
