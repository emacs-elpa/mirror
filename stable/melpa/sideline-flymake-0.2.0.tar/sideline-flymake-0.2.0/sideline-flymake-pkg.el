;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-flymake" "0.2.0"
  "Show flymake errors with sideline."
  '((emacs    "28.1")
    (sideline "0.1.0"))
  :url "https://github.com/emacs-sideline/sideline-flymake"
  :commit "87459e2b083674520d7fc4ee36b6b04c990b2e4f"
  :revdesc "87459e2b0836"
  :keywords '("convenience" "flymake")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
