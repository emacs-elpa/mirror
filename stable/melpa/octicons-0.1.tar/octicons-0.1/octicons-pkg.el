;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "octicons" "0.1"
  "Octicons utility."
  '((cl-lib "0.5"))
  :url "https://github.com/syohex/emacs-octicons"
  :commit "77bb1a49045f89b3eaf9bcffeefbb9e1abaee556"
  :revdesc "77bb1a49045f"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
