;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-checkpatch" "0.1"
  "Flyckeck support for checkpatch.pl tool."
  '((emacs    "25")
    (flycheck "30"))
  :url "https://github.com/zpp0/flycheck-checkpatch"
  :commit "aca98ea79f8b26a95f9dbdd4142b01fdd2def866"
  :revdesc "aca98ea79f8b"
  :authors '(("Alexander Yarygin" . "yarygin.alexander@gmail.com"))
  :maintainers '(("Alexander Yarygin" . "yarygin.alexander@gmail.com")))
