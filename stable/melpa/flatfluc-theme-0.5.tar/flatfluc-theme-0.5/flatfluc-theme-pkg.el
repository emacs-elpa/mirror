;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatfluc-theme" "0.5"
  "Custom merge for flucui and flatui themes ;;."
  '((emacs "26.1"))
  :url "https://github.com/seblemaguer/flatfluc-theme"
  :commit "ee8e3c440f3657d2427349fa36557cef2f0fb76d"
  :revdesc "ee8e3c440f36"
  :keywords '("lisp")
  :authors '(("Sébastien Le Maguer" . "lemagues@tcd.ie"))
  :maintainers '(("Sébastien Le Maguer" . "lemagues@tcd.ie")))
