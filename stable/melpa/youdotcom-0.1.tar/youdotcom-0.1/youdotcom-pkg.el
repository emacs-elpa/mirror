;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youdotcom" "0.1"
  "You.com search in Emacs."
  ()
  :url "https://github.com/SamuelVanie/youdotcom.el"
  :commit "05f9951fa51dad08b0db5672eddb678f601b39cc"
  :revdesc "05f9951fa51d"
  :keywords '("ai" "you.com" "search" "assistant")
  :authors '(("Samuel Michael Vanié" . "samuelmichaelvanie@gmail.com"))
  :maintainers '(("Samuel Michael Vanié" . "samuelmichaelvanie@gmail.com")))
