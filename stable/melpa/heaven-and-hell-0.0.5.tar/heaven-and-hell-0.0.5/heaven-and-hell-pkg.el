;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "heaven-and-hell" "0.0.5"
  "Easy toggle light/dark themes."
  '((emacs "24.4"))
  :url "https://github.com/valignatev/heaven-and-hell"
  :commit "e1febfd60d060c110a1e43c5f093cd8537251308"
  :revdesc "e1febfd60d06"
  :keywords '("faces")
  :authors '(("Valentin Ignatev" . "valentignatev@gmail.com"))
  :maintainers '(("Valentin Ignatev" . "valentignatev@gmail.com")))
