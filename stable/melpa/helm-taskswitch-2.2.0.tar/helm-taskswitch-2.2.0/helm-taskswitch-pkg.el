;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-taskswitch" "2.2.0"
  "Use helm to switch windows, browser tabs and buffers."
  '((emacs     "28.1")
    (helm      "3.0")
    (websocket "1.15"))
  :url "https://github.com/bdc34/helm-taskswitch"
  :commit "2337812ad304a1a02bf7215628fdef4ebb0c27a1"
  :revdesc "v2.2.0-0-g2337812ad304"
  :keywords '("frames")
  :authors '(("Brian Caruso" . "briancaruso@gmail.com"))
  :maintainers '(("Brian Caruso" . "briancaruso@gmail.com")))
