;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "io-mode" "20100405"
  "Major mode to edit Io language files in Emacs."
  ()
  :url "http://bitbucket.com/bobry/io-mode"
  :commit "2d0049a896f7a9ec9fcdfcf240595f99e0dbb427"
  :revdesc "2d0049a896f7"
  :keywords '("languages" "io")
  :authors '(("Sergei Lebedev" . "superbobry@gmail.com"))
  :maintainers '(("Sergei Lebedev" . "superbobry@gmail.com")))
