;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-nand2tetris" "0.0.1"
  "Company backend for nand2tetris major mode."
  '((company "0.5")
    (cl-lib  "0.5.0"))
  :url "http://www.github.com/CestDiego/nand2tetris.el/"
  :commit "2c65e7570dc19524529a337fac5fd247977fa8da"
  :revdesc "2c65e7570dc1"
  :keywords '("nand2tetris" "hdl" "company")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")))
