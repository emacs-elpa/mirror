;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpt-mode" "0.0.1"
  "Major mode for editing PHPT test code."
  '((emacs    "25")
    (polymode "0.1.5")
    (php-mode "1.21.2"))
  :url "https://github.com/emacs-php/phpt-mode"
  :commit "310579e5db57c344460f74239bd1a8fc0d6ddf33"
  :revdesc "310579e5db57"
  :keywords '("languages" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
