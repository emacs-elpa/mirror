;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outlook" "0.1"
  "Send emails in MS Outlook style."
  '((emacs "24.4"))
  :url "https://github.com/asavonic/outlook.el"
  :commit "5847c6f13b106cb54529080e9050be5b8b5be867"
  :revdesc "5847c6f13b10"
  :keywords '("mail"))
