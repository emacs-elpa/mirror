;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graph-fa2" "0.2.3"
  "ForceAtlas2 pure-elisp background-cached engine."
  '((emacs "27.1"))
  :url "https://github.com/elij/graph-fa2"
  :commit "17cbd4b18979cb468e3822d9ea994454ac642992"
  :revdesc "17cbd4b18979"
  :keywords '("multimedia" "graphs" "visualization")
  :authors '(("Elijah Charles" . "https://github.com/elij"))
  :maintainers '(("Elijah Charles" . "https://github.com/elij")))
