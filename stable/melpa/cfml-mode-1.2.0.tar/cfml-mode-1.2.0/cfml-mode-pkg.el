;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfml-mode" "1.2.0"
  "Emacs mode for editing CFML files."
  '((emacs "25"))
  :url "https://github.com/am2605/cfml-mode"
  :commit "356755e4753ac9926f7b4ca8e30eac0b0e61e2ce"
  :revdesc "356755e4753a"
  :authors '(("Andrew Myers" . "am2605@gmail.com"))
  :maintainers '(("Andrew Myers" . "am2605@gmail.com")))
