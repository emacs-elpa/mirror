;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grammarly" "0.3.0"
  "Grammarly API interface."
  '((emacs     "24.4")
    (s         "1.12.0")
    (request   "0.3.0")
    (websocket "1.6"))
  :url "https://github.com/jcs-elpa/grammarly"
  :commit "1fd3ed0fad915d3c5c1a2eb055bb3b91a949be21"
  :revdesc "1fd3ed0fad91"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
