;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ripgrep" "0.4.0"
  "Front-end for ripgrep, a command line search tool."
  ()
  :url "https://github.com/nlamirault/ripgrep.el"
  :commit "73595f1364f2117db49e1e4a49290bd6d430e345"
  :revdesc "73595f1364f2"
  :keywords '("ripgrep" "ack" "pt" "ag" "sift" "grep" "search")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
