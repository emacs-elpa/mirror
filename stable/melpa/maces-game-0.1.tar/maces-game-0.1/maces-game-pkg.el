;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maces-game" "0.1"
  "[No description available]."
  '((dash "2.13.0"))
  :url "https://github.com/pawelbx/anagram-game"
  :commit "d00dc6f775ef399adc21274ce1e3556439608f9a"
  :revdesc "d00dc6f775ef"
  :keywords '("games" "word games" "anagram")
  :authors '(("Pawel Bokota" . "pawelb.lnx@gmail.com"))
  :maintainers '(("Pawel Bokota" . "pawelb.lnx@gmail.com")))
