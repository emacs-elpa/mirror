;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-aider" "0.1.0"
  "Org Babel functions for Aider.el integration."
  '((emacs "27.1")
    (org   "9.4")
    (aider "0.1.0"))
  :url "https://github.com/yourusername/ob-aider"
  :commit "5e4cb84576b4d1ee103e240ee92cf01d967ea1f0"
  :revdesc "5e4cb84576b4"
  :keywords '("literate programming" "reproducible research" "ai" "aider")
  :authors '(("Your Name" . "your.email@example.com"))
  :maintainers '(("Your Name" . "your.email@example.com")))
