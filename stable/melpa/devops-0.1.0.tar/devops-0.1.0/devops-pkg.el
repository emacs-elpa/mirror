;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devops" "0.1.0"
  "Infrastructure as an org file."
  '((emacs "29.1"))
  :url "https://github.com/kpassapk/devops.el"
  :commit "da9823575f205611bd35ffeb925181ef2122e69a"
  :revdesc "da9823575f20"
  :keywords '("tools" "processes" "outlines")
  :authors '(("Kyle S Passarelli" . "kyle.passarelli@gmail.com"))
  :maintainers '(("Kyle S Passarelli" . "kyle.passarelli@gmail.com")))
