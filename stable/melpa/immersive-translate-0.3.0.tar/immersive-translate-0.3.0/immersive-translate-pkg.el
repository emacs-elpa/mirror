;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "immersive-translate" "0.3.0"
  "Translate the current buffer immersively."
  '((emacs "28.2"))
  :url "https://github.com/Elilif/emacs-immersive-translate"
  :commit "683e30bf3dcc1680666140a43a5ba056e4846bad"
  :revdesc "683e30bf3dcc"
  :keywords '("translation")
  :authors '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainers '(("Eli Qian" . "eli.q.qian@gmail.com")))
