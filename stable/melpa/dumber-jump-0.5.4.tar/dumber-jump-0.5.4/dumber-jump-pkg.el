;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumber-jump" "0.5.4"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "24.3")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/zenspider/dumber-jump"
  :commit "0b0c8af5cc7e3adec80f4bbe224b4e6da21e8862"
  :revdesc "0b0c8af5cc7e"
  :keywords '("tools"))
