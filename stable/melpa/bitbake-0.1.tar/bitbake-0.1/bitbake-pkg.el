;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbake" "0.1"
  "Running bitbake from emacs."
  '((emacs "24.1")
    (dash  "2.6.0"))
  :url "https://github.com/canatella/bitbake-mode"
  :commit "efb1a9a8a9fe4dcbb5343ff714cfc5b3abca4e8b"
  :revdesc "efb1a9a8a9fe"
  :keywords '("convenience"))
