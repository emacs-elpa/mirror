;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chronos" "1.3"
  "Multiple simultaneous countdown / countup timers."
  '((emacs   "27.1")
    (consult "0.16"))
  :url "https://github.com/DarkBuffalo/chronos"
  :commit "34ab6a7fab4441c500036b8a20923295397bb037"
  :revdesc "34ab6a7fab44"
  :keywords '("calendar")
  :authors '(("David Knight" . "dxknight@opmbx.org"))
  :maintainers '(("David Knight" . "dxknight@opmbx.org")))
