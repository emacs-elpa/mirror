;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bind-key" "0.1"
  "Helm-source for for bind-key."
  '((bind-key "1.0")
    (helm     "1.6.4"))
  :url "https://github.com/myuhe/helm-bind-key.el"
  :commit "c69e29a534e33198ddbcc4a3cafa879c35456aa1"
  :revdesc "c69e29a534e3"
  :keywords '("convenience" "emulation")
  :authors '(("Yuhei Maeda" . "yuhei.maeda_at_gmail.com")))
