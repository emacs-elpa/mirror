;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dbc" "0.1"
  "Control how to open buffers."
  '((emacs  "24.4")
    (cl-lib "0.5")
    (ht     "2.3"))
  :url "https://gitlab.com/matsievskiysv/display-buffer-control"
  :commit "5123477396a562fae350a89fbed79464cc498bc9"
  :revdesc "5123477396a5"
  :keywords '("convenience"))
