;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ewal-doom-themes" "0.2.1"
  "Dread the colors of darkness."
  '((emacs       "25")
    (ewal        "0.1")
    (doom-themes "0.1"))
  :url "https://gitlab.com/jjzmajic/ewal"
  :commit "732a2f4abb480f9f5a3249af822d8eb1e90324e3"
  :revdesc "732a2f4abb48"
  :keywords '("faces"))
