;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lispyville" "0.1"
  "A minor mode for integrating evil with lispy."
  '((lispy "0")
    (evil  "0"))
  :url "https://github.com/noctuid/lispyville"
  :commit "fdfdcb993fe6ec5812c1a730550bae713be97d7a"
  :revdesc "fdfdcb993fe6"
  :keywords '("vim" "evil" "lispy" "lisp" "parentheses")
  :authors '(("Fox Kiester" . "noct@openmailbox.org"))
  :maintainers '(("Fox Kiester" . "noct@openmailbox.org")))
