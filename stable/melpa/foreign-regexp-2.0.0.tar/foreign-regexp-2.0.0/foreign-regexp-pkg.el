;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "foreign-regexp" "2.0.0"
  "Search and replace by foreign regexp."
  ()
  :url "https://github.com/k-talo/foreign-regexp.el"
  :commit "5a82e2a2fb277c1ea02064c859445a99f4256d44"
  :revdesc "5a82e2a2fb27"
  :keywords '("convenience" "emulations" "matching" "tools" "unix" "wp")
  :authors '(("K-talo Miyazaki" . "KeitarodotMiyazakiatgmaildotcom"))
  :maintainers '(("K-talo Miyazaki" . "KeitarodotMiyazakiatgmaildotcom")))
