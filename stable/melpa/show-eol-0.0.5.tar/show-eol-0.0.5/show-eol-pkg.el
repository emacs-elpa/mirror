;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "show-eol" "0.0.5"
  "Show end of line symbol in buffer."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/show-eol"
  :commit "02fdb5b2832889afd6cad5c517da9b1e4611c766"
  :revdesc "02fdb5b28328"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
