;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proxy-mode" "0.1"
  "A minor mode to toggle proxy."
  '((emacs "25"))
  :url "https://github.com/stardiviner/proxy-mode"
  :commit "b3cea94c83deb5af950221b6e8723137cf265cbe"
  :revdesc "b3cea94c83de"
  :keywords '("comm" "proxy")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
