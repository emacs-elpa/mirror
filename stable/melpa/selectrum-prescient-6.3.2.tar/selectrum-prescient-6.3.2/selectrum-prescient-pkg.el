;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selectrum-prescient" "6.3.2"
  "Prescient.el + Selectrum."
  '((emacs     "25.1")
    (prescient "6.1.0")
    (selectrum "3.1"))
  :url "https://github.com/raxod502/prescient.el"
  :commit "87e2d2f2ddf24f591a5f70cc90d2afb4537caa18"
  :revdesc "87e2d2f2ddf2"
  :keywords '("extensions")
  :authors '(("Radian LLC" . "contact+prescient@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+prescient@radian.codes")))
