;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haskell-emacs" "4.0.3"
  "Write emacs extensions in haskell."
  ()
  :url "https://github.com/knupfer/haskell-emacs"
  :commit "a2c6a079175904689eed7c6c200754bfa85d1ed9"
  :revdesc "a2c6a0791759"
  :keywords '("haskell" "emacs" "ffi"))
