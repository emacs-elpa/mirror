;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cerbere" "0.1.0"
  "Unit testing in Emacs for several programming languages."
  '((s        "1.9.0")
    (f        "0.16.0")
    (go-mode  "20140409")
    (pkg-info "0.5"))
  :url "https://github.com/nlamirault/cerbere"
  :commit "11de1e7ec5126083ae697f5a9993facdb9895f9d"
  :revdesc "0.1.0-0-g11de1e7ec512"
  :keywords '("python" "go" "php" "tests" "tdd")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
