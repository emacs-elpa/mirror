;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.950"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "3b1474f0c50cf276df1c8e4bca7cb9c00b484fd3"
  :revdesc "3b1474f0c50c"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
