;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "private-comments-mode" "1.0.0"
  "Minor mode for masukomi/private_comments."
  '((emacs "27.1"))
  :url "https://github.com/masukomi/private-comments-mode"
  :commit "9d7a650278749cdbcc2564b54b15d66be8213efc"
  :revdesc "v1.0.0-0-g9d7a65027874"
  :keywords '("tools")
  :authors '(("Richard Chiang" . "richard@commandlinesystems.com")
             ("Kay Rhodes" . "masukomi@masukomi.org"))
  :maintainers '(("Richard Chiang" . "richard@commandlinesystems.com")
                 ("Kay Rhodes" . "masukomi@masukomi.org")))
