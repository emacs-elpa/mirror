;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-overlay" "0.1.1"
  "Display eldoc with contextual documentation overlay."
  '((emacs       "24.3")
    (inline-docs "1.0.1")
    (quick-peek  "1.0"))
  :url "https://github.com/stardiviner/eldoc-overlay"
  :commit "bf0548196a1e0f1c28be38b6f29e1107a49839fd"
  :revdesc "bf0548196a1e"
  :keywords '("documentation" "eldoc" "overlay")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
