;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-exchange" "0.41"
  "Exchange text more easily within Evil."
  '((evil   "1.2.8")
    (cl-lib "0.3"))
  :url "https://github.com/Dewdrops/evil-exchange"
  :commit "47691537815150715e64e6f6ec79be7746c96120"
  :revdesc "476915378151"
  :keywords '("evil" "plugin")
  :authors '(("Dewdrops" . "v_v_4474@126.com"))
  :maintainers '(("Dewdrops" . "v_v_4474@126.com")))
