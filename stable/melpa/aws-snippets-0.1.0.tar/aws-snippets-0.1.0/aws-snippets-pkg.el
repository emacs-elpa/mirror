;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aws-snippets" "0.1.0"
  "Yasnippets for AWS."
  '((yasnippet "0.8.0"))
  :url "https://github.com/baron42bba/aws-snippets"
  :commit "f483f778ad8d99a3c037b2c819ccbbf3624c8023"
  :revdesc "f483f778ad8d"
  :keywords '("snippets"))
