;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-latex" "0.25.2"
  "Preview LaTeX math as SVG in LaTeX buffers."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.25.2"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "0328d65a356051fde079b8ca8e29aa58cc5935cd"
  :revdesc "v0.25.2-0-g0328d65a3560"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
