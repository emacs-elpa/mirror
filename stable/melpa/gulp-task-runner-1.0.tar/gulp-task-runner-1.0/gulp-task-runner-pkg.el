;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gulp-task-runner" "1.0"
  "Gulp task runner."
  ()
  :url "https://github.com/NicolasPetton/gulp-task-runner"
  :commit "9c8abc1094807003d6fbc393205dbd45c3f612d3"
  :revdesc "9c8abc109480"
  :keywords '("convenience" "javascript")
  :authors '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")))
