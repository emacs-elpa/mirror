;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "applescript-mode" "0.1"
  "Major mode for editing AppleScript source."
  ()
  :url "https://github.com/emacsorphanage/applescript-mode"
  :commit "42b3db3838821f240e05752de4337359d25d8c04"
  :revdesc "42b3db383882"
  :keywords '("languages" "tools")
  :authors '(("sakito" . "sakito@users.sourceforge.jp"))
  :maintainers '(("sakito" . "sakito@users.sourceforge.jp")))
