;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "celery" "0.0.3"
  "A minor mode to draw stats from celery and more?."
  '((emacs           "24")
    (dash-functional "2.11.0")
    (s               "1.9.0")
    (deferred        "0.3.2"))
  :url "https://github.com/ardumont/emacs-celery"
  :commit "163ebede3f6a7f59202ff319675b0873dd1de365"
  :revdesc "163ebede3f6a"
  :keywords '("celery" "convenience")
  :authors '(("ardumont" . "eniotna.t@gmail.com"))
  :maintainers '(("ardumont" . "eniotna.t@gmail.com")))
