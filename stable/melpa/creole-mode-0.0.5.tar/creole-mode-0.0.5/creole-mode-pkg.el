;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "creole-mode" "0.0.5"
  "A markup mode for creole."
  ()
  :url "https://github.com/nicferrier/creole-mode"
  :commit "b568f9ff9630674dbc8b04633c2b41d4f1a3b715"
  :revdesc "b568f9ff9630"
  :keywords '("hypermedia" "wp")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
