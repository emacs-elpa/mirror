;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persistent-soft" "0.8.10"
  "Persistent storage, returning nil on failure."
  '((pcache     "0.3.1")
    (list-utils "0.4.2"))
  :url "https://github.com/rolandwalker/persistent-soft"
  :commit "a1e0ddf2a12a6f18cab565dee250f070384cbe02"
  :revdesc "v0.8.10-0-ga1e0ddf2a12a"
  :keywords '("data" "extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
