;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdshader-mode" "0.1"
  "Major mode for Godot gdshader."
  '((glsl-mode "2.4"))
  :url "https://github.com/bbbscarter/gdshader-mode"
  :commit "19369cf334c6e00a75c1f37ba5b3ac6caf31707d"
  :revdesc "19369cf334c6"
  :keywords '("languages" "opengl" "gpu" "godot")
  :authors '(("Simon Carter" . "bbbscarter@gmail.com"))
  :maintainers '(("Simon Carter" . "bbbscarter@gmail.com")))
