;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cycle-resize" "0.5.0"
  "Cycle resize the current window horizontally or vertically."
  ()
  :url "http://qsdfgh.com/"
  :commit "e69b538fdf76e50ac85982fa36874bd4d4056aca"
  :revdesc "e69b538fdf76")
