;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evm-mode" "0.0.1"
  "Major mode for editing Ethereum EVM bytecode."
  ()
  :url "https://github.com/taquangtrung/emacs-evm-mode"
  :commit "a4c06d098d2f21055728331e5bfe475a5951419e"
  :revdesc "a4c06d098d2f"
  :keywords '("ethereum" "evm bytcode"))
