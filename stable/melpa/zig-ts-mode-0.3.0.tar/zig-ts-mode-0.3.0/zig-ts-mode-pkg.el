;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zig-ts-mode" "0.3.0"
  "Major mode for Zig code."
  '((emacs "29.1"))
  :url "https://codeberg.org/meow_king/zig-ts-mode"
  :commit "74c71a7859978dea5d299a1eea1548b3751af0ae"
  :revdesc "74c71a785997"
  :keywords '("zig" "languages" "tree-sitter")
  :authors '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers '(("meowking" . "mr.meowking@tutamail.com")))
