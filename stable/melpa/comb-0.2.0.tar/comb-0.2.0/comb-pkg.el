;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comb" "0.2.0"
  "Interactive grep tool for manual static analysis."
  '((emacs "25.1"))
  :url "https://github.com/cyrus-and/comb"
  :commit "8a68d313bf429763eb8aa78ece00230a668f2a1f"
  :revdesc "8a68d313bf42"
  :keywords '("matching")
  :authors '(("Andrea Cardaci" . "cyrus.and@gmail.com"))
  :maintainers '(("Andrea Cardaci" . "cyrus.and@gmail.com")))
