;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hc-zenburn-theme" "0.0.0.20150928.394"
  "An higher contrast version of the Zenburn theme."
  ()
  :url "https:github.com/edran/hc-zenburn-emacs"
  :commit "fd0024a5191cdce204d91c8f1db99ba31640f6e9"
  :revdesc "fd0024a5191c"
  :authors '(("Nantas Nardelli" . "nantas.nardelli@gmail.com"))
  :maintainers '(("Nantas Nardelli" . "nantas.nardelli@gmail.com")))
