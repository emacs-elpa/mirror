;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "w32-browser" "235"
  "Run Windows application associated with a file."
  ()
  :url "http://www.emacswiki.org/w32-browser.el"
  :commit "a8126b60bf18193e8e4ec6f699b5694b6f71a062"
  :revdesc "a8126b60bf18"
  :keywords '("mouse" "dired" "w32" "explorer")
  :maintainers '(("Drew Adams (concat \"drew.adams\" \"oracle\" \".com\"" . "\"@\" ")))
