;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pretty-speedbar" "0.2"
  "Make speedbar pretty."
  '((emacs "27.1"))
  :url "ADD!"
  :commit "875e136308325a46eaed122a3095a95b9d08517b"
  :revdesc "875e13630832"
  :keywords '("speedbar" "pretty speedbar" "sr-speedbar"))
