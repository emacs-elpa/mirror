;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recomplete" "0.2"
  "Immediately (re)complete actions."
  '((emacs "26.1"))
  :url "https://gitlab.com/ideasman42/emacs-recomplete"
  :commit "2b38ca25e3392636fe936d3edad447970279a463"
  :revdesc "2b38ca25e339"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
