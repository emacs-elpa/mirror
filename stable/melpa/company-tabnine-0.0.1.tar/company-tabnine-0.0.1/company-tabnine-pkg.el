;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-tabnine" "0.0.1"
  "A company-mode backend for TabNine, the all-language autocompleter: https://tabnine.com/."
  '((emacs          "24.3")
    (company        "0.9.3")
    (cl-lib         "0.5")
    (json           "0")
    (unicode-escape "0")
    (s              "0"))
  :url "https://github.com/TommyX12/company-tabnine/"
  :commit "438a4fcbbe194eb3678c38d10898c63344f54ed4"
  :revdesc "438a4fcbbe19"
  :keywords '("convenience")
  :authors '(("Tommy Xiang" . "tommyx058@gmail.com"))
  :maintainers '(("Tommy Xiang" . "tommyx058@gmail.com")))
