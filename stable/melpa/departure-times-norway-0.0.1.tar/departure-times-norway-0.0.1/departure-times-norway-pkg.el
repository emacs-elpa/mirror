;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "departure-times-norway" "0.0.1"
  "Description."
  '((emacs   "27.1")
    (persist "0.6.1"))
  :url "https://github.com/hsolg/emacs-departure-times-norway"
  :commit "fa2880ee8e896c794b4b72641dec2c7531e84287"
  :revdesc "fa2880ee8e89"
  :keywords '("transport")
  :authors '(("Henrik Solgaard" . "henrik.solgaard@gmail.com"))
  :maintainers '(("Henrik Solgaard" . "henrik.solgaard@gmail.com")))
