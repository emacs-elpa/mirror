;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "db-pg" "0.0.3"
  "A PostgreSQL adapter for emacs-db."
  '((pg "0.12")
    (db "0.0.6"))
  :url "https://github.com/nicferrier/emacs-db-pg"
  :commit "58f7521acf0b9da12cb19547c0708f680bb5e822"
  :revdesc "58f7521acf0b"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Nic Ferrier" . "nic@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nic@ferrier.me.uk")))
