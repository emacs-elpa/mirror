;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-jump-to-list" "1.0"
  "Mu4e jump-to-list extension."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/wavexx/mu4e-jump-to-list.el"
  :commit "e5b008163c49621b7f4231c450834345c936b530"
  :revdesc "e5b008163c49"
  :keywords '("mu4e" "mail" "convenience")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
