;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doc-show-inline" "0.1"
  "Show doc-strings found in external files."
  '((emacs "26.2"))
  :url "https://gitlab.com/ideasman42/emacs-doc-show-inline"
  :commit "1c5837d2a667d977a1bd90ba44ebd911cc660f26"
  :revdesc "1c5837d2a667"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
