;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sphinx-mode" "1.0.0"
  "Minor mode providing sphinx support."
  '((f    "0.20.0")
    (dash "2.14.1"))
  :url "https://github.com/Fuco1/sphinx-mode"
  :commit "9d4075c106fc837006394c4c803281383f2ec6f3"
  :revdesc "9d4075c106fc"
  :keywords '("languages")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
