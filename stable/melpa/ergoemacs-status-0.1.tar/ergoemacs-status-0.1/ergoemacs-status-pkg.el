;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ergoemacs-status" "0.1"
  "Adapatave Status Bar / Mode Line."
  '((powerline  "2.3")
    (mode-icons "0.1.0"))
  :url "https://github.com/ergoemacs/ergoemacs-status"
  :commit "fd01b2f734814373392e2e40340f45a2672817a4"
  :revdesc "fd01b2f73481")
