;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typing" "1.1.4"
  "The Typing Of Emacs."
  ()
  :url "http://www.emacswiki.org/emacs/TypingOfEmacs"
  :commit "1ada06484695b8959f4a7c41cacf7f78c2aad998"
  :revdesc "1ada06484695"
  :keywords '("games")
  :authors '(("Alex Schroeder" . "alex@gnu.org"))
  :maintainers '(("Alex Schroeder" . "alex@gnu.org")))
