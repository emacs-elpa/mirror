;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyconf" "0.2.0"
  "Set up python execution configurations like dap-mode ones."
  '((pyvenv     "1.21")
    (emacs      "28.1")
    (transient  "0.3.7")
    (pyenv-mode "0.1.0"))
  :url "https://github.com/andcarnivorous/pyconf"
  :commit "da0532c85f194be9c35db74e533695593b5cd6b1"
  :revdesc "da0532c85f19"
  :keywords '("processes" "python")
  :authors '(("Andrew Favia" . "drewlinguistics01atgmaildotcom"))
  :maintainers '(("Andrew Favia" . "drewlinguistics01atgmaildotcom")))
