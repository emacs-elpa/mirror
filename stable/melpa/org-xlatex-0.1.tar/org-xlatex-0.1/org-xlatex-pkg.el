;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-xlatex" "0.1"
  "[No description available]."
  '((emacs "28.1")
    (org   "9.6"))
  :url "https://github.com/ksqsf/org-xlatex"
  :commit "ed0d88a16226b40d1d587084fbe98b0bbd712178"
  :revdesc "ed0d88a16226"
  :authors '(("ksqsf" . "justksqsf@gmail.com"))
  :maintainers '(("ksqsf" . "justksqsf@gmail.com")))
