;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "0.11.1"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "fcdde8a2896441652f1485cb8ed7992e61590787"
  :revdesc "fcdde8a28964"
  :keywords '("wp" "convenience"))
