;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "klondike" "1.2.0"
  "Klondike."
  '((emacs "28.1"))
  :url "https://codeberg.org/tomenzgg/Emacs-Klondike"
  :commit "50315bbb341f74e0ecc23e66757bbfa4a8cacb50"
  :revdesc "50315bbb341f"
  :keywords '("games" "cards" "solitaire" "klondike")
  :authors '(("Jean Libète" . "tomenzgg@mail.mayfirst.org"))
  :maintainers '(("Jean Libète" . "tomenzgg@mail.mayfirst.org")))
