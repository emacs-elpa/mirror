;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rcirc-styles" "1.3.2"
  "Support mIRC-style color and attribute codes."
  '((cl-lib "0.5"))
  :url "https://github.com/aaron-em/rcirc-styles.el"
  :commit "f313bf6a7470bed314b27c7a40558cb787d7bc67"
  :revdesc "f313bf6a7470")
