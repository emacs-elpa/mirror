;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "actionscript-mode" "7.2.2"
  "A simple mode for editing Actionscript 3 files."
  ()
  :url "https://codeberg.org/austinhaas/actionscript-mode"
  :commit "fddd7220342d29e7eca734f6b798b7a2849717a5"
  :revdesc "fddd7220342d"
  :keywords '("language" "modes"))
