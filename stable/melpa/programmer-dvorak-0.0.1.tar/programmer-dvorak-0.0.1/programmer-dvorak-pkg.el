;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "programmer-dvorak" "0.0.1"
  "Input method for Programmer Dvorak."
  ()
  :url "https://github.com/yangchenyun/programmer-dvorak"
  :commit "c35d5e3b8b53c1e9341957b5d5db40387ba0c8ee"
  :revdesc "c35d5e3b8b53"
  :keywords '("dvorak" "programmer-dvorak" "input-method")
  :authors '(("Chenyun Yang" . "yangchenyun@gmail.com"))
  :maintainers '(("Chenyun Yang" . "yangchenyun@gmail.com")))
