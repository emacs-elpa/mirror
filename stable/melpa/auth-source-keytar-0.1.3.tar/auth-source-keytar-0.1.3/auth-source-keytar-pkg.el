;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auth-source-keytar" "0.1.3"
  "Integrate auth-source with keytar."
  '((emacs  "24.4")
    (keytar "0.1.2")
    (s      "1.12.0"))
  :url "https://github.com/emacs-grammarly/auth-source-keytar"
  :commit "6edf8ec86d74f1e9853da23052291cc28d2df8bc"
  :revdesc "6edf8ec86d74"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
