;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-region" "1.0"
  "Select region, rectangle, multi cursol in smart way."
  '((expand-region        "20141223")
    (region-bindings-mode "20140407.1514")
    (multiple-cursors     "20150307.2322"))
  :url "https://github.com/uk-ar/smart-region"
  :commit "49eea3fc9ed1aee4f3af3fdf80ea531a1cddd95b"
  :revdesc "49eea3fc9ed1"
  :keywords '("region")
  :authors '(("Yuuki Arisawa" . "yuuki.ari@gmail.com"))
  :maintainers '(("Yuuki Arisawa" . "yuuki.ari@gmail.com")))
