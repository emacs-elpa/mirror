;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "download-region" "1.0.0"
  "Simple in-buffer download manager."
  '((cl-lib "0.3"))
  :url "http://zk-phi.github.io/"
  :commit "0dca3b224649bba80a7e9ecbf1d1b6f6be962455"
  :revdesc "0dca3b224649")
