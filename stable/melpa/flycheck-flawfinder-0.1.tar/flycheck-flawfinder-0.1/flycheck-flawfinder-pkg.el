;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-flawfinder" "0.1"
  "Integrate flawfinder with flycheck."
  '((flycheck "0.24")
    (emacs    "24.4"))
  :url "https://github.com/alexmurray/flycheck-flawfinder"
  :commit "0123ec8cdaceaa4d158b1976ed3595475912fe9a"
  :revdesc "0123ec8cdace"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
