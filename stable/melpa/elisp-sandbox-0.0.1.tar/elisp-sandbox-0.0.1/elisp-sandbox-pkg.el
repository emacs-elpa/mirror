;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-sandbox" "0.0.1"
  "Evaluate EmacsLisp expressions in a sandbox."
  ()
  :url "https://github.com/joelmccracken/elisp-sandbox"
  :commit "a3be073e647a3927a6c540dc825bee8d3bee7c83"
  :revdesc "a3be073e647a"
  :keywords '("lisp")
  :authors '(("Joel McCracken" . "mccracken.joel@gmail.com")
             ("D. Goel" . "deego@gnufans.org"))
  :maintainers '(("Joel McCracken" . "mccracken.joel@gmail.com")
                 ("D. Goel" . "deego@gnufans.org")))
