;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greymatters-theme" "0.1"
  "Emacs 24 theme with a light background."
  '((emacs "24"))
  :url "https://github.com/mswift42/greymatters-theme"
  :commit "8f4c42465fae4299e95329f648571ced5cdd6f88"
  :revdesc "8f4c42465fae")
