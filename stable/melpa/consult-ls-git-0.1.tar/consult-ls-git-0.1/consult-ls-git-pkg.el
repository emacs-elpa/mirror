;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ls-git" "0.1"
  "Consult integration for git."
  '((emacs   "27.1")
    (consult "0.16"))
  :url "https://github.com/rcj/consult-ls-git"
  :commit "14f077350df97d68f25f136a166f41b288e39b1d"
  :revdesc "14f077350df9"
  :keywords '("convenience"))
