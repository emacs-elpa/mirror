;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-acl2" "3.1"
  "Babel Functions for ACL2."
  '((emacs "28")
    (org   "9"))
  :url "https://github.com/tani/ob-acl2"
  :commit "89de8ab94d7b832c9b3ff242c33013b28c8663a2"
  :revdesc "89de8ab94d7b"
  :keywords '("tools" "org" "literate programming" "theorem proving" "acl2" "proof assistant system")
  :authors '(("TANIGUCHI Masaya" . "masaya.taniguchi@a.riken.jp"))
  :maintainers '(("TANIGUCHI Masaya" . "masaya.taniguchi@a.riken.jp")))
