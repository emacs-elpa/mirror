;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-csv" "1.2"
  "Export `org-mode' clock entries to CSV format."
  '((org "8.3")
    (s   "1.0"))
  :url "https://github.com/atheriel/org-clock-csv"
  :commit "e2fbaa1ad1a1be40fceecde603a600b292b76acc"
  :revdesc "e2fbaa1ad1a1"
  :keywords '("calendar" "data" "org")
  :authors '(("Aaron Jacobs" . "atheriel@gmail.com"))
  :maintainers '(("Aaron Jacobs" . "atheriel@gmail.com")))
