;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-jstack" "0.0.0.20150603.9"
  "Helm interface to Jps & Jstack for Java/JVM processes."
  '((emacs  "24")
    (helm   "1.7.0")
    (cl-lib "0.5"))
  :url "https://github.com/raghavgautam/helm-jstack"
  :commit "aab0fd9f14794ae3a6e7cfbe7f6a81842ce4c23b"
  :revdesc "aab0fd9f1479"
  :keywords '("java" "jps" "jstack" "jvm" "emacs" "elisp" "helm")
  :authors '(("Raghav Kumar Gautam" . "rgautam@apache.com"))
  :maintainers '(("Raghav Kumar Gautam" . "rgautam@apache.com")))
