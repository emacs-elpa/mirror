;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devil" "0.6.0"
  "Minor mode for translating key sequences."
  '((emacs "24.4"))
  :url "https://github.com/susam/devil"
  :commit "1985300ce84abd712be93b271b27c3bdb164231d"
  :revdesc "0.6.0-0-g1985300ce84a"
  :keywords '("convenience" "abbrev")
  :authors '(("Susam Pal" . "susam@susam.net"))
  :maintainers '(("Susam Pal" . "susam@susam.net")))
