;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mandoku-tls" "0.1"
  "A tool to access the TLS database."
  '((mandoku      "20160301.1705")
    (github-clone "20150705.1705"))
  :url "https://github.com/krp-zinbun/tls"
  :commit "a44d02d3569bffe0044c57bbf60e3ed4d6ff0276"
  :revdesc "a44d02d3569b"
  :keywords '("convenience")
  :authors '(("Christian Wittern" . "cwittern@gmail.com"))
  :maintainers '(("Christian Wittern" . "cwittern@gmail.com")))
