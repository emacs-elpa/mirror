;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minsk-theme" "0.3"
  "Minsk, a theme in deep muted greens."
  '((emacs "24"))
  :url "https://codeberg.org/loj/minsk-theme"
  :commit "9a20781c07108256d6e4c2699c7ccb5b520abd52"
  :revdesc "9a20781c0710"
  :keywords '("theme" "faces")
  :authors '(("June Lo" . "loh.ka.tsun@gmail.com"))
  :maintainers '(("June Lo" . "loh.ka.tsun@gmail.com")))
