;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mermaid-ts-mode" "1.0"
  "Major mode for Mermaid."
  ()
  :url "https://github.com/JonathanHope/mermaid-ts-mode"
  :commit "e0f72a822828ece3be08fc78ad845ed06069f4fd"
  :revdesc "e0f72a822828"
  :keywords '("mermaid")
  :authors '(("Jonathan Hope" . "jhope@theflatfield.net"))
  :maintainers '(("Jonathan Hope" . "jhope@theflatfield.net")))
