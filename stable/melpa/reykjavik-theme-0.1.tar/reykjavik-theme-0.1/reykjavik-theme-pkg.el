;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reykjavik-theme" "0.1"
  "Emacs theme."
  '((emacs "24"))
  :url "https://github.com/mswift42/reykjavik-theme"
  :commit "656799c77768d294a4a0e44f56493d651d418b0c"
  :revdesc "656799c77768")
