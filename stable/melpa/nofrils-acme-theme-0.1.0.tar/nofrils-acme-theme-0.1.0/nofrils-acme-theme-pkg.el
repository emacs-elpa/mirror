;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nofrils-acme-theme" "0.1.0"
  "Port of \"No Frils Acme\" Vim theme."
  '((emacs "24"))
  :url "https://gitlab.com/esessoms/nofrils-theme"
  :commit "7825f88cb881a84eaa5cd1689772819a18eb2943"
  :revdesc "0.1.0-0-g7825f88cb881"
  :authors '(("Eric Sessoms" . "esessoms@protonmail.com"))
  :maintainers '(("Eric Sessoms" . "esessoms@protonmail.com")))
