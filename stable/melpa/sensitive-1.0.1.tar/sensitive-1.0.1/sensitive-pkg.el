;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sensitive" "1.0.1"
  "A dead simple way to load sensitive information."
  '((emacs     "24")
    (sequences "0.1.0"))
  :url "https://github.com/timvisher/sensitive.el"
  :commit "7f2c77811e983234e1a93055d78cc4480ae807c3"
  :revdesc "7f2c77811e98"
  :keywords '("convenience")
  :authors '(("Tim Visher" . "tim.visher@gmail.com"))
  :maintainers '(("Tim Visher" . "tim.visher@gmail.com")))
