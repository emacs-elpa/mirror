;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "initsplit" "1.6"
  "[No description available]."
  ()
  :url "http://www.gci-net.com/users/j/johnw/emacs.html"
  :commit "950bdc568e3fd08e6106170953caf98ac582a431"
  :revdesc "950bdc568e3f"
  :keywords '("lisp")
  :authors '(("John Wiegley" . "johnw@gnu.org"))
  :maintainers '(("John Wiegley" . "johnw@gnu.org")))
