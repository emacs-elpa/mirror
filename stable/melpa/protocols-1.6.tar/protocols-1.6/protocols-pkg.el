;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "protocols" "1.6"
  "Protocol database access functions."
  '((cl-lib "0.5"))
  :url "https://github.com/davep/protocols.el"
  :commit "f5549f5d873a683af45a0e19c732524d5b964026"
  :revdesc "f5549f5d873a"
  :keywords '("convenience" "net" "protocols")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
