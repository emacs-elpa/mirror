;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smithers" "0.4"
  "A startup message featuring Mr C.M. Burns."
  '((emacs "26.1")
    (dash  "2.17.0")
    (org   "9.4.5"))
  :url "https://gitlab.com/mtekman/smithers.el"
  :commit "af91506c59145587c438f63db679b8a2afd61dbe"
  :revdesc "af91506c5914"
  :keywords '("games"))
