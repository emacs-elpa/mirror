;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hippie-exp-ext" "0.1"
  "Extension of hippie-expand."
  ()
  :url "http://www.emacswiki.org/emacs/download/hippie-exp-ext.el"
  :commit "18b8c268a9f787017c6e523428b3308621f57362"
  :revdesc "18b8c268a9f7"
  :keywords '("abbrev" "convenience" "completions" "hippie-expand")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
