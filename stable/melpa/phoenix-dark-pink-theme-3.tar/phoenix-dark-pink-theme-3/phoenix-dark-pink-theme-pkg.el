;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phoenix-dark-pink-theme" "3"
  "Originally a port of the Sublime Text 2 theme."
  ()
  :url "https://github.com/j0ni/phoenix-dark-pink"
  :commit "2f1d96e08d4f9137f0a25dee50245492b59bbf15"
  :revdesc "2f1d96e08d4f"
  :authors '(("J Irving" . "j@lollyshouse.ca"))
  :maintainers '(("J Irving" . "j@lollyshouse.ca")))
