;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smblog" "1.0"
  "Samba log viewer."
  ()
  :url "https://github.com/aaptel/smblog-mode"
  :commit "4b059dfab24e4e4e3e2869a6a4541dfcec2c0b7a"
  :revdesc "4b059dfab24e"
  :authors '(("Aurélien Aptel" . "aaptel@suse.com"))
  :maintainers '(("Aurélien Aptel" . "aaptel@suse.com")))
