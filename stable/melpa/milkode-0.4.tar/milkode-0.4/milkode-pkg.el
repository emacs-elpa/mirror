;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "milkode" "0.4"
  "Command line search and direct jump with Milkode."
  ()
  :url "https://github.com/ongaeshi/emacs-milkode"
  :commit "ba97e2aeefa1d9d0b3835bf08edd0de248b0c513"
  :revdesc "ba97e2aeefa1"
  :keywords '("milkode" "search" "grep" "jump" "keyword"))
