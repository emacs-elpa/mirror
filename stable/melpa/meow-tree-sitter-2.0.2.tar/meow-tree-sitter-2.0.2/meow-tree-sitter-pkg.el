;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow-tree-sitter" "2.0.2"
  "Tree-sitter powered motions for Meow."
  '((emacs "29.1")
    (meow  "1.2.0"))
  :url "https://github.com/skissue/meow-tree-sitter"
  :commit "09181314c465e6536a282657704d4fc267304d0d"
  :revdesc "09181314c465"
  :keywords '("convenience" "files" "languages" "tools")
  :authors '(("Ad" . "me@skissue.xyz"))
  :maintainers '(("Ad" . "me@skissue.xyz")))
