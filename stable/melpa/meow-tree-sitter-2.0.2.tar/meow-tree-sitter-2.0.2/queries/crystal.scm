; inherits: ruby
