;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-whitespace" "0.2.4"
  "Teach whitespace-mode about fancy characters."
  '((ucs-utils       "0.7.6")
    (persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/unicode-whitespace"
  :commit "6d29f25d46b3344c74ce289fc80b3d4fc17ed6db"
  :revdesc "v0.2.4-0-g6d29f25d46b3"
  :keywords '("faces" "wp" "interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
