;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enh-ruby-mode" "20191111"
  "Major mode for editing Ruby files."
  '((emacs "24.3"))
  :url "https://github.com/zenspider/Enhanced-Ruby-Mode"
  :commit "4e058f36a455c90816fd9615a4a7a63a8c8b8cc8"
  :revdesc "4e058f36a455"
  :keywords '("languages" "elisp" "ruby"))
