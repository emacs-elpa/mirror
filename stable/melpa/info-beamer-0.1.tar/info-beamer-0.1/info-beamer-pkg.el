;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "info-beamer" "0.1"
  "Utilities for working with info-beamer."
  '((emacs "24.4"))
  :url "https://github.com/dakra/info-beamer.el"
  :commit "f65e89ad0c2a7acdef1dc182947d59287f371783"
  :revdesc "0.1-0-gf65e89ad0c2a"
  :keywords '("tools" "processes" "comm")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
