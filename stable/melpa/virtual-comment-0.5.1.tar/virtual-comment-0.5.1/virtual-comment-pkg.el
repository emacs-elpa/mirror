;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "virtual-comment" "0.5.1"
  "Virtual Comments."
  '((emacs "26.1"))
  :url "https://github.com/thanhvg/emacs-virtual-comment"
  :commit "b0c2ac4a9d625b5f4f329bbab879ad86cd7056bd"
  :revdesc "b0c2ac4a9d62"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
