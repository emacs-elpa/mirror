;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perl-live" "1"
  "[No description available]."
  ()
  :url "https://github.com/vividsnow/perl-live"
  :commit "62410c5fe98e9e8026cb11ffb7151e7f24ef6d68"
  :revdesc "62410c5fe98e")
