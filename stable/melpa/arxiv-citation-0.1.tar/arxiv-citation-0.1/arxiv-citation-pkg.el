;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arxiv-citation" "0.1"
  "Utility functions for dealing with arXiv papers."
  '((emacs "25.1")
    (dash  "2.19.1")
    (s     "1.12.0"))
  :url "https://gitlab.com/slotThe/arXiv-citation"
  :commit "f2be54c0a1789503f770b978fdbf7d0d988ddc08"
  :revdesc "f2be54c0a178"
  :keywords '("convenience")
  :authors '(("Tony Zorman" . "soliditsallgood@mailbox.org"))
  :maintainers '(("Tony Zorman" . "soliditsallgood@mailbox.org")))
