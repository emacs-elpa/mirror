;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "0.1"
  "Advent of Code helper minor mode."
  '((emacs "28.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "0c234d9321493ba1a0540fd8e55a33d714ffe69a"
  :revdesc "0c234d932149"
  :keywords '("lisp"))
