;;; advent-mode.el --- Advent of Code helper minor mode -*- lexical-binding: t; -*-

;; Copyright (C) 2015-2021 Keegan Carruthers-Smith
;; Copyright (C) 2026  Vladimir Kazanov

;; Author: Vladimir Kazanov
;; Keywords: lisp
;; Maintainer: Vladimir Kazanov
;; Package-Requires: ((emacs "28.1"))
;; URL: https://github.com/vkazanov/advent-mode
;; Package-Version: 0.1
;; Package-Revision: 0c234d932149

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Advent of Code helper minor mode.

;; Features:
;;
;; - Global minor mode that autodetects AoC code.
;;
;; - Mode-line shows year/day/cookie
;;
;; - Assumed directory layout: path/to/aoc/year<YYYY>/day<DD>
;;
;; - Commands to open problem, fetch input, add new day, submit
;;   answers.
;;
;; Inspired by https://github.com/keegancsmith/advent/

;;; Code:

(require 'url)
(require 'url-cookie)
(require 'eww)
(require 'pcase)

(defgroup advent nil
  "Advent of Code helpers."
  :group 'convenience)

(defcustom advent-root-dir nil
  "Root directory containing Advent of Code solutions."
  :type 'directory
  :group 'advent)

(defcustom advent-year-dir-format "year%04d"
  "Format string for the year directory, used with `format'."
  :type 'string
  :group 'advent)

(defcustom advent-day-dir-format "day%02d"
  "Format string for the day directory, used with `format'."
  :type 'string
  :group 'advent)

(defcustom advent-problem-path-re
  "^\\(?:year\\)?\\([0-9]\\{4\\}\\)/\\(?:day\\)?\\([0-9]\\{1,2\\}\\)/"
  "Regexp for the full problem dir path.
Subexpr 1 should be a problem's year.
Subexpr 2 should be a problem's day"
  :type 'regexp
  :group 'advent)

(defcustom advent-input-file-name "input.txt"
  "Name of the input file saved under a day directory."
  :type 'string
  :group 'advent)

(defcustom advent-new-files nil
  "List of files to copy into new day directories.
Absolute paths are copied as-is, relative paths are resolved from
`advent-root-dir'."
  :type '(repeat file)
  :group 'advent)

(defcustom advent-mode-line-format " AoC[%s/%s %s]"
  "Mode line format.  Receives (YEAR DAY COOKIE-STATUS)."
  :type 'string
  :group 'advent)

(defcustom advent-timezone "America/New_York"
  "Timezone used when computing AoC default year/day."
  :type 'string
  :group 'advent)

(defvar advent-submit-level-history nil)

;;;; Helper functions.

(defun advent--aoc-now ()
  "Return (YEAR DAY) in the AoC timezone."
  (pcase-let ((`(,_ ,_ ,_ ,day ,_ ,year ,_ ,_ ,_)
               (decode-time (current-time) advent-timezone)))
    (list year day)))

(defun advent--year-dir (year)
  "YEAR directory name."
  (format advent-year-dir-format year))

(defun advent--day-dir (day)
  "DAY directory name."
  (format advent-day-dir-format day))

(defun advent--problem-dir (year day)
  "YEAR/DAY problem directory path."
  (file-name-concat advent-root-dir (advent--year-dir year)
                    (advent--day-dir day)))

(defun advent--input-path (year day)
  "YEAR/DAY input file path."
  (file-name-concat (advent--problem-dir year day)
                    advent-input-file-name))

(defun advent--problem-url (year day)
  "YEAR/DAY problem url."
  (format "https://adventofcode.com/%d/day/%d" year day))

(defun advent--input-url (year day)
  "YEAR/DAY input url."
  (format "https://adventofcode.com/%d/day/%d/input" year day))

(defun advent--answer-url (year day)
  "YEAR/DAY answer url."
  (format "https://adventofcode.com/%d/day/%d/answer" year day))

(defun advent--infer-year-day-from-path (path)
  "Infer (YEAR DAY) from PATH.
PATH is expected to be relative to `advent-root-dir'."
  (when (string-match advent-problem-path-re path)
    (list (string-to-number (match-string 1 path))
          (string-to-number (match-string 2 path)))))

(defun advent--context-year-day ()
  "Infer (YEAR DAY) from current buffer path or default to AoC now."
  (and (file-in-directory-p default-directory (expand-file-name advent-root-dir))
       (advent--infer-year-day-from-path
        (file-relative-name default-directory advent-root-dir))))

(defun advent--default-answer ()
  "Return default answer from region or thing at point."
  (cond
   ((use-region-p)
    (string-trim (buffer-substring-no-properties (region-beginning) (region-end))))
   ((thing-at-point 'number t))
   ((thing-at-point 'symbol t))
   (t (string-trim (thing-at-point 'line t)))))

;;;; Cookie management

(defun advent--cookie-ok-p ()
  "Return non-nil if an AoC session cookie exists and is not expired."
  (when-let* ((cookies (url-cookie-retrieve ".adventofcode.com" "/" t))
              (c (car cookies)))
    (not (url-cookie-expired-p c))))

(defun advent--cookie-status-string ()
  "Return a string representing cookie status."
  (if (advent--cookie-ok-p) "✓" "✗"))

(defun advent--refresh-mode-lines ()
  "Update mode-lines of `advent-mode' buffers."
  (dolist (b (buffer-list))
    (with-current-buffer b
      (when (bound-and-true-p advent-mode)
        (force-mode-line-update t)))))

;;;###autoload
(defun advent-login (session)
  "Login to AoC by providing the SESSION cookie."
  (interactive "sSession cookie: ")
  (url-cookie-store "session" session
                    "Fri, 25 Dec 2031 00:00:00 GMT"
                    ".adventofcode.com" "/" t)
  (advent--refresh-mode-lines)
  (message "AoC session cookie stored."))

;;;; IO helpers

(defun advent--ensure-dir (dir)
  "Create a DIR if it doesn't exist.
Return t if dir existed, nil otherwise."
  (if (not (file-directory-p dir))
      (progn (mkdir dir t)
             (message "Created %s" dir)
             nil) t))

(defun advent--write-url-to-file (url file)
  "Synchronously GET URL and write body to FILE.
Return FILE or signal error."
  (let ((buf (url-retrieve-synchronously url)))
    (unless buf (error "Failed to retrieve %s" url))
    (unwind-protect
        (with-current-buffer buf
          (goto-char (point-min))
          (unless (re-search-forward "\r?\n\r?\n" nil t)
            (error "Malformed HTTP response"))
          (advent--ensure-dir (file-name-directory file))
          (write-region (point) (point-max) file nil 'silent)
          file)
      (kill-buffer buf))))

(defun advent--http-post (url data)
  "Synchronously POST DATA (application/x-www-form-urlencoded) to URL.
Returns response body as string."
  (let* ((url-request-method "POST")
         (url-request-extra-headers '(("Content-Type" . "application/x-www-form-urlencoded")))
         (url-request-data data)
         (buf (url-retrieve-synchronously url t t 30)))
    (unless buf (error "Failed to POST to %s" url))
    (unwind-protect
        (with-current-buffer buf
          (goto-char (point-min))
          (unless (re-search-forward "\r?\n\r?\n" nil t)
            (error "Malformed HTTP response"))
          (buffer-substring-no-properties (point) (point-max)))
      (kill-buffer buf))))

;;;; Commands

;;;###autoload
(defun advent-open-problem-page (&optional year day)
  "Open the AoC problem page for YEAR and DAY in EWW.
If not provided, infer from context or use AoC today."
  (interactive nil advent-mode)
  (let* ((ctx (advent--context-year-day))
         (year (or year (car ctx)))
         (day (or day (cadr ctx))))
    (unless (and year day)
      (user-error "Problem not detected"))
    (eww-browse-url (advent--problem-url year day))))

;;;###autoload
(defun advent-open-input (&optional year day)
  "Fetch (if needed) and open the input for YEAR and DAY."
  (interactive nil advent-mode)
  (let* ((ctx (advent--context-year-day))
         (year (or year (car ctx)))
         (day (or day (cadr ctx)))
         (dst (advent--input-path year day)))
    (unless (advent--cookie-ok-p)
      (if (y-or-n-p "AoC session cookie missing.  Set it now? ")
          (call-interactively #'advent-login)
        (user-error "No AoC session cookie set; run M-x advent-login")))
    (if (file-exists-p dst)
        (find-file-other-window dst)
      (advent--write-url-to-file (advent--input-url year day) dst)
      (message "%s saved." dst)
      (find-file-other-window dst))))

;;;###autoload
(defun advent-submit-answer (answer level &optional year day)
  "Submit ANSWER for LEVEL (1 or 2) for YEAR and DAY.
Return server response."
  (interactive
   (let* ((def (advent--default-answer))
          (ans (read-string "Answer: " nil nil def))
          (lvl (completing-read "Level: " '("1" "2") nil t nil 'advent-submit-level-history "1")))
     (list ans lvl nil nil))
   advent-mode)
  (unless (advent--cookie-ok-p)
    (if (y-or-n-p "AoC session cookie missing.  Set it now? ")
        (call-interactively #'advent-login)
      (user-error "No AoC session cookie set; run M-x advent-login")))
  (let* ((ctx (advent--context-year-day))
         (year (or year (car ctx)))
         (day (or day (cadr ctx)))
         (resp (advent--http-post (advent--answer-url year day)
                                  (format "level=%s&answer=%s"
                                          (url-hexify-string (format "%s" level))
                                          (url-hexify-string (format "%s" answer))))))
    (with-current-buffer (get-buffer-create "*AoC Submit*")
      (erase-buffer)
      (insert resp)
      (goto-char (point-min))
      (display-buffer (current-buffer)))
    (message "Submitted answer for %d day %d (level %s)" year day level)
    resp))

;;;###autoload
(defun advent-open-day (year day)
  "Open YEAR/DAY problem directory.
Create the directory if it doesn't exist.  Suggest opening the problem
page and retrieving the input."
  (interactive
   (pcase-let* ((`(,year-now ,day-now) (advent--aoc-now)))
     (list (read-number "Year: " year-now)
           (read-number "Day: "  day-now))))
  (unless (advent--cookie-ok-p)
      (if (y-or-n-p "AoC session cookie missing.  Set it now? ")
          (call-interactively #'advent-login)
        (user-error "No AoC session cookie set; run M-x advent-login")))
  (let* ((dir (advent--problem-dir year day)))
    (unless (advent--ensure-dir dir)
      (dolist (f advent-new-files)
        (let* ((src (if (file-name-absolute-p f) f (expand-file-name f advent-root-dir)))
               (dst (file-name-concat dir (file-name-nondirectory f))))
          (when (file-exists-p src)
            (copy-file src dst t)))))
    (dired dir)
    (when (y-or-n-p "Open problem in EWW? ")
      (advent-open-problem-page year day))
    (when (y-or-n-p (format "Download %s and open it? " advent-input-file-name))
      (advent-open-input year day))))

;;;; Mode line and modes

(defun advent--mode-line-string (year day)
  "Return mode line string for YEAR and DAY using the current cookie status."
  (format advent-mode-line-format year (format "%02d" day)
          (advent--cookie-status-string)))

(defun advent--mode-line ()
  "Generate a mode line using current directory."
  (if-let ((ctx (advent--context-year-day)))
      (let ((year (car ctx))
            (day (cadr ctx)))
        (advent--mode-line-string year day))))

(defun advent--in-project-p (&optional dir)
  "Return t if DIR in `advent-root-dir'."
  (file-in-directory-p (expand-file-name (or dir default-directory))
                       (expand-file-name advent-root-dir)))

;;;###autoload
(define-minor-mode advent-mode
  "Show AoC year/day and cookie status in the mode line."
  :lighter '(:eval (advent--mode-line))
  (force-mode-line-update))

(defun advent--maybe-enable ()
  "Enable `advent-mode' in the current buffer."
  (unless advent-root-dir
    (user-error "Variable advent-root-dir is not set"))
  (when (advent--in-project-p) (advent-mode 1)))

(defun advent--maybe-disable ()
  "Disable `advent-mode' in the current buffer."
  (when (bound-and-true-p advent-mode)
        (advent-mode 0)))

(defun advent--enable-all ()
  "Disable `advent-mode' in all AoC buffers."
  (dolist (b (buffer-list))
    (with-current-buffer b
      (advent--maybe-enable))))

(defun advent--disable-all ()
  "Enable `advent-mode' in all AoC buffers."
  (dolist (b (buffer-list))
    (with-current-buffer b
      (advent--maybe-disable))))

;;;###autoload
(define-minor-mode global-advent-mode
  "Enable `advent-mode' automatically in `advent-root-dir'."
  :global t
  (unless advent-root-dir
    (user-error "Variable advent-root-dir is not set"))
  (if global-advent-mode
      (progn
        (add-hook 'find-file-hook #'advent--maybe-enable)
        (add-hook 'dired-mode-hook #'advent--maybe-enable)
        (advent--enable-all))
    (remove-hook 'find-file-hook #'advent--maybe-enable)
    (remove-hook 'dired-mode-hook #'advent--maybe-enable)
    (advent--disable-all))
  (advent--refresh-mode-lines))

(provide 'advent-mode)
;;; advent-mode.el ends here
