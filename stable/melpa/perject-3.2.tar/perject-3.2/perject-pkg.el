;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perject" "3.2"
  "[No description available]."
  '((emacs "27.1")
    (dash  "2.12"))
  :url "https://gitlab.com/overideal/perject"
  :commit "80eb784350feba82dd662ceea1b80a943a48f54d"
  :revdesc "80eb784350fe")
