;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liblouis" "0.2"
  "Mode for editing liblouis braille translation tables."
  '((emacs "26.1"))
  :url "https://github.com/liblouis/liblouis-mode"
  :commit "36ec3f98c0a3a84669444a9b3726824f1aaa9682"
  :revdesc "v0.2-0-g36ec3f98c0a3"
  :keywords '("languages")
  :authors '(("Christian Egli" . "christian.egli@sbs.ch"))
  :maintainers '(("Christian Egli" . "christian.egli@sbs.ch")))
