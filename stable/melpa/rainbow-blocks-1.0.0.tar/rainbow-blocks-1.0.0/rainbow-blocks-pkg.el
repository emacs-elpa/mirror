;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rainbow-blocks" "1.0.0"
  "Block syntax highlighting for lisp code."
  ()
  :url "https://github.com/istib/rainbow-blocks"
  :commit "8335993563aadd4290c5fa09dd7a6a81691b0690"
  :revdesc "1.0.0-0-g8335993563aa")
