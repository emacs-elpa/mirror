;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-seek" "0.1.0"
  "Searching Org-mode files with search tools."
  '((emacs "24.3")
    (ag    "0.48"))
  :url "https://github.com/stardiviner/org-seek.el"
  :commit "f6556e09ff0c88a9530bca8654c65c9e0de3d0fa"
  :revdesc "f6556e09ff0c"
  :keywords '("org" "search")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
