;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cyphejor" "0.1.2"
  "Shorten major mode names using user-defined rules."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/cyphejor"
  :commit "d7842388a1872b165489624a1a68f536de97e28d"
  :revdesc "d7842388a187"
  :keywords '("mode-line" "major-mode")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
