;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "skewer-less" "0.2"
  "Skewer support for live LESS stylesheet updates."
  '((skewer-mode "1.5.3"))
  :url "https://github.com/purcell/skewer-less"
  :commit "593001930f1d68c85233f34c5f6fb04173fc98d6"
  :revdesc "593001930f1d"
  :keywords '("languages" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
