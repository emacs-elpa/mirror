;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tardis-theme" "0.1.0"
  "Quantum Country Theme."
  ()
  :url "https://github.com/antonhibl/tardis-theme"
  :commit "9646c3faa10599cc4e279f87dc4f4f4d9d79005d"
  :revdesc "9646c3faa105"
  :keywords '("convenience")
  :authors '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainers '(("Anton Hibl" . "antonhibl11@gmail.com")))
