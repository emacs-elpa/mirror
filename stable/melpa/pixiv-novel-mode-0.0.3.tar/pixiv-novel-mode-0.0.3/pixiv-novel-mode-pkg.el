;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pixiv-novel-mode" "0.0.3"
  "Major mode for pixiv novel."
  ()
  :url "https://github.com/zonuexe/pixiv-novel-mode.el"
  :commit "4dd9caf749190fab8f0b33862b3894b635de46c5"
  :revdesc "4dd9caf74919"
  :keywords '("novel" "pixiv")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
