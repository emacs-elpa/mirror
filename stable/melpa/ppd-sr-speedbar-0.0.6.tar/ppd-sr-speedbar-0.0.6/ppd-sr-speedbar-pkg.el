;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ppd-sr-speedbar" "0.0.6"
  "Sr Speedbar Adaptor for project-persist-drawer."
  ()
  :url "https://github.com/rdallasgrayppd-sr-speedbar"
  :commit "19d3e924407f40a6bb38c8fe427a159af755adce"
  :revdesc "0.0.6-0-g19d3e924407f"
  :keywords '("projects" "drawer"))
