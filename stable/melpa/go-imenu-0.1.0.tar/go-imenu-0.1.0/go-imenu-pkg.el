;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-imenu" "0.1.0"
  "Imenu for go language."
  '((emacs "24.3"))
  :url "https://github.com/brantou/go-imenu.el"
  :commit "fc1566fbe396fc8c94f7de99d9c7191b47cd48d9"
  :revdesc "fc1566fbe396"
  :keywords '("tools")
  :authors '(("Brantou" . "brantou89@gmail.com"))
  :maintainers '(("Brantou" . "brantou89@gmail.com")))
