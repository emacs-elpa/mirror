;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "textmate-to-yas" "0.21"
  "Import Textmate macros into yasnippet syntax."
  ()
  :url "https://github.com/mlf176f2/textmate-to-yas.el/"
  :commit "8805e5159329e1b74629b7b584373fc446f57d31"
  :revdesc "v0.21-0-g8805e5159329"
  :keywords '("yasnippet" "textmate"))
