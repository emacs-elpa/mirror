;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fill-column-indicator" "1.90"
  "Graphically indicate the fill column."
  ()
  :url "https://github.com/alpaker/fill-column-indicator"
  :commit "f7b3f99b41ff017f50a21ad53eed16f8ef5ab7ee"
  :revdesc "f7b3f99b41ff"
  :keywords '("convenience")
  :authors '(("Alp Aker" . "alp.tekin.aker@gmail.com"))
  :maintainers '(("Alp Aker" . "alp.tekin.aker@gmail.com")))
