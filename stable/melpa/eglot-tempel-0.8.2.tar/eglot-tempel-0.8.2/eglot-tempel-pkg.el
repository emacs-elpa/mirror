;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-tempel" "0.8.2"
  "Use tempel to expand snippets from eglot."
  '((eglot  "1.9")
    (tempel "0.5")
    (emacs  "29.1")
    (peg    "1.0.1"))
  :url "https://github.com/fejfighter/eglot-tempel"
  :commit "2e796a2fb4785d0aa68f0aad61b582c11e5238df"
  :revdesc "2e796a2fb478"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Jeff Walsh" . "fejfighter@gmail.com"))
  :maintainers '(("Jeff Walsh" . "fejfighter@gmail.com")))
