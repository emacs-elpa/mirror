;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tramp-auto-auth" "20191027.1117"
  "TRAMP automatic authentication library."
  '((emacs "24.4")
    (tramp "0.0"))
  :url "https://github.com/oitofelix/tramp-auto-auth"
  :commit "f15a12dfab651aff60f4a9d70f868030a12344ac"
  :revdesc "f15a12dfab65"
  :keywords '("comm" "processes")
  :authors '(("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org"))
  :maintainers '(("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org")))
