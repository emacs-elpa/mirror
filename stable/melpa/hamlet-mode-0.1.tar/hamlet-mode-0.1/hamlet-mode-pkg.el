;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hamlet-mode" "0.1"
  "Hamlet editing mode."
  ()
  :url "https://github.com/lightquake/hamlet-mode"
  :commit "6f451366e7f74efdd9f54a4d941ae9d04d9d929d"
  :revdesc "6f451366e7f7"
  :keywords '("wp" "languages" "comm")
  :authors '(("Kata" . "lightquake@amateurtopologist.com"))
  :maintainers '(("Kata" . "lightquake@amateurtopologist.com")))
