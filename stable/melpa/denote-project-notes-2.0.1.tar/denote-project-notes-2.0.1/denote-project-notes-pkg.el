;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-project-notes" "2.0.1"
  "Link Denote notes to a project."
  '((emacs  "28.1")
    (denote "3.0.0"))
  :url "https://git.sr.ht/~swflint/denote-project-notes"
  :commit "e109c84071b3aa8da49e5b0fc56e96f8d1cf5e95"
  :revdesc "e109c84071b3"
  :keywords '("convenience")
  :authors '(("Samuel W. Flint" . "swflint@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "swflint@samuelwflint.com")))
