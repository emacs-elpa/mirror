;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "json-process-client" "0.2.0"
  "Interact with a TCP process using JSON."
  '((emacs "25.1"))
  :url "https://gitlab.petton.fr/nico/json-process-client"
  :commit "1d4a1fe2ecc682890dfc75e40054c9697c3046f6"
  :revdesc "v0.2.0-0-g1d4a1fe2ecc6"
  :authors '(("Nicolas Petton" . "nicolas@petton.fr")
             ("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")
                 ("Damien Cassou" . "damien@cassou.me")))
