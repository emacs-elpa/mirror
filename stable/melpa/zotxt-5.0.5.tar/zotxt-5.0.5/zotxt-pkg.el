;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zotxt" "5.0.5"
  "Tools to integrate emacs with Zotero via the zotxt plugin."
  '((request  "0.3.2")
    (deferred "0.5.1"))
  :url "https://gitlab.com/egh/zotxt-emacs"
  :commit "98323098c37a444de49cfef44f1506e9386e8c5f"
  :revdesc "v5.0.5-0-g98323098c37a"
  :keywords '("bib")
  :authors '(("Erik Hetzner" . "egh@e6h.org"))
  :maintainers '(("Erik Hetzner" . "egh@e6h.org")))
