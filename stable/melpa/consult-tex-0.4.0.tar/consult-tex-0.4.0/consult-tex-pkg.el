;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-tex" "0.4.0"
  "Consult powered completion for tex."
  '((emacs   "28.2")
    (consult "0.35"))
  :url "https://gitlab.com/titus.pinta/consult-TeX"
  :commit "14aa968056923fe6b0f96f637405e9d0b8e23020"
  :revdesc "14aa96805692"
  :keywords '("consult" "tex" "latex")
  :maintainers '(("Titus Pinta" . "titus.pinta@gmail.com")))
