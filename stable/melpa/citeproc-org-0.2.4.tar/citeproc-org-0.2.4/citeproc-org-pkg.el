;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citeproc-org" "0.2.4"
  "Render org-mode references in CSL styles."
  '((emacs    "25.1")
    (dash     "2.12.0")
    (org      "9")
    (f        "0.18.0")
    (citeproc "0.1")
    (org-ref  "1.1.1"))
  :url "https://github.com/andras-simonyi/citeproc-org"
  :commit "a35655c55bbdc3f8c0571c8a8f14a33f9eac330b"
  :revdesc "a35655c55bbd"
  :keywords '("org-ref" "org-mode" "cite" "bib")
  :authors '(("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainers '(("András Simonyi" . "andras.simonyi@gmail.com")))
