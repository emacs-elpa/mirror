;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-org-md" "1.2"
  "Export a markdown file automatically when you save an org-file."
  '((org   "8.0")
    (emacs "24.4"))
  :url "https://github.com/jamcha-aa/auto-org-md"
  :commit "7eebba1feb4d628f9f4a073d7966e44a32b9f244"
  :revdesc "7eebba1feb4d"
  :keywords '("org" "markdown")
  :authors '(("jamcha" . "jamcha.aa@gmail.com"))
  :maintainers '(("jamcha" . "jamcha.aa@gmail.com")))
