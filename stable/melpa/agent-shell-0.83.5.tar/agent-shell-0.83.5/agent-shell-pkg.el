;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.83.5"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "1cd4f20e0ebbebe72829f163b1447cf432587c17"
  :revdesc "1cd4f20e0ebb")
