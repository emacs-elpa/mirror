;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgnav" "2.0.3"
  "Org tree navigation using helm."
  '((helm  "2.7.0")
    (s     "1.11.0")
    (dash  "1.11.0")
    (emacs "24"))
  :url "https://github.com/facetframer/orgnav"
  :commit "9e2cac9c1a67af5f0080e60022e821bf7b70312d"
  :revdesc "9e2cac9c1a67"
  :keywords '("convenience" "outlines")
  :authors '(("Facet Framer" . "(facet@facetframer.com)"))
  :maintainers '(("Facet Framer" . "(facet@facetframer.com)")))
