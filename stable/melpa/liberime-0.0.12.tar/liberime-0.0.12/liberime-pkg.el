;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "0.0.12"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "e62f553d9514e97a9087017d5058d7c546e93f45"
  :revdesc "e62f553d9514"
  :keywords '("convenience" "chinese" "input-method" "rime"))
