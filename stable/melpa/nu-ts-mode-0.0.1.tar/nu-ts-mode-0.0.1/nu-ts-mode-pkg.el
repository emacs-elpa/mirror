;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nu-ts-mode" "0.0.1"
  "Major mode for Nushell scripts, powered by treesitter."
  '((emacs "29.1"))
  :url "https://github.com/ItsOleks/nu-ts-mode"
  :commit "6c4bea30ffff77db2c192a2e325e5b6a01c4f900"
  :revdesc "6c4bea30ffff"
  :keywords '("nushell" "nu" "languages" "tree-sitter")
  :authors '(("Oleksandr Makhmudov" . "oleksandr.makhmudov@proton.me"))
  :maintainers '(("Oleksandr Makhmudov" . "oleksandr.makhmudov@proton.me")))
