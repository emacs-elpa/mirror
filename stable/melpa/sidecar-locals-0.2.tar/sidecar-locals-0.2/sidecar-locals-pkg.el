;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sidecar-locals" "0.2"
  "A flexible alternative to built-in dir-locals."
  '((emacs "27.1"))
  :url "https://codeberg.org/ideasman42/emacs-sidecar-locals"
  :commit "2b2b765387f2cbae9935c3ee6e2a32aa8d68f1b8"
  :revdesc "2b2b765387f2"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
