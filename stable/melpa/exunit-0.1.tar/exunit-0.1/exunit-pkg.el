;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exunit" "0.1"
  "ExUnit test runner."
  '((dash "2.10.0")
    (s    "1.11.0"))
  :url "https://github.com/ananthakumaran/exunit.el"
  :commit "07e753e299e3d1cc3b23329fe3913031bc105551"
  :revdesc "07e753e299e3"
  :keywords '("elixir" "exunit")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
