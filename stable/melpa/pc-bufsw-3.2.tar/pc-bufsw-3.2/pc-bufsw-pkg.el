;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pc-bufsw" "3.2"
  "PC style quick buffer switcher."
  ()
  :url "https://github.com/ibukanov/pc-bufsw"
  :commit "762d47b2f278c072643cf2a1ddc785516483d74a"
  :revdesc "762d47b2f278"
  :keywords '("buffer")
  :authors '(("Igor Bukanov" . "igor@mir2.org"))
  :maintainers '(("Igor Bukanov" . "igor@mir2.org")))
