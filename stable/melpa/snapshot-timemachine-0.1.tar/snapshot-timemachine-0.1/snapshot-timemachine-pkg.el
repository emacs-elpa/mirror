;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snapshot-timemachine" "0.1"
  "Step through (Btrfs, ZFS, ...) snapshots of files."
  ()
  :url "https://github.com/mrBliss/snapshot-timemachine"
  :commit "4641c7daada80e6947a2978add388f578de25f42"
  :revdesc "4641c7daada8"
  :authors '(("Thomas Winant" . "dewinant@gmail.com"))
  :maintainers '(("Thomas Winant" . "dewinant@gmail.com")))
