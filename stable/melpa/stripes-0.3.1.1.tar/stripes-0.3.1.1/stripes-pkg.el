;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripes" "0.3.1.1"
  "Highlight alternating lines differently."
  '((emacs "24"))
  :url "https://gitlab.com/stepnem/stripes-el"
  :commit "7b1d501f44b697a0514ef6759fd126d65867f18d"
  :revdesc "7b1d501f44b6"
  :keywords '("convenience" "faces")
  :authors '(("Michael Schierl" . "schierlm-public@gmx.de")
             ("těpán Němec" . "stepnem@gmail.com"))
  :maintainers '(("těpán Němec" . "stepnem@gmail.com")))
