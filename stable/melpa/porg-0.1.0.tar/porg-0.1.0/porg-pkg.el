;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "porg" "0.1.0"
  "Bring org-mode features to any prog mode."
  '((emacs "26.1"))
  :url "https://github.com/laluxx/porg"
  :commit "9f8e348b4cfd3ba6799f0f899610f567796b89ad"
  :revdesc "9f8e348b4cfd"
  :keywords '("folding" "convenience" "org-mode"))
