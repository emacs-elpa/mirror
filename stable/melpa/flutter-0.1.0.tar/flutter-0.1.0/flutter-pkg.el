;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flutter" "0.1.0"
  "Tools for working with Flutter SDK."
  '((emacs "24.5"))
  :url "https://github.com/amake/flutter.el"
  :commit "f757f34d906134c2617f72d4d592f1ca6fee83e0"
  :revdesc "f757f34d9061"
  :keywords '("languages"))
