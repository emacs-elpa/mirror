;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-tab-groups" "1.0.2"
  "Simple auto tab group creator for specified commands."
  '((emacs "29.1"))
  :url "https://github.com/MArpogaus/auto-tab-groups"
  :commit "4cdf0f121efe2e32854bb6e198eabb3230906f48"
  :revdesc "v1.0.2-0-g4cdf0f121efe"
  :keywords '("convenience" "tabs")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
