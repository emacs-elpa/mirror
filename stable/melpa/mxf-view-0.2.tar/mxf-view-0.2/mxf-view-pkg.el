;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mxf-view" "0.2"
  "Simple MXF viewer."
  '((emacs "25"))
  :url "https://github.com/t-suwa/mxf-view"
  :commit "9fd914cd2ef41a5e67a2d6df5a5b65e328199557"
  :revdesc "9fd914cd2ef4"
  :keywords '("data" "multimedia")
  :authors '(("Tomotaka SUWA" . "tomotaka.suwa@gmail.com"))
  :maintainers '(("Tomotaka SUWA" . "tomotaka.suwa@gmail.com")))
