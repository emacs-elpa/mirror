;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpages" "20141120"
  "An Emacs buffer for quickly writing your Morning Pages."
  ()
  :url "https://github.com/slevin/mpages"
  :commit "b3296390403c0f9c2d00e6908a032381a30268f7"
  :revdesc "b3296390403c")
