;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maxima" "0.8.1"
  "Major mode for Maxima."
  '((emacs       "25.1")
    (s           "1.11.0")
    (test-simple "1.3.0"))
  :url "https://gitlab.com/sasanidas/maxima"
  :commit "1334f44725bd80a265de858d652f3fde4ae401fa"
  :revdesc "1334f44725bd"
  :keywords '("maxima" "tools" "math")
  :maintainers '(("Fermin Munoz" . "fmfs@posteo.net")))
