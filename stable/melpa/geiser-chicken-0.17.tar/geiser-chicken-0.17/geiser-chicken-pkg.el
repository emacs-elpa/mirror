;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-chicken" "0.17"
  "Chicken's implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.19"))
  :url "https://gitlab.com/emacs-geiser/chicken"
  :commit "79a9ac78f4df7c9ec1f918313c543c116dbb8b70"
  :revdesc "79a9ac78f4df"
  :keywords '("languages" "chicken" "scheme" "geiser"))
