;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clang-format" "0.1.0"
  "Format code using clang-format."
  '((cl-lib "0.3"))
  :url "https://github.com/emacsmirror/clang-format"
  :commit "9f4358fcc8b04018cc1ed46fcc96fc7bfa361a47"
  :revdesc "9f4358fcc8b0"
  :keywords '("tools" "c"))
