;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-cask" "0.4"
  "Cask support in Flycheck."
  '((emacs    "24.1")
    (flycheck "0.14")
    (dash     "2.4.0"))
  :url "https://github.com/flycheck/flycheck-cask"
  :commit "b4667500dcf52f96ec7e0fa10dd07edf191cbf5b"
  :revdesc "0.4-0-gb4667500dcf5"
  :keywords '("tools" "convenience")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
