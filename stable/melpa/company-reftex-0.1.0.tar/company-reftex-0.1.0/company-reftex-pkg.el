;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-reftex" "0.1.0"
  "Company backend based on RefTeX."
  '((emacs   "25.1")
    (cl-lib  "0.5")
    (s       "1.12")
    (company "0.8"))
  :url "https://github.com/TheBB/company-reftex"
  :commit "ee212a327d475ad57687f861c2cd8ec7751241d3"
  :revdesc "ee212a327d47"
  :keywords '("company" "latex" "reftex" "references" "labels" "citations")
  :authors '(("Eivind Fonn" . "evfonn@gmail.com"))
  :maintainers '(("Eivind Fonn" . "evfonn@gmail.com")))
