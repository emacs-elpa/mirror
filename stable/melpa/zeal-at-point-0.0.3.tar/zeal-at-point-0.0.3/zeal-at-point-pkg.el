;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zeal-at-point" "0.0.3"
  "Search the word at point with Zeal."
  ()
  :url "https://github.com/jinzhu/zeal-at-point"
  :commit "901cf187cb515722d40983504d5e771f3b736657"
  :revdesc "901cf187cb51"
  :authors '(("Jinzhu" . "wosmvp@gmail.com"))
  :maintainers '(("Jinzhu" . "wosmvp@gmail.com")))
