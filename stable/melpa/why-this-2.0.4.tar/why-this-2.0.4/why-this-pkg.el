;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "why-this" "2.0.4"
  "Why is this line here?  Ask version control."
  '((emacs "27.1"))
  :url "https://codeberg.org/akib/emacs-why-this"
  :commit "5203d9379afaf6703746823a580c804e1dd98e08"
  :revdesc "5203d9379afa"
  :keywords '("tools" "convenience" "vc")
  :authors '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainers '(("Akib Azmain Turja" . "akib@disroot.org")))
