;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tray" "0.1.9"
  "Various transient menus."
  '((emacs     "28.1")
    (compat    "31.0")
    (transient "0.13"))
  :url "https://github.com/tarsius/tray"
  :commit "2d3368d4dd70da4f9d7c5aec8468c97054dc8234"
  :revdesc "v0.1.9-0-g2d3368d4dd70"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.tray@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.tray@jonas.bernoulli.dev")))
