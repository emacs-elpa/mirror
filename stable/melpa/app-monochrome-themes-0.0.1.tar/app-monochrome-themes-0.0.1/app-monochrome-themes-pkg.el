;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "app-monochrome-themes" "0.0.1"
  "Low contrast monochromatic themes optimised for OLED."
  ()
  :url "https://github.com/Greybeard-Entertainment/app-monochrome"
  :commit "2057971bbba2a9fb9b8568f7c6c65bf33b98e80f"
  :revdesc "2057971bbba2"
  :authors '(("Aleksandr Petrosyan" . "appetrosan3@gmail.com"))
  :maintainers '(("Aleksandr Petrosyan" . "appetrosan3@gmail.com")))
