;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-annex" "1.9.0"
  "Control git-annex from Magit."
  '((emacs "26.1")
    (magit "4.0.0"))
  :url "https://github.com/magit/magit-annex"
  :commit "9db0bc61461f222106c7ae3d8cd6d3de1f1b143f"
  :revdesc "v1.9.0-0-g9db0bc61461f"
  :keywords '("vc" "tools")
  :authors '(("Kyle Meyer" . "kyle@kyleam.com")
             ("Rémi Vanicat" . "vanicat@debian.org"))
  :maintainers '(("Kyle Meyer" . "kyle@kyleam.com")
                 ("Rémi Vanicat" . "vanicat@debian.org")))
