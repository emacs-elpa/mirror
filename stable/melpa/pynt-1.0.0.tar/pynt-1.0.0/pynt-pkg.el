;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pynt" "1.0.0"
  "Generate and scroll EIN buffers from python code."
  '((emacs    "24.4")
    (ein      "0.13.1")
    (epc      "0.1.1")
    (deferred "0.5.1")
    (helm     "2.8.8"))
  :url "https://github.com/ebanner/pynt"
  :commit "bc750cd244141005ea3b7bb87f75c6f6c5a5778f"
  :revdesc "bc750cd24414"
  :keywords '("convenience")
  :authors '(("Edward Banner" . "edward.banner@gmail.com"))
  :maintainers '(("Edward Banner" . "edward.banner@gmail.com")))
