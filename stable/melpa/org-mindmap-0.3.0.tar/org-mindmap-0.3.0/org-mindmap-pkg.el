;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mindmap" "0.3.0"
  "Editable mindmap visualization in org-mode."
  '((emacs "29.1")
    (org   "9.1"))
  :url "https://github.com/krvkir/org-mindmap"
  :commit "de81481bff9e33568b7df202478e95aff9e7b4af"
  :revdesc "de81481bff9e"
  :keywords '("org" "tools" "outlines")
  :authors '(("krvkir" . "krvkir@gmail.com"))
  :maintainers '(("krvkir" . "krvkir@gmail.com")))
