;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rinari" "2.11"
  "Rinari Is Not A Rails IDE."
  '((ruby-mode        "1.0")
    (inf-ruby         "2.2.5")
    (ruby-compilation "0.16")
    (jump             "2.0"))
  :url "https://github.com/eschulte/rinari"
  :commit "e2ed2fa55ac3435a86b1cf6a4f2d29aebc309135"
  :revdesc "e2ed2fa55ac3"
  :keywords '("ruby" "rails" "project" "convenience" "web"))
