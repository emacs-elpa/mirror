;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plenv" "0.32"
  "A plenv wrapper for Emacs."
  ()
  :url "https://github.com/karupanerura/plenv.el"
  :commit "ee937d0f3a1a7ba2d035f45be896d3ed8fefaee2"
  :revdesc "ee937d0f3a1a"
  :keywords '("emacs" "perl")
  :authors '(("Kenta Sato" . "karupa@cpan.org"))
  :maintainers '(("Kenta Sato" . "karupa@cpan.org")))
