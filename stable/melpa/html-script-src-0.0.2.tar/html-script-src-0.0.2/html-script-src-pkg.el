;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "html-script-src" "0.0.2"
  "Insert <script src=\"..\"> for popular JavaScript libraries."
  ()
  :url "https://github.com/rejeep/html-script-src"
  :commit "52da4421ec4a0603d5cf9e2278e36a614f871dd2"
  :revdesc "52da4421ec4a"
  :keywords '("tools" "convenience")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
