;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-command-x" "0.1.3"
  "Extensions for shell commands."
  '((emacs "28.1"))
  :url "https://github.com/elizagamedev/shell-command-x.el"
  :commit "416dad677314e3eec704d5b02594b5f8a7e7fd65"
  :revdesc "v0.1.3-0-g416dad677314"
  :keywords '("convenience" "processes" "unix"))
