;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oj" "1.0.0"
  "Competitive programming tools client for AtCoder, Codeforces."
  '((emacs    "26.1")
    (quickrun "2.2"))
  :url "https://github.com/conao3/oj.el"
  :commit "d103730610149f4b395baca127a4f922e8d09618"
  :revdesc "d10373061014"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
