;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pretty-symbols" "2.0"
  "L a m b d a -> λ."
  ()
  :url "https://github.com/drothlis/pretty-symbols"
  :commit "e88f349cca9282cf20886c833713e2d4f6c64894"
  :revdesc "e88f349cca92"
  :keywords '("faces")
  :authors '(("David Röthlisberger" . "david@rothlis.net"))
  :maintainers '(("David Röthlisberger" . "david@rothlis.net")))
