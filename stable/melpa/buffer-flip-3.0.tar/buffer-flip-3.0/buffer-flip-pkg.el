;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-flip" "3.0"
  "Cycle through buffers like Alt-Tab in Windows."
  ()
  :url "https://github.com/killdash9/buffer-flip.el"
  :commit "5b85c1cfd37b60c7419e1d4bf8931ea04c0db743"
  :revdesc "5b85c1cfd37b"
  :keywords '("convenience")
  :authors '(("Russell Black" . "(killdash9@github)"))
  :maintainers '(("Russell Black" . "(killdash9@github)")))
