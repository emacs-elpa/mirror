;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leerzeichen" "0.0.0.20220626.23"
  "Minor mode to display whitespace characters."
  ()
  :url "https://github.com/fgeller/leerzeichen.el"
  :commit "9d4126d5f6563569080845a69b0867119a9fd6ea"
  :revdesc "9d4126d5f656"
  :keywords '("whitespace" "characters")
  :authors '(("Felix Geller" . "fgeller@gmail.com"))
  :maintainers '(("Felix Geller" . "fgeller@gmail.com")))
