;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neon-mode" "1.3.0"
  "Simple major mode for editing neon files."
  ()
  :url "https://github.com/Fuco1/neon-mode"
  :commit "99d15e46beaf1e7d71e39a00cce810df1f33229d"
  :revdesc "99d15e46beaf"
  :keywords '("conf")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
