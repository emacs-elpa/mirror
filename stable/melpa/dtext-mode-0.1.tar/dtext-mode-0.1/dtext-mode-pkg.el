;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dtext-mode" "0.1"
  "Major mode for Danbooru DText."
  '((emacs       "24.4")
    (bbcode-mode "20190304.2122"))
  :url "https://github.com/JohnDevlopment/dtext-mode.el"
  :commit "9e9a202518e075b88de22b5b0c0ae3e8409cd637"
  :revdesc "9e9a202518e0"
  :keywords '("languages")
  :authors '(("John Russell" . "johndevlopment7@gmail.com"))
  :maintainers '(("John Russell" . "johndevlopment7@gmail.com")))
