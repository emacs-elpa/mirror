;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-hatena-bookmark" "0.5.0"
  "Consult commands for the Hatena Bookmark."
  '((emacs   "27.1")
    (consult "2.0"))
  :url "https://github.com/Nyoho/consult-hatena-bookmark"
  :commit "82591ce9cfb793c29278eca9f2dec9fca203427e"
  :revdesc "82591ce9cfb7")
