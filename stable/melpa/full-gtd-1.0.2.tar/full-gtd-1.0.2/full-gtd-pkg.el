;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "1.0.2"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "61ff6fa7173e290b6271c56a99f0a0bf5101e318"
  :revdesc "61ff6fa7173e"
  :keywords '("outlines" "tools" "convenience" "org" "todo" "gtd" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
