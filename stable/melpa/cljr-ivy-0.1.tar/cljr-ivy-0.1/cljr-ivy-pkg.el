;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cljr-ivy" "0.1"
  "Access clojure refactor with ivy completion."
  '((clj-refactor "2.5.0")
    (ivy          "0.13.0")
    (emacs        "25.1")
    (cl-lib       "1.0"))
  :url "https://github.com/wandersoncferreira/cljr-ivy"
  :commit "f538232e06a4985a5f3d02be1a3b2458c3bbc956"
  :revdesc "f538232e06a4"
  :keywords '("ivy" "clojure" "refactor")
  :authors '(("Wanderson Ferreira" . "iagwanderson@gmail.com"))
  :maintainers '(("Wanderson Ferreira" . "iagwanderson@gmail.com")))
