;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yankpad" "1.6"
  "Paste snippets from an org-mode file."
  ()
  :url "https://github.com/Kungsgeten/yankpad"
  :commit "d2ea6920a2444f1ce6f53947640446b8e16f84b7"
  :revdesc "d2ea6920a244"
  :keywords '("abbrev" "convenience"))
