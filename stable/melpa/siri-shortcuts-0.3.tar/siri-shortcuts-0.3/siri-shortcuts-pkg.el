;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "siri-shortcuts" "0.3"
  "Interact with Siri Shortcuts."
  '((emacs "25.2"))
  :url "https://github.com/DaniruKun/siri-shortcuts.el"
  :commit "190f242f71e071adfd89fa1f2f6ea22b62afd133"
  :revdesc "190f242f71e0"
  :keywords '("convenience" "multimedia")
  :authors '(("Daniils Petrovs" . "thedanpetrov@gmail.com"))
  :maintainers '(("Daniils Petrovs" . "thedanpetrov@gmail.com")))
