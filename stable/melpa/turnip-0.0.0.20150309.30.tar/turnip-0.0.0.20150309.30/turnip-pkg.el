;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "turnip" "0.0.0.20150309.30"
  "Interacting with tmux from Emacs."
  '((dash "2.6.0")
    (s    "1.9.0"))
  :url "https://github.com/kljohann/turnip.el"
  :commit "2fd32562fc6fc1cda6d91aa939cfb29f9b16e9de"
  :revdesc "2fd32562fc6f"
  :keywords '("terminals" "tools")
  :authors '(("Johann Klähn" . "kljohann@gmail.com"))
  :maintainers '(("Johann Klähn" . "kljohann@gmail.com")))
