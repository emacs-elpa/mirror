;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "japanese-holidays" "1.190317"
  "Calendar functions for the Japanese calendar."
  '((cl-lib "0.3"))
  :url "https://github.com/emacs-jp/japanese-holidays"
  :commit "f04662cf1e96a2ef9fd7be43e9723fe355025d50"
  :revdesc "f04662cf1e96"
  :keywords '("calendar")
  :authors '(("Takashi Hattori" . "hattori@sfc.keio.ac.jp")
             ("Hiroya Murata" . "lapis-lazuli@pop06.odn.ne.jp"))
  :maintainers '(("Takashi Hattori" . "hattori@sfc.keio.ac.jp")
                 ("Hiroya Murata" . "lapis-lazuli@pop06.odn.ne.jp")))
