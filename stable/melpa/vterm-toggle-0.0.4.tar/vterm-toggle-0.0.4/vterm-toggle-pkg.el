;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vterm-toggle" "0.0.4"
  "Toggles between the vterm buffer and other buffers."
  '((emacs "25.1")
    (vterm "0.0.1"))
  :url "https://github.com/jixiuf/vterm-toggle"
  :commit "9d26b84f4d33be8b382095544a2674866770b00c"
  :revdesc "9d26b84f4d33"
  :keywords '("vterm" "terminals")
  :authors '((nil . "jixiufjixiuf@qq.com"))
  :maintainers '((nil . "jixiufjixiuf@qq.com")))
