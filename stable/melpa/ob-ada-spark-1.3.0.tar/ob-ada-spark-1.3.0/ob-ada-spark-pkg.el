;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-ada-spark" "1.3.0"
  "Babel functions for Ada & SPARK."
  '((emacs "26.1")
    (f     "0.20.0"))
  :url "https://github.com/rocher/ob-ada-spark"
  :commit "38b72a41c12f8b6e6ba47f9136affa956123d73e"
  :revdesc "38b72a41c12f"
  :keywords '("languages" "tools" "outlines"))
