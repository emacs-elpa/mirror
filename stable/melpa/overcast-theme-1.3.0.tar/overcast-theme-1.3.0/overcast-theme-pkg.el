;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overcast-theme" "1.3.0"
  "A dark but vibrant color theme for Emacs."
  '((emacs "24"))
  :url "http://ismail.teamfluxion.com"
  :commit "769078cb4a6ea87a31fcea0218c06e1ec689b97c"
  :revdesc "769078cb4a6e"
  :keywords '("theme")
  :authors '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com"))
  :maintainers '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com")))
