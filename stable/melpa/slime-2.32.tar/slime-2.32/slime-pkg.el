;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "2.32"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "2fd4c2f08bf335872b8fff046f25b05179fb8571"
  :revdesc "2fd4c2f08bf3"
  :keywords '("languages" "lisp" "slime"))
