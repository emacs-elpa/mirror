;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex" "0.2.1"
  "LSP Clients for LTEX."
  '((emacs    "26.1")
    (lsp-mode "6.1")
    (f        "0.20.0")
    (s        "1.12.0"))
  :url "https://github.com/emacs-languagetool/lsp-ltex"
  :commit "7ff60400f23efe4916778e7b21a238114e5cdba7"
  :revdesc "7ff60400f23e"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
