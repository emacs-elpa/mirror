;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-reviewboard" "1.0"
  "Show open Reviewboard reviews in Magit."
  '((emacs   "25.2")
    (magit   "2.13.0")
    (s       "1.12.0")
    (request "0.3.0"))
  :url "https://github.com/jtamagnan/magit-reviewboard"
  :commit "4eb5c70217343043e6a660c9cef015f095c57d2b"
  :revdesc "4eb5c7021734"
  :keywords '("magit" "vc")
  :authors '(("Jules Tamagnan" . "jtamagnan@gmail.com"))
  :maintainers '(("Jules Tamagnan" . "jtamagnan@gmail.com")))
