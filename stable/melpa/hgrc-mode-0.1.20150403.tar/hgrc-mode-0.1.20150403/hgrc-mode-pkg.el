;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hgrc-mode" "0.1.20150403"
  "Major mode for editing hgrc files <omajid@trotts>."
  ()
  :url "https://github.com/omajid/hgrc-mode"
  :commit "cae45a9ba565bc114d631f24e6140b6846769498"
  :revdesc "cae45a9ba565"
  :keywords '("convenience" "vc" "hg")
  :authors '(("Omair Majid" . "omair.majid@gmail.com"))
  :maintainers '(("Omair Majid" . "omair.majid@gmail.com")))
