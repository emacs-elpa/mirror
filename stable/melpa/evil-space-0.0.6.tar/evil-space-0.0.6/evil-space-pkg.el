;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-space" "0.0.6"
  "Repeat motion in Evil. Correct the behaviour of what SPC should do."
  '((evil "1.0.0"))
  :url "https://github.com/linktohack/evil-space"
  :commit "f77860fa00662e2def3e1885adac777f051e1e61"
  :revdesc "f77860fa0066"
  :keywords '("space" "repeat" "motion")
  :authors '(("Quang Linh LE" . "linktohack@gmail.com"))
  :maintainers '(("Quang Linh LE" . "linktohack@gmail.com")))
