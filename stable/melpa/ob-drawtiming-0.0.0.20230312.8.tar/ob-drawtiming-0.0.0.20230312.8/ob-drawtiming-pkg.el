;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-drawtiming" "0.0.0.20230312.8"
  "Functions for drawtiming evaluation in org-babel."
  '((emacs "24.1")
    (org   "8.0"))
  :url "https://github.com/perfab71/ob-drawtiming"
  :commit "813736e20ce1c223700c87a6e70e3f126a11e933"
  :revdesc "813736e20ce1"
  :keywords '("tools" "multimedia"))
