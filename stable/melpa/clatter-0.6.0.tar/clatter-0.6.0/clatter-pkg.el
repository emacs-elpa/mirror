;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.6.0"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "6b1c8466d283b052e2dbba44e6df06f5fe0c16df"
  :revdesc "6b1c8466d283"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
