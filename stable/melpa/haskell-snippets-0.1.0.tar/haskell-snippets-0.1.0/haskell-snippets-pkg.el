;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haskell-snippets" "0.1.0"
  "Yasnippets for Haskell."
  '((yasnippet "0.8.0"))
  :url "https://github.com/haskell/haskell-snippets"
  :commit "bcf12cf33a67ddc2f023a55072859e637fe4fa25"
  :revdesc "bcf12cf33a67"
  :keywords '("snippets" "haskell")
  :authors '(("Luke Hoersten" . "luke@hoersten.org"))
  :maintainers '(("Luke Hoersten" . "luke@hoersten.org")))
