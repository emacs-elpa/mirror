;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "0.5.1"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "0ace6e048d26e580ee02f614fde578c288c765fc"
  :revdesc "0ace6e048d26"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
