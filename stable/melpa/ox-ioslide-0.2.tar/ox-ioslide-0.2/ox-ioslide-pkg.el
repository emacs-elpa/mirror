;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-ioslide" "0.2"
  "Export org-mode to Google I/O HTML5 slide."
  '((emacs  "24.1")
    (org    "8.0")
    (cl-lib "0.5")
    (f      "0.17.2"))
  :url "https://github.com/coldnew/org-ioslide"
  :commit "e81f7a6dab512da7eaa8c2c50c673538b97db267"
  :revdesc "e81f7a6dab51"
  :keywords '("html" "presentation")
  :authors '(("coldnew" . "coldnew.tw@gmail.com"))
  :maintainers '(("coldnew" . "coldnew.tw@gmail.com")))
