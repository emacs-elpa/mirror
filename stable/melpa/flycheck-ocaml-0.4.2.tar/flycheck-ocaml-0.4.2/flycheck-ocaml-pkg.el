;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-ocaml" "0.4.2"
  "Flycheck: OCaml support."
  '((emacs     "24.1")
    (flycheck  "0.22")
    (merlin    "3.0.1")
    (let-alist "1.0.3"))
  :url "https://github.com/flycheck/flycheck-ocaml"
  :commit "7f7530043d0a52f4900ced5d202534dd5e855363"
  :revdesc "7f7530043d0a"
  :keywords '("convenience" "tools" "languages" "ocaml")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
