;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "isearch-dabbrev" "0.1"
  "Use dabbrev in isearch."
  ()
  :url "https://github.com/Dewdrops/isearch-dabbrev"
  :commit "499b0654cf40ca0e05c7f878ae5f94f11270fc77"
  :revdesc "499b0654cf40"
  :keywords '("dabbrev" "isearch")
  :authors '(("Dewdrops" . "v_v_4474@126.com"))
  :maintainers '(("Dewdrops" . "v_v_4474@126.com")))
