;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yoficator" "0.9"
  "[No description available]."
  ()
  :url "https://gitlab.com/link2xt/yoficator"
  :commit "36c864e25abf628f9fd37d336b0a3b1ef769e5bb"
  :revdesc "36c864e25abf"
  :authors '(("Eugene Minkovskii" . "emin@mccme.ru")
             ("Alexander Krotov" . "ilabdsf@gmail.com"))
  :maintainers '(("Eugene Minkovskii" . "emin@mccme.ru")
                 ("Alexander Krotov" . "ilabdsf@gmail.com")))
