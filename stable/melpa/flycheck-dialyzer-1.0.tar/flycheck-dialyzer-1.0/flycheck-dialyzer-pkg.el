;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-dialyzer" "1.0"
  "Support dialyzer in flycheck."
  '((flycheck "0.18"))
  :url "https://github.com/lbolla/emacs-flycheck-dialyzer"
  :commit "3560214658cbdbd454f8b3d4f108cb51537afa36"
  :revdesc "3560214658cb"
  :authors '(("Lorenzo Bolla" . "lbolla@gmail.com"))
  :maintainers '(("Lorenzo Bolla" . "lbolla@gmail.com")))
