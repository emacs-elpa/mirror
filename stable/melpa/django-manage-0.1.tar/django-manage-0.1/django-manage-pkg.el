;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "django-manage" "0.1"
  "Django minor mode for commanding manage.py."
  '((hydra "0.13.2"))
  :url "https://github.com/gopar/django-manage"
  :commit "36cd8db4e0c3e50469b834d798c01fb39a578c12"
  :revdesc "36cd8db4e0c3"
  :keywords '("languages")
  :authors '(("Daniel Gopar" . "gopardaniel@yahoo.com"))
  :maintainers '(("Daniel Gopar" . "gopardaniel@yahoo.com")))
