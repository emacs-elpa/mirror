;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pyre" "2018.10.14"
  "Support Pyre in flycheck."
  '((emacs    "24")
    (flycheck "29")
    (cl-lib   "0.6"))
  :url "https://github.com/linnik/flycheck-pyre"
  :commit "8b14688df52de9f2d8f8ddcb9bc6f2b44bc8e70c"
  :revdesc "8b14688df52d"
  :authors '(("Vyacheslav Linnik" . "vyacheslav.linnik@gmail.com"))
  :maintainers '(("Vyacheslav Linnik" . "vyacheslav.linnik@gmail.com")))
