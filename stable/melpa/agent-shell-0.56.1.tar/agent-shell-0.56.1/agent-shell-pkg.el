;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.56.1"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.1")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6b3799cac0e3a224fc7486970bfbc46b78fde8b7"
  :revdesc "6b3799cac0e3")
