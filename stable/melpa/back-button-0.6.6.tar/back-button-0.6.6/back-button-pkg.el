;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "back-button" "0.6.6"
  "Visual navigation through mark rings."
  '((nav-flash       "1.0.0")
    (smartrep        "0.0.3")
    (ucs-utils       "0.7.2")
    (persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/back-button"
  :commit "c7b50a3e087a8dc5588d7292379cd387a1afff87"
  :revdesc "v0.6.6-0-gc7b50a3e087a"
  :keywords '("convenience" "navigation" "interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
