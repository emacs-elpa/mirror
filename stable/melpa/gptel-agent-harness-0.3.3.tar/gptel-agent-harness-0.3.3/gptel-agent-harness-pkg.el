;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent-harness" "0.3.3"
  "Agent execution harness for gptel-agent."
  '((emacs       "29.1")
    (compat      "30.1.0.0")
    (gptel-agent "0.0.1"))
  :url "https://github.com/beacoder/gptel-agent-harness"
  :commit "d9bd21a6c5a498f118dec893197e8d604ad9a46b"
  :revdesc "d9bd21a6c5a4"
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
