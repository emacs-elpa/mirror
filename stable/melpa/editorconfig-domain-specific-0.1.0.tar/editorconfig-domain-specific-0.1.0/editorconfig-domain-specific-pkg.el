;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "editorconfig-domain-specific" "0.1.0"
  "Apply brace style and other \"domain-specific\" EditorConfig properties."
  '((cl-lib       "0.5")
    (editorconfig "0.6.0"))
  :url "https://github.com/lassik/editorconfig-emacs-domain-specific"
  :commit "0142ddff7b3293c82b0a83ad2c3edd6ee1a84ddd"
  :revdesc "0142ddff7b32"
  :keywords '("editorconfig" "util")
  :authors '((nil . "@lassik"))
  :maintainers '((nil . "@lassik")))
