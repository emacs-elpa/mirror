;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-eglot" "0.1.0"
  "Show eglot information with sideline."
  '((emacs    "27.1")
    (sideline "0.1.0")
    (ht       "2.4"))
  :url "https://github.com/emacs-sideline/sideline-eglot"
  :commit "158e8819172b144364658833db80b7aa0ef24e72"
  :revdesc "158e8819172b"
  :keywords '("convenience" "eglot")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
