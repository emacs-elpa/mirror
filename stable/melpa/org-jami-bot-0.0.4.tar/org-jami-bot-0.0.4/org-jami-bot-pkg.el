;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-jami-bot" "0.0.4"
  "Capture GNU Jami messages as notes and todos in Org mode."
  '((emacs    "28.1")
    (jami-bot "0.0.2"))
  :url "https://gitlab.com/hperrey/org-jami-bot"
  :commit "a9ac8f6628978d60d8171fff45997c3e25dd35b5"
  :revdesc "a9ac8f662897"
  :keywords '("comm" "outlines" "org-capture" "jami")
  :authors '(("Hanno Perrey" . "http://gitlab.com/hperrey"))
  :maintainers '(("Hanno Perrey" . "hanno@hoowl.se")))
