;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ncl-mode" "0.99"
  "Major Mode for editing NCL scripts."
  '((emacs "24"))
  :url "https://github.com/yyr/ncl-mode"
  :commit "63e6a3ce7df4abf823ac36a0c52c161d1ec6998e"
  :revdesc "63e6a3ce7df4"
  :keywords '("ncl" "major mode" "ncl-mode" "atmospheric science.")
  :authors '(("Yagnesh Raghava Yakkala" . "hi@yagnesh.org"))
  :maintainers '(("Yagnesh Raghava Yakkala" . "hi@yagnesh.org")))
