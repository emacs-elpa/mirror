;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-box" "0.0.1"
  "Company front-end."
  '((emacs           "26.1")
    (dash            "2.13")
    (dash-functional "1.2.0")
    (company         "0.9.6"))
  :url "https://github.com/sebastiencs/company-box"
  :commit "b1fe4a1e996ebf4b8db7a5f708443c1e834edc5e"
  :revdesc "b1fe4a1e996e"
  :keywords '("company" "completion" "front-end")
  :authors '(("Sebastien Chapuis" . "sebastien@chapu.is"))
  :maintainers '(("Sebastien Chapuis" . "sebastien@chapu.is")))
