;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mb-url" "0.12.0"
  "Multiple Backends for Emacs URL package."
  '((emacs "25"))
  :url "https://github.com/dochang/mb-url"
  :commit "a9f1e8ab46858c35a600ce304748a7db65400bef"
  :revdesc "0.12.0-0-ga9f1e8ab4685"
  :keywords '("comm" "data" "processes" "hypermedia")
  :authors '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainers '(("ZHANG Weiyi" . "dochang@gmail.com")))
