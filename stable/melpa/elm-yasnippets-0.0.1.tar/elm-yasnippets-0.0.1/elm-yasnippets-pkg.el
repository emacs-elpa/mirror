;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elm-yasnippets" "0.0.1"
  "Yasnippets for Elixir."
  '((yasnippet "0.8.0"))
  :url "https://github.com/abingham/elm-yasnippets"
  :commit "9e41725546597d4c83282208a107db3cde301764"
  :revdesc "9e4172554659"
  :keywords '("snippets")
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
