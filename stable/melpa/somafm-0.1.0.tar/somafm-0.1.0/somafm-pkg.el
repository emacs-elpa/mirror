;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "somafm" "0.1.0"
  "A simple soma.fm interface."
  '((emacs   "26.1")
    (dash    "2.12.0")
    (request "0.3.2")
    (cl-lib  "0.6.1"))
  :url "https://github.com/artenator/somafm.el"
  :commit "af164b706ab501a3d2451568452b22a654c1e6a3"
  :revdesc "af164b706ab5"
  :keywords '("multimedia")
  :authors '(("Arte Ebrahimi" . ""))
  :maintainers '(("Arte Ebrahimi" . "")))
