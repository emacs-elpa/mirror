;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rasi-mode" "0.0.1"
  "Major mode for editing RASI files."
  ()
  :url "https://github.com/taquangtrung/emacs-rasi-mode"
  :commit "3a7bd14354ea0b26849fad13803c699591aef2eb"
  :revdesc "3a7bd14354ea"
  :keywords '("languages"))
