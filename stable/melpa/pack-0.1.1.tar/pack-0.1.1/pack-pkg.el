;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pack" "0.1.1"
  "Pack and unpack archive files."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/10sr/pack-el"
  :commit "85cd856fdc00a2365e88b50373b99f1b3d2227be"
  :revdesc "85cd856fdc00"
  :keywords '("files" "dired")
  :authors '(("10sr" . "8.slashes@gmail.com"))
  :maintainers '(("10sr" . "8.slashes@gmail.com")))
