;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-bashate" "0.1"
  "Integrate bashate with flycheck."
  '((flycheck "0.24")
    (emacs    "24.4"))
  :url "https://github.com/alexmurray/flycheck-bashate"
  :commit "d9780b73ee698d6bc001e617b187845cafa3292a"
  :revdesc "d9780b73ee69"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
