;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "5.2.1"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (treepy   "0.1.3"))
  :url "https://github.com/magit/ghub"
  :commit "62d3582f1e395de1cf410af1f125dae56fe1dc4d"
  :revdesc "v5.2.1-0-g62d3582f1e39"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
