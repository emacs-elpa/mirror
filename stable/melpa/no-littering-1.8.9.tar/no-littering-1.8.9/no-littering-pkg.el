;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "1.8.9"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "719c2a3773419ebc92a06e61b0fb26f6d64e750e"
  :revdesc "v1.8.9-0-g719c2a377341"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
