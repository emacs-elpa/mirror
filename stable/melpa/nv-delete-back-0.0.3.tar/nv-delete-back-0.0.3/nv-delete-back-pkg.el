;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nv-delete-back" "0.0.3"
  "Backward delete like modern text editors."
  '((emacs "24"))
  :url "https://gitlab.com/nivaca/nv-delete-back"
  :commit "45bf0668a44a51d5da8677744f4df7f1792d9223"
  :revdesc "45bf0668a44a"
  :keywords '("lisp")
  :authors '(("Nicolas Vaughan" . "n.vaughan[at]oxon.org"))
  :maintainers '(("Nicolas Vaughan" . "n.vaughan[at]oxon.org")))
