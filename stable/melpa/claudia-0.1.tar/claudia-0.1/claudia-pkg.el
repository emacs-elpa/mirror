;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claudia" "0.1"
  "Claude AI Emacs integration."
  '((emacs         "27.1")
    (uuidgen       "0.3")
    (markdown-mode "2.3"))
  :url "https://github.com/mzacho/claudia"
  :commit "e51e9a824456b3dd71b93687689615b88aa46b1c"
  :revdesc "e51e9a824456"
  :keywords '("ai" "tools" "productivity" "codegen")
  :authors '(("Martin Zacho" . "hi@martinzacho.net"))
  :maintainers '(("Martin Zacho" . "hi@martinzacho.net")))
