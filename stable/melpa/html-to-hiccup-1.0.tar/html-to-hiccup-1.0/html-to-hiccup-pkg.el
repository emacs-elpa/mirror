;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "html-to-hiccup" "1.0"
  "Convert HTML to Hiccup syntax."
  ()
  :url "https://github.com/plexus/html-to-hiccup"
  :commit "e08700529b9ab7d159b4c5e1d838e95125136de8"
  :revdesc "e08700529b9a"
  :keywords '("html" "hiccup" "clojure")
  :authors '(("Arne Brasseur" . "arne@arnebrasseur.net"))
  :maintainers '(("Arne Brasseur" . "arne@arnebrasseur.net")))
