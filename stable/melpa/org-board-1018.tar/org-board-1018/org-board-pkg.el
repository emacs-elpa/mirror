;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-board" "1018"
  "Bookmarking and web archival system for Org mode."
  ()
  :url "https://github.com/scallywag/org-board"
  :commit "405bfd630f1b31bd77158bc8e79aab86812cba65"
  :revdesc "405bfd630f1b"
  :keywords '("org" "bookmarks" "archives")
  :authors '(("Charles A. Roelli" . "charles@aurox.ch"))
  :maintainers '(("Charles A. Roelli" . "charles@aurox.ch")))
