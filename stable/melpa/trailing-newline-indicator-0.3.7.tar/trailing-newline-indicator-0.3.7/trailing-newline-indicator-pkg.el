;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trailing-newline-indicator" "0.3.7"
  "Show an indicator for the trailing newline."
  '((emacs "26.1"))
  :url "https://github.com/saulotoledo/trailing-newline-indicator"
  :commit "52af1d7d63499020b21d57147cd7d27bc1bb35d3"
  :revdesc "52af1d7d6349"
  :keywords '("convenience" "display" "editing")
  :authors '(("Saulo S. de Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo S. de Toledo" . "saulotoledo@gmail.com")))
