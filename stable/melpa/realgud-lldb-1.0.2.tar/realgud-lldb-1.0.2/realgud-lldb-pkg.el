;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-lldb" "1.0.2"
  "Realgud front-end to lldb."
  '((load-relative "1.3.1")
    (realgud       "1.5.0")
    (emacs         "25"))
  :url "https://github.com/realgud/realgud-lldb"
  :commit "f2f77d6ddfa42430ead400eaf81c605c3a04dead"
  :revdesc "f2f77d6ddfa4"
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
