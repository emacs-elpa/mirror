;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elvish-mode" "0.1.0"
  "Defines a major mode for Elvish."
  ()
  :url "https://github.com/ALSchwalm/elvish-mode"
  :commit "3b410266d2a50f77101adfe91ce0f80f12af88ae"
  :revdesc "3b410266d2a5"
  :authors '(("Adam Schwalm" . "adamschwalm@gmail.com"))
  :maintainers '(("Adam Schwalm" . "adamschwalm@gmail.com")))
