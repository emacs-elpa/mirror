;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-racer" "0.1"
  "Company integration for racer."
  '((emacs      "24")
    (cl-lib     "0.5")
    (company    "0.8.0")
    (concurrent "0.3.1")
    (rust-mode  "0.2.0"))
  :url "https://github.com/emacs-pe/company-racer"
  :commit "4661696f1913f0e5a6b2a9fec8c41e921a9f02da"
  :revdesc "4661696f1913"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
