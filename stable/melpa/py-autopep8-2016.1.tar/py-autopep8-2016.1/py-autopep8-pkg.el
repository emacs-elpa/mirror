;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-autopep8" "2016.1"
  "Use autopep8 to beautify a Python buffer."
  ()
  :url "http://paetzke.me/project/py-autopep8.el"
  :commit "68e12d8788c91c7ec53a68acf1d23adb2ffa4788"
  :revdesc "68e12d8788c9"
  :authors '(("Friedrich Paetzke" . "f.paetzke@gmail.com"))
  :maintainers '(("Friedrich Paetzke" . "f.paetzke@gmail.com")))
