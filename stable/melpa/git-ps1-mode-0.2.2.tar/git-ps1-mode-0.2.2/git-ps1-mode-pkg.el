;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-ps1-mode" "0.2.2"
  "Global minor-mode to print __git_ps1."
  ()
  :url "https://github.com/10sr/git-ps1-mode-el"
  :commit "288e5c4d0ff20a4e1ac9e72b6af632f67f1d7525"
  :revdesc "288e5c4d0ff2"
  :keywords '("utility" "mode-line" "git")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
