;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lpy" "0.1.0"
  "A lispy interface to Python."
  ()
  :url "https://github.com/abo-abo/lpy"
  :commit "29adfcc590a1655b7333269467239e30efb1cf96"
  :revdesc "29adfcc590a1"
  :keywords '("python" "lisp")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
