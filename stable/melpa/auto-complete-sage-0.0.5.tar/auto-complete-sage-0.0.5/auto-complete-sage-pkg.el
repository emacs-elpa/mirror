;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-sage" "0.0.5"
  "An auto-complete source for sage-shell-mode."
  '((auto-complete   "1.5.0")
    (sage-shell-mode "0.0.8"))
  :url "https://github.com/stakemori/auto-complete-sage"
  :commit "a61a4e58b14134712e0737280281c0b10e56da93"
  :revdesc "a61a4e58b141"
  :keywords '("sage" "math" "auto-complete")
  :authors '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainers '(("Sho Takemori" . "stakemorii@gmail.com")))
