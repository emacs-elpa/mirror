;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eplotly" "0.1"
  "Create Plotly charts."
  '((emacs "26.1"))
  :url "https://codeberg.org/GioBo/eplotly"
  :commit "e6e18ca032ab40443f96cae202f022b9c89b0639"
  :revdesc "e6e18ca032ab"
  :keywords '("tools")
  :authors '((nil . ""))
  :maintainers '((nil . "")))
