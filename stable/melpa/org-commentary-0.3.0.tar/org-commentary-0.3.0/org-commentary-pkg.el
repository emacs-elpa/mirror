;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-commentary" "0.3.0"
  "Generate or update conventional library headers using Org mode files."
  '((dash  "2.0")
    (emacs "24.4")
    (org   "8.0"))
  :url "https://github.com/smaximov/org-commentary"
  :commit "2eeeb0f506e30ef82263e67279d837a79cbde021"
  :revdesc "v0.3.0-0-g2eeeb0f506e3"
  :keywords '("convenience" "docs" "tools")
  :authors '(("Sergei Maximov" . "s.b.maximov@gmail.com"))
  :maintainers '(("Sergei Maximov" . "s.b.maximov@gmail.com")))
