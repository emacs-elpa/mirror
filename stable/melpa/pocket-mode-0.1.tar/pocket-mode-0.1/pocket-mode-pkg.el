;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pocket-mode" "0.1"
  "Manage your pocket."
  '((emacs      "24.4")
    (pocket-api "0.1"))
  :url "https://github.com/lujun9972/pocket-mode"
  :commit "0e08a312e7aa8f7225ac8b999548b250f7dcc18e"
  :revdesc "0e08a312e7aa"
  :keywords '("convenience" "pocket")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
