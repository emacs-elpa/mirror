;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weak-ref" "2.0"
  "Weak references for Emacs Lisp."
  ()
  :url "https://github.com/skeeto/elisp-weak-ref"
  :commit "434e7d7cc84d0813bd06606a04c08fc96cd9eec8"
  :revdesc "2.0-0-g434e7d7cc84d"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
