;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-kotlin" "0.4"
  "Support kotlin in flycheck."
  '((flycheck "0.20"))
  :url "https://github.com/whirm/flycheck-kotlin"
  :commit "5104ee9a3fdb7f0a0a3d3bcfd8dd3c45a9929310"
  :revdesc "5104ee9a3fdb"
  :authors '(("Elric Milon" . "whirm_REMOVETHIS__@gmx.com"))
  :maintainers '(("Elric Milon" . "whirm_REMOVETHIS__@gmx.com")))
