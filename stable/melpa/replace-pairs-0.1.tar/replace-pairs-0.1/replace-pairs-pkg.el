;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "replace-pairs" "0.1"
  "Find-replace pairs of things."
  '((dash  "2.10.0")
    (names "20150618.0")
    (emacs "24.4"))
  :url "https://github.com/davidshepherd7/replace-pairs"
  :commit "9ceff701ebbfcd24f5c45a00f18e2c062b4887a6"
  :revdesc "9ceff701ebbf"
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
