;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hide-lines" "20130623.1701"
  "Commands for hiding lines based on a regexp."
  ()
  :url "https://github.com/vapniks/hide-lines"
  :commit "c5c362b5333a4bdc1135048ab3c93e61f20a470c"
  :revdesc "c5c362b5333a"
  :keywords '("convenience")
  :authors '(("Mark Hulme-Jones" . "tureatpligcucumberdotnet"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
