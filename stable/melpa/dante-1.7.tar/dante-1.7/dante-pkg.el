;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dante" "1.7"
  "Development mode for Haskell."
  '((dash         "2.12.0")
    (emacs        "25.1")
    (f            "0.19.0")
    (flycheck     "0.30")
    (company      "0.9")
    (haskell-mode "13.14")
    (s            "1.11.0")
    (lcr          "1.2"))
  :url "https://github.com/jyp/dante"
  :commit "b9061204dfa4c0a62589c25159b6a9b6bcc030be"
  :revdesc "b9061204dfa4"
  :keywords '("haskell" "tools")
  :authors '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com"))
  :maintainers '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com")))
