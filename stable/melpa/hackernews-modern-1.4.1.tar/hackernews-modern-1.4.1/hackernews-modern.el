;;; hackernews-modern.el --- Hacker News client with modern widget UI -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; Keywords: comm hypermedia news
;; Package-Version: 1.4.1
;; Package-Revision: 97b64f3ba1d3
;; Package-Requires: ((emacs "28.1") (visual-fill-column "2.2") (async-http-queue "0.1.0"))
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Read Hacker News from Emacs using a modern widget-based interface.

;;; Code:

(require 'async-http-queue)
(require 'hackernews-modern-core)
(require 'hackernews-modern-account)
(require 'hackernews-modern-comments)
(require 'hackernews-modern-vote)
(require 'hackernews-modern-submit)

;; Forward declarations for controller symbols referenced in view.
(defvar hackernews-modern-mode-map)
(declare-function visual-fill-column-mode "visual-fill-column")

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar hackernews-modern-feed-names
  '(("top"  . "top stories")
    ("new"  . "new stories")
    ("best" . "best stories")
    ("ask"  . "ask stories")
    ("show" . "show stories")
    ("job"  . "job stories"))
  "Map feed types as strings to their display names.")

(put 'hackernews-modern-feed-names 'risky-local-variable t)

(defvar hackernews-modern-feed-history ()
  "Completion history of hackernews-modern feeds switched to.")

(defvar-local hackernews-modern--feed-state ()
  "Plist capturing state of current buffer's Hacker News feed.
:feed     - Type of endpoint feed; see `hackernews-modern-feed-names'.
:items    - Vector holding items being or last fetched.
:shown    - List of the items rendered in the buffer, in order.
:register - Cons of number of items currently displayed and
            vector of item IDs last read from this feed.
            The `car' is thus an offset into the `cdr'.
:more-start  - Marker at the start of the \"Load more\" button, if shown.
:more-button - Widget of the \"Load more\" button, if shown.")

(defun hackernews-modern--get (prop)
  "Extract value of PROP from `hackernews-modern--feed-state'."
  (plist-get hackernews-modern--feed-state prop))

(defun hackernews-modern--put (prop val)
  "Change value in `hackernews-modern--feed-state' of PROP to VAL."
  (setq hackernews-modern--feed-state (plist-put hackernews-modern--feed-state prop val)))

(defun hackernews-modern--feed-url (feed)
  "Return Hacker News API URL for FEED.
See `hackernews-modern-feed-names' for supported values of FEED."
  (hackernews-modern--format-api-url "%sstories" feed))

(defun hackernews-modern--feed-name (feed)
  "Lookup FEED in `hackernews-modern-feed-names'."
  (cdr (assoc-string feed hackernews-modern-feed-names)))

(defun hackernews-modern--feed-annotation (feed)
  "Annotate FEED during completion.
This is intended as an :annotation-function in
`completion-extra-properties'."
  (let ((name (hackernews-modern--feed-name feed)))
    (and name (concat " - " name))))

(defun hackernews-modern--retrieve-items-async (callback)
  "Retrieve items associated with current buffer asynchronously.
Calls CALLBACK when all items have been fetched.
Uses `async-http-queue' for non-blocking, parallel downloads."
  (let* ((target-buffer (current-buffer))
         (reg    (hackernews-modern--get :register))
         (nitem  (hackernews-modern--get :nitem))
         (offset (car reg))
         (ids    (cdr reg))
         (urls '()))
    ;; Build list of URLs to fetch
    (dotimes (i nitem)
      (push (hackernews-modern--item-url (aref ids (+ offset i))) urls))
    (setq urls (nreverse urls))

    ;; Fetch items asynchronously using async-http-queue
    (async-http-queue
     urls
     :max-concurrent 10
     :parser (lambda () (json-parse-buffer :object-type 'alist))
     :callback
     (lambda (items)
       ;; Execute in the correct buffer context
       (with-current-buffer target-buffer
         ;; Store items in buffer state
         (hackernews-modern--put :items items)
         ;; Call completion callback
         (funcall callback))))))

;;;; View ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defconst hackernews-modern--feed-buttons
  '(("top"  "🔥 " "View top stories"  hackernews-modern-top-stories)
    ("new"  "🆕 " "View new stories"  hackernews-modern-new-stories)
    ("best" "⭐ " "View best stories" hackernews-modern-best-stories)
    ("ask"  "❓ " "View ask stories"  hackernews-modern-ask-stories)
    ("show" "📺 " "View show stories" hackernews-modern-show-stories))
  "Feed button specs: (feed-key emoji help-text command).")

(defun hackernews-modern--insert-header (feed-name)
  "Insert the page header showing FEED-NAME and navigation buttons."
  (hackernews-modern--insert-logo)
  (dolist (spec hackernews-modern--feed-buttons)
    (let ((label (capitalize (nth 0 spec)))
          (emoji (nth 1 spec))
          (help  (nth 2 spec))
          (cmd   (nth 3 spec)))
      (widget-create 'push-button
                     :notify (lambda (&rest _) (call-interactively cmd))
                     :help-echo help
                     (format " %s%s " (if hackernews-modern-enable-emojis emoji "") label))
      (insert " ")))
  (widget-create 'push-button
                 :notify (lambda (&rest _) (hackernews-modern-reload))
                 :help-echo "Refresh current feed"
                 " ↻ Refresh ")
  (insert "\n\n")
  (insert (propertize (format "Showing: %s" feed-name)
                      'face 'hackernews-modern-feed-indicator))
  (hackernews-modern--insert-account)
  (insert "\n\n")
  (insert "Keys: (n) Next (p) Prev (c) Comments (v) Vote (m) More (g) Refresh (q) Quit\n")
  (hackernews-modern--insert-separator))

(defun hackernews-modern--render-item (item)
  "Render Hacker News ITEM in the current buffer using widgets."
  (let* ((id           (cdr (assq 'id          item)))
         (title        (cdr (assq 'title       item)))
         (score        (cdr (assq 'score       item)))
         (by           (cdr (assq 'by          item)))
         (item-url     (cdr (assq 'url         item)))
         (descendants  (cdr (assq 'descendants item)))
         (comments-url (hackernews-modern--comments-url id))
         (item-start   (point)))
    (setq title (xml-substitute-special title))
    (widget-create 'push-button
                   :notify (lambda (&rest _)
                             (hackernews-modern--browse-url (or item-url comments-url)))
                   :help-echo (or item-url "No URL")
                   :format "%[%v%]"
                   title)
    (insert "\n")
    (insert (propertize "  " 'face 'default))
    (insert (propertize (format "↑%d" (or score 0))
                        'face 'hackernews-modern-score-modern))
    (insert " | ")
    (widget-create 'push-button
                   :notify (lambda (&rest _)
                             (hackernews-modern--open-comments id))
                   :help-echo (format "View comments: %s" comments-url)
                   :format "%[%v%]"
                   (format "%s%d comment%s"
                           (if hackernews-modern-enable-emojis "💬 " "")
                           (or descendants 0)
                           (if (= (or descendants 0) 1) "" "s")))
    (when by
      (insert " | by ")
      (insert (propertize by 'face 'hackernews-modern-author)))
    (when (hackernews-modern--can-vote-p by)
      (insert " | ")
      (hackernews-modern--insert-vote-button id))
    (insert "\n")
    (hackernews-modern--insert-separator)
    (put-text-property item-start (point) 'hackernews-modern-item-id id)))

(defun hackernews-modern--insert-more-button ()
  "Insert a button at point that loads more stories."
  (hackernews-modern--put :more-start (point-marker))
  (hackernews-modern--put
   :more-button
   (widget-create 'push-button
                  :notify (lambda (&rest _) (hackernews-modern-load-more-stories))
                  :help-echo "Load more stories"
                  " Load more "))
  (insert "\n"))

(defun hackernews-modern--remove-more-button ()
  "Remove the button inserted by `hackernews-modern--insert-more-button'."
  (let ((start (hackernews-modern--get :more-start)))
    (when start
      (widget-delete (hackernews-modern--get :more-button))
      (delete-region start (point-max))
      (set-marker start nil)
      (hackernews-modern--put :more-start nil)
      (hackernews-modern--put :more-button nil))))

(defun hackernews-modern--visible-items (items)
  "Return a list of the ITEMS that are neither missing, deleted nor dead."
  (seq-remove (lambda (item)
                (or (null item)
                    (cdr (assq 'deleted item))
                    (cdr (assq 'dead item))))
              items))

(defun hackernews-modern--render-stories ()
  "Render again every story shown in the current buffer.
Used when the session changes, so that the vote buttons appear or
vanish."
  (when (> (buffer-size) 0)
    (let ((reg (hackernews-modern--get :register))
          (inhibit-read-only t))
      (erase-buffer)
      (remove-overlays)
      (hackernews-modern--put :more-start nil)
      (hackernews-modern--put :more-button nil)
      (hackernews-modern--insert-header
       (hackernews-modern--feed-name (hackernews-modern--get :feed)))
      (mapc #'hackernews-modern--render-item (hackernews-modern--get :shown))
      (when (< (car reg) (length (cdr reg)))
        (hackernews-modern--insert-more-button))
      (widget-setup))))

(defun hackernews-modern--display-items ()
  "Render items associated with the current buffer and display it."
  (let* ((reg        (hackernews-modern--get :register))
         (items      (hackernews-modern--get :items))
         (nitem      (length items))
         (visible    (hackernews-modern--visible-items items))
         (feed       (hackernews-modern--get :feed))
         (feed-name  (hackernews-modern--feed-name feed))
         (first-load (= (buffer-size) 0))
         (inhibit-read-only t))
    (when first-load
      (hackernews-modern--insert-header feed-name))
    (run-hooks 'hackernews-modern-before-render-hook)
    (hackernews-modern--remove-more-button)
    (save-excursion
      (goto-char (point-max))
      (mapc #'hackernews-modern--render-item visible)
      (when (< (+ (car reg) nitem) (length (cdr reg)))
        (hackernews-modern--insert-more-button)))
    (run-hooks 'hackernews-modern-after-render-hook)
    (use-local-map (make-composed-keymap (list widget-keymap hackernews-modern-mode-map)
                                         special-mode-map))
    (widget-setup)
    (when (and (require 'visual-fill-column nil t)
               (boundp 'visual-fill-column-width))
      (setq-local visual-fill-column-width hackernews-modern-display-width)
      (setq-local visual-fill-column-center-text t)
      (visual-fill-column-mode 1))
    (when (fboundp 'display-line-numbers-mode)
      (display-line-numbers-mode 0))
    (cond
     (first-load
      (goto-char (point-min))
      (widget-forward 1))
     ((not (or (<= nitem 0) hackernews-modern-preserve-point))
      (goto-char (point-max))
      (hackernews-modern-previous-item nitem)))
    (hackernews-modern--put :shown (append (hackernews-modern--get :shown) visible))
    (setcar reg (+ (car reg) nitem)))
  (read-only-mode 1)
  (pop-to-buffer (current-buffer) '((display-buffer-same-window)))
  (run-hooks 'hackernews-modern-finalize-hook))

;;;; Controller ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar hackernews-modern-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map "c" #'hackernews-modern-show-comments)
    (define-key map "f" #'hackernews-modern-switch-feed)
    (define-key map "g" #'hackernews-modern-reload)
    (define-key map "m" #'hackernews-modern-load-more-stories)
    (define-key map "n" #'hackernews-modern-next-item)
    (define-key map "p" #'hackernews-modern-previous-item)
    (define-key map "s" #'hackernews-modern-submit)
    (define-key map "v" #'hackernews-modern-vote)
    map)
  "Keymap used in hackernews-modern buffer.")

(define-derived-mode hackernews-modern-mode special-mode "HN"
  "Mode for browsing Hacker News.

Key bindings:
\\<hackernews-modern-mode-map>
\\[hackernews-modern-next-item]		Move to next story.
\\[hackernews-modern-previous-item]		Move to previous story.
\\[hackernews-modern-load-more-stories]	Load more stories.
\\[hackernews-modern-reload]			Reload stories.
\\[hackernews-modern-switch-feed]		Switch feed.
\\<special-mode-map>\\[quit-window]	Quit.

\\{hackernews-modern-mode-map}"
  :interactive nil
  (setq hackernews-modern--feed-state ())
  (setq hackernews-modern--redraw-function #'hackernews-modern--render-stories)
  (setq truncate-lines t)
  (buffer-disable-undo))

(defun hackernews-modern-next-item (&optional n)
  "Move to Nth next story (previous if N is negative).
N defaults to 1."
  (declare (modes hackernews-modern-mode))
  (interactive "p")
  (let ((count (or n 1))
        (separator-regex (concat "^" (regexp-quote (hackernews-modern--string-separator)) "$")))
    (if (< count 0)
        (hackernews-modern-previous-item (- count))
      (dotimes (_ count)
        (if (search-forward-regexp separator-regex nil t)
            (progn
              (forward-line 2)
              (beginning-of-line)
              (recenter))
          (message "No more stories"))))))

(defun hackernews-modern-previous-item (&optional n)
  "Move to Nth previous story (next if N is negative).
N defaults to 1."
  (declare (modes hackernews-modern-mode))
  (interactive "p")
  (let ((count (or n 1))
        (separator-regex (concat "^" (regexp-quote (hackernews-modern--string-separator)) "$")))
    (if (< count 0)
        (hackernews-modern-next-item (- count))
      (dotimes (_ count)
        (search-backward-regexp separator-regex nil t)
        (if (search-backward-regexp separator-regex nil t)
            (progn
              (forward-line 2)
              (beginning-of-line)
              (recenter))
          (goto-char (point-min))
          (widget-forward 1))))))

(defun hackernews-modern-first-item ()
  "Move point to the first story in the hackernews-modern buffer."
  (declare (modes hackernews-modern-mode))
  (interactive)
  (goto-char (point-min))
  (hackernews-modern-next-item))

(defun hackernews-modern--fetch-feed-ids (feed callback)
  "Fetch list of item IDs from FEED asynchronously.
Calls CALLBACK with the vector of IDs."
  (let ((url (hackernews-modern--feed-url feed)))
    (url-retrieve
     url
     (lambda (status)
       (let ((ids nil))
         (condition-case err
             (progn
               (when (plist-get status :error)
                 (error "Failed to fetch feed: %S" (plist-get status :error)))
               (goto-char (point-min))
               (re-search-forward "\r\n\r\n\\|\n\n" nil t)
               (setq ids (json-parse-buffer)))
           (error
            (message "Error fetching feed list: %s" (error-message-string err))
            (setq ids (make-vector 0 nil))))
         (kill-buffer (current-buffer))
         (funcall callback ids)))
     nil t)))

(defun hackernews-modern--load-stories (feed n &optional append)
  "Retrieve and render at most N items from FEED asynchronously.
Create and setup corresponding hackernews-modern buffer if necessary.

If APPEND is nil, refresh the list of items from FEED and render
at most N of its top items.  Any previous hackernews-modern buffer
contents are overwritten.

Otherwise, APPEND should be a cons cell (OFFSET . IDS), where IDS
is the vector of item IDs corresponding to FEED and OFFSET
indicates where in IDS the previous retrieval and render left
off.  At most N of FEED's items starting at OFFSET are then
rendered at the end of the hackernews-modern buffer.

This function returns immediately; items are loaded asynchronously
and the buffer is updated when ready."
  (let* ((name   (hackernews-modern--feed-name feed))
         (offset (or (car append) 0)))
    (if append
        ;; Appending to existing feed - IDs already available
        (let ((ids (cdr append)))
          (with-current-buffer (get-buffer-create (format "*hackernews-modern %s*" name))
            (hackernews-modern--put :feed feed)
            (hackernews-modern--put :register (cons offset ids))
            (hackernews-modern--put :nitem
                                    (max 0 (min (- (length ids) offset)
                                                (prefix-numeric-value
                                                 (or n hackernews-modern-items-per-page)))))
            ;; Fetch items asynchronously
            (hackernews-modern--retrieve-items-async
             (lambda ()
               (hackernews-modern--display-items)))))
      ;; Fresh load - need to fetch feed IDs first
      (message "Retrieving %s..." name)
      (hackernews-modern--fetch-feed-ids
       feed
       (lambda (ids)
         (with-current-buffer (get-buffer-create (format "*hackernews-modern %s*" name))
           (let ((inhibit-read-only t))
             (erase-buffer))
           (remove-overlays)
           (hackernews-modern-mode)
           (hackernews-modern--put :feed feed)
           (hackernews-modern--put :register (cons offset ids))
           (hackernews-modern--put :nitem
                                   (max 0 (min (- (length ids) offset)
                                               (prefix-numeric-value
                                                (or n hackernews-modern-items-per-page)))))
           ;; Fetch items asynchronously
           (hackernews-modern--retrieve-items-async
            (lambda ()
              (hackernews-modern--display-items)))))))))

;;;###autoload
(defun hackernews-modern (&optional n)
  "Read top N Hacker News stories.
The feed is determined by `hackernews-modern-default-feed' and N defaults
to `hackernews-modern-items-per-page'."
  (interactive "P")
  (hackernews-modern--load-stories hackernews-modern-default-feed n))

(defun hackernews-modern-reload (&optional n)
  "Reload top N stories from the current feed.
N defaults to `hackernews-modern-items-per-page'."
  (declare (modes hackernews-modern-mode))
  (interactive "P")
  (unless (derived-mode-p #'hackernews-modern-mode)
    (user-error "Not a hackernews-modern buffer"))
  (hackernews-modern--load-stories
   (or (hackernews-modern--get :feed)
       (user-error "Buffer unassociated with feed"))
   n))

(defun hackernews-modern-load-more-stories (&optional n)
  "Load N more stories into the hackernews-modern buffer.
N defaults to `hackernews-modern-items-per-page'."
  (declare (modes hackernews-modern-mode))
  (interactive "P")
  (unless (derived-mode-p #'hackernews-modern-mode)
    (user-error "Not a hackernews-modern buffer"))
  (let ((feed (hackernews-modern--get :feed))
        (reg  (hackernews-modern--get :register)))
    (unless (and feed reg)
      (user-error "Buffer in invalid state"))
    (if (>= (car reg) (length (cdr reg)))
        (message "%s" (substitute-command-keys "\
End of feed; type \\[hackernews-modern-reload] to load new items."))
      (hackernews-modern--load-stories feed n reg))))

(defun hackernews-modern-switch-feed (&optional n)
  "Read top N stories from a feed chosen with completion.
N defaults to `hackernews-modern-items-per-page'."
  (interactive "P")
  (hackernews-modern--load-stories
   (let ((completion-extra-properties
          (list :annotation-function #'hackernews-modern--feed-annotation)))
     (completing-read
      (format-prompt "Hacker News feed" hackernews-modern-default-feed)
      hackernews-modern-feed-names nil t nil 'hackernews-modern-feed-history
      hackernews-modern-default-feed))
   n))

(defun hackernews-modern-top-stories (&optional n)
  "Read top N Hacker News top stories.
N defaults to `hackernews-modern-items-per-page'."
  (interactive "P")
  (hackernews-modern--load-stories "top" n))

(defun hackernews-modern-new-stories (&optional n)
  "Read top N Hacker News new stories.
N defaults to `hackernews-modern-items-per-page'."
  (interactive "P")
  (hackernews-modern--load-stories "new" n))

(defun hackernews-modern-best-stories (&optional n)
  "Read top N Hacker News best stories.
N defaults to `hackernews-modern-items-per-page'."
  (interactive "P")
  (hackernews-modern--load-stories "best" n))

(defun hackernews-modern-ask-stories (&optional n)
  "Read top N Hacker News ask stories.
N defaults to `hackernews-modern-items-per-page'."
  (interactive "P")
  (hackernews-modern--load-stories "ask" n))

(defun hackernews-modern-show-stories (&optional n)
  "Read top N Hacker News show stories.
N defaults to `hackernews-modern-items-per-page'."
  (interactive "P")
  (hackernews-modern--load-stories "show" n))

(defun hackernews-modern-job-stories (&optional n)
  "Read top N Hacker News job stories.
N defaults to `hackernews-modern-items-per-page'."
  (interactive "P")
  (hackernews-modern--load-stories "job" n))

(defun hackernews-modern--open-comments (id)
  "Open the comments of item ID.
See `hackernews-modern-comments-in-browser'."
  (if hackernews-modern-comments-in-browser
      (hackernews-modern--browse-url (hackernews-modern--comments-url id))
    (hackernews-modern-comments id)))

(defun hackernews-modern-show-comments ()
  "Open the comments of the story at point."
  (declare (modes hackernews-modern-mode))
  (interactive)
  (hackernews-modern--open-comments
   (or (get-text-property (point) 'hackernews-modern-item-id)
       (user-error "No story at point"))))

(defun hackernews-modern-vote ()
  "Upvote the story at point, or remove the vote if already upvoted."
  (declare (modes hackernews-modern-mode))
  (interactive)
  (hackernews-modern--toggle-vote
   (or (get-text-property (point) 'hackernews-modern-item-id)
       (user-error "No story at point"))))

(provide 'hackernews-modern)

;;; hackernews-modern.el ends here
