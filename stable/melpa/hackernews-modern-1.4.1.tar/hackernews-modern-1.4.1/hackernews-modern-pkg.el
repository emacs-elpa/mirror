;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hackernews-modern" "1.4.1"
  "Hacker News client with modern widget UI."
  '((emacs              "28.1")
    (visual-fill-column "2.2")
    (async-http-queue   "0.1.0"))
  :url "https://git.andros.dev/andros/hackernews-modern-el"
  :commit "97b64f3ba1d3cce961c44b9fcc2c90ef2e7cb9ed"
  :revdesc "97b64f3ba1d3"
  :keywords '("comm" "hypermedia" "news")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
