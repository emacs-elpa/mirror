;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "har-viewer" "0.1.0"
  "Major mode for viewing HTTP Archive (HAR) files."
  '((emacs "26.1"))
  :url "https://github.com/gregnewman/har-viewer.el"
  :commit "250ad3e99d504f817eb8e24c049d41f51af1c6d5"
  :revdesc "250ad3e99d50"
  :keywords '("tools" "http" "network")
  :authors '(("Gregory Newman" . "bozoslivehere@protonmail.com"))
  :maintainers '(("Gregory Newman" . "bozoslivehere@protonmail.com")))
