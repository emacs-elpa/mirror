;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osa-chrome" "0.5"
  "Google Chrome remote tab control."
  '((emacs "25.1")
    (osa   "0"))
  :url "https://github.com/atomontage/osa-chrome"
  :commit "b91df54b7797b4b29fd17a9c8ee0ace96b6817bc"
  :revdesc "b91df54b7797"
  :keywords '("comm")
  :authors '(("xristos" . "xristos@sdf.org"))
  :maintainers '(("xristos" . "xristos@sdf.org")))
