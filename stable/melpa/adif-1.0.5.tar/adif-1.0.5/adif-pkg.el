;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adif" "1.0.5"
  "Major mode for viewing and editing ADIF log files."
  '((emacs "25.1"))
  :url "https://github.com/K6SM/adif-mode"
  :commit "da52c09d599f0943b6332246a13f79ca12b6137b"
  :revdesc "da52c09d599f"
  :keywords '("comm" "hamradio" "adif" "logging"))
