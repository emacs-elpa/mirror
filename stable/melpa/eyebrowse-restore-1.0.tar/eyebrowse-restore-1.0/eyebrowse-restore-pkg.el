;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eyebrowse-restore" "1.0"
  "Persistent Eyebrowse for all frames."
  '((emacs "26.3"))
  :url "https://github.com/FrostyX/eyebrowse-restore"
  :commit "4416418a5d3d9787b2333a6a5dbe2abdc468b9ae"
  :revdesc "4416418a5d3d"
  :keywords '("eyebrowse" "helm" "persistent")
  :authors '(("Jakub Kadlčík" . "frostyx@email.cz"))
  :maintainers '(("Jakub Kadlčík" . "frostyx@email.cz")))
