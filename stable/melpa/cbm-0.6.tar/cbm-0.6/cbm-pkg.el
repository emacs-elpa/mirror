;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cbm" "0.6"
  "Switch to similar buffers."
  '((cl-lib "0.5"))
  :url "https://github.com/akermu/cbm.el"
  :commit "5b41c936ba9f6d170309a85ffebc9939c1050b31"
  :revdesc "5b41c936ba9f"
  :keywords '("buffers")
  :authors '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainers '(("Lukas Fürmetz" . "fuermetz@mailbox.org")))
