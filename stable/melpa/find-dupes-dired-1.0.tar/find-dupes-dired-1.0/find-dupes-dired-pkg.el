;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "find-dupes-dired" "1.0"
  "Find dupes and handle in dired."
  '((emacs "26.1"))
  :url "https://github.com/ShuguangSun/find-dupes-dired"
  :commit "f39e2afbc33e02a6bf62116f6ce71b8368068698"
  :revdesc "f39e2afbc33e"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
