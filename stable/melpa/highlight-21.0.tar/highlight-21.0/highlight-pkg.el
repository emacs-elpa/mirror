;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight" "21.0"
  "Highlighting commands."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/highlight.el"
  :commit "b8d3ae1935d4b190ad35c8d2f5a44ff8d706bbf0"
  :revdesc "b8d3ae1935d4"
  :keywords '("faces" "help" "local"))
