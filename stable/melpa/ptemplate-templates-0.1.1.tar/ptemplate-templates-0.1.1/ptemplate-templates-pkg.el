;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ptemplate-templates" "0.1.1"
  "Official templates."
  '((emacs     "25.1")
    (ptemplate "2.0.0"))
  :url "https://github.com/nbfalcon/ptemplate-templates"
  :commit "84474713f4772ef0962bb9eb01c00be85fbb258b"
  :revdesc "84474713f477"
  :authors '(("Nikita Bloshchanevich" . "nikblos@outlook.com"))
  :maintainers '(("Nikita Bloshchanevich" . "nikblos@outlook.com")))
