;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chinese-conv" "0.1.0"
  "Conversion between Chinese Characters."
  '((cl-lib "0.5"))
  :url "https://github.com/gucong/emacs-chinese-conv"
  :commit "6f0cfa86b03ad74534427eaa916192627028ca83"
  :revdesc "6f0cfa86b03a"
  :authors '(("gucong" . "gucong43216@gmail.com"))
  :maintainers '(("gucong" . "gucong43216@gmail.com")))
