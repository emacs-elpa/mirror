;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solaire-mode" "2.2.0"
  "Make certain buffers grossly incandescent."
  '((emacs  "27.1")
    (cl-lib "0.5"))
  :url "https://github.com/hlissner/emacs-solaire-mode"
  :commit "dddcbdc90156a7ca52604a4b6f9d1c0add378b2d"
  :revdesc "v2.2.0-0-gdddcbdc90156"
  :keywords '("dim" "bright" "window" "buffer" "faces")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
