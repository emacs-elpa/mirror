;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sr-speedbar" "20140914.2339"
  "Same frame speedbar."
  ()
  :url "http://www.emacswiki.org/emacs/download/sr-speedbar.el"
  :commit "4f816528a32eb421197a768d6dcf3a05de83f642"
  :revdesc "4f816528a32e"
  :keywords '("speedbar" "sr-speedbar.el")
  :authors '(("Sebastian Rose" . "sebastian_rose@gmx.de"))
  :maintainers '(("Sebastian Rose" . "sebastian_rose@gmx.de")
                 ("Peter Lunicks" . "plunix@users.sourceforge.net")))
