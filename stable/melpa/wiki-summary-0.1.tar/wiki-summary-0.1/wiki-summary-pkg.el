;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wiki-summary" "0.1"
  "View Wikipedia summaries in Emacs easily."
  '((emacs "24"))
  :url "https://github.com/jozefg/wiki-summary.el"
  :commit "2e4a344ff3d585d0b506baad22a815d812abbd82"
  :revdesc "2e4a344ff3d5"
  :keywords '("wikipedia" "utility"))
