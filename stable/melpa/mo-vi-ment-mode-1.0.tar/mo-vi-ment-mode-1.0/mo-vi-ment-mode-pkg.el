;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mo-vi-ment-mode" "1.0"
  "Provide vi-like cursor movement that's easy on the fingers."
  ()
  :url "https://github.com/AjayMT/mo-vi-ment"
  :commit "e8b525ffc5faa31d36ecc5496b40f0f5c3603c08"
  :revdesc "e8b525ffc5fa"
  :keywords '("convenience")
  :authors '(("Ajay MT" . "ajay.tatachar@gmail.com"))
  :maintainers '(("Ajay MT" . "ajay.tatachar@gmail.com")))
