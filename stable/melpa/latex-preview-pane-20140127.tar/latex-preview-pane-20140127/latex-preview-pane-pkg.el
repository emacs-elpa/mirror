;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-preview-pane" "20140127"
  "Makes LaTeX editing less painful by providing a updatable preview pane."
  ()
  :url "https://github.com/jsinglet/latex-preview-pane"
  :commit "b55272bf9067c46fc2341678f96f0a2516ae31fa"
  :revdesc "b55272bf9067"
  :keywords '("latex" "preview")
  :authors '(("John L. Singleton" . "jsinglet@gmail.com"))
  :maintainers '(("John L. Singleton" . "jsinglet@gmail.com")))
