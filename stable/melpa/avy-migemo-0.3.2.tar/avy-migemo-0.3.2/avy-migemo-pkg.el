;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-migemo" "0.3.2"
  "Avy with migemo."
  '((emacs  "24.4")
    (avy    "0.4.0")
    (migemo "1.9"))
  :url "https://github.com/momomo5717/avy-migemo"
  :commit "ce87777bea76c45be5f185e9fe356a8efe5c2d16"
  :revdesc "0.3.2-0-gce87777bea76"
  :keywords '("avy" "migemo"))
