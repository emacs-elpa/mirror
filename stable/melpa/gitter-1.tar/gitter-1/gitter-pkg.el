;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitter" "1"
  "An Emacs Gitter client."
  '((emacs     "24.1")
    (let-alist "1.0.4"))
  :url "https://github.com/xuchunyang/gitter.el"
  :commit "bd2ba457109dd5d3e4b419e3ef5cbd3b5c9498d6"
  :revdesc "bd2ba457109d"
  :keywords '("gitter" "chat" "client" "internet")
  :authors '(("Chunyang Xu" . "xuchunyang.me@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang.me@gmail.com")))
