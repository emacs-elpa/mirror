;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whitespace-cleanup-mode" "0.10"
  "Intelligently call whitespace-cleanup on save."
  ()
  :url "https://github.com/purcell/whitespace-cleanup-mode"
  :commit "e1e250aa6f5b1a526778c7a501cdec98ba29c0a4"
  :revdesc "e1e250aa6f5b"
  :keywords '("convenience")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
