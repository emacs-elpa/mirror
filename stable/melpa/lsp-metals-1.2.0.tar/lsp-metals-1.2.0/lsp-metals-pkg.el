;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-metals" "1.2.0"
  "Scala Client settings."
  '((emacs        "26.1")
    (scala-mode   "1.1")
    (lsp-mode     "7.0")
    (lsp-treemacs "0.2")
    (dap-mode     "0.3")
    (dash         "2.18.0")
    (f            "0.20.0")
    (ht           "2.0")
    (treemacs     "2.5"))
  :url "https://github.com/emacs-lsp/lsp-metals"
  :commit "5aea52dfe08b8f5936ea3982be6c25339f652eba"
  :revdesc "5aea52dfe08b"
  :keywords '("languages" "extensions")
  :authors '(("Ross A. Baker" . "ross@rossabaker.com")
             ("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers '(("Ross A. Baker" . "ross@rossabaker.com")
                 ("Evgeny Kurnevsky" . "kurnevsky@gmail.com")))
