;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "all-the-icons-ivy-rich" "1.9.0"
  "Better experience with icons for ivy."
  '((emacs         "25.1")
    (ivy-rich      "0.1.0")
    (all-the-icons "2.2.0"))
  :url "https://github.com/seagle0128/all-the-icons-ivy-rich"
  :commit "1bae2c95e5bf865af55d219d50baf4ee9ce5e7c6"
  :revdesc "1bae2c95e5bf"
  :keywords '("convenience" "icons" "ivy")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
