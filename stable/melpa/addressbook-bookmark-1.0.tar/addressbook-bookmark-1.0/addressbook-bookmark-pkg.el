;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "addressbook-bookmark" "1.0"
  "An address book based on Standard Emacs bookmarks."
  '((emacs "24"))
  :url "https://github.com/thierryvolpiatto/addressbook-bookmark"
  :commit "ad3c73369b804a48803fdfdf2ab613e6220260de"
  :revdesc "v1.0-0-gad3c73369b80"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")))
