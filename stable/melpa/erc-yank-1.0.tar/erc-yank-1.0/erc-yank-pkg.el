;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-yank" "1.0"
  "[No description available]."
  ()
  :url "https://github.com/jwiegley/erc-yank"
  :commit "0ac61b6c4f5e1e75d326eb3affb1c1b0d6ca9c95"
  :revdesc "0ac61b6c4f5e"
  :keywords '("erc" "yank" "gist")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("John Wiegley" . "jwiegley@gmail.com")))
