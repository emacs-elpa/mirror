;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-buffer-local" "0.0.3"
  "Install color-themes by buffer."
  '((color-theme "0"))
  :url "https://github.com/vic/color-theme-buffer-local"
  :commit "ca8470bc34c65a026a6bca1707d95240bfd019af"
  :revdesc "ca8470bc34c6"
  :keywords '("faces")
  :authors '(("Victor Borja" . "vic.borja@gmail.com"))
  :maintainers '(("Victor Borja" . "vic.borja@gmail.com")))
