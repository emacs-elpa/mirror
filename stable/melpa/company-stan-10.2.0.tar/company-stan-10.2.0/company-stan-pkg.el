;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-stan" "10.2.0"
  "A company-mode completion backend for stan."
  '((emacs     "24.3")
    (company   "0.9.10")
    (stan-mode "10.1.0"))
  :url "https://github.com/stan-dev/stan-mode/tree/master/company-stan"
  :commit "2dd330604563d143031fc8ffd516266217aa1f9b"
  :revdesc "2dd330604563"
  :keywords '("languages")
  :authors '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu"))
  :maintainers '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu")))
