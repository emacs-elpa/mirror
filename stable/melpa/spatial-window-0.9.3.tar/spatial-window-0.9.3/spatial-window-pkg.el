;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spatial-window" "0.9.3"
  "Jump to windows using keyboard spatial mapping."
  '((emacs    "28.1")
    (posframe "1.0.0"))
  :url "https://github.com/lewang/spatial-window"
  :commit "5388bb6c1989578222b4d5b576482b538977bea4"
  :revdesc "5388bb6c1989"
  :keywords '("convenience" "windows")
  :authors '(("Le Wang" . "lewang.dev.26@gmail.com"))
  :maintainers '(("Le Wang" . "lewang.dev.26@gmail.com")))
