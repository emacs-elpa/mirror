;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "extend-dnd" "0.5"
  "R drag and Drop."
  ()
  :url "https://github.com/mlf176f2/extend-dnd"
  :commit "a1923d57f8f5e862cc66c189b5e6627bc84a2119"
  :revdesc "v0.5-0-ga1923d57f8f5"
  :keywords '("extend" "drag and drop"))
