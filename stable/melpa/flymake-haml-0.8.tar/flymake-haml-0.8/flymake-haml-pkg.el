;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-haml" "0.8"
  "A flymake handler for haml files."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-haml"
  :commit "343449920866238db343d61343bc845cc8bc5e1b"
  :revdesc "343449920866"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
