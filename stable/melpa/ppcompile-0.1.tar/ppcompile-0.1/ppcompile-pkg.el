;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ppcompile" "0.1"
  "Ping-pong compile projects on remote machines."
  ()
  :url "homepage"
  :commit "eab5e89659e7b95bf7e3cfc8033fa98942a6c780"
  :revdesc "eab5e89659e7"
  :keywords '("tools"))
