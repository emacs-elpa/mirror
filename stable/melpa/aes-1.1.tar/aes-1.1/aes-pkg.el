;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aes" "1.1"
  "Implementation of AES."
  '((emacs "26.1"))
  :url "https://github.com/Sauermann/emacs-aes"
  :commit "26281e03c948bdb9cc8f5feb22a7c077c28a0cdd"
  :revdesc "26281e03c948"
  :keywords '("data" "tools"))
