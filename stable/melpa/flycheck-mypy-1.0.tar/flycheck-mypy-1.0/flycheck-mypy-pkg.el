;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-mypy" "1.0"
  "Support mypy in flycheck."
  '((flycheck "0.18"))
  :url "https://github.com/lbolla/emacs-flycheck-mypy"
  :commit "caa16f2ed3a86db34dcb2728057f31d7faffb71b"
  :revdesc "caa16f2ed3a8"
  :authors '(("Lorenzo Bolla" . "lbolla@gmail.com"))
  :maintainers '(("Lorenzo Bolla" . "lbolla@gmail.com")))
