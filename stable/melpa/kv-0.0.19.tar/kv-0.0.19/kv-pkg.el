;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kv" "0.0.19"
  "Key/value data structure functions."
  ()
  :url "https://github.com/nicferrier/emacs-kv"
  :commit "4623e83e6e7764ae0654bfe143c059b66c2fad5a"
  :revdesc "4623e83e6e77"
  :keywords '("lisp")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
