;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forest-blue-theme" "0.1"
  "Emacs theme with a dark background."
  '((emacs "24"))
  :url "https://github.com/olkinn/forest-blue-emacs"
  :commit "eca4d5ae9e896338fd348478a1358511a230df6a"
  :revdesc "eca4d5ae9e89")
