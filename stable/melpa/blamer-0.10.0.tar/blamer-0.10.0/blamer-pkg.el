;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blamer" "0.10.0"
  "Show git blame info about current line."
  '((emacs    "27.1")
    (posframe "1.1.7")
    (async    "1.9.8"))
  :url "https://github.com/artawower/blamer.el"
  :commit "d06e1b8907f0bb5d603c76323dbcd8b00a014062"
  :revdesc "d06e1b8907f0"
  :authors '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers '(("Artur Yaroshenko" . "artawower@protonmail.com")))
