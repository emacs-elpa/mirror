;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bug-reference-github" "1.0.0"
  "Set `bug-reference-url-format' in Github repos."
  ()
  :url "https://github.com/arnested/bug-reference-github"
  :commit "f570a0532bfb44f095b42cf68ab1f69799101137"
  :revdesc "v1.0.0-0-gf570a0532bfb"
  :keywords '("programming" "tools")
  :authors '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainers '(("Arne Jørgensen" . "arne@arnested.dk")))
