;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dtb-mode" "20210102.2003"
  "Show device tree souce in dtbs."
  '((emacs "25"))
  :url "https://github.com/schspa/dtb-mode"
  :commit "c6f65123a1647924dc69b8e19188860fbcbeda87"
  :revdesc "c6f65123a164"
  :keywords '("dtb" "dts" "convenience")
  :authors '(("Schspa Shi" . "schspa@gmail.com"))
  :maintainers '(("Schspa Shi" . "schspa@gmail.com")))
