;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-web" "4.0.0"
  "Web interface to Elfeed."
  '((emacs        "28.1")
    (compat       "31")
    (elfeed       "3.4.2")
    (simple-httpd "1.6"))
  :url "https://github.com/emacs-elfeed/elfeed-web"
  :commit "e947501a29457a55dfb0828aa791185c6b41bc37"
  :revdesc "4.0.0-0-ge947501a2945"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
