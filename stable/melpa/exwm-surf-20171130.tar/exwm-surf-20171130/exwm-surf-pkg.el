;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-surf" "20171130"
  "Interface for Surf under exwm."
  '((emacs "24.4"))
  :url "https://github.com/ecraven/exwm-surf"
  :commit "af96fafc7a815e27b0530c8efd82281ba3ff6b14"
  :revdesc "af96fafc7a81"
  :keywords '("extensions")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Peter" . "craven@gmx.net")))
