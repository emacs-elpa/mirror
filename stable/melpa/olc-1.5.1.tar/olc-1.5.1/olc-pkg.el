;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "olc" "1.5.1"
  "Open location code library."
  '((emacs "25.1"))
  :url "https://gitlab.liu.se/davby02/olc"
  :commit "d2dc62dbc3cf6460cc12bd96857a988bc80ac37e"
  :revdesc "d2dc62dbc3cf"
  :keywords '("extensions" "lisp")
  :authors '(("David Byers" . "david.byers@liu.se"))
  :maintainers '(("David Byers" . "david.byers@liu.se")))
