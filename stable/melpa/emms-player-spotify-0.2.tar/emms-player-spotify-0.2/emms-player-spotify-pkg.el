;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms-player-spotify" "0.2"
  "Spotify player for EMMS."
  '((emacs  "26.1")
    (compat "29.1")
    (emms   "18")
    (s      "1.13.0"))
  :url "https://github.com/sarg/emms-spotify"
  :commit "d9e3e2d639b0cd1333cc180f562d9e228b7ac565"
  :revdesc "d9e3e2d639b0"
  :authors '(("Sergey Trofimov" . "sarg@sarg.org.ru"))
  :maintainers '(("Sergey Trofimov" . "sarg@sarg.org.ru")))
