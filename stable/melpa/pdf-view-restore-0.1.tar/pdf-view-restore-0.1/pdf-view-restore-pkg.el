;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdf-view-restore" "0.1"
  "Support for reopening pdf to last position opened."
  '((pdf-tools   "0.80")
    (org-pdfview "0.10"))
  :url "https://github.com/007kevin/pdf-view-restore"
  :commit "e9c6d814662dba3544979012f98f747b0c7023c8"
  :revdesc "e9c6d814662d"
  :keywords '("pdf-view" "pdf-tools")
  :authors '(("Kevin Kim" . "kevinkim1991@gmail.com"))
  :maintainers '(("Kevin Kim" . "kevinkim1991@gmail.com")))
