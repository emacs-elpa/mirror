;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "config-general-mode" "0.3"
  "Config::General config file mode."
  ()
  :url "https://github.com/tlinden/config-general-mode"
  :commit "b4a8e6ba0bb027a77e4a0f701409f3e57bb2e4c0"
  :revdesc "b4a8e6ba0bb0"
  :keywords '("files")
  :authors '(("T.v.Dein" . "tlinden@cpan.org"))
  :maintainers '(("T.v.Dein" . "tlinden@cpan.org")))
