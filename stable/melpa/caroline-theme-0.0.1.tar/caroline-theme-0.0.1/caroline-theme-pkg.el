;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "caroline-theme" "0.0.1"
  "[No description available]."
  ()
  :url "https://github.com/xjackk/carolines-theme"
  :commit "e56abc048d78cb75aa706e5da1c05b047d75c9b6"
  :revdesc "e56abc048d78"
  :authors '(("Jack Killilea" . "jaaacckz1@gmail.com"))
  :maintainers '(("Jack Killilea" . "jaaacckz1@gmail.com")))
