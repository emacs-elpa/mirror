;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-auctex" "0.1"
  "Company-mode auto-completion for AUCTeX."
  '((yasnippet    "0.6.1")
    (company-mode "0.8.0"))
  :url "https://github.com/alexeyr/company-auctex"
  :commit "eb44c9038dee8b511cd8bc22e3d5086ab2c2b6a0"
  :revdesc "eb44c9038dee"
  :authors '(("Christopher Monsanto" . "chris@monsan.to")
             ("Alexey Romanov" . "alexey.v.romanov@gmail.com"))
  :maintainers '(("Christopher Monsanto" . "chris@monsan.to")
                 ("Alexey Romanov" . "alexey.v.romanov@gmail.com")))
