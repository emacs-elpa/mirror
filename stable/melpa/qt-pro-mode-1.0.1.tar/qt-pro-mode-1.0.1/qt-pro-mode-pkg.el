;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qt-pro-mode" "1.0.1"
  "Qt Pro/Pri major mode."
  '((emacs "24"))
  :url "https://github.com/emacsorphanage/qt-pro-mode"
  :commit "f4accdeba5d49b79f85f0f24f74ac25e8326d487"
  :revdesc "f4accdeba5d4"
  :keywords '("extensions")
  :authors '(("Todd Neal" . "tolchz@gmail.com"))
  :maintainers '(("Todd Neal" . "tolchz@gmail.com")))
