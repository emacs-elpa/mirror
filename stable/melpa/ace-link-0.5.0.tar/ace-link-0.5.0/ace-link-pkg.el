;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-link" "0.5.0"
  "Quickly follow links."
  '((avy "0.4.0"))
  :url "https://github.com/abo-abo/ace-link"
  :commit "7b9bc8d916b60a501c32b63ce81f315486ad44e9"
  :revdesc "7b9bc8d916b6"
  :keywords '("convenience" "links" "avy")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
