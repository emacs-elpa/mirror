;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ctftime" "1.0.0"
  "CTFtime dashboard."
  '((emacs "27.1"))
  :url "https://github.com/giovanni-iannaccone/ctftime.el"
  :commit "c00bd83e3ce2ff45540eec541439a0558991246c"
  :revdesc "c00bd83e3ce2"
  :keywords '("ctf" "tools" "games")
  :authors '(("Giovanni Francesco Iannaccone" . "iannacconegiovanni444@gmail.com"))
  :maintainers '(("Giovanni Francesco Iannaccone" . "iannacconegiovanni444@gmail.com")))
