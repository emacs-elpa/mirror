;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-dvorak" "0.2"
  "[No description available]."
  '((evil          "1.0.8")
    (ace-jump-mode "2.0")
    (anzu          "0")
    (helm          "0")
    (evil-surround "0")
    (wind-move     "0"))
  :url "https://github.com/jbranso/evil-dvorak"
  :commit "a5eb5057da031b03155f39f13b9ba459425df5cd"
  :revdesc "a5eb5057da03"
  :keywords '("dvorak" "evil" "vim"))
