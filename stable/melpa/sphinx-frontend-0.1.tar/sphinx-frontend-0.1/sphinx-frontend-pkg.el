;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sphinx-frontend" "0.1"
  "[No description available]."
  ()
  :url "https://github.com/kostafey/sphinx-frontend"
  :commit "8ef17efe6e926cc62dedb0b8ba56f3da515a1db9"
  :revdesc "8ef17efe6e92"
  :keywords '("compile" "sphinx" "restructuredtext")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
