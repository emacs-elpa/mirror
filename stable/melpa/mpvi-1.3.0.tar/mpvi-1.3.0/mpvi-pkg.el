;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "1.3.0"
  "Watch video and take interactive video notes."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "1e661147ecf8f4433f45e003c600d6cc04a72776"
  :revdesc "1e661147ecf8"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
