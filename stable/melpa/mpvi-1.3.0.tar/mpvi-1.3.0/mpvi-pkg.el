;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "1.3.0"
  "Watch video and take interactive video notes."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "f423ffb7116ff4ab2c1f0207cb38f4ec2bc9660a"
  :revdesc "f423ffb7116f"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
