;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "niconama" "2.1"
  "Tools for Niconico Live Broadcast."
  '((emacs   "24")
    (request "20170131.1747")
    (cl-lib  "0.5"))
  :url "https://github.com/NOBUTOKA/niconama.el"
  :commit "96e7553e50e6bf7b58aac50f52c9b0b8edb41c56"
  :revdesc "96e7553e50e6"
  :keywords '("comm"))
