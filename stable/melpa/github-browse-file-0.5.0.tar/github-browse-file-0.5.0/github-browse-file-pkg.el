;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-browse-file" "0.5.0"
  "View the file you're editing on GitHub."
  '((cl-lib "0.5"))
  :url "https://github.com/osener/github-browse-file"
  :commit "fa5cc00a40869430fb44596792961a4cddf9c265"
  :revdesc "fa5cc00a4086"
  :keywords '("convenience" "vc" "git" "github")
  :authors '(("Ozan Sener" . "ozan@ozansener.com"))
  :maintainers '(("Ozan Sener" . "ozan@ozansener.com")))
