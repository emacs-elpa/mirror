;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blox" "0.3.0"
  "Interaction with Roblox tooling."
  '((emacs "25.1"))
  :url "https://github.com/kennethloeffler/blox"
  :commit "f27e79d6da65d8877ebb4e84a40350b61c3f0362"
  :revdesc "f27e79d6da65"
  :keywords '("roblox" "rojo" "tools")
  :authors '(("Kenneth Loeffler" . "kenneth.loeffler@outlook.com"))
  :maintainers '(("Kenneth Loeffler" . "kenneth.loeffler@outlook.com")))
