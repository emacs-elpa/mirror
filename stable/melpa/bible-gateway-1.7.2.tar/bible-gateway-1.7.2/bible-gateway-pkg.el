;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "1.7.2"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "908e5ad0baed859c5e228f9bf5b29fcd52809a8b"
  :revdesc "908e5ad0baed"
  :keywords '("convenience" "comm" "hypermedia"))
