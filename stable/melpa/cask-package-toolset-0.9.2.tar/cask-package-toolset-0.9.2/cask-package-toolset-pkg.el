;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cask-package-toolset" "0.9.2"
  "Toolsettize your package."
  '((emacs     "24")
    (cl-lib    "0.3")
    (s         "1.6.1")
    (dash      "1.8.0")
    (f         "0.10.0")
    (commander "0.2.0")
    (ansi      "0.1.0")
    (shut-up   "0.1.0"))
  :url "https://github.com/AdrieanKhisbe/cask-package-toolset.el"
  :commit "2c74cd827e88c7f8360581a841e45f0b794510e7"
  :revdesc "2c74cd827e88"
  :keywords '("convenience" "tools")
  :authors '(("Adrien Becchis" . "adriean.khisbe@live.fr"))
  :maintainers '(("Adrien Becchis" . "adriean.khisbe@live.fr")))
