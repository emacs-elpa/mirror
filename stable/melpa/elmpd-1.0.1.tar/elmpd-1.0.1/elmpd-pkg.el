;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elmpd" "1.0.1"
  "A tight, ergonomic, async client library for mpd."
  '((emacs "25.1"))
  :url "https://github.com/sp1ff/elmpd"
  :commit "89d8b514ed940d7a9452a804158fe6604ec6016f"
  :revdesc "1.0.1-0-g89d8b514ed94"
  :keywords '("comm")
  :authors '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainers '(("Michael Herstine" . "sp1ff@pobox.com")))
