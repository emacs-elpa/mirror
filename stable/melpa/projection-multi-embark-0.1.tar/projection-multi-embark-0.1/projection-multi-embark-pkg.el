;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projection-multi-embark" "0.1"
  "`projection-multi' integration for `embark'."
  '((emacs                "29")
    (projection           "0.1")
    (compile-multi-embark "0.5"))
  :url "https://github.com/mohkale/projection"
  :commit "d043418c707d5637d869c488e8abe2186e55b5fe"
  :revdesc "d043418c707d"
  :keywords '("project" "convenience")
  :authors '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@kisara.moe")))
