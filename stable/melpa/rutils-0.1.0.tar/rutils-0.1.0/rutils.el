;;; rutils.el --- R utilities with transient       -*- lexical-binding: t; -*-

;; Copyright (C) 2021-2024  Shuguang Sun

;; Author: Shuguang Sun <shuguang79@qq.com>
;; Created: 2021/06/25
;; Package-Version: 0.1.0
;; Package-Revision: c910dd21f542
;; URL: https://github.com/ShuguangSun/rutils.el
;; Package-Requires: ((emacs "27.1") (ess "19") (transient "0.4"))
;; Keywords: convenience

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; R utilities with transient.

;;; Code:


(require 'rutils-lib)

(require 'rutils-renv)
(require 'rutils-devtools)
(require 'rutils-rmd)


;;; * Keymap

(defcustom rutils-mode-command-prefix "C-c R"
  "Key prefix under which the rutils menus are bound in `rutils-mode'.
Change it (and then re-enable `rutils-mode') to re-bind the prefix;
set it to nil to not bind any prefix."
  :group 'rutils
  :type '(choice (const :tag "Do not bind a prefix" nil)
                 (key-sequence :tag "Key prefix")))

(defvar rutils-mode-command-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "r") #'rutils-renv)
    (define-key map (kbd "d") #'rutils-devtools)
    (define-key map (kbd "m") #'rutils-rmd)
    map)
  "Sub-keymap of `rutils-mode-map' holding the module menus.")

(defvar rutils-mode-map
  (let ((map (make-sparse-keymap)))
    (when rutils-mode-command-prefix
      (define-key map (kbd rutils-mode-command-prefix) rutils-mode-command-map))
    map)
  "Keymap for `rutils-mode'.")

;;;###autoload
(define-minor-mode rutils-mode
  "Global minor mode to bind the rutils menus under `C-c R'.

The module menus `rutils-renv', `rutils-devtools' and `rutils-rmd'
are bound under the prefix defined by `rutils-mode-command-prefix'
\(default `C-c R').  Re-enable the mode after changing that option."
  :global t
  :group 'rutils
  (when (boundp 'rutils-mode-map)
    (setq rutils-mode-map
          (if rutils-mode
              (let ((map (make-sparse-keymap)))
                (when rutils-mode-command-prefix
                  (define-key map (kbd rutils-mode-command-prefix)
                    rutils-mode-command-map))
                map)
            (make-sparse-keymap)))))

;;;###autoload
(define-globalized-minor-mode rutils-global-mode
  rutils-mode
  (lambda () (rutils-mode 1))
  :group 'rutils)

(provide 'rutils)
;;; rutils.el ends here
