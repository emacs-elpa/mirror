;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rutils" "0.1.0"
  "R utilities with transient."
  '((emacs     "27.1")
    (ess       "19")
    (transient "0.4"))
  :url "https://github.com/ShuguangSun/rutils.el"
  :commit "c910dd21f5427896860ddc4d914d2fab3c5c0a23"
  :revdesc "c910dd21f542"
  :keywords '("convenience")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
