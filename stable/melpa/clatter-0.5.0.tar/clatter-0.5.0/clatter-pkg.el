;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.5.0"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "16db9958b3b608a77bec03c583472c520b1fb269"
  :revdesc "v0.5.0-0-g16db9958b3b6"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
