;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zettelkasten" "0.5.0"
  "Helper functions to organise notes in a Zettelkasten style."
  '((emacs "25.1")
    (s     "1.10.0"))
  :url "https://github.com/ymherklotz/emacs-zettelkasten"
  :commit "f470db20ad0a7e591daa73c903524ac267ae7236"
  :revdesc "f470db20ad0a"
  :keywords '("files" "hypermedia" "notes")
  :authors '(("Yann Herklotz" . "yann@ymhg.org"))
  :maintainers '(("Yann Herklotz" . "yann@ymhg.org")))
