;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "double-press" "3.0.1"
  "Double-press key dispatcher."
  '((emacs "24.4"))
  :url "https://github.com/k-talo/double-press.el"
  :commit "35fc8b41f015992c2b4ccf6bac0b820258b774f0"
  :revdesc "v3.0.1-0-g35fc8b41f015"
  :keywords '("abbrev" "convenience" "emulations" "wp")
  :authors '(("K-talo Miyazaki" . "KeitarodotMiyazakiatgmaildotcom"))
  :maintainers '(("K-talo Miyazaki" . "KeitarodotMiyazakiatgmaildotcom")))
