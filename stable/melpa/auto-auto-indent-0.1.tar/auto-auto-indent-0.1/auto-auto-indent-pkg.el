;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-auto-indent" "0.1"
  "Indents code as you type."
  '((es-lib "0.1"))
  :url "https://github.com/sabof/auto-auto-indent"
  :commit "4d6820216cd96b0c43424983cf614914c01edd16"
  :revdesc "4d6820216cd9")
