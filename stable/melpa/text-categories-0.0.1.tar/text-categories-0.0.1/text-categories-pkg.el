;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "text-categories" "0.0.1"
  "Assign text categories to a buffer for mass deletion."
  '((emacs "24.3"))
  :url "https://github.com/Dspil/text-categories"
  :commit "f4f5e581c2398e648009dc6929480cfa90532e39"
  :revdesc "f4f5e581c239"
  :keywords '("lisp")
  :authors '(("Dionisios Spiliopoulos" . "dennisspiliopoylos@gmail.com"))
  :maintainers '(("Dionisios Spiliopoulos" . "dennisspiliopoylos@gmail.com")))
