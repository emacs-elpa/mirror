;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpl" "0.1.6"
  "Emacs Lisp REPL."
  '((emacs "24.4"))
  :url "https://github.com/twlz0ne/elpl"
  :commit "501871ab543b9967bfe87a8a82f83ab96b7f909e"
  :revdesc "501871ab543b"
  :keywords '("lisp" "tool")
  :authors '(("Gong Qijian" . "gongqijian@gmail.com"))
  :maintainers '(("Gong Qijian" . "gongqijian@gmail.com")))
