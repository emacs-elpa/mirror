;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-show-header" "1.0.0"
  "Show the header of the current column in the minibuffer."
  ()
  :url "https://github.com/DamienCassou/orgtbl-show-header"
  :commit "f0f48ccc0f96d4aa2a676ff609d9dddd71748e6f"
  :revdesc "f0f48ccc0f96"
  :authors '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainers '(("Damien Cassou" . "damien.cassou@gmail.com")))
