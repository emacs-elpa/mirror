;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "etherpad" "0.1"
  "Etherpad API."
  '((emacs     "26.1")
    (request   "0.3")
    (let-alist "0.0"))
  :url "https://github.com/zzkt/etherpad-emacs"
  :commit "b6037e466af67754d740d5c74599d1ca208338cf"
  :revdesc "b6037e466af6"
  :keywords '("etherpad" "collaborative editing")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
