;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vagrant-tramp" "0.5.0"
  "Vagrant method for TRAMP."
  ()
  :url "https://github.com/dougm/vagrant-tramp"
  :commit "a1da534abfa66e7e88c83a849366931ab6941400"
  :revdesc "a1da534abfa6"
  :keywords '("vagrant")
  :authors '(("Doug MacEachern" . "dougm@vmware.com"))
  :maintainers '(("Doug MacEachern" . "dougm@vmware.com")))
