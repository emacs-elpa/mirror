;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-select-account" "0.10"
  "Select an account before writing a mail in gnus."
  ()
  :url "https://github.com/tumashu/gnus-select-account"
  :commit "4bf5c0056c54ba345e39ee9c9841cfb32f7a3a3b"
  :revdesc "4bf5c0056c54"
  :keywords '("convenience")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
