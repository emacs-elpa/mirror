;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-deno" "0.1.0"
  "Flycheck for deno-lint."
  '((emacs    "26.1")
    (flycheck "0.14"))
  :url "https://github.com/jcs-elpa/flycheck-deno"
  :commit "ea7a5330535bdb25edb1c147f4d6d426abb1e097"
  :revdesc "ea7a5330535b"
  :keywords '("lisp" "deno")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
