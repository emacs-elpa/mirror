;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "0.15.0"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "1849c6c774332c6451288debd4c353449ee79a92"
  :revdesc "1849c6c77433"
  :keywords '("extensions"))
