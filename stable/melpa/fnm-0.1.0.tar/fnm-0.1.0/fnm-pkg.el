;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fnm" "0.1.0"
  "Manage Node versions within Emacs."
  '((s    "1.8.0")
    (dash "2.18.0")
    (f    "0.14.0"))
  :url "https://github.com/nhojb/fnm.el"
  :commit "7e87a0fef5fd2067715daa485bf4e8c53a8bd4b2"
  :revdesc "7e87a0fef5fd"
  :keywords '("node" "nvm")
  :authors '(("John Buckley" . "nhoj.buckley@gmail.com"))
  :maintainers '(("Johan Andersson" . "nhoj.buckley@gmail.com")))
