;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enotify" "0.1.3"
  "[No description available]."
  ()
  :url "https://github.com/laynor/enotify"
  :commit "75c84b53703e5d52cb18acc9251b87ffa400f388"
  :revdesc "75c84b53703e")
