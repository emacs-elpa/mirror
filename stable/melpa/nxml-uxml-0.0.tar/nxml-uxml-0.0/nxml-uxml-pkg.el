;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nxml-uxml" "0.0"
  "MicroXML support for nXML."
  '((emacs "25"))
  :url "https://gitlab.com/dpk/nxml-uxml"
  :commit "14c4730f10d9c3fe1fc796a25d332740dcebe1f0"
  :revdesc "14c4730f10d9"
  :keywords '("languages" "xml" "microxml"))
