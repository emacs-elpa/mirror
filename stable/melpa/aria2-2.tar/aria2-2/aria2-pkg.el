;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aria2" "2"
  "Control aria2c commandline tool from Emacs."
  '((emacs "24.4"))
  :url "https://bitbucket.org/ukaszg/aria2-mode"
  :commit "5aa26f9db4abb365d7c4e21d10c9f83d6f12f6c0"
  :revdesc "5aa26f9db4ab"
  :keywords '("download" "bittorrent" "aria2")
  :authors '(("ukasz Gruner" . "lukasz@gruner.lu"))
  :maintainers '(("ukasz Gruner" . "lukasz@gruner.lu")))
