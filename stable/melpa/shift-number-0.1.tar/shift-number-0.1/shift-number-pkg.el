;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shift-number" "0.1"
  "Increase/decrease the number at point."
  ()
  :url "https://github.com/alezost/shift-number.el"
  :commit "ba3c1f2e6b01bf14aa1433c2a49098af1c025f7c"
  :revdesc "ba3c1f2e6b01"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
