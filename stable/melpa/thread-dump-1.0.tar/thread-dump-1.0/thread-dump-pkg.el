;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thread-dump" "1.0"
  "Java thread dump viewer."
  ()
  :url "https://github.com/nd/thread-dump.el"
  :commit "dfc59de03e76e6934f6e9d6849b58209cf1d9816"
  :revdesc "dfc59de03e76")
