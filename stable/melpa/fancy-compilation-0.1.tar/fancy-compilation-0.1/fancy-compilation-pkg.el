;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-compilation" "0.1"
  "Enhanced compilation output."
  '((emacs "26.1"))
  :url "https://codeberg.org/ideasman42/emacs-fancy-compilation"
  :commit "913fa36583e89032ca258a75df18b45b530cc9d9"
  :revdesc "913fa36583e8"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
