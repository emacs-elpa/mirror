;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spaceline" "2.0.1"
  "Modeline configuration library for powerline."
  '((emacs     "24.3")
    (cl-lib    "0.5")
    (powerline "2.3")
    (dash      "2.11.0")
    (s         "1.10.0"))
  :url "https://github.com/TheBB/spaceline"
  :commit "2d1a7bfb5bdaf24958f50b4bf93182847916af85"
  :revdesc "2d1a7bfb5bda"
  :keywords '("mode-line" "powerline" "spacemacs")
  :authors '(("Eivind Fonn" . "evfonn@gmail.com"))
  :maintainers '(("Eivind Fonn" . "evfonn@gmail.com")))
