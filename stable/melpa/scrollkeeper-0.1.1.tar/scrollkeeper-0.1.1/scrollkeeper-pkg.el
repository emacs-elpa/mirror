;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scrollkeeper" "0.1.1"
  "Custom scrolling commands with visual guidelines."
  '((emacs "25.1"))
  :url "https://github.com/alphapapa/scrollkeeper.el"
  :commit "3c4ac6b6b44686d31c260ee0b19daaee59bdccd6"
  :revdesc "0.1.1-0-g3c4ac6b6b446"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
