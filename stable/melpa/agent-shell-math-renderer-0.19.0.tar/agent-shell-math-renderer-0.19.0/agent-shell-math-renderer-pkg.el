;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.19.0"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.93.3")
    (latex-to-svg-backend "0.19.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "1d16d10b21dec013ebfe2140eafd9a9b22d36528"
  :revdesc "v0.19.0-0-g1d16d10b21de"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
