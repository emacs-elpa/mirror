;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "1.1.5"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "61290afd8c1fdef6b5b03b1588c5cf830e196ded"
  :revdesc "1.1.5-0-g61290afd8c1f"
  :keywords '("frames")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
