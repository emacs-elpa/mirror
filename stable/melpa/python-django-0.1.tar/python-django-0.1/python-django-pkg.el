;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-django" "0.1"
  "A Jazzy package for managing Django projects."
  ()
  :url "https://github.com/fgallina/python-django.el"
  :commit "4bf9dc2dde1761eb6760c1b6c714049b5fa4ca20"
  :revdesc "4bf9dc2dde17"
  :keywords '("languages")
  :authors '(("Fabián E. Gallina" . "fabian@anue.biz")))
