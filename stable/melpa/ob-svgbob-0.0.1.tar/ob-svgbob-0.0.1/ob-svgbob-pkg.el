;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-svgbob" "0.0.1"
  "Babel Functions for svgbob."
  ()
  :url "https://github.com/mgxm/ob-svgbob"
  :commit "9a930b1ed93e5ce1818029b2ec9e7662c098dbf4"
  :revdesc "0.0.1-0-g9a930b1ed93e"
  :keywords '("literate programming" "svg" "ascii")
  :authors '(("Marcio Giaxa" . "i@mgxm.me"))
  :maintainers '(("Marcio Giaxa" . "i@mgxm.me")))
