;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "languagetool" "1.3.1"
  "LanguageTool integration for grammar and spell check."
  '((emacs "27.1"))
  :url "https://github.com/PillFall/Emacs-LanguageTool.el"
  :commit "8e697f43d1a55356983c93be2a0f314dcf86ca20"
  :revdesc "v1.3.1-0-g8e697f43d1a5"
  :keywords '("grammar" "text" "docs" "tools" "convenience" "checker")
  :authors '(("Joar Buitrago" . "jebuitragoc@unal.edu.co"))
  :maintainers '(("Joar Buitrago" . "jebuitragoc@unal.edu.co")))
