;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-project-persist" "1.0.0"
  "Helm integration for project-persist package."
  '((helm            "1.5.2")
    (project-persist "0.1.4"))
  :url "https://github.com/Sliim/helm-project-persist"
  :commit "df63a21b9118f9639f0f4a336127b4fb8ec6deec"
  :revdesc "1.0.0-0-gdf63a21b9118"
  :keywords '("project-persist" "project" "helm")
  :authors '(("Sliim" . "sliim@mailoo.org"))
  :maintainers '(("Sliim" . "sliim@mailoo.org")))
