;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jdecomp" "0.2.0"
  "Interface to Java decompilers."
  '((emacs "24.5"))
  :url "https://github.com/xiongtx/jdecomp"
  :commit "1590b06f139f036c1041e1ce5c0acccaa24b31a7"
  :revdesc "1590b06f139f"
  :keywords '("decompile" "java" "languages" "tools")
  :authors '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com"))
  :maintainers '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com")))
