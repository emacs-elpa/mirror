;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-spy" "0.1"
  "Mocking framework for Emacs lisp. It also support spy, proxy."
  ()
  :url "https://github.com/uk-ar/el-spy"
  :commit "e80aed865c48a0aeb6b3d93f8ef39521ac804a10"
  :revdesc "e80aed865c48"
  :keywords '("test")
  :authors '(("Yuuki Arisawa" . "yuuki.ari@gmail.com"))
  :maintainers '(("Yuuki Arisawa" . "yuuki.ari@gmail.com")))
