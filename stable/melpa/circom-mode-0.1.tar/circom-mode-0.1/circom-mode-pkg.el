;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "circom-mode" "0.1"
  "Major mode for editing Circom circuit."
  '((emacs "24.3"))
  :url "https://github.com/taquangtrung/emacs-circom-mode"
  :commit "eaf98bba06aaef2c6fb45ddfa84e2142ff6419f5"
  :revdesc "eaf98bba06aa"
  :keywords '("languages"))
