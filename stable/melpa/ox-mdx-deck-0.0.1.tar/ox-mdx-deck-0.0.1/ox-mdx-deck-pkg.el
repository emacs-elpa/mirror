;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-mdx-deck" "0.0.1"
  "Org-mode to mdx-deck exporter."
  '((emacs "24"))
  :url "https://github.com/WolfeCub/ox-mdx-deck/"
  :commit "1ea6c38418f18a1ac7c677ac555aafc96e43e9fa"
  :revdesc "1ea6c38418f1"
  :keywords '("lisp" "org" "ox" "mdx" "deck"))
