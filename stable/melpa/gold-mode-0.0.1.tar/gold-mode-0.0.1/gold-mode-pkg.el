;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gold-mode" "0.0.1"
  "Major mode for editing .gold files."
  '((sws-mode "0"))
  :url "https://github.com/yuutayamada/gold-mode-el"
  :commit "876adf83aaa701949aa693483779772df4d4e7fb"
  :revdesc "876adf83aaa7"
  :keywords '("golang" "template" "gold")
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
