;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swift-helpful" "0.3"
  "Show documentation for Swift programs."
  '((emacs      "25.1")
    (dash       "2.12.0")
    (lsp-mode   "6.0")
    (swift-mode "8.0.0"))
  :url "https://github.com/danielmartin/swift-helpful"
  :commit "ed36ea3d8cd80159f7f90b144c4503411b74ae3e"
  :revdesc "ed36ea3d8cd8"
  :keywords '("help" "swift")
  :authors '(("Daniel Martín" . "mardani29@yahoo.es"))
  :maintainers '(("Daniel Martín" . "mardani29@yahoo.es")))
