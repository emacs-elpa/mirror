;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elm-mode" "0.22.0"
  "Major mode for Elm."
  '((f           "0.17")
    (s           "1.7.0")
    (emacs       "25.1")
    (seq         "2.23")
    (reformatter "0.3"))
  :url "https://github.com/jcollard/elm-mode"
  :commit "1e277684d8a6681a2410cce2dd589ee30a998369"
  :revdesc "1e277684d8a6")
