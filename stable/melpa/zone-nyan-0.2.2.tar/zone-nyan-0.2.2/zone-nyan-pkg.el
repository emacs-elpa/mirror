;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zone-nyan" "0.2.2"
  "Zone out with nyan cat."
  '((esxml "0.3.1"))
  :url "https://github.com/wasamasa/zone-nyan"
  :commit "e36875d83ad3dce14f23864688959fa0d98ba410"
  :revdesc "e36875d83ad3"
  :keywords '("zone")
  :authors '(("Vasilij Schneidermann" . "v.schneidermann@gmail.com"))
  :maintainers '(("Vasilij Schneidermann" . "v.schneidermann@gmail.com")))
