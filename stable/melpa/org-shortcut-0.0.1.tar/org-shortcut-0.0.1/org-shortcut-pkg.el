;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-shortcut" "0.0.1"
  "Shortcut.com bindings for org-mode."
  '((plz "0.9.1"))
  :url "https://github.com/Endi1/org-shortcut"
  :commit "d9b5cf22f35538bfb4c018677e047b5b0b6e9eeb"
  :revdesc "d9b5cf22f355"
  :keywords '("org-mode")
  :authors '(("Endi Sukaj" . "endisukaj@gmail.com"))
  :maintainers '(("Endi Sukaj" . "endisukaj@gmail.com")))
