;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winnow" "0.1"
  "Filter compilation/ag results by matching/excluding lines."
  ()
  :url "https://github.com/dgtized/winnow.el"
  :commit "b1ed57c5b5a0fe9dbfa8bfa37576951657c051ad"
  :revdesc "b1ed57c5b5a0"
  :keywords '("matching")
  :authors '(("Charles L.G. Comstock" . "dgtized@gmail.com"))
  :maintainers '(("Charles L.G. Comstock" . "dgtized@gmail.com")))
