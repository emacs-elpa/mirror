;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-raindrop" "0.2.1"
  "Raindrop.io with helm interface."
  '((emacs   "29.1")
    (helm    "4.0.4")
    (request "0.3.2"))
  :url "https://github.com/masutaka/emacs-helm-raindrop"
  :commit "ebfe81d19c3d4b84564c38add1093e5b71d72c2e"
  :revdesc "0.2.1-0-gebfe81d19c3d"
  :authors '(("Takashi Masuda" . "masutaka.net@gmail.com"))
  :maintainers '(("Takashi Masuda" . "masutaka.net@gmail.com")))
