;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hover" "1.2.3"
  "Package to use hover with flutter."
  '((emacs "25.2")
    (dash  "2.14.1"))
  :url "https://github.com/ericdallo/hover.el"
  :commit "cd362d80b72f45707e95f08824a5d7e7ae91d956"
  :revdesc "cd362d80b72f"
  :keywords '("hover" "flutter" "mobile" "tools"))
