;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "romanian-holidays" "0.0.1"
  "Romanian holidays."
  '((emacs "26"))
  :url "https://github.com/petrem/romanian-holidays"
  :commit "96c9983ea170503abbd5b3cd79bfe4481c72f43d"
  :revdesc "96c9983ea170"
  :keywords '("calendar" "holidays" "romanian"))
