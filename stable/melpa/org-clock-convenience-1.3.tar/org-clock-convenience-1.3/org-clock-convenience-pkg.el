;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-convenience" "1.3"
  "Convenience functions for org time tracking."
  '((org   "8")
    (emacs "24.3"))
  :url "https://github.com/dfeich/org-clock-convenience"
  :commit "9201db80862d144459f1316d571842f5389a47eb"
  :revdesc "9201db80862d"
  :keywords '("convenience")
  :authors '(("Derek Feichtinger" . "dfeich.gmail.com"))
  :maintainers '(("Derek Feichtinger" . "dfeich.gmail.com")))
