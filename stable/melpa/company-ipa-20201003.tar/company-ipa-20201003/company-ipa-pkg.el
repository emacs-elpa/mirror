;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ipa" "20201003"
  "Ipa backend for company."
  '((emacs   "24")
    (company "0.8.12"))
  :url "https://github.com/mguzmann/company-ipa"
  :commit "b38548fbe02ae00646ca7b2f02b962bced41c50f"
  :revdesc "b38548fbe02a"
  :keywords '("convenience" "company" "ipa")
  :authors '(("Matías Guzmán Naranjo" . "mguzmann89@gmail.com"))
  :maintainers '(("Matías Guzmán Naranjo" . "mguzmann89@gmail.com")))
