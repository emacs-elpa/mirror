;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evim" "0.1.0"
  "Evil Visual Multi - Multiple cursors for evil-mode."
  '((emacs "27.1")
    (evil  "1.14.0"))
  :url "https://github.com/chestnykh/evil-visual-multi"
  :commit "3c87222422dfe27aee7cafab7ee3cc6cabf78eb5"
  :revdesc "3c87222422df"
  :keywords '("convenience" "emulations")
  :authors '(("Vadim Pavlov" . "vadim198527@gmail.com"))
  :maintainers '(("Vadim Pavlov" . "vadim198527@gmail.com")))
