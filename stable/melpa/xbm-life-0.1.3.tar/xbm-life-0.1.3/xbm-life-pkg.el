;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xbm-life" "0.1.3"
  "A XBM version of Conway's Game of Life."
  ()
  :url "https://github.com/wasamasa/xbm-life"
  :commit "bde2b3730a02d237f7d95a8e3f3722f23f2d9201"
  :revdesc "bde2b3730a02"
  :keywords '("games")
  :authors '(("Vasilij Schneidermann" . "v.schneidermann@gmail.com"))
  :maintainers '(("Vasilij Schneidermann" . "v.schneidermann@gmail.com")))
