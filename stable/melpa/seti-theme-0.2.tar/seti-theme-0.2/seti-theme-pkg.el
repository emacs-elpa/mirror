;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seti-theme" "0.2"
  "A dark colored theme, inspired by Seti Atom Theme."
  ()
  :url "https://github.com/caisah/seti-theme"
  :commit "cbfef2fc15d19ce4c8326e65fafdd61737077132"
  :revdesc "cbfef2fc15d1"
  :keywords '("themes")
  :authors '(("Vlad Piersec" . "vlad.piersec@gmail.com"))
  :maintainers '(("Vlad Piersec" . "vlad.piersec@gmail.com")))
