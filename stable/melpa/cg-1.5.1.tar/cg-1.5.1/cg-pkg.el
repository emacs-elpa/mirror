;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cg" "1.5.1"
  "Major mode for editing Constraint Grammar files."
  '((emacs "26.1"))
  :url "https://edu.visl.dk/constraint_grammar.html"
  :commit "0b40c412971037a945d833e2fc9a75954d40f8bc"
  :revdesc "0b40c4129710"
  :keywords '("languages")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
