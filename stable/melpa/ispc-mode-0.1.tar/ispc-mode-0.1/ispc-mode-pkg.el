;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ispc-mode" "0.1"
  "Syntax coloring for ispc kernels."
  ()
  :url "https://github.com/Munksgaard/ispc-mode"
  :commit "96ff33f59a6d32186cc5f65c14544114f2129aeb"
  :revdesc "96ff33f59a6d"
  :keywords '("c" "ispc")
  :authors '(("Philip Munksgaard" . "philip@munksgaard.me"))
  :maintainers '(("Philip Munksgaard" . "philip@munksgaard.me")))
