;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "0.47"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (compat    "31")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "73ea6263be5c0959e94688ca24a89265b4a172ad"
  :revdesc "73ea6263be5c"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
