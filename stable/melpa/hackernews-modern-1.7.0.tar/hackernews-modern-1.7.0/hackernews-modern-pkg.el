;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hackernews-modern" "1.7.0"
  "Hacker News client with modern widget UI."
  '((emacs              "28.1")
    (transient          "0.5.0")
    (visual-fill-column "2.2")
    (async-http-queue   "0.1.0"))
  :url "https://git.andros.dev/andros/hackernews-modern-el"
  :commit "fc25fb3c5c8765dfd4a34f105125e8e244802b39"
  :revdesc "fc25fb3c5c87"
  :keywords '("comm" "hypermedia" "news")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
