;;; hackernews-modern-user.el --- User profiles for hackernews-modern -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; User profiles for hackernews-modern: karma, creation date and the
;; "about" text of a user, fetched from the API.  Author names are
;; clickable and open the profile of the author.

;;; Code:

(require 'button)
(require 'hackernews-modern-core)
(require 'hackernews-modern-account)
(require 'hackernews-modern-edit)

;; Forward declarations for controller symbols referenced in view.
(defvar hackernews-modern-user-mode-map)
(declare-function visual-fill-column-mode "visual-fill-column")
(declare-function hackernews-modern-submissions "hackernews-modern-lists" (user))
(declare-function hackernews-modern-user-comments "hackernews-modern-lists" (user))
(declare-function hackernews-modern-favorites "hackernews-modern-lists" (user &optional comments))
(declare-function hackernews-modern-upvoted "hackernews-modern-lists" (&optional comments))

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar-local hackernews-modern--user-name nil
  "Name of the user whose profile is shown in the current buffer.")

(defvar-local hackernews-modern--user-data nil
  "Profile shown in the current buffer, as returned by the API.
It is nil while loading and `missing' when the user does not exist.")

(defun hackernews-modern--fetch-user (name callback)
  "Fetch the profile of user NAME from the API asynchronously.
Calls CALLBACK with the profile as an alist, `missing' when the user
does not exist or nil on errors."
  (hackernews-modern--fetch-json
   (hackernews-modern--user-url name)
   (lambda (data error)
     (when error
       (message "Error reading the profile of %s: %s" name error))
     (funcall callback (cond (error nil)
                             (data)
                             (t 'missing))))))

(defun hackernews-modern--group-digits (number)
  "Return NUMBER as a string with its thousands separated by commas."
  (let ((digits (number-to-string number)))
    (while (string-match "\\([0-9]\\)\\([0-9]\\{3\\}\\)\\(,\\|\\'\\)" digits)
      (setq digits (replace-match "\\1,\\2\\3" t nil digits)))
    digits))

;;;; View ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--insert-author (name &optional face)
  "Insert NAME as a link that opens the profile of the user.
FACE defaults to `hackernews-modern-author'."
  (insert-text-button name
                      'face (or face 'hackernews-modern-author)
                      'mouse-face 'highlight
                      'follow-link t
                      'help-echo (format "View the profile of %s" name)
                      'action (lambda (_button) (hackernews-modern-user name))))

(defun hackernews-modern--insert-list-button (label help function &rest args)
  "Insert a button with LABEL and HELP calling FUNCTION with ARGS."
  (widget-create 'push-button
                 :notify (lambda (&rest _) (apply function args))
                 :help-echo help
                 (format " %s " label)))

(defun hackernews-modern--insert-user-profile (name data)
  "Insert the profile DATA of user NAME."
  (let ((karma   (cdr (assq 'karma data)))
        (created (cdr (assq 'created data)))
        (about   (cdr (assq 'about data)))
        (items   (length (cdr (assq 'submitted data))))
        (own     (equal name (hackernews-modern--current-user))))
    (insert (propertize name 'face (if own
                                       'hackernews-modern-own-author
                                     'hackernews-modern-author)))
    (when own
      (insert (propertize " (you)" 'face 'hackernews-modern-comment-time))
      (insert "  ")
      (hackernews-modern--insert-list-button
       "✎ Edit profile" "Change your about text, email and settings"
       #'hackernews-modern-edit-profile))
    (insert "\n\n")
    (when karma
      (insert "  Karma:   ")
      (insert (propertize (hackernews-modern--group-digits karma)
                          'face 'hackernews-modern-score-modern))
      (insert "\n"))
    (when created
      (insert (format "  Joined:  %s " (format-time-string "%B %-d, %Y" created t)))
      (insert (propertize (format "(%s)" (hackernews-modern--time-ago created))
                          'face 'hackernews-modern-comment-time))
      (insert "\n"))
    (insert (format "  Posted:  %s item%s\n"
                    (hackernews-modern--group-digits items) (if (= items 1) "" "s")))
    (hackernews-modern--insert-separator)
    (if (and about (not (string-empty-p about)))
        (progn
          (hackernews-modern--insert-html about)
          (insert "\n"))
      (insert (propertize "No \"about\" text.\n" 'face 'hackernews-modern-comment-time)))
    (hackernews-modern--insert-separator)
    (insert "Lists: ")
    (hackernews-modern--insert-list-button
     "Submissions" (format "Stories submitted by %s" name)
     #'hackernews-modern-submissions name)
    (insert " ")
    (hackernews-modern--insert-list-button
     "Comments" (format "Comments written by %s" name)
     #'hackernews-modern-user-comments name)
    (insert " ")
    (hackernews-modern--insert-list-button
     "Favorites" (format "Favorites of %s" name)
     #'hackernews-modern-favorites name)
    (when own
      (insert " ")
      (hackernews-modern--insert-list-button
       "Upvoted" "Stories you upvoted, only visible to you"
       #'hackernews-modern-upvoted))
    (insert "\n")))

(defun hackernews-modern--display-user (buffer)
  "Render the profile stored in BUFFER, keeping point when possible."
  (when (buffer-live-p buffer)
    (with-current-buffer buffer
      (let* ((window (get-buffer-window buffer t))
             (pos    (if window (window-point window) (point)))
             (name   hackernews-modern--user-name)
             (data   hackernews-modern--user-data)
             (inhibit-read-only t))
        (erase-buffer)
        (remove-overlays)
        (hackernews-modern--insert-logo)
        (widget-create 'push-button
                       :notify (lambda (&rest _) (quit-window))
                       :help-echo "Go back"
                       " ← Back ")
        (insert " ")
        (widget-create 'push-button
                       :notify (lambda (&rest _) (hackernews-modern-user-reload))
                       :help-echo "Refresh the profile"
                       " ↻ Refresh ")
        (insert " ")
        (widget-create 'push-button
                       :notify (lambda (&rest _) (hackernews-modern-user-browse))
                       :help-echo (hackernews-modern--site-url (format "user?id=%s" name))
                       " Open in browser ")
        (insert "\n")
        (hackernews-modern--insert-account)
        (insert "\n")
        (hackernews-modern--insert-separator)
        (pcase data
          ('nil     (insert "Loading profile...\n"))
          ('missing (insert (format "There is no user called %s.\n" name)))
          (_        (hackernews-modern--insert-user-profile name data)))
        (use-local-map (make-composed-keymap
                        (list widget-keymap hackernews-modern-user-mode-map)
                        special-mode-map))
        (widget-setup)
        (when (and (require 'visual-fill-column nil t)
                   (boundp 'visual-fill-column-width))
          (setq-local visual-fill-column-width hackernews-modern-display-width)
          (setq-local visual-fill-column-center-text t)
          (visual-fill-column-mode 1))
        (when (fboundp 'display-line-numbers-mode)
          (display-line-numbers-mode 0))
        (goto-char (min pos (point-max)))
        (when window
          (set-window-point window (point)))))))

;;;; Controller ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar hackernews-modern-user-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map "g" #'hackernews-modern-user-reload)
    (define-key map "o" #'hackernews-modern-user-browse)
    map)
  "Keymap used in hackernews-modern user profile buffer.")

(define-derived-mode hackernews-modern-user-mode special-mode "HN User"
  "Mode for reading the profile of a Hacker News user.

\\<hackernews-modern-user-mode-map>
\\[hackernews-modern-user-reload]	Reload the profile.
\\[hackernews-modern-user-browse]	Open the profile in the browser.
\\<special-mode-map>\\[quit-window]	Quit.

\\{hackernews-modern-user-mode-map}"
  :interactive nil
  (setq hackernews-modern--redraw-function
        (lambda () (hackernews-modern--display-user (current-buffer))))
  (setq truncate-lines nil)
  (visual-line-mode 1)
  (buffer-disable-undo))

;;;###autoload
(defun hackernews-modern-user (name)
  "Display the profile of the Hacker News user NAME."
  (interactive
   (list (let ((default (hackernews-modern--current-user)))
           (read-string (format-prompt "Hacker News user" default) nil nil default))))
  (when (string-empty-p name)
    (user-error "No user name given"))
  (let ((buffer (get-buffer-create (format "*hackernews-modern user %s*" name))))
    (with-current-buffer buffer
      (unless (derived-mode-p #'hackernews-modern-user-mode)
        (hackernews-modern-user-mode)
        (setq hackernews-modern--user-name name)
        (hackernews-modern--display-user buffer)))
    (pop-to-buffer buffer '((display-buffer-same-window)))
    (hackernews-modern-user-reload)))

(defun hackernews-modern-user-reload ()
  "Fetch and redisplay the profile of the current buffer."
  (declare (modes hackernews-modern-user-mode))
  (interactive)
  (unless (derived-mode-p #'hackernews-modern-user-mode)
    (user-error "Not a hackernews-modern user buffer"))
  (let ((buffer (current-buffer)))
    (message "Retrieving profile...")
    (hackernews-modern--fetch-user
     hackernews-modern--user-name
     (lambda (data)
       (when (buffer-live-p buffer)
         (if (null data)
             (message "Could not load the profile, press g to try again")
           (with-current-buffer buffer
             (setq hackernews-modern--user-data data))
           (hackernews-modern--display-user buffer)
           (message nil)))))))

(defun hackernews-modern-user-browse ()
  "Open the profile of the current buffer in the browser."
  (declare (modes hackernews-modern-user-mode))
  (interactive)
  (hackernews-modern--browse-url
   (hackernews-modern--site-url (format "user?id=%s" hackernews-modern--user-name))))

;;;; Profile editing ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defconst hackernews-modern--profile-fields
  '(("email" text "Email"
     "Only admins see it.  To share it, add it to the about text.")
    ("showd" bool "Show dead"
     "Show stories and comments killed by moderators or flags.")
    ("nopro" bool "Noprocrast"
     "Limit your visits to the website, see the next two fields.")
    ("maxv" text "Max visit"
     "Minutes you can stay on the website with noprocrast.")
    ("mina" text "Min away"
     "Minutes you have to stay away with noprocrast.")
    ("topc" text "Top color"
     "Color of the top bar of the website, in hexadecimal.")
    ("delay" text "Delay"
     "Minutes before your new comments are visible to others."))
  "Fields of the profile form, besides the about text.
Each element is a list of the name of the field in the form, its
kind (`text' or `bool' for a yes or no menu), its label and a help
text.  Only the fields present in the form are shown.")

(defvar-local hackernews-modern--profile-form nil
  "Profile form of the current profile edit buffer.")

(defvar-local hackernews-modern--profile-widgets nil
  "Alist mapping the names of the profile fields to their widgets.")

(defvar hackernews-modern-profile-edit-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-c C-c") #'hackernews-modern-profile-save)
    (define-key map (kbd "C-c C-k") #'hackernews-modern-profile-cancel)
    map)
  "Keymap used in hackernews-modern profile edit buffer.")

(define-derived-mode hackernews-modern-profile-edit-mode nil "HN Profile"
  "Mode for editing your Hacker News profile.

Click a field to change it, and the buttons to save or cancel.

\\<hackernews-modern-profile-edit-mode-map>
\\[hackernews-modern-profile-save]	Save the changes.
\\[hackernews-modern-profile-cancel]	Cancel.

\\{hackernews-modern-profile-edit-mode-map}"
  :interactive nil)

(defun hackernews-modern--insert-profile-buttons ()
  "Insert the buttons that save or cancel the profile changes."
  (widget-create 'push-button
                 :notify (lambda (&rest _) (hackernews-modern-profile-save))
                 :help-echo "Save the changes on Hacker News"
                 " ✓ Save ")
  (insert " ")
  (widget-create 'push-button
                 :notify (lambda (&rest _) (hackernews-modern-profile-cancel))
                 :help-echo "Discard the changes"
                 " Cancel ")
  (insert "\n"))

(defun hackernews-modern--profile-edit-open (user form)
  "Open the buffer to edit the profile of USER with its FORM."
  (let ((buffer  (get-buffer-create "*HN edit profile*"))
        (values  (plist-get form :values))
        (selects (plist-get form :selects))
        (widgets '()))
    (with-current-buffer buffer
      (let ((inhibit-read-only t))
        (erase-buffer))
      (remove-overlays)
      (hackernews-modern-profile-edit-mode)
      (setq hackernews-modern--profile-form form)
      (insert (propertize (format "Editing the profile of %s\n" user)
                          'face 'hackernews-modern-feed-indicator))
      (insert (propertize (substitute-command-keys
                           (concat "Click a field to change it.  "
                                   "\\<hackernews-modern-profile-edit-mode-map>"
                                   "\\[hackernews-modern-profile-save] save · "
                                   "\\[hackernews-modern-profile-cancel] cancel\n"))
                          'face 'shadow))
      (hackernews-modern--insert-separator)
      (insert "About\n")
      (push (cons "about" (widget-create 'text :format "%v\n" :value (or (plist-get form :text) "")))
            widgets)
      (insert (propertize "Blank line = paragraph, 2 spaces = code, *text* = italic.\n\n"
                          'face 'shadow))
      (dolist (spec hackernews-modern--profile-fields)
        (let* ((name  (nth 0 spec))
               (kind  (nth 1 spec))
               (value (cdr (assoc name (if (eq kind 'bool) selects values)))))
          (when value
            (insert (format "%-12s " (nth 2 spec)))
            (push (cons name
                        (if (eq kind 'bool)
                            (widget-create 'checkbox (equal value "yes"))
                          (widget-create 'editable-field
                                         :size (if (equal name "email") 40 10)
                                         :format "%v"
                                         value)))
                  widgets)
            (insert "\n")
            (insert (propertize (format "%-12s %s\n" "" (nth 3 spec)) 'face 'shadow)))))
      (hackernews-modern--insert-separator)
      (hackernews-modern--insert-profile-buttons)
      (setq hackernews-modern--profile-widgets widgets)
      (use-local-map (make-composed-keymap
                      (list hackernews-modern-profile-edit-mode-map widget-keymap)))
      (widget-setup)
      (set-buffer-modified-p nil))
    (pop-to-buffer buffer '((display-buffer-same-window)))
    (goto-char (point-min))
    (widget-forward 1)
    (message nil)))

(defun hackernews-modern-edit-profile ()
  "Edit your Hacker News profile: about text, email and settings."
  (interactive)
  (hackernews-modern--with-login
   (lambda ()
     (let ((user (hackernews-modern--current-user)))
       (message "Opening your profile...")
       (hackernews-modern--site-request
        (format "user?id=%s" (url-hexify-string user))
        (lambda (body _redirect)
          (let ((form (hackernews-modern--page-form body "xuser")))
            (if form
                (hackernews-modern--profile-edit-open user form)
              (message "Hacker News did not offer to edit your profile")))))))))

(defun hackernews-modern-profile-cancel ()
  "Discard the changes to your profile."
  (declare (modes hackernews-modern-profile-edit-mode))
  (interactive)
  (when (or (not (buffer-modified-p))
            (y-or-n-p "Discard your changes? "))
    (quit-window t)))

(defun hackernews-modern--profile-values ()
  "Return the values of the profile edit buffer as (NAME VALUE) pairs."
  (mapcar (lambda (field)
            (let ((value (widget-value (cdr field))))
              (list (car field)
                    (cond ((eq value t) "yes")
                          ((null value) "no")
                          (t (string-trim value))))))
          (reverse hackernews-modern--profile-widgets)))

(defun hackernews-modern-profile-save ()
  "Save the changes to your profile on Hacker News."
  (declare (modes hackernews-modern-profile-edit-mode))
  (interactive)
  (let ((buffer (current-buffer))
        (form   hackernews-modern--profile-form)
        (user   (hackernews-modern--current-user)))
    (message "Saving profile...")
    (hackernews-modern--site-request
     (plist-get form :action)
     (lambda (body redirect)
       (if (not (hackernews-modern--sent-p redirect))
           (message "Profile not saved: %s"
                    (if redirect
                        "the form expired, open it again"
                      (hackernews-modern--page-message body)))
         (hackernews-modern--quit-buffer buffer)
         (let ((profile (get-buffer (format "*hackernews-modern user %s*" user))))
           (when (buffer-live-p profile)
             (with-current-buffer profile
               (hackernews-modern-user-reload))))
         (message "Profile saved")))
     (append (plist-get form :fields) (hackernews-modern--profile-values)))))

(provide 'hackernews-modern-user)

;;; hackernews-modern-user.el ends here
