;;; hackernews-modern-lists.el --- User lists and search for hackernews-modern -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Lists of items shown like the story feeds: the submissions, comments
;; and favorites of a user, your upvoted items and search results.
;; Search and the public lists of a user come from the Algolia Hacker
;; News API, while favorites and upvoted items are read from the
;; website, which is the only place that has them.

;;; Code:

(require 'hackernews-modern-core)
(require 'hackernews-modern-account)
(require 'hackernews-modern-vote)

(declare-function hackernews-modern--load-stories "hackernews-modern" (feed n &optional append))

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defconst hackernews-modern-algolia-search-format
  "https://hn.algolia.com/api/v1/%s?%s"
  "Format of Algolia Hacker News API search URLs.
The first argument is the endpoint, \"search\" or \"search_by_date\",
and the second one the query string.")

(defconst hackernews-modern--list-hits 200
  "Number of items asked to the Algolia API for a list.")

(defconst hackernews-modern--list-max-pages 4
  "Maximum number of pages of the website read for a list.")

(defvar hackernews-modern-search-history ()
  "History of the searches made with `hackernews-modern-search'.")

(defun hackernews-modern--remember-context (id story-id title)
  "Remember that comment ID belongs to story STORY-ID called TITLE."
  (when (and story-id (not (eql id story-id)))
    (puthash id (cons story-id title) hackernews-modern--item-context)))

(defun hackernews-modern--algolia-ids (endpoint params callback)
  "Search the Algolia API at ENDPOINT with PARAMS.
PARAMS is a list of (KEY VALUE) pairs.  Calls CALLBACK with the
vector of the IDs found, remembering the story of the comments."
  (hackernews-modern--fetch-json
   (format hackernews-modern-algolia-search-format
           endpoint (url-build-query-string params))
   (lambda (data error)
     (when error
       (message "Search failed: %s" error))
     (funcall callback
              (vconcat
               (seq-map (lambda (hit)
                          (let ((id (string-to-number (cdr (assq 'objectID hit)))))
                            (hackernews-modern--remember-context
                             id (cdr (assq 'story_id hit)) (cdr (assq 'story_title hit)))
                            id))
                        (cdr (assq 'hits data))))))))

(defun hackernews-modern--read-list-page (body)
  "Return the IDs of the items listed in the website page BODY.
The story of each comment is remembered."
  (let ((ids '())
        (pos 0))
    (while (string-match "<tr[ \t][^>]*class=['\"]athing[^'\"]*['\"][^>]*id=['\"]\\([0-9]+\\)['\"]"
                         body pos)
      (let* ((id    (string-to-number (match-string 1 body)))
             (start (match-beginning 0))
             (end   (or (string-match "<tr[ \t][^>]*class=['\"]athing" body (match-end 0))
                        (length body)))
             (row   (substring body start end)))
        (setq pos end)
        (push id ids)
        (when (string-match "class=['\"]onstory['\"].*?href=['\"]item\\?id=\\([0-9]+\\)['\"][^>]*>\\([^<]*\\)<"
                            row)
          (hackernews-modern--remember-context
           id (string-to-number (match-string 1 row))
           (hackernews-modern--decode-entities (match-string 2 row))))))
    (nreverse ids)))

(defun hackernews-modern--site-list-ids (path callback &optional found page)
  "Read the IDs of the items of the website list at PATH.
The pages of the list are followed up to
`hackernews-modern--list-max-pages', and the votes and actions of
their items are read too.  FOUND holds the IDs of the
pages already read and PAGE their number.  Calls CALLBACK with the
vector of IDs."
  (let ((page (or page 1)))
    (hackernews-modern--site-request
     path
     (lambda (body _redirect)
       (cond
        ((null body)
         (message "No response from Hacker News")
         (funcall callback (vconcat found)))
        ((hackernews-modern--login-page-p body)
         (message "Log in to see this list")
         (funcall callback (vconcat found)))
        (t
         (hackernews-modern--read-item-page body)
         (let ((ids (append found (hackernews-modern--read-list-page body))))
           (if (and (< page hackernews-modern--list-max-pages)
                    (string-match "href=['\"]\\([^'\"]*\\)['\"][^>]*class=['\"]morelink" body))
               (hackernews-modern--site-list-ids
                (hackernews-modern--decode-entities (match-string 1 body))
                callback ids (1+ page))
             (funcall callback (vconcat ids))))))))))

;;;; Feeds ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--list-tab (label current function &rest args)
  "Return a tab with LABEL opening the list of FUNCTION called with ARGS.
CURRENT is non-nil for the tab of the list shown."
  (list label current (lambda () (apply function args))))

(defun hackernews-modern--user-list-tabs (user current)
  "Return the tabs of the lists of USER, where CURRENT is the shown one."
  (let ((own (equal user (hackernews-modern--current-user))))
    (list
     (append
      (list (hackernews-modern--list-tab "Submissions" (eq current 'submissions)
                                         #'hackernews-modern--submissions-feed user)
            (hackernews-modern--list-tab "Comments" (eq current 'comments)
                                         #'hackernews-modern--comments-feed user)
            (hackernews-modern--list-tab "Favorite stories" (eq current 'favorites)
                                         #'hackernews-modern--favorites-feed user nil)
            (hackernews-modern--list-tab "Favorite comments" (eq current 'favorite-comments)
                                         #'hackernews-modern--favorites-feed user t))
      (when own
        (list (hackernews-modern--list-tab "Upvoted stories" (eq current 'upvoted)
                                           #'hackernews-modern--upvoted-feed nil)
              (hackernews-modern--list-tab "Upvoted comments" (eq current 'upvoted-comments)
                                           #'hackernews-modern--upvoted-feed t)))))))

(defun hackernews-modern--submissions-feed (user)
  "Return the feed of the stories submitted by USER."
  (list :title (format "submissions of %s" user)
        :tabs (lambda () (hackernews-modern--user-list-tabs user 'submissions))
        :ids (lambda (callback)
               (hackernews-modern--algolia-ids
                "search_by_date"
                `(("tags" ,(format "story,author_%s" user))
                  ("hitsPerPage" ,(number-to-string hackernews-modern--list-hits)))
                callback))))

(defun hackernews-modern--comments-feed (user)
  "Return the feed of the comments written by USER."
  (list :title (format "comments of %s" user)
        :tabs (lambda () (hackernews-modern--user-list-tabs user 'comments))
        :ids (lambda (callback)
               (hackernews-modern--algolia-ids
                "search_by_date"
                `(("tags" ,(format "comment,author_%s" user))
                  ("hitsPerPage" ,(number-to-string hackernews-modern--list-hits)))
                callback))))

(defun hackernews-modern--favorites-feed (user comments)
  "Return the feed of the favorites of USER.
The favorite comments are listed when COMMENTS is non-nil, and the
favorite stories otherwise."
  (list :title (format "favorite %s of %s" (if comments "comments" "stories") user)
        :tabs (lambda ()
                (hackernews-modern--user-list-tabs
                 user (if comments 'favorite-comments 'favorites)))
        :ids (lambda (callback)
               (hackernews-modern--site-list-ids
                (format "favorites?id=%s%s" (url-hexify-string user)
                        (if comments "&comments=t" ""))
                callback))))

(defun hackernews-modern--upvoted-feed (comments)
  "Return the feed of the items you upvoted.
The comments are listed when COMMENTS is non-nil, and the stories
otherwise."
  (let ((user (hackernews-modern--current-user)))
    (list :title (format "upvoted %s" (if comments "comments" "stories"))
          :tabs (lambda ()
                  (hackernews-modern--user-list-tabs
                   user (if comments 'upvoted-comments 'upvoted)))
          :ids (lambda (callback)
                 (hackernews-modern--site-list-ids
                  (format "upvoted?id=%s%s" (url-hexify-string user)
                          (if comments "&comments=t" ""))
                  callback)))))

(defun hackernews-modern--search-feed (query comments newest)
  "Return the feed of the items matching QUERY.
Comments are searched when COMMENTS is non-nil, and stories
otherwise.  The newest items come first when NEWEST is non-nil, and
the most popular ones otherwise."
  (list :title (format "%s %s about \"%s\""
                       (if newest "newest" "popular")
                       (if comments "comments" "stories")
                       query)
        :tabs (lambda ()
                (list
                 (list (hackernews-modern--list-tab "Stories" (not comments)
                                                    #'hackernews-modern--search-feed
                                                    query nil newest)
                       (hackernews-modern--list-tab "Comments" comments
                                                    #'hackernews-modern--search-feed
                                                    query t newest))
                 (list (hackernews-modern--list-tab "Popular" (not newest)
                                                    #'hackernews-modern--search-feed
                                                    query comments nil)
                       (hackernews-modern--list-tab "Newest" newest
                                                    #'hackernews-modern--search-feed
                                                    query comments t))))
        :ids (lambda (callback)
               (hackernews-modern--algolia-ids
                (if newest "search_by_date" "search")
                `(("query" ,query)
                  ("tags" ,(if comments "comment" "story"))
                  ("hitsPerPage" ,(number-to-string hackernews-modern--list-hits)))
                callback))))

;;;; Controller ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--read-user-name ()
  "Read a Hacker News user name, defaulting to the logged in user."
  (let* ((default (hackernews-modern--current-user))
         (name    (read-string (format-prompt "Hacker News user" default)
                               nil nil default)))
    (when (string-empty-p name)
      (user-error "No user name given"))
    name))

;;;###autoload
(defun hackernews-modern-submissions (user)
  "List the stories submitted by USER."
  (interactive (list (hackernews-modern--read-user-name)))
  (hackernews-modern--load-stories (hackernews-modern--submissions-feed user) nil))

;;;###autoload
(defun hackernews-modern-user-comments (user)
  "List the comments written by USER."
  (interactive (list (hackernews-modern--read-user-name)))
  (hackernews-modern--load-stories (hackernews-modern--comments-feed user) nil))

;;;###autoload
(defun hackernews-modern-favorites (user &optional comments)
  "List the favorite stories of USER.
With a prefix argument COMMENTS, list the favorite comments."
  (interactive (list (hackernews-modern--read-user-name) current-prefix-arg))
  (hackernews-modern--load-stories (hackernews-modern--favorites-feed user comments) nil))

;;;###autoload
(defun hackernews-modern-upvoted (&optional comments)
  "List the stories you upvoted.
With a prefix argument COMMENTS, list the upvoted comments.  Only
your own upvotes can be listed, so you need to be logged in."
  (interactive "P")
  (hackernews-modern--with-login
   (lambda ()
     (hackernews-modern--load-stories (hackernews-modern--upvoted-feed comments) nil))))

;;;###autoload
(defun hackernews-modern-search (query &optional comments)
  "Search Hacker News stories matching QUERY.
With a prefix argument COMMENTS, search comments instead.  The
results buffer has buttons to switch between stories and comments
and between popular and newest results."
  (interactive (list (read-string "Search Hacker News: " nil
                                  'hackernews-modern-search-history)
                     current-prefix-arg))
  (when (string-empty-p (string-trim query))
    (user-error "Nothing to search"))
  (hackernews-modern--load-stories
   (hackernews-modern--search-feed (string-trim query) comments nil) nil))

(provide 'hackernews-modern-lists)

;;; hackernews-modern-lists.el ends here
