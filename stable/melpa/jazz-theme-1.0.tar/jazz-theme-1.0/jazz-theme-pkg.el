;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jazz-theme" "1.0"
  "A warm color theme for Emacs 24."
  ()
  :url "https://github.com/donderom/jazz-theme"
  :commit "f071f6ff90e8f94181af8cb0c9157abfcff4b2b3"
  :revdesc "f071f6ff90e8"
  :authors '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainers '(("Roman Parykin" . "donderom@ymail.com")))
