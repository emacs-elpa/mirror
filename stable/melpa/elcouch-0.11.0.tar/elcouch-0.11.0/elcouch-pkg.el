;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elcouch" "0.11.0"
  "View and manipulate CouchDB databases."
  '((emacs      "25.1")
    (json-mode  "1.0.0")
    (libelcouch "0.11.0")
    (navigel    "0.3.0"))
  :url "https://gitlab.petton.fr/DamienCassou/elcouch"
  :commit "3d162dda14411349e12509029d2b621c5d1edea2"
  :revdesc "3d162dda1441"
  :keywords '("data" "tools")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
