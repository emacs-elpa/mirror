;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-stats" "0.1"
  "Code::Stats plugin."
  '((emacs   "25")
    (request "0.3.0"))
  :url "https://github.com/xuchunyang/code-stats-emacs"
  :commit "20d60ded0743f01206c3c2e92ab73788def9adcb"
  :revdesc "20d60ded0743"
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
