;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sail" "0.1.0"
  "NOAA tide and wind reports for sailors."
  '((emacs "25.1"))
  :url "https://github.com/brannala64/esail"
  :commit "41d00bb355912f43af87ccf99734b5a7c864fde5"
  :revdesc "41d00bb35591"
  :keywords '("comm")
  :authors '(("Bruce Rannala" . "brannala@ucdavis.edu"))
  :maintainers '(("Bruce Rannala" . "brannala@ucdavis.edu")))
