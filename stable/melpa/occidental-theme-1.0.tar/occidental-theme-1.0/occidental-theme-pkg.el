;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occidental-theme" "1.0"
  "Custom theme for faces based on Adwaita."
  ()
  :url "https://github.com/olcai/occidental-theme"
  :commit "e7668a3e2f028a905df1356e997d09f4c6a2a9cc"
  :revdesc "e7668a3e2f02"
  :authors '(("William Stevenson" . "yhvh2000@gmail.com")
             ("Erik Timan" . "dev@timan.info"))
  :maintainers '(("William Stevenson" . "yhvh2000@gmail.com")
                 ("Erik Timan" . "dev@timan.info")))
