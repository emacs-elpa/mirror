;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-edit" "0.1.0"
  "Description."
  '((emacs             "27.0")
    (tree-sitter       "0.15.0")
    (tree-sitter-langs "0.10.0")
    (dash              "2.19")
    (evil              "1.0.0")
    (avy               "0.5.0")
    (reazon            "0.4.0")
    (s                 "0.0.0"))
  :url "https://github.com/ethan-leba/tree-edit"
  :commit "92d591b3183af45fa83d5816bc78ab2625856c22"
  :revdesc "92d591b3183a"
  :authors '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainers '(("Ethan Leba" . "ethanleba5@gmail.com")))
