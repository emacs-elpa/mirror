;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-explorer" "0.8"
  "Provide Explorer-like file selection in Dired."
  '((emacs "24.3"))
  :url "https://github.com/jidaikobo-shibata/dired-explorer"
  :commit "5739314327b1d1cc8977a8593275248f7790f1f1"
  :revdesc "0.8-0-g5739314327b1"
  :keywords '("dired" "explorer"))
