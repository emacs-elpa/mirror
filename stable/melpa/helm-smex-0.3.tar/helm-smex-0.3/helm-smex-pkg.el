;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-smex" "0.3"
  "Helm interface for smex."
  '((emacs "24")
    (smex  "3.0")
    (helm  "1.7.7"))
  :url "https://github.com/ptrv/helm-smex"
  :commit "2269375dfa452b88b5170d1a5d5849ebb2c1e413"
  :revdesc "2269375dfa45"
  :keywords '("convenience")
  :authors '(("Peter Vasil" . "mail@petervasil.net"))
  :maintainers '(("Peter Vasil" . "mail@petervasil.net")))
