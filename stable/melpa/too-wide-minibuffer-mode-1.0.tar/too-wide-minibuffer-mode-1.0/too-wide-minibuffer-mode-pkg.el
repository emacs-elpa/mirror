;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "too-wide-minibuffer-mode" "1.0"
  "Shrink minibuffer if the frame is too wide."
  '((emacs "30.1"))
  :url "https://github.com/hron/too-wide-minibuffer-mode"
  :commit "f78830a327f40aa4d62f9b69a19f4838eca96e12"
  :revdesc "f78830a327f4"
  :keywords '("convenience")
  :authors '(("Aleksei Gusev" . "aleksei.gusev@gmail.com"))
  :maintainers '(("Aleksei Gusev" . "aleksei.gusev@gmail.com")))
