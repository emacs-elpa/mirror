;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flames-of-freedom" "1.2"
  "The flames of freedom."
  '((emacs "25.1"))
  :url "https://github.com/wiz21b/FlamesOfFreedom"
  :commit "7da5b8cf91343197d68ab3637494342d83250aa6"
  :revdesc "7da5b8cf9134"
  :keywords '("multimedia")
  :authors '(("Stéphane Champailler" . "schampailler@skynet.be"))
  :maintainers '(("Stéphane Champailler" . "schampailler@skynet.be")))
