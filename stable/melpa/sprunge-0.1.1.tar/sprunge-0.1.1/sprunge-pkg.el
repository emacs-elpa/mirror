;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sprunge" "0.1.1"
  "Upload pastes to sprunge.us."
  '((request "0.2.0")
    (cl-lib  "0.5"))
  :url "https://github.com/tomjakubowski/sprunge.el"
  :commit "0fd386b8b29c4175022a04ad70ea5643185b6726"
  :revdesc "0fd386b8b29c"
  :keywords '("tools"))
