;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "extempore-mode" "2.0"
  "Major mode for Extempore source files."
  '((emacs "29.1"))
  :url "https://github.com/extemporelang/extempore-emacs-mode"
  :commit "5b3741efe6341d6a2db3915b31585eb15603d578"
  :revdesc "5b3741efe634"
  :keywords '("languages" "lisp" "extempore")
  :authors '(("Ben Swift" . "ben@benswift.me"))
  :maintainers '(("Ben Swift" . "ben@benswift.me")))
