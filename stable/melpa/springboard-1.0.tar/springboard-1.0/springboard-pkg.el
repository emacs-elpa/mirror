;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "springboard" "1.0"
  "[No description available]."
  ()
  :url "https://github.com/jwiegley/springboard"
  :commit "f7a637b30b982708d850239c8829babd7cf83b74"
  :revdesc "f7a637b30b98"
  :keywords '("helm")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("John Wiegley" . "jwiegley@gmail.com")))
