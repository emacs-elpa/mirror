;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "didyoumean" "0.4.0"
  "Did you mean to open another file?."
  '((emacs "24.4"))
  :url "https://gitlab.com/kisaragi-hiu/didyoumean.el"
  :commit "6d0c4203eb192d73d89261b3a9bad52951e394af"
  :revdesc "6d0c4203eb19"
  :keywords '("convenience")
  :authors '(("Kisaragi Hiu" . "mail@kisaragi-hiu.com"))
  :maintainers '(("Kisaragi Hiu" . "mail@kisaragi-hiu.com")))
