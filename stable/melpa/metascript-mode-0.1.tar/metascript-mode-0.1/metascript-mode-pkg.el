;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metascript-mode" "0.1"
  "Major mode for the Metascript programming language."
  '((emacs "24.3"))
  :url "https://github.com/metascript/metascript-mode"
  :commit "24f531f8df3df24c283e92f35fc62ec2b65fb61d"
  :revdesc "24f531f8df3d"
  :keywords '("languages" "metascript" "mjs")
  :authors '(("Rodrigo B. de Oliveira" . "rbo@acm.org"))
  :maintainers '(("Rodrigo B. de Oliveira" . "rbo@acm.org")))
