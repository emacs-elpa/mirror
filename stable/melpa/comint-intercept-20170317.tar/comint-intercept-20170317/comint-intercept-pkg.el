;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comint-intercept" "20170317"
  "Intercept input in comint-mode."
  '((emacs "24.3"))
  :url "https://github.com/hying-caritas/comint-intercept"
  :commit "84c41e60e1ea3e9d5da1eb99e9926a52b6658d6d"
  :revdesc "84c41e60e1ea"
  :keywords '("processes" "terminals")
  :authors '(("Huang, Ying" . "huang.ying.caritas@gmail.com"))
  :maintainers '(("Huang, Ying" . "huang.ying.caritas@gmail.com")))
