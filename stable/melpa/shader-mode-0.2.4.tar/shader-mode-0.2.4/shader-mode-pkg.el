;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shader-mode" "0.2.4"
  "Major mode for shader."
  '((emacs "24"))
  :url "https://github.com/midnightSuyama/shader-mode"
  :commit "d7dc8d0d6fe8914e8b6d5cf2081ad61e6952359c"
  :revdesc "d7dc8d0d6fe8"
  :authors '(("midnightSuyama" . "midnightSuyama@gmail.com"))
  :maintainers '(("midnightSuyama" . "midnightSuyama@gmail.com")))
