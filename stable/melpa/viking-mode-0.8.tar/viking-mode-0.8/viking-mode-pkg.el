;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "viking-mode" "0.8"
  "Kill first, ask later."
  ()
  :url "https://github.com/tlinden/viking-mode"
  :commit "7675a3c395e0da4d30a7a46ea74680271469f9a5"
  :revdesc "7675a3c395e0"
  :keywords '("kill" "delete")
  :authors '(("T.v.Dein" . "tlinden@cpan.org"))
  :maintainers '(("T.v.Dein" . "tlinden@cpan.org")))
