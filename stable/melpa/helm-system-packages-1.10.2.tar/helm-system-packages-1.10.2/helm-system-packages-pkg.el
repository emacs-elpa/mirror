;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-system-packages" "1.10.2"
  "Helm UI wrapper for system package managers."
  '((emacs "24.4")
    (helm  "2.8.7")
    (seq   "1.8"))
  :url "https://github.com/emacs-helm/helm-system-packages"
  :commit "c331c69de0a37d2bc4d6f882cc021a905e7e56f9"
  :revdesc "c331c69de0a3"
  :keywords '("helm" "packages")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
