;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-init" "0.2.0"
  "A loader inspired by init-loader."
  '((emacs    "24")
    (cl-lib   "0.5")
    (anaphora "1.0.0"))
  :url "https://github.com/HKey/el-init"
  :commit "25fd21d820bca1cf576b8f70c8d5a3bc76792597"
  :revdesc "25fd21d820bc"
  :authors '(("Hiroki YAMAKAWA" . "s06139@gmail.com"))
  :maintainers '(("Hiroki YAMAKAWA" . "s06139@gmail.com")))
