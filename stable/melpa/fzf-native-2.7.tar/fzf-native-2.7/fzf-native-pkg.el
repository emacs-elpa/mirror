;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "2.7"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "182d912b147aa0924e47d67e7f38fd336378719e"
  :revdesc "182d912b147a"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
