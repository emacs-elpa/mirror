;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pkgbuild-mode" "0.14"
  "Interface to the ArchLinux package manager."
  ()
  :url "https://github.com/juergenhoetzel/pkgbuild-mode"
  :commit "6bb7cb3b0599ac0ae3c1d8d5014aefc1ecff7965"
  :revdesc "6bb7cb3b0599")
