;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elmacro" "1.1.1"
  "Convert keyboard macros to emacs lisp."
  '((s    "1.11.0")
    (dash "2.13.0"))
  :url "https://github.com/Silex/elmacro"
  :commit "5bf9ba6009226b95e5ba0f50489ccced475753e3"
  :revdesc "1.1.1-0-g5bf9ba600922"
  :keywords '("macro" "elisp" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
