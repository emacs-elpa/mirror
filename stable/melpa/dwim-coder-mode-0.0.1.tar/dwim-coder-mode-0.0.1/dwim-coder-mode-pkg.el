;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwim-coder-mode" "0.0.1"
  "DWIM keybindings for programming modes."
  '((emacs "29"))
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html"
  :commit "c8c5b3981bd44bee7ab59eb0a686c8841975a2c3"
  :revdesc "c8c5b3981bd4"
  :keywords '("convenience" "hacks")
  :authors '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers '(("Mohammed Sadiq" . "sadiq@sadiqpk.org")))
