;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-swiftx" "1.0.2"
  "Flycheck: Swift backend."
  '((emacs         "26.1")
    (flycheck      "26")
    (xcode-project "1.0"))
  :url "https://github.com/nhojb/flycheck-swiftx"
  :commit "94ead32e879c055902e3edb78af1193f21339e5f"
  :revdesc "94ead32e879c"
  :keywords '("convenience" "languages" "tools")
  :authors '(("John Buckley" . "john@olivetoast.com"))
  :maintainers '(("John Buckley" . "john@olivetoast.com")))
