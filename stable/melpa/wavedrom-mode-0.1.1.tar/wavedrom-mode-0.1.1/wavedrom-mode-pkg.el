;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wavedrom-mode" "0.1.1"
  "WaveDrom Integration."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/wavedrom-mode"
  :commit "159767bc9e1726035c9e21ac50f2d0f7fe315fa8"
  :revdesc "159767bc9e17"
  :keywords '("fpga" "asic" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
