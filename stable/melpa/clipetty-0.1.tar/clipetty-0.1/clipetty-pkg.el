;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clipetty" "0.1"
  "Send every kill from a TTY frame to the system clipboard."
  '((emacs "25.1"))
  :url "https://github.com/spudlyo/clipetty"
  :commit "8430e1c01ae701fb85bb12703fe59a0f04fd0a6f"
  :revdesc "8430e1c01ae7"
  :keywords '("terminals" "convenience")
  :authors '(("Mike Hamrick" . "mikeh@muppetlabs.com"))
  :maintainers '(("Mike Hamrick" . "mikeh@muppetlabs.com")))
