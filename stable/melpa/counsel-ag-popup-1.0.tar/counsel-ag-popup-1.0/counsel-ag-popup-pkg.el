;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-ag-popup" "1.0"
  "Interactive search with counsel-ag."
  '((emacs     "26.1")
    (counsel   "0.13.0")
    (transient "0.3.0"))
  :url "https://github.com/gexplorer/counsel-ag-popup"
  :commit "6f6cad05c7cc938b2b25fab2beb0029ef4926fd0"
  :revdesc "6f6cad05c7cc"
  :keywords '("convenience" "matching" "tools")
  :authors '(("Eder Elorriaga" . "gexplorer8@gmail.com"))
  :maintainers '(("Eder Elorriaga" . "gexplorer8@gmail.com")))
