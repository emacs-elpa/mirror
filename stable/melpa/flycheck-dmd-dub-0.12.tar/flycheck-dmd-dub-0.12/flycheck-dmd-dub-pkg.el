;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-dmd-dub" "0.12"
  "Sets flycheck-dmd-include-paths from dub package information."
  '((flycheck "0.24")
    (f        "0.18.2"))
  :url "https://github.com/atilaneves/flycheck-dmd-dub"
  :commit "41a839e18eb7159175c59a2f8b2f5f283191e33f"
  :revdesc "V0.12-0-g41a839e18eb7"
  :keywords '("languages")
  :authors '(("Atila Neves" . "atila.neves@gmail.com"))
  :maintainers '(("Atila Neves" . "atila.neves@gmail.com")))
