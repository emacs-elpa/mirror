;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-outline-numbering" "0.1"
  "Show outline numbering as overlays in org-mode."
  '((emacs "24")
    (ov    "1.0.6")
    (org   "8.3"))
  :url "https://gitlab.com/andersjohansson/org-outline-numbering"
  :commit "11d0e003871bfab9e0637c5a17ebd448d3276abb"
  :revdesc "11d0e003871b"
  :keywords '("wp" "convenience"))
