;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-eask" "0.1.0"
  "Eldoc support for Eask-file."
  '((emacs "26.1")
    (eask  "0.1.0"))
  :url "https://github.com/emacs-eask/eldoc-eask"
  :commit "c82dedc41772f6a84f02b2fe24bea7ba9512e246"
  :revdesc "c82dedc41772"
  :keywords '("convenience")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
