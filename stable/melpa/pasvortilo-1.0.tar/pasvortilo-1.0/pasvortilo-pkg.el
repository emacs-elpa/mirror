;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pasvortilo" "1.0"
  "Summary."
  ()
  :url "homepage"
  :commit "128b821233722d2507529a84e952f3c666f10207"
  :revdesc "128b82123372"
  :keywords '("password_manager"))
