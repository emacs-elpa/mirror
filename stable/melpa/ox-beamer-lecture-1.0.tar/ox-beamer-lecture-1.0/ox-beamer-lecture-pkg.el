;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-beamer-lecture" "1.0"
  "Beamer Lecture Back-End for Org Export Engine."
  '((emacs "29.1"))
  :url "https://github.com/fjesser/ox-beamer-lecture"
  :commit "77546eaf9ac8f94b6079720f1d93c33dbbcc4108"
  :revdesc "1.0-0-g77546eaf9ac8"
  :keywords '("org" "text" "tex")
  :authors '(("Felix J. Esser" . "code-esser@mailbox.org"))
  :maintainers '(("Felix J. Esser" . "code-esser@mailbox.org")))
