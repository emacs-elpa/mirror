;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "year-1984-theme" "1.0"
  "A retro-futuristic theme."
  '((emacs "27.1"))
  :url "https://github.com/mastro35/year-1984-theme"
  :commit "7d8b5ec7eb9ee364a66cc7c83d6490915543ba1f"
  :revdesc "7d8b5ec7eb9e"
  :keywords '("themes" "faces" "colors")
  :authors '(("Davide Mastromatteo" . "mastro35@gmail.com"))
  :maintainers '(("Davide Mastromatteo" . "mastro35@gmail.com")))
