;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "expand-line" "0.0.0.20151006.10"
  "Expand selection by line."
  ()
  :url "https://github.com/victorteokw/expand-line"
  :commit "75a5d0241f35dd0748ab8ecb4ff16891535be372"
  :revdesc "75a5d0241f35"
  :authors '(("Kai Yu" . "yeannylam@gmail.com"))
  :maintainers '(("Kai Yu" . "yeannylam@gmail.com")))
