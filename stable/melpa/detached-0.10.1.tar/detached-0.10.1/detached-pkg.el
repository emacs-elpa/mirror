;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "detached" "0.10.1"
  "A package to launch, and manage, detached processes."
  '((emacs "27.1"))
  :url "https://sr.ht/~niklaseklund/detached.el/"
  :commit "fedb0df5b0fbba13c662107855fb07a922793096"
  :revdesc "0.10.1-0-gfedb0df5b0fb"
  :keywords '("convenience" "processes")
  :authors '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainers '(("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")))
