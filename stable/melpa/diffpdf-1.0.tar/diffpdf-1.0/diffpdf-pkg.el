;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diffpdf" "1.0"
  "Transient diffpdf."
  '((emacs     "25.1")
    (transient "0.3.0"))
  :url "https://github.com/ShuguangSun/diffpdf.el"
  :commit "fdb37bb696aaec6cb2bcece3760866760e68edc4"
  :revdesc "fdb37bb696aa"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
