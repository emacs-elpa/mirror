;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pony" "0.3.0"
  "Pony support in Flycheck."
  '((flycheck "0.25.1"))
  :url "https://github.com/seantallen/flycheck-pony"
  :commit "22787cf8223ca9ec309e30a42c20a8e706d8bfbe"
  :revdesc "22787cf8223c"
  :keywords '("tools" "convenience")
  :authors '(("Sean T Allen" . "sean@seantallen.com"))
  :maintainers '(("Sean T Allen" . "sean@seantallen.com")))
