;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-lsp" "0.1.0"
  "Show lsp information with sideline."
  '((emacs    "27.1")
    (sideline "0.1.0")
    (lsp-mode "6.0")
    (dash     "2.18.0")
    (ht       "2.4")
    (s        "1.12.0"))
  :url "https://github.com/jcs-elpa/sideline-lsp"
  :commit "afe8995e27a71b0e7355c40cbd3137ca26939dfc"
  :revdesc "afe8995e27a7"
  :keywords '("sideline" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
