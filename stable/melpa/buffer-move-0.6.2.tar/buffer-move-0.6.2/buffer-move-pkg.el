;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-move" "0.6.2"
  "[No description available]."
  ()
  :url "https://github.com/lukhas/buffer-move"
  :commit "9bf3ff940011c7af3fdd172fa3ea2511c7a8a190"
  :revdesc "9bf3ff940011"
  :keywords '("lisp" "convenience")
  :authors '(("Lucas Bonnet" . "lucas@rincevent.net")
             ("Geyslan G. Bem" . "geyslan@gmail.com")
             ("Mathis Hofer" . "mathis@fsfe.org"))
  :maintainers '(("Lucas Bonnet" . "lucas@rincevent.net")
                 ("Geyslan G. Bem" . "geyslan@gmail.com")
                 ("Mathis Hofer" . "mathis@fsfe.org")))
