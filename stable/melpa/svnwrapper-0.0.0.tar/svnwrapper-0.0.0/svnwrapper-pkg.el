;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "svnwrapper" "0.0.0"
  "Highlighting and paging for shell command `svn'."
  '((e2ansi "0.1.1"))
  :url "https://github.com/Lindydancer/svnwrapper"
  :commit "de5069f5784e5d9e87a0af0159ba5f28a3716583"
  :revdesc "de5069f5784e"
  :keywords '("faces"))
