;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faust-mode" "0.6"
  "Faust syntax colorizer for Emacs."
  ()
  :url "https://github.com/rukano/emacs-faust-mode"
  :commit "7c31b22bdbfd2f8c16ec117d2975d56dd61ac15c"
  :revdesc "7c31b22bdbfd"
  :keywords '("languages" "faust")
  :authors '(("rukano" . "rukano@gmail.com"))
  :maintainers '(("Yassin Philip" . "xaccrocheur@gmail.com")))
