;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-dired-recent-dirs" "0.0.0.20131228.9"
  "Show recent dirs with helm.el support."
  '((helm "1.0"))
  :url "https://github.com/zonkyy/helm-dired-recent-dirs"
  :commit "3bcd125b44f5a707588ae3868777d91192351523"
  :revdesc "3bcd125b44f5"
  :keywords '("helm" "dired" "zsh")
  :authors '(("Akisute" . "akisute3@gmail.com"))
  :maintainers '(("Akisute" . "akisute3@gmail.com")))
