;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-books" "0.3.1"
  "Reading list management with Org mode and helm."
  '((enlive   "0.0.1")
    (s        "1.11.0")
    (helm     "2.9.2")
    (helm-org "1.0")
    (dash     "2.14.1")
    (org      "9.3")
    (emacs    "25"))
  :url "https://github.com/lepisma/org-books"
  :commit "3f769e5a5a85a5eb6a2249ba971a3d77dc6e7d94"
  :revdesc "3f769e5a5a85"
  :keywords '("outlines")
  :authors '(("Abhinav Tushar" . "abhinav@lepisma.xyz"))
  :maintainers '(("Abhinav Tushar" . "abhinav@lepisma.xyz")))
