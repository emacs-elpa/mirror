;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-yaow" "1.0"
  "Generate html pages from org files."
  '((emacs "27")
    (f     "0.2.0")
    (s     "1.12.0")
    (dash  "2.17.0"))
  :url "https://github.com/LaurenceWarne/ox-yaow.el"
  :commit "83f9e903f2853e9dc6367fa0a49015428d061dea"
  :revdesc "83f9e903f285"
  :keywords '("org"))
