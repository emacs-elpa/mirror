;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-emms" "0.2"
  "Play multimedia files in org-mode."
  '((emacs "24.1")
    (org   "9.3")
    (emms  "0.0"))
  :url "https://git.sr.ht/~jagrg/org-emms"
  :commit "0de96cec40fa4b430ff2a47133303d649bf017ce"
  :revdesc "0de96cec40fa"
  :keywords '("multimedia")
  :authors '(("Jonathan Gregory" . "jgrgatautisticidotorg"))
  :maintainers '(("Jonathan Gregory" . "jgrgatautisticidotorg")))
