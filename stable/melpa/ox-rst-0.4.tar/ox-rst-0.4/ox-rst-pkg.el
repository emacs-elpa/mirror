;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-rst" "0.4"
  "Export reStructuredText using org-mode."
  '((emacs "25.1")
    (org   "8.3"))
  :url "https://github.com/msnoigrs/ox-rst"
  :commit "f7eea0239b244f4b285d5d476b24696c6ed16ca3"
  :revdesc "f7eea0239b24"
  :keywords '("org" "rst" "rest" "restructuredtext")
  :authors '(("Masanao Igarashi" . "syoux2@gmail.com"))
  :maintainers '(("Masanao Igarashi" . "syoux2@gmail.com")))
