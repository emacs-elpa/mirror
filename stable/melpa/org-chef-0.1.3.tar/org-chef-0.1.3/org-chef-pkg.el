;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-chef" "0.1.3"
  "Cookbook and recipe management with org-mode."
  '((org   "0")
    (emacs "24"))
  :url "https://github.com/Chobbes/org-chef"
  :commit "4d55ba81200c44cd17e9a41259fc07e62ace4c21"
  :revdesc "4d55ba81200c"
  :keywords '("convenience" "abbrev" "outlines" "org" "food" "recipes" "cooking")
  :authors '(("Calvin Beck" . "hobbes@ualberta.ca"))
  :maintainers '(("Calvin Beck" . "hobbes@ualberta.ca")))
