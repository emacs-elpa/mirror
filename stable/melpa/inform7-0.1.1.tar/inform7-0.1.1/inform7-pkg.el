;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inform7" "0.1.1"
  "Major mode for working with Inform 7 files."
  '((emacs "24.3")
    (s     "1.12.0"))
  :url "https://github.com/GuiltyDolphin/inform7-mode"
  :commit "a409bbc6f04264f7f00616a995fa6ecf59d33d0d"
  :revdesc "a409bbc6f042"
  :keywords '("languages")
  :authors '(("Ben Moon" . "software@guiltydolphin.com"))
  :maintainers '(("Ben Moon" . "software@guiltydolphin.com")))
