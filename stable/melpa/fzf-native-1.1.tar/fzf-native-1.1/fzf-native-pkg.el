;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "1.1"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "c20a206ef51d52c65e64716382e230bfac75b056"
  :revdesc "c20a206ef51d"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
