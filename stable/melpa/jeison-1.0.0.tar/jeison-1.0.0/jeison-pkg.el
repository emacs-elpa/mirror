;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jeison" "1.0.0"
  "A library for declarative JSON parsing."
  '((emacs "25.1")
    (dash  "2.16.0"))
  :url "https://github.com/SavchenkoValeriy/jeison"
  :commit "4b68ba9e001594f3e33d98cf89580d0aee02b258"
  :revdesc "4b68ba9e0015"
  :keywords '("lisp" "json" "data-types")
  :authors '(("Valeriy Savchenko" . "sinmipt@gmail.com"))
  :maintainers '(("Valeriy Savchenko" . "sinmipt@gmail.com")))
