;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "retraction-viewer-section" "1.0.6"
  "Show retraction information in the universal-sidecar."
  '((emacs             "25.1")
    (retraction-viewer "1.0.2")
    (universal-sidecar "1.5.1"))
  :url "https://git.sr.ht/~swflint/retraction-viewer"
  :commit "e8ab96e5a95a93849b912e2684b9776c685ac4bd"
  :revdesc "v1.0.6-0-ge8ab96e5a95a"
  :keywords '("bib" "tex")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
