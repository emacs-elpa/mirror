;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpt" "3.0"
  "Run instruction-following language models."
  '((emacs "28.1"))
  :url "https://github.com/stuhlmueller/gpt.el"
  :commit "e638892bbffe89c4675e8cc14bf7406decf6758e"
  :revdesc "e638892bbffe"
  :keywords '("openai" "anthropic" "claude" "language" "copilot" "convenience" "tools")
  :authors '(("Andreas Stuhlmueller" . "emacs@stuhlmueller.org"))
  :maintainers '(("Andreas Stuhlmueller" . "emacs@stuhlmueller.org")))
