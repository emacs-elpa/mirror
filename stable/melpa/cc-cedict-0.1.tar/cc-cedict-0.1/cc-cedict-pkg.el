;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cc-cedict" "0.1"
  "Interface to CC-CEDICT (a Chinese-English dictionary)."
  '((emacs "24.4"))
  :url "https://github.com/xuchunyang/cc-cedict.el"
  :commit "3776614543864588874ca0cf0a43675e059a5195"
  :revdesc "377661454386"
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
