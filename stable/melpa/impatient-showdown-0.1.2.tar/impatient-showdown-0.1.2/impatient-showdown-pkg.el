;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "impatient-showdown" "0.1.2"
  "Preview markdown buffer live over HTTP using showdown."
  '((emacs          "24.3")
    (impatient-mode "1.1"))
  :url "https://github.com/jcs-elpa/impatient-showdown"
  :commit "b0c2da8e5936809f534c055beb6540b4f8721ed4"
  :revdesc "b0c2da8e5936"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
