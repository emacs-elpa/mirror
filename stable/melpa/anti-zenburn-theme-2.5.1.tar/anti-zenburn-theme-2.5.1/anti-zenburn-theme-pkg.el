;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anti-zenburn-theme" "2.5.1"
  "Low-contrast Zenburn-inverted theme."
  ()
  :url "https://github.com/m00natic/anti-zenburn-theme"
  :commit "c80cc51bb1aaf11dd53b9d08e01d61bc9b32622f"
  :revdesc "c80cc51bb1aa"
  :authors '(("Andrey Kotlarski" . "m00naticus@gmail.com"))
  :maintainers '(("Andrey Kotlarski" . "m00naticus@gmail.com")))
