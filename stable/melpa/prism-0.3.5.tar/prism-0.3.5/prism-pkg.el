;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prism" "0.3.5"
  "Customizable, depth-based syntax coloring."
  '((emacs  "27.1")
    (compat "29.1.4.5")
    (dash   "2.14.1"))
  :url "https://github.com/alphapapa/prism.el"
  :commit "3a61852dd01c738dc18b88a7be524db67a2d5520"
  :revdesc "v0.3.5-0-g3a61852dd01c"
  :keywords '("faces" "lisp")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
