;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pos-tip" "0.3"
  "Display Flycheck errors in GUI tooltips."
  '((emacs    "24.1")
    (flycheck "0.22")
    (pos-tip  "0.4.6"))
  :url "https://github.com/flycheck/flycheck-pos-tip"
  :commit "3f1d5297fdff44a14ee624160eefdc678e2bd0bd"
  :revdesc "0.3-0-g3f1d5297fdff"
  :keywords '("tools" "convenience")
  :authors '(("Akiha Senda" . "senda.akiha@gmail.com")
             ("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
