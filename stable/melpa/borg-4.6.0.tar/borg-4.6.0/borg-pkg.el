;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.6.0"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "a83fbcfa6bf519a318b3c443c2defff20a671335"
  :revdesc "v4.6.0-0-ga83fbcfa6bf5"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
