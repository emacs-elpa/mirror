;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nushell-mode" "0.1.0"
  "Major mode for nushell scripts."
  '((emacs "24"))
  :url "https://github.com/azzamsa/emacs-nushell"
  :commit "ae3f530ccd75f8212aa70d6845129a9cd123996d"
  :revdesc "ae3f530ccd75"
  :keywords '("nushell" "shell")
  :authors '(("Azzam S.A" . "vcs@azzamsa.com"))
  :maintainers '(("Azzam S.A" . "vcs@azzamsa.com")))
