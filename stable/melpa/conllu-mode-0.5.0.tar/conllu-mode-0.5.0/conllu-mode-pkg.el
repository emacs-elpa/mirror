;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conllu-mode" "0.5.0"
  "Editing mode for CoNLL-U files."
  '((emacs    "25")
    (cl-lib   "0.5")
    (flycheck "30")
    (hydra    "0.13.0")
    (s        "1.0"))
  :url "https://github.com/odanoburu/conllu-mode"
  :commit "d1b5b682e0a481ab74caed20bbca6177edb83080"
  :revdesc "d1b5b682e0a4"
  :keywords '("extensions")
  :authors '(("bruno cuconato" . "bcclaro+emacs@gmail.com"))
  :maintainers '(("bruno cuconato" . "bcclaro+emacs@gmail.com")))
