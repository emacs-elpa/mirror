;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitlab-pipeline" "1.1.0"
  "Get infomation about Gitlab pipelines."
  '((emacs "25.1")
    (ghub  "3.3.0"))
  :url "https://github.com/TxGVNN/gitlab-pipeline"
  :commit "078f72d52e840907aa4c568468ce25758f20eb15"
  :revdesc "078f72d52e84"
  :keywords '("comm" "tools" "git")
  :authors '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers '(("Giap Tran" . "txgvnn@gmail.com")))
