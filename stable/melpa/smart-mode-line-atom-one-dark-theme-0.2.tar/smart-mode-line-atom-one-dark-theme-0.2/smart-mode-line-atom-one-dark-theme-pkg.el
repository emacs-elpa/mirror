;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-mode-line-atom-one-dark-theme" "0.2"
  "Atom-one-dark theme for smart-mode-line."
  '((emacs           "24.3")
    (smart-mode-line "2.10"))
  :url "https://github.com/daviderestivo/emacs-config/blob/master/themes/smart-mode-line-atom-one-dark-theme.el"
  :commit "014a380e1ac413d13c1013725207658c3978f431"
  :revdesc "014a380e1ac4"
  :keywords '("modeline" "theme")
  :authors '(("Davide Restivo" . "davide.restivo@yahoo.it"))
  :maintainers '(("Davide Restivo" . "davide.restivo@yahoo.it")))
