;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "light-soap-theme" "0.1"
  "Emacs 24 theme with a light background."
  '((emacs "24"))
  :url "https://github.com/mswift42/light-soap-theme"
  :commit "343a3b85a64422df943382ad3c3d125bf9216a16"
  :revdesc "343a3b85a644")
