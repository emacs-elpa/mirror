;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-html-bootstrap" "0.9.3"
  "Auto complete bootstrap3/fontawesome classes for `ac-html' and `company-web'."
  '((web-completion-data "0.1"))
  :url "https://github.com/osv/ac-html-bootstrap"
  :commit "591e1e996c820da218ea1eee0a500c556769f128"
  :revdesc "591e1e996c82"
  :keywords '("html" "auto-complete" "bootstrap" "cssx")
  :authors '(("Olexandr Sydorchuk" . "olexandr.syd@gmail.com"))
  :maintainers '(("Olexandr Sydorchuk" . "olexandr.syd@gmail.com")))
