;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-tramp" "1.0.0"
  "Group ibuffer's list by TRAMP connection."
  ()
  :url "https://github.com/svend/ibuffer-tramp"
  :commit "bcad0bda3a67f55d1be936bf8fa9ef735fe1e3f3"
  :revdesc "1.0.0-0-gbcad0bda3a67"
  :keywords '("convenience")
  :authors '(("Svend Sorensen" . "svend@ciffer.net"))
  :maintainers '(("Svend Sorensen" . "svend@ciffer.net")))
