;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-sets" "3.8.1"
  "Sets of Buffers for Buffer Management."
  '((cl-lib "0.5"))
  :url "https://git.sr.ht/~swflint/buffer-sets"
  :commit "9c30f12feaa4182d845b70c5be459a07d3be5db3"
  :revdesc "9c30f12feaa4"
  :keywords '("buffer-management")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
