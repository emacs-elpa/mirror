;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "environ" "0.0.1"
  "API for environment variables and env files."
  '((emacs "24.1")
    (dash  "2.17.0")
    (f     "0.20.0")
    (s     "1.12.0"))
  :url "https://github.com/cfclrk/env"
  :commit "03e367b8887713be2662ede872bb9bb300bd7bbb"
  :revdesc "03e367b88877"
  :keywords '("environment")
  :authors '(("Chris Clark" . "cfclrk@gmail.com"))
  :maintainers '(("Chris Clark" . "cfclrk@gmail.com")))
