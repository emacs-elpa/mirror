;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "contextual" "1.0.1"
  "Contextual profile management system."
  '((emacs  "24")
    (dash   "2.12.1")
    (cl-lib "0.5"))
  :url "https://github.com/lshift-de/contextual"
  :commit "8134a2d8034c624f4fdbbb0b3893de12f4257909"
  :revdesc "1.0.1-0-g8134a2d8034c"
  :keywords '("convenience" "tools")
  :authors '(("Alexander Kahl" . "alex@lshift.de"))
  :maintainers '(("Alexander Kahl" . "alex@lshift.de")))
