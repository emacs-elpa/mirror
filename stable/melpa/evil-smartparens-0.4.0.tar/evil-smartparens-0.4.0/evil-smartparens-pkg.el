;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-smartparens" "0.4.0"
  "Evil support for smartparens."
  '((evil        "1.0")
    (emacs       "24.4")
    (smartparens "1.10.1"))
  :url "https://www.github.com/expez/evil-smartparens"
  :commit "9fe4eed1c6327197afe6c13bb0771e18908aff00"
  :revdesc "0.4.0-0-g9fe4eed1c632"
  :keywords '("evil" "smartparens")
  :authors '(("Lars Andersen" . "expez@expez.com"))
  :maintainers '(("Lars Andersen" . "expez@expez.com")))
