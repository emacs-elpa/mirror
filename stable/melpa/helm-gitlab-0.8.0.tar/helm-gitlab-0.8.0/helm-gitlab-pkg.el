;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-gitlab" "0.8.0"
  "Helm interface to Gitlab."
  '((s      "1.9.0")
    (dash   "2.9.0")
    (helm   "1.0")
    (gitlab "0.8.0"))
  :url "https://github.com/nlamirault/emacs-gitlab"
  :commit "a1c1441ff5ffb290e695eb9ac05431e9385578f4"
  :revdesc "a1c1441ff5ff"
  :keywords '("gitlab" "helm")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
