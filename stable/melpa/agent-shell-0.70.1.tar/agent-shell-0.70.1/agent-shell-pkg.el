;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.70.1"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.96.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d9adb2a2668af351e654f29503b0018f31e79f95"
  :revdesc "d9adb2a2668a")
