;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-assist" "1.0"
  "Minibuffer keybinding cheatsheet and launcher."
  '((emacs "24.3"))
  :url "https://github.com/Boruch-Baum/emacs-key-assist"
  :commit "dda02615b45a86c806d61e0484e08aa51343f8d8"
  :revdesc "dda02615b45a"
  :keywords '("abbrev" "convenience" "docs" "help")
  :authors '(("Boruch Baum" . "boruch_baum@gmx.com"))
  :maintainers '(("Boruch Baum" . "boruch_baum@gmx.com")))
