;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corg" "0.2.1"
  "Header completion for org-mode."
  '((emacs  "27.1")
    (s      "1.13.1")
    (compat "30"))
  :url "https://github.com/isamert/corg.el"
  :commit "0eeb4255b0c47a1e3c46513ae3fa2ffe749400b8"
  :revdesc "v0.2.1-0-g0eeb4255b0c4"
  :keywords '("abbrev" "convenience" "completion" "matching")
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
