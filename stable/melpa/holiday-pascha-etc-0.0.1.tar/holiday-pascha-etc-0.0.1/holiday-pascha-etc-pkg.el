;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "holiday-pascha-etc" "0.0.1"
  "Eastern Christian analog to emacs' holiday-easter-etc."
  ()
  :url "https://github.com/hexmode/holiday-pascha-etc"
  :commit "38562a26034848937a2c757e00f38883a8196f2e"
  :revdesc "38562a260348"
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
