;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-mc" "0.0.3"
  "Multiple cursors for evil-mode."
  '((emacs  "24.3")
    (evil   "1.2.12")
    (cl-lib "0.5"))
  :url "https://github.com/gabesoft/evil-mc"
  :commit "be2259b8cedd62011b25ddbcc1774bbbe9a66c61"
  :revdesc "be2259b8cedd"
  :keywords '("evil" "editing" "multiple-cursors" "vim" "evil-multiple-cursors" "evil-mc" "evil-mc")
  :authors '(("Gabriel Adomnicai" . "gabesoft@gmail.com"))
  :maintainers '(("Gabriel Adomnicai" . "gabesoft@gmail.com")))
