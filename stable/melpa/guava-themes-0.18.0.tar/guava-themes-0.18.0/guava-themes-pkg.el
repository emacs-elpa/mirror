;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "0.18.0"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "92ed6ba6c117ce52137fae975e6c73aa1ff3ed62"
  :revdesc "v0.18.0-0-g92ed6ba6c117"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
