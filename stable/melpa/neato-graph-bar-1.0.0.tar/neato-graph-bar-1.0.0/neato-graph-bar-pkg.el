;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neato-graph-bar" "1.0.0"
  "Neat-o graph bars for Emacs."
  '((cl-lib "0"))
  :url "https://gitlab.com/RobertCochran/neato-graph-bar"
  :commit "01e6667fe3d2dbfe38e3e89ffb72d63a6da29f21"
  :revdesc "01e6667fe3d2"
  :authors '(("Robert Cochran" . "robert-git@cochranmail.com."))
  :maintainers '(("Robert Cochran" . "robert-git@cochranmail.com.")))
