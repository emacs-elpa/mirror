;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insfactor" "0.2.0"
  "Client for a Clojure project with insfactor in it."
  ()
  :url "https://github.com/duelinmarkers/insfactor.el"
  :commit "ff4a69aa117940ec81db3e36742e0cf208de810a"
  :revdesc "ff4a69aa1179"
  :keywords '("clojure")
  :authors '(("John D. Hume" . "duelin.markers@gmail.com"))
  :maintainers '(("John D. Hume" . "duelin.markers@gmail.com")))
