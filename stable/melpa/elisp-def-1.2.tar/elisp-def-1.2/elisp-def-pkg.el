;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-def" "1.2"
  "Macro-aware go-to-definition for elisp."
  '((dash  "2.12.0")
    (f     "0.19.0")
    (s     "1.11.0")
    (emacs "24.3"))
  :url "https://github.com/Wilfred/elisp-def"
  :commit "37260b2edd738f27d7d256cd9383888d24d84a3d"
  :revdesc "37260b2edd73"
  :keywords '("lisp")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
