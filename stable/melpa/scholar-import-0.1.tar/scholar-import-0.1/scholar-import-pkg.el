;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scholar-import" "0.1"
  "Import Bibtex & PDF from Google Scholar."
  '((emacs   "26.1")
    (org     "9.0")
    (request "0.3.2"))
  :url "https://github.com/teeann/scholar-import"
  :commit "3c9cdf8712609f904f0c24c90b50e2d487b45039"
  :revdesc "3c9cdf871260"
  :authors '(("Anh T Nguyen" . "https://github.com/teeann"))
  :maintainers '(("Anh T Nguyen" . "https://github.com/teeann")))
