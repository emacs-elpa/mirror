;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selcand" "2.0"
  "Select a candidate from a tree of hint characters."
  '((emacs "25.1"))
  :url "https://github.com/erjoalgo/selcand"
  :commit "b6fc231a784df570df0f817d34f926f141a65126"
  :revdesc "v2.0-0-gb6fc231a784d"
  :keywords '("lisp" "completing-read" "prompt" "combinations" "vimium")
  :maintainers '(("concat \"erjoalgo\" \"@\" \"gmail\" \".com\"" . "")))
