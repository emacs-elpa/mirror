;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guide-key" "1.2.5"
  "Guide the following key bindings automatically and dynamically."
  '((popwin "0.3.0"))
  :url "https://github.com/kai2nenobu/guide-key"
  :commit "626f3aacfe4561eddc46617570426246b88e9cab"
  :revdesc "v1.2.5-0-g626f3aacfe45"
  :keywords '("help" "convenience")
  :authors '(("Tsunenobu Kai" . "kai2nenobu@gmail.com"))
  :maintainers '(("Tsunenobu Kai" . "kai2nenobu@gmail.com")))
