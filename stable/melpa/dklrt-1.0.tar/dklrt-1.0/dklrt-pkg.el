;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dklrt" "1.0"
  "Ledger Recurring Transactions."
  '((dkmisc      "0.50")
    (ledger-mode "20130908.1357")
    (emacs       "24.1"))
  :url "https://github.com/davidkeegan/dklrt"
  :commit "2bc5ef02d21fc6afb63cac173f1fc5613b71bbbf"
  :revdesc "2bc5ef02d21f"
  :keywords '("ledger" "ledger-cli" "recurring" "periodic" "automatic")
  :authors '(("David Keegan" . "dksw@eircom.net"))
  :maintainers '(("David Keegan" . "dksw@eircom.net")))
