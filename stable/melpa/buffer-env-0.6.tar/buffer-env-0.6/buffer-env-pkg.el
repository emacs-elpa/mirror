;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-env" "0.6"
  "Buffer-local process environments."
  '((emacs  "27.1")
    (compat "29.1"))
  :url "https://github.com/astoff/buffer-env"
  :commit "3814bdf3585ffffea3014b1d01549894ec1aa897"
  :revdesc "3814bdf3585f"
  :keywords '("processes" "tools")
  :authors '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers '(("Augusto Stoffel" . "arstoffel@gmail.com")))
