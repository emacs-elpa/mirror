;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-operators" "0.1"
  "A face for operators in programming modes."
  ()
  :url "https://github.com/jpkotta/highlight-operators"
  :commit "a5660a261d7d10d0327f47604fba38a49d746b70"
  :revdesc "a5660a261d7d"
  :authors '(("Jonathan Kotta" . "jpkotta@gmail.com"))
  :maintainers '(("Jonathan Kotta" . "jpkotta@gmail.com")))
