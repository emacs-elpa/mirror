;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hide-secrets" "0.5"
  "A package for hiding IP addresses and passwords in Emacs buffers."
  '((emacs "29.1"))
  :url "https://gitlab.com/ostseepinguin1/hide-secrets-el"
  :commit "bfe61a933eeba0c9cf330706d6e79f8a0aed1b7f"
  :revdesc "bfe61a933eeb"
  :keywords '("passwords" "secrets" "keys")
  :authors '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainers '(("Sebastian Meisel" . "sebastian.meisel@gmail.com")))
