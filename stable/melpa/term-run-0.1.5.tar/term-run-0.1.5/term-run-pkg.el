;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-run" "0.1.5"
  "Run arbitrary command in terminal buffer."
  ()
  :url "https://github.com/10sr/term-run-el"
  :commit "54650dbbabb13cb2a6c0670ff6b24b29717a6a8b"
  :revdesc "54650dbbabb1"
  :keywords '("utility" "shell" "command" "term-mode")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
