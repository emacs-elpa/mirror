;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "textsize" "3.0"
  "Configure frame text size automatically."
  '((emacs "26.1"))
  :url "https://github.com/WJCFerguson/textsize"
  :commit "df91392c3c928d7841631f5809716b9cf0f7309e"
  :revdesc "3.0-0-gdf91392c3c92"
  :keywords '("convenience")
  :authors '(("James Ferguson" . "james@faff.org"))
  :maintainers '(("James Ferguson" . "james@faff.org")))
