;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "csound-mode" "0.2.1"
  "A major mode for interacting and coding Csound."
  '((emacs     "25")
    (shut-up   "0.3.2")
    (multi     "2.0.1")
    (highlight "0"))
  :url "https://github.com/hlolli/csound-mode"
  :commit "389be230aecfea03e8043e8ea6884ea21ea9230b"
  :revdesc "389be230aecf"
  :authors '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers '(("Hlöðver Sigurðsson" . "hlolli@gmail.com")))
