;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "listenbrainz" "0.1"
  "ListenBrainz API interface."
  '((emacs   "27.1")
    (request "0.3"))
  :url "https://github.com/zzkt/listenbrainz"
  :commit "d1ec6704c7f55517ef355273e4233093f2880450"
  :revdesc "d1ec6704c7f5"
  :keywords '("music" "scrobbling" "multimedia")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
