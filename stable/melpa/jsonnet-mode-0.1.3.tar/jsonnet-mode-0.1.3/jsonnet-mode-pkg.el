;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsonnet-mode" "0.1.3"
  "Major mode for editing jsonnet files."
  '((emacs "24")
    (dash  "2.17.0"))
  :url "https://github.com/mgyucht/jsonnet-mode"
  :commit "54a89b0aaba7a68782008c5e1ab00d5ec757316a"
  :revdesc "54a89b0aaba7"
  :keywords '("languages"))
