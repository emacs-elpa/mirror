;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emaps" "0.2.0"
  "Utilities for working with keymaps."
  '((dash  "2.17.0")
    (emacs "24"))
  :url "https://github.com/GuiltyDolphin/emaps"
  :commit "7c561f3ded2015ed3774e5784059d6601082743e"
  :revdesc "7c561f3ded20"
  :keywords '("convenience" "keyboard" "keymap" "utility")
  :authors '(("Ben Moon" . "software@guiltydolphin.com"))
  :maintainers '(("Ben Moon" . "software@guiltydolphin.com")))
