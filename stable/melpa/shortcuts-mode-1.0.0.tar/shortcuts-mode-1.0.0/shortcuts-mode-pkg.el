;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shortcuts-mode" "1.0.0"
  "[No description available]."
  ()
  :url "https://github.com/tetron/shortcuts-mode"
  :commit "bd1c6c46717270df828275c6940ce82a480d96f8"
  :revdesc "bd1c6c467172"
  :keywords '("lisp")
  :authors '(("Peter Amstutz" . "tetron@interreality.org"))
  :maintainers '(("Peter Amstutz" . "tetron@interreality.org")))
