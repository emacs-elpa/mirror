;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "common-lisp-snippets" "0.1.2"
  "Yasnippets for Common Lisp."
  '((yasnippet "0.8.0"))
  :url "https://github.com/mrkkrp/common-lisp-snippets"
  :commit "fc5c2683952328927a6d1c1f2694b85ddf7e9053"
  :revdesc "fc5c26839523"
  :keywords '("snippets")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
