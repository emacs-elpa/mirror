;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "0.3"
  "Scheme Requests for Implementation browser."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "98b8b1f9edd4ce6a05eeef49bed0d1966bd7c528"
  :revdesc "0.3-0-g98b8b1f9edd4"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
