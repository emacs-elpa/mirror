;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "northcode-theme" "0.1"
  "A dark theme for emacs focused on blue and orange colors."
  '((emacs "23"))
  :url "https://github.com/Northcode/northcode-theme.el"
  :commit "30cc3d021f00de3e8a520eb352f50c2cd016430e"
  :revdesc "30cc3d021f00"
  :authors '(("Andreas Larsen" . "andreas@northcode.no"))
  :maintainers '(("Andreas Larsen" . "andreas@northcode.no")))
