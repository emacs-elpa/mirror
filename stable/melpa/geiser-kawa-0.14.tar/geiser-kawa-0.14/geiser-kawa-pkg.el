;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-kawa" "0.14"
  "Kawa scheme support for Geiser."
  '((emacs  "26.1")
    (geiser "0.11.2"))
  :url "https://gitlab.com/spellcard199/geiser-kawa"
  :commit "f76b53dbc1465dbd799e29bdcd2be34cc1603f50"
  :revdesc "f76b53dbc146"
  :keywords '("languages" "kawa" "scheme" "geiser")
  :authors '(("spellcard199" . "spellcard199@protonmail.com"))
  :maintainers '(("spellcard199" . "spellcard199@protonmail.com")))
