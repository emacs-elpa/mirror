;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient-extras" "0.0.1"
  "[No description available]."
  ()
  :url "https://github.com/haji-ali/lp-transient"
  :commit "e63a2d1db478de93eb9ac698a4db6b783cb15bdc"
  :revdesc "e63a2d1db478"
  :keywords '("transient" "gui")
  :authors '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com")
             ("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com")
                 ("Samuel W. Flint" . "swflint@flintfam.org")))
