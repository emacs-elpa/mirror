;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tangotango-theme" "0.0.5"
  "Tango Palette color theme for Emacs 24."
  ()
  :url "https://github.com/juba/color-theme-tangotango"
  :commit "fad0fa589a2086571589c74905fa23591777c250"
  :revdesc "fad0fa589a20"
  :keywords '("tango" "palette" "color" "theme" "emacs"))
