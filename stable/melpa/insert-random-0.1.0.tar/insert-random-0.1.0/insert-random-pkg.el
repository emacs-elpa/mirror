;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insert-random" "0.1.0"
  "Insert random characters from various character sets."
  '((emacs "24.5"))
  :url "https://github.com/lassik/emacs-insert-random"
  :commit "ba676478d180769b81a7222497e12a4f4ff1331f"
  :revdesc "ba676478d180"
  :keywords '("convenience")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
