;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jump-tree" "20170803.1"
  "Treat position history as a tree."
  ()
  :url "https://github.com/yangwen0228/jump-tree"
  :commit "ceb693f8cb7cdd6860a67c21a9b7457ab640bb1d"
  :revdesc "ceb693f8cb7c"
  :keywords '("convenience" "files" "jump" "tree")
  :authors '(("Wen Yang" . "yangwen0228@foxmail.com"))
  :maintainers '(("Wen Yang" . "yangwen0228@foxmail.com")))
