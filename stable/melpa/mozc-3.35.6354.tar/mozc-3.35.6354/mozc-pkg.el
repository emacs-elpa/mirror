;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc" "3.35.6354"
  "Minor mode to input Japanese with Mozc."
  '((emacs "24.3"))
  :url "https://github.com/google/mozc"
  :commit "0136c35782536cb43d710575c311cd4185982738"
  :revdesc "3.35.6354-0-g0136c3578253"
  :keywords '("mule" "multilingual" "input method"))
