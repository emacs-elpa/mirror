;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dispwatch" "1"
  "Watch displays for configuration changes."
  '((emacs "24.1"))
  :url "https://github.com/mnp/dispwatch"
  :commit "93aac853215d0902e7a30a6dd2b99d796da77df4"
  :revdesc "93aac853215d"
  :keywords '("frames")
  :authors '(("Mitchell Perilstein" . "mitchell.perilstein@gmail.com"))
  :maintainers '(("Mitchell Perilstein" . "mitchell.perilstein@gmail.com")))
