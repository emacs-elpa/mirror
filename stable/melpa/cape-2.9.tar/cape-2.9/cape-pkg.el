;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "2.9"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/cape"
  :commit "f0135abaf95a22b9fb2c951751a5d0733ce61bbd"
  :revdesc "2.9-0-gf0135abaf95a"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
