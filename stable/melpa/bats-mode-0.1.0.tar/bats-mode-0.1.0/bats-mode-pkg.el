;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bats-mode" "0.1.0"
  "Bats mode."
  ()
  :url "https://github.com/dougm/bats-mode"
  :commit "69f532d87b6fe870f854814d58387bea5fd8bce0"
  :revdesc "69f532d87b6f"
  :keywords '("bats" "tests"))
