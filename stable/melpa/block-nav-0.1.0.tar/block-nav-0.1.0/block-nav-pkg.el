;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "block-nav" "0.1.0"
  "Block level navigation for quick jumping."
  '((emacs "25.1"))
  :url "https://github.com/nixin72/block-nav.el"
  :commit "e5efb1384230040f473407b25874b17d2a8357e8"
  :revdesc "e5efb1384230"
  :keywords '("navigation")
  :authors '(("Philip Dumaresq" . "phdumaresq@protonmail.com"))
  :maintainers '(("Philip Dumaresq" . "phdumaresq@protonmail.com")))
