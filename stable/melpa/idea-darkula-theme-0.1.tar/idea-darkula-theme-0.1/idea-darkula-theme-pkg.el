;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idea-darkula-theme" "0.1"
  "Color theme based on IntelliJ IDEA Darkula color theme."
  '((emacs "24.1"))
  :url "https://github.com/fourier/idea-darkula-theme"
  :commit "26104e612996a35d1a2bcb63c39ebf108e3b1fd4"
  :revdesc "26104e612996"
  :keywords '("themes")
  :authors '(("Alexey Veretennikov" . "alexeydotveretennikovatgmaildotcom"))
  :maintainers '(("Alexey Veretennikov" . "alexeydotveretennikovatgmaildotcom")))
