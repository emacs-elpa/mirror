;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jack" "1.0"
  "HTML renderer library."
  '((emacs "26.1"))
  :url "https://github.com/tonyaldon/jack"
  :commit "7e4b1a1c732fdc8ccda4bb78c0aa8697bdf43491"
  :revdesc "7e4b1a1c732f"
  :keywords '("lisp" "html")
  :authors '(("Tony Aldon" . "tony.aldon.adm@gmail.com"))
  :maintainers '(("Tony Aldon" . "tony.aldon.adm@gmail.com")))
