;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chyla-dark-theme" "0.1"
  "Chyla.org - green color theme."
  ()
  :url "https://github.com/chyla/ChylaThemeForEmacs"
  :commit "e0d532ade45836cfc30120447c32a28b884dbbb3"
  :revdesc "e0d532ade458"
  :authors '(("Adam Chyła https://chyla.org/" . "adam@chyla.org"))
  :maintainers '(("Adam Chyła https://chyla.org/" . "adam@chyla.org")))
