;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rotate" "0.1.0"
  "Rotate the layout of emacs."
  ()
  :url "https://github.com/daic-h/emacs-rotate"
  :commit "868122fa807db32762a68defcf69654a28a5a39f"
  :revdesc "868122fa807d"
  :keywords '("window" "layout")
  :authors '(("daichi.hirata" . "daichi.hiratatgmail.com"))
  :maintainers '(("daichi.hirata" . "daichi.hiratatgmail.com")))
