;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "runtests" "1.0.0"
  "Run unit tests from Emacs."
  ()
  :url "https://github.com/sunesimonsen/emacs-runtests"
  :commit "eef7136886ce5843c3e27187830c06d13d992e5c"
  :revdesc "eef7136886ce"
  :keywords '("test")
  :authors '(("Sune Simonsen" . "sune@we-knowhow.dk"))
  :maintainers '(("Sune Simonsen" . "sune@we-knowhow.dk")))
