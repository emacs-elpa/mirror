;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nightpanel-theme" "0.1.0"
  "Saab instrument cluster colorscheme."
  '((emacs "27.1"))
  :url "https://github.com/gregfelice/nightpanel-theme"
  :commit "c4237f578c86dc473116fdd65a88764f4f03e7b1"
  :revdesc "v0.1.0-0-gc4237f578c86"
  :keywords '("faces" "theme")
  :authors '(("Greg Felice" . "gregfelice@gmail.com"))
  :maintainers '(("Greg Felice" . "gregfelice@gmail.com")))
