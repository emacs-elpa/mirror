;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grab-x-link" "0.5"
  "Grab links from X11 apps and insert into Emacs."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/xuchunyang/grab-x-link"
  :commit "d19f0c0da0ddc55005a4c1cdc2b8c5de8bea1e8c"
  :revdesc "d19f0c0da0dd"
  :keywords '("hyperlink")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
