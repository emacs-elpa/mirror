;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yml" "0.1.4"
  "Fast YAML parser (dynamic module)."
  '((emacs "26.1"))
  :url "https://github.com/isamert/yml.el"
  :commit "771ec134eb58658db0e42f7ead647984294b3afb"
  :revdesc "v0.1.4-0-g771ec134eb58"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
