;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gotham-theme" "1.1.9"
  "A very dark Emacs color theme."
  '((emacs "24.1"))
  :url "https://depp.brause.cc/gotham-theme"
  :commit "4b8214df0851bb69b44c3e864568b7e0030a95d2"
  :revdesc "4b8214df0851"
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
