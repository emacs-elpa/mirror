;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-movies" "0.1"
  "Manage watchlist with Org mode."
  '((emacs   "26.1")
    (org     "9.0")
    (request "0.3.0"))
  :url "https://github.com/teeann/org-movies"
  :commit "e96fecaffa2924de64a507aa31d2934e667ee1ea"
  :revdesc "e96fecaffa29"
  :keywords '("hypermedia" "outlines" "org"))
