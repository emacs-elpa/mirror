;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redis" "0.1"
  "Redis integration."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/emacs-pe/redis.el"
  :commit "63bd5d87c3dbcbc872295a20bfdbc39c24663dae"
  :revdesc "63bd5d87c3db"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
