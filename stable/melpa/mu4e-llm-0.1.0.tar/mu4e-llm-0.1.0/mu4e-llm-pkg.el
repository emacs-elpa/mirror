;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-llm" "0.1.0"
  "AI-powered email assistance for mu4e."
  '((emacs "28.1")
    (llm   "0.17"))
  :url "https://github.com/sillyfellow/mu4e-llm"
  :commit "80cd1e86f12bbbbe6c8f05406079e0955104a168"
  :revdesc "v0.1.0-0-g80cd1e86f12b"
  :keywords '("mail" "convenience")
  :authors '(("Dr. Sandeep Sadanandan" . "sands@kotaico.de"))
  :maintainers '(("Dr. Sandeep Sadanandan" . "sands@kotaico.de")))
