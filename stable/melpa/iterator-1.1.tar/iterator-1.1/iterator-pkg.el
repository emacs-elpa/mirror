;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iterator" "1.1"
  "A library to create and use elisp iterators objects."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/thierryvolpiatto/iterator"
  :commit "6b35a827599f303a1cf0ebe2b4494d29396b084b"
  :revdesc "6b35a827599f"
  :authors '(("Thierry Volpiatto" . "thierrydotvolpiattoatgmaildotcom"))
  :maintainers '(("Thierry Volpiatto" . "thierrydotvolpiattoatgmaildotcom")))
