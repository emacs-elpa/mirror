;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "memento-mori" "0.3.1"
  "Reminder of our mortality."
  '((emacs "24.3"))
  :url "https://github.com/gvol/emacs-memento-mori"
  :commit "5dce0fcd3a2c2becf72e8691d0f66e851b8597a1"
  :revdesc "5dce0fcd3a2c"
  :keywords '("help")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Ivan Andrus" . "darthandrus@gmail.com")))
