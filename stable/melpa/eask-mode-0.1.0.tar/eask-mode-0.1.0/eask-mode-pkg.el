;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask-mode" "0.1.0"
  "Major mode for editing Eask files."
  '((emacs "24.3"))
  :url "https://github.com/emacs-eask/eask-mode"
  :commit "8925f1bd998d1297ebd93278add0be0b809e473c"
  :revdesc "8925f1bd998d"
  :keywords '("lisp" "eask")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
