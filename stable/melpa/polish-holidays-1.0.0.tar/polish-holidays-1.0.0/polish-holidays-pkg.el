;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "polish-holidays" "1.0.0"
  "Polish holidays for Emacs calendar."
  ()
  :url "https://github.com/przemarbor/polish-holidays"
  :commit "b6c5d486d534c730fc315e8a1d9c815daf93e84d"
  :revdesc "b6c5d486d534"
  :keywords '("calendar"))
