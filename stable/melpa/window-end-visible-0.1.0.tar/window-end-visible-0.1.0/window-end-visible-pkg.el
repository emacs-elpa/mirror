;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "window-end-visible" "0.1.0"
  "Find the last visible point in a window."
  ()
  :url "https://github.com/rolandwalker/window-end-visible"
  :commit "bdc3d182e5f76e75f1b8cc49357194b36e48b67c"
  :revdesc "v0.1.0-0-gbdc3d182e5f7"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
