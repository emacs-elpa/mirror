;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "opencl-c-mode" "2.0"
  "Syntax coloring for opencl kernels."
  ()
  :url "https://github.com/salmanebah/opencl-mode"
  :commit "204d5d9e0f5cb2cbe810f2933230eb08fe2c7695"
  :revdesc "204d5d9e0f5c"
  :keywords '("c" "opencl")
  :authors '(("Salmane Bah" . "salmane.bah~at~u-bordeaux.fr")
             ("Gustaf Waldemarson" . "gustaf.waldemarson~at~gmail.com"))
  :maintainers '(("Salmane Bah" . "salmane.bah~at~u-bordeaux.fr")
                 ("Gustaf Waldemarson" . "gustaf.waldemarson~at~gmail.com")))
