;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ts-comint" "0.0.1"
  "Run a JavaScript interpreter in an inferior process window."
  ()
  :url "https://github.com/josteink/ts-comint"
  :commit "ba87e3ce3aa5929596b1e87e455e67800920d0c8"
  :revdesc "ba87e3ce3aa5"
  :keywords '("javascript" "node" "inferior-mode" "convenience")
  :authors '(("Paul Huff" . "paul.huff@gmail.com")
             ("Stefano Mazzucco" . "MYFIRSTNAME-AT-CURSO-DOT-RE"))
  :maintainers '(("Paul Huff" . "paul.huff@gmail.com")
                 ("Stefano Mazzucco" . "MYFIRSTNAME-AT-CURSO-DOT-RE")))
