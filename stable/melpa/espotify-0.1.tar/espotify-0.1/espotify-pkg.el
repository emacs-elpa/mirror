;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "espotify" "0.1"
  "Spotify access library."
  '((emacs "26.1"))
  :url "https://codeberg.org/jao/espotify"
  :commit "a8608fd7b31e5896356d4a3ccbbd8062686ea2af"
  :revdesc "a8608fd7b31e"
  :keywords '("media")
  :authors '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
