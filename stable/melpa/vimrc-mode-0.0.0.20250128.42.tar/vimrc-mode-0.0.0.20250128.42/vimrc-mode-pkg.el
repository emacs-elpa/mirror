;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vimrc-mode" "0.0.0.20250128.42"
  "Major mode for vimrc files."
  '((emacs "24.3"))
  :url "https://github.com/mcandre/vimrc-mode"
  :commit "f594392a0834193a1fe1522d007e1c8ce5b68e43"
  :revdesc "f594392a0834"
  :keywords '("languages" "vim")
  :authors '(("Alpha Tan" . "alphatan.zh@gmail.com"))
  :maintainers '(("Alpha Tan" . "alphatan.zh@gmail.com")))
