;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-capitalize" "3.1.2"
  "Automatic capitalization with batteries included."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/abdulnafe-t/auto-capitalize.el"
  :commit "cffa2bf3055603e836dabb71932d23d9fde6f3c3"
  :revdesc "cffa2bf30556"
  :keywords '("text" "wp" "convenience")
  :maintainers '(("Abdulnafé Toulaïmat" . "abdulnafe.toulaimat@gmail.com")))
