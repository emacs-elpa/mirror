;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ink-mode" "0.3.2"
  "Major mode for writing interactive fiction in Ink."
  '((emacs "26.1"))
  :url "https://github.com/Kungsgeten/ink-mode"
  :commit "71d215712067729eb92e766a3b2067e7f3254183"
  :revdesc "71d215712067"
  :keywords '("languages" "wp" "hypermedia"))
