;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-window" "0.6"
  "Vim-like window controlling plugin."
  ()
  :url "https://github.com/dryman/smart-window.el"
  :commit "622646bbe8fc17a72a4b924c8226a2ae64f37e43"
  :revdesc "622646bbe8fc"
  :keywords '("window")
  :authors '(("Felix Chern" . "idryman@gmail.com"))
  :maintainers '(("Felix Chern" . "idryman@gmail.com")))
