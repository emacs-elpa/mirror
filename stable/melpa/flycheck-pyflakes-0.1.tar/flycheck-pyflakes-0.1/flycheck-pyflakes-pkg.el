;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pyflakes" "0.1"
  "Support pyflakes in flycheck."
  ()
  :url "https://github.com/Wilfred/flycheck-pyflakes"
  :commit "92f2b19c951a2dbc2139627b32135d95be094b66"
  :revdesc "92f2b19c951a"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
