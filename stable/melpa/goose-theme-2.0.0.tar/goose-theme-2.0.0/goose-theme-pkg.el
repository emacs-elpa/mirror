;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goose-theme" "2.0.0"
  "A gray color theme for Emacs."
  '((emacs "24.1"))
  :url "https://github.com/thwg/goose-theme"
  :commit "a0633ec702998cc078594d2141100ed0b28ab891"
  :revdesc "a0633ec70299"
  :authors '(("Stephen Whipple" . "shw@wicdmedia.org"))
  :maintainers '(("Stephen Whipple" . "shw@wicdmedia.org")))
