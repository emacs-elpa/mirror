;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "1.11.4"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "1558ad1a24702b8d91c9c4ce8c81058611dfcc71"
  :revdesc "1558ad1a2470"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
