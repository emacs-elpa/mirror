;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-projectile" "0.1.1"
  "Go add-ons for Projectile."
  '((projectile "0.10.0")
    (go-mode    "0")
    (go-eldoc   "0.16")
    (go-rename  "0")
    (go-guru    "0"))
  :url "https://github.com/dougm/go-projectile"
  :commit "0c36c5abd1510a2b35bab2b8b36fcd4a26a8d05c"
  :revdesc "0c36c5abd151"
  :keywords '("project" "convenience")
  :authors '(("Doug MacEachern" . "dougm@vmware.com"))
  :maintainers '(("Doug MacEachern" . "dougm@vmware.com")))
