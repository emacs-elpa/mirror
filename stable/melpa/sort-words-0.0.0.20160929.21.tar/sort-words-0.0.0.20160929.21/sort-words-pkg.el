;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sort-words" "0.0.0.20160929.21"
  "Sort words in a selected region."
  ()
  :url "http://github.org/dotemacs/sort-words.el"
  :commit "7b6e108f80237363faf7ec28b2c58dec270b8601"
  :revdesc "7b6e108f8023"
  :keywords '("tools")
  :authors '(("Aleksandar Simic" . "asimic@gmail.com"))
  :maintainers '(("Aleksandar Simic" . "asimic@gmail.com")))
