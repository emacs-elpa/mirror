;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indian-ext" "0.1"
  "Extension to Indian language utilities."
  '((emacs "24"))
  :url "https://github.com/paddymcall/indian-ext"
  :commit "a5450fe467393194bc2458c0d5e0a06c91bf117a"
  :revdesc "a5450fe46739"
  :keywords '("i18n" "tools" "wp" "indian" "devanagari" "encoding")
  :authors '(("Patrick McAllister" . "pma@rdorte.org"))
  :maintainers '(("Patrick McAllister" . "pma@rdorte.org")))
