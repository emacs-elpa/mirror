;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-get" "5.2"
  "Manage the external elisp bits and pieces you depend upon."
  ()
  :url "http://www.emacswiki.org/emacs/el-get"
  :commit "ec3b0a052bf2f90f30c51042ddb06471b35c7ab6"
  :revdesc "5.2-0-gec3b0a052bf2"
  :keywords '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
