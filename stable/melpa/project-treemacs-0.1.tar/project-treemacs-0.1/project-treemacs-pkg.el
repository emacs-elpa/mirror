;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-treemacs" "0.1"
  "Project.el backend for treemacs."
  '((emacs    "28.1")
    (treemacs "3.1"))
  :url "https://github.com/cmccloud/project-treemacs"
  :commit "9f9c1562bae063b3c5c78fe06ece144f0dc9f9e8"
  :revdesc "9f9c1562bae0")
