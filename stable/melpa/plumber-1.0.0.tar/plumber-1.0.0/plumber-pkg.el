;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plumber" "1.0.0"
  "Run different commands depending on the text format."
  ()
  :url "https://github.com/8dcc/plumber.el"
  :commit "c9b09639bf6f6f5d67c70d55f16586eebdc76937"
  :revdesc "c9b09639bf6f"
  :authors '(("8dcc" . "8dcc.git@gmail.com"))
  :maintainers '(("8dcc" . "8dcc.git@gmail.com")))
