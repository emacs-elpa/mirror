;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatland-theme" "0.1.2"
  "A simple theme for Emacs."
  ()
  :url "https://github.com/gregchapple/flatland-emacs"
  :commit "42a276ea77593dd2d857c25e13ca90da66f6816a"
  :revdesc "42a276ea7759"
  :authors '(("Greg Chapple" . "info@gregchapple.com"))
  :maintainers '(("Greg Chapple" . "info@gregchapple.com")))
