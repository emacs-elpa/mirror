;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-intercept" "0.1"
  "Intercept prefix keys."
  ()
  :url "https://github.com/tarao/key-intercept-el"
  :commit "24376b1aa21eb9da32d105ea172ffbe36d329846"
  :revdesc "24376b1aa21e"
  :keywords '("keyboard")
  :authors '(("INA Lintaro" . "tarao.gnnatgmail.com"))
  :maintainers '(("INA Lintaro" . "tarao.gnnatgmail.com")))
