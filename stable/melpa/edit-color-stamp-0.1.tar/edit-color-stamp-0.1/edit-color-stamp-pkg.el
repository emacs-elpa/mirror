;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-color-stamp" "0.1"
  "Edit a hex color stamp, using a QT or the internal color picker."
  '((es-lib "0.2"))
  :url "https://github.com/sabof/edit-color-stamp"
  :commit "9061c8e8b3f9d527ba82eead9ab845536ce9e9ee"
  :revdesc "9061c8e8b3f9")
