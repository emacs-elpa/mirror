;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prefab" "0.1.1"
  "Integration for project generation tools like cookiecutter."
  '((emacs     "27.1")
    (f         "0.2.0")
    (transient "0.3.7"))
  :url "https://github.com/laurencewarne/prefab.el"
  :commit "e4775959e5410a24f84fa2855b9709fb65fc89b3"
  :revdesc "v0.1.1-0-ge4775959e541")
