;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-org-roam" "0.5.1"
  "Citar/org-roam integration."
  '((emacs    "27.1")
    (org-roam "2.2")
    (citar    "1.2.0"))
  :url "https://github.com/emacs-citar/citar-org-roam"
  :commit "761eed66782fdbb6d65749098caa42ba43e8441d"
  :revdesc "761eed66782f"
  :authors '(("Bruce D'Arcus" . "bdarcus@gmail.com"))
  :maintainers '(("Bruce D'Arcus" . "bdarcus@gmail.com")))
