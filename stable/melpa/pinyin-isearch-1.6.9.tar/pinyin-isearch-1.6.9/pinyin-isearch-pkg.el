;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "1.6.9"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "1ed4218cb50b4de614c11dc41ab6053255271ae7"
  :revdesc "1ed4218cb50b"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
