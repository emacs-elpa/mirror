;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.57.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "a269cce7d1f583a64712a7d7ee2218e728b3e505"
  :revdesc "a269cce7d1f5"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
