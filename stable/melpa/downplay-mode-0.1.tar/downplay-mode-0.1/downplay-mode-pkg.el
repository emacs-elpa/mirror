;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "downplay-mode" "0.1"
  "Focus attention on a region of the buffer."
  ()
  :url "https://github.com/tobias/downplay-mode/"
  :commit "225a4b3ca09e6f463dfdd54941c98b02be8d574c"
  :revdesc "225a4b3ca09e"
  :authors '(("Toby Crawley" . "toby@tcrawley.org"))
  :maintainers '(("Toby Crawley" . "toby@tcrawley.org")))
