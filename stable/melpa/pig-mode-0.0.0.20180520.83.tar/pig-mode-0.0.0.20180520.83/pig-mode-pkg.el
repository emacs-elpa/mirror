;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pig-mode" "0.0.0.20180520.83"
  "Major mode for Pig files."
  ()
  :url "https://github.com/motus/pig-mode"
  :commit "4c6c6e1b1bb719d8adc6c47cc24665f6fe558959"
  :revdesc "4c6c6e1b1bb7")
