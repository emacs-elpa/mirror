;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-books" "0.4.0"
  "Reading list management with Org mode."
  '((org   "9.3")
    (emacs "25"))
  :url "https://github.com/lepisma/org-books"
  :commit "e2670bf571bcdefc71d11206535a3c920a3206c3"
  :revdesc "e2670bf571bc"
  :keywords '("outlines")
  :authors '(("Abhinav Tushar" . "abhinav@lepisma.xyz"))
  :maintainers '(("Abhinav Tushar" . "abhinav@lepisma.xyz")))
