;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mood-line" "3.1.1"
  "A minimal mode line inspired by doom-modeline."
  '((emacs "26.1"))
  :url "https://gitlab.com/jessieh/mood-line"
  :commit "d5b6b5b3552a5b84f4f887e2f805d9e72747fab2"
  :revdesc "d5b6b5b3552a"
  :keywords '("mode-line" "faces")
  :authors '(("Jessie Hildebrandt" . "jessieh.net"))
  :maintainers '(("Jessie Hildebrandt" . "jessieh.net")))
