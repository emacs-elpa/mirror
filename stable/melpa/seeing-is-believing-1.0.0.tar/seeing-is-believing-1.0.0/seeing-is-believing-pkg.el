;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seeing-is-believing" "1.0.0"
  "Minor mode for running the seeing-is-believing ruby gem."
  ()
  :url "https://github.com/jcinnamond/seeing-is-believing"
  :commit "f9f20c1c59ef1c4e87b864e51565a9a9798f42d7"
  :revdesc "f9f20c1c59ef")
