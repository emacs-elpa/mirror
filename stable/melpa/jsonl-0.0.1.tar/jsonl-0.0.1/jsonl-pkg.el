;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsonl" "0.0.1"
  "Utility functions for working with line-delimited JSON."
  '((emacs "25"))
  :url "https://github.com/ebpa/jsonl.el"
  :commit "b135a10a2d53a89d81ccc06d4f5de5fa242b1211"
  :revdesc "b135a10a2d53"
  :keywords '("tools")
  :authors '(("Erik Anderson" . "erik@ebpa.link"))
  :maintainers '(("Erik Anderson" . "erik@ebpa.link")))
