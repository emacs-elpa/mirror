;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daml-lsp" "0.0.0.20261104.20"
  "LSP client definition for daml."
  '((emacs    "29.1")
    (dash     "2.18.0")
    (lsp-mode "7.0"))
  :url "https://github.com/bartfaitamas/daml-mode"
  :commit "9e24743ff1c0c883f2c1b0db90e1acd6bdcb7593"
  :revdesc "9e24743ff1c0"
  :authors '(("Bártfai Tamás" . "tamas@bartfai.dev"))
  :maintainers '(("Bártfai Tamás" . "tamas@bartfai.dev")))
