;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-migemo" "0.1"
  "Migemo plug-in for Ido."
  '((migemo "1.9.1"))
  :url "https://github.com/myuhe/ido-migemo.el"
  :commit "247d2e98e22eb311700bc41138510e79e754eab1"
  :revdesc "247d2e98e22e"
  :keywords '("files")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
