;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "assess" "0.6"
  "Test support functions."
  '((emacs    "24.4")
    (m-buffer "0.15"))
  :url "https://github.com/phillord/assess"
  :commit "5bac045b273623772b6a2d820997d50f7ab4e466"
  :revdesc "5bac045b2736"
  :authors '(("Phillip Lord" . "phillip.lord@russet.org.uk"))
  :maintainers '(("Phillip Lord" . "phillip.lord@russet.org.uk")))
