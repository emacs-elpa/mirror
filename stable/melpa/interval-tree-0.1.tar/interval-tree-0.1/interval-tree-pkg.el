;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "interval-tree" "0.1"
  "Interval tree data structure for 1D range queries."
  ()
  :url "https://github.com/Fuco1/interval-tree"
  :commit "e3deb807f9ed4ac8588b58eb7235ab588b67251c"
  :revdesc "e3deb807f9ed"
  :keywords '("extensions" "data structure")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
