;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-spotify" "0.1.0"
  "Control Spotify with Helm."
  '((json "0.0.0")
    (s    "0.0.0"))
  :url "https://github.com/krisajenkins/helm-spotify"
  :commit "c058970895feac5d184da859998fc96a2ae03f6e"
  :revdesc "c058970895fe"
  :keywords '("helm" "spotify")
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
