;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphql-doc" "0.2.1"
  "GraphQL Documentation Explorer."
  '((emacs   "26.1")
    (request "0.3.2")
    (promise "1.1"))
  :url "https://github.com/ifitzpatrick/graphql-doc.el"
  :commit "6ba7961fc9c5c9818bd60abce6ba9dfef2dad452"
  :revdesc "6ba7961fc9c5")
