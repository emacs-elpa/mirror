;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphql-doc" "0.2.1"
  "GraphQL Documentation Explorer."
  '((emacs   "26.1")
    (request "0.3.2")
    (promise "1.1"))
  :url "https://github.com/ifitzpatrick/graphql-doc.el"
  :commit "333f46bfebba285301c048e78ecb29edad628611"
  :revdesc "333f46bfebba")
