;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark-vc" "0.2"
  "Embark actions for various VC integrations."
  '((emacs       "25.1")
    (code-review "0"))
  :url "https://github.com/elken/embark-vc"
  :commit "9264c6cf0126e3883aecc6d80d995e8968761a0f"
  :revdesc "9264c6cf0126"
  :keywords '("convenience" "matching" "terminals" "tools" "unix" "vc")
  :authors '(("Ellis Kenyő" . "https://github.com/elken"))
  :maintainers '(("Ellis Kenyő" . "me@elken.dev")))
