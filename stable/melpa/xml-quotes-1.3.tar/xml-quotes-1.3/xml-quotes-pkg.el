;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xml-quotes" "1.3"
  "Read quotations from an XML document."
  ()
  :url "https://github.com/ndw/xml-quotes"
  :commit "26db170e80b9295861227cdf970721b12539ed44"
  :revdesc "26db170e80b9"
  :keywords '("xml" "quotations")
  :authors '(("Norman Walsh" . "ndw@nwalsh.com"))
  :maintainers '(("Norman Walsh" . "ndw@nwalsh.com")))
