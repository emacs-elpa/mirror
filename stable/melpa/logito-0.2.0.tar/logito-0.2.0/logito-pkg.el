;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "logito" "0.2.0"
  "Logging library for Emacs."
  '((emacs "25.1"))
  :url "https://github.com/sigma/logito"
  :commit "d5934ce10ba3a70d3fcfb94d742ce3b9136ce124"
  :revdesc "d5934ce10ba3"
  :keywords '("lisp" "extensions")
  :authors '(("Yann Hodique" . "yann.hodique@gmail.com"))
  :maintainers '(("Yann Hodique" . "yann.hodique@gmail.com")))
