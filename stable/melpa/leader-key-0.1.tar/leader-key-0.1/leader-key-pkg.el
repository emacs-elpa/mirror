;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leader-key" "0.1"
  "Leader key configuration for god-mode."
  '((emacs "25.1"))
  :url "https://github.com/havner/leader-key"
  :commit "43b7f1b5f828e87ad31bfef7ceda13a4ad433def"
  :revdesc "43b7f1b5f828"
  :keywords '("keys" "keybinding" "config" "leader" "god" "god-mode")
  :authors '(("ukasz Pawelczyk" . "havner@gmail.com"))
  :maintainers '(("Łukasz Pawelczyk" . "havner@gmail.com")))
