;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typit" "0.3.0"
  "Typing game similar to tests on 10 fast fingers."
  '((emacs "24.4")
    (f     "0.18")
    (mmt   "0.1.1"))
  :url "https://github.com/mrkkrp/typit"
  :commit "eb67151f0693103bd7ef09a4a121c0f18b53c395"
  :revdesc "eb67151f0693"
  :keywords '("games")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
