;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-bashate" "1.0.5"
  "A Flymake backend for bashate, a Bash scripts style checker."
  '((flymake-quickdef "1.0.0")
    (emacs            "27.1"))
  :url "https://github.com/jamescherti/flymake-bashate.el"
  :commit "4893738819306517736e3f8ea8aeebadb4df4bf9"
  :revdesc "1.0.5-0-g489373881930"
  :keywords '("tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
