;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "license-templates" "0.1.3"
  "Create LICENSE using GitHub API."
  '((emacs   "24.3")
    (request "0.3.0"))
  :url "https://github.com/jcs-elpa/license-templates"
  :commit "ef80eff8b7be117f9c48bdc6d9a62e56b0a93554"
  :revdesc "ef80eff8b7be"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
