;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix3" "0.1"
  "Frontend for experimental commands of Nix."
  '((emacs         "26.1")
    (promise       "1.1")
    (project       "0.6")
    (magit-section "3.3")
    (s             "1.12"))
  :url "https://github.com/emacs-twist/nix3.el"
  :commit "4c498af13476ccf9afdcfe27751b60ce763748ce"
  :revdesc "4c498af13476"
  :keywords '("processes")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
