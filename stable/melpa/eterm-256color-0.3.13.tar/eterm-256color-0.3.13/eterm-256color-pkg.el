;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eterm-256color" "0.3.13"
  "Customizable 256 colors for term."
  '((emacs       "24.4")
    (xterm-color "1.7")
    (f           "0.19.0"))
  :url "https://github.com/dieggsy/eterm-256color"
  :commit "dab96af559deb443c4c9c00e23389926e1607192"
  :revdesc "dab96af559de"
  :keywords '("faces")
  :authors '(("Diego A. Mundo" . "diegoamundo@gmail.com"))
  :maintainers '(("Diego A. Mundo" . "diegoamundo@gmail.com")))
