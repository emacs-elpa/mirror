;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aggressive-fill-paragraph" "0.0.1"
  "A minor mode to keep comment paragraphs filled."
  ()
  :url "https://github.com/davidshepherd7/aggressive-fill-paragraph-mode"
  :commit "a66d571ceb6840610a7ed09765e6e050c3c8e3c6"
  :revdesc "a66d571ceb68"
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
