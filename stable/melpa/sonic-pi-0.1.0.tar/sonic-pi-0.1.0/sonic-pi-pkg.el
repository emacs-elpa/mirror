;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sonic-pi" "0.1.0"
  "A Emacs client for SonicPi."
  '((cl-lib "0.5")
    (osc    "0.1")
    (emacs  "24"))
  :url "https://github.com/repl-electric/sonic-pi.el"
  :commit "4af1e6c9af6c92cdd4864f1898df95f87c7c05c5"
  :revdesc "4af1e6c9af6c"
  :keywords '("sonicpi" "ruby"))
