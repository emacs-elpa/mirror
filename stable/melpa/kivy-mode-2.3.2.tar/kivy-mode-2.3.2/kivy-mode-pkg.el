;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kivy-mode" "2.3.2"
  "Emacs major mode for editing Kivy files."
  ()
  :url "https://github.com/kivy/kivy"
  :commit "ec09ee880c666e70de42501f36dbc43e349e3712"
  :revdesc "2.3.2-0-gec09ee880c66"
  :authors '(("Dean Serenevy" . "dean@serenevy.net"))
  :maintainers '(("Dean Serenevy" . "dean@serenevy.net")))
