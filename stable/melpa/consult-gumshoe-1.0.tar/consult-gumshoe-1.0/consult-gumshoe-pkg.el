;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gumshoe" "1.0"
  "Consult integration for gumshoe."
  '((emacs   "27.1")
    (consult "0.35")
    (gumshoe "4.0"))
  :url "https://github.com/Overdr0ne/gumshoe"
  :commit "95ee50e7962391a1f1f9c2bbe32111ae26a85855"
  :revdesc "95ee50e79623"
  :keywords '("tools"))
