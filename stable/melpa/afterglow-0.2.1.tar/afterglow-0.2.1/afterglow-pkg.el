;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "afterglow" "0.2.1"
  "Temporary Highlighting after Function Calls."
  '((emacs "26.1"))
  :url "https://github.com/ernestvanderlinden/emacs-afterglow"
  :commit "8254dc5d4fdfec63e1b5b2d59af0771d2c5a5474"
  :revdesc "v0.2.1-0-g8254dc5d4fdf"
  :keywords '("highlight" "line" "convenience" "evil")
  :authors '(("Ernest M. van der Linden" . "hello@ernestoz.com"))
  :maintainers '(("Ernest M. van der Linden" . "hello@ernestoz.com")))
