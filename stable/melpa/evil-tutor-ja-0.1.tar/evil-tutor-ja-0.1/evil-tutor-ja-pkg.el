;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-tutor-ja" "0.1"
  "Vimtutor adapted to Evil and wrapped in a major-mode."
  '((evil "1.0.9"))
  :url "https://github.com/kenjimyzk/evil-tutor-ja"
  :commit "767827d6832cfda8faca0e18456990db0c4c5cae"
  :revdesc "767827d6832c"
  :keywords '("convenience" "editing" "evil")
  :authors '(("Kenji Miyazaki" . "kenjizmyzk@gmail.com"))
  :maintainers '(("Kenji Miyazaki" . "kenjizmyzk@gmail.com")))
