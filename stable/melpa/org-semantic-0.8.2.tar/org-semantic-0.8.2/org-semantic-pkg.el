;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-semantic" "0.8.2"
  "Search org notes by meaning, or by word."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/org-semantic"
  :commit "eac04d151a00e969b9ad36f55f8f26039348be5f"
  :revdesc "v0.8.2-0-geac04d151a00"
  :keywords '("outlines" "matching" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
