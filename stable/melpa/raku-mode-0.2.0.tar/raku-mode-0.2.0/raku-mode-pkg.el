;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "raku-mode" "0.2.0"
  "Major mode for editing Raku code."
  '((emacs    "24.4")
    (pkg-info "0.1"))
  :url "https://github.com/hinrik/perl6-mode"
  :commit "7496ad3a03bed613c259405ec8839ae02950fdb1"
  :revdesc "7496ad3a03be"
  :keywords '("languages")
  :authors '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com"))
  :maintainers '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com")))
