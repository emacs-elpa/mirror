;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pomidor" "0.6.1"
  "Simple and cool pomodoro timer."
  '((emacs "24.3")
    (alert "1.2")
    (dash  "nil"))
  :url "https://github.com/TatriX/pomidor"
  :commit "bf3ca99c24a84befe9ed76b9636ec9adb37ab844"
  :revdesc "v0.6.1-0-gbf3ca99c24a8"
  :keywords '("tools" "time" "applications" "pomodoro technique")
  :authors '(("TatriX" . "tatrics@gmail.com"))
  :maintainers '(("TatriX" . "tatrics@gmail.com")))
