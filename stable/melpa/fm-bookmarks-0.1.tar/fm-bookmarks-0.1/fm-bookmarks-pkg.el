;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fm-bookmarks" "0.1"
  "Access existed FM bookmarks (ex: Dolphin, Nautilus, PCManFM) via Dired."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/kuanyui/fm-bookmarks.el"
  :commit "f92358a5cc140e5260a98ca4c643242d1eed3df5"
  :revdesc "f92358a5cc14"
  :keywords '("files" "convenience")
  :authors '(("Ono Hiroko" . "azazabc123@gmail.com"))
  :maintainers '(("Ono Hiroko" . "azazabc123@gmail.com")))
