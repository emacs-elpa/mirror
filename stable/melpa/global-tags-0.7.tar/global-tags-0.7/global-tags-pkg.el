;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "global-tags" "0.7"
  "Elisp API and editor integration for GNU global."
  '((emacs   "26.1")
    (async   "1.9.4")
    (project "0.5.2")
    (ht      "2.3"))
  :url "https://launchpad.net/global-tags.el"
  :commit "344d084ec5ff6c99b31c5ea57e5352c85b57ae26"
  :revdesc "344d084ec5ff"
  :keywords '("convenience" "matching" "tools")
  :authors '(("Felipe Lema" . "felipelema@mortemale.org"))
  :maintainers '(("Felipe Lema" . "felipelema@mortemale.org")))
