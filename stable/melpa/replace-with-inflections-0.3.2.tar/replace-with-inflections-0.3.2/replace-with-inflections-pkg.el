;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "replace-with-inflections" "0.3.2"
  "Inflection aware `query-replace'."
  '((cl-lib            "0.5")
    (string-inflection "1.0.10")
    (inflections       "1.1"))
  :url "https://github.com/knu/replace-with-inflections.el"
  :commit "c57cfb06752bb17389465890ff0ef58a7dd465d2"
  :revdesc "c57cfb06752b"
  :keywords '("matching")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
