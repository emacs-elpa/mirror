;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "manage-minor-mode-table" "0.1.3"
  "Manage minor-modes in table."
  '((emacs             "25.1")
    (manage-minor-mode "1.1"))
  :url "https://github.com/jcs-elpa/manage-minor-mode-table"
  :commit "d377094c4ff5e93321e12f53892113083148bdaf"
  :revdesc "d377094c4ff5"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
