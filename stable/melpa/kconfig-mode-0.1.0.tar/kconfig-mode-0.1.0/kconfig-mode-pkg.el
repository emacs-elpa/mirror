;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kconfig-mode" "0.1.0"
  "Major mode for editing Kconfig files."
  ()
  :url "https://github.com/beta1440/kernel-modes"
  :commit "f25647ff302c7b03cb6532a8e8157f19d21f924b"
  :revdesc "f25647ff302c"
  :keywords '("kconfig" "linux" "kernel")
  :authors '(("Dela Anthonio" . "dell.anthonio@gmail.com"))
  :maintainers '(("Dela Anthonio" . "dell.anthonio@gmail.com")))
