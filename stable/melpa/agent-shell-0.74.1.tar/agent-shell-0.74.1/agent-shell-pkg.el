;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.74.1"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "1bcb735153df87e3f88244491ede04e999ede5f0"
  :revdesc "1bcb735153df")
