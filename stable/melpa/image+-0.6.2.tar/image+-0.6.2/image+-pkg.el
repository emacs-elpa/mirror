;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "image+" "0.6.2"
  "Image manipulate extensions for Emacs."
  '((cl-lib "0.3"))
  :url "https://github.com/mhayashi1120/Emacs-imagex"
  :commit "967508a6c151e6ab6e97d3ac332dc5599011830d"
  :revdesc "967508a6c151"
  :keywords '("multimedia" "extensions")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
