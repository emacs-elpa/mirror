;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oer-reveal" "4.35.1"
  "OER with reveal.js, plugins, and org-re-reveal."
  '((emacs         "24.4")
    (org-re-reveal "3.38.0"))
  :url "https://gitlab.com/oer/oer-reveal"
  :commit "47b626bcb7f1b2d2a5a1e4a740a659a89c2b2b1f"
  :revdesc "47b626bcb7f1"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "oer"))
