;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tblui" "0.1.0"
  "Define tabulated list UI easily."
  '((dash        "2.12.1")
    (magit-popup "2.6.0")
    (tablist     "0.70")
    (cl-lib      "0.5"))
  :url "https://github.com/Yuki-Inoue/tblui.el"
  :commit "e280e11b35a2fdbcadf9ce901a2b62684ac7a7a3"
  :revdesc "e280e11b35a2"
  :authors '(("Yuki Inoue" . "inouetakahiroki_at_gmail.com"))
  :maintainers '(("Yuki Inoue" . "inouetakahiroki_at_gmail.com")))
