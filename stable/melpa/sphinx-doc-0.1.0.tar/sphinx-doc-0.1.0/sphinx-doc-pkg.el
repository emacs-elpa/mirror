;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sphinx-doc" "0.1.0"
  "Sphinx friendly docstrings for Python functions."
  '((s      "1.9.0")
    (cl-lib "0.5"))
  :url "https://github.com/naiquevin/sphinx-doc.el"
  :commit "b3459ecb9e6d3fffdee3cb7342563a56a32ce666"
  :revdesc "b3459ecb9e6d"
  :keywords '("sphinx" "python")
  :authors '(("Vineet Naik" . "naikvin@gmail.com"))
  :maintainers '(("Vineet Naik" . "naikvin@gmail.com")))
