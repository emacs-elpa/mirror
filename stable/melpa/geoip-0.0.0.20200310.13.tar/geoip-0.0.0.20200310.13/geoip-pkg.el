;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geoip" "0.0.0.20200310.13"
  "Find out where an IP address is located via GeoIP2."
  '((emacs "25.1"))
  :url "https://github.com/xuchunyang/geoip.el"
  :commit "b4952890993642c7055f4bbbf05b0384740f8f51"
  :revdesc "b49528909936"
  :keywords '("tools"))
