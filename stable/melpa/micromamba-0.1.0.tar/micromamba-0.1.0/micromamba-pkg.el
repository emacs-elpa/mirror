;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "micromamba" "0.1.0"
  "A simple micromamba integration for Emacs."
  '((emacs    "27.1")
    (pythonic "0.1.0"))
  :url "https://github.com/SqrtMinusOne/micromamba.el"
  :commit "1997a345e2d9dd534f59260d082a8708ec7f82ab"
  :revdesc "1997a345e2d9"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
