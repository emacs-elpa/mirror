;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sorcery-theme" "1.0"
  "A D&D (Dark and Dusty) Theme."
  '((autothemer "0.2"))
  :url "https://github.com/vxid/emacs-theme-sorcery"
  :commit "143bf144e89ea9d4a59e7f41baf9f53d180465f9"
  :revdesc "143bf144e89e"
  :authors '(("Maxime Tréca" . "maxime@gmail.com"))
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")))
