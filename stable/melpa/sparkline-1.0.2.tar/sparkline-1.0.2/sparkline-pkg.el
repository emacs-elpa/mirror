;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sparkline" "1.0.2"
  "Make sparkline images from a list of numbers."
  '((cl-lib "0.3"))
  :url "https://github.com/woudshoo/sparkline"
  :commit "e44498cf1a58fb165991198fe5104d51c92ea904"
  :revdesc "e44498cf1a58"
  :keywords '("extensions")
  :authors '(("Willem Rein Oudshoorn" . "woudshoo@xs4all.nl"))
  :maintainers '(("Willem Rein Oudshoorn" . "woudshoo@xs4all.nl")))
