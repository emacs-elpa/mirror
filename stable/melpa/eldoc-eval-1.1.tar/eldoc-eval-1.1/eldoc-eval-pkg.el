;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-eval" "1.1"
  "Enable eldoc support when minibuffer is in use."
  ()
  :url "https://github.com/thierryvolpiatto/eldoc-eval"
  :commit "deca5e39f31282a06531002d289258cd099433c0"
  :revdesc "v1.1-0-gdeca5e39f312"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")))
