;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-ffdata" "0.0.1"
  "[No description available]."
  '((emacs   "25.2")
    (ivy     "")
    (counsel "")
    (emacsql ""))
  :url "https://github.com/cireu/counsel-ffdata"
  :commit "3161ceeca7304ce4d0b9a3c17d9f4db71c8b5148"
  :revdesc "3161ceeca730"
  :keywords '("firefox" "browser")
  :authors '((nil . "ZhuZihaoall_but_last@163.com"))
  :maintainers '((nil . "ZhuZihaoall_but_last@163.com")))
