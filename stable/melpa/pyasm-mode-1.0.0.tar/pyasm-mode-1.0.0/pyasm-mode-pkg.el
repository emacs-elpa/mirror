;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyasm-mode" "1.0.0"
  "Mode for editing assembler code."
  ()
  :url "https://github.com/rocky/pyasm-mode.el"
  :commit "71fbe5f436401d57df9fa57b712211fd8d568236"
  :revdesc "71fbe5f43640"
  :keywords '("languages")
  :maintainers '((nil . "rocky@gnu.org")))
