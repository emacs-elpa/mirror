;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lumos-mode" "0.1.0"
  "Major mode for LUMOS schema language."
  '((emacs    "26.1")
    (lsp-mode "8.0"))
  :url "https://github.com/getlumos/lumos-mode"
  :commit "1685cea53bfc0d3cd72c2ef09e5a63d9e2daa987"
  :revdesc "1685cea53bfc"
  :keywords '("languages" "solana" "blockchain"))
