;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibrowse" "0.2.3"
  "Interact with your browser."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~ngraves/ibrowse.el"
  :commit "0ace95c948b8fae87aaf08cc2b80ceb0b1713835"
  :revdesc "0ace95c948b8"
  :keywords '("comm" "data" "files" "tools")
  :authors '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainers '(("Nicolas Graves" . "ngraves@ngraves.fr")))
