;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "d2-mode" "0.1.3"
  "Major mode for working with d2 graphs."
  '((emacs "26.1"))
  :url "https://github.com/andorsk/d2-mode"
  :commit "872a0d79223d2fe0ecad02fd4474831ec623672f"
  :revdesc "872a0d79223d"
  :keywords '("d2" "graphs" "tools" "processes")
  :authors '(("Andor Kesselman" . "andor@henosisknot.com"))
  :maintainers '(("Andor Kesselman" . "andor@henosisknot.com")))
