;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-location" "0.4"
  "Watch and respond to changes in geographical location on OS X."
  ()
  :url "https://github.com/purcell/osx-location"
  :commit "110aee945b53ea550e4debe69bf3c077d940ec8c"
  :revdesc "110aee945b53"
  :keywords '("convenience" "calendar")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
