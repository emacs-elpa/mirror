;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-surround" "1.1.1"
  "Emulate surround.vim from Vim."
  '((evil "1.2.12"))
  :url "https://github.com/emacs-evil/evil-surround"
  :commit "346d4d85fcf1f9517e9c4991c1efe68b4130f93a"
  :revdesc "346d4d85fcf1"
  :keywords '("emulation" "vi" "evil")
  :authors '(("Tim Harper" . "timcharperatgmaildotcom")
             ("Vegard ye" . "vegard_oyeathotmaildotcom"))
  :maintainers '(("Tim Harper" . "timcharperatgmaildotcom")
                 ("Vegard ye" . "vegard_oyeathotmaildotcom")))
