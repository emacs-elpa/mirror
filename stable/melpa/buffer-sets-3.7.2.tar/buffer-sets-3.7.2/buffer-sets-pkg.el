;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-sets" "3.7.2"
  "Sets of Buffers for Buffer Management."
  '((cl-lib "0.5"))
  :url "https://git.sr.ht/~swflint/buffer-sets"
  :commit "cdc66804b8a1ec7ddf94d99c7f24b801148b64df"
  :revdesc "3.7.2-0-gcdc66804b8a1"
  :keywords '("buffer-management")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
