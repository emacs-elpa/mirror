;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mac-pseudo-daemon" "2.2"
  "Daemon mode that plays nice with Mac OS."
  '((cl-lib "0.1"))
  :url "https://github.com/DarwinAwardWinner/osx-pseudo-daemon"
  :commit "564b006835facc4a8df247d8a47ab1030d7e7beb"
  :revdesc "564b006835fa"
  :keywords '("convenience" "osx" "mac"))
