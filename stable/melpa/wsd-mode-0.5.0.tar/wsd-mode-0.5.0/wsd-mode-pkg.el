;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wsd-mode" "0.5.0"
  "Emacs major-mode for www.websequencediagrams.com."
  ()
  :url "https://github.com/josteink/wsd-mode"
  :commit "b5e8ea0daeaa52f2ea6349e09902bd3216e96258"
  :revdesc "b5e8ea0daeaa"
  :keywords '("wsd" "diagrams" "design" "process" "modelling" "uml")
  :authors '(("Jostein Kjønigsen" . "jostein@gmail.com"))
  :maintainers '(("Jostein Kjønigsen" . "jostein@gmail.com")))
