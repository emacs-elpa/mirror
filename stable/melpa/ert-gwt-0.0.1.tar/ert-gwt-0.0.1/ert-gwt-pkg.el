;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-gwt" "0.0.1"
  "GWT-style BDD testing for ERT."
  '((emacs "28.1"))
  :url "https://github.com/OverbearingPearl/ert-gwt"
  :commit "49bf6501351dc3f4e925d91241c6cd1a8438aa87"
  :revdesc "49bf6501351d"
  :keywords '("lisp" "tools")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
