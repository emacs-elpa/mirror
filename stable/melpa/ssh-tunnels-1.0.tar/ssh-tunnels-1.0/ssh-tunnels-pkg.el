;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ssh-tunnels" "1.0"
  "Manage SSH tunnels."
  ()
  :url "https://github.com/death/ssh-tunnels"
  :commit "4685c0c43970fbbe25ff895cc0aa89b8fd2a54a7"
  :revdesc "4685c0c43970"
  :keywords '("tools" "convenience")
  :authors '(("death" . "github.com/death"))
  :maintainers '(("death" . "github.com/death")))
