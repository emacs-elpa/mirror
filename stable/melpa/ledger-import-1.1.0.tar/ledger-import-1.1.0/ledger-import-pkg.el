;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-import" "1.1.0"
  "Fetch OFX files from bank and push them to Ledger."
  '((emacs       "25.1")
    (ledger-mode "3.1.1"))
  :url "https://gitlab.petton.fr/mpdel/libmpdel"
  :commit "2c199fcc8671c2ec82e62cea7716289426b7407c"
  :revdesc "v1.1.0-0-g2c199fcc8671"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
