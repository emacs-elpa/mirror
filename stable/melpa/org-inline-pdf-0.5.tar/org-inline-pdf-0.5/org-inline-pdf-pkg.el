;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-inline-pdf" "0.5"
  "Inline PDF previewing for Org."
  '((emacs "25.1")
    (org   "9.4"))
  :url "https://github.com/shg/org-inline-pdf.el"
  :commit "3a22dca889e8fa815274adcc73bb31a31f5ed992"
  :revdesc "3a22dca889e8"
  :keywords '("org" "outlines" "hypermedia"))
