;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "4.2.1"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.0")
    (closql   "2.4")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "849ce2359fcd51467e7ef00faaf6130e1017e6ce"
  :revdesc "v4.2.1-0-g849ce2359fcd"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
