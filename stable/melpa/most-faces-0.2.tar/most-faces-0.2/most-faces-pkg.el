;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "most-faces" "0.2"
  "A List of Most Available Faces."
  '((emacs "24"))
  :url "https://codeberg.org/mekeor/most-faces"
  :commit "e37cd1baa74f1bdf3230a9174e5c6cde73e3474c"
  :revdesc "e37cd1baa74f"
  :keywords '("faces")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
