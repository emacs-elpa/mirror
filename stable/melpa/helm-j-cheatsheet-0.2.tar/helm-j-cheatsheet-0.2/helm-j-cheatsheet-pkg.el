;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-j-cheatsheet" "0.2"
  "Quick J reference for Emacs."
  '((helm "1.5.3"))
  :url "https://github.com/abo-abo/helm-j-cheatsheet"
  :commit "6adccbd26584c5e558b0fd64477375c81e194466"
  :revdesc "6adccbd26584"
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
