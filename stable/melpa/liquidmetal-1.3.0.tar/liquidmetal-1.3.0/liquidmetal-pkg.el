;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liquidmetal" "1.3.0"
  "Quicksilver scoring algorithm, essentially LiquidMetal."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/liquidmetal"
  :commit "32ddd9b52875a6fa403104ed271e15d86d215463"
  :revdesc "32ddd9b52875"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
