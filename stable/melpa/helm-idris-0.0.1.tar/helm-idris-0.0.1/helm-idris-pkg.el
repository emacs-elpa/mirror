;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-idris" "0.0.1"
  "A Helm datasource for Idris documentation, queried from the compiler."
  '((helm       "0.0.0")
    (idris-mode "0.9.14"))
  :url "https://github.com/david-christiansen/helm-idris"
  :commit "43a1f22dae8daf7ea86905d8e014b5f78c679c1d"
  :revdesc "43a1f22dae8d"
  :keywords '("languages" "helm")
  :authors '(("David Raymond Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Raymond Christiansen" . "david@davidchristiansen.dk")))
