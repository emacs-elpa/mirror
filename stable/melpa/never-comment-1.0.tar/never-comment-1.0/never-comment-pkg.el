;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "never-comment" "1.0"
  "Never blocks are comment."
  ()
  :url "http://stackoverflow.com/a/4554658/89376"
  :commit "26f45f37edc73c2bb069779abb7e861331333e3f"
  :revdesc "26f45f37edc7")
