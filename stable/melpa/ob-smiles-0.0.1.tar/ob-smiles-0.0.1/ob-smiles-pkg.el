;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-smiles" "0.0.1"
  "Org-mode Babel support for SMILES."
  '((smiles-mode "0.0.1")
    (org         "8"))
  :commit "bc3d19a0cf5105604f8f07967b6ffc7ba6568f14"
  :revdesc "bc3d19a0cf51"
  :keywords '("org" "babel" "smiles")
  :authors '((nil . "JohnKitchinjkitchin@andrew.cmu.edu"))
  :maintainers '((nil . "JohnKitchinjkitchin@andrew.cmu.edu")))
