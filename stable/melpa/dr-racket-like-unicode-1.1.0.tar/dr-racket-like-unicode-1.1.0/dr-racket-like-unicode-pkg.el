;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dr-racket-like-unicode" "1.1.0"
  "DrRacket-style unicode input."
  '((emacs "24.1"))
  :url "https://github.com/david-christiansen/dr-racket-like-unicode"
  :commit "4953f1c8a68472e157a0dcd0a7e35a4ec2577133"
  :revdesc "4953f1c8a684"
  :keywords '("i18n" "tools")
  :authors '(("David Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Christiansen" . "david@davidchristiansen.dk")))
