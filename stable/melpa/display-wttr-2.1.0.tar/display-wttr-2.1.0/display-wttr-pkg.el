;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "display-wttr" "2.1.0"
  "Display wttr(weather) in the mode line."
  '((emacs "27.1"))
  :url "https://github.com/josegpt/display-wttr"
  :commit "d1f5b57e00ee229548005ddd1e8061e213effd32"
  :revdesc "d1f5b57e00ee"
  :authors '(("Jose G Perez Taveras" . "josegpt27@gmail.com"))
  :maintainers '(("Jose G Perez Taveras" . "josegpt27@gmail.com")))
