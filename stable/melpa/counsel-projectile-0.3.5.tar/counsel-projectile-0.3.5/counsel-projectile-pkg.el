;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-projectile" "0.3.5"
  "Ivy integration for Projectile."
  '((counsel    "0.13.4")
    (projectile "3.3.0"))
  :url "https://github.com/ericdanan/counsel-projectile"
  :commit "d4ea64ed1d283ca9b00bf441ca7e4ed3e37efa43"
  :revdesc "0.3.5-0-gd4ea64ed1d28"
  :keywords '("project" "convenience"))
