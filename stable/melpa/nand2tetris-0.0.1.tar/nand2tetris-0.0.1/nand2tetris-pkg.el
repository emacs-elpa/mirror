;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nand2tetris" "0.0.1"
  "Major Mode for HDL files in the Nand2Tetris Course https://www.coursera.org/course/nand2tetris1."
  ()
  :url "http://www.github.com/CestDiego/nand2tetris.el/"
  :commit "c14b43cc11d1d5b281e3615a9aa7a5630b3caa96"
  :revdesc "c14b43cc11d1"
  :keywords '("nand2tetris" "hdl")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")))
