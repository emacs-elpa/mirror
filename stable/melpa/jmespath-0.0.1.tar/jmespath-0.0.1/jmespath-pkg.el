;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jmespath" "0.0.1"
  "Query JSON using jmespath."
  '((emacs "24.3"))
  :url "https://github.com/unresolvedcold/jmespath"
  :commit "a64d8688d6c04d419a16c8b9c6103d2dd739991e"
  :revdesc "a64d8688d6c0"
  :keywords '("json" "data" "languages" "tools")
  :authors '(("Shubham Kumar" . "unresolved.shubham@gmail.com"))
  :maintainers '(("Shubham Kumar" . "unresolved.shubham@gmail.com")))
