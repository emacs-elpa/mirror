;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-dictionary" "1.1"
  "Automatic dictionary switcher for flyspell."
  ()
  :url "http://nschum.de/src/emacs/auto-dictionary/"
  :commit "0e3567a81f7bb0ad53ed9f20c7d3d1ac40c26ad1"
  :revdesc "1.1-0-g0e3567a81f7b"
  :keywords '("wp")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
