;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tox" "0.4.0"
  "Launch current python test with tox."
  ()
  :url "https://github.com/chmouel/tox.el"
  :commit "7655eb254038d5e34433e8a9d66b3ffc9c72e40c"
  :revdesc "7655eb254038"
  :keywords '("convenience" "tox" "python" "tests")
  :authors '(("Chmouel Boudjnah" . "chmouel@chmouel.com"))
  :maintainers '(("Chmouel Boudjnah" . "chmouel@chmouel.com")))
