;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "1.0"
  "Draw lines, boxes, & arrows with the keyboard."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "9d6fb0191e05faf716f02bb4562063007935181b"
  :revdesc "9d6fb0191e05"
  :keywords '("convenience" "text"))
