;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-msg" "1.1.1"
  "Show commit information of current line."
  '((emacs "24.4")
    (popup "0.5.0"))
  :url "https://github.com/redguardtoo/vc-msg"
  :commit "720c6f0e699f25463cd37642ee23adb4e23bc60b"
  :revdesc "720c6f0e699f"
  :keywords '("git" "vc" "svn" "hg" "messenger")
  :authors '(("Chen Bin" . "chenbinDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmailDOTcom")))
