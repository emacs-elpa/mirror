;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rebecca-theme" "1.2.1"
  "Rebecca Purple Theme."
  '((emacs "24"))
  :url "https://github.com/vic/rebecca-theme"
  :commit "239115183e0a354ccd5c2cb299893b558fbde05c"
  :revdesc "239115183e0a"
  :keywords '("theme" "dark")
  :authors '(("vic" . "vborja@apache.org"))
  :maintainers '(("vic" . "vborja@apache.org")))
