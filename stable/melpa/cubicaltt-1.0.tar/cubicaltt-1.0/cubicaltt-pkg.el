;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cubicaltt" "1.0"
  "Mode for cubical type theory."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/mortberg/cubicaltt"
  :commit "3257eadf70826fb3ef060c46f85b7a4d60464b1d"
  :revdesc "3257eadf7082"
  :keywords '("languages"))
