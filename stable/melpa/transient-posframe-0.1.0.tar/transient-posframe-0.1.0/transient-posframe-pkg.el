;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient-posframe" "0.1.0"
  "Using posframe to show transient."
  '((emacs     "26.0")
    (posframe  "0.4.3")
    (transient "0.2.0"))
  :url "https://github.com/yanghaoxie/transient-posframe"
  :commit "3d50442f53197466450005f3ed448c2c36dd5706"
  :revdesc "3d50442f5319"
  :keywords '("convenience" "bindings" "tooltip")
  :maintainers '(("Yanghao Xie" . "yhaoxie@gmail.com")))
