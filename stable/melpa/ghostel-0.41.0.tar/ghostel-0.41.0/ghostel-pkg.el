;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.41.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b8a302bcf48424d5f5965ab84fbbd958616f30db"
  :revdesc "b8a302bcf484"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
