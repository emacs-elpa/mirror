;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-consult" "0.0.1"
  "Consult UI for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.83.4")
    (acp         "0.18.1")
    (consult     "3.0"))
  :url "https://github.com/Gleek/agent-shell-consult"
  :commit "4f8c8f3ea08d8ade6b1ff1ec1eb0b4cea79e8d6f"
  :revdesc "v0.0.1-0-g4f8c8f3ea08d"
  :keywords '("convenience" "processes" "tools")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
