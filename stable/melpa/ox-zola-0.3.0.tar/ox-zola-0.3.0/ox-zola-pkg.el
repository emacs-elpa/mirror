;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-zola" "0.3.0"
  "Org export to Zola static site generator."
  '((emacs   "27.2")
    (ox-hugo "0.8"))
  :url "https://github.com/gicrisf/ox-zola"
  :commit "1615e8e77ecb2feb0929d92df5965fc55f06e1c5"
  :revdesc "1615e8e77ecb"
  :keywords '("wp" "hypermedia" "org" "zola")
  :authors '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com"))
  :maintainers '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com")))
