;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undohist" "0.3.0"
  "Persistent undo history for GNU Emacs."
  '((cl-lib "1.0"))
  :url "https://github.com/emacsorphanage/undohist"
  :commit "76338755b8aa710a07d6bc6faa4c03d792e90d82"
  :revdesc "0.3.0-0-g76338755b8aa"
  :keywords '("convenience")
  :authors '(("MATSUYAMA Tomohiro" . "m2ym.pub@gmail.com"))
  :maintainers '(("MATSUYAMA Tomohiro" . "m2ym.pub@gmail.com")))
