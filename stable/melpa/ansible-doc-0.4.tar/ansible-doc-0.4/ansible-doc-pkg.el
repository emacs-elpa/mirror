;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ansible-doc" "0.4"
  "Ansible documentation Minor Mode."
  '((emacs "24.3"))
  :url "https://github.com/lunaryorn/ansible-doc.el"
  :commit "bc8128a85a79b14f4a121105d87a5eddc33975ad"
  :revdesc "0.4-0-gbc8128a85a79"
  :keywords '("tools" "help")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn")))
