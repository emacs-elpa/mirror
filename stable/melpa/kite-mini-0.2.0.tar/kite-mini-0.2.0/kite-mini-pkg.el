;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kite-mini" "0.2.0"
  "Remotely evaluate JavaScript in the WebKit debugger."
  '((dash      "2.11.0")
    (websocket "1.5"))
  :url "https://github.com/tungd/kite-mini.el"
  :commit "db43b216ef742b12e35de4b7b88e8025bc21f06d"
  :revdesc "db43b216ef74"
  :keywords '("webkit")
  :authors '(("Tung Dao" . "me@tungdao.com"))
  :maintainers '(("Tung Dao" . "me@tungdao.com")))
