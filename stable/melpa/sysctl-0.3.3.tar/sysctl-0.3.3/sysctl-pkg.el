;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sysctl" "0.3.3"
  "Manage sysctl though org-mode."
  '((emacs "26"))
  :url "https://github.com/dantecatalfamo/sysctl.el"
  :commit "0fc50305a96de059ad1ff4e6081c9b4089f5247f"
  :revdesc "0fc50305a96d"
  :keywords '("sysctl" "tools" "unix"))
