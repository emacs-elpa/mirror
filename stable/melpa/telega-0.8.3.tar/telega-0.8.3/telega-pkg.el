;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "0.8.3"
  "Telegram client (unofficial)."
  '((emacs               "26.1")
    (visual-fill-column  "1.9")
    (rainbow-identifiers "0.2.2"))
  :url "https://github.com/zevlg/telega.el"
  :commit "ac3634e2e7efe9c29c4311196e0ed67085d58f11"
  :revdesc "ac3634e2e7ef"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
