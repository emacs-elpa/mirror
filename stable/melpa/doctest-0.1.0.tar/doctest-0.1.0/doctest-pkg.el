;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doctest" "0.1.0"
  "Doctests for Emacs Lisp."
  '((emacs "28.1"))
  :url "https://github.com/ag91/doctest"
  :commit "0a621020e671ccf75de1582b78da5a6ff31e0d69"
  :revdesc "0a621020e671"
  :keywords '("lisp" "maint" "docs" "help")
  :authors '(("Chris Rayner" . "(dchrisrayner@gmail.com)")
             ("Andrea -- current maintainer" . "(andrea-dev@hotmail.com) "))
  :maintainers '(("Chris Rayner" . "(dchrisrayner@gmail.com)")
                 ("Andrea -- current maintainer" . "(andrea-dev@hotmail.com) ")))
