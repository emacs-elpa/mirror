;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.4"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "f1b8eb2fa98765adcad5817920b37903de5bf68a"
  :revdesc "f1b8eb2fa987"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
