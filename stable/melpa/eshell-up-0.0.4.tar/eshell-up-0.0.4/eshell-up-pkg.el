;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-up" "0.0.4"
  "Quickly go to a specific parent directory in eshell."
  '((emacs "24"))
  :url "https://github.com/peterwvj/eshell-up"
  :commit "1999afaa509204b780db44e99ac9648fe7d92d32"
  :revdesc "1999afaa5092"
  :keywords '("eshell")
  :authors '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com"))
  :maintainers '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com")))
