;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "load-relative" "1.3.2"
  "Relative file load (within a multi-file Emacs package)."
  ()
  :url "https://github.com/rocky/emacs-load-relative"
  :commit "b7987c265a64435299d6b02f960ed2c894c4a145"
  :revdesc "1.3.2-0-gb7987c265a64"
  :keywords '("internal")
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
