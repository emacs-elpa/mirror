;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doing" "0.1.0"
  "A tiny hello world package."
  '((emacs "26.1"))
  :url "https://example.com/hello-world"
  :commit "9d62edac4af3198b5a57e7e1ea18ca3076b769be"
  :revdesc "9d62edac4af3"
  :keywords '("convenience"))
