;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-traces" "0.2.0"
  "Visual hints for `evil-ex'."
  '((emacs "25.1")
    (evil  "1.2.13"))
  :url "https://github.com/mamapanda/evil-traces"
  :commit "05e201cd63b549e3c88b5c3fc9b264bd6fe5a42c"
  :revdesc "05e201cd63b5"
  :keywords '("emulations" "evil" "visual")
  :authors '(("Daniel Phan" . "daniel.phan36@gmail.com"))
  :maintainers '(("Daniel Phan" . "daniel.phan36@gmail.com")))
