;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "headlong" "0.1.0"
  "Reckless completion."
  ()
  :url "https://github.com/abo-abo/headlong"
  :commit "698c6977132965bcf61564dcb01aa2bbd7d4d758"
  :revdesc "698c69771329"
  :keywords '("completion")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
