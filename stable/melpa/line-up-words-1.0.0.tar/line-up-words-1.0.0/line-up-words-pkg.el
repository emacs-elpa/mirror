;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "line-up-words" "1.0.0"
  "Align words in an intelligent way."
  ()
  :url "https://github.com/janestreet/line-up-words"
  :commit "54d2c51c1c3da7e06be47b829bf465bf467ab53f"
  :revdesc "1.0.0-0-g54d2c51c1c3d")
