;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "webdriver" "0.1"
  "WebDriver local end implementation."
  '((emacs "25.1"))
  :url "https://gitlab.com/mauroaranda/emacs-webdriver"
  :commit "db4acd830acd09e8814cddcb682676d6c5a1e6fd"
  :revdesc "db4acd830acd"
  :keywords '("tools")
  :authors '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers '(("Mauro Aranda" . "maurooaranda@gmail.com")))
