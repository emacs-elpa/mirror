;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-emojify" "0.1.0"
  "Company completion for Emojify."
  '((emacs   "26.1")
    (company "0.8.0")
    (emojify "1.2.1")
    (ht      "2.0"))
  :url "https://github.com/jcs-elpa/company-emojify"
  :commit "015dc2cee7c9713794efd44d398a12eb62a94185"
  :revdesc "015dc2cee7c9"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
