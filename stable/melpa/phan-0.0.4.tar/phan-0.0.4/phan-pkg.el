;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phan" "0.0.4"
  "Utility functions for Phan (PHP static analizer)."
  '((emacs    "24")
    (composer "0.0.8")
    (f        "0.17"))
  :url "https://github.com/emacs-php/phan.el"
  :commit "6b077b3421a0b2c0b98a6906b8ab0d14d9d7bf50"
  :revdesc "6b077b3421a0"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@pixiv.com"))
  :maintainers '(("USAMI Kenta" . "tadsan@pixiv.com")))
