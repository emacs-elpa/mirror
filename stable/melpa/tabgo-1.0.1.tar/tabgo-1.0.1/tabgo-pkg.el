;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabgo" "1.0.1"
  "Jump to tabs, avy style."
  '((emacs "27.1"))
  :url "https://github.com/isamert/tabgo.el"
  :commit "23b6397fd61db31689feacb4b7df2b1f64e69572"
  :revdesc "23b6397fd61d"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
