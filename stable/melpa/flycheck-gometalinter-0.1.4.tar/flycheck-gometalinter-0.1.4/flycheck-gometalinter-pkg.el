;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-gometalinter" "0.1.4"
  "Flycheck checker for gometalinter."
  '((emacs    "24")
    (flycheck "0.22"))
  :url "https://github.com/favadi/flycheck-gometalinter"
  :commit "2e863429cc953cf4c14783e249df56d1ae669868"
  :revdesc "v0.1.4-0-g2e863429cc95"
  :keywords '("convenience" "tools" "go")
  :authors '(("Diep Pham" . "me@favadi.com"))
  :maintainers '(("Diep Pham" . "me@favadi.com")))
