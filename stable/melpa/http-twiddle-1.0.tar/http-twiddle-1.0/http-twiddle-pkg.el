;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-twiddle" "1.0"
  "[No description available]."
  ()
  :url "https://github.com/hassy/http-twiddle/blob/master/http-twiddle.el"
  :commit "1f05820ce46040c544207952114a2bcc2c7544a9"
  :revdesc "1f05820ce460"
  :keywords '("http" "rest" "soap")
  :authors '(("Luke Gorrie" . "luke@synap.se"))
  :maintainers '(("Hasan Veldstra" . "h@vidiowiki.com")))
