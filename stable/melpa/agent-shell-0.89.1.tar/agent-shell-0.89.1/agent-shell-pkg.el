;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.89.1"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d3a6067bc606293343171efc8ff763ae78c85653"
  :revdesc "d3a6067bc606")
