;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-hoogle" "1.0"
  "[No description available]."
  ()
  :url "https://github.com/jwiegley/haskell-config"
  :commit "9ed342d9081c350b51ed501251e803ae6050308e"
  :revdesc "9ed342d9081c"
  :keywords '("haskell" "programming" "hoogle")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("John Wiegley" . "jwiegley@gmail.com")))
