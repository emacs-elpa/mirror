;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "walkclj" "0.2.0"
  "Manipulate Clojure parse trees."
  '((emacs    "25")
    (parseclj "0.1.0")
    (treepy   "0.1.0"))
  :url "https://github.com/plexus/walkclj"
  :commit "4b4e9fcef2361bdf88ab3c7f905a76672cfd43e4"
  :revdesc "4b4e9fcef236"
  :keywords '("languages"))
