;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "psalm" "0.6.0"
  "Interface to Psalm."
  '((emacs    "24.3")
    (php-mode "1.22.3"))
  :url "https://github.com/emacs-php/psalm.el"
  :commit "aaa77b4ceb61d41a520baa0b84b9b236c99c4156"
  :revdesc "aaa77b4ceb61"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
