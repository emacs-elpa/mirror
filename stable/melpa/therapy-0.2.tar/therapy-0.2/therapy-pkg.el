;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "therapy" "0.2"
  "Hooks for managing multiple Python major version."
  '((emacs "24")
    (dash  "2.10.0")
    (f     "0.17.2"))
  :url "https://github.com/abingham/therapy"
  :commit "a5526d8373d390a5a72725ef993bdd679c5302c9"
  :revdesc "a5526d8373d3"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
