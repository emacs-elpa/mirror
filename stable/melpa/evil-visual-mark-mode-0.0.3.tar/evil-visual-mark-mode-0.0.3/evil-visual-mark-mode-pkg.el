;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-visual-mark-mode" "0.0.3"
  "Display evil marks on buffer."
  '((evil "1.0.9")
    (dash "2.10"))
  :url "https://github.com/roman/evil-visual-mark-mode"
  :commit "094ee37599492885ff3144918fcdd9b74dadaaa0"
  :revdesc "094ee3759949"
  :keywords '("evil")
  :authors '(("Roman Gonzalez" . "romanandreg@gmail.com"))
  :maintainers '(("Roman Gonzalez" . "romanandreg@gmail.com")))
