;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bibtex-capf" "1.0"
  "Completion at point for bibtex --- *- lexical-binding: t -*-."
  '((emacs    "27.1")
    (parsebib "3.0")
    (org      "9.5"))
  :url "https://github.com/mclear-tools/bibtex-capf"
  :commit "683531061dcf4918a01c6c74f7b3347cbeec2df1"
  :revdesc "683531061dcf"
  :keywords '("bibtex" "convenience"))
