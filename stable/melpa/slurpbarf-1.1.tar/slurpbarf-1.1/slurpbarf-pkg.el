;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slurpbarf" "1.1"
  "Commands for slurping and barfing."
  '((emacs "29.1"))
  :url "https://codeberg.org/vilij/slurpbarf-elcute"
  :commit "97b4c3b0bd3e22d4d4b1a9aed3435b5a58b09259"
  :revdesc "97b4c3b0bd3e"
  :keywords '("convenience"))
