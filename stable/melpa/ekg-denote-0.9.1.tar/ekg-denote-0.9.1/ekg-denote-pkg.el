;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-denote" "0.9.1"
  "A denote integration for ekg."
  '((emacs  "28.1")
    (ekg    "0.7.0")
    (denote "4.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "f1401f4189143dcfce5cd7d68231462d7a8873ec"
  :revdesc "f1401f418914"
  :keywords '("outlines" "hypermedia")
  :authors '(("Jay Rajput" . "jayrajput@gmail.com"))
  :maintainers '(("Jay Rajput" . "jayrajput@gmail.com")))
