;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-gcal" "0.4.3"
  "Org sync with Google Calendar."
  '((aio              "1.0")
    (alert            "1.2")
    (emacs            "26.1")
    (oauth2-auto      "20240326.2225")
    (org              "9.3")
    (persist          "0.8")
    (request          "20190901")
    (request-deferred "20181129"))
  :url "https://github.com/kidd/org-gcal.el"
  :commit "9627478a7d26468957d965ebb858e5ff9e260568"
  :revdesc "v0.4.3-0-g9627478a7d26"
  :keywords '("convenience")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com"))
  :maintainers '(("Raimon Grau" . "raimonster@gmail.com")))
