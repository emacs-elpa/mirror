;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haml-mode" "3.1.9"
  "Major mode for editing Haml files."
  '((ruby-mode "1.0"))
  :url "https://github.com/nex3/haml/tree/master"
  :commit "5e0baf7b795b9e41ac03b55f8feff6b51027c43b"
  :revdesc "5e0baf7b795b"
  :keywords '("markup" "language" "html"))
