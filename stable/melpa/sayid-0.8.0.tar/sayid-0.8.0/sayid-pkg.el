;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "0.8.0"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "2.0"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "16fe77228cb3f76eee52d1be336a505f23a31223"
  :revdesc "v0.8.0-0-g16fe77228cb3"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
