;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cql-mode" "0.0.2"
  "Major mode for editting CQLs."
  '((emacs "24"))
  :url "https://github.com/Yuki-Inoue/cql-mode"
  :commit "060610c5570a26838b1502fd7576777ff713ea25"
  :revdesc "060610c5570a"
  :keywords '("cql" "cassandra")
  :authors '(("Yuki Inoue" . "inouetakahirokiatgmail.com"))
  :maintainers '(("Yuki Inoue" . "inouetakahirokiatgmail.com")))
