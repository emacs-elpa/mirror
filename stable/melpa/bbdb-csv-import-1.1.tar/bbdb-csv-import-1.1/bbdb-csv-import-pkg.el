;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbdb-csv-import" "1.1"
  "[No description available]."
  '((pcsv "1.3.3")
    (dash "2.5.0"))
  :url "https://gitlab.com/iankelling/bbdb-csv-import"
  :commit "8b59aa1e503d9ef9595f0a8f8265828f97590f56"
  :revdesc "8b59aa1e503d"
  :keywords '("csv" "util" "bbdb")
  :authors '(("Ian Kelling" . "ian@iankelling.org"))
  :maintainers '(("Ian Kelling" . "ian@iankelling.org")))
