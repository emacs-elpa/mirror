;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agda-editor-tactics" "1.0"
  "An editor tactic to produce Σ-types from Agda records."
  '((s     "1.12.0")
    (dash  "2.16.0")
    (emacs "27.1")
    (org   "9.1"))
  :url "https://github.com/alhassy/next-700-module-systems"
  :commit "1181477d7c4497247ca436a009faa4998a62f89c"
  :revdesc "1181477d7c44"
  :keywords '("abbrev" "convenience" "languages" "agda" "tools")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
