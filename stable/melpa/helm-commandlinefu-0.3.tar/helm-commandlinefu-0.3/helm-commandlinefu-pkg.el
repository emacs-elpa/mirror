;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-commandlinefu" "0.3"
  "Search and browse commandlinefu.com from helm."
  '((emacs     "24.1")
    (helm      "1.7.0")
    (json      "1.3")
    (let-alist "1.0.3"))
  :url "https://github.com/xuchunyang/helm-commandlinefu"
  :commit "e11cd3e961c1c4c973b51d8d12592e7235a4971b"
  :revdesc "e11cd3e961c1"
  :keywords '("commandlinefu.com")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
