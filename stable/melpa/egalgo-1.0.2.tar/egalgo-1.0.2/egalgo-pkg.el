;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "egalgo" "1.0.2"
  "Genetic algorithm for Emacs."
  '((dash  "2.14")
    (emacs "24"))
  :url "https://github.com/ROCKTAKEY/egalgo"
  :commit "85c8c01c3424e69528f4111a384092dfa721196a"
  :revdesc "85c8c01c3424"
  :keywords '("data")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
