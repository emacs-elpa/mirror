;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-buf-lint" "0.0.1"
  "Flycheck checker for protobuf with buf.build."
  '((emacs    "25")
    (flycheck "0.22")
    (cl-lib   "0.5")
    (s        "1.12.0"))
  :url "https://github.com/shuxiao9058/flycheck-buf-lint"
  :commit "9ba17c991f1cb7a7ac225e70ce8777216b7ebc2c"
  :revdesc "9ba17c991f1c"
  :keywords '("convenience" "tools" "buf" "protobuf")
  :authors '(("Aaron Ji" . "shuxiao9058@gmail.com"))
  :maintainers '(("Aaron Ji" . "shuxiao9058@gmail.com")))
