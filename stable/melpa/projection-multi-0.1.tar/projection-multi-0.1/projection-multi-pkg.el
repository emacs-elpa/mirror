;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projection-multi" "0.1"
  "Projection integration for `compile-multi'."
  '((projection    "0.1")
    (compile-multi "0.1"))
  :url "https://github.com/mohkale/projection"
  :commit "0ad0179fba3659b0c5a1a7258a523fdb77972dec"
  :revdesc "0ad0179fba36"
  :keywords '("project" "convenience")
  :authors '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@kisara.moe")))
