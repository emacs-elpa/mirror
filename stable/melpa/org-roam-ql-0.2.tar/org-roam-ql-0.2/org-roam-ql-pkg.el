;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "0.2"
  "Interface to query and view results from org-roam."
  '((emacs            "28")
    (org-roam         "2.2.0")
    (s                "1.12.0")
    (magit-section    "3.3.0")
    (transient        "0.4")
    (org-super-agenda "1.2"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "f628fef081394f159f196f4350132aecb3edb8cc"
  :revdesc "f628fef08139")
