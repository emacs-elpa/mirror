;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ample-regexps" "0.1"
  "Ample regular expressions for Emacs."
  ()
  :url "https://github.com/immerrr/ample-regexps.el"
  :commit "04b001cbe8047c1bc2b6d5cb82e82245c1da5046"
  :revdesc "04b001cbe804"
  :keywords '("regexps" "extensions" "tools")
  :authors '(("immerrr" . "immerrr@gmail.com"))
  :maintainers '(("immerrr" . "immerrr@gmail.com")))
