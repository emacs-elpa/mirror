;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kagi" "0.6"
  "Kagi API integration."
  '((emacs         "29.1")
    (markdown-mode "2.6")
    (shell-maker   "0.46.1"))
  :url "https://codeberg.org/bram85/kagi.el"
  :commit "9e48fc96d513f863acde3689077197306e3d205c"
  :revdesc "0.6-0-g9e48fc96d513"
  :keywords '("terminals" "wp")
  :authors '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers '(("Bram Schoenmakers" . "me@bramschoenmakers.nl")))
