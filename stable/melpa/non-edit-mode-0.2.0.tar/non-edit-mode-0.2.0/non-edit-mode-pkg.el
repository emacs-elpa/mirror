;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "non-edit-mode" "0.2.0"
  "Minor mode that disables editing."
  '((emacs "24.1"))
  :url "https://gitlab.com/aragaer/non-edit-mode"
  :commit "dfe065acdd06be176fce3ab150fae699b2ad1a13"
  :revdesc "dfe065acdd06"
  :keywords '("convenience")
  :authors '(("aragaer" . "aragaer@gmail.com"))
  :maintainers '(("aragaer" . "aragaer@gmail.com")))
