;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.3.0"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "37b94dc2df6e557f0e72999ac9f835474bf33477"
  :revdesc "v2.3.0-0-g37b94dc2df6e"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
