;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corsair" "0.1"
  "[No description available]."
  '((emacs "28.1")
    (gptel "0.9.0"))
  :url "https://github.com/rob137/Corsair"
  :commit "70614cb6b05a0e1f61b3422c188d8d2a257a65f8"
  :revdesc "70614cb6b05a"
  :keywords '("convenience" "tools")
  :authors '(("Robert Kirby" . "corsair.el.package@gmail.com"))
  :maintainers '(("Robert Kirby" . "corsair.el.package@gmail.com")))
