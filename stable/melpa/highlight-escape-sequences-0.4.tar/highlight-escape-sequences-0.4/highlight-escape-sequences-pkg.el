;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-escape-sequences" "0.4"
  "Highlight escape sequences."
  ()
  :url "https://github.com/dgutov/highlight-escape-sequences"
  :commit "08d846a7aa748209d65fecead2b6a766c3e5cb41"
  :revdesc "08d846a7aa74"
  :keywords '("convenience")
  :authors '(("Dmitry Gutov" . "dgutov@yandex.ru")
             ("Pavel Matcula" . "dev.plvlml@gmail.com"))
  :maintainers '(("Dmitry Gutov" . "dgutov@yandex.ru")
                 ("Pavel Matcula" . "dev.plvlml@gmail.com")))
