;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-pause" "0.1"
  "Library for creating auto-pause process which will be paused when Emacs idle for specific time and be resumed when emacs become busy again."
  '((cl-lib "0.5"))
  :url "https://github.com/lujun9972/auto-pause"
  :commit "b8e7301a7739bf49e79f7e8cba5a87645c70cbc1"
  :revdesc "b8e7301a7739"
  :keywords '("convenience" "menu")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
