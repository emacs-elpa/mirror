;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-trepan-ni" "1.0.1"
  "Realgud front-end to trepan-ni."
  '((load-relative "1.2")
    (realgud       "1.5.0")
    (cl-lib        "0.5")
    (emacs         "25"))
  :url "https://github.com/realgud/realgud-trepan-ni"
  :commit "ce008862ea33de0a9e6c06099b9ddff8f620f2e4"
  :revdesc "ce008862ea33"
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
