;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "2.2"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "39dc386062d6ae942b4a7e8592d26ce11b73bf29"
  :revdesc "39dc386062d6"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
