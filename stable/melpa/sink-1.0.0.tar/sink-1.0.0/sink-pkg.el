;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sink" "1.0.0"
  "Receive messages from the plan9 plumber."
  '((emacs "25.1"))
  :url "https://github.com/alcah/sink.el"
  :commit "b11b8e6755c6036e092a1e4e1f807a87522b7a4c"
  :revdesc "b11b8e6755c6")
