;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "numbers" "1.4"
  "Display information and trivia about numbers."
  '((emacs "24"))
  :url "https://github.com/davep/numbers.el"
  :commit "74be68b94143f042ce461b2a69202f515acaf20c"
  :revdesc "74be68b94143"
  :keywords '("games" "trivia" "maths" "numbers")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
