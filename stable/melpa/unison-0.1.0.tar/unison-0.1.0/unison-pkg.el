;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison" "0.1.0"
  "Sync with Unison."
  '((emacs "24.1"))
  :url "http://wiki.apertium.org/wiki/Emacs"
  :commit "876ee863d5f7d3fb4b4c26eb9763cc2b8dcf2302"
  :revdesc "876ee863d5f7"
  :keywords '("sync")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
