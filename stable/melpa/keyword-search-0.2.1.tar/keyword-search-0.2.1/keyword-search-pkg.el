;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keyword-search" "0.2.1"
  "Browser keyword search from Emacs."
  ()
  :url "https://github.com/juhp/keyword-search"
  :commit "1a01e3d5a43e48701cfab0332876284f5d3a1bba"
  :revdesc "1a01e3d5a43e"
  :keywords '("web" "search" "keyword"))
