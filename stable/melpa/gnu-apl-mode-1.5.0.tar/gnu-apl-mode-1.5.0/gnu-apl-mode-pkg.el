;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnu-apl-mode" "1.5.0"
  "[No description available]."
  ()
  :url "http://www.gnu.org/software/apl/"
  :commit "5d998206a963f2205dc6c4eddb41fb34187cb527"
  :revdesc "5d998206a963"
  :keywords '("languages")
  :authors '(("Elias Mårtenson" . "lokedhs@gmail.com"))
  :maintainers '(("Elias Mårtenson" . "lokedhs@gmail.com")))
