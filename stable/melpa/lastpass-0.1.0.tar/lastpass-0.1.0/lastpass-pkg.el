;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lastpass" "0.1.0"
  "LastPass command wrapper."
  '((emacs "24.4"))
  :url "https://github.com/storvik/lastpass"
  :commit "6b189b654b5ba3741565e9a954e9df99d69e987a"
  :revdesc "6b189b654b5b"
  :keywords '("extensions" "processes" "lpass" "lastpass"))
