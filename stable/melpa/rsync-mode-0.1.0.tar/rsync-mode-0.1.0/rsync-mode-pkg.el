;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rsync-mode" "0.1.0"
  "Rsync projects to remote machines."
  '((emacs   "26.1")
    (spinner "1.7.3"))
  :url "https://github.com/r-zip/rsync-mode.el"
  :commit "77115dcfd66ea521e83b4233edb6d5a119ff8021"
  :revdesc "77115dcfd66e"
  :keywords '("remote" "rsync")
  :authors '(("Ryan Pilgrim" . "ryan.z.pilgrim@gmail.com"))
  :maintainers '(("Ryan Pilgrim" . "ryan.z.pilgrim@gmail.com")))
