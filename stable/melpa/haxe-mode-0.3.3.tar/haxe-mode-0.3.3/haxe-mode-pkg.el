;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haxe-mode" "0.3.3"
  "Major mode for editing Haxe files."
  ()
  :url "https://github.com/emacsorphanage/haxe-mode"
  :commit "5e8183a275babdc7604ae01fc94853e60cb04a32"
  :revdesc "5e8183a275ba"
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
