;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-shells" "20170311"
  "Manage the shell buffers of each project."
  '((emacs "24.3")
    (seq   "2.19"))
  :url "https://github.com/hying-caritas/project-shells"
  :commit "ab10fcd370781f684ca334f83fd70ed22a3f93b9"
  :revdesc "ab10fcd37078"
  :keywords '("processes" "terminals")
  :authors '(("Huang, Ying" . "huang.ying.caritas@gmail.com"))
  :maintainers '(("Huang, Ying" . "huang.ying.caritas@gmail.com")))
