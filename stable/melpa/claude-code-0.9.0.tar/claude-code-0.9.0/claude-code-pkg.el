;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claude-code" "0.9.0"
  "Run Claude Code sessions."
  '((emacs         "28.1")
    (projectile    "2.5.0")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (markdown-mode "2.5"))
  :url "https://github.com/yuya373/claude-code-emacs"
  :commit "9dcfabfdfeb153543c0b09416a0e5fcbc702ee40"
  :revdesc "9dcfabfdfeb1"
  :keywords '("tools" "convenience"))
