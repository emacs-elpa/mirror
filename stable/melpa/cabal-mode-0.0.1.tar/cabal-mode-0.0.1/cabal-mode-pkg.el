;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cabal-mode" "0.0.1"
  "Support for Cabal packages."
  '((emacs "24.4"))
  :url "https://github.com/webdevred/cabal-mode"
  :commit "ae5a7c7ac99c199bebc7f3bf69900906d8ced883"
  :revdesc "ae5a7c7ac99c"
  :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainers '(("Stefan Monnier" . "monnier@iro.umontreal.ca")))
