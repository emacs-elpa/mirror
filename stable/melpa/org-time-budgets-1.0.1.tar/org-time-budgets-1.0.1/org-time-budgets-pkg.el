;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-time-budgets" "1.0.1"
  "Define time budgets and display clocked time."
  '((alert  "0.5.10")
    (cl-lib "0.5"))
  :url "https://github.com/leoc/org-time-budgets"
  :commit "f2a8fe3d9d6104f3dd61fabbb385a596363b360b"
  :revdesc "f2a8fe3d9d61"
  :authors '(("Arthur Leonard Andersen" . "leoc.git@gmail.com"))
  :maintainers '(("Arthur Leonard Andersen" . "leoc.git@gmail.com")))
