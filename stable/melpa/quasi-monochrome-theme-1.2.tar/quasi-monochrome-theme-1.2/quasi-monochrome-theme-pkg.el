;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quasi-monochrome-theme" "1.2"
  "High contrast quasi monochrome color theme."
  '((evil     "1.2")
    (flycheck "29"))
  :url "https://github.com/lbolla/emacs-quasi-monochrome"
  :commit "68060dbbc0bbfe4924387392874186c5a29bb434"
  :revdesc "68060dbbc0bb"
  :keywords '("color-theme" "monochrome" "high contrast")
  :authors '(("Lorenzo Bolla" . "lbolla@gmail.com"))
  :maintainers '(("Lorenzo Bolla" . "lbolla@gmail.com")))
