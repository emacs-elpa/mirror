;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-social-graph" "1.0"
  "A social network graph module for ERC."
  ()
  :url "https://github.com/vibhavp/erc-social-graph"
  :commit "8ef570576af3ad18ffb3f4233b4a4bd54096d528"
  :revdesc "8ef570576af3"
  :keywords '("erc" "graph")
  :authors '(("Vibhav Pant" . "vibhavp@gmail.com"))
  :maintainers '(("Vibhav Pant" . "vibhavp@gmail.com")))
