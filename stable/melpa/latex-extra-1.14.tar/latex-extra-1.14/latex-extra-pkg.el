;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-extra" "1.14"
  "Adds several useful functionalities to LaTeX-mode."
  '((auctex "11.86.1")
    (cl-lib "0.5"))
  :url "https://github.com/Malabarba/latex-extra"
  :commit "82d99b8b0c2db20e5270749582e03bcc2443ffb5"
  :revdesc "82d99b8b0c2d"
  :keywords '("tex")
  :authors '(("Artur Malabarba" . "artur@endlessparentheses.com"))
  :maintainers '(("Artur Malabarba" . "artur@endlessparentheses.com")))
