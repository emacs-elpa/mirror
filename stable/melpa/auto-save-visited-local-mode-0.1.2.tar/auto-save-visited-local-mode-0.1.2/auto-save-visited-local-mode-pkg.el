;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-save-visited-local-mode" "0.1.2"
  "Buffer-local auto-save for visited files."
  '((emacs "26.1"))
  :url "https://github.com/pierrelegall/auto-save-visited-local-mode"
  :commit "78a46d8a02360b4c63e45496bd32efe351459c81"
  :revdesc "78a46d8a0236"
  :keywords '("convenience" "files" "autosave")
  :authors '(("Pierre Le Gall" . "pierre@legall.im"))
  :maintainers '(("Pierre" . "pierre@legall.im")))
