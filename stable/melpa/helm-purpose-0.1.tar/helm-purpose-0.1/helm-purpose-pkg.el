;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-purpose" "0.1"
  "Helm Interface for Purpose."
  '((emacs          "24")
    (helm           "1.9.2")
    (window-purpose "1.4"))
  :url "https://github.com/bmag/helm-purpose"
  :commit "115a9d612aa07bb6f7f7b18f42b34918699660b9"
  :revdesc "115a9d612aa0")
