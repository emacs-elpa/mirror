;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-formatter" "0.4"
  "Use JuliaFormatter.jl for julia code."
  '((emacs         "27.1")
    (session-async "0.0.5"))
  :url "https://codeberg.org/FelipeLema/julia-formatter.el"
  :commit "5ae0e4d67459b65a82dae3622ee7283a0751d98f"
  :revdesc "5ae0e4d67459"
  :keywords '("convenience" "tools")
  :authors '(("Felipe Lema" . "felipe.lema@mortemale.org"))
  :maintainers '(("Felipe Lema" . "felipe.lema@mortemale.org")))
