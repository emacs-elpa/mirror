;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitignore-templates" "1.0"
  "Create .gitignore using GitHub or gitignore.io API."
  '((emacs "24.3"))
  :url "https://github.com/xuchunyang/gitignore-templates.el"
  :commit "b147d1930645dda76dbd48fb6f4f7f790353de26"
  :revdesc "b147d1930645"
  :keywords '("tools"))
