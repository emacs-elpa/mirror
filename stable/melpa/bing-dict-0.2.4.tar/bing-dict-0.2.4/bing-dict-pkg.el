;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bing-dict" "0.2.4"
  "Minimalists' English-Chinese Bing dictionary."
  ()
  :url "https://github.com/cute-jumper/bing-dict.el"
  :commit "52718ae3a3abfa5e5457239ee7ddf8f0c23a79a7"
  :revdesc "52718ae3a3ab"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
