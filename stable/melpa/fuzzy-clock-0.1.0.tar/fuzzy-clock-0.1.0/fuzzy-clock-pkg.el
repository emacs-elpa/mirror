;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuzzy-clock" "0.1.0"
  "Display time in a human-friendly, approximate way."
  '((emacs "24.4"))
  :url "https://github.com/example/fuzzy-clock"
  :commit "90a6878791ab50efb81e6dd43ad5c68e50720186"
  :revdesc "90a6878791ab"
  :keywords '("calendar" "time"))
