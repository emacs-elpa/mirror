;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-springboard" "1.0"
  "[No description available]."
  ()
  :url "https://github.com/jwiegley/springboard"
  :commit "4fd0a8b208669ff4e6f0d568339a05bf016b317a"
  :revdesc "4fd0a8b20866"
  :keywords '("ido")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("John Wiegley" . "jwiegley@gmail.com")))
