;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "move-mode" "1.1.2"
  "A major-mode for editing Move language."
  '((emacs "25.1"))
  :url "https://github.com/amnn/move-mode"
  :commit "e72e2d5102669b82ba70599fb64e64241d49376d"
  :revdesc "e72e2d510266"
  :keywords '("languages"))
