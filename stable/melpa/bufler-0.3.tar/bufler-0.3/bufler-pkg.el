;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufler" "0.3"
  "Group buffers into workspaces with programmable rules."
  '((emacs         "26.3")
    (dash          "2.18")
    (f             "0.17")
    (pretty-hydra  "0.2.2")
    (magit-section "0.1")
    (map           "2.1"))
  :url "https://github.com/alphapapa/bufler.el"
  :commit "3a6176d0e074bb00ea8b3fef4f7e03957a3ea058"
  :revdesc "v0.3-0-g3a6176d0e074"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
