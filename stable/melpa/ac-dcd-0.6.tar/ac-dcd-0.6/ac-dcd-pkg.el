;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-dcd" "0.6"
  "Auto Completion source for dcd for GNU Emacs."
  '((auto-complete    "1.3.1")
    (flycheck-dmd-dub "0.7"))
  :url "https://github.com/atilaneves/ac-dcd"
  :commit "d378d33c7bedc6c108eda7f674bd0aa1d8664857"
  :revdesc "V0.6-0-gd378d33c7bed"
  :keywords '("languages")
  :authors '((nil . "atila.neves@gmail.com"))
  :maintainers '((nil . "atila.neves@gmail.com")))
