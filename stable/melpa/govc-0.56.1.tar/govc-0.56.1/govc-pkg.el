;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "govc" "0.56.1"
  "Interface to govc for managing VMware ESXi and vCenter."
  '((emacs       "24.3")
    (dash        "1.5.0")
    (s           "1.9.0")
    (magit-popup "2.0.50")
    (json-mode   "1.6.0"))
  :url "https://github.com/vmware/govmomi/tree/main/govc/emacs"
  :commit "e45bf1c80c5bc1b227fbd747d4b31464460537a2"
  :revdesc "v0.56.1-0-ge45bf1c80c5b"
  :keywords '("convenience"))
