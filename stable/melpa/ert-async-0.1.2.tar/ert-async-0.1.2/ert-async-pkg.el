;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-async" "0.1.2"
  "Async support for ERT."
  ()
  :url "https://github.com/rejeep/ert-async.el"
  :commit "f64a7ed5b0d2900c9a3d8cc33294bf8a79bc8526"
  :revdesc "f64a7ed5b0d2"
  :keywords '("test")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
