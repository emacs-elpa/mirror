;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "number" "0.0.0.20170901.8"
  "Working with numbers at point."
  ()
  :url "https://github.com/emacsattic/number"
  :commit "bbc278d34dbcca83e70e3be855ec98b23debfb99"
  :revdesc "bbc278d34dbc")
