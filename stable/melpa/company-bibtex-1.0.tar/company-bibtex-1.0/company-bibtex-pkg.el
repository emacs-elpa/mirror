;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-bibtex" "1.0"
  "Company completion for bibtex keys."
  '((cl-lib   "1.0")
    (parsebib "1.0"))
  :url "https://github.com/gbgar/company-bibtex"
  :commit "3bd492f34b02aedfcd56e1e4055343a527cdc7a6"
  :revdesc "3bd492f34b02"
  :keywords '("company-mode" "bibtex")
  :authors '(("GB Gardner" . "gbgar@users.noreply.github.com"))
  :maintainers '(("GB Gardner" . "gbgar@users.noreply.github.com")))
