;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-list" "0.0.1"
  "Create dired listings from sources."
  '((dash "2.9.0"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "913b7b41a2fae0ca78123a9f2e36ea9fc181e540"
  :revdesc "913b7b41a2fa"
  :keywords '("files")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
