;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tidal" "1.10.2"
  "Interact with TidalCycles for live coding patterns."
  '((haskell-mode "16")
    (emacs        "25.1"))
  :url "https://codeberg.org/uzu/tidal"
  :commit "864b8cc18efc2e999e65e676a5ec1670dbd186e9"
  :revdesc "864b8cc18efc"
  :keywords '("tools")
  :authors '((nil . "alex@slab.org"))
  :maintainers '((nil . "alex@slab.org")))
