;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metaweblog" "1.1.18"
  "An XML-RPC MetaWeblog and WordPress API client."
  '((emacs "29.4"))
  :url "https://github.com/org2blog/org2blog"
  :commit "175244a0b7dae8211cf42c17a51c35e9236eda71"
  :revdesc "v1.1.18-0-g175244a0b7da"
  :keywords '("comm")
  :authors '(("Puneeth Chaganti" . "punchagan+org2blog@gmail.com"))
  :maintainers '(("Grant Rettke" . "grant@wisdomandwonder.com")))
