;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "w32-ime" "0.0.1"
  "Windows IME UI/UX controler."
  '((emacs "24.4"))
  :url "https://github.com/trueroad/w32-ime.el"
  :commit "1dbdc056f507172857195b5e14b7550c565018bc"
  :revdesc "v0.0.1-0-g1dbdc056f507"
  :authors '(("Masamichi Hosoda" . "trueroad@trueroad.jp")
             ("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Masamichi Hosoda" . "trueroad@trueroad.jp")))
