;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magrant" "0.1.0"
  "Emacs interface to Vagrant."
  '((emacs     "25.1")
    (cl-lib    "0.6.1")
    (dash      "2.17.0")
    (s         "1.12.0")
    (tablist   "0.70")
    (transient "0.2.0"))
  :url "https://github.com/p3r7/magrant"
  :commit "d1174df1c8ca741ef6acc0ee81ed7bda596214a1"
  :revdesc "d1174df1c8ca"
  :keywords '("processes" "terminals"))
