;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elmpd" "1.0.2"
  "A tight, ergonomic, async client library for mpd."
  '((emacs "25.1"))
  :url "https://github.com/sp1ff/elmpd"
  :commit "40a666c153da0c45262230bed3c7594e3362ca09"
  :revdesc "1.0.2-0-g40a666c153da"
  :keywords '("comm")
  :authors '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainers '(("Michael Herstine" . "sp1ff@pobox.com")))
