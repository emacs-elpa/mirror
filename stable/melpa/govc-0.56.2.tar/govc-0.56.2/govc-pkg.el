;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "govc" "0.56.2"
  "Interface to govc for managing VMware ESXi and vCenter."
  '((emacs       "24.3")
    (dash        "1.5.0")
    (s           "1.9.0")
    (magit-popup "2.0.50")
    (json-mode   "1.6.0"))
  :url "https://github.com/vmware/govmomi/tree/main/govc/emacs"
  :commit "10a792caabf08426f90d2e58d4a3a41b0a427c0b"
  :revdesc "v0.56.2-0-g10a792caabf0"
  :keywords '("convenience"))
