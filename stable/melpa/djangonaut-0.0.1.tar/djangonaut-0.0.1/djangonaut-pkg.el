;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "djangonaut" "0.0.1"
  "Emacs minor mode for Django."
  '((emacs    "24")
    (pythonic "0.1.0")
    (hydra    "0.14.0")
    (dash     "2.6.0")
    (s        "1.9"))
  :url "https://github.com/proofit404/djangonaut"
  :commit "2607c88b9e8105b0552b71262d2a60935419c57a"
  :revdesc "2607c88b9e81"
  :authors '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers '(("Artem Malyshev" . "proofit404@gmail.com")))
