(define-package "ejc-sql" "0.4.1" "Emacs SQL client uses Clojure JDBC."
  '((emacs "26.3")
    (clomacs "0.0.4")
    (dash "2.16.0")
    (spinner "1.7.3")
    (direx "1.0.0"))
  :commit "ddbae7be2aed9c273d9d570c542936f1faa3088f" :authors
  '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers
  '(("Kostafey" . "kostafey@gmail.com"))
  :maintainer
  '("Kostafey" . "kostafey@gmail.com")
  :keywords
  '("sql" "jdbc")
  :url "https://github.com/kostafey/ejc-sql")
;; Local Variables:
;; no-byte-compile: t
;; End:
