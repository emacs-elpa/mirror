;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "0.4.1"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "26.3")
    (clomacs "0.0.4")
    (dash    "2.16.0")
    (spinner "1.7.3")
    (direx   "1.0.0"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "3cf8d6f2f88aeeb2371f787e6c10b6d914c00128"
  :revdesc "3cf8d6f2f88a"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
