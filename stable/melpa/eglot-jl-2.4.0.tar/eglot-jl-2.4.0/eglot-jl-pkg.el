;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-jl" "2.4.0"
  "Julia support for eglot."
  '((emacs      "25.1")
    (eglot      "1.4")
    (project    "0.8.1")
    (cl-generic "1.0"))
  :url "https://github.com/non-Jedi/eglot-jl"
  :commit "7c968cc61fb64016ebe6dc8ff83fd05923db4374"
  :revdesc "v2.4.0-0-g7c968cc61fb6"
  :keywords '("convenience" "languages")
  :authors '(("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz"))
  :maintainers '(("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz")))
