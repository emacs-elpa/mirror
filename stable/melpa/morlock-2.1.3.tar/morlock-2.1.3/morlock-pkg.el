;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morlock" "2.1.3"
  "More font-lock keywords for elisp."
  '((emacs "29.1"))
  :url "https://github.com/tarsius/morlock"
  :commit "4ec0253ffbac4764b90457bb3b887b0a07badb20"
  :revdesc "v2.1.3-0-g4ec0253ffbac"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev")))
