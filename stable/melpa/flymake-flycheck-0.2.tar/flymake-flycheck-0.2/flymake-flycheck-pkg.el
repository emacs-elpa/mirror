;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-flycheck" "0.2"
  "Use flycheck checkers as flymake backends."
  '((flycheck "31")
    (emacs    "26.1"))
  :url "https://github.com/purcell/flymake-flycheck"
  :commit "cc50a97ee1384d260c56aca257a1dbf770084330"
  :revdesc "cc50a97ee138"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
