;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rdxmk" "0.10"
  "A small set of tools for redox development in Gnu Emacs."
  ()
  :url "https://github.com/jsalzbergedu/rdxmk"
  :commit "b63e4159e0b0acbd0d399954dbe4427ba222f209"
  :revdesc "b63e4159e0b0"
  :keywords '("redox")
  :authors '(("Jacob Salzberg" . "jsalzbergedu@yahoo.com"))
  :maintainers '(("Jacob Salzberg" . "jsalzbergedu@yahoo.com")))
