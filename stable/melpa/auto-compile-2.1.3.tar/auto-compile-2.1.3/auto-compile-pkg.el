;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-compile" "2.1.3"
  "Automatically compile Emacs Lisp libraries."
  '((emacs "27.1"))
  :url "https://github.com/emacscollective/auto-compile"
  :commit "cc51aea86617cab6cb1ef76672a343f2bf3206c1"
  :revdesc "v2.1.3-0-gcc51aea86617"
  :keywords '("compile" "convenience" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev")))
