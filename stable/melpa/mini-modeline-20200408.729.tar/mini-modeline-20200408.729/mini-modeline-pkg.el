;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mini-modeline" "20200408.729"
  "Display modeline in minibuffer."
  '((emacs "25.1")
    (dash  "2.12.0"))
  :url "https://github.com/kiennq/emacs-mini-modeline"
  :commit "b761e41479a2564e801ac6c427956203de3d62ca"
  :revdesc "b761e41479a2"
  :keywords '("convenience" "tools")
  :authors '(("Kien Nguyen" . "kien.n.quang@gmail.com"))
  :maintainers '(("Kien Nguyen" . "kien.n.quang@gmail.com")))
