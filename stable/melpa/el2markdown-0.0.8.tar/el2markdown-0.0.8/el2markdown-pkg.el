;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el2markdown" "0.0.8"
  "Convert commentary of elisp files to markdown."
  ()
  :url "https://github.com/Lindydancer/el2markdown"
  :commit "66f11d8e46f2def11b3c46abdc114bfd9cfa185e"
  :revdesc "66f11d8e46f2")
