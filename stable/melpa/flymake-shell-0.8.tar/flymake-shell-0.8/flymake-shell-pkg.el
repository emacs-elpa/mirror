;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-shell" "0.8"
  "A flymake syntax-checker for shell scripts."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-shell"
  :commit "ec097bd77db5523a04ceb15a128e01689d36fb90"
  :revdesc "ec097bd77db5"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
