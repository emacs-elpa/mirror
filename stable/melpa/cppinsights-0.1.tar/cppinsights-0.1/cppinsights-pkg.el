;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cppinsights" "0.1"
  "Integration with cppinsights tool."
  '((emacs "26.1"))
  :url "https://github.com/ignity21/cppinsights.el"
  :commit "70ef9813ddd9f7e3b3cbab7af3a2705c08efdfce"
  :revdesc "70ef9813ddd9"
  :keywords '("c++" "tools" "cppinsights")
  :authors '(("Chris Chen" . "chrischen@ignity.xyz"))
  :maintainers '(("Chris Chen" . "chrischen@ignity.xyz")))
