;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-html-angular" "1.5.0"
  "Auto complete angular15 data for `ac-html' and `company-web'."
  '((web-completion-data "0.1"))
  :url "https://github.com/osv/ac-html-bootstrap"
  :commit "e398f0a8f2c03905e64e4cc3905fcf5cc36f55a0"
  :revdesc "e398f0a8f2c0"
  :keywords '("html" "auto-complete" "bootstrap" "cssx")
  :authors '(("Olexandr Sydorchuk" . "olexandr.syd@gmail.com"))
  :maintainers '(("Olexandr Sydorchuk" . "olexandr.syd@gmail.com")))
