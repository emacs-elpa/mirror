;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2wm-pkgex4pl" "0.0.1"
  "Plugin of e2wm.el for package explorer of Perl."
  '((e2wm          "1.2")
    (plsense-direx "0.2.0"))
  :url "https://github.com/aki2o/e2wm-pkgex4pl"
  :commit "7ea994450727190c4f3cb46cb429ba41b692ecc0"
  :revdesc "7ea994450727"
  :keywords '("tools" "window manager" "perl")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
