;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hima-theme" "0.1"
  "A minimal theme with pretty colors."
  '((emacs "25.1"))
  :url "https://github.com/meain/hima-theme"
  :commit "309a6cbca2d779b11ac53f21052fa7529dd5c788"
  :revdesc "309a6cbca2d7"
  :keywords '("theme"))
