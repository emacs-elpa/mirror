;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "protobuf-mode" "35.0"
  "Major mode for editing protocol buffers."
  ()
  :url "https://github.com/protocolbuffers/protobuf"
  :commit "e59364c38e10de3686a3305ff11fbfc59a10dbd8"
  :revdesc "v35.0-0-ge59364c38e10"
  :keywords '("google" "protobuf" "languages")
  :authors '(("Alexandre Vassalotti" . "alexandre@peadrop.com"))
  :maintainers '(("Alexandre Vassalotti" . "alexandre@peadrop.com")))
