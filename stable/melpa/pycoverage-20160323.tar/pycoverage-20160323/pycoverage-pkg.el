;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pycoverage" "20160323"
  "Support for coverage stats on Python 2.X and 3."
  ()
  :url "https://github.com/mattharrison/pycoverage.el"
  :commit "ad7aaf9d56c2646d886a2b6e0a16bf67f2b33a9f"
  :revdesc "ad7aaf9d56c2"
  :keywords '("project" "convenience"))
