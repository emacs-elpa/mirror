;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-view-data" "0.1"
  "View data in python."
  '((emacs    "26.1")
    (python   "0.2")
    (csv-mode "1.12"))
  :url "https://github.com/ShuguangSun/python-view-data"
  :commit "4c0226e8c71b579dcd7e9df71f3ed8ed85b55e5f"
  :revdesc "4c0226e8c71b"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
