;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "green-screen-theme" "1.0.26"
  "A nice color theme for those who miss green CRTs."
  ()
  :url "https://github.com/rbanffy/green-screen-emacs"
  :commit "774e8f6c033786406267f71ec07319d906a30b75"
  :revdesc "774e8f6c0337"
  :keywords '("faces" "theme")
  :authors '(("Ricardo Banffy" . "rbanffy@gmail.com"))
  :maintainers '(("Ricardo Banffy" . "rbanffy@gmail.com")))
