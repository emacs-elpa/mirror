;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-perldoc" "0.7"
  "Perldoc with helm interface."
  '((helm     "1.0")
    (deferred "0.3.1")
    (cl-lib   "0.5"))
  :url "https://github.com/syohex/emacs-helm-perldoc"
  :commit "18645f2065a07acce2c6b50a2f9d7a2554e532a3"
  :revdesc "18645f2065a0"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
