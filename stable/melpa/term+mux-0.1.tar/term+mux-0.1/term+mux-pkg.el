;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term+mux" "0.1"
  "Term+ terminal multiplexer and session management."
  ()
  :url "https://github.com/tarao/term+-el"
  :commit "da558c5972effd4babb724e5d1e3c7c8bfb0faaa"
  :revdesc "da558c5972ef"
  :keywords '("terminal" "emulation")
  :authors '(("INA Lintaro" . "tarao.gnnatgmail.com"))
  :maintainers '(("INA Lintaro" . "tarao.gnnatgmail.com")))
