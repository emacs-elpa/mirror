;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slothbar" "0.30.1"
  "Emacs X window manager status bar."
  '((all-the-icons "5.0.0")
    (backlight     "1.4")
    (compat        "29.1")
    (dash          "2.1.0")
    (f             "0.20.0")
    (fontsloth     "0.19.1")
    (log4e         "0.3.3")
    (nerd-icons    "0.1.0")
    (s             "1.12.0")
    (volume        "1.0")
    (xelb          "0.18")
    (emacs         "28.1"))
  :url "https://codeberg.org/agnes-li/slothbar"
  :commit "f8066074a93dd6e2be54c4a5e503df9f78178a3e"
  :revdesc "v0.30.1-0-gf8066074a93d"
  :keywords '("frames" "hardware")
  :authors '(("Jo Gay" . "jo.gay@mailfence.com")
             ("Agnes Li" . "agnes.li@mailfence.com"))
  :maintainers '(("Jo Gay" . "jo.gay@mailfence.com")
                 ("Agnes Li" . "agnes.li@mailfence.com")))
