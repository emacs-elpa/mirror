;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "virtualenv" "1.2.1"
  "Virtualenv for Python."
  ()
  :url "https://github.com/aculich/virtualenv.el"
  :commit "4eaad87c83fde1264dc0fa32478699deecde81bd"
  :revdesc "4eaad87c83fd"
  :keywords '("python" "virtualenv")
  :authors '(("Aaron Culich" . "aculich@gmail.com"))
  :maintainers '(("Aaron Culich" . "aculich@gmail.com")))
