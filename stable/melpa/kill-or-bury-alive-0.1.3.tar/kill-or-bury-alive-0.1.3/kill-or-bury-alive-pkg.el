;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kill-or-bury-alive" "0.1.3"
  "Precise control over buffer killing in Emacs."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/mrkkrp/kill-or-bury-alive"
  :commit "51daf55565034b8cb6aa3ca2aa0a827e31751041"
  :revdesc "51daf5556503"
  :keywords '("buffer" "killing" "convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
