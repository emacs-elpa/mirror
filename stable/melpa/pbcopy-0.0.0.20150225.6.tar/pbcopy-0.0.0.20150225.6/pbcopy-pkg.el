;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pbcopy" "0.0.0.20150225.6"
  "Emacs Interface to pbcopy."
  ()
  :url "https://github.com/jkp/pbcopy.el"
  :commit "338f7245746b5de1bb96c5cc2b32bfd9b5d83272"
  :revdesc "338f7245746b"
  :keywords '("mac" "osx" "pbcopy"))
