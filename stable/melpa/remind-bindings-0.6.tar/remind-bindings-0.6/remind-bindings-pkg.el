;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remind-bindings" "0.6"
  "Reminders for your init bindings."
  '((emacs "25.1"))
  :url "https://github.com/mtekman/remind-bindings.el"
  :commit "93b62b9ee50d23bab383ae830300e65364a3c975"
  :revdesc "93b62b9ee50d"
  :keywords '("outlines"))
