;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docean" "0.0.1"
  "Interact with DigitalOcean from Emacs."
  '((request "0.2.0")
    (ctable  "0.1.2"))
  :url "https://github.com/emacs-pe/docean.el"
  :commit "fbc34a3e5781cde8fc00ab394c6564c06930cb16"
  :revdesc "fbc34a3e5781"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
