;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-nimsuggest" "0.8.1"
  "Flycheck backend for Nim using nimsuggest."
  '((flycheck "0.23")
    (nim-mode "0.4.1")
    (emacs    "24"))
  :url "https://github.com/yuutayamada/flycheck-nimsuggest"
  :commit "8b1c69e9aa924368bc4dadd4cde818ff158cd3f0"
  :revdesc "8b1c69e9aa92"
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
