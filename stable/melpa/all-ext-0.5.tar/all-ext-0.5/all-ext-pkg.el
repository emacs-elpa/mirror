;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "all-ext" "0.5"
  "M-x all with helm-swoop/anything/multiple-cursors/line-number."
  '((all "1.0"))
  :url "https://github.com/rubikitch/all-ext"
  :commit "9f4ef84a147cf4e0af6ef45826d6cb3558db6b88"
  :revdesc "9f4ef84a147c"
  :keywords '("all" "search" "replace" "anything" "helm" "helm-swoop" "occur")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
