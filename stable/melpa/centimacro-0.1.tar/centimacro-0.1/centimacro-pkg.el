;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "centimacro" "0.1"
  "Assign multiple macros as global key bindings."
  ()
  :url "https://github.com/abo-abo/centimacro"
  :commit "80f5957f9f3a7e1ec3a89ffdb4d6e190f4cb1a38"
  :revdesc "80f5957f9f3a"
  :keywords '("macros")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
