;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-raindrop" "0.2.0"
  "Raindrop.io with helm interface."
  '((emacs   "29.1")
    (helm    "4.0.4")
    (request "0.3.2"))
  :url "https://github.com/masutaka/emacs-helm-raindrop"
  :commit "0c87eddc7f15c2046b9b03b83a8a7ee0551a0747"
  :revdesc "0.2.0-0-g0c87eddc7f15"
  :authors '(("Takashi Masuda" . "masutaka.net@gmail.com"))
  :maintainers '(("Takashi Masuda" . "masutaka.net@gmail.com")))
