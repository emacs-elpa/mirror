;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "msvc" "1.4.3"
  "Microsoft Visual C/C++ mode."
  '((emacs    "24")
    (cl-lib   "0.5")
    (cedet    "1.0")
    (ac-clang "2.0.0"))
  :url "https://github.com/yaruopooner/msvc"
  :commit "1bf173b5da3fbf2bdb799116e2a1f31916c1e16e"
  :revdesc "v1.4.3-0-g1bf173b5da3f"
  :keywords '("languages" "completion" "syntax check" "mode" "intellisense"))
