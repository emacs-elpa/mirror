;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aurel" "0.10"
  "Search, get info, vote for and download AUR packages."
  '((emacs "29.1")
    (bui   "1.1.0"))
  :url "https://github.com/alezost/aurel"
  :commit "c571cc44ea3b9aa96399056bff22919efffbbb06"
  :revdesc "c571cc44ea3b"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
