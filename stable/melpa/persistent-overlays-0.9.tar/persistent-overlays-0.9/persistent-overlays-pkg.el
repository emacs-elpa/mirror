;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persistent-overlays" "0.9"
  "Minor mode to store selected overlays to be loaded later."
  ()
  :url "https://github.com/mneilly/Emacs-Persistent-Overlays"
  :commit "8f73f456b3c08c0b079cebf888b409c3a6f86d0d"
  :revdesc "8f73f456b3c0"
  :keywords '("overlays" "persistent")
  :authors '(("Michael Neilly" . "mneilly@yahoo.com"))
  :maintainers '(("Michael Neilly" . "mneilly@yahoo.com")))
