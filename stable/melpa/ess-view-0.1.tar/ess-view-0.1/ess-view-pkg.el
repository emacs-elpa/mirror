;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-view" "0.1"
  "A small package to view dataframes within spreadsheet softwares."
  ()
  :url "https://github.com/GioBo/ess-view"
  :commit "10ef51b3582ccf5446fbf1f5c008b98c9a63929e"
  :revdesc "10ef51b3582c"
  :authors '(("boccigionata" . "boccigionata@gmail.com"))
  :maintainers '(("boccigionata" . "boccigionata@gmail.com")))
