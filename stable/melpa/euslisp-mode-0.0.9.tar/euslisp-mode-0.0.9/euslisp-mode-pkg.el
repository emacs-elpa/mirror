;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "euslisp-mode" "0.0.9"
  "Major mode for Euslisp-formatted text."
  '((emacs                "23")
    (s                    "1.9")
    (exec-path-from-shell "0")
    (helm-ag              "0.58"))
  :url "https://github.com/iory/euslisp-mode"
  :commit "80b6cfd9a0925f8d47a8b1da7222329d442db162"
  :revdesc "80b6cfd9a092"
  :keywords '("euslisp" "euslisp" "github")
  :authors '(("iory" . "ab.ioryz@gmail.com"))
  :maintainers '(("iory" . "ab.ioryz@gmail.com")))
