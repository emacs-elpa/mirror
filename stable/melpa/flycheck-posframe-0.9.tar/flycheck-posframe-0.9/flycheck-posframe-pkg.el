;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-posframe" "0.9"
  "Show flycheck error messages using posframe.el."
  '((flycheck "0.24")
    (emacs    "26")
    (posframe "0.7.0"))
  :url "https://github.com/alexmurray/flycheck-posframe"
  :commit "8f60c9bf124ab9597d681504a73fdf116a0bde12"
  :revdesc "8f60c9bf124a"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
