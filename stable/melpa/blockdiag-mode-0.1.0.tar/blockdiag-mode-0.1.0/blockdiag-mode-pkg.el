;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blockdiag-mode" "0.1.0"
  "Major mode for editing blockdiag files."
  ()
  :url "https://github.com/xcezx/xdiag-mode"
  :commit "c1304237b8f4e5ee3c28bb2fd129f303c179d105"
  :revdesc "c1304237b8f4"
  :authors '(("xcezx" . "main.xcezx@gmail.com"))
  :maintainers '(("xcezx" . "main.xcezx@gmail.com")))
