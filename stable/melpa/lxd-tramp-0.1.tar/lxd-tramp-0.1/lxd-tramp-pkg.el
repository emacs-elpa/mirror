;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lxd-tramp" "0.1"
  "TRAMP integration for LXD containers."
  '((emacs  "24.4")
    (cl-lib "0.6"))
  :url "https://github.com/onixie/lxd-tramp.git"
  :commit "327c5ae47dcc39ceeeafe18b6d80ad21d73b8c7e"
  :revdesc "327c5ae47dcc"
  :keywords '("lxd" "lxc" "convenience")
  :authors '(("Yc.S" . "onixie@gmail.com"))
  :maintainers '(("Yc.S" . "onixie@gmail.com")))
