;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vcomp" "1.2.0"
  "Compare version strings."
  '((emacs "26.1"))
  :url "https://github.com/tarsius/vcomp"
  :commit "2227de68c2fc4d7a029bd30d188422429bb18d28"
  :revdesc "v1.2.0-0-g2227de68c2fc"
  :keywords '("versions")
  :authors '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
