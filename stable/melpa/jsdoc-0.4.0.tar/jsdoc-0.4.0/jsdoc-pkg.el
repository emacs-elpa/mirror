;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsdoc" "0.4.0"
  "Insert JSDoc comments."
  '((emacs "29.1")
    (dash  "2.11.0")
    (s     "1.12.0"))
  :url "https://github.com/isamert/jsdoc.el"
  :commit "5b514ad23834b7a584b184125ba4a66bc3c26cff"
  :revdesc "5b514ad23834"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
