;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "labburn-theme" "1.0.0"
  "A lab color space zenburn theme."
  ()
  :url "https://github.com/ksjogo/labburn-theme"
  :commit "bfa1d9f1c7e107cb45754fe57e4e72a9be70e9d1"
  :revdesc "bfa1d9f1c7e1"
  :keywords '("theme" "zenburn"))
