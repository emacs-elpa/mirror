;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.5"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "63bc6874a9f70a505e268d3d52983cc67fa3480c"
  :revdesc "63bc6874a9f7"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
