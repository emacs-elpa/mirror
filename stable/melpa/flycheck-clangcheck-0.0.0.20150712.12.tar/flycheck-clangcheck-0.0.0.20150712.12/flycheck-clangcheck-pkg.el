;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-clangcheck" "0.0.0.20150712.12"
  "A Flycheck checker difinition for ClangCheck."
  '((cl-lib   "0.5")
    (seq      "1.7")
    (flycheck "0.17"))
  :url "https://github.com/kumar8600/flycheck-clangcheck"
  :commit "24a9424c484420073a24443a829fd5779752362b"
  :revdesc "24a9424c4844"
  :authors '(("kumar8600" . "kumar8600@gmail.com"))
  :maintainers '(("kumar8600" . "kumar8600@gmail.com")))
