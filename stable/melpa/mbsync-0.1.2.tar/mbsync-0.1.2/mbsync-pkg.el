;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mbsync" "0.1.2"
  "Run mbsync to fetch mails."
  ()
  :url "https://github.com/dimitri/mbsync-el"
  :commit "d92928a4df79fa2c587e04df36726a34d11a65eb"
  :revdesc "d92928a4df79"
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
