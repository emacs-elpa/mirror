;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-review" "0.1"
  "GitHub based code review."
  '((emacs "25")
    (s     "1.12.0")
    (ghub  "2.0")
    (dash  "2.11.0"))
  :url "https://github.com/charignon/github-review"
  :commit "909b167e9dfdc47c73396709200ecfa759501bf6"
  :revdesc "909b167e9dfd"
  :keywords '("git" "tools" "vc" "github")
  :authors '(("Laurent Charignon" . "l.charignon@gmail.com"))
  :maintainers '(("Laurent Charignon" . "l.charignon@gmail.com")))
