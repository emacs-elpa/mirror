;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "p4-ts-mode" "0.1"
  "[No description available]."
  '((emacs "29.1"))
  :url "https://github.com/oxidecomputer/p4-ts-mode"
  :commit "a1fdc697549657cf3905caac6facd8f819a33393"
  :revdesc "a1fdc6975496"
  :keywords '("languages" "p4_16" "p4")
  :authors '(("Zeeshan Lakhani" . "zeeshan@oxidecomputer.com"))
  :maintainers '(("Zeeshan Lakhani" . "zeeshan@oxidecomputer.com")))
