;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blimp" "1.0"
  "Bustling Image Manipulation Package."
  '((eimp "1.4.0"))
  :url "https://github.com/walseb/blimp"
  :commit "626d08e038311f316affa18a7118b5fde3776c4a"
  :revdesc "626d08e03831"
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
