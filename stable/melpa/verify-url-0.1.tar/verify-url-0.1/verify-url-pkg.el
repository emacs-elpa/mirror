;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verify-url" "0.1"
  "Find out invalid urls in the buffer or region."
  ()
  :url "https://github.com/lujun9972/verify-url"
  :commit "8db6dbc83b6aeed48abd837e05fd17df9132856f"
  :revdesc "8db6dbc83b6a"
  :keywords '("convenience" "usability" "url")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
