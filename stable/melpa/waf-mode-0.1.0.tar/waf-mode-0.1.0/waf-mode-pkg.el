;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "waf-mode" "0.1.0"
  "Waf integration for Emacs."
  '((projectile "20151130.1039"))
  :url "https://bitbucket.org/dvalchuk/waf-mode"
  :commit "b0fb14aedf108b89e4f46b4386c5d9ea73e49e40"
  :revdesc "b0fb14aedf10"
  :authors '(("Denys Valchuk" . "dvalchuk@gmail.com"))
  :maintainers '(("Denys Valchuk" . "dvalchuk@gmail.com")))
