;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-coffeescript" "1.0.0"
  "Org-babel functions for coffee-script evaluation, and fully implementation!."
  ()
  :url "https://github.com/brantou/ob-coffeescript"
  :commit "b70f3d822c707cb02333fcb739ba4874614cad2a"
  :revdesc "b70f3d822c70"
  :keywords '("coffee-script" "literate programming" "reproducible research")
  :authors '(("Brantou" . "brantou89@gmail.com"))
  :maintainers '(("Brantou" . "brantou89@gmail.com")))
