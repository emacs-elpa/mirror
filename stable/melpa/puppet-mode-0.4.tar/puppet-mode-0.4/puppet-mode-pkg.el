;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "puppet-mode" "0.4"
  "Major mode for Puppet manifests."
  '((emacs    "24.1")
    (pkg-info "0.4"))
  :url "https://github.com/voxpupuli/puppet-mode"
  :commit "73ea35bc7a3ad663c5b73f65cb6377eb0ae11d6f"
  :revdesc "0.4-0-g73ea35bc7a3a"
  :keywords '("languages")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com")
             ("Sebastian Wiesner" . "swiesner@lunaryorn.com")
             ("Russ Allbery" . "rra@stanford.edu"))
  :maintainers '(("Tim Meusel" . "tim@bastelfreak.de")))
