;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-propose" "4.0.0"
  "Simple and safe undo navigation."
  '((emacs "24.3"))
  :url "https://github.com/jackkamm/undo-propose.el"
  :commit "20409358ad321fb937152cf93a50a4a775e405d6"
  :revdesc "20409358ad32"
  :keywords '("convenience" "files" "undo" "redo" "history"))
