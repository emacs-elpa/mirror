;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcomplete-extension" "1.0"
  "Additional completion for pcomplete."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/thierryvolpiatto/pcomplete-extension"
  :commit "839740c90de857e18db2f578d6660951522faab5"
  :revdesc "v1.0-0-g839740c90de8"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")))
