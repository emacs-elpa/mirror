;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "powerthesaurus" "0.4.0"
  "Powerthesaurus integration."
  '((emacs  "26.1")
    (jeison "1.0.0")
    (s      "1.13.0"))
  :url "https://github.com/SavchenkoValeriy/emacs-powerthesaurus"
  :commit "f2d624677f54b95509b63e69a9e3520d014c196e"
  :revdesc "f2d624677f54"
  :keywords '("convenience" "writing")
  :authors '(("Valeriy Savchenko" . "sinmipt@gmail.com"))
  :maintainers '(("Valeriy Savchenko" . "sinmipt@gmail.com")))
