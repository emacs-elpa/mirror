;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wakatime-mode" "1.1.0"
  "Automatic time tracking extension for WakaTime."
  '((emacs "28.1"))
  :url "https://github.com/wakatime/wakatime-mode"
  :commit "464ea0ea99696133553c565cdfc0966a496b1887"
  :revdesc "464ea0ea9969"
  :keywords '("calendar" "comm")
  :authors '(("Gabor Torok" . "gabor@20y.hu"))
  :maintainers '(("Alan Hamlett" . "alan@wakatime.com")))
