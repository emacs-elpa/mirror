;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-fonts" "0.4.10"
  "Configure Unicode fonts."
  '((font-utils      "0.7.8")
    (ucs-utils       "0.8.2")
    (list-utils      "0.4.2")
    (persistent-soft "0.8.10")
    (pcache          "0.3.1"))
  :url "https://github.com/rolandwalker/unicode-fonts"
  :commit "7b88ae84e589f6c8b9386b2fb5a02ff4ccb91169"
  :revdesc "v0.4.10-0-g7b88ae84e589"
  :keywords '("i18n" "faces" "frames" "wp" "interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
