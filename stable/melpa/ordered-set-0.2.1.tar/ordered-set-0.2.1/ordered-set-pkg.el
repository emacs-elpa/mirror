;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ordered-set" "0.2.1"
  "Insertion-order sets."
  '((emacs "25.3")
    (seq   "2.23"))
  :url "https://github.com/kisaragi-hiu/ordered-set.el"
  :commit "9688d9e39f365ac86f852c5381f294a757d3bdf4"
  :revdesc "9688d9e39f36"
  :keywords '("extensions" "sequences" "collection" "set")
  :authors '(("Kisaragi Hiu" . "mail@kisaragi-hiu.com"))
  :maintainers '(("Kisaragi Hiu" . "mail@kisaragi-hiu.com")))
