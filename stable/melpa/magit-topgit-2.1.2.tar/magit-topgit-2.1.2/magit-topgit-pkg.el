;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-topgit" "2.1.2"
  "TopGit extension for Magit."
  '((emacs "24.4")
    (magit "2.1.0"))
  :url "https://github.com/greenrd/magit-topgit"
  :commit "11489ea798bc88d0ea5244bbf725285eedfefbef"
  :revdesc "2.1.2-0-g11489ea798bc"
  :keywords '("vc" "tools")
  :authors '(("Yann Hodique" . "yann.hodique@gmail.com"))
  :maintainers '(("Robin Green" . "greenrd@greenrd.org")))
