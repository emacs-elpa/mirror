;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php" "2.8.1"
  "Auto Completion source for PHP."
  '((ac-php-core   "2.0")
    (auto-complete "1.4.0")
    (yasnippet     "0.8.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "b626cc6b3a343b2431f2e13b241b1612da5fc3f4"
  :revdesc "v2.8.1-0-gb626cc6b3a34"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
