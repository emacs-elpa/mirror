;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ast-grep" "0.3.0"
  "Search code using ast-grep with completing-read interface."
  '((emacs "28.1"))
  :url "https://github.com/sunskyxh/ast-grep.el"
  :commit "e95f7f219627ff11b5ca3ad62061b92c5a604a00"
  :revdesc "e95f7f219627"
  :keywords '("tools" "matching")
  :authors '(("SunskyxXH" . "sunskyxh@gmail.com"))
  :maintainers '(("SunskyxXH" . "sunskyxh@gmail.com")))
