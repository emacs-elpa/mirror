;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winum" "2.1.0"
  "Navigate windows and frames using numbers."
  '((cl-lib "0.5")
    (dash   "2.13.0"))
  :url "https://github.com/deb0ch/winum.el"
  :commit "efcb14fd306afbc738666e6b2e5a8a1bb5904392"
  :revdesc "efcb14fd306a"
  :keywords '("convenience" "frames" "windows" "multi-screen")
  :authors '(("Thomas de Beauchêne" . "thomas.de.beauchene@gmail.com"))
  :maintainers '(("Thomas de Beauchêne" . "thomas.de.beauchene@gmail.com")))
