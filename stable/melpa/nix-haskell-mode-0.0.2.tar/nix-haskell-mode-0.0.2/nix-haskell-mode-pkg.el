;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-haskell-mode" "0.0.2"
  "Haskell-mode integrations for Nix."
  '((emacs        "25")
    (haskell-mode "16.0")
    (flycheck     "30")
    (nix-mode     "1.3.0"))
  :url "https://github.com/matthewbauer/nix-haskell"
  :commit "1622924f0f6668f9b42f135323087ba94b1bf252"
  :revdesc "1622924f0f66"
  :keywords '("nix" "haskell" "languages" "processes")
  :authors '(("Matthew Bauer" . "mjbauer95@gmail.com"))
  :maintainers '(("Matthew Bauer" . "mjbauer95@gmail.com")))
