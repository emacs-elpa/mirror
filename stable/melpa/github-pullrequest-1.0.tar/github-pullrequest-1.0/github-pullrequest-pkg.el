;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-pullrequest" "1.0"
  "Create and fetch Github Pull requests with ease."
  '((emacs   "24.4")
    (request "0.2.0")
    (dash    "2.11.0"))
  :url "https://github.com/jakoblind/github-pullrequest"
  :commit "97273dc989b23be9761c3d14f823de620ed5e112"
  :revdesc "97273dc989b2"
  :keywords '("tools"))
