;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-pullrequest" "1.0"
  "Create and fetch Github Pull requests with ease."
  '((emacs   "24.4")
    (request "0.2.0")
    (dash    "2.11.0"))
  :url "https://github.com/jakoblind/github-pullrequest"
  :commit "562b71fa2cdd41d81fe004093da83f4295320c72"
  :revdesc "562b71fa2cdd"
  :keywords '("tools")
  :authors '(("Jakob Lind" . "karl.jakob.lind@gmail.com"))
  :maintainers '(("Jakob Lind" . "karl.jakob.lind@gmail.com")))
