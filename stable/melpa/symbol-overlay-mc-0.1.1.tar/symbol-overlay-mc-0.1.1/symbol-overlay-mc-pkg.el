;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symbol-overlay-mc" "0.1.1"
  "Symbol-overlay extensions to multiple-cursors."
  '((emacs            "28.1")
    (multiple-cursors "1.4.0")
    (symbol-overlay   "4.1"))
  :url "https://github.com/xenodium/symbol-overlay-mc"
  :commit "944b2e52077634eaca408b693f58abfd1a93ef6b"
  :revdesc "944b2e520776")
