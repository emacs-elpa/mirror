;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "govc" "0.54.1"
  "Interface to govc for managing VMware ESXi and vCenter."
  '((emacs       "24.3")
    (dash        "1.5.0")
    (s           "1.9.0")
    (magit-popup "2.0.50")
    (json-mode   "1.6.0"))
  :url "https://github.com/vmware/govmomi/tree/main/govc/emacs"
  :commit "e6cfff79a15f1c7e7a59187985132ee1685b8233"
  :revdesc "v0.54.1-0-ge6cfff79a15f"
  :keywords '("convenience"))
