;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-god-toggle" "1.0.0"
  "Toggle Evil and God Mode."
  '((emacs    "28.1")
    (evil     "1.0.8")
    (god-mode "2.12.0"))
  :url "https://github.com/jam1015/evil-god-toggle"
  :commit "a2e240e8ffdfff16ffa2be2517a7c60d3cc3ced9"
  :revdesc "v1.0.0-0-ga2e240e8ffdf"
  :keywords '("convenience" "emulation" "evil" "god-mode")
  :authors '(("Jordan Mandel" . "jordan.mandel@live.com"))
  :maintainers '(("Jordan Mandel" . "jordan.mandel@live.com")))
