;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vue-mode" "0.4"
  "Major mode for vue component based on mmm-mode."
  '((mmm-mode      "0.5.5")
    (vue-html-mode "0.2")
    (ssass-mode    "0.2")
    (edit-indirect "0.1.4"))
  :url "https://github.com/AdamNiederer/vue-mode"
  :commit "48ff04657613f39848d0e66e9dd367aa2dc19e89"
  :revdesc "0.4-0-g48ff04657613"
  :keywords '("languages")
  :authors '(("codefalling" . "code.falling@gmail.com"))
  :maintainers '(("codefalling" . "code.falling@gmail.com")))
