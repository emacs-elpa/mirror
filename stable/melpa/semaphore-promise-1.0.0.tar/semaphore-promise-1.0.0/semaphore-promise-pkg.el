;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "semaphore-promise" "1.0.0"
  "Semaphore integration with promise."
  ()
  :url "https://github.com/webnf/semaphore.el"
  :commit "306d5a84b99526213c3a7d367f8d8041961ea52a"
  :revdesc "306d5a84b995"
  :keywords '("thread" "parallelism" "concurrency")
  :authors '(("Herwig Hochleitner" . "herwig@bendlas.net"))
  :maintainers '(("Herwig Hochleitner" . "herwig@bendlas.net")))
