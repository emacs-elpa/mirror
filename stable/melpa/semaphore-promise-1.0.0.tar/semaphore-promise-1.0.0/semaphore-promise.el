;;; semaphore-promise.el --- semaphore integration with promise -*- lexical-binding: t; -*-

;; Copyright (C) 2019 Herwig Hochleitner

;; Author: Herwig Hochleitner <herwig@bendlas.net>
;; Maintainer: Herwig Hochleitner <herwig@bendlas.net>
;; Package-Version: 1.0.0
;; Package-Revision: 306d5a84b995
;; Keywords: thread, parallelism, concurrency
;; URL: http://github.com/webnf/semaphore.el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 3, or (at your option)
;; any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with GNU Emacs; see the file COPYING.  If not, write to the
;; Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
;; Boston, MA 02110-1301, USA.

;;; Commentary:

;; semaphore-gated-promise uses semaphore to implement a sort of
;; thread pool for promises

;;; Code:

(require 'semaphore)
(require 'promise)

(defun semaphore-gated-promise (semaphore handler)
  "Create a promise based on handler, like promise-new, but
   acquire and release the semaphore around resolving the
   handler (+ result promises).

   This is useful for controlling parallelism in asynchronous work flows:
   e.g. if you want to fetch 10000 files, but only 7 at a time:

   (let ((s (make-semaphore 7)))
     (promise-all
       (mapcar
         (lambda (url)
           (semaphore-gated-promise s
             (lambda (resolve _)
               (resolve (http-get url))))) ;; assuming http-get returns another promise
         url-list))"
  (if semaphore
      (promise-finally
       (promise-new
        (lambda (resolve reject)
          (semaphore-acquire semaphore)
          (funcall handler resolve reject)))
       (lambda ()
         (semaphore-release semaphore)))
    (promise-new handler)))


(provide 'semaphore-promise)

;;; semaphore-promise.el ends here
