;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enlive" "0.0.1"
  "Query html document with css selectors."
  ()
  :url "https://github.com/zweifisch/enlive"
  :commit "60facaf8bc48b660d209551c0ce4d17e5c907ab8"
  :revdesc "60facaf8bc48"
  :keywords '("css" "selector" "query")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
