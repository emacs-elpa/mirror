;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "1.5"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "f76cf45d4838c6c02130992240ac986045ae5cc4"
  :revdesc "f76cf45d4838"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
