;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-ini-pyinilint" "0.3"
  "Flycheck integration for PyINILint."
  '((flycheck "31"))
  :url "https://gitlab.com/danieljrmay/flycheck-ini-pyinilint"
  :commit "54744a78d06373404933fedc3ca836916e83de51"
  :revdesc "54744a78d063"
  :keywords '("convenience" "files" "tools")
  :authors '(("Daniel J. R. May" . "daniel.may@danieljrmay.com"))
  :maintainers '(("Daniel J. R. May" . "daniel.may@danieljrmay.com")))
