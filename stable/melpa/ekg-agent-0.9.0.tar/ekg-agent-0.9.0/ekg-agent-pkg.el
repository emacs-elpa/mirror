;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "0.9.0"
  "Agentic actions for ekg."
  '((emacs "28.1")
    (ekg   "0.8.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "be6cc349a5054154470173af6521e569cb21bcb1"
  :revdesc "be6cc349a505"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
