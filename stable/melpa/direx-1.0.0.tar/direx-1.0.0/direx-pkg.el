;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "direx" "1.0.0"
  "Simple Directory Explorer."
  ()
  :url "https://github.com/emacsorphanage/direx"
  :commit "423caeed13249e37afc937dc8134cb3c53e0f111"
  :revdesc "423caeed1324"
  :keywords '("convenience")
  :authors '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainers '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com")))
