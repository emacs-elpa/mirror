;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "subemacs" "1.0"
  "Evaluating expressions in a fresh Emacs subprocess."
  ()
  :url "https://github.com/kbauer/subemacs"
  :commit "24f0896f1995a3ea42a58b0452d250dcc6802944"
  :revdesc "24f0896f1995"
  :keywords '("extensions" "lisp" "multiprocessing")
  :authors '(("Klaus-Dieter Bauer" . "bauer.klaus.dieter@gmail.com"))
  :maintainers '(("Klaus-Dieter Bauer" . "bauer.klaus.dieter@gmail.com")))
