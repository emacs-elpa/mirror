;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-local" "0.1"
  "Allow different Lisp indentation in each buffer."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/lispunion/emacs-lisp-local"
  :commit "ff745a937f79df51cac0209b3cc3c35ce1d1fc61"
  :revdesc "0.1-0-gff745a937f79"
  :keywords '("languages" "lisp")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
