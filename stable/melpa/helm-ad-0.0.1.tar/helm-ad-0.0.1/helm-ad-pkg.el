;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ad" "0.0.1"
  "Helm source for Active Directory."
  '((dash "2.8.0"))
  :url "https://github.com/tnoda/helm-ad"
  :commit "ab93209a94cf3fb63c1d6bae561a9e109d366e5e"
  :revdesc "ab93209a94cf"
  :keywords '("comm")
  :authors '(("Takahiro Noda" . "takahiro.noda+github@gmail.com"))
  :maintainers '(("Takahiro Noda" . "takahiro.noda+github@gmail.com")))
