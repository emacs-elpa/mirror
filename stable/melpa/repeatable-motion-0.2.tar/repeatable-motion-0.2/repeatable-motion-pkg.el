;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeatable-motion" "0.2"
  "Make repeatable versions of motions."
  '((emacs "24"))
  :url "https://github.com/willghatch/emacs-repeatable-motion"
  :commit "e664b0a4a3e39c4085378a28b5136b349a0afb22"
  :revdesc "e664b0a4a3e3"
  :keywords '("motion" "repeatable")
  :authors '(("William Hatch" . "willghatch@gmail.com"))
  :maintainers '(("William Hatch" . "willghatch@gmail.com")))
