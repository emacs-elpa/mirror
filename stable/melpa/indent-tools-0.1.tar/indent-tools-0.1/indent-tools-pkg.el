;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-tools" "0.1"
  "Indent, move around etc by indentation units."
  '((s         "0")
    (hydra     "0")
    (yafolding "0"))
  :url "https://gitlab.com/emacs-stuff/indent-tools/"
  :commit "587c49603368e18401051bb0124fe14e8c58afdc"
  :revdesc "587c49603368"
  :keywords '("indentation" "movements" "navigation" "kill" "fold" "yaml" "python")
  :authors '(("vindarel" . "ehvince@mailz.org"))
  :maintainers '(("vindarel" . "ehvince@mailz.org")))
