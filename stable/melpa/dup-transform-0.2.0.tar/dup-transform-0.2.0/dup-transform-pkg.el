;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dup-transform" "0.2.0"
  "RGB/XY graphics code helpers."
  '((emacs "27"))
  :url "https://github.com/garyo/dup-transform.el"
  :commit "5a644bdfeb747c93cd0ac5b583e0bbc4f659f45a"
  :revdesc "5a644bdfeb74"
  :keywords '("graphics" "programming" "c++" "3d" "video" "rgb")
  :authors '(("Gary Oberbrunner" . "garyo@darkstarsystems.com"))
  :maintainers '(("Gary Oberbrunner" . "garyo@darkstarsystems.com")))
