;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlstack-mode" "0.1.1"
  "Minor mode for analysing Erlang stacktraces."
  '((emacs "25.1")
    (dash  "2.12.0"))
  :url "https://github.com/k32/erlstack-mode"
  :commit "a4a30f74e48894ccfdefc073a9e1b005ee632017"
  :revdesc "a4a30f74e488"
  :keywords '("tools" "erlang"))
