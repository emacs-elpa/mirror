;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-yasnippet" "0.2"
  "A consulting-read interface for yasnippet."
  '((emacs     "27.1")
    (yasnippet "0.14")
    (consult   "0.16"))
  :url "https://github.com/mohkale/consult-yasnippet"
  :commit "cdb256d2c50e4f8473c6052e1009441b65b8f8ab"
  :revdesc "cdb256d2c50e"
  :authors '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("mohsin kaleem" . "mohkale@kisara.moe")))
