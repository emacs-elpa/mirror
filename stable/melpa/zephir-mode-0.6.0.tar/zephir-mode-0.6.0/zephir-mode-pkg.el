;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zephir-mode" "0.6.0"
  "Major mode for editing Zephir code."
  '((cl-lib   "0.5")
    (pkg-info "0.4")
    (emacs    "25.1"))
  :url "https://github.com/zephir-lang/zephir-mode"
  :commit "9adc5cf07a9117d25eaab41867ddde914c6d2f5a"
  :revdesc "0.6.0-0-g9adc5cf07a91"
  :keywords '("languages")
  :authors '(("Serghei Iakovlev" . "egrep@protonmail.ch"))
  :maintainers '(("Serghei Iakovlev" . "egrep@protonmail.ch")))
