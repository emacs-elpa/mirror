;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "burnt-toast" "0.1"
  "Elisp integration with BurntToast."
  '((emacs "25.1"))
  :url "https://github.com/cedarbaum/burnt-toast.el"
  :commit "37e33ebc909e1ccf48d2153c3cdbe41feb42dce8"
  :revdesc "37e33ebc909e"
  :keywords '("alert" "notifications" "powershell")
  :authors '(("Sam Cedarbaum" . "(scedarbaum@gmail.com)"))
  :maintainers '(("Sam Cedarbaum" . "(scedarbaum@gmail.com)")))
