;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-project" "0.7"
  "Integrates CMake build process with Emacs."
  ()
  :url "https://github.com/alamaison/emacs-cmake-project"
  :commit "ec61f687772cccdb699f64ebe1e8dc8ba83f790f"
  :revdesc "ec61f687772c"
  :keywords '("c" "cmake" "languages" "tools")
  :authors '(("Alexander Lamaison" . "alexander.lamaison@gmail"))
  :maintainers '(("Alexander Lamaison" . "alexander.lamaison@gmail")))
