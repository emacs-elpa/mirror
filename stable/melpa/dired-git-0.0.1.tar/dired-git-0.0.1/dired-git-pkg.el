;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-git" "0.0.1"
  "Git integration for dired."
  '((emacs "26"))
  :url "https://github.com/conao3/dired-git.el"
  :commit "3cdd062cfc51c5834f6fe0c3bb831645c577dbd0"
  :revdesc "3cdd062cfc51"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
