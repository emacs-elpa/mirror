;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective-project-bridge" "0.1"
  "Integration of perspective.el + project.el."
  '((emacs       "27.1")
    (perspective "2.18")
    (cl-lib      "0.5"))
  :url "https://github.com/arunkmv/perspective-project-bridge"
  :commit "32215a4693a792002f7565904767c9a1d3e8713b"
  :revdesc "32215a4693a7"
  :keywords '("perspective" "project" "project.el")
  :authors '(("Arunkumar Vaidyanathan" . "arunkumarmv1997@gmail.com"))
  :maintainers '(("Arunkumar Vaidyanathan" . "arunkumarmv1997@gmail.com")))
