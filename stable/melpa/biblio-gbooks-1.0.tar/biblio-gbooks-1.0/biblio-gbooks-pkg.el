;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "biblio-gbooks" "1.0"
  "Google Books backend for biblio.el."
  '((emacs       "24.4")
    (biblio-core "0.2"))
  :url "https://github.com/jrasband/biblio-gbooks"
  :commit "213a24c302482fbc547fe5faefda71bfbd09ad3f"
  :revdesc "213a24c30248"
  :keywords '("bib" "tex"))
