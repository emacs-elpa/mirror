;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard-project-status" "0.0.1"
  "Display a git project status in a dashboard widget."
  '((emacs     "24")
    (git       "0.1.1")
    (dashboard "1.2.5"))
  :url "https://github.com/functionreturnfurnction/dashboard-project-status"
  :commit "42fc624937b965d05c9f9d017661fa0420164df7"
  :revdesc "42fc624937b9"
  :authors '(("Jason Duncan" . "jasond496@msn.com"))
  :maintainers '(("Jason Duncan" . "jasond496@msn.com")))
