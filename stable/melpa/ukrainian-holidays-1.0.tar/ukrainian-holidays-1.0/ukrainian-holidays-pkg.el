;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ukrainian-holidays" "1.0"
  "Ukrainain holidays for Emacs calendar."
  ()
  :url "https://github.com/abo-abo/ukrainian-holidays"
  :commit "4a1794c104f359769b16e8b21b1dcaa543abb577"
  :revdesc "4a1794c104f3"
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
