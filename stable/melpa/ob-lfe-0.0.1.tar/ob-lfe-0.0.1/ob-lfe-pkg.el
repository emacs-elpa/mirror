;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-lfe" "0.0.1"
  "Org-babel functions for lfe evaluation."
  '((org "8"))
  :url "https://github.com/zweifisch/ob-lfe"
  :commit "d50a5d76e389501504e060a7005f20b96c895594"
  :revdesc "d50a5d76e389"
  :keywords '("org" "babel" "lfe" "lisp" "erlang")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
