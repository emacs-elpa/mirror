;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flow-minor-mode" "0.3"
  "Flow type mode based on web-mode."
  '((emacs "25.1"))
  :url "https://github.com/an-sh/flow-minor-mode"
  :commit "50dded94ad201fdc9453656a8b15179981cd5acd"
  :revdesc "50dded94ad20")
