;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rmsbolt" "0.1.2"
  "A compiler output viewer."
  '((emacs "25.1"))
  :url "https://gitlab.com/jgkamat/rmsbolt"
  :commit "95130c14213429e81a33b91c21c91fe48de45e7a"
  :revdesc "95130c142134"
  :keywords '("compilation" "tools")
  :authors '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainers '(("Jay Kamat" . "jaygkamat@gmail.com")))
