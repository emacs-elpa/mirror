;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asx" "0.1.1"
  "Ask Stack Exchange."
  '((request "0.3.0")
    (org     "9.2.5")
    (seq     "2")
    (emacs   "25"))
  :url "https://github.com/ragone/asx"
  :commit "9d76d6ad1e9f4c0998bdc770cc7042b6759c3724"
  :revdesc "9d76d6ad1e9f"
  :keywords '("convenience")
  :authors '(("Alex Ragone" . "ragonedk@gmail.com"))
  :maintainers '(("Alex Ragone" . "ragonedk@gmail.com")))
