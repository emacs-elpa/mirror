;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-collection" "1.0.1"
  "Collection of checkers for flymake, bringing flymake to the level of flycheck."
  '((emacs     "28.1")
    (let-alist "1.0")
    (flymake   "1.2.1"))
  :url "https://github.com/mohkale/flymake-collection"
  :commit "6fb90eefc2ad6214127de2ccff5160bf1d47eb87"
  :revdesc "6fb90eefc2ad"
  :keywords '("language" "tools")
  :authors '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@kisara.moe")))
