;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simplicity-theme" "0.1.0"
  "A minimalist dark theme."
  ()
  :url "https://github.com/smallwat3r/emacs-simplicity-theme"
  :commit "035aa41bb626b71e462ff18f39b266c3464b7723"
  :revdesc "035aa41bb626"
  :keywords '("faces" "theme" "minimal")
  :authors '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com"))
  :maintainers '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com")))
