;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ednc" "0.2"
  "Emacs Desktop Notification Center."
  '((emacs "26.1"))
  :url "https://github.com/sinic/ednc"
  :commit "6fdb2da558049ad7978ffac40012ff1e1b2249a6"
  :revdesc "6fdb2da55804"
  :keywords '("unix")
  :authors '(("Simon Nicolussi" . "sinic@sinic.name"))
  :maintainers '(("Simon Nicolussi" . "sinic@sinic.name")))
