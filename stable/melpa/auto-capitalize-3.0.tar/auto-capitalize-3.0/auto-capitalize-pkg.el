;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-capitalize" "3.0"
  "Automatically capitalize (or upcase) words."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/abdulnafe-t/auto-capitalize-el"
  :commit "6d17da4c03529cbe2e18215cb0c727737fd48d03"
  :revdesc "6d17da4c0352"
  :keywords '("text" "wp" "convenience")
  :maintainers '(("Abdulnafé Toulaïmat" . "abdulnafe.toulaimat@gmail.com")))
