;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eterm-fn" "0.0.0.20250110.16"
  "Function (F1--F12) keys for term."
  '((emacs "25"))
  :url "https://github.com/oitofelix/eterm-fn"
  :commit "b5d433fedc030046ea0e4a217f4dd3846a113fe4"
  :revdesc "b5d433fedc03"
  :keywords '("terminals")
  :authors '(("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org"))
  :maintainers '(("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org")))
