;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "berrys-theme" "0.1.0"
  "[No description available]."
  '((emacs "24"))
  :url "https://github.com/vbuzin/berrys-theme"
  :commit "5193676bc58b5937c0192f13fce5497a491ddb34"
  :revdesc "5193676bc58b"
  :authors '(("Slava Buzin" . "v8v.buzin@gmail.com"))
  :maintainers '(("Slava Buzin" . "v8v.buzin@gmail.com")))
