;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyimport" "1.0"
  "Manage Python imports!."
  '((dash "2.8.0")
    (s    "1.9.0"))
  :url "https://github.com/Wilfred/pyimport"
  :commit "2c05712748f6b6624b15d524323f6391612683f4"
  :revdesc "2c05712748f6"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
