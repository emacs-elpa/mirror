;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metropolis-light-theme" "0.1.0"
  "[No description available]."
  '((emacs "25.1"))
  :url "https://github.com/bitorhugo/metropolis-light-theme"
  :commit "65c060c7d04c9d1bc6372ed238400fbf1dd34ad5"
  :revdesc "65c060c7d04c"
  :keywords '("faces" "theme"))
