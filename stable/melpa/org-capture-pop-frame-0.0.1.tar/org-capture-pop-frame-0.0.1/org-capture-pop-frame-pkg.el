;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-capture-pop-frame" "0.0.1"
  "Run org-capture in a new pop frame."
  ()
  :url "https://github.com/tumashu/org-capture-pop-frame.git"
  :commit "71f99c22f19207612197349440446c0075bd72ff"
  :revdesc "71f99c22f192"
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
