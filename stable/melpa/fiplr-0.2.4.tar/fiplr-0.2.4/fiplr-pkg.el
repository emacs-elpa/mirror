;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fiplr" "0.2.4"
  "Fuzzy Search for Files in Projects."
  '((grizzl "0.1.0"))
  :url "https://github.com/d11wtq/fiplr"
  :commit "100dfc33f43da8c49e50e8a2222b9d95532f6e24"
  :revdesc "0.2.4-0-g100dfc33f43d"
  :keywords '("convenience" "usability" "project")
  :authors '(("Chris Corbyn" . "chris@w3style.co.uk"))
  :maintainers '(("Chris Corbyn" . "chris@w3style.co.uk")))
