;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-snippets" "0.1.0"
  "Yasnippets for go."
  '((yasnippet "0.8.0"))
  :url "https://github.com/toumorokoshi/go-snippets"
  :commit "a85ece20372ee80652bf8a9720d4fe43126636bc"
  :revdesc "a85ece20372e"
  :keywords '("snippets"))
