;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-prolog" "1.0.2"
  "Org-babel functions for prolog evaluation."
  ()
  :url "https://github.com/ljos/ob-prolog"
  :commit "efa86bb70fd1907806f3e43705aff54d35582442"
  :revdesc "efa86bb70fd1"
  :keywords '("literate programming" "reproducible research"))
