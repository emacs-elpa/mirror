;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "teco" "9"
  "Teco interpreter for Gnu Emacs."
  ()
  :url "https://github.com/mtk/teco.git"
  :commit "3e1db9d41d44f52c6b0de4349c5bbfeb125b2735"
  :revdesc "3e1db9d41d44"
  :keywords '("convenience" "emulations" "files")
  :authors '(("Dale R. Worley" . "worley@alum.mit.edu"))
  :maintainers '(("Mark T. Kennedy" . "mtk@acm.org")))
