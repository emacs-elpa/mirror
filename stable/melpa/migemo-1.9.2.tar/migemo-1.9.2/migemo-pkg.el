;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "migemo" "1.9.2"
  "Japanese incremental search through dynamic pattern expansion."
  '((cl-lib "0.5"))
  :url "https://github.com/emacs-jp/migemo"
  :commit "f42832c8ac462ecbec9a16eb781194f876fba64a"
  :revdesc "f42832c8ac46"
  :authors '(("Satoru Takabayashi" . "satoru-t@is.aist-nara.ac.jp"))
  :maintainers '(("Satoru Takabayashi" . "satoru-t@is.aist-nara.ac.jp")))
