;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nemerle" "1.2"
  "Major mode for editing nemerle programs."
  ()
  :url "https://github.com/rsdn/nemerle"
  :commit "556270ce8b97668a65e9ec20a05f78c3dffeac60"
  :revdesc "556270ce8b97"
  :keywords '("nemerle" "mode" "languages")
  :authors '(("Jacek Sliwerski" . "rzyj@o2.pl"))
  :maintainers '(("Jacek Sliwerski" . "rzyj@o2.pl")))
