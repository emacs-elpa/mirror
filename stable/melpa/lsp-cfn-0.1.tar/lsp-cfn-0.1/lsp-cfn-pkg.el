;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-cfn" "0.1"
  "Cfn-lsp-extra setup for lsp-mode."
  '((emacs     "27.0")
    (lsp-mode  "8.0.0")
    (yaml-mode "0.0.15"))
  :url "https://github.com/Laurence Warne/lsp-cfn.el"
  :commit "83a6fc7342edaae5fedb32270a065117ac490622"
  :revdesc "83a6fc7342ed")
