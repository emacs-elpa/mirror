;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alert-termux" "1.0"
  "[No description available]."
  '((emacs "24.4"))
  :url "https://github.com/gergelypolonkai/alert-termux"
  :commit "225fad8e24900ce3f73697133def84a941e49dc8"
  :revdesc "225fad8e2490"
  :keywords '("termux" "alert" "notification")
  :authors '(("Gergely Polonkai" . "gergely@polonkai.eu"))
  :maintainers '(("Gergely Polonkai" . "gergely@polonkai.eu")))
