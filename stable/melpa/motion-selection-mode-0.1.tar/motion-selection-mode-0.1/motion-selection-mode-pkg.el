;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "motion-selection-mode" "0.1"
  "A minor mode to add a text editing grammar."
  '((emacs    "29.3")
    (god-mode "0"))
  :url "https://github.com/alexispurslane/motion-selection-mode"
  :commit "86dcc765c38f8e0feed8b7eab147603246d64301"
  :revdesc "86dcc765c38f"
  :keywords '("tools")
  :authors '(("Alexis Purslane" . "alexispurslane@pm.me"))
  :maintainers '(("Alexis Purslane" . "alexispurslane@pm.me")))
