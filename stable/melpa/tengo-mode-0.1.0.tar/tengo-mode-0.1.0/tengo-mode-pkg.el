;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tengo-mode" "0.1.0"
  "Major mode for the Tengo programming language."
  '((emacs "24.3"))
  :url "https://github.com/yourusername/tengo-mode"
  :commit "0cd017dc21e236c03f8026482afaccb267b9bcaf"
  :revdesc "0cd017dc21e2"
  :keywords '("languages" "tengo"))
