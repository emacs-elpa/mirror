;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buckwalter" "20171126.1"
  "Write arabic using Buckwalter transliteration."
  ()
  :url "https://github.com/joehakimrahme/buckwalter-arabic"
  :commit "57358a839eaa482e1f6545e7eec729384aef115f"
  :revdesc "57358a839eaa"
  :keywords '("arabic" "transliteration" "i18n")
  :authors '(("Joe HAKIM RAHME" . "joehakimrahme@gmail.com"))
  :maintainers '(("Joe HAKIM RAHME" . "joehakimrahme@gmail.com")))
