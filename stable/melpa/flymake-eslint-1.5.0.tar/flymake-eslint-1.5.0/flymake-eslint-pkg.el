;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-eslint" "1.5.0"
  "A Flymake backend for Javascript using eslint."
  '((emacs "26.0"))
  :url "https://github.com/orzechowskid/flymake-eslint"
  :commit "6e2d376f84ddf9af593072954c97e9c82ab85331"
  :revdesc "6e2d376f84dd")
