;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly-hello-world" "0.1"
  "Support named readtables in Common Lisp files."
  '((sly "1.0.0-beta2"))
  :url "https://github.com/capitaomorte/sly-hello-world"
  :commit "f32a36dc646817f0d222f196dcd94ae862df516c"
  :revdesc "f32a36dc6468"
  :keywords '("languages" "lisp" "sly")
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
