;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "salt-mode" "0.2"
  "Major mode for Salt States."
  '((emacs      "24.4")
    (yaml-mode  "0.0.12")
    (mmm-mode   "0.5.4")
    (mmm-jinja2 "0.1"))
  :url "https://github.com/glynnforrest/salt-mode"
  :commit "6a1fedb4da7181b00f1bebfc88c87dd2f0c58766"
  :revdesc "6a1fedb4da71"
  :keywords '("languages")
  :authors '(("Ben Hayden" . "hayden767@gmail.com"))
  :maintainers '(("Glynn Forrest" . "me@glynnforrest.com")))
