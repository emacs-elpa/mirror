;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proportional" "0.1.2"
  "Use a proportional font everywhere."
  '((emacs "25.1"))
  :url "https://github.com/ksjogo/proportional"
  :commit "edc9885be1d4ac51fdcf4527cb29c1d0a58eaaec"
  :revdesc "edc9885be1d4"
  :keywords '("faces"))
