;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buttercup-junit" "1.1.2"
  "JUnit reporting for Buttercup."
  '((emacs     "24.4")
    (buttercup "1.15"))
  :url "https://bitbucket.org/olanilsson/buttercup-junit"
  :commit "877daa33fc3fc23f2a3d633e28650c04534458b5"
  :revdesc "v1.1.2-0-g877daa33fc3f"
  :keywords '("tools" "test" "unittest" "buttercup" "ci")
  :authors '(("Ola Nilsson" . "ola.nilsson@gmail.com"))
  :maintainers '(("Ola Nilsson" . "ola.nilsson@gmail.com")))
