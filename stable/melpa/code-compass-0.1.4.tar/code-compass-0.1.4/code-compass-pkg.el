;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-compass" "0.1.4"
  "Navigate software aided by metrics and visualization."
  '((emacs        "26.1")
    (s            "1.12.0")
    (dash         "2.13")
    (async        "1.9.7")
    (simple-httpd "1.5.1"))
  :url "https://github.com/ag91/code-compass"
  :commit "67ec53f9ca43bea941ec5ba6fccba8565c1d937f"
  :revdesc "67ec53f9ca43"
  :keywords '("tools" "extensions" "help")
  :authors '(("Andrea" . "andrea-dev@hotmail.com"))
  :maintainers '(("Andrea" . "andrea-dev@hotmail.com")))
