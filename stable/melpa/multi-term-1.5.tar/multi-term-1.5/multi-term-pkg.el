;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multi-term" "1.5"
  "Managing multiple terminal buffers in Emacs."
  ()
  :url "http://www.emacswiki.org/emacs/download/multi-term.el"
  :commit "8deb0f2252399cca2426eb3cc3e9646c5de726b3"
  :revdesc "8deb0f225239"
  :keywords '("term" "terminal" "multiple buffer")
  :authors '(("Andy Stewart" . "lazycat.manatee@gmail.com"))
  :maintainers '(("Andy Stewart" . "lazycat.manatee@gmail.com")))
