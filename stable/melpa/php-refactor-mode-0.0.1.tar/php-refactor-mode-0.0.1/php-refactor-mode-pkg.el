;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-refactor-mode" "0.0.1"
  "[No description available]."
  ()
  :url "https://github.com/keelerm84/php-refactor-mode.el"
  :commit "61a8c99159942ac273739c557f1f651c35f9b4e3"
  :revdesc "61a8c9915994"
  :keywords '("php" "refactor")
  :authors '(("Matthew M. Keeler" . "keelerm84@gmail.com"))
  :maintainers '(("Matthew M. Keeler" . "keelerm84@gmail.com")))
