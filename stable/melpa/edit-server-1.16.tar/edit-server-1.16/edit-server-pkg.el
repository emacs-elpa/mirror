;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-server" "1.16"
  "Server that responds to edit requests from Chrome."
  ()
  :url "https://github.com/stsquad/emacs_chrome"
  :commit "1632acab5624637031326bd902e2ad7ccb6b4c90"
  :revdesc "1632acab5624"
  :authors '(("Alex Bennée" . "alex@bennee.com"))
  :maintainers '(("Alex Bennée" . "alex@bennee.com")))
