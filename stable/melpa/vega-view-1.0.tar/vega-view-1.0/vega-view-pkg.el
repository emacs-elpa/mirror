;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vega-view" "1.0"
  "Vega visualization viewer."
  '((emacs    "25")
    (cider    "0.24.0")
    (parseedn "0.1"))
  :url "https://www.github.com/applied-science/emacs-vega-view"
  :commit "b0160c883f53ce069c0b4498880474c158ac7245"
  :revdesc "b0160c883f53"
  :keywords '("multimedia")
  :authors '(("Jack Rusher" . "jack@appliedscience.studio"))
  :maintainers '(("Jack Rusher" . "jack@appliedscience.studio")))
