;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "1.0"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "27.1")
    (org   "9.6")
    (fsrs  "1.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "fc710a3f5b46f20c51e092ec786a153fe4759b57"
  :revdesc "fc710a3f5b46"
  :keywords '("memory" "flashcards")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
