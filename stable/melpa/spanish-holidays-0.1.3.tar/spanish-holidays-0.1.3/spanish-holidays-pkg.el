;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spanish-holidays" "0.1.3"
  "Spain holidays for calendar."
  ()
  :url "https://gitlab.com/gnuhack/spanish-holidays"
  :commit "a596ec68f26c06063718dc83132e2843107cfe5c"
  :revdesc "a596ec68f26c"
  :keywords '("calendar")
  :authors '(("Carlos Pajuelo" . "carlospajuelo_@hotmail.com"))
  :maintainers '(("Carlos Pajuelo" . "carlospajuelo_@hotmail.com")))
