;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-toc" "0.1"
  "Sidebar showing a \"table of contents\"."
  ()
  :url "https://github.com/abingham/outline-toc.el"
  :commit "009c2697f21b2144d598aab8e677e239185e99a5"
  :revdesc "009c2697f21b"
  :keywords '("convenience" "outlines")
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
