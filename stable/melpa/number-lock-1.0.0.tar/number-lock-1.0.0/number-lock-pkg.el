;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "number-lock" "1.0.0"
  "Enter symbols on your number keys without pressing shift."
  ()
  :url "https://github.com/Liu233w/number-lock.el"
  :commit "846e86e2b3b07410f69e70d3ba7afb072b5585da"
  :revdesc "846e86e2b3b0"
  :keywords '("convenience")
  :authors '(("Liu233w" . "wwwlsmcom@outlook.com"))
  :maintainers '(("Liu233w" . "wwwlsmcom@outlook.com")))
