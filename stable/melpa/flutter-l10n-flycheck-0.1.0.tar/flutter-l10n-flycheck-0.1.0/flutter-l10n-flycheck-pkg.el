;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flutter-l10n-flycheck" "0.1.0"
  "Tools for Flutter L10N."
  '((emacs    "24.5")
    (flycheck "30"))
  :url "https://github.com/amake/flutter.el"
  :commit "b948903e77d1e8a3d14b32b2bedf93a89bb1af46"
  :revdesc "b948903e77d1"
  :keywords '("languages"))
