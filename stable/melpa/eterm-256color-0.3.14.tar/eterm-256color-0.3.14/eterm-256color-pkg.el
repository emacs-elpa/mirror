;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eterm-256color" "0.3.14"
  "Customizable 256 colors for term."
  '((emacs       "24.4")
    (xterm-color "1.7")
    (f           "0.19.0"))
  :url "https://github.com/dieggsy/eterm-256color"
  :commit "ef99d3a12ddce4aa06069c19e66e826f4cfc91e4"
  :revdesc "ef99d3a12ddc"
  :keywords '("faces")
  :authors '(("Diego A. Mundo" . "diegoamundo@gmail.com"))
  :maintainers '(("Diego A. Mundo" . "diegoamundo@gmail.com")))
