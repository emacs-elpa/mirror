;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "turkish" "0.0.0.20260614.21"
  "Convert to Turkish characters on-the-fly."
  ()
  :url "http://www.denizyuret.com/2006/11/emacs-turkish-mode.html"
  :commit "70196d4502759060bb2b0ac2f09f18ce1cbbcb20"
  :revdesc "70196d450275"
  :keywords '("turkish" "languages" "automatic" "conversion")
  :maintainers '(("Emre Sevinç" . "emre.sevinc@gmail.com")))
