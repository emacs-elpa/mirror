;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rhtml-mode" "0.0.0.20130422.13"
  "Major mode for editing RHTML files."
  ()
  :url "https://github.com/eschulte/rhtml"
  :commit "a6d71b38a3db867ccf82999c99805db1a3a33c33"
  :revdesc "a6d71b38a3db")
