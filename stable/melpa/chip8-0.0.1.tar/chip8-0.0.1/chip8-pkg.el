;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chip8" "0.0.1"
  "A CHIP-8 emulator written in Emacs Lisp running in Emacs."
  '((emacs "28.1"))
  :url "https://github.com/gabrielelana/chip8.el"
  :commit "315e1568bd65b898524a6e936e827b7f3d4958b4"
  :revdesc "315e1568bd65"
  :keywords '("chip-8" "game" "games" "emulator")
  :authors '(("Gabriele Lana" . "gabriele.lana@gmail.com"))
  :maintainers '(("Gabriele Lana" . "gabriele.lana@gmail.com")))
