;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quelpa-use-package" "0.0.3"
  "Quelpa handler for use-package."
  '((emacs  "29.1")
    (quelpa "1.0"))
  :url "https://github.com/quelpa/quelpa-use-package"
  :commit "df33711882457cb6b59f8a687f35d02f010ddb65"
  :revdesc "df3371188245"
  :keywords '("package" "management" "elpa" "use-package")
  :authors '(("Reto Hubmann" . "(@steckerhalter)"))
  :maintainers '(("Reto Hubmann" . "(@steckerhalter)")))
