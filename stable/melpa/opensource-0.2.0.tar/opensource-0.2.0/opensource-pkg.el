;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "opensource" "0.2.0"
  "Client for Opensource API."
  '((s        "1.11.0")
    (dash     "2.12.1")
    (pkg-info "0.6.0")
    (request  "0.2.0"))
  :url "https://github.com/nlamirault/opensource.el"
  :commit "27d06be45c852e84e47c33cbd0f4c344fd9a0370"
  :revdesc "27d06be45c85"
  :keywords '("opensource")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
