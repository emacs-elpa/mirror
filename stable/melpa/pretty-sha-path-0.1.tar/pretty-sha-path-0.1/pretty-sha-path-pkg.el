;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pretty-sha-path" "0.1"
  "Prettify Guix/Nix store paths."
  ()
  :url "https://github.com/alezost/pretty-sha-path.el"
  :commit "29ce8a85ac779fbef0e1c04ec23dd50b680aaeaa"
  :revdesc "29ce8a85ac77"
  :keywords '("faces" "convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
