;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simplecov" "2.0"
  "Colorize untested ruby code."
  '((dash  "2.19")
    (emacs "28"))
  :url "https://github.org/zenspider/elisp"
  :commit "2f6695d6aba7ce98b214498deeb182bd11afdbad"
  :revdesc "2f6695d6aba7"
  :keywords '("tools" "languages")
  :authors '(("Ryan Davis" . "ryand-ruby@zenspider.com"))
  :maintainers '(("Ryan Davis" . "ryand-ruby@zenspider.com")))
