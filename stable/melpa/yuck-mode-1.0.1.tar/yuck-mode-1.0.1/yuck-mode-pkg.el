;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yuck-mode" "1.0.1"
  "Major mode for the yuck configuration language."
  '((emacs "25.1"))
  :url "https://github.com/mmcjimsey26/yuck-mode"
  :commit "eaad843c044b0c4cbd04fde2f38409facfa20a3b"
  :revdesc "eaad843c044b"
  :keywords '("languages" "yuck" "eww" "widgets"))
