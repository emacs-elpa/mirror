;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "0.3.0"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "9b56e5d960d1e6f12379c6bc4c60cf16f59131f5"
  :revdesc "v0.3.0-0-g9b56e5d960d1"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
