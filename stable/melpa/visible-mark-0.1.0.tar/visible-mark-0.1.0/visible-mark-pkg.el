;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visible-mark" "0.1.0"
  "Make marks visible."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-visible-mark"
  :commit "33d8398e7c27a7eaf20fc1312e38241537f7d75d"
  :revdesc "33d8398e7c27"
  :keywords '("marking" "color" "faces")
  :authors '(("Ian Kelling" . "ian@iankelling.org"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
