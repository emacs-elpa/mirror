;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.73.1"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "048d17fc59f9b980ad77186758f05f8bfb9987cb"
  :revdesc "048d17fc59f9")
