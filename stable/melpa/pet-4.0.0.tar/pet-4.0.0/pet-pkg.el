;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pet" "4.0.0"
  "Executable and virtualenv tracker for python-mode."
  '((emacs "27.1")
    (f     "0.6.0")
    (map   "3.3.1")
    (seq   "2.24"))
  :url "https://github.com/wyuenho/emacs-pet/"
  :commit "6b62cf5f7e968c8137d8818b58638b2f0e64d02b"
  :revdesc "6b62cf5f7e96"
  :keywords '("tools")
  :authors '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
