;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asyncloop" "1.1"
  "Non-blocking series of functions."
  '((emacs "28"))
  :url "https://github.com/meedstrom/asyncloop"
  :commit "8bc72f51c52c108ece0655625dedc10b9fe1cb8d"
  :revdesc "8bc72f51c52c"
  :keywords '("tools")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
