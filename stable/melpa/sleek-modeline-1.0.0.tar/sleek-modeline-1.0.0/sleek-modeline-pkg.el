;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sleek-modeline" "1.0.0"
  "Minimal and elegant modeline."
  '((emacs "29.1"))
  :url "https://github.com/abidanBrito/sleek-modeline"
  :commit "ac3335237397d01cddc4d9534e9da682e733d849"
  :revdesc "v1.0.0-0-gac3335237397"
  :keywords '("mode-line" "faces")
  :authors '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com"))
  :maintainers '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com")))
