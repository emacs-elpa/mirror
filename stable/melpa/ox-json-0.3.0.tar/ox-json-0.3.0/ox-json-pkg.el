;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-json" "0.3.0"
  "JSON export backend for Org mode."
  '((emacs "26.1")
    (org   "9")
    (s     "1.12"))
  :url "https://github.com/jlumpe/ox-json"
  :commit "57a43e3b3e400d219b80008c51373796b844c6b8"
  :revdesc "57a43e3b3e40"
  :keywords '("outlines")
  :authors '(("Jared Lumpe" . "jared@jaredlumpe.com"))
  :maintainers '(("Jared Lumpe" . "jared@jaredlumpe.com")))
