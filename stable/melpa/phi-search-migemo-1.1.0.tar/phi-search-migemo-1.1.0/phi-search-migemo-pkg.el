;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-search-migemo" "1.1.0"
  "Migemo extension for phi-search."
  '((phi-search "2.2.0")
    (migemo     "1.9.1"))
  :url "http://hins11.yu-yake.com/"
  :commit "57623e4b67ee766cbb299da00a212f3ebf7d6fb0"
  :revdesc "57623e4b67ee")
