;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ron-mode" "1"
  "Rusty Object Notation mode."
  '((emacs "26.1"))
  :url "https://chiselapp.com/user/Hutzdog/repository/ron-mode/home"
  :commit "000614f9b8caa5542a3f30d8046532a5000384b4"
  :revdesc "000614f9b8ca"
  :keywords '("languages")
  :authors '(("Daniel Hutzley" . "endergeryt@gmail.com"))
  :maintainers '(("Daniel Hutzley" . "endergeryt@gmail.com")))
