;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "1.0.2"
  "Integration for the command-line tool `fasd'."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "249334222d13b5ea6d4811833326358e8d0dd30a"
  :revdesc "1.0.2-0-g249334222d13"
  :keywords '("convenience"))
