;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "just-ts-mode" "0.1.0"
  "Justfile editing mode."
  '((emacs "29.1"))
  :url "https://github.com/leon-barrett/just-ts-mode.el"
  :commit "652d7866167830c1c9dd7763fdec01245f8472e7"
  :revdesc "652d78661678"
  :keywords '("files" "languages" "tools" "treesitter")
  :authors '(("Leon Barrett" . "(leon@barrettnexus.com)"))
  :maintainers '(("Leon Barrett" . "(leon@barrettnexus.com)")))
