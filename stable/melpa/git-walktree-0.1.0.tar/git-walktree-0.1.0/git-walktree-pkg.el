;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-walktree" "0.1.0"
  "Browse Git tree and blob objects."
  '((emacs  "26.1")
    (git    "0.1.1")
    (cl-lib "0.5"))
  :url "https://github.com/10sr/git-walktree-el"
  :commit "a1a5490b89d193724ec637818baf2d8edf97c638"
  :revdesc "a1a5490b89d1"
  :keywords '("vc" "utility" "git")
  :authors '(("10sr" . "8.slashes[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8.slashes[at]gmail[dot]com")))
