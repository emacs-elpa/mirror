;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "obfusurl" "2.2"
  "Obfuscate URLs so they aren't spoilers."
  '((emacs "25.1"))
  :url "https://github.com/davep/obfusurl.el"
  :commit "3f3a6416223c98b7fddd2c55998ef29f1c77046c"
  :revdesc "3f3a6416223c"
  :keywords '("convenience" "web" "text")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
