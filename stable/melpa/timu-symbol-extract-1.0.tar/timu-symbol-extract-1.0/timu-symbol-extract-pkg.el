;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-symbol-extract" "1.0"
  "Extract symbols to org table."
  '((emacs "28.1"))
  :url "https://gitlab.com/aimebertrand/dotemacs"
  :commit "1198f4b97ee843641351375eaf57d3782ae64fea"
  :revdesc "1198f4b97ee8"
  :keywords '("defaults" "tools" "helper")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
