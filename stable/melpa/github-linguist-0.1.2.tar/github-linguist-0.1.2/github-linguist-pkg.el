;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-linguist" "0.1.2"
  "Run GitHub Linguist on projects to collect information."
  '((emacs   "27.1")
    (project "0.8")
    (async   "1.9")
    (map     "3"))
  :url "https://github.com/akirak/github-linguist.el"
  :commit "f8f28745542d7e4300d73c6bf006ce48b6657947"
  :revdesc "f8f28745542d"
  :keywords '("processes")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
