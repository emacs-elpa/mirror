;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slim-mode" "1.1"
  "Major mode for editing Slim files."
  ()
  :url "https://github.com/minad/emacs-slim"
  :commit "fe8abb644b7b9cc0ed1e76d9ca8d6c01edccbdb8"
  :revdesc "fe8abb644b7b"
  :keywords '("markup" "language"))
