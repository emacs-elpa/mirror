;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ligature" "1.0"
  "Display typographical ligatures in major modes."
  '((emacs "28"))
  :url "https://www.github.com/mickeynp/ligature.el"
  :commit "b732c7c57d06bda30d31fa6b52758a94490d0710"
  :revdesc "1.0-0-gb732c7c57d06"
  :keywords '("tools" "faces")
  :authors '(("Mickey Petersen" . "mickey@masteringemacs.org"))
  :maintainers '(("Mickey Petersen" . "mickey@masteringemacs.org")))
