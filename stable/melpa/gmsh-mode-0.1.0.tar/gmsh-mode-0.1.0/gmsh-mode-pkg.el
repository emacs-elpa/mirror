;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gmsh-mode" "0.1.0"
  "Highlight GMSH mesh generator script syntax."
  '((emacs "26.1"))
  :url "https://gitlab.com/matsievskiysv/gmsh-mode"
  :commit "6c50210101c7dfda6114ddcb4b71b195610331f7"
  :revdesc "6c50210101c7"
  :keywords '("languages"))
