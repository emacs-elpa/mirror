;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "just-mode" "0.1.8"
  "Justfile editing mode."
  '((emacs "26.1"))
  :url "https://github.com/leon-barrett/just-mode.el"
  :commit "d7f52eab8fa3828106f80acb1e2176e5877b7191"
  :revdesc "d7f52eab8fa3"
  :keywords '("files" "languages" "tools")
  :authors '(("Leon Barrett" . "(leon@barrettnexus.com)"))
  :maintainers '(("Leon Barrett" . "(leon@barrettnexus.com)")))
