;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-omni-org" "0.2.2"
  "Browse anything in Org mode."
  '((emacs "25.1")
    (ivy   "0.10")
    (dash  "2.12"))
  :url "https://github.com/akirak/ivy-omni-org"
  :commit "f386f8a1df92bffefe1b5db521de809992baef34"
  :revdesc "f386f8a1df92"
  :keywords '("outlines")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
