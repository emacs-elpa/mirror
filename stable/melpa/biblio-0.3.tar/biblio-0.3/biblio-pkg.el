;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "biblio" "0.3"
  "Browse and import bibliographic references and BibTeX records from CrossRef, arXiv, DBLP, HAL, IEEE Xplore, Dissemin, and doi.org."
  '((emacs       "24.3")
    (biblio-core "0.3"))
  :url "https://github.com/cpitclaudel/biblio.el"
  :commit "ee52f6cda82ea6fbc3b400e7b12132595cc0374c"
  :revdesc "0.3-0-gee52f6cda82e"
  :keywords '("bib" "tex" "convenience" "hypermedia")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
