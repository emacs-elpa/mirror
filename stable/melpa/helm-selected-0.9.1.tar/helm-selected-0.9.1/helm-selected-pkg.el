;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-selected" "0.9.1"
  "Helm extension for selected.el."
  '((emacs    "24.4")
    (helm     "2.8.6")
    (selected "1.01"))
  :url "https://github.com/takaxp/helm-selected"
  :commit "3bed3cecd86eb7264d8aacf02a88bdad16120547"
  :revdesc "3bed3cecd86e"
  :keywords '("extensions" "convenience")
  :authors '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg"))
  :maintainers '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg")))
