;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-orgcard" "0.2"
  "Browse the orgcard by helm."
  '((helm-core "1.7.7"))
  :url "https://github.com/emacs-jp/helm-orgcard"
  :commit "9655ac340d1ccc5f3d1c0f7c49be8dd3556d4d0d"
  :revdesc "0.2-0-g9655ac340d1c"
  :keywords '("convenience" "helm" "org")
  :authors '(("Yuhei Maeda" . "yuhei.maeda_at_gmail.com")))
