;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soft-charcoal-theme" "0.2"
  "Dark charcoal theme with soft colors."
  ()
  :url "https://github.com/mswift42/soft-charcoal-theme"
  :commit "843f17b76dc283c000477f0d0555a30927849191"
  :revdesc "843f17b76dc2")
