;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "futhark-mode" "0.2"
  "Major mode for editing Futhark source files."
  '((cl-lib "0.5"))
  :url "https://github.com/diku-dk/futhark-mode"
  :commit "e85c2c37b2ae36d40b2fd7679111c6a84de0c9b4"
  :revdesc "e85c2c37b2ae"
  :keywords '("languages"))
