;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trident-mode" "0.9.1"
  "Live Parenscript interaction."
  '((slime       "2013-05-26")
    (skewer-mode "1.5.0")
    (dash        "1.0.3"))
  :url "https://github.com/johnmastro/trident-mode.el"
  :commit "106075f2e8a740628feecb5f818694e2b4fc0ea2"
  :revdesc "106075f2e8a7"
  :keywords '("languages" "lisp" "processes" "tools")
  :authors '(("John Mastro" . "john.b.mastro@gmail.com"))
  :maintainers '(("John Mastro" . "john.b.mastro@gmail.com")))
