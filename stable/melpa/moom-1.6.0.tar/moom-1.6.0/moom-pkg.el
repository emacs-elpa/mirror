;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moom" "1.6.0"
  "Commands to control frame position and size."
  '((emacs "25.1"))
  :url "https://github.com/takaxp/Moom"
  :commit "f94cf84138a81212ffe856599834f7824a1b6e95"
  :revdesc "f94cf84138a8"
  :keywords '("frames" "faces" "convenience")
  :authors '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg"))
  :maintainers '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg")))
