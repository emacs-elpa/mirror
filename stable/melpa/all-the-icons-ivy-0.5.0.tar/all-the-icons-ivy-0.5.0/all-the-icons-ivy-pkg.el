;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "all-the-icons-ivy" "0.5.0"
  "Shows icons while using ivy and counsel."
  '((emacs         "24.4")
    (all-the-icons "2.4.0")
    (ivy           "0.8.0"))
  :url "https://github.com/asok/all-the-icons-ivy"
  :commit "b768b83716100701a5cda9c071da2bcac34bd6a4"
  :revdesc "b768b8371610"
  :keywords '("faces"))
