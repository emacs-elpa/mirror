;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oauth2-auto" "0.1"
  "Automatically refreshing OAuth 2.0 tokens."
  '((emacs "27.1")
    (aio   "1.0")
    (dash  "2.19"))
  :url "https://github.com/telotortium/emacs-oauth2-auto"
  :commit "178ca24b0c61c5a9fb286d13e98626978992eda5"
  :revdesc "178ca24b0c61"
  :keywords '("comm" "oauth2")
  :authors '(("Adrià Garriga-Alonso" . "adria.garriga@gmail.com"))
  :maintainers '(("Adrià Garriga-Alonso" . "adria.garriga@gmail.com")))
