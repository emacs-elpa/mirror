;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "camcorder" "1.0"
  "Record screencasts in gif or other formats."
  '((emacs  "24")
    (names  "20150000")
    (cl-lib "0.5"))
  :url "https://github.com/Bruce-Connor/camcorder.el"
  :commit "b11ca61491a27681bb3131b72b51c105fd996bed"
  :revdesc "b11ca61491a2"
  :keywords '("multimedia" "screencast")
  :authors '(("Artur Malabarba" . "bruce.connor.am@gmail.com"))
  :maintainers '(("Artur Malabarba" . "bruce.connor.am@gmail.com")))
