;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wavefront-obj-mode" "0.6"
  "Major mode for Wavefront obj files."
  ()
  :url "https://github.com/abend/wavefront-obj-mode"
  :commit "34027915de6496460d8e68b5991dd24d47d54859"
  :revdesc "34027915de64"
  :authors '(("Sasha Kovar" . "sasha-emacs@arcocene.org"))
  :maintainers '(("Sasha Kovar" . "sasha-emacs@arcocene.org")))
