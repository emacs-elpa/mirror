;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-lark" "0.2.0"
  "Export Lark docs to Org."
  '((emacs "27.1"))
  :url "https://github.com/bbw9n/org-lark"
  :commit "b14eeaf439296a329146f0bd480be61bbd2d2c5d"
  :revdesc "b14eeaf43929"
  :keywords '("outlines" "hypermedia" "tools")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
