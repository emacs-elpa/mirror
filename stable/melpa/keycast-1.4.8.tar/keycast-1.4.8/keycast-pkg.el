;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keycast" "1.4.8"
  "Show current command and its binding."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1"))
  :url "https://github.com/tarsius/keycast"
  :commit "a6518e1b48b08ba883e9b1a2db0872d5bf3d85f4"
  :revdesc "v1.4.8-0-ga6518e1b48b0"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev")))
