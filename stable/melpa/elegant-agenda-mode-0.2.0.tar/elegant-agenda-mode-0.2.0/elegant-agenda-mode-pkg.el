;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elegant-agenda-mode" "0.2.0"
  "An elegant theme for your org-agenda."
  '((emacs "26.1"))
  :url "https://github.com/justinbarclay/elegant-agenda-mode"
  :commit "7503da618a85a22f2bd9fcea263b9ba65532d75b"
  :revdesc "7503da618a85"
  :keywords '("faces")
  :authors '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainers '(("Justin Barclay" . "justinbarclay@gmail.com")))
