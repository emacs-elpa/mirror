;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toggle-window" "0.1.0"
  "Toggle current window size between half and full."
  ()
  :url "https://github.com/deadghost/toggle-window"
  :commit "05c032aea63298fc42930b485220321aad4b6d51"
  :revdesc "05c032aea632"
  :keywords '("hide" "window"))
