;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rescript-mode" "0.1.0"
  "A major mode for editing ReScript."
  '((emacs "24.3"))
  :url "https://github.com/jjlee/rescript-mode"
  :commit "0a976798d25a366c82bc1074214b3c07995a6a99"
  :revdesc "0a976798d25a"
  :keywords '("languages"))
