;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "function-args" "0.6.0"
  "C++ completion for GNU Emacs."
  '((ivy "0.9.1"))
  :url "https://github.com/abo-abo/function-args"
  :commit "0b07db81c0c1fa88d1ec763219ee57640858f79d"
  :revdesc "0b07db81c0c1"
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
