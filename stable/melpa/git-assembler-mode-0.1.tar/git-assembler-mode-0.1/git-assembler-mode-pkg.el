;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-assembler-mode" "0.1"
  "Git-assembler major mode."
  '((emacs "24.4"))
  :url "https://gitlab.com/wavexx/git-assembler-mode.el"
  :commit "4201e54ab93653f98df1b7965e592039e68bcb53"
  :revdesc "4201e54ab936"
  :keywords '("git" "git-assembler" "languages" "highlight" "syntax")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
