;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "searchq" "20150224.1800"
  "Framework of queued search tasks using GREP, ACK, AG and more."
  '((emacs "24.3"))
  :url "https://github.com/tcw165/searchq"
  :commit "580d3b1cb335793205189d787c49b077a63ce922"
  :revdesc "580d3b1cb335")
