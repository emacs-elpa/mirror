;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "honcho" "0.1"
  "Manage external services."
  '((emacs     "25.1")
    (sudo-edit "0.1"))
  :url "https://github.com/emacs-pe/honcho.el"
  :commit "340b87708e26867e1965d2c9aae8a7e717e25556"
  :revdesc "340b87708e26"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
