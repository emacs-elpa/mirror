;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scpaste" "0.7.0"
  "Paste to the web via scp."
  '((htmlize "1.39"))
  :url "https://git.sr.ht/~technomancy/scpaste"
  :commit "4723c551951c5e86ceaf078846f4f46db38739fe"
  :revdesc "0.7.0-0-g4723c551951c"
  :keywords '("convenience" "hypermedia"))
