;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cpputils-cmake" "5.5"
  "Easy realtime C++ syntax check and IntelliSense with CMake."
  ()
  :url "https://github.com/redguardtoo/cpputils-cmake"
  :commit "55e5c69554379632692a0fa20bfadeef9194fbdd"
  :revdesc "55e5c6955437"
  :keywords '("cmake" "intellisense" "flymake" "flycheck")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
