;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wollok-mode" "0.1"
  "Major mode for the Wollok programming language."
  '((emacs "24.4"))
  :url "https://github.com/tralph3/wollok-mode"
  :commit "61eb443ccfd8ab1a1e3315eb87ed3c4fe9ae31cd"
  :revdesc "61eb443ccfd8"
  :keywords '("wollok" "languages")
  :authors '(("Tomás Ralph" . "tomasralph2000@gmail.com"))
  :maintainers '(("Tomás Ralph" . "tomasralph2000@gmail.com")))
