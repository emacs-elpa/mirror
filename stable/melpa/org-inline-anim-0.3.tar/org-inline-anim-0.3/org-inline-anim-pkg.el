;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-inline-anim" "0.3"
  "Inline playback of animated GIF/PNG for Org."
  '((emacs "25.3")
    (org   "9.4"))
  :url "https://github.com/shg/org-inline-anim.el"
  :commit "9316fe78319fa18c7282993bd547cd33fda1b8ee"
  :revdesc "9316fe78319f"
  :keywords '("org" "outlines" "hypermedia" "multimedia"))
