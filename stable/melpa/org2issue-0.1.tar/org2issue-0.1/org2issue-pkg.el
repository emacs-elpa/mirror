;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org2issue" "0.1"
  "Org to github issue based blog."
  '((org    "8.0")
    (emacs  "24.4")
    (ox-gfm "0.1")
    (gh     "0.1"))
  :url "https://github.com/lujun9972/org2issue"
  :commit "3120250cc800cf4065d51bd475923d5695f48ff2"
  :revdesc "3120250cc800"
  :keywords '("convenience" "github" "org")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
