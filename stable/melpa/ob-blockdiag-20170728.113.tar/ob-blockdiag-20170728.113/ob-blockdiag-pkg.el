;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-blockdiag" "20170728.113"
  "Org-babel functions for blockdiag evaluation."
  ()
  :url "https://github.com/corpix/ob-blockdiag.el"
  :commit "634fcf64a4ae735afe7001d865b03f5d71e23046"
  :revdesc "634fcf64a4ae"
  :keywords '("tools" "convenience"))
