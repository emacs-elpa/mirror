;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "0.1.0"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (toml       "20230411.1449"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "75711b58b9d087b15ebc6c6a754d6e1289e02e72"
  :revdesc "75711b58b9d0"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
