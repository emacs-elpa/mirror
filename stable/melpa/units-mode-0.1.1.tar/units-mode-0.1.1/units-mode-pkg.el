;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "units-mode" "0.1.1"
  "Mode for conversion between different units."
  '((emacs "24.4"))
  :url "https://github.com/Atreyagaurav/units-mode"
  :commit "86d6a8773403455e39b15e8d09a76564f2ccbd6c"
  :revdesc "86d6a8773403"
  :keywords '("units" "unit-conversion" "convenience")
  :authors '(("Gaurav Atreya" . "allmanpride@gmail.com"))
  :maintainers '(("Gaurav Atreya" . "allmanpride@gmail.com")))
