;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solaire-mode" "2.0.5"
  "Make certain buffers grossly incandescent."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/hlissner/emacs-solaire-mode"
  :commit "8ccdceeb9298b3c4e35f630914f467bf164f39ad"
  :revdesc "v2.0.5-0-g8ccdceeb9298"
  :keywords '("dim" "bright" "window" "buffer" "faces")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
