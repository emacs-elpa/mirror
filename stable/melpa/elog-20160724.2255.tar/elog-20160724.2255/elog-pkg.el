;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elog" "20160724.2255"
  "Logging library extended from logito."
  '((eieio "1.3"))
  :url "https://github.com/lujun9972/elog"
  :commit "e171d0ff0a21011124204d77111e5992b50b7007"
  :revdesc "e171d0ff0a21"
  :keywords '("lisp" "tool" "log")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
