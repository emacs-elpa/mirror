;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jack-connect" "0.2"
  "Manage jack connections within Emacs."
  ()
  :commit "044d6eb0a38fab26fab56543dfb413840784c507"
  :revdesc "044d6eb0a38f"
  :authors '(("Stefano Barbi" . "stefanobarbi@gmail.com"))
  :maintainers '(("Stefano Barbi" . "stefanobarbi@gmail.com")))
