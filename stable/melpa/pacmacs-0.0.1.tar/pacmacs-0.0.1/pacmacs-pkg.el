;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pacmacs" "0.0.1"
  "Pacmacs for Emacs."
  ()
  :url "https://github.com/rexim/pacmacs.el"
  :commit "ba7ad0349d67864424a239b2f67354fcb1b321cd"
  :revdesc "ba7ad0349d67"
  :authors '(("Codingteam" . "codingteam@conference.jabber.ru"))
  :maintainers '(("Alexey Kutepov" . "reximkut@gmail.com")))
