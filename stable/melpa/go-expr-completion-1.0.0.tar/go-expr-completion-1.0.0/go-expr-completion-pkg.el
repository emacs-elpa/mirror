;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-expr-completion" "1.0.0"
  "[No description available]."
  ()
  :url "https://github.com/fujimisakari/emacs-go-expr-completion"
  :commit "4d63966f22d0c61eba9494ad38c013bd6a59aa53"
  :revdesc "4d63966f22d0"
  :authors '(("Ryo Fujimoto" . "fujimisakri@gmail.com"))
  :maintainers '(("Ryo Fujimoto" . "fujimisakri@gmail.com")))
