;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-results" "1.0.6"
  "Filter ERT test results display."
  '((emacs "24.1"))
  :url "https://github.com/rswgnu/ert-results"
  :commit "b89ffb3d719e24bb29a9d57cf189f5962caafdd4"
  :revdesc "b89ffb3d719e"
  :keywords '("lisp" "maint" "tools")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
