;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clang-capf" "1.2.3"
  "Completion-at-point backend for c/c++ using clang."
  '((emacs "24.4"))
  :url "https://git.sr.ht/~pkal/clang-capf"
  :commit "147be0e908f09ab2346443d48457f9624a404019"
  :revdesc "147be0e908f0"
  :keywords '("c" "abbrev" "convenience")
  :authors '(("Philip K." . "philipk[at]posteo[dot]net"))
  :maintainers '(("Philip K." . "philipk[at]posteo[dot]net")))
