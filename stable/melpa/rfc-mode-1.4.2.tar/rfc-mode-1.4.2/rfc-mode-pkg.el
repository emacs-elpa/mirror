;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rfc-mode" "1.4.2"
  "RFC document browser and viewer."
  '((emacs "25.1"))
  :url "https://github.com/galdor/rfc-mode"
  :commit "ab09db78d9d1baa4da4f926930833598e1e978ce"
  :revdesc "v1.4.2-0-gab09db78d9d1"
  :authors '(("Nicolas Martyanoff" . "nicolas@n16f.net"))
  :maintainers '(("Nicolas Martyanoff" . "nicolas@n16f.net")))
