;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "29.1.2"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "d199a49a01a2079afb6f2c5c9ae047cd4555e68d"
  :revdesc "OTP-29.1.2-0-gd199a49a01a2"
  :keywords '("erlang" "languages" "processes"))
