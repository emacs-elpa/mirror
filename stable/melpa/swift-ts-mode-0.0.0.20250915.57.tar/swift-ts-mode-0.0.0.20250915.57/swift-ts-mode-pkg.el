;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swift-ts-mode" "0.0.0.20250915.57"
  "Major mode for Swift based on tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/rechsteiner/swift-ts-mode"
  :commit "17806f6f56f09c86c5e70af239bea4313aaaf0b8"
  :revdesc "17806f6f56f0"
  :keywords '("swift" "languages" "tree-sitter"))
