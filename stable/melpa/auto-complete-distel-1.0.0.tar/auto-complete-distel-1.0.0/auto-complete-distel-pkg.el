;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-distel" "1.0.0"
  "Erlang/distel completion backend for auto-complete-mode."
  '((auto-complete         "1.4")
    (distel-completion-lib "1.0.0"))
  :url "github.com/sebastiw/distel-completion"
  :commit "340c9c11939d5f220db05e55388bf3cb606fd190"
  :revdesc "340c9c11939d"
  :keywords '("erlang" "distel" "auto-complete"))
