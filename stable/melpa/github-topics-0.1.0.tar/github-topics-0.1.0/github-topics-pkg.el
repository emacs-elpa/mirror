;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-topics" "0.1.0"
  "Lookup PRs matching a query."
  '((emacs "29.4")
    (ts    "0.3"))
  :url "https://github.com/agzam/github-topics"
  :commit "6086960d85bc538b6ea8cb91d1d69f9fedad4817"
  :revdesc "v0.1.0-0-g6086960d85bc"
  :keywords '("vc" "matching" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
