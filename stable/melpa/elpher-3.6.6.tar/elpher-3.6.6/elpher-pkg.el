;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpher" "3.6.6"
  "A friendly gopher and gemini client."
  '((emacs "27.1"))
  :url "https://thelambdalab.xyz/elpher"
  :commit "dcdeb86f7ae633e252f9ef8a73d3458e87c1ab12"
  :revdesc "dcdeb86f7ae6"
  :keywords '("comm" "gopher" "gemini")
  :authors '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainers '(("Tim Vaughan" . "plugd@thelambdalab.xyz")))
