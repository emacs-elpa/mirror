;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-tutor-sc" "2.2"
  "Simplified Chinese tutor for Evil."
  '((evil       "1.0.9")
    (evil-tutor "0.1"))
  :url "https://github.com/clsty/evil-tutor-sc"
  :commit "9ae3cff4b1d44d74989e832cfa566c20bbe6bb1a"
  :revdesc "9ae3cff4b1d4"
  :keywords '("convenience" "editing" "evil" "chinese")
  :authors '(("clsty" . "celestial.y@outlook.com"))
  :maintainers '(("clsty" . "celestial.y@outlook.com")))
