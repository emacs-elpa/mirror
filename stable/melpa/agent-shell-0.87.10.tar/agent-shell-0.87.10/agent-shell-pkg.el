;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.87.10"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6c35ec02775e0c1767f1c71ffbc860fe2e222f0b"
  :revdesc "6c35ec02775e")
