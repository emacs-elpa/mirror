;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitlab-ci-mode-flycheck" "20180605.1"
  "Flycheck support for ‘gitlab-ci-mode’."
  '((emacs          "25")
    (flycheck       "31")
    (gitlab-ci-mode "1"))
  :url "https://gitlab.com/joewreschnig/gitlab-ci-mode-flycheck/"
  :commit "30ea0eab74b24818f187242b079845785035e967"
  :revdesc "30ea0eab74b2"
  :keywords '("tools" "vc" "convenience"))
