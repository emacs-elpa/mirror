;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meshtastic" "1.2.0"
  "Chat client for Meshtastic LoRa devices via serial."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/meshtastic.el"
  :commit "6a85e523db966e8faf45ad909ed03d4d2b146191"
  :revdesc "6a85e523db96"
  :keywords '("comm")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
