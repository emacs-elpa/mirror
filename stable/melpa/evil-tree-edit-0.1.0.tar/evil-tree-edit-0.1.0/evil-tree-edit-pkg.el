;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-tree-edit" "0.1.0"
  "Evil structural editing for any language!."
  '((emacs     "27.0")
    (tree-edit "0.1.0")
    (evil      "1.0.0")
    (avy       "0.5.0"))
  :url "https://github.com/ethan-leba/tree-edit"
  :commit "fe0d2ff4edc016a4ed0ec3466a3f4438a64640bf"
  :revdesc "fe0d2ff4edc0"
  :authors '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainers '(("Ethan Leba" . "ethanleba5@gmail.com")))
