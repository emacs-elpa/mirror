;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zotra" "1.0"
  "Library to use Zotero translators."
  '((emacs "27.1"))
  :url "https://github.com/mpedramfar/zotra"
  :commit "73c138cda992b3eead3334c8b60c7b72b7b92297"
  :revdesc "73c138cda992"
  :authors '(("Mohammad Pedramfar" . "https://github.com/mpedramfar"))
  :maintainers '(("Mohammad Pedramfar" . "https://github.com/mpedramfar")))
