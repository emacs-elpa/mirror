;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pager-default-keybindings" "1.1"
  "Add the default keybindings suggested for pager.el."
  ()
  :url "https://github.com/nflath/pager-default-keybindings"
  :commit "2232d25c1ff9f99dced908ac6a9d7bb417474d34"
  :revdesc "2232d25c1ff9"
  :authors '(("Nathaniel Flath" . "nflath@gmail.com"))
  :maintainers '(("Nathaniel Flath" . "nflath@gmail.com")))
