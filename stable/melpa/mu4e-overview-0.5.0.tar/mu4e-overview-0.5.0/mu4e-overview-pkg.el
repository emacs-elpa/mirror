;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-overview" "0.5.0"
  "Show overview of maildir."
  '((emacs "26"))
  :url "https://github.com/mkcms/mu4e-overview"
  :commit "25a1c0c5fbac240e5faa1518b511609b709e3c53"
  :revdesc "0.5.0-0-g25a1c0c5fbac"
  :keywords '("mail" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
