;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typst-overlay" "0.8.1"
  "Overlay Typst equations."
  '((emacs "29.1"))
  :url "https://github.com/hesampakdaman/typst-overlay"
  :commit "95d2c633fe1ec9a14b32c834c8a1f00ba4c08e74"
  :revdesc "95d2c633fe1e"
  :keywords '("tools")
  :authors '(("Hesam Pakdaman" . "https://github.com/hesampakdaman"))
  :maintainers '(("Hesam Pakdaman" . "https://github.com/hesampakdaman")))
