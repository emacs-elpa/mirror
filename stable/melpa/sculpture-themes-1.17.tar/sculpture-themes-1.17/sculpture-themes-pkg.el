;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "1.17"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "89efb6bca369bb6240735e6228eb97d261a0e491"
  :revdesc "89efb6bca369"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
