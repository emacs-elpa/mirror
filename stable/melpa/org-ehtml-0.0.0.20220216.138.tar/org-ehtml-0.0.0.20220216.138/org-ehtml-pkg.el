;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ehtml" "0.0.0.20220216.138"
  "[No description available]."
  ()
  :url "https://github.com/eschulte/org-ehtml"
  :commit "419932d6dbce193b0d90b1ccf9bf643169d21f52"
  :revdesc "419932d6dbce"
  :keywords '("org" "web-server" "javascript" "html")
  :authors '(("Eric Schulte" . "schulte.eric@gmail.com"))
  :maintainers '(("Eric Schulte" . "schulte.eric@gmail.com")))
