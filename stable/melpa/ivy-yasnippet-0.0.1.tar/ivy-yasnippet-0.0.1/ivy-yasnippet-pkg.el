;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-yasnippet" "0.0.1"
  "Preview yasnippets with ivy."
  ()
  :url "https://github.com/emacsattic/ivy-yasnippet"
  :commit "e3830a4086f96a7c16873d30d2afdbe2707531e8"
  :revdesc "e3830a4086f9"
  :keywords '("convenience" "tools")
  :authors '(("Michał Kondraciuk" . "k.michal@zoho.com"))
  :maintainers '(("Michał Kondraciuk" . "k.michal@zoho.com")))
