;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "z3-mode" "0.0.1"
  "[No description available]."
  ()
  :url "https://github.com/zv/z3-mode"
  :commit "98c9cd7aa25923599a54c9fbbbb0a978315f783c"
  :revdesc "98c9cd7aa259"
  :keywords '("z3" "smt")
  :authors '(("Zephyr Pellerin" . "zephyr.pellerin@gmail.com"))
  :maintainers '(("Zephyr Pellerin" . "zephyr.pellerin@gmail.com")))
