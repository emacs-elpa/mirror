;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-palette" "1.0.4"
  "Make scratch buffer for each files."
  ()
  :url "http://zk-phi.gitub.io/"
  :commit "6b344af6b33b6b0bfd08e213dd0d43b714f7a5e9"
  :revdesc "6b344af6b33b")
