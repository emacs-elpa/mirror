;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sudoku" "1.4"
  "Simple sudoku game, can download puzzles from the web."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/zevlg/sudoku.el"
  :commit "324e0832183b322e3b36e9cd7215f1eecb4949af"
  :revdesc "324e0832183b"
  :keywords '("games")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
