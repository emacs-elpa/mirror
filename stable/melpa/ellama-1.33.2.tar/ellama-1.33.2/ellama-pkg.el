;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "1.33.2"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.31.1")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "6dee58ebb4e25c8bf98d21a302264a5f51c8180f"
  :revdesc "6dee58ebb4e2"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
