;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-math-input" "0.1"
  "Insert Unicode math symbols with Quail or Ivy."
  '((emacs "24.1")
    (ivy   "0.10.0"))
  :url "https://codeberg.org/astoff/unicode-math-input.el"
  :commit "42dcfdd6c13594f224d6b09690f851eabe9115f2"
  :revdesc "42dcfdd6c135")
