;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eclipse-theme" "0.1.0"
  "Theme from Eclispe circa 2010."
  ()
  :url "https://github.com/abo-abo/eclipse-theme"
  :commit "07e2bed4959393e28c68fa614e5edff902f3873c"
  :revdesc "07e2bed49593"
  :keywords '("themes")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
