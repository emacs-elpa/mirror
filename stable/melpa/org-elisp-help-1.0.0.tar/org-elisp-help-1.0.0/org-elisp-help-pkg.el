;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-elisp-help" "1.0.0"
  "Org links to emacs-lisp documentation."
  '((cl-lib "0.5")
    (org    "9.0"))
  :url "https://github.com/tarsius/org-elisp-help"
  :commit "3e33ab1a2933dd7f2782ef91d667a37f12d633ab"
  :revdesc "1.0.0-0-g3e33ab1a2933"
  :keywords '("org" "remember" "lisp")
  :authors '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
