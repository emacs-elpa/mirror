;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "literate-coffee-mode" "0.4"
  "Major-mode for Literate CoffeeScript."
  '((coffee-mode "0.5.0"))
  :url "https://github.com/syohex/emacs-literate-coffee-mode"
  :commit "39fe3bfa1f68a7b8b91160875589219b214a2cd6"
  :revdesc "39fe3bfa1f68"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
