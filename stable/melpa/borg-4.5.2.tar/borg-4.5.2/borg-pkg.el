;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.5.2"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.6"))
  :url "https://github.com/emacscollective/borg"
  :commit "a844569c8ef24408ba0df31d5cd58be9d955efce"
  :revdesc "v4.5.2-0-ga844569c8ef2"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
