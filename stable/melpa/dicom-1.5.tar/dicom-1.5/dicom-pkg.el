;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "1.5"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/dicom"
  :commit "026a12a27939b29935ea343bab9162ed27bd732e"
  :revdesc "1.5-0-g026a12a27939"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
