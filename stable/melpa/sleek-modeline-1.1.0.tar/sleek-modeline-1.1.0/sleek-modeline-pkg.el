;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sleek-modeline" "1.1.0"
  "Minimal and elegant modeline."
  '((emacs "29.1"))
  :url "https://github.com/abidanBrito/sleek-modeline"
  :commit "e5981c02498f4922f220f16f062f91512a5c406d"
  :revdesc "v1.1.0-0-ge5981c02498f"
  :keywords '("mode-line" "faces")
  :authors '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com"))
  :maintainers '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com")))
