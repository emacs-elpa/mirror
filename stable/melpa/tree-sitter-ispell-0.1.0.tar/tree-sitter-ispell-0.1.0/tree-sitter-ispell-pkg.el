;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-sitter-ispell" "0.1.0"
  "Run ispell on tree-sitter text nodes."
  ()
  :url "https://github.com/erickgnavar/tree-sitter-ispell.el"
  :commit "2d7e68c6ab010ede0170c426a2a4d04537ce191f"
  :revdesc "2d7e68c6ab01"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
