;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-yasnippet" "0.3.0"
  "Quickly create disposable yasnippets."
  '((yasnippet "0.8.0"))
  :url "https://github.com/abo-abo/auto-yasnippet"
  :commit "5cc54edbe03c0061bf69883a3e39d3bb16019e0f"
  :revdesc "5cc54edbe03c"
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
