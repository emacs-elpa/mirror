;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "api-credit" "1.0.1"
  "AI API balance in the modeline."
  '((emacs "25.1"))
  :url "https://github.com/OverbearingPearl/api-credit"
  :commit "fdb5648fd73c18bb25aa78557c7de21623268a63"
  :revdesc "fdb5648fd73c"
  :keywords '("comm" "convenience")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
