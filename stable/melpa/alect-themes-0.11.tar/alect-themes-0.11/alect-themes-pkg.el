;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alect-themes" "0.11"
  "Configurable light, dark and black themes for Emacs 24 or later."
  '((emacs "24.0"))
  :url "https://github.com/alezost/alect-themes"
  :commit "032dfebede02d44c167328f95c7ea5846d340e3c"
  :revdesc "032dfebede02"
  :keywords '("color" "theme")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
