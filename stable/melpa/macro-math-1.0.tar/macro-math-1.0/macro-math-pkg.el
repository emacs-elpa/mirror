;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macro-math" "1.0"
  "In-buffer mathematical operations."
  ()
  :url "http://nschum.de/src/emacs/macro-math/"
  :commit "105e03c80290d1b88984b2d265a149a13d722920"
  :revdesc "1.0-0-g105e03c80290"
  :keywords '("convenience")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
