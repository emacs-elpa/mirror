;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undersea-theme" "0.3"
  "Theme styled after undersea imagery."
  '((emacs "24.3"))
  :url "https://github.com/jcs-elpa/undersea-theme"
  :commit "952d0c14258b0fd2d2e4642c6576708dac35c2f8"
  :revdesc "952d0c14258b"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
