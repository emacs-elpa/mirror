;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.93.1"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "43ee9e1862994cbaa89715d324edb7a424181f22"
  :revdesc "43ee9e186299")
