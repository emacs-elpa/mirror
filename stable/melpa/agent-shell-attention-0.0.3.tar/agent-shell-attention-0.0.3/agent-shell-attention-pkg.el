;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-attention" "0.0.3"
  "Mode-line attention tracker for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.47.1"))
  :url "https://github.com/ultronozm/agent-shell-attention.el"
  :commit "ecd3c056fb42582ca93aeb6ab72e3b3f1a4350fb"
  :revdesc "v0.0.3-0-gecd3c056fb42"
  :keywords '("convenience")
  :authors '(("Paul D. Nelson" . "ultrono@gmail.com"))
  :maintainers '(("Paul D. Nelson" . "ultrono@gmail.com")))
