;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-osx-app" "1.0"
  "Launch macOS apps with helm."
  '((emacs     "25.1")
    (helm-core "3.0"))
  :url "https://github.com/xuchunyang/helm-osx-app"
  :commit "872bc258b688f95ed4d4769ba0738b255376a47d"
  :revdesc "872bc258b688")
