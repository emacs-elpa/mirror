;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-test" "0.6.1"
  "A test runner for Python code."
  '((dash  "2.9.0")
    (f     "0.17")
    (emacs "24"))
  :url "https://github.com/Bogdanp/py-test.el"
  :commit "c55efee2d2f00266d7c8b4ace926359de5140f73"
  :revdesc "c55efee2d2f0"
  :keywords '("python" "testing" "py.test")
  :authors '(("Bogdan Paul Popa" . "popa.bogdanp@gmail.com"))
  :maintainers '(("Bogdan Paul Popa" . "popa.bogdanp@gmail.com")))
