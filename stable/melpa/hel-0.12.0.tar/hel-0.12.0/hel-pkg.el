;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hel" "0.12.0"
  "Helix Emulation Layer."
  '((emacs "29.1"))
  :url "https://github.com/anuvyklack/hel"
  :commit "51a1818650e7345ec385c7e62a763fa32a1d3a75"
  :revdesc "51a1818650e7"
  :authors '(("Yuriy Artemyev" . "anuvyklack@gmail.com"))
  :maintainers '(("Yuriy Artemyev" . "anuvyklack@gmail.com")))
