;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "define-word" "0.1.0"
  "Display the definition of word at point."
  '((emacs "24.1"))
  :url "https://github.com/abo-abo/define-word"
  :commit "38e2f94779652fc6280a51b68dc910431513a8e1"
  :revdesc "38e2f9477965"
  :keywords '("dictionary" "convenience")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
