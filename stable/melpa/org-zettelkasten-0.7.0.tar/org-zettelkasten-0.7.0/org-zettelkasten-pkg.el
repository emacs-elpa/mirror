;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-zettelkasten" "0.7.0"
  "A Zettelkasten mode leveraging Org."
  '((emacs "24.3")
    (org   "9.0"))
  :url "https://git.sr.ht/~ymherklotz/org-zettelkasten"
  :commit "e8a4d435e1d33344a1be192b6816a67394d91307"
  :revdesc "e8a4d435e1d3"
  :keywords '("files" "hypermedia" "org" "notes")
  :authors '(("Yann Herklotz" . "yann@ymhg.org"))
  :maintainers '(("Yann Herklotz" . "yann@ymhg.org")))
