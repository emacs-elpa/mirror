;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flx" "0.6.1"
  "Fuzzy matching with good sorting."
  '((cl-lib "0.3"))
  :url "https://github.com/lewang/flx"
  :commit "7fce6a4cdb65ac1b52e2b409ba548767581ce34c"
  :revdesc "7fce6a4cdb65")
