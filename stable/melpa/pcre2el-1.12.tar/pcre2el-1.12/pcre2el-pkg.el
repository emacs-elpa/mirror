;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcre2el" "1.12"
  "Regexp syntax converter."
  '((emacs "25.1"))
  :url "https://github.com/joddie/pcre2el"
  :commit "7ba65df17d946448b33421d08d975e9bcfc51d91"
  :revdesc "7ba65df17d94"
  :authors '(("joddie" . "jonxfieldatgmail.com"))
  :maintainers '(("joddie" . "jonxfieldatgmail.com")))
