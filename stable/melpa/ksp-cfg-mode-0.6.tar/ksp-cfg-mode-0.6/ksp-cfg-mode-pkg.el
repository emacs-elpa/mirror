;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ksp-cfg-mode" "0.6"
  "Major mode for editing KSP CFG files."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/lashtear/ksp-cfg-mode"
  :commit "faec8bd8456c67276d065eb68c88a30efcef59ef"
  :revdesc "faec8bd8456c"
  :keywords '("data")
  :authors '(("Emily Backes" . "lucca@accela.net"))
  :maintainers '(("Emily Backes" . "lucca@accela.net")))
