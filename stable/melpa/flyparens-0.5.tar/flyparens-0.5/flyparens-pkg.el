;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyparens" "0.5"
  "Check for unbalanced parens on the fly."
  ()
  :url "https://github.com/jiyoo/flyparens"
  :commit "8ddd44a604295e98eda16f22e4b3a98ba84aeaaf"
  :revdesc "8ddd44a60429"
  :keywords '("faces" "convenience" "lisp" "matching" "parentheses" "parens"))
