;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyfun-mode" "0.8.1"
  "Major mode for the Pyfun language."
  '((emacs "29.1"))
  :url "https://github.com/simontreanor/Pyfun"
  :commit "dec181b060c41a8bec4e3e308abdd37c27d9eed0"
  :revdesc "dec181b060c4"
  :keywords '("languages"))
