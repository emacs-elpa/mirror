;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-json-to-hash" "0.1"
  "Convert JSON to Hash and play with the keys."
  '((emacs             "27.2")
    (smartparens       "20210904.1621")
    (string-inflection "1.0.16"))
  :url "https://github.com/otavioschwanck/rails-json-to-hash.el"
  :commit "78ddd50b2e78dfa8916c51ad0ee7b11791839649"
  :revdesc "78ddd50b2e78"
  :keywords '("tools" "languages")
  :authors '(("Otávio Schwanck dos Santos" . "otavioschwanck@gmail.com"))
  :maintainers '(("Otávio Schwanck dos Santos" . "otavioschwanck@gmail.com")))
