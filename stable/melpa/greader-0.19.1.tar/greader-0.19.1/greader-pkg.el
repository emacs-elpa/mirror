;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "0.19.1"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "b749500395e7fab8b6c17e503fc4e250f3921ed9"
  :revdesc "v0.19.1-0-gb749500395e7"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
