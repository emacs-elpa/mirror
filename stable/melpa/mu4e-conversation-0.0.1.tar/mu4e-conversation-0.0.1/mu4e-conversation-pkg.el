;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-conversation" "0.0.1"
  "Show a complete thread in a single buffer."
  '((emacs "25.1")
    (mu4e  "1.0"))
  :url "https://github.com/Ambrevar/mu4e-conversation"
  :commit "13b3809d41ac9586419084519f35e01ffc6b1b1c"
  :revdesc "13b3809d41ac"
  :keywords '("mail" "convenience" "mu4e")
  :authors '(("Pierre Neidhardt" . "ambrevar@gmail.com"))
  :maintainers '(("Pierre Neidhardt" . "ambrevar@gmail.com")))
