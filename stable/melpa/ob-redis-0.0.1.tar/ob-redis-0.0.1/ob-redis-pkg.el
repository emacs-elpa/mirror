;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-redis" "0.0.1"
  "Execute mongodb queries within org-mode blocks."
  '((org "8"))
  :url "https://github.com/stardiviner/ob-redis"
  :commit "932cc70f57ceb29ce9f4eb6854100fcdd1be7ce4"
  :revdesc "932cc70f57ce"
  :keywords '("org" "babel" "mongo" "mongodb")
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
