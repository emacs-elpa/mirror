;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "po-mode" "2.32"
  "Major mode for GNU gettext PO files."
  '((emacs "23"))
  :commit "a36ab4652ad712f5e7c43db222ef27c8a6e1c4c5"
  :revdesc "a36ab4652ad7"
  :keywords '("i18n" "gettext"))
