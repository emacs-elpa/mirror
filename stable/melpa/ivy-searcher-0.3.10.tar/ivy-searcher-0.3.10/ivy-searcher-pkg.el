;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-searcher" "0.3.10"
  "Ivy interface to use searcher."
  '((emacs    "25.1")
    (ivy      "0.8.0")
    (searcher "0.1.8")
    (s        "1.12.0")
    (f        "0.20.0"))
  :url "https://github.com/jcs-elpa/ivy-searcher"
  :commit "46a461eb873083bc53d7fd3a15b266c52b3cbfb4"
  :revdesc "46a461eb8730"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
