;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "searcher" "0.4.1"
  "Searcher in pure elisp."
  '((emacs "25.1")
    (dash  "2.10")
    (f     "0.20.0"))
  :url "https://github.com/jcs-elpa/searcher"
  :commit "432d2ea9f7d0ab7274ff2927d26e7adca85be169"
  :revdesc "432d2ea9f7d0"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
