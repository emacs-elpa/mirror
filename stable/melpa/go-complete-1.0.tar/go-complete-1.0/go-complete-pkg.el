;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-complete" "1.0"
  "Native code completion for Go."
  '((go-mode "0"))
  :url "https://github.com/vibhavp/go-complete"
  :commit "d3ec55408f5340662410da831a3753acd2767bd5"
  :revdesc "d3ec55408f53"
  :keywords '("go" "golang" "completion")
  :authors '(("Vibhav Pant" . "vibhavp@gmail.com"))
  :maintainers '(("Vibhav Pant" . "vibhavp@gmail.com")))
