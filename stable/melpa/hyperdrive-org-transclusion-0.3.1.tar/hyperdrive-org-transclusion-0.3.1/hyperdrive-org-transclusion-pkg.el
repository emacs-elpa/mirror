;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperdrive-org-transclusion" "0.3.1"
  "Tranclude hyperdrive content."
  '((emacs            "28.1")
    (hyperdrive       "0.4.2")
    (org-transclusion "1.4.0"))
  :url "https://git.sr.ht/~ushin/hyperdrive-org-transclusion"
  :commit "25570c6e4b90dce0858b80b7f557db19744b3955"
  :revdesc "v0.3.1-0-g25570c6e4b90"
  :authors '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht")))
