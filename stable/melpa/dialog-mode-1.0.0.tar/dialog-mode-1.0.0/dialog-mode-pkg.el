;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "1.0.0"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "7eb70b7473bb86b4c661fbe39dc1f8d1f01d6ec5"
  :revdesc "7eb70b7473bb"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
