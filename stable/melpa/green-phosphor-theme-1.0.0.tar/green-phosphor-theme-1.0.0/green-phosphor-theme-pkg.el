;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "green-phosphor-theme" "1.0.0"
  "A light color theme with muted, autumnal colors."
  ()
  :url "https://github.com/aalpern/emacs-color-theme-green-phosphor"
  :commit "f2273b54508a99e57abf138c7f1e498cc567d073"
  :revdesc "f2273b54508a"
  :keywords '("color" "theme")
  :authors '(("Adam Alpern" . "adam.alpern@gmail.com"))
  :maintainers '(("Adam Alpern" . "adam.alpern@gmail.com")))
