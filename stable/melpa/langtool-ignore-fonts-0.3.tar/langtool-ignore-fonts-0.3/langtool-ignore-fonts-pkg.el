;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "langtool-ignore-fonts" "0.3"
  "Force langtool to ignore certain fonts."
  '((emacs    "25.1")
    (langtool "2.2.1"))
  :url "https://github.com/cjl8zf/langtool-ignore-fonts"
  :commit "8c2099ff97c6f7f0127cb86f0ced10074da078fc"
  :revdesc "8c2099ff97c6"
  :authors '(("Christopher Lloyd" . "cjl8zf@virginia.edu"))
  :maintainers '(("Christopher Lloyd" . "cjl8zf@virginia.edu")))
