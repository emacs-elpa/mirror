;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clang-format-lite" "0.0.1"
  "A clang-format package with on-save and remote file support."
  ()
  :url "https://github.com/arteen1000/clang-format-lite"
  :commit "85d6bf204803bb5724d1c031624f95b8e295dd34"
  :revdesc "85d6bf204803"
  :keywords '("tools" "c" "c++" "clang-format" "formatting")
  :authors '(("Arteen Abrishami" . "arteen@ucla.edu"))
  :maintainers '(("Arteen Abrishami" . "arteen@ucla.edu")))
