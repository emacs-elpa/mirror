;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zeno-theme" "20180211.1557"
  "A dark theme with vibrant colors."
  '((emacs "24"))
  :url "https://github.com/jbharat/zeno-theme"
  :commit "576a9e962d0640feb6bffdea6ec19fbf1eeaca8e"
  :revdesc "576a9e962d06"
  :keywords '("faces" "theme" "dark" "vibrant colors")
  :authors '(("Bharat Joshi" . "jbharat@outlook.com"))
  :maintainers '(("Bharat Joshi" . "jbharat@outlook.com")))
