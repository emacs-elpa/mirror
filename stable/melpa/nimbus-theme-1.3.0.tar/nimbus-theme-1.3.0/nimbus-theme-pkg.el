;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nimbus-theme" "1.3.0"
  "Nimbus dark theme."
  '((emacs "24.1"))
  :url "https://github.com/m-cat/nimbus-theme"
  :commit "178557148f2e132c79be25429d04c5b89f6535dd"
  :revdesc "178557148f2e"
  :keywords '("faces")
  :authors '(("Marcin Swieczkowski" . "marcin.swieczkowski@gmail.com"))
  :maintainers '(("Marcin Swieczkowski" . "marcin.swieczkowski@gmail.com")))
