;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swoop" "1.0"
  "Peculiar buffer navigation."
  '((emacs   "24.3")
    (ht      "2.0")
    (pcre2el "1.5")
    (async   "1.1"))
  :url "https://github.com/ShingoFukuyama/emacs-swoop"
  :commit "de2d29eb45edab802cf8b275aa1c25a24050122e"
  :revdesc "de2d29eb45ed"
  :keywords '("tools" "swoop" "inner" "buffer" "search" "navigation"))
