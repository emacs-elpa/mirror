;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-today" "0.0.2"
  "Show total clocked time of the current day in the mode line."
  '((emacs "25"))
  :url "https://github.com/mallt/org-clock-today-mode"
  :commit "18af3fede1aa0ccab83ce9195f94f9097f51c548"
  :revdesc "18af3fede1aa"
  :authors '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com"))
  :maintainers '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com")))
