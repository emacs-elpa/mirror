;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "free-keys" "1.0.0"
  "Show free keybindings for modkeys or prefixes."
  '((cl-lib "0.3"))
  :url "https://github.com/Fuco1/free-keys"
  :commit "edfd69dc369b2647447b7c28c7c1163b1ddf45b4"
  :revdesc "edfd69dc369b"
  :keywords '("convenience")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
