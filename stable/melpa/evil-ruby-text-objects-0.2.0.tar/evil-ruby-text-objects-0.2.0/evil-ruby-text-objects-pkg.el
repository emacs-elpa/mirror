;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ruby-text-objects" "0.2.0"
  "Evil text objects for Ruby code."
  '((emacs "25.1")
    (evil  "1.2.0"))
  :url "https://github.com/porras/evil-ruby-text-objects"
  :commit "e69abb6aad7687222cb47a8a64dc4dd66ef96a9e"
  :revdesc "e69abb6aad76"
  :keywords '("languages")
  :authors '(("Sergio Gil" . "sgilperez@gmail.com"))
  :maintainers '(("Sergio Gil" . "sgilperez@gmail.com")))
