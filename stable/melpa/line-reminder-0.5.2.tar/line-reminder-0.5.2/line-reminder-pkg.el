;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "line-reminder" "0.5.2"
  "Line annotation for changed and saved lines."
  '((emacs         "25.1")
    (indicators    "0.0.4")
    (fringe-helper "1.0.1")
    (ov            "1.0.6")
    (ht            "2.0"))
  :url "https://github.com/emacs-vs/line-reminder"
  :commit "8b63b6ad6733363b24a8f5472f71eab301044b43"
  :revdesc "8b63b6ad6733"
  :keywords '("convenience" "annotation")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
