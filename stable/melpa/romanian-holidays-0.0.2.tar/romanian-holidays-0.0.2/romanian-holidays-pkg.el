;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "romanian-holidays" "0.0.2"
  "Romanian holidays."
  '((emacs "26"))
  :url "https://github.com/petrem/romanian-holidays"
  :commit "3bd6909b9709e65e83a0a77e59292d4932602bb8"
  :revdesc "3bd6909b9709"
  :keywords '("calendar" "holidays" "romanian"))
