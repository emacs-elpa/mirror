;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stem-reading-mode" "0.1"
  "Highlight word stems for speed-reading."
  '((emacs "25.1"))
  :url "https://gitlab.com/wavexx/stem-reading-mode.el"
  :commit "71b885dc5d32b82e27e5ae8460e02f2042ed5afd"
  :revdesc "71b885dc5d32"
  :keywords '("convenience" "wp")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
