;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotate" "1.4.3"
  "Annotate files without changing them."
  ()
  :url "https://github.com/bastibe/annotate.el"
  :commit "b9c908f24c2119d99cd93c86a0920223ef0568e9"
  :revdesc "b9c908f24c21")
