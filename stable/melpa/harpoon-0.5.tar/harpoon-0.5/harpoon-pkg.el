;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "harpoon" "0.5"
  "Bookmarks on steroids."
  '((emacs   "27.2")
    (f       "0.20.0")
    (hydra   "0.14.0")
    (project "0.8.1"))
  :url "https://github.com/otavioschwanck/harpoon.el"
  :commit "a23571eaab94fb2da0569ed5ab3c1b469f123b97"
  :revdesc "a23571eaab94"
  :keywords '("tools" "languages")
  :authors '(("Otávio Schwanck" . "otavioschwanck@gmail.com"))
  :maintainers '(("Otávio Schwanck" . "otavioschwanck@gmail.com")))
