;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-expat" "0.0.1"
  "Evil ex commands."
  '((emacs "24.3")
    (evil  "1.0.0"))
  :url "https://github.com/edkolev/evil-expat"
  :commit "d5a2014078b795440dc823525610a971ef0ed7cd"
  :revdesc "d5a2014078b7"
  :keywords '("emulations" "evil" "vim")
  :authors '(("edkolev" . "evgenysw@gmail.com"))
  :maintainers '(("edkolev" . "evgenysw@gmail.com")))
