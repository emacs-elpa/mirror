;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-tcl" "0.4"
  "A flycheck checker for Tcl using ActiveState's tclchecker."
  '((flycheck "0.17"))
  :url "https://github.com/nwidger/flycheck-tcl"
  :commit "9c8746493c17fc92ad8576d0143c6a2e5d7deb0a"
  :revdesc "9c8746493c17")
