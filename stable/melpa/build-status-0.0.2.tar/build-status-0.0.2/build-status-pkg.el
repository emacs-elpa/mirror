;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "build-status" "0.0.2"
  "Mode line build status indicator."
  '((cl-lib "0.5"))
  :url "https://github.com/sshaw/build-status"
  :commit "c29a0146c5d0be274f5e17921e01698f572c23a1"
  :revdesc "c29a0146c5d0"
  :keywords '("mode-line" "ci" "circleci" "travis-ci")
  :authors '(("Skye Shaw" . "skye.shaw@gmail.com"))
  :maintainers '(("Skye Shaw" . "skye.shaw@gmail.com")))
