;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neut-mode" "1.0.0"
  "A major mode for Neut."
  '((emacs    "27.1")
    (lsp-mode "8.0.1"))
  :url "https://github.com/vekatze/neut-mode"
  :commit "c1676f71b8925c0c37051792e5789bd6c0d38f19"
  :revdesc "c1676f71b892"
  :authors '(("vekatze" . "vekatze@icloud.com"))
  :maintainers '(("vekatze" . "vekatze@icloud.com")))
