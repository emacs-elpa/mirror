;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "expui-icons" "0.2.1"
  "Icons from IntelliJ's New UI."
  '((emacs "29.1"))
  :url "https://github.com/wwulfric/expui-icons"
  :commit "30b170955acfb147076fbd9a079ed69623ee88ad"
  :revdesc "v0.2.1-0-g30b170955acf"
  :keywords '("convenience" "files")
  :authors '(("Lufei Wang" . "wwulfric@gmail.com"))
  :maintainers '(("Lufei Wang" . "wwulfric@gmail.com")))
