;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "1.28.0"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.31.1")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "b6e123a880173b8bfa918829806e22f575266ffd"
  :revdesc "b6e123a88017"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
