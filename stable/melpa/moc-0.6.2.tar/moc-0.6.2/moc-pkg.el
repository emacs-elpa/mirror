;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moc" "0.6.2"
  "Master of Ceremonies."
  '((emacs          "29.4")
    (hide-mode-line "1.0.3")
    (transient      "0.7.2"))
  :url "https://github.com/positron-solutions/moc"
  :commit "fda3cf6fae0ccd195cb69c440a56a8a18a7acaf3"
  :revdesc "fda3cf6fae0c"
  :keywords '("convenience" "outline")
  :authors '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainers '(("Positron Solutions" . "contact@positron.solutions")))
