;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amber-mode" "1.1.1"
  "A major mode for the Amber programming language."
  '((emacs "28.1"))
  :url "https://codeberg.org/GeorgGD/amber-mode"
  :commit "0e5efff23e2ad6d55a57e8e5df5e3fe8a35bfa32"
  :revdesc "0e5efff23e2a"
  :keywords '("amber" "languages")
  :authors '(("Georgios Davakos" . "georgios.davakos@protonmail.com"))
  :maintainers '(("Georgios Davakos" . "georgios.davakos@protonmail.com")))
