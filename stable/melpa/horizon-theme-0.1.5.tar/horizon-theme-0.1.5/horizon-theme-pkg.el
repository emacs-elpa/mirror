;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "horizon-theme" "0.1.5"
  "A beautifully warm dual theme for Emacs."
  '((emacs "24.3"))
  :url "https://github.com/aodhneine/horizon-theme.el"
  :commit "8cf9a59d712cd0421b2efed07dbe91c0c1696a6b"
  :revdesc "8cf9a59d712c"
  :authors '(("Aodnait taín" . "aodhneine@tuta.io"))
  :maintainers '(("Aodnait taín" . "aodhneine@tuta.io")))
