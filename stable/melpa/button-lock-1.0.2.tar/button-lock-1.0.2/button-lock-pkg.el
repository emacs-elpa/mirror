;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "button-lock" "1.0.2"
  "Clickable text defined by regular expression."
  ()
  :url "https://github.com/rolandwalker/button-lock"
  :commit "cd0bf4a3c2f224d851e6ed8a54a6e80c129b225f"
  :revdesc "v1.0.2-0-gcd0bf4a3c2f2"
  :keywords '("mouse" "button" "hypermedia" "extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
