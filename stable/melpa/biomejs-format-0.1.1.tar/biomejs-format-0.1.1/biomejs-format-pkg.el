;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "biomejs-format" "0.1.1"
  "Minor mode to format JS code with Biome on file save."
  '((emacs "24.1"))
  :url "https://github.com/yadex205/emacs-biomejs-format"
  :commit "cbfb8aac8bfab6fd893f1ccb4eb9efa29b1b3214"
  :revdesc "v0.1.1-0-gcbfb8aac8bfa"
  :keywords '("convenience" "wp" "edit" "js")
  :maintainers '(("Kanon Kakuno" . "yadex205@yadex205.com")))
