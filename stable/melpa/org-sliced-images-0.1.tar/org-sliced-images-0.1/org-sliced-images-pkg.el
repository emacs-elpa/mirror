;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-sliced-images" "0.1"
  "Sliced inline images in org-mode."
  '((org "0"))
  :url "https://github.com/jcfk/org-sliced-images"
  :commit "fd4b7281d367c3d65d7f5da3748c212dbb0ddfc6"
  :revdesc "fd4b7281d367"
  :authors '(("Jacob Fong" . "jacobcfong@gmail.com"))
  :maintainers '(("Jacob Fong" . "jacobcfong@gmail.com")))
