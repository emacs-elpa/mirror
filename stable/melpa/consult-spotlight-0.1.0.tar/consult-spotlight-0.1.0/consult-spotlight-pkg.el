;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-spotlight" "0.1.0"
  "Spotlight search using Consult."
  '((emacs   "29.1")
    (consult "3.1"))
  :url "https://github.com/mdf/consult-spotlight"
  :commit "e3fad0f29ab9b32bbdc1a260d199d1f203eed76a"
  :revdesc "e3fad0f29ab9"
  :keywords '("matching" "files" "convenience"))
