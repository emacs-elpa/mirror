;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "texfrag" "1.0.1"
  "Preview LaTeX fragments in alien major modes."
  '((emacs  "25")
    (auctex "11.90.2"))
  :url "https://github.com/TobiasZawada/texfrag"
  :commit "270a8a4b5dadddc5b226d9a9c6c7868ea6bfe86f"
  :revdesc "270a8a4b5dad"
  :keywords '("tex" "languages" "wp")
  :authors '(("Tobias Zawada" . "i@tn-home.de"))
  :maintainers '(("Tobias Zawada" . "i@tn-home.de")))
