;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exotica-theme" "1.0.2"
  "A dark theme with vibrant colors."
  '((emacs "24"))
  :url "https://github.com/jbharat/exotica-theme"
  :commit "dddaf53485432b401d28769634a5712316905d39"
  :revdesc "dddaf5348543"
  :keywords '("faces" "theme" "dark" "vibrant colors")
  :authors '(("Bharat Joshi" . "jbharat@outlook.com"))
  :maintainers '(("Bharat Joshi" . "jbharat@outlook.com")))
