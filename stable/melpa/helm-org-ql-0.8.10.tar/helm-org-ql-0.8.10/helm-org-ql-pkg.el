;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-org-ql" "0.8.10"
  "Helm support for org-ql."
  '((emacs    "26.1")
    (dash     "2.18.1")
    (s        "1.12.0")
    (helm-org "1.0")
    (org-ql   "0.6-pre"))
  :url "https://github.com/alphapapa/org-ql"
  :commit "9c53c1bddfcbda3475ffd8810f012be6de07d963"
  :revdesc "v0.8.10-0-g9c53c1bddfcb"
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
