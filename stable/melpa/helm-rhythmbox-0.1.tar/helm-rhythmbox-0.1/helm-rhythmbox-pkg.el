;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-rhythmbox" "0.1"
  "Control Rhythmbox's play queue via Helm."
  '((helm   "1.5.0")
    (cl-lib "0.5"))
  :url "https://github.com/mrBliss/helm-rhyhmtbox"
  :commit "4cc067a6f04338ddcda815e9593a0801c79d82dc"
  :revdesc "4cc067a6f043"
  :authors '(("Thomas Winant" . "dewinant@gmail.com"))
  :maintainers '(("Thomas Winant" . "dewinant@gmail.com")))
