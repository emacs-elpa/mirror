;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-bible" "1.3.2"
  "Org Link support for Bible Passages."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~swflint/ol-bible"
  :commit "ee59069585bc8cb5c9c06e0206de97dafa56d8cd"
  :revdesc "ee59069585bc"
  :keywords '("convenience" "outlines")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
