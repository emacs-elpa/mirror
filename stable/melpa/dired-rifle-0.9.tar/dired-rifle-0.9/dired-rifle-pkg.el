;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-rifle" "0.9"
  "Call rifle(1) from dired."
  ()
  :url "https://github.com/vifon/dired-rifle.el"
  :commit "942f2fe5867119f35f5e2eb17612bcf86abb3d22"
  :revdesc "942f2fe58671"
  :keywords '("files" "convenience")
  :authors '(("Wojciech Siewierski" . "wojciechdotsiewierskiatonetdotpl"))
  :maintainers '(("Wojciech Siewierski" . "wojciechdotsiewierskiatonetdotpl")))
