;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modern-cpp-font-lock" "0.1.3"
  "Font-locking for \"Modern C++\"."
  ()
  :url "https://github.com/ludwigpacifici/modern-cpp-font-lock"
  :commit "3e9c18b5a2ade485565f5191f12a724f1969dbb0"
  :revdesc "3e9c18b5a2ad"
  :keywords '("languages" "c++" "cpp" "font-lock")
  :authors '(("Ludwig PACIFICI" . "ludwig@lud.cc"))
  :maintainers '(("Ludwig PACIFICI" . "ludwig@lud.cc")))
