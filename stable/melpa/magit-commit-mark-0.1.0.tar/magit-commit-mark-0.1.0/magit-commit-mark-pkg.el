;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-commit-mark" "0.1.0"
  "Support marking commits as read."
  '((emacs "26.2")
    (magit "3.3.0"))
  :url "https://gitlab.com/ideasman42/emacs-magit-commit-mark"
  :commit "3debd2bdf20b78e108d309be606db01bb2cb4810"
  :revdesc "3debd2bdf20b"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
