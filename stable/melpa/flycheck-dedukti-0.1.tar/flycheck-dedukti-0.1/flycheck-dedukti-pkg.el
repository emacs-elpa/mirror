;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-dedukti" "0.1"
  "Flycheck integration of Dedukti."
  '((f            "0.11.0")
    (flycheck     "0.19")
    (dedukti-mode "0.1"))
  :url "https://github.com/rafoo/flycheck-dedukti"
  :commit "44ef6755331c67bcf6a8585ababcee4b85dff650"
  :revdesc "44ef6755331c")
