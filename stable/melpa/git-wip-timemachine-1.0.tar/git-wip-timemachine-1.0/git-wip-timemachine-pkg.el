;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-wip-timemachine" "1.0"
  "Walk through git-wip revisions of a file."
  '((s "1.9.0"))
  :url "https://github.com/itsjeyd/git-wip-timemachine"
  :commit "7da7f2acec0b1d1252d7474b13190ae88e5b205d"
  :revdesc "7da7f2acec0b"
  :keywords '("git")
  :authors '(("Tim Krones" . "t.krones@gmx.net"))
  :maintainers '(("Tim Krones" . "t.krones@gmx.net")))
