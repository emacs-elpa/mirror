;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "md-readme" "0.0.0.20191112.26"
  "Markdown-formatted READMEs for your ELisp."
  ()
  :url "https://github.com/thomas11/md-readme/tree/master"
  :commit "ca99f44de11fab18d1f50d4b1722f2ceee3c814d"
  :revdesc "ca99f44de11f"
  :keywords '("lisp" "help" "readme" "markdown" "header" "documentation" "github")
  :authors '(("Thomas Kappler" . "tkappler@gmail.com"))
  :maintainers '(("Thomas Kappler" . "tkappler@gmail.com")))
