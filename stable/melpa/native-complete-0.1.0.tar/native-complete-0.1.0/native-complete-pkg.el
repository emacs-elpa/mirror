;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "native-complete" "0.1.0"
  "Shell completion using native complete mechanisms."
  '((emacs "25"))
  :url "github.com/CeleritasCelery/native-complete"
  :commit "6409b4c8c522f3da72acb98c9e20b8336a1246dc"
  :revdesc "6409b4c8c522"
  :authors '(("Troy Hinckley" . "troy.hinckley@gmail.com"))
  :maintainers '(("Troy Hinckley" . "troy.hinckley@gmail.com")))
