;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons-xref" "0.0.1"
  "Add nerd-icons to xref buffers."
  '((emacs      "30.1")
    (nerd-icons "0.0.1")
    (xref       "1.0.4"))
  :url "https://github.com/hron/nerd-icons-xref"
  :commit "5814a0c50c59b44721ecb7a5e2ecb4a153995463"
  :revdesc "5814a0c50c59"
  :keywords '("tools" "xref" "icons")
  :authors '(("Aleksei Gusev" . "aleksei.gusev@gmail.com"))
  :maintainers '(("Aleksei Gusev" . "aleksei.gusev@gmail.com")))
