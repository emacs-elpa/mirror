;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-gtags" "1.5.7"
  "GNU GLOBAL helm interface."
  '((emacs "24.4")
    (helm  "2.0"))
  :url "https://github.com/syohex/emacs-helm-gtags"
  :commit "a15fe1dd272d252ad933d8129db1dce02fd41adb"
  :revdesc "a15fe1dd272d"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
