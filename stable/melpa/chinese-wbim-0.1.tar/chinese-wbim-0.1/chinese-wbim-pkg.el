;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chinese-wbim" "0.1"
  "[No description available]."
  ()
  :url "https://github.com/andyque/chinese-wbim"
  :commit "d313a83b6d7323314143cc8228cc7c3460cac638"
  :revdesc "d313a83b6d73"
  :keywords '("wubi" "input" "method.")
  :authors '(("Guanghui Qu" . "guanghui8827@gmail.com"))
  :maintainers '(("Guanghui Qu" . "guanghui8827@gmail.com")))
