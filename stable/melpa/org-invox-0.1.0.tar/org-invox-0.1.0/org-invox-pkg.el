;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-invox" "0.1.0"
  "Invoice management for contractors using Org mode."
  '((emacs "27.1")
    (org   "9.0"))
  :url "https://github.com/manu-r-n/org-invox"
  :commit "2276fbd73ae5f4159a42ff261810634d3767a3c9"
  :revdesc "2276fbd73ae5"
  :keywords '("org" "invoice" "billing" "contractor"))
