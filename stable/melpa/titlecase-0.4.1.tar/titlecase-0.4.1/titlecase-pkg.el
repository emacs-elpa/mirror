;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "titlecase" "0.4.1"
  "Title-case phrases."
  '((emacs "25.1"))
  :url "https://github.com/duckwork/titlecase.el"
  :commit "dafaa6ca09fdf1ae8413159cae2b5d74e9713440"
  :revdesc "dafaa6ca09fd"
  :authors '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainers '(("Case Duckworth" . "acdw@acdw.net")))
