;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-runner" "0.8.0"
  "Opinionated Ert testing workflow."
  '((s         "1.6.1")
    (dash      "1.8.0")
    (f         "0.10.0")
    (commander "0.2.0")
    (ansi      "0.1.0")
    (shut-up   "0.1.0"))
  :url "https://github.com/rejeep/ert-runner.el"
  :commit "1829f05c46b0baaae160d900f89c8881f4fcdbcc"
  :revdesc "1829f05c46b0"
  :keywords '("test")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
