;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "discover-clj-refactor" "0.1"
  "Adds discover context menu for clj-refactor."
  '((clj-refactor "20150318.225")
    (discover     "20140103.1339"))
  :url "https://github.com/maio/discover-clj-refactor.el"
  :commit "66821853ff23e682d0a3421fba6f3e39eb8b2ab8"
  :revdesc "66821853ff23"
  :keywords '("clj-refactor" "discover" "convenience")
  :authors '(("Marian Schubert" . "marian.schubert@gmail.com"))
  :maintainers '(("Marian Schubert" . "marian.schubert@gmail.com")))
