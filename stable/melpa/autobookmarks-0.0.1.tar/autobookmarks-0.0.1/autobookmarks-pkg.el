;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autobookmarks" "0.0.1"
  "Save recently visited files and buffers."
  '((dash "2.10.0"))
  :url "https://github.com/Fuco1/autobookmarks"
  :commit "59e41884d83809cc3c58fd15ea15abc9373efd96"
  :revdesc "59e41884d838"
  :keywords '("files")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
