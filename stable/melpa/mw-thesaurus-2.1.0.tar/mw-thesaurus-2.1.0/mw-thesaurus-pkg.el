;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mw-thesaurus" "2.1.0"
  "Merriam-Webster Thesaurus and Dictionary."
  '((emacs "27.1"))
  :url "https://github.com/agzam/mw-thesaurus.el"
  :commit "4dba02ae862cce9db37d2400636254e812a6d36a"
  :revdesc "2.1.0-0-g4dba02ae862c"
  :keywords '("wp" "matching")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
