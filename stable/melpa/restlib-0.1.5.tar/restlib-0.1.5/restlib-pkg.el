;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restlib" "0.1.5"
  "Utility library for building REST clients."
  '((emacs "30.1"))
  :url "https://github.com/kickingvegas/restlib"
  :commit "b1da37d9296cbf8cab4d447ff5a2b4ce95e3e061"
  :revdesc "b1da37d9296c"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
