;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-terminal-cursor-changer" "0.0.5"
  "Change cursor shape and color in terminal."
  ()
  :url "https://github.com/7696122/evil-terminal-cursor-changer"
  :commit "689ac77a251f62c4f25682508c3fef656da6540c"
  :revdesc "689ac77a251f"
  :keywords '("terminal" "cursor" "evil"))
