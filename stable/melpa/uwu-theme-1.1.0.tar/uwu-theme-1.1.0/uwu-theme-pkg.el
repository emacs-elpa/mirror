;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uwu-theme" "1.1.0"
  "An awesome dark color scheme."
  '((emacs "24.1"))
  :url "https://github.com/kborling/uwu-theme"
  :commit "166ee6a95fc931b28fc089c937a726b6d1a3692b"
  :revdesc "166ee6a95fc9"
  :keywords '("custom themes" "dark" "faces"))
