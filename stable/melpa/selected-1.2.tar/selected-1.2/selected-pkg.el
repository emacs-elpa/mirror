;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected" "1.2"
  "Keymap for when region is active."
  ()
  :url "https://github.com/Kungsgeten/selected.el"
  :commit "1ca6e12f456caa1dc97c3d68597598662eb5de9a"
  :revdesc "1ca6e12f456c"
  :keywords '("convenience"))
