;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gregorio-mode" "1.0"
  "Gregorio Mode for .gabc files."
  ()
  :url "http://chant.fsspx.pl/gregorio-mode/docs/"
  :commit "f6b4418662303c924f572f4c4e1954daf716b2ae"
  :revdesc "f6b441866230"
  :keywords '("gregorio" "chant")
  :authors '(("Fr. John Jenkins" . "jenkins@sspx.ng"))
  :maintainers '(("Fr. John Jenkins" . "jenkins@sspx.ng")))
