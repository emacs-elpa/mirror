;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-multiple-keymap" "0.2"
  "Set keymap to elements, such as timestamp and priority."
  '((org    "8.2.4")
    (emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/myuhe/org-multiple-keymap.el"
  :commit "20eb3be6be9f0abbad9f0d007e40cb00c8109201"
  :revdesc "20eb3be6be9f"
  :keywords '("convenience" "org-mode")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
