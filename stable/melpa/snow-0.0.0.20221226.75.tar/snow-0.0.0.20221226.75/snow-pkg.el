;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snow" "0.0.0.20221226.75"
  "Let it snow in Emacs!."
  '((emacs "26.3"))
  :url "https://github.com/alphapapa/snow.el"
  :commit "be17977677fa29709a726715a1a1cba1bd299f68"
  :revdesc "be17977677fa"
  :keywords '("games")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
