;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-swap-keys" "1.0.0"
  "Intelligently swap keys on text input with evil."
  '((emacs "24"))
  :url "https://github.com/wbolster/evil-swap-keys"
  :commit "56bc201e265a6bd482a7c41a7c81d2238341ef3a"
  :revdesc "1.0.0-0-g56bc201e265a"
  :keywords '("evil" "key" "swap" "numbers" "symbols")
  :authors '(("Wouter Bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("Wouter Bolsterlee" . "wouter@bolsterl.ee")))
