;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fcitx" "0.2.3"
  "Make fcitx better in Emacs."
  ()
  :url "https://github.com/cute-jumper/fcitx.el"
  :commit "6d552ab44234ed78ce9a50f2412f56197266bc9f"
  :revdesc "6d552ab44234"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
