;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpstan" "0.9.0"
  "Interface to PHPStan."
  '((emacs       "25.1")
    (compat      "30")
    (php-mode    "1.22.3")
    (php-runtime "0.2"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "206573c8de58654384823765dcca636c9e35e909"
  :revdesc "206573c8de58"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
