;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sweet-theme" "4"
  "Sweet-looking theme."
  '((emacs "24.1"))
  :url "https://github.com/2bruh4me/sweet-theme"
  :commit "d881dc4d52c2a84cbc66ccbb1f9444b6a0980f9c"
  :revdesc "d881dc4d52c2"
  :keywords '("faces"))
