;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cern-root-mode" "0.1.5"
  "Major-mode for running C++ code with ROOT."
  '((emacs "26.1"))
  :url "https://github.com/jaypmorgan/cern-root-mode"
  :commit "2c9c6ea100d9be31733f2f2c4ea8bcda85600254"
  :revdesc "2c9c6ea100d9"
  :keywords '("languages" "tools")
  :authors '(("Jay Morgan" . "jay@morganwastaken.com"))
  :maintainers '(("Jay Morgan" . "jay@morganwastaken.com")))
