;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wilt" "0.1"
  "[No description available]."
  '((dash "X.Y.Z")
    (s    "X.Y.Z"))
  :url "https://github.com/sixty-north/emacs-wilt"
  :commit "28a630fdd0f01cf3711e55c94e1d5119435be5f7"
  :revdesc "28a630fdd0f0"
  :authors '(("Austin Bingham" . "austin@sixty-north.com"))
  :maintainers '(("Austin Bingham" . "austin@sixty-north.com")))
