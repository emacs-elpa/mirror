;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frame-mode" "0.0.0"
  "Frames mode."
  '((s      "1.9.0")
    (emacs  "24.4")
    (cl-lib "0.5")
    (dash   "2.12.0"))
  :url "https://github.com/IvanMalison/frame-mode"
  :commit "a5cab8f798671e132ce8a4ca6e9b549f683ee980"
  :revdesc "a5cab8f79867"
  :keywords '("frames")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
