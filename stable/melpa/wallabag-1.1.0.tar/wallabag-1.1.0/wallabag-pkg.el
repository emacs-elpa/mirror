;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wallabag" "1.1.0"
  "Emacs wallabag client."
  '((emacs   "25.1")
    (request "0.3.3")
    (emacsql "3.0.0"))
  :url "https://github.com/chenyanming/wallabag.el"
  :commit "fea68d7185542d4491cdbb3e7a4b821936303e52"
  :revdesc "fea68d718554"
  :keywords '("tools")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
