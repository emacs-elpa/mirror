;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-elvish" "0.0.1"
  "Org-babel functions for Elvish shell."
  ()
  :url "https://github.com/zzamboni/ob-elvish"
  :commit "fec60f0034aa29ae7de9819f45be9db4a64b6023"
  :revdesc "fec60f0034aa"
  :keywords '("literate programming" "org-mode" "elvish" "shell")
  :authors '(("Diego Zamboni" . "diego@zzamboni.org"))
  :maintainers '(("Diego Zamboni" . "diego@zzamboni.org")))
