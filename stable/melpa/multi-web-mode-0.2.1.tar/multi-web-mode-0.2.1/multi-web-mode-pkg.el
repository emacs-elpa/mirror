;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multi-web-mode" "0.2.1"
  "Multiple major mode support for web editing."
  ()
  :url "https://github.com/fgallina/multi-web-mode"
  :commit "0517b9e2b3052533ac0cb71eba7073ed309fce06"
  :revdesc "0517b9e2b305"
  :keywords '("convenience" "languages" "wp")
  :authors '(("Fabián Ezequiel Gallina" . "fabian@gnu.org.ar"))
  :maintainers '(("Fabián Ezequiel Gallina" . "fabian@gnu.org.ar")))
