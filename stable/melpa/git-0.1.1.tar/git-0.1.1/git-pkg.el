;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git" "0.1.1"
  "An Elisp API for programmatically using Git."
  '((s    "1.7.0")
    (dash "2.2.0")
    (f    "0.10.0"))
  :url "https://github.com/rejeep/git.el"
  :commit "8b7f1477ef367b5b7de452589dd9a8ab30150d0a"
  :revdesc "8b7f1477ef36"
  :keywords '("git")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
