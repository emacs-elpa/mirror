;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tab-bar-echo-area" "0.2"
  "Display tab names of the tab bar in the echo area."
  '((emacs "27.1"))
  :url "https://github.com/fritzgrabo/tab-bar-echo-area"
  :commit "d2ff6b1acb553bf1546e730640397b9e33ca5279"
  :revdesc "d2ff6b1acb55"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "me@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "me@fritzgrabo.com")))
