;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fxrd-mode" "1.0"
  "Major mode for editing fixed field width files."
  '((s "1.2"))
  :url "https://github.com/msherry/fxrd-mode"
  :commit "795b969346982b75e24b5c8619b46197982fbb4d"
  :revdesc "1.0-0-g795b96934698"
  :keywords '("convenience")
  :authors '(("Marc Sherry" . "(msherry@gmail.com)"))
  :maintainers '(("Marc Sherry" . "(msherry@gmail.com)")))
