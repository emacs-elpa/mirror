;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eink-theme" "1.0.0"
  "E Ink color theme."
  ()
  :url "https://github.com/maio/eink-emacs"
  :commit "93d25c097b105594472c4f99d693f439b4b709f0"
  :revdesc "93d25c097b10"
  :authors '(("Marian Schubert" . "marian.schubert@gmail.com"))
  :maintainers '(("Marian Schubert" . "marian.schubert@gmail.com")))
