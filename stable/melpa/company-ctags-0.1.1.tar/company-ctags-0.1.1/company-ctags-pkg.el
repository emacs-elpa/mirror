;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ctags" "0.1.1"
  "Fastest company-mode completion backend for ctags."
  '((emacs   "27.1")
    (company "0.9.0"))
  :url "https://github.com/redguardtoo/company-ctags"
  :commit "2e079a634afa5687bdb004e3883ac0671a222401"
  :revdesc "2e079a634afa"
  :keywords '("convenience")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
