;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "3.5"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "20a16a277764436e003f1d84cb9f0352263f3bad"
  :revdesc "20a16a277764"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
