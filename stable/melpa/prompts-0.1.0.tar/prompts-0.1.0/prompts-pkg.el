;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prompts" "0.1.0"
  "Utilities for working with text prompts."
  '((dash "2.13.0"))
  :url "https://github.com/guiltydolphin/prompt"
  :commit "9b2c1719dde32353d54f309d91bf5e374cb177e5"
  :revdesc "9b2c1719dde3"
  :keywords '("input" "minibuffer")
  :authors '(("Ben Moon" . "guiltydolphin@gmail.com"))
  :maintainers '(("Ben Moon" . "guiltydolphin@gmail.com")))
