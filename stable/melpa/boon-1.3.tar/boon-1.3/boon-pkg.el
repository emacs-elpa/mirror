;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boon" "1.3"
  "An Ergonomic Command Mode."
  ()
  :url "https://github.com/jyp/boon"
  :commit "ded55a290065e39856266e74fb6eb92795c0c214"
  :revdesc "ded55a290065")
