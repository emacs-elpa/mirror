;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boon" "1.3"
  "Ergonomic Command Mode for Emacs."
  '((emacs            "26.1")
    (dash             "2.12.0")
    (expand-region    "0.10.0")
    (multiple-cursors "1.3.0"))
  :url "https://github.com/jyp/boon"
  :commit "ded55a290065e39856266e74fb6eb92795c0c214"
  :revdesc "ded55a290065")
