;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "which-key-posframe" "0.2.0"
  "Using posframe to show which-key."
  '((emacs     "26.0")
    (posframe  "0.4.3")
    (which-key "3.3.2"))
  :url "https://github.com/yanghaoxie/which-key-posframe"
  :commit "75e73e187da78d823a5dc01c21e09e808e4fb938"
  :revdesc "v0.2.0-0-g75e73e187da7"
  :keywords '("convenience" "bindings" "tooltip")
  :maintainers '(("Yanghao Xie" . "yhaoxie@gmail.com")))
