;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-context" "0.1"
  "Contextual capture and agenda commands for Org-mode."
  ()
  :url "https://github.com/thisirs/org-context"
  :commit "29a955b19463053a83fd1ce038de28db20dd4f93"
  :revdesc "29a955b19463"
  :keywords '("org" "capture" "agenda" "convenience")
  :authors '(("Sylvain Rousseau" . "thisirsatgmaildotcom"))
  :maintainers '(("Sylvain Rousseau" . "thisirsatgmaildotcom")))
