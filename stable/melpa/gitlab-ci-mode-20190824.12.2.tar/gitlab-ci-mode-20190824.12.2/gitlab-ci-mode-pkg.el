;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitlab-ci-mode" "20190824.12.2"
  "Mode for editing GitLab CI files."
  '((emacs     "25")
    (yaml-mode "0.0.12"))
  :url "https://gitlab.com/joewreschnig/gitlab-ci-mode/"
  :commit "2651e831aed84ee2512245952fac94901b086549"
  :revdesc "2651e831aed8"
  :keywords '("tools" "vc"))
