;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "closure-lint-mode" "0.1"
  "Minor mode for the Closure Linter."
  ()
  :url "https://github.com/r0man/closure-lint-mode"
  :commit "a1ac2431670c2a3497aecae29e2a8cf8d622ca6d"
  :revdesc "a1ac2431670c"
  :keywords '("tools" "closure" "javascript" "lint" "flymake")
  :authors '(("Roman Scherer" . "roman@burningswell.com"))
  :maintainers '(("Roman Scherer" . "roman@burningswell.com")))
