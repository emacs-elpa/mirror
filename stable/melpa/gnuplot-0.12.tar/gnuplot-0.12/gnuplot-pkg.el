;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "0.12"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs  "28.1")
    (compat "31"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "2da2ef68d4861e2e5a5b1a81340b8d92b276a3a5"
  :revdesc "0.12-0-g2da2ef68d486"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
