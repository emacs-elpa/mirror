;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "numpydoc" "0.9"
  "NumPy style docstring insertion."
  '((emacs "25.1")
    (s     "1.12.0")
    (dash  "2.18.0"))
  :url "https://github.com/douglasdavis/numpydoc.el"
  :commit "5cb26db4f6b63a588ad7b8d2ec22ebf0f56f1076"
  :revdesc "0.9-0-g5cb26db4f6b6"
  :keywords '("convenience")
  :authors '(("Doug Davis" . "ddavis@ddavis.io"))
  :maintainers '(("Doug Davis" . "ddavis@ddavis.io")))
