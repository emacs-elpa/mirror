;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.0.0"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "67c508c0f2dd6773a590df47c355edb3911f0bcb"
  :revdesc "v1.0.0-0-g67c508c0f2dd"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
