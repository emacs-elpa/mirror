;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "create-link" "1.0"
  "Formatted link generator in browser."
  '((emacs   "25.1")
    (request "0.3.2")
    (w3m     "1.4.632"))
  :url "https://github.com/kijimaD/create-link"
  :commit "fbc4e8eeec845f7d1610c52b81c0c7a4e961b991"
  :revdesc "fbc4e8eeec84"
  :keywords '("link" "format" "browser" "convenience")
  :authors '(("Kijima Daigo" . "norimaking777@gmail.com"))
  :maintainers '(("Kijima Daigo" . "norimaking777@gmail.com")))
