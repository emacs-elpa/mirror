;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "australia-holidays" "1.0.0"
  "Australian holidays for Emacs calendar."
  ()
  :url "https://github.com/jmibanez/australia-holidays.el"
  :commit "297e7ecffc69c40e92d642fc47932bb491358c27"
  :revdesc "297e7ecffc69"
  :keywords '("calendar")
  :authors '(("JM Ibañez" . "jm@jmibanez.com"))
  :maintainers '(("JM Ibañez" . "jm@jmibanez.com")))
