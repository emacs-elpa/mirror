;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-multi" "0.2.3"
  "Prettified Notmuch UI For Multiple Accounts."
  '((emacs   "29")
    (notmuch "0.38.3"))
  :url "https://github.com/pivaldi/notmuch-multi"
  :commit "baf954b1d510b0e298823ac9c4b1174d953a24c0"
  :revdesc "baf954b1d510"
  :keywords '("mail" "notmuch")
  :authors '(("Philippe IVALDI" . "emacs@ivaldi.me"))
  :maintainers '(("Philippe IVALDI" . "emacs@ivaldi.me")))
