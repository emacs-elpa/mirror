;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monky" "0.1"
  "Control Hg from Emacs."
  ()
  :url "https://github.com/ananthakumaran/monky"
  :commit "099f1af9d3f6f6143f5e98a9b844f965a011a120"
  :revdesc "099f1af9d3f6"
  :keywords '("tools")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
