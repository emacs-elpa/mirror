;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptai" "1.0.5"
  "Integrate with the OpenAI API."
  '((emacs "24.1"))
  :url "https://github.com/antonhibl/gptai"
  :commit "e2fb58785e1e8ae2956d0786d77821a5c2d2b326"
  :revdesc "e2fb58785e1e"
  :keywords '("comm" "convenience")
  :authors '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainers '(("Anton Hibl" . "antonhibl11@gmail.com")))
