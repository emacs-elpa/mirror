;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-caribbean-theme" "1.5"
  "Color theme with cyan as a dominant color."
  '((emacs "27.1"))
  :url "https://gitlab.com/aimebertrand/timu-caribbean-theme"
  :commit "af60151fe35bd1c780b7c4a37032699989ee6162"
  :revdesc "af60151fe35b"
  :keywords '("faces" "themes")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
