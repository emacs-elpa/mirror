;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "editorconfig-charset-extras" "0.1"
  "Extra EditorConfig Charset Support."
  ()
  :url "https://github.com/10sr/editorconfig-charset-extras-el"
  :commit "c1087c77a633f528df6f7fd94a6f008cf50f7a08"
  :revdesc "c1087c77a633"
  :keywords '("utility")
  :authors '(("10sr" . ""))
  :maintainers '(("10sr" . "")))
