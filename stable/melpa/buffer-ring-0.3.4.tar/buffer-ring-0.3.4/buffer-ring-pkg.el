;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-ring" "0.3.4"
  "Rings and tori for buffer navigation."
  '((emacs    "25.1")
    (dynaring "0.3")
    (s        "1.12.0")
    (ht       "2.0"))
  :url "https://github.com/countvajhula/buffer-ring"
  :commit "177d67238c4d126a0270585e21c0f03ae750ca2a"
  :revdesc "0.3.4-0-g177d67238c4d"
  :authors '(("Mike Mattie" . "codermattie@gmail.com")
             ("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
