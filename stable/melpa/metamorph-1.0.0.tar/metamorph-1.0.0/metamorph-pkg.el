;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metamorph" "1.0.0"
  "Transform your buffers with lisp."
  '((emacs "26.1"))
  :url "https://github.com/AdamNiederer/metamorph"
  :commit "3633e32a9601c491df32d6c2212dbe63dc6484f4"
  :revdesc "3633e32a9601"
  :keywords '("metaprogramming" "wp")
  :authors '(("Adam Niederer" . "adam.niederer@gmail.com"))
  :maintainers '(("Adam Niederer" . "adam.niederer@gmail.com")))
