;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xhair" "1.0"
  "Highlight the current line and column."
  '((emacs "24.3")
    (vline "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-xhair"
  :commit "9ae87bc197b0637baf509cbbbeb2c412cd3d0913"
  :revdesc "9ae87bc197b0"
  :keywords '("convenience" "faces" "maint"))
