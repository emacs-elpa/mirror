;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-atuin" "0.2.0"
  "Intergrate eshell with atuin, a shell history tool."
  '((emacs "27.1"))
  :url "https://github.com/SqrtMinusOne/eshell-atuin.el"
  :commit "1e7ccba75c432a7c3f7ee36d51de06bd8569284d"
  :revdesc "1e7ccba75c43"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
