;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-aws-iam-role" "1.6.7"
  "Browse, modify, and simulate AWS IAM Roles in Org Babel."
  '((emacs   "29.1")
    (async   "1.9")
    (promise "1.1"))
  :url "https://github.com/will-abb/org-aws-iam-role"
  :commit "49434f06ea8fe1ae3b1ea28555f435bafb6fc5f9"
  :revdesc "v1.6.7-0-g49434f06ea8f"
  :keywords '("aws" "iam" "org" "babel" "tools")
  :authors '(("William Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("William Bosch-Bello" . "williamsbosch@gmail.com")))
