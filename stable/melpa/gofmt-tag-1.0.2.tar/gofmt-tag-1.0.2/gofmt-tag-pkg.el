;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gofmt-tag" "1.0.2"
  "Format and align go struct tags."
  '((emacs "27"))
  :url "https://github.com/m1ndo/gofmt-tag"
  :commit "b7cc315ac45342fc9c17dde779cc9c37aa309841"
  :revdesc "b7cc315ac453"
  :keywords '("tools" "wp" "matching")
  :authors '(("ybenel" . "http://github/m1ndo"))
  :maintainers '(("ybenel" . "root@ybenel.cf")))
