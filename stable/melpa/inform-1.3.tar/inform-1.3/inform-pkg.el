;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inform" "1.3"
  "Link symbols in Info buffers to their help documentation."
  '((emacs "25.1"))
  :url "https://github.com/dieter-wilhelm/inform"
  :commit "5e096549632b2691fe1f975394d07a31cf603fc6"
  :revdesc "1.3-0-g5e096549632b"
  :keywords '("help" "docs" "convenience")
  :authors '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de")))
