;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nael-lsp" "0.8.3"
  "Nael and lsp-mode."
  '((emacs    "29.1")
    (lsp-mode "9")
    (nael     "0.8.3"))
  :url "https://codeberg.org/mekeor/nael"
  :commit "c1d349746731bbff6bf1887c51eb7a1f3bea5c4c"
  :revdesc "c1d349746731"
  :keywords '("languages")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
