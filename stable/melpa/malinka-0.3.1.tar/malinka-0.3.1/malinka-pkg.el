;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "malinka" "0.3.1"
  "A C/C++ project configuration package for Emacs."
  '((s          "1.9.0")
    (dash       "2.4.0")
    (f          "0.11.0")
    (cl-lib     "0.3")
    (rtags      "0.0")
    (projectile "0.11.0"))
  :url "https://github.com/LefterisJP/malinka"
  :commit "81cf7dd81fbf124ceda31ee963cce8c3616f28f1"
  :revdesc "v0.3.1-0-g81cf7dd81fbf"
  :keywords '("c" "c++" "project-management")
  :authors '(("Lefteris Karapetsas" . "lefteris@refu.co"))
  :maintainers '(("Lefteris Karapetsas" . "lefteris@refu.co")))
