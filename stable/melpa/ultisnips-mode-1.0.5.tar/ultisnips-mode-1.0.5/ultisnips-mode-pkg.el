;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "1.0.5"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "ddf10faffbbb0a342cf258716be47c9accb4b27f"
  :revdesc "1.0.5-0-gddf10faffbbb"
  :keywords '("languages" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
