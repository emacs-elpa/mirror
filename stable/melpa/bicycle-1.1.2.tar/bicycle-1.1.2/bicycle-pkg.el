;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bicycle" "1.1.2"
  "Cycle outline and code visibility."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/bicycle"
  :commit "9da65dcb0e8ea6a9fe2b02d3be3cd4f2f4e29977"
  :revdesc "v1.1.2-0-g9da65dcb0e8e"
  :keywords '("outlines")
  :authors '(("Jonas Bernoulli" . "emacs.bicycle@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.bicycle@jonas.bernoulli.dev")))
