;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oauth" "1.11"
  "OAuth 1.0 client library."
  '((emacs "25.1"))
  :url "https://github.com/fvdbeek/emacs-oauth"
  :commit "737f4058b3239261cf7c95043034b95f1ce3b282"
  :revdesc "737f4058b323"
  :keywords '("comm")
  :authors '(("Peter Sanford" . "peter@petersdanceparty.com")
             ("Neil Roberts" . "bpeeluk@yahoo.co.uk"))
  :maintainers '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com")))
