;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jack-ts-mode" "1.0.0"
  "Major mode for jack buffers using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/jack-ts-mode"
  :commit "f48ca8edd4c9d1e204c5f60566640ded64b9e327"
  :revdesc "f48ca8edd4c9"
  :keywords '("tree-sitter" "languages" "jack" "nand2tetris")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
