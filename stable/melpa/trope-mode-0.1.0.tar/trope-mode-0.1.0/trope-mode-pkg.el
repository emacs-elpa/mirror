;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trope-mode" "0.1.0"
  "Major mode to edit TV Tropes format \".trp\" files."
  ()
  :url "https://github.com/TriAttack238/trope-mode"
  :commit "f0f276d2a69bc97faee7d1f53d34a50d8ca51c61"
  :revdesc "f0f276d2a69b"
  :keywords '("tv tropes" "trope")
  :authors '(("Sean Vo" . "triattack238@gmail.com"))
  :maintainers '(("Sean Vo" . "triattack238@gmail.com")))
