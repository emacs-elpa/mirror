;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mustang-theme" "0.3"
  "Port of vim's mustang theme."
  ()
  :url "https://github.com/mswift42/mustang-theme"
  :commit "3b257eecd5223187ed7bd1474e7c53aabe49e8df"
  :revdesc "3b257eecd522")
