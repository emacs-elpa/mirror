;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbcode-mode" "2.3.0"
  "Major mode for phpBB posts (BBCode markup)."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/lassik/emacs-bbcode-mode"
  :commit "e16619c80ea21154b4a4ccc2e13d0077e97c9caf"
  :revdesc "e16619c80ea2"
  :keywords '("bbcode" "languages")
  :authors '(("Eric James Michael Ritz" . "lobbyjones@gmail.com"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
