;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-rootfile" "0.0.1"
  "Project backend by root file."
  '((emacs "28.1"))
  :url "https://github.com/buzztaiki/project-rootfile.el"
  :commit "14487ab3c0c33ec9021b383b6f32c7d26af08367"
  :revdesc "14487ab3c0c3"
  :authors '(("Taiki Sugawara" . "buzz.taiki@gmail.com"))
  :maintainers '(("Taiki Sugawara" . "buzz.taiki@gmail.com")))
