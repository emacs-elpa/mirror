;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "find-things-fast" "1.0"
  "Find things fast, leveraging the power of git."
  ()
  :url "https://github.com/eglaysher/find-things-fast"
  :commit "8f348d8b6a5026d0bf1c51f3c277e7cc0d07caa7"
  :revdesc "8f348d8b6a50"
  :keywords '("project" "convenience"))
