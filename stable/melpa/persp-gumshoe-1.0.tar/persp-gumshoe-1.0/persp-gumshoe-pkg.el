;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persp-gumshoe" "1.0"
  "Perspective support for gumshoe."
  '((emacs       "27.1")
    (perspective "2.0")
    (gumshoe     "4.0"))
  :url "https://github.com/Overdr0ne/gumshoe"
  :commit "2316eb5e9114615eea69c9fa32eecb2598b62027"
  :revdesc "2316eb5e9114"
  :keywords '("tools"))
