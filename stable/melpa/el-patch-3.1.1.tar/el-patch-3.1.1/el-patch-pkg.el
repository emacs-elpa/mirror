;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-patch" "3.1.1"
  "Future-proof your Elisp."
  '((emacs "26"))
  :url "https://github.com/radian-software/el-patch"
  :commit "5adb7097d0ff3d9e004a8bb07c0b25f7ee20ba8a"
  :revdesc "5adb7097d0ff"
  :keywords '("extensions")
  :authors '(("Radian LLC" . "contact+el-patch@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+el-patch@radian.codes")))
