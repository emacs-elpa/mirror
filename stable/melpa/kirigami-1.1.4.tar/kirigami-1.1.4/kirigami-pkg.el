;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.1.4"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "44af2459166f59feff3bd8f4cab57a5275fa17ec"
  :revdesc "1.1.4-0-g44af2459166f"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
