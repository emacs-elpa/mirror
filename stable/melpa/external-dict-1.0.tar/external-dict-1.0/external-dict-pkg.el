;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "external-dict" "1.0"
  "Query external dictionary like goldendict, Bob.app etc."
  '((emacs "25.1"))
  :url "https://repo.or.cz/external-dict.el.git"
  :commit "0399b1c086417030f914bd26fff636dfdd55833a"
  :revdesc "0399b1c08641"
  :keywords '("wp" "processes")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
