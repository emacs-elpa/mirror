;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-dwim" "0.0.0.20170126.27"
  "Context-aware git commands such as branch handling."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/download/git-dwim.el"
  :commit "485c732130686c2f28a026e385366006435394b9"
  :revdesc "485c73213068"
  :keywords '("git" "tools" "convenience")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
