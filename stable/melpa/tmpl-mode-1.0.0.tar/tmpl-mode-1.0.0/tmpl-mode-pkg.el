;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tmpl-mode" "1.0.0"
  "Minor mode for \"tmpl\" template files."
  '((emacs "25.1"))
  :url "https://github.com/Lindydancer/tmpl-mode"
  :commit "ff9883cfa3b63005c64d556a5a5c2f81aa312ea7"
  :revdesc "ff9883cfa3b6"
  :keywords '("languages"))
