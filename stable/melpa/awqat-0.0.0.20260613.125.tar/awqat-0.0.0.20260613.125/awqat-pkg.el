;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awqat" "0.0.0.20260613.125"
  "Islamic prayer times."
  '((emacs "28.1")
    (alert "1.2"))
  :url "https://github.com/zkry/awqat"
  :commit "0ef8501dc31774cbc6b17f8b899609a45c1fe0c7"
  :revdesc "0ef8501dc317"
  :authors '(("Zachary Romero" . "zacromero@posteo.net"))
  :maintainers '(("Zachary Romero" . "zacromero@posteo.net")))
