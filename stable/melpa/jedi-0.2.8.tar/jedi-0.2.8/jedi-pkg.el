;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jedi" "0.2.8"
  "A Python auto-completion for Emacs."
  '((emacs         "24")
    (jedi-core     "0.2.2")
    (auto-complete "1.4"))
  :url "https://github.com/tkf/emacs-jedi"
  :commit "9d5f29116c4d42cae561a9d69e6fba2b61e2cf43"
  :revdesc "v0.2.8-0-g9d5f29116c4d"
  :authors '(("Takafumi Arakaki" . "aka.tkfatgmail.com"))
  :maintainers '(("Takafumi Arakaki" . "aka.tkfatgmail.com")))
