;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ansilove" "2.0.0"
  "Display buffers as PNG images using ansilove."
  '((emacs "26.1"))
  :url "https://gitlab.com/xgqt/emacs-ansilove/"
  :commit "785f0bad0c73069e6c41ca543c29675785b614a8"
  :revdesc "2.0.0-0-g785f0bad0c73"
  :keywords '("multimedia")
  :authors '(("Maciej Barć" . "xgqt@riseup.net"))
  :maintainers '(("Maciej Barć" . "xgqt@riseup.net")))
