;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "m-buffer" "0.15"
  "List-Oriented, Functional Buffer Manipulation."
  '((seq "2.14"))
  :url "https://github.com/phillord/m-buffer-el"
  :commit "6eb1d2535a82707a83733173bc400a0d8e520c80"
  :revdesc "6eb1d2535a82"
  :authors '(("Phillip Lord" . "phillip.lord@russet.org.uk"))
  :maintainers '(("Phillip Lord" . "phillip.lord@russet.rg.uk")))
