;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebf" "1.0.0"
  "Brainfuck language transpiler to Emacs Lisp."
  '((dash            "2.11.0")
    (dash-functional "1.2.0")
    (cl-lib          "0.5"))
  :url "https://github.com/rexim/ebf"
  :commit "d0bd4fe1abbe327e7d9228eff09927fec57e8378"
  :revdesc "d0bd4fe1abbe"
  :authors '(("Alexey Kutepov" . "reximkut@gmail.com"))
  :maintainers '(("Alexey Kutepov" . "reximkut@gmail.com")))
