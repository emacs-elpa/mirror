;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-avfs" "0.0.1"
  "AVFS support for dired."
  '((dash "2.5.0"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "48f6bb7abe154554cb40f6b5931c189afab41dcc"
  :revdesc "48f6bb7abe15"
  :keywords '("lisp")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
