;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuel" "0.0.0.20261004.394"
  "Factor's Ultimate Emacs Library."
  '((cl-lib "0.2")
    (emacs  "24.2"))
  :url "https://github.com/factor/fuel"
  :commit "07cd5290f6ad9610928a89c8aeb89c103efcf27b"
  :revdesc "07cd5290f6ad"
  :keywords '("languages" "fuel" "factor")
  :authors '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org")))
