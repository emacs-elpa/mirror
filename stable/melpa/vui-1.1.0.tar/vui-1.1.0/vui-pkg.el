;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.1.0"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "d7f56acd76bf1e94b583060d729892bf21633aec"
  :revdesc "d7f56acd76bf"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
