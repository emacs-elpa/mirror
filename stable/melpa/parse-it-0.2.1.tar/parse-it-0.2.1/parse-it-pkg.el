;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parse-it" "0.2.1"
  "Basic Parser in Emacs Lisp."
  '((emacs "25.1")
    (s     "1.12.0"))
  :url "https://github.com/jcs-elpa/parse-it"
  :commit "f910af3b1d98b88a0f41794bbe7fd57411e9b909"
  :revdesc "f910af3b1d98"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
