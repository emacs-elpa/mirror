;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vdm-mode" "0.0.4"
  "Major mode for the Vienna Development Method."
  '((emacs "25"))
  :url "https://github.com/peterwvj/vdm-mode"
  :commit "e131edb0d35de28bd47d6128dd70d9a6fc46e0fa"
  :revdesc "e131edb0d35d"
  :keywords '("languages")
  :authors '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com"))
  :maintainers '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com")))
