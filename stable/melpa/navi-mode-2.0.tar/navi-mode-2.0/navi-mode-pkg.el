;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "navi-mode" "2.0"
  "Major-mode for easy buffer-navigation."
  ()
  :url "https://github.com/tj64/navi"
  :commit "5c979b3b3873b0e67751a1321a9e271d066f2022"
  :revdesc "5c979b3b3873"
  :authors '(("Thorsten Jolitz" . "tjolitzATgmailDOTcom"))
  :maintainers '(("Thorsten Jolitz" . "tjolitzATgmailDOTcom")))
