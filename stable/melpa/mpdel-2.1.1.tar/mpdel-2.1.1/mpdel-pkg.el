;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpdel" "2.1.1"
  "Play and control your MPD music."
  '((emacs    "25.1")
    (libmpdel "1.2.0")
    (navigel  "0.7.0"))
  :url "https://github.com/mpdel/mpdel"
  :commit "006ccab29492cda567112be76e84e40e51d1f70b"
  :revdesc "v2.1.1-0-g006ccab29492"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
