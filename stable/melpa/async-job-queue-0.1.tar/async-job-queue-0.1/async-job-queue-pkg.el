;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async-job-queue" "0.1"
  "[No description available]."
  '((async "0"))
  :url "https://github.com/owinebar/emacs-async-job-queue"
  :commit "0805e02efb91377868d554c3d48801285b7998fe"
  :revdesc "0805e02efb91"
  :keywords '("extensions" "lisp"))
