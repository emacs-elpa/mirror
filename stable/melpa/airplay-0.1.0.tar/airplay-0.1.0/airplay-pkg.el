;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "airplay" "0.1.0"
  "Airplay bindings to Emacs."
  '((request      "20130110.2144")
    (simple-httpd "1.4.1")
    (deferred     "0.3.1"))
  :url "https://github.com/gongo/airplay-el"
  :commit "8b3ff56f9f9d5c2c5791b7e1dd79eb2b1be83bc3"
  :revdesc "8b3ff56f9f9d"
  :keywords '("appletv" "airplay")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
