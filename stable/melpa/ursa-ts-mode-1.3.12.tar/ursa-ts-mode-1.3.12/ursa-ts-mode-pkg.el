;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ursa-ts-mode" "1.3.12"
  "Major mode for Ursa, using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/ursalang/ursa-ts-mode"
  :commit "b76fb46721839ef210700ee6d00763f5646c30af"
  :revdesc "b76fb4672183"
  :keywords '("ursalang" "languages" "tree-sitter")
  :authors '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainers '(("Reuben Thomas" . "rrt@sc3d.org")))
