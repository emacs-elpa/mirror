;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jbeam-mode" "0.1"
  "Major mode for JBeam files."
  '((emacs "24.3"))
  :url "https://github.com/webdevred/jbeam-mode"
  :commit "fb70808372c95ab1d46037894fd689f93763a53b"
  :revdesc "fb70808372c9"
  :keywords '("languages"))
