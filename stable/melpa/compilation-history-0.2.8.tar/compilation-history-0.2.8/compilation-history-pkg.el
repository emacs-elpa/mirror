;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compilation-history" "0.2.8"
  "Track compilation history in SQLite."
  '((emacs "29.1"))
  :url "https://github.com/djgoku/compilation-history"
  :commit "f7b0d6051531e8f8d11f8c489a08199b4805dfa4"
  :revdesc "f7b0d6051531"
  :keywords '("processes" "tools")
  :authors '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com"))
  :maintainers '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com")))
