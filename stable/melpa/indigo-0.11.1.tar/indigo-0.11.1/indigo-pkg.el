;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indigo" "0.11.1"
  "Emacs interface to the Indigo cheminformatics library."
  '((emacs "25.1"))
  :url "https://github.com/gicrisf/emacs-indigo"
  :commit "f9305632ca14dd27bef538007ff73ec941bbbd31"
  :revdesc "f9305632ca14"
  :keywords '("data" "tools" "extensions")
  :authors '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com"))
  :maintainers '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com")))
