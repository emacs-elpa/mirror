;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zig-ts-mode" "0.3.1"
  "Major mode for Zig code."
  '((emacs "29.1"))
  :url "https://codeberg.org/meow_king/zig-ts-mode"
  :commit "bb1e8287800868ee338e986bda5b5a1f5abf7445"
  :revdesc "bb1e82878008"
  :keywords '("zig" "languages" "tree-sitter")
  :authors '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers '(("meowking" . "mr.meowking@tutamail.com")))
