;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-python-movement" "1.0"
  "Port Neovim's python movement to Evil."
  ()
  :commit "9419ad376040d94f732d021847a7098c0e637e0b"
  :revdesc "9419ad376040"
  :authors '(("Felipe Lema" . "felipelemaenmortemalepuntoorg"))
  :maintainers '(("Felipe Lema" . "felipelemaenmortemalepuntoorg")))
