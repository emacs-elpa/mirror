;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "i-ching" "0.2"
  "The Book of Changes."
  '((emacs   "25.1")
    (request "0.3"))
  :url "https://github.com/zzkt/i-ching"
  :commit "bed68c91a987975a87b691226ae2eae613f2a5d0"
  :revdesc "bed68c91a987"
  :keywords '("games" "divination" "stochastism" "cleromancy" "change")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
