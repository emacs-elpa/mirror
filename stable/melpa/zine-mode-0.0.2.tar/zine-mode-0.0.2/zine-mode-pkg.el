;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zine-mode" "0.0.2"
  "Major mode for zine, the static site generator."
  '((emacs         "29.1")
    (reformatter   "0.6")
    (css-mode      "0")
    (js            "9")
    (markdown-mode "2.8-alpha")
    (ziggy-mode    "0.0.2"))
  :url "https://github.com/dcolazin/zine-mode"
  :commit "c3bfe5770625790202749318041d94787659354c"
  :revdesc "c3bfe5770625"
  :authors '(("2024 Robbie Lyman" . "rb.lymn@gmail.com"))
  :maintainers '(("Davide Colazingari" . "dcolazin@gmail.com")))
