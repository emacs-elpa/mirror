(define-package "lognav-mode" "0.0.8" "Navigate Log Error Messages"
  '((emacs "24.3"))
  :commit "5b2ae4f9941d8584f456cc921b56c7c610a683eb" :authors
  '(("Shawn Ellis" . "shawn.ellis17@gmail.com"))
  :maintainers
  '(("Shawn Ellis" . "shawn.ellis17@gmail.com"))
  :maintainer
  '("Shawn Ellis" . "shawn.ellis17@gmail.com")
  :keywords
  '("log" "error" "lognav-mode" "convenience")
  :url "https://hg.osdn.net/view/lognav-mode/lognav-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
