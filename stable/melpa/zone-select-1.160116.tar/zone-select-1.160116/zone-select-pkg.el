;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zone-select" "1.160116"
  "Select zone programs."
  '((emacs "24.3")
    (dash  "2.8"))
  :url "https://github.com/kawabata/zone-select"
  :commit "bf30da12f1625fe6563448fccf3c506acad10af7"
  :revdesc "bf30da12f162"
  :keywords '("games")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
