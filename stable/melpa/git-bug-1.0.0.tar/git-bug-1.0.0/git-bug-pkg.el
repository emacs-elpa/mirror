;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-bug" "1.0.0"
  "Conviences for git-bug local-first issues."
  '((emacs "29.1"))
  :url "http://www.github.com/WillForan/emacs-git-bug"
  :commit "79465c6bf7f050895999365024e10644bfd7da52"
  :revdesc "79465c6bf7f0"
  :keywords '("tools" "vc" "processes")
  :authors '(("Will Foran" . "willforan+emacs@gmail.com"))
  :maintainers '(("Will Foran" . "willforan+emacs@gmail.com")))
