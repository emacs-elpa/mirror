;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "merlin-iedit" "4.1"
  "Merlin and iedit integration."
  ()
  :url "https://github.com/ocaml/merlin"
  :commit "ab02f60994c81166820791b5f465f467d752b8dc"
  :revdesc "v4.1-0-gab02f60994c8"
  :keywords '("ocaml" "languages")
  :authors '(("Simon Castellan" . "simon.castellaniuwt.fr")
             ("Frédéric Bour" . "frederic.bourlakaban.net")
             ("Thomas Refis" . "thomas.refisgmail.com"))
  :maintainers '(("Simon Castellan" . "simon.castellaniuwt.fr")
                 ("Frédéric Bour" . "frederic.bourlakaban.net")
                 ("Thomas Refis" . "thomas.refisgmail.com")))
