;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claude-code" "0.10.1"
  "Run Claude Code sessions."
  '((emacs         "28.1")
    (projectile    "2.5.0")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (markdown-mode "2.5"))
  :url "https://github.com/yuya373/claude-code-emacs"
  :commit "2e29b77e2930d679f8a3fa3f171fa0cf67a48aca"
  :revdesc "2e29b77e2930"
  :keywords '("tools" "convenience"))
