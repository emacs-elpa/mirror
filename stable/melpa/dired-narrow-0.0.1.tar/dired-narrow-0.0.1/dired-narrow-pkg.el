;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-narrow" "0.0.1"
  "Live-narrowing of search results for dired."
  '((dash              "2.7.0")
    (dired-hacks-utils "0.0.1"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "46f8687d3f6c3180db4082bb3e6af852d7434312"
  :revdesc "46f8687d3f6c"
  :keywords '("files")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
