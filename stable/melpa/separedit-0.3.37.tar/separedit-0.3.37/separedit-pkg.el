;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "separedit" "0.3.37"
  "Edit comment/string/docstring/code block in separate buffer."
  '((emacs         "25.1")
    (dash          "2.18")
    (edit-indirect "0.1.5"))
  :url "https://github.com/twlz0ne/separedit.el"
  :commit "91a41ff8044e7cbeb82159f6c595393606e5e744"
  :revdesc "91a41ff8044e"
  :keywords '("tools" "languages" "docs")
  :authors '(("Gong Qijian" . "gongqijian@gmail.com"))
  :maintainers '(("Gong Qijian" . "gongqijian@gmail.com")))
