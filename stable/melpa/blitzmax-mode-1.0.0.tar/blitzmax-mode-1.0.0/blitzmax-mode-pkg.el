;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blitzmax-mode" "1.0.0"
  "A major mode for editing BlitzMax source code."
  '((emacs "24.1"))
  :url "https://www.sodaware.net/dev/tools/blitzmax-mode/"
  :commit "d772deff2464d48d018bbe43b1e4b3745a4ac886"
  :revdesc "d772deff2464"
  :keywords '("languages" "blitzmax"))
