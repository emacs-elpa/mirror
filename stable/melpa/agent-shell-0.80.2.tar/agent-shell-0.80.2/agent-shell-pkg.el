;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.80.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "9c4e060e84569e9bead8b8cb492e779faf354a70"
  :revdesc "9c4e060e8456")
