;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ruff" "0.1.0"
  "A flymake plugin for python files using ruff."
  '((emacs "26.1"))
  :url "https://github.com/erickgnavar/flymake-ruff"
  :commit "1567685414c81a24303058631d6ee81fb78eee73"
  :revdesc "1567685414c8"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
