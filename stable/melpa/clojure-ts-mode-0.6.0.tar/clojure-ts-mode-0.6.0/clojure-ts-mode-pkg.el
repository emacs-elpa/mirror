;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "0.6.0"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "https://github.com/clojure-emacs/clojure-ts-mode"
  :commit "96fdffcbe9e1b8ebf9ad14e23b06f62cc3422e22"
  :revdesc "96fdffcbe9e1"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :authors '(("Danny Freeman" . "danny@dfreeman.email")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
