;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nclip" "2"
  "Network (HTTP) Clipboard."
  ()
  :url "http://www.github.com/maio/nclip.el"
  :commit "4328a3a5fe8eb8a304903dadc97f6d23bed0fe0f"
  :revdesc "4328a3a5fe8e"
  :keywords '("nclip" "clipboard" "network")
  :authors '(("Marian Schubert" . "marian.schubert@gmail.com"))
  :maintainers '(("Marian Schubert" . "marian.schubert@gmail.com")))
