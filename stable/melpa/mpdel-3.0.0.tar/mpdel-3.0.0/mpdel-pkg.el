;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpdel" "3.0.0"
  "Play and control your MPD music."
  '((emacs    "28.0")
    (libmpdel "1.2.0")
    (navigel  "0.7.0"))
  :url "https://github.com/mpdel/mpdel"
  :commit "fe4e9506c7e3033efb998daaefb519d7edddc73b"
  :revdesc "v3.0.0-0-gfe4e9506c7e3"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
