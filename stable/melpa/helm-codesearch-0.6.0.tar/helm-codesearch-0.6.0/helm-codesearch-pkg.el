;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-codesearch" "0.6.0"
  "Helm interface for codesearch."
  '((emacs  "25.1")
    (s      "1.11.0")
    (dash   "2.12.0")
    (helm   "1.7.7")
    (cl-lib "0.5"))
  :url "https://github.com/youngker/helm-codesearch.el"
  :commit "bd5a7e3ece98f2940cb09be56d3e56da97d4c865"
  :revdesc "bd5a7e3ece98"
  :keywords '("tools")
  :authors '(("Youngjoo Lee" . "youngker@gmail.com"))
  :maintainers '(("Youngjoo Lee" . "youngker@gmail.com")))
