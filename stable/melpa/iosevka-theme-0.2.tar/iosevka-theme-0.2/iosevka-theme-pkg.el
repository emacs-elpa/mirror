;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iosevka-theme" "0.2"
  "Theme using various stylistic sets of Iosevka font."
  '((emacs "28.1"))
  :url "https://codeberg.org/mekeor/iosevka-theme"
  :commit "4b4fecee994b62c4b2b3d7bc34c181937c41eafc"
  :revdesc "4b4fecee994b"
  :keywords '("faces" "theme")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
