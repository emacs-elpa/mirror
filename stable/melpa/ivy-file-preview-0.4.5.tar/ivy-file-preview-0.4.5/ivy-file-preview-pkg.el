;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-file-preview" "0.4.5"
  "Preview the current ivy file selection."
  '((emacs "25.1")
    (ivy   "0.8.0")
    (s     "1.12.0")
    (f     "0.20.0"))
  :url "https://github.com/jcs-elpa/ivy-file-preview"
  :commit "b237ee8e9fd2fd1b52254ef84cd06a0bb6c10a24"
  :revdesc "b237ee8e9fd2"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
