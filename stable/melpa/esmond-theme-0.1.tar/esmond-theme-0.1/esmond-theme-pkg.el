;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esmond-theme" "0.1"
  "Dark theme for emacs."
  ()
  :url "https://github.com/xcatalyst/esmond-theme"
  :commit "93221d165fab1e380995965c8f76547d54f7c15a"
  :revdesc "93221d165fab"
  :authors '(("ağan Korkmaz" . "xcatalystt@gmail.com"))
  :maintainers '(("ağan Korkmaz" . "xcatalystt@gmail.com")))
