;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sqlite-mode-extras" "0.7"
  "Extensions for sqlite-mode."
  ()
  :url "https://github.com/xenodium/sqlite-mode-extras"
  :commit "e0c7162e931c8be2a6ce3f1958ca9525b0716231"
  :revdesc "e0c7162e931c")
