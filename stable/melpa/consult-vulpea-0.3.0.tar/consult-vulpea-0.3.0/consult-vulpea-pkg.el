;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-vulpea" "0.3.0"
  "Use Consult in tandem with Vulpea."
  '((emacs   "28.1")
    (vulpea  "2.0.0")
    (consult "2.2"))
  :url "https://github.com/fabcontigiani/consult-vulpea"
  :commit "ffb093ee9f1de1e68eaee16dfaf41635ad6bc711"
  :revdesc "ffb093ee9f1d"
  :keywords '("convenience" "notes" "vulpea")
  :authors '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com"))
  :maintainers '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com")))
