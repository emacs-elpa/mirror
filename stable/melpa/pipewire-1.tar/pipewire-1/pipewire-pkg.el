;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pipewire" "1"
  "PipeWire user interface."
  '((emacs "25.1"))
  :url "https://git.zamazal.org/pdm/pipewire-0"
  :commit "7ec78e2caf9b0870a5bc1983af005c44ca0ad7fb"
  :revdesc "7ec78e2caf9b"
  :keywords '("multimedia")
  :authors '(("Milan Zamazal" . "pdm@zamazal.org"))
  :maintainers '(("Milan Zamazal" . "pdm@zamazal.org")))
