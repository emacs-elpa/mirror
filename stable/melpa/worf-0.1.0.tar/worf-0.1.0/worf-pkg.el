;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "worf" "0.1.0"
  "A warrior does not press so many keys! (in org-mode)."
  '((swiper   "0.7.0")
    (ace-link "0.1.0")
    (hydra    "0.13.0"))
  :url "https://github.com/abo-abo/worf"
  :commit "f36755447b588b739b2bf6ab0fb5eb5f4d8db3df"
  :revdesc "f36755447b58"
  :keywords '("lisp")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
