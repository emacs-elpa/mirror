;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-spec" "0.2"
  "Ruby's rspec like syntax test frame work."
  ()
  :url "https://github.com/uk-ar/el-spec"
  :commit "52dc72aa71ddfa1dba87ba93703f1328b1496ed3"
  :revdesc "52dc72aa71dd"
  :keywords '("test")
  :authors '(("Yuuki Arisawa" . "yuuki.ari@gmail.com"))
  :maintainers '(("Yuuki Arisawa" . "yuuki.ari@gmail.com")))
