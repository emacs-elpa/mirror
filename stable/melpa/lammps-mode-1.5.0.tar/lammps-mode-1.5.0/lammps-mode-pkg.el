;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lammps-mode" "1.5.0"
  "Basic syntax highlighting for LAMMPS files."
  '((emacs "24.4"))
  :url "https://github.com/lammps/lammps/tree/master/tools/emacs"
  :commit "3795c88ae7c7f51254995129b97588e1ed0492c9"
  :revdesc "3795c88ae7c7"
  :keywords '("languages" "faces")
  :authors '(("Aidan Thompson" . "athompsatsandia.gov"))
  :maintainers '(("Rohit Goswami" . "r95g10atgmail.com")))
