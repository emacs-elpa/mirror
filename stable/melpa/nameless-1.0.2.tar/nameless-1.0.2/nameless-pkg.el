;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nameless" "1.0.2"
  "Hide package namespace in your emacs-lisp code."
  '((emacs "24.4"))
  :url "https://github.com/Malabarba/nameless"
  :commit "ab1a5c589378334eafca105af1a17f73b9065423"
  :revdesc "ab1a5c589378"
  :keywords '("convenience" "lisp")
  :authors '(("Artur Malabarba" . "emacs@endlessparentheses.com"))
  :maintainers '(("Artur Malabarba" . "emacs@endlessparentheses.com")))
