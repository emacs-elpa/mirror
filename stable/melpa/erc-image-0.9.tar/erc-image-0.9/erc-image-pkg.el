;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-image" "0.9"
  "Show received image urls in the ERC buffer."
  '((url-queue "1"))
  :url "https://github.com/kidd/erc-image.el"
  :commit "4ebb92729a3ed1b71bca5af3433e793f53ddc17d"
  :revdesc "4ebb92729a3e"
  :keywords '("multimedia")
  :authors '(("Jon de Andrés Frías" . "jondeandres@gmail.com"))
  :maintainers '(("Jon de Andrés Frías" . "jondeandres@gmail.com")))
