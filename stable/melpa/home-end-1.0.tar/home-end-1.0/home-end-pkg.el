;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "home-end" "1.0"
  "Smart multi-purpose home / end keys."
  '((emacs                "24.3")
    (keypress-multi-event "1.0"))
  :url "https://www.github.com/Boruch_Baum/emacs-home-end"
  :commit "30676ceec0d4ad84038cd0d65ee45ae810ab185c"
  :revdesc "30676ceec0d4"
  :keywords '("abbrev" "convenience" "wp" "keyboard")
  :authors '(("Boruch Baum" . "boruch_baum@gmx.com"))
  :maintainers '(("Boruch Baum" . "boruch_baum@gmx.com")))
