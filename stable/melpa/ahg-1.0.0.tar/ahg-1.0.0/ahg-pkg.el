;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ahg" "1.0.0"
  "Alberto's Emacs interface for Mercurial (Hg)."
  ()
  :url "https://bitbucket.org/agriggio/ahg"
  :commit "425a9c039610d3300a548c3ef52a5e0fce3c27e0"
  :revdesc "425a9c039610"
  :authors '(("Alberto Griggio" . "agriggio@users.sourceforge.net"))
  :maintainers '(("Alberto Griggio" . "agriggio@users.sourceforge.net")))
