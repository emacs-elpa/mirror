;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerdtab" "1.2.3"
  "Keyboard-oriented tabs."
  '((emacs "24.5"))
  :url "https://github.com/casouri/nerdtab"
  :commit "dba3c83b4ce6c1de84ef7ebe4ce144a009c61e68"
  :revdesc "dba3c83b4ce6"
  :keywords '("convenience")
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
