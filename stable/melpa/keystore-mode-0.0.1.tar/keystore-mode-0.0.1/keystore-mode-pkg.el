;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keystore-mode" "0.0.1"
  "A major mode for displaying JKS keystore."
  '((origami "1.0")
    (s       "1.12.0"))
  :url "https://github.com/peterpaul/keystore-mode"
  :commit "ab2a164b91fa0a5021efaf64acf566cbf934bc52"
  :revdesc "ab2a164b91fa"
  :keywords '("tools")
  :authors '(("Peterpaul Taekele Klein Haneveld" . "pp.kleinhaneveld@gmail.com"))
  :maintainers '(("Peterpaul Taekele Klein Haneveld" . "pp.kleinhaneveld@gmail.com")))
