;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spaces" "0.1.0"
  "Create and switch between named window configurations."
  ()
  :url "https://github.com/chumpage/chumpy-windows"
  :commit "2ad3dc03807623d5e608387d7f529697abb6fbdc"
  :revdesc "2ad3dc038076"
  :keywords '("windows"))
