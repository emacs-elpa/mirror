;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jknav" "0.0.1"
  "Automatically enable j/k keys for line-based navigation."
  ()
  :url "https://github.com/aculich/jknav.el"
  :commit "e74284f640a40bf618b5c37fdd9c00d295a6b4a3"
  :revdesc "e74284f640a4"
  :keywords '("keyboard" "navigation")
  :authors '(("Aaron Culich" . "aculich@gmail.com"))
  :maintainers '(("Aaron Culich" . "aculich@gmail.com")))
