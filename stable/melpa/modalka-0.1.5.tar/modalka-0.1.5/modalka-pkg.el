;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modalka" "0.1.5"
  "Easily introduce native modal editing of your own design."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/modalka"
  :commit "1259afa084f58d143d133aac56a6c0c10bc460f2"
  :revdesc "1259afa084f5"
  :keywords '("modal" "editing")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
