;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frame-tag" "0.1.1"
  "Minor mode that assigns a unique number to each frame for easy switching."
  '((cl-lib "0.5"))
  :url "https://github.com/liangzan/frame-tag.el"
  :commit "7018490dbc3c39f2c959e38c448001d1864bfa17"
  :revdesc "7018490dbc3c"
  :keywords '("frame" "movement")
  :authors '(("Wong Liang Zan" . "zan@liangzan.net"))
  :maintainers '(("Wong Liang Zan" . "zan@liangzan.net")))
