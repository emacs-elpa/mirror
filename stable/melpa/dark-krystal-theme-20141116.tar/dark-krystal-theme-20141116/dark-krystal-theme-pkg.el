;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dark-krystal-theme" "20141116"
  "An Emacs 24 theme based on Dark Krystal (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "9442586be84186571d461a5aeca1228202ef4d3d"
  :revdesc "9442586be841")
