;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slack" "0.0.1"
  "Slack client for emacs."
  '((websocket "1.5")
    (request   "0.2.0")
    (oauth2    "0.10")
    (circe     "2.1")
    (alert     "1.2")
    (emojify   "0.2"))
  :url "https://github.com/emacs-slack/emacs-slack"
  :commit "f09735f907076a693a999690140e5287a9c0c2d1"
  :revdesc "f09735f90707"
  :keywords '("tools")
  :authors '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local"))
  :maintainers '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local")))
