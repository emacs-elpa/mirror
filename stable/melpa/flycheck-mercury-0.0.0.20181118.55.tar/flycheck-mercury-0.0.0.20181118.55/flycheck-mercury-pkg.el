;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-mercury" "0.0.0.20181118.55"
  "Mercury support in Flycheck."
  '((flycheck "0.22")
    (s        "1.9.0")
    (dash     "2.4.0"))
  :url "https://github.com/flycheck/flycheck-mercury"
  :commit "b6807a8db70981e21a91a93324c31e49de85c89f"
  :revdesc "b6807a8db709"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Matthias Güdemann" . "matthias.gudemann@gmail.com"))
  :maintainers '(("Matthias Güdemann" . "matthias.gudemann@gmail.com")))
