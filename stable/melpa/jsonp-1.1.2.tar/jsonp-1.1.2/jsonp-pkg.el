;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsonp" "1.1.2"
  "Resolve JSON pointers in ELisp objects."
  '((emacs "28.1"))
  :url "https://github.com/joshbax189/jsonp-el"
  :commit "91c6ef2f998c4a70d3ebe30bf72d99f9c70ff6c7"
  :revdesc "91c6ef2f998c"
  :keywords '("comm" "tools"))
