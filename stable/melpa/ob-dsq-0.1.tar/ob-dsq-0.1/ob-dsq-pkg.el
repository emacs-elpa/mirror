;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-dsq" "0.1"
  "Babel functions for the `dsq` CLI tool by Multiprocess Labs."
  '((emacs "27.1"))
  :url "https://github.com/fritzgrabo/ob-dsq"
  :commit "2bda6c381a73b8d92a7a953a162590e244f1ee9c"
  :revdesc "2bda6c381a73"
  :keywords '("data" "tools")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
