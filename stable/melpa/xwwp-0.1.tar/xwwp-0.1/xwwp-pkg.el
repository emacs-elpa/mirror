;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xwwp" "0.1"
  "Enhance xwidget webkit browser."
  '((emacs "26.1"))
  :url "https://github.com/canatella/xwwp"
  :commit "b3b7b904c3e4448df06beaf146f34271770a54cc"
  :revdesc "b3b7b904c3e4"
  :keywords '("convenience"))
