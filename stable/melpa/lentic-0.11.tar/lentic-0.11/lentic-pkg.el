;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lentic" "0.11"
  "One buffer as a view of another."
  '((emacs    "24.4")
    (m-buffer "0.13")
    (dash     "2.5.0")
    (f        "0.17.2")
    (s        "1.9.0"))
  :url "https://github.com/phillord/lentic"
  :commit "8655ecd51e189bbdd6a4d8405dc3ea2e689c709a"
  :revdesc "8655ecd51e18"
  :authors '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
  :maintainers '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk")))
