;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-gnome" "0.3"
  "Orgmode integration with the GNOME desktop."
  '((alert          "1.2")
    (telepathy      "0.1")
    (gnome-calendar "0.1"))
  :url "https://github.com/NicolasPetton/org-gnome.el"
  :commit "1012d47886cfd30eed25b73d9f18e475e0155f88"
  :revdesc "1012d47886cf"
  :keywords '("org" "gnome")
  :authors '(("Nicolas Petton" . "petton.nicolas@gmail.com"))
  :maintainers '(("Nicolas Petton" . "petton.nicolas@gmail.com")))
