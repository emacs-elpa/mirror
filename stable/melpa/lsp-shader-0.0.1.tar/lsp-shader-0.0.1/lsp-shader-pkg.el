;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-shader" "0.0.1"
  "LSP Clients for ShaderLab."
  '((emacs    "27.1")
    (lsp-mode "6.1"))
  :url "https://github.com/shader-ls/lsp-shader"
  :commit "ac0de807b52d32b0e7ed3b216ab6d539bbb328de"
  :revdesc "ac0de807b52d"
  :keywords '("convenience" "shader")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
