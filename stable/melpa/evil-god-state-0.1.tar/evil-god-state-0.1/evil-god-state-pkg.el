;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-god-state" "0.1"
  "Use god-mode keybindings in evil-mode."
  '((diminish "0.44")
    (evil     "1.0.8")
    (god-mode "2.12.0"))
  :url "https://github.com/gridaphobe/evil-god-state"
  :commit "a3ef69a22976f964c44d26e87dc149f0a82e5ed0"
  :revdesc "a3ef69a22976"
  :keywords '("evil"))
