;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eww-lnum" "1.1"
  "Conkeror-like functionality for eww."
  ()
  :url "https://github.com/m00natic/eww-lnum"
  :commit "daef49974446ed4c1001e0549c3f74679bca6bd3"
  :revdesc "daef49974446"
  :keywords '("eww" "browse" "conkeror")
  :authors '(("Andrey Kotlarski" . "m00naticus@gmail.com"))
  :maintainers '(("Andrey Kotlarski" . "m00naticus@gmail.com")))
