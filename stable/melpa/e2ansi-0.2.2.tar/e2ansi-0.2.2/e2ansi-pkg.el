;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2ansi" "0.2.2"
  "Syntax highlighting for `less', powered by Emacs."
  '((emacs         "25.1")
    (face-explorer "0.0.7"))
  :url "https://github.com/Lindydancer/e2ansi"
  :commit "3de5bbe723e7a229b096c37098db89b06af1a228"
  :revdesc "3de5bbe723e7"
  :keywords '("faces" "languages"))
