;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nu-mode" "0.0.0.20260913.793"
  "Modern Emacs Keybinding."
  '((undo-tree       "0.6.5")
    (ace-window      "0")
    (lv              "0")
    (avy             "0")
    (which-key       "0")
    (transpose-frame "0"))
  :url "https://github.com/pyluyten/emacs-nu"
  :commit "157c414bb451a84fc4add88c328da33ef76058fc"
  :revdesc "157c414bb451")
