;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mocha" "1.1"
  "Run Mocha or Jasmine tests."
  '((js2-mode "20150909"))
  :url "https://github.com/scottaj/mocha.el"
  :commit "4ca9495d4b00b753f055152bd4256c07d7b208f4"
  :revdesc "v1.1-0-g4ca9495d4b00"
  :keywords '("javascript" "mocha" "jasmine"))
