;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "underline-with-char" "3.0.0"
  "Underline with a char."
  '((emacs "24"))
  :url "https://gitlab.com/marcowahl/underline-with-char"
  :commit "c2f4870aff70efe70a8d1b089e56d3a2d6d048b9"
  :revdesc "3.0.0-0-gc2f4870aff70"
  :keywords '("convenience"))
