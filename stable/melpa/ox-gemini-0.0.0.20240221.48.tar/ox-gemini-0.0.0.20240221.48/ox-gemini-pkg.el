;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-gemini" "0.0.0.20240221.48"
  "Output gemini formatted documents from org-mode."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~abrahms/ox-gemini"
  :commit "50818de823b7929f2d3207833e7c581280a60289"
  :revdesc "50818de823b7"
  :keywords '("lisp" "gemini")
  :authors '(("Justin Abrahms" . "justin@abrah.ms"))
  :maintainers '(("Justin Abrahms" . "justin@abrah.ms")))
