;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ansible-lint" "1.0.6"
  "A Flymake backend for ansible-lint."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/flymake-ansible-lint.el"
  :commit "8e300cc49b234a03aca90f497a69de2de8deab96"
  :revdesc "1.0.6-0-g8e300cc49b23"
  :keywords '("tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
