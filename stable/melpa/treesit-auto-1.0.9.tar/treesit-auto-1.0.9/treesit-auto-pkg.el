;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-auto" "1.0.9"
  "Automatically use tree-sitter enhanced major modes."
  '((emacs "29.0"))
  :url "https://github.com/renzmann/treesit-auto.git"
  :commit "e10d10adcf1a71d2c1813b44be00774237dad750"
  :revdesc "v1.0.9-0-ge10d10adcf1a"
  :keywords '("treesitter" "auto" "automatic" "major" "mode" "fallback" "convenience")
  :authors '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainers '(("Robb Enzmann" . "robbenzmann@gmail.com")))
