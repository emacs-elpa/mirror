;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-elp" "0.1"
  "Preview latex equations in org mode while editing."
  '((emacs "27.1"))
  :url "https://github.com/guanyilun/org-elp"
  :commit "f9d48042eed49b9936d162cecb4188456a9cc19b"
  :revdesc "f9d48042eed4"
  :keywords '("lisp" "tex" "org"))
