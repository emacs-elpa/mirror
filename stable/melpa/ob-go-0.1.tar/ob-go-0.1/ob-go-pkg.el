;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-go" "0.1"
  "Org-babel functions for go evaluation."
  ()
  :url "http://orgmode.org"
  :commit "d7f24b0ba435a66f33351fda6998b5219bf1718a"
  :revdesc "d7f24b0ba435"
  :keywords '("golang" "go" "literate programming" "reproducible research"))
