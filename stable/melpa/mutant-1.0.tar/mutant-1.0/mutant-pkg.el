;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mutant" "1.0"
  "An Emacs interface for the Mutant testing tool."
  '((emacs "24.4")
    (dash  "2.1.0"))
  :url "https://github.com/p-lambert/mutant.el"
  :commit "a3373573cb7a5fc4ba44f8c860cdd035c9d69259"
  :revdesc "a3373573cb7a"
  :keywords '("mutant" "testing"))
