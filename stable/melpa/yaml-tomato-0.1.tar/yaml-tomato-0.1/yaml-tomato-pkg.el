;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yaml-tomato" "0.1"
  "Some useful functions for editing yaml files."
  '((s "1.9"))
  :url "https://github.com/RadekMolenda/yaml-tomato"
  :commit "7d835694d25cc4b59b6040d303f192ec824a54d7"
  :revdesc "7d835694d25c"
  :keywords '("yaml"))
