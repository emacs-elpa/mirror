;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chinese-number" "0.0.0.20161008.39"
  "Convert numbers between Arabic and Chinese formats."
  ()
  :url "https://github.com/zhcosin/chinese-number"
  :commit "1d0c440181848dfcd1d1e618b2650fb0562a32ac"
  :revdesc "1d0c44018184"
  :authors '(("zhcosin" . "zhcosin@163.com"))
  :maintainers '(("zhcosin" . "zhcosin@163.com")))
