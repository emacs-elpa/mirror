;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "focus-autosave-mode" "0.0.0.20160519.11"
  "Automatically save files in focus-out-hook."
  '((emacs "24.4"))
  :url "https://github.com/vifon/focus-autosave-mode.el"
  :commit "e89ed22aa4dfc76e1b844b202aedd468ad58814a"
  :revdesc "e89ed22aa4df"
  :keywords '("convenience" "files" "frames" "mouse")
  :authors '(("Wojciech Siewierski" . "wojciech.siewierski@onet.pl"))
  :maintainers '(("Wojciech Siewierski" . "wojciech.siewierski@onet.pl")))
