;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mosey" "0.2"
  "Mosey around your buffers."
  '((emacs "24.4"))
  :url "https://github.com/alphapapa/mosey.el"
  :commit "2e3ac9d334fa2937ed5267193dfd25d8e1f14dc2"
  :revdesc "0.2-0-g2e3ac9d334fa"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
