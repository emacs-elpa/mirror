;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-notes" "0.4.2"
  "Keep handy notes of read Gnus articles with helm and org."
  '((emacs "27.1")
    (bbdb  "3.1")
    (helm  "3.1")
    (hydra "0.13.0")
    (org   "8.3")
    (s     "0.0")
    (lv    "0.0")
    (async "1.9.1"))
  :url "https://github.com/deusmax/gnus-notes"
  :commit "249e1471d586e0b3679a4b1ac4070e9f5c4516d2"
  :revdesc "v0.4.2-0-g249e1471d586"
  :keywords '("convenience" "mail" "bbdb" "gnus" "helm" "org" "hydra")
  :authors '(("Deus Max" . "deusmax@gmx.com"))
  :maintainers '(("Deus Max" . "deusmax@gmx.com")))
