;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "livid-mode" "0.1.0"
  "Live browser eval of JavaScript every time a buffer changes."
  '((skewer-mode "20130925")
    (s           "20130905"))
  :url "https://github.com/pandeiro"
  :commit "cfd2d46cafa720604ffb594cda08dbbcca645613"
  :revdesc "cfd2d46cafa7")
