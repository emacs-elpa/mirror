;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gtasks" "0.2.2"
  "Google Tasks API (sync)."
  '((emacs "27.1"))
  :url "https://github.com/thndrbrrr/gtasks"
  :commit "1b5aba8ee152d9646fd6062f45824cb5fa4b127b"
  :revdesc "1b5aba8ee152"
  :keywords '("convenience" "tools" "google" "tasks" "api")
  :authors '((nil . "thndrbrrr@gmail.com"))
  :maintainers '((nil . "thndrbrrr@gmail.com")))
