;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.1.1"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "fdf477f99fe1e152f7fbcb098fae1de00fa09efb"
  :revdesc "4.1.1-0-gfdf477f99fe1"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
