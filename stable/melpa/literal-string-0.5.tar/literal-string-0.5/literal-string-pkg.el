;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "literal-string" "0.5"
  "Edit string literals in a dedicated buffer."
  '((emacs         "25")
    (edit-indirect "0.1.5"))
  :url "https://github.com/joodie/literal-string-mode/"
  :commit "afffa86e626798ee9f9188ea3be2d5ee6ad17c39"
  :revdesc "0.5-0-gafffa86e6267"
  :keywords '("lisp" "tools" "docs")
  :authors '(("Joost Diepenmaat" . "joost@zeekat.nl"))
  :maintainers '(("Joost Diepenmaat" . "joost@zeekat.nl")))
