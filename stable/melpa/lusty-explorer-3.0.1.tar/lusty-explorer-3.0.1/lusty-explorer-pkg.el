;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lusty-explorer" "3.0.1"
  "Dynamic filesystem explorer and buffer switcher."
  ()
  :url "https://github.com/sjbach/lusty-emacs"
  :commit "8ece9b1379a73e7dc0b6e682dd5a573f88a5cb32"
  :revdesc "8ece9b1379a7"
  :keywords '("convenience" "files" "matching"))
