;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minimal-theme" "0.0.0.20250921.1"
  "A light/dark minimalistic Emacs 24 theme."
  ()
  :url "https://github.com/nullvec/minimal-theme"
  :commit "4382db5c4afc3beab0a356f8867bf480bddc5273"
  :revdesc "4382db5c4afc"
  :keywords '("color" "theme" "minimal")
  :authors '(("A. Hdez" . "trefoil_chilled_7k@icloud.com"))
  :maintainers '(("A. Hdez" . "trefoil_chilled_7k@icloud.com")))
