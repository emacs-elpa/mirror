;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-checkbashisms" "1.5"
  "Checkbashisms checker for flycheck."
  '((emacs    "24")
    (flycheck "0.25"))
  :url "https://github.com/Gnouc/flycheck-checkbashisms"
  :commit "39362240b8e38e6ddc1da2e2c2229e3fecdf6057"
  :revdesc "39362240b8e3"
  :keywords '("convenience" "tools" "sh" "unix")
  :authors '(("Cuong Le" . "cuong.manhle.vn@gmail.com"))
  :maintainers '(("Cuong Le" . "cuong.manhle.vn@gmail.com")))
