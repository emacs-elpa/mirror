;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-sentence" "3"
  "Highlight a sentence based on customizable face."
  ()
  :url "https://github.com/milkypostman/hl-sentence"
  :commit "f88882772f1a29fabb54194cc8aacd80d7f5b085"
  :revdesc "f88882772f1a"
  :keywords '("highlighting")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net"))
  :maintainers '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")))
