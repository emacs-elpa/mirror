;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-x" "1.3"
  "Convert color themes to X11 resource settings."
  ()
  :url "https://github.com/ajsquared/color-theme-x"
  :commit "6e243109bd6c0711a114c73b27238c3e56684c56"
  :revdesc "6e243109bd6c"
  :keywords '("convenience" "faces" "frames")
  :authors '(("Matthew Kennedy" . "mkennedy@killr.ath.cx"))
  :maintainers '(("Andrew Johnson" . "theonceandfutureajsquared@gmail.com")))
