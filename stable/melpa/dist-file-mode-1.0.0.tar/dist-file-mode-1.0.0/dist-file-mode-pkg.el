;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dist-file-mode" "1.0.0"
  "Dispatch major mode for *.dist files."
  '((emacs "26"))
  :url "https://github.com/emacs-php/dist-file-mode.el"
  :commit "8bb2f05487164cd690cac9c9c442969f6f79b81f"
  :revdesc "8bb2f0548716"
  :keywords '("files" "convenience")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
