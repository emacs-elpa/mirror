;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-tree-sitter" "0.1.0"
  "Helm interface for tree-sitter."
  '((emacs       "25.1")
    (helm        "3.6.2")
    (tree-sitter "0.16.1"))
  :url "https://gitlab.com/giedriusj1/helm-tree-sitter"
  :commit "71a66bb2739da7d6103e1ebd09db99ef8e0ad7d7"
  :revdesc "71a66bb2739d"
  :authors '(("Giedrius Jonikas" . "giedriusj1@gmail.com"))
  :maintainers '(("Giedrius Jonikas" . "giedriusj1@gmail.com")))
