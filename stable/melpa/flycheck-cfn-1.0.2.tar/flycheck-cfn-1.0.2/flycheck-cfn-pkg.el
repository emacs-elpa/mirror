;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-cfn" "1.0.2"
  "Flycheck backend for AWS cloudformation."
  '((emacs    "26.1")
    (flycheck "31"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "4cf56affe3035fda364109836e26499431095185"
  :revdesc "flycheck-cfn/v1.0.2-0-g4cf56affe303"
  :keywords '("convenience")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
