;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fish-mode" "0.1.6"
  "Major mode for fish shell scripts."
  '((emacs "24"))
  :url "https://github.com/wwwjfy/emacs-fish"
  :commit "a7c953b1491ac3a3e00a7b560f2c9f46b3cb5c04"
  :revdesc "a7c953b1491a"
  :keywords '("fish" "shell")
  :authors '(("Tony Wang" . "wwwjfy@gmail.com"))
  :maintainers '(("Tony Wang" . "wwwjfy@gmail.com")))
