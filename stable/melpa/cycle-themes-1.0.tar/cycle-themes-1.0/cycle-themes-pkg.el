;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cycle-themes" "1.0"
  "Minor mod for theme cycling."
  ()
  :url "https://github.com/toroidal-code/cycle-themes.el"
  :commit "54170273cb28b00a9d7cf064556644864937270f"
  :revdesc "54170273cb28"
  :keywords '("themes" "utility" "global minor mode")
  :authors '(("Katherine Whitlock" . "toroidalcode@gmail.com"))
  :maintainers '(("Katherine Whitlock" . "toroidalcode@gmail.com")))
