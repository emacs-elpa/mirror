;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-rename-tag" "0.3.5"
  "Automatically rename paired HTML/XML tag."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/auto-rename-tag"
  :commit "88c5236280ff8212ff5c74f3e2e654c1a288dbf2"
  :revdesc "88c5236280ff"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
