;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-sourcekit" "0.2.0"
  "Company-mode completion backend for SourceKit."
  '((emacs           "24.3")
    (company         "0.8.12")
    (dash            "2.12.1")
    (dash-functional "1.2.0")
    (sourcekit       "0.2.0"))
  :url "https://github.com/nathankot/company-sourcekit"
  :commit "8ba62ac25bf533b7f148f333bcb5c1db799f749b"
  :revdesc "8ba62ac25bf5"
  :keywords '("abbrev")
  :authors '(("Nathan Kot" . "nk@nathankot.com"))
  :maintainers '(("Nathan Kot" . "nk@nathankot.com")))
