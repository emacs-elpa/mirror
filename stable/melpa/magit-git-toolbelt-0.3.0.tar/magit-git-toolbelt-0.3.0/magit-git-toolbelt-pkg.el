;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-git-toolbelt" "0.3.0"
  "A Magit interface for git-toolbelt."
  '((emacs     "26.1")
    (magit     "3.0.0")
    (transient "0.3.0"))
  :url "https://github.com/jonathanchu/magit-git-toolbelt"
  :commit "c6c69ebf8e1a5dfa89c1bcc37ca8abc9713f957b"
  :revdesc "c6c69ebf8e1a"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
