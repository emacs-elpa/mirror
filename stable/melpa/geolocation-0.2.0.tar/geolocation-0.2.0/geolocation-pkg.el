;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geolocation" "0.2.0"
  "Get your location on Earth."
  '((request-deferred "0.3.2")
    (deferred         "0.5.1")
    (emacs            "25.1"))
  :url "https://github.com/gonewest818/geolocation.el"
  :commit "83ab28e64bc067016b5344dffe93e380e9807e9c"
  :revdesc "83ab28e64bc0"
  :keywords '("hardware")
  :authors '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com"))
  :maintainers '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com")))
