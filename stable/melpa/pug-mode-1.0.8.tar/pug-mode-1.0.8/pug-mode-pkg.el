;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pug-mode" "1.0.8"
  "Major mode for jade/pug template files."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/hlissner/emacs-pug-mode"
  :commit "d08090485eb8c0488a7d2fbf63680dc0880c7d2f"
  :revdesc "d08090485eb8"
  :keywords '("markup" "language" "jade" "pug")
  :maintainers '(("Henrik Lissner" . "henrik@lissner.net")))
