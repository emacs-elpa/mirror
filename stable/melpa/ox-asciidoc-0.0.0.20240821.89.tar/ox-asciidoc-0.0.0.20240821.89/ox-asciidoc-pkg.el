;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-asciidoc" "0.0.0.20240821.89"
  "AsciiDoc Back-End for Org Export Engine."
  '((org "8.1"))
  :url "https://github.com/yashi/org-asciidoc"
  :commit "a8d49c44cc9aa8a3f384155f0ae052dbf36df00c"
  :revdesc "a8d49c44cc9a"
  :keywords '("org" "asciidoc")
  :authors '(("Yasushi SHOJI" . "yasushi.shoji@gmail.com"))
  :maintainers '(("Yasushi SHOJI" . "yasushi.shoji@gmail.com")))
