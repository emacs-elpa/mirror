;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unfill" "0.3"
  "Do the opposite of fill-paragraph or fill-region."
  '((emacs "24.1"))
  :url "https://github.com/purcell/unfill"
  :commit "8375d87ec184fbe964189e2f9b7263cdb1396694"
  :revdesc "8375d87ec184"
  :keywords '("convenience")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
