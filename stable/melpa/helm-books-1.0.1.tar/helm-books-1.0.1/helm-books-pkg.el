;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-books" "1.0.1"
  "Helm interface for searching books."
  '((helm "1.7.7"))
  :url "https://github.com/grugrut/helm-books"
  :commit "b4c57d2aed596faad41a753dccbcd0a31a717b76"
  :revdesc "b4c57d2aed59"
  :authors '(("grugrut" . "grugruglut+github@gmail.com"))
  :maintainers '(("grugrut" . "grugruglut+github@gmail.com")))
