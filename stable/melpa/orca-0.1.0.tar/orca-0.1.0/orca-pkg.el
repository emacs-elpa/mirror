;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orca" "0.1.0"
  "Org Capture."
  '((counsel "0.9.1"))
  :url "https://github.com/abo-abo/orca"
  :commit "26b0fb41cc95f757c66b922b7466f34bf4c1000a"
  :revdesc "26b0fb41cc95"
  :keywords '("org" "capture")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
