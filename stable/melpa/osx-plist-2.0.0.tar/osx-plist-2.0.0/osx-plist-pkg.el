;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-plist" "2.0.0"
  "Apple plist file parser."
  '((emacs "25.1"))
  :url "https://github.com/gonewest818/osx-plist.el"
  :commit "bbed74d334e8a4141c8f6ed07c8e42ee7979c35c"
  :revdesc "bbed74d334e8"
  :keywords '("convenience")
  :authors '(("Theresa O'Connor" . "tess@oconnor.cx"))
  :maintainers '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com")))
