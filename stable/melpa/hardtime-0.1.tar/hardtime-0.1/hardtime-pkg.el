;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hardtime" "0.1"
  "Prevents overuse of specified commands."
  '((emacs "26.3"))
  :url "https://github.com/ichernyshovvv/hardtime.el"
  :commit "a14df12bda3951e53553426629f4af7a638f6eee"
  :revdesc "0.1-0-ga14df12bda39"
  :keywords '("navigation" "convenience")
  :authors '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainers '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com")))
