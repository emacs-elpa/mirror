;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elune-theme" "0.1"
  "Elune theme."
  ()
  :url "https://github.com/xcatalyst/elune-theme"
  :commit "23e10e6fd5aabcbcf9c4dae7904edca555fd4062"
  :revdesc "23e10e6fd5aa"
  :authors '(("ağan Korkmaz" . "xcatalystt@gmail.com"))
  :maintainers '(("ağan Korkmaz" . "xcatalystt@gmail.com")))
