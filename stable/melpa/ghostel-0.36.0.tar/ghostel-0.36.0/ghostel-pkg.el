;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.36.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "2479c15182458e337e6929b9f0daf82eb0368d4d"
  :revdesc "2479c1518245"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
