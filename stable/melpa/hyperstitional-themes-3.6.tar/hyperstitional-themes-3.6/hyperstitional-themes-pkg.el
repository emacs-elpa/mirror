;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperstitional-themes" "3.6"
  "Weird themes with incremental palettes."
  '((emacs "24.1"))
  :url "https://github.com/precompute/hyperstitional-themes"
  :commit "adde296858f4c468008eb8ed92ccad416e7e0391"
  :revdesc "adde296858f4"
  :authors '(("precompute" . "git@precompute.net"))
  :maintainers '(("precompute" . "git@precompute.net")))
