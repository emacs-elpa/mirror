;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "add-node-modules-path" "1.3.1"
  "Add node_modules to your exec-path."
  '((s "1.12.0"))
  :url "https://github.com/codesuki/add-node-modules-path"
  :commit "63f047fd84b825876152743f66de7ee6f9ed203b"
  :revdesc "63f047fd84b8"
  :keywords '("javascript" "node" "node_modules" "eslint")
  :authors '(("Neri Marschik" . "marschik_neri@cyberagent.co.jp"))
  :maintainers '(("Neri Marschik" . "marschik_neri@cyberagent.co.jp")))
