;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clocker" "0.0.11"
  "Note taker and clock-in enforcer."
  '((projectile "0.11.0")
    (dash       "2.10"))
  :url "https://github.com/roman/clocker.el"
  :commit "4a4831ed4e42e18976edd16b844cb16cb78f3c17"
  :revdesc "4a4831ed4e42"
  :keywords '("org")
  :authors '(("Roman Gonzalez" . "romanandreg@gmail.com"))
  :maintainers '(("Roman Gonzalez" . "romanandreg@gmail.com")))
