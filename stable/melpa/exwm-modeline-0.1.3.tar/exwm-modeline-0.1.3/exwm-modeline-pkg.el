;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-modeline" "0.1.3"
  "A modeline segment for EXWM workspaces."
  '((emacs "27.1")
    (exwm  "0.26"))
  :url "https://github.com/SqrtMinusOne/pomm.el"
  :commit "dfd0b861337d4cdef9d4e6126d631397f893c087"
  :revdesc "dfd0b861337d"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
