;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "default-font-presets" "0.1"
  "Support selecting fonts from a list of presets."
  '((emacs "26.1"))
  :url "https://gitlab.com/ideasman42/emacs-default-font-presets"
  :commit "dd143e7e6cf5384d203a76e50fe677a77f1cd615"
  :revdesc "dd143e7e6cf5"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
