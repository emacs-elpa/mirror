;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zig-mode" "0.0.8"
  "A major mode for the Zig programming language."
  '((emacs       "26.1")
    (reformatter "0.6"))
  :url "https://github.com/zig-lang/zig-mode"
  :commit "f3e952c24a9c152307a6e7ca1645b5f72be74314"
  :revdesc "f3e952c24a9c"
  :keywords '("zig" "languages")
  :authors '(("Andrea Orru" . "andreaorru1991@gmail.com")
             ("Andrew Kelley" . "superjoe30@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
