;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vterm-editor" "1.0.0"
  "Edit text in a buffer and send it to vterm."
  '((emacs "25.1")
    (vterm "0.0.1"))
  :url "https://git.andros.dev/andros/vterm-editor.el"
  :commit "dc10185111e4f0014528d28a3e31d26c48d5e2ef"
  :revdesc "dc10185111e4"
  :keywords '("terminals" "convenience"))
