;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-mock" "1.25.1"
  "Tiny Mock and Stub framework in Emacs Lisp."
  ()
  :url "https://github.com/rejeep/el-mock.el"
  :commit "3069931de75bb6704ecf565af5390009dc4dae00"
  :revdesc "3069931de75b"
  :keywords '("lisp" "testing" "unittest")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
