;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tramp-term" "0.5"
  "Automatic setup of directory tracking in ssh sessions."
  ()
  :url "https://github.com/randymorris/tramp-term.el"
  :commit "fdc3d5a29ca9549db462cd66d8f5d97026a1200f"
  :revdesc "fdc3d5a29ca9"
  :keywords '("tramp" "ssh")
  :authors '(("Randy Morris" . "randy.morris@archlinux.us"))
  :maintainers '(("Randy Morris" . "randy.morris@archlinux.us")))
