;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-indent-scope" "0.1"
  "Highlight indentation by scope."
  '((emacs "26.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope"
  :commit "9eecaa255a7a3c2812fe3c148a5a97325fe733af"
  :revdesc "9eecaa255a7a"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
