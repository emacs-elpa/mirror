;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-replace-with-char" "1.0.0"
  "Replace chars of a text object with a char."
  '((evil  "1.2.13")
    (emacs "24"))
  :url "https://github.com/ninrod/evil-replace-with-char"
  :commit "dddbbafdd620cc48dd0a257baf4010e1b415ebe8"
  :revdesc "dddbbafdd620"
  :authors '(("Filipe Silva" . "filipe.silva@gmail.com"))
  :maintainers '(("Filipe Silva" . "filipe.silva@gmail.com")))
