;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annoying-arrows-mode" "0.1.0"
  "Ring the bell if using arrows too much."
  ()
  :url "https://github.com/magnars/annoying-arrows-mode.el"
  :commit "fe59f3fd464e7a87cc43fb8a1f135b3bdf8a2fb3"
  :revdesc "0.1.0-0-gfe59f3fd464e"
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
