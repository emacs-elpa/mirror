;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sas-py" "0.2"
  "SAS with SASPy."
  '((emacs "28.1")
    (ess   "18.10.1"))
  :url "https://github.com/ShuguangSun/sas-py"
  :commit "0031b7f10495fa3a5272255d50e23cda2cf2e5f1"
  :revdesc "0031b7f10495"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
