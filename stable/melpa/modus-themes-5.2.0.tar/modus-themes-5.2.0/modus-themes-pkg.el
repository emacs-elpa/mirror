;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "5.2.0"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "d1037f1322487e5686fff655dcd88aa644b2ad51"
  :revdesc "d1037f132248"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
