;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly-asdf" "0.2.0"
  "ASDF system support for SLY."
  '((emacs "24.3")
    (sly   "1.0.0-beta2")
    (popup "0.5.3"))
  :url "https://github.com/mmgeorge/sly-asdf"
  :commit "3180921efdc19a2195960e1d601b2a6f31a6feea"
  :revdesc "3180921efdc1"
  :keywords '("languages" "lisp" "sly" "asdf")
  :maintainers '(("Matt George" . "mmge93@gmail.com")))
