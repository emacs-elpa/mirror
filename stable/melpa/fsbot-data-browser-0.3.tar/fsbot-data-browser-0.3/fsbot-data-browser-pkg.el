;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fsbot-data-browser" "0.3"
  "Browse the fsbot database using tabulated-list-mode."
  ()
  :url "https://github.com/benaiah/fsbot-data-browser"
  :commit "6bca4f7de63e31839d2542f6c678b79931dec344"
  :revdesc "6bca4f7de63e"
  :keywords '("fsbot" "irc" "tabulated-list-mode"))
