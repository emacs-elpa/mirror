;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-native-complete" "0.1.0"
  "Company completion using native-complete."
  '((emacs           "25.1")
    (company         "0.9.0")
    (native-complete "0.1.0"))
  :url "https://github.com/CeleritasCelery/emacs-native-shell-complete"
  :commit "fd133fb7ebf9a1d5bd76da601fdcc49480927658"
  :revdesc "fd133fb7ebf9"
  :authors '(("Troy Hinckley" . "troy.hinckley@gmail.com"))
  :maintainers '(("Troy Hinckley" . "troy.hinckley@gmail.com")))
