;;; company-native-complete.el --- Company completion using native-complete -*- lexical-binding: t; -*-

;; Copyright (C) 2019 by Troy Hinckley

;; Author: Troy Hinckley <troy.hinckley@gmail.com>
;; URL: https://github.com/CeleritasCelery/emacs-native-shell-complete
;; Package-Version: 0.1.0
;; Package-Revision: fd133fb7ebf9
;; Package-Requires: ((emacs "25.1")(company "0.9.0")(native-complete "0.1.0"))


;;; Commentary:
;; This package provides a company backend for use with native-complete.

;;; Code:

(require 'native-complete)

(defvar comint-redirect-hook)

(defun company-native-complete--candidates (callback)
  "Get candidates for `company-native-complete'.
Send results by calling CALLBACK."
  (add-hook 'comint-redirect-hook
            (lambda ()
              (setq comint-redirect-hook nil)
              (funcall callback (native-complete--get-completions))))
  (comint-redirect-send-command
   native-complete--redirection-command
   native-complete--buffer nil t))

(defun company-native-complete--prefix ()
  "Get prefix for `company-native-complete'."
  (when (native-complete--usable-p)
    (native-complete--get-prefix)
    (cond
     ((string-prefix-p "-" native-complete--prefix)
      (cons native-complete--prefix t))
     ((string-match-p "/" native-complete--common)
      (cons native-complete--prefix
            (+ (length native-complete--common)
               (length native-complete--prefix))))
     (t native-complete--prefix))))

;;;###autoload
(defun company-native-complete (command &rest _ignored)
  "Completion for native shell complete functionality.
Dispatch based on COMMAND."
  (interactive '(interactive))
  (cl-case command
    (interactive (company-begin-backend 'company-native-complete))
    (prefix (company-native-complete--prefix))
    (candidates (cons :async 'company-native-complete--candidates))
    (ignore-case t)))

(provide 'company-native-complete)

;;; company-native-complete.el ends here
