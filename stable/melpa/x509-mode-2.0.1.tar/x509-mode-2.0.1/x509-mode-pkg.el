;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "2.0.1"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "fec2f7281b3224ea950284cf39ba45a355c652f5"
  :revdesc "v2.0.1-0-gfec2f7281b32"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
