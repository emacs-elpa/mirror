;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "handlebars-mode" "1.4"
  "A major mode for editing Handlebars files."
  ()
  :url "https://github.com/danielevans/handlebars-mode"
  :commit "1d4e6f61ec70342a6ff21cfa122266234943d706"
  :revdesc "1d4e6f61ec70")
