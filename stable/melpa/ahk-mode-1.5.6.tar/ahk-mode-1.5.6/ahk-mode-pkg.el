;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ahk-mode" "1.5.6"
  "Major mode for editing AHK (AutoHotkey and AutoHotkey_L)."
  '((emacs "24.3"))
  :url "https://github.com/ralesi/ahk-mode"
  :commit "bf3205efe7b7a40f3c8978f68f14ea3a939cffa8"
  :revdesc "bf3205efe7b7"
  :keywords '("ahk" "autohotkey" "hotkey" "keyboard shortcut" "automation"))
