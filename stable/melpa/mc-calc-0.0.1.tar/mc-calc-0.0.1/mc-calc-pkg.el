;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mc-calc" "0.0.1"
  "Combine multiple-cursors and calc."
  ()
  :url "https://github.com/hatheroldev/mc-calc"
  :commit "cfd561558e53f3ad26a7641a2877ea84fed0b43c"
  :revdesc "cfd561558e53"
  :keywords '("convenience")
  :authors '((nil . "FrankRolandhatheroldev@fgmail.com"))
  :maintainers '((nil . "FrankRolandhatheroldev@fgmail.com")))
