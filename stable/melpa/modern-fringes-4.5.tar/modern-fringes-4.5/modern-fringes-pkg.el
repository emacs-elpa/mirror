;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modern-fringes" "4.5"
  "Replaces default fringe bitmaps with better looking ones."
  ()
  :url "https://github.com/specialbomb/emacs-modern-fringes"
  :commit "98473694a33922cfdddb18b4791028e4854b53b5"
  :revdesc "4.5-0-g98473694a339"
  :keywords '("themes" "fringes" "convenience")
  :authors '(("Quen Jankosky" . "quen.jankosky@gmail.com"))
  :maintainers '(("Quen Jankosky" . "quen.jankosky@gmail.com")))
