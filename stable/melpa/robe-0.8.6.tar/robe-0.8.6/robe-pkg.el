;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "robe" "0.8.6"
  "Code navigation, documentation lookup and completion for Ruby."
  '((inf-ruby "2.5.1")
    (emacs    "25.1"))
  :url "https://github.com/dgutov/robe"
  :commit "43a85c2eb6e52f4e684919210dd84d67289938c1"
  :revdesc "43a85c2eb6e5"
  :keywords '("ruby" "convenience" "rails"))
