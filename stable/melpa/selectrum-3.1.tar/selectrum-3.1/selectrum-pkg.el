;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selectrum" "3.1"
  "Easily select item from list."
  '((emacs "25.1"))
  :url "https://github.com/raxod502/selectrum"
  :commit "a9ecaa018f249c15fae8e1af5d4df337e846e92f"
  :revdesc "a9ecaa018f24"
  :keywords '("extensions")
  :authors '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainers '(("Radon Rosborough" . "radon.neon@gmail.com")))
