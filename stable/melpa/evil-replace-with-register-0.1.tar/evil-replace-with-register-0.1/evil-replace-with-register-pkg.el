;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-replace-with-register" "0.1"
  "Port of vim plugin ReplaceWithRegister."
  '((evil "1.0.8"))
  :url "https://github.com/Dewdrops/evil-ReplaceWithRegister"
  :commit "454c161e076d29960b1353bbe3975cd061918ce6"
  :revdesc "454c161e076d"
  :keywords '("evil" "plugin")
  :authors '(("Dewdrops" . "v_v_4474@126.com"))
  :maintainers '(("Dewdrops" . "v_v_4474@126.com")))
