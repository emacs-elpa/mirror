;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu-candidate-overlay" "1.3"
  "Show first candidate in an overlay while typing."
  '((emacs "28.1")
    (corfu "0.36"))
  :url "https://code.bsdgeek.org/adam/corfu-candidate-overlay/"
  :commit "0674824cb87881b86e9f20ae3ef1daba0e1a7b68"
  :revdesc "0674824cb878"
  :authors '(("Adam Kruszewski" . "adam@kruszewski.name"))
  :maintainers '(("Adam Kruszewski" . "adam@kruszewski.name")))
