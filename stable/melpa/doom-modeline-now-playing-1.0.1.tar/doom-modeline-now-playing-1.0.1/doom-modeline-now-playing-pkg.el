;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline-now-playing" "1.0.1"
  "Segment for Doom Modeline to show media player information."
  '((emacs         "26.1")
    (doom-modeline "3.0.0"))
  :url "https://github.com/elken/doom-modeline-now-playing"
  :commit "c851f2642a3f8603355b86a1d86affb46fd05a4d"
  :revdesc "c851f2642a3f"
  :authors '(("Ellis Kenyő" . "me@elken.dev"))
  :maintainers '(("Ellis Kenyő" . "me@elken.dev")))
