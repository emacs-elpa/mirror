;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "0.18.1"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.11.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "1944a44ddf02d1507b381ffdf9460a9f248b5d63"
  :revdesc "v0.18.1-0-g1944a44ddf02"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
