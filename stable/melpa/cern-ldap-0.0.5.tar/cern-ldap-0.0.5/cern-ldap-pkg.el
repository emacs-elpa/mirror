;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cern-ldap" "0.0.5"
  "Library to interact with CERN's LDAP servers."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~nbarrientos/cern-ldap.el"
  :commit "70b5275f0e7b8e15a3def48281f364a32c55afce"
  :revdesc "70b5275f0e7b"
  :keywords '("tools" "convenience")
  :authors '(("Nacho Barrientos" . "nacho.barrientos@cern.ch"))
  :maintainers '(("Nacho Barrientos" . "nacho.barrientos@cern.ch")))
