;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apples-mode" "0.0.2"
  "Major mode for editing and executing AppleScript code."
  ()
  :url "https://github.com/tequilasunset/apples-mode"
  :commit "fac47b6255e79a373c5d5e1abe66ea5d74588e9f"
  :revdesc "fac47b6255e7"
  :keywords '("applescript" "languages")
  :authors '(("tequilasunset" . "tequilasunset.mac@gmail.com"))
  :maintainers '(("tequilasunset" . "tequilasunset.mac@gmail.com")))
