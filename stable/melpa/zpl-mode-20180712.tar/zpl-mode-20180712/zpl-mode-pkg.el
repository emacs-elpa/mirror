;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zpl-mode" "20180712"
  "ZIMPL major mode."
  '((emacs "24.3"))
  :url "https://github.com/ax487/zpl-mode.git"
  :commit "5cbcc7954487c2d7e9d1f814398821b7f95faed8"
  :revdesc "5cbcc7954487")
