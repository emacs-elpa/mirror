;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-project-capture" "3.1.0"
  "Repository todo capture and management for org-mode."
  '((dash                 "2.10.0")
    (emacs                "28")
    (s                    "1.9.0")
    (org-category-capture "1.0.0"))
  :url "https://github.com/colonelpanic8/org-project-capture"
  :commit "214a6068c467323a795b27996c1e7b75ae42dc68"
  :revdesc "214a6068c467"
  :keywords '("org-mode" "todo" "tools" "outlines" "project" "capture")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
