;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-auto-expand" "0.1"
  "Automatically expand certain headings."
  '((emacs "26.1"))
  :url "https://github.com/alphapapa/org-auto-expand"
  :commit "dfb909d9fd0a658df8a05613a5b95b645b855344"
  :revdesc "0.1-0-gdfb909d9fd0a"
  :keywords '("convenience" "outlines" "org")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
