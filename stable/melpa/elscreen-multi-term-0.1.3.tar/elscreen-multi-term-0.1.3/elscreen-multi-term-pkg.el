;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elscreen-multi-term" "0.1.3"
  "Multi term for elscreen."
  '((emacs      "24.4")
    (elscreen   "1.4.6")
    (multi-term "1.3"))
  :url "https://github.com/wamei/elscreen-multi-term"
  :commit "68559190d853cb80a6c7f52e928606b82cf37438"
  :revdesc "68559190d853"
  :keywords '("elscreen" "multi term")
  :authors '(("wamei" . "wamei.cho@gmail.com"))
  :maintainers '(("wamei" . "wamei.cho@gmail.com")))
