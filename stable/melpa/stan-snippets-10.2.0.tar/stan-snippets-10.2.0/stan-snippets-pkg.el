;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stan-snippets" "10.2.0"
  "Yasnippets for Stan."
  '((emacs     "24.3")
    (stan-mode "10.1.0")
    (yasnippet "0.8.0"))
  :url "https://github.com/stan-dev/stan-mode/tree/master/stan-snippets"
  :commit "2dd330604563d143031fc8ffd516266217aa1f9b"
  :revdesc "2dd330604563"
  :keywords '("languages" "tools")
  :authors '(("Jeffrey Arnold" . "jeffrey.arnold@gmail.com")
             ("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu"))
  :maintainers '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu")))
