;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seethru" "0.3"
  "Easily change Emacs' transparency."
  '((shadchen "1.4"))
  :url "https://github.com/benaiah/seethru"
  :commit "f9b66e2f7ab8796ec458658e3f8e94b73a97adc2"
  :revdesc "f9b66e2f7ab8"
  :keywords '("lisp" "tools" "alpha" "transparency")
  :authors '(("Benaiah Mischenko" . "benaiah@mischenko.com"))
  :maintainers '(("Benaiah Mischenko" . "benaiah@mischenko.com")))
