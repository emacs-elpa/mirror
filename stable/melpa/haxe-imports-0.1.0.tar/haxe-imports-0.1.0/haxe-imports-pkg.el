;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haxe-imports" "0.1.0"
  "Code for dealing with Haxe imports based on java-imports by Matthew Lee Hinman."
  '((emacs  "24.4")
    (s      "1.10.0")
    (pcache "0.3.2"))
  :url "http://www.github.com/dakrone/emacs-haxe-imports"
  :commit "9daaac8e523c9c60d3624c38155130949873cd54"
  :revdesc "9daaac8e523c"
  :keywords '("haxe")
  :authors '(("Juan Karlo Licudine" . "karlo@accidentalrebel.com"))
  :maintainers '(("Juan Karlo Licudine" . "karlo@accidentalrebel.com")))
