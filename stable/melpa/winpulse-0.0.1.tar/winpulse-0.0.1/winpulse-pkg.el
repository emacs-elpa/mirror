;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winpulse" "0.0.1"
  "Momentary window background flash animation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/winpulse"
  :commit "cf0b1f34653fa469410932dd5f070445739e85eb"
  :revdesc "cf0b1f34653f")
