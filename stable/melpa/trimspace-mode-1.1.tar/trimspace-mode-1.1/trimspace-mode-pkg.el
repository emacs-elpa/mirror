;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trimspace-mode" "1.1"
  "A minor mode to trim trailing whitespace and newlines."
  '((emacs "24.3"))
  :url "https://git.sr.ht/~bkhl/trimspace-mode"
  :commit "ea7dd0d4847e10c77d174f537051db70233ecf6e"
  :revdesc "ea7dd0d4847e"
  :keywords '("files" "convenience")
  :authors '(("Björn Lindström" . "bkhl@elektrubadur.se"))
  :maintainers '(("Björn Lindström" . "bkhl@elektrubadur.se")))
