;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "engine-mode" "2.2.4"
  "Define and query search engines."
  '((cl-lib "0.5"))
  :url "https://github.com/hrs/engine-mode"
  :commit "67b68c1a2bff48bad2cc4722598da0f36e3866a9"
  :revdesc "67b68c1a2bff"
  :authors '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainers '(("Harry R. Schwartz" . "hello@harryrschwartz.com")))
