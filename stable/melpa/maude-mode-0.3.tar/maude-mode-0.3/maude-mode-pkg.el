;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maude-mode" "0.3"
  "Emacs mode for the programming language Maude."
  '((emacs "25"))
  :url "https://github.com/rudi/abs-mode"
  :commit "008f372631a1efe15be033792cfb1686b1736aeb"
  :revdesc "008f372631a1"
  :keywords '("languages" "maude")
  :authors '(("Ellef Gjelstad" . "ellefg+maude*ifi.uio.no"))
  :maintainers '(("Rudi Schlatte" . "rudi@constantly.at")))
