;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apdl-mode" "20.6.0"
  "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :url "https://github.com/dieter-wilhelm/apdl-mode"
  :commit "9950b3092933adde85d613410432971071e33263"
  :revdesc "9950b3092933"
  :keywords '("languages" "convenience" "tools" "ansys" "apdl")
  :authors '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de")))
