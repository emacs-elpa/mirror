;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chembalance" "1.0"
  "Balance chemical equations."
  '((emacs "24.4"))
  :url "https://github.com/sergiruiztrepat/chembalance.el"
  :commit "5a38869bbd5f3030cc101fc3a6d16eac5cade64d"
  :revdesc "5a38869bbd5f"
  :keywords '("convenience" "chemistry"))
