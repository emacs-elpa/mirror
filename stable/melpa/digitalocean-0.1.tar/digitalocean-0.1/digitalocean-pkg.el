;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "digitalocean" "0.1"
  "Create and manipulate digitalocean droplets."
  '((requests "2.5")
    (emacs    "24.3")
    (widget   ""))
  :url "https://github.com/olymk2/digitalocean-api"
  :commit "abd28955bd580469f9657963a36808174a47dba6"
  :revdesc "abd28955bd58"
  :keywords '("processes" "tools")
  :authors '(("Oliver Marks" . "oly@digitaloctave.com"))
  :maintainers '(("Oliver Marks" . "oly@digitaloctave.com")))
