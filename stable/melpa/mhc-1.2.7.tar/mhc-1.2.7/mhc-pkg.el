;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mhc" "1.2.7"
  "Message Harmonized Calendaring system."
  '((calfw "20150703"))
  :url "http://www.quickhack.net/mhc"
  :commit "b527a88748651d06222ad24f7417941088515275"
  :revdesc "v1.2.7-0-gb527a8874865"
  :keywords '("calendar")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
