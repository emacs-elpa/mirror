;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gtk-pomodoro-indicator" "0.1.0"
  "A pomodoro indicator for the GTK tray."
  ()
  :url "https://github.com/abo-abo/gtk-pomodoro-indicator"
  :commit "cf781671c4565ec305bd7c19ad100b631b7e0c2b"
  :revdesc "cf781671c456"
  :keywords '("convenience" "pomodoro")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
