;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keepass-mode" "0.0.5"
  "Mode for KeePass DB."
  '((emacs "27"))
  :url "https://github.com/ifosch/keepass-mode"
  :commit "f432bb60f9f3bd027025140d723906dcabeefaef"
  :revdesc "f432bb60f9f3"
  :keywords '("data" "files" "tools")
  :authors '(("Ignasi Fosch" . "natx@y10k.ws"))
  :maintainers '(("Ignasi Fosch" . "natx@y10k.ws")))
