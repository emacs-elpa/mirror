;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.6.0"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "82a747a3a139bb238ab857214bf1c72c5690ed6c"
  :revdesc "82a747a3a139"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
