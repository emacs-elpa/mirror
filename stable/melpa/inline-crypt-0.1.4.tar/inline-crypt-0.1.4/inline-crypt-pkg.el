;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inline-crypt" "0.1.4"
  "Simple inline encryption via openssl."
  ()
  :url "https://github.com/Sodel-the-Vociferous/inline-crypt-el"
  :commit "497ce9dc29a8ccac0b6dd6854f5d120514350282"
  :revdesc "497ce9dc29a8"
  :keywords '("crypt")
  :authors '(("Daniel Ralston" . "Wubbulous@gmail.com"))
  :maintainers '(("Daniel Ralston" . "Wubbulous@gmail.com")))
