;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xo" "1.0"
  "XO linter integration with compilation mode."
  ()
  :url "https://github.com/j-em/xo-emacs"
  :commit "47b67eca35a840b9e2ba0fd6126c9471dadbf327"
  :revdesc "47b67eca35a8"
  :keywords '("processes")
  :authors '(("J.A" . "jer.github@gmail.com"))
  :maintainers '(("J.A" . "jer.github@gmail.com")))
