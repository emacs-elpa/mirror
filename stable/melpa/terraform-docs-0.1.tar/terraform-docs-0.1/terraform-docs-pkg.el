;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "terraform-docs" "0.1"
  "Integrate terraform-docs."
  '((emacs "27.1"))
  :url "https://github.com/loispostula/terraform-docs.el"
  :commit "94a78999ec03e66ce49f7343cc8705354e195c3a"
  :revdesc "94a78999ec03"
  :keywords '("terraform" "tools" "docs")
  :authors '(("Lois Postula" . "lois@postu.la"))
  :maintainers '(("Lois Postula" . "lois@postu.la")))
