;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compdef" "0.2"
  "A stupid completion definer."
  '((emacs "24.4"))
  :url "https://gitlab.com/jjzmajic/compdef"
  :commit "8504500246eb02e15e234058bc3d514358770731"
  :revdesc "8504500246eb"
  :keywords '("convenience"))
