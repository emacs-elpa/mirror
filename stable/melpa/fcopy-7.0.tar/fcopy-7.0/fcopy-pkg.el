;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fcopy" "7.0"
  "Funny Copy, set past point HERE then search copy text."
  ()
  :url "https://github.com/ataka/fcopy"
  :commit "f84b7fbe166c9fe5ae256f00a79556247ba3eee6"
  :revdesc "f84b7fbe166c"
  :keywords '("convenience")
  :authors '(("Masayuki Ataka" . "masayuki.ataka@gmail.com"))
  :maintainers '(("Masayuki Ataka" . "masayuki.ataka@gmail.com")))
