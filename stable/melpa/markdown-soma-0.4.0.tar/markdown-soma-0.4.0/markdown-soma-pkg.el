;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-soma" "0.4.0"
  "Live preview for Markdown."
  '((emacs "25")
    (s     "1.11.0")
    (dash  "2.19.1")
    (f     "0.20.0"))
  :url "https://github.com/jasonm23/markdown-soma"
  :commit "a80ed319a835efeaf7d71f49df0be143939bcc13"
  :revdesc "a80ed319a835"
  :keywords '("wp" "docs" "text" "markdown")
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
