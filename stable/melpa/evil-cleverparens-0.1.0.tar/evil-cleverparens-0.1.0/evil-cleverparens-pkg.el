;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-cleverparens" "0.1.0"
  "Evil friendly minor-mode for editing lisp."
  '((evil        "1.0")
    (paredit     "1")
    (paxedit     "1.1.4")
    (drag-stuff  "0.1.0")
    (smartparens "1.6.1"))
  :url "https://github.com/luxbock/evil-cleverparens"
  :commit "13c63fac85f7bb998e2109550c2d28d18de6ac48"
  :revdesc "13c63fac85f7"
  :keywords '("cleverparens" "parentheses" "evil" "paredit" "smartparens")
  :authors '(("Olli Piepponen" . "opieppo@gmail.com"))
  :maintainers '(("Olli Piepponen" . "opieppo@gmail.com")))
