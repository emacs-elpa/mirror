;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shannon-max" "0.1.1"
  "Analyze your keybindings with information theory."
  '((emacs "29.1"))
  :url "https://github.com/sstraust/shannonmax"
  :commit "9ebeddb9e0fe4958a2347288d3860097a331a77c"
  :revdesc "9ebeddb9e0fe"
  :authors '(("Sam Straus" . "sam_straus@alumni.brown.edu"))
  :maintainers '(("Sam Straus" . "sam_straus@alumni.brown.edu")))
