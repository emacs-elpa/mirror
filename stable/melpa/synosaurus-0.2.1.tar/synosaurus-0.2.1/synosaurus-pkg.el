;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "synosaurus" "0.2.1"
  "An Emacs frontend for thesauri."
  '((cl-lib "0.5"))
  :url "https://github.com/hpdeifel/synosaurus"
  :commit "690755ce88a50e65ab0441ce9aabe6341aae3964"
  :revdesc "v0.2.1-0-g690755ce88a5"
  :keywords '("wp")
  :authors '(("Hans-Peter Deifel" . "hpd@hpdeifel.de"))
  :maintainers '(("Hans-Peter Deifel" . "hpd@hpdeifel.de")))
