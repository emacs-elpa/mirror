;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "take-off" "0.0.1"
  "Remote Emacs Web Access."
  '((emacs      "24.3")
    (web-server "0.1.0"))
  :url "https://github.com/tburette/take-off"
  :commit "dc71fa5bf5763a0c57e15a982bd78b53dda5195f"
  :revdesc "dc71fa5bf576"
  :authors '(("Thomas Burette" . "burettethomas@gmail.com"))
  :maintainers '(("Thomas Burette" . "burettethomas@gmail.com")))
