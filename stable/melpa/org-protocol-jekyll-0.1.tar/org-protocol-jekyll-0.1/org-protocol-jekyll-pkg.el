;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-protocol-jekyll" "0.1"
  "Jekyll's handler for org-protocol."
  ()
  :url "https://github.com/vonavi/org-protocol-jekyll"
  :commit "c1ac46793eb9bf22b1a601e841947428be5c9766"
  :revdesc "c1ac46793eb9"
  :authors '(("Vladimir S. Ivanov" . "ivvl82@gmail.com"))
  :maintainers '(("Vladimir S. Ivanov" . "ivvl82@gmail.com")))
