;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smlfmt" "0.1.0"
  "Format SML source code using the \"smlfmt\" program."
  '((emacs       "24")
    (reformatter "0.4"))
  :url "https://github.com/diku-dk/smlfmt.el"
  :commit "b36ee4400a8b6d02e7b54bf9a88d3feb9a272bf9"
  :revdesc "b36ee4400a8b"
  :keywords '("files" "tools")
  :authors '(("Troels Henriksen" . "athas@sigkill"))
  :maintainers '(("Troels Henriksen" . "athas@sigkill")))
