;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "translate-mode" "1.0.2"
  "Paragraph-oriented side-by-side doc translation workflow."
  '((emacs "24.3"))
  :url "https://github.com/rayw000/translate-mode"
  :commit "fb73b3d928a8011a21402e2c14aa4aab56bd05ae"
  :revdesc "fb73b3d928a8"
  :keywords '("translate" "convenience" "editing")
  :authors '(("Ray Wang" . "rayw.public@gmail.com"))
  :maintainers '(("Ray Wang" . "rayw.public@gmail.com")))
