;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-gist" "0.3"
  "Org mode exporter for GitHub gists."
  '((emacs "26.1")
    (gist  "1.4.0")
    (s     "1.12.0"))
  :url "https://github.com/punchagan/org2gist/"
  :commit "69a47cbb965e777a27184ebbadc047ec20da8e01"
  :revdesc "69a47cbb965e"
  :keywords '("org" "lisp" "gist" "github")
  :authors '(("Puneeth Chaganti" . "punchagan+emacs@muse-amuse.in"))
  :maintainers '(("Puneeth Chaganti" . "punchagan+emacs@muse-amuse.in")))
