;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "surround" "1.0.3"
  "Easily add/delete/change parens, quotes, and more."
  '((emacs "24.3"))
  :url "https://github.com/mkleehammer/surround"
  :commit "5c6e4ba9a4540fbcebfe6d21363179a15bc4ee9e"
  :revdesc "5c6e4ba9a454"
  :authors '(("Michael Kleehammer" . "michael@kleehammer.com"))
  :maintainers '(("Michael Kleehammer" . "michael@kleehammer.com")))
