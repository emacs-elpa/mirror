;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pycarddavel" "1.0.1"
  "Integrate pycarddav."
  '((helm  "1.7.0")
    (emacs "24.0"))
  :url "https://github.com/DamienCassou/pycarddavel"
  :commit "6ead921066fa0156f20155b7126e5875ce11c328"
  :revdesc "6ead921066fa"
  :keywords '("helm" "pyccarddav" "carddav" "message" "mu4e" "contacts")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
