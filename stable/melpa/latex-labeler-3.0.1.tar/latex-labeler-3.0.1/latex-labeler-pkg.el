;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-labeler" "3.0.1"
  "Simplify equation labeling in LaTeX."
  '((emacs "28.1"))
  :url "https://github.com/X9hRRDys/latex-labeler"
  :commit "afb5b514b19ac3ee8d4b02de9f943ec34c6e2f63"
  :revdesc "afb5b514b19a"
  :keywords '("tools"))
