;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multi-run" "1"
  "Manage multiple terminals and run commands on them."
  '((emacs         "24")
    (window-layout "1.4"))
  :url "https://www.github.com/sagarjha/multi-run"
  :commit "87d9eed414999fd94685148d39e5308c099e65ca"
  :revdesc "87d9eed41499"
  :keywords '("tools" "terminals"))
