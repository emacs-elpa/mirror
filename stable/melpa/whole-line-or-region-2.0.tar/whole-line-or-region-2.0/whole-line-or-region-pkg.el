;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whole-line-or-region" "2.0"
  "Operate on current line if region undefined."
  '((emacs  "24.1")
    (cl-lib "0.6"))
  :url "https://github.com/purcell/whole-line-or-region"
  :commit "4189d03cfda752f04364e2abc0117080ed4112cd"
  :revdesc "4189d03cfda7"
  :keywords '("convenience" "wp")
  :authors '(("Joe Casadonte" . "emacs@northbound-train.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
