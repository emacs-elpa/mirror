;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-scratch" "0.0.1"
  "*scratch* buffer for Go."
  '((go-mode "1.3.1")
    (emacs   "24"))
  :url "https://github.com/shosti/go-scratch.el"
  :commit "3f68cbcce04f59eb8e83af109164731ec0454be0"
  :revdesc "3f68cbcce04f"
  :keywords '("languages" "go")
  :authors '(("Emanuel Evans" . "mail@emanuel.industries"))
  :maintainers '(("Emanuel Evans" . "mail@emanuel.industries")))
