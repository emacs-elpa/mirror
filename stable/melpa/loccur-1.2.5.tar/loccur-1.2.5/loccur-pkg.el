;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loccur" "1.2.5"
  "Perform an occur-like folding in current buffer."
  '((emacs "25.1"))
  :url "https://github.com/fourier/loccur"
  :commit "2120345933a1617cc5359dabd7636fd3479441bf"
  :revdesc "2120345933a1"
  :keywords '("matching")
  :authors '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com"))
  :maintainers '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com")))
