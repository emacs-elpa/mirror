;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comint-hyperlink" "0.1.6"
  "Create hyperlinks in comint for SGR URL control sequences."
  '((emacs "24.3"))
  :url "https://github.com/matthewbauer/comint-hyperlink"
  :commit "a7878825788ff6b9d6b8a5adf0214a028bad895e"
  :revdesc "a7878825788f"
  :keywords '("comint" "shell" "processes" "hypermedia" "terminals")
  :authors '(("Matthew Bauer" . "mjbauer95@gmail.com"))
  :maintainers '(("Matthew Bauer" . "mjbauer95@gmail.com")))
