;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "archive-phar" "1.24.1"
  "Phar file support for archive-mode."
  '((emacs           "28.1")
    (php-runtime     "0.2")
    (datetime-format "0.0.1"))
  :url "https://github.com/emacs-php/archive-phar.el"
  :commit "0bda3e338446d06dbe9d8c8837dee746de48632f"
  :revdesc "0bda3e338446"
  :keywords '("files")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
