;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-skk" "0.1"
  "[No description available]."
  '((ddskk "20150912.1820"))
  :url "https://github.com/tsukimizake/ido-skk"
  :commit "674002515d2f4633fe8ff6638f869e0d903f04bf"
  :revdesc "674002515d2f"
  :keywords '("languages")
  :authors '(("tsukimizake" . "shomasd_at_gmail.com"))
  :maintainers '(("tsukimizake" . "shomasd_at_gmail.com")))
