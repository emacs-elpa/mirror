;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "challenger-deep-theme" "0.0.2"
  "Orbit Theme."
  '((emacs "24"))
  :url "https://github.com/MaxSt/challenger-deep"
  :commit "a0aa1fc5442a357d0dcd6fccaf34de4b7aa77c14"
  :revdesc "a0aa1fc5442a")
