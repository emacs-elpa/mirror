;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "burly" "0.3"
  "Save and restore frame/window configurations with buffers."
  '((emacs "27.1")
    (map   "2.1"))
  :url "https://github.com/alphapapa/burly.el"
  :commit "3397eb2599bf76de1b96563e5a9201550e33a810"
  :revdesc "v0.3-0-g3397eb2599bf"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
