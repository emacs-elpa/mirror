;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "0.2.3"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "15594c3348ed7febef31f99d709b128f267035eb"
  :revdesc "15594c3348ed"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
