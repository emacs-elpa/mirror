;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-modern" "0.0.3"
  "Ports of color-theme themes to deftheme."
  ()
  :url "https://github.com/emacs-jp/replace-colorthemes"
  :commit "4f7da6f955f7c584c5dfab2dc170f9a3debd80f8"
  :revdesc "4f7da6f955f7"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
