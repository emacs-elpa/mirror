;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "0.0.1"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "5bf641ce2963eba2cd2d43f838b30071185eb223"
  :revdesc "5bf641ce2963"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
