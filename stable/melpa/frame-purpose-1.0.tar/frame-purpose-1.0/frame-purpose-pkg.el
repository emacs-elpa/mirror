;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frame-purpose" "1.0"
  "Purpose-specific frames."
  '((emacs           "25.1")
    (dash            "2.12")
    (dash-functional "1.2.0"))
  :url "https://github.com/alphapapa/frame-purpose.el"
  :commit "60778ef3c02cb09a7ccc323732c89bf374dfbffe"
  :revdesc "1.0-0-g60778ef3c02c"
  :keywords '("buffers" "convenience" "frames")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
