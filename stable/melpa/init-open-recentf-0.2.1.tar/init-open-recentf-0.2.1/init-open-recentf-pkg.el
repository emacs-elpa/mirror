;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "init-open-recentf" "0.2.1"
  "Invoke a command immediately after startup."
  '((emacs "24.4"))
  :url "https://github.com/zonuexe/init-open-recentf.el"
  :commit "369304d6adb6875948c4534419c4f303ac23c4f6"
  :revdesc "369304d6adb6"
  :keywords '("files" "recentf" "after-init-hook")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
