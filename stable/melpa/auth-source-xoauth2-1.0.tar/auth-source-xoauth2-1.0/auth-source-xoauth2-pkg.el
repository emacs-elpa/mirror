;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auth-source-xoauth2" "1.0"
  "Integrate auth-source with XOAUTH2."
  '((emacs "26.1"))
  :url "https://github.com/ccrusius/auth-source-xoauth2"
  :commit "5e646a32c9ba31a015a09fce1ad711b85717119a"
  :revdesc "v1.0-0-g5e646a32c9ba"
  :authors '(("Cesar Crusius" . "ccrusius@google.com"))
  :maintainers '(("Cesar Crusius" . "ccrusius@google.com")))
