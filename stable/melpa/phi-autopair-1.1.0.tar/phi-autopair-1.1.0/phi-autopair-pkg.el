;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-autopair" "1.1.0"
  "Another simple-minded autopair implementation."
  '((paredit "20"))
  :url "http://hins11.yu-yake.com/"
  :commit "5685b9541c4c9d4cc8a892743fdf245aceea1682"
  :revdesc "5685b9541c4c")
