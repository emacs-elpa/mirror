;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fontify-face" "1.1.0"
  "Fontify symbols representing faces with that face."
  '((emacs "24"))
  :url "https://github.com/Fuco1/fontify-face"
  :commit "fc3325c98427523d86f0b411e0515cec51ac3d8a"
  :revdesc "fc3325c98427"
  :keywords '("faces")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
