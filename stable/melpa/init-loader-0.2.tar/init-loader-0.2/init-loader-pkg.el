;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "init-loader" "0.2"
  "Loader for configuration files."
  ()
  :url "https://github.com/emacs-jp/init-loader/"
  :commit "128ee76adbf431f0b8c30a3a29cb20c9c5100cde"
  :revdesc "128ee76adbf4"
  :authors '(("IMAKADO" . "ken.imakado@gmail.com"))
  :maintainers '(("IMAKADO" . "ken.imakado@gmail.com")))
