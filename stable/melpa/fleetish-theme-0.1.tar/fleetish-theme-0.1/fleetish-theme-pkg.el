;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fleetish-theme" "0.1"
  "A take on the JetBrains Fleet theme."
  '((emacs "24"))
  :url "https://github.com/nylar/fleetish-emacs-theme.el"
  :commit "f1c20b306c84e80b8a961ac44806384f78a2dd59"
  :revdesc "f1c20b306c84"
  :authors '(("Scott Raine" . "scott@raine.sh"))
  :maintainers '(("Scott Raine" . "scott@raine.sh")))
