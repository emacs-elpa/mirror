;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-indirect-region-latex" "20161125.1740"
  "Edit regions of latex in separate buffers especially for english grammar cheker."
  '((emacs "24.3"))
  :url "https://github.com/niitsuma/edit-indirect-region-latex"
  :commit "cf246d409e06d627b5e0d627628c39f8293ca7af"
  :revdesc "cf246d409e06"
  :authors '(("Hirotaka Niitsuma" . "hirotaka.niitsuma@gmail.com"))
  :maintainers '(("Hirotaka Niitsuma" . "hirotaka.niitsuma@gmail.com")))
