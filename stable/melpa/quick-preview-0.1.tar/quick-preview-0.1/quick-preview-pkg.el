;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-preview" "0.1"
  "Quick preview using GNOME sushi, gloobus or quick look."
  ()
  :url "https://github.com/myuhe/quick-preview.el"
  :commit "3ca3b7513c19dcf101749f8652c7d993471b9c8d"
  :revdesc "3ca3b7513c19"
  :keywords '("files" "hypermedia")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
