;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dedicated" "1.0.0"
  "A very simple minor mode for dedicated buffers."
  ()
  :url "https://github.com/emacsorphanage/dedicated"
  :commit "8275fb672f9cc4ba6682ebda0ef91db827e32992"
  :revdesc "1.0.0-0-g8275fb672f9c"
  :keywords '("dedicated" "buffer")
  :authors '(("Eric Crampton" . "eric@atdesk.com"))
  :maintainers '(("Eric Crampton" . "eric@atdesk.com")))
