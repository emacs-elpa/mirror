;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-tbdiff" "1.2.0"
  "Magit extension for range diffs."
  '((emacs "26.1")
    (magit "4.0.0"))
  :url "https://github.com/magit/magit-tbdiff"
  :commit "e8219d2db176bfccb1aa485c9ae91743c33ada0e"
  :revdesc "v1.2.0-0-ge8219d2db176"
  :keywords '("vc" "tools")
  :authors '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainers '(("Kyle Meyer" . "kyle@kyleam.com")))
