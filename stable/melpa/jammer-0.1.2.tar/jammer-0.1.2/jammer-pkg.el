;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jammer" "0.1.2"
  "Punish yourself for using Emacs inefficiently."
  ()
  :url "https://depp.brause.cc/jammer"
  :commit "76e006dddd491aecccfcb06939db56f9f7daa56d"
  :revdesc "76e006dddd49"
  :keywords '("games")
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
