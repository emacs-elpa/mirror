;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "3.1.0"
  "Transient user interfaces for various modes."
  '((emacs     "30.1")
    (transient "0.9.0")
    (org       "9.3")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "d5166240f23e4481a32672cd952f7d117c647a0f"
  :revdesc "d5166240f23e"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
