;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "peertube" "0.3.1"
  "Query PeerTube videos in Emacs."
  '((emacs        "25.1")
    (transmission "0.12.1"))
  :url "https://git.sr.ht/~yoctocell/peertube"
  :commit "96b288c9ff95ee8f19dab7e932d44991c8141ee4"
  :revdesc "96b288c9ff95"
  :keywords '("peertube" "multimedia")
  :authors '(("yoctocell" . "public@yoctocell.xyz"))
  :maintainers '(("yoctocell" . "public@yoctocell.xyz")))
