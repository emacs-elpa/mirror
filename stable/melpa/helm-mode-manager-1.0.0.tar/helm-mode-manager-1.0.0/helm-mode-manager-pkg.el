;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-mode-manager" "1.0.0"
  "Select and toggle major and minor modes with helm."
  '((helm "1.5.3"))
  :url "https://github.com/istib/helm-mode-manager"
  :commit "1fc1d65a27bc57d3a5bbd359f3eb77a6353fa4a5"
  :revdesc "1.0.0-0-g1fc1d65a27bc")
