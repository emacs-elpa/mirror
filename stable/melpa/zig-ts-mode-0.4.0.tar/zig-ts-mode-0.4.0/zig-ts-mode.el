;;; zig-ts-mode.el --- Major mode for Zig code -*- lexical-binding: t; -*-

;; Copyright (C) 2023-2026 meowking <mr.meowking@tutamail.com>

;; Author: meowking <mr.meowking@tutamail.com>
;; Homepage: https://codeberg.org/meow_king/zig-ts-mode
;; Keywords: zig languages tree-sitter

;; Package-Version: 0.4.0
;; Package-Revision: 4c03d52bd1e7
;; Package-Requires: ((emacs "30.1"))

;; SPDX-License-Identifier: GPL-3.0-or-later

;; This file is NOT part of Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Provide font-lock, indentation, and navigation for the Zig
;; programming language <https://ziglang.org/>.
;;
;; For the tree-sitter grammar this mode is based on, see
;; <https://github.com/tree-sitter-grammars/tree-sitter-zig/>.

;;; Code:

(require 'treesit)
(require 'seq)
(require 'rx)

(defgroup zig-ts nil
  "Major mode for editing Zig code."
  :link '(url-link "https://codeberg.org/meow_king/zig-ts-mode")
  :link '(url-link "https://ziglang.org")
  :prefix "zig-ts-"
  :group 'languages)

(defcustom zig-ts-indent-offset 4
  "Number of spaces for each indentation step in `zig-ts-mode'."
  :type 'natnum
  :safe 'natnump
  :group 'zig-ts)

(defcustom zig-ts-markdown-enable t
  "Highlight Markdown in doc comments when both Markdown grammars exist.
Requires the `markdown' and `markdown-inline' grammars.  Use
`zig-ts-install-grammars' to install them, then re-enable the mode."
  :type 'boolean
  :safe #'booleanp
  :group 'zig-ts)

(defcustom zig-ts-zig-bin "zig"
  "Path to zig executable."
  :type 'file
  :safe #'stringp)

(defcustom zig-ts-run-optimization-mode "Debug"
  "Optimization mode to run code with."
  :type '(choice (const :tag "Optimizations off and safety on" "Debug")
                 (const :tag "Optimizations on and safety on" "ReleaseSafe")
                 (const :tag "Optimizations on and safety off" "ReleaseFast")
                 (const :tag "Size optimizations on and safety off" "ReleaseSmall"))
  :safe #'stringp)

(defcustom zig-ts-test-optimization-mode "Debug"
  "Optimization mode to run tests with."
  :type '(choice (const :tag "Optimizations off and safety on" "Debug")
                 (const :tag "Optimizations on and safety on" "ReleaseSafe")
                 (const :tag "Optimizations on and safety off" "ReleaseFast")
                 (const :tag "Size optimizations on and safety off" "ReleaseSmall"))
  :safe #'stringp)

(defvar zig-ts--syntax-table
  (let ((table (make-syntax-table)))
    ;; Comments: Zig only has // comments.
    ;;
    ;; 12 means: start of a 2-char comment sequence (1st and 2nd char
    ;; are the same)
    (modify-syntax-entry ?/   ". 12" table)
    (modify-syntax-entry ?\n  ">"    table)

    ;; Strings and Chars
    (modify-syntax-entry ?\"  "\""   table)
    (modify-syntax-entry ?\'  "\""   table)
    (modify-syntax-entry ?\\  "\\"   table) ;; Escape character

    ;; Symbol constituents (variable names)
    (modify-syntax-entry ?_   "_"    table)

    ;; Punctuation / Operators
    ;; These are mostly "." by default, but being explicit is good practice
    (modify-syntax-entry ?+   "."    table)
    (modify-syntax-entry ?-   "."    table)
    (modify-syntax-entry ?=   "."    table)
    (modify-syntax-entry ?%   "."    table)
    (modify-syntax-entry ?&   "."    table)
    (modify-syntax-entry ?|   "."    table)
    (modify-syntax-entry ?^   "."    table)
    (modify-syntax-entry ?!   "."    table)
    (modify-syntax-entry ?@   "."    table)
    (modify-syntax-entry ?~   "."    table)
    (modify-syntax-entry ?<   "."    table)
    (modify-syntax-entry ?>   "."    table)
    (modify-syntax-entry ?*   "."    table) ; Distinct from Rust (no block comments)
    (modify-syntax-entry ?.   "."    table)

    table)
  "Syntax table for `zig-ts-mode'.")

;;;; Font-locking
;;
;;
;; See https://github.com/tree-sitter-grammars/tree-sitter-zig/blob/master/queries/highlights.scm
;;
;; Ideally the font-locking should be aligned with the upstream highlights.scm.

(defconst zig-ts--keywords
  '("asm" "defer" "errdefer" "test" "error" "const" "var"
    "struct" "union" "enum" "opaque"
    "async" "await" "suspend" "nosuspend" "resume"
    "fn"
    "and" "or" "orelse"
    "return"
    "if" "else" "switch"
    "for" "while" "break" "continue"
    "usingnamespace" "export"
    "try" "catch"
    "volatile" "allowzero" "noalias" "addrspace" "align" "callconv" "linksection" "pub"
    "inline" "noinline" "extern" "comptime" "packed" "threadlocal")
  "Zig keywords for tree-sitter font-locking.")

(defconst zig-ts--operators
  '("=" "*=" "*%=" "*|=" "/=" "%=" "+=" "+%=" "+|=" "-=" "-%=" "-|=" "<<=" "<<|=" ">>="
    "&=" "^=" "|=" "!" "~" "-" "-%" "&" "==" "!=" ">" ">=" "<=" "<" "^" "&" "|" "<<" ">>"
    "<<|" "+" "++" "+%" "-%" "+|" "-|" "*" "/" "%" "**" "*%" "*|" "||" ".*" ".?" "?" "..")
  "Zig operators for tree-sitter font-locking.")

(defvar zig-ts--font-lock-feature-list
  '((comment definition)
    (keyword string type)
    (assignment builtin constant escape-sequence label number)
    (bracket delimiter error function operator property variable))
  "`treesit-font-lock-feature-list' for `zig-ts-mode'.")

(defvar zig-ts--font-lock-settings
  (treesit-font-lock-rules
   :language 'zig
   :feature 'bracket
   '((["[" "]" "(" ")" "{" "}"]) @font-lock-bracket-face
     (payload "|" @font-lock-bracket-face))

   :language 'zig
   :feature 'builtin
   '(([(builtin_identifier) "c" "..."]) @font-lock-builtin-face
     (calling_convention "(" _ @font-lock-builtin-face ")")
     (((identifier) @font-lock-builtin-face)
      (:equal "_" @font-lock-builtin-face)))

   :language 'zig
   :feature 'comment
   '((((comment) @font-lock-doc-face)
      (:match "^//\\(?:!\\|/\\(?:[^/]\\|$\\)\\)" @font-lock-doc-face))
     (comment) @font-lock-comment-face)

   :language 'zig
   :feature 'delimiter
   '(([";" "." "," ":" "=>" "->"]) @font-lock-delimiter-face)

   :language 'zig
   :feature 'definition
   '((function_declaration name: (identifier) @font-lock-function-name-face)
     (struct_declaration (container_field
                          name: (identifier) @font-lock-property-name-face))
     (enum_declaration (container_field
                        name: (identifier) @font-lock-property-name-face))
     (union_declaration (container_field
                         name: (identifier) @font-lock-property-name-face))
     (variable_declaration (identifier) @font-lock-type-face
                           "=" [(struct_declaration)
                                (enum_declaration)
                                (union_declaration)
                                (opaque_declaration)])
     (variable_declaration
      :anchor [("const" :anchor (identifier) @font-lock-constant-face)
               ("var" :anchor (identifier) @font-lock-variable-name-face)]))

   :language 'zig
   :feature 'assignment
   '((initializer_list
      (assignment_expression
       left: (field_expression
              "."
              member: (identifier) @font-lock-property-name-face)))
     (variable_declaration (field_expression
                            "."
                            member: (identifier) @font-lock-property-use-face)))

   :language 'zig
   :feature 'function
   '((call_expression function: (identifier) @font-lock-function-call-face)
     (call_expression
      function: (field_expression
                 member: (identifier) @font-lock-function-call-face)))

   :language 'zig
   :feature 'keyword
   `(([,@zig-ts--keywords]) @font-lock-keyword-face)

   :language 'zig
   :feature 'number
   '(([(integer) (float)]) @font-lock-number-face)

   :language 'zig
   :feature 'operator
   `(([,@zig-ts--operators]) @font-lock-operator-face)

   :language 'zig
   :feature 'string
   '(([(character) (string) (multiline_string)]) @font-lock-string-face)

   :language 'zig
   :feature 'type
   '((parameter type: (identifier) @font-lock-type-face)
     (enum_declaration (container_field
                        type: (identifier) @font-lock-type-face))
     ((identifier) @font-lock-type-face
      (:match "\\`\\(?:[A-Z_][a-zA-Z0-9_]*[a-z][a-zA-Z0-9_]*\\|[A-Z_]\\)\\'"
              @font-lock-type-face))
     (([(builtin_type) "anyframe"]) @font-lock-type-face))

   :language 'zig
   :feature 'constant
   '(([(boolean) "null" "unreachable" "undefined"]) @font-lock-constant-face
     ((identifier) @font-lock-constant-face
      (:match "^[A-Z][A-Z_0-9]+$" @font-lock-constant-face)))

   :language 'zig
   :feature 'label
   '((block_label (identifier) @font-lock-constant-face)
     (break_label (identifier) @font-lock-constant-face))

   :language 'zig
   :feature 'property
   '((field_expression "." member: (identifier) @font-lock-property-use-face)
     (call_expression
      function: (field_expression
                 object: (field_expression
                          member: (identifier) @font-lock-property-use-face))))

   :language 'zig
   :feature 'variable
   '((field_initializer "." (identifier) @font-lock-variable-use-face)
     (identifier) @font-lock-variable-use-face)

   :language 'zig
   :feature 'escape-sequence
   :override t
   '((escape_sequence) @font-lock-escape-face)

   :language 'zig
   :feature 'error
   :override t
   '((ERROR) @font-lock-warning-face))
  "`treesit-font-lock-settings' for `zig-ts-mode'.")

;;;; Indentation
;;
;; Tree-sitter indentation rules for Zig
;;
;; Adapted from nvim indentation queries in nvim-treesitter

(defvar zig-ts--indent-rules
  `((zig
     ;; Top-level definitions: column 0
     ((parent-is "source_file") column-0 0)

     ;; Closing delimiters align with the opening construct
     ((node-is ")") parent-bol 0)
     ((node-is "]") parent-bol 0)
     ((node-is "}") parent-bol 0)

     ((parent-is "multiline_string") prev-line 0)

     ((node-is ";") parent-bol 0)

     ((match "else" "if") parent-bol 0)
     ((parent-is "if") parent-bol zig-ts-indent-offset)
     ((parent-is "else") parent-bol zig-ts-indent-offset)

     ((parent-is "while") parent-bol zig-ts-indent-offset)

     ((parent-is "for") parent-bol zig-ts-indent-offset)

     ((parent-is "switch") parent-bol zig-ts-indent-offset)

     ((parent-is "assignment_expression") parent-bol 0)
     ((parent-is "field_expression") parent-bol zig-ts-indent-offset)

     ((parent-is "variable_declaration") parent-bol zig-ts-indent-offset)
     ((parent-is "struct_declaration") parent-bol zig-ts-indent-offset)
     ((parent-is "enum_declaration") parent-bol zig-ts-indent-offset)
     ((parent-is "union_declaration") parent-bol zig-ts-indent-offset)
     ((parent-is "opaque_declaration") parent-bol zig-ts-indent-offset)
     ((parent-is "error_set_declaration") parent-bol zig-ts-indent-offset)
     ((parent-is "container_field") parent-bol zig-ts-indent-offset)
     ((parent-is "initializer_list") parent-bol zig-ts-indent-offset)

     ((parent-is "block") parent-bol zig-ts-indent-offset)
     ((parent-is "arguments") parent-bol zig-ts-indent-offset)
     ((parent-is "parameters") parent-bol zig-ts-indent-offset)

     (no-node parent-bol 0)))
  "`treesit-simple-indent-rules' for `zig-ts-mode'.")

;;;; Find the definition at point (some Emacs commands use this internally)

(defvar zig-ts--defun-type-regexp
  (regexp-opt '("declaration"))
  "Regex matching tree-sitter node types treated as defun-like.
Used as the value of `treesit-defun-type-regexp'.")

(defun zig-ts--imenu-func-name-fn (node)
  "Return appropriate name for the given function NODE.
See `treesit-simple-imenu-settings'."
  (treesit-node-text (treesit-node-child-by-field-name node "name")))

(defun zig-ts--imenu-assign-style-declaration-name-fn (node)
  "Return appropriate name for the given enum NODE.
See `treesit-simple-imenu-settings'."
  (let ((parent-node (treesit-node-parent node)))
    (when (equal (treesit-node-type parent-node) "variable_declaration")
      (treesit-node-text (treesit-node-child parent-node 0 t)))))

(defun zig-ts--imenu-test-name-fn (node)
  "Return appropriate name for the given test NODE.
See `treesit-simple-imenu-settings'."
  (let ((child (treesit-node-child node 0 t)))
    (if (equal (treesit-node-type child) "string")
        (treesit-node-text child)
      (format "test at line %d" (line-number-at-pos (treesit-node-start node))))))

(defun zig-ts--defun-name (node)
  "Return the defun name of NODE.
Return nil if there is no name or if NODE is not a defun node."
  (pcase (treesit-node-type node)
    ("function_declaration" (zig-ts--imenu-func-name-fn node))
    (_ (zig-ts--imenu-assign-style-declaration-name-fn node))))

;;;; Imenu integration

(defvar zig-ts--imenu-settings
  `(("Fn" "\\`function_declaration\\'" nil zig-ts--imenu-func-name-fn)
    ("Enum" "\\`enum_declaration\\'"
     nil zig-ts--imenu-assign-style-declaration-name-fn)
    ("Struct" "\\`struct_declaration\\'"
     nil zig-ts--imenu-assign-style-declaration-name-fn)
    ("Opaque" "\\`opaque_declaration\\'"
     nil zig-ts--imenu-assign-style-declaration-name-fn)
    ("ErrorSet" "\\`error_set_declaration\\'"
     nil zig-ts--imenu-assign-style-declaration-name-fn)
    ("Union" "\\`union_declaration\\'"
     nil zig-ts--imenu-assign-style-declaration-name-fn)
    ("Test" "\\`test_declaration\\'" nil zig-ts--imenu-test-name-fn))
  "Settings for `treesit-simple-imenu' in `zig-ts-mode'.")

;;;; Structured navigation

(defvar zig-ts--thing-settings
  `((zig
     (defun ,(regexp-opt '("function_declaration")))
     (sentence ,(regexp-opt '("variable_declaration"
                              "defer_statement"
                              "expression_statement")))
     (text ,(regexp-opt '("comment" "string" "multiline_string")))
     (comment "comment")))
  "Settings for `treesit-thing-settings' in `zig-ts-mode'.")

;;;; Fill paragraph

(defun zig-ts--syntax-propertize (beg end)
  "Mark Zig multiline string lines between BEG and END as strings."
  (goto-char beg)
  (while (search-forward "\\\\" end t)
    (let ((start (- (point) 2)))
      (when (equal (treesit-node-type (treesit-node-at start))
                   "multiline_string")
        (let ((eol (line-end-position)))
          ;; Quotes and backslashes inside a multiline string are literal.
          (put-text-property start eol 'syntax-table (string-to-syntax "."))
          (put-text-property start (1+ start) 'syntax-table (string-to-syntax "|"))
          (when (< eol (point-max))
            (put-text-property eol (1+ eol) 'syntax-table (string-to-syntax "|"))))
        (goto-char (line-end-position))))))

(defun zig-ts--fill-paragraph (&optional justify)
  "Fill the Zig paragraph at point.
Pass JUSTIFY to the standard filling functions.  Do not reflow code or
multiline strings.  With a Markdown grammar, fill only documentation
paragraphs, leaving headings, tables and code blocks unchanged."
  (let* ((node (treesit-node-at (point)))
         (type (treesit-node-type node))
         (doc-comment-p (and (string= type "comment")
                             (save-excursion
                               (goto-char (treesit-node-start node))
                               (looking-at "//\\(?:!\\|/\\(?:[^/]\\|$\\)\\)"))))
         (multiline-string-p (string= type "multiline_string")))
    (cond
     (multiline-string-p t)
     ((and doc-comment-p (treesit-language-available-p 'markdown))
      (zig-ts--fill-doc-comment node justify)
      t)
     ((equal type "comment") (fill-comment-paragraph justify))
     ;; Like c-ts-common, never let the fallback fill Zig source code.
     (t t))))

(defun zig-ts--fill-doc-comment (comment justify)
  "Fill the Markdown paragraph in COMMENT, honoring JUSTIFY."
  (let* ((bounds (zig-ts--doc-comment-bounds
                  (treesit-node-start comment) (treesit-node-end comment)))
         (groups (zig-ts--doc-comment-ranges (car bounds) (cdr bounds)))
         (ranges (seq-find
                  (lambda (ranges)
                    (<= (caar ranges) (treesit-node-end comment)
                        (cdar (last ranges))))
                  groups))
         (parser (and ranges (treesit-parser-create 'markdown nil t))))
    (when parser
      (unwind-protect
          (progn
            (treesit-parser-set-included-ranges parser ranges)
            (let* ((pos (max (point) (+ (treesit-node-start comment) 3)))
                   (node (treesit-node-at pos parser))
                   (paragraph (treesit-parent-until
                               node (lambda (n)
                                      (equal (treesit-node-type n) "paragraph")) t)))
              (when paragraph
                (let* ((start (treesit-node-start paragraph))
                       (end (treesit-node-end paragraph))
                       (beg (save-excursion (goto-char start) (line-beginning-position)))
                       (prefix (buffer-substring-no-properties beg start))
                       ;; A list's marker belongs only to its first line.
                       (fill-prefix
                        (replace-regexp-in-string
                         "\\(?:[-+*]\\|[0-9]+[.)]\\)[ \t]+\\'"
                         (lambda (s) (make-string (string-width s) ?\s)) prefix)))
                  ;; Preserve explicit Markdown hard line breaks.
                  (unless (string-match-p "\\(?:  \\|\\\\\\)\n"
                                          (buffer-substring-no-properties start end))
                    (let* ((inline (treesit-node-child paragraph 0 t))
                           ;; Remove only grammar-recognized continuation
                           ;; markers, not literal `>' characters in prose.
                           (parts (zig-ts--markdown-node-ranges inline ranges))
                           (text (concat
                                  (mapconcat
                                   (lambda (range)
                                     (buffer-substring-no-properties (car range) (cdr range)))
                                   parts "")
                                  (buffer-substring-no-properties (treesit-node-end inline) end)))
                           (lines (split-string text "\n"))
                           (normalized
                            (concat prefix (car lines)
                                    (mapconcat
                                     (lambda (line)
                                       (concat "\n" (unless (string-empty-p line) fill-prefix) line))
                                     (cdr lines) "")))
                           (end-marker (copy-marker end t)))
                      (unwind-protect
                          (save-excursion
                            (atomic-change-group
                              (replace-region-contents beg end (lambda () normalized))
                              (fill-region-as-paragraph beg end-marker justify nil start)))
                        (set-marker end-marker nil))))))))
        (treesit-parser-delete parser)))))

;;;; Comment continuation (M-j)

(defun zig-ts--comment-indent-new-line (&optional soft)
  "Break line at point and indent, continuing comment if within one.
SOFT works the same as in `comment-indent-new-line'."
  (let* ((pos (point))
         (state (syntax-ppss))
         (prefix
          (save-excursion
            (cond
             ((nth 4 state)
              (goto-char (nth 8 state))
              (when (looking-at (rx "//" (* (any "/!")) (* blank)))
                (cons (current-column) (match-string-no-properties 0))))
             ((and (nth 3 state)
                   (equal (treesit-node-type
                           (treesit-node-at (max (point-min) (1- pos))))
                          "multiline_string"))
              (goto-char (nth 8 state))
              (when (looking-at (rx "\\\\" (* blank)))
                (cons (current-column) (match-string-no-properties 0))))))))
    (delete-horizontal-space)
    (if soft (insert-and-inherit ?\n) (newline 1))
    (if prefix
        (progn (indent-to (car prefix)) (insert (cdr prefix)))
      (indent-according-to-mode))))

;;;; Pre-check

(defconst zig-ts-grammar-recipes
  '((zig . ("https://github.com/tree-sitter-grammars/tree-sitter-zig")))
  "Tree-sitter grammar recipes for Zig.
Each entry is a list of (LANG . (URL REVISION SOURCE-DIR)).  Suitable
for use as the value of `treesit-language-source-alist'.")

(defun zig-ts-install-grammars (&optional force)
  "Install Zig and enabled optional grammars if not already available.

When `zig-ts-markdown-enable' is non-nil, also install the Markdown
grammars used for doc comments.

With prefix argument FORCE, reinstall grammars even if they are already
installed.  This is useful after upgrading `zig-ts-mode' to a version that
requires a newer grammar."
  (interactive "P")
  (let ((recipes
         (append zig-ts-grammar-recipes
                 (when zig-ts-markdown-enable
                   '((markdown . ("https://github.com/tree-sitter-grammars/tree-sitter-markdown"
                                  "split_parser" "tree-sitter-markdown/src"))
                     (markdown-inline . ("https://github.com/tree-sitter-grammars/tree-sitter-markdown"
                                         "split_parser" "tree-sitter-markdown-inline/src")))))))
    (zig-ts--install-grammars recipes force)))

(defun zig-ts--install-grammars (recipes &optional force)
  "Install missing grammars from RECIPES, or reinstall them with FORCE."
  (dolist (recipe recipes)
    (let ((grammar (car recipe)))
      (when (or force (not (treesit-language-available-p grammar)))
        (message "Installing %s tree-sitter grammar..." grammar)
        ;; Make `treesit-install-language-grammar' pick up the grammar
        ;; recipes without modifying user's configuration
        (let ((treesit-language-source-alist recipes))
          (treesit-install-language-grammar grammar))))))

;;;; Markdown doc comments

(defvar-local zig-ts--markdown-parsers nil
  "Parser groups, each (BLOCK-PARSER INLINE-PARSERS CONTENT-RANGES).")

(defvar-local zig-ts--markdown-tick nil
  "Modification tick, requested bounds and feature state of the last update.")

(defun zig-ts--doc-comment-bounds (beg end &optional _old-len)
  "Expand BEG and END to include adjacent documentation comment lines.
Also suitable for `font-lock-extend-after-change-region-function'."
  (save-excursion
    (goto-char beg)
    (beginning-of-line)
    (while (and (> (point) (point-min))
                (save-excursion
                  (forward-line -1)
                  (looking-at "[ \t]*//\\(?:!\\|/\\(?:[^/]\\|$\\)\\)")))
      (forward-line -1))
    (setq beg (point))
    (goto-char end)
    (forward-line 1)
    (while (and (not (eobp))
                (looking-at "[ \t]*//\\(?:!\\|/\\(?:[^/]\\|$\\)\\)"))
      (forward-line 1))
    (cons beg (point))))

(defun zig-ts--doc-comment-ranges (&optional beg end)
  "Return content ranges grouped by consecutive documentation comments.
Exclude comment prefixes and one optional space following each prefix."
  (let (groups ranges previous-end previous-kind)
    (dolist (capture (treesit-query-capture
                      (treesit-parser-root-node treesit-primary-parser)
                      '((comment) @comment) (or beg (point-min)) (or end (point-max))))
      (let* ((node (cdr capture))
             (beg (treesit-node-start node))
             (end (treesit-node-end node))
             (text (treesit-node-text node t)))
        (when (string-match-p "\\`//\\(?:!\\|/\\(?:[^/]\\|$\\)\\)" text)
          (let ((kind (substring text 0 3)))
            (unless (and previous-end (equal previous-kind kind)
                         (string-match-p
                          "\\`[ \t]*\n[ \t]*\\'"
                          (buffer-substring-no-properties previous-end beg)))
              (when ranges (push (nreverse ranges) groups))
              (setq ranges nil))
            (let ((start (+ beg 3)))
              (when (eq (char-after start) ?\s) (setq start (1+ start)))
              ;; Preserve newlines so Markdown sees paragraphs and fences.
              (when (< start (min (point-max) (1+ end)))
                (push (cons start (min (point-max) (1+ end))) ranges)))
            (setq previous-kind kind previous-end end)))))
    (when ranges (push (nreverse ranges) groups))
    (nreverse groups)))

(defun zig-ts--markdown-node-ranges (node ranges)
  "Intersect NODE with RANGES, excluding its named children."
  (let ((beg (treesit-node-start node))
        (end (treesit-node-end node))
        result)
    (dolist (range ranges)
      (let ((lo (max beg (car range))) (hi (min end (cdr range))))
        (when (< lo hi) (push (cons lo hi) result))))
    (setq result (nreverse result))
    (dolist (child (treesit-node-children node t))
      (let ((lo (treesit-node-start child))
            (hi (treesit-node-end child))
            remaining)
        (dolist (range result)
          (if (or (<= hi (car range)) (>= lo (cdr range)))
              (push range remaining)
            (when (< (car range) lo) (push (cons (car range) lo) remaining))
            (when (< hi (cdr range)) (push (cons hi (cdr range)) remaining))))
        (setq result (nreverse remaining))))
    result))

(defun zig-ts--markdown-update-ranges (beg end)
  "Update Markdown parsers for documentation intersecting BEG through END.
Each comment block and each inline region has its own parser, so
unfinished markup cannot cross independent documentation blocks.
Parsers outside the requested region are released, not kept for the
entire file.  Expand the region to preserve complete comment blocks."
  (let* ((bounds (zig-ts--doc-comment-bounds beg end))
         (enabled (seq-some
                   (lambda (setting)
                     ;; Emacs 30 documents the list representation;
                     ;; Emacs 31 provides public field accessors.
                     (if (and (fboundp 'treesit-font-lock-setting-feature)
                              (fboundp 'treesit-font-lock-setting-enable))
                         (and (eq (treesit-font-lock-setting-feature setting) 'doc-markup)
                              (eq (treesit-font-lock-setting-enable setting) t))
                       (and (eq (nth 2 setting) 'doc-markup)
                            (eq (nth 1 setting) t))))
                   treesit-font-lock-settings))
         (tick (list (buffer-chars-modified-tick) bounds enabled)))
    (unless (equal tick zig-ts--markdown-tick)
      (let ((old zig-ts--markdown-parsers) groups)
        (dolist (ranges (and enabled
                            (zig-ts--doc-comment-ranges (car bounds) (cdr bounds))))
          (let* ((entry (pop old))
                 (block (or (car entry) (treesit-parser-create 'markdown nil t)))
                 (old-inline (cadr entry))
                 inline)
            (treesit-parser-set-included-ranges block ranges)
            (dolist (capture (treesit-query-capture
                              (treesit-parser-root-node block) '((inline) @inline)))
              (when-let* ((parts (zig-ts--markdown-node-ranges (cdr capture) ranges)))
                (let ((parser (or (pop old-inline)
                                  (treesit-parser-create 'markdown-inline nil t))))
                  (treesit-parser-set-included-ranges parser parts)
                  (push parser inline))))
            (mapc #'treesit-parser-delete old-inline)
            (push (list block (nreverse inline) ranges) groups)))
        (dolist (entry old)
          (mapc #'treesit-parser-delete (cons (car entry) (cadr entry))))
        (setq zig-ts--markdown-parsers (nreverse groups)
              zig-ts--markdown-tick tick)))))

(defun zig-ts--markdown-fontify (node override beg end &rest _)
  "Fontify Markdown NODE between BEG and END with OVERRIDE.
Clip faces to included ranges to leave Zig comment prefixes untouched."
  (let ((face (pcase (treesit-node-type node)
                ((or "atx_heading" "setext_heading" "strong_emphasis") 'bold)
                ("emphasis" 'italic)
                ((or "link_text" "link_destination" "uri_autolink" "link_label") 'link)
                (_ 'font-lock-doc-markup-face))))
    (dolist (range (treesit-parser-included-ranges (treesit-node-parser node)))
      (let ((start (max beg (car range) (treesit-node-start node)))
            (stop (min end (cdr range) (treesit-node-end node))))
        (when (< start stop)
          (treesit-fontify-with-override start stop face override))))))

(defun zig-ts--markdown-setup ()
  "Enable optional Markdown fontification using public tree-sitter APIs."
  (when (and zig-ts-markdown-enable
             (treesit-language-available-p 'markdown)
             (treesit-language-available-p 'markdown-inline))
    ;; Editing, indentation and defun navigation remain owned by Zig.
    (setq-local treesit-language-at-point-function (lambda (_pos) 'zig))
    ;; A block may have no live parser after scrolling away.  Invalidate
    ;; its entire text after edits even when no parser notifier exists.
    (setq-local font-lock-extend-after-change-region-function
                #'zig-ts--doc-comment-bounds)
    (setq-local treesit-range-settings
                (treesit-range-rules #'zig-ts--markdown-update-ranges))
    (setq-local treesit-font-lock-settings
                (append treesit-font-lock-settings
                        (treesit-font-lock-rules
                         :language 'markdown :feature 'doc-markup :override 'prepend
                         '([(atx_heading) (setext_heading) (fenced_code_block)
                            (indented_code_block) (link_destination) (link_label)]
                           @zig-ts--markdown-fontify)
                         :language 'markdown-inline :feature 'doc-markup :override 'prepend
                         '([(emphasis) (strong_emphasis) (code_span) (link_text)
                            (link_destination) (uri_autolink) (link_label)]
                           @zig-ts--markdown-fontify))))
    (setq-local treesit-font-lock-feature-list
                (copy-tree treesit-font-lock-feature-list))
    (push 'doc-markup (nth 2 treesit-font-lock-feature-list))))

(defvar zig-ts--grammar-compatibility-checked nil
  "Non-nil if grammar compatibility has already been checked this session.")

(defun zig-ts--check-grammar-compatibility ()
  "Check whether installed grammars are compatible with current `zig-ts-mode'.
Emit a warning if an outdated grammar is detected."
  (unless zig-ts--grammar-compatibility-checked
    (setq zig-ts--grammar-compatibility-checked t)
    (when (treesit-language-available-p 'zig)
      (condition-case nil
          ;; old tree-sitter use ValDecl
          (treesit-query-compile 'zig '((variable_declaration)) t)
        (error
         (display-warning
          'zig
          (format "The installed `%s' grammar does not appear to be from \
tree-sitter-grammars.  Run C-u M-x zig-ts-install-grammars to reinstall."
                  'zig)))))))

;;;; CLI commands
;;
;; copied from zig-mode

(defun zig-ts--buffer-file-name ()
  "Return the local part of the visited file name, or signal a user error."
  (unless buffer-file-name
    (user-error "This buffer is not visiting a file"))
  (file-local-name buffer-file-name))

(defun zig-ts--run-cmd (cmd &optional source &rest args)
  "Use compile command to execute a zig CMD with ARGS if given.
If given a SOURCE, execute the CMD on it."
  (let ((cmd-args (if source (cons source args) args)))
    (save-some-buffers)
    (compilation-start (mapconcat 'shell-quote-argument
                                  `(,zig-ts-zig-bin ,cmd ,@cmd-args)
                                  " "))))

(defun zig-ts-build ()
  "Compile using `zig build`."
  (interactive)
  (zig-ts--run-cmd "build"))

(defun zig-ts-build-exe ()
  "Create executable from source or object file."
  (interactive)
  (zig-ts--run-cmd "build-exe" (zig-ts--buffer-file-name)))

(defun zig-ts-build-lib ()
  "Create library from source or assembly."
  (interactive)
  (zig-ts--run-cmd "build-lib" (zig-ts--buffer-file-name)))

(defun zig-ts-build-obj ()
  "Create object from source or assembly."
  (interactive)
  (zig-ts--run-cmd "build-obj" (zig-ts--buffer-file-name)))

(defun zig-ts-test ()
  "Test buffer using `zig test`."
  (interactive)
  (zig-ts--run-cmd "test" (zig-ts--buffer-file-name) "-O" zig-ts-test-optimization-mode))

(defun zig-ts-run ()
  "Create an executable from the current buffer and run it immediately."
  (interactive)
  (zig-ts--run-cmd "run" (zig-ts--buffer-file-name) "-O" zig-ts-run-optimization-mode))

;;;; Major mode definitions

(defvar-keymap zig-ts-mode-map
  :doc "Keymap for `zig-ts-mode'."
  "C-c C-b C-b" #'zig-ts-build
  "C-c C-b C-e" #'zig-ts-build-exe
  "C-c C-b C-l" #'zig-ts-build-lib
  "C-c C-b C-o" #'zig-ts-build-obj
  "C-c C-r" #'zig-ts-run
  "C-c C-t" #'zig-ts-test)

;;;###autoload
(define-derived-mode zig-ts-mode prog-mode "Zig"
  "Major mode for editing Zig, powered by tree-sitter."
  :group 'zig-ts
  :syntax-table zig-ts--syntax-table

  (setq-local indent-tabs-mode nil)

  (when-let* ((missing (seq-filter (lambda (r)
                                     (not (treesit-language-available-p (car r))))
                                   zig-ts-grammar-recipes)))
    (when (y-or-n-p "Zig tree-sitter grammars are not installed yet.  Install now?")
      (zig-ts--install-grammars missing)))

  ;; Warn if installed grammars are outdated
  (zig-ts--check-grammar-compatibility)

  ;; Compile
  (setq-local compile-command (concat (shell-quote-argument zig-ts-zig-bin) " build"))

  ;; Comment
  (setq-local comment-start "// ")
  (setq-local comment-end "")
  (setq-local comment-start-skip (rx (group (seq "/" (+ "/") (? "!")))
                                     (* (syntax whitespace))))
  (setq-local comment-end-skip (rx (* (syntax whitespace))
                                   (group (syntax comment-end))))
  (setq-local comment-line-break-function #'zig-ts--comment-indent-new-line)

  ;; Electric indentation on delimiters
  (setq-local electric-indent-chars
              (append "{}()[].,;" electric-indent-chars))

  ;; Fill paragraph
  (setq-local paragraph-start
              (rx (or (seq (* (syntax whitespace))
                           (group (* (seq "/" (+ "/"))))
                           (* (syntax whitespace))
                           eol)
                      "\f")))
  (setq-local paragraph-separate paragraph-start)
  (setq-local adaptive-fill-mode t)

  (when (treesit-ready-p 'zig)
    (setq-local treesit-primary-parser (treesit-parser-create 'zig))

    (setq-local syntax-propertize-function #'zig-ts--syntax-propertize)
    (add-hook 'syntax-propertize-extend-region-functions
              #'syntax-propertize-wholelines nil t)

    ;; Fill paragraph with tree-sitter feature
    (setq-local fill-paragraph-function #'zig-ts--fill-paragraph)

    ;; Font-lock
    (setq-local treesit-font-lock-settings zig-ts--font-lock-settings)
    (setq-local treesit-font-lock-feature-list zig-ts--font-lock-feature-list)

    ;; Indentation
    (setq-local treesit-simple-indent-rules zig-ts--indent-rules)

    ;; Navigation
    (setq-local treesit-simple-imenu-settings zig-ts--imenu-settings)
    (setq-local treesit-thing-settings zig-ts--thing-settings)

    ;; Defun
    (setq-local treesit-defun-name-function #'zig-ts--defun-name)
    (setq-local treesit-defun-type-regexp zig-ts--defun-type-regexp)

    (zig-ts--markdown-setup)
    (treesit-major-mode-setup)))

;;;###autoload
(add-to-list 'auto-mode-alist '("\\.\\(zig\\|zon\\)\\'" . zig-ts-mode))

(provide 'zig-ts-mode)
;;; zig-ts-mode.el ends here
