;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-multi-all-the-icons" "0.7"
  "Affixate `compile-multi' with icons."
  '((emacs                    "28.0")
    (all-the-icons-completion "0.0.1"))
  :url "https://github.com/mohkale/compile-multi"
  :commit "19d16d8871b5f19f5625e1a66c1dc46a7c3f6a3a"
  :revdesc "19d16d8871b5"
  :keywords '("tools" "compile" "build")
  :authors '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("mohsin kaleem" . "mohkale@kisara.moe")))
