;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-quickhelp" "0.5.5"
  "Quickhelp at point for php."
  '((emacs "25.1"))
  :url "https://github.com/vpxyz/php-quickhelp"
  :commit "d5e11b7a6bad64550521e8822139a33218b8c9bb"
  :revdesc "d5e11b7a6bad")
