;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "2.1"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "ae9c747e93ca48443792a59f4f59a4cda96949f2"
  :revdesc "ae9c747e93ca"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
