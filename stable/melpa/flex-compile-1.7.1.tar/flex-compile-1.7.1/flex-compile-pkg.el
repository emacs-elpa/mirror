;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-compile" "1.7.1"
  "Run, evaluate and compile across many languages."
  '((emacs         "26.1")
    (dash          "2.17.0")
    (buffer-manage "1.1"))
  :url "https://github.com/plandes/flex-compile"
  :commit "f15d23afabd03c39583b1a87dd847a91cb7bfe34"
  :revdesc "v1.7.1-0-gf15d23afabd0"
  :keywords '("compilation" "integration" "processes"))
