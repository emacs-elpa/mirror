;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "literate-calc-mode" "0.1"
  "Calc, but as a document."
  ()
  :url "https://github.com/sulami/literate-calc-mode.el"
  :commit "edb42e4c481246cfabcde01c63fddaa968148410"
  :revdesc "edb42e4c4812"
  :keywords '("calc" "languages" "tools"))
