;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "side-notes" "0.4.1"
  "Easy access to a directory notes file."
  '((emacs "24.5"))
  :url "https://github.com/rnkn/side-notes"
  :commit "452378c68b7e95b9e8244d20ace073a0be27ccb2"
  :revdesc "452378c68b7e"
  :keywords '("convenience")
  :authors '(("Paul W. Rankin" . "pwr@bydasein.com"))
  :maintainers '(("Paul W. Rankin" . "pwr@bydasein.com")))
