;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "age" "0.1.9"
  "The Age Encryption Library."
  '((emacs "28.1"))
  :url "https://github.com/anticomputer/age.el"
  :commit "e99165ef5274bc4512b8d77ba2ac208c59b5d456"
  :revdesc "e99165ef5274"
  :keywords '("data")
  :authors '(("Daiki Ueno" . "ueno@unixuser.org")
             ("Bas Alberts" . "bas@anti.computer"))
  :maintainers '(("Bas Alberts" . "bas@anti.computer")))
