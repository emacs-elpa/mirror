;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "howdoi" "0.4.3"
  "Instant coding answers via Emacs."
  ()
  :url "https://github.com/atykhonov/emacs-howdoi/"
  :commit "5ee65c6dc1d83aef37742885c67eddd887173aa4"
  :revdesc "5ee65c6dc1d8"
  :keywords '("howdoi")
  :authors '(("Andrey Tykhonov" . "atykhonovatgmail.com"))
  :maintainers '(("Andrey Tykhonov" . "atykhonov@gmail.com")))
