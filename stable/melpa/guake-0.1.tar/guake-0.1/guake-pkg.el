;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guake" "0.1"
  "Interact with Guake via DBus."
  '((emacs "27.1"))
  :url "https://github.com/juergenhoetzel/emacs-guake"
  :commit "5d2c3c26e19f15c6866ad7bc17649f634171ca90"
  :revdesc "5d2c3c26e19f"
  :keywords '("convenience")
  :authors '(("Jürgen Hötzel" . "juergen.hoetzel@hr.de"))
  :maintainers '(("Jürgen Hötzel" . "juergen.hoetzel@hr.de")))
