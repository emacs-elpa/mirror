;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "1.0"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "97f2f90ba8c7cdb7eed89866b2e322632bb49391"
  :revdesc "97f2f90ba8c7"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
