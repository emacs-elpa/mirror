;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pt" "0.0.3"
  "A front-end for pt, The Platinum Searcher."
  ()
  :url "https://github.com/bling/pt.el"
  :commit "a539dc11ecb2d69760ff50f76c96f49895ce1e1e"
  :revdesc "a539dc11ecb2"
  :keywords '("pt" "ack" "ag" "grep" "search"))
