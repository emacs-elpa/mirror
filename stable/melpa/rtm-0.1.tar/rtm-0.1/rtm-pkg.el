;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rtm" "0.1"
  "An elisp implementation of the Remember The Milk API."
  '((cl-lib "0.5"))
  :url "https://github.com/pmiddend/emacs-rtm"
  :commit "74cee8f27f34a55b213f3ce1c13f6c565aaedd83"
  :revdesc "74cee8f27f34"
  :keywords '("remember" "the" "milk" "productivity" "todo")
  :authors '(("Friedrich Delgado Friedrichs" . "frie...@nomaden.org"))
  :maintainers '(("Friedrich Delgado Friedrichs" . "frie...@nomaden.org")))
