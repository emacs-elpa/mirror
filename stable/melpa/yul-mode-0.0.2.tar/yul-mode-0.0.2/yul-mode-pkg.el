;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yul-mode" "0.0.2"
  "Major mode for editing Ethereum Yul intermediate code."
  ()
  :url "https://github.com/taquangtrung/emacs-yul-mode"
  :commit "56cba05549873fcf1b66e304969011dc1a1ad228"
  :revdesc "56cba0554987"
  :keywords '("languages"))
