;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-quickhelp-terminal" "0.1.1"
  "Terminal support for `company-quickhelp'."
  '((emacs             "24.4")
    (company-quickhelp "2.2.0")
    (popup             "0.5.3"))
  :url "https://github.com/jcs-elpa/company-quickhelp-terminal"
  :commit "c2e077e8d32610f80a506c410ab51a4ba747a47f"
  :revdesc "c2e077e8d326"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
