;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "theme-changer" "2.3.0"
  "Sunrise/Sunset Theme Changer for Emacs."
  '((cl-lib "0"))
  :url "https://github.com/hadronzoo/theme-changer"
  :commit "2312851b08de2e810c0f51a405b413c039cc8d2f"
  :revdesc "2312851b08de"
  :keywords '("color-theme" "deftheme" "solar" "sunrise" "sunset")
  :authors '(("Joshua B. Griffith" . "josh.griffith@gmail.com"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
