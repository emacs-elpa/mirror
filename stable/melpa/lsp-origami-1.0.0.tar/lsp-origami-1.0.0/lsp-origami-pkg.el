;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-origami" "1.0.0"
  "Origami.el support for lsp-mode."
  '((origami  "1.0")
    (lsp-mode "6.1"))
  :url "https://github.com/emacs-lsp/lsp-origami"
  :commit "110c40eafde81179ec7a78aab94b0b2059689374"
  :revdesc "110c40eafde8"
  :keywords '("languages" "lsp-mode"))
