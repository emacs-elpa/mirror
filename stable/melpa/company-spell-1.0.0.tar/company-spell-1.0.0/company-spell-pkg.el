;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-spell" "1.0.0"
  "Autocompleting spelling for Company."
  '((emacs "24.4"))
  :url "https://enzu.ru"
  :commit "2798cf8730921f43035957462b01183fbee1244a"
  :revdesc "2798cf873092"
  :keywords '("wp"))
