;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-category-capture" "3.1.0"
  "Contextualy capture of org-mode TODOs."
  '((org   "9.0.0")
    (emacs "24"))
  :url "https://github.com/IvanMalison/org-project-capture"
  :commit "214a6068c467323a795b27996c1e7b75ae42dc68"
  :revdesc "214a6068c467"
  :keywords '("org-mode" "todo" "tools" "outlines")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
