;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elogcat" "0.2.0"
  "Logcat interface."
  '((s    "1.9.0")
    (dash "2.10.0"))
  :url "https://github.com/youngker/elogcat.el"
  :commit "f2f19d7ab6b77b8fec55cb67524df629fe967891"
  :revdesc "f2f19d7ab6b7"
  :keywords '("tools")
  :authors '(("Youngjoo Lee" . "youngker@gmail.com"))
  :maintainers '(("Youngjoo Lee" . "youngker@gmail.com")))
