;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gap-mode" "2.2.2"
  "Major mode for editing files in the GAP programming language."
  ()
  :url "https://gitlab.com/gvol/gap-mode"
  :commit "8439c3622e1f9e2ec1a8ef21020eb55e917f4416"
  :revdesc "8439c3622e1f"
  :keywords '("gap")
  :authors '(("Michael Smith" . "smith@pell.anu.edu.au")
             ("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainers '(("Ivan Andrus" . "darthandrus@gmail.com")))
