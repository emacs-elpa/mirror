;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reveal-in-folder" "0.1.2"
  "Reveal current file in folder."
  '((emacs "24.3")
    (f     "0.20.0")
    (s     "1.12.0"))
  :url "https://github.com/jcs-elpa/reveal-in-folder"
  :commit "f62be2d11c8a9182cf84f0efe7ed054cc304262d"
  :revdesc "f62be2d11c8a"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
