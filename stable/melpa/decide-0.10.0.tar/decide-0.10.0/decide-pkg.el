;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "decide" "0.10.0"
  "Rolling dice and other random things."
  ()
  :url "https://github.com/lifelike/decide-mode"
  :commit "cdd1cf76fdf4f08fb9dbe7de25b59af81337cce6"
  :revdesc "cdd1cf76fdf4"
  :authors '(("Pelle Nilsson" . "perni@lysator.liu.se"))
  :maintainers '(("Pelle Nilsson" . "perni@lysator.liu.se")))
