;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slow-keys" "0.1.0"
  "Slow keys mode to avoid RSI."
  '((emacs "24.1"))
  :url "https://github.com/manuel-uberti/slow-keys"
  :commit "9bba1181634f5da66d9cf6ec31af8af39a211697"
  :revdesc "9bba1181634f"
  :keywords '("convenience")
  :authors '(("Manuel Uberti" . "manuel.uberti@inventati.org"))
  :maintainers '(("Manuel Uberti" . "manuel.uberti@inventati.org")))
