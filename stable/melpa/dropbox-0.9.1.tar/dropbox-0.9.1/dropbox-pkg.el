;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dropbox" "0.9.1"
  "Emacs backend for dropbox."
  '((json  "1.2")
    (oauth "1.0.3"))
  :url "https://github.com/pavpanchekha/dropbox.el"
  :commit "ca2ae875355967ac5202c0cc0a9745403d6bdf4e"
  :revdesc "ca2ae8753559"
  :keywords '("dropbox")
  :authors '(("Pavel Panchekha" . "me@pavpanchekha.com"))
  :maintainers '(("Pavel Panchekha" . "me@pavpanchekha.com")))
