;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abs-mode" "1.7"
  "Major mode for the modeling language Abs."
  '((emacs      "26.1")
    (erlang     "2.8")
    (maude-mode "0.3")
    (flymake    "1.0")
    (yasnippet  "0.14.0"))
  :url "https://github.com/abstools/abs-mode"
  :commit "0132032d9317861e63bea865746124accab9db83"
  :revdesc "v1.7-0-g0132032d9317"
  :keywords '("languages")
  :authors '(("Rudi Schlatte" . "rudi@constantly.at"))
  :maintainers '(("Rudi Schlatte" . "rudi@constantly.at")))
