;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-essential-ref" "0.1.1"
  "Cider-doc to \"Clojure, The Essential Reference\"."
  '((emacs "24")
    (cider "0.24.0"))
  :url "https://github.com/p3r7/clojure-essential-ref"
  :commit "e05d61b96f6469a93f52015b7ad5deadf616139e"
  :revdesc "e05d61b96f64")
