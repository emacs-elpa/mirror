;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "textx-mode" "0.0.2"
  "Major mode for editing TextX files."
  '((emacs "24.3"))
  :url "https://github.com/novakboskov/textx-mode"
  :commit "72f9f0c5855b382024f0da8f56833c22a70a5cb3"
  :revdesc "72f9f0c5855b"
  :keywords '("textx")
  :authors '(("Novak Boškov" . "gnovak.boskov@gmail.com"))
  :maintainers '(("Novak Boškov" . "gnovak.boskov@gmail.com")))
