;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borland-blue-theme" "0.1"
  "Blue/yellow theme based on old DOS Borland/Turbo C IDE."
  '((emacs "24.1"))
  :url "https://github.com/fourier/borland-blue-theme"
  :commit "b21afcf774dbcc2c9bb7058b4e246106843d6bfc"
  :revdesc "b21afcf774db"
  :keywords '("themes")
  :authors '(("Alexey Veretennikov" . "alexeydotveretennikovatgmaildotcom"))
  :maintainers '(("Alexey Veretennikov" . "alexeydotveretennikovatgmaildotcom")))
