;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgbox" "0.5.0"
  "Mailbox-like task scheduling Org."
  '((org    "8.0")
    (cl-lib "0.5"))
  :url "https://github.com/yasuhito/orgbox"
  :commit "ecaf5a064431cf92922338c974df8fce1a8f1734"
  :revdesc "0.5.0-0-gecaf5a064431"
  :keywords '("org")
  :authors '(("Yasuhito Takamiya" . "yasuhito@gmail.com"))
  :maintainers '(("Yasuhito Takamiya" . "yasuhito@gmail.com")))
