;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hamburg-theme" "0.1"
  "Color Theme with a dark blue background."
  '((emacs "24"))
  :url "https://github.com/mswift42/hamburg-theme"
  :commit "59ce367c17faa09a4ef199a3f7942d4ab79596eb"
  :revdesc "59ce367c17fa")
