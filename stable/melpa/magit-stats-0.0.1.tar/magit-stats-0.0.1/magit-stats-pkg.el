;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-stats" "0.0.1"
  "Generates GIT Repo Statistics Report."
  '((emacs "24.4"))
  :url "https://github.com/LionyxML/magit-stats"
  :commit "067f141fe524c960a5f7ed64f1a3ad3c75e7fc8d"
  :revdesc "067f141fe524"
  :keywords '("vc" "convenience"))
