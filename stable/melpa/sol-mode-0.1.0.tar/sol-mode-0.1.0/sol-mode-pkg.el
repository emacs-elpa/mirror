;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sol-mode" "0.1.0"
  "Major mode for editing Solidity code."
  '((emacs "30.1"))
  :url "https://codeberg.org/nlordell/sol-mode"
  :commit "93d96af2b7d19edd9caaf35478ec88e1530785aa"
  :revdesc "v0.1.0-0-g93d96af2b7d1"
  :keywords '("solidity" "languages")
  :authors '(("Nicholas Rodrigues Lordello" . "n@lordello.net"))
  :maintainers '(("Nicholas Rodrigues Lordello" . "n@lordello.net")))
