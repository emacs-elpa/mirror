;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wordreference" "0.2"
  "Interface for wordreference.com."
  '((emacs "27.1"))
  :url "https://codeberg.org/martianh/wordreference"
  :commit "b0de30340315b0f09ae7081d4e2f920ea60d9210"
  :revdesc "b0de30340315"
  :keywords '("convenience" "translate")
  :authors '(("Marty Hiatt" . "martianhiatusATriseup.net"))
  :maintainers '(("Marty Hiatt" . "martianhiatusATriseup.net")))
