;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-explorer" "1.1.0"
  "Explore a GitHub repository on the fly."
  '((emacs   "25")
    (graphql "0"))
  :url "https://github.com/TxGVNN/github-explorer"
  :commit "d7198dd81afc4ee2001606be821707a9ff4f31da"
  :revdesc "d7198dd81afc"
  :keywords '("comm")
  :authors '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers '(("Giap Tran" . "txgvnn@gmail.com")))
