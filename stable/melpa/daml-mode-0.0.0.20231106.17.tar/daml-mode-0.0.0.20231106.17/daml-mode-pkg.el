;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daml-mode" "0.0.0.20231106.17"
  "Major mode for daml."
  '((emacs        "27.1")
    (haskell-mode "16.1"))
  :url "https://github.com/bartfaitamas/daml-mode"
  :commit "3ba1166edd4c22402996625b1f8a05a2d5b1cbc6"
  :revdesc "3ba1166edd4c")
