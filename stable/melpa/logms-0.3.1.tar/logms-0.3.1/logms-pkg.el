;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "logms" "0.3.1"
  "Log message with clickable links to context."
  '((emacs "27.1")
    (f     "0.20.0")
    (s     "1.9.0")
    (ht    "2.3"))
  :url "https://github.com/jcs-elpa/logms"
  :commit "68bab96a13d64efdf4f5951d931d0862e6861fb5"
  :revdesc "68bab96a13d6"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
