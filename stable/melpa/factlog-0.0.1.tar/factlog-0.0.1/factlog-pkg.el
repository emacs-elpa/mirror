;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "factlog" "0.0.1"
  "File activity logger."
  ()
  :url "https://github.com/tkf/factlog"
  :commit "c834fdab81ec5b1bdc0ee2721a12cecb48a319bf"
  :revdesc "c834fdab81ec"
  :authors '(("Takafumi Arakaki" . "aka.tkfatgmail.com"))
  :maintainers '(("Takafumi Arakaki" . "aka.tkfatgmail.com")))
