;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symbolist" "0.1.0"
  "List and interactively unbind Emacs Lisp symbols."
  '((emacs "24.3"))
  :url "https://github.com/lassik/emacs-symbolist"
  :commit "0b43bb2eabcebe24b732f83daee34820c571d82e"
  :revdesc "0b43bb2eabce"
  :keywords '("lisp" "maint")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
