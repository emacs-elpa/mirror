;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-languagetool" "0.5.0"
  "Flycheck support for LanguageTool."
  '((emacs    "27.1")
    (flycheck "0.14"))
  :url "https://github.com/emacs-languagetool/flycheck-languagetool"
  :commit "28b376e4337c93149fb2620001afb284d739ce94"
  :revdesc "28b376e4337c"
  :keywords '("convenience" "grammar" "check")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com")
             ("Peter Oliver" . "git@mavit.org.uk"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Peter Oliver" . "git@mavit.org.uk")))
