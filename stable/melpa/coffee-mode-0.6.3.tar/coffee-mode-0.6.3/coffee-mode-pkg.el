;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coffee-mode" "0.6.3"
  "Major mode for CoffeeScript code."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/defunkt/coffee-mode"
  :commit "adfb7ae73d6ee2ef790c780dd3c967e62930e94a"
  :revdesc "adfb7ae73d6e"
  :keywords '("coffeescript" "major" "mode")
  :authors '(("Chris Wanstrath" . "chris@ozmm.org"))
  :maintainers '(("Chris Wanstrath" . "chris@ozmm.org")))
