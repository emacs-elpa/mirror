;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elbank" "1.2"
  "Personal finances reporting application."
  '((emacs "25")
    (seq   "2.16"))
  :url "https://github.com/NicolasPetton/elbank"
  :commit "f494716105b1a9f4f52f43bc3dd37c9cd0309bf5"
  :revdesc "1.2-0-gf494716105b1"
  :keywords '("tools" "personal-finances")
  :authors '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")))
