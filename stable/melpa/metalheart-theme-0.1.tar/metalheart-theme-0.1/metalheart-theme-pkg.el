;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metalheart-theme" "0.1"
  "Emacs low-contrast theme with a dark blue-green background."
  '((emacs "24"))
  :url "https://github.com/mswift42/MetalHeart-Emacs"
  :commit "e71ff3d8b42aee54739f7748bc92d28fa1597556"
  :revdesc "e71ff3d8b42a")
