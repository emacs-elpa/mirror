;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0.1"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.2"))
  :url "https://github.com/jojojames/fzfa"
  :commit "6737ba916ace7147eaa492fdbe950817beeecfd8"
  :revdesc "6737ba916ace"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
