;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yoshi-theme" "7.0.0"
  "Theme named after my cat."
  ()
  :url "http://projects.ryuslash.org/yoshi-theme/"
  :commit "11c37ef4ef68b55c7ce8ad058abb0b678411b299"
  :revdesc "7.0.0-0-g11c37ef4ef68"
  :keywords '("faces")
  :authors '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainers '(("Tom Willemse" . "tom@ryuslash.org")))
