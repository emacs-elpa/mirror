;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "1.1.7"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "a473d47ea6e28c5918d9fff6e95ff619778e0188"
  :revdesc "a473d47ea6e2"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
