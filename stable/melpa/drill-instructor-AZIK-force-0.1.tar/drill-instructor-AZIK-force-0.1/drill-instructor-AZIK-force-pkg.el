;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "drill-instructor-AZIK-force" "0.1"
  "Support AZIK input."
  ()
  :url "https://github.com/myuhe/drill-instructor-AZIK-force.el"
  :commit "430a5fd49fbd4783db29340c1d590ab2248b1abc"
  :revdesc "430a5fd49fbd"
  :keywords '("convenience")
  :authors '(("Yuhei Maeda" . "yuhei.maeda_at_gmail.com")))
