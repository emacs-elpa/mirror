;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compilation-history" "0.2.10"
  "Track compilation history in SQLite."
  '((emacs "29.1"))
  :url "https://github.com/djgoku/compilation-history"
  :commit "58b2c04b7a30a7d83576840cf05b08e435ed5be0"
  :revdesc "58b2c04b7a30"
  :keywords '("processes" "tools")
  :authors '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com"))
  :maintainers '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com")))
