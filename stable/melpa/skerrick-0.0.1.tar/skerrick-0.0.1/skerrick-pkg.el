;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "skerrick" "0.0.1"
  "Description."
  '((emacs   "27.1")
    (request "0.2.0"))
  :url "https://github.com/anonimitoraf/skerrick"
  :commit "98c8e6986f98a994659d8b1c0275e307b9e92914"
  :revdesc "98c8e6986f98"
  :keywords '("javascript" "js" "repl" "repl-driven")
  :authors '(("Rafael Nicdao" . "https://github.com/anonimitoraf"))
  :maintainers '(("Rafael Nicdao" . "nicdaoraf@gmail.com")))
