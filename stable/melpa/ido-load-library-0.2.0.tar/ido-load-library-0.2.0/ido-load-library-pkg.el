;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-load-library" "0.2.0"
  "Load-library alternative using ido-completing-read."
  '((persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/ido-load-library"
  :commit "8589cb1e4303066eb333f1cfc789835d1cbe21df"
  :revdesc "v0.2.0-0-g8589cb1e4303"
  :keywords '("maint" "completion")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
