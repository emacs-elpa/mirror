;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-mu" "1.0.0"
  "Helm sources for searching emails and contacts."
  '((helm "1.5.5"))
  :url "https://github.com/emacs-helm/helm-mu"
  :commit "212cca13528302a5501849ee6dcd735cf8635d24"
  :revdesc "212cca135283"
  :authors '(("Titus von der Malsburg" . "malsburg@posteo.de"))
  :maintainers '(("Titus von der Malsburg" . "malsburg@posteo.de")))
