;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atom-dark-theme" "0.2"
  "An Emacs port of the Atom Dark theme from Atom.io."
  ()
  :url "https://github.com/whitlockjc/atom-dark-theme-emacs"
  :commit "19ed52cf86fa8e5aad92483843e3f2929417b87a"
  :revdesc "19ed52cf86fa"
  :keywords '("themes" "atom" "dark")
  :authors '(("Jeremy Whitlock" . "jwhitlock@apache.org"))
  :maintainers '(("Jeremy Whitlock" . "jwhitlock@apache.org")))
