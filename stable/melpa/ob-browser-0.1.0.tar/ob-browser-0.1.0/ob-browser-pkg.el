;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-browser" "0.1.0"
  "Translation of text blocks in org-mode."
  '((org "8"))
  :url "https://github.com/krisajenkins/ob-browser"
  :commit "2ad23dc5a9cfc4f8f7b00b9426de71fb1a5acaa8"
  :revdesc "2ad23dc5a9cf"
  :keywords '("org" "babel" "browser" "phantomjs")
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
