;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-gleam" "0.1.1"
  "Org Babel functions for Gleam."
  '((emacs "29.1"))
  :url "https://github.com/takeokunn/ob-gleam"
  :commit "22fae3e741647750a603fdac29eb61b5c052f3da"
  :revdesc "22fae3e74164"
  :keywords '("languages" "tools")
  :authors '(("takeokunn" . "bararararatty@gmail.com"))
  :maintainers '(("takeokunn" . "bararararatty@gmail.com")))
