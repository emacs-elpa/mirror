;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nyan-mode" "1.1.3"
  "Nyan Cat shows position in current buffer in mode-line."
  ()
  :url "https://github.com/TeMPOraL/nyan-mode/"
  :commit "06e67ab2c490756d3eeed4a68aba7c33e508a5d5"
  :revdesc "v1.1.3-0-g06e67ab2c490"
  :keywords '("nyan" "cat" "lulz" "scrolling" "pop tart cat" "build something amazing")
  :authors '(("Jacek TeMPOraL Zlydach" . "temporal.pl@gmail.com"))
  :maintainers '(("Jacek TeMPOraL Zlydach" . "temporal.pl@gmail.com")))
