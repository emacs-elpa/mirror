;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mingus" "0.34"
  "MPD Interface."
  '((libmpdee "2.1"))
  :url "https://github.com/pft/mingus"
  :commit "826a2b536b73a24c22e73ea92d3deba2bffa1ad1"
  :revdesc "826a2b536b73"
  :keywords '("multimedia" "elisp" "music" "mpd")
  :authors '(("Niels Giesen" . "pfton#emacs"))
  :maintainers '(("Niels Giesen" . "pfton#emacs")))
