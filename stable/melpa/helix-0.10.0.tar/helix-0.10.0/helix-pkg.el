;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "0.10.0"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "eca52f517583a599a0a2589cdaa04f00cfc86184"
  :revdesc "eca52f517583"
  :keywords '("convenience"))
