;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-consult" "0.7"
  "Consult integration for zk."
  '((emacs   "27.1")
    (zk      "0.4")
    (consult "0.14"))
  :url "https://github.com/localauthor/zk"
  :commit "599be69ae1c1283935f98f9aca4ccda47063d82c"
  :revdesc "599be69ae1c1"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
