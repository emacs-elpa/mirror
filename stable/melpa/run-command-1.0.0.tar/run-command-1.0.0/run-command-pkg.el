;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "run-command" "1.0.0"
  "Run an external command from a context-dependent list."
  '((emacs "27.1"))
  :url "https://github.com/bard/emacs-run-command"
  :commit "e44bc5fb9712303150906f05ce7dd41c8c184aea"
  :revdesc "e44bc5fb9712"
  :keywords '("processes")
  :authors '(("Massimiliano Mirra" . "hyperstruct@gmail.com"))
  :maintainers '(("Massimiliano Mirra" . "hyperstruct@gmail.com")))
