;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ex-fasd" "0.1.0"
  "Using fasd right from evil-ex."
  '((emacs "24.4"))
  :url "https://github.com/yqrashawn/evil-ex-fasd"
  :commit "e5c00f3f95d5b464fc963a47dd44baa973956ab7"
  :revdesc "e5c00f3f95d5"
  :keywords '("tools" "fasd" "evil" "navigation")
  :authors '(("Rashawn Zhang" . "namy.19@gmail.com"))
  :maintainers '(("Rashawn Zhang" . "namy.19@gmail.com")))
