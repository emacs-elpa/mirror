;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-search-mc" "2.2.1"
  "Multiple-cursors extension for phi-search."
  '((phi-search       "2.0.0")
    (multiple-cursors "1.2.1"))
  :url "https://github.com/knu/phi-search-mc.el"
  :commit "4c6d2d39feb502febb81fc98b7b5854d88150c69"
  :revdesc "4c6d2d39feb5"
  :keywords '("search" "cursors")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
