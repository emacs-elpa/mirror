;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-flex-with-migemo" "0.0.0"
  "Use ido with flex and migemo."
  '((flx-ido "0.6.1")
    (migemo  "1.9.1")
    (emacs   "24.4"))
  :url "https://github.com/ROCKTAKEY/ido-flex-with-migemo"
  :commit "cc5119f1a483e65c682d5246f31d35e15b9468c4"
  :revdesc "cc5119f1a483"
  :keywords '("matching")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
