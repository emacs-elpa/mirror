;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "display-theme" "1.0"
  "Display current theme(s) at mode-line."
  ()
  :url "https://github.com/kawabata/emacs-display-theme/"
  :commit "8b14eeacfb1b573a18236216bdc68d418d29d146"
  :revdesc "8b14eeacfb1b"
  :keywords '("tools")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
