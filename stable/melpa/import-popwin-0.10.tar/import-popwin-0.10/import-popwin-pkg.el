;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "import-popwin" "0.10"
  "Popwin buffer near by import statements with popwin."
  '((emacs  "24.3")
    (popwin "0.6"))
  :url "https://github.com/syohex/emacs-import-popwin"
  :commit "6a21efc7fd44f8c2484d22eadf298e4bfd4bc003"
  :revdesc "6a21efc7fd44"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
