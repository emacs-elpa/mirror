;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "license-snippets" "1.0.0"
  "LICENSE templates for yasnippet."
  '((emacs     "26")
    (yasnippet "0.8.0"))
  :url "https://github.com/sei40kr/license-snippets"
  :commit "cb8b126d0dd04ee054e499c51d2f742ca03d8460"
  :revdesc "cb8b126d0dd0"
  :keywords '("tools")
  :authors '(("Seong Yong-ju" . "sei40kr@gmail.com"))
  :maintainers '(("Seong Yong-ju" . "sei40kr@gmail.com")))
