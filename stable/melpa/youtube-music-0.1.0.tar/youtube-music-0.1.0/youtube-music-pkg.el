;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youtube-music" "0.1.0"
  "YouTube Music client."
  '((emacs "29.1"))
  :url "https://github.com/cyberkm/emacs-youtube-music"
  :commit "98a3ac9b8e02079cfdca88e26fa4dfc8c7fa5690"
  :revdesc "98a3ac9b8e02"
  :keywords '("multimedia" "youtube" "music")
  :authors '(("Pavel Bibergal" . "pavel@keewano.com"))
  :maintainers '(("Pavel Bibergal" . "pavel@keewano.com")))
