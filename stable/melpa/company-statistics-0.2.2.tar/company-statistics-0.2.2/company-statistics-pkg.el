;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-statistics" "0.2.2"
  "Sort candidates using completion history."
  '((emacs   "24.3")
    (company "0.8.5"))
  :url "https://github.com/company-mode/company-statistics"
  :commit "906d8137224c1a5bd1dc913940e0d32ffecf5523"
  :revdesc "0.2.2-0-g906d8137224c"
  :keywords '("abbrev" "convenience" "matching")
  :authors '(("Ingo Lohmar" . "i.lohmar@gmail.com"))
  :maintainers '(("Ingo Lohmar" . "i.lohmar@gmail.com")))
