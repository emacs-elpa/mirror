;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "isearch-symbol-at-point" "0.0.0.20130728.7"
  "Use isearch to search for the symbol at point."
  ()
  :url "https://github.com/re5et/isearch-symbol-at-point"
  :commit "51a1029bec1ec414885f9edb7e5947603dffdab2"
  :revdesc "51a1029bec1e"
  :keywords '("isearch"))
