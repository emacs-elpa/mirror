;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keypression" "1.0.5"
  "Keystroke visualizer."
  '((emacs "26.3"))
  :url "https://github.com/chuntaro/emacs-keypression"
  :commit "ba30e4960cf5258016bc06205d00c8fadb0aa7d8"
  :revdesc "ba30e4960cf5"
  :keywords '("key" "screencast" "tools")
  :authors '(("chuntaro" . "chuntaro@sakura-games.jp"))
  :maintainers '(("chuntaro" . "chuntaro@sakura-games.jp")))
