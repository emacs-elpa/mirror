;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-rst" "0.2.2"
  "Poly-rst-mode polymode."
  '((emacs    "25")
    (polymode "0.2.2"))
  :url "https://github.com/polymode/poly-rst"
  :commit "8530f56fbdce01bcf4004839ff54e4156282c2b5"
  :revdesc "8530f56fbdce"
  :keywords '("languages" "multi-modes"))
