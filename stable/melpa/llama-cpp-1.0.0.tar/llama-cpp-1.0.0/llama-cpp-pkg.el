;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llama-cpp" "1.0.0"
  "A client for llama-cpp server."
  '((emacs "27.1")
    (dash  "2.19"))
  :url "https://github.com/kurnevsky/llama.el"
  :commit "4b48c1b7d8a027298bb5f7dba347f7a977a09243"
  :revdesc "4b48c1b7d8a0"
  :keywords '("llama" "llm" "ai")
  :authors '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com")))
