;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-spice" "0.3.0"
  "Extra spice for emacs lisp programming."
  ()
  :url "https://github.com/vedang/el-spice"
  :commit "972dace20ec61cd27b9322432d0c7a688c6f061a"
  :revdesc "0.3.0-0-g972dace20ec6"
  :keywords '("languages" "extensions")
  :authors '(("Vedang Manerikar" . "vedang.manerikar@gmail.com"))
  :maintainers '(("Vedang Manerikar" . "vedang.manerikar@gmail.com")))
