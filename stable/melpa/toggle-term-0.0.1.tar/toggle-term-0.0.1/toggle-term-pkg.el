;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toggle-term" "0.0.1"
  "[No description available]."
  ()
  :url "https://github.com/justinlime/toggle-term.el"
  :commit "91dce6ec832ba2d71be0dca971881231855d5484"
  :revdesc "91dce6ec832b"
  :keywords '("toggle" "terminal" "term" "shell"))
