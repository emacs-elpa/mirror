;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zzz-to-char" "1.0.0"
  "Fancy version of `zap-to-char' command."
  '((emacs "24.4")
    (avy   "0.3.0"))
  :url "https://github.com/mrkkrp/zzz-to-char"
  :commit "3bc8e0b3b34f511be2ae663785e3cad758361ba2"
  :revdesc "3bc8e0b3b34f"
  :keywords '("convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
