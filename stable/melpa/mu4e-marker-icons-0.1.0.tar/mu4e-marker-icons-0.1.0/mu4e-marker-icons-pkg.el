;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-marker-icons" "0.1.0"
  "Display icons for mu4e markers."
  '((emacs         "26.1")
    (all-the-icons "4.0.0"))
  :url "https://github.com/stardiviner/mu4e-marker-icons"
  :commit "a71a452971b0c33f6f78ce168edd01342162103a"
  :revdesc "a71a452971b0"
  :keywords '("mail")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
