;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tile" "0.0.0"
  "Tile windows with layouts."
  '((emacs  "25.1")
    (s      "1.9.0")
    (dash   "2.12.0")
    (stream "2.2.3"))
  :url "https://github.com/IvanMalison/tile"
  :commit "bebe40cafb60ec0e7f17e2c2480c92c932ea65c9"
  :revdesc "bebe40cafb60"
  :keywords '("tile" "tiling" "window" "manager" "dynamic")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
