;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc" "3.34.6239"
  "Minor mode to input Japanese with Mozc."
  '((emacs "24.3"))
  :url "https://github.com/google/mozc"
  :commit "76887c679e1e4f156102e4bc62ea9cf9174678a3"
  :revdesc "3.34.6239-0-g76887c679e1e"
  :keywords '("mule" "multilingual" "input method"))
