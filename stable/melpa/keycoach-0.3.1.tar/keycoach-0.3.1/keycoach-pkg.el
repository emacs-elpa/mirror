;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keycoach" "0.3.1"
  "Learn keybindings."
  '((emacs "25.1"))
  :url "https://github.com/mrcnski/keycoach"
  :commit "01e8f77dce7f17c71d2bc4a16cd4fcc7f5ce7952"
  :revdesc "01e8f77dce7f"
  :keywords '("help")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
