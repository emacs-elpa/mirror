;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typo" "1.1"
  "Minor mode for typographic editing."
  ()
  :url "https://github.com/jorgenschaefer/typoel"
  :commit "e72171e4eb0b9ec80b9dabc3198d137d9fb4f972"
  :revdesc "v1.1-0-ge72171e4eb0b"
  :keywords '("convenience" "wp")
  :authors '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainers '(("Jorgen Schaefer" . "forcer@forcix.cx")))
