;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-charinfo" "0.1"
  "A helm source for character information."
  '((emacs  "24")
    (helm   "1.7.0")
    (cl-lib "0.5"))
  :url "https://github.com/cwittern/helm-charinfo"
  :commit "d303f6f45d68b80bed614b5e5ebc1f7bf83d4cd1"
  :revdesc "d303f6f45d68"
  :keywords '("convenience")
  :authors '(("Christian Wittern" . "cwittern@gmail.com"))
  :maintainers '(("Christian Wittern" . "cwittern@gmail.com")))
