;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghostel" "0.56.0"
  "Consult integration for ghostel."
  '((emacs   "28.1")
    (consult "1.5")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "829ac98a3e3183249028f9f4e029e7e9c0869be3"
  :revdesc "829ac98a3e31"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
