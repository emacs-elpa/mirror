;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bongo" "1.1"
  "Play music with Emacs."
  '((cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/dbrock/bongo"
  :commit "9afbf269d33cd3196962423a2c261824611cffe4"
  :revdesc "9afbf269d33c")
