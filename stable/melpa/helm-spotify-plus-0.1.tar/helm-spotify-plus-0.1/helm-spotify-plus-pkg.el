;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-spotify-plus" "0.1"
  "Control Spotify with Helm."
  '((emacs "24.4"))
  :url "https://github.com/wandersoncferreira/helm-spotify-plus"
  :commit "320ac23a15c12559a8554063e0424c2f8a779d27"
  :revdesc "320ac23a15c1"
  :authors '(("Wanderson Ferreira and Luis Moneda" . "https://github.com/lgmoneda"))
  :maintainers '(("Wanderson Ferreira and Luis Moneda" . "https://github.com/lgmoneda")))
