;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-relint" "0.6"
  "A Flycheck checker for elisp regular expressions."
  '((emacs    "26.1")
    (flycheck "0.22")
    (relint   "1.15"))
  :url "https://github.com/purcell/flycheck-relint"
  :commit "d1e54d4bfdb12d0b60a1b9a8c2b11799426ddc57"
  :revdesc "d1e54d4bfdb1"
  :keywords '("lisp")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
