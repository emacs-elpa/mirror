;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tanglesync" "0.6"
  "Syncing org src blocks with tangled external files."
  '((emacs "24.4"))
  :url "https://github.com/mtekman/org-tanglesync.el"
  :commit "19abbadc227eb064cd36fba432706d251fa3b60d"
  :revdesc "19abbadc227e"
  :keywords '("outlines"))
