;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sotlisp" "1.6.2"
  "Write lisp at the speed of thought."
  '((emacs "24.1"))
  :url "https://github.com/Malabarba/speed-of-thought-lisp"
  :commit "fffe8d0b42b143a2e7df0470d9049fa57b6ecac5"
  :revdesc "fffe8d0b42b1"
  :keywords '("convenience" "lisp")
  :authors '(("Artur Malabarba" . "emacs@endlessparentheses.com"))
  :maintainers '(("Artur Malabarba" . "emacs@endlessparentheses.com")))
