;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pepita" "0.0.0.20240102.31"
  "Run Splunk search commands, export results to CSV/HTML/JSON."
  '((emacs "25")
    (csv   "2.1"))
  :url "https://github.com/sebasmonia/pepita.git"
  :commit "02ac00ad23b9a3e19797fc76ac569c2d46da54b9"
  :revdesc "02ac00ad23b9"
  :keywords '("tools" "convenience" "matching")
  :authors '(("Sebastian Monia" . "smonia@outlook.com"))
  :maintainers '(("Sebastian Monia" . "smonia@outlook.com")))
