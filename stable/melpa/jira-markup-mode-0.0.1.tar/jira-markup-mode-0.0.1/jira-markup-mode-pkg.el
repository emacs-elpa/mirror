;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira-markup-mode" "0.0.1"
  "Emacs Major mode for JIRA-markup-formatted text files."
  ()
  :url "https://github.com/mnuessler/jira-markup-mode"
  :commit "bf43975e239dbe9832b8e4c5fd2d747fa145c624"
  :revdesc "bf43975e239d"
  :keywords '("jira" "markup")
  :authors '(("Matthias Nuessler" . "m.nuessler@web.de"))
  :maintainers '(("Matthias Nuessler" . "m.nuessler@web.de")))
