;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nixfmt" "0.1"
  "Reformat Nix using nixfmt."
  '((emacs       "24")
    (reformatter "0.3"))
  :url "https://github.com/purcell/emacs-nixfmt"
  :commit "99b15e362564465bc7eeef3d3284bdb79bb7df62"
  :revdesc "99b15e362564"
  :keywords '("languages")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
