;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bolt-mode" "0.1"
  "Editing support for Bolt language."
  ()
  :url "https://github.com/mpontus/bolt-mode"
  :commit "54994c51cac59a9da9fbe5f4362fcc6922c9698c"
  :revdesc "54994c51cac5"
  :keywords '("languages")
  :authors '(("Mikhail Pontus" . "m.pontus@gmail.com"))
  :maintainers '(("Mikhail Pontus" . "m.pontus@gmail.com")))
