;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cherry-blossom-theme" "0.0.2"
  "A soothing color theme for Emacs24."
  '((emacs "24.0"))
  :url "https://github.com/byels/emacs-cherry-blossom-theme"
  :commit "e6e093ccbf5efca6490f3e85880adfaaef42583d"
  :revdesc "e6e093ccbf5e"
  :authors '(("Ben Yelsey" . "byelsey1@gmail.com"))
  :maintainers '(("Ben Yelsey" . "byelsey1@gmail.com")))
