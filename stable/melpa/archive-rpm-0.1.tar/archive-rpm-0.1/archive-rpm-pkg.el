;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "archive-rpm" "0.1"
  "RPM support for archive-mode."
  ()
  :url "https://github.com/nbarrientos/archive-rpm"
  :commit "59f83caebbd2f92fd634f6968e6d17b50ffa3dc7"
  :revdesc "59f83caebbd2"
  :keywords '("files")
  :authors '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainers '(("Magnus Henoch" . "magnus.henoch@gmail.com")))
