;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-journal-tags" "0.4.0"
  "Tagging and querying system of org-journal."
  '((emacs         "27.1")
    (org-journal   "2.1.2")
    (magit-section "3.3.0")
    (transient     "0.3.7"))
  :url "https://github.com/SqrtMinusOne/org-journal-tags"
  :commit "d2375f42c80799ad7fb2324247315169bedc4c19"
  :revdesc "d2375f42c807"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
