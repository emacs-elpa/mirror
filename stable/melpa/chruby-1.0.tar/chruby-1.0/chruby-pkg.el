;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chruby" "1.0"
  "Emacs integration for chruby."
  ()
  :url "http://www.emacswiki.org/emacs/ChrubyEl"
  :commit "cbc0d24282900469f48cb6656508fc57c27a49a0"
  :revdesc "cbc0d2428290"
  :keywords '("ruby" "chruby")
  :authors '(("Arne Brasseur" . "arne@arnebrasseur.net"))
  :maintainers '(("Arne Brasseur" . "arne@arnebrasseur.net")))
