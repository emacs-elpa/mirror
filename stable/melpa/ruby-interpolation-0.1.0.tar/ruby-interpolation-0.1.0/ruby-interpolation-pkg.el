;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-interpolation" "0.1.0"
  "Ruby string interpolation helpers."
  ()
  :url "https://github.com/leoc/ruby-interpolation.el"
  :commit "33b7b871e29e0c9f02e45c45b051d455e3d27cd0"
  :revdesc "33b7b871e29e"
  :authors '(("Arthur Leonard Andersen" . "leoc.git@gmail.com"))
  :maintainers '(("Arthur Leonard Andersen" . "leoc.git@gmail.com")))
