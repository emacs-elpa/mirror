;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker-api" "0.0.1"
  "Emacs interface to the Docker API."
  '((dash "2.12.1")
    (s    "1.11.0"))
  :url "https://github.com/Silex/docker-api.el"
  :commit "71d7c052e3fd002c1d5df7f11a23dd1aa3f73e5e"
  :revdesc "71d7c052e3fd"
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
