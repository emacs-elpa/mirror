;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "logview" "0.19.3"
  "Major mode for viewing log files."
  '((emacs    "25.1")
    (datetime "0.8")
    (extmap   "1.0")
    (compat   "29"))
  :url "https://github.com/doublep/logview"
  :commit "93b744ac5d57d527b8ca625116c3206549b8231f"
  :revdesc "93b744ac5d57"
  :keywords '("files" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
