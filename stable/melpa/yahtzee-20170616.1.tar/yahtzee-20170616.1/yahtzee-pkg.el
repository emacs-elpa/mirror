;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yahtzee" "20170616.1"
  "The yahtzee game."
  '((emacs "24.3"))
  :url "https://github.com/drdv/yahtzee"
  :commit "57cb8f12e3cc795ecf6dcaa49fce5f15a51a664f"
  :revdesc "57cb8f12e3cc"
  :keywords '("games")
  :authors '(("Dimitar Dimitrov" . "mail.mitko@gmail.com"))
  :maintainers '(("Dimitar Dimitrov" . "mail.mitko@gmail.com")))
