;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esh-autosuggest" "2.0.1"
  "History autosuggestions for eshell."
  '((emacs   "24.4")
    (company "0.9.4"))
  :url "https://github.com/dieggsy/esh-autosuggest"
  :commit "a6d5eb3337d010bd2a2d677ff304cd53adc291a0"
  :revdesc "a6d5eb3337d0"
  :keywords '("completion" "company" "matching" "convenience" "abbrev")
  :authors '(("Diego A. Mundo" . "diegoamundo@gmail.com"))
  :maintainers '(("Diego A. Mundo" . "diegoamundo@gmail.com")))
