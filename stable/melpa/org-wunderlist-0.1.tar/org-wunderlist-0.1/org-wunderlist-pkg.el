;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-wunderlist" "0.1"
  "Org sync with Wunderlist."
  '((request-deferred "0.2.0")
    (alert            "1.1")
    (emacs            "24")
    (cl-lib           "0.5")
    (org              "8.2.4"))
  :url "https://github.com/myuhe/org-wunderlist.el"
  :commit "f00d30bec163a631fe6668345d4f0785a2cd53da"
  :revdesc "f00d30bec163"
  :keywords '("convenience")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
