;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-search-highlight-persist" "1.8"
  "Persistent highlights after search."
  '((highlight "0"))
  :url "https://github.com/naclander/evil-search-highlight-persist"
  :commit "0e2b3d4e3dec5f38ae95f62519eb2736f73c0b85"
  :revdesc "0e2b3d4e3dec"
  :authors '(("Juanjo Alvarez" . "juanjo@juanjoalvarez.net"))
  :maintainers '(("Juanjo Alvarez" . "juanjo@juanjoalvarez.net")))
