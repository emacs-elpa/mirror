;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-comint" "1.2.0"
  "JavaScript interpreter in window."
  '((emacs "24.3"))
  :url "https://github.com/redguardtoo/js-comint"
  :commit "0dedaf4753fbe8cdbab14aa85f05d7673cbee8b6"
  :revdesc "0dedaf4753fb"
  :keywords '("javascript" "node" "inferior-mode" "convenience")
  :authors '(("Paul Huff" . "paul.huff@gmail.com")
             ("Stefano Mazzucco" . "MYFIRSTNAME-AT-CURSO-DOT-RE"))
  :maintainers '(("Chen Bin" . "chenbin.shATgmailDOTcom")))
