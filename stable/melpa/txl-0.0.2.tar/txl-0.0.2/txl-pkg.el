;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "txl" "0.0.2"
  "Provides machine translation via DeepL's REST API."
  '((request        "0.3.2")
    (guess-language "0.0.1")
    (emacs          "28"))
  :url "https://github.com/tmalsburg/txl.el"
  :commit "ef7389b570452006b5b469d5adefa90e0259b34c"
  :revdesc "ef7389b57045"
  :authors '(("Titus von der Malsburg" . "malsburg@posteo.de"))
  :maintainers '(("Titus von der Malsburg" . "malsburg@posteo.de")))
