;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flucui-themes" "1.0"
  "Custom theme inspired by the Flat UI palette."
  '((emacs "24"))
  :url "https://github.com/MetroWind/emacs-flatui-theme"
  :commit "a6c825cc69a9d8b990a2f02e067fddba9e03b955"
  :revdesc "a6c825cc69a9"
  :keywords '("lisp")
  :authors '(("MetroWind" . "chris.corsair@gmail.com"))
  :maintainers '(("MetroWind" . "chris.corsair@gmail.com")))
