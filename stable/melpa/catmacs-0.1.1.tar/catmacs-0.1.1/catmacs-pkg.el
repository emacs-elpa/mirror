;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "catmacs" "0.1.1"
  "Simple CAT interface for Yaesu FT991A."
  ()
  :url "https://pymaximus@bitbucket.org/pymaximus/catmacs.git"
  :commit "c6e8277bd2aab3f5fbf10d419111110f3b33564f"
  :revdesc "0.1.1-0-gc6e8277bd2aa"
  :keywords '("catmacs" "radio" "control" "cat" "yaesu" "ft991a")
  :authors '(("Frank Singleton" . "b17flyboy@gmail.com"))
  :maintainers '(("Frank Singleton" . "b17flyboy@gmail.com")))
