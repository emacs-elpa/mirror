;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.0.0"
  "An Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "d9ec8b93a61f6653bf9bcc929dbfa5e49133d37f"
  :revdesc "4.0.0-0-gd9ec8b93a61f"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
