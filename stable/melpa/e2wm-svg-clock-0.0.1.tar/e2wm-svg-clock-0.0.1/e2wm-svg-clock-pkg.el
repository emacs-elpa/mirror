;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2wm-svg-clock" "0.0.1"
  "E2wm plugin for svg-clock."
  '((e2wm      "20130225.1602")
    (svg-clock "0.4"))
  :url "https://github.com/myuhe/e2wm-svg-clock.el"
  :commit "6a1ceacb547b09d44c7418f2b013392b0744c134"
  :revdesc "6a1ceacb547b"
  :keywords '("convenience" "e2wm")
  :authors '(("Yuhei Maeda" . "yuhei.maeda_at_gmail.com")))
