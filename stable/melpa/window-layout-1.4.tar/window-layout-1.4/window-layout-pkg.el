;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "window-layout" "1.4"
  "Window layout manager."
  ()
  :url "https://github.com/kiwanami/emacs-window-layout"
  :commit "cd2e4f967b610c2bbef53182829e47250d027056"
  :revdesc "cd2e4f967b61"
  :keywords '("window" "layout")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net"))
  :maintainers '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net")))
