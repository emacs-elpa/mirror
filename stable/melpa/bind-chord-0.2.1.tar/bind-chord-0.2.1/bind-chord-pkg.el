;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bind-chord" "0.2.1"
  "Key-chord binding helper for use-package-chords."
  '((emacs     "24.3")
    (bind-key  "1.0")
    (key-chord "0.6"))
  :url "https://github.com/jwiegley/use-package"
  :commit "a2b16a1e64b19ae9428a6cd8f3e09b8159707a29"
  :revdesc "a2b16a1e64b1"
  :keywords '("convenience" "tools" "extensions")
  :authors '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainers '(("Justin Talbott" . "justin@waymondo.com")))
