;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wispjs-mode" "0.2.0"
  "Major mode for Wisp code."
  '((clojure-mode "0"))
  :url "https://github.com/krisajenkins/wispjs-mode"
  :commit "be094c3c3223c07b26b5d8bb8fa7aa6866369b3f"
  :revdesc "be094c3c3223"
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
