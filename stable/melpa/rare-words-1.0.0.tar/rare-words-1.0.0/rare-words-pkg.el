;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rare-words" "1.0.0"
  "[No description available]."
  '((Emacs "29.1"))
  :url "https://github.com/amolv06/rare-words"
  :commit "2bc14109b602f7a7fbffd130def2c709472c8720"
  :revdesc "2bc14109b602"
  :authors '(("Amol Vaidya" . "amolvaidya.signup@gmail.com"))
  :maintainers '(("Amol Vaidya" . "amolvaidya.signup@gmail.com")))
