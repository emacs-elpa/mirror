;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sticky-shell" "1.0.1"
  "Minor mode to keep track of previous prompt in your shell."
  '((emacs "25.1"))
  :url "https://github.com/andyjda/sticky-shell"
  :commit "b44f88bb0b3752d47c81a6459be57b7ff0ee866f"
  :revdesc "b44f88bb0b37"
  :keywords '("processes" "terminals" "tools")
  :authors '(("Andrew De Angelis" . "bobodeangelis@gmail.com"))
  :maintainers '(("Andrew De Angelis" . "bobodeangelis@gmail.com")))
