;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicad" "1.1.7"
  "An elisp port of Mozilla Universal Charset Auto Detector."
  '((emacs   "24")
    (nadvice "0.3"))
  :url "https://github.com/ukari/unicad"
  :commit "a5fd4e326a0607acc3776c11f41826e60b6486c6"
  :revdesc "1.1.7-0-ga5fd4e326a06"
  :keywords '("i18n")
  :authors '(("Qichen Huang" . "unicad.el@gmail.com"))
  :maintainers '(("Qichen Huang" . "unicad.el@gmail.com")))
