;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ewc" "0.4"
  "Wayland client in Elisp."
  '((emacs "28.2")
    (lgr   "0.1.0"))
  :url "http://perma-curious.eu/repo-ewx/"
  :commit "2667d7e5487d1400208dbe7a7b582096a4d1f328"
  :revdesc "2667d7e5487d"
  :keywords '("unix")
  :authors '(("Michael Bauer" . "michael-bauer@posteo.de"))
  :maintainers '(("Thomas Koch" . "thomas@koch.ro")))
