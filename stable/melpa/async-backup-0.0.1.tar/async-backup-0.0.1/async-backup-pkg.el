;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async-backup" "0.0.1"
  "Backup on each save, without freezing the interface."
  '((emacs "24.4"))
  :url "https://tildegit.org/contrapunctus/async-backup"
  :commit "477d9f5df6bbfa853e5b60d8a66af1ed0098465b"
  :revdesc "477d9f5df6bb"
  :keywords '("calendar")
  :authors '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainers '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de")))
