;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pygen" "0.2.7"
  "Python code generation using Elpy and Python-mode."
  '((elpy        "1.12.0")
    (python-mode "6.2.2")
    (dash        "2.13.0"))
  :url "https://github.com/JackCrawley/pygen/"
  :commit "3a5d1d1a0640865b15be05cd1eeb33bb4793b622"
  :revdesc "3a5d1d1a0640"
  :keywords '("python" "code generation")
  :authors '(("Jack Crawley" . "http://www.github.com/jackcrawley"))
  :maintainers '(("Jack Crawley" . "http://www.github.com/jackcrawley")))
