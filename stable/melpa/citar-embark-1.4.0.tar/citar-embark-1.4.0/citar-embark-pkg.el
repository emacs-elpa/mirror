;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-embark" "1.4.0"
  "Citar/Embark integration."
  '((emacs  "27.1")
    (embark "0.17")
    (citar  "0.9.7"))
  :url "https://github.com/emacs-citar/citar-embark"
  :commit "e21bf22b29d8ca40649517bb7dc503765f240282"
  :revdesc "v1.4.0-0-ge21bf22b29d8"
  :keywords '("bib" "extensions")
  :authors '(("Bruce D'Arcus" . "bdarcus@gmail.com"))
  :maintainers '(("Bruce D'Arcus" . "bdarcus@gmail.com")))
