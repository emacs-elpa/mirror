;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaomel" "1.0.0"
  "A snappy kaomoji picker."
  '((emacs "27.1"))
  :url "https://github.com/gicrisf/kaomel"
  :commit "a1a596e3c907457ea1e773b499c49b96fb93038a"
  :revdesc "a1a596e3c907"
  :keywords '("convenience" "extensions" "faces" "tools")
  :authors '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com"))
  :maintainers '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com")))
