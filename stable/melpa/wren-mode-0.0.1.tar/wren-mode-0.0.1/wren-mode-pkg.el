;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wren-mode" "0.0.1"
  "A major mode for the Wren programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/wren-mode"
  :commit "c815892fc61da14e47f8b4dc20902fb7125f9515"
  :revdesc "c815892fc61d"
  :keywords '("files" "wren"))
