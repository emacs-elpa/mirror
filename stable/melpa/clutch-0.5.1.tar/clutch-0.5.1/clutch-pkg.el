;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.1"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "34ede39231d95806daf2888de33e11493a4a6b86"
  :revdesc "34ede39231d9"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
