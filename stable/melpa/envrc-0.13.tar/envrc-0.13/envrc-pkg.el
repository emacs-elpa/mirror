;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "0.13"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "64944dab7991ae571caa5303cf324be91d9e8171"
  :revdesc "64944dab7991"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
