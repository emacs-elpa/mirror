;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wordel" "0.1.0"
  "An Elisp implementation of \"Wordle\" (aka \"Lingo\")."
  '((emacs "27.1"))
  :url "https://github.com/progfolio/wordel"
  :commit "e1686812cc72467df2845407b1ffd6cf55e49743"
  :revdesc "e1686812cc72"
  :keywords '("games")
  :authors '(("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com"))
  :maintainers '(("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com")))
