;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "system-specific-settings" "0.2"
  "Apply settings only on certain systems."
  ()
  :url "https://github.com/DarwinAwardWinner/emacs-system-specific-settings"
  :commit "0050d85b2175095aa5ecf580a2fe43c069b0eef3"
  :revdesc "0050d85b2175"
  :keywords '("configuration"))
