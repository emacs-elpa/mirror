;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slirm" "1.0"
  "Systematic Literature Review Mode for Emacs."
  ()
  :url "https://github.com/fbie/slirm"
  :commit "e9f027c8e193f3a3a66ba6eabf1c42f65b57126e"
  :revdesc "e9f027c8e193"
  :authors '(("Florian Biermann" . "fbie@itu.dk"))
  :maintainers '(("Florian Biermann" . "fbie@itu.dk")))
