;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-function-calls" "0.1"
  "Highlight function/macro calls."
  '((emacs "24.4"))
  :url "https://github.com/alphapapa/highlight-function-calls"
  :commit "b56956c2b6ed1e87d0f8f49088ead3221244b53d"
  :revdesc "v0.1-0-gb56956c2b6ed"
  :keywords '("faces" "highlighting")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
