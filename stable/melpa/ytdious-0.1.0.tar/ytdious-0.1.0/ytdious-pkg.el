;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ytdious" "0.1.0"
  "Query / Preview YouTube via Invidious."
  '((emacs "25.3"))
  :url "https://github.com/spiderbit/ytdious"
  :commit "47245a2133489814f6237a6f39bdf6567dafbcee"
  :revdesc "47245a213348"
  :keywords '("youtube" "matching" "multimedia"))
