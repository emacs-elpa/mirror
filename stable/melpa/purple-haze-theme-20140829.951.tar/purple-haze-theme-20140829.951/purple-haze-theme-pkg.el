;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "purple-haze-theme" "20140829.951"
  "An overtly purple color theme for Emacs24."
  '((emacs "24.0"))
  :url "https://github.com/jasonm23/emacs-purple-haze-theme"
  :commit "189fd0e4a4f9897307a7e07f730c6d290c255cfa"
  :revdesc "189fd0e4a4f9"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
