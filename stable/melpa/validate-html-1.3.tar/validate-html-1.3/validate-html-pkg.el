;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "validate-html" "1.3"
  "Compilation mode for W3C HTML Validator."
  '((emacs "25.1"))
  :url "https://github.com/arthurgleckler/validate-html"
  :commit "748e874d50c3a95c61590ae293778e26de05c5f9"
  :revdesc "748e874d50c3"
  :keywords '("languages" "tools")
  :authors '(("Arthur A. Gleckler" . "melpa4aag@speechcode.com"))
  :maintainers '(("Arthur A. Gleckler" . "melpa4aag@speechcode.com")))
