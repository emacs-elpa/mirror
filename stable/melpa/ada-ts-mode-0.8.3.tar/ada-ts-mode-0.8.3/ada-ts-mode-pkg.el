;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ada-ts-mode" "0.8.3"
  "Major mode for Ada using Tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/brownts/ada-ts-mode"
  :commit "52e0fd11604ab1d51a34c89e05692446d9dc5ecb"
  :revdesc "52e0fd11604a"
  :keywords '("ada" "languages" "tree-sitter")
  :authors '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainers '(("Troy Brown" . "brownts@troybrown.dev")))
