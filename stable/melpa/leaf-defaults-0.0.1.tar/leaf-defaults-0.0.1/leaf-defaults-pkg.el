;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-defaults" "0.0.1"
  "Awesome leaf config collections."
  '((emacs "26.1"))
  :url "https://github.com/conao3/leaf-defaults.el"
  :commit "4892abb87cb84c3a5914c542124f66ef22c9d5ce"
  :revdesc "4892abb87cb8"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
