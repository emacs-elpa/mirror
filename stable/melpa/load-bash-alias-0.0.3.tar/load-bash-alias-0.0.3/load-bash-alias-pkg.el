;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "load-bash-alias" "0.0.3"
  "Convert bash aliases into eshell ones."
  '((emacs "24.1")
    (seq   "2.16"))
  :url "https://github.com/daviderestivo/load-bash-alias"
  :commit "684a6236dfe50a375dc6fa58f358ac99a36865a4"
  :revdesc "684a6236dfe5"
  :keywords '("emacs" "bash" "eshell" "alias")
  :authors '(("Davide Restivo" . "davide.restivo@yahoo.it"))
  :maintainers '(("Davide Restivo" . "davide.restivo@yahoo.it")))
