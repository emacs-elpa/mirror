;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-easymotion" "20160228"
  "A port of vim's easymotion to emacs."
  '((emacs  "24")
    (avy    "0.3.0")
    (cl-lib "0.5"))
  :url "https://github.com/pythonnut/evil-easymotion"
  :commit "407fbb3bfea160b58057b628729baaaa27d82ded"
  :revdesc "407fbb3bfea1"
  :keywords '("convenience" "evil")
  :authors '(("PythonNut" . "pythonnut@pythonnut.com"))
  :maintainers '(("PythonNut" . "pythonnut@pythonnut.com")))
