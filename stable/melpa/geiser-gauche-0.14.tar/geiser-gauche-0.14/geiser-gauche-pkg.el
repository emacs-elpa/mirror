;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-gauche" "0.14"
  "[No description available]."
  ()
  :url "https://gitlab.com/emacs-geiser/gauche"
  :commit "362f1d1189c090ece8b94f6a51680f74b1ff40f9"
  :revdesc "362f1d1189c0")
