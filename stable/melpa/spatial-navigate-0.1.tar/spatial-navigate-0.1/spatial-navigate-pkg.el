;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spatial-navigate" "0.1"
  "Directional navigation between white-space blocks."
  '((emacs "26.2"))
  :url "https://github.com/ideasman42/emacs-spatial-navigate"
  :commit "863efd3f2d434cdf1212c07c02c554965b269997"
  :revdesc "863efd3f2d43"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
