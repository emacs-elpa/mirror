;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-doc" "0.0.4"
  "Insert JsDoc style comment easily."
  ()
  :url "http://www.d.hatena.ne.jp/mooz/"
  :commit "7089d006b833d1c71235ef566b9df01d480270d5"
  :revdesc "7089d006b833"
  :keywords '("document" "comment")
  :authors '(("mooz" . "stillpedant@gmail.com"))
  :maintainers '(("mooz" . "stillpedant@gmail.com")))
