;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inlineR" "0.2"
  "Insert Tag for inline image of R graphics."
  ()
  :url "https://github.com/myuhe/e2wm-bookmark.el"
  :commit "4f077c771cb80fd3c6f740396cc940ee687eb6ef"
  :revdesc "4f077c771cb8"
  :keywords '("convenience" "iimage.el" "cacoo.el")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
