;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-dt" "0.1.0"
  "Templating package."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://codeberg.org/niqc/org-dynamic-templates"
  :commit "b2835aa8ddeb2f7b521de7123d2e5daf2973096c"
  :revdesc "b2835aa8ddeb")
