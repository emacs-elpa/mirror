(defcustom my/org-roam-templates-folder "templates"
	"Folder to save your templates"
	:type 'string
	:group 'org-roam)

(defvar my/org-roam-last-template-category nil
	"Last template category used.")

(defcustom my/org-roam-always-use-last-category nil
	"If non-nil, always reuse the last template category."
	:type 'boolean
	:group 'org-roam)

(defun my/org-roam-templates-dir ()
	"Return current directory"
	(when-let ((project (project-current)))
		(expand-file-name my/org-roam-templates-folder
											(project-root project))))

(defun my/org-roam-toggle-always-use-last-category ()
	"Toggle always using the last template category."
	(interactive)
	(setq my/org-roam-always-use-last-category
				(not my/org-roam-always-use-last-category))
	(message "Always use last category: %s"
					 (if my/org-roam-always-use-last-category "enabled" "disabled")))

(defun my/ask-dir ()
	(concat (read-directory-name "Directory: " default-directory)))

(defun my/org-roam-generate-key (name used-keys)
	"Generate unique key for template"
	(let ((chars (string-to-list name))
				key)
		(while (and chars (member (setq key (string (pop chars))) used-keys)))
		(or key
				(number-to-string (length used-keys)))))

(defun my/org-roam-select-template-dir (root)
	"Select template directory."
	(let* ((dirs
					(cons root
								(seq-filter
								 #'file-directory-p
								 (directory-files-recursively root "" t))))
				 (names
					(mapcar
					 (lambda (dir)
						 (let ((rel (file-relative-name dir root)))
							 (if (string= rel ".")
									 "root"
								 rel)))
					 dirs)))

		(cond
		 (my/org-roam-always-use-last-category
			(or my/org-roam-last-template-category root))

		 (t
			(let* ((choice (completing-read "Template category: " names nil t))
						 (dir (if (string= choice "root")
											root
										(expand-file-name choice root))))

				(setq my/org-roam-last-template-category dir)
				dir)))))

(defun my/load-roam-templates ()
	"Load templates from project root folder"
	(interactive)
	(when-let* ((root (my/org-roam-templates-dir))
							((file-directory-p root))
							(dir (my/org-roam-select-template-dir root))
							(files (sort (directory-files dir t "\\.org$")
													 #'string<)))
		(let ((used-keys '()))
			(setq org-roam-capture-templates
						(cl-loop
						 for file in files
						 for name = (file-name-base file)
						 for key = (my/org-roam-generate-key name used-keys)
						 do (push key used-keys)
						 collect
						 `(,key ,name
										plain
										(file ,file)
										:if-new
										(file+head
										 "%(concat (my/ask-dir) \"/\" \"${slug}.org\")"
										 "#+title: ${title}\n")
										:unnarrowed t))))))

(advice-add 'org-roam-capture :before #'my/load-roam-templates)
