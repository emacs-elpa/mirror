;;; org-dt.el --- Templating package -*- lexical-binding: t -*-

;; Package-Version: 0.1.0
;; Package-Revision: b2835aa8ddeb
;; Package-Requires: ((emacs "29.1") (compat "30"))
;; URL: https://codeberg.org/niqc/org-dynamic-templates

;;; Commentary:

;; Define template folder for org files, you can define a folder and all org files are converted in a template

;;; Code:

(defgroup org-dt nil
  "Dynamic templates loaded from directories."
  :group 'org-dt)

(defcustom org-dt--templates-folder "templates"
	"Folder to save your templates"
	:type 'string
	:group 'org-dt)

(defcustom org-dt--always-use-last-category nil
	"If non-nil, always reuse the last template category."
	:type 'boolean
	:group 'org-dt)

(defcustom org-dt-capture-target "${slug}.org"
	"Target used in the file+head for dyanmic templates"
  :type 'string
  :group 'org-dt)

;; (defcustom org-dt-using-roam nil
;; 	"Define as t if you use org roam"
;; 	:type 'boolean
;; 	:group 'org-dt)

(defvar org-dt--last-template-category nil
	"Last template category used.")

(defun org-dt--templates-dir ()
	"Return current directory"
	(when-let ((project (project-current)))
		(expand-file-name org-dt--templates-folder
											(project-root project))))

(defun org-dt-toggle-always-use-last-category ()
	"Toggle always using the last template category."
	(interactive)
	(setq org-dt--always-use-last-category
				(not org-dt--always-use-last-category))
	(message "Always use last category: %s"
					 (if org-dt--always-use-last-category "enabled" "disabled")))

(defun org-dt--generate-key (name used-keys)
	"Generate unique key for template"
	(let ((chars (string-to-list name))
				key)
		(while (and chars (member (setq key (string (pop chars))) used-keys)))
		(or key
				(number-to-string (length used-keys)))))

(defun org-dt--select-template-dir (root)
	"Select template directory."
	(let* ((dirs
					(cons root
								(seq-filter
								 #'file-directory-p
								 (directory-files-recursively root "" t))))
				 (names
					(mapcar
					 (lambda (dir)
						 (let ((rel (file-relative-name dir root)))
							 (if (string= rel ".")
									 "root"
								 rel)))
					 dirs)))

		(cond
		 (org-dt--always-use-last-category
			(or org-dt--last-template-category root))
		 (t
			(let* ((choice (completing-read "Template category: " names nil t))
						 (dir (if (string= choice "root")
											root
										(expand-file-name choice root))))
				(setq org-dt--last-template-category dir)
				dir)))))

(defun org-dt-load-templates ()
	"Load templates from project root folder"
	(interactive)
	(when-let* ((root (org-dt--templates-dir))
							((file-directory-p root))
							(dir (org-dt--select-template-dir root))
							(files (sort (directory-files dir t "\\.org$")
													 #'string<)))
		(let ((used-keys '()))
      (setq org-roam-capture-templates
            (cl-loop
             for file in files
             for name = (file-name-base file)
             for key = (org-dt--generate-key name used-keys)
             do (push key used-keys)
             collect
             `(,key ,name
                    plain
                    (file ,file)
                    :if-new
										(file ,org-dt-capture-target)
										:unnarrowed t))))))

;; (defun org-dt-load-templates ()
;; 	"Load templates from project root folder"
;; 	(interactive)
;; 	(when-let* ((root (org-dt--templates-dir))
;; 							((file-directory-p root))
;; 							(dir (org-dt--select-template-dir root))
;; 							(files (sort (directory-files dir t "\\.org$")
;; 													 #'string<)))
;; 		(let ((used-keys '()))
;;       (setq org-roam-capture-templates
;;             (cl-loop
;;              for file in files
;;              for name = (file-name-base file)
;;              for key = (org-dt--generate-key name used-keys)
;;              for target = org-dt-capture-target
;;              for head = org-dt-capture-head
;;              do (push key used-keys)
;;              collect
;;              `(,key ,name
;;                     plain
;;                     (file ,file)
;;                     :if-new
;; 										(file+head ,target ,head)
;; 										:unnarrowed t))))))

;; (defun org-dt-load-templates ()
;; 	"Load templates from project root folder"
;; 	(interactive)
;; 	(when-let* ((root (org-dt--templates-dir))
;; 							((file-directory-p root))
;; 							(dir (org-dt--select-template-dir root))
;; 							(files (sort (directory-files dir t "\\.org$")
;; 													 #'string<)))
;; 		(let ((used-keys '()))
;; 			(setq org-roam-capture-templates
;; 						(cl-loop
;; 						 for file in files
;; 						 for name = (file-name-base file)
;; 						 for key = (org-dt--generate-key name used-keys)
;; 						 do (push key used-keys)
;; 						 collect
;; 						 `(,key ,name
;; 										plain
;; 										(file ,file)
;; 										:if-new
;; 										(file+head
;; 										 "%(identity org-dt-capture-target)"
;; 										 "%(identity org-dt-capture-head)")
;; 										:unnarrowed t))))))

;; (let ((used-keys '()))
;;   (setq org-roam-capture-templates
;;         (cl-loop
;;          for file in files
;;          for name = (file-name-base file)
;;          for key = (org-dt--generate-key name used-keys)
;;          for target = org-dt-capture-target
;;          for head = org-dt-capture-head
;;          do (push key used-keys)
;;          collect
;;          `(,key ,name
;;                 plain
;;                 (file ,file)
;;                 :if-new
;;                 (file+head ,target ,head)
;;                 :unnarrowed t))))))

(provide 'org-dt)
;;; org-dt.el ends here
