;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "date2name" "0.0.1"
  "Package to prepend ISO Timestamps to files."
  ()
  :url "https://github.com/DerBeutlin/date2name.el"
  :commit "121e86d99feecc70b8269db911e8813139602c75"
  :revdesc "121e86d99fee"
  :keywords '("files" "convenience"))
