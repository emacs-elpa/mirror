;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-ispell" "0.7"
  "Ispell completion source for auto-complete."
  '((auto-complete "1.4")
    (cl-lib        "0.5"))
  :url "https://github.com/syohex/emacs-ac-ispell"
  :commit "a8c84f7f0b96dc091abc51b1698f24e9c994e6aa"
  :revdesc "a8c84f7f0b96"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
