;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iasm-mode" "0.1"
  "Interactive assembly major mode."
  ()
  :url "https://github.com/RAttab/iasm-mode"
  :commit "8b741f13ff34e748337b11199239a919348bbb61"
  :revdesc "8b741f13ff34"
  :keywords '(":" "tools")
  :authors '(("Rémi Attab" . "remi.attab@gmail.com"))
  :maintainers '(("Rémi Attab" . "remi.attab@gmail.com")))
