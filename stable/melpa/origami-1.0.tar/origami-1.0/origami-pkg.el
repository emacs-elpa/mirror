;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "origami" "1.0"
  "Flexible text folding."
  '((emacs "24"))
  :url "https://github.com/gregsexton/"
  :commit "30442bbbb12a9962e4a91ed9f4bb6f3ffd16c080"
  :revdesc "30442bbbb12a"
  :keywords '("folding")
  :authors '(("Greg Sexton" . "gregsexton@gmail.com"))
  :maintainers '(("Greg Sexton" . "gregsexton@gmail.com")))
