;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zoxide" "1.2.3"
  "Find file by zoxide."
  '((emacs "25.1"))
  :url "https://gitlab.com/Vonfry/zoxide.el"
  :commit "b412457d9dc0802db6dcc304976c80aa3773597d"
  :revdesc "1.2.3-0-gb412457d9dc0"
  :keywords '("converience" "matching")
  :authors '(("Ruoyu Feng" . "emacs@vonfry.name"))
  :maintainers '(("Ruoyu Feng" . "emacs@vonfry.name")))
