;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.5.0"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "7177af78bc67dccbff1705e623b823bd9c13da60"
  :revdesc "7177af78bc67"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
