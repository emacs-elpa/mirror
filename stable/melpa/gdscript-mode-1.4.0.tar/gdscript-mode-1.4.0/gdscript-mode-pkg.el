;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "1.4.0"
  "Major mode for Godot's GDScript language."
  '((emacs "26.3"))
  :url "https://github.com/GDQuest/emacs-gdscript-mode/"
  :commit "ef7a7f2789d0708a624a93b0f7037dd057cd8532"
  :revdesc "ef7a7f2789d0"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '((nil . "nathan@gdquest.com")))
