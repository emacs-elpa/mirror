;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cyanometric-theme" "1.0.2"
  "A Theme with overwhelming bias towards cyan."
  '((autothemer "0.2")
    (emacs      "24"))
  :url "https://github.com/emacsfodder/emacs-theme-cyanometric"
  :commit "9b20e33a8cc2c76bfe6ad45916be6881386707f5"
  :revdesc "9b20e33a8cc2"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
