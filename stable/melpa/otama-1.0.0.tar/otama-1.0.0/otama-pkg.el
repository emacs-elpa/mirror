;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otama" "1.0.0"
  "Org-table Manipulator."
  ()
  :url "https://github.com/yoshinari-nomura/otama"
  :commit "75282bff112685cbf07d1103f29480f04e312636"
  :revdesc "75282bff1126"
  :keywords '("database" "org-mode")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
