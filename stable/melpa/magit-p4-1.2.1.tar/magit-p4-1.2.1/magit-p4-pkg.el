;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-p4" "1.2.1"
  "Git-p4 plug-in for Magit."
  '((emacs       "25.1")
    (magit       "2.1")
    (magit-popup "2.1")
    (p4          "12.0")
    (cl-lib      "0.5"))
  :url "https://github.com/qoocku/magit-p4"
  :commit "0fd0f882eb14510714393c15c2ccb8d2c259f01e"
  :revdesc "v1.2.1-0-g0fd0f882eb14"
  :keywords '("vc" "tools")
  :authors '(("Damian T. Dobroczyński" . "qoocku@gmail.com"))
  :maintainers '(("Aleksey Fedotov" . "lexa@cfotr.com")))
