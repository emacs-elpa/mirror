;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comby" "20171023.358"
  "Emacs comby integration."
  '((emacs "25.1"))
  :url "https://github.com/s-kostyaev/comby.el"
  :commit "e3b1958afc130cab8f9d79ba7d4a678e4453e1d7"
  :revdesc "e3b1958afc13"
  :keywords '("languages")
  :authors '(("Sergey Kostyaev" . "feo.me@ya.ru"))
  :maintainers '(("Sergey Kostyaev" . "feo.me@ya.ru")))
