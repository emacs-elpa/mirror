;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-crystal" "0.0.1"
  "Org-babel functions for Crystal evaluation."
  ()
  :url "https://github.com/brantou/ob-crystal"
  :commit "5761cfa19b6eb80beee77cf5f2baf7ad6b39b4ac"
  :revdesc "5761cfa19b6e"
  :keywords '("crystal" "literate programming" "reproducible research")
  :authors '(("Brantou" . "brantou89@gmail.com"))
  :maintainers '(("Brantou" . "brantou89@gmail.com")))
