;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "schlau-compile" "1.0.0"
  "An interface to `compile'."
  ()
  :url "https://github.com/flajann2/elisp#schlau-compile"
  :commit "82698a878c821043efafba54d784d2f38f067e71"
  :revdesc "82698a878c82"
  :keywords '("tools" "unix" "git")
  :authors '(("Fred Mitchell" . "fred.mitchell@gmx.de"))
  :maintainers '(("Fred Mitchell" . "fred.mitchell@gmx.de")))
