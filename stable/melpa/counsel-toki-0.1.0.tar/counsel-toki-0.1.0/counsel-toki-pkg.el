;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-toki" "0.1.0"
  "Counsel support for toki pona dictionary lookup."
  '((request "20230127.417")
    (emacs   "24.4")
    (ivy     "0.14.0"))
  :url "https://github.com/emiflake/counsel-toki"
  :commit "e62aad8beb0a019841cd28ffab67d51384723a57"
  :revdesc "e62aad8beb0a"
  :authors '(("Emily Martins" . "emi@haskell.fyi"))
  :maintainers '(("Emily Martins" . "emi@haskell.fyi")))
