;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rcirc-alertify" "0.1"
  "Cross platform notifications for rcirc."
  '((alert "20140406.1353"))
  :url "https://github.com/fgallina/rcirc-alertify"
  :commit "8f9d3621f798ccafc86174d10ec4d756c293b069"
  :revdesc "8f9d3621f798"
  :keywords '("comm" "convenience")
  :authors '(("Fabián Ezequiel Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Fabián Ezequiel Gallina" . "fgallina@gnu.org")))
