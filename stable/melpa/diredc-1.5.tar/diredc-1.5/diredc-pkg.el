;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "1.5"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "6072d009712f31ec58a49140ffa9da05f0f2b2c1"
  :revdesc "6072d009712f"
  :keywords '("files"))
