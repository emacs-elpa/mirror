;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql-to-org" "1.0.0"
  "Minor mode to output the results of mysql queries to org tables."
  '((emacs "24.3")
    (s     "1.11.0"))
  :url "https://github.com/mallt/mysql-to-org-mode"
  :commit "0f51b174a0ee6c9820baf9d79783923b270f3ffc"
  :revdesc "0f51b174a0ee"
  :authors '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com"))
  :maintainers '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com")))
