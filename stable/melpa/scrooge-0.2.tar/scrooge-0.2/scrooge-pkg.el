;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scrooge" "0.2"
  "Major mode for Twitter Scrooge files."
  '((emacs              "24")
    (cl-lib             "0.5")
    (dash               "2.13.0")
    (rainbow-delimiters "1.3.7")
    (thrift             "0.9.3"))
  :url "https://github.com/cosmicexplorer/emacs-scrooge"
  :commit "8ed9d2e51221a42d1798f1c3f7487dc8a45b3d5e"
  :revdesc "8ed9d2e51221"
  :keywords '("scrooge" "thrift")
  :authors '(("Daniel McClanahan" . "danieldmcclanahan@gmail.com"))
  :maintainers '(("Daniel McClanahan" . "danieldmcclanahan@gmail.com")))
