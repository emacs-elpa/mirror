;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-sourcekit" "0.1"
  "Sourcekit-lsp client for lsp-mode."
  '((emacs    "25.1")
    (lsp-mode "4.2"))
  :url "https://github.com/emacs-lsp/lsp-sourcekit"
  :commit "4a021e2717b29909f116cd82062dbc6f5c76e0f2"
  :revdesc "4a021e2717b2"
  :keywords '("languages" "lsp" "swift" "objective-c" "c++"))
