;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keg" "0.0.1"
  "Modern Elisp package development system."
  '((emacs "26.1"))
  :url "https://github.com/conao3/keg.el"
  :commit "8fcf39a56fb3169e93fb29fd457bb11a2ec8ca1f"
  :revdesc "8fcf39a56fb3"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
