;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-leading-spaces" "0.1"
  "Highlight leading spaces."
  '((emacs "24.4"))
  :url "https://github.com/mrBliss/highlight-leading-spaces"
  :commit "7dfc3cc2b9e9e91d1c500b0174f1320a49709292"
  :revdesc "7dfc3cc2b9e9"
  :authors '(("Thomas Winant" . "dewinant@gmail.com"))
  :maintainers '(("Thomas Winant" . "dewinant@gmail.com")))
