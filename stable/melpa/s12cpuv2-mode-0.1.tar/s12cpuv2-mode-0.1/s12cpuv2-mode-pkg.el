;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "s12cpuv2-mode" "0.1"
  "Major-mode for S12CPUV2 assembly."
  ()
  :url "https://github.com/AdamNiederer/s12cpuv2-mode"
  :commit "8f458f283f65e0f267cacde63eca188a13f36e76"
  :revdesc "8f458f283f65"
  :keywords '("s12cpuv2" "assembly")
  :authors '(("Adam Niederer" . "adam.niederer@gmail.com"))
  :maintainers '(("Adam Niederer" . "adam.niederer@gmail.com")))
