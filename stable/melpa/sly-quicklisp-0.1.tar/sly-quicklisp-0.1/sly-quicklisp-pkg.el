;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly-quicklisp" "0.1"
  "A template SLY contrib."
  '((sly "1.0.0-beta2"))
  :url "https://github.com/capitaomorte/sly-quicklisp"
  :commit "a9f029e6c34fd4aa485c875db6c556d995b8a3fa"
  :revdesc "a9f029e6c34f"
  :keywords '("languages" "lisp" "sly")
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
