;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noxml-fold" "0.0.2"
  "Fold away XML things."
  ()
  :url "https://github.com/paddymcall/noxml-fold"
  :commit "56fbc44b25cee9f8719edb3c7f8b1c4327dc1051"
  :revdesc "56fbc44b25ce"
  :keywords '("xml" "folding")
  :authors '(("Patrick McAllister" . "pma@rdorte.org"))
  :maintainers '(("Patrick McAllister" . "pma@rdorte.org")))
