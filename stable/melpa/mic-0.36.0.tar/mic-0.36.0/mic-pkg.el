;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mic" "0.36.0"
  "Minimal and combinable configuration manager."
  '((emacs "26.1"))
  :url "https://github.com/ROCKTAKEY/mic"
  :commit "fcb51a8171354d1d912c29095488ed8536b89bb0"
  :revdesc "v0.36.0-0-gfcb51a817135"
  :keywords '("convenience")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
