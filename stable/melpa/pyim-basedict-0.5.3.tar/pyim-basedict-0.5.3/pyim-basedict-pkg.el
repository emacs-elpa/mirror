;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyim-basedict" "0.5.3"
  "The default pinyin dict of pyim."
  ()
  :url "https://github.com/tumashu/pyim-basedict"
  :commit "4aa30ff9f83cf6435230a987d323e48230f1f40e"
  :revdesc "4aa30ff9f83c"
  :keywords '("convenience" "chinese" "pinyin" "input-method" "complete")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
