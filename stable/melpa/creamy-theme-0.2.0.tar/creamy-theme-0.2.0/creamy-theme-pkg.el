;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "creamy-theme" "0.2.0"
  "A simple creamy theme."
  '((emacs "24.1"))
  :url "https://github.com/smallwat3r/emacs-creamy-theme"
  :commit "3bceabac758378d91d07ba39b855e744be7e3c54"
  :revdesc "3bceabac7583")
