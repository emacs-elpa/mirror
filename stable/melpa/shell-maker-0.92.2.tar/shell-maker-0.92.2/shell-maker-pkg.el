;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.92.2"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "adce7baa92d5715eaf2defc77eb394576eb226f1"
  :revdesc "adce7baa92d5")
