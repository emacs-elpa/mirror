;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-snippets" "1.0.1"
  "Yasnippets for clojure."
  '((yasnippet "0.8.0"))
  :url "https://github.com/mpenet/clojure-snippets"
  :commit "83785faa607884308a42b81f160854f2cecfd098"
  :revdesc "83785faa6078"
  :keywords '("snippets")
  :authors '(("Max Penet" . "m@qbits.cc"))
  :maintainers '(("Max Penet" . "m@qbits.cc")))
