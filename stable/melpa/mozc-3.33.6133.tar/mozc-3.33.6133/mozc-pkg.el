;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc" "3.33.6133"
  "Minor mode to input Japanese with Mozc."
  '((emacs "24.3"))
  :url "https://github.com/google/mozc"
  :commit "c9163b6bb1010671781b8acd358b025c519fc1e0"
  :revdesc "3.33.6133-0-gc9163b6bb101"
  :keywords '("mule" "multilingual" "input method"))
