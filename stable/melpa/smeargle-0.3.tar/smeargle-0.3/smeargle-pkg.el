;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smeargle" "0.3"
  "Highlighting region by last updated time."
  '((emacs "24.3"))
  :url "https://github.com/syohex/emacs-smeargle"
  :commit "0665b1ff5109731898bc4a0ca6d939933b804777"
  :revdesc "0665b1ff5109"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
