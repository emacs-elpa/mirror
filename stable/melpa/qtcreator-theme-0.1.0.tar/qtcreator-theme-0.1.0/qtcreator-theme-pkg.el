;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qtcreator-theme" "0.1.0"
  "A color theme that mimics the default theme of the Qt Creator IDE."
  '((emacs "24.3"))
  :url "https://github.com/LesleyLai/emacs-qtcreator-theme"
  :commit "3f52d66c6381a3ce78e30ee2534c24b372c71f97"
  :revdesc "3f52d66c6381"
  :keywords '("theme" "light" "faces")
  :authors '(("Lesley Lai" . "lesley@lesleylai.info"))
  :maintainers '(("Lesley Lai" . "lesley@lesleylai.info")))
