;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-etags" "2.0.5"
  "Fast and complete Ctags solution using ivy."
  '((emacs   "28.1")
    (counsel "0.15.1"))
  :url "https://github.com/redguardtoo/counsel-etags"
  :commit "385eb738d09ce47f905982532e2b03cfb8381f17"
  :revdesc "385eb738d09c"
  :keywords '("tools" "convenience"))
