;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-who" "1.0"
  "A s-expression html DSL library compatible with cl-who."
  '((emacs "25.1"))
  :url "https://github.com/alejandrogallo/p5js"
  :commit "97148c72e365bf228d7e418e47f6525151a62545"
  :revdesc "97148c72e365"
  :keywords '("lisp" "hypermedia" "docs" "tools" "html" "web")
  :authors '(("Alejandro Gallo" . "aamsgallo@gmail.com"))
  :maintainers '(("Alejandro Gallo" . "aamsgallo@gmail.com")))
