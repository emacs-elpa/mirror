;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "togetherly" "0.1.1"
  "Allow multiple clients to edit a single buffer online."
  '((cl-lib "0.3"))
  :url "http://hins11.yu-yake.com/"
  :commit "971b19712787ce6c6f3a2ee7b8424d8c8878029b"
  :revdesc "971b19712787")
