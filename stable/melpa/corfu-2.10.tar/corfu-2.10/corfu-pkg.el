;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.10"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "4a9c67da16eb64cadaa4bfcc16713188145c83da"
  :revdesc "2.10-0-g4a9c67da16eb"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
