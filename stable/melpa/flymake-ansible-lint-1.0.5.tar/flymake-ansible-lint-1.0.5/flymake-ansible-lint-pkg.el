;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ansible-lint" "1.0.5"
  "A Flymake backend for ansible-lint."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/flymake-ansible-lint.el"
  :commit "c5375aea83586e1ae97e6c2fa74ea61cf44d98f4"
  :revdesc "1.0.5-0-gc5375aea8358"
  :keywords '("tools"))
