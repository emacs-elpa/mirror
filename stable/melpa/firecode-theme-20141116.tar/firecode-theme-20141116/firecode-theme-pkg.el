;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firecode-theme" "20141116"
  "An Emacs 24 theme based on FireCode (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "4c7f683c555818376b1a6a03e8f0e2db0d5c90bc"
  :revdesc "4c7f683c5558")
