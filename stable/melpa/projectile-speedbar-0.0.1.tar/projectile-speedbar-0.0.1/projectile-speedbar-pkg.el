;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-speedbar" "0.0.1"
  "[No description available]."
  '((projectile "0.11.0"))
  :url "https://github.com/anshulverma/projectile-speedbar"
  :commit "50daf1791bf823ef14587ab53f39c87267233dda"
  :revdesc "50daf1791bf8"
  :keywords '("project" "convenience" "speedbar" "projectile")
  :authors '(("Anshul Verma" . "anshul.verma86@gmail.com"))
  :maintainers '(("Anshul Verma" . "anshul.verma86@gmail.com")))
