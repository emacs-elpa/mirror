;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "naquadah-theme" "0.0.0.20260913.101"
  "A theme based on Tango color set."
  ()
  :url "https://github.com/jd/naquadah-theme"
  :commit "e097c227b43520d7a08e86224432346c10b49aea"
  :revdesc "e097c227b435"
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")))
