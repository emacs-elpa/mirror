;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-line" "1.6"
  "Custom and simple mode line."
  '((emacs "29.1"))
  :url "https://gitlab.com/aimebertrand/timu-line"
  :commit "9ba731bd947b5851509c487be8f19887aab84234"
  :revdesc "9ba731bd947b"
  :keywords '("modeline" "frames" "ui")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
