;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.0.5"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "7038a9dcfa7e2d8848817508777d8ad878756cfb"
  :revdesc "1.0.5-0-g7038a9dcfa7e"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
