;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-web-track" "0.1.1"
  "Web data tracking framework in Org Mode."
  '((emacs   "29.1")
    (request "0.3.0")
    (enlive  "0.0.1")
    (gnuplot "0.8.1"))
  :url "https://github.com/p-snow/org-web-track"
  :commit "2cf9367ef6f8800fa058a8ca30cbb6f2e75fe4de"
  :revdesc "2cf9367ef6f8"
  :keywords '("org" "agenda" "web" "hypermedia")
  :authors '(("p-snow" . "public@p-snow.org"))
  :maintainers '(("p-snow" . "public@p-snow.org")))
