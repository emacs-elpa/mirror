;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-imenu" "0.5.0"
  "Imenu binding for dired mode."
  ()
  :url "https://github.com/DamienCassou/dired-imenu"
  :commit "610e21fe0988c85931d34894d3eee2442c79ab0a"
  :revdesc "610e21fe0988"
  :keywords '("dired" "imenu")
  :authors '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainers '(("Damien Cassou" . "damien.cassou@gmail.com")))
