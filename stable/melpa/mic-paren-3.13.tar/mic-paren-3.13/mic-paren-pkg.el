;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mic-paren" "3.13"
  "Advanced highlighting of matching parentheses."
  ()
  :url "https://github.com/emacsattic/mic-paren"
  :commit "d0332fae515af2fa461d19afa7f933588afc327f"
  :revdesc "d0332fae515a"
  :keywords '("languages" "faces" "parenthesis" "matching")
  :authors '(("Mikael Sjödin" . "(mic@docs.uu.se)")
             ("Klaus Berndl" . "berndl@sdm.de")
             ("Jonathan Kotta" . "jpkotta@gmail.com")))
