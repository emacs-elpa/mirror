;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "play-routes-mode" "1.0"
  "Play Framework Routes File Support."
  ()
  :url "https://github.com/brocode/play-routes-mode/"
  :commit "d7eb682cd474d90b3a3d005290cd6d4fe9f94cae"
  :revdesc "d7eb682cd474"
  :keywords '("play" "scala")
  :authors '(("M.Riehl" . "max@flatmap.ninja")
             ("P.Haun" . "bomgar85@googlemail.com"))
  :maintainers '(("M.Riehl" . "max@flatmap.ninja")
                 ("P.Haun" . "bomgar85@googlemail.com")))
