;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rg-themes" "0.1.0"
  "The rg theme collection."
  '((emacs "25.1"))
  :url "https://github.com/raegnald/rg-themes"
  :commit "3003e2fe4df63b98f2f87af46bb03d8eb4a82146"
  :revdesc "3003e2fe4df6"
  :keywords '("faces")
  :authors '(("Ronaldo Gligan" . "ronaldogligan@gmail.com"))
  :maintainers '(("Ronaldo Gligan" . "ronaldogligan@gmail.com")))
