;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adafruit-wisdom" "0.3.0"
  "Get/display adafruit.com quotes."
  '((emacs   "25")
    (request "0.3.1"))
  :url "https://github.com/gonewest818/adafruit-wisdom.el"
  :commit "50414eaac3dbeb67a1329833b912d26b164873eb"
  :revdesc "50414eaac3db"
  :keywords '("games")
  :authors '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com"))
  :maintainers '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com")))
