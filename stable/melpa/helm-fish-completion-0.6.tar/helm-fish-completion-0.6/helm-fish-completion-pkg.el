;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-fish-completion" "0.6"
  "Helm interface for fish completion."
  '((emacs           "25")
    (helm            "3")
    (fish-completion "1.2"))
  :url "https://github.com/emacs-helm/helm-fish-completion"
  :commit "2a2001b3a876da3c468ffec8935572509c485aac"
  :revdesc "2a2001b3a876"
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
