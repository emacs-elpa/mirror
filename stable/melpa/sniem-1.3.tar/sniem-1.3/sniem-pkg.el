;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sniem" "1.3"
  "Hands-eased united editing method."
  '((emacs "27.1")
    (s     "2.12.0")
    (dash  "1.12.0"))
  :url "https://github.com/SpringHan/sniem.git"
  :commit "5020c8efc0a6d575bd277942353869322275c9bf"
  :revdesc "5020c8efc0a6"
  :keywords '("convenience" "united-editing-method"))
