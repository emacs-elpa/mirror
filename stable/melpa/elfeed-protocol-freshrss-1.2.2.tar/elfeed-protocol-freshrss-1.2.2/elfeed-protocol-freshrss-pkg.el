;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-protocol-freshrss" "1.2.2"
  "FreshRSS protocol for elfeed."
  '((emacs            "29.1")
    (elfeed           "4.0.0")
    (elfeed-protocol  "1.0.0")
    (deferred         "0.5.1")
    (request          "0.3.2")
    (request-deferred "0.3.2"))
  :url "https://codeberg.org/lou/elfeed-protocol-freshrss"
  :commit "47de2f60571f0346653b054049b69f23588d0c64"
  :revdesc "47de2f60571f"
  :authors '(("Lou Woell" . "lou@repetitions.de"))
  :maintainers '(("Lou Woell" . "lou@repetitions.de")))
