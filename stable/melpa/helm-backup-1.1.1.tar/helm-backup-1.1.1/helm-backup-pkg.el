;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-backup" "1.1.1"
  "Backup each file change using git."
  '((helm   "1.5.5")
    (s      "1.8.0")
    (cl-lib "0"))
  :url "https://github.com/antham/helm-backup"
  :commit "45a86a41ac44f90d4db2c0e9339233ee7f0be0b8"
  :revdesc "45a86a41ac44"
  :keywords '("backup" "convenience" "files" "tools" "vc")
  :authors '(("Anthony HAMON" . "hamon.anth@gmail.com"))
  :maintainers '(("Anthony HAMON" . "hamon.anth@gmail.com")))
