;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elscreen-separate-buffer-list" "0.1.3"
  "Separate buffer list manager for elscreen."
  '((emacs    "24.4")
    (elscreen "1.4.6"))
  :url "https://github.com/wamei/elscreen-separate-buffer-list"
  :commit "ed75561e9cd2ce6e719eb9f91fe20f13f2867526"
  :revdesc "ed75561e9cd2"
  :keywords '("elscreen")
  :authors '(("wamei" . "wamei.cho@gmail.com"))
  :maintainers '(("wamei" . "wamei.cho@gmail.com")))
