;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bar-cursor" "2.0"
  "Package used to switch block cursor to a bar."
  ()
  :url "https://github.com/ajsquared/bar-cursor"
  :commit "afa1d4bc1937610cc30575d71aab85ea20ebf2ea"
  :revdesc "afa1d4bc1937"
  :keywords '("files")
  :authors '(("Joe Casadonte" . "(emacs@northbound-train.com)"))
  :maintainers '(("Andrew Johnson" . "(andrew@andrewjamesjohnson.com)")))
