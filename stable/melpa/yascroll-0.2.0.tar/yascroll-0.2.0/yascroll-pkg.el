;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yascroll" "0.2.0"
  "Yet Another Scroll Bar Mode."
  '((emacs "26.1"))
  :url "https://github.com/emacsorphanage/yascroll"
  :commit "cd66d81c5d4ba39da3c385d12d22f7103ecd67c5"
  :revdesc "cd66d81c5d4b"
  :keywords '("convenience")
  :authors '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
