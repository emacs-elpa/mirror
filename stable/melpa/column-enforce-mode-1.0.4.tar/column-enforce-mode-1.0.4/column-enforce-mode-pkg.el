;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "column-enforce-mode" "1.0.4"
  "Highlight text that extends beyond a  column."
  ()
  :url "www.github.com/jordonbiondo/column-enforce-mode"
  :commit "59e230d9a7cba574f53a768ed0574ef6a302913f"
  :revdesc "59e230d9a7cb")
