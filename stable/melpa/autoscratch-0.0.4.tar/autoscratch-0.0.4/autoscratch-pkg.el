;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autoscratch" "0.0.4"
  "Automatically switch scratch buffer mode."
  '((emacs "24.1"))
  :url "https://github.com/tlinden/autoscratch"
  :commit "8c6488183a91a968cd90e148b79527f26b936fb2"
  :revdesc "8c6488183a91"
  :keywords '("convenience" "buffer" "scrach")
  :authors '(("T.v.Dein" . "tlinden@cpan.org"))
  :maintainers '(("T.v.Dein" . "tlinden@cpan.org")))
