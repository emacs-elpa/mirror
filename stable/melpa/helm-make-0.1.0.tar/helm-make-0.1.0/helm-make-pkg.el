;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-make" "0.1.0"
  "Select a Makefile target with helm."
  '((helm       "1.5.3")
    (projectile "0.11.0"))
  :url "https://github.com/abo-abo/helm-make"
  :commit "6558a79d20d04465419b312da198190be6832647"
  :revdesc "6558a79d20d0"
  :keywords '("makefile")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
