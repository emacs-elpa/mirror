;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "echo-bar" "1.0.0"
  "Turn the echo area into a custom status bar."
  ()
  :url "https://github.com/benzanol/echo-bar.el"
  :commit "096eca53a9bb85ce944dab4abbf42302de6710b4"
  :revdesc "096eca53a9bb"
  :keywords '("tools")
  :authors '(("Adam Tillou" . "qaiviq@gmail.com"))
  :maintainers '(("Adam Tillou" . "qaiviq@gmail.com")))
