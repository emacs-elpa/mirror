;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "starhugger" "0.6.0"
  "Hugging Face/AI-powered text & code completion client."
  '((emacs   "28.2")
    (compat  "29.1.4.0")
    (dash    "2.18.0")
    (s       "1.13.1")
    (spinner "1.7.4")
    (request "0.3.2"))
  :url "https://gitlab.com/daanturo/starhugger.el"
  :commit "46f32d4444d4cf6a8937e89538371c97eb0a65dd"
  :revdesc "46f32d4444d4"
  :keywords '("completion" "convenience" "languages"))
