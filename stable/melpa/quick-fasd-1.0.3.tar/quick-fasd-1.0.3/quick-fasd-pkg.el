;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "1.0.3"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "1f533ad7e4b6c7d189511cf4baeac2942f2aeb15"
  :revdesc "1.0.3-0-g1f533ad7e4b6"
  :keywords '("convenience" "files" "tools"))
