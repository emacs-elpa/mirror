;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atomic-chrome" "2.0.0"
  "Edit Chrome text area with Emacs using Atomic Chrome."
  '((emacs     "24.3")
    (let-alist "1.0.4")
    (websocket "1.4"))
  :url "https://github.com/alpha22jp/atomic-chrome"
  :commit "38ce9127285e1ff45f0f39b9da36a682103bdb96"
  :revdesc "38ce9127285e"
  :keywords '("chrome" "edit" "textarea")
  :authors '(("alpha22jp" . "alpha22jp@gmail.com"))
  :maintainers '(("alpha22jp" . "alpha22jp@gmail.com")))
