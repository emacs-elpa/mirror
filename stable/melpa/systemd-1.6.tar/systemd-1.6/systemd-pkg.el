;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "systemd" "1.6"
  "Major mode for editing systemd units."
  '((emacs "24.4"))
  :url "https://github.com/holomorph/systemd-mode"
  :commit "1e7567a9973bf80cab0d7e0355656a84bee7ca96"
  :revdesc "v1.6-0-g1e7567a9973b"
  :keywords '("tools" "unix")
  :authors '(("Mark Oteiza" . "mvoteiza@udel.edu"))
  :maintainers '(("Mark Oteiza" . "mvoteiza@udel.edu")))
