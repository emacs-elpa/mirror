;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "0.53"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (compat    "31")
    (fedi      "0.5")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "74b0eb22a4fec30900a2c1b16222b4ff305fff61"
  :revdesc "74b0eb22a4fe"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
