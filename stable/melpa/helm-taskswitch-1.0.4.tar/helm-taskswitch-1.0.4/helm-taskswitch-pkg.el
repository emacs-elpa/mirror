;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-taskswitch" "1.0.4"
  "Use helm to switch windows and buffers."
  '((emacs "24")
    (helm  "3.0"))
  :url "https://github.com/bdc34/helm-taskswitch"
  :commit "de494738f8e5f7d6e681199dd3aad91e5bdb7691"
  :revdesc "de494738f8e5"
  :keywords '("desktop" "windows")
  :authors '(("Brian Caruso" . "briancaruso@gmail.com"))
  :maintainers '(("Brian Caruso" . "briancaruso@gmail.com")))
