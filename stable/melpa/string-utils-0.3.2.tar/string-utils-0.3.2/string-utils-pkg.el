;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "string-utils" "0.3.2"
  "String-manipulation utilities."
  '((list-utils "0.4.2"))
  :url "https://github.com/rolandwalker/string-utils"
  :commit "3ae530143899f533a9ef5e1f26f28b577ebe72ee"
  :revdesc "v0.3.2-0-g3ae530143899"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
