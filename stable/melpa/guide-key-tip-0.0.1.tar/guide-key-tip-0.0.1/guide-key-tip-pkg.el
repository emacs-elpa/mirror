;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guide-key-tip" "0.0.1"
  "Show guide-key.el hints using pos-tip.el."
  '((guide-key "1.2.3")
    (pos-tip   "0.4.5"))
  :url "https://github.com/aki2o/guide-key-tip"
  :commit "e08b2585228529aeaae5e0ae0948f898e83a6200"
  :revdesc "e08b25852285"
  :keywords '("help" "convenience" "tooltip")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
