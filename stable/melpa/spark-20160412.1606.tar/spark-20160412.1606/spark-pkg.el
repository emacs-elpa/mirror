;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spark" "20160412.1606"
  "Sparkline generation."
  '((emacs "24.3"))
  :url "https://github.com/alvinfrancis/spark"
  :commit "31e2e9322c3f405e045bc0083cae8bdeed7f763b"
  :revdesc "31e2e9322c3f"
  :keywords '("lisp" "data"))
