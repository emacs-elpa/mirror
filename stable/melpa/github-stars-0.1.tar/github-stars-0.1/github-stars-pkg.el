;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-stars" "0.1"
  "Browse your Github Stars."
  '((emacs "25.1")
    (ghub  "2.0.0"))
  :url "https://github.com/xuchunyang/github-stars.el"
  :commit "d8e1a7216b86d54c7d8cae661083546c0a0cc3c2"
  :revdesc "d8e1a7216b86"
  :keywords '("tools")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
