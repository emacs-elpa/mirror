;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diary-manager" "2.0.2"
  "Simple personal diary."
  '((emacs "25"))
  :url "https://github.com/raxod502/diary-manager"
  :commit "919f724bb58e36b8626dd8d7c8475f71c0c54443"
  :revdesc "919f724bb58e"
  :keywords '("extensions")
  :authors '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainers '(("Radon Rosborough" . "radon.neon@gmail.com")))
