;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lingr" "0.2"
  "Lingr Client for GNU Emacs."
  ()
  :url "https://github.com/lugecy/lingr-el"
  :commit "c9c20dd9b4967aa2f8873d6890d6797e6a498d23"
  :revdesc "v0.2-0-gc9c20dd9b496"
  :keywords '("chat" "client" "internet")
  :authors '(("lugecy" . "lugecy@gmail.com"))
  :maintainers '(("lugecy" . "lugecy@gmail.com")))
