;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-tip" "0.5.0"
  "Show flycheck/flymake errors by tooltip."
  '((flycheck "0.13")
    (emacs    "24.1")
    (popup    "0.5.0"))
  :url "https://github.com/yuutayamada/flycheck-tip"
  :commit "0bfddf52ae4ec48d970324f8336a5d62986bbc9e"
  :revdesc "0bfddf52ae4e"
  :keywords '("flycheck")
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
