;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "balanced-windows" "1.0.0"
  "Keep windows balanced."
  '((emacs "25"))
  :url "https://github.com/wbolster/emacs-balanced-windows"
  :commit "ec3ccd1bee04c5f0c517fc48e4a080b17c89d537"
  :revdesc "ec3ccd1bee04"
  :keywords '("convenience")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
