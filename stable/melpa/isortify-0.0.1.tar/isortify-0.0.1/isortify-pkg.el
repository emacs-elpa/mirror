;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "isortify" "0.0.1"
  "(automatically) format python buffers using isort."
  ()
  :url "https://github.com/proofit404/isortify"
  :commit "6714d63f254e2eecc1ca3d533ba6f59a66bc2791"
  :revdesc "6714d63f254e"
  :authors '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers '(("Artem Malyshev" . "proofit404@gmail.com")))
