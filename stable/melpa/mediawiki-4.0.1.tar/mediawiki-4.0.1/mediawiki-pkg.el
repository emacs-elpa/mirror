;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "4.0.1"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "bcee6701b474bb805d558e58e7d0e29d999dc873"
  :revdesc "bcee6701b474"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
