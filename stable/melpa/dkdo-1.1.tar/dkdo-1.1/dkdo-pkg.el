;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dkdo" "1.1"
  "Do List major mode based on org-mode."
  '((dkmisc "0.50")
    (emacs  "24.1"))
  :url "https://github.com/davidkeegan/dkdo"
  :commit "b7be2eefbcb8f59a902f5ea1fb2804bc897de00d"
  :revdesc "b7be2eefbcb8"
  :keywords '("dolist" "task" "productivity")
  :authors '(("David Keegan" . "dksw@eircom.net"))
  :maintainers '(("David Keegan" . "dksw@eircom.net")))
