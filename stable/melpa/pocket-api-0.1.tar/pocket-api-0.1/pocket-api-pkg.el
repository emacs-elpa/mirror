;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pocket-api" "0.1"
  "Read and write to Pocket (getpocket.com) ;;."
  '((request "0.5.2")
    (emacs   "24"))
  :url "https://github.com/lujun9972/pocket-api"
  :commit "c1694d224fce2288baef78e312a87b18c142d9f5"
  :revdesc "c1694d224fce"
  :keywords '("emacs" "pocket" "bookmarks")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
