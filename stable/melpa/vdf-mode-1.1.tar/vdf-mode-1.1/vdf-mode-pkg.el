;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vdf-mode" "1.1"
  "Major mode for editing Valve VDF files."
  ()
  :url "https://github.com/plapadoo/vdf-mode"
  :commit "f474047a35a2779e4ebaf9166f3d54f359cf9f3c"
  :revdesc "f474047a35a2")
