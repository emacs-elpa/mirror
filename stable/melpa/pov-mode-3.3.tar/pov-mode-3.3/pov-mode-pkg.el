;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pov-mode" "3.3"
  "Major mode for Povray scene files."
  ()
  :url "https://github.com/melmothx/pov-mode"
  :commit "e8836bda90a4cf86578f326104880959d622eb65"
  :revdesc "e8836bda90a4"
  :keywords '("pov" "povray")
  :authors '(("Peter Boettcher" . "pwb@andrew.cmu.edu"))
  :maintainers '(("Marco Pessotto" . "melmothx@gmail.com")))
