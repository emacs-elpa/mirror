;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mowie" "0.1.1"
  "Cycle Through Point-Moving Commands."
  '((emacs "28.1"))
  :url "https://codeberg.org/mekeor/mowie"
  :commit "7b826c751014a294b493a6bfebe1cda6a1832ab0"
  :revdesc "7b826c751014"
  :keywords '("convenience")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
