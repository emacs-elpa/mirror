;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-css-scss" "1.3"
  "CSS/SCSS/LESS Selectors with helm interface."
  '((helm  "1.0")
    (emacs "24"))
  :url "https://github.com/ShingoFukuyama/helm-css-scss"
  :commit "6a50b4ebcd90e0eaa6121c226428851f2e8f47cf"
  :revdesc "6a50b4ebcd90"
  :keywords '("scss" "css" "less" "selector" "helm"))
