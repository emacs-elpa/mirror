;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnu-indent" "1.0"
  "Indent your code with GNU Indent."
  '((emacs "27.2"))
  :url "https://codeberg.org/akib/emacs-why-this"
  :commit "6bb82ce89ed93222dd919bc65e0f46ac4aa13479"
  :revdesc "6bb82ce89ed9"
  :keywords '("tools" "convenience" "vc")
  :authors '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainers '(("Akib Azmain Turja" . "akib@disroot.org")))
