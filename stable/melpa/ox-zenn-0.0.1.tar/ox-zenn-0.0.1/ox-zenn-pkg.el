;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-zenn" "0.0.1"
  "Zenn flavored markdown backend for org export engine."
  '((emacs "26.1"))
  :url "https://github.com/conao3/ox-zenn.el"
  :commit "88c2d97f7cdd0abf4570da8637768aa3161da94c"
  :revdesc "88c2d97f7cdd"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
