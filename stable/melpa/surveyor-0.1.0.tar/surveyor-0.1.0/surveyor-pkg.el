;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "surveyor" "0.1.0"
  "Survey your code with LLM-generated diagrams."
  '((emacs     "29.1")
    (gptel     "0.9.0")
    (transient "0.4.0"))
  :url "https://github.com/mrcnski/surveyor.el"
  :commit "cc5caff1c5f57e15099c2eacba9243f59b2bd7f6"
  :revdesc "cc5caff1c5f5"
  :keywords '("convenience" "tools" "docs")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
