;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ember-mode" "0.3.1"
  "Ember navigation mode for emacs."
  '((cl-lib "0.5"))
  :url "https://github.com/madnificent/ember-mode"
  :commit "755256782478cb724edd8f111225d7c8d342f90c"
  :revdesc "755256782478"
  :keywords '("ember" "ember.js" "emberjs")
  :authors '(("Aad Versteden" . "madnificent@gmail.com"))
  :maintainers '(("Aad Versteden" . "madnificent@gmail.com")))
