;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-end" "0.4.1"
  "Automatic insertion of end blocks for Ruby."
  ()
  :url "https://github.com/rejeep/ruby-end"
  :commit "648b81af136a581bcef387744d93c011d9cdf54b"
  :revdesc "648b81af136a"
  :keywords '("speed" "convenience" "ruby")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
