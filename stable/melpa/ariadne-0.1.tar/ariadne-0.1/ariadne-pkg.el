;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ariadne" "0.1"
  "Ariadne plugin for Emacs."
  '((bert "0.1"))
  :url "https://github.com/manzyuk/ariadne-el"
  :commit "598d075abed0a7cbd44a82c1f24b73a43a12d2b8"
  :revdesc "598d075abed0"
  :keywords '("comm" "convenience" "processes")
  :authors '(("Oleksandr Manzyuk" . "manzyuk@gmail.com"))
  :maintainers '(("Oleksandr Manzyuk" . "manzyuk@gmail.com")))
