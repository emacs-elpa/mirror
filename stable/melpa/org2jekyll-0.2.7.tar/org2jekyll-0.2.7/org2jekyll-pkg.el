;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org2jekyll" "0.2.7"
  "Minor mode to publish org-mode post to jekyll without specific yaml."
  '((dash-functional "2.11.0")
    (s               "1.9.0"))
  :url "https://github.com/ardumont/org2jekyll"
  :commit "c05ba707190cfab20938afd1b5d4966511ca63b7"
  :revdesc "0.2.7-0-gc05ba707190c"
  :keywords '("org-mode" "jekyll" "blog" "publish")
  :authors '(("Antoine R. Dumont" . "antoine.romain.dumont@gmail.com"))
  :maintainers '(("Antoine R. Dumont" . "antoine.romain.dumont@gmail.com")))
