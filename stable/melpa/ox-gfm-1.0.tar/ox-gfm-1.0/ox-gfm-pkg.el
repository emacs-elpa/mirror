;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-gfm" "1.0"
  "Github Flavored Markdown Back-End for Org Export Engine."
  ()
  :url "https://github.com/larstvei/ox-gfm"
  :commit "99f93011b069e02b37c9660b8fcb45dab086a07f"
  :revdesc "99f93011b069"
  :keywords '("org" "wp" "markdown" "github"))
