;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "resize-window" "0.7"
  "Easily resize windows."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/dpsutton/resize-mode"
  :commit "dcbbd30f4f4435070a66a22c5a169b752ca9f904"
  :revdesc "dcbbd30f4f44"
  :keywords '("window" "resize")
  :authors '(("Dan Sutton" . "danielsutton01@gmail.com"))
  :maintainers '(("Dan Sutton" . "danielsutton01@gmail.com")))
