;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "define-scratch" "0.1.0"
  "Define new commands to make scratch buffers."
  '((emacs "24.3"))
  :url "https://github.com/lassik/emacs-define-scratch"
  :commit "22bebc6f4370b2bd41f4093859ff0d6e0ad0f277"
  :revdesc "22bebc6f4370"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
