;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tiny-menu" "1.0"
  "Run a selected command from one menu."
  '((emacs "24.4"))
  :url "https://github.com/aaronbieber/tiny-menu.el"
  :commit "4b9364a1b8d80586972743e452d6b732e742ff9d"
  :revdesc "4b9364a1b8d8"
  :keywords '("menu" "tools")
  :authors '(("Aaron Bieber" . "aaron@aaronbieber.com"))
  :maintainers '(("Aaron Bieber" . "aaron@aaronbieber.com")))
