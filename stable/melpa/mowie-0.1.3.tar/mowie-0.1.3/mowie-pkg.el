;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mowie" "0.1.3"
  "Cycle Through Point-Moving Commands."
  '((emacs "28.1"))
  :url "https://codeberg.org/mekeor/mowie"
  :commit "8e3e1eb8446175a3a591d304975d4dabb3ecf906"
  :revdesc "8e3e1eb84461"
  :keywords '("convenience")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
