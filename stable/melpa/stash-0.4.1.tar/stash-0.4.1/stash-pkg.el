;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stash" "0.4.1"
  "Lightweight persistent caching."
  ()
  :url "https://www.github.com/vermiculus/stash.el/"
  :commit "638ae8a4f6d33af54fe77d57c2c0eb1800dd2e19"
  :revdesc "638ae8a4f6d3"
  :keywords '("extensions" "data" "internal" "lisp")
  :authors '(("Sean Allred" . "code@seanallred.com"))
  :maintainers '(("Sean Allred" . "code@seanallred.com")))
