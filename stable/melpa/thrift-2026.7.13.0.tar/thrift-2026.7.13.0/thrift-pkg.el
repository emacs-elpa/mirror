;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.7.13.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "fe08f6c48479e1f851390b0c88e6c5644a4e9ff6"
  :revdesc "fe08f6c48479"
  :keywords '("languages"))
