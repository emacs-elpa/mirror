;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "define-it" "0.2.5"
  "Define, translate, wiki the word."
  '((emacs            "25.1")
    (s                "1.12.0")
    (popup            "0.5.3")
    (pos-tip          "0.4.6")
    (posframe         "1.1.7")
    (define-word      "0.1.0")
    (google-translate "0.11.18")
    (wiki-summary     "0.1"))
  :url "https://github.com/jcs-elpa/define-it"
  :commit "de026f399d5b7fa9286f7733b2e3416c6f234372"
  :revdesc "de026f399d5b"
  :keywords '("convenience" "dictionary" "explanation" "search" "wiki")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
