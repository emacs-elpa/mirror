;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srcery-theme" "0.2.0"
  "Dark color theme."
  '((emacs "24"))
  :url "https://github.com/srcery-colors/srcery-emacs"
  :commit "16973c5577904d395cf1f81f06e93661328914e7"
  :revdesc "16973c557790"
  :keywords '("faces"))
