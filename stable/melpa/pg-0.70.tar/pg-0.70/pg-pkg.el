;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "0.70"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "cda2e1ff5eecd90730e88c8b2ce1597367e85309"
  :revdesc "cda2e1ff5eec"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
