;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pos-tip" "0.4.7"
  "Show tooltip at point."
  ()
  :url "https://github.com/pitkali/pos-tip"
  :commit "4889e08cf9077c8589ea6fea4e2ce558614dfcde"
  :revdesc "4889e08cf907"
  :keywords '("tooltip"))
