;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "netease-music" "1.0"
  "Listen netease music."
  ()
  :url "https://github.com/nicehiro/netease-music"
  :commit "f3bba59664e1c4c4ed47f16fa786151272d99a70"
  :revdesc "v1.0-0-gf3bba59664e1"
  :keywords '("tools")
  :authors '(("hiro方圆" . "wfy11235813@gmail.com"))
  :maintainers '(("hiro方圆" . "wfy11235813@gmail.com")))
