;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyde" "0.2"
  "[No description available]."
  ()
  :url "https://github.com/nibrahim/Hyde"
  :commit "181f9d2f91c2678a22243c5485162fa7999fd893"
  :revdesc "0.2-0-g181f9d2f91c2")
