;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morlock" "2.2.0"
  "More font-lock keywords for elisp."
  '((emacs "29.1"))
  :url "https://github.com/tarsius/morlock"
  :commit "58ae8cdcc68c547dca6d6686b4014c337e512e1e"
  :revdesc "v2.2.0-0-g58ae8cdcc68c"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev")))
