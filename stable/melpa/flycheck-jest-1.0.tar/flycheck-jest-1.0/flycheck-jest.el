;;; flycheck-jest.el --- Flycheck extension for Jest. -*- lexical-binding: t -*-

;; Copyright (C) 2017 James Nguyen

;; Authors: James Nguyen <james@jojojames.com>
;; Maintainer: James Nguyen <james@jojojames.com>
;; URL: https://github.com/jojojames/flycheck-jest
;; Package-Version: 1.0
;; Package-Revision: e40b28c7fa8f
;; Package-Requires: ((emacs "25.1") (flycheck "0.25"))
;; Keywords: languages jest

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; Flycheck extension for Jest.
;; (with-eval-after-load 'flycheck
;;   (flycheck-jest-setup))

;;; Code:

(require 'flycheck)
(require 'cl-lib)

;; Compatibility
(eval-and-compile
  (with-no-warnings
    (if (version< emacs-version "26")
        (progn
          (defalias 'flycheck-jest-if-let* #'if-let)
          (defalias 'flycheck-jest-when-let* #'when-let)
          (function-put #'flycheck-jest-if-let* 'lisp-indent-function 2)
          (function-put #'flycheck-jest-when-let* 'lisp-indent-function 1))
      (defalias 'flycheck-jest-if-let* #'if-let*)
      (defalias 'flycheck-jest-when-let* #'when-let*))))

;; Customization

(defgroup flycheck-jest nil
  "A `flycheck' extension for jest."
  :group 'programming)

(defcustom flycheck-jest-report-directory
  (format "%s.jest-reports" user-emacs-directory)
  "Where jest stores results for each test run."
  :type 'string
  :group 'flycheck-jest)

;;; Flycheck

(flycheck-def-executable-var jest "jest")

(flycheck-def-option-var flycheck-jest-extra-flags nil jest
  "Extra flags prepended to arguments of jest."
  :type '(repeat (string :tag "Flags"))
  :safe #'flycheck-string-list-p)

(flycheck-define-checker jest
  "Flycheck plugin for for Jest."
  :command ("node"
            (eval (flycheck-jest--path))
            "--json"
            "--testPathPattern"
            (eval buffer-file-name)
            "--outputFile"
            (eval (flycheck-jest--result-path)))
  :error-parser flycheck-jest--parse
  :modes (web-mode js-mode typescript-mode rjsx-mode)
  :predicate
  (lambda ()
    (funcall #'flycheck-jest--should-use-p))
  :working-directory
  (lambda (checker)
    (flycheck-jest--find-jest-project-directory checker)))

;;;###autoload
(defun flycheck-jest-setup ()
  "Setup Flycheck for Jest."
  (interactive)
  (add-to-list 'flycheck-checkers 'jest))

(defun flycheck-jest--find-jest-project-directory (&optional _checker)
  "Return directory containing project-related jest files or nil."
  (expand-file-name
   (or
    (locate-dominating-file buffer-file-name "app.json")
    (locate-dominating-file buffer-file-name ".npmrc")
    (locate-dominating-file buffer-file-name ".git")
    (locate-dominating-file buffer-file-name "package.json"))))

(defun flycheck-jest--set-flychecker-executable ()
  "Set `flycheck-jest' executable according to jest location."
  (setq flycheck-jest-executable
        (format "node %snode_modules/jest/bin/jest.js"
                (flycheck-jest--find-jest-project-directory))))

(defun flycheck-jest--should-use-p ()
  "Return whether or not `flycheck-jest' should run."
  (and buffer-file-name
       (string-match-p "test" buffer-file-name)
       (file-exists-p (format "%snode_modules/jest/bin/jest.js"
                              (flycheck-jest--find-jest-project-directory)))))

(defun flycheck-jest--path ()
  "Path in project jest should be located."
  (format "%snode_modules/jest/bin/jest.js"
          (flycheck-jest--find-jest-project-directory)))

(defun flycheck-jest--result-path (&optional buffer)
  "Return the path `flycheck-jest' writes json reports to."
  (unless (file-exists-p flycheck-jest-report-directory)
    (make-directory flycheck-jest-report-directory))
  (let ((base-name
         (file-name-base (if buffer
                             (buffer-file-name buffer)
                           buffer-file-name))))
    (expand-file-name (format "%s/%s-report.json"
                              flycheck-jest-report-directory base-name))))

(defun flycheck-jest--parse (_output checker buffer)
  "`flycheck' parser for jest output."
  (let* ((jest-result-file (flycheck-jest--result-path buffer))
         (json (json-read-file jest-result-file)))
    (let ((jest-results (flycheck-jest--parse-json json)))
      (mapcar (lambda (jest-result)
                (flycheck-error-new-at
                 (plist-get jest-result :line)
                 (plist-get jest-result :column)
                 'error (plist-get jest-result :error)
                 :checker checker
                 :buffer buffer
                 :filename (plist-get jest-result :filename)))
              jest-results))))

(defun flycheck-jest--parse-json (json)
  "Parse JSON and return result.

Result is a list of plists with the form:

'(:line 12 :column 23 :error \"This is an error message.\" :filename \"absolute-path-to-file\")"
  (when (eq (alist-get 'success json) :json-false)
    (let ((testResults (alist-get 'testResults json)))
      (car
       (seq-map
        (lambda (testResult)
          (let ((filename (alist-get 'name testResult))
                (message (alist-get 'message testResult)))
            (mapcar
             (lambda (s)
               (let* ((split (split-string s "at Object.<anonymous>" t))
                      (error-message (string-trim (car split)))
                      (linenumbers-str (cadr split))
                      (line (flycheck-jest--extract-line linenumbers-str))
                      (col (flycheck-jest--extract-column linenumbers-str)))
                 `(
                   :line ,line
                   :column ,col
                   :error ,error-message
                   :filename ,filename)))
             (seq-filter (lambda (s)
                           (not (string-blank-p s)))
                         (split-string message "●" t)))))
        testResults)))))

(defun flycheck-jest--extract-line (s)
  "Extract line number from S."
  (let ((split (split-string s ":")))
    (string-to-number (cadr split))))

(defun flycheck-jest--extract-column (s)
  "Extract column number from S."
  (let* ((split (split-string s ":" t))
         (split2 (split-string (car (cddr split)) ")")))
    (string-to-number (car split2))))

(provide 'flycheck-jest)
;;; flycheck-jest.el ends here
