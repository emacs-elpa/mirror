;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-jest" "1.0"
  "Flycheck extension for Jest."
  '((emacs    "25.1")
    (flycheck "0.25"))
  :url "https://github.com/jojojames/flycheck-jest"
  :commit "e40b28c7fa8f65433db8e5ec84f92ffd27568366"
  :revdesc "e40b28c7fa8f"
  :keywords '("languages" "jest")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
