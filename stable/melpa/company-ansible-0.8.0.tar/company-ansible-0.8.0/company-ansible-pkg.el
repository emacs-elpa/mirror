;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ansible" "0.8.0"
  "A company back-end for ansible."
  '((emacs   "24.4")
    (company "0.8.12"))
  :url "https://github.com/krzysztof-magosa/company-ansible"
  :commit "2ea0be24f003dc64a30412df76298152be29103c"
  :revdesc "2ea0be24f003"
  :keywords '("ansible")
  :authors '(("Krzysztof Magosa" . "krzysztof@magosa.pl"))
  :maintainers '(("Krzysztof Magosa" . "krzysztof@magosa.pl")))
