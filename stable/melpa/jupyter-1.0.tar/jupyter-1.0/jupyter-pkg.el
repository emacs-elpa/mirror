;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jupyter" "1.0"
  "Jupyter."
  '((emacs        "26")
    (cl-lib       "0.5")
    (org          "9.1.6")
    (zmq          "0.10.10")
    (simple-httpd "1.5.0")
    (websocket    "1.9"))
  :url "https://github.com/emacs-jupyter/jupyter"
  :commit "2059d79b2fecf6d25a6c796b69ab954645ec37d1"
  :revdesc "2059d79b2fec"
  :authors '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainers '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")))
