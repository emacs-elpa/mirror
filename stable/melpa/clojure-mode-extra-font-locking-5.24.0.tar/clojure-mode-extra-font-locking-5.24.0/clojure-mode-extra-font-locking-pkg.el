;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode-extra-font-locking" "5.24.0"
  "Extra font-locking for Clojure mode."
  '((clojure-mode "5.24.0"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "065f8489c0cea7532982c8f0b63f3ed64f1837c0"
  :revdesc "065f8489c0ce"
  :keywords '("languages" "lisp")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
