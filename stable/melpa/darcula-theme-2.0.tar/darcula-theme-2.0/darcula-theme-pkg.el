;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darcula-theme" "2.0"
  "Inspired by IntelliJ's Darcula theme."
  ()
  :url "https://github.com/fommil/darcula-theme-emacs"
  :commit "2ecd466ffa7a3157b9ddcd7545b6fb8ad308c976"
  :revdesc "2ecd466ffa7a"
  :keywords '("faces")
  :authors '(("Sam Halliday" . "Sam.Halliday@gmail.com"))
  :maintainers '(("Sam Halliday" . "Sam.Halliday@gmail.com")))
