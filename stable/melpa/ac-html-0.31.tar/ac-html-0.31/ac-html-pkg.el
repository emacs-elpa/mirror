;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-html" "0.31"
  "Auto complete source for html tags and attributes."
  '((auto-complete       "1.4")
    (web-completion-data "0.1"))
  :url "https://github.com/cheunghy/ac-html"
  :commit "415a78c3b84855b0c0411832d21a0fb63239b184"
  :revdesc "415a78c3b848"
  :keywords '("html" "auto-complete" "rails" "ruby")
  :authors '(("Zhang Kai Yu" . "yeannylam@gmail.com"))
  :maintainers '(("Zhang Kai Yu" . "yeannylam@gmail.com")))
