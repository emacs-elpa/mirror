;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-etags" "0.6"
  "Etags/ctags completion source for auto-complete."
  '((auto-complete "1.4"))
  :url "https://github.com/syohex/emacs-ac-etags"
  :commit "8cd188b2e4908285ba8178bbd18a555edd7282e8"
  :revdesc "8cd188b2e490"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
