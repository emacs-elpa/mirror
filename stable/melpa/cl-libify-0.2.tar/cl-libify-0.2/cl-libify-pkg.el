;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cl-libify" "0.2"
  "Update elisp code to use cl-lib instead of cl."
  '((emacs "25"))
  :url "https://github.com/purcell/cl-libify"
  :commit "f7df5d868ada173bc81860ef81ece359f13ae4e4"
  :revdesc "f7df5d868ada"
  :keywords '("lisp")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
