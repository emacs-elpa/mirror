;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.28.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5aed35c5d7e2decd07e469d6e2be4de3637b2341"
  :revdesc "5aed35c5d7e2"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
