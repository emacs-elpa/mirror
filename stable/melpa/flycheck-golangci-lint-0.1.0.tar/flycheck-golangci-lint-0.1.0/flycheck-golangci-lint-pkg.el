;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-golangci-lint" "0.1.0"
  "Flycheck checker for golangci-lint."
  ()
  :url "https://github.com/weijiangan/flycheck-golangci-lint"
  :commit "760c3c6a399c2dcaa7574ff067943761417fa51e"
  :revdesc "760c3c6a399c"
  :keywords '("convenience" "tools" "go")
  :authors '(("Wei Jian Gan" . "weijiangan@Weis-MacBook-Pro.local"))
  :maintainers '(("Wei Jian Gan" . "weijiangan@Weis-MacBook-Pro.local")))
