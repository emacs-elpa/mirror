;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rocq-timing" "0.0.1"
  "Display timing of rocq commands in buffer."
  '((emacs "24"))
  :url "https://github.com/Chobbes/rocq-timing-el"
  :commit "c5b0e594af0c2e4a5a9645101d9a10cfc45ea3a4"
  :revdesc "c5b0e594af0c"
  :keywords '("convenience" "tools" "rocq" "coq" "proofs" "profiling")
  :authors '(("Calvin Beck" . "hobbes@ualberta.ca"))
  :maintainers '(("Calvin Beck" . "hobbes@ualberta.ca")))
