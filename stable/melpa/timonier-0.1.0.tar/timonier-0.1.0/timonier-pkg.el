;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timonier" "0.1.0"
  "Timonier, Manage Kubernetes Applications from Emacs."
  '((s             "1.11.0")
    (dash          "2.12.0")
    (pkg-info      "0.5.0")
    (hydra         "0.13.6")
    (request       "0.2.0")
    (all-the-icons "2.0.0"))
  :url "https://github.com/nlamirault/timonier"
  :commit "33ca5887a1d1b63349177237e9edfb73546511a5"
  :revdesc "33ca5887a1d1"
  :keywords '("kubernetes" "docker")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
