;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grandshell-theme" "1.3"
  "Grand Shell color theme for Emacs > 24."
  ()
  :url "https://github.com/steckerhalter/grandshell-theme"
  :commit "22c8df52c0fb8899fa748fa2980947ab38b53380"
  :revdesc "22c8df52c0fb"
  :keywords '("color" "theme" "grand" "shell" "faces"))
