;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autodisass-java-bytecode" "1.3"
  "Automatically disassemble Java bytecode."
  ()
  :url "https://github.com/gbalats/autodisass-java-bytecode"
  :commit "3d61dbe266133c950b39e880f78d142751c7dc4c"
  :revdesc "3d61dbe26613"
  :keywords '("convenience" "data" "files")
  :authors '(("George Balatsouras" . "gbalatsgmailcom"))
  :maintainers '(("George Balatsouras" . "gbalatsgmailcom")))
