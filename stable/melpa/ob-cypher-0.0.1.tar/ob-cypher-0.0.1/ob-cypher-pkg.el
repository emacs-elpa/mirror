;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-cypher" "0.0.1"
  "Query neo4j using cypher in org-mode blocks."
  '((s               "1.9.0")
    (cypher          "0.0.6")
    (dash            "2.10.0")
    (dash-functional "1.2.0"))
  :url "https://github.com/zweifisch/ob-cypher"
  :commit "6a37d9d659246ed8498539bcb1c953ebe61b2b3d"
  :revdesc "6a37d9d65924"
  :keywords '("org" "babel" "cypher" "neo4j")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
