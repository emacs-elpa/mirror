;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-flycheck" "1.2"
  "Provides the command `consult-flycheck'."
  '((emacs    "29.1")
    (consult  "3.5")
    (flycheck "35"))
  :url "https://github.com/minad/consult-flycheck"
  :commit "9dd95361669f87e14230376f4f93c6b9a222c497"
  :revdesc "1.2-0-g9dd95361669f"
  :keywords '("languages" "tools" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
