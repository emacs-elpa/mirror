;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "folio-theme" "0.1.0"
  "Warm paper-like theme built on Modus and Ef."
  '((emacs        "28.1")
    (modus-themes "5.0.0")
    (ef-themes    "2.0.0"))
  :url "https://github.com/kn66/folio-theme.el"
  :commit "247280f0ed9d9c94614635baf69d2a3d65bf1793"
  :revdesc "0.1.0-0-g247280f0ed9d"
  :keywords '("faces"))
