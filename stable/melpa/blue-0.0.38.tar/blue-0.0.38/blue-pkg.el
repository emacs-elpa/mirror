;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "0.0.38"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "822a965f17f1860661b788a9caee5f1996ab0c1d"
  :revdesc "822a965f17f1"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
