;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treemacs-projectile" "3.2"
  "Projectile integration for treemacs."
  '((emacs      "26.1")
    (projectile "0.14.0")
    (treemacs   "0.0"))
  :url "https://github.com/Alexander-Miller/treemacs"
  :commit "55079b017fb821a34ace398cd3d8c5b556a22f6d"
  :revdesc "55079b017fb8"
  :authors '(("Alexander Miller" . "alexanderm@web.de"))
  :maintainers '(("Alexander Miller" . "alexanderm@web.de")))
