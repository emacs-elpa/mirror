;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-hatena-bookmark" "2.5.2"
  "Helm interface for Hatena::Bookmark."
  '((emacs "24")
    (helm  "2.8.2"))
  :url "https://github.com/masutaka/emacs-helm-hatena-bookmark"
  :commit "15ff145a7f8cc3f0a0fa555e404f8b7a55cd2b25"
  :revdesc "2.5.2-0-g15ff145a7f8c"
  :authors '(("Takashi Masuda" . "masutaka.net@gmail.com"))
  :maintainers '(("Takashi Masuda" . "masutaka.net@gmail.com")))
