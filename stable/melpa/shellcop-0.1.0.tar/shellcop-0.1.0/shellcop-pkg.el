;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shellcop" "0.1.0"
  "Analyze info&error in shell-mode."
  '((emacs "25.1"))
  :url "https://github.com/redguardtoo/shellcop"
  :commit "4e71f5b9199a0ad10017104a6b2bf5ef5f207dfc"
  :revdesc "4e71f5b9199a"
  :keywords '("unix" "tools")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
