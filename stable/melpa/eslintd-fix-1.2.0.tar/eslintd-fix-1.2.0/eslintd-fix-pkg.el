;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eslintd-fix" "1.2.0"
  "Use eslint_d to automatically fix js files."
  '((dash  "2.12.0")
    (emacs "26.3"))
  :url "https://github.com/aaronjensen/eslintd-fix"
  :commit "5488db4436fc312386fdb123289d7fc5f099702b"
  :revdesc "v1.2.0-0-g5488db4436fc"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
