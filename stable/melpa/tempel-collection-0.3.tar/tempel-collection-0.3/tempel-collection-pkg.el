;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel-collection" "0.3"
  "Collection of templates for Tempel."
  '((tempel "0.5")
    (emacs  "31.1"))
  :url "https://github.com/Crandel/tempel-collection"
  :commit "68bc5eb9d4c19eb02dd1ba4cb00e041bb0500feb"
  :revdesc "68bc5eb9d4c1"
  :keywords '("tools")
  :authors '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
             ("Max Penet" . "mpenetr@s-exp.com")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
                 ("Max Penet" . "mpenetr@s-exp.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
