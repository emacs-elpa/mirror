;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-command-not-found" "0.1.2"
  "Integrate command-not-found in eshell."
  '((emacs "25.1"))
  :url "https://github.com/jaeyeom/eshell-command-not-found"
  :commit "28427f0ca266fd75890ceafdd96997b5507e1bc4"
  :revdesc "28427f0ca266"
  :keywords '("convenience")
  :authors '(("Jaehyun Yeom" . "jae.yeom@gmail.com"))
  :maintainers '(("Jaehyun Yeom" . "jae.yeom@gmail.com")))
