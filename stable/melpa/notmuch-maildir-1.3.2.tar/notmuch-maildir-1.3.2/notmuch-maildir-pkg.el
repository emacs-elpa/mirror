;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-maildir" "1.3.2"
  "Display maildirs as a tree."
  '((emacs   "29.1")
    (compat  "30.1")
    (notmuch "0.39"))
  :url "https://github.com/tarsius/notmuch-maildir"
  :commit "ef3952c785cc4bc41366d798bff5edad1a945553"
  :revdesc "v1.3.2-0-gef3952c785cc"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-maildir@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-maildir@jonas.bernoulli.dev")))
