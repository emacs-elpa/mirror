;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bookmark-frecency" "0.1"
  "Sort bookmarks by frecency."
  '((emacs "26.1"))
  :url "https://github.com/akirak/bookmark-frecency.el"
  :commit "c5405639e902c5516c95e5ba74a0b333ef0d8968"
  :revdesc "c5405639e902"
  :keywords '("convenience")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
