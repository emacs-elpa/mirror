;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blacken" "0.2.0"
  "Reformat python buffers using the \"black\" formatter."
  '((emacs "25.2"))
  :url "https://github.com/proofit404/blacken"
  :commit "563c744f545552cb92e8e84d5be4e2cdbabc93ca"
  :revdesc "563c744f5455"
  :authors '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers '(("Artem Malyshev" . "proofit404@gmail.com")))
