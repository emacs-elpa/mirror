;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "all-the-icons-completion" "1.0"
  "Add icons to completion candidates."
  '((emacs         "26.1")
    (all-the-icons "5.0"))
  :url "https://github.com/iyefrat/all-the-icons-completion"
  :commit "8eb3e410d63f5d0657b41829e7898793e81f31c0"
  :revdesc "8eb3e410d63f"
  :keywords '("convenient" "lisp")
  :authors '(("Itai Y. Efrat" . "https://github.com/iyefrat"))
  :maintainers '(("Itai Y. Efrat" . "itai3397@gmail.com")))
