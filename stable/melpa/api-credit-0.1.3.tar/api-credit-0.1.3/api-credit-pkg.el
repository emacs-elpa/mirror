;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "api-credit" "0.1.3"
  "AI API balance in the modeline."
  '((emacs "25.1"))
  :url "https://github.com/OverbearingPearl/api-credit"
  :commit "4020b70592acb46633d307b03ed247feba64bc66"
  :revdesc "4020b70592ac"
  :keywords '("comm" "convenience" "ai" "llm" "api" "balance" "modeline" "mode-line" "openrouter" "deepseek" "moonshot")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
