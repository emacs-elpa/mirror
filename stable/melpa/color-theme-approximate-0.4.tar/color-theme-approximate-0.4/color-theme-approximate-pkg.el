;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-approximate" "0.4"
  "Makes Emacs theme works on terminal transparently."
  ()
  :url "https://github.com/tungd/color-theme-approximate"
  :commit "b2a9920eb1f747adcf741c16038fa85b4ad0938d"
  :revdesc "b2a9920eb1f7"
  :authors '(("Tung Dao" . "me@tungdao.com"))
  :maintainers '(("Tung Dao" . "me@tungdao.com")))
