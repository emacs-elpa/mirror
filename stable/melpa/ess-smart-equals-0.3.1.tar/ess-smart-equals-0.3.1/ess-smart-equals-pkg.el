;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-smart-equals" "0.3.1"
  "Flexible, context-sensitive assignment key for R/S."
  '((emacs "25.1")
    (ess   "18.10"))
  :url "https://github.com/genovese/ess-smart-equals"
  :commit "746cf9e78c3b86cbbf78d69c335a8a4ff3da79d6"
  :revdesc "v0.3.1-0-g746cf9e78c3b"
  :keywords '("r" "s" "ess" "convenience")
  :authors '(("Christopher R. Genovese" . "genovese@cmu.edu"))
  :maintainers '(("Christopher R. Genovese" . "genovese@cmu.edu")))
