;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "0.1.1"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "3531488f0304edb547dcad5309287d9cbc6c5e24"
  :revdesc "3531488f0304"
  :keywords '("convenience" "chinese" "input-method" "rime"))
