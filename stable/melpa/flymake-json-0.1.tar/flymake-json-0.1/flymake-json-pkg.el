;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-json" "0.1"
  "A flymake handler for json using jsonlint."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-json"
  :commit "ad8e482db1ad29e23bdd9d089b9bc3615649ce65"
  :revdesc "ad8e482db1ad"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
