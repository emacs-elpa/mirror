;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "0.9.0"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "f3f724ab2c933811a779e0cd6917829ab9e2de3c"
  :revdesc "f3f724ab2c93"
  :keywords '("convenience"))
