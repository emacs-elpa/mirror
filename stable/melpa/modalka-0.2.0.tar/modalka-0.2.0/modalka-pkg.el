;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modalka" "0.2.0"
  "Modal editing your way."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/modalka"
  :commit "9bc73786bbd038e97bae7e31d3341a01085a300e"
  :revdesc "0.2.0-0-g9bc73786bbd0"
  :keywords '("convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
