;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pippel" "1.4"
  "Frontend to python package manager pip."
  '((emacs "25.1")
    (s     "1.11.0")
    (dash  "2.12.0"))
  :url "https://github.com/arifer612/pippel"
  :commit "9f5236a50d645635d8e4a1f548a02eac323b4101"
  :revdesc "9f5236a50d64"
  :authors '(("Fritz Stelzer" . "brotzeitmacher@gmail.com"))
  :maintainers '(("Arif Er" . "arifer612@protonmail.me")))
