;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuel" "0.100"
  "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs  "24.2"))
  :url "https://github.com/factor/factor"
  :commit "80a4633f05a47547c60556baee1b43546f20e331"
  :revdesc "80a4633f05a4")
