;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vue-html-mode" "0.2"
  "Major mode for editing Vue.js templates."
  ()
  :url "https://github.com/AdamNiederer/vue-html-mode"
  :commit "361a9fa117f044c3072dc5a7344ff7be31725849"
  :revdesc "0.2-0-g361a9fa117f0"
  :keywords '("languages" "vue" "template")
  :authors '(("Adam Niederer" . "adam.niederer@gmail.com"))
  :maintainers '(("Adam Niederer" . "adam.niederer@gmail.com")))
