;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jami-bot" "0.0.2"
  "An extendable chat bot for the private messenger GNU Jami."
  '((emacs "27.1"))
  :url "https://gitlab.com/hperrey/jami-bot"
  :commit "1da4d471587f55599686f97e143dfdb80d080fd5"
  :revdesc "1da4d471587f"
  :keywords '("comm" "jami" "messenger" "chat bot" "dbus")
  :authors '(("Hanno Perrey" . "http://gitlab.com/hperrey"))
  :maintainers '(("Hanno Perrey" . "hanno@hoowl.se")))
