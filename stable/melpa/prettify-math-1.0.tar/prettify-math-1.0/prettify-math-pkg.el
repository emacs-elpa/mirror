;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettify-math" "1.0"
  "Prettify math formula."
  '((emacs   "27.1")
    (dash    "2.19.0")
    (s       "1.12.0")
    (jsonrpc "1.0.9"))
  :url "https://gitee.com/shaqxu/prettify-math"
  :commit "9076d8c5f77b0b7ab0be488e90d5e2e5fb7ea9e8"
  :revdesc "9076d8c5f77b"
  :keywords '("math" "asciimath" "tex" "latex" "prettify" "mathjax")
  :authors '(("Shaq Xu" . "shaqxu@163.com"))
  :maintainers '(("Shaq Xu" . "shaqxu@163.com")))
