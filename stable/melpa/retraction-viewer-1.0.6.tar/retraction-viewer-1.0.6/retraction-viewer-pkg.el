;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "retraction-viewer" "1.0.6"
  "View retraction information for current citation."
  '((emacs "26.1")
    (plz   "0.7"))
  :url "https://git.sr.ht/~swflint/retraction-viewer"
  :commit "e8ab96e5a95a93849b912e2684b9776c685ac4bd"
  :revdesc "v1.0.6-0-ge8ab96e5a95a"
  :keywords '("bib" "tex" "data")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
