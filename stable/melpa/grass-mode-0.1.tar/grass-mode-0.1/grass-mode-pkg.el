;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grass-mode" "0.1"
  "Provides Emacs modes for interacting with the GRASS GIS program."
  '((cl-lib "0.2"))
  :url "https://github.com/plantarum/grass-mode"
  :commit "23ca856ca979fec0f90196b357f2b74fe1cc3a73"
  :revdesc "23ca856ca979"
  :keywords '("grass" "gis")
  :authors '(("Tyler Smith" . "tyler@plantarum.ca"))
  :maintainers '(("Tyler Smith" . "tyler@plantarum.ca")))
