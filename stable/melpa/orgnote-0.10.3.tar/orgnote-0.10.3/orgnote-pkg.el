;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgnote" "0.10.3"
  "Sync org-roam notes with OrgNote app."
  '((emacs "27.1"))
  :url "https://github.com/Artawower/orgnote.el"
  :commit "0919f9fd05b83870b8a7073eb94f77199e681241"
  :revdesc "0919f9fd05b8"
  :authors '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers '(("Artur Yaroshenko" . "artawower@protonmail.com")))
