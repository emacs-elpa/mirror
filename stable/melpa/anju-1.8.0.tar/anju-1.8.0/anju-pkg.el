;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "1.8.0"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "f5d27108ffe5facb6886fab191068efd1faea39f"
  :revdesc "f5d27108ffe5"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
