;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chinese-word-at-point" "0.2.3"
  "Add `chinese-word' thing to `thing-at-point'."
  '((cl-lib "0.5"))
  :url "https://github.com/xuchunyang/chinese-word-at-point.el"
  :commit "36a03cce32fe059d2b581cb2e029715c0be81074"
  :revdesc "36a03cce32fe"
  :keywords '("convenience" "chinese")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
