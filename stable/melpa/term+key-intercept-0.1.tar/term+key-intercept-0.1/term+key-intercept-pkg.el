;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term+key-intercept" "0.1"
  "Term+ intercept key mapping."
  ()
  :url "https://github.com/tarao/term+-el"
  :commit "3eb194644f250fd28f2b65ea15d45531b9018eba"
  :revdesc "3eb194644f25"
  :keywords '("terminal" "emulation")
  :authors '(("INA Lintaro" . "tarao.gnnatgmail.com"))
  :maintainers '(("INA Lintaro" . "tarao.gnnatgmail.com")))
