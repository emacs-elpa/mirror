;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperdrive" "0.5.2"
  "P2P filesystem."
  '((emacs              "28.1")
    (map                "3.0")
    (compat             "30.0.0.0")
    (org                "9.7.6")
    (plz                "0.9.1")
    (persist            "0.6.1")
    (taxy-magit-section "0.14")
    (transient          "0.8.0"))
  :url "https://git.sr.ht/~ushin/hyperdrive.el"
  :commit "4dceb8e88160bd28e31f4b56f1e5c01138c8fcdc"
  :revdesc "v0.5.2-0-g4dceb8e88160"
  :authors '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht")))
