;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clean-buffers" "0.1"
  "Clean useless buffers."
  ()
  :url "https://github.com/lujun9972/clean-buffers"
  :commit "647b2ad91be86a5735ff8d07286dcf4c6c0ed2e2"
  :revdesc "647b2ad91be8"
  :keywords '("convenience" "usability" "buffers")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
