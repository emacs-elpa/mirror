;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcmpl-pip" "0.5"
  "Pcomplete for pip."
  '((s   "1.12.0")
    (f   "0.19.0")
    (seq "2.15"))
  :url "https://github.com/suzzvv/pcmpl-pip"
  :commit "8b001b579fc015f80ee0e4f3211058b830bf7c47"
  :revdesc "8b001b579fc0"
  :keywords '("pcomplete" "pip" "python" "tools")
  :authors '(("Wei Zhao" . "kaihaosw@gmail.com"))
  :maintainers '(("Wei Zhao" . "kaihaosw@gmail.com")))
