;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbdb-ext" "20151220.2009"
  "Extra commands for BBDB."
  '((bbdb "2.36"))
  :url "https://github.com/vapniks/bbdb-ext"
  :commit "fee97b1b3faa83edaea00fbc5ad3cbca5e791a55"
  :revdesc "fee97b1b3faa"
  :keywords '("extensions")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
