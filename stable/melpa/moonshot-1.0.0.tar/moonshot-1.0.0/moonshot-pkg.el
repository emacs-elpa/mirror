;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moonshot" "1.0.0"
  "Run executable file, debug and build commands on project."
  '((cl-lib      "0.5")
    (f           "0.18")
    (s           "1.11.0")
    (projectile  "2.0.0")
    (counsel     "0.11.0")
    (realgud     "20190122.43")
    (seq         "2.20")
    (levenshtein "20090830.1040"))
  :url "https://github.com/ageldama/moonshot"
  :commit "005dbf7a64242f9d15a10c28748f4a9c7ada7e73"
  :revdesc "005dbf7a6424"
  :keywords '("convenience" "files" "processes" "tools" "unix")
  :authors '(("Jong-Hyouk Yun" . "ageldama@gmail.com"))
  :maintainers '(("Jong-Hyouk Yun" . "ageldama@gmail.com")))
