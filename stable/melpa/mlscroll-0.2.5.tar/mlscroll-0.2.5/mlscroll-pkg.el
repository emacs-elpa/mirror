;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mlscroll" "0.2.5"
  "A scroll bar for the modeline."
  '((emacs "27.1"))
  :url "https://github.com/jdtsmith/mlscroll"
  :commit "5a7cfed411cc5f8d8894dcbd989fd5c81ebcf8a8"
  :revdesc "5a7cfed411cc"
  :keywords '("convenience"))
