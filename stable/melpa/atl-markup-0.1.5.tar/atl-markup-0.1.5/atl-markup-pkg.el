;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atl-markup" "0.1.5"
  "Automatically truncate lines for markup languages."
  '((emacs "24.3"))
  :url "https://github.com/jcs-elpa/atl-markup"
  :commit "876d8a31d5e233d5234231f1428f8edb013e30eb"
  :revdesc "876d8a31d5e2"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
