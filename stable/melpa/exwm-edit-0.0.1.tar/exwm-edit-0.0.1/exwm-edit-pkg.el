;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-edit" "0.0.1"
  "Edit mode for EXWM."
  ()
  :url "https://github.com/agzam/exwm-edit"
  :commit "37f2a10524d512b0d31819d203b45adb68d17691"
  :revdesc "37f2a10524d5"
  :keywords '("exwm" "edit")
  :maintainers '(("Ag Ibragimov (concat \"agzam.ibragimov\" \"gm\" \"ail\" \".c\" \"om\"" . "\"@\" ")))
