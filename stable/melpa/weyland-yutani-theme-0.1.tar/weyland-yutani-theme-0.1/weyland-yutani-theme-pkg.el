;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weyland-yutani-theme" "0.1"
  "Emacs theme with a dark background."
  '((emacs "24"))
  :url "https://github.com/jstaursky/weyland-yutani-theme"
  :commit "e4957fb614ff597bd5a6ea0c5f2a4172a6c8f57e"
  :revdesc "e4957fb614ff")
