;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-org-clock" "0.2.2"
  "Counsel commands for org-clock."
  '((emacs "24.3")
    (ivy   "0.10.0")
    (dash  "2.0"))
  :url "https://github.com/akirak/counsel-org-clock"
  :commit "1ad0b2af370e64a6487b3a41760cc678a5bfadca"
  :revdesc "1ad0b2af370e"
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
