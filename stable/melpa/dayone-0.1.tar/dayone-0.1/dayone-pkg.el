;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dayone" "0.1"
  "Utility script for Day One."
  '((uuid     "0.0.3")
    (mustache "1.2"))
  :url "https://github.com/mori-dev/emacs-dayone"
  :commit "bf3e4587f38f5fcbb2a62c03af6e01e42dc19647"
  :revdesc "bf3e4587f38f"
  :keywords '("dayone")
  :authors '(("mori-dev" . "mori.dev.asdf@gmail.com"))
  :maintainers '(("mori-dev" . "mori.dev.asdf@gmail.com")))
