;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jal" "2.1.0"
  "Java Agent Loader (JAL) for JDTLS."
  '((emacs "28.1"))
  :url "https://github.com/saulotoledo/java-agent-loader"
  :commit "00cb7be8facea246906f74d70e07f84e16222b08"
  :revdesc "00cb7be8face"
  :keywords '("java" "languages" "tools")
  :authors '(("Saulo Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo Toledo" . "saulotoledo@gmail.com")))
