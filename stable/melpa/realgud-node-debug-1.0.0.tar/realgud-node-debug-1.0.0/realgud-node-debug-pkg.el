;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-node-debug" "1.0.0"
  "Realgud front-end to older nodejs \"node debug\"."
  '((realgud       "1.4.5")
    (load-relative "1.2")
    (cl-lib        "0.5")
    (emacs         "24"))
  :url "https://github.com/realgud/realgud-node-debug"
  :commit "e83e6d8f5a0018cba136b7a9ea845a25049caa09"
  :revdesc "e83e6d8f5a00")
