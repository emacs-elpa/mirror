;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tiny" "0.2.1"
  "Quickly generate linear ranges in Emacs."
  ()
  :url "https://github.com/abo-abo/tiny"
  :commit "481d36e47e51f27e64c826633c01518459f17d1c"
  :revdesc "481d36e47e51"
  :keywords '("convenience")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
