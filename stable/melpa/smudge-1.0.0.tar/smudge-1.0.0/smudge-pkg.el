;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smudge" "1.0.0"
  "Control the Spotify app."
  '((emacs        "24.4")
    (simple-httpd "1.5")
    (request      "0.3"))
  :url "https://github.com/danielfm/smudge"
  :commit "d65f8edda98058b5ad2b52e617e33312451fdf49"
  :revdesc "d65f8edda980"
  :keywords '("multimedia" "music" "spotify" "smudge"))
