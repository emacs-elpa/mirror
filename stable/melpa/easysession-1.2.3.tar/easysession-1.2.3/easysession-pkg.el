;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "1.2.3"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "07c24d08b02c7433d99a63d9260eb8c632e3533d"
  :revdesc "1.2.3-0-g07c24d08b02c"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
