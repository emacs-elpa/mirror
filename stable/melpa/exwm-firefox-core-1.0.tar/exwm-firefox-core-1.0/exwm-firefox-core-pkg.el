;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-firefox-core" "1.0"
  "Firefox hotkeys to functions."
  '((emacs "24.4")
    (exwm  "0.16"))
  :url "https://github.com/walseb/exwm-firefox-core"
  :commit "dca4afb5becc8d2689ef4f6b9d352cca655eb780"
  :revdesc "dca4afb5becc"
  :keywords '("extensions")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
