;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "volatile-highlights" "1.20"
  "Transient visual feedback for edits."
  '((emacs "24.4"))
  :url "https://github.com/k-talo/volatile-highlights.el"
  :commit "b1e7754d7b502ef6583a13f2662e515a654f944d"
  :revdesc "v1.20-0-gb1e7754d7b50"
  :keywords '("editing" "emulations" "convenience" "wp")
  :authors '(("K-talo Miyazaki" . "Keitaro.Miyazaki@gmail.com"))
  :maintainers '(("K-talo Miyazaki" . "Keitaro.Miyazaki@gmail.com")))
