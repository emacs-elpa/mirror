;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-sqlfluff" "0.1.0"
  "A flymake handler for sqlfluff-mode files."
  ()
  :url "https://github.com/erickgnavar/flymake-sqlfluff"
  :commit "62184daf9f4192ba7953de3b4735201f1e66227d"
  :revdesc "62184daf9f41"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
