;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-yes-or-no" "1.4"
  "Use Ido to answer yes-or-no questions."
  '((ido-completing-read+ "0"))
  :url "https://github.com/DarwinAwardWinner/ido-yes-or-no"
  :commit "9ddee9e878ad62d58c9f4b3a7685f22b8e36e420"
  :revdesc "9ddee9e878ad")
