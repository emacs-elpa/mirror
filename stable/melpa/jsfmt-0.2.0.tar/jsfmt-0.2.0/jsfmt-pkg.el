;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsfmt" "0.2.0"
  "[No description available]."
  ()
  :url "https://github.com/brettlangdon/jsfmt.el"
  :commit "c5d9742872509143db0250a77db705ef78f02cd0"
  :revdesc "c5d974287250"
  :authors '(("Brett Langdon" . "brett@blangdon.com"))
  :maintainers '(("Brett Langdon" . "brett@blangdon.com")))
