;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lyrics-fetcher" "0.2.0"
  "Fetch song lyrics and album covers."
  '((emacs   "27")
    (emms    "7.5")
    (f       "0.20.0")
    (request "0.3.2"))
  :url "https://github.com/SqrtMinusOne/lyrics-fetcher.el"
  :commit "06bd0293dfa759df48faefd73be60d43d1febd17"
  :revdesc "06bd0293dfa7"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
