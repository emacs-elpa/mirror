;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guard" "1.0.0"
  "Custom modular init framework."
  '((emacs "29.1"))
  :url "https://github.com/Dspil/guard.el"
  :commit "13b91e0d7ba336e8c5851f92937f43d13e9c1a85"
  :revdesc "13b91e0d7ba3"
  :keywords '("convenience" "initialization" "profiles" "tools")
  :authors '(("Dionisis Spiliopoulos" . "dennisspiliopoylos@gmail.com"))
  :maintainers '(("Dionisis Spiliopoulos" . "dennisspiliopoylos@gmail.com")))
