;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ajnc" "20260907"
  "A Janet (Spork) Netrepl Client."
  '((emacs "28.1"))
  :url "https://codeberg.org/zzkt/ajnc"
  :commit "bd28b7212245163155312578dc7bbe6901f404c8"
  :revdesc "bd28b7212245"
  :keywords '("tools" "programming" "janet" "repl" "netrepl")
  :maintainers '(("nik gaffney" . "nik@fo.am")))
