;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-llm" "0.1.0"
  "Use `llm' as an Org Babel language."
  '((emacs "27.1"))
  :url "https://github.com/sunflowerseastar/ob-llm"
  :commit "35d14e29652d9532c03454524fff6f8baed94c45"
  :revdesc "35d14e29652d"
  :keywords '("llm" "org-mode" "tools" "convenience" "org" "babel")
  :authors '(("Grant Surlyn" . "grant@sunflowerseastar.com"))
  :maintainers '(("Grant Surlyn" . "grant@sunflowerseastar.com")))
