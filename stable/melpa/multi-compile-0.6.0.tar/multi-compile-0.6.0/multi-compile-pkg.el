;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multi-compile" "0.6.0"
  "Multi target interface to compile."
  '((emacs "24")
    (dash  "2.12.1"))
  :url "https://github.com/ReanGD/emacs-multi-compile"
  :commit "bd0331854774e7a269ce8a7dd49580cd397c0ec2"
  :revdesc "bd0331854774"
  :keywords '("tools" "compile" "build")
  :authors '(("Kvashnin Vladimir" . "reangd@gmail.com"))
  :maintainers '(("Kvashnin Vladimir" . "reangd@gmail.com")))
