;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fixed-page-mode" "1.0"
  "A fixed page length mode."
  ()
  :url "https://gitlab.com/igorwojnicki/fixed-page-mode"
  :commit "5cf83ee036ca5d02f0046549d9d92dc0178080e8"
  :revdesc "5cf83ee036ca"
  :keywords '("text" "page")
  :authors '(("Igor Wojnicki" . "wojnicki@gmail.com"))
  :maintainers '(("Igor Wojnicki" . "wojnicki@gmail.com")))
