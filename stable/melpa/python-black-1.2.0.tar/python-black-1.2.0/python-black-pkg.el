;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-black" "1.2.0"
  "Reformat Python using python-black."
  '((emacs       "25")
    (dash        "2.16.0")
    (reformatter "0.3"))
  :url "https://github.com/wbolster/emacs-python-black"
  :commit "e1bbf574a952562ddeadb0caa42c44016136c2c9"
  :revdesc "1.2.0-0-ge1bbf574a952"
  :keywords '("languages")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
