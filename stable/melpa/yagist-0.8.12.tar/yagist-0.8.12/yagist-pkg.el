;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yagist" "0.8.12"
  "Yet Another Emacs integration for gist.github.com."
  '((cl-lib "0.3"))
  :url "https://github.com/mhayashi1120/yagist.el"
  :commit "97723a34750ccab5439eb9f6a2f67e4e0e234167"
  :revdesc "97723a34750c"
  :keywords '("tools")
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
