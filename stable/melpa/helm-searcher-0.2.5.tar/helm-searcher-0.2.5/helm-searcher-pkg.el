;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-searcher" "0.2.5"
  "Helm interface to use searcher."
  '((emacs    "25.1")
    (helm     "2.0")
    (searcher "0.1.8")
    (s        "1.12.0")
    (f        "0.20.0"))
  :url "https://github.com/emacs-helm/helm-searcher"
  :commit "3c0e4997126b5e7ba2db2dba8f1dbc5cb92d2459"
  :revdesc "3c0e4997126b"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
