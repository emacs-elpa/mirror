;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-hlint" "0.2"
  "A flymake handler for haskell-mode files using hlint."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-hlint"
  :commit "d540e250a80a09da3036c16bf86f9deb6d738c9c"
  :revdesc "d540e250a80a"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
