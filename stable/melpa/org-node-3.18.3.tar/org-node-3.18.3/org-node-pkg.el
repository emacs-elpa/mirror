;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "3.18.3"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.34.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "f5b85fb54dfb3c0a4ade14c6dd0dcba475bffca7"
  :revdesc "3.18.3-0-gf5b85fb54dfb"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
