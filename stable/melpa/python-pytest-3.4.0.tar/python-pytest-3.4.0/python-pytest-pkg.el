;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-pytest" "3.4.0"
  "Helpers to run pytest."
  '((emacs      "24.4")
    (dash       "2.18.0")
    (transient  "0.3.7")
    (projectile "0.14.0")
    (s          "1.12.0"))
  :url "https://github.com/wbolster/emacs-python-pytest"
  :commit "46fd006462258a3366723fafacdf2db6a6ae689d"
  :revdesc "3.4.0-0-g46fd00646225"
  :keywords '("pytest" "test" "python" "languages" "processes" "tools")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
