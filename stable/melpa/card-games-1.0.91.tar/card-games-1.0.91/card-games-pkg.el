;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "card-games" "1.0.91"
  "Play card games in Emacs (console + SVG)."
  '((emacs "26.1"))
  :url "https://code.bru.st/corwin/card-game.el"
  :commit "7918daf7ef6ab2ea4d4fc6391e49fde696cb5856"
  :revdesc "1.0.91-0-g7918daf7ef6a"
  :keywords '("games")
  :authors '(("Corwin Brust" . "corwin@bru.st"))
  :maintainers '(("Corwin Brust" . "corwin@bru.st")))
