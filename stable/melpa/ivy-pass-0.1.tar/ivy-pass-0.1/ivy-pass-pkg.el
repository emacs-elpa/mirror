;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-pass" "0.1"
  "Use ivy as an interface for the pass password store."
  '((ivy "0"))
  :url "https://github.com/ecraven/ivy-pass/"
  :commit "2f29093d0a9c98abec5fdb039e7259f0a31ede06"
  :revdesc "2f29093d0a9c"
  :keywords '("pass" "password"))
