;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cpp-auto-include" "0.2.0"
  "Insert and delete C++ header files automatically."
  '((cl-lib "0.5"))
  :url "https://github.com/emacsorphanage/cpp-auto-include"
  :commit "08208ca7b9dc4ac940ce9ca1f79424d2f3d3d391"
  :revdesc "v0.2.0-0-g08208ca7b9dc"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
