;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yapfify" "0.0.6"
  "(automatically) format python buffers using YAPF."
  ()
  :url "https://github.com/JorisE/yapfify"
  :commit "9e63a9135bd8dbfbee55819837a3aa0d119c5e6f"
  :revdesc "9e63a9135bd8"
  :authors '(("Joris Engbers" . "info@jorisengbers.nl"))
  :maintainers '(("Joris Engbers" . "info@jorisengbers.nl")))
