;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-mom" "0.1.0"
  "Groff MOM Macro Back-End for Org Export Engine."
  '((emacs "27.1")
    (org   "9.5"))
  :url "https://github.com/hinman/ox-mom"
  :commit "7acb3a0013d8e7d7d116a7a20f758c1ab903be4c"
  :revdesc "7acb3a0013d8"
  :keywords '("org" "groff" "mom" "wp" "outlines")
  :authors '(("Lee Hinman" . "hinman@gmail.com"))
  :maintainers '(("Lee Hinman" . "hinman@gmail.com")))
