;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wc-goal-mode" "2.1"
  "Running word count with goals (minor mode)."
  ()
  :url "https://github.com/bnbeckwith/wc-goal-mode"
  :commit "a8aa227b1a692dd6399855add84b5e37f6c5d9cb"
  :revdesc "v2.1-0-ga8aa227b1a69")
