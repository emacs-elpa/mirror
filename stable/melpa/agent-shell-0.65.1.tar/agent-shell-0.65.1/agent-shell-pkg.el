;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.65.1"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "bcb91e53cc9753423a5c8638e517d21fc7800b18"
  :revdesc "bcb91e53cc97")
