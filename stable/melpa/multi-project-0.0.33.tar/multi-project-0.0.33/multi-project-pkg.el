(define-package "multi-project" "0.0.33" "Find files, compile, and search for multiple projects."
  '((emacs "25"))
  :commit "983a8125e5569a45c592b2f73c4d9740b7d69dc1" :authors
  '(("Shawn Ellis" . "shawn.ellis17@gmail.com"))
  :maintainers
  '(("Shawn Ellis" . "shawn.ellis17@gmail.com"))
  :maintainer
  '("Shawn Ellis" . "shawn.ellis17@gmail.com")
  :keywords
  '("convenience" "project" "management")
  :url "https://hg.osdn.net/view/multi-project/multi-project")
;; Local Variables:
;; no-byte-compile: t
;; End:
