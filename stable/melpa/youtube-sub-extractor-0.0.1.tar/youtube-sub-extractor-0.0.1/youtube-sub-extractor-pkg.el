;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youtube-sub-extractor" "0.0.1"
  "Extract YouTube video subtitles."
  '((emacs "28.1"))
  :url "https://github.com/agzam/yt-sub-extractor"
  :commit "39b7fd81005428f0d34283752c2e7d74815cf3b4"
  :revdesc "39b7fd810054"
  :keywords '("convenience" "multimedia")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
