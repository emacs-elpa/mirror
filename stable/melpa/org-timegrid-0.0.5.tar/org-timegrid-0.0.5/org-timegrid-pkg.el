;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "0.0.5"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "f8f5076a56a0ca21c807904dbb5eb009646e8a82"
  :revdesc "v0.0.5-0-gf8f5076a56a0"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
