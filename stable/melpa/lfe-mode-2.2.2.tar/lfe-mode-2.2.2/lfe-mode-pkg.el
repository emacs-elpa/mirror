;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lfe-mode" "2.2.2"
  "Lisp Flavoured Erlang mode."
  ()
  :url "https://github.com/rvirding/lfe"
  :commit "dae7489ebf9588e5f746a34cd4f8ff83d1469eef"
  :revdesc "dae7489ebf95")
