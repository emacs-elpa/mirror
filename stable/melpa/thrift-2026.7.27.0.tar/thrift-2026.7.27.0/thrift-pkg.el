;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.7.27.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "0215ea4e57004131f0eb7e092770f95659a15136"
  :revdesc "0215ea4e5700"
  :keywords '("languages"))
