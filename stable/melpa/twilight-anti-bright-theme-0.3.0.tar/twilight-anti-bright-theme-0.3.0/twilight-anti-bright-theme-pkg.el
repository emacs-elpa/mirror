;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "twilight-anti-bright-theme" "0.3.0"
  "A soothing Emacs 24 light-on-dark theme."
  ()
  :url "https://github.com/jimeh/twilight-anti-bright-theme.el"
  :commit "16d4ff2606789b506f0d2f53d12f02d5b1b64f9b"
  :revdesc "16d4ff260678"
  :keywords '("themes")
  :authors '(("Jim Myhrberg" . "contact@jimeh.me"))
  :maintainers '(("Jim Myhrberg" . "contact@jimeh.me")))
