;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinboard-popular" "0.1.2"
  "Displays links from the pinboard.in popular page."
  '((loop "1.4"))
  :url "https://github.com/asimpson/pinboard-popular"
  :commit "df6f5928f1e5a614fb770f6f4b9aefe0bf4d1c25"
  :revdesc "df6f5928f1e5"
  :keywords '("pinboard"))
