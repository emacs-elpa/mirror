;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "netherlands-holidays" "1.0.0"
  "Netherlands holidays for Emacs calendar."
  ()
  :url "https://github.com/abo-abo/netherlands-holidays"
  :commit "26236178cdd650df9958bf5a086e184096559f00"
  :revdesc "26236178cdd6"
  :keywords '("calendar")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
