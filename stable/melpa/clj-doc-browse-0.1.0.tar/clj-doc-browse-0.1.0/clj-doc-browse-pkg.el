;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clj-doc-browse" "0.1.0"
  "Browse Clojure library docs from classpath JARs."
  '((emacs         "27.1")
    (cider         "1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/dcj/clj-doc-browse-el"
  :commit "309fb922e4ae6ae5a11cb837807aa125109d5f73"
  :revdesc "309fb922e4ae"
  :keywords '("clojure" "documentation" "tools")
  :authors '(("Don Jackson" . "dcj@clark-communications.com"))
  :maintainers '(("Don Jackson" . "dcj@clark-communications.com")))
