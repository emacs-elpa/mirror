;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "2.2.1"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "7b9b8780ab80700df673d804d9444778d1077c05"
  :revdesc "7b9b8780ab80"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
