;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "protobuf-ts-mode" "0.0.0.20230728.8"
  "Tree sitter support for Protocol Buffers (proto3 only)."
  '((emacs "29"))
  :url "https://git.ookami.one/cgit/protobuf-ts-mode"
  :commit "65152f5341ea4b3417390b3e60b195975161b8bc"
  :revdesc "65152f5341ea"
  :keywords '("protobuf" "languages" "tree-sitter")
  :authors '(("ookami" . "mail@ookami.one"))
  :maintainers '(("ookami" . "mail@ookami.one")))
