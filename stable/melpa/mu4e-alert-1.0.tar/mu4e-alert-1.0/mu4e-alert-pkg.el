;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-alert" "1.0"
  "Desktop notification for mu4e."
  '((alert "1.2")
    (s     "1.10.0")
    (ht    "2.0")
    (emacs "24.1"))
  :url "https://github.com/iqbalansari/mu4e-alert"
  :commit "3453e25ff6c07c1b768b2a79fdb9fc5c97100e76"
  :revdesc "3453e25ff6c0"
  :keywords '("mail" "convenience")
  :authors '(("Iqbal Ansari" . "iqbalansari02@yahoo.com"))
  :maintainers '(("Iqbal Ansari" . "iqbalansari02@yahoo.com")))
