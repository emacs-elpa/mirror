;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-test-mode" "1.0"
  "Minor mode for Behaviour and Test Driven."
  ()
  :url "https://github.com/ruby-test-mode/ruby-test-mode"
  :commit "7d3c04b60721665af93ffb4abc2a7b3191926431"
  :revdesc "7d3c04b60721"
  :keywords '("ruby" "unit" "test" "rspec")
  :authors '(("Roman Scherer" . "roman.scherer@gmx.de")
             ("Caspar Florian Ebeling" . "florian.ebeling@gmail.com"))
  :maintainers '(("Roman Scherer" . "roman.scherer@gmx.de")))
