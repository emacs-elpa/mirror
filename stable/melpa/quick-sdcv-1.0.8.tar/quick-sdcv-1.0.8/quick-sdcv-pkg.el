;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "1.0.8"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "d710a47aef32e030f38207cf71175e94f84cc225"
  :revdesc "1.0.8-0-gd710a47aef32"
  :keywords '("tools" "convenience" "text"))
