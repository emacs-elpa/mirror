;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mtg-deck-mode" "0.2"
  "Major mode to edit MTG decks."
  '((emacs "24.4"))
  :url "https://github.com/mattiasb/mtg-deck-mode"
  :commit "7774641630ef85999ab2f6d57eebddbc7c1e7244"
  :revdesc "v0.2-0-g7774641630ef"
  :keywords '("data" "mtg" "magic")
  :authors '(("Mattias Bengtsson" . "mattias.jc.bengtsson@gmail.com"))
  :maintainers '(("Mattias Bengtsson" . "mattias.jc.bengtsson@gmail.com")))
