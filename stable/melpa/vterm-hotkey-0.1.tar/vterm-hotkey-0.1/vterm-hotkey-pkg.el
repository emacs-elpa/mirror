;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vterm-hotkey" "0.1"
  "Control vterm buffers with hotkeys."
  '((emacs "29.4")
    (vterm "0.0"))
  :url "https://github.com/rootatpixel/vterm-hotkey"
  :commit "869aa290da7a158b3e68db89238221896b6e3e35"
  :revdesc "869aa290da7a"
  :keywords '("terminals" "processes" "hotkeys")
  :authors '(("rootatpixel" . "rootatpixel@gmail.com"))
  :maintainers '(("rootatpixel" . "rootatpixel@gmail.com")))
