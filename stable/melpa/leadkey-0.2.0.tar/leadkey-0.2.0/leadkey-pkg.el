;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leadkey" "0.2.0"
  "Translate leader keys to key sequences."
  '((emacs "30.1"))
  :url "https://github.com/jixiuf/emacs-leadkey"
  :commit "61042efbbde72e096e74833eeebdcdf9599cab7c"
  :revdesc "61042efbbde7"
  :keywords '("convenience")
  :authors '(("jixiuf" . "https://github.com/jixiuf"))
  :maintainers '(("jixiuf" . "https://github.com/jixiuf")))
