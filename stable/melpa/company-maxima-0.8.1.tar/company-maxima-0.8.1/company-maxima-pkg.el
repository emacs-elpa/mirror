;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-maxima" "0.8.1"
  "Maxima company integration."
  '((emacs   "25.1")
    (maxima  "0.6.1")
    (seq     "2.20")
    (company "0.9.13"))
  :url "https://gitlab.com/sasanidas/maxima"
  :commit "1334f44725bd80a265de858d652f3fde4ae401fa"
  :revdesc "1334f44725bd"
  :keywords '("languages" "tools" "convenience")
  :maintainers '(("Fermin Munoz" . "fmfs@posteo.net")))
