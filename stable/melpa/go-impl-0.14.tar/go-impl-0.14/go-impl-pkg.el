;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-impl" "0.14"
  "Impl integration for go-mode."
  '((emacs   "24.3")
    (go-mode "1.3.0"))
  :url "https://github.com/syohex/emacs-go-impl"
  :commit "69f0d0ef05771487e15abec500cd06befd171abf"
  :revdesc "69f0d0ef0577"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
