;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typewriter-roll-mode" "1.2.2"
  "Aid for distraction-free writing."
  '((emacs "24.1"))
  :url "https://github.com/KeyWeeUsr/typewriter-roll-mode"
  :commit "dd6738e86db6492c945e3a9238e0cfbe154ad98b"
  :revdesc "1.2.2-0-gdd6738e86db6"
  :keywords '("convenience" "line" "carriage" "writing" "distraction" "cr" "rewind")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
