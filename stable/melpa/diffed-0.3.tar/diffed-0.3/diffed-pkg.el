;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diffed" "0.3"
  "Diffed is for recursive diff like Dired is for ls."
  '((emacs "27.1"))
  :url "https://github.com/ber-ro/diffed"
  :commit "f7dc37f13a4f1660212c41a6e9faba61eb8cc078"
  :revdesc "f7dc37f13a4f"
  :keywords '("tools")
  :authors '(("Bernhard Rotter" . "bernhard@b-rotter.de"))
  :maintainers '(("Bernhard Rotter" . "bernhard@b-rotter.de")))
