;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emojify-logos" "0.1"
  "[No description available]."
  '((emojify "0.4"))
  :url "https://github.com/mxgoldstein/emojify-logos"
  :commit "19c8fc6d11ba814875d2be5fe55b5ebc3b2ffaa4"
  :revdesc "19c8fc6d11ba"
  :authors '(("mxgoldstein" . "m_goldstein@gmx.net"))
  :maintainers '(("mxgoldstein" . "m_goldstein@gmx.net")))
