;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ghs" "0.0.2"
  "Ghs with helm interface."
  '((emacs "24")
    (helm  "2.2.0"))
  :url "https://github.com/iory/emacs-helm-ghs"
  :commit "f9d4ab80e8a33b21cd635285289ec5779bbe629f"
  :revdesc "f9d4ab80e8a3"
  :authors '(("iory" . "ab.ioryz@gmail.com"))
  :maintainers '(("iory" . "ab.ioryz@gmail.com")))
