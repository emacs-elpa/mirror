;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-fuzzier" "0.0.0.20160605.58"
  "Better fuzzy matching for Helm."
  '((emacs "24.3")
    (helm  "1.7.0"))
  :url "https://github.com/EphramPerdition/helm-fuzzier"
  :commit "8798dcf3583b863df5b9dea7fe3b0179ba1c35bc"
  :revdesc "8798dcf3583b"
  :keywords '("convenience" "helm" "fuzzy"))
