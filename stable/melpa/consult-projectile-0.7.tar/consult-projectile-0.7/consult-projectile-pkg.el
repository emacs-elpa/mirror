;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-projectile" "0.7"
  "Consult integration for projectile."
  '((emacs      "25.1")
    (consult    "0.12")
    (projectile "2.5.0"))
  :url "https://gitlab.com/OlMon/consult-projectile"
  :commit "130ba9d3879bc293d81b1aa9fbfd0dffae3b5579"
  :revdesc "130ba9d3879b"
  :keywords '("convenience"))
