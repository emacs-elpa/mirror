;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sixcolors-theme" "1.0"
  "Just another theme."
  '((emacs "27.1"))
  :url "https://github.com/mastro35/sixcolors-theme"
  :commit "a42110935686142045886d34db8135f74793ef3b"
  :revdesc "a42110935686"
  :keywords '("faces" "colors")
  :authors '(("Davide Mastromatteo" . "mastro35@gmail.com"))
  :maintainers '(("Davide Mastromatteo" . "mastro35@gmail.com")))
