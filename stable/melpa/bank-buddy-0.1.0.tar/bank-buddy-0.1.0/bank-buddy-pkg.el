;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bank-buddy" "0.1.0"
  "Financial analysis and reporting."
  '((emacs "26.1")
    (async "1.9.4"))
  :url "https://github.com/captainflasmr/bank-buddy"
  :commit "0002826a3f47b908fb6fd2a867193e04cb465273"
  :revdesc "0002826a3f47"
  :keywords '("matching")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
