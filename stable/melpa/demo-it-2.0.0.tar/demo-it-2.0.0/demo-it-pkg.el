;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "demo-it" "2.0.0"
  "[No description available]."
  ()
  :url "https://github.com/howardabrams/demo-it"
  :commit "83e124dbb7a8e33d18c1ff813ac0030b1d5c5dec"
  :revdesc "83e124dbb7a8"
  :keywords '("demonstration" "presentation" "test")
  :authors '(("Howard Abrams" . "howard.abrams@gmail.com"))
  :maintainers '(("Howard Abrams" . "howard.abrams@gmail.com")))
