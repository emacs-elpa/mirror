;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ghci" "0.3"
  "Company backend which uses the current ghci process."
  '((company      "0.8.11")
    (haskell-mode "13"))
  :url "https://github.com/horellana/company-ghci"
  :commit "9e186c12424beb4f1c186543ba71aec64f3bfd7f"
  :revdesc "9e186c12424b"
  :authors '(("Hector Orellana" . "hofm92@gmail.com"))
  :maintainers '(("Hector Orellana" . "hofm92@gmail.com")))
