;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eradio" "0.1"
  "A radio player."
  '((emacs "24.1"))
  :url "https://github.com/olav35/radio"
  :commit "0a37c00c9ba98739e5c74fac04acb3f224602472"
  :revdesc "0a37c00c9ba9"
  :authors '(("Olav Fosse" . "fosseolav@gmail.com"))
  :maintainers '(("Olav Fosse" . "fosseolav@gmail.com")))
