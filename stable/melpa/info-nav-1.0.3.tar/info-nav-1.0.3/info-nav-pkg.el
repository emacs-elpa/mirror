;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "info-nav" "1.0.3"
  "Browse info docs with a 2 pane layout."
  '((emacs "29.1"))
  :url "https://codeberg.org/ggxx/info-nav"
  :commit "eede340e73cecf435bda4ad27d386a98b8c02f36"
  :revdesc "eede340e73ce"
  :keywords '("docs" "hypermedia")
  :authors '(("ggxx" . "https://codeberg.org/ggxx"))
  :maintainers '(("ggxx" . "https://codeberg.org/ggxx")))
