;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eide" "2.3.4"
  "IDE features made available out of the box."
  '((emacs "26.1"))
  :url "https://software.hjuvi.fr.eu.org/eide/"
  :commit "a5b47c5d0a19441359e0ad0de5f2fe3f61f671fa"
  :revdesc "2.3.4-0-ga5b47c5d0a19"
  :authors '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainers '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org")))
