;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oceanic-theme" "0.0.1"
  "Oceanic theme for Emacs."
  ()
  :url "https://github.com/terry3/oceanic-theme"
  :commit "673fb3ad35aa3b9e8cef34b983e82b5286732899"
  :revdesc "673fb3ad35aa"
  :keywords '("oceanic" "color" "theme" "emacs"))
