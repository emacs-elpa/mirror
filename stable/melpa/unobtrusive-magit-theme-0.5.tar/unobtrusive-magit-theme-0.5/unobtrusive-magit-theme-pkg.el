;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unobtrusive-magit-theme" "0.5"
  "An unobtrusive Magit theme."
  '((emacs "24.1"))
  :url "https://github.com/tee3/unobtrusive-magit-theme"
  :commit "33d265d08a0a215aab558550d1596ac0e57c9d63"
  :revdesc "0.5-0-g33d265d08a0a"
  :keywords '("faces" "vc" "magit")
  :authors '(("Thomas A. Brown" . "tabsoftwareconsulting@gmail.com"))
  :maintainers '(("Thomas A. Brown" . "tabsoftwareconsulting@gmail.com")))
