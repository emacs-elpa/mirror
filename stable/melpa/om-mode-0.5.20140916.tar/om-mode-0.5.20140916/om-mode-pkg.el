;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "om-mode" "0.5.20140916"
  "Insert Om component template with life cycle."
  ()
  :url "https://github.com/danielsz/om-mode"
  :commit "5a6b380f8d1293a865d8a37aa4816d7412c512ce"
  :revdesc "5a6b380f8d12"
  :keywords '("clojurescript")
  :authors '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com"))
  :maintainers '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com")))
