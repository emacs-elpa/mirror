;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sniem" "1.2"
  "Hands-eased united editing method."
  '((emacs "27.1")
    (s     "2.12.0")
    (dash  "1.12.0"))
  :url "https://github.com/SpringHan/sniem.git"
  :commit "4f33cf6b24bdd9857127d7cfd73e6c368eeeba9e"
  :revdesc "4f33cf6b24bd"
  :keywords '("convenience" "united-editing-method"))
