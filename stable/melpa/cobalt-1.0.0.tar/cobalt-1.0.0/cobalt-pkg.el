;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cobalt" "1.0.0"
  "Summary."
  '((emacs "24"))
  :url "https://github.com/accidentalrebel/cobalt.el"
  :commit "2ace1cf742684874c4e3d8c5ca7fdfd5f6827cb3"
  :revdesc "2ace1cf74268"
  :keywords '("convenience")
  :authors '(("Juan Karlo Licudine" . "accidentalrebel@gmail.com"))
  :maintainers '(("Juan Karlo Licudine" . "accidentalrebel@gmail.com")))
