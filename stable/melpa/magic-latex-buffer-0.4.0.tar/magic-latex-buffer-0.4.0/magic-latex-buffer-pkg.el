;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magic-latex-buffer" "0.4.0"
  "Magically enhance LaTeX-mode font-locking for semi-WYSIWYG editing."
  '((cl-lib "0.5")
    (emacs  "24.3"))
  :url "http://hins11.yu-yake.com/"
  :commit "db01f00780cba71a18bd442332efc599450d5fec"
  :revdesc "db01f00780cb")
