;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phony" "2.0.0"
  "Define voice commands."
  '((emacs      "29.1")
    (simulacrum "2.0.0"))
  :url "https://github.com/ErikPrantare/phony.el"
  :commit "ec26a6faa1a31fc12d80e2910305f28f522d171a"
  :revdesc "ec26a6faa1a3"
  :keywords '("files")
  :authors '(("Erik Präntare" . "erik@prantare.xyz"))
  :maintainers '(("Erik Präntare" . "erik@prantare.xyz")))
