;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-highlight-symbol" "1.61"
  "Automatic highlighting current symbol minor mode."
  '((emacs "26.1")
    (ht    "2.3"))
  :url "https://github.com/jcs-elpa/auto-highlight-symbol"
  :commit "ca285d84e4a22514adaff2f0ba39657e296f4fff"
  :revdesc "ca285d84e4a2"
  :keywords '("highlight" "face" "match" "convenience")
  :authors '(("Mitsuo Saito" . "arch320@NOSPAM.gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
