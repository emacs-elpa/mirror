;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-todo" "0.5.0"
  "Search hl-todo keywords in consult."
  '((emacs   "29.1")
    (consult "1.9")
    (hl-todo "3.8.2"))
  :url "https://github.com/eki3z/consult-todo"
  :commit "0d962bd5115ae312505df7f63c9cb82a225245ca"
  :revdesc "0d962bd5115a"
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
