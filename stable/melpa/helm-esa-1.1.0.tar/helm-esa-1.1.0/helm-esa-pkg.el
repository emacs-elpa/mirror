;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-esa" "1.1.0"
  "Esa with helm interface."
  '((emacs   "26.2")
    (helm    "3.2")
    (request "0.3.0"))
  :url "https://github.com/masutaka/emacs-helm-esa"
  :commit "d93b4af404346870cb2cf9c257d055332ef3f577"
  :revdesc "1.1.0-0-gd93b4af40434"
  :authors '(("Takashi Masuda" . "masutaka.net@gmail.com"))
  :maintainers '(("Takashi Masuda" . "masutaka.net@gmail.com")))
