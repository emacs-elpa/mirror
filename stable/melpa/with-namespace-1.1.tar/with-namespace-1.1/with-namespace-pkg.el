;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-namespace" "1.1"
  "Poor-man's namespaces for elisp."
  ()
  :url "https://github.com/Wilfred/with-namespace.el"
  :commit "04c2aa576b2ab4aa4174cf2612f989c8ee8cde7e"
  :revdesc "04c2aa576b2a"
  :keywords '("namespaces")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
