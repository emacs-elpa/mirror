;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-org-multi-wiki" "0.4.0"
  "Helm interface to org-multi-wiki."
  '((emacs          "25.1")
    (org-multi-wiki "0.3")
    (org-ql         "0.4")
    (dash           "2.12"))
  :url "https://github.com/akirak/org-multi-wiki"
  :commit "80791ea872939df0578dc3a2992a2f7fd5618971"
  :revdesc "80791ea87293"
  :keywords '("org" "outlines")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
