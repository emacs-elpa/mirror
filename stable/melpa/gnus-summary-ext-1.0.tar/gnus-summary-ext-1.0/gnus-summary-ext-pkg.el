;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-summary-ext" "1.0"
  "Extra limit and process mark commands for the gnus summary buffer."
  ()
  :url "https://github.com/vapniks/gnus-summary-ext"
  :commit "9f53a8a2161fe6ddc5fce6d1e23e7d20098310e9"
  :revdesc "9f53a8a2161f"
  :keywords '("comm")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
