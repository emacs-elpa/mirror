;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "0x0" "1.0.1"
  "Upload sharing to 0x0.st."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~willvaughn/emacs-0x0"
  :commit "d02f16056ef325e4773708b2e831a02b6b453d89"
  :revdesc "d02f16056ef3"
  :authors '(("William Vaughn" . "https://git.sr.ht/~willvaughn/"))
  :maintainers '(("William Vaughn" . "vaughnwilld@gmail.com")))
