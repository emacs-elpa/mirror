;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp-server-lib" "0.2.0"
  "Model Context Protocol server library."
  '((emacs "27.1"))
  :url "https://github.com/laurynas-biveinis/mcp-server-lib.el"
  :commit "cfa2f2f3367b32429a06d2c401a2b791a896bba6"
  :revdesc "0.2.0-0-gcfa2f2f3367b"
  :keywords '("comm" "tools")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
