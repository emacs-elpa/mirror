;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browse-kill-ring" "2.1.0"
  "Interactively insert items from kill-ring."
  ()
  :url "https://github.com/browse-kill-ring/browse-kill-ring"
  :commit "1fa2c611f80ccdadfe766e3e7f4272b0f5d1dd28"
  :revdesc "1fa2c611f80c"
  :keywords '("convenience")
  :authors '(("Colin Walters" . "walters@verbum.org"))
  :maintainers '(("browse-kill-ring" . "browse-kill-ring@tonotdo.com")))
