;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-server-htmlize" "0.4"
  "(de)HTMLization hooks for edit-server.el."
  ()
  :url "https://github.com/frobtech/edit-server-htmlize"
  :commit "ec92d1132cd2d2949bfa2230dcc410d5c65c75c5"
  :revdesc "ec92d1132cd2"
  :authors '(("Roland McGrath" . "roland@hack.frob.com"))
  :maintainers '(("Roland McGrath" . "roland@hack.frob.com")))
