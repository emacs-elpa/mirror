;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.49.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "ccc371ba61213412954e785f5b472d84dbbf0d51"
  :revdesc "ccc371ba6121"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
