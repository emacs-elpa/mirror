;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weibo" "1.0"
  "[No description available]."
  ()
  :url "https://github.com/austin-----/weibo.emacs"
  :commit "a8af467e5660a35342029c2796de99cd551454b2"
  :revdesc "v1.0-0-ga8af467e5660")
