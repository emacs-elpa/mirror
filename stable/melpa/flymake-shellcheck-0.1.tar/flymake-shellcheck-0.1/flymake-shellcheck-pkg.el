;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-shellcheck" "0.1"
  "A bash/sh Flymake backend powered by ShellCheck."
  '((emacs "26"))
  :url "https://github.com/federicotdn/flymake-shellcheck"
  :commit "ccc593f818dac5e4dd5d80c202b8fb2a63531d3b"
  :revdesc "ccc593f818da"
  :authors '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers '(("Federico Tedin" . "federicotedin@gmail.com")))
