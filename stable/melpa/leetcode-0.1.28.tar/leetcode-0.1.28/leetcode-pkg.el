;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leetcode" "0.1.28"
  "An leetcode client."
  '((emacs "28.1")
    (s     "1.13.0")
    (aio   "1.0")
    (log4e "0.3.3"))
  :url "https://github.com/kaiwk/leetcode.el"
  :commit "02eb6ff9c75ba8f0a7196f34665e9ed43c4d7598"
  :revdesc "02eb6ff9c75b"
  :keywords '("extensions" "tools")
  :authors '(("Wang Kai" . "kaiwkx@gmail.com"))
  :maintainers '(("Wang Kai" . "kaiwkx@gmail.com")))
