;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imenus" "0.2"
  "Imenu for multiple buffers and without subgroups."
  '((cl-lib "0.5"))
  :url "https://github.com/alezost/imenus.el"
  :commit "ee1bbd2228dbb86df2865dc9004d375421b171ba"
  :revdesc "ee1bbd2228db"
  :keywords '("tools" "convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
