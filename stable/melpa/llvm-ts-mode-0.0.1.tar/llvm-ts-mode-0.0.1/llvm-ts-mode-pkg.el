;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llvm-ts-mode" "0.0.1"
  "LLVM major mode using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/llvm-ts-mode"
  :commit "f2dcfe0a3d99472d69394981b88fcdd6a11ed283"
  :revdesc "f2dcfe0a3d99"
  :keywords '("languages" "tree-sitter" "llvm")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
