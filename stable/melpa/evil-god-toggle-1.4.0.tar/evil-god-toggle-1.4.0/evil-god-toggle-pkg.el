;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-god-toggle" "1.4.0"
  "Toggle Evil and God Mode."
  '((emacs    "28.1")
    (evil     "1.0.8")
    (god-mode "2.12.0"))
  :url "https://github.com/jam1015/evil-god-toggle"
  :commit "4102e67bb9fadd4fd20fffedb5415b50f9b66b40"
  :revdesc "v1.4.0-0-g4102e67bb9fa"
  :keywords '("convenience" "emulation" "evil" "god-mode")
  :authors '(("Jordan Mandel" . "jordan.mandel@live.com"))
  :maintainers '(("Jordan Mandel" . "jordan.mandel@live.com")))
