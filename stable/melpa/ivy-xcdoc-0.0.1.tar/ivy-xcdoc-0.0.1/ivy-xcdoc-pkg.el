;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-xcdoc" "0.0.1"
  "Search Xcode documents with ivy interface."
  '((ivy   "0")
    (emacs "24.1"))
  :url "https://github.com/hex2010/emacs-ivy-xcdoc"
  :commit "36d17b8c4592c79ec8d335bcfc7a24b0eb2cf516"
  :revdesc "36d17b8c4592"
  :authors '(("C.T.Chen" . "chenct@7adybird.com"))
  :maintainers '(("C.T.Chen" . "chenct@7adybird.com")))
