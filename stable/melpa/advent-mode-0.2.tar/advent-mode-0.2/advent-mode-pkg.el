;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "0.2"
  "Advent of Code mode."
  '((emacs "30.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "e72f2d89b75a1bb63fa62969838e914840eff682"
  :revdesc "e72f2d89b75a"
  :keywords '("tools")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
