;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-toodledo" "2.1.0"
  "[No description available]."
  ()
  :url "https://github.com/myuhe/org-toodledo"
  :commit "5473c1a2762371b198862aa8fd83fd3ec57485a4"
  :revdesc "2.1.0-0-g5473c1a27623")
