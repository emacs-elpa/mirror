;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zero-input-panel-posframe" "1.0.1"
  "Posframe based zero-input panel implementation."
  '((emacs      "24.4")
    (zero-input "2.9.0")
    (posframe   "1.4.3"))
  :url "https://gitlab.emacsos.com/sylecn/zero-el"
  :commit "01d5a8f94b7936152ae719e25ffc19574f7b0cc5"
  :revdesc "01d5a8f94b79")
