;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "badwolf-theme" "1.2"
  "Bad Wolf color theme."
  '((emacs "24"))
  :url "https://github.com/bkruczyk/badwolf-emacs"
  :commit "24a557f92a702f632901a5b7bee59945a0a8cde9"
  :revdesc "1.2-0-g24a557f92a70"
  :keywords '("themes")
  :authors '(("bkruczyk" . "bartlomiej.kruczyk@gmail.com"))
  :maintainers '(("bkruczyk" . "bartlomiej.kruczyk@gmail.com")))
