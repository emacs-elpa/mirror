;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "battle-haxe" "1.0"
  "A Haxe development system, with code completion and more ;;."
  '((emacs   "25")
    (company "0.9.9")
    (helm    "3.0")
    (async   "1.9.3")
    (dash    "2.12.0")
    (cl-lib  "0.5")
    (s       "1.10.0")
    (f       "0.19.0"))
  :url "https://github.com/AlonTzarafi/battle-haxe"
  :commit "5ba7b388a659820591ded3981cef51a4bd5cd1f7"
  :revdesc "5ba7b388a659"
  :keywords '("programming" "languages" "completion")
  :authors '(("Alon Tzarafi" . "alontzarafi@gmail.com"))
  :maintainers '(("Alon Tzarafi" . "alontzarafi@gmail.com")))
