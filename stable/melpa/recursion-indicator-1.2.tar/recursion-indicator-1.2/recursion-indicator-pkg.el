;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recursion-indicator" "1.2"
  "Recursion indicator."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/recursion-indicator"
  :commit "eb33010866742808cabae694fa4e77b33737522e"
  :revdesc "1.2-0-geb3301086674"
  :keywords '("convenience")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
