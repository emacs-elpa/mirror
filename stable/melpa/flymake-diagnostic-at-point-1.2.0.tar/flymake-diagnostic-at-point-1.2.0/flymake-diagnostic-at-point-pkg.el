;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-diagnostic-at-point" "1.2.0"
  "Display flymake diagnostics at point."
  '((emacs "26.1")
    (popup "0.5.3"))
  :url "https://github.com/meqif/flymake-diagnostic-at-point"
  :commit "379616b1c6f5ebeaf08fbe54ae765008a78b3be7"
  :revdesc "379616b1c6f5"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Ricardo Martins" . "ricardo@scarybox.net"))
  :maintainers '(("Ricardo Martins" . "ricardo@scarybox.net")))
