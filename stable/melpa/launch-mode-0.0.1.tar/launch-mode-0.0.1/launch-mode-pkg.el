;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "launch-mode" "0.0.1"
  "Major mode for launch-formatted text."
  '((emacs "24.4")
    (helm  "2.0"))
  :url "https://github.com/iory/launch-mode"
  :commit "d49c2c49964f3b20a3c6aed90e4cad99695dbb9e"
  :revdesc "d49c2c49964f"
  :authors '(("iory" . "ab.ioryz@gmail.com"))
  :maintainers '(("iory" . "ab.ioryz@gmail.com")))
