;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.4.0"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "8cecdcafeb306f654c5eed1847a0c36cb6ff370b"
  :revdesc "v1.4.0-0-g8cecdcafeb30"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
