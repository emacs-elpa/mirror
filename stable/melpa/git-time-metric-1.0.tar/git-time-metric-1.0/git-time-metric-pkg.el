;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-time-metric" "1.0"
  "Provide function to record time with gtm ( git time metric )."
  ()
  :url "https://github.com/c301/gtm-emacs-plugin"
  :commit "287108ed1d6885dc795eb3bad4476aa08c626186"
  :revdesc "287108ed1d68"
  :keywords '("tools" "gtm" "productivity" "time")
  :authors '(("Anton Sivolapov" . "anton.sivolapov@gmail.com"))
  :maintainers '(("Anton Sivolapov" . "anton.sivolapov@gmail.com")))
