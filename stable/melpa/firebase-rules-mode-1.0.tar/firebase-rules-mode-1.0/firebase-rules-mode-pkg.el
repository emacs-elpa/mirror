;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firebase-rules-mode" "1.0"
  "Editing support for firebase.rules."
  '((emacs "24.3"))
  :url "https://github.com/dherbst/firebase-mode"
  :commit "a4d72363abb6b0bb3c3d800b058c8973674de1c6"
  :revdesc "a4d72363abb6"
  :keywords '("languages")
  :authors '(("Darrel Herbst" . "dherbst@gmail.com"))
  :maintainers '(("Darrel Herbst" . "dherbst@gmail.com")))
