;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sops" "0.2.0"
  "Edit SOPS-encrypted files transparently."
  '((emacs "29.1"))
  :url "https://github.com/djgoku/sops"
  :commit "95b2178a71dcbf3e69729c52cba2bc23171e059d"
  :revdesc "95b2178a71dc"
  :keywords '("convenience" "files" "tools" "sops" "encrypt" "decrypt")
  :authors '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com"))
  :maintainers '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com")))
