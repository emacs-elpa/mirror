;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-caldav" "3.1"
  "Sync org files with external calendar through CalDAV."
  '((emacs "26.3")
    (org   "9.1"))
  :url "https://github.com/dengste/org-caldav/"
  :commit "7c0ae0dd84d47f7f28a5e74e68ecbbd53df401d8"
  :revdesc "7c0ae0dd84d4"
  :keywords '("calendar" "caldav")
  :authors '(("David Engster" . "deng@randomsample.de"))
  :maintainers '(("David Engster" . "deng@randomsample.de")))
