;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-preview-eww" "0.0.1"
  "Realtime preview by eww."
  '((emacs "24.4"))
  :url "https://github.com/niku/markdown-preview-eww"
  :commit "d273b408e498c2ae1324d4e429524880b531e7ff"
  :revdesc "d273b408e498"
  :authors '(("niku" . "niku@niku.name"))
  :maintainers '(("niku" . "niku@niku.name")))
