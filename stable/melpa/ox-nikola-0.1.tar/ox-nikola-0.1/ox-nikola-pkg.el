;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-nikola" "0.1"
  "Export Nikola articles using org-mode."
  ()
  :url "https://github.com/msnoigrs/ox-nikola"
  :commit "055cebc7655ff6d815c70f42a6e149d3c62450d0"
  :revdesc "055cebc7655f"
  :keywords '("org" "nikola")
  :authors '(("IGARASHI Masanao" . "syoux2@gmail.com"))
  :maintainers '(("IGARASHI Masanao" . "syoux2@gmail.com")))
