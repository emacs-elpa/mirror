;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exiftool" "0.3.2"
  "Elisp wrapper around ExifTool."
  '((emacs "25"))
  :url "https://git.systemreboot.net/exiftool.el"
  :commit "c1058d99c34e62b99dbfca13ada47519fb51bf73"
  :revdesc "v0.3.2-0-gc1058d99c34e"
  :keywords '("data")
  :authors '(("Arun I" . "arunisaac@systemreboot.net"))
  :maintainers '(("Arun I" . "arunisaac@systemreboot.net")))
