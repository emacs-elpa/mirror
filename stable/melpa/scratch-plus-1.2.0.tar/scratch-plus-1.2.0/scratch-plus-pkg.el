;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-plus" "1.2.0"
  "Better Scratch Buffer Behavior."
  '((emacs "29.1"))
  :url "https://git.sr.ht/~swflint/scratch-plus"
  :commit "cfecace1a6f3389fcabbfdd009f2b14db6dcc637"
  :revdesc "cfecace1a6f3"
  :keywords '("convenience")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
