;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "voca-builder" "0.2.0"
  "[No description available]."
  '((popup "0.5.2"))
  :url "https://github.com/yitang/voca-builder"
  :commit "224402532da28e45edd398fda61ecbddb97d22d3"
  :revdesc "224402532da2"
  :keywords '("english" "vocabulary")
  :authors '(("Yi Tang" . "yi.tang.uk@me.com"))
  :maintainers '(("Yi Tang" . "yi.tang.uk@me.com")))
