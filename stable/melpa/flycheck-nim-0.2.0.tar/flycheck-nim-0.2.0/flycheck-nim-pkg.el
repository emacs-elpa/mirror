;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-nim" "0.2.0"
  "Defines a flycheck syntax checker for nim."
  '((dash     "2.4.0")
    (flycheck "0.20"))
  :url "https://github.com/ALSchwalm/flycheck-nim"
  :commit "d923ab0275d3bc02cc0c3d3d92ddbbfd083e5b56"
  :revdesc "d923ab0275d3"
  :authors '(("Adam Schwalm" . "adamschwalm@gmail.com"))
  :maintainers '(("Adam Schwalm" . "adamschwalm@gmail.com")))
