;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awscli-capf" "0.0.0.20190930.24"
  "Completion at point function for the AWS CLI."
  '((emacs "26"))
  :url "https://github.com/sebasmonia/awscli-capf.git"
  :commit "1a75f88f53a2969fe821c31e6857861d0a0c0a5e"
  :revdesc "1a75f88f53a2"
  :keywords '("tools" "convenience" "abbrev")
  :authors '(("Sebastian Monia" . "smonia@outlook.com"))
  :maintainers '(("Sebastian Monia" . "smonia@outlook.com")))
