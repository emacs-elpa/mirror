;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "1.0"
  "Create an aggregated Org table from another one."
  ()
  :url "https://github.com/tbanel/orgaggregate"
  :commit "3ed4bd81d35f44d06c65c50df65f88726d32f381"
  :revdesc "3ed4bd81d35f"
  :keywords '("org" "table" "aggregation" "filtering"))
