;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smilefjes" "0.0.1"
  "Check if a restaurant has a good rating with Mattilsynet (food administration in Norway)."
  '((emacs   "24.4")
    (request "0.3.2")
    (ht      "2.3")
    (dash    "2.19.1")
    (helm    "3.8.6"))
  :url "https://github.com/themkat/mos-mode"
  :commit "a4cbdaf21f66cd50036cd52206ad43b4b3e7942e"
  :revdesc "a4cbdaf21f66")
