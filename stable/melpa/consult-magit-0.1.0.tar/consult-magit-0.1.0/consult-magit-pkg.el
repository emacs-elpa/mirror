;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-magit" "0.1.0"
  "Switch and manage magit buffers with consult."
  '((emacs   "28.1")
    (consult "1.0")
    (magit   "3.0"))
  :url "https://github.com/nhojb/consult-magit"
  :commit "dacb8639f3fe61e390e1c89b595d104df272a83d"
  :revdesc "dacb8639f3fe"
  :keywords '("convenience" "vc" "tools")
  :authors '(("John Buckley" . "john@raycast.com"))
  :maintainers '(("John Buckley" . "john@raycast.com")))
