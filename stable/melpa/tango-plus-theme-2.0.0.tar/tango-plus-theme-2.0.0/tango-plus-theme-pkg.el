;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tango-plus-theme" "2.0.0"
  "A color theme based on the tango palette."
  ()
  :url "https://github.com/tmalsburg/tango-plus-theme"
  :commit "ef8510d75c60459a7c3bce8aaf686280faf71663"
  :revdesc "ef8510d75c60"
  :authors '(("Titus von der Malsburg" . "malsburg@posteo.de"))
  :maintainers '(("Titus von der Malsburg" . "malsburg@posteo.de")))
