;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "le-thesaurus" "0.0.0.20241229.77"
  "Query thesaurus.com for synonyms of a given word."
  '((request "0.3.2")
    (emacs   "24.4"))
  :url "https://github.com/AnselmC/le-thesaurus.el"
  :commit "8c8ea595678da69df817a173ec043ab1b17d96c3"
  :revdesc "8c8ea595678d")
