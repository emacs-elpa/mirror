;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-last-point" "0.1.0"
  "Record and jump to the last point in the buffer."
  '((emacs "24.3"))
  :url "https://github.com/manuel-uberti/goto-last-point"
  :commit "d99982084e6f85e1130572f1d4efd60f1beba909"
  :revdesc "d99982084e6f"
  :keywords '("convenience")
  :authors '(("Manuel Uberti" . "manuel.uberti@inventati.org"))
  :maintainers '(("Manuel Uberti" . "manuel.uberti@inventati.org")))
