;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-text-object-python" "1.0.1"
  "Python specific evil text objects."
  '((emacs "24")
    (evil  "1.2.12"))
  :url "https://github.com/wbolster/evil-text-object-python"
  :commit "3b3fb01e7ad7eeeeae1143695547fe75148cc44f"
  :revdesc "1.0.1-0-g3b3fb01e7ad7"
  :keywords '("evil" "python" "text-object")
  :authors '(("Wouter Bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("Wouter Bolsterlee" . "wouter@bolsterl.ee")))
