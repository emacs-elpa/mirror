;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "golden-ratio" "1.0"
  "Automatic resizing of Emacs windows to the golden ratio."
  ()
  :url "https://github.com/roman/golden-ratio.el"
  :commit "79b1743fc1a2f3462445e9ddd0a869f30065bb6d"
  :revdesc "v1.0-0-g79b1743fc1a2"
  :keywords '("window" "resizing")
  :authors '(("Roman Gonzalez" . "romanandreg@gmail.com"))
  :maintainers '(("Roman Gonzalez" . "romanandreg@gmail.com")))
