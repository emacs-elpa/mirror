;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "real-mono-themes" "1.0.0"
  "Real monochromatic color themes."
  '((emacs "24"))
  :url "https://github.com/qingsongliao/real-mono-themes"
  :commit "824e26a039064e951afbe965ec731420fe3c3fb8"
  :revdesc "824e26a03906"
  :keywords '("faces")
  :authors '(("Qingsong Liao" . "llqingsong@qq.com"))
  :maintainers '(("Qingsong Liao" . "llqingsong@qq.com")))
