;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-static-blog" "1.7.0"
  "A simple org-mode based static blog generator."
  '((emacs "24.3"))
  :url "https://github.com/bastibe/org-static-blog"
  :commit "728968e4a84ba28c5acedc54ece17e49d6811ad9"
  :revdesc "728968e4a84b")
