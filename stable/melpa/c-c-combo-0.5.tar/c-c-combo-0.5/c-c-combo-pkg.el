;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "c-c-combo" "0.5"
  "Make stuff happen when you reach a target wpm -*- lexical-binding: nil -."
  ()
  :url "https://www.github.com/CestDiego/c-c-combo.el"
  :commit "b1acc33b89fbb247ad92ee5e7340c5ba8bab4e60"
  :revdesc "b1acc33b89fb"
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")))
