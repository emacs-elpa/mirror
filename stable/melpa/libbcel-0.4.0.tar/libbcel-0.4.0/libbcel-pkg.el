;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "libbcel" "0.4.0"
  "Library to connect to basecamp 3 API."
  '((emacs   "26.1")
    (request "0.3.1"))
  :url "https://gitlab.petton.fr/bcel/libbcel"
  :commit "d02a38898016bba314802b1f6a07317e52ea6c63"
  :revdesc "v0.4.0-0-gd02a38898016"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
