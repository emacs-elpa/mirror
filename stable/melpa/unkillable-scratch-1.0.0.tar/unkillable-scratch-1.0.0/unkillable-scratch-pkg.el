;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unkillable-scratch" "1.0.0"
  "Disallow the \\*scratch\\* buffer from being killed."
  '((emacs "24"))
  :url "https://github.com/EricCrosson/unkillable-scratch"
  :commit "dac9dbed946a26829e6227ac15c0fa1d07ccd05f"
  :revdesc "dac9dbed946a"
  :keywords '("convenience")
  :authors '(("Eric Crosson" . "eric.s.crosson@utexas.com"))
  :maintainers '(("Eric Crosson" . "eric.s.crosson@utexas.com")))
