;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poet-theme" "2.1"
  "A theme for prose."
  '((emacs "24.1"))
  :url "https://github.com/kunalb/poet/"
  :commit "ed63c3fd056c4ad61d1f402afa376cafea7ef7c1"
  :revdesc "ed63c3fd056c"
  :keywords '("faces" "theme" "prose")
  :authors '(("Kunal Bhalla" . "bhalla.kunal@gmail.com"))
  :maintainers '(("Kunal Bhalla" . "bhalla.kunal@gmail.com")))
