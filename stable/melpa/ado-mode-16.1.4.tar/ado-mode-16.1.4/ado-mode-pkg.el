;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ado-mode" "16.1.4"
  "Major mode for editing Stata-related files."
  '((emacs "24.1"))
  :url "https://github.com/louabill/ado-mode"
  :commit "29d56532c7ab6f680c596add31fd80cd79186e89"
  :revdesc "16.1.4-0-g29d56532c7ab"
  :keywords '("tools" "languages" "files" "convenience" "stata" "mata" "ado")
  :authors '(("Bill Rising" . "brising@alum.mit.edu"))
  :maintainers '(("Bill Rising" . "brising@alum.mit.edu")))
