;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-agenda-dock" "0.0.1"
  "Show a badge with number of todos at dock."
  '((emacs "28.1")
    (dock  "0.0.1"))
  :url "https://github.com/hron/org-agenda-dock.el"
  :commit "ce53dffdcc1edd997136fc10dabf4004222bccf8"
  :revdesc "ce53dffdcc1e"
  :keywords '("convenience" "org" "dock" "desktop")
  :authors '(("Aleksei Gusev" . "aleksei.gusev@gmail.com"))
  :maintainers '(("Aleksei Gusev" . "aleksei.gusev@gmail.com")))
