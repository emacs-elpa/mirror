;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpr-ts-mode" "0.8.0"
  "Major mode for GNAT project files using Tree-Sitter."
  '((emacs "29.1"))
  :url "https://github.com/brownts/gpr-ts-mode"
  :commit "13692f415d2a78908bda68143065fb714b3fae10"
  :revdesc "13692f415d2a"
  :keywords '("gpr" "gnat" "ada" "languages" "tree-sitter")
  :authors '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainers '(("Troy Brown" . "brownts@troybrown.dev")))
