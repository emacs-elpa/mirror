;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kapacitor" "0.0.1"
  "Main file for kapacitor-mode."
  '((emacs       "25.1")
    (magit       "2.13.0")
    (magit-popup "2.12.4"))
  :url "https://github.com/Manoj321/kapacitor-el"
  :commit "212e87f328526b570c2bf582ed7b2df8e65916a0"
  :revdesc "212e87f32852"
  :keywords '("kapacitor" "emacs" "magit" "tools")
  :authors '(("Manoj Kumar Manikchand" . "manojm.321@gmail.com"))
  :maintainers '(("Manoj Kumar Manikchand" . "manojm.321@gmail.com")))
