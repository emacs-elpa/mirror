;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-youtube" "1.1"
  "Query YouTube and play videos in your browser."
  '((request "0.2.0")
    (helm    "2.3.1")
    (cl-lib  "0.5"))
  :url "https://github.com/maximus12793/helm-youtube"
  :commit "7a944bc25f0f9e915011e9325caf46b46fcaa1b8"
  :revdesc "7a944bc25f0f"
  :keywords '("youtube" "multimedia")
  :authors '(("Maximilian Roquemore" . "maximus12793@gmail.com"))
  :maintainers '(("Maximilian Roquemore" . "maximus12793@gmail.com")))
