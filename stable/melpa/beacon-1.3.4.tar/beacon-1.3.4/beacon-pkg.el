;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beacon" "1.3.4"
  "Highlight the cursor whenever the window scrolls."
  '((seq "2.14"))
  :url "https://github.com/Malabarba/beacon"
  :commit "729338b02a0e331a4faf475da9f54771a3470106"
  :revdesc "729338b02a0e"
  :keywords '("convenience")
  :authors '(("Artur Malabarba" . "emacs@endlessparentheses.com"))
  :maintainers '(("Artur Malabarba" . "emacs@endlessparentheses.com")))
