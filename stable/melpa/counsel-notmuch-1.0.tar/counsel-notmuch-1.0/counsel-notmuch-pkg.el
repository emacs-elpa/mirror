;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-notmuch" "1.0"
  "Search emails in Notmuch asynchronously with Ivy."
  '((swiper  "0.10.0")
    (notmuch "0.21"))
  :url "https://github.com/fuxialexander/counsel-notmuch"
  :commit "c6613b9a39ce8cf5d612e276fbe98edfd80e23f5"
  :revdesc "c6613b9a39ce"
  :keywords '("mail")
  :authors '(("Alexander Fu Xi" . "fuxialexander@gmail.com"))
  :maintainers '(("Alexander Fu Xi" . "fuxialexander@gmail.com")))
