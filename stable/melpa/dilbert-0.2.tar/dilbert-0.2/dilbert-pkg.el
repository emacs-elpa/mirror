;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dilbert" "0.2"
  "View Dilbert comics."
  '((emacs  "26.1")
    (enlive "0.0.1")
    (dash   "2.19.1"))
  :url "https://github.com/DaniruKun/dilbert-el"
  :commit "4d0ac315d1bf2d7965ea6a4d32a572a73315caf0"
  :revdesc "4d0ac315d1bf"
  :keywords '("multimedia" "news")
  :authors '(("Daniils Petrovs" . "thedanpetrov@gmail.com"))
  :maintainers '(("Daniils Petrovs" . "thedanpetrov@gmail.com")))
