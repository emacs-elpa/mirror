;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cnfonts" "1.1.1"
  "A simple Chinese fonts config tool."
  '((emacs "24"))
  :url "https://github.com/tumashu/cnfonts"
  :commit "5115f53366bd6118dce3673ddec5ff428534ce67"
  :revdesc "5115f53366bd"
  :keywords '("convenience" "chinese" "font")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
