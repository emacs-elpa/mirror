;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kixtart-mode" "1.4.3"
  "Major mode for editing KiXtart scripts."
  '((emacs "28.1")
    (eldoc "1.14.0"))
  :url "https://git.sr.ht/~mew/kixtart-mode"
  :commit "f1a713f812af49cd109efa30ad498008e31b87c6"
  :revdesc "v1.4.3-0-gf1a713f812af"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
