;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "message-attachment-reminder" "0.2"
  "Remind if missing attachment."
  '((emacs "24.1"))
  :url "https://github.com/alexmurray/message-attachment-reminder"
  :commit "975381d6e7c6771c462e73abd3398a4ed2a9b86b"
  :revdesc "975381d6e7c6"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
