;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lively" "0.2"
  "Interactively updating text."
  ()
  :url "https://github.com/purcell/lively"
  :commit "6ec648fcde85e81393db1ed1364860f960179c92"
  :revdesc "6ec648fcde85")
