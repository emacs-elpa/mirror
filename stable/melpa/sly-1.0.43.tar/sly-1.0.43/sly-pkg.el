;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "1.0.43"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.3"))
  :url "https://github.com/joaotavora/sly"
  :commit "eb67be9698794ba66a09f46b7cfffab742863a91"
  :revdesc "eb67be969879"
  :keywords '("languages" "lisp" "sly"))
