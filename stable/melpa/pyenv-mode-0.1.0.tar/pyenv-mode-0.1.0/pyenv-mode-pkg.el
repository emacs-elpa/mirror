;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyenv-mode" "0.1.0"
  "Integrate pyenv with python-mode."
  '((pythonic "0.1.0"))
  :url "https://github.com/proofit404/pyenv-mode"
  :commit "b96c15fa1b83cad855e472eda06319ad35e34513"
  :revdesc "b96c15fa1b83"
  :authors '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers '(("Artem Malyshev" . "proofit404@gmail.com")))
