;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jjdescription" "0.1"
  "Major mode for editing Jujutsu description files."
  '((emacs "25.1"))
  :url "https://github.com/necaris/jjdescription.el"
  :commit "bfc99a8e54873223678a9436bd9c50e490d25696"
  :revdesc "bfc99a8e5487"
  :authors '(("Rami Chowdhury" . "rami.chowdhury@gmail.com"))
  :maintainers '(("Rami Chowdhury" . "rami.chowdhury@gmail.com")))
