;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "v2ex-mode" "0.2"
  "Major mode for visit http://v2ex.com/ site."
  '((cl-lib    "0.5")
    (request   "0.2")
    (let-alist "1.0.3"))
  :url "https://github.com/aborn/v2ex-mode"
  :commit "7a59ac3be2b08d873ec271ec7a3d5ace309c1407"
  :revdesc "7a59ac3be2b0"
  :keywords '("v2ex" "v2ex.com")
  :authors '(("Aborn Jiang" . "aborn.jiang@gmail.com"))
  :maintainers '(("Aborn Jiang" . "aborn.jiang@gmail.com")))
