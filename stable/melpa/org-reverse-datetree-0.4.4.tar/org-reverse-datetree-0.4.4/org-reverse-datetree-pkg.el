;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-reverse-datetree" "0.4.4"
  "Create reverse date trees in org-mode."
  '((emacs "29.1")
    (dash  "2.19.1")
    (org   "9.6"))
  :url "https://github.com/akirak/org-reverse-datetree"
  :commit "8466a3566292cf17e70e6ab4e7fb9e1b48831586"
  :revdesc "8466a3566292"
  :keywords '("outlines")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
