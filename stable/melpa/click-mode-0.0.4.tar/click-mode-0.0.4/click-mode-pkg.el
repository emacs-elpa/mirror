;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "click-mode" "0.0.4"
  "Major mode for the Click Modular Router Project."
  '((emacs "24"))
  :url "https://github.com/bmalehorn/click-mode"
  :commit "c074e7b5b0a88434d0d3411f18884d1f6e288b33"
  :revdesc "c074e7b5b0a8"
  :keywords '("click" "router")
  :authors '(("Brian Malehorn" . "bmalehorn@gmail.com"))
  :maintainers '(("Brian Malehorn" . "bmalehorn@gmail.com")))
