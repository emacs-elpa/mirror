;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jtsx" "0.7.0"
  "Extends JSX/TSX built-in support."
  '((emacs "29.1"))
  :url "https://github.com/llemaitre19/jtsx"
  :commit "ec2617b8ebe6c7f8bc1fe1b1cb6ad0ea6421af52"
  :revdesc "ec2617b8ebe6"
  :keywords '("languages")
  :authors '(("Loïc Lemaître" . "loic.lemaitre@gmail.com"))
  :maintainers '(("Loïc Lemaître" . "loic.lemaitre@gmail.com")))
