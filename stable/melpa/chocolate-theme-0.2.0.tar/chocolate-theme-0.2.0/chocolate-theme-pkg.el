;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chocolate-theme" "0.2.0"
  "A dark chocolaty theme."
  '((emacs      "24.1")
    (autothemer "0.2"))
  :url "https://github.com/SavchenkoValeriy/emacs-chocolate-theme"
  :commit "0b001cb48726146174e88a32a1e6f8b766dc27bf"
  :revdesc "0b001cb48726"
  :authors '(("Valeriy Savchenko" . "sinmipt@gmail.com"))
  :maintainers '(("Valeriy Savchenko" . "sinmipt@gmail.com")))
