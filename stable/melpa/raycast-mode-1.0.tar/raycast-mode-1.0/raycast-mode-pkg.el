;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "raycast-mode" "1.0"
  "Develop Raycast Extensions."
  '((emacs "26.1"))
  :url "https://github.com/nhojb/raycast-mode"
  :commit "57485d1d9842e66c6bed1a27c6e35c6c838d9bdd"
  :revdesc "57485d1d9842"
  :keywords '("convenience" "languages" "tools")
  :authors '(("John Buckley" . "nhoj.buckley@gmail.com"))
  :maintainers '(("John Buckley" . "nhoj.buckley@gmail.com")))
