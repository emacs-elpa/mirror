;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "command-queue" "0.0.1"
  "Shell command queue."
  ()
  :url "https://github.com/Yuki-Inoue/command-queue"
  :commit "ef906a08b438ea1f8f0367561b28d2396eb4201c"
  :revdesc "ef906a08b438"
  :authors '(("Yuki INOUE" . "inouetakahirokiatgmail.com"))
  :maintainers '(("Yuki INOUE" . "inouetakahirokiatgmail.com")))
