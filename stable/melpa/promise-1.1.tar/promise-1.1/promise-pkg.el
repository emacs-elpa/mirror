;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promise" "1.1"
  "Promises/A+."
  '((emacs "25.1"))
  :url "https://github.com/chuntaro/emacs-promise"
  :commit "53e1dfe9a8bd613fdfa31944e5259dcdd3a29e12"
  :revdesc "1.1-0-g53e1dfe9a8bd"
  :keywords '("async" "promise" "convenience")
  :authors '(("chuntaro" . "chuntaro@sakura-games.jp"))
  :maintainers '(("chuntaro" . "chuntaro@sakura-games.jp")))
