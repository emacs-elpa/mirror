;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sl" "0.2"
  "An Emacs clone of sl(1)."
  '((cl-lib "0.5"))
  :url "https://github.com/xuchunyang/sl.el"
  :commit "51d92f820f3e93776fff6cdb9690458816888bdc"
  :revdesc "51d92f820f3e"
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
