;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-simple" "1.0"
  "Simple Unit Test Framework for Emacs Lisp."
  ()
  :url "https://github.com/rocky/emacs-test-simple"
  :commit "75eea25bae04d8e5e3e835a2770f02f0ff4602c4"
  :revdesc "75eea25bae04"
  :keywords '("unit-test"))
