;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "letterbox-mode" "0.3"
  "A small artist adjunct."
  ()
  :url "http://www.github.com/pacha64/letterbox-mode"
  :commit "f773815b258af5fe140893e4b221d99fbaf30dd9"
  :revdesc "f773815b258a"
  :keywords '("box-drawing" "privacy" "password" "sensitive")
  :authors '(("Fernando Leboran" . "f.leboran@gmail.com"))
  :maintainers '(("Fernando Leboran" . "f.leboran@gmail.com")))
