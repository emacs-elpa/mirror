;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "2.6.0"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "fef0ec7e526d47f18aefbe7c9481eefc6a175c19"
  :revdesc "2.6.0-0-gfef0ec7e526d"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
