;;; reddigg.el --- A reader for redditt -*- lexical-binding: t; -*-
;; Copyright (C) 2021  Thanh Vuong

;; Author: Thanh Vuong <thanhvg@gmail.com>
;; URL: https://github.com/thanhvg/emacs-reddigg
;; Package-Requires: ((emacs "26.3") (promise "1.1") (ht "2.3") (org "9.2") (json "1.4"))
;; Package-Version: 0.9.3
;; Package-Revision: 54f8bc5bfef9

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;; This package allows you to browse reddit in org-mode.
;;
;; Reddit now requires a logged-in, browser-driven session for its
;; JSON endpoints, so reddigg no longer talks to old.reddit.com
;; directly.  Instead it talks to a small local Python server (see
;; server/reddigg_server.py) over a simple HTTP/REST API.  That server
;; relays requests to a reddit tab running the reddigg userscript,
;; which is the only thing with the user's real, logged-in session.
;; You must:
;;   1. Run the server:  python3 server/reddigg_server.py
;;   2. Load userscript/reddigg-ws.user.js in your browser and be
;;      logged into old.reddit.com there.
;; The server listens on a single port (1979) for both the userscript's
;; websocket and Emacs's REST requests.  REST requests are authenticated
;; with a token the server stores in `reddigg-token-file'.
;; See `reddigg-server-url' to point Emacs at a non-default host/port,
;; and `reddigg-ping' to check that the whole chain
;; (Emacs -> server -> browser tab) is working.
;;
;; Buffers:
;; There are three buffers which are on org-mode. They show links and elisp
;; commands which will run when you enter/click (org-open-at-point) on them.
;; *reddigg-main*: show your subreddit list, enter on them will fetch the
;; subreddit posts and show them on *reddigg*. On *reddigg* when you enter on a
;; post will fetch the comments and show them on *reddigg-comments* buffer.
;;
;; Variables:
;; reddigg-subs: list of subreddits you want to show on *reddigg-main*
;;
;; * Commands
;; reddigg-view-main: show your subreddit list in *reddigg-main*, r/all and
;; r/popular are included.
;;
;; reddigg-view-sub: prompt for a subreddits and show it,
;;
;; reddigg-view-frontpage: view frontpage
;;
;; reddigg-view-comments: prompt for a post (eg:
;; r/emacs/comments/lfww57/weekly_tipstricketc_thread/ or
;; https://old.reddit.com/r/emacs/comments/lfww57/weekly_tipstricketc_thread/)
;; and show it.
;;
;; reddigg-ping: check the server and the browser tab are reachable.
;;
;; reddigg-refresh-session: re-read the logged-in username from the tab.
;;
;; * Interaction (in the generated buffers, `reddigg-view-mode')
;; C-c C-v u / d / 0   upvote / downvote / clear vote
;; C-c C-v r           reply
;; C-c C-v e           edit your own post/comment
;; C-c C-v x           delete your own post/comment
;; `reddigg-submit-post' creates a new submission.

;;; Code:

(require 'promise)
(require 'cl-lib)
(require 'seq)
(require 'subr-x)
(require 'dom)

;; Org internals we bind dynamically in `reddigg--replace-more-line'.
(defvar org-fold-core--ignore-fragility-checks)
(require 'ht)
(require 'org)
(require 'json)
(require 'url)
(require 'url-http)

(defgroup reddigg nil
  "Search and read stackoverflow and sisters's sites."
  :group 'convenience
  :link '(emacs-commentary-link "reddigg.el"))

(defcustom reddigg-subs '(acmilan emacs starcraft)
  "List of subreddits."
  :type 'list
  :group 'reddigg)

(defcustom reddigg-server-url "http://127.0.0.1:1979/reddigg"
  "Base URL of the reddigg HTTP/REST server.
The server (see server/reddigg_server.py) relays requests to a reddit
tab running userscript/reddigg-ws.user.js.  The default matches the
server's default --port (1979), which serves both REST and websocket."
  :type 'string
  :group 'reddigg)

(defcustom reddigg-token-file
  (or (getenv "REDDIGG_TOKEN_FILE")
      (expand-file-name "reddigg/token"
                        (or (getenv "XDG_CONFIG_HOME") "~/.config")))
  "File holding the secret token the reddigg server requires.
The server creates this file (mode 0600) on first start; it is sent
as the X-Bridge-Token header on every request."
  :type 'file
  :group 'reddigg)

(defcustom reddigg-request-timeout 35
  "Seconds to wait for a single reddigg HTTP request to complete."
  :type 'number
  :group 'reddigg)

(defvar reddigg--modhash nil
  "Cached CSRF modhash scraped from the reddit tab (informational only;
the server/userscript attaches the modhash to state-changing requests).")

(defvar reddigg--current-user nil
  "Cached logged-in reddit username, scraped from the reddit tab.")

(defconst reddigg--json-false :reddigg-false
  "Sentinel representing JSON `false', kept distinct from `null'/missing
when parsing reddit API responses. Needed for fields like \"likes\",
where true = upvoted, this sentinel = downvoted, and nil = no vote /
not present -- collapsing false and null together (the old behavior)
made \"downvoted\" indistinguishable from \"never voted\".")

(defun reddigg--parse-json-string (text)
  "Parse JSON TEXT the way reddit's API responses should be read:
hash-tables for objects, nil for JSON null, and `reddigg--json-false'
for JSON false."
  (if (fboundp 'json-parse-string)
      (json-parse-string text
                          :object-type 'hash-table
                          :null-object nil
                          :false-object reddigg--json-false)
    (let ((json-array-type 'vector)
          (json-object-type 'hash-table)
          (json-false reddigg--json-false))
      (json-read-from-string text))))

(defun reddigg--parse-json-buffer ()
  "Read json from the current buffer (from point to the end)."
  (reddigg--parse-json-string
   (buffer-substring-no-properties (point) (point-max))))

(defun reddigg--reason-string (reason)
  "Turn a promise rejection REASON into a printable string.
Reasons are either plain strings (from the HTTP layer) or Lisp error
objects such as (error \"msg\") or (user-error \"msg\")."
  (cond ((stringp reason) reason)
        ((and (consp reason) (symbolp (car reason)))
         (error-message-string reason))
        (t (format "%s" reason))))

(defconst reddigg--sub-path
  "/r/%s.json?count=25"
  "Sub reddit path template (origin supplied by the server).")

(defconst reddigg--sub-view-sort-path
  "/r/%s/%s.json?count=25"
  "Sub reddit path template for new and rising.")

(defconst reddigg--sub-view-sort-scope-path
  "/r/%s/%s.json?count=25&sort=%s&t=%s"
  "Sub reddit path template for top and controversial.")

(defconst reddigg--cmt-path
  "/%s.json"
  "Comment link path template.")

(defconst reddigg--cmt-more-path
  "/api/morechildren?api_type=json&link_id=%s&children=%s"
  "More comment link path template.")

(defconst reddigg--template-sub "[[elisp:(reddigg-view-sub \"%s\")][%s]]\n"
  "Template string for main.")

(defconst reddigg--template-sub* "[[elisp:(reddigg-view-sub \"%s\")][%s]]"
  "Template string for refresh sub post list.")

(defconst reddigg--template-sub-sort "[[elisp:(reddigg--view-sub \"%s\" %s)][%s]]"
  "Template string for sub sort.")

(defun reddigg--ensure-modes ()
  "Get a bunch of modes up and running."
  (if (equal major-mode 'org-mode)
      (org-set-startup-visibility)
    (org-mode)
    (font-lock-flush))
  (visual-line-mode)
  (reddigg-view-mode 1))

(defvar reddigg-replacement-list
  '(("^\\* " . "- ")
    ("&gt;" . ">")
    ("&lt;" . "<")
    ("&amp;#x200B;" . "\n")
    ("&amp;nbsp;" . "\n")
    ("&amp;" . "&"))
  "List of (find . replace) to sanitize the text in range.")

(defvar-local reddigg--cmt-list-id nil
  "ID/name of the current comment list.")

;;; --- HTTP transport to the local reddigg server --------------------------
;;
;; All reddit access goes through the local Python server (see
;; `reddigg-server-url'), which relays each request to the reddit tab
;; running the reddigg userscript -- the only thing with a real,
;; logged-in session.  The server exposes a small REST API:
;;
;;   GET  /reddigg/ping                   -> {"ok":true,"result":...}
;;   GET  /reddigg/session                -> {"ok":true,"result":{modhash,user}}
;;   GET  /reddigg/get?path=<reddit path> -> {"ok":true,"result":<json>}
;;   POST /reddigg/vote     {"id","dir"}
;;   POST /reddigg/comment  {"parent","text"}
;;   POST /reddigg/edit     {"id","text"}
;;   POST /reddigg/delete   {"id"}
;;   POST /reddigg/submit   {"subreddit","title","kind","text","url"}
;;
;; Every reply is either {"ok":true,"result":...} or {"error":"..."}
;; (with a 4xx/5xx status on failure).  Every request must carry the
;; token from `reddigg-token-file' in an X-Bridge-Token header.

(defun reddigg--token ()
  "Return the server auth token read from `reddigg-token-file'."
  (let ((file (expand-file-name reddigg-token-file)))
    (unless (file-readable-p file)
      (error "reddigg: cannot read token file %s (start the server once to create it)"
             file))
    (string-trim
     (with-temp-buffer
       (insert-file-contents file)
       (buffer-string)))))

(defun reddigg--url-encode (s)
  "Percent-encode string S for use as a URL query value."
  (url-hexify-string s))

(defun reddigg--http-request (method url &optional body)
  "Perform a synchronous HTTP request and promise the parsed result.
METHOD is \"GET\" or \"POST\".  URL is the full request URL.  BODY,
when non-nil, is a hash-table/alist to send as a JSON POST body.
The promise resolves to the server's `result' value, or rejects with
a string carrying the server's message on failure."
  (promise-new
   (lambda (resolve reject)
     (condition-case err
         (let* ((url-request-method method)
                (url-request-extra-headers
                 `(("X-Bridge-Token" . ,(reddigg--token))
                   ,@(when body '(("Content-Type" . "application/json")))))
                (url-request-data
                 (when body (encode-coding-string (json-encode body) 'utf-8)))
                (buf (url-retrieve-synchronously url t t
                                                 reddigg-request-timeout)))
           (if (not buf)
               (funcall reject
                        "reddigg: no response from server (is it running, or did the request time out?)")
             (unwind-protect
                 (with-current-buffer buf
                   (goto-char (point-min))
                   (let* ((status (and (looking-at "HTTP/[0-9.]+ \\([0-9]+\\)")
                                       (string-to-number (match-string 1))))
                          ;; The body starts after the blank line that ends
                          ;; the headers; it is UTF-8 bytes in a unibyte buffer.
                          (data (and (re-search-forward "\r?\n\r?\n" nil t)
                                     (condition-case nil
                                         (reddigg--parse-json-string
                                          (decode-coding-string
                                           (buffer-substring-no-properties
                                            (point) (point-max))
                                           'utf-8))
                                       (error nil)))))
                     (if (and status (>= status 200) (< status 300)
                              (hash-table-p data))
                         (funcall resolve (gethash "result" data))
                       (funcall reject
                                (or (and (hash-table-p data)
                                         (gethash "error" data))
                                    (format "reddigg: HTTP %s from server"
                                            (or status "?")))))))
               (kill-buffer buf))))
       (error (funcall reject
                       (format "reddigg: request to %s failed: %s"
                               url (error-message-string err))))))))

(defun reddigg--reddigg-get (path)
  "Promise the reddit JSON at reddit PATH (e.g. \"/r/emacs.json\")."
  (reddigg--http-request
   "GET"
   (format "%s/get?path=%s" reddigg-server-url (reddigg--url-encode path))))

(defun reddigg--reddigg-post (action params)
  "Promise the result of POSTing PARAMS to server ACTION.
PARAMS is an alist of (\"name\" . value) or a hash-table; it is sent
as a JSON object body."
  (reddigg--http-request
   "POST"
   (format "%s/%s" reddigg-server-url action)
   (if (hash-table-p params) params (ht<-alist params))))

;;; --- reading: posts and comments -------------------------------------------

(cl-defun reddigg--promise-posts (sub &key after before sort scope)
  "Promise SUB post list with keywords.
AFTER: fetch post after name.
BEFORE: fetch posts before name.
SORT: top, hot, best, rising, controversial.
SCOPE: hour, day, week, year, all."
  (reddigg--reddigg-get
   ;; create the reddit path (the server prepends the origin)
   (concat
    (cond
     ((or (eq sort 'new )
          (eq sort 'rising))
      (format reddigg--sub-view-sort-path sub sort))
     ((or (eq sort 'top )
          (eq sort 'controversial))
      (format reddigg--sub-view-sort-scope-path sub sort sort scope))
     (t (format reddigg--sub-path sub)))
    (when after
      (concat "&after=" after))
    (when before
      (concat "&before=" before)))))

(defun reddigg--normalize-cmt-path (cmt)
  "Reduce CMT to a bare path such as \"r/emacs/comments/abc/title\".
CMT may be a full reddit URL, a permalink with leading/trailing
slashes (as reddit returns them), or an already-bare path.  The
leading slash matters: the server resolves the path against the
reddit origin, so a stray \"//\" would be read as a host."
  (let* ((p (replace-regexp-in-string "\\`https?://[^/]+/" "" cmt))
         (p (replace-regexp-in-string "[?#].*\\'" "" p))
         (p (replace-regexp-in-string "\\`/+\\|/+\\'" "" p))
         (p (replace-regexp-in-string "\\.json\\'" "" p)))
    p))

(defun reddigg--promise-comments (cmt)
  "Promise CMT list."
  (reddigg--reddigg-get
   (format reddigg--cmt-path (reddigg--normalize-cmt-path cmt))))

(defun reddigg--promise-more-comments (children)
  "Promise more comment list for CHILDREN."
  (reddigg--reddigg-get
   (format reddigg--cmt-more-path reddigg--cmt-list-id children)))

;;; --- health check -----------------------------------------------------------

;;;###autoload
(defun reddigg-ping ()
  "Check that the reddigg server is up and a reddit tab is connected."
  (interactive)
  (promise-chain (reddigg--http-request
                  "GET" (format "%s/ping" reddigg-server-url))
    (then (lambda (_result)
            (message "reddigg: server and browser tab are reachable")))
    (promise-catch (lambda (reason)
                     (message "reddigg: ping failed: %s"
                              (reddigg--reason-string reason))))))

;;; --- session info -------------------------------------------------------
;;
;; The local server reports the logged-in user (and modhash) for the
;; reddit tab it is relaying to; Emacs keeps the username around so it
;; can tell which entries are the user's own (for edit/delete).

(defun reddigg--promise-session-info (&optional force)
  "Promise (MODHASH . USER). Uses cached values unless FORCE."
  (if (and (not force) reddigg--current-user)
      (promise-resolve (cons reddigg--modhash reddigg--current-user))
    (promise-chain (reddigg--http-request
                    "GET" (format "%s/session" reddigg-server-url))
      (then (lambda (data)
              (let ((modhash (and (hash-table-p data) (gethash "modhash" data)))
                    (user (and (hash-table-p data) (gethash "user" data))))
                (unless (and (stringp user) (> (length user) 0))
                  (error "reddigg: not logged in on the reddit tab \
(are you logged into old.reddit.com?)"))
                (setq reddigg--modhash modhash
                      reddigg--current-user user)
                (cons modhash user)))))))

(defun reddigg--prefetch-session ()
  "Warm the session cache in the background, ignoring failures."
  (promise-catch (reddigg--promise-session-info) #'ignore))

;;;###autoload
(defun reddigg-refresh-session ()
  "Force re-reading the username from the reddit tab.
Use this if actions start failing after you log out/in or switch
accounts in the browser."
  (interactive)
  (promise-chain (reddigg--promise-session-info t)
    (then (lambda (info)
            (message "reddigg: session refreshed (logged in as %s)" (cdr info))))
    (promise-catch (lambda (reason)
                     (message "reddigg: could not refresh session: %s"
                              (reddigg--reason-string reason))))))

;;; --- Generic authenticated POST ------------------------------------------

(defun reddigg--check-api-errors (data)
  "Signal a readable error if DATA (parsed reddit API JSON) carries
errors in the {\"json\":{\"errors\":[...]}} envelope; else return DATA."
  (when (hash-table-p data)
    (let* ((json (gethash "json" data))
           (errors (and (hash-table-p json) (gethash "errors" json))))
      (when (and errors (> (length errors) 0))
        (error "reddigg: reddit API error: %s"
               (mapconcat (lambda (e)
                            (format "%s" (if (and (sequencep e) (>= (length e) 2))
                                             (elt e 1)
                                           e)))
                          (append errors nil) "; ")))))
  data)

(defun reddigg--promise-post (action fields)
  "Promise the parsed JSON result of POSTing FIELDS (an alist) to server
ACTION (e.g. \"vote\").  The browser side attaches the CSRF modhash
itself; this signals an error if reddit's response reports one."
  (promise-chain (reddigg--reddigg-post action fields)
    (then #'reddigg--check-api-errors)))

;;; --- Thing identity (posts/comments) at point ----------------------------

(defun reddigg--thing-at-point ()
  "Return (:id ID :author AUTHOR :subreddit SUBREDDIT) for the reddigg
entry at point, or user-error."
  (save-excursion
    (condition-case nil
        (org-back-to-heading t)
      (error (user-error "reddigg: point is not on a reddigg entry")))
    (let ((id (org-entry-get (point) "REDDIGG_ID"))
          (author (org-entry-get (point) "REDDIGG_AUTHOR"))
          (subreddit (org-entry-get (point) "REDDIGG_SUBREDDIT")))
      (unless id
        (user-error "reddigg: no reddit item at point (missing REDDIGG_ID)"))
      (list :id id :author author :subreddit subreddit))))

(defun reddigg--mark-body-overlay (start end)
  "Wrap START..END (markers or positions) in an overlay tagging it as
this entry's editable body text, so `reddigg-edit-at-point' can find
and replace it later without needing to re-fetch from reddit."
  (let ((ov (make-overlay start end nil t nil)))
    (overlay-put ov 'reddigg-body t)
    ov))

(defun reddigg--find-body-overlay ()
  "Find the body overlay for the reddigg entry at point, or nil."
  (save-excursion
    (org-back-to-heading t)
    (let ((subtree-end (save-excursion (org-end-of-subtree t t) (point))))
      (car (seq-filter (lambda (ov) (overlay-get ov 'reddigg-body))
                       (overlays-in (point) subtree-end))))))

(defun reddigg--likes->string (value)
  "Convert a raw reddit \"likes\" JSON VALUE into \"up\"/\"down\"/\"none\".
VALUE is t (upvoted), `reddigg--json-false' (downvoted), or nil (no
vote / not present)."
  (cond
   ((eq value t) "up")
   ((eq value reddigg--json-false) "down")
   (t "none")))

(defun reddigg--likes-string->number (s)
  "Inverse of `reddigg--likes->string': \"up\"/\"down\"/\"none\" (or nil,
treated as \"none\") to 1/-1/0."
  (cond ((equal s "up") 1)
        ((equal s "down") -1)
        (t 0)))

(defun reddigg--bump-score (delta)
  "Add DELTA to the :REDDIGG_SCORE: property of the heading at point."
  (let* ((current (org-entry-get (point) "REDDIGG_SCORE"))
         (current-n (if current (string-to-number current) 0)))
    (org-entry-put (point) "REDDIGG_SCORE" (number-to-string (+ current-n delta)))))

(defun reddigg--format-created (epoch)
  "Format EPOCH (reddit's \"created_utc\", seconds since epoch) as a
readable timestamp, or \"unknown\" if EPOCH isn't a number."
  (if (numberp epoch)
      (format-time-string "%Y-%m-%d %H:%M:%S" epoch)
    "unknown"))

;;; --- Voting ---------------------------------------------------------------

(defconst reddigg--vote-action "vote"
  "Server action for voting.  Params: id, dir.")

(defun reddigg--vote (dir)
  "Vote DIR (1, -1, or 0) on the reddigg entry at point."
  (let* ((thing (reddigg--thing-at-point))
         (id (plist-get thing :id))
         (marker (point-marker)))
    (promise-chain (reddigg--promise-post reddigg--vote-action
                                          (list (cons "id" id) (cons "dir" dir)))
      (then (lambda (_data)
              (with-current-buffer (marker-buffer marker)
                (save-excursion
                  (goto-char marker)
                  (org-back-to-heading t)
                  (let* ((old-numeric (reddigg--likes-string->number
                                       (org-entry-get (point) "REDDIGG_LIKES")))
                         (delta (- dir old-numeric)))
                    (reddigg--bump-score delta)
                    (org-entry-put (point) "REDDIGG_LIKES"
                                   (pcase dir (1 "up") (-1 "down") (_ "none")))
                    (message "reddigg: %s (score %s%s)"
                            (pcase dir (1 "upvoted") (-1 "downvoted") (_ "vote cleared"))
                            (if (>= delta 0) "+" "")
                            delta))))))
      (promise-catch (lambda (reason)
                       (message "reddigg: vote failed: %s"
                                (reddigg--reason-string reason)))))))

;;;###autoload
(defun reddigg-vote-up ()
  "Upvote the post or comment at point."
  (interactive)
  (reddigg--vote 1))

;;;###autoload
(defun reddigg-vote-down ()
  "Downvote the post or comment at point."
  (interactive)
  (reddigg--vote -1))

;;;###autoload
(defun reddigg-vote-clear ()
  "Clear your vote on the post or comment at point."
  (interactive)
  (reddigg--vote 0))

;;; --- Compose buffers (reply/edit/submit) -----------------------------------

(defvar-local reddigg-compose--kind nil
  "Symbol: `comment', `edit', or `submit'. Decides what C-c C-c does.")
(defvar-local reddigg-compose--parent-id nil
  "Fullname of the thing being replied to or edited.")
(defvar-local reddigg-compose--target-marker nil
  "Marker in the source buffer where the result should be inserted/updated.")
(defvar-local reddigg-compose--extra-fields nil
  "Alist of extra POST fields the specific kind needs.")

(defvar-local reddigg-compose--submit-sr nil
  "Subreddit name for a `submit' compose buffer.")

(defvar-local reddigg-compose--submit-kind nil
  "Reddit submission kind (`self' or `link') for a `submit' compose buffer.")

(defvar-local reddigg-compose--submit-title nil
  "Submission title for a `submit' compose buffer.")

(defvar reddigg-compose-mode-map
  (let ((m (make-sparse-keymap)))
    (define-key m (kbd "C-c C-c") #'reddigg-compose-send)
    (define-key m (kbd "C-c C-k") #'reddigg-compose-abort)
    m)
  "Keymap for reddigg compose buffers.")

(define-minor-mode reddigg-compose-mode
  "Minor mode for composing reddit comments/posts/edits."
  :lighter " reddigg-compose"
  :keymap reddigg-compose-mode-map)

(defun reddigg--compose-body ()
  "Return the compose buffer's text, stripping leading `# reddigg:' lines."
  (save-excursion
    (goto-char (point-min))
    (while (looking-at "^# reddigg:.*\n") (forward-line 1))
    (string-trim (buffer-substring-no-properties (point) (point-max)))))

(defun reddigg-compose-abort ()
  "Abandon the current reddigg compose buffer."
  (interactive)
  (when (y-or-n-p "reddigg: discard this? ")
    (kill-buffer)))

(defun reddigg-compose-send ()
  "Submit the current reddigg compose buffer, dispatching on its kind."
  (interactive)
  (let ((kind reddigg-compose--kind)
        (body (reddigg--compose-body))
        (buf (current-buffer)))
    (when (string-empty-p body)
      (user-error "reddigg: empty body, nothing to send"))
    (pcase kind
      ('comment (reddigg--send-comment buf body))
      ('edit (reddigg--send-edit buf body))
      ('submit (reddigg--send-submit buf body))
      (_ (error "reddigg: compose kind %S not implemented yet" kind)))))

(defun reddigg--insert-new-comment (parent-marker comment-data)
  "Insert COMMENT-DATA (a hash-table, see `reddigg--comment-data-with-fallback')
as a new child heading under PARENT-MARKER's entry."
  (with-current-buffer (marker-buffer parent-marker)
    (let ((inhibit-read-only t))
      (save-excursion
        (goto-char parent-marker)
        (org-back-to-heading t)
        (let* ((level (org-current-level))
               (author (gethash "author" comment-data))
               (body (gethash "body" comment-data))
               (name (gethash "name" comment-data))
               begin)
          (org-end-of-subtree t t)
          (unless (bolp) (insert "\n"))
          (insert (make-string (1+ level) ?*) " " author "\n")
          (insert ":PROPERTIES:\n")
          (insert (format ":REDDIGG_ID: %s\n" name))
          (insert (format ":REDDIGG_AUTHOR: %s\n" author))
          (insert (format ":REDDIGG_SUBREDDIT: %s\n" (or (gethash "subreddit" comment-data) "")))
          (insert (format ":REDDIGG_LIKES: %s\n" (reddigg--likes->string (gethash "likes" comment-data))))
          (insert (format ":REDDIGG_SCORE: %s\n" (gethash "score" comment-data)))
          (insert (format ":REDDIGG_CREATED: %s\n" (reddigg--format-created (gethash "created_utc" comment-data))))
          (insert ":END:\n")
          (setq begin (point-marker))
          (insert body "\n")
          ;; tag the body so the new comment can be edited right away
          (reddigg--mark-body-overlay begin (point-marker)))))))

(defun reddigg--comment-data-with-fallback (server-comment local-body)
  "Build a comment-data hash-table to insert locally.

By the time this is called the POST to reddit has already
succeeded, so we don't want a partial/missing api/comment
response (SERVER-COMMENT, possibly nil, possibly missing keys)
to stop us from showing the comment the user just made. Prefer
whatever the server gave us field-by-field, and fall back to
what we already know locally (the exact text we sent, the
logged-in username) or a sane placeholder otherwise."
  (let ((merged (make-hash-table :test 'equal))
        (server-comment (if (hash-table-p server-comment)
                            server-comment
                          (make-hash-table :test 'equal))))
    (puthash "author" (or (gethash "author" server-comment)
                           reddigg--current-user
                           "[unknown]")
             merged)
    ;; The body we sent is authoritative: it's exactly what reddit received,
    ;; so prefer it over anything (or nothing) the server echoes back.
    (puthash "body" (or local-body (gethash "body" server-comment) "") merged)
    (puthash "name" (or (gethash "name" server-comment) "") merged)
    (puthash "subreddit" (gethash "subreddit" server-comment) merged)
    (puthash "likes" (gethash "likes" server-comment) merged)
    (puthash "score" (or (gethash "score" server-comment) 1) merged)
    (puthash "created_utc" (or (gethash "created_utc" server-comment)
                                (float-time))
             merged)
    merged))

(defconst reddigg--comment-action "comment"
  "Server action for replying.  Params: parent, text.")

(defun reddigg--send-comment (compose-buffer body)
  (let ((parent-id (buffer-local-value 'reddigg-compose--parent-id compose-buffer))
        (target-marker (buffer-local-value 'reddigg-compose--target-marker compose-buffer)))
    (promise-chain (reddigg--promise-post reddigg--comment-action
                                          (list (cons "parent" parent-id)
                                                (cons "text" body)))
      (then (lambda (data)
              ;; The POST has already succeeded by this point. Everything
              ;; below is best-effort local rendering, so wrap it in
              ;; condition-case rather than letting a display bug propagate
              ;; up to promise-catch, where it would be misreported as a
              ;; failed reply even though reddit already has the comment.
              (condition-case err
                  (let* ((json (and (hash-table-p data) (gethash "json" data)))
                         (jdata (and (hash-table-p json) (gethash "data" json)))
                         (things (and (hash-table-p jdata) (gethash "things" jdata)))
                         (first-thing (and things (> (length things) 0)
                                           (elt things 0)))
                         (server-comment (and (hash-table-p first-thing)
                                              (gethash "data" first-thing))))
                    (reddigg--insert-new-comment
                     target-marker
                     (reddigg--comment-data-with-fallback server-comment body)))
                (error
                 (message "reddigg: comment posted, but displaying it locally \
failed (%s); refresh to see it." (error-message-string err))))
              (when (buffer-live-p compose-buffer)
                (kill-buffer compose-buffer))
              (message "reddigg: reply posted")))
      (promise-catch (lambda (reason)
                       (message "reddigg: reply failed: %s"
                                (reddigg--reason-string reason)))))))

;;;###autoload
(defun reddigg-reply-at-point ()
  "Compose a reply to the post or comment at point."
  (interactive)
  (let* ((thing (reddigg--thing-at-point))
         (parent-id (plist-get thing :id))
         (parent-marker (point-marker))
         (buf (generate-new-buffer "*reddigg-reply*")))
    ;; learn our username while the user types, so the locally inserted
    ;; reply is attributed correctly
    (reddigg--prefetch-session)
    (with-current-buffer buf
      (org-mode)
      (reddigg-compose-mode 1)
      (setq-local reddigg-compose--kind 'comment)
      (setq-local reddigg-compose--parent-id parent-id)
      (setq-local reddigg-compose--target-marker parent-marker)
      (insert (format "# reddigg: replying to %s\n" parent-id))
      (insert "# reddigg: C-c C-c to send, C-c C-k to abort\n\n"))
    (pop-to-buffer buf)
    (goto-char (point-max))))

(defconst reddigg--submit-action "submit"
  "Server action for new submissions.
Params: subreddit, title, kind, text, url.")

(defun reddigg--submit-comments-path (post-id)
  "Return a reddigg comments path for the submitted POST-ID."
  (format "comments/%s" (replace-regexp-in-string "\\`t3_" "" post-id)))

(defun reddigg--send-submit (compose-buffer body)
  "Submit the post described by COMPOSE-BUFFER with BODY."
  (let* ((subreddit (buffer-local-value 'reddigg-compose--submit-sr compose-buffer))
         (kind (buffer-local-value 'reddigg-compose--submit-kind compose-buffer))
         (title (buffer-local-value 'reddigg-compose--submit-title compose-buffer))
         (link-p (equal kind "link")))
    (promise-chain
        (reddigg--promise-post
         reddigg--submit-action
         (list (cons "subreddit" subreddit)
               (cons "title" title)
               (cons "kind" kind)
               (cons "text" (if link-p "" body))
               (cons "url" (if link-p body ""))))
      (then
       (lambda (data)
         (let* ((json (and (hash-table-p data) (gethash "json" data)))
                (payload (and (hash-table-p json) (gethash "data" json)))
                (post-id (and (hash-table-p payload) (gethash "name" payload)))
                (post-url (and (hash-table-p payload) (gethash "url" payload)))
                (comments-path (and post-id
                                    (reddigg--submit-comments-path post-id))))
           (when (buffer-live-p compose-buffer)
             (kill-buffer compose-buffer))
           (message "reddigg: post submitted%s%s"
                    (if post-id (format " (%s)" post-id) "")
                    (if post-url (format " %s" post-url) ""))
           (when (and comments-path
                      (y-or-n-p "reddigg: view the new post's comments? "))
             (reddigg--view-comments comments-path t)))))
      (promise-catch
       (lambda (reason)
         (message "reddigg: submit failed: %s"
                  (reddigg--reason-string reason)))))))

;;;###autoload
(defun reddigg-submit-post ()
  "Compose and submit a new Reddit post."
  (interactive)
  (let* ((choices (mapcar (lambda (sub) (if (symbolp sub)
                                            (symbol-name sub)
                                          sub))
                          reddigg-subs))
         (subreddit (string-trim
                     (completing-read "Subreddit: " choices nil nil)))
         (kind (completing-read "Post kind: " '("self" "link") nil t))
         (title (string-trim (read-string "Title: ")))
         (buf (generate-new-buffer "*reddigg-submit*")))
    (when (string-empty-p subreddit)
      (user-error "reddigg: subreddit cannot be empty"))
    (when (string-empty-p title)
      (user-error "reddigg: title cannot be empty"))
    (with-current-buffer buf
      (org-mode)
      (reddigg-compose-mode 1)
      (setq-local reddigg-compose--kind 'submit)
      (setq-local reddigg-compose--submit-sr subreddit)
      (setq-local reddigg-compose--submit-kind kind)
      (setq-local reddigg-compose--submit-title title)
      (insert (format "# reddigg: submitting to r/%s\n" subreddit))
      (insert (format "# reddigg: %s post: %s\n" kind title))
      (insert "# reddigg: C-c C-c to submit, C-c C-k to abort\n\n")
      (insert (if (equal kind "link")
                  "# reddigg: Paste the link URL below.\n"
                "# reddigg: Write the post body below.\n")))
    (pop-to-buffer buf)
    (goto-char (point-max))))

;;; --- Edit / delete your own content ----------------------------------------

(defconst reddigg--edit-action "edit"
  "Server action for editing text.  Params: id, text.")
(defconst reddigg--del-action "delete"
  "Server action for deleting.  Params: id.")

(defun reddigg--replace-body-at-marker (heading-marker new-text)
  "Replace the editable body text of the reddigg entry at HEADING-MARKER
with NEW-TEXT (the raw markdown just submitted to reddit)."
  (with-current-buffer (marker-buffer heading-marker)
    (let ((inhibit-read-only t))
      (save-excursion
        (goto-char heading-marker)
        (org-back-to-heading t)
        (let ((ov (reddigg--find-body-overlay)))
          (if (not ov)
              (message "reddigg: edit saved on reddit, but couldn't find the \
body in this buffer to update it locally; refresh to see the change.")
            (let ((start (overlay-start ov)))
              (goto-char start)
              (delete-region start (overlay-end ov))
              (insert new-text "\n")
              (move-overlay ov start (point))
              (reddigg--sanitize-range start (point)))))))))

(defun reddigg--send-edit (compose-buffer body)
  (let ((thing-id (buffer-local-value 'reddigg-compose--parent-id compose-buffer))
        (target-marker (buffer-local-value 'reddigg-compose--target-marker compose-buffer)))
    (promise-chain (reddigg--promise-post reddigg--edit-action
                                          (list (cons "id" thing-id)
                                                (cons "text" body)))
      (then (lambda (_data)
              (reddigg--replace-body-at-marker target-marker body)
              (when (buffer-live-p compose-buffer)
                (kill-buffer compose-buffer))
              (message "reddigg: edit saved")))
      (promise-catch (lambda (reason)
                       (message "reddigg: edit failed: %s"
                                (reddigg--reason-string reason)))))))

(defun reddigg--open-edit-buffer (id marker existing-text)
  "Pop up an edit compose buffer for thing ID (heading at MARKER),
pre-filled with EXISTING-TEXT."
  (let ((buf (generate-new-buffer "*reddigg-edit*")))
    (with-current-buffer buf
      (org-mode)
      (reddigg-compose-mode 1)
      (setq-local reddigg-compose--kind 'edit)
      (setq-local reddigg-compose--parent-id id)
      (setq-local reddigg-compose--target-marker marker)
      (insert (format "# reddigg: editing %s\n" id))
      (insert "# reddigg: C-c C-c to save, C-c C-k to abort\n\n")
      (when existing-text (insert existing-text)))
    (pop-to-buffer buf)
    (goto-char (point-max))))

;;;###autoload
(defun reddigg-edit-at-point ()
  "Compose an edit to the post or comment at point.
Only works on entries you authored; only self-posts and comments have
editable text on reddit (link posts don't)."
  (interactive)
  ;; Gather everything that depends on point *now*; the session lookup
  ;; below is asynchronous.
  (let* ((thing (reddigg--thing-at-point))
         (id (plist-get thing :id))
         (author (plist-get thing :author))
         (ov (reddigg--find-body-overlay))
         (existing-text (when ov
                          (buffer-substring-no-properties
                           (overlay-start ov) (overlay-end ov))))
         (marker (point-marker)))
    (promise-chain (reddigg--promise-session-info)
      (then (lambda (info)
              (unless (equal author (cdr info))
                (user-error "reddigg: this entry isn't yours to edit (author: %s)"
                            (or author "unknown")))
              (reddigg--open-edit-buffer id marker existing-text)))
      (promise-catch (lambda (reason)
                       (message "reddigg: cannot edit: %s"
                                (reddigg--reason-string reason)))))))

;;;###autoload
(defun reddigg-delete-at-point ()
  "Delete the post or comment at point. Only works on entries you authored."
  (interactive)
  (let* ((thing (reddigg--thing-at-point))
         (id (plist-get thing :id))
         (author (plist-get thing :author))
         (marker (point-marker)))
    (promise-chain (reddigg--promise-session-info)
      (then (lambda (info)
              (unless (equal author (cdr info))
                (user-error "reddigg: this entry isn't yours to delete (author: %s)"
                            (or author "unknown")))
              (if (not (y-or-n-p "reddigg: really delete this? "))
                  (message "reddigg: delete cancelled")
                (promise-then
                 (reddigg--promise-post reddigg--del-action (list (cons "id" id)))
                 (lambda (_data)
                   (with-current-buffer (marker-buffer marker)
                     (let ((inhibit-read-only t))
                       (save-excursion
                         (goto-char marker)
                         (org-back-to-heading t)
                         (org-cut-subtree))))
                   (message "reddigg: deleted"))))))
      (promise-catch (lambda (reason)
                       (message "reddigg: delete failed: %s"
                                (reddigg--reason-string reason)))))))

;;; --- View-buffer keymap (voting, replying, editing, deleting) --------------

(defvar reddigg-view-mode-map
  (let ((m (make-sparse-keymap)))
    (define-key m (kbd "C-c C-v u") #'reddigg-vote-up)
    (define-key m (kbd "C-c C-v d") #'reddigg-vote-down)
    (define-key m (kbd "C-c C-v 0") #'reddigg-vote-clear)
    (define-key m (kbd "C-c C-v r") #'reddigg-reply-at-point)
    (define-key m (kbd "C-c C-v e") #'reddigg-edit-at-point)
    (define-key m (kbd "C-c C-v x") #'reddigg-delete-at-point)
    m)
  "Keymap for reddigg's generated browsing buffers.")

(define-minor-mode reddigg-view-mode
  "Minor mode for reddigg's generated org buffers (posts, comments)."
  :lighter " reddigg"
  :keymap reddigg-view-mode-map)

;;; --- buffers and rendering -----------------------------------------------

(defvar reddigg--main-buffer "*reddigg-main*"
  "Buffer for main page.")

(defvar reddigg--buffer "*reddigg*"
  "Buffer for main page.")

(defvar reddigg--cmt-buffer "*reddigg-comments*"
  "Comment buffer.")

(defun reddigg--get-buffer ()
  "Get buffer for sub."
  (get-buffer-create reddigg--buffer))

(defun reddigg--get-cmt-buffer ()
  "Get buffer for comments."
  (get-buffer-create reddigg--cmt-buffer))

(defun reddigg--get-main-buffer ()
  "Get main buffer."
  (get-buffer-create reddigg--main-buffer))

(cl-defun reddigg--print-sub (data sub &optional append &key sort scope)
  "Print sub post list in DATA for SUB.
SORT: top, hot, best, rising, controversial.
SCOPE: hour, day, week, year, all.
When APPEND is non-nil, will not delete buffer but append to it,
after deleting the current line which should be the More button."
  (with-current-buffer (reddigg--get-buffer)
    (save-excursion
      (if append
          (kill-whole-line)
        (erase-buffer)
        ;; insert header and links
        (insert "#+startup: overview indent\n")
        (insert (format "#+title: %s sorted by %s%s\n"
                        (if (< (length sub) 30)
                            sub
                          "posts")
                        (if sort sort 'default)
                        (if scope
                            (format " %s" scope)
                          "")))
        (insert (format reddigg--template-sub* sub "refresh"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'new"
                        "new"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'rising"
                        "rising"))
        (insert "\n")
        ;; top
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'top :scope 'hour"
                        "top-hour"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'top :scope 'day"
                        "top-day"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'top :scope 'week"
                        "top-week"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'top :scope 'month"
                        "top-month"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'top :scope 'year"
                        "top-year"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'top :scope 'all"
                        "top-all"))
        (insert "\n")
        ;; controversial
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'controversial :scope 'hour"
                        "controversial-hour"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'controversial :scope 'day"
                        "con-day"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'controversial :scope 'week"
                        "con-week"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'controversial :scope 'month"
                        "con-month"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'controversial :scope 'year"
                        "con-year"))
        (insert " ")
        (insert (format reddigg--template-sub-sort
                        sub
                        ":sort 'controversial :scope 'all"
                        "con-all"))
        (insert "\n"))

      (seq-do
       (lambda (it)
         (let ((my-it (gethash "data" it)))
           (insert "* " (gethash "title" my-it) "\n")
           (insert ":PROPERTIES:\n")
           (insert (format ":REDDIGG_ID: %s\n" (gethash "name" my-it)))
           (insert (format ":REDDIGG_AUTHOR: %s\n" (gethash "author" my-it)))
           (insert (format ":REDDIGG_SUBREDDIT: %s\n" (gethash "subreddit" my-it)))
           (insert (format ":REDDIGG_LIKES: %s\n" (reddigg--likes->string (gethash "likes" my-it))))
           (insert (format ":REDDIGG_SCORE: %s\n" (gethash "score" my-it)))
           (insert (format ":REDDIGG_CREATED: %s\n" (reddigg--format-created (gethash "created_utc" my-it))))
           (insert ":END:\n")
           (insert "| " (ht-get my-it "subreddit_name_prefixed") " | ")
           (insert "score: " (format "%s" (gethash "score" my-it) ) " | ")
           (insert "comments: " (format "%s" (gethash "num_comments" my-it)) " | ")
           (insert "created: " (format-time-string "%Y-%m-%d" (gethash "created_utc" my-it)) "\n")
           (let ((selftext (gethash "selftext" my-it)) begin end)
             (if (or (null selftext) (string-empty-p selftext))
                 (insert (reddigg--link-post-line (gethash "url" my-it)))
               (setq begin (point-marker))
               (insert "\n" selftext "\n")
               (setq end (point-marker))
               (reddigg--sanitize-range begin end)
               (reddigg--mark-body-overlay begin end)))
           (dolist (u (reddigg--gallery-urls my-it))
             (insert (format "%s \n[[elisp:(reddigg-view-image \"%s\")][view image]]\n" u u)))
           (insert (format "[[elisp:(reddigg--view-comments \"%s\")][view comments]]\n"
                           (ht-get my-it "permalink")))))
       (ht-get data "children"))
      (let ((after (ht-get data "after")))
        (when after
          (insert (format "* [[elisp:(reddigg--view-sub-more \"%s\" \"%s\" '%s '%s)][More]]"
                          sub after sort scope))))
      (reddigg--ensure-modes))))

(defun reddigg--sanitize-range (begin end)
  "Remove heading * inside rang between BEGIN and END."
  (save-excursion
    (dolist (it reddigg-replacement-list)
      (goto-char begin)
      (while (re-search-forward (car it) end t)
        (replace-match (cdr it))))))

(defun reddigg--iso-time->epoch (s)
  "Convert an ISO 8601 UTC timestamp string S to epoch seconds, or nil."
  (when (and (stringp s)
             (string-match
              "\\([0-9]+\\)-\\([0-9]+\\)-\\([0-9]+\\)T\\([0-9]+\\):\\([0-9]+\\):\\([0-9]+\\)"
              s))
    (let ((n (lambda (i) (string-to-number (match-string i s)))))
      (float-time (encode-time (funcall n 6) (funcall n 5) (funcall n 4)
                               (funcall n 3) (funcall n 2) (funcall n 1)
                               t)))))

;; (defun reddigg--unescape-entities (s)
;;   "Undo ONE level of HTML entity escaping in S.
;; The \"content\" field of the morechildren response is an HTML fragment
;; that was itself entity-escaped (\"&lt;div ...\").  This is a single
;; pass, so \"&amp;#32;\" becomes \"&#32;\" and is left for the HTML parser."
;;   (replace-regexp-in-string
;;    "&\\(?:lt\\|gt\\|amp\\|quot\\|#39\\);"
;;    (lambda (m)
;;      (pcase m
;;        ("&lt;" "<") ("&gt;" ">") ("&amp;" "&") ("&quot;" "\"") (_ "'")))
;;    s t t))

(defun reddigg--content->dom (content)
  "Parse the escaped HTML fragment CONTENT into a DOM tree."
  (unless (fboundp 'libxml-parse-html-region)
    (user-error "reddigg: this Emacs lacks libxml2 support, needed to read more comments"))
  (with-temp-buffer
    (insert content)
    (libxml-parse-html-region (point-min) (point-max))))

(defun reddigg--normalize-thing (thing)
  "Return THING in the classic comment shape.
The newer /api/morechildren response gives each comment as
{\"kind\":\"t1\",\"data\":{\"id\",\"parent\",\"link\",\"content\",
\"contentHTML\",\"contentText\",\"replies\"}} with no author, score,
body, depth etc.  The metadata only lives in the HTML in \"content\",
so parse that into a DOM and read it with the `dom' API.  Things
already in the classic shape (and \"more\" stubs) are returned as is."
  (let ((data (ht-get thing "data")))
    (if (or (not (hash-table-p data))
            (equal (ht-get thing "kind") "more")
            (ht-get data "body")
            (not (stringp (ht-get data "content"))))
        thing
      (let* ((dom (reddigg--content->dom (ht-get data "content")))
             (node (car (dom-by-id dom "\\`thing_")))
             (score (car (dom-by-class dom "\\`score unvoted\\'")))
             (entry (car (dom-by-class dom "\\`entry ")))
             (entry-state (and entry
                               (cadr (split-string
                                      (or (dom-attr entry 'class) "")))))
             (time (car (dom-by-tag dom 'time)))
             (new (ht-copy data))
             (out (ht-create)))
        (ht-set! new "name" (ht-get data "id"))
        (ht-set! new "author" (or (and node (dom-attr node 'data-author))
                                  "[deleted]"))
        (ht-set! new "subreddit" (and node (dom-attr node 'data-subreddit)))
        ;; no score node when the subreddit hides scores
        (ht-set! new "score" (and score (dom-attr score 'title)
                                  (string-to-number (dom-attr score 'title))))
        (ht-set! new "created_utc"
                 (and time (reddigg--iso-time->epoch (dom-attr time 'datetime))))
        (ht-set! new "likes" (cond ((equal entry-state "likes") t)
                                   ((equal entry-state "dislikes")
                                    reddigg--json-false)))
        (ht-set! new "body" (or (ht-get data "contentText") ""))
        (ht-set! out "kind" (ht-get thing "kind"))
        (ht-set! out "data" new)
        out))))

(defun reddigg--nest-things (things)
  "Arrange the flat THINGS list into a tree by their \"parent\" ids.
Return the roots (things whose parent is not in THINGS); each thing's
\"replies\" is filled with a listing of its children so that
`reddigg--print-comment-list' recurses into it."
  (let ((ids (make-hash-table :test 'equal))
        (kids (make-hash-table :test 'equal))
        roots)
    (seq-do (lambda (th)
              (let ((id (ht-get* th "data" "name")))
                (when id (puthash id t ids))))
            things)
    (seq-do (lambda (th)
              (let ((parent (ht-get* th "data" "parent")))
                (if (and parent (gethash parent ids))
                    (puthash parent (append (gethash parent kids) (list th))
                             kids)
                  (push th roots))))
            things)
    (maphash (lambda (parent children)
               (let ((th (seq-find (lambda (x)
                                     (equal (ht-get* x "data" "name") parent))
                                   things))
                     (listing (ht-create))
                     (ldata (ht-create)))
                 (ht-set! ldata "children" (vconcat children))
                 (ht-set! listing "data" ldata)
                 (ht-set! (ht-get th "data") "replies" listing)))
             kids)
    (nreverse roots)))

(defun reddigg--print-comment-list (cmt-list level)
  "Print comments from CMT-LIST with LEVEL."
  (seq-do
   (lambda (it)
     (let* ((kind (ht-get it "kind"))
            (data (ht-get it "data"))
            (replies (ht-get data "replies"))
            ;; morechildren no longer returns "depth"; LEVEL is
            ;; depth+1 stars, so derive it from that.
            (depth (or (ht-get data "depth") (max 0 (1- (length level)))))
            (my-level (make-string (+ 2 depth) ?*))
            begin end)
       (if (string= kind "more")
           ;; (insert level " reddigg: too many subcomments\n")
           (insert my-level
                   (format " [[elisp:(reddigg--view-more-cmts \"%s\" \"%s\")][load more comments (%s)]]\n"
                           level
                           (mapconcat #'identity (ht-get data "children") ",")
                           (ht-get data "count")))

         (insert my-level " " (or (ht-get data "author") "[deleted]") "\n")
         (insert ":PROPERTIES:\n")
         (insert (format ":REDDIGG_ID: %s\n" (ht-get data "name")))
         (insert (format ":REDDIGG_AUTHOR: %s\n" (ht-get data "author")))
         (insert (format ":REDDIGG_SUBREDDIT: %s\n" (ht-get data "subreddit")))
         (insert (format ":REDDIGG_LIKES: %s\n" (reddigg--likes->string (ht-get data "likes"))))
         (insert (format ":REDDIGG_SCORE: %s\n" (ht-get data "score")))
         (insert (format ":REDDIGG_CREATED: %s\n" (reddigg--format-created (ht-get data "created_utc"))))
         (insert ":END:\n")
         (setq begin (point-marker))
         (insert (or (ht-get data "body") "") "\n")
         (setq end (point-marker))
         (reddigg--sanitize-range begin end)
         (reddigg--mark-body-overlay begin end)
         (when (hash-table-p replies)
           (reddigg--print-comment-list (ht-get* replies "data" "children") (concat level "*"))))))
   cmt-list))

(defun reddigg--print-comment-1 (data)
  "Print the post itself as a level-1 heading, so it's a full reddigg
entry like any post or comment -- votable, replyable, editable, and
deletable, same as everything nested under it.
Return the value of `reddigg--cmt-list-id'."
  (let ((cmt (ht-get* (aref (ht-get* data "data" "children") 0) "data")) begin end)
    (insert "* " (ht-get cmt "title") "\n")
    (insert ":PROPERTIES:\n")
    (insert (format ":REDDIGG_ID: %s\n" (ht-get cmt "name")))
    (insert (format ":REDDIGG_AUTHOR: %s\n" (ht-get cmt "author")))
    (insert (format ":REDDIGG_SUBREDDIT: %s\n" (ht-get cmt "subreddit")))
    (insert (format ":REDDIGG_LIKES: %s\n" (reddigg--likes->string (ht-get cmt "likes"))))
    (insert (format ":REDDIGG_SCORE: %s\n" (ht-get cmt "score")))
    (insert (format ":REDDIGG_CREATED: %s\n" (reddigg--format-created (ht-get cmt "created_utc"))))
    (insert ":END:\n")
    (insert "| " (ht-get cmt "subreddit_name_prefixed") " | ")
    (insert "score: " (format "%s" (ht-get cmt "score")) " | ")
    (insert "author: " (ht-get cmt "author") " | ")
    (insert "created: " (reddigg--format-created (ht-get cmt "created_utc")) "\n")
    (insert (ht-get cmt "url") "\n")
    (dolist (u (reddigg--gallery-urls cmt))
      (insert u "\n"))
    (insert (format "[[elisp:(reddigg--view-comments \"%s\" t)][refresh]]\n"
                    (ht-get cmt "permalink")))
    (setq begin (point-marker))
    (insert (or (gethash "selftext" cmt) "") "\n")
    (setq end (point-marker))
    (reddigg--sanitize-range begin end)
    (reddigg--mark-body-overlay begin end)
    ;; get value for `reddigg--cmt-list-id'
    (ht-get cmt "name")))

(defun reddigg--print-comment-2 (data level)
  "Extrac comment list from DATA and pass it along with LEVEL."
  (reddigg--print-comment-list (ht-get* data "data" "children") level))

(defun reddigg--print-comments (data)
  "Print comments DATA to buffer."
  (with-current-buffer (reddigg--get-cmt-buffer)
    (erase-buffer)
    (insert "#+startup: show2levels indent\n")
    (insert (format "#+title: comments for '%s'\n"
                    (ht-get* (aref (ht-get* (aref data 0) "data" "children") 0) "data" "title")))
    (let ((post-id (reddigg--print-comment-1 (aref data 0))))
      (reddigg--print-comment-2 (aref data 1) "*")
      (reddigg--ensure-modes)
      ;; `overview' startup visibility (set by `reddigg--ensure-modes' via
      ;; `org-set-startup-visibility') folds the post's own body along
      ;; with all the comments underneath it -- reveal just the post's
      ;; own entry (heading + body, not its comment children) so it
      ;; still reads the way it always has.
      (goto-char (point-min))
      (when (re-search-forward "^\\* " nil t)
        (beginning-of-line)
        (org-show-entry))
      ;; must set here after org-mode is in otherwise when org-mode kicks in all
      ;; local variables will be killed
      (setq reddigg--cmt-list-id post-id))))

;;;###autoload
(defun reddigg-view-comments (cmt)
  "Ask and print CMT to buffer.
CMT may be a full reddit URL or a path like
r/emacs/comments/lfww57/weekly_tipstricketc_thread/."
  (interactive "sComment: ")
  ;; `reddigg--promise-comments' normalizes URLs/slashes itself.
  (reddigg--view-comments cmt))

(defun reddigg--view-comments (cmt &optional new-window)
  "Ask and print CMT to buffer. When NEW-WINDOW will show in new buffer."
  (promise-chain (reddigg--promise-comments cmt)
    (then #'reddigg--print-comments)
    (then (lambda (&rest _)
            (if new-window
                (switch-to-buffer (reddigg--get-cmt-buffer))
              (select-window
               (display-buffer
                (reddigg--get-cmt-buffer)
                '((display-buffer-reuse-window display-buffer-in-direction)
                  ;; (direction . right)
                  (reusable-frames . nil)
                  (inhibit-same-window . t)))))))
    (promise-catch (lambda (reason)
                     (message "reddigg: could not load comments: %s"
                              (reddigg--reason-string reason))))))


(cl-defun reddigg--view-sub (sub &key after before append sort scope)
  "Fetch SUB and print its post list.
AFTER: fetch post after name.
BEFORE: fetch posts before name.
APPEND: tell `reddigg--print-sub' to append.
SORT: top, hot, best, rising, controversial.
SCOPE: hour, day, week, year, all."
  (promise-chain (reddigg--promise-posts sub
                                         :after after
                                         :before before
                                         :sort sort
                                         :scope scope)
    (then (lambda (result)
            (ht-get result "data")))
    (then (lambda (data)
            (reddigg--print-sub data sub append
                                :sort sort
                                :scope scope)))
    (then (lambda (&rest _)
            (switch-to-buffer (reddigg--get-buffer))))
    (promise-catch (lambda (reason)
                     (message "reddigg: could not load %s: %s"
                              sub (reddigg--reason-string reason))))))

(defun reddigg--replace-more-line (things level)
  "Replace the \"load more\" line at point with THINGS printed at LEVEL.
Inserting right in front of the next heading makes org unfold that
heading (the next sibling comment), so skip Org's fold fix-ups and, as
a fallback for older Org versions, fold it again if it was folded."
  (let* ((next (save-excursion
                 (forward-line 1)
                 (and (not (eobp))
                      (org-at-heading-p)
                      (copy-marker (point) t))))
         (was-folded (and next
                          (save-excursion
                            (goto-char next)
                            (invisible-p (line-end-position))))))
    ;; Org >= 9.6 checks the folds next to an edit and queues an unfold
    ;; for any it considers broken, to be run after the *next* command
    ;; (that is why the neighbour used to open when you pressed a key).
    ;; We only insert whole new subtrees, so skip that check.
    (let ((org-fold-core--ignore-fragility-checks t))
      (kill-whole-line)
      (save-excursion
        (reddigg--print-comment-list things level)))
    (when next
      (when was-folded
        (save-excursion
          (goto-char next)
          (outline-hide-subtree)))
      (set-marker next nil))))

(defun reddigg--view-more-cmts (level children)
  "Get more comments from CHILDREN and print at LEVEL."
  (promise-chain (reddigg--promise-more-comments children)
    (then (lambda (result)
            (reddigg--nest-things
             (seq-map #'reddigg--normalize-thing
                      (ht-get* result "json" "data" "things")))))
    (then (lambda (result)
            (reddigg--replace-more-line result level)))
    (promise-catch (lambda (reason)
                     (message "reddigg: could not load more comments: %s"
                              (reddigg--reason-string reason))))))

;;;###autoload
(defun reddigg-view-sub (sub)
  "Prompt SUB and print its post list."
  (interactive (list (completing-read "Select sub reddit:" reddigg-subs)))
  (reddigg--view-sub sub))

;;;###autoload
(defun reddigg-view-frontpage ()
  "View frontpage."
  (interactive)
  (reddigg--view-sub (mapconcat #'symbol-name reddigg-subs "+")))

(defun reddigg--view-sub-more (sub after sort scope)
  "Fetch SUB from AFTER and append."
  (reddigg--view-sub sub :after after :append t :sort sort :scope scope))

;;;###autoload
(defun reddigg-view-main ()
  "View main page."
  (interactive)
  (switch-to-buffer (or (get-buffer reddigg--main-buffer)
                        (with-current-buffer (reddigg--get-main-buffer)
                          (erase-buffer)
                          (insert "#+startup: overview indent\n")
                          (insert "#+title: main\n\n")
                          (insert (format reddigg--template-sub "all" "all"))
                          (insert (format reddigg--template-sub "popular" "popular"))
                          (insert (format reddigg--template-sub (mapconcat #'symbol-name reddigg-subs "+") "main"))
                          (dolist (sub reddigg-subs)
                            (insert (format reddigg--template-sub sub sub)))
                          (reddigg--ensure-modes)
                          reddigg--main-buffer))))

;;; --- images ----------------------------------------------------------------
;;
;; Reddit serves a bot-check page (HTML/JS) to anything that is not a real
;; browser, so Emacs cannot fetch i.redd.it / preview.redd.it itself.  Images
;; are fetched by the logged-in reddit tab instead (the server's `image'
;; action) and come back base64-encoded.

(defconst reddigg--image-url-regexp
  "https://\\(?:i\\|preview\\)\\.redd\\.it/[^][ \t\n<>(),\"]+"
  "Regexp matching reddit-hosted image URLs.")

(defcustom reddigg-image-max-width 800
  "Maximum pixel width of images shown by reddigg."
  :type 'integer
  :group 'reddigg)

(defun reddigg--image-url-p (url)
  "Return non-nil when URL is a reddit-hosted image URL."
  (and (stringp url)
       (string-match-p (concat "\\`" reddigg--image-url-regexp) url)))

(defun reddigg--link-post-line (url)
  "Return the org text that links a link post's URL."
  (if (reddigg--image-url-p url)
      (format "%s \n[[elisp:(reddigg-view-image \"%s\")][view image]]\n" url url)
    (format "%s \n[[eww:%s][view in eww]]\n" url url)))

(defun reddigg--gallery-urls (post)
  "Return the direct image URLs of gallery POST, in gallery order."
  (let ((meta (ht-get post "media_metadata"))
        (gallery (ht-get post "gallery_data")))
    (when (and (hash-table-p meta) (hash-table-p gallery))
      (delq nil
            (mapcar
             (lambda (item)
               (let* ((id (ht-get item "media_id"))
                      (info (and id (ht-get meta id)))
                      (mime (and (hash-table-p info) (ht-get info "m"))))
                 (when (and (stringp mime) (string-match "/\\(.+\\)\\'" mime))
                   (format "https://i.redd.it/%s.%s" id (match-string 1 mime)))))
             (ht-get gallery "items"))))))

(defun reddigg--fetch-image (url)
  "Promise an image object for URL, fetched through the reddit tab."
  (promise-then
   (reddigg--http-request
    "GET"
    (format "%s/image?url=%s" reddigg-server-url (reddigg--url-encode url)))
   (lambda (result)
     (let ((data (base64-decode-string (ht-get result "data"))))
       (create-image data nil t :max-width reddigg-image-max-width)))))

(defun reddigg--image-url-at-point ()
  "Return the reddit image URL at point, or nil."
  (let ((url (thing-at-point 'url t)))
    (and (reddigg--image-url-p url) url)))

;;;###autoload
(defun reddigg-view-image (url)
  "View the reddit image at URL in a dedicated buffer."
  (interactive
   (list (or (reddigg--image-url-at-point)
             (read-string "Image URL: "))))
  (promise-chain (reddigg--fetch-image url)
    (then (lambda (image)
            (with-current-buffer (get-buffer-create "*reddigg-image*")
              (special-mode)
              (let ((inhibit-read-only t))
                (erase-buffer)
                (insert-image image)
                (insert "\n" url "\n"))
              (goto-char (point-min)))
            (pop-to-buffer "*reddigg-image*")))
    (promise-catch (lambda (reason)
                     (message "reddigg: could not load image: %s"
                              (reddigg--reason-string reason))))))

(defun reddigg--browse-image (url &rest _)
  "`browse-url-handlers' entry: open reddit image URL in reddigg."
  (reddigg-view-image url))

;; Enter / C-c C-o on an image link then opens it in reddigg (Emacs 28+).
(when (boundp 'browse-url-handlers)
  (add-to-list 'browse-url-handlers
               (cons (concat "\\`" reddigg--image-url-regexp)
                     #'reddigg--browse-image)))

(defun reddigg--show-image-overlay (marker image)
  "Show IMAGE in an overlay after MARKER, without touching the buffer text."
  (when (buffer-live-p (marker-buffer marker))
    (with-current-buffer (marker-buffer marker)
      (remove-overlays marker marker 'reddigg-image t)
      (let ((ov (make-overlay marker marker)))
        (overlay-put ov 'reddigg-image t)
        (overlay-put ov 'after-string
                     (concat "\n" (propertize " " 'display image) "\n"))))))

;;;###autoload
(defun reddigg-inline-images (&optional beg end)
  "Fetch and show every reddit image link between BEG and END inline.
Interactively, use the region if active, else the whole (visible) buffer.
Images are shown in overlays, so the post and comment text stays intact."
  (interactive (when (use-region-p) (list (region-beginning) (region-end))))
  (let ((beg (or beg (point-min)))
        (end (or end (point-max)))
        (found nil))
    (save-excursion
      (goto-char beg)
      (while (re-search-forward reddigg--image-url-regexp end t)
        (push (cons (copy-marker (match-end 0)) (match-string-no-properties 0))
              found)))
    (if (null found)
        (message "reddigg: no reddit image links found")
      (dolist (it (nreverse found))
        (let ((marker (car it)))
          (promise-chain (reddigg--fetch-image (cdr it))
            (then (lambda (image) (reddigg--show-image-overlay marker image)))
            (promise-catch (lambda (reason)
                             (message "reddigg: could not load %s: %s"
                                      (cdr it) (reddigg--reason-string reason))))))))))

(defun reddigg-clear-inline-images ()
  "Remove all inline images shown by `reddigg-inline-images'."
  (interactive)
  (remove-overlays nil nil 'reddigg-image t))

(provide 'reddigg)
;;; reddigg.el ends here
