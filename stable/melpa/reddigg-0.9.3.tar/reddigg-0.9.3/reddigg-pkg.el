;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reddigg" "0.9.3"
  "A reader for redditt."
  '((emacs   "26.3")
    (promise "1.1")
    (ht      "2.3")
    (org     "9.2")
    (json    "1.4"))
  :url "https://github.com/thanhvg/emacs-reddigg"
  :commit "54f8bc5bfef9145937c2c6ad1cd7fcc99dc37d6a"
  :revdesc "54f8bc5bfef9"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
