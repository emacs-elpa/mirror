;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lang-refactor-perl" "0.1.4"
  "Simple refactorings, primarily for Perl."
  ()
  :url "https://github.com/jplindstrom/emacs-lang-refactor-perl"
  :commit "6bf2a885c30ec0844abf3df0d23bd1bfba971922"
  :revdesc "6bf2a885c30e"
  :keywords '("languages" "refactoring" "perl")
  :authors '(("Johan Lindstrom" . "buzzwordninjanot_this_bit@googlemail.com"))
  :maintainers '(("Johan Lindstrom" . "buzzwordninjanot_this_bit@googlemail.com")))
