;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syntactic-sugar" "0.9.4"
  "Effect-free forms such as if/then/else."
  ()
  :url "https://github.com/rolandwalker/syntactic-sugar"
  :commit "06d943c6ad9507603bb6ab6d37be2d359d0763a9"
  :revdesc "v0.9.4-0-g06d943c6ad95"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
