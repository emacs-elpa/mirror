;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ereader" "0.0.0"
  "Major mode for reading ebooks."
  '((dash    "2.12.1")
    (s       "1.10.0")
    (xml+    "0.0.0")
    (picture "0"))
  :url "https://github.com/bddean/ereader-el"
  :commit "4d6dcae54fd20a6866ffd739d8f8957cc8267a2f"
  :revdesc "4d6dcae54fd2"
  :keywords '("epub" "ebook")
  :authors '(("Ben Dean" . "bendean837@gmail.com"))
  :maintainers '(("Ben Dean" . "bendean837@gmail.com")))
