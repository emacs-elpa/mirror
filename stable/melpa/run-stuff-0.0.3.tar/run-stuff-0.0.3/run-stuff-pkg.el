;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "run-stuff" "0.0.3"
  "Context based command execution."
  '((emacs "25.1"))
  :url "https://codeberg.org/ideasman42/emacs-run-stuff"
  :commit "984e5219adbee369487768a3ad6a408515e15446"
  :revdesc "984e5219adbe"
  :keywords '("files" "lisp" "files" "convenience" "hypermedia")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
