;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macos-notifications" "0.1"
  "Native macOS notifications with click callbacks."
  '((emacs "28.1"))
  :url "https://github.com/dakra/macos-notifications"
  :commit "c3425dcffc7a2d8546b97f0840494cd7a9ad7d5c"
  :revdesc "c3425dcffc7a"
  :keywords '("notifications" "tools")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
