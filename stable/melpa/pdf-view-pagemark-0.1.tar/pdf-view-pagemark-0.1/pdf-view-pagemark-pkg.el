;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdf-view-pagemark" "0.1"
  "Add indicator in pdfview mode to show the page remaining."
  '((pdf-tools "0.90")
    (emacs     "26.0"))
  :url "https://github.com/kimim/pdf-view-pagemark"
  :commit "7cf9a23ef6bea4bccc766dabcf9634211526a1ac"
  :revdesc "7cf9a23ef6be"
  :keywords '("pdf" "reading" "experience")
  :authors '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainers '(("Kimi Ma" . "kimi.im@outlook.com")))
