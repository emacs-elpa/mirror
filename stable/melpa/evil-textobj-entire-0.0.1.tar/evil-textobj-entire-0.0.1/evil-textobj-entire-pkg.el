;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-entire" "0.0.1"
  "Text object for entire lines of buffer for evil."
  '((emacs "24")
    (evil  "1.0.0"))
  :url "https://github.com/supermomonga/evil-textobj-entire"
  :commit "5b3a98f3a69edc3a788f539f6ffef4a0ef5e853d"
  :revdesc "5b3a98f3a69e"
  :keywords '("convenience" "emulations"))
