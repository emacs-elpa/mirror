;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-test" "0.1"
  "Python testing integration."
  '((emacs "24.3"))
  :url "https://github.com/emacs-pe/python-test"
  :commit "3912cfe9b40c87331b71f4a662cf16b19935605c"
  :revdesc "3912cfe9b40c"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
