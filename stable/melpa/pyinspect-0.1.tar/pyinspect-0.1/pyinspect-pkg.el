;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyinspect" "0.1"
  "Python object inspector."
  '((emacs "27.1"))
  :url "https://github.com/it-is-wednesday/pyinspect.el"
  :commit "a59fe3a386923248b8dfa527a20ce6c1ddde8f93"
  :revdesc "a59fe3a38692"
  :keywords '("tools")
  :authors '(("Maor Kadosh" . "git@avocadosh.xyz"))
  :maintainers '(("Maor Kadosh" . "git@avocadosh.xyz")))
