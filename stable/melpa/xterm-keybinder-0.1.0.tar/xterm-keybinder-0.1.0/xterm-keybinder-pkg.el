;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xterm-keybinder" "0.1.0"
  "Let your terminal emacs to control keybinds in xterm."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/yuutayamada/xterm-keybinder-el"
  :commit "952de4e1433206298d7a5eb903244e40c5d0c39f"
  :revdesc "952de4e14332"
  :keywords '("convenient")
  :authors '(("Yuta Yamada" . "sleepboy.zzz@gmail.com"))
  :maintainers '(("Yuta Yamada" . "sleepboy.zzz@gmail.com")))
