;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fwb-cmds" "2.0.5"
  "Misc frame, window and buffer commands."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/fwb-cmds"
  :commit "d230b9e42f992d9a4c4b155ba7f1920e8577caca"
  :revdesc "v2.0.5-0-gd230b9e42f99"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.fwb-cmds@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.fwb-cmds@jonas.bernoulli.dev")))
