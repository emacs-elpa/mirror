;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "media-thumbnail" "0.0.1"
  "Utility package to provide media icons."
  '((emacs "28.1"))
  :url "https://github.com/jojojames/media-thumbnail"
  :commit "1ef2a7046aea4d9a84e6f0698a3e16d925dd65d9"
  :revdesc "1ef2a7046aea"
  :keywords '("files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
