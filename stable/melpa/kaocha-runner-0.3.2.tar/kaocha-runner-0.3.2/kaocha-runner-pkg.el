;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaocha-runner" "0.3.2"
  "A package for running Kaocha tests via CIDER."
  '((emacs    "26")
    (s        "1.4.0")
    (cider    "0.21.0")
    (parseedn "0.1.0"))
  :url "https://github.com/magnars/kaocha-runner.el"
  :commit "e5071ce09ec2d8c700bac91c902318035c5489bf"
  :revdesc "e5071ce09ec2"
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
