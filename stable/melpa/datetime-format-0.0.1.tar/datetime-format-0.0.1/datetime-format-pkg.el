;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "datetime-format" "0.0.1"
  "Datetime functions."
  ()
  :url "https://github.com/zonuexe/emacs-datetime"
  :commit "4c3bf8235bf7ac31f0e25c84957855b96336bdfc"
  :revdesc "4c3bf8235bf7"
  :keywords '("datetime" "calendar")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
