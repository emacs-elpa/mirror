;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "0.1"
  "Join columns from another table."
  ()
  :url "https://github.com/tbanel/orgtbljoin"
  :commit "7a319992c62611eb904389c2cf401d77a56b9b3e"
  :revdesc "7a319992c626"
  :keywords '("org" "table" "join" "filtering"))
