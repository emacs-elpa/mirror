;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ordinal" "1.0.0"
  "Convert number to ordinal number notation."
  '((emacs "24.3"))
  :url "https://github.com/zonuexe/ordinal.el"
  :commit "a7f378306290b6807fb6b87cee3ef79b31cec711"
  :revdesc "a7f378306290"
  :keywords '("lisp")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
