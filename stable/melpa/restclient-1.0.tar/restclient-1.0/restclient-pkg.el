;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restclient" "1.0"
  "An interactive HTTP client for Emacs."
  '((emacs "26.1"))
  :url "https://github.com/emacsorphanage/restclient"
  :commit "f1caca40102cf5e52ac1fdfeed67ee674645880a"
  :revdesc "f1caca40102c"
  :keywords '("http" "comm" "tools")
  :authors '(("Pavel Kurnosov" . "pashky@gmail.com"))
  :maintainers '(("Peder O. Klingenberg" . "peder@klingenberg.no")))
