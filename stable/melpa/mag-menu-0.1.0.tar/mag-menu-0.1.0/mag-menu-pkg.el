;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mag-menu" "0.1.0"
  "Intuitive keyboard-centric menu system."
  ()
  :url "https://github.com/chumpage/mag-menu"
  :commit "37138f3adaf6f90847d8f415ef7a7f38758bb218"
  :revdesc "37138f3adaf6"
  :keywords '("menu" "dialog"))
