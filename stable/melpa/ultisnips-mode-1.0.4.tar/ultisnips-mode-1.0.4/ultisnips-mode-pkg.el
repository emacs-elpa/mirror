;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "1.0.4"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "39df8b78d4a9450cec5acbd74eb82b7372e28b73"
  :revdesc "1.0.4-0-g39df8b78d4a9"
  :keywords '("languages")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
