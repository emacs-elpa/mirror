;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kolon-mode" "0.1"
  "Syntax highlighting for Text::Xslate's Kolon syntax."
  ()
  :url "https://github.com/samvtran/kolon-mode"
  :commit "b98af7de4ee5f2178b33ffa401840740b01f83d3"
  :revdesc "b98af7de4ee5"
  :keywords '("xslate" "perl"))
