;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "password-store" "1.7.4"
  "Password store (pass) support."
  '((emacs            "25")
    (s                "1.9.0")
    (with-editor      "2.5.11")
    (auth-source-pass "5.0.0"))
  :url "https://www.passwordstore.org/"
  :commit "1078f2514d579178d5df7042c6a790e9c9b731ad"
  :revdesc "1.7.4-0-g1078f2514d57"
  :keywords '("tools" "pass" "password" "password-store")
  :authors '(("Svend Sorensen" . "svend@svends.net"))
  :maintainers '(("Tino Calancha" . "tino.calancha@gmail.com")))
