;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaleidoscope-evil-state-flash" "0.1.0"
  "Flash keyboard LEDs when changing Evil state."
  '((evil         "1.2.12")
    (kaleidoscope "0.1.0"))
  :url "https://github.com/algernon/kaleidoscope.el"
  :commit "f13a4dc9341849c61c4a4beaff9493878c9fde70"
  :revdesc "f13a4dc93418")
