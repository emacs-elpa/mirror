;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elmine" "0.3"
  "[No description available]."
  ()
  :url "https://github.com/leoc/elmine"
  :commit "091f61c70c9e7630a74b7b127488051d143a35e7"
  :revdesc "091f61c70c9e"
  :keywords '("tools")
  :authors '(("Arthur Andersen" . "leocDOTgitATgmail.com"))
  :maintainers '(("Arthur Andersen" . "leocDOTgitATgmail.com")))
