;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-react-redux-yasnippets" "0.0.2"
  "JavaScript,React,Redux yasnippets."
  '((emacs     "24.3")
    (yasnippet "0.8.0"))
  :url "https://github.com/sooqua/js-react-redux-yasnippets"
  :commit "c3818c554389ab7e994d135483293721da14bc2d"
  :revdesc "c3818c554389"
  :keywords '("convenience" "snippets"))
