;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-command-redo" "0.1"
  "Repeat commands with automatic undo."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-with-command-redo"
  :commit "f364332837ae7c7a8d0ab78460e499bfc2b74155"
  :revdesc "f364332837ae"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
