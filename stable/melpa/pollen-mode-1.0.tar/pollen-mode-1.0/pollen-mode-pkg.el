;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pollen-mode" "1.0"
  "Major mode for editing pollen files."
  '((emacs "24.1"))
  :url "https://github.com/lijunsong/pollen-mode"
  :commit "0383ccba353af5e5536afcaedefc0e20191686ae"
  :revdesc "0383ccba353a"
  :keywords '("languages" "pollen" "pollenpub")
  :authors '(("Junsong Li" . "ljs.darkfishATGMAIL")))
