;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "url-shortener" "0.3"
  "Shorten long url and expand tinyurl."
  ()
  :url "https://github.com/yuyang0/url-shortener"
  :commit "d58fd512ae136fbb7651f4177f85e77b46cb879e"
  :revdesc "d58fd512ae13"
  :authors '(("Yu Yang" . "yy2012cn@NOSPAM.gmail.com"))
  :maintainers '(("Yu Yang" . "yy2012cn@NOSPAM.gmail.com")))
