;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "angular-snippets" "0.2.3"
  "Yasnippets for AngularJS."
  '((s    "1.4.0")
    (dash "1.2.0"))
  :url "https://github.com/magnars/angular-snippets.el"
  :commit "8f737c2cf5fce758a7a3833ebad2952b5398568d"
  :revdesc "0.2.3-0-g8f737c2cf5fc"
  :keywords '("snippets")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
