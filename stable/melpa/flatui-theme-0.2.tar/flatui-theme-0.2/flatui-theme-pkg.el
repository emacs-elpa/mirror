;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatui-theme" "0.2"
  "A color theme for Emacs based on flatuicolors.com."
  ()
  :url "https://github.com/john2x/flatui-theme.el"
  :commit "edfe72c35bf6c0cca5263e93aa0406c2c5c4b6c7"
  :revdesc "edfe72c35bf6"
  :authors '(("John Louis Del Rosario" . "john2x@gmail.com"))
  :maintainers '(("John Louis Del Rosario" . "john2x@gmail.com")))
