;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejson-mode" "0.5.2"
  "Major Mode for editing ejson files."
  '((emacs "25"))
  :url "https://github.com/dantecatalfamo/ejson-mode"
  :commit "33d121dfc31b3eefe91f0a8ee761ebb1161711be"
  :revdesc "33d121dfc31b"
  :keywords '("convenience" "languages" "tools"))
