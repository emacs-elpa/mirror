;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.5.0"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "962de6bc5741f4a802dac527cc1b1a5afb5e4923"
  :revdesc "962de6bc5741"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
