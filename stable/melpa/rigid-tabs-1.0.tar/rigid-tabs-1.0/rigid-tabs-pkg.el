;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rigid-tabs" "1.0"
  "Rigidify and adjust the visual alignment of TABs."
  '((emacs "24.3"))
  :url "https://github.com/wavexx/rigid-tabs.el"
  :commit "c7c6b726806df7e8cb25a41b213a207850c91cb7"
  :revdesc "v1.0-0-gc7c6b726806d"
  :keywords '("diff" "whitespace" "version control" "magit")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
