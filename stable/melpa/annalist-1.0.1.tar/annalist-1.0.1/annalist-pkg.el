;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annalist" "1.0.1"
  "Record and display information such as keybindings."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/noctuid/annalist.el"
  :commit "08df07e4530953a2c0b1aa553adcab37b7b614b0"
  :revdesc "1.0.1-0-g08df07e45309"
  :keywords '("convenience" "tools" "keybindings" "org")
  :authors '(("Fox Kiester" . "noct@posteo.net"))
  :maintainers '(("Fox Kiester" . "noct@posteo.net")))
