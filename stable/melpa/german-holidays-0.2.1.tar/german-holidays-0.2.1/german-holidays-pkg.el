;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "german-holidays" "0.2.1"
  "German holidays for Emacs calendar."
  ()
  :url "https://github.com/rudolfochrist/german-holidays"
  :commit "d7d540c229c1a8be68ee09fbda08fe3ea31b7d29"
  :revdesc "german-holidays-0.2.1-0-gd7d540c229c1"
  :authors '(("Sebastian Christ" . "rudolfo.christ@gmail.com"))
  :maintainers '(("Sebastian Christ" . "rudolfo.christ@gmail.com")))
