;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-rails" "1.0.0"
  "Rails support for project.el."
  '((emacs       "28.1")
    (inflections "2.6"))
  :url "https://github.com/harrybournis/project-rails"
  :commit "b24648653379c98cd7a3787271df358b194bc1aa"
  :revdesc "b24648653379"
  :keywords '("languages" "project.el" "rails")
  :authors '(("Harry Bournis" . "harrybournis@gmail.com"))
  :maintainers '(("Harry Bournis" . "harrybournis@gmail.com")))
