;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-nim" "0.0.1"
  "Babel Functions for C and Similar Languages."
  '((cl-lib "0.5"))
  :url "https://github.com/Lompik/ob-nim"
  :commit "8a787b3213571d9808f8e915d528451b472fc2c4"
  :revdesc "8a787b321357"
  :keywords '("literate programming" "reproducible research"))
