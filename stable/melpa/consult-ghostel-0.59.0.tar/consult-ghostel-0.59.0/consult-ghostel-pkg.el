;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghostel" "0.59.0"
  "Consult integration for ghostel."
  '((emacs   "28.1")
    (consult "1.5")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "b77eae6f58ed1fc9b36694807e84a4bb6dfbf9fd"
  :revdesc "b77eae6f58ed"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
