;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-biome" "0.1.0"
  "A flymake plugin for SQL files using biome."
  '((emacs "27.1"))
  :url "https://github.com/erickgnavar/flymake-biome"
  :commit "e196d360c287984943db40973721c227403d0ec6"
  :revdesc "e196d360c287"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
