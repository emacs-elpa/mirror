;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rainbow-fart" "0.1"
  "Encourage when you programming."
  '((emacs "25.1"))
  :url "https://github.com/stardiviner/emacs-rainbow-fart"
  :commit "c82d816f6182a8d54ecbc569b2e9fefcbeb25a68"
  :revdesc "c82d816f6182"
  :keywords '("tools")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
