;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jaword" "1.0.1"
  "Minor-mode for handling Japanese words better."
  '((tinysegmenter "0.1")
    (emacs         "24.4"))
  :url "http://hins11.yu-yake.com/"
  :commit "78be38c30b8aa113c689b2ef59db083268375733"
  :revdesc "78be38c30b8a")
