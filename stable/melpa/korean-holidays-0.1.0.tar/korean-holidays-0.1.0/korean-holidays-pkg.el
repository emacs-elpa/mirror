;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "korean-holidays" "0.1.0"
  "[No description available]."
  ()
  :url "https://github.com/tttuuu888/korean-holidays"
  :commit "5dee193a0d1ae0b161af72f60e8a149a6e36bf3c"
  :revdesc "5dee193a0d1a"
  :keywords '("calendar")
  :authors '(("SeungKi Kim" . "tttuuu888@gmail.com"))
  :maintainers '(("SeungKi Kim" . "tttuuu888@gmail.com")))
