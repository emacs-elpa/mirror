;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "2.4.0"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "f9845422db502eb765231f5fbc735dd0eb9c8a19"
  :revdesc "2.4.0-0-gf9845422db50"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
