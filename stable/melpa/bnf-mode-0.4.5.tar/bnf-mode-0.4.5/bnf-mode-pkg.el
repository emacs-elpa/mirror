;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bnf-mode" "0.4.5"
  "Major mode for editing BNF grammars."
  '((cl-lib "0.5")
    (emacs  "24.3"))
  :url "https://github.com/sergeyklay/bnf-mode"
  :commit "a4fe013fc945d8396930bc6d0dcc1cf9d7102f41"
  :revdesc "0.4.5-0-ga4fe013fc945"
  :keywords '("languages")
  :authors '(("Serghei Iakovlev" . "egrep@protonmail.ch"))
  :maintainers '(("Serghei Iakovlev" . "egrep@protonmail.ch")))
