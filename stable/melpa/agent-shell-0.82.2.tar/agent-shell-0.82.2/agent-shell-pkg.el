;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.82.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.4")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a43b18b201f89952fe0c21ca8b08cf23c3ec86bb"
  :revdesc "a43b18b201f8")
