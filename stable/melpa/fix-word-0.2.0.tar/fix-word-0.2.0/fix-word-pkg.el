;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fix-word" "0.2.0"
  "Convenient word transformation."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/mrkkrp/fix-word"
  :commit "b3b3a3c8e33e425f9a8d0ec653adb6897c8efc03"
  :revdesc "b3b3a3c8e33e"
  :keywords '("word" "convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
