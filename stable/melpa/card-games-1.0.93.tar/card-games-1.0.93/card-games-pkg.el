;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "card-games" "1.0.93"
  "Play card games (console + SVG)."
  '((emacs "26.1"))
  :url "https://code.bru.st/corwin/card-game.el"
  :commit "fa95fc99f23149e1f99b8273fb5b95180ef490c6"
  :revdesc "1.0.93-0-gfa95fc99f231"
  :keywords '("games")
  :authors '(("Corwin Brust" . "corwin@bru.st"))
  :maintainers '(("Corwin Brust" . "corwin@bru.st")))
