;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async-status" "0.1.0"
  "A package for indicator support."
  '((emacs    "28.1")
    (posframe "20230714.227")
    (svg-lib  "0.2.7"))
  :url "https://github.com/seokbeomkim/async-status"
  :commit "2b6975b141545a765070799a48d53644761f0ef4"
  :revdesc "2b6975b14154"
  :keywords '("tools" "kconfig" "linux" "kernel")
  :authors '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainers '(("Jason Kim" . "sukbeom.kim@gmail.com")))
