;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sysml-mode" "1.1.0"
  "Major mode for SysML v2 (Systems Modeling Language)."
  '((emacs "24.3"))
  :url "https://github.com/decisym/sysml-mode"
  :commit "428ab554cde5d699df62979f95d59144df8365c9"
  :revdesc "428ab554cde5"
  :keywords '("languages" "modeling" "systems engineering"))
