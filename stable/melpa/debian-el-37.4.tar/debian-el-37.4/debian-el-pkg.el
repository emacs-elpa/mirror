;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "debian-el" "37.4"
  "Startup file for the debian-el package."
  ()
  :commit "9690c4adb71e0fc7d00fea24b49ba944f913f4f5"
  :revdesc "37.4-0-g9690c4adb71e")
