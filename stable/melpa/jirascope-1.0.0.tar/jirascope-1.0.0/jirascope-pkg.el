;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jirascope" "1.0.0"
  "A Jira client."
  '((emacs "25.1"))
  :url "https://github.com/Duckonaut/jirascope"
  :commit "61acd8d6adbd6b25ebcc5436b4dce6d5c6d2981c"
  :revdesc "61acd8d6adbd"
  :keywords '("tools")
  :authors '(("Stanisław Zagórowski" . "duckonaut@gmail.com"))
  :maintainers '(("Stanisław Zagórowski" . "duckonaut@gmail.com")))
