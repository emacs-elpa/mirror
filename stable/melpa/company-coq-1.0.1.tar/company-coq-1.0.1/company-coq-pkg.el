;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-coq" "1.0.1"
  "A collection of extensions for Proof General's Coq mode."
  '((company-math "1.1")
    (company      "0.8.12")
    (yasnippet    "0.11.0")
    (dash         "2.12.1")
    (cl-lib       "0.5"))
  :url "https://github.com/cpitclaudel/company-coq"
  :commit "a4e0625725e4f54d202e746bb41b8bc14c14ddef"
  :revdesc "1.0.1-0-ga4e0625725e4"
  :keywords '("convenience" "languages")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
