;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "react-snippets" "0.1"
  "Yasnippets for React."
  '((yasnippet "0.7.0"))
  :url "https://github.com/johnmastro/react-snippets.el"
  :commit "bfc4b68b81374a6a080240592641091a7e8a6d61"
  :revdesc "bfc4b68b8137"
  :keywords '("snippets")
  :authors '(("John Mastro" . "john.b.mastro@gmail.com"))
  :maintainers '(("John Mastro" . "john.b.mastro@gmail.com")))
