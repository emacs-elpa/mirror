;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "0.0.35"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "16c7092e7483cf7b29511374bbc8c80a1359b6b9"
  :revdesc "16c7092e7483"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
