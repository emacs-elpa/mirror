;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-signature-eldoc-talkative" "0.0.7"
  "Make Eglot make ElDoc echo docs."
  '((emacs   "29.1")
    (eglot   "1.16")
    (eldoc   "1.14.0")
    (jsonrpc "1.0.23"))
  :url "https://codeberg.org/mekeor/emacs-eglot-signature-eldoc-talkative"
  :commit "859aa6f2c0acf060a8e7549b79daf46c8d63ea8d"
  :revdesc "859aa6f2c0ac"
  :keywords '("convenience" "documentation" "eglot" "eldoc" "languages" "lsp")
  :authors '(("João Távora" . "joaotavora@gmail.com")
             ("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
