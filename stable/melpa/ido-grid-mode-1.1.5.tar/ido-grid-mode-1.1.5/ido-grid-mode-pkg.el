;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-grid-mode" "1.1.5"
  "Display ido-prospects in the minibuffer in a grid."
  '((emacs "24.4"))
  :url "https://github.com/larkery/ido-grid-mode.el"
  :commit "8bbd66e365d4f6f352bbb17673be5869ab26d7ab"
  :revdesc "8bbd66e365d4"
  :keywords '("convenience")
  :maintainers '(("Tom Hinton" . "t@larkery.com")))
