;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cue-sheet-mode" "1.1.0"
  "Major mode for editing CUE sheet files."
  '((emacs "27.1"))
  :url "https://github.com/peterhoeg/cue-sheet-mode"
  :commit "24f6a39d2f2fdeb3a02845784a6f44d471ff4c60"
  :revdesc "24f6a39d2f2f"
  :keywords '("languages")
  :authors '(("Peter Hoeg" . "(peter@hoeg.com)"))
  :maintainers '(("Peter Hoeg" . "(peter@hoeg.com)")))
