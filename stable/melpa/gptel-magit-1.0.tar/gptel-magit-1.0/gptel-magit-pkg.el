;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-magit" "1.0"
  "Generate commit messages for magit using gptel."
  '((emacs "28.1")
    (magit "1.0")
    (gptel "1.0"))
  :url "https://github.com/ragnard/gptel-magit"
  :commit "f0e298d834c0945e5275f14f9a1d7eec75f1efa0"
  :revdesc "f0e298d834c0"
  :keywords '("vc" "convenience")
  :authors '(("Ragnar Dahlén" . "r.dahlen@gmail.com"))
  :maintainers '(("Ragnar Dahlén" . "r.dahlen@gmail.com")))
