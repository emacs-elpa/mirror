;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "1.7.7"
  "A set of eye pleasing themes."
  '((emacs      "26.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "8dc98bd1a63aa35e44ff8b3fd1be6d6afd4e2301"
  :revdesc "8dc98bd1a63a"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
