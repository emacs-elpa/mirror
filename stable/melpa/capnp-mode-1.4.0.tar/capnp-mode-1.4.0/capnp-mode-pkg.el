;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "capnp-mode" "1.4.0"
  "Major mode for editing Capn' Proto Files."
  ()
  :url "https://github.com/capnproto/capnproto"
  :commit "8b892a8a11a632f5d52b877a49728808a142379a"
  :revdesc "8b892a8a11a6"
  :authors '(("Brian Taylor" . "el.wubo@gmail.com"))
  :maintainers '(("Brian Taylor" . "el.wubo@gmail.com")))
