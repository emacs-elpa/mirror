;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wallpaper" "1.1.3"
  "Setting the wallpaper."
  '((emacs "25.1"))
  :url "https://github.com/farlado/emacs-wallpaper"
  :commit "c7e99d86541ca6c8272a7deaeee5d4c4ca4899f7"
  :revdesc "c7e99d86541c"
  :keywords '("unix" "wallpaper" "extensions")
  :authors '(("Farlado" . "farlado@sdf.org"))
  :maintainers '(("Farlado" . "farlado@sdf.org")))
