;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-bookmarks" "0.2"
  "Add bookmark handling for notmuch buffers."
  '((seq     "2.20")
    (emacs   "26.1")
    (notmuch "0.29.3"))
  :url "https://github.com/publicimageltd/notmuch-bookmarks"
  :commit "7c053fd2d278dc3a9f07f86975867bfbb4e7448d"
  :revdesc "7c053fd2d278"
  :keywords '("mail")
  :authors '(("Jörg Volbers" . "joerg@joergvolbers.de"))
  :maintainers '(("Jörg Volbers" . "joerg@joergvolbers.de")))
