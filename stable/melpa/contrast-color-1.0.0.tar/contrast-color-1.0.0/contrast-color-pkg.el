;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "contrast-color" "1.0.0"
  "Pick best contrast color for you."
  '((cl-lib "0.5"))
  :url "https://github.com/yuutayamada/contrast-color-el"
  :commit "7a610be99a17204d69173552fdeab62cad820d66"
  :revdesc "7a610be99a17"
  :keywords '("color" "convenience")
  :authors '(("Yuta Yamada" . "cokesboy[at]gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy[at]gmail.com")))
