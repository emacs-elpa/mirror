;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-indentation" "0.1"
  "Simplify writing indentation functions, alternative to SMIE."
  '((emacs "24.3")
    (dash  "2.18.0")
    (s     "1.12.0"))
  :url "https://github.com/semenInRussia/simple-indentation.el"
  :commit "dac21c6d25b2c0d653d4e9d0b3396e7c9df9042f"
  :revdesc "dac21c6d25b2"
  :authors '(("Semen Khramtsov" . "hrams205@gmail.com"))
  :maintainers '(("Semen Khramtsov" . "hrams205@gmail.com")))
