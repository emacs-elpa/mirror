;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "@" "1.5"
  "Multiple-inheritance prototype-based objects DSL."
  '((emacs "24.3"))
  :url "https://github.com/skeeto/at-el"
  :commit "3671318a811fb51c03a792342af7b42004922809"
  :revdesc "3671318a811f"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
