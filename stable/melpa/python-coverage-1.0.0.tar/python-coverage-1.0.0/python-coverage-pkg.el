;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-coverage" "1.0.0"
  "Python coverage support."
  '((emacs           "25.1")
    (dash            "2.16.0")
    (dash-functional "1.2.0")
    (s               "1.12.0")
    (xml+            "1"))
  :url "https://github.com/wbolster/emacs-python-coverage"
  :commit "bdcd4849a025a2f657d5b3040d44bf3d34e7371f"
  :revdesc "bdcd4849a025"
  :keywords '("languages" "processes" "tools")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
