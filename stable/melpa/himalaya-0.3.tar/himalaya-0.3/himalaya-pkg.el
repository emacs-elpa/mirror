;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "himalaya" "0.3"
  "Interface for the himalaya email client."
  '((emacs "27.1"))
  :url "https://github.com/dantecatalfamo/himalaya-emacs"
  :commit "3e4e9dc3697434efd3f25ea8e800bf81d75de9d8"
  :revdesc "v0.3-0-g3e4e9dc36974"
  :keywords '("mail" "comm")
  :authors '(("soywod" . "clement.douin@posteo.net"))
  :maintainers '(("soywod" . "clement.douin@posteo.net")))
