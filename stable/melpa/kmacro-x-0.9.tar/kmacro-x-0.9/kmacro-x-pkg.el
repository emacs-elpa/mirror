;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kmacro-x" "0.9"
  "Keyboard macro helpers and extensions."
  '((emacs "27.2"))
  :url "https://github.com/vifon/kmacro-x.el"
  :commit "82b2b379a0f90b430893a363f02a1a5ab535c3e9"
  :revdesc "82b2b379a0f9"
  :keywords '("convenience"))
