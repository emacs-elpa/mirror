;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-terraform" "1.3"
  "A company backend for terraform."
  '((emacs          "24.4")
    (company        "0.8.12")
    (terraform-mode "0.06"))
  :url "https://github.com/rafalcieslak/emacs-company-terraform"
  :commit "2d11a21fee2f298e48968e479ddcaeda4d736e12"
  :revdesc "2d11a21fee2f"
  :keywords '("abbrev" "convenience" "terraform" "company")
  :authors '(("Rafał Cieślak" . "rafalcieslak256@gmail.com"))
  :maintainers '(("Rafał Cieślak" . "rafalcieslak256@gmail.com")))
