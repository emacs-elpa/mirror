;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-here" "1.3"
  "Open a shell relative to the working directory."
  ()
  :url "https://codeberg.org/emacs-weirdware/shell-here"
  :commit "251309141e18978d2b8014345acc6f5afcd4d509"
  :revdesc "251309141e18"
  :keywords '("unix" "tools" "processes")
  :authors '(("Ian Eure" . "ian.eure@gmail.com"))
  :maintainers '(("Ian Eure" . "ian.eure@gmail.com")))
