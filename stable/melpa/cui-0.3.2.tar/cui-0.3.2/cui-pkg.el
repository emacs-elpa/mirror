;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "0.3.2"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "d4ea6f0667f12a7b6022107e84de76fd5739a041"
  :revdesc "d4ea6f0667f1"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
