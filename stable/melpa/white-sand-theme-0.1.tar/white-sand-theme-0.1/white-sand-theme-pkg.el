;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "white-sand-theme" "0.1"
  "Emacs 24 theme with a light background."
  '((emacs "24"))
  :url "https://github.com/mswift42/white-sand-theme"
  :commit "2b6df49a34b32792c40162f339c8907026141269"
  :revdesc "2b6df49a34b3")
