;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.5.0"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "8bec65211f5b204da158b8ec25bf8dc8fbbe8dce"
  :revdesc "v4.5.0-0-g8bec65211f5b"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
