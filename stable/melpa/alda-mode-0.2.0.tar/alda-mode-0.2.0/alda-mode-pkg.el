;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alda-mode" "0.2.0"
  "A simple major mode for the musical programming language Alda."
  '((emacs "24.0"))
  :url "https://github.com/jgkamat/alda-mode"
  :commit "97c20b1fd9ad3f138e1100e3a837d05108c4c564"
  :revdesc "0.2.0-0-g97c20b1fd9ad"
  :keywords '("alda" "highlight")
  :authors '(("Jay Kamat" . "github@jgkamat.33mail.com"))
  :maintainers '(("Jay Kamat" . "github@jgkamat.33mail.com")))
