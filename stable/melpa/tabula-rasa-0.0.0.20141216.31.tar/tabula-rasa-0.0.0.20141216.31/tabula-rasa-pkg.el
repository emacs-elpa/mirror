;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabula-rasa" "0.0.0.20141216.31"
  "Distraction free writing mode."
  '((emacs "24.4"))
  :url "https://github.com/idomagal/Tabula-Rasa/blob/master/tabula-rasa.el"
  :commit "e85fff9de18dc31bc6a7aca726e34a95cc5459f5"
  :revdesc "e85fff9de18d"
  :keywords '("distraction free" "writing")
  :authors '(("Ido Magal" . "misc@satans.church"))
  :maintainers '(("Ido Magal" . "misc@satans.church")))
