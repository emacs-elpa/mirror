;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-browse" "0.8.8"
  "Web browsing helpers for OS X."
  '((string-utils    "0.3.2")
    (browse-url-dwim "0.6.6"))
  :url "https://github.com/rolandwalker/osx-browse"
  :commit "6186a6020e143e90d557c8d062c44fcdba0516c7"
  :revdesc "v0.8.8-0-g6186a6020e14"
  :keywords '("hypermedia" "external")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
