;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-overleaf" "2.0.0"
  "Clone, push, and pull full Overleaf projects with Git."
  '((emacs     "29.4")
    (websocket "1.15")
    (webdriver "0.1"))
  :url "https://github.com/Jamie-Cui/git-overleaf"
  :commit "a19cc16fdebe6b6a467490592041eea7119feb37"
  :revdesc "a19cc16fdebe"
  :keywords '("hypermedia" "tex" "tools")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
