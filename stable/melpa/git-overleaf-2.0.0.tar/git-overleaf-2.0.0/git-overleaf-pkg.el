;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-overleaf" "2.0.0"
  "Clone, push, and pull full Overleaf projects with Git."
  '((emacs     "29.4")
    (websocket "1.15")
    (webdriver "0.1"))
  :url "https://github.com/Jamie-Cui/git-overleaf"
  :commit "244b954b100c1a376ad6458bb978ba2ca3be1799"
  :revdesc "244b954b100c"
  :keywords '("hypermedia" "tex" "tools")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
