;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "digit-groups" "0.2"
  "Highlight place-value positions in numbers."
  '((dash "2.11.0"))
  :url "http://bitbucket.com/adamsmd/digit-groups"
  :commit "032000afe1c4f5156ad57aed83cfc9462ffde00f"
  :revdesc "032000afe1c4"
  :authors '(("Michael D. Adams" . "http://michaeldadams.org"))
  :maintainers '(("Michael D. Adams" . "http://michaeldadams.org")))
