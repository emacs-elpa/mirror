;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fantom-mode" "0.0.1"
  "A major mode for the Fantom programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/fantom-mode"
  :commit "3e5c3f10cf9fc00293fb895f93c633cc0ffe1958"
  :revdesc "3e5c3f10cf9f"
  :keywords '("files" "fantom"))
