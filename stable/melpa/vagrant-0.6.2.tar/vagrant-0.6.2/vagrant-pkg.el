;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vagrant" "0.6.2"
  "Manage a vagrant box from emacs."
  ()
  :url "https://github.com/ottbot/vagrant.el"
  :commit "636ce2f9af32ea199170335a9cf1201b64873440"
  :revdesc "636ce2f9af32"
  :keywords '("vagrant" "chef")
  :authors '(("Robert Crim" . "rob@servermilk.com"))
  :maintainers '(("Robert Crim" . "rob@servermilk.com")))
