;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spacebar" "0.0.2"
  "Workspaces Bar."
  '((eyebrowse "0.7.7")
    (emacs     "25.4.0"))
  :url "https://github.com/matthias-margush/spacebar"
  :commit "a513abba83fe4fc2e9e8b9f011a24b99c57ffd0d"
  :revdesc "a513abba83fe"
  :keywords '("convenience")
  :authors '(("Matthias Margush" . "matthias.margush@gmail.com"))
  :maintainers '(("Matthias Margush" . "matthias.margush@gmail.com")))
