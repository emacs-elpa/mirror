;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markless" "1.0"
  "Major mode for Markless documents."
  '((emacs "24.3"))
  :url "https://github.com/shirakumo/markless.el/"
  :commit "8218eb28406f231d051f23a001b13d0bb425cd82"
  :revdesc "8218eb28406f"
  :keywords '("markless" "markup" "major-mode" "language")
  :authors '(("Nicolas Hafner" . "shinmera@tymoon.eu"))
  :maintainers '(("Nicolas Hafner" . "shinmera@tymoon.eu")))
