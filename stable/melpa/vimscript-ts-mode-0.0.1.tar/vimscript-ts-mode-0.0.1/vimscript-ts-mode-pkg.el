;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vimscript-ts-mode" "0.0.1"
  "Vim-script major mode using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/vimscript-ts-mode"
  :commit "ba1dca9b1b568a00ec2debdc4a2c0224c2246bcb"
  :revdesc "ba1dca9b1b56"
  :keywords '("languages" "vim" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
