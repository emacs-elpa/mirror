;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "b905786ae1da9da4c015d69b9417a55985f07668"
  :revdesc "b905786ae1da")
