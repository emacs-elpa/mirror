;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hass" "3.0.2"
  "Interact with Home Assistant."
  '((emacs     "25.1")
    (request   "0.3.3")
    (websocket "1.13"))
  :url "https://github.com/purplg/hass"
  :commit "033d11b07e0f8bb68b348a12d5ae13fabea56c73"
  :revdesc "033d11b07e0f")
