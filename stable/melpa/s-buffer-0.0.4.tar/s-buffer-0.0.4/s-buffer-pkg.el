;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "s-buffer" "0.0.4"
  "S operations for buffers."
  '((s      "1.6.0")
    (noflet "0.0.3"))
  :url "https://github.com/nicferrier/emacs-s-buffer"
  :commit "f95d234282377f00a2c3a9846681080cb95bb1df"
  :revdesc "f95d23428237"
  :keywords '("lisp")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
