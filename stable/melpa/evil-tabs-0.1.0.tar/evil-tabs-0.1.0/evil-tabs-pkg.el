;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-tabs" "0.1.0"
  "Integrating Vim-style tabs for Evil mode users."
  '((evil     "0.0.0")
    (elscreen "0.0.0"))
  :url "https://github.com/krisajenkins/evil-tabs"
  :commit "c8fc33bdf48144ec03a3d9eb0bf3280045620cd3"
  :revdesc "c8fc33bdf481"
  :keywords '("evil" "tab" "tabs" "vim")
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
