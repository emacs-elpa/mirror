;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-sagemath" "0.4"
  "Org-babel functions for SageMath evaluation."
  '((sage-shell-mode "0.0.8")
    (s               "1.8.0")
    (emacs           "24"))
  :url "https://github.com/stakemori/ob-sagemath"
  :commit "450d510a5eb1fd644d0037e9f02271ca33639fb0"
  :revdesc "450d510a5eb1"
  :keywords '("sagemath" "org-babel")
  :authors '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainers '(("Sho Takemori" . "stakemorii@gmail.com")))
