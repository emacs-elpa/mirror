;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pretend-type" "0.1.0"
  "Reveal buffer as you pretend to type."
  '((emacs "24.3"))
  :url "https://github.com/haji-ali/pretend-type"
  :commit "dfa42daf4538f7ab6351df8cd601a03e60da45a6"
  :revdesc "dfa42daf4538"
  :keywords '("hide" "show" "invisible" "learning" "games")
  :authors '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com")))
