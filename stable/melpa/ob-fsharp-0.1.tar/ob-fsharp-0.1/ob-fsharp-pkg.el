;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-fsharp" "0.1"
  "Org-Babel F#."
  '((emacs       "25")
    (fsharp-mode "1.9.7"))
  :url "https://github.com/juergenhoetzel/ob-fsharp"
  :commit "9da73c44c02bcfe0dbbbcf003402395d85b24f0e"
  :revdesc "9da73c44c02b"
  :keywords '("literate programming" "reproducible research")
  :authors '(("Jürgen Hötzel" . "juergen@archlinux.org"))
  :maintainers '(("Jürgen Hötzel" . "juergen@archlinux.org")))
