;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clean-aindent-mode" "1.5.0"
  "Simple indent and unindent, trims indent white-space."
  ()
  :url "https://github.com/pmarinov/clean-aindent-mode"
  :commit "9ae15997cd75c5625a4f759a3aff39bf202fc36f"
  :revdesc "9ae15997cd75"
  :keywords '("indentation" "whitespace" "backspace")
  :authors '(("peter marinov" . "efravia@gmail.com"))
  :maintainers '(("peter marinov" . "efravia@gmail.com")))
