;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "manage-minor-mode" "1.1"
  "Manage your minor-modes easily."
  '((emacs "24.3"))
  :url "https://github.com/ShingoFukuyama/manage-minor-mode"
  :commit "d07d269586233787b4bea4c40df43d6357a40f58"
  :revdesc "d07d26958623"
  :keywords '("tools" "minor-mode" "manage" "emacs"))
