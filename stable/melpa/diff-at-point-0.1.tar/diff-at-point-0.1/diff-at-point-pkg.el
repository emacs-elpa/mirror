;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-at-point" "0.1"
  "Diff navigation."
  '((emacs "26.2"))
  :url "https://gitlab.com/ideasman42/emacs-diff-at-point"
  :commit "9263b088285d8475e1fe50dbfa346f208453b25c"
  :revdesc "9263b088285d"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
