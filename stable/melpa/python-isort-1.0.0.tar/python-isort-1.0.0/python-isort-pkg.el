;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-isort" "1.0.0"
  "Reformat python-mode buffer with isort."
  '((emacs       "26")
    (reformatter "0.6"))
  :url "https://github.com/wyuenho/emacs-python-isort"
  :commit "4ba3dd75e7dd9f953d8b7c0b9c4c6d1b1c263047"
  :revdesc "4ba3dd75e7dd"
  :keywords '("languages")
  :authors '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
