;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ready-player" "0.33.1"
  "Open media files in ready-player major mode."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/ready-player"
  :commit "f1a422c855748d0af0c61964f8a92ad81c445470"
  :revdesc "f1a422c85574")
