;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f3" "0.1"
  "A helm interface to find."
  '((emacs  "24.3")
    (helm   "2.8.8")
    (cl-lib "0.5"))
  :url "https://github.com/cosmicexplorer/f3"
  :commit "19120dda2d760d3dd6c6aa620121d1de0a40932d"
  :revdesc "19120dda2d76"
  :keywords '("find" "file" "files" "helm" "fast" "finder"))
