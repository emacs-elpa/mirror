;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "2.0.0"
  "Browse GitHub repos without cloning."
  '((emacs "29.1")
    (ghub  "4.0.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "af795f3f7c086b4cca2b7ad866acc87dfe1b1633"
  :revdesc "2.0.0-0-gaf795f3f7c08"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
