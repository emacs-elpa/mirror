;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "netrunner" "1.0"
  "Organize and launch Steam games."
  '((cl-lib  "0.5")
    (emacs   "25.0")
    (popup   "0.5.3")
    (company "0.9.0"))
  :url "https://github.com/Kungsgeten/steam.el"
  :commit "92955c1c5da91e4e65c0d57a1931ff8794d67159"
  :revdesc "92955c1c5da9"
  :keywords '("games"))
