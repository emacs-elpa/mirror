;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "char-menu" "0.1.1"
  "Create your own menu for fast insertion of arbitrary symbols."
  '((emacs    "24.3")
    (avy-menu "0.1"))
  :url "https://github.com/mrkkrp/char-menu"
  :commit "f4d8bf8fa6787e2aaca2ccda5223646541d7a4b2"
  :revdesc "f4d8bf8fa678"
  :keywords '("convenience" "editing")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
