;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chezmoi" "0.0.1"
  "A package for interacting with chezmoi."
  '((emacs "26.1"))
  :url "http://www.github.com/tuh8888/chezmoi.el"
  :commit "d493925f93d5e0badb04a5331bbc8741b0cb04ca"
  :revdesc "d493925f93d5"
  :keywords '("vc"))
