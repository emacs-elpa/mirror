;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mise-tasks" "0.1.0"
  "Run mise tasks from Emacs."
  '((emacs "28.1"))
  :url "https://github.com/klochowicz/mise-tasks"
  :commit "3e600534ed41946393b4d82cfa062e8946d23dba"
  :revdesc "3e600534ed41"
  :keywords '("tools" "processes" "mise")
  :authors '(("Mariusz Klochowicz" . "mariusz@klochowicz.com"))
  :maintainers '(("Mariusz Klochowicz" . "mariusz@klochowicz.com")))
