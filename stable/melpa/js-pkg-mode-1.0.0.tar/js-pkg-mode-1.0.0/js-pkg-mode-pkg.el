;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-pkg-mode" "1.0.0"
  "[No description available]."
  '((emacs "24.1"))
  :url "https://github.com/ovistoica/js-pkg-mode"
  :commit "27c8b4692ae357115d6d1346570be83b63fa1b07"
  :revdesc "27c8b4692ae3"
  :keywords '("convenience" "project" "javascript" "package-manager")
  :authors '(("Ovi Stoica" . "ovidiu.stoica1094@gmail.com"))
  :maintainers '(("Ovi Stoica" . "ovidiu.stoica1094@gmail.com")))
