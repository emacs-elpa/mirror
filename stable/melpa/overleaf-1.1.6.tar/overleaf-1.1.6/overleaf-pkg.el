;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "1.1.6"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "b10bc8e2b511ed6a4501cb3c0a8980c883613d93"
  :revdesc "b10bc8e2b511"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
