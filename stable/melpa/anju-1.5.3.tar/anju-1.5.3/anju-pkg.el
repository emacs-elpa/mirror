;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "1.5.3"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "bb21f41c90814dcc1286296e26a27b7dc0d1a569"
  :revdesc "bb21f41c9081"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
