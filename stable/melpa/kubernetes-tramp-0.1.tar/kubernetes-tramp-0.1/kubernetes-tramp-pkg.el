;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubernetes-tramp" "0.1"
  "TRAMP integration for kubernetes containers."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/gruggiero/kubernetes-tramp.el"
  :commit "47b48051116eecced2a92b276199e21fbf1536da"
  :revdesc "47b48051116e"
  :keywords '("kubernetes" "convenience")
  :authors '(("Giovanni Ruggiero" . "giovanni.ruggiero+github@gmail.com"))
  :maintainers '(("Giovanni Ruggiero" . "giovanni.ruggiero+github@gmail.com")))
