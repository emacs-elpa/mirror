;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alsamixer" "0.2.1"
  "Functions to call out to amixer."
  ()
  :url "https://github.com/remvee/alsamixer-el"
  :commit "1bdb99e433acd38685f05408562746cfbf2bc820"
  :revdesc "0.2.1-0-g1bdb99e433ac"
  :keywords '("convenience"))
