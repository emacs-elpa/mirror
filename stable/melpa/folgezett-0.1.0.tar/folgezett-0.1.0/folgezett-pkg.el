;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "folgezett" "0.1.0"
  "Folgezettel IDs for org-roam."
  '((emacs    "27.1")
    (org-roam "2.0.0"))
  :url "https://github.com/landerwells/folgezett.el"
  :commit "d11ffaebf1f8115db2979804d39d44aaf62a1fab"
  :revdesc "d11ffaebf1f8"
  :keywords '("outlines" "tools" "org-roam" "zettelkasten")
  :authors '(("Lander Wells" . "landerwells@gmail.com"))
  :maintainers '(("Lander Wells" . "landerwells@gmail.com")))
