;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lonelog" "0.2.0"
  "Solo RPG notation support."
  '((emacs "27.1"))
  :url "https://github.com/enfors/lonelog"
  :commit "068b03d0047a4cba674dd3463b05fb5fd4a51e19"
  :revdesc "068b03d0047a"
  :keywords '("games" "convenience" "wp")
  :authors '(("Christer Enfors" . "christer.enfors@gmail.com"))
  :maintainers '(("Christer Enfors" . "christer.enfors@gmail.com")))
