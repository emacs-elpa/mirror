;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "i2b2-mode" "1.0"
  "Highlights corresponding PHI data in the text portion of an i2b2 XML Document."
  ()
  :url "https://github.com/danlamanna/i2b2-mode"
  :commit "f2abe934e1aaf6a3a3c3bf3deb578d212992862e"
  :revdesc "f2abe934e1aa"
  :keywords '("xml" "phi" "i2b2" "deidi2b2")
  :authors '(("Dan LaManna" . "dan.lamanna@gmail.com"))
  :maintainers '(("Dan LaManna" . "dan.lamanna@gmail.com")))
