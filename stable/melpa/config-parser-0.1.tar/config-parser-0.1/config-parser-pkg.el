;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "config-parser" "0.1"
  "A library to parse config file."
  '((cl-lib "0.5"))
  :url "https://github.com/lujun9972/el-config-parser"
  :commit "3dbbafdfd133da2d44736f606668d5ca8adf3bea"
  :revdesc "3dbbafdfd133"
  :keywords '("convenience" "config")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
