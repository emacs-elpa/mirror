;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bpe" "0.0.1"
  "Blogger Post progrom for Emacs."
  ()
  :url "https://github.com/yuutayamada/bpe"
  :commit "c2d9e7a3a574f799a0f10b0f09118f1334c32d90"
  :revdesc "c2d9e7a3a574"
  :keywords '("blogger")
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
