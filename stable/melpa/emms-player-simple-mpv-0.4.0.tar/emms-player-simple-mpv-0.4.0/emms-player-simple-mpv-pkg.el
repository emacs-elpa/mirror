;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms-player-simple-mpv" "0.4.0"
  "An extension of emms-player-simple.el for mpv JSON IPC."
  '((emacs  "24")
    (cl-lib "0.5")
    (emms   "4.0"))
  :url "https://github.com/momomo5717/emms-player-simple-mpv"
  :commit "bcc056364df5f405716006a8b7bb90102a57f62f"
  :revdesc "v0.4.0-0-gbcc056364df5"
  :keywords '("emms" "mpv"))
