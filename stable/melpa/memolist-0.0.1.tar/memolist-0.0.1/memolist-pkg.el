;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "memolist" "0.0.1"
  "Memolist.el is Emacs port of memolist.vim."
  '((markdown-mode "22.0")
    (ag            "0.45"))
  :url "https://github.com/mikanfactory/emacs-memolist"
  :commit "e70920ec1757354c5a732aecf52a1e62e097c0cf"
  :revdesc "e70920ec1757"
  :keywords '("markdown" "memo")
  :authors '(("mikanfactory" . "k952i4j14x17_at_gmail.com")))
