;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "window-numbering" "1.1.2"
  "[No description available]."
  ()
  :url "http://nschum.de/src/emacs/window-numbering-mode/"
  :commit "653afce73854d629c2b9d63dad73126032d6a24c"
  :revdesc "1.1.2-0-g653afce73854"
  :keywords '("faces" "matching")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
