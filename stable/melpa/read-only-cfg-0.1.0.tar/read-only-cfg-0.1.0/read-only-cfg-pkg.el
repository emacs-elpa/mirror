;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "read-only-cfg" "0.1.0"
  "Make files read-only based on user config."
  '((emacs "24.3"))
  :url "https://github.com/pfchen/read-only-cfg"
  :commit "09789d6d41eb8092512de86bed7b30a993aaf5df"
  :revdesc "09789d6d41eb"
  :keywords '("tools" "convenience")
  :authors '(("pfchen" . "pfchen31@gmail.com"))
  :maintainers '(("pfchen" . "pfchen31@gmail.com")))
