;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-pest" "0.1.0"
  "A flymake handler for Pest files."
  '((emacs     "26.3")
    (pest-mode "0.1"))
  :url "https://github.com/ksqsf/pest-mode"
  :commit "43447a2c70f98edd1139005e32f437d3f142442b"
  :revdesc "v0.1.0-0-g43447a2c70f9"
  :keywords '("languages" "flymake")
  :authors '(("ksqsf" . "i@ksqsf.moe")
             ("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("ksqsf" . "i@ksqsf.moe")
                 ("Naoya Yamashita" . "conao3@gmail.com")))
