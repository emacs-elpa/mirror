;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mimetypes" "1.0"
  "Guess a file's mimetype by extension."
  '((emacs "25.1"))
  :url "https://github.com/cniles/emacs-mimetypes"
  :commit "82d9c045b258b21864932913a8896978f8b45702"
  :revdesc "82d9c045b258"
  :authors '(("Craig Niles" . "niles.catgmail.com"))
  :maintainers '(("Craig Niles" . "niles.catgmail.com")))
