;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "replace-from-region" "0.1"
  "Replace commands whose query is from region."
  ()
  :url "http://www.emacswiki.org/emacs/download/replace-from-region.el"
  :commit "ea8358c4d6c504461470fec582862b9e6e80c9a3"
  :revdesc "ea8358c4d6c5"
  :keywords '("replace" "search" "region")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
