;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertigo" "1.0"
  "Jump across lines using the home row."
  '((dash "2.11.0"))
  :url "https://github.com/noctuid/vertigo.el"
  :commit "ebfa068d9e2fc39ba6d1744618c4e31dad6f629b"
  :revdesc "v1.0-0-gebfa068d9e2f"
  :keywords '("vim" "vertigo")
  :authors '(("Fox Kiester" . "noct@openmailbox.org"))
  :maintainers '(("Fox Kiester" . "noct@openmailbox.org")))
