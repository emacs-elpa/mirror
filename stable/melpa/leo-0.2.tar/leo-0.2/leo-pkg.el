;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leo" "0.2"
  "Interface for dict.leo.org."
  '((emacs "25.1"))
  :url "https://github.com/mtenders/emacs-leo"
  :commit "7f2cdf09c70f642b85f102981ba5234422740724"
  :revdesc "7f2cdf09c70f"
  :keywords '("convenience" "translate")
  :authors '(("M.T. Enders" . "michaelATenders.io"))
  :maintainers '(("M.T. Enders" . "michaelATenders.io")))
