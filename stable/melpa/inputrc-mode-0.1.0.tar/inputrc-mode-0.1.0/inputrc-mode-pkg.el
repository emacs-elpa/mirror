;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inputrc-mode" "0.1.0"
  "Major mode for readline(3) configuration."
  '((emacs "29.1"))
  :url "https://github.com/nverno/inputrc-mode"
  :commit "7d7b1be8f7b5785e15c090a273fe7c9218d0cf1e"
  :revdesc "7d7b1be8f7b5"
  :keywords '("languages" "readline" "config")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
