;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pueue" "2.1.0"
  "Interface for pueue."
  '((emacs       "28.1")
    (with-editor "3.0.4"))
  :url "https://github.com/xFA25E/pueue"
  :commit "5ad6979a0129c7cddc69f71c9084e4356f450fac"
  :revdesc "2.1.0-0-g5ad6979a0129"
  :keywords '("processes")
  :authors '(("Valeriy Litkovskyy" . "vlr.ltkvsk@protonmail.com"))
  :maintainers '(("Valeriy Litkovskyy" . "vlr.ltkvsk@protonmail.com")))
