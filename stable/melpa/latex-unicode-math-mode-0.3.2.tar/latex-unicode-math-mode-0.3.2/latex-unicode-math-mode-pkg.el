;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-unicode-math-mode" "0.3.2"
  "Input method for Unicode math symbols."
  ()
  :url "https://github.com/Christoph-D/latex-unicode-math-mode"
  :commit "af6a28c3c7e8652f1e9c124beeccaa81133b1d88"
  :revdesc "af6a28c3c7e8"
  :authors '(("Christoph Dittmann" . "github@christoph-d.de"))
  :maintainers '(("Christoph Dittmann" . "github@christoph-d.de")))
