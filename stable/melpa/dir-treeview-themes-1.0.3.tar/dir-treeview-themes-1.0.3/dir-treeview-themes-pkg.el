;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-treeview-themes" "1.0.3"
  "Themes for dir-treeview."
  '((emacs        "24.4")
    (dir-treeview "1.3.3"))
  :url "https://github.com/tilmanrassy/emacs-dir-treeview-themes"
  :commit "8e28c2501a978e6ff733fc9cf43a826fd8e7b87e"
  :revdesc "8e28c2501a97"
  :keywords '("tools" "convenience" "files")
  :authors '(("Tilman Rassy" . "tilman.rassy@googlemail.com"))
  :maintainers '(("Tilman Rassy" . "tilman.rassy@googlemail.com")))
