;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-rtm" "0.1"
  "Simple import/export from rememberthemilk to org-mode."
  '((org "7")
    (rtm "0.1"))
  :url "https://github.com/pmiddend/org-rtm"
  :commit "c01c45af2cbb4f15f0a8b92c600a5e11ff5cb8ec"
  :revdesc "c01c45af2cbb"
  :keywords '("outlines" "data")
  :authors '(("Philipp Middendorf" . "pmidden@secure.mailbox.org"))
  :maintainers '(("Philipp Middendorf" . "pmidden@secure.mailbox.org")))
