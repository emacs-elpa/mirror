;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sudo-edit" "0.1.1"
  "Open files as another user."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/nflath/sudo-edit"
  :commit "a7ae1713bb659988bb1465a13b837fbc2d699504"
  :revdesc "a7ae1713bb65"
  :keywords '("convenience")
  :authors '(("Nathaniel Flath" . "flat0103@gmail.com"))
  :maintainers '(("Nathaniel Flath" . "flat0103@gmail.com")))
