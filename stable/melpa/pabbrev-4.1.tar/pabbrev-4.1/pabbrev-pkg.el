;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pabbrev" "4.1"
  "Predictive abbreviation expansion."
  ()
  :url "https://github.com/phillord/pabbrev"
  :commit "127a8b10cf352b0491fefd2f4178ba78ee587564"
  :revdesc "127a8b10cf35"
  :authors '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
  :maintainers '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk")))
