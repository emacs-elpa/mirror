;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quotient" "0.1"
  "A library for generating random quotes using a corpus."
  '((scratch-message "20220209.2207"))
  :url "https://github.com/tvirolai/quotient"
  :commit "edcdd75d470ee2555ae96a3d57e3137df61659b3"
  :revdesc "edcdd75d470e"
  :keywords '("lisp")
  :authors '(("Tuomo Virolainen" . "tvirolai@soittakaaparanoid.mail.kapsi.fi"))
  :maintainers '(("Tuomo Virolainen" . "tvirolai@soittakaaparanoid.mail.kapsi.fi")))
