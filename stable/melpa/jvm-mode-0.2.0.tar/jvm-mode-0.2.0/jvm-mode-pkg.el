;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jvm-mode" "0.2.0"
  "Monitor and manage your JVMs."
  '((dash  "2.6.0")
    (emacs "24"))
  :url "https://github.com/martintrojer/jvm-mode.el"
  :commit "16d84c8c80bb214367bae6ed30b08756521c27d6"
  :revdesc "16d84c8c80bb"
  :keywords '("convenience")
  :authors '(("Martin Trojer" . "martin.trojer@gmail.com"))
  :maintainers '(("Martin Trojer" . "martin.trojer@gmail.com")))
