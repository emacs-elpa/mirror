;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "purp-theme" "1.0"
  "A dark color theme with few colors."
  ()
  :url "https://github.com/gnuvince/purp"
  :commit "6807bfbdec15168244af1105de2e57510c9bb9e2"
  :revdesc "6807bfbdec15"
  :keywords '("color" "theme")
  :authors '(("Vincent Foley" . "vfoley@gmail.com"))
  :maintainers '(("Vincent Foley" . "vfoley@gmail.com")))
