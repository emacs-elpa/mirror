;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-julia-vterm" "0.11"
  "Babel functions for Julia that work with julia-vterm."
  '((emacs       "26.1")
    (julia-vterm "0.26")
    (queue       "0.2"))
  :url "https://github.com/shg/ob-julia-vterm.el"
  :commit "bc0f851d4a64f1659021b480f61cdac024ce76fe"
  :revdesc "bc0f851d4a64"
  :keywords '("julia" "org" "outlines" "literate programming" "reproducible research"))
