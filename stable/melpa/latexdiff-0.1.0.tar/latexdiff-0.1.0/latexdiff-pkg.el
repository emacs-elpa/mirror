;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latexdiff" "0.1.0"
  "Latexdiff integration in Emacs."
  ()
  :url "https://github.com/galaunay/emacs-latexdiff"
  :commit "dc4cd69bb5a5e5da708466fb1e3a5f43cfc8b33a"
  :revdesc "dc4cd69bb5a5"
  :keywords '("latex" "diff")
  :authors '(("Launay Gaby" . "gaby.launay@tutanota.com"))
  :maintainers '(("Launay Gaby" . "gaby.launay@tutanota.com")))
