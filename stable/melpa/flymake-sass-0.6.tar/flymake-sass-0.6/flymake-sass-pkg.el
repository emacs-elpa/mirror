;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-sass" "0.6"
  "Flymake handler for sass files."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-sass"
  :commit "1c7664818db539de7f3dab396c013528a3f5b8b4"
  :revdesc "1c7664818db5"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
