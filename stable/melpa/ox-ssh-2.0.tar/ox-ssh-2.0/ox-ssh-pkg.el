;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-ssh" "2.0"
  "SSH Config Backend for Org Export Engine."
  '((emacs "24.4"))
  :url "https://github.com/dantecatalfamo/ox-ssh"
  :commit "8a6adca5751833928744541aa8631d40fbf666e5"
  :revdesc "8a6adca57518"
  :keywords '("outlines" "org" "ssh"))
