;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "circleci-api" "0.1"
  "Bindings for the CircleCI API."
  '((emacs "25.1"))
  :url "https://github.com/sulami/circleci-api"
  :commit "0167779562c42f0bb978ce20acf9a1e4b277a15a"
  :revdesc "0167779562c4")
