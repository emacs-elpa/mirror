;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "foreman-mode" "0.0.1"
  "View and manage Procfile-based applications."
  '((s               "1.9.0")
    (dash            "2.10.0")
    (dash-functional "1.2.0")
    (f               "0.17.2")
    (emacs           "24"))
  :url "https://github.com/zweifisch/foreman-mode"
  :commit "e90d2b56e83ab914f9ba9e78126bd7a534d5b8fb"
  :revdesc "e90d2b56e83a"
  :keywords '("foreman")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
