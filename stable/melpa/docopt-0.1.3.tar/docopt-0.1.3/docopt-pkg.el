;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docopt" "0.1.3"
  "A Docopt implementation in Elisp."
  '((emacs     "26.3")
    (dash      "2.17.0")
    (emacs     "26.1")
    (f         "0.20.0")
    (parsec    "0.1.3")
    (s         "1.12.0")
    (transient "0.3.7"))
  :url "https://github.com/r0man/docopt.el"
  :commit "21c575db68d4ccadb3125241a62136a0f8b76f63"
  :revdesc "21c575db68d4"
  :keywords '("docopt" "tools" "processes")
  :authors '(("r0man" . "roman@burningswell.com"))
  :maintainers '(("r0man" . "roman@burningswell.com")))
