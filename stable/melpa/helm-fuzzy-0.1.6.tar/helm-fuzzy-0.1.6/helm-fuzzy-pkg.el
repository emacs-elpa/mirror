;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-fuzzy" "0.1.6"
  "Fuzzy matching for helm source."
  '((emacs "24.4")
    (helm  "1.7.9")
    (flx   "0.5"))
  :url "https://github.com/jcs-elpa/helm-fuzzy"
  :commit "72d618f95d6531854a60322d88b242825016f8e6"
  :revdesc "72d618f95d65"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
