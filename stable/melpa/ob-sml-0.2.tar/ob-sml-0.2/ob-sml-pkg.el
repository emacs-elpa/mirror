;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-sml" "0.2"
  "Org-babel functions for template evaluation."
  '((sml-mode "6.4"))
  :url "http://orgmode.org"
  :commit "5dc966acbe65e9e158bfa90018035bf52d4dafd4"
  :revdesc "5dc966acbe65"
  :keywords '("literate programming" "reproducible research"))
