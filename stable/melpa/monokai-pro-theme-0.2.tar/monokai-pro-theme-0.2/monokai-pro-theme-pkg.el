;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monokai-pro-theme" "0.2"
  "A simple theme based on the Monokai Pro Sublime color schemes."
  ()
  :url "https://github.com/belak/emacs-monokai-pro-theme"
  :commit "e644dcc6e0603aa5ff1354703acc3b6a9ed7ac74"
  :revdesc "e644dcc6e060"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
