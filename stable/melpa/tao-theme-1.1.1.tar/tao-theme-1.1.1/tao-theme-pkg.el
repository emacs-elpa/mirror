;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tao-theme" "1.1.1"
  "Tao of EMACS grayscale color theme."
  '((cl-lib "0.5"))
  :url "https://github.com/11111000000/tao-theme-emacs"
  :commit "af142b423536b47bce67afda5108dbf3a9317521"
  :revdesc "af142b423536"
  :authors '(("Peter Kosov" . "11111000000@email.com"))
  :maintainers '(("Peter Kosov" . "11111000000@email.com")))
