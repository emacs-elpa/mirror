;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-backend" "0.8.3"
  "LaTeX-to-SVG rendering engine with caching."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/latex-to-svg-backend"
  :commit "8fed2fc99568fb36a86d6fff978aa33ea8eeb800"
  :revdesc "v0.8.3-0-g8fed2fc99568"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
