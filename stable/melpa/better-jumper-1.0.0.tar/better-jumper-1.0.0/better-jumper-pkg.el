;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "better-jumper" "1.0.0"
  "Configurable jump list."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/gilbertw1/better-jumper"
  :commit "879ce3939fbcffd43537f0ed34b5811a94f84ec6"
  :revdesc "879ce3939fbc"
  :keywords '("jump" "history" "evil")
  :authors '(("Bryan Gilbert" . "http://github/gilbertw1"))
  :maintainers '(("Bryan Gilbert" . "bryan@bryan.sh")))
