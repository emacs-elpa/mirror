;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gl-conf-mode" "0.3"
  "[No description available]."
  ()
  :url "https://github.com/llloret/gitolite-emacs"
  :commit "1a53e548277eb9c669bbeda4bee9be32be7a82ec"
  :revdesc "v0.3-0-g1a53e548277e")
