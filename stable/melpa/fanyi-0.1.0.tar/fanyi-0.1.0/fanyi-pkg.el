;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fanyi" "0.1.0"
  "English-Chinese translator for Emacs."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/fanyi.el"
  :commit "0012a067a3d54c84fc488ab31dc40f3172bc1b07"
  :revdesc "0012a067a3d5"
  :keywords '("convenience" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
