;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awk-ts-mode" "1.0.0"
  "Major mode for awk."
  '((emacs "29.1"))
  :url "https://github.com/nverno/awk-ts-mode"
  :commit "55aef33a445a96ef6d69cd4379bd086f810d3d49"
  :revdesc "55aef33a445a"
  :keywords '("awk" "languages" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
