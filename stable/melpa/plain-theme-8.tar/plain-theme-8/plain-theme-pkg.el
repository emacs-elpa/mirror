;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plain-theme" "8"
  "Plain theme without syntax highlighting."
  '((emacs "24"))
  :url "https://github.com/lukateras/plain-theme"
  :commit "2609a811335d58cfb73a65d6307c156fe09037d3"
  :revdesc "2609a811335d")
