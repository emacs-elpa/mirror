;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tok-theme" "0.3"
  "Minimal monochromatic theme with restrained color highlights."
  '((emacs "27.0"))
  :url "https://github.com/topikettunen/tok-theme"
  :commit "c99b30cfb7bbf98479d1236b199308c31ebede76"
  :revdesc "c99b30cfb7bb"
  :authors '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainers '(("Topi Kettunen" . "topi@topikettunen.com")))
