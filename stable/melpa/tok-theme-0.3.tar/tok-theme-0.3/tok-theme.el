;;; tok-theme.el --- Minimal monochromatic theme with restrained color highlights. -*- lexical-binding: t; -*-

;; Author: Topi Kettunen <topi@topikettunen.com>
;; URL: https://github.com/topikettunen/tok-theme
;; Package-Version: 0.3
;; Package-Revision: c99b30cfb7bb
;; Package-Requires: ((emacs "27.0"))

;; This is free and unencumbered software released into the public domain.
;;
;; Anyone is free to copy, modify, publish, use, compile, sell, or
;; distribute this software, either in source code form or as a compiled
;; binary, for any purpose, commercial or non-commercial, and by any
;; means.
;;
;; In jurisdictions that recognize copyright laws, the author or authors
;; of this software dedicate any and all copyright interest in the
;; software to the public domain. We make this dedication for the benefit
;; of the public at large and to the detriment of our heirs and
;; successors. We intend this dedication to be an overt act of
;; relinquishment in perpetuity of all present and future rights to this
;; software under copyright law.
;;
;; THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
;; EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
;; MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
;; IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
;; OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
;; ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
;; OTHER DEALINGS IN THE SOFTWARE.
;;
;; For more information, please refer to <https://unlicense.org>

;; This file is not part of Emacs.

;;; Commentary:

;; tok-theme is a minimal monochromatic theme with restrained color highlights.

;;; Code:

(defgroup tok-theme nil
  "Options for tok-theme."
  :group 'faces)

(deftheme tok
  "Minimal monochromatic theme for Emacs in the spirit of Zmacs and
Smalltalk-80"
  :kind 'color-scheme)

(let* ((class '((class color) (min-colors 89)))
       ;; TOK color palette
       (bg    "white")
       (fg    "black")
       (dim-0 "grey95")
       (dim-1 "grey90")
       (dim-2 "grey80")
       (dim-3 "grey70")
       (dim-4 "grey60")
       (dim-5 "grey50"))
  (custom-theme-set-faces
   'tok
   ;;; Basic faces
   ;; Let terminal to define these.
   `(default ((,class (:foreground ,fg :background ,bg))))
   `(cursor ((,class (:background ,fg))))
   `(highlight ((,class (:background ,dim-0))))
   `(trailing-whitespace ((,class (:underline t))))
   `(region ((,class (:extend t :background "lightgoldenrod1"))))
   `(secondary-selection ((,class (:inherit region))))
   `(error ((,class (:weight bold :foreground "red"))))
   `(warning ((,class (:weight bold :foreground "orange"))))
   `(success ((,class (:weight bold :foreground "green"))))
   `(fringe ((t nil)))
   `(button ((,class (:box 1))))
   `(vertical-border ((,class (:foreground ,dim-2))))
   `(minibuffer-prompt ((t nil)))
   `(link ((,class (:underline t))))
   ;;; Line-numbers
   `(line-number ((,class (:foreground ,dim-2))))
   `(line-number-current-line ((,class (:foreground ,fg :background ,dim-1))))
   ;;; Mode-line
   `(mode-line ((,class (:foreground ,fg :background ,bg :box (:line-width -1 :style released-button)))))
   `(mode-line-active ((,class (:inherit mode-line))))
   `(mode-line-inactive ((,class (:weight light :foreground ,dim-5 :background ,dim-0 :box (:line-width -1 :color ,dim-1 :style nil)))))
   `(mode-line-highlight ((t nil)))
   `(mode-line-emphasis ((,class (:weight bold))))
   `(mode-line-buffer-id ((,class (:weight bold))))
   ;;; Font-lock
   `(font-lock-comment-face ((t nil)))
   `(font-lock-comment-delimiter-face ((t nil)))
   `(font-lock-string-face ((t nil)))
   `(font-lock-doc-face ((t nil)))
   `(font-lock-doc-markup-face ((t nil)))
   `(font-lock-keyword-face ((t nil)))
   `(font-lock-builtin-face ((t nil)))
   `(font-lock-function-name-face ((t nil)))
   `(font-lock-variable-name-face ((t nil)))
   `(font-lock-type-face ((t nil)))
   `(font-lock-constant-face ((t nil)))
   `(font-lock-warning-face ((t nil)))
   `(font-lock-negation-char-face ((t nil)))
   `(font-lock-preprocessor-face ((t nil)))
   `(font-lock-regexp-grouping-backslash ((t nil)))
   `(font-lock-regexp-grouping-construct ((t nil)))
   ;;; isearch
   `(isearch ((,class (:foreground ,bg :background ,fg))))
   `(isearch-group-1 ((,class (:background ,dim-5))))
   `(isearch-group-2 ((,class (:background ,dim-4))))
   `(lazy-highlight ((,class (:background ,dim-1))))
   ;;; Dired
   `(dired-directory ((,class (:weight bold))))
   `(dired-broken-symlink ((,class (:inherit error))))
   ;;; ERC
   `(erc-timestamp-face ((t nil)))
   ;;; sh
   `(sh-heredoc ((t nil)))
   `(sh-quoted-exec ((t nil)))
   ;;; Org
   `(org-agenda-structure ((t nil)))
   `(org-block ((t nil)))
   `(org-headline-done ((t nil)))
   `(org-special-keyword ((,class (:foreground ,dim-5))))
   ;;; Outline
   `(outline-1 ((,class (:weight bold))))
   `(outline-2 ((,class (:inherit outline-1))))
   `(outline-3 ((,class (:inherit outline-1))))
   `(outline-4 ((,class (:inherit outline-1))))
   `(outline-5 ((,class (:inherit outline-1))))
   `(outline-6 ((,class (:inherit outline-1))))
   `(outline-7 ((,class (:inherit outline-1))))
   `(outline-8 ((,class (:inherit outline-1))))
   ;;; Terraform
   `(terraform--resource-name-face ((t nil)))
   `(terraform--resource-type-face ((t nil)))
   ;;; Markdown
   `(markdown-header-face ((,class (:inherit outline-1))))
   `(markdown-header-delimiter-face ((t nil)))
   `(markdown-metadata-key-face ((,class (:inherit font-lock-comment-face))))
   `(markdown-metadata-value-face ((,class (:inherit font-lock-comment-face))))
   `(markdown-blockquote-face ((t nil)))
   `(markdown-pre-face ((t nil)))
   ;;; Magit
   `(magit-diff-file-heading ((t nil)))
   `(magit-section-heading ((,class (:weight bold))))
   ;;; completions
   `(completions-common-part ((,class (:weight bold))))
   `(completions-first-difference ((t nil)))
   ;;; Corfu
   `(corfu-default ((,class (:background ,bg))))
   `(corfu-bar ((,class (:background ,fg))))
   `(corfu-border ((,class (:background ,fg))))
   `(corfu-current ((,class (:inherit highlight))))))

;;;###autoload
(when (and (boundp 'custom-theme-load-path) load-file-name)
  (add-to-list 'custom-theme-load-path
               (file-name-as-directory (file-name-directory load-file-name))))

(provide-theme 'tok)

;;; tok-theme.el ends here
