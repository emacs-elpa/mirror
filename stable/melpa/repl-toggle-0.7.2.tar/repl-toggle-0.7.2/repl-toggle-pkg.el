;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repl-toggle" "0.7.2"
  "Switch to/from repl buffer for current major-mode."
  '((fullframe "0.0.5"))
  :url "https://git.sr.ht/~tomterl/repl-toggle"
  :commit "68ffba6888bf626e5175fae3b035d98d73ab4151"
  :revdesc "68ffba6888bf"
  :keywords '("repl" "buffers" "toggle")
  :authors '(("Tom Regner" . "tom@goochesa.de"))
  :maintainers '(("Tom Regner" . "tom@goochesa.de")))
