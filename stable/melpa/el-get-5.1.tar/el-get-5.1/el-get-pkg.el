;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-get" "5.1"
  "Manage the external elisp bits and pieces you depend upon."
  ()
  :url "http://www.emacswiki.org/emacs/el-get"
  :commit "bfffd553f4c72b818e9ee94f05458eae7a16056b"
  :revdesc "bfffd553f4c7"
  :keywords '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
