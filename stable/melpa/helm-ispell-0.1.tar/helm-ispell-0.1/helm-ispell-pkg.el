;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ispell" "0.1"
  "Ispell-complete-word with helm interface."
  '((helm-core "1.7.7"))
  :url "https://github.com/syohex/emacs-helm-ispell"
  :commit "640723ace794d21b8a5892012db99f963149415b"
  :revdesc "640723ace794"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
