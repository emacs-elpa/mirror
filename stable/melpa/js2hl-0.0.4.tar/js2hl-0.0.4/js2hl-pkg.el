;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js2hl" "0.0.4"
  "Highlight/rename things using js2-mode parser."
  '((emacs    "24.4")
    (js2-mode "20190219"))
  :url "https://github.com/redguardtoo/js2hl"
  :commit "334028e4c8df957a55986566fe099bb4e325cb00"
  :revdesc "334028e4c8df"
  :keywords '("convenience")
  :authors '(("Chen Bin" . "chenbinDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmailDOTcom")))
