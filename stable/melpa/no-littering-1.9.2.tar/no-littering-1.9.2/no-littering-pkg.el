;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "1.9.2"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "ca39a217864e8320db9a6e8f07ff58d76c2f7e8a"
  :revdesc "v1.9.2-0-gca39a217864e"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
