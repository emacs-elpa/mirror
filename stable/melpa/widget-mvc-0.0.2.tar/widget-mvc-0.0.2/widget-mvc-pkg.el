;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "widget-mvc" "0.0.2"
  "MVC framework for the emacs widgets."
  ()
  :url "https://github.com/kiwanami/emacs-widget-mvc"
  :commit "2576e6f0c35d8dedfa9c2cd6ea4fb4c14cb72b63"
  :revdesc "2576e6f0c35d"
  :keywords '("lisp" "widget")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net")))
