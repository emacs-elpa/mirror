;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sql-trino" "0.1.0"
  "[No description available]."
  '((emacs "24.4"))
  :url "https://github.com/regadas/sql-trino"
  :commit "759e80f22012e9b40fe433e7bde7d2d9d46ef8b1"
  :revdesc "759e80f22012"
  :keywords '("sql" "trino" "database")
  :authors '(("Filipe Regadas" . "oss@regadas.email"))
  :maintainers '(("Filipe Regadas" . "oss@regadas.email")))
