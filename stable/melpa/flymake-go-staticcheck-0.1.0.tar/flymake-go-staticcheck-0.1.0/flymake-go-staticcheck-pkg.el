;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-go-staticcheck" "0.1.0"
  "Go staticcheck linter for flymake."
  '((emacs "25"))
  :url "https://github.com/s-kostyaev/flymake-go-staticcheck"
  :commit "ba4cdcfce66b7bb94cdf3deeb44f063f15b0a196"
  :revdesc "ba4cdcfce66b"
  :keywords '("languages" "tools")
  :authors '(("Sergey Kostyaev" . "feo.me@ya.ru"))
  :maintainers '(("Sergey Kostyaev" . "feo.me@ya.ru")))
