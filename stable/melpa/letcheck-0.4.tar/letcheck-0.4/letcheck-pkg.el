;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "letcheck" "0.4"
  "Check the erroneous assignments in let forms."
  ()
  :url "https://github.com/Fuco1/letcheck"
  :commit "e85b185993a2eaeec6490709f4c131fde2edd672"
  :revdesc "e85b185993a2"
  :keywords '("convenience")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
