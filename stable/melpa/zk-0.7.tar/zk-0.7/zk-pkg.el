;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk" "0.7"
  "Functions for working with Zettelkasten-style linked notes."
  '((emacs "25.1"))
  :url "https://github.com/localauthor/zk"
  :commit "599be69ae1c1283935f98f9aca4ccda47063d82c"
  :revdesc "599be69ae1c1"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
