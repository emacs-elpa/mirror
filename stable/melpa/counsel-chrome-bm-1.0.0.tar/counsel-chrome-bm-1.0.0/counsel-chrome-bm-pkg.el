;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-chrome-bm" "1.0.0"
  "Browse your Chrom(e/ium) bookmarks with Ivy."
  '((emacs   "25.1")
    (counsel "0.13.0"))
  :url "https://github.com/BlueBoxWare/counsel-chrome-bm"
  :commit "cd4b16a1e89c446d68a0a57b4e8ef566e2590191"
  :revdesc "cd4b16a1e89c"
  :keywords '("hypermedia")
  :authors '(("BlueBoxWare" . "(BlueBoxWare@users.noreply.github.com)"))
  :maintainers '(("BlueBoxWare" . "(BlueBoxWare@users.noreply.github.com)")))
