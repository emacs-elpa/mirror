;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "0.1.1"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "c021dc08fe129a35c3f052f96a0de892a92faddb"
  :revdesc "c021dc08fe12"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
