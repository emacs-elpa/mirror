;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prassee-theme" "1.0"
  "A dark contrast color theme for Emacs."
  ()
  :url "https://github.com/prassee/prassee-emacs-theme"
  :commit "9850c806d39acffdef8e91e1a31b54a7620cbae3"
  :revdesc "9850c806d39a"
  :authors '(("Prassee" . "prassee.sathian@gmail.com"))
  :maintainers '(("Prassee" . "prassee.sathian@gmail.com")))
