;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-denote" "0.9.0"
  "A denote integration for ekg."
  '((emacs  "28.1")
    (ekg    "0.7.0")
    (denote "4.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "be6cc349a5054154470173af6521e569cb21bcb1"
  :revdesc "be6cc349a505"
  :keywords '("outlines" "hypermedia")
  :authors '(("Jay Rajput" . "jayrajput@gmail.com"))
  :maintainers '(("Jay Rajput" . "jayrajput@gmail.com")))
