;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trust-manager" "0.4.3"
  "Convenient trust management."
  '((emacs "30.1"))
  :url "https://git.sr.ht/~eshel/trust-manager"
  :commit "e527653dc41fa59a4a8af63dc4bfb4b4a8f9f68a"
  :revdesc "v0.4.3-0-ge527653dc41f"
  :keywords '("security" "trust" "files")
  :authors '(("Eshel Yaron" . "me@eshelyaron.com"))
  :maintainers '(("Eshel Yaron" . "me@eshelyaron.com")))
