;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellocate" "1.0"
  "Find a file using emacs with the speed of locate."
  '((emacs "24.4")
    (s     "1.12.0")
    (ivy   "0.11.0"))
  :url "https://github.com/walseb/ellocate"
  :commit "f828dd6080931c77b932790feb8d3fce90de2e76"
  :revdesc "f828dd608093"
  :keywords '("extensions")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
