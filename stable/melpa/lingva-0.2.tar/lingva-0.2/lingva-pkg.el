;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lingva" "0.2"
  "Access Google Translate via lingva.ml."
  '((emacs "25.1"))
  :url "https://codeberg.org/martianh/lingva.el"
  :commit "44181ec34f4ed85d7170e46bb70052ffaf0a4789"
  :revdesc "44181ec34f4e"
  :keywords '("convenience" "translation" "wp" "text")
  :authors '(("marty hiatt" . "martianhiatus[at]riseup[dot]net"))
  :maintainers '(("marty hiatt" . "martianhiatus[at]riseup[dot]net")))
