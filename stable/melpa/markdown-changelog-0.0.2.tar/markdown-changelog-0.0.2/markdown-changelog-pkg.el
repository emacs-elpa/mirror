;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-changelog" "0.0.2"
  "Maintain changelog entries."
  '((emacs "26")
    (dash  "2.13.0"))
  :url "https://github.com/plandes/markdown-changelog"
  :commit "403d2cd1cff932ae135692d57062824892e01d13"
  :revdesc "v0.0.2-0-g403d2cd1cff9"
  :keywords '("markdown" "changelog" "files"))
