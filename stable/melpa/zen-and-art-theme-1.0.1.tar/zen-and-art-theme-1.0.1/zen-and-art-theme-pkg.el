;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zen-and-art-theme" "1.0.1"
  "Zen and art color theme for GNU Emacs 24."
  ()
  :url "https://github.com/developernotes/zen-and-art-theme"
  :commit "a7226cbce0bca2501d69a620cb2aeabfc396c232"
  :revdesc "a7226cbce0bc")
