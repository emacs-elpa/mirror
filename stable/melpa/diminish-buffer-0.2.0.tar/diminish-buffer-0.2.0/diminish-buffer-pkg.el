;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diminish-buffer" "0.2.0"
  "Diminish (hide) buffers from buffer-menu."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/diminish-buffer"
  :commit "f5305840a5a09043f1d012cf50a55dc41317c080"
  :revdesc "f5305840a5a0"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
