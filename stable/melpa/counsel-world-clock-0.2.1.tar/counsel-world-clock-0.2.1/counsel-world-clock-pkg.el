;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-world-clock" "0.2.1"
  "Display world clock using Ivy."
  '((ivy "0.9.0")
    (s   "1.12.0"))
  :url "https://github.com/kchenphy/counsel-world-clock"
  :commit "4cb501a5a9e920ae6778072dc89700a0d14eadd6"
  :revdesc "4cb501a5a9e9"
  :authors '(("Kuang Chen" . "http://github.com/kchenphy"))
  :maintainers '(("Kuang Chen" . "http://github.com/kchenphy")))
