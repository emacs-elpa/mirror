;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-anzu" "0.3"
  "Anzu for evil-mode."
  '((evil "1.0.0")
    (anzu "0.46"))
  :url "https://github.com/syohex/emacs-evil-anzu"
  :commit "64cc08a3546373f28cd7bfd76a3e93bd78efa251"
  :revdesc "64cc08a35463"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com")
             ("Fredrik Bergroth" . "fbergroth@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")
                 ("Fredrik Bergroth" . "fbergroth@gmail.com")))
