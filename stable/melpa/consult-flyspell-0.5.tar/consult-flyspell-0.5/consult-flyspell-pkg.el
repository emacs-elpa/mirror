;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-flyspell" "0.5"
  "Consult integration for flyspell."
  '((emacs    "25.1")
    (consult  "0.12")
    (flyspell "27.1"))
  :url "https://gitlab.com/OlMon/consult-flyspell"
  :commit "356ca07c8809344685ca5855bc4bd3b18b179c3f"
  :revdesc "356ca07c8809"
  :keywords '("convenience"))
