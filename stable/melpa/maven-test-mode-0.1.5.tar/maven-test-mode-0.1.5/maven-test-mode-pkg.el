;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maven-test-mode" "0.1.5"
  "Utilities for navigating test files and running maven test tasks."
  '((s     "1.9")
    (emacs "24"))
  :url "https://github.com/rranelli/maven-test-mode"
  :commit "f79409907375591283291eb96af4754b1ccc0e6f"
  :revdesc "f79409907375"
  :keywords '("java" "maven" "test"))
