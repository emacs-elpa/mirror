;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grove" "0.2.0"
  "Obsidian-like note-taking for org files."
  '((emacs "29.1"))
  :url "https://github.com/jonathanchu/grove"
  :commit "ae97a3636638cbf349661c5a391a45310e7a169d"
  :revdesc "ae97a3636638"
  :keywords '("notes" "outlines" "tools")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
