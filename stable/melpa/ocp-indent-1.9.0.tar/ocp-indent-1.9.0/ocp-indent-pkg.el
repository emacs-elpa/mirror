;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocp-indent" "1.9.0"
  "Automatic indentation with ocp-indent."
  ()
  :url "http://www.typerex.org/ocp-indent.html"
  :commit "8aeb5cc580106366050de0068c11e20f8a947acc"
  :revdesc "1.9.0-0-g8aeb5cc58010"
  :keywords '("ocaml" "languages"))
