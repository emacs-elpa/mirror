;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tempus" "0.0.1"
  "Enhance Org time tracking."
  '((emacs "27.1"))
  :url "https://github.com/rul/org-tempus"
  :commit "e07a05d66c084cf4796c2683f4320d9360af8b83"
  :revdesc "e07a05d66c08"
  :keywords '("calendar")
  :authors '(("Raul Benencia" . "id@rbenencia.name"))
  :maintainers '(("Raul Benencia" . "id@rbenencia.name")))
