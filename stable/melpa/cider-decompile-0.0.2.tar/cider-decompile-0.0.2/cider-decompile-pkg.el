;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cider-decompile" "0.0.2"
  "Decompilation extension for cider."
  '((cider      "0.3.0")
    (javap-mode "9"))
  :url "http://www.github.com/clojure-emacs/cider-decompile"
  :commit "52862117b82f1946e0af37be2511498120a1956b"
  :revdesc "52862117b82f"
  :keywords '("languages" "clojure" "cider"))
