;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskrunner" "0.6"
  "Retrieve build system/taskrunner tasks."
  '((emacs "25.1"))
  :url "https://github.com/emacs-taskrunner/emacs-taskrunner"
  :commit "d8f4ee411444586bf06dbff8ab3f34f1880a5de4"
  :revdesc "d8f4ee411444"
  :keywords '("build-system" "taskrunner" "build" "task-runner" "tasks" "convenience")
  :authors '(("Yavor Konstantinov" . "ykonstantinov1ATgmailDOTcom"))
  :maintainers '(("Yavor Konstantinov" . "ykonstantinov1ATgmailDOTcom")))
