;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cats" "0.0.1"
  "Monads for Elisp."
  '((dash  "2.17.0")
    (emacs "26.1"))
  :url "https://github.com/Fuco1/emacs-cats"
  :commit "9c0652aca1886a21c8c9b4fb7386ea9870810e99"
  :revdesc "9c0652aca188"
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
