;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vcsh" "0.4.4"
  "Vcsh integration."
  '((emacs "25.1"))
  :url "https://gitlab.com/stepnem/vcsh-el"
  :commit "7e376436b8f450a5571e19246136ccf77bbdd4f1"
  :revdesc "7e376436b8f4"
  :keywords '("vc" "files")
  :authors '(("těpán Němec" . "stepnem@gmail.com"))
  :maintainers '(("těpán Němec" . "stepnem@gmail.com")))
