;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mustard-theme" "20141116"
  "An Emacs 24 theme based on Mustard (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "d03f9a01036b2681b162cd3fa2c0940b8bcd76ee"
  :revdesc "d03f9a01036b")
