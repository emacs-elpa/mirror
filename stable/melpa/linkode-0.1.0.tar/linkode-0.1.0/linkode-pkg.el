;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linkode" "0.1.0"
  "Send buffer or region code to linkode.org to generate a snippet."
  ()
  :url "https://github.com/erickgnavar/linkode.el"
  :commit "c39f59564030d3b116809df779879d5501a92635"
  :revdesc "c39f59564030"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
