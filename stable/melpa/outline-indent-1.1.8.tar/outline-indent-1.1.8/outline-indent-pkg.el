;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "1.1.8"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "85d1f66e82454829fcda5aa40334bb47be10586c"
  :revdesc "1.1.8-0-g85d1f66e8245"
  :keywords '("outlines")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
