;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quickref" "0.2"
  "Display relevant notes-to-self in the echo area."
  '((dash "1.0.3")
    (s    "1.0.0"))
  :url "https://github.com/pd/quickref.el"
  :commit "691f39392df1a2c0f25f40af51e3efc66d97d8df"
  :revdesc "691f39392df1")
