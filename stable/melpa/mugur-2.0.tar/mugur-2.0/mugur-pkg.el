;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mugur" "2.0"
  "Configurator for QMK compatible keyboards."
  '((emacs    "26.1")
    (s        "1.12.0")
    (anaphora "1.0.4")
    (dash     "2.18.1")
    (cl-lib   "1.0"))
  :url "https://github.com/mihaiolteanu/mugur"
  :commit "b8ebfd18a579b834d062082a8018f73561a0cde1"
  :revdesc "b8ebfd18a579"
  :keywords '("multimedia")
  :authors '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainers '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm")))
