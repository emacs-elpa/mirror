;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edebug-x" "1.2"
  "Extensions for Edebug."
  '((dash "1.1.0"))
  :url "https://github.com/ScottyB/edebug-x"
  :commit "411f06874cae87743e00af6455c25f66d0708839"
  :revdesc "411f06874cae"
  :keywords '("extensions")
  :authors '(("Scott Barnett" . "scott.n.barnett@gmail.com"))
  :maintainers '(("Scott Barnett" . "scott.n.barnett@gmail.com")))
