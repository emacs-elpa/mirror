;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "golden-ratio-scroll-screen" "1.1"
  "Scroll half screen down or up, and highlight current line."
  ()
  :url "https://github.com/jixiuf/golden-ratio-scroll-screen"
  :commit "0428fbe020ddb90811f2932e661796f667bf4ac5"
  :revdesc "0428fbe020dd"
  :keywords '("scroll" "screen" "highlight")
  :authors '((nil . "jixiufatgmaildotcom"))
  :maintainers '((nil . "jixiufatgmaildotcom")))
