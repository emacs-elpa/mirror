;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bibtex-completion" "2.0.0"
  "A BibTeX backend for completion frameworks."
  '((parsebib "1.0")
    (s        "1.9.0")
    (dash     "2.6.0")
    (f        "0.16.2")
    (cl-lib   "0.5"))
  :url "https://github.com/tmalsburg/helm-bibtex"
  :commit "d6a98ac6f28d2a6a05e203115211c98333d40aca"
  :revdesc "d6a98ac6f28d"
  :authors '(("Titus von der Malsburg" . "malsburg@posteo.de")
             ("Justin Burkett" . "justin@burkett.cc"))
  :maintainers '(("Titus von der Malsburg" . "malsburg@posteo.de")))
