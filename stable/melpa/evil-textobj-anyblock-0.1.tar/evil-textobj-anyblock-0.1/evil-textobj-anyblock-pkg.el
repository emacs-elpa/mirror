;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-anyblock" "0.1"
  "Textobject for the closest user-defined blocks."
  '((cl-lib "0.5")
    (evil   "1.1.0"))
  :url "https://github.com/noctuid/evil-textobj-anyblock"
  :commit "068d26a625cd6202aaf70a8ff399f9130c0ffa68"
  :revdesc "v0.1-0-g068d26a625cd"
  :keywords '("evil")
  :authors '(("Lit Wakefield" . "noct@openmailbox.org"))
  :maintainers '(("Lit Wakefield" . "noct@openmailbox.org")))
