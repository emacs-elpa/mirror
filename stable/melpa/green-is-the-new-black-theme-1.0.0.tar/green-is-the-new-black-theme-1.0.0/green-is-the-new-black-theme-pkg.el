;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "green-is-the-new-black-theme" "1.0.0"
  "A cool and minimalist green blackened theme engine."
  ()
  :url "https://github.com/fredcamps/green-is-the-new-black-emacs"
  :commit "9b682c0000bc732e4c55e876ac968877eada0402"
  :revdesc "9b682c0000bc"
  :keywords '("faces" "themes")
  :authors '(("Fred Campos" . "fred.tecnologia@gmail.com"))
  :maintainers '(("Fred Campos" . "fred.tecnologia@gmail.com")))
