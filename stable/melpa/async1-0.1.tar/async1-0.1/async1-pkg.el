;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async1" "0.1"
  "Unroll chain of async callbacks, parallel and sequencial."
  '((emacs  "24.1")
    (compat "30.1"))
  :url "https://github.com/Anoncheg1/emacs-async1"
  :commit "3f945d84c8d937d714824e29f992ea92f7db241d"
  :revdesc "3f945d84c8d9"
  :keywords '("tools" "async" "callback" "lisp" "extensions")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
