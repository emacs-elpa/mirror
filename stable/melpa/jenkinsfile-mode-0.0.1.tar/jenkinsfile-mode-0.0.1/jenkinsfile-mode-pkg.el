;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jenkinsfile-mode" "0.0.1"
  "Major mode for editing Jenkins declarative pipeline syntax."
  '((emacs       "24")
    (groovy-mode "2.0"))
  :url "https://github.com/john2x/jenkinsfile-mode"
  :commit "f53adf6ae413f29a126f5906fe37d0bb904d980c"
  :revdesc "f53adf6ae413")
