;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "strace-mode" "0.0.2"
  "Strace output syntax highlighting."
  ()
  :url "https://github.com/pkmoore/strace-mode"
  :commit "c6b544ede9791ba43da7f6ccb4c2126a2e447860"
  :revdesc "c6b544ede979"
  :keywords '("languages")
  :authors '(("Preston Moore" . "(prestonkmoore@gmail.com)"))
  :maintainers '(("Preston Moore" . "(prestonkmoore@gmail.com)")))
