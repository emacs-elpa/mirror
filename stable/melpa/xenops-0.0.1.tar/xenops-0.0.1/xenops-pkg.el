;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xenops" "0.0.1"
  "A LaTeX editing environment for mathematical documents."
  '((emacs  "26.1")
    (aio    "1.0")
    (auctex "12.2.0")
    (avy    "0.5.0")
    (dash   "2.18.0")
    (f      "0.20.0")
    (s      "1.12.0"))
  :url "https://github.com/dandavison/xenops"
  :commit "6d9a8d654a6102484ac9087f25931f0664e7dd07"
  :revdesc "6d9a8d654a61"
  :authors '(("Dan Davison" . "dandavison7@gmail.com"))
  :maintainers '(("Dan Davison" . "dandavison7@gmail.com")))
