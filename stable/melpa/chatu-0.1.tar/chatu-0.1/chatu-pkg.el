;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatu" "0.1"
  "Convert and insert any images to org-mode or markdown buffer."
  '((org           "9.6.6")
    (emacs         "29.1")
    (plantuml-mode "1.2.9"))
  :url "https://github.com/kimim/chatu"
  :commit "c5d05938e1a7ea16cb47e50ee43c1ffe58d306a0"
  :revdesc "c5d05938e1a7"
  :keywords '("multimedia" "convenience")
  :authors '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainers '(("Kimi Ma" . "kimi.im@outlook.com")))
