;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-rails" "0.2"
  "Helm extension for Rails projects."
  '((helm        "1.5.1")
    (inflections "1.1"))
  :url "https://github.com/asok/helm-rails"
  :commit "16359c2691c6bed74cc6a7f9949b21e60c99d262"
  :revdesc "16359c2691c6"
  :keywords '("helm" "rails" "git")
  :authors '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com"))
  :maintainers '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com")))
