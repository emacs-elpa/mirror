;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "web-beautify" "0.3.2"
  "Format HTML, CSS and JavaScript/JSON by js-beautify."
  ()
  :url "https://github.com/yasuyk/web-beautify"
  :commit "aa95055224c24f38736716809fec487cd817c38d"
  :revdesc "aa95055224c2"
  :authors '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
