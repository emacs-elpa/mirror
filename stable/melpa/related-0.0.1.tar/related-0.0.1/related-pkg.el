;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "related" "0.0.1"
  "Switch back and forth between similarly named buffers."
  ()
  :url "https://bitbucket.org/lyude/related"
  :commit "4391c0eceabee95a1bf2513f93b55c203ed6c8b5"
  :revdesc "4391c0eceabe"
  :keywords '("file" "buffer" "switch" "selection" "matching" "convenience"))
