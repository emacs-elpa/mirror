;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-mode" "4.5.1"
  "Major-mode for editing CMake sources."
  '((emacs "24.1"))
  :commit "2803b0fd98c2b0e000d36ef834cf5c2d4992e653"
  :revdesc "v4.5.1-0-g2803b0fd98c2")
