;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bracketed-paste" "0.1.0"
  "Bracketed paste mode support within emacs -nw."
  '((emacs "24"))
  :url "https://github.com/hchbaw/bracketed-paste.el"
  :commit "26580b3d33f0e4887bee3fe6604e12a9471c5491"
  :revdesc "26580b3d33f0"
  :keywords '("terminals")
  :authors '(("Takeshi Banse" . "takebi@laafc.net"))
  :maintainers '(("Takeshi Banse" . "takebi@laafc.net")))
