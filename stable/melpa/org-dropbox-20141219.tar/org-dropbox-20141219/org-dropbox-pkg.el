;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-dropbox" "20141219"
  "Move Dropbox notes from phone into org-mode datetree."
  '((dash  "2.2")
    (names "0.5")
    (emacs "24"))
  :url "https://github.com/heikkil/org-dropbox"
  :commit "81942ddeb455e42e9ab11f1481d28388b0166741"
  :revdesc "81942ddeb455"
  :keywords '("dropbox" "android" "notes" "org-mode")
  :authors '(("Heikki Lehvaslaiho" . "heikki.lehvaslaiho@gmail.com"))
  :maintainers '(("Heikki Lehvaslaiho" . "heikki.lehvaslaiho@gmail.com")))
