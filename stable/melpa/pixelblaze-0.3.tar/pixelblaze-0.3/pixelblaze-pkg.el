;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pixelblaze" "0.3"
  "Interact with a Pixelblaze via Websocket."
  '((emacs     "27.1")
    (websocket "1.13"))
  :url "https://github.com/mgsb/emacs-pixelblaze"
  :commit "10790ba95b78e7eb1829862d2fa894324a884a5f"
  :revdesc "10790ba95b78"
  :keywords '("games" "pixelblaze" "neopixel" "ws2812" "sk6812")
  :authors '(("Mark Grosen" . "mark@grosen.org"))
  :maintainers '(("Mark Grosen" . "mark@grosen.org")))
