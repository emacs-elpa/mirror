;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ercn" "1.1.1"
  "Flexible ERC notifications."
  ()
  :url "http://www.github.com/leathekd/ercn"
  :commit "73b00dadf83b97dd9edd8381a4b27f583c08b7f6"
  :revdesc "73b00dadf83b"
  :authors '(("David Leatherman" . "leathekd@gmail.com"))
  :maintainers '(("David Leatherman" . "leathekd@gmail.com")))
