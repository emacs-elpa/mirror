;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ronny-theme" "0.1"
  "A ronny.el colorscheme for Emacs."
  '((emacs "27"))
  :url "https://github.com/judaew/ronny.el"
  :commit "4357a42261678e02138d6ca40e3184c73f55b32e"
  :revdesc "4357a4226167")
