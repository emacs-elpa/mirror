;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org2ctex" "0.0.1"
  "Export org to ctex (a latex macro for Chinese)."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/tumashu/org2ctex"
  :commit "988846d2c5cf78c02f17e7a868da4368ca28f47a"
  :revdesc "988846d2c5cf"
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
