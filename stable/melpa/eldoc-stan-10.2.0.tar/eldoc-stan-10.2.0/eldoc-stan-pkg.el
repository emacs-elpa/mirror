;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-stan" "10.2.0"
  "Eldoc support for stan functions."
  '((emacs     "25")
    (stan-mode "10.1.0"))
  :url "https://github.com/stan-dev/stan-mode/tree/master/eldoc-stan"
  :commit "2dd330604563d143031fc8ffd516266217aa1f9b"
  :revdesc "2dd330604563"
  :keywords '("help" "tools")
  :authors '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu"))
  :maintainers '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu")))
