;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nlinum-relative" "0.1"
  "Relative line number with nlinum."
  '((nlinum "1.5"))
  :url "https://github.com/xcodebuild/nlinum-relative"
  :commit "40c082729d9254e922d0195de36d3048b152ee6a"
  :revdesc "40c082729d92"
  :keywords '("convenience")
  :authors '(("codefalling" . "code.falling@gmail.com"))
  :maintainers '(("codefalling" . "code.falling@gmail.com")))
