;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "0.38.0"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.8.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "b6d7b37353572bf92d04c8de5abced3ef68a0304"
  :revdesc "b6d7b3735357"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
