;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-open-github" "0.15"
  "Utilities of Opening Github Page."
  '((emacs     "24.4")
    (helm-core "1.7.7")
    (gh        "0.8.2"))
  :url "https://github.com/syohex/emacs-helm-open-github"
  :commit "553f3ab0fe0a028015e9b6cb7c35fb139ec222fc"
  :revdesc "553f3ab0fe0a"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
