;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reddigg" "0.6.0"
  "A reader for redditt."
  '((emacs   "26.3")
    (promise "1.1")
    (ht      "2.3")
    (org     "9.2"))
  :url "https://github.com/thanhvg/emacs-reddigg"
  :commit "0d8f3f9d86e63a24e949cf1acc9159ae7d092cef"
  :revdesc "0d8f3f9d86e6"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
