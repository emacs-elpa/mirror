;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "streamlink" "0.1"
  "A major mode for streamlink output."
  '((s "1.12.0"))
  :url "https://github.com/BenediktBroich/streamlink"
  :commit "c02564cf518ad07400fcf00df28b7789d1434c8c"
  :revdesc "c02564cf518a"
  :keywords '("multimedia" "streamlink"))
