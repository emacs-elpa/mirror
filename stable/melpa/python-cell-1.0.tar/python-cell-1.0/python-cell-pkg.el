;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-cell" "1.0"
  "Support for MATLAB-like cells in python mode."
  ()
  :url "https://github.com/twmr/python-cell.el"
  :commit "1b71ec7a03903b0225d7929351a50e602cd0a8ab"
  :revdesc "1b71ec7a0390"
  :keywords '("python" "matlab" "cell")
  :authors '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainers '(("Thomas Hisch" . "t.hisch@gmail.com")))
