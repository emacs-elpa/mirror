;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eproject" "1.5"
  "[No description available]."
  ()
  :url "https://github.com/jrockway/eproject"
  :commit "45a6544e7133bcc4703814b12fc1d81947beddc2"
  :revdesc "45a6544e7133"
  :keywords '("programming" "projects")
  :authors '(("Jonathan Rockway" . "jon@jrock.us"))
  :maintainers '(("Jonathan Rockway" . "jon@jrock.us")))
