;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poetry" "0.2.0"
  "Interface to Poetry."
  '((transient "0.2.0")
    (pyvenv    "1.2")
    (emacs     "25.1"))
  :url "https://github.com/galaunay/poetry.el"
  :commit "2cbc690c8c1153e578ecb376367d355a7669f9ec"
  :revdesc "2cbc690c8c11"
  :keywords '("python" "tools")
  :authors '(("Gaby Launay" . "gaby.launay@protonmail.com"))
  :maintainers '(("Gaby Launay" . "gaby.launay@protonmail.com")))
