;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keytar" "0.1.2"
  "Emacs Lisp interface for node-keytar."
  '((emacs "24.4"))
  :url "https://github.com/emacs-grammarly/keytar"
  :commit "17972320ef140bd56e551842d89f5d8c2d979f83"
  :revdesc "17972320ef14"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
