;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tumblesocks" "0.0.0.20250109.65"
  "An Emacs tumblr client."
  '((htmlize       "1.39")
    (oauth         "1.0.3")
    (markdown-mode "1.8.1"))
  :url "https://github.com/gcr/tumblesocks"
  :commit "4e72482b21750f495bffa6785b873d86743e9c0a"
  :revdesc "4e72482b2175"
  :authors '(("gcr" . "gcr@sneakygcr.net"))
  :maintainers '(("gcr" . "gcr@sneakygcr.net")))
