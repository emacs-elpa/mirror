;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pandoc" "0.0.1"
  "Pandoc interface."
  '((emacs "24"))
  :url "https://github.com/zonuexe/pandoc.el"
  :commit "0f59533bbd8494fea3172551efb6ec49f61ba285"
  :revdesc "0f59533bbd84"
  :keywords '("documentation" "markup" "converter")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
