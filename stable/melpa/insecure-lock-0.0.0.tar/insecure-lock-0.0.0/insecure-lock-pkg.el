;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insecure-lock" "0.0.0"
  "[No description available]."
  ()
  :url "https://github.com/BlueFlo0d/insecure-lock"
  :commit "0eb20ba68f91866ad2861f2c32a879f1fe68b13e"
  :revdesc "0eb20ba68f91"
  :keywords '("unix" "screensaver" "security")
  :authors '(("Qiantan Hong" . "qhong@alum.mit.edu"))
  :maintainers '(("Qiantan Hong" . "qhong@alum.mit.edu")))
