;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conner" "0.5"
  "Define and run project specific commands."
  '((emacs "29.1"))
  :url "https://github.com/tralph3/conner"
  :commit "c87ada981743184ad21cd41def1405520651d626"
  :revdesc "c87ada981743"
  :keywords '("tools")
  :authors '(("Tomás Ralph" . "tomasralph2000@gmail.com"))
  :maintainers '(("Tomás Ralph" . "tomasralph2000@gmail.com")))
