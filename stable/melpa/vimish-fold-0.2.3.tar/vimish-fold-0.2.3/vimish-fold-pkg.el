;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vimish-fold" "0.2.3"
  "Fold text like in Vim."
  '((emacs  "24.4")
    (cl-lib "0.5")
    (f      "0.18.0"))
  :url "https://github.com/mrkkrp/vimish-fold"
  :commit "e631352fbf910f692807afe38a2b6a7882a403a8"
  :revdesc "e631352fbf91"
  :keywords '("convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
