;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql-ql" "0.2"
  "Intgrating org-roam and org-ql."
  '((emacs       "28")
    (org-roam-ql "0.1")
    (org-ql      "0.7")
    (org-roam    "2.2.0")
    (s           "1.12.0")
    (transient   "0.4"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "f628fef081394f159f196f4350132aecb3edb8cc"
  :revdesc "f628fef08139")
