;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms-soundcloud" "0.1"
  "EMMS source for Soundcloud audio sharing platform."
  ()
  :url "https://github.com/osener/emms-soundcloud"
  :commit "57feba02b77bc19c8d34f5a91e5eeb27bf3b654b"
  :revdesc "57feba02b77b"
  :keywords '("emms" "soundcloud")
  :authors '(("Ozan Sener" . "ozan@ozansener.com"))
  :maintainers '(("Ozan Sener" . "ozan@ozansener.com")))
