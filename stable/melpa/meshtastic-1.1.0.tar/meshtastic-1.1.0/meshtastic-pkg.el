;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meshtastic" "1.1.0"
  "Chat client for Meshtastic LoRa devices via serial."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/meshtastic.el"
  :commit "52b63ada27870b79bcdad746f3df0fd203db2342"
  :revdesc "52b63ada2787"
  :keywords '("comm")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
