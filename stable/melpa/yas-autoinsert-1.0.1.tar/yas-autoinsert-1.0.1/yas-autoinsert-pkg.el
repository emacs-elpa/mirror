;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yas-autoinsert" "1.0.1"
  "Autoinsert trigger for YASnippet."
  '((emacs     "25.1")
    (yasnippet "0.8.1"))
  :url "https://gitlab.com/rchastel1/yas-autoinsert"
  :commit "455d7b52c006ba12dd21f74a07da343a8655d483"
  :revdesc "v1.0.1-0-g455d7b52c006"
  :keywords '("editing" "files" "convenience")
  :authors '(("Wieland Hoffmann" . "themineo+yatemplate@gmail.com")
             ("Piknik" . "https://github.com/piknik")
             ("Romain Châtel" . "rchastel@protonmail.com"))
  :maintainers '(("Romain Châtel" . "rchastel@protonmail.com")))
