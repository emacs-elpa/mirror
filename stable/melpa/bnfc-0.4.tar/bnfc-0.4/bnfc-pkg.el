;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bnfc" "0.4"
  "Define context-free grammars for the BNFC tool."
  '((emacs "24.3"))
  :url "https://github.com/jmitchell/bnfc-mode"
  :commit "1b58df1dd0cb9b81900632fb2843a03b94f56fdb"
  :revdesc "1b58df1dd0cb"
  :keywords '("languages" "tools")
  :authors '(("Jacob Mitchell" . "jmitchell@member.fsf.org"))
  :maintainers '(("Jacob Mitchell" . "jmitchell@member.fsf.org")))
