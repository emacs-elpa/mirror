;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rego-mode" "0.1.0"
  "A major mode for rego language."
  '((emacs       "24.4")
    (reformatter "0.3"))
  :url "https://github.com/psibi/rego-mode"
  :commit "668a079d3c3ab86c08c4508680e31f69b9b96f35"
  :revdesc "668a079d3c3a"
  :keywords '("languages")
  :authors '(("Sibi Prabakaran" . "sibi@psibi.in"))
  :maintainers '(("Sibi Prabakaran" . "sibi@psibi.in")))
