;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-tools" "0.1.2"
  "Collection of handy functions for ruby-mode."
  ()
  :url "https://github.com/rejeep/ruby-tools"
  :commit "6e7fb376085bfa7010ecd3dfad63adacc6e2b4ac"
  :revdesc "6e7fb376085b"
  :keywords '("speed" "convenience" "ruby")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
