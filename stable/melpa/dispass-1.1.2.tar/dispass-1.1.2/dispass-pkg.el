;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dispass" "1.1.2"
  "Emacs wrapper for DisPass."
  ()
  :url "http://projects.ryuslash.org/dispass.el/"
  :commit "38b880e72cfe5e65179b16791903b0900c73eff4"
  :revdesc "1.1.2-0-g38b880e72cfe"
  :keywords '("processes")
  :authors '(("Tom Willemsen" . "tom@ryuslash.org"))
  :maintainers '(("Tom Willemsen" . "tom@ryuslash.org")))
