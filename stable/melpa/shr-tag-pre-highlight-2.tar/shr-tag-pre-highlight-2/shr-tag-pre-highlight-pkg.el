;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shr-tag-pre-highlight" "2"
  "Syntax highlighting code block in HTML."
  '((emacs              "24")
    (language-detection "0.1.0"))
  :url "https://github.com/xuchunyang/shr-tag-pre-highlight.el"
  :commit "63eb0b2a4c1caf1004bac8e002ff8b7477871e36"
  :revdesc "63eb0b2a4c1c"
  :keywords '("html")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
