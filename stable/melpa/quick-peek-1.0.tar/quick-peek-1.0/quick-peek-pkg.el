;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-peek" "1.0"
  "Inline quick-peek windows."
  '((cl-lib "0.5")
    (emacs  "24.3"))
  :url "https://github.com/cpitclaudel/quick-peek"
  :commit "1bb445c80062354539837fd753f5241c46598b91"
  :revdesc "1bb445c80062"
  :keywords '("tools" "help" "doc" "convenience")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
