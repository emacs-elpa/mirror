;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codesearch" "1"
  "Core support for managing codesearch tools."
  '((dash "2.8.0"))
  :url "https://github.com/abingham/emacs-codesearch"
  :commit "bf6dfc6210af1b770a0fb8584020b46895d2b542"
  :revdesc "bf6dfc6210af"
  :keywords '("tools" "development" "search")
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
