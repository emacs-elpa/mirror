;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mini-echo" "0.15.0"
  "Echo buffer status in minibuffer window."
  '((emacs          "29.1")
    (dash           "2.19.1")
    (hide-mode-line "1.0.3"))
  :url "https://github.com/eki3z/mini-echo.el"
  :commit "fe1fe43b3ad616a29288c82d8d7fe189dd2eccff"
  :revdesc "fe1fe43b3ad6"
  :keywords '("frames")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
