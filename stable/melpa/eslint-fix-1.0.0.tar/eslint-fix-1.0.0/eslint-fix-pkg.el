;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eslint-fix" "1.0.0"
  "Fix JavaScript files using ESLint."
  ()
  :url "https://github.com/codesuki/eslint-fix"
  :commit "be90d1e78b1dfd43b6b3b1c06868539e2ac27d3a"
  :revdesc "1.0.0-0-gbe90d1e78b1d"
  :keywords '("javascript" "eslint" "lint" "formatting" "style")
  :authors '(("Neri Marschik" . "marschik_neri@cyberagent.co.jp"))
  :maintainers '(("Neri Marschik" . "marschik_neri@cyberagent.co.jp")))
