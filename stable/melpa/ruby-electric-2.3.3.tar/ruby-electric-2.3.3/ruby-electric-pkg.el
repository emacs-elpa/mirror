;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-electric" "2.3.3"
  "Minor mode for electrically editing ruby code."
  ()
  :url "https://github.com/ruby/elisp-ruby-electric"
  :commit "f2323cd9b5df3b34aa9810ba8109502824925d23"
  :revdesc "f2323cd9b5df"
  :keywords '("languages" "ruby")
  :authors '(("Dee Zsombor" . "deedotzsomboratgmaildotcom")
             ("Akinori MUSHA" . "knu@iDaemons.org")
             ("Jakub Kuźma" . "qoobaa@gmail.com"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
