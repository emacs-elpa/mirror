;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nushell-ts-mode" "0.0.1"
  "Tree-sitter support for Nushell."
  '((emacs "29.1"))
  :url "https://github.com/herbertjones/nushell-ts-mode"
  :commit "b68d0ff370fb8cfcf547d36d5dc648e5f22ce587"
  :revdesc "b68d0ff370fb"
  :keywords '("nu" "nushell" "languages" "tree-sitter")
  :authors '(("Herbert Jones" . "jones.herbert@gmail.com"))
  :maintainers '(("Herbert Jones" . "jones.herbert@gmail.com")))
