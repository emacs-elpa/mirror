;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-crystal" "0.1.0"
  "Run a Inferior-Crystal process in a buffer."
  '((emacs        "24.3")
    (crystal-mode "0.1.0"))
  :url "https://github.com/brantou/inf-crystal.el"
  :commit "71a330f2d29e2fb4f51d223cf6230b88620a80af"
  :revdesc "71a330f2d29e"
  :keywords '("languages" "crystal")
  :authors '(("Brantou" . "brantou89@gmail.com"))
  :maintainers '(("Brantou" . "brantou89@gmail.com")))
