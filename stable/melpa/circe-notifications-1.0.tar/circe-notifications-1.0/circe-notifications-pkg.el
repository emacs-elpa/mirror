;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "circe-notifications" "1.0"
  "Add desktop notifications to Circe."
  '((emacs "24.4")
    (circe "2.3")
    (alert "1.2"))
  :url "https://github.com/eqyiel/circe-notifications"
  :commit "80c44441ecd3ae04ae63760aa20afa837c1ed05b"
  :revdesc "80c44441ecd3"
  :authors '(("Ruben Maher" . "r@rkm.id.au"))
  :maintainers '(("Ruben Maher" . "r@rkm.id.au")))
