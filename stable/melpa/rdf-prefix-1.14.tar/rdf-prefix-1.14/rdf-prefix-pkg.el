;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rdf-prefix" "1.14"
  "Prefix lookup for RDF."
  ()
  :url "https://github.com/simenheg/rdf-prefix"
  :commit "c591608d12278b293a14c27ab2df72a269eb535d"
  :revdesc "c591608d1227"
  :keywords '("convenience" "abbrev")
  :authors '(("Simen Heggestøyl" . "simenheg@runbox.com"))
  :maintainers '(("Simen Heggestøyl" . "simenheg@runbox.com")))
