;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gsnip" "0.1.0"
  "A gitlab snippet client."
  '((emacs "26")
    (aio   "1.0")
    (log4e "0.3.3"))
  :url "https://github.com/kaiwk/gitlab-snippet"
  :commit "c8bff61b10cd33de9d6f5fd84e4b27f48c772304"
  :revdesc "c8bff61b10cd"
  :keywords '("extensions" "tools")
  :authors '(("Wang Kai" . "kaiwkx@gmail.com"))
  :maintainers '(("Wang Kai" . "kaiwkx@gmail.com")))
