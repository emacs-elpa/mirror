;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "what-the-commit" "1.0"
  "Random commit message generator."
  ()
  :url "http://barbarito.me/"
  :commit "57052121faa8b534b90db4c2537e1256f9c4e449"
  :revdesc "57052121faa8"
  :keywords '("git" "commit" "message")
  :authors '(("Dan Barbarito" . "dan@barbarito.me"))
  :maintainers '(("Dan Barbarito" . "dan@barbarito.me")))
