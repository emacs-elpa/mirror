;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-hledger" "0.1.0"
  "Flymake module to check hledger journals."
  '((emacs "28.2"))
  :url "https://github.com/DamienCassou/flymake-hledger"
  :commit "542f44933712b6e0abd8e4f3e51787a1afb40440"
  :revdesc "v0.1.0-0-g542f44933712"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
