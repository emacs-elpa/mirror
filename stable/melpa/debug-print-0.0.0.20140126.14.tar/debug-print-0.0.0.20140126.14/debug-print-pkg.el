;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "debug-print" "0.0.0.20140126.14"
  "A nice printf debugging environment by the way Gauche do."
  '((emacs "24"))
  :url "https://github.com/kenoss/debug-print"
  :commit "d817fd9ea2d3f8d2c1ace4d8af155684f3a99dc5"
  :revdesc "d817fd9ea2d3"
  :keywords '("extensions" "lisp" "tools" "maint")
  :authors '(("Ken Okada" . "keno.ss57@gmail.com"))
  :maintainers '(("Ken Okada" . "keno.ss57@gmail.com")))
