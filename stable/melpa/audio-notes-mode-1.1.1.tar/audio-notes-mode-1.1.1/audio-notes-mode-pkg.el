;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "audio-notes-mode" "1.1.1"
  "Play audio notes synced from somewhere else."
  ()
  :url "https://github.com/Bruce-Connor/audio-notes-mode"
  :commit "9072e2d8e1b7cdfb8ff28385e35102df8fd78769"
  :revdesc "9072e2d8e1b7"
  :keywords '("hypermedia" "convenience")
  :authors '(("Artur Malabarba" . "bruce.connor.am@gmail.com"))
  :maintainers '(("Artur Malabarba" . "bruce.connor.am@gmail.com")))
