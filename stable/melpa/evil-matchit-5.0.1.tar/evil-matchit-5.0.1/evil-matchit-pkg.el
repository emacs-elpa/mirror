;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-matchit" "5.0.1"
  "Vim matchit ported to Evil."
  '((emacs "27.1"))
  :url "https://github.com/redguardtoo/evil-matchit"
  :commit "d3777fe1984b081537f6410c3f907ff1d24c6225"
  :revdesc "d3777fe1984b"
  :keywords '("matchit" "vim" "evil")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
