;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srefactor" "0.5"
  "A refactoring tool based on Semantic parser framework."
  '((emacs "24.4"))
  :url "https://github.com/tuhdo/semantic-refactor"
  :commit "ecd40713f736b243285c07f4cfd77113794d4f9f"
  :revdesc "ecd40713f736"
  :keywords '("c" "languages" "tools")
  :authors '(("Do Hoang" . "tuhdo1710@gmail.com")))
