;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rails-routes" "0.3"
  "Search for and insert rails routes."
  '((emacs       "27.2")
    (inflections "1.1"))
  :url "https://github.com/otavioschwanck/rails-routes"
  :commit "33d9ea7ed100dc388d1a3af4f4b1e8ab15b3ab2a"
  :revdesc "33d9ea7ed100"
  :keywords '("tools" "languages")
  :authors '(("Otávio Schwanck" . "otavioschwanck@gmail.com"))
  :maintainers '(("Otávio Schwanck" . "otavioschwanck@gmail.com")))
