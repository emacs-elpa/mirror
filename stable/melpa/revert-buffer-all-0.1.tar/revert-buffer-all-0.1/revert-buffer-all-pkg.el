;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "revert-buffer-all" "0.1"
  "Revert all open buffers."
  '((emacs "24.3"))
  :url "https://gitlab.com/ideasman42/emacs-buffer-revert-all"
  :commit "14efdbf24ebe0d743ccb3f0d43acae98939c94fd"
  :revdesc "14efdbf24ebe"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
