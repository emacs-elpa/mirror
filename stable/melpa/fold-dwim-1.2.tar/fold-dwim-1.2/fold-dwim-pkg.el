;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fold-dwim" "1.2"
  "[No description available]."
  ()
  :url "http://www.dur.ac.uk/p.j.heslin/emacs/download/fold-dwim.el"
  :commit "4764b0246a722d37eb8ec9f204ffaccaad1755d0"
  :revdesc "1.2-0-g4764b0246a72"
  :authors '(("Peter Heslin" . "p.j.heslin@dur.ac.uk"))
  :maintainers '(("Peter Heslin" . "p.j.heslin@dur.ac.uk")))
