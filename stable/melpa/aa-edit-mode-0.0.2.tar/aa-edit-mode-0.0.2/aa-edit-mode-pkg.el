;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aa-edit-mode" "0.0.2"
  "Major mode for editing AA(S_JIS Art) and .mlt file."
  '((emacs   "24.3")
    (navi2ch "2.0.0"))
  :url "https://github.com/zonuexe/aa-edit-mode"
  :commit "2e56f3b627f0f19fbfce4968180b4d736f7afb5d"
  :revdesc "2e56f3b627f0"
  :keywords '("wp" "text" "shiftjis" "mlt" "yaruo")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
