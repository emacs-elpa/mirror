;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-sonarlint" "0.1.0"
  "Emacs Sonarlint lsp client."
  '((emacs    "25")
    (dash     "2.12.0")
    (lsp-mode "6.3")
    (ht       "2.3"))
  :url "https://github.com/emacs-lsp/lsp-sonarlint"
  :commit "a429be2aea7797369a3c751ef54e3554733117be"
  :revdesc "a429be2aea77"
  :keywords '("languages" "tools" "php" "javascript" "xml" "ruby" "html" "scala" "java" "python")
  :authors '(("Fermin MF" . "fmfs@posteo.net"))
  :maintainers '(("Fermin MF" . "fmfs@posteo.net")))
