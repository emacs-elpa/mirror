;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cil-mode" "0.4"
  "Common Intermediate Language mode."
  ()
  :url "https://github.com/ForNeVeR/cil-mode"
  :commit "a78a88ca9a66a82f069329a96e34b67478ae2d9b"
  :revdesc "a78a88ca9a66"
  :keywords '("languages")
  :authors '(("Friedrich von Never" . "friedrich@fornever.me"))
  :maintainers '(("Friedrich von Never" . "friedrich@fornever.me")))
