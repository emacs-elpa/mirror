;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "1.6.0"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "4e359ce9fbed7a307240411c61782e37e84aa9e1"
  :revdesc "4e359ce9fbed"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
