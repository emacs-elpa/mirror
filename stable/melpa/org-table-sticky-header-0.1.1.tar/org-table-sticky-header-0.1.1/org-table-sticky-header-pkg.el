;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-table-sticky-header" "0.1.1"
  "Sticky header for org-mode tables."
  '((org "8.2.10"))
  :url "https://github.com/cute-jumper/org-table-sticky-header"
  :commit "4dba2dc9a3ed63f58aa946aeec84a52d46ca4043"
  :revdesc "4dba2dc9a3ed"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
