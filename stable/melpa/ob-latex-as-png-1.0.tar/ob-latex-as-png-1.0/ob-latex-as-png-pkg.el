;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-latex-as-png" "1.0"
  "Org-babel functions for latex-as-png evaluation."
  '((emacs "26.1")
    (org   "9.1"))
  :url "https://github.com/alhassy/ob-latex-as-png"
  :commit "f899a89d3ac48d17c79818ca41a1d86885c948d2"
  :revdesc "f899a89d3ac4"
  :keywords '("literate programming" "reproducible research" "org" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
