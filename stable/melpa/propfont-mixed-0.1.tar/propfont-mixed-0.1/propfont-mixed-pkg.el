;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "propfont-mixed" "0.1"
  "Use proportional fonts with space-based indentation."
  ()
  :url "https://github.com/ikirill/propfont-mixed"
  :commit "b96ff15368dd70007a031545b76a87be0ad05ef3"
  :revdesc "b96ff15368dd"
  :keywords '("faces")
  :authors '(("Kirill Ignatiev" . "github.com/ikirill"))
  :maintainers '(("Kirill Ignatiev" . "github.com/ikirill")))
