;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.5.3"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "af234cc3b741eda11016a666c03ab238e8763bf2"
  :revdesc "v4.5.3-0-gaf234cc3b741"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
