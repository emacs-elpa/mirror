;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hy-mode" "1.0.4"
  "Major mode for Hylang."
  '((dash            "2.13.0")
    (dash-functional "1.2.0")
    (s               "1.11.0")
    (emacs           "24"))
  :url "https://github.com/hylang/hy-mode"
  :commit "e2d5fecdaec602788aa7123ed13651c888b8d94b"
  :revdesc "e2d5fecdaec6"
  :keywords '("languages" "lisp" "python")
  :authors '(("Julien Danjou" . "julien@danjou.info")
             ("Eric Kaschalk" . "ekaschalk@gmail.com"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")
                 ("Eric Kaschalk" . "ekaschalk@gmail.com")))
