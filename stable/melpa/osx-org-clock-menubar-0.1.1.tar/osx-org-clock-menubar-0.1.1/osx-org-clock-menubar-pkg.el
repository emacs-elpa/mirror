;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-org-clock-menubar" "0.1.1"
  "Simple menubar integration for org-clock."
  ()
  :url "www.github.com/jordonbiondo/.emacs.d"
  :commit "f6e9d80f9e8bd3bb827051a2eb121bb574d24c59"
  :revdesc "f6e9d80f9e8b"
  :keywords '("org" "osx")
  :authors '(("Jordon Biondo" . "jordonbiondo@gmail.com"))
  :maintainers '(("Jordon Biondo" . "jordonbiondo@gmail.com")))
