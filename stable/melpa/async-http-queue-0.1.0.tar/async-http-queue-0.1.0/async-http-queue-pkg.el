;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async-http-queue" "0.1.0"
  "Async HTTP queue with parallel fetching."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/async-http-queue-el"
  :commit "bd37342372a0b24ce0d54e9dad8070af997b0a0b"
  :revdesc "bd37342372a0"
  :keywords '("comm" "processes" "http")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
