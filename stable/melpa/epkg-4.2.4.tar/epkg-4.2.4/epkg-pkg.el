;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "4.2.4"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.0")
    (closql   "2.4")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "20d401d600e84e110fe4d2957dd389352e011ea3"
  :revdesc "v4.2.4-0-g20d401d600e8"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
