;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-alchemist" "0.1"
  "Auto-complete source for alchemist."
  '((auto-complete "1.5.0")
    (alchemist     "1.3.1")
    (cl-lib        "0.5"))
  :url "https://github.com/syohex/emacs-ac-alchemist"
  :commit "31114f3e1e7cc1e101d0b81819d7876d8861df92"
  :revdesc "31114f3e1e7c"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
