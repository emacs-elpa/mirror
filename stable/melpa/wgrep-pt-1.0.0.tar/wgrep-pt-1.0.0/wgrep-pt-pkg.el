;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wgrep-pt" "1.0.0"
  "Writable pt buffer."
  '((emacs "25.1")
    (wgrep "3.0.0"))
  :url "https://github.com/mhayashi1120/Emacs-wgrep/raw/master/wgrep-pt.el"
  :commit "ff3cf631b6842432daa59bf604049ca916cce73b"
  :revdesc "ff3cf631b684"
  :keywords '("grep" "edit" "extensions")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")
             ("Bailey Ling" . "bling@live.ca"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")
                 ("Bailey Ling" . "bling@live.ca")))
