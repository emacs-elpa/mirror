;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-exit-target" "0.0.1"
  "Commands and keys for selecting other window and frame targets within ido."
  '((emacs "24.4"))
  :url "https://github.com/waymondo/ido-exit-target"
  :commit "e19cc07166507aaf851f3693b71c4e2c1031f990"
  :revdesc "e19cc0716650"
  :keywords '("convenience" "tools" "extensions")
  :authors '(("justin talbott" . "justin@waymondo.com"))
  :maintainers '(("justin talbott" . "justin@waymondo.com")))
