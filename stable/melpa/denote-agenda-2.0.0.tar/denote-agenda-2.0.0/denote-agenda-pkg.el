;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-agenda" "2.0.0"
  "Integrate Denote and Org-Agenda."
  '((emacs  "27.1")
    (denote "3.1.0")
    (seq    "2.24"))
  :url "https://git.sr.ht/~swflint/denote-agenda"
  :commit "90876a96663c1cb8baf4281e79aea51a95bd5be6"
  :revdesc "90876a96663c"
  :keywords '("calendar")
  :authors '(("Samuel W. Flint" . "swflint@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "swflint@samuelwflint.com")))
