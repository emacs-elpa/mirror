;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-aibo" "0.0.1"
  "An AI Writing Assistant."
  '((emacs "27.1")
    (gptel "0.9.0"))
  :url "https://github.com/dolmens/gptel-aibo"
  :commit "afb861b7ffe5ff18f94bea26f366946f13944813"
  :revdesc "afb861b7ffe5"
  :keywords '("emacs" "tools" "editing" "gptel" "ai" "assistant" "code-completion" "productivity")
  :authors '(("Sun Yi Ming" . "dolmens@gmail.com"))
  :maintainers '(("Sun Yi Ming" . "dolmens@gmail.com")))
