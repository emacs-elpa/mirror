;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "1.0.5"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "f0583c0ca6a9c155ea0037c9c59e0665a884e33d"
  :revdesc "1.0.5-0-gf0583c0ca6a9"
  :keywords '("docs" "startdict" "sdcv"))
