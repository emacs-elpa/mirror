;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-commentary" "2.2.0"
  "Comment stuff out. A port of vim-commentary."
  '((evil "1.0.0"))
  :url "https://github.com/linktohack/evil-commentary"
  :commit "ca182e27156198db533bf6d48b7e5f6f54081397"
  :revdesc "ca182e271561"
  :keywords '("evil" "comment" "commentary" "evil-commentary")
  :authors '(("Quang Linh LE" . "linktohack@gmail.com"))
  :maintainers '(("Quang Linh LE" . "linktohack@gmail.com")))
