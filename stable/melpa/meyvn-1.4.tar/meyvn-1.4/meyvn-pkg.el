;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meyvn" "1.4"
  "Meyvn client."
  '((emacs      "25.1")
    (cider      "0.23")
    (projectile "2.1")
    (s          "1.12")
    (dash       "2.17")
    (parseedn   "1.1.0")
    (parseclj   "1.1.0")
    (geiser     "0.12"))
  :url "https://github.com/danielsz/meyvn-el"
  :commit "62802ab42ee021f89f980bd3de3e1336ad760944"
  :revdesc "62802ab42ee0"
  :authors '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com"))
  :maintainers '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com")))
