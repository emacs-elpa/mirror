;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "language-id" "0.20"
  "Library to work with programming language identifiers."
  '((emacs "24.3"))
  :url "https://github.com/lassik/emacs-language-id"
  :commit "1ad782d7e448c1e8d8652861f01f4a58315826c3"
  :revdesc "1ad782d7e448"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
