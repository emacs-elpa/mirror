;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons-ivy-rich" "1.0.0"
  "Excellent experience with nerd icons for ivy/counsel."
  '((emacs      "26.1")
    (ivy-rich   "0.1.0")
    (nerd-icons "0.0.1"))
  :url "https://github.com/seagle0128/nerd-icons-ivy-rich"
  :commit "ecf86cea522a551bf9a0eb10088b84cc84cce29d"
  :revdesc "ecf86cea522a"
  :keywords '("convenience" "icons" "ivy")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
