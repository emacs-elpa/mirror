;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shelltest-mode" "1.1"
  "Major mode for shelltestrunner."
  ()
  :url "https://github.com/rtrn/shelltest-mode"
  :commit "fead97c7ff1b39715ec033a793de41176f1788f5"
  :revdesc "fead97c7ff1b"
  :keywords '("languages")
  :authors '(("Dustin Fechner" . "fechnedu@gmail.com"))
  :maintainers '(("Dustin Fechner" . "fechnedu@gmail.com")))
