;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "com-css-sort" "0.0.7"
  "Common way of sorting the CSS attributes."
  '((emacs "25.1")
    (s     "1.12.0"))
  :url "https://github.com/jcs090218/com-css-sort"
  :commit "61244e12594f117ffac047454311212604399d52"
  :revdesc "61244e12594f"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
