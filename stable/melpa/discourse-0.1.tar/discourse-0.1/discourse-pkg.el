;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "discourse" "0.1"
  "Discourse api."
  '((cl-lib  "0.5")
    (request "0.2")
    (s       "20160508.2357"))
  :url "https://github.com/lujun9972/discourse.el"
  :commit "5c0fccfe2fb51d8bc1aff70982c288db511d2e62"
  :revdesc "5c0fccfe2fb5"
  :keywords '("lisp" "discourse")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
