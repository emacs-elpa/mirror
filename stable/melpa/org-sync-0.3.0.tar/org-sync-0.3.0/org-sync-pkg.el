;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-sync" "0.3.0"
  "Synchronize Org documents with External Issue Trackers."
  '((cl-lib "0.5")
    (org    "8.2")
    (emacs  "24"))
  :url "https://github.com/arbox/org-sync"
  :commit "8c65dceaa2f3d436f83ed591916f22556a6e7f91"
  :revdesc "8c65dceaa2f3"
  :keywords '("org" "synchronization" "issue tracking" "github" "redmine")
  :authors '(("Aurelien Aptel" . "aureliendotaptelatgmaildotcom"))
  :maintainers '(("Andrei Beliankou" . "arbox@yandex.ru")))
