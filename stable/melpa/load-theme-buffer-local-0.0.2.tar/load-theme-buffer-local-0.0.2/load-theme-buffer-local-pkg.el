;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "load-theme-buffer-local" "0.0.2"
  "Install emacs24 color themes by buffer."
  ()
  :url "https://github.com/vic/color-theme-buffer-local"
  :commit "99bb63923050c37fbdb6d61bd693da49c4705764"
  :revdesc "99bb63923050"
  :keywords '("faces")
  :authors '(("Victor Borja" . "vic.borja@gmail.com"))
  :maintainers '(("Victor Borja" . "vic.borja@gmail.com")))
