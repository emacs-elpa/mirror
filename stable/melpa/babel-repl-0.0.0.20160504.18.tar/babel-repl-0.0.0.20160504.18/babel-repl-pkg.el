;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "babel-repl" "0.0.0.20160504.18"
  "Run babel REPL."
  '((emacs "24"))
  :url "https://github.com/hung-phan/babel-repl/"
  :commit "0faa2f6518a2b46236f116ca1736a314f7d9c034"
  :revdesc "0faa2f6518a2"
  :keywords '("babel" "javascript" "es6"))
