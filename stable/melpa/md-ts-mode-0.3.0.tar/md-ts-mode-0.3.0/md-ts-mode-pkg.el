;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "md-ts-mode" "0.3.0"
  "Major mode for Markdown using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/dnouri/md-ts-mode"
  :commit "209f7b89383169ad759ba6bec8642d3fc15ce212"
  :revdesc "v0.3.0-0-g209f7b893831"
  :keywords '("markdown" "languages" "tree-sitter")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
