;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tiles" "0.5"
  "Tagged Instant Lightweight Emacs Snippets."
  '((emacs "27.1"))
  :url "https://github.com/ctanas/tiles"
  :commit "15fa6fa0f2b44b0db0110862b609a42aabb8bb40"
  :revdesc "15fa6fa0f2b4"
  :keywords '("files" "text" "convenience")
  :authors '(("Claudiu Tănăselia" . "https://www.tanaselia.ro"))
  :maintainers '(("Claudiu Tănăselia" . "https://www.tanaselia.ro")))
