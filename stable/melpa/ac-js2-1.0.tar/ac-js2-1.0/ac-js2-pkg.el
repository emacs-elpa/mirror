;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-js2" "1.0"
  "Autocomplete source for Js2-mode."
  '((js2-mode      "20090723")
    (auto-complete "1.4")
    (skewer-mode   "1.3"))
  :url "https://github.com/ScottyB/ac-js2"
  :commit "a1d1139afad0952afe4c76db1dd8ac3fa0786fcf"
  :revdesc "a1d1139afad0"
  :authors '(("Scott Barnett" . "scott.n.barnett@gmail.com"))
  :maintainers '(("Scott Barnett" . "scott.n.barnett@gmail.com")))
