;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php" "2.8.2"
  "Auto Completion source for PHP."
  '((ac-php-core   "2.0")
    (auto-complete "1.4.0")
    (yasnippet     "0.8.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "579063ac92f3cba9816edd31f24c759aac3a64b2"
  :revdesc "v2.8.2-0-g579063ac92f3"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
