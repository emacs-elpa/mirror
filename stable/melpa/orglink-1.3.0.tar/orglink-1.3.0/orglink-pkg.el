;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orglink" "1.3.0"
  "Use Org Mode links in other modes."
  '((emacs  "28.1")
    (compat "31.0")
    (llama  "1.0")
    (org    "9.8")
    (seq    "2.24"))
  :url "https://github.com/tarsius/orglink"
  :commit "e4805628e731021cf360ae7e61dcb40ae1e1992f"
  :revdesc "v1.3.0-0-ge4805628e731"
  :keywords '("hypermedia")
  :authors '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev")))
