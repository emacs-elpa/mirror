;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "igv" "0.1"
  "[No description available]."
  ()
  :commit "1e744c89402fde2c7f48d8550929b99f49993c24"
  :revdesc "1e744c89402f"
  :authors '(("Stefano Barbi" . "stefanobarbi@gmail.com"))
  :maintainers '(("Stefano Barbi" . "stefanobarbi@gmail.com")))
