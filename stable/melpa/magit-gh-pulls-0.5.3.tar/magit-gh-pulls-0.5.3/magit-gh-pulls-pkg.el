;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gh-pulls" "0.5.3"
  "GitHub pull requests extension for Magit."
  '((emacs  "24.4")
    (gh     "0.9.1")
    (magit  "2.1.0")
    (pcache "0.2.3")
    (s      "1.6.1"))
  :url "https://github.com/sigma/magit-gh-pulls"
  :commit "d526f4c9ee1709c79f8a4630699ce1f25ae054e7"
  :revdesc "d526f4c9ee17"
  :keywords '("git" "tools")
  :authors '(("Yann Hodique" . "yann.hodique@gmail.com"))
  :maintainers '(("Yann Hodique" . "yann.hodique@gmail.com")))
