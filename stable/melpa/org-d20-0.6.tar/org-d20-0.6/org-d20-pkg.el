;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-d20" "0.6"
  "Minor mode for d20 tabletop roleplaying games."
  '((s     "1.11.0")
    (seq   "2.19")
    (dash  "2.12.0")
    (emacs "24"))
  :url "https://spwhitton.name/tech/code/org-d20/"
  :commit "ad399cde0ee21adc67ed0c95ae20900fa936f008"
  :revdesc "0.6-0-gad399cde0ee2"
  :keywords '("outlines" "games")
  :authors '(("Sean Whitton" . "spwhitton@spwhitton.name"))
  :maintainers '(("Sean Whitton" . "spwhitton@spwhitton.name")))
