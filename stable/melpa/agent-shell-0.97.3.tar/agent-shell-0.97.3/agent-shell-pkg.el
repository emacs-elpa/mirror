;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.97.3"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.3")
    (acp         "0.19.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "f24f7ccb8f710709c2cb198df568a942af83350d"
  :revdesc "f24f7ccb8f71")
