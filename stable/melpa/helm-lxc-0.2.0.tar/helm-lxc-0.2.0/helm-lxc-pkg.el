;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-lxc" "0.2.0"
  "Helm interface to manage LXC containers."
  '((emacs     "25")
    (cl-lib    "0.5")
    (helm      "2.9.4")
    (lxc-tramp "0.2.0"))
  :url "https://github.com/montag451/helm-lxc"
  :commit "02812daf09d5ffb02abef7a8e0fa1f7b7c472d67"
  :revdesc "02812daf09d5"
  :keywords '("helm" "lxc" "convenience"))
