;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clingo-mode" "0.4.0"
  "A major mode for editing Answer Set Programs."
  '((emacs "24.3"))
  :url "https://github.com/llaisdy/clingo-mode"
  :commit "9773d4e22acd9ddf6f159ee5634212f4ab4575ea"
  :revdesc "0.4.0-0-g9773d4e22acd"
  :keywords '("asp" "clingo" "answer set programs" "potassco" "major mode" "languages")
  :authors '(("Ivan Uemlianin" . "ivan@llaisdy.com"))
  :maintainers '(("Ivan Uemlianin" . "ivan@llaisdy.com")))
