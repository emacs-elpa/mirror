;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-forward" "1.0.0"
  "Semantic navigatioin."
  '((expand-region "0.8.0"))
  :url "https://github.com/magnars/smart-forward.el"
  :commit "5835c5057e320cdd66b33d46ff38effd3d66232a"
  :revdesc "5835c5057e32"
  :keywords '("navigation")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
