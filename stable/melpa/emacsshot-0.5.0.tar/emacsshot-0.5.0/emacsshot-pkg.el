;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsshot" "0.5.0"
  "Snapshot a frame or window from within."
  '((emacs "24.4"))
  :url "https://github.com/marcowahl/emacsshot"
  :commit "f0add6820d250875f7d7c21aa5d813dc73dbcf96"
  :revdesc "f0add6820d25"
  :keywords '("convenience")
  :authors '(("Marco Wahl" . "marcowahlsoft@gmail.com")))
