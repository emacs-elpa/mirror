;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "29.0.1"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "f26c7e590c5d1b3afa0dee38093442df117822e3"
  :revdesc "OTP-29.0.1-0-gf26c7e590c5d"
  :keywords '("erlang" "languages" "processes"))
