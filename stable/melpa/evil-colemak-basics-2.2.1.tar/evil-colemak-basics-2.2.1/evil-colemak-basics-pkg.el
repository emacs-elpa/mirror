;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-colemak-basics" "2.2.1"
  "Basic Colemak key bindings for evil-mode."
  '((emacs      "24.3")
    (evil       "1.2.12")
    (evil-snipe "2.0.3"))
  :url "https://github.com/wbolster/evil-colemak-basics"
  :commit "05c023740f3d95805533081894bfd87f06401af5"
  :revdesc "2.2.1-0-g05c023740f3d"
  :keywords '("convenience" "emulations" "colemak" "evil")
  :authors '(("Wouter Bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("Wouter Bolsterlee" . "wouter@bolsterl.ee")))
