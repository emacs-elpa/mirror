;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "build-helper" "0.1"
  "[No description available]."
  ()
  :url "https://github.com/afonso360/build-helper"
  :commit "8f0acd7d18c0afbc578af8c336f93bb425ce4456"
  :revdesc "8f0acd7d18c0"
  :authors '(("Afonso Bordado" . "afonsobordado@az8.co"))
  :maintainers '(("Afonso Bordado" . "afonsobordado@az8.co")))
