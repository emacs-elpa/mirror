;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cloc" "2015.9.12"
  "Count lines of code over emacs buffers."
  '((cl-lib "0.5"))
  :url "https://github.com/cosmicexplorer/cloc-emacs"
  :commit "5e5aecaecf64b563a5f181a88aeada6023d9496b"
  :revdesc "5e5aecaecf64"
  :keywords '("cloc" "count" "source" "code" "lines")
  :authors '(("Danny McClanahan" . "danieldmcclanahan@gmail.com"))
  :maintainers '(("Danny McClanahan" . "danieldmcclanahan@gmail.com")))
