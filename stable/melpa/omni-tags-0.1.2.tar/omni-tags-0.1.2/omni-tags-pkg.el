;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "omni-tags" "0.1.2"
  "Highlight and Actions for 'Tags'."
  '((pcre2el "1.7")
    (cl-lib  "0.5"))
  :url "https://github.com/AdrieanKhisbe/omni-tags.el"
  :commit "a7078bfbc9a6256efd0e57530df9fd7808bc2185"
  :revdesc "v0.1.2-0-ga7078bfbc9a6"
  :keywords '("convenience")
  :authors '(("Adrien Becchis" . "adriean.khisbe@live.fr"))
  :maintainers '(("Adrien Becchis" . "adriean.khisbe@live.fr")))
