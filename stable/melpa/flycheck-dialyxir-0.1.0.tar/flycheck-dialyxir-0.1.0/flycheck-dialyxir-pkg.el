;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-dialyxir" "0.1.0"
  "Flycheck checker for elixir dialyxir."
  '((flycheck "29"))
  :url "https://github.com/aaronjensen/flycheck-dialyxir"
  :commit "7e79dc33a12b8aded7a86d64d302072eed522cb4"
  :revdesc "7e79dc33a12b"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
