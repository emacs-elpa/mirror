;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "state" "0.1"
  "Quick navigation between workspaces."
  '((emacs "24"))
  :url "https://github.com/thisirs/state.git"
  :commit "0778c55536789be8b8a70fb45e97cb4636795ced"
  :revdesc "0778c5553678"
  :keywords '("convenience" "workspaces")
  :authors '(("Sylvain Rousseau" . "thisirsatgmaildotcom"))
  :maintainers '(("Sylvain Rousseau" . "thisirsatgmaildotcom")))
