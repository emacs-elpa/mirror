;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-gutter-fringe" "0.23"
  "Fringe version of git-gutter.el."
  '((git-gutter    "0.88")
    (fringe-helper "0.1.1")
    (cl-lib        "0.5")
    (emacs         "24"))
  :url "https://github.com/syohex/emacs-git-gutter-fringe"
  :commit "dfc93d1064df154a809aab350942830408051da3"
  :revdesc "dfc93d1064df"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
