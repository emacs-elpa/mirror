;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ext" "0.1.2"
  "A few extensions to Helm."
  '((emacs "24.4")
    (helm  "2.5.3"))
  :url "https://github.com/cute-jumper/helm-ext"
  :commit "c8ac56918b200239b3f73a4e6a031deecc2c5646"
  :revdesc "c8ac56918b20"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
