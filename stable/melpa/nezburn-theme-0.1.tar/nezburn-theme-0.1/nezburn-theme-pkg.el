;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nezburn-theme" "0.1"
  "A low contrast color theme for Emacs (inspired by zenburn)."
  ()
  :url "https://github.com/lanjoni/nezburn"
  :commit "b2560838ceb1d8cb24b3bb864996d48b1a25cb83"
  :revdesc "b2560838ceb1"
  :authors '(("João Lanjoni" . "joaoaugustolanjoni@gmail.com"))
  :maintainers '(("João Lanjoni" . "joaoaugustolanjoni@gmail.com")))
