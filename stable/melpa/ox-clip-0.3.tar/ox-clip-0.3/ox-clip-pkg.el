;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-clip" "0.3"
  "Cross-platform Formatted copy commands for org-mode."
  '((org     "8.2")
    (htmlize "0"))
  :url "https://github.com/jkitchin/scimax/ox-clip.el"
  :commit "9b0cf05facb33a1f6732ff4d01d6786c108bdef2"
  :revdesc "9b0cf05facb3"
  :keywords '("org-mode")
  :authors '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainers '(("John Kitchin" . "jkitchin@andrew.cmu.edu")))
