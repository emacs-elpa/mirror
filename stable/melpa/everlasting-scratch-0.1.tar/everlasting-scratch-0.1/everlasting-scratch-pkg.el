;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "everlasting-scratch" "0.1"
  "The *scratch* that lasts forever."
  '((emacs "25.1"))
  :url "https://github.com/beacoder/everlasting-scratch"
  :commit "509cf24422d4047b110aac8ed077b52a8011cfe7"
  :revdesc "509cf24422d4"
  :keywords '("convenience" "tool")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
