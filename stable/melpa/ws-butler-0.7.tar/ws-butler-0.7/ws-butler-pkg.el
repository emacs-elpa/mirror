;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ws-butler" "0.7"
  "Unobtrusively remove trailing whitespace."
  ()
  :url "https://github.com/lewang/ws-butler"
  :commit "d3927f6131f215e9cd3e1f747be5a91e5be8ca9a"
  :revdesc "v0.7-0-gd3927f6131f2")
