;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "luarocks" "0.1"
  "Luarocks tools."
  '((emacs "24.4"))
  :url "https://github.com/emacs-pe/luarocks.el"
  :commit "814a001112e4187512dfce800a79f031755fc165"
  :revdesc "814a001112e4"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
