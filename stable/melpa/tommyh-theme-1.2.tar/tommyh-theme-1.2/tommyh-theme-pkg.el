;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tommyh-theme" "1.2"
  "A bright, bold-colored theme for emacs."
  ()
  :url "https://github.com/wglass/tommyh-theme"
  :commit "3796843254c890240fba168f952d261160dbaa0c"
  :revdesc "3796843254c8"
  :authors '(("William Glass" . "william.glass@gmail.com"))
  :maintainers '(("William Glass" . "william.glass@gmail.com")))
