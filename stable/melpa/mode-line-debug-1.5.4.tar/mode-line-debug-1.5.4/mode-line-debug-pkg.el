;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mode-line-debug" "1.5.4"
  "Show status of debug-on-error in mode-line."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/tarsius/mode-line-debug"
  :commit "c582d0523e98eca0a7382df11ce73aae80f24120"
  :revdesc "v1.5.4-0-gc582d0523e98"
  :keywords '("convenience" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.mode-line-debug@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.mode-line-debug@jonas.bernoulli.dev")))
