;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "isgd" "1.1"
  "Shorten URLs using the isgd.com shortener service."
  ()
  :url "https://github.com/chmouel/isgd.el"
  :commit "764306dadd5a9213799081a48aba22f7c75cca9a"
  :revdesc "764306dadd5a"
  :authors '(("Chmouel Boudjnah" . "chmouel@chmouel.com"))
  :maintainers '(("Chmouel Boudjnah" . "chmouel@chmouel.com")))
