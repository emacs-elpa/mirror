;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dim" "0.1"
  "Change mode-line names of major/minor modes."
  '((emacs "24.4"))
  :url "https://github.com/alezost/dim.el"
  :commit "0c19a510580ebdc77e6db536f0f8ed2840b9b33e"
  :revdesc "0c19a510580e"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
