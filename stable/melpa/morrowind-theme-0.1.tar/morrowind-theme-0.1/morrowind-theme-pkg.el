;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morrowind-theme" "0.1"
  "Theme."
  '((emacs "24"))
  :url "https://github.com/samuelbanya/morrowind-theme"
  :commit "5dd3e5663d8fe911ad068acbc9b5a915741192c4"
  :revdesc "5dd3e5663d8f")
