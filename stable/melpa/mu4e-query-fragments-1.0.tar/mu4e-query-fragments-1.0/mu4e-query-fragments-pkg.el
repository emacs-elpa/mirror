;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-query-fragments" "1.0"
  "Mu4e query fragments extension."
  '((emacs "24.4")
    (mu4e  "0"))
  :url "https://github.com/wavexx/mu4e-query-fragments.el"
  :commit "0b56ecce9cb6aa91dc53a49a2a286e4f8f5df6d6"
  :revdesc "0b56ecce9cb6"
  :keywords '("mu4e" "mail" "convenience")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
