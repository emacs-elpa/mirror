;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dhall-mode" "0.1.3"
  "A major mode for dhall configuration language."
  '((emacs      "24.4")
    (ansi-color "3.0"))
  :url "https://github.com/psibi/dhall-mode"
  :commit "181e5b0df73ce729cf4b711fa76bb43c2581d29d"
  :revdesc "181e5b0df73c"
  :keywords '("languages")
  :authors '(("Sibi Prabakaran" . "sibi@psibi.in"))
  :maintainers '(("Sibi Prabakaran" . "sibi@psibi.in")))
