;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "path-headerline-mode" "0.0.2"
  "Displaying file path on headerline."
  ()
  :url "https://github.com/7696122/path-headerline-mode"
  :commit "406191ef1fca8d5d01a788d7cd2d726ec4934aee"
  :revdesc "406191ef1fca"
  :keywords '("headerline"))
