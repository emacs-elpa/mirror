;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-defined" "0.1.6"
  "Syntax highlighting of known Elisp symbols."
  '((emacs "24"))
  :url "https://github.com/Fanael/highlight-defined"
  :commit "4420bdda419875dacb065468aafe273b2022580e"
  :revdesc "4420bdda4198"
  :authors '(("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers '(("Fanael Linithien" . "fanael4@gmail.com")))
