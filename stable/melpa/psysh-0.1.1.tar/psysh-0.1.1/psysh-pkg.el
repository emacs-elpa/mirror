;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "psysh" "0.1.1"
  "PsySH, PHP interactive shell (REPL)."
  '((emacs       "24.3")
    (s           "1.9.0")
    (php-runtime "0.2"))
  :url "https://github.com/emacs-php/psysh.el"
  :commit "796b26a5cd75df9d2ecb206718b310ff21787063"
  :revdesc "796b26a5cd75"
  :keywords '("processes" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
