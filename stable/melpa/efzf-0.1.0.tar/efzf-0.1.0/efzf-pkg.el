;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "efzf" "0.1.0"
  "Emacs-based fuzzy finder for the command line."
  '((emacs "29.1"))
  :url "https://github.com/yoshinari-nomura/efzf"
  :commit "ca7a353f286477ee5df591570cfe2709b7d9319b"
  :revdesc "ca7a353f2864"
  :keywords '("convenience" "matching" "terminals")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
