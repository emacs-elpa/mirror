;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "defproject" "0.1.0"
  "Manager dir-locals and project specific variables."
  ()
  :url "https://github.com/kotfic/defproject"
  :commit "7b0b4d929c0ee0fe1dee59895fe23ab274eff593"
  :revdesc "7b0b4d929c0e"
  :keywords '("convenience")
  :authors '((nil . "kotfic@gmail.com"))
  :maintainers '((nil . "kotfic@gmail.com")))
