;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdffontetc" "0.15"
  "Display `pdffont' and other PDF information."
  '((emacs "24.4"))
  :url "https://github.com/emacsomancer/pdffontetc"
  :commit "3fc7cdc5b6d5af56b86fa859ac9e9d892d77d597"
  :revdesc "3fc7cdc5b6d5"
  :keywords '("files" "multimedia")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
