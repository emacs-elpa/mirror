;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab" "3.7.0"
  "An interface for GitLab."
  '((emacs       "27.1")
    (request     "0.3.2")
    (s           "1.10.0")
    (f           "0.20.0")
    (compat      "29.1.4.4")
    (promise     "1.1")
    (async-await "1.1"))
  :url "https://github.com/isamert/lab.el"
  :commit "aa3af6f8e2eb16edac2b680ecddf4823f94287de"
  :revdesc "v3.7.0-0-gaa3af6f8e2eb"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
