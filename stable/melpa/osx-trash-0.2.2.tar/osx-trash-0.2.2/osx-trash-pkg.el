;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-trash" "0.2.2"
  "System trash for OS X."
  '((emacs "24.1"))
  :url "https://github.com/lunaryorn/osx-trash.el"
  :commit "90f0c99206022fec646206018fcd63d9d2e57325"
  :revdesc "0.2.2-0-g90f0c9920602"
  :keywords '("files" "convenience" "tools" "unix")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
