;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pink-bliss-uwu-theme" "1.0.0"
  "Pink color theme."
  '((emacs "24.1"))
  :url "https://github.com/themkat/pink-bliss-uwu"
  :commit "0557b322b9f70b42b7f47c4cdf110a6f201d3620"
  :revdesc "0557b322b9f7")
