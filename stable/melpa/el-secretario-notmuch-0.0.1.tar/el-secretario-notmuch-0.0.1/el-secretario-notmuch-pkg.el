;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-secretario-notmuch" "0.0.1"
  "[No description available]."
  '((emacs  "26.1")
    (cl-lib "0.5"))
  :url "https://github.com/leo/el-secretario-notmuch"
  :commit "83a7cc5283756709bba0593c3fd5071738c79c95"
  :revdesc "83a7cc528375"
  :authors '(("Leo" . "http://github/leo"))
  :maintainers '(("Leo" . "leo@leo-B85-HD3")))
