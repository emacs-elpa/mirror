;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.89.6"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "cd2b38ddc4c7664eaad47b5e3aa2e4ba7bc2a7dc"
  :revdesc "cd2b38ddc4c7")
