;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "night-owl-theme" "0.1.0"
  "A color theme for the night owls out there."
  '((emacs "24"))
  :url "https://github.com/aaronjensen/night-owl-theme"
  :commit "3d1b6b319173c2f0aaf42a294ab01fba473f11c4"
  :revdesc "v0.1.0-0-g3d1b6b319173"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
