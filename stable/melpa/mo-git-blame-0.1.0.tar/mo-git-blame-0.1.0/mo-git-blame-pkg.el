;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mo-git-blame" "0.1.0"
  "[No description available]."
  ()
  :url "https://codeberg.org/mbunkus/mo-git-blame"
  :commit "2424eae2fff2bf9953c5d851df09f9874e90cdd1"
  :revdesc "2424eae2fff2"
  :keywords '("tools")
  :authors '(("Moritz Bunkus" . "moritz@bunkus.org"))
  :maintainers '(("Moritz Bunkus" . "moritz@bunkus.org")))
