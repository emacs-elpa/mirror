;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lirve" "1.5.0"
  "Learn irregular verbs in English."
  '((emacs "26.1"))
  :url "https://git.andros.dev/andros/lirve.el"
  :commit "1edfd36867bbcc8e9877280a16041223df72a49f"
  :revdesc "1edfd36867bb"
  :authors '(("Andros Fenollosa" . "andros@fenollosa.email"))
  :maintainers '(("Andros Fenollosa" . "andros@fenollosa.email")))
