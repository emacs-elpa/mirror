;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-ascii-plot" "1.1"
  "Ascii-art bar plots in org-mode tables."
  '((org "7"))
  :url "https://github.com/tbanel/orgtblasciiplot"
  :commit "ab746b5e1406c88606e048e1e76686ab9b8bec69"
  :revdesc "ab746b5e1406"
  :keywords '("org" "table" "ascii" "plot"))
