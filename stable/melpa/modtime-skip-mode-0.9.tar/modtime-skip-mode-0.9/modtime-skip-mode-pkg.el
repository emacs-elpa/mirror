;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modtime-skip-mode" "0.9"
  "Minor mode for disabling modtime and supersession checks on files."
  ()
  :url "github.com/jordonbiondo/modtime-skip-mode"
  :commit "d8ed4bcef40e2f9f539fa857a58ff35c0e174239"
  :revdesc "d8ed4bcef40e"
  :authors '(("Jordon Biondo" . "biondoj@mail.gvsu.edu"))
  :maintainers '(("Jordon Biondo" . "biondoj@mail.gvsu.edu")))
