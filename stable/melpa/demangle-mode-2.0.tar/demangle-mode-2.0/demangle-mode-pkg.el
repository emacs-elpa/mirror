;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "demangle-mode" "2.0"
  "Automatically demangle C++ symbols."
  '((cl-lib "0.1")
    (emacs  "24.3"))
  :url "https://github.com/liblit/demangle-mode"
  :commit "901242db26d00432ba075a2325b389cc847825e2"
  :revdesc "901242db26d0"
  :keywords '("c" "tools")
  :authors '(("Ben Liblit" . "liblit@acm.org"))
  :maintainers '(("Ben Liblit" . "liblit@acm.org")))
