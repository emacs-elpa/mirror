;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-sections" "0.3.0"
  "Universal Sidecar Sections for Denote."
  '((universal-sidecar "1.5.0")
    (denote            "2.2.4")
    (emacs             "27.1"))
  :url "https://git.sr.ht/~swflint/denote-sections"
  :commit "ea81318cf1c7d7281047a6b3a2ac8fb76c8535d7"
  :revdesc "ea81318cf1c7"
  :keywords '("convenience" "files" "notes" "hypermedia")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
