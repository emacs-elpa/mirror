;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "octopress" "1.0"
  "A lightweight wrapper for Jekyll and Octopress."
  ()
  :url "https://github.com/aaronbieber/octopress-mode"
  :commit "c12647df3ee12a392299ac336de0c8f3f1d4d259"
  :revdesc "c12647df3ee1"
  :keywords '("octopress" "blog" "mode")
  :authors '(("Aaron Bieber" . "aaron@aaronbieber.com"))
  :maintainers '(("Aaron Bieber" . "aaron@aaronbieber.com")))
