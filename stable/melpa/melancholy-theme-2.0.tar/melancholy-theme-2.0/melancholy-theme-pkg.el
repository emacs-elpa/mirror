;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "melancholy-theme" "2.0"
  "A dark theme that's pretty sad  -*- lexical-binding: t; -."
  '((emacs "27.1"))
  :url "https://gitlab.com/baaash/melancholy-theme"
  :commit "a5c4360f57793401b63b0df382e845b4845c8f97"
  :revdesc "a5c4360f5779"
  :keywords '("faces" "frames")
  :authors '(("@baaash" . "bleat@baaa.sh"))
  :maintainers '(("@baaash" . "bleat@baaa.sh")))
