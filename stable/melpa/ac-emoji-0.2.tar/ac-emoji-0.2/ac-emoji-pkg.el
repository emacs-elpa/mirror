;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-emoji" "0.2"
  "Auto-complete source of Emoji."
  '((auto-complete "1.5.0")
    (cl-lib        "0.5"))
  :url "https://github.com/syohex/emacs-ac-emoji"
  :commit "53677f754929ead403ccde64b714ebb6b8fc808e"
  :revdesc "53677f754929"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
