;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esh-help" "1.0.1"
  "Add some help functions and support for Eshell."
  '((dash "1.4.0"))
  :url "https://github.com/tom-tan/esh-help/"
  :commit "8a8a9d4d9852f8bd96da3b94e95ff57097ac8ec6"
  :revdesc "v1.0.1-0-g8a8a9d4d9852"
  :keywords '("eshell" "extensions")
  :authors '(("Tomoya Tanjo" . "ttanjo@gmail.com"))
  :maintainers '(("Tomoya Tanjo" . "ttanjo@gmail.com")))
