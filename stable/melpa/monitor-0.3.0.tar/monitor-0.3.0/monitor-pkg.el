;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monitor" "0.3.0"
  "Utilities for monitoring expressions."
  '((dash "2.13.0"))
  :url "https://github.com/guiltydolphin/monitor"
  :commit "8c67c06f60a89b2583bae90afc91a7e7d73260fd"
  :revdesc "8c67c06f60a8"
  :keywords '("lisp" "monitor" "utility")
  :authors '(("Ben Moon" . "guiltydolphin@gmail.com"))
  :maintainers '(("Ben Moon" . "guiltydolphin@gmail.com")))
