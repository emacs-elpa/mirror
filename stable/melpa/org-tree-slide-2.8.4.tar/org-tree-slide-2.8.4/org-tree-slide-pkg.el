;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tree-slide" "2.8.4"
  "A presentation tool for org-mode."
  ()
  :url "https://github.com/takaxp/org-tree-slide"
  :commit "dccd80418a4444df5e8301695ff0d0dfe86a3c21"
  :revdesc "dccd80418a44"
  :keywords '("org-mode" "presentation" "narrowing")
  :authors '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg"))
  :maintainers '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg")))
