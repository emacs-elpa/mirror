;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ipp" "0.8"
  "Implementation of the Internet Printing Protocol."
  '((cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/emarsden/ipp-el"
  :commit "cb26728c32ab78ae926791388a864f528eb7c800"
  :revdesc "cb26728c32ab"
  :keywords '("printing" "hardware")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
