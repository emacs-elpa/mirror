;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tidal" "1.10.3"
  "Interact with TidalCycles for live coding patterns."
  '((haskell-mode "16")
    (emacs        "25.1"))
  :url "https://codeberg.org/uzu/tidal"
  :commit "5ae655255d87c983a596f398a0385b21df97df3b"
  :revdesc "5ae655255d87"
  :keywords '("tools")
  :authors '((nil . "alex@slab.org"))
  :maintainers '((nil . "alex@slab.org")))
