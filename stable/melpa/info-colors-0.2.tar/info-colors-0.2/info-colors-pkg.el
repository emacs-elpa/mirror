;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "info-colors" "0.2"
  "Extra colors for Info-mode."
  '((emacs "24"))
  :url "https://github.com/ubolonton/info-colors"
  :commit "13dd9b6a7288e6bb692b210bcb9cd72016658dae"
  :revdesc "13dd9b6a7288"
  :keywords '("faces")
  :authors '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainers '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")))
