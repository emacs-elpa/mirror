;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "default-text-scale" "0.2"
  "Easily adjust the font size in all frames."
  '((emacs "24"))
  :url "https://github.com/purcell/default-text-scale"
  :commit "f425d3765c4dea3f2e550720278f9d424579ee5d"
  :revdesc "f425d3765c4d"
  :keywords '("frames" "faces")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
