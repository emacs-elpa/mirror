;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ubuntu-theme" "0.5.2"
  "A theme inspired by the default terminal colors in Ubuntu."
  ()
  :url "https://github.com/rocher/ubuntu-theme"
  :commit "4b544f9b38fdfdaa956d3cf510c91573d6a96fd0"
  :revdesc "4b544f9b38fd"
  :authors '(("Francesc Rocher" . "francesc.rocher@gmail.com"))
  :maintainers '(("Francesc Rocher" . "francesc.rocher@gmail.com")))
