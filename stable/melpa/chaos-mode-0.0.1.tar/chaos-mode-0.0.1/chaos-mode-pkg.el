;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chaos-mode" "0.0.1"
  "A major mode for the Chaos programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/chaos-mode"
  :commit "b0bbe08906f0dee52161519e7b0757ba2d533fa3"
  :revdesc "b0bbe08906f0"
  :keywords '("files" "chaos"))
