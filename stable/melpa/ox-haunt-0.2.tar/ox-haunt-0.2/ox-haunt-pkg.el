;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-haunt" "0.2"
  "Haunt-flavored HTML backend for the Org export engine."
  '((emacs "24.3")
    (org   "9.0"))
  :url "https://git.sr.ht/~jakob/ox-haunt"
  :commit "f3c8fda6fee78f45a259e5d218a519dfd11c00c7"
  :revdesc "v0.2-0-gf3c8fda6fee7"
  :keywords '("convenience" "hypermedia" "wp")
  :authors '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org"))
  :maintainers '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org")))
