;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alectryon" "2.0.0"
  "Toggle between Code and markup."
  '((flycheck "31")
    (emacs    "25.1"))
  :url "https://github.com/cpitclaudel/alectryon"
  :commit "86bac4eae28c2d6f27859a4ca8821a374e8b1c4f"
  :revdesc "v2.0.0-0-g86bac4eae28c"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
