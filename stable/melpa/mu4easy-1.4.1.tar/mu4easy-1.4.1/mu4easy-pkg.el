;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4easy" "1.4.1"
  "Packages + configs for using mu4e with multiple accounts."
  '((emacs             "25.1")
    (mu4e-column-faces "1.2.1")
    (mu4e-alert        "1.0")
    (org-msg           "4.0"))
  :url "https://github.com/danielfleischer/mu4easy"
  :commit "5767f6fed2ae077116f2876e872943a3dd5ea788"
  :revdesc "5767f6fed2ae"
  :keywords '("mail")
  :authors '(("Daniel Fleischer" . "danflscr@gmail.com"))
  :maintainers '(("Daniel Fleischer" . "danflscr@gmail.com")))
