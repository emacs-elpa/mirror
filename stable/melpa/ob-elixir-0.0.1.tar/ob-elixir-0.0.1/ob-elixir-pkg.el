;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-elixir" "0.0.1"
  "Org-babel functions for elixir evaluation."
  '((org "8"))
  :url "https://github.com/zweifisch/ob-elixir"
  :commit "20335c714c5b2784ee6a8459713748a4cc47fb35"
  :revdesc "20335c714c5b"
  :keywords '("org" "babel" "elixir")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
