;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "textmate" "1"
  "[No description available]."
  ()
  :url "https://github.com/defunkt/textmate.el"
  :commit "484845493a3c9b570799aea5195a5435a5a01b76"
  :revdesc "484845493a3c"
  :keywords '("textmate" "osx" "mac")
  :authors '(("Chris Wanstrath" . "chris@ozmm.org"))
  :maintainers '(("Chris Wanstrath" . "chris@ozmm.org")))
