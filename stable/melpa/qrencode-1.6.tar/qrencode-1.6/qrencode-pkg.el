;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "1.6"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "3ba67bdf376c9e1445bcc4710c7c8c4bd3c5c65c"
  :revdesc "3ba67bdf376c"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
