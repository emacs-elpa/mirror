;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "drawille" "0.1"
  "Drawille implementation in elisp."
  ()
  :url "https://github.com/sshbio/elisp-drawille"
  :commit "6a6a3e3512a71abf378df1cdc5816da16f775d42"
  :revdesc "6a6a3e3512a7"
  :keywords '("graphics")
  :authors '(("Josuah Demangeon" . "josuah.demangeon@gmail.com"))
  :maintainers '(("Josuah Demangeon" . "josuah.demangeon@gmail.com")))
