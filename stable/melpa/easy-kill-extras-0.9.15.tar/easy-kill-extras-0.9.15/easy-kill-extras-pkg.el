;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-kill-extras" "0.9.15"
  "Extra functions for easy-kill."
  '((easy-kill "0.9.4"))
  :url "https://github.com/knu/easy-kill-extras.el"
  :commit "7aad156fb9017facbe81076c00a07335ee1fec37"
  :revdesc "7aad156fb901"
  :keywords '("killing" "convenience")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
