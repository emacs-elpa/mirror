;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fortune-cookie" "1.0.0"
  "Print a fortune in your scratch buffer."
  ()
  :url "https://github.com/andschwa/fortune-cookie"
  :commit "bad99a2cd090f6646c7ee1125b95dd98744939c6"
  :revdesc "bad99a2cd090"
  :keywords '("fortune" "cowsay" "scratch" "startup")
  :authors '(("Andrew Schwartzmeyer" . "andrew@schwartzmeyer.com"))
  :maintainers '(("Andrew Schwartzmeyer" . "andrew@schwartzmeyer.com")))
