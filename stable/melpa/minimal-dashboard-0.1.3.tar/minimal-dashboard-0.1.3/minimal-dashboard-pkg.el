;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minimal-dashboard" "0.1.3"
  "A very minimal dashboard plugin."
  '((emacs "27.1"))
  :url "https://github.com/dheerajshenoy/minimal-dashboard.el"
  :commit "10fb5881b8d88f6bd2e972a2bc65c8e63a7ac802"
  :revdesc "10fb5881b8d8"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Dheeraj Vittal Shenoy" . "dheerajshenoy22@gmail.com"))
  :maintainers '(("Dheeraj Vittal Shenoy" . "dheerajshenoy22@gmail.com")))
