;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-mmark" "0.1.0"
  "Flycheck checker for MMark markdown processor."
  '((emacs    "24.4")
    (flycheck "0.29"))
  :url "https://github.com/mmark-md/flycheck-mmark"
  :commit "b73b40cb9c5cf6bc6fa501aa87a4c30b210c0c5f"
  :revdesc "b73b40cb9c5c"
  :keywords '("convenience" "text")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
