;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dart-server" "0.1.0"
  "Minor mode for editing Dart files."
  '((emacs    "24.5")
    (cl-lib   "0.5")
    (dash     "2.10.0")
    (flycheck "0.23")
    (s        "1.10"))
  :url "https://github.com/bradyt/dart-server"
  :commit "bbc66eb981d17046ab98584c950baf963ac5da61"
  :revdesc "bbc66eb981d1"
  :keywords '("languages")
  :authors '(("Brady Trainor" . "mail@bradyt.com"))
  :maintainers '(("Brady Trainor" . "mail@bradyt.com")))
