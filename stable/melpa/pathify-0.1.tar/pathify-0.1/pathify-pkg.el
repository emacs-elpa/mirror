;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathify" "0.1"
  "Symlink your scripts into a PATH directory."
  ()
  :url "https://gitlab.com/alezost-emacs/pathify"
  :commit "335332a900717ae01bde5ccb8f3dc97a5350f123"
  :revdesc "335332a90071"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
