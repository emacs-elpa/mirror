;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.87.4"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "99b9922285f5c5c5b38e5e4a0016cb9ef3c16ef7"
  :revdesc "99b9922285f5")
