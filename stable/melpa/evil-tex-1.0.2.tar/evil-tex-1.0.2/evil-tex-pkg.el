;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-tex" "1.0.2"
  "Useful features for editing LaTeX in evil-mode."
  '((emacs  "25.1")
    (evil   "1.0")
    (auctex "11.88"))
  :url "https://github.com/iyefrat/evil-tex"
  :commit "ac313efb22d621c093d8d30233bd7dc8b4cc54b4"
  :revdesc "ac313efb22d6"
  :keywords '("tex" "emulation" "vi" "evil" "wp")
  :authors '(("Yoav Marco" . "https://github.com/ymarco")
             ("Itai Y. Efrat" . "https://github.com/iyefrat"))
  :maintainers '(("Yoav Marco" . "yoavm448@gmail.com")
                 ("Itai Y. Efrat" . "itai3397@gmail.com")))
