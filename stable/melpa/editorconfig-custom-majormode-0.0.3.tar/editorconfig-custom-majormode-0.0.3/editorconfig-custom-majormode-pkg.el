;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "editorconfig-custom-majormode" "0.0.3"
  "Decide major-mode and mmm-mode from EditorConfig."
  '((editorconfig "0.6.0"))
  :url "https://github.com/10sr/editorconfig-custom-major-mode-el"
  :commit "ae613f0a56364afbbab19d4377c108406d5cfc7c"
  :revdesc "ae613f0a5636"
  :keywords '("editorconfig" "util")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
