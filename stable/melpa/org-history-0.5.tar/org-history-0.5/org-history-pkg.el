;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-history" "0.5"
  "Show Dates for Org headers from vcs + auto-commit."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-org-history"
  :commit "518040a62ee8c63e94e7c3147103b0a558c72a29"
  :revdesc "518040a62ee8"
  :keywords '("org" "outline" "vc")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
