;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsc" "1.6.20260930"
  "Helper for emacsc(1)."
  ()
  :url "https://github.com/knu/emacsc"
  :commit "94cee7ce11d7eb699e1619dd02b75e95cacdaaa5"
  :revdesc "v1.6.20260930-0-g94cee7ce11d7"
  :keywords '("tools")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
