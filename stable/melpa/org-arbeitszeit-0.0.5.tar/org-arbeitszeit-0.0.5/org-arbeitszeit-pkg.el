;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-arbeitszeit" "0.0.5"
  "Calculate your worktime."
  '((emacs "27.1"))
  :url "https://github.com/bkaestner/org-arbeitszeit"
  :commit "7f8c50e1dea3595bbf3e79f5a5737f7336478a92"
  :revdesc "7f8c50e1dea3"
  :keywords '("tools" "org" "calendar" "convenience")
  :authors '(("Benjamin Kästner" . "benjamin.kaestner@gmail.com"))
  :maintainers '(("Benjamin Kästner" . "benjamin.kaestner@gmail.com")))
