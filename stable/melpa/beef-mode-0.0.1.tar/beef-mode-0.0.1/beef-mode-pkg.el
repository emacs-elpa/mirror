;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beef-mode" "0.0.1"
  "A major mode for the Beef programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/beef-mode"
  :commit "0f70dd439dac7297611ea43acc861ce11e09432e"
  :revdesc "0f70dd439dac"
  :keywords '("files" "beef"))
