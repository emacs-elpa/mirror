;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arjen-grey-theme" "20150731"
  "A soothing dark grey theme."
  ()
  :url "https://github.com/credmp/arjen-grey"
  :commit "ca3a01e85c9e9a64af936aacddaa29834a0d162b"
  :revdesc "ca3a01e85c9e"
  :keywords '("faces")
  :authors '(("Arjen Wiersma" . "arjen@wiersma.org"))
  :maintainers '(("Arjen Wiersma" . "arjen@wiersma.org")))
