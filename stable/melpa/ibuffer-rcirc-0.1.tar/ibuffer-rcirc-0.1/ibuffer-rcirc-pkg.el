;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-rcirc" "0.1"
  "Ibuffer integration for rcirc."
  '((cl-lib "0.2"))
  :url "https://github.com/fgallina/ibuffer-rcirc"
  :commit "28bfa007d07871d3e369b0ebb0d08823e2a5c032"
  :revdesc "28bfa007d078"
  :keywords '("buffer" "convenience" "comm")
  :authors '(("Fabián Ezequiel Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Fabián Ezequiel Gallina" . "fgallina@gnu.org")))
