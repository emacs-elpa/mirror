;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sentex" "0.2"
  "Regexes for sentence segmentation rules."
  '((emacs "27.1"))
  :url "https://codeberg.org/martianh/sentex"
  :commit "352f5b0fa9fbfd67dccfe5f8484f325d249f4cb4"
  :revdesc "352f5b0fa9fb"
  :keywords '("languages" "convenience" "translation" "sentences" "text" "wp")
  :authors '(("Marty Hiatt" . "martianhiatusATriseup.net"))
  :maintainers '(("Marty Hiatt" . "martianhiatusATriseup.net")))
