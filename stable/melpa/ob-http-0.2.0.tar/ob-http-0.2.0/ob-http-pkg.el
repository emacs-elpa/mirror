;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-http" "0.2.0"
  "Http request in org-mode babel."
  '((s      "1.9.0")
    (cl-lib "0.5"))
  :url "https://github.com/zweifisch/ob-http"
  :commit "20393dd8130d21a3f06d8514da14c5ffdd88ae44"
  :revdesc "20393dd8130d"
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
