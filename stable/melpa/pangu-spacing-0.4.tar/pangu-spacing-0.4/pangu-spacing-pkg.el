;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pangu-spacing" "0.4"
  "Minor-mode to add space between Chinese and English characters."
  ()
  :url "https://github.com/coldnew/pangu-spacing"
  :commit "034b4ef8a1b29bf7bfed6a916380941506ed26ed"
  :revdesc "034b4ef8a1b2"
  :authors '(("coldnew" . "coldnew.tw@gmail.com"))
  :maintainers '(("coldnew" . "coldnew.tw@gmail.com")))
