;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "broadcast" "20150303"
  "Links buffers together for editing."
  '((emacs "24"))
  :url "https://github.com/killdash9/broadcast.el"
  :commit "28d7564b4fd96e71a67fcd610f0c5cf699f0c1c5"
  :revdesc "28d7564b4fd9"
  :keywords '("convenience" "frames" "link" "cursors")
  :authors '(("Russell Black" . "(killdash9@github)"))
  :maintainers '(("Russell Black" . "(killdash9@github)")))
