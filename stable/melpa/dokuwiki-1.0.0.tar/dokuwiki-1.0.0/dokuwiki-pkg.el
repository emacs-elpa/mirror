;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dokuwiki" "1.0.0"
  "Edit Remote DokuWiki Pages Using XML-RPC."
  '((emacs   "24.3")
    (xml-rpc "1.6.8"))
  :url "http://www.github.com/accidentalrebel/emacs-dokuwiki"
  :commit "b41d9ba780fa05cdd9f84d84544bf40266e6fc73"
  :revdesc "b41d9ba780fa"
  :keywords '("convenience")
  :authors '(("Juan Karlo Licudine" . "accidentalrebel@gmail.com"))
  :maintainers '(("Juan Karlo Licudine" . "accidentalrebel@gmail.com")))
