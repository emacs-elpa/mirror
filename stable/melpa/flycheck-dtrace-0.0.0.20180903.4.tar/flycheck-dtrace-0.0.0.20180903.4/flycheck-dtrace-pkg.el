;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-dtrace" "0.0.0.20180903.4"
  "Flycheck: DTrace support."
  '((emacs    "25.1")
    (flycheck "0.22"))
  :url "https://github.com/juergenhoetzel/flycheck-dtrace"
  :commit "951fab3a15c11d92b9fac1ea4791a80dfe034a00"
  :revdesc "951fab3a15c1"
  :keywords '("languages" "convenience" "tools")
  :authors '(("Jürgen Hötzel" . "juergen@hoetzel.info"))
  :maintainers '(("Jürgen Hötzel" . "juergen@hoetzel.info")))
