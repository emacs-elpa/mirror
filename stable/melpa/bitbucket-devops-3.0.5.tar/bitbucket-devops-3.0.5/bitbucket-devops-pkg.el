;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbucket-devops" "3.0.5"
  "Bitbucket Cloud DevOps workflows."
  '((emacs         "29.1")
    (magit         "4.0.0")
    (markdown-mode "2.6")
    (transient     "0.3.0")
    (yaml          "1.2.3"))
  :url "https://github.com/will-abb/bitbucket-devops.el"
  :commit "ab61b99c2bc99d8c78931ece1439719f776f4c3d"
  :revdesc "v3.0.5-0-gab61b99c2bc9"
  :keywords '("tools" "vc")
  :authors '(("Will Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("Will Bosch-Bello" . "williamsbosch@gmail.com")))
