;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "4.0.9"
  "Development files for Helm."
  '((emacs "25.1")
    (async "2.0"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "a1e8724ed20d1f8024ff7530047374e1d7e994b0"
  :revdesc "v4.0.9-0-ga1e8724ed20d"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
