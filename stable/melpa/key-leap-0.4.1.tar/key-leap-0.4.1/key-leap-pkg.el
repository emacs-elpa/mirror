;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-leap" "0.4.1"
  "Leap between lines by typing keywords."
  '((emacs "24.3"))
  :url "https://github.com/MartinRykfors/key-leap"
  :commit "5add9fd38fdf46cc0306c27f721195ba6cf6ecf1"
  :revdesc "5add9fd38fdf"
  :keywords '("point" "convenience")
  :authors '(("Martin Rykfors" . "martinrykfors@gmail.com"))
  :maintainers '(("Martin Rykfors" . "martinrykfors@gmail.com")))
