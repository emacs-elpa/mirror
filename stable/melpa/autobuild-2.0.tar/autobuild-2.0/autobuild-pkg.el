;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autobuild" "2.0"
  "Define and execute build rules and compilation pipelines."
  '((emacs   "26.1")
    (selcand "0.0.1"))
  :url "https://github.com/erjoalgo/autobuild"
  :commit "151edbe52e7bea02155e7381450956c571648077"
  :revdesc "v2.0-0-g151edbe52e7b"
  :keywords '("compile" "build" "pipeline" "autobuild" "extensions" "processes" "tools")
  :maintainers '(("concat \"erjoalgo\" \"@\" \"gmail\" \".com\"" . "")))
