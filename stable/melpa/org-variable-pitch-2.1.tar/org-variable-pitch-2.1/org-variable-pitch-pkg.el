;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-variable-pitch" "2.1"
  "Minor mode for variable pitch text in org mode."
  '((emacs "25"))
  :url "https://dev.gkayaalp.com/elisp/index.html#ovp"
  :commit "e086c59a14701cd041641b51c952fa704ee963df"
  :revdesc "e086c59a1470"
  :keywords '("faces")
  :authors '(("Göktuğ Kayaalp" . "self@gkayaalp.com"))
  :maintainers '(("Göktuğ Kayaalp" . "self@gkayaalp.com")))
