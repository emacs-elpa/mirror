;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "japanese-menu" "0.1.0"
  "Japanese menu translation."
  ()
  :url "https://github.com/yt-emacs-ja/emacs-japanese-menu"
  :commit "5e4e2be6253b10b993036eba428d7d9f2112f8e5"
  :revdesc "5e4e2be6253b")
