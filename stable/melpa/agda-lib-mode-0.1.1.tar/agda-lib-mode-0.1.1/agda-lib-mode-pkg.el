;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agda-lib-mode" "0.1.1"
  "Major mode for Agda library files."
  ()
  :url "https://codeberg.org/heraplem/agda-lib-mode"
  :commit "3a9eb9c114bb0503b55f94114c15cb9867a1a1ad"
  :revdesc "3a9eb9c114bb"
  :keywords '("text")
  :authors '(("Nicholas Coltharp" . "mail@heraplem.xyz"))
  :maintainers '(("Nicholas Coltharp" . "mail@heraplem.xyz")))
