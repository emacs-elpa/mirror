;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "0.13.1"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "d5dbee013afc2c29facf1581a542a48f9f39e49f"
  :revdesc "d5dbee013afc"
  :keywords '("wp" "convenience"))
