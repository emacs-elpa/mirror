;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ecb" "2.52"
  "A code browser for Emacs."
  ()
  :url "https://github.com/ecb-org/ecb"
  :commit "0c318f1167ef8d7cf940dcdca7b27ff448707fe0"
  :revdesc "0c318f1167ef"
  :keywords '("browser" "code" "programming" "tools")
  :authors '(("Jesper Nordenberg" . "mayhem@home.se")
             ("Klaus Berndl" . "klaus.berndl@sdm.de")
             ("Kevin A. Burton" . "burton@openprivacy.org"))
  :maintainers '(("Klaus Berndl" . "klaus.berndl@sdm.de")))
