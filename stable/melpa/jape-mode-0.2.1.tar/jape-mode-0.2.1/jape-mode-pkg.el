;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jape-mode" "0.2.1"
  "[No description available]."
  '((emacs "24.1"))
  :url "https://github.com/tanzoniteblack/jape-mode"
  :commit "addd760a25d3436aa8d93e74c8f7bb42eff03313"
  :revdesc "addd760a25d3"
  :keywords '("languages" "jape" "gate")
  :authors '(("Ryan Smith" . "rnsmith2@gmail.com"))
  :maintainers '(("Ryan Smith" . "rnsmith2@gmail.com")))
