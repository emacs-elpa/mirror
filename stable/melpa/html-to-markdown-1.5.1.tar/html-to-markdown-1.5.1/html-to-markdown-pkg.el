;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "html-to-markdown" "1.5.1"
  "HTML to Markdown converter written in Emacs-lisp."
  ()
  :url "https://github.com/Bruce-Connor/html-to-markdown"
  :commit "0fa0effd71acd8981a425ef11e0e63d53aea3199"
  :revdesc "0fa0effd71ac"
  :keywords '("tools" "wp" "languages")
  :authors '(("Artur Malabarba" . "bruce.connor.am@gmail.com"))
  :maintainers '(("Artur Malabarba" . "bruce.connor.am@gmail.com")))
