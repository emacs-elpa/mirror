;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "1.0.5"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "2161b1a4d75c01781953acf536518c38661116f5"
  :revdesc "1.0.5-0-g2161b1a4d75c"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
