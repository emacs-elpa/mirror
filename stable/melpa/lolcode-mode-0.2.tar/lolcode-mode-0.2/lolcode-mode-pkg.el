;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lolcode-mode" "0.2"
  "Major mode for editing LOLCODE."
  ()
  :url "https://github.com/bodil/lolcode-mode"
  :commit "0fabaad3a32733cad5795b9099a11ca9cd2edb74"
  :revdesc "0fabaad3a327"
  :keywords '("lolcode" "major" "mode")
  :authors '(("Bodil Stokke" . "lolcode@bodil.tv"))
  :maintainers '(("Bodil Stokke" . "lolcode@bodil.tv")))
