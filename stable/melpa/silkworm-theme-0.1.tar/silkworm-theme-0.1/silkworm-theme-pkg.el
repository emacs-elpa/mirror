;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "silkworm-theme" "0.1"
  "Light theme with pleasant, low contrast colors."
  '((emacs "24"))
  :url "https://github.com/mswift42/silkworm-theme"
  :commit "7951b53e5caf9daf6a5a15a57ae3a668cb78bd7b"
  :revdesc "7951b53e5caf")
