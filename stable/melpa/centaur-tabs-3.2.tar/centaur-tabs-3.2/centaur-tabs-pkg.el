;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "centaur-tabs" "3.2"
  "Aesthetic, modern looking customizable tabs plugin."
  '((emacs     "24.4")
    (powerline "2.4")
    (cl-lib    "0.5"))
  :url "https://github.com/ema2159/centaur-tabs"
  :commit "eac6522bb9c19c525770822d9f14b4d0ff07324c"
  :revdesc "eac6522bb9c1"
  :authors '(("Emmanuel Bustos" . "ema2159@gmail.com"))
  :maintainers '(("Emmanuel Bustos" . "ema2159@gmail.com")))
