;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minions" "1.2.2"
  "A minor-mode menu for the mode line."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://github.com/tarsius/minions"
  :commit "242e82614151b304a597429c06b4265ea6b099b1"
  :revdesc "v1.2.2-0-g242e82614151"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.minions@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.minions@jonas.bernoulli.dev")))
