;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insert-shebang" "0.9.7"
  "Insert shebang line automatically."
  ()
  :url "https://gitlab.com/psachin/insert-shebang"
  :commit "d5cf5bad3ea3e5dc86fb19eb3545149935e10dbd"
  :revdesc "d5cf5bad3ea3"
  :keywords '("shebang" "tool" "convenience")
  :authors '(("Sachin Patil" . "iclcoolster@gmail.com"))
  :maintainers '(("Sachin Patil" . "iclcoolster@gmail.com")))
