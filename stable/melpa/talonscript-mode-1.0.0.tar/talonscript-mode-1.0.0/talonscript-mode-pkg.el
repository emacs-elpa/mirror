;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "talonscript-mode" "1.0.0"
  "Major mode for Talon Voice's .talon files."
  '((emacs "24.3"))
  :url "https://github.com/jcaw/talonscript-mode"
  :commit "b6eb61f56349e0d47276270163ec611c2d5b188e"
  :revdesc "b6eb61f56349"
  :keywords '("languages")
  :authors '(("Jcaw" . "toastedjcaw@gmail.com"))
  :maintainers '(("Jcaw" . "toastedjcaw@gmail.com")))
