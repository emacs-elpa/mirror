;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-rescript" "0.1.0"
  "LSP client configuration for lsp-mode and rescript-vscode."
  '((lsp-mode "3.0")
    (emacs    "24.3"))
  :url "https://github.com/jjlee/lsp-rescript"
  :commit "dd34cd3096830714ae852554b85c25b6b1227dcf"
  :revdesc "dd34cd309683"
  :keywords '("languages"))
