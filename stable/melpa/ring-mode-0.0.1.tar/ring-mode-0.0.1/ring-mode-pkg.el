;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ring-mode" "0.0.1"
  "A major mode for the Ring programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/ring-mode"
  :commit "566578cd3b912bcd6c5a6243b8f43e4b78dd6ac4"
  :revdesc "566578cd3b91"
  :keywords '("files" "ring"))
