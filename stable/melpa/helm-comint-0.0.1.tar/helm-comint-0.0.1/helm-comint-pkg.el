;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-comint" "0.0.1"
  "Comint prompt navigation for helm."
  '((emacs "29.1")
    (helm  "3.9.4"))
  :url "https://github.com/benedicthw/helm-comint.git"
  :commit "dea9a86de0d133e9e9fbaf3a66fa3dc2e8fec2f8"
  :revdesc "dea9a86de0d1"
  :keywords '("processes" "matching")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Benedict Wang" . "foss@bhw.name")))
