;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaesar" "0.9.5"
  "AES algorithm encrypt/decrypt."
  '((emacs         "24.3")
    (kaesar-pbkdf2 "0.9.0"))
  :url "https://github.com/mhayashi1120/Emacs-kaesar"
  :commit "75655238e0dcdb77a74d685cc4f3368fcd284020"
  :revdesc "75655238e0dc"
  :keywords '("data")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
