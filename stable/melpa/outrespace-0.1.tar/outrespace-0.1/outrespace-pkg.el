;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outrespace" "0.1"
  "C++ namespace utility functions."
  '((emacs "24.4"))
  :url "https://github.com/danrharms/outrespace.git"
  :commit "0e8d112f8e931f9d23ecb3bb810d6093b70490df"
  :revdesc "0e8d112f8e93"
  :keywords '("tools" "c++" "namespace")
  :authors '(("Dan Harms" . "danielrharms@gmail.com"))
  :maintainers '(("Dan Harms" . "danielrharms@gmail.com")))
