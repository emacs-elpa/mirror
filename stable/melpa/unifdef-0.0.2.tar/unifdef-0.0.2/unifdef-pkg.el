;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unifdef" "0.0.2"
  "Delete code guarded by processor directives."
  ()
  :url "https://github.com/Lindydancer/unifdef"
  :commit "4a428d544893e91835b625fab38fdac964dcff88"
  :revdesc "4a428d544893"
  :keywords '("convenience" "languages"))
