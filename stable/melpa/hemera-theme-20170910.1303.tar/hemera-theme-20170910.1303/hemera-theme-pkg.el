;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hemera-theme" "20170910.1303"
  "Light theme."
  '((emacs "24"))
  :url "https://github.com/GuidoSchmidt/emacs-hemera-theme"
  :commit "b67c902b210b37b00cac68726822404543147ba8"
  :revdesc "b67c902b210b"
  :keywords '("themes" "light-theme")
  :maintainers '(("Guido Schmidt" . "guido.schmidt.2912@gmail.com")))
