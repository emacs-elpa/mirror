;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "password-store-otp" "0.1.5"
  "Password store (pass) OTP extension support."
  '((emacs          "25")
    (s              "1.9.0")
    (password-store "0.1"))
  :url "https://github.com/volrath/password-store-otp.el"
  :commit "a39a64a91de36e87b852339635bd3c5fb0e32441"
  :revdesc "0.1.5-0-ga39a64a91de3"
  :keywords '("tools" "pass"))
