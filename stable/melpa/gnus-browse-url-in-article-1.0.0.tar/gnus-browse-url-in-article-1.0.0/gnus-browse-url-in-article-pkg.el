;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-browse-url-in-article" "1.0.0"
  "Smarter browse-url for Gnus articles."
  '((emacs "26.1")
    (gnus  "1.0"))
  :url "https://github.com/jmibanez/gnus-browse-url-in-article"
  :commit "c5a90e94ccdc28e1f9f2de16a8a24d3fa989f6ab"
  :revdesc "c5a90e94ccdc"
  :keywords '("convenience" "mail" "gnus")
  :authors '(("JM Ibañez" . "jm@jmibanez.com"))
  :maintainers '(("JM Ibañez" . "jm@jmibanez.com")))
