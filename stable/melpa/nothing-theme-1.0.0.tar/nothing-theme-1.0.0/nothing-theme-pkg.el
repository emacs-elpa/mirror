;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nothing-theme" "1.0.0"
  "Monochrome emacs."
  '((emacs "24"))
  :url "https://github.com/jaredgorski/nothing.el"
  :commit "5a6779ad97ba4b443a89a7c6d041f3b4cc1b1a2e"
  :revdesc "5a6779ad97ba"
  :keywords '("colorscheme" "theme" "monochrome" "minimal")
  :authors '((nil . "jaredgorski6@gmail.com"))
  :maintainers '((nil . "jaredgorski6@gmail.com")))
