;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leanote" "0.4.0"
  "A minor mode writing markdown leanote."
  '((emacs     "24.4")
    (cl-lib    "0.5")
    (request   "0.2")
    (let-alist "1.0.3")
    (pcache    "0.4.0")
    (s         "1.10.0")
    (async     "1.9"))
  :url "https://github.com/aborn/leanote-emacs"
  :commit "1bd49fdf13ef707bae7edaa724a1592aa7fb002f"
  :revdesc "1bd49fdf13ef"
  :keywords '("leanote" "note" "markdown")
  :authors '(("Aborn Jiang" . "aborn.jiang@gmail.com"))
  :maintainers '(("Aborn Jiang" . "aborn.jiang@gmail.com")))
