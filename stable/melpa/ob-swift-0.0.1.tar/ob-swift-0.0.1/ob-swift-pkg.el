;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-swift" "0.0.1"
  "Org-babel functions for swift evaluation."
  '((org "8"))
  :url "https://github.com/zweifisch/ob-swift"
  :commit "d32216f9287d319c477bcae726d593fcf5eea32b"
  :revdesc "d32216f9287d"
  :keywords '("org" "babel" "swift")
  :authors '(("Feng Zhou" . "zf.pascal@gmail.com"))
  :maintainers '(("Feng Zhou" . "zf.pascal@gmail.com")))
