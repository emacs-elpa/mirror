;;; ob-swift.el --- org-babel functions for swift evaluation

;; Copyright (C) 2015 Feng Zhou

;; Author: Feng Zhou <zf.pascal@gmail.com>
;; URL: http://github.com/zweifisch/ob-swift
;; Keywords: org babel swift
;; Package-Version: 0.0.1
;; Package-Revision: d32216f9287d
;; Created: 4th Dec 2015
;; Package-Requires: ((org "8"))

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; org-babel functions for swift evaluation
;;

;;; Code:
(require 'ob)

(defvar ob-swift-process-output "")

(defvar ob-swift-eoe "ob-swift-eoe")

(defun org-babel-execute:swift (body params)
  (let ((session (cdr (assoc :session params))))
    (ob-swift--ensure-session session)
    (ob-swift-eval-in-repl session body)))

(defun ob-swift--ensure-session (session)
  (let ((name (format "*ob-swift-%s*" session)))
    (unless (and (get-process name)
                 (process-live-p (get-process name)))
      (let ((process (with-current-buffer (get-buffer-create name)
                       (start-process name name "swift"))))
        (sit-for 1)
        (set-process-filter process 'ob-swift--process-filter)
        (ob-swift--wait "Welcome to Swift")))))

(defun ob-swift--process-filter (process output)
  (setq ob-swift-process-output (concat ob-swift-process-output output)))

(defun ob-swift--wait (pattern)
  (while (not (string-match-p pattern ob-swift-process-output))
    (sit-for 0.2)))

(defun ob-swift-eval-in-repl (session body)
  (let ((name (format "*ob-swift-%s*" session)))
    (setq ob-swift-process-output "")
    (process-send-string name (format "%s\n\"%s\"\n" body ob-swift-eoe))
    (accept-process-output (get-process name) nil nil 1)
    (ob-swift--wait ob-swift-eoe)
    (replace-regexp-in-string
     (format "^\\$R[0-9]+: String = \"%s\"\n" ob-swift-eoe) ""
     (message
      (replace-regexp-in-string
       "^\\([0-9]+\\. \\)+\\([0-9]+> \\)?" ""
       (message
        (replace-regexp-in-string
         "^[0-9]+> " ""
         ob-swift-process-output)))))))

(provide 'ob-swift)
;;; ob-swift.el ends here
