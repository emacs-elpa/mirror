;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "0.16.2"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.9.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "851860555c3942e4f9cb2d660e912a08ea81f808"
  :revdesc "v0.16.2-0-g851860555c39"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
