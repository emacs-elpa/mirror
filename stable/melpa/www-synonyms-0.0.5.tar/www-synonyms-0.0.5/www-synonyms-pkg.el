;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "www-synonyms" "0.0.5"
  "Insert synonym for a word."
  '((request "0.2.0")
    (cl-lib  "0.5"))
  :url "https://github.com/spebern/www-synonyms"
  :commit "c38aec1f0f30932360525141c30d9837dffd59fb"
  :revdesc "c38aec1f0f30"
  :keywords '("lisp")
  :authors '(("Bernhard Specht" . "bernhard@specht.net"))
  :maintainers '(("Bernhard Specht" . "bernhard@specht.net")))
