;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soft-morning-theme" "0.2"
  "Emacs24 theme with a light background."
  ()
  :url "https://github.com/mswift42/soft-morning-theme"
  :commit "3e71b1ed41ac34395c6707cee57ee8f176bac013"
  :revdesc "3e71b1ed41ac")
