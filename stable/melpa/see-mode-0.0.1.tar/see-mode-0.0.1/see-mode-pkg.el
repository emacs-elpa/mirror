;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "see-mode" "0.0.1"
  "Edit string  in a separate buffer with appropriate major mode enabled in it."
  '((emacs              "24.3")
    (language-detection "0.1.0"))
  :url "https://github.com/marcelino-m/see-mode"
  :commit "5306808c836fcfe9efba94bc467b76487a8846ac"
  :revdesc "5306808c836f"
  :keywords '("convenience")
  :authors '(("Marcelo Muñoz" . "ma.munoz.araya@gmail.com"))
  :maintainers '(("Marcelo Muñoz" . "ma.munoz.araya@gmail.com")))
