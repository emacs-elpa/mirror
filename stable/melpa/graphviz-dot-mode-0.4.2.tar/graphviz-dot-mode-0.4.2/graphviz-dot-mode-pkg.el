;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphviz-dot-mode" "0.4.2"
  "Mode for the dot-language used by graphviz (att)."
  '((emacs "25.0"))
  :url "https://ppareit.github.io/graphviz-dot-mode/"
  :commit "80b9c5e7f464c70cfa423e5ee3237581bc69d643"
  :revdesc "v0.4.2-0-g80b9c5e7f464"
  :keywords '("mode" "dot" "dot-language" "dotlanguage" "graphviz" "graphs" "att")
  :authors '(("Pieter Pareit" . "pieter.pareit@gmail.com")
             ("Rubens Ramos" . "rubensrATusers.sourceforge.net"))
  :maintainers '(("Pieter Pareit" . "pieter.pareit@gmail.com")))
