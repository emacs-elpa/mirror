;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "filldent" "1.0.1"
  "Fill or indent."
  '((emacs "24.1"))
  :url "https://github.com/duckwork/filldent.el"
  :commit "ec406d76c97fd8a59df9308d60dba63061dc716a"
  :revdesc "ec406d76c97f"
  :authors '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainers '(("Case Duckworth" . "acdw@acdw.net")))
