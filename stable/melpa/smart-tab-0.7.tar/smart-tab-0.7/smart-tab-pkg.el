;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-tab" "0.7"
  "Intelligent tab completion and indentation."
  '((emacs "24.3"))
  :url "https://github.com/genehack/smart-tab/tree/master"
  :commit "088002ccdb7efaf7a7f3bf57852ca629012373de"
  :revdesc "088002ccdb7e"
  :keywords '("extensions")
  :authors '(("John SJ Anderson" . "john@genehack.org")
             ("Sebastien Rocca Serra" . "sroccaserra@gmail.com")
             ("Daniel Hackney" . "dan@haxney.org"))
  :maintainers '(("John SJ Anderson" . "john@genehack.org")))
