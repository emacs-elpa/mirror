;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-summary" "0.1.0"
  "Feed summary interface for elfeed."
  '((emacs         "27.1")
    (magit-section "3.3.0")
    (elfeed        "3.4.1"))
  :url "https://github.com/SqrtMinusOne/elfeed-summary.el"
  :commit "1cf73acae8b791e214dc347c2adf7ec17e8ff41a"
  :revdesc "1cf73acae8b7"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
