;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "call-graph" "1.0.5"
  "Generate call graph for c/c++ functions."
  '((emacs     "26.1")
    (tree-mode "1.0.0")
    (ivy       "0.10.0")
    (beacon    "1.3.4"))
  :url "https://github.com/beacoder/call-graph"
  :commit "302803eaf3149031c5ada5b49cd77e8d7e96116a"
  :revdesc "302803eaf314"
  :keywords '("programming" "convenience")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
