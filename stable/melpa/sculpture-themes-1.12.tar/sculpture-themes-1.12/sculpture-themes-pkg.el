;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "1.12"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "bc1a1b8ab9e9e63944e554bb5253f74066ed191d"
  :revdesc "bc1a1b8ab9e9"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
