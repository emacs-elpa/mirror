;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-nginx" "0.1"
  "Company-mode keywords support for nginx-mode."
  '((emacs "24"))
  :url "https://github.com/stardiviner/company-nginx"
  :commit "4a57dea773908a565f50d7d9d570f33c33141cec"
  :revdesc "4a57dea77390"
  :keywords '("company" "nginx")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
