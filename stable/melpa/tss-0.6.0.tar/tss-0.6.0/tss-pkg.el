;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tss" "0.6.0"
  "Provide a interface for auto-complete.el/flymake.el on typescript-mode."
  '((auto-complete "1.4.0")
    (json-mode     "1.1.0")
    (log4e         "0.2.0")
    (yaxception    "0.1"))
  :url "https://github.com/aki2o/emacs-tss"
  :commit "1f302deea3d74462c71a9c62031f48b753e8915f"
  :revdesc "1f302deea3d7"
  :keywords '("typescript" "completion")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
