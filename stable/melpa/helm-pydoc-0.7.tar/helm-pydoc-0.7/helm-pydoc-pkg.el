;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-pydoc" "0.7"
  "Pydoc with helm interface."
  '((helm-core "1.7.4")
    (cl-lib    "0.5"))
  :url "https://github.com/syohex/emacs-helm-pydoc"
  :commit "30f1814b5b16db0413ffe74b0d0420b38e153df9"
  :revdesc "30f1814b5b16"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
