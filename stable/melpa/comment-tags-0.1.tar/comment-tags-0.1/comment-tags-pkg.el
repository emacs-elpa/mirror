;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comment-tags" "0.1"
  "Highlight and navigate comment tags like TODO, FIXME, etc."
  '((emacs    "24.5")
    (pkg-info "0.4"))
  :url "https://github.com/vincekd/comment-tags"
  :commit "293a30026d7750f6657d6c2e6d6428abf1d7db5a"
  :revdesc "v0.1-0-g293a30026d77"
  :keywords '("convenience" "comments" "tags")
  :authors '(("Vincent Dumas" . "vincekd@gmail.com"))
  :maintainers '(("Vincent Dumas" . "vincekd@gmail.com")))
