;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "objc-font-lock" "0.0.5"
  "Highlight Objective-C method calls."
  ()
  :url "https://github.com/Lindydancer/objc-font-lock"
  :commit "c971d72599e5a943e8552f929562346ed15446ce"
  :revdesc "c971d72599e5"
  :keywords '("languages" "faces"))
