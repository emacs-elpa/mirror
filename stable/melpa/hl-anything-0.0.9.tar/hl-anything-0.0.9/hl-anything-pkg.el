;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-anything" "0.0.9"
  "Highlight symbols, selections, enclosing parens and more."
  '((emacs "24.3"))
  :url "https://github.com/hl-anything/hl-anything-emacs"
  :commit "de631c87d3a6602cdbf84c1623558334fda354fa"
  :revdesc "de631c87d3a6")
