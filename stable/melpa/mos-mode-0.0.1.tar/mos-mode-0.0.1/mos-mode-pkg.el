;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mos-mode" "0.0.1"
  "MOS toolkit usage in Emacs."
  '((emacs    "24.4")
    (lsp-mode "8.0.0")
    (dap-mode "0.7")
    (dash     "2.19.1")
    (s        "1.12.0")
    (ht       "2.3"))
  :url "https://github.com/themkat/mos-mode"
  :commit "4a0f4c22b53118b99565cb08a37a37647da8dce7"
  :revdesc "4a0f4c22b531")
