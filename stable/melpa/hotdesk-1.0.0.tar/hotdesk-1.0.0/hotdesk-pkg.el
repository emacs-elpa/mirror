;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hotdesk" "1.0.0"
  "Flexible frame Buffer Lists for projects & workspaces."
  '((emacs "29.3"))
  :url "https://github.com/j-hotlink/hotdesk"
  :commit "80f2f71b30253216bdac81c5197eb2ff14688c77"
  :revdesc "80f2f71b3025"
  :keywords '("convenience" "frames" "local")
  :authors '(("Jonathan Doull" . "jonathan@hotlink.technology"))
  :maintainers '(("Jonathan Doull" . "jonathan@hotlink.technology")))
