;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kotlin-mode" "2.0.0"
  "Major mode for kotlin."
  '((emacs "24.3"))
  :url "https://github.com/Emacs-Kotlin-Mode-Maintainers/kotlin-mode"
  :commit "d92c3b773473e9fe15f61f6177e4fbf097aadd05"
  :revdesc "d92c3b773473"
  :keywords '("languages")
  :authors '(("Shodai Yokoyama" . "(quantumcars@gmail.com)"))
  :maintainers '(("Shodai Yokoyama" . "(quantumcars@gmail.com)")))
