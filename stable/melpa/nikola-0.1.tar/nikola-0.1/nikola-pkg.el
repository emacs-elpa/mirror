;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nikola" "0.1"
  "Simple wrapper for nikola."
  '((async "1.5")
    (emacs "24.3"))
  :url ": https://git.daemons.cf/drymer/nikola.el"
  :commit "519d37911f0370a58ac64be809ecda10413f6e36"
  :revdesc "519d37911f03"
  :keywords '(":" "nikola")
  :authors '(("drymer" . "drymer[AT]autistici.org"))
  :maintainers '(("drymer" . "drymer[AT]autistici.org")))
