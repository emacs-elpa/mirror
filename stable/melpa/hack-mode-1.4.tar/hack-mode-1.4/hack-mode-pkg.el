;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hack-mode" "1.4"
  "Major mode for the Hack programming language."
  '((emacs "25.1")
    (s     "1.11.0"))
  :url "https://github.com/hhvm/hack-mode"
  :commit "86a981bd7bc9929750abc7cea368d58c6ebb86fa"
  :revdesc "86a981bd7bc9"
  :authors '(("John Allen" . "jallen@fb.com")
             ("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("John Allen" . "jallen@fb.com")
                 ("Wilfred Hughes" . "me@wilfred.me.uk")))
