;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.8.0"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "2afd0d2f3e5eac573add173f6b5857ad20e46c15"
  :revdesc "2afd0d2f3e5e"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
