;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "subsonic" "0.4.1"
  "Browse and play music from subsonic servers with mpv."
  '((emacs     "27.1")
    (transient "0.2"))
  :url "https://git.sr.ht/~amk/subsonic.el"
  :commit "011e58d434ed707a06a2cfa20509629ebb339c04"
  :revdesc "v0.4.1-0-g011e58d434ed"
  :keywords '("multimedia")
  :authors '(("Alex McGrath" . "amk@amk.ie"))
  :maintainers '(("Alex McGrath" . "amk@amk.ie")))
