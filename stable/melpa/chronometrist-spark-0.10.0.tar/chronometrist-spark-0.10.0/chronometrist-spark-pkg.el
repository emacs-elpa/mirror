;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chronometrist-spark" "0.10.0"
  "Show sparklines in Chronometrist buffers."
  '((emacs         "25.1")
    (chronometrist "0.7.0")
    (spark         "0.1"))
  :url "https://tildegit.org/contrapunctus/chronometrist"
  :commit "2c1274147475b552716de7cecd7a9fd46e578e46"
  :revdesc "2c1274147475"
  :keywords '("calendar")
  :authors '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainers '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de")))
