;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "total-lines" "0.2.0"
  "Keep track of a buffer's total number of lines."
  '((emacs "24.3"))
  :url "https://github.com/hinrik/total-lines"
  :commit "58a9fb0ffca63e3dfb3b27c7d91b4630e422903b"
  :revdesc "58a9fb0ffca6"
  :keywords '("convenience" "mode-line"))
