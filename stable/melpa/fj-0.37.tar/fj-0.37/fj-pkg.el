;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "0.37"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "4832dcfcd167d1975bb44a024881c75fef64182e"
  :revdesc "4832dcfcd167"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
