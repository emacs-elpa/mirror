;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "retrie" "0.0.1"
  "Refactoring Haskell code with retrie."
  '((emacs "24.5"))
  :url "https://github.com/Ailrun/emacs-retrie"
  :commit "edb40c15dcdea34be70df8c614e21104b8639b04"
  :revdesc "edb40c15dcde"
  :keywords '("files" "languages" "tools")
  :authors '(("Junyoung Clare Jang" . "jjc9310@gmail.com"))
  :maintainers '(("Junyoung Clare Jang" . "jjc9310@gmail.com")))
