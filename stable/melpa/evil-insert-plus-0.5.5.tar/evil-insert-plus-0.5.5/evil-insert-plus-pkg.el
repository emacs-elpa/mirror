;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-insert-plus" "0.5.5"
  "Use insert and append as evil operators."
  '((emacs "24.4")
    (evil  "1.14.0"))
  :url "https://github.com/yad-tahir/evil-insert-plus"
  :commit "a43914e3d483685dc11d616f9fcd268779dd0258"
  :revdesc "a43914e3d483"
  :keywords '("emulations" "textvim" "editing")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
