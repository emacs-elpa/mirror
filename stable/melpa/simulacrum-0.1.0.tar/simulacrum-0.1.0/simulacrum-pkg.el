;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simulacrum" "0.1.0"
  "Inject custom event types into the event stream."
  '((emacs "29.1"))
  :url "https://github.com/ErikPrantare/simulacrum.el"
  :commit "a728b4e30c48de5eaf723317b387d46ca9799015"
  :revdesc "a728b4e30c48"
  :keywords '("convenience"))
