;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-isearch" "1.0.1"
  "A seamless bridge between isearch, ace-jump-mode, avy, helm-swoop and swiper."
  '((emacs "24"))
  :url "https://github.com/tam17aki/ace-isearch"
  :commit "7defe3517f2be444a1479c0a18859d78da4919a5"
  :revdesc "7defe3517f2b")
