;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hidepass" "0.2"
  "Hide passwords at one or multiple lines."
  '((emacs "27.2"))
  :url "https://codeberg.org/Anoncheg/emacs-hidepass"
  :commit "6094bc0e37f5ac4abfe3fe8ed0ce8eef1a928ef9"
  :revdesc "6094bc0e37f5"
  :keywords '("hide" "hidden" "password" "faces")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
