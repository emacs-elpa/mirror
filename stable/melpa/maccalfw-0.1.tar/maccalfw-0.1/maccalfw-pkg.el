;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maccalfw" "0.1"
  "Calendar view for Mac Calendars."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/maccalfw"
  :commit "84f3c27a6d7032a42bba865b56d3c364ea333c04"
  :revdesc "84f3c27a6d70"
  :keywords '("calendar")
  :authors '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
