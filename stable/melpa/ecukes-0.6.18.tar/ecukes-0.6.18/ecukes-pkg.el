;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ecukes" "0.6.18"
  "Cucumber for Emacs."
  ()
  :url "https://github.com/ecukes/ecukes"
  :commit "d173cdf487bc2c62305e2232db96290bc021950f"
  :revdesc "d173cdf487bc")
