;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fill-function-arguments" "0.9"
  "Convert function arguments to/from single line."
  '((emacs "24.4"))
  :url "https://github.com/davidshepherd7/fill-function-arguments"
  :commit "e819fca19a138ae67201220e41fe1d4384fb2a42"
  :revdesc "e819fca19a13"
  :keywords '("convenience")
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
