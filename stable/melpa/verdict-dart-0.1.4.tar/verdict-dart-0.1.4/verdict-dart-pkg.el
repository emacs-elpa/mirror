;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verdict-dart" "0.1.4"
  "Dart runner for verdict."
  '((emacs   "29.1")
    (verdict "0.1")
    (dash    "2.0")
    (f       "0.20")
    (yaml    "0.5"))
  :url "https://github.com/tjarvstrand/verdict.el"
  :commit "84fff362b8068a1a8112b772fa927b56a6786482"
  :revdesc "84fff362b806"
  :keywords '("tools" "languages")
  :authors '(("Thomas Järvstrand" . "https://github.com/tjarvstrand"))
  :maintainers '(("Thomas Järvstrand" . "https://github.com/tjarvstrand")))
