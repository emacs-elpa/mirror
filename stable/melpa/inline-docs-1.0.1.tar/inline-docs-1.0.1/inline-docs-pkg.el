;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inline-docs" "1.0.1"
  "Show inline contextual docs in Emacs."
  '((emacs "25.1"))
  :url "https://github.com/stardiviner/inline-docs.el"
  :commit "dfd32aa31f149e4ace709a1afc6fc9f92d6640a1"
  :revdesc "dfd32aa31f14"
  :keywords '("inline" "docs" "overlay")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
