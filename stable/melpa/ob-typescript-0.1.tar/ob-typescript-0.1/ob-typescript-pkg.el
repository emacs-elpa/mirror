;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-typescript" "0.1"
  "Org-babel functions for typescript evaluation."
  ()
  :url "http://orgmode.org"
  :commit "fe93540c1795ef7f3907e6d82952734421fa6318"
  :revdesc "fe93540c1795"
  :keywords '("literate programming" "reproducible research" "typescript"))
