;;; grizzl.el --- Fast fuzzy search index for Emacs.

;; Copyright © 2013 Chris Corbyn
;;
;; Author:   Chris Corbyn <chris@w3style.co.uk>
;; URL:      https://github.com/d11wtq/grizzl
;; Package-Version: 0.1.1
;; Package-Revision: v0.1.1-0-gc775de1c34d1
;; Keywords: convenience, usability

;; This file is NOT part of GNU Emacs.

;;; --- License

;; Licensed under the same terms as Emacs.

;;; --- Commentary

;; This package is broken into separate files.
;;

(require 'grizzl-core)
(require 'grizzl-read)

(provide 'grizzl)

;;; grizzl.el ends here
