;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grizzl" "0.1.1"
  "Fuzzy Search Library & Completing Read."
  ()
  :url "https://github.com/d11wtq/grizzl"
  :commit "c775de1c34d1e5a374e2f40c1ae2396b4b003fe7"
  :revdesc "v0.1.1-0-gc775de1c34d1"
  :keywords '("convenience" "usability")
  :authors '(("Chris Corbyn" . "chris@w3style.co.uk"))
  :maintainers '(("Chris Corbyn" . "chris@w3style.co.uk")))
