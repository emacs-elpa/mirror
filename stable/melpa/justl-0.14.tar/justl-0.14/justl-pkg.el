;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "justl" "0.14"
  "Major mode for driving just files."
  '((transient  "0.1.0")
    (emacs      "27.1")
    (s          "1.2.0")
    (f          "0.20.0")
    (inheritenv "0.2"))
  :url "https://github.com/psibi/justl.el"
  :commit "1b16ca44b227dc761a2c8631690140f62e024f98"
  :revdesc "v0.14-0-g1b16ca44b227"
  :keywords '("just" "justfile" "tools" "processes"))
