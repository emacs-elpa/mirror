;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuz" "1.3.0"
  "Fast and precise fuzzy scoring/matching utils."
  '((emacs "25.1"))
  :url "https://github.com/cireu/fuz.el"
  :commit "90ca9207a9c1decda24a552b94ff41169ecccb14"
  :revdesc "1.3.0-0-g90ca9207a9c1"
  :keywords '("lisp")
  :authors '(("Zhu Zihao" . "all_but_last@163.com"))
  :maintainers '(("Zhu Zihao" . "all_but_last@163.com")))
