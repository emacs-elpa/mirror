;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tesouro" "1.0"
  "Procure sinônimos no dicio.com.br."
  '((request "0.3.2")
    (emacs   "24.4"))
  :url "https://github.com/rberaldo/tesouro.el"
  :commit "d8d6b5f4c53525655acb9be9dde003fa381bfbe5"
  :revdesc "d8d6b5f4c535")
