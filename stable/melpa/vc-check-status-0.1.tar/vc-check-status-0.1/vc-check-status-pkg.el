;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-check-status" "0.1"
  "Warn you when quitting emacs and leaving repo dirty."
  ()
  :url "https://github.com/thisirs/vc-check-status"
  :commit "07891bb695ef09d9a1d1b1a24733e9d00fb187ba"
  :revdesc "07891bb695ef"
  :keywords '("vc" "convenience")
  :authors '(("Sylvain Rousseau" . "thisirsatgmaildotcom"))
  :maintainers '(("Sylvain Rousseau" . "thisirsatgmaildotcom")))
