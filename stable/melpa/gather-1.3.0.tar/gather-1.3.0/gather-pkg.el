;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gather" "1.3.0"
  "Gather string in buffer."
  '((emacs "24.3"))
  :url "https://github.com/mhayashi1120/Emacs-gather"
  :commit "b85bf10552561ca687633d73070efbcb1e2ce2b8"
  :revdesc "b85bf1055256"
  :keywords '("matching" "convenience" "tools")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
