;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mini-header-line" "0.1.0"
  "A minimal header-line instead of a convoluted mode-line."
  ()
  :url "https://github.com/ksjogo/mini-header-line"
  :commit "f5fdbaf805b723610d186aa9f8f56d78673af86b"
  :revdesc "f5fdbaf805b7"
  :keywords '("header-line" "mode-line"))
