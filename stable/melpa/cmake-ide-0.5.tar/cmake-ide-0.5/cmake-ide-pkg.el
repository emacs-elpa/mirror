;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-ide" "0.5"
  "Calls CMake to find out include paths and other compiler flags."
  '((emacs       "24.1")
    (cl-lib      "0.5")
    (seq         "1.11")
    (levenshtein "0"))
  :url "https://github.com/atilaneves/cmake-ide"
  :commit "a2e476ad42e61075cae9beb35fb83e3c1bf8619e"
  :revdesc "V0.5-0-ga2e476ad42e6"
  :keywords '("languages")
  :authors '(("Atila Neves" . "atila.neves@gmail.com"))
  :maintainers '(("Atila Neves" . "atila.neves@gmail.com")))
