;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buttons" "0.0.3"
  "Define and visualize hierarchies of keymaps."
  '((emacs  "24.1")
    (cl-lib "0.3"))
  :url "https://github.com/erjoalgo/emacs-buttons"
  :commit "ae97996cc52bf0523f5b6626db14987c3b56b3e2"
  :revdesc "0.0.3-0-gae97996cc52b"
  :keywords '("lisp" "extensions" "convenience" "tools")
  :maintainers '(("concat \"erjoalgo\" \"@\" \"gmail\" \".com\"" . "")))
