;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "0.8"
  "Client for Lichess.org."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "1dd8a25ede7144c5d6be1f45f4ae3d07903783cd"
  :revdesc "1dd8a25ede71"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
