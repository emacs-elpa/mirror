;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "0.15.1"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "dfd8b26bac48b8c59d8bddf79eb9721ad06f98c6"
  :revdesc "dfd8b26bac48"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
