;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hidepw" "0.3.0"
  "Minor mode to hide passwords."
  ()
  :url "https://github.com/jekor/hidepw"
  :commit "3a16fc194c24f50a134a57694ee89b9353de3e7e"
  :revdesc "3a16fc194c24"
  :keywords '("hide" "hidden" "password" "faces")
  :authors '(("Chris Forno" . "jekor@jekor.com"))
  :maintainers '(("Chris Forno" . "jekor@jekor.com")))
