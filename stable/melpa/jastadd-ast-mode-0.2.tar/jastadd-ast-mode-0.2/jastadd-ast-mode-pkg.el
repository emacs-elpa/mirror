;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jastadd-ast-mode" "0.2"
  "Major mode for editing JastAdd AST files."
  '((emacs "25"))
  :url "https://github.com/rudi/jastadd-ast-mode"
  :commit "a98a5eef274d8eedabc7467874edf4338c9a012e"
  :revdesc "a98a5eef274d"
  :keywords '("languages")
  :authors '(("Rudi Schlatte" . "rudi@constantly.at"))
  :maintainers '(("Rudi Schlatte" . "rudi@constantly.at")))
