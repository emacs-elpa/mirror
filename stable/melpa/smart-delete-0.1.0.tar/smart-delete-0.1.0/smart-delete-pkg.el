;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-delete" "0.1.0"
  "IntelliJ-like backspace/delete."
  ()
  :url "https://github.com/leodag/smart-delete"
  :commit "70431a71660b8bc3e071e2165005e75a41b88d21"
  :revdesc "70431a71660b"
  :keywords '("delete" "backspace"))
