;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "deft" "0.8"
  "Quickly browse, filter, and edit plain text notes."
  ()
  :url "https://jblevins.org/projects/deft/"
  :commit "c4b30d780bfa732ff52d85f0311e4a045f44a7b4"
  :revdesc "v0.8-0-gc4b30d780bfa"
  :keywords '("plain text" "notes" "simplenote" "notational velocity")
  :authors '(("Jason R. Blevins" . "jrblevin@xbeta.org"))
  :maintainers '(("Jason R. Blevins" . "jrblevin@xbeta.org")))
