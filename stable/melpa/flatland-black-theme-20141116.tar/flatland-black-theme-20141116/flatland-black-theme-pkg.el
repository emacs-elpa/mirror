;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatland-black-theme" "20141116"
  "An Emacs 24 theme based on Flatland Black (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/flatland-black-theme"
  :commit "fd9bae1b155058d2fd3155259bdd28858d5178de"
  :revdesc "fd9bae1b1550")
