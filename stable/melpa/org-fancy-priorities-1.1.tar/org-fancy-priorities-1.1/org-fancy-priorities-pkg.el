;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-fancy-priorities" "1.1"
  "Display org priorities as custom strings."
  ()
  :url "https://github.com/harrybournis/org-fancy-priorities"
  :commit "fc09edc9b139e82395982d08db2825702045cb85"
  :revdesc "fc09edc9b139"
  :keywords '("convenience" "faces" "outlines")
  :authors '(("Harry Bournis" . "harrybournis@gmail.com"))
  :maintainers '(("Harry Bournis" . "harrybournis@gmail.com")))
