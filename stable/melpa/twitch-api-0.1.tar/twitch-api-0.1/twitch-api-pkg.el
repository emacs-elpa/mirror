;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "twitch-api" "0.1"
  "An elisp interface for the Twitch.tv API."
  '((emacs "24.3"))
  :url "https://github.com/BenediktBroich/twitch-api"
  :commit "60ba21e275c4c9fa405e8874a2bb3759ffaee3fc"
  :revdesc "60ba21e275c4"
  :keywords '("multimedia" "twitch-api"))
