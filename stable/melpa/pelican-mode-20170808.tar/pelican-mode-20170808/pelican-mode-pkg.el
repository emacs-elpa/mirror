;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pelican-mode" "20170808"
  "Minor mode for editing Pelican sites."
  '((emacs "25"))
  :url "https://git.korewanetadesu.com/pelican-mode.git"
  :commit "8b13c30c4ec38dd535eadf26e463f8616d5c089c"
  :revdesc "8b13c30c4ec3"
  :keywords '("convenience" "editing")
  :authors '(("Joe Wreschnig" . "joe.wreschnig@gmail.com"))
  :maintainers '(("Joe Wreschnig" . "joe.wreschnig@gmail.com")))
