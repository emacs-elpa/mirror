;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-colemak-minimal" "1.0.0"
  "Minimal Colemak key bindings for evil-mode."
  '((emacs "24")
    (evil  "1.2.12"))
  :url "https://github.com/bmallred/evil-colemak-minimal"
  :commit "e3a882473d043005dfe7f7bea21f8308a927c8ab"
  :revdesc "e3a882473d04"
  :keywords '("colemak" "evil")
  :authors '(("Bryan Allred" . "bryan@revolvingcow.com"))
  :maintainers '(("Bryan Allred" . "bryan@revolvingcow.com")))
