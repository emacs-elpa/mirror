;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-brain" "0.94"
  "Org-mode concept mapping."
  '((emacs "25.1")
    (org   "9.2"))
  :url "https://github.com/Kungsgeten/org-brain"
  :commit "49e5231ea1c64b4cced041a6d5d63e5871965018"
  :revdesc "49e5231ea1c6"
  :keywords '("outlines" "hypermedia")
  :authors '(("Erik Sjöstrand" . "sjostrand.erik@gmail.com"))
  :maintainers '(("Erik Sjöstrand" . "sjostrand.erik@gmail.com")))
