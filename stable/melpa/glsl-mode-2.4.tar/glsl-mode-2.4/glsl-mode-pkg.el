;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "glsl-mode" "2.4"
  "Major mode for Open GLSL shader files."
  ()
  :url "https://github.com/jimhourihan/glsl-mode"
  :commit "b07112016436d9634cd4ef747f9af6b01366d136"
  :revdesc "b07112016436"
  :keywords '("languages" "opengl" "gpu" "spir-v" "vulkan")
  :authors '((nil . "Xavier.Decoret@imag.fr")
             ("Jim Hourihan" . "jimhourihan~at~gmail.com"))
  :maintainers '((nil . "Xavier.Decoret@imag.fr")
                 ("Jim Hourihan" . "jimhourihan~at~gmail.com")))
