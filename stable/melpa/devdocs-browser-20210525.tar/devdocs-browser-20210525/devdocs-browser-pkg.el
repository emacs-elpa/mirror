;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devdocs-browser" "20210525"
  "Browse devdocs.io documents using EWW."
  '((emacs "27.1"))
  :url "https://github.com/blahgeek/emacs-devdocs-browser"
  :commit "0df2bb41504ce229aeef80bfb7e9f3b2dda0c8d1"
  :revdesc "0df2bb41504c"
  :keywords '("docs" "help" "tools")
  :authors '(("blahgeek" . "i@blahgeek.com"))
  :maintainers '(("blahgeek" . "i@blahgeek.com")))
