;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projection" "0.1"
  "Project specific compilation commands."
  '((emacs         "29.0")
    (project       "0.8.1")
    (compile-multi "0.1"))
  :url "https://github.com/mohkale/projection"
  :commit "3cfafe98e40254c3d0d0dc2308f42a8b342b7cd7"
  :revdesc "3cfafe98e402"
  :keywords '("project")
  :authors '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@kisara.moe")))
