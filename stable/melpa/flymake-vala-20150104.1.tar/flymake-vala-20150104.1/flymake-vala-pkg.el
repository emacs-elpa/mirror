;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-vala" "20150104.1"
  "A flymake handler for vala-mode files."
  '((flymake-easy "0.1"))
  :url "https://github.com/daniellawrence/flymake-vala"
  :commit "f9daac08c5fddc7b3e4f4e7a72b32cfdcb84d9c9"
  :revdesc "f9daac08c5fd"
  :authors '(("Daniel Lawrence" . "dannyla@linux.com"))
  :maintainers '(("Daniel Lawrence" . "dannyla@linux.com")))
