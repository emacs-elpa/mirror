;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-wild-notifier" "0.7.0"
  "Customizable org-agenda notifications."
  '((alert "1.2")
    (async "1.9.3")
    (dash  "2.18.0")
    (emacs "27.1"))
  :url "https://github.com/emacsorphanage/org-wild-notifier.el"
  :commit "832dd0d606f773499ffdad9845b1cf1f6735399d"
  :revdesc "832dd0d606f7"
  :keywords '("calendar" "convenience")
  :authors '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainers '(("Artem Khramov" . "akhramov+emacs@pm.me")))
