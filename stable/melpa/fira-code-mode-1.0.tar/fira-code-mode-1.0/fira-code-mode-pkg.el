;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fira-code-mode" "1.0"
  "Minor mode for Fira Code ligatures using prettify-symbols."
  '((emacs "24.4"))
  :url "https://github.com/jming422/fira-code-mode"
  :commit "018afe6c09cd4786948ea32d51183e06ec8b90b8"
  :revdesc "018afe6c09cd"
  :keywords '("faces" "ligatures" "fonts" "programming-ligatures")
  :authors '(("Jonathan Ming" . "jming422@gmail.com"))
  :maintainers '(("Jonathan Ming" . "jming422@gmail.com")))
