;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "roguel-ike" "0.1.3"
  "Main file for roguel-ike."
  '((popup "0.5.0"))
  :url "https://github.com/stevenremot/roguel-ike"
  :commit "e2e0c089129353f0d4c08b42baf6dc9d66a05175"
  :revdesc "e2e0c0891293")
