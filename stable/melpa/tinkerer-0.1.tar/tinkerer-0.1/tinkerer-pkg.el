;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tinkerer" "0.1"
  "[No description available]."
  '((s "0"))
  :url "https://github.com/yyr/tinkerer.el"
  :commit "a2908327b3e89ad152e444d45e971506d762a21f"
  :revdesc "a2908327b3e8"
  :keywords '("tinkerer" "blog" "wrapper")
  :authors '(("Yagnesh Raghava Yakkala" . "hi@yagnesh.org"))
  :maintainers '(("Yagnesh Raghava Yakkala" . "hi@yagnesh.org")))
