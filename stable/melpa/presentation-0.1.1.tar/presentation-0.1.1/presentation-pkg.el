;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "presentation" "0.1.1"
  "Display large character for presentation."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/zonuexe/emacs-presentation-mode"
  :commit "e9e402d05a8b6d9e1e7fe853503c92fea4cf65cb"
  :revdesc "e9e402d05a8b"
  :keywords '("environment" "faces" "frames")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
