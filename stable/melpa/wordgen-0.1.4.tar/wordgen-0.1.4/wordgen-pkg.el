;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wordgen" "0.1.4"
  "Random word generator."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/Fanael/wordgen.el"
  :commit "aacad928ae99a953e034a831dfd0ebdf7d52ac1d"
  :revdesc "aacad928ae99"
  :authors '(("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers '(("Fanael Linithien" . "fanael4@gmail.com")))
