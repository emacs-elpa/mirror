;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-prompt-extras" "1.1"
  "Display extra information for your eshell prompt."
  '((emacs "25"))
  :url "https://github.com/zwild/eshell-prompt-extras"
  :commit "f490ab511a36166f09b97811495b09d72c9d37f9"
  :revdesc "f490ab511a36"
  :keywords '("eshell" "prompt")
  :authors '(("zwild" . "judezhao@outlook.com"))
  :maintainers '(("Xu Chunyang" . "xuchunyang56@gmail.com")))
