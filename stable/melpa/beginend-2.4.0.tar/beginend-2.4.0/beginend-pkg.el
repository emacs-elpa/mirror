;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beginend" "2.4.0"
  "Redefine M-< and M-> for some modes."
  '((emacs "25.3"))
  :url "https://github.com/DamienCassou/beginend"
  :commit "61f1eb22718fcd9796b47a98702d161ff323a532"
  :revdesc "v2.4.0-0-g61f1eb22718f"
  :authors '(("Damien Cassou" . "damien@cassou.me")
             ("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")
                 ("Matus Goljer" . "matus.goljer@gmail.com")))
