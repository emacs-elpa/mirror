;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-subtree" "0.0.1"
  "Insert subdirectories in a tree-like fashion."
  '((dash              "2.5.0")
    (dired-hacks-utils "0.0.1"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "3f84ba500117304afc4265f2ee87fc52193e5f59"
  :revdesc "3f84ba500117"
  :keywords '("files")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
