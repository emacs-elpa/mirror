;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hideshow-org" "0.0.0.20120223.10"
  "Provides org-mode like hide and show for hideshow.el."
  ()
  :url "https://github.com/shanecelis/hideshow-org"
  :commit "16419e52e6cdd2f46f755144c0ab11ce00d1a626"
  :revdesc "16419e52e6cd"
  :keywords '("c" "c++" "java" "lisp" "tools" "editing" "comments" "blocks" "hiding" "outlines" "org-mode")
  :authors '(("Shane Celis" . "shanegnufooorg"))
  :maintainers '(("Shane Celis" . "shanegnufooorg")))
