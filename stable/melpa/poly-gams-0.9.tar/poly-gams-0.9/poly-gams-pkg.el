;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-gams" "0.9"
  "Polymode for GAMS."
  '((emacs    "25")
    (polymode "0.2.2"))
  :url "https://github.com/ShiroTakeda/poly-gams"
  :commit "902434632b7f79c23cb8a854d498ad1774bb0d36"
  :revdesc "902434632b7f"
  :keywords '("languages" "multi-modes" "gams"))
