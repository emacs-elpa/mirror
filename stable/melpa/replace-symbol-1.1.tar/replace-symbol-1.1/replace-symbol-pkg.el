;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "replace-symbol" "1.1"
  "Rename symbols in expressions or buffers."
  ()
  :url "https://github.com/bmastenbrook/replace-symbol-el"
  :commit "baf949e528aee1881f455f9c84e67718bedcb3f6"
  :revdesc "v1.1-0-gbaf949e528ae"
  :authors '(("Brian Mastenbrook" . "brian@mastenbrook.net"))
  :maintainers '(("Brian Mastenbrook" . "brian@mastenbrook.net")))
