;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vdiff-magit" "0.3.2"
  "Magit integration for vdiff."
  '((emacs "24.4")
    (vdiff "0.3")
    (magit "2.10.0"))
  :url "https://github.com/justbur/emacs-vdiff-magit"
  :commit "7e841dc7225300dd4d5560faad04e5c44cd8b267"
  :revdesc "7e841dc72253"
  :keywords '("diff")
  :authors '(("Justin Burkett" . "justin@burkett.cc"))
  :maintainers '(("Justin Burkett" . "justin@burkett.cc")))
