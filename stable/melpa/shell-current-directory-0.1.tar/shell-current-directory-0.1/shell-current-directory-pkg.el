;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-current-directory" "0.1"
  "Create new shell based on buffer directory."
  ()
  :url "https://github.com/metaperl/shell-current-directory"
  :commit "1991b085216c6e5c0d603494b0cb89cc5fa9cc52"
  :revdesc "1991b085216c"
  :keywords '("shell" "comint"))
