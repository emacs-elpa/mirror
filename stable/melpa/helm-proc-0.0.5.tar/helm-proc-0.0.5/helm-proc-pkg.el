;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-proc" "0.0.5"
  "Helm interface for managing system processes."
  '((helm "1.6.0"))
  :url "https://github.com/markus1189/helm-proc"
  :commit "0a75a86e4f381143134e0cdcd8c84c5b5b0fb2d6"
  :revdesc "0.0.5-0-g0a75a86e4f38"
  :keywords '("helm")
  :authors '(("Markus Hauck" . "markus1189@gmail.com"))
  :maintainers '(("Markus Hauck" . "markus1189@gmail.com")))
