(define-package "blackjack" "1.0.3" "The game of Blackjack"
  '((emacs "26.2"))
  :commit "d8c8d81093254f977778c55f8dc281a96b77d05d" :authors
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainer
  '("Greg Donald" . "gdonald@gmail.com")
  :keywords
  '("card" "game" "games" "blackjack" "21")
  :url "https://github.com/gdonald/blackjack-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
