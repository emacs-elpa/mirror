;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inverse-acme-theme" "1.0"
  "A theme that looks like an inverse of Acmes color scheme."
  '((autothemer "0.2"))
  :url "https://github.com/djohnson/emacs-theme-gruvbox"
  :commit "c87867d8d24f7c103c72cf4c881282b2959a55ca"
  :revdesc "c87867d8d24f")
