;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-swiftlint" "1.0"
  "Flycheck extension for Swiftlint."
  '((emacs    "25.1")
    (flycheck "0.25"))
  :url "https://github.com/jojojames/flycheck-swiftlint"
  :commit "6e4fa728243af9caa378f47efcfe6c0bcdbc329a"
  :revdesc "6e4fa728243a"
  :keywords '("languages" "swiftlint" "swift" "emacs")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
