;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "math-symbol-lists" "1.3"
  "Lists of Unicode math symbols and latex commands."
  ()
  :url "https://github.com/vspinu/math-symbol-lists"
  :commit "590d9f09f8ad9aab747b97f077396a2035dcf50f"
  :revdesc "590d9f09f8ad"
  :keywords '("unicode" "symbols" "mathematics")
  :authors '(("Vitalie Spinu" . "spinuvit@gmail.com"))
  :maintainers '(("Vitalie Spinu" . "spinuvit@gmail.com")))
