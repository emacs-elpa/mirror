;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "private" "0.1"
  "Take care of your private configuration files."
  '((aes "0.6"))
  :url "https://github.com/cheunghy/private"
  :commit "a39c3c3961dd93be8f301d3e5a01b71a520093f9"
  :revdesc "a39c3c3961dd"
  :keywords '("private" "configuration" "backup" "recover")
  :authors '(("Cheung Mou Wai" . "yeannylam@gmail.com"))
  :maintainers '(("Cheung Mou Wai" . "yeannylam@gmail.com")))
