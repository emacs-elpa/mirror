;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "feebleline" "1.1"
  "Replace modeline with a slimmer proxy."
  ()
  :url "https://github.com/tautologyclub/feebleline"
  :commit "f894fb079f3b65a0b220a9a466d7a79bf1e29432"
  :revdesc "f894fb079f3b"
  :authors '(("Benjamin Lindqvist" . "benjamin.lindqvist@gmail.com"))
  :maintainers '(("Benjamin Lindqvist" . "benjamin.lindqvist@gmail.com")))
