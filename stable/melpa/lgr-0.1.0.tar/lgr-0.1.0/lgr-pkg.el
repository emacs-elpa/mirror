;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lgr" "0.1.0"
  "A fully featured logging framework for Emacs."
  '((emacs "26.1"))
  :url "https://github.com/Fuco1/emacs-lgr"
  :commit "ee486be4527f9f4273658b7e4f65600dba4a8545"
  :revdesc "ee486be4527f"
  :keywords '("logging")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
