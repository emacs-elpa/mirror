;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zombie" "1.0.0"
  "Major mode for editing ZOMBIE programs."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "c108e636e2a2622b09648d8a99ad346082a098ff"
  :revdesc "c108e636e2a2")
