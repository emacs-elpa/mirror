;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-sift" "0.2.0"
  "Run a sift with Projectile."
  '((sift       "0.2.0")
    (projectile "0.13.0"))
  :url "https://github.com/nlamirault/sift.el"
  :commit "8c3f3d14a351a2394027d72ee0599aa73b9f0d13"
  :revdesc "8c3f3d14a351"
  :keywords '("sift" "projectile")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
