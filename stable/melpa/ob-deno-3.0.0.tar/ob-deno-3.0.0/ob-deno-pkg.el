;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-deno" "3.0.0"
  "Babel Functions for Javascript/TypeScript with Deno."
  '((emacs "29.1"))
  :url "https://github.com/isamert/ob-deno"
  :commit "d9225ecf2e4e111d75b1a059ec04448bc044f3d2"
  :revdesc "d9225ecf2e4e"
  :keywords '("literate programming" "reproducible research" "javascript" "typescript" "tools" "deno"))
