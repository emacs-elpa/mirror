;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-pomodoro" "2.1.0"
  "Pomodoro implementation for org-mode."
  '((alert  "0.5.10")
    (cl-lib "0.5"))
  :url "https://github.com/lolownia/org-pomodoro"
  :commit "a6d867865f1a033fb5a09cca6643045d7ebac49c"
  :revdesc "a6d867865f1a"
  :authors '(("Arthur Leonard Andersen" . "leoc.git@gmail.com")
             ("Marcin Koziej" . "marcinatlolowniadotorg"))
  :maintainers '(("Arthur Leonard Andersen" . "leoc.git@gmail.com")
                 ("Marcin Koziej" . "marcinatlolowniadotorg")))
