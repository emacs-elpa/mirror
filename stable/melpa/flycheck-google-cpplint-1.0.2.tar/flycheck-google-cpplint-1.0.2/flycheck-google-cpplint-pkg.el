;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-google-cpplint" "1.0.2"
  "Help to comply with the Google C++ Style Guide."
  '((flycheck "0.20-cvs1"))
  :url "https://github.com/flycheck/flycheck-google-cpplint/"
  :commit "95f2038831d1e04a4ea6f91f0a846a4f989606b7"
  :revdesc "95f2038831d1"
  :keywords '("flycheck" "c" "c++")
  :authors '(("Akiha Senda" . "senda.akiha@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
