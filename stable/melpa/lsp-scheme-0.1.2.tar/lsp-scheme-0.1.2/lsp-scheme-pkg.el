;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-scheme" "0.1.2"
  "Scheme support for lsp-mode."
  '((emacs    "26.1")
    (f        "0.20.0")
    (lsp-mode "8.0.0"))
  :url "https://codeberg.org/rgherdt/emacs-lsp-scheme"
  :commit "1821cf7ecc089251e08f03cf4ab11b60e9b58dda"
  :revdesc "1821cf7ecc08"
  :keywords '("languages" "lisp" "tools")
  :authors '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainers '(("Ricardo G. Herdt" . "r.herdt@posteo.de")))
