;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elm-test-runner" "0.0.1"
  "Enhanced support for running elm-test."
  '((emacs "24.4"))
  :url "https://github.com/juanedi/elm-test-runner"
  :commit "ca7596d4de4f52dfcafba5a1c7a797584b721866"
  :revdesc "ca7596d4de4f")
