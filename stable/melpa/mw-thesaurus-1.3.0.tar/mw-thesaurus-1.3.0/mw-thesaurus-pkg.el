;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mw-thesaurus" "1.3.0"
  "Merriam-Webster Thesaurus."
  '((emacs "27.1"))
  :url "https://github.com/agzam/mw-thesaurus.el"
  :commit "1237e8c31d393bea4810c9fc0d21ed34795c72f4"
  :revdesc "1.3.0-0-g1237e8c31d39"
  :keywords '("wp" "matching")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
