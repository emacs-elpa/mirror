;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wat-ts-mode" "1.0.0"
  "Tree-sitter support for wasm buffers."
  '((emacs "29.1"))
  :url "https://github.com/nverno/wasm-ts-mode"
  :commit "b424be46a718a6c8c7f59e115e0a8e5dd7b6f087"
  :revdesc "b424be46a718"
  :keywords '("wasm" "wat" "languages" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
