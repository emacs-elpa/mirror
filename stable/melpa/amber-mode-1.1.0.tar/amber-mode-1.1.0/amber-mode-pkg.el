;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amber-mode" "1.1.0"
  "A major mode for the Amber programming language."
  '((emacs "26.1"))
  :url "https://codeberg.org/GeorgGD/amber-mode"
  :commit "3a99e7e7b3795687df9e7094b5917dd8a0af4e94"
  :revdesc "3a99e7e7b379"
  :keywords '("amber" "languages")
  :authors '(("Georgios Davakos" . "georgios.davakos@protonmail.com"))
  :maintainers '(("Georgios Davakos" . "georgios.davakos@protonmail.com")))
