;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-epub" "0.3"
  "Export org mode projects to EPUB."
  '((emacs "24.3")
    (org   "9"))
  :url "https://github.com/ofosos/org-epub"
  :commit "3d958203e169cbfb2204c43cb4c5543befec0b9d"
  :revdesc "3d958203e169"
  :keywords '("hypermedia")
  :authors '(("Mark Meyer" . "mark@ofosos.org"))
  :maintainers '(("Mark Meyer" . "mark@ofosos.org")))
