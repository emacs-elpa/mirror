;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plan9-theme" "0.2"
  "A color theme for Emacs based on Plan9."
  ()
  :url "https://github.com/john2x/plan9-theme.el"
  :commit "2a5b1cec4bce9d250aa8b590678aece55316ac28"
  :revdesc "2a5b1cec4bce"
  :authors '(("John Louis Del Rosario" . "john2x@gmail.com"))
  :maintainers '(("John Louis Del Rosario" . "john2x@gmail.com")))
