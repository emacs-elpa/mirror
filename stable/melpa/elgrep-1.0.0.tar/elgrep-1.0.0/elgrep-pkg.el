;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elgrep" "1.0.0"
  "Searching files for regular expressions."
  '((emacs "25.1"))
  :url "https://github.com/TobiasZawada/elgrep"
  :commit "c2c5858f335ac1d0013dc631e5bc2dc16d9b3198"
  :revdesc "c2c5858f335a"
  :keywords '("tools" "matching" "files" "unix")
  :authors '(("Tobias Zawada" . "naehring@smtp.1und1.de"))
  :maintainers '(("Tobias Zawada" . "naehring@smtp.1und1.de")))
