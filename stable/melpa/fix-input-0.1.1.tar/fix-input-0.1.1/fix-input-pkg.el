;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fix-input" "0.1.1"
  "Make input methods play nicely with alternative keyboard layout on OS level."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/fix-input"
  :commit "a70edfa7880ff9b082f358607d2a9ad6a8dcc8f3"
  :revdesc "a70edfa7880f"
  :keywords '("input" "method")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
