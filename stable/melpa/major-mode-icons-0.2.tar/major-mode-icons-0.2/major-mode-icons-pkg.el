;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "major-mode-icons" "0.2"
  "Display icon for major-mode on mode-line."
  '((emacs     "25.1")
    (powerline "2.4"))
  :url "https://github.com/stardiviner/major-mode-icons"
  :commit "0d923d7f6a857b25d2c306a340e09fb56f43e03b"
  :revdesc "0d923d7f6a85"
  :keywords '("frames" "multimedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
