;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "extmap" "1.3"
  "Externally-stored constant mapping for Elisp."
  '((emacs "24.4"))
  :url "https://github.com/doublep/extmap"
  :commit "c7af95865ef083327d299b86c254ca87fa88a504"
  :revdesc "c7af95865ef0"
  :keywords '("lisp")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
