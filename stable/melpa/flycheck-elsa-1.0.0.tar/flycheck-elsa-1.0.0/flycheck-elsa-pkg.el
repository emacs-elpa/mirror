;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-elsa" "1.0.0"
  "Flycheck for Elsa."
  '((emacs "25")
    (seq   "2.0")
    (cask  "0.8.4"))
  :url "https://github.com/emacs-elsa/flycheck-elsa"
  :commit "059050f83642c1d1957d202efc51089d88befe01"
  :revdesc "059050f83642"
  :keywords '("convenience")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
