;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "1.1.2"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "526e94404692d36715db22248dc8a39dadf1ccdd"
  :revdesc "526e94404692"
  :keywords '("outlines" "tools" "convenience" "org" "todo" "gtd" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
