;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pif" "0.0.7"
  "Prevent Initial Flash of Light."
  '((emacs "29.1"))
  :url "https://github.com/oliverepper/pif"
  :commit "85e55528967d5aee87ae84b306c1cd292a6705c9"
  :revdesc "85e55528967d"
  :keywords '("convenience" "faces" "display" "startup" "appearance" "dark-theme")
  :authors '(("Oliver Epper" . "oliver.epper@gmail.com"))
  :maintainers '(("Oliver Epper" . "oliver.epper@gmail.com")))
