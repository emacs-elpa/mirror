;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidev-mode" "0.1.0"
  "AI-assisted development tools for Emacs."
  '((emacs "27.1"))
  :url "https://github.com/yourusername/aidev-mode"
  :commit "8afb6e82d64491a185d1be9714ec4ce7a9bbb7a6"
  :revdesc "8afb6e82d644"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Your Name Here" . "your.email@example.com"))
  :maintainers '(("Your Name Here" . "your.email@example.com")))
