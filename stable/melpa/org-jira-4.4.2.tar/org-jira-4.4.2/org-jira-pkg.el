;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-jira" "4.4.2"
  "Syncing between Jira and Org-mode."
  '((emacs   "24.5")
    (cl-lib  "0.5")
    (request "0.2.0")
    (dash    "2.14.1"))
  :url "https://github.com/ahungry/org-jira"
  :commit "ac625b080545a1ade22d070c23624f71b7ab02b5"
  :revdesc "ac625b080545"
  :keywords '("ahungry" "jira" "org" "bug" "tracker")
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
