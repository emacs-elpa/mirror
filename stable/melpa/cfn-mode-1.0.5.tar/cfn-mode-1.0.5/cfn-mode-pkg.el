;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "1.0.5"
  "AWS cloudformation mode."
  '((emacs     "26.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "ac122af751ba9903599c6eb9c3e9e12a375e19d0"
  :revdesc "cfn-mode/v1.0.5-0-gac122af751ba"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
