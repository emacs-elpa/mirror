;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kill-file-path" "1.0"
  "Copy file name into kill ring."
  '((emacs "26"))
  :url "https://github.com/chyla/kill-file-path/kill-file-path.el"
  :commit "71670558c22eb51a1f9fea4e999f55e1aa7eb10d"
  :revdesc "71670558c22e"
  :keywords '("files")
  :authors '(("Adam Chyła" . "adam@chyla.org"))
  :maintainers '(("Adam Chyła" . "adam@chyla.org")))
