;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magent" "0.1.0"
  "AI coding agent."
  '((emacs       "29.1")
    (gptel       "0.9.8")
    (transient   "0.7.8")
    (yaml        "1.0.0")
    (compat      "30.1.0.0")
    (acp         "0.12.2")
    (agent-shell "0.57.1"))
  :url "https://github.com/jamie-cui/magent"
  :commit "24c5c48f4a1df8e9a88c6f45b980ed89c409a1c7"
  :revdesc "24c5c48f4a1d"
  :keywords '("tools" "ai" "copilot")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
