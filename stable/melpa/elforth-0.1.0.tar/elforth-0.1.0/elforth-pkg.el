;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elforth" "0.1.0"
  "Do you have what it takes to hack Emacs Lisp in Forth?."
  '((emacs "26.1"))
  :url "https://github.com/lassik/elforth"
  :commit "58f444ad1e06ff4d22a354cd2d7d617feb6df0c7"
  :revdesc "58f444ad1e06"
  :keywords '("games")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
