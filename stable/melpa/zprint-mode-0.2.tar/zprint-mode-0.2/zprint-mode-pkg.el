;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zprint-mode" "0.2"
  "Reformat Clojure(Script) code using zprint."
  '((emacs "24.3"))
  :url "https://github.com/pesterhazy/zprint-mode.el"
  :commit "aaad0bbf784f335263b66e488579c27d8f24392a"
  :revdesc "aaad0bbf784f"
  :keywords '("tools")
  :authors '(("Paulus Esterhazy" . "(pesterhazy@gmail.com)"))
  :maintainers '(("Paulus Esterhazy" . "(pesterhazy@gmail.com)")))
