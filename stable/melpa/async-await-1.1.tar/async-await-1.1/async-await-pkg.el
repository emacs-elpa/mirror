;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async-await" "1.1"
  "Async/Await."
  '((emacs   "25.1")
    (promise "1.1")
    (iter2   "0.9.10"))
  :url "https://github.com/chuntaro/emacs-async-await"
  :commit "deef2bb343463f5196545f1dd8c2a32d0cb3b146"
  :revdesc "1.1-0-gdeef2bb34346"
  :keywords '("async" "await" "convenience")
  :authors '(("chuntaro" . "chuntaro@sakura-games.jp"))
  :maintainers '(("chuntaro" . "chuntaro@sakura-games.jp")))
