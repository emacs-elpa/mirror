;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "objed" "0.8.1"
  "Navigate and edit text objects."
  '((emacs  "25")
    (cl-lib "0.5"))
  :url "https://github.com/clemera/objed"
  :commit "4798b5b9fd531562ac17d6148e86cd8cdc1bc985"
  :revdesc "4798b5b9fd53"
  :keywords '("convenience")
  :authors '(("Clemens Radermacher" . "clemera@posteo.net"))
  :maintainers '(("Clemens Radermacher" . "clemera@posteo.net")))
