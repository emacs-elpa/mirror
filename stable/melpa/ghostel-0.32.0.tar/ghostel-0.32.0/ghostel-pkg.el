;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.32.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "658ad48b0aec1d8883332a964c80b5af0a26bdf1"
  :revdesc "658ad48b0aec"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
