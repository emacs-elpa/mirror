;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-random-todo" "0.5.3"
  "Show a random TODO (with alert) every so often."
  '((emacs "24.3")
    (alert "1.2"))
  :url "https://github.com/unhammer/org-random-todo"
  :commit "09228e55f1cc702053d305fdea2b094b548e6dbe"
  :revdesc "0.5.3-0-g09228e55f1cc"
  :keywords '("org" "todo" "notification" "calendar")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
