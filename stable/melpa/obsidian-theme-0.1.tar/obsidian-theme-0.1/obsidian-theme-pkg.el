;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "obsidian-theme" "0.1"
  "Port of the eclipse obsidian theme."
  ()
  :url "https://github.com/mswift42/obsidian-theme"
  :commit "78c3d711759a5b8fc0d41f685870b9fa15388f2d"
  :revdesc "78c3d711759a")
