;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "psci" "0.0.6"
  "Major mode for purescript repl psci."
  '((purescript-mode "13.10")
    (dash            "2.9.0")
    (s               "1.9.0")
    (f               "0.17.1")
    (deferred        "0.3.2"))
  :url "https://github.com/ardumont/emacs-psci"
  :commit "8c2d5a0ba604ec593f83f632b2830a87f41f84d4"
  :revdesc "8c2d5a0ba604"
  :keywords '("purescript" "psci" "repl" "major" "mode")
  :authors '(("Antoine R. Dumont" . "eniotna.tATgmail.com"))
  :maintainers '(("Antoine R. Dumont" . "eniotna.tATgmail.com")))
