;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsc" "1.6.20250711"
  "Helper for emacsc(1)."
  ()
  :url "https://github.com/knu/emacsc"
  :commit "c0d51eea7c5cbef4ea49350dff8c721227635be6"
  :revdesc "c0d51eea7c5c"
  :keywords '("tools")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
