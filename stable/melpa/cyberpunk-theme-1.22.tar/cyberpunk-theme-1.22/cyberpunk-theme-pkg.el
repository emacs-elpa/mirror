;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cyberpunk-theme" "1.22"
  "Cyberpunk Color Theme."
  ()
  :url "https://github.com/n3mo/cyberpunk-theme.el"
  :commit "81004fc774d373777d426926fc11abcf1e7ab334"
  :revdesc "81004fc774d3"
  :keywords '("color" "theme" "cyberpunk")
  :authors '(("Nicholas M. Van Horn" . "nvanhorn@protonmail.com"))
  :maintainers '(("Nicholas M. Van Horn" . "nvanhorn@protonmail.com")))
