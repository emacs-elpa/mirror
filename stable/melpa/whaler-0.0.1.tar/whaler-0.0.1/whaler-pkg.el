;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whaler" "0.0.1"
  "Move between directories blazingly fast."
  '((emacs "24.5"))
  :url "https://github.com/salorack/whaler.el"
  :commit "95c815193d2e85db18c859d4d8eb03cb387a7913"
  :revdesc "95c815193d2e"
  :keywords '("matching")
  :authors '(("Hector Alarcon" . "salorack@protonmail.com"))
  :maintainers '(("Hector Alarcon" . "salorack@protonmail.com")))
