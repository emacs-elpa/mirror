;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keymap-utils" "4.1.4"
  "Keymap utilities."
  '((emacs  "28.1")
    (compat "31.0")
    (llama  "1.0"))
  :url "https://github.com/tarsius/keymap-utils"
  :commit "3064e5ffe98458500c75bf7c854c45d3e60e8e90"
  :revdesc "v4.1.4-0-g3064e5ffe984"
  :keywords '("convenience" "extensions")
  :authors '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev")))
