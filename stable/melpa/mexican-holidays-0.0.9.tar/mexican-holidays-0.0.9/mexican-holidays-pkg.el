;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mexican-holidays" "0.0.9"
  "Mexico holidays for Emacs calendar."
  ()
  :url "https://github.com/shopClerk/mexican-holidays"
  :commit "101d41120c8e93e124dda7d0b76d55213320a8cd"
  :revdesc "101d41120c8e"
  :keywords '("calendar")
  :authors '(("Saúl Gutiérrez" . "me@sggc.me"))
  :maintainers '(("Saúl Gutiérrez" . "me@sggc.me")))
