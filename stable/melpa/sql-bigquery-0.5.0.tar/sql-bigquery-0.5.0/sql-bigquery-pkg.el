;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sql-bigquery" "0.5.0"
  "[No description available]."
  '((emacs "24.4"))
  :url "https://github.com/MartinNowak/sql-bigquery"
  :commit "e8f56cb4d2d6806aed932a7ae923079c9636c7cc"
  :revdesc "e8f56cb4d2d6"
  :keywords '("sql" "bigquery")
  :authors '(("Martin Nowak" . "code+sql-bigquery@dawg.eu"))
  :maintainers '(("Martin Nowak" . "code+sql-bigquery@dawg.eu")))
