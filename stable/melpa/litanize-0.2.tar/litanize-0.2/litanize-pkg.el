;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "litanize" "0.2"
  "Generate \"Latour Litanies\"."
  '((emacs  "24.1")
    (enlive "0.0.1")
    (s      "1.12.0"))
  :url "https://github.com/zzkt/litanizer"
  :commit "ce74f10540d6b335c4d0966cbabcf5099531280e"
  :revdesc "ce74f10540d6"
  :keywords '("tools" "latour litany" "alien phenomenology" "ontography" "metaphorism" "carpentry")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
