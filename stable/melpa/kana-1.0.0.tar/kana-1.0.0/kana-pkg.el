;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kana" "1.0.0"
  "Review hiragana and katakana."
  '((emacs "24.4"))
  :url "https://github.com/chenyanming/kana"
  :commit "d66337490874827bd66c830d7ab20b120f159f3c"
  :revdesc "d66337490874"
  :keywords '("tools")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
