;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pache-dark-theme" "0.1"
  "A high-contrast gruvbox theme for Emacs adapted from Gruber Darker."
  ()
  :url "https://github.com/0xhenrique/pache-dark-theme"
  :commit "c6ef1260b07359bf4c175cd0ffa6bdc0b29489fe"
  :revdesc "c6ef1260b073"
  :authors '(("Henrique Marques" . "hm2030master@proton.me"))
  :maintainers '(("Henrique Marques" . "hm2030master@proton.me")))
