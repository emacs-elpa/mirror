;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-company" "0.2.8"
  "Helm interface for company-mode."
  '((helm    "1.5.9")
    (company "0.10.0"))
  :url "https://github.com/Sodel-the-Vociferous/helm-company"
  :commit "4622b82353220ee6cc33468f710fa5b6b253b7f1"
  :revdesc "4622b8235322"
  :authors '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Daniel Ralston" . "Sodel-the-Vociferous@users.noreply.github.com")))
