;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "4.5"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "c366365aaddeb3a65dc0816c8f93ec209dc9de44"
  :revdesc "v4.5-0-gc366365aadde")
