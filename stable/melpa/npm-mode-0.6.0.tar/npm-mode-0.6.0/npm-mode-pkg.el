;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "npm-mode" "0.6.0"
  "Minor mode for working with npm projects."
  '((emacs "24.1"))
  :url "https://github.com/mojochao/npm-mode"
  :commit "84b35211cba4f2d5f03b8dc2b60ae4b03d90bf8a"
  :revdesc "84b35211cba4"
  :keywords '("convenience" "project" "javascript" "node" "npm")
  :authors '(("Allen Gooch" . "allen.gooch@gmail.com"))
  :maintainers '(("Allen Gooch" . "allen.gooch@gmail.com")))
