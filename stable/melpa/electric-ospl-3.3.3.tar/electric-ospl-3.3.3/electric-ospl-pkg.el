;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-ospl" "3.3.3"
  "Electric OSPL Mode."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~swflint/electric-ospl-mode"
  :commit "e7761e5cc901d4b7208003a039259661ff2092d8"
  :revdesc "e7761e5cc901"
  :keywords '("convenience" "text")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
