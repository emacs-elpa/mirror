;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "protobuf-mode" "36.0"
  "Major mode for editing protocol buffers."
  ()
  :url "https://github.com/protocolbuffers/protobuf"
  :commit "3f17acbf7ffbda81db8be17505554c726e558bb2"
  :revdesc "v36.0-0-g3f17acbf7ffb"
  :keywords '("google" "protobuf" "languages")
  :authors '(("Alexandre Vassalotti" . "alexandre@peadrop.com"))
  :maintainers '(("Alexandre Vassalotti" . "alexandre@peadrop.com")))
