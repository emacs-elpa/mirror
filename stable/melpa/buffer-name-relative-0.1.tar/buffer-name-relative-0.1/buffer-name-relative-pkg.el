;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-name-relative" "0.1"
  "Relative buffer names."
  '((emacs "28.1"))
  :url "https://codeberg.com/ideasman42/emacs-buffer-name-relative"
  :commit "6c0657999d152cb6351b81166b745d2ac4bae059"
  :revdesc "6c0657999d15"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
