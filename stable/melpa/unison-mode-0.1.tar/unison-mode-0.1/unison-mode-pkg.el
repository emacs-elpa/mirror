;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison-mode" "0.1"
  "Syntax highlighting for unison file synchronization program."
  ()
  :url "https://github.com/impaktor/unison-mode"
  :commit "b88af17a68dca562f73973e87433d4184c422e8c"
  :revdesc "b88af17a68dc"
  :keywords '("symchronization" "unison")
  :authors '(("Karl Fogelmark" . "karlfogel@gmail.com"))
  :maintainers '(("Karl Fogelmark" . "karlfogel@gmail.com")))
