;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "switch-buffer-functions" "0.0.1"
  "Hook run when current buffer changed."
  ()
  :url "https://github.com/10sr/switch-buffer-functions-el"
  :commit "e1bccfff2d123b6218efab16c486215cedb9a108"
  :revdesc "e1bccfff2d12"
  :keywords '("hook" "utility")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
