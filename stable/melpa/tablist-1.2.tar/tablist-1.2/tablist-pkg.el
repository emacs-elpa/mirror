;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tablist" "1.2"
  "Extended tabulated-list-mode."
  '((emacs "24.3"))
  :url "https://github.com/emacsorphanage/tablist"
  :commit "4e9d94362896a9f3d27bb2851b01cf7d9b433ac2"
  :revdesc "v1.2-0-g4e9d94362896"
  :keywords '("extensions" "lisp")
  :authors '(("Andreas Politz" . "politza@fh-trier.de"))
  :maintainers '(("Andreas Politz" . "politza@fh-trier.de")))
