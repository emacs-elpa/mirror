;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-numbers" "0.2.3"
  "Highlight numbers in source code."
  '((emacs       "24")
    (parent-mode "2.0"))
  :url "https://github.com/Fanael/highlight-numbers"
  :commit "b7adef0286aaa5bca8e98a12d0ffed3a880e25aa"
  :revdesc "b7adef0286aa"
  :authors '(("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers '(("Fanael Linithien" . "fanael4@gmail.com")))
