;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "astyle" "0.1.0"
  "Astyle formatter functions."
  '((emacs       "25.1")
    (reformatter "0.4"))
  :url "https://github.com/storvik/emacs-astyle"
  :commit "c2e017a5f80bbb6ece83443c94630954db320c3f"
  :revdesc "c2e017a5f80b"
  :keywords '("astyle" "c" "c++" "cpp" "reformatter"))
