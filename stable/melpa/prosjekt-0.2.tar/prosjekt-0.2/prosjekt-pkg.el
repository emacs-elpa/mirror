;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prosjekt" "0.2"
  "A software project tool for emacs."
  ()
  :url "https://github.com/abingham/prosjekt"
  :commit "9857baaa27923bb20655df0049579ecd8ade1c7b"
  :revdesc "9857baaa2792"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
