;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-lobsters" "0.1"
  "Browse lobste.rs stories with ivy."
  '((ivy    "0.8.0")
    (cl-lib "0.5"))
  :url "https://github.com/julienXX/ivy-lobsters"
  :commit "ab49b2e119441a318adaf840450301fffb333245"
  :revdesc "ab49b2e11944"
  :authors '(("Julien Blanchard" . "https://github.com/julienXX"))
  :maintainers '(("Julien Blanchard" . "https://github.com/julienXX")))
