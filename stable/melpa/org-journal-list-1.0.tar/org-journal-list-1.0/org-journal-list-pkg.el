;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-journal-list" "1.0"
  "Org mode Journal List."
  '((emacs "25"))
  :url "https://github.com/huytd/org-journal-list"
  :commit "005982555b4e699cfc36a47bb09eb058f270ca20"
  :revdesc "005982555b4e"
  :authors '(("Huy Tran" . "huytd189@gmail.com"))
  :maintainers '(("Huy Tran" . "huytd189@gmail.com")))
