;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.33.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f1324a1fc58dea381224e0fd08306a70fe109777"
  :revdesc "f1324a1fc58d"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
