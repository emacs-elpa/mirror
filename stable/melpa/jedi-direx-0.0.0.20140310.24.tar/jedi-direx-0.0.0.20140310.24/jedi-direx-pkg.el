;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jedi-direx" "0.0.0.20140310.24"
  "Tree style source code viewer for Python buffer."
  '((jedi  "0.1.2")
    (direx "0.1alpha"))
  :url "https://github.com/tkf/emacs-jedi-direx"
  :commit "7a2e677400717ed12b959cb5988e7b3fb1c12117"
  :revdesc "7a2e67740071"
  :authors '(("Takafumi Arakaki" . "aka.tkfatgmail.com"))
  :maintainers '(("Takafumi Arakaki" . "aka.tkfatgmail.com")))
