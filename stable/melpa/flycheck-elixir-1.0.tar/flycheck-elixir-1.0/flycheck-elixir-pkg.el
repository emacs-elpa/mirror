;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-elixir" "1.0"
  "Support Elixir in flycheck."
  '((flycheck "0.26"))
  :url "https://github.com/lbolla/emacs-flycheck-elixir"
  :commit "e234b8798942fc6480a22cec8e47da01909809e6"
  :revdesc "e234b8798942"
  :authors '(("Lorenzo Bolla" . "lbolla@gmail.com"))
  :maintainers '(("Lorenzo Bolla" . "lbolla@gmail.com")))
