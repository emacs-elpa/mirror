;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keychain-environment" "2.4.1"
  "Load keychain environment variables."
  ()
  :url "https://github.com/tarsius/keychain-environment"
  :commit "d3643196de6dc79ea77f9f4805028350fd76100b"
  :revdesc "2.4.1-0-gd3643196de6d"
  :keywords '("gnupg" "pgp" "ssh")
  :authors '(("Paul Tipper" . "bluefooatgooglemaildotcom"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
