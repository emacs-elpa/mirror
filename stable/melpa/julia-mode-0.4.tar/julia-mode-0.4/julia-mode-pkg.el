;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-mode" "0.4"
  "Major mode for editing Julia source code."
  '((emacs "24.3"))
  :url "https://github.com/JuliaEditorSupport/julia-emacs"
  :commit "8bfc709716a257521cb386f20b8932e83db930a9"
  :revdesc "8bfc709716a2"
  :keywords '("languages"))
