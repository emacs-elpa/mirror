;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tfsmacs" "1.0"
  "MS Team Foundation Server commands."
  '((emacs   "25")
    (tablist "0.70"))
  :url "https://github.com/sebasmonia/tfsmacs/"
  :commit "51050223fd9b4376d5a2dc5c73c2bc4f3e14183f"
  :revdesc "51050223fd9b"
  :keywords '("tfs" "vc")
  :authors '(("Dino Chiesa" . "dpchiesa@outlook.com")
             ("Sebastian Monia" . "smonia@outlook.com"))
  :maintainers '(("Dino Chiesa" . "dpchiesa@outlook.com")
                 ("Sebastian Monia" . "smonia@outlook.com")))
