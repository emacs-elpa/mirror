;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddp" "0.1.0"
  "Dynamic Data Processor with cmd tools."
  '((emacs "29.1"))
  :url "https://github.com/eki3z/ddp.el"
  :commit "89f88de868a090b1464670427c1e47f61b389bf9"
  :revdesc "89f88de868a0"
  :keywords '("tools")
  :authors '(("Eki Zhang" . "liuyinz@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz@gmail.com")))
