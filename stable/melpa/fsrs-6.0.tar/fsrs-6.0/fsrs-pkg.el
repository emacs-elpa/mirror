;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fsrs" "6.0"
  "Free Spaced Repetition Scheduler."
  '((emacs "25.1"))
  :url "https://github.com/open-spaced-repetition/lisp-fsrs"
  :commit "b2c9b8e928b030b80ae7278701eed2bf0c53a79d"
  :revdesc "b2c9b8e928b0"
  :keywords '("tools"))
