;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iregister" "0.5.0"
  "Interactive register commands for Emacs."
  ()
  :url "https://github.com/atykhonov/iregister.el"
  :commit "0b431136056735657e77235658365019943a13ab"
  :revdesc "0b4311360567"
  :keywords '("convenience")
  :authors '(("Andrey Tykhonov" . "atykhonov@gmail.com"))
  :maintainers '(("Andrey Tykhonov" . "atykhonov@gmail.com")))
