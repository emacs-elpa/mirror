;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-reveal-layouts" "0.1.0"
  "Predefined layouts for ox-reveal."
  '((emacs     "27.1")
    (transient "0.3.0"))
  :url "https://github.com/GerardoCendejas/ox-reveal-layouts"
  :commit "eb63e5ddc106b83e81f6305964f26bea2c4db6d5"
  :revdesc "eb63e5ddc106"
  :keywords '("ox-reveal" "layouts" "presentations")
  :authors '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu"))
  :maintainers '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu")))
