;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-habit-ng" "0.7.1"
  "Full RRULE recurrence for org-habit."
  '((emacs     "28.1")
    (org       "9.6")
    (transient "0.13.5"))
  :url "https://codeberg.org/Trevoke/org-habit-ng"
  :commit "7fdd0331edbce773ca87f6544c501accd32711f9"
  :revdesc "0.7.1-0-g7fdd0331edbc"
  :keywords '("calendar" "org" "habits")
  :authors '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainers '(("Aldric Giacomoni" . "trevoke@gmail.com")))
