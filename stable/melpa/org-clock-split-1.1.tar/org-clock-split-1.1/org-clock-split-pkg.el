;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-split" "1.1"
  "Split clock entries."
  '((emacs "24"))
  :url "https://github.com/justintaft/emacs-org-clock-split"
  :commit "eab3db1b8aa79cf2baa1054410f86024b158833e"
  :revdesc "eab3db1b8aa7"
  :keywords '("calendar")
  :authors '(("Justin Taft" . "https://github.com/justintaft"))
  :maintainers '(("Justin Taft" . "https://github.com/justintaft")))
