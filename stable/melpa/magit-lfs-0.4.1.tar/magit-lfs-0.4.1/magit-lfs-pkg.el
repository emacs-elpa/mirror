;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-lfs" "0.4.1"
  "Magit plugin for Git LFS."
  '((emacs "24.4")
    (magit "2.10.3")
    (dash  "2.13.0"))
  :url "https://github.com/ailrun/magit-lfs"
  :commit "ee005580c1441cce4251734dd239c84d9e88639e"
  :revdesc "ee005580c144"
  :keywords '("magit" "git" "lfs" "tools" "vc")
  :authors '(("Junyoung/Clare Jang" . "jjc9310@gmail.com"))
  :maintainers '(("Junyoung/Clare Jang" . "jjc9310@gmail.com")))
