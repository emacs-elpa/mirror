;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "find-temp-file" "0.0.0.20240512.38"
  "Open quickly a temporary file."
  ()
  :url "https://github.com/thisirs/find-temp-file.git"
  :commit "76414b6ba8660905675ec8969f5db0adb270bb80"
  :revdesc "76414b6ba866"
  :keywords '("convenience")
  :authors '(("Sylvain Rousseau" . "thisirsatgmaildotcom"))
  :maintainers '(("Sylvain Rousseau" . "thisirsatgmaildotcom")))
