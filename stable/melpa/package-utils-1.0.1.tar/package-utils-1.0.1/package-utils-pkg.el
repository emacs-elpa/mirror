;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-utils" "1.0.1"
  "Extensions for package.el."
  '((restart-emacs "0.1.1"))
  :url "https://github.com/Silex/package-utils"
  :commit "5621b95c56b55499f0463fd8b29501da25d861bd"
  :revdesc "1.0.1-0-g5621b95c56b5"
  :keywords '("package" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
