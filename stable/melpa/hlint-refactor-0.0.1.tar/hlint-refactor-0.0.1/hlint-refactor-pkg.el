;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hlint-refactor" "0.0.1"
  "Apply HLint suggestions."
  ()
  :url "https://github.com/mpickering/hlint-refactor-mode"
  :commit "f5c9efd4bea6b0ef57d162b85bc9bb8b0a9003f8"
  :revdesc "f5c9efd4bea6"
  :keywords '("haskell" "refactor"))
