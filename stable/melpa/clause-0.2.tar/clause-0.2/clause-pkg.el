;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clause" "0.2"
  "Clause functions."
  '((emacs         "27.1")
    (segment       "0.1")
    (mark-thing-at "0.3"))
  :url "https://codeberg.org/martianh/clause.el"
  :commit "319bd55ebcaf9c8b14d688f37484c3c8c97c846b"
  :revdesc "319bd55ebcaf"
  :keywords '("wp" "convenience" "sentences")
  :authors '(("Marty Hiatt" . "martianhiatus[at]riseup[dot]net"))
  :maintainers '(("Marty Hiatt" . "martianhiatus[at]riseup[dot]net")))
