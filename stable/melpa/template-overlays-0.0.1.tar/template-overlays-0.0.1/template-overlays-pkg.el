;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "template-overlays" "0.0.1"
  "Emacs overlays for template systems."
  '((emacs "24.4")
    (ov    "20150311.2228"))
  :url "http://www.github.com/mmontone/template-overlays"
  :commit "20fabba790e39aa1d2d039167e63c250e1256b6d"
  :revdesc "20fabba790e3"
  :keywords '("templates" "overlays")
  :authors '(("Mariano Montone" . "marianomontone@gmail.com"))
  :maintainers '(("Mariano Montone" . "marianomontone@gmail.com")))
