;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-glsl" "0.2"
  "Support glsl in company-mode."
  '((company   "0.9.4")
    (glsl-mode "2.0"))
  :url "https://github.com/guidoschmidt/company-glsl"
  :commit "76d8cb36d2c41633c5bfbac0fbc9bf531a43530d"
  :revdesc "76d8cb36d2c4"
  :authors '(("Guido Schmidt" . "git@guidoschmidt.cc"))
  :maintainers '(("Guido Schmidt" . "git@guidoschmidt.cc")))
