;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "musicbrainz-interactive" "20260802"
  "Interactive commands for MusicBrainz related things."
  '((emacs       "28.1")
    (musicbrainz "0.1"))
  :url "https://github.com/zzkt/metabrainz"
  :commit "47f290b3901e30e1ae93c0f7d8b4598defe285bf"
  :revdesc "47f290b3901e"
  :keywords '("data" "convenience" "music")
  :authors '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me"))
  :maintainers '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me")))
