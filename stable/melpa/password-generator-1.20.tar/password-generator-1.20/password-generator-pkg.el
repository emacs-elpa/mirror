;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "password-generator" "1.20"
  "Password generator for humans. Good, Bad, Phonetic passwords included."
  ()
  :url "https://github.com/zargener/emacs-password-genarator"
  :commit "d754391d11d1d384833eb82fd34e02d2baec36cb"
  :revdesc "d754391d11d1"
  :authors '(("Zargener" . "zargener@gmail.com"))
  :maintainers '(("Zargener" . "zargener@gmail.com")))
