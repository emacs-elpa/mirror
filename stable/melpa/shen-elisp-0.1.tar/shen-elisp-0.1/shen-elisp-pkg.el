;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shen-elisp" "0.1"
  "An implementation of the Shen programming language."
  ()
  :url "https://github.com/deech/shen-elisp"
  :commit "ffe17dee05f75539cf5e4c59395e4c7400ececaa"
  :revdesc "ffe17dee05f7"
  :authors '(("Aditya Siram" . "aditya.siram@gmail.com"))
  :maintainers '(("Aditya Siram" . "aditya.siram@gmail.com")))
