;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clmemo" "0.0.0.20220204.20"
  "Change Log MEMO."
  ()
  :url "https://github.com/ataka/clmemo"
  :commit "f695c38c551f72f6ac5e1a82badc540c80d3b33b"
  :revdesc "f695c38c551f"
  :keywords '("convenience")
  :authors '(("Masayuki Ataka" . "masayuki.ataka@gmail.com"))
  :maintainers '(("Masayuki Ataka" . "masayuki.ataka@gmail.com")))
