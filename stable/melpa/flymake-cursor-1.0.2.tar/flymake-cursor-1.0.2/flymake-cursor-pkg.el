;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-cursor" "1.0.2"
  "Show flymake messages in the minibuffer after delay."
  '((flymake "0.3"))
  :url "https://github.com/illusori/emacs-flymake-cursor"
  :commit "5cac5045398b1436ceb143d48961b50d38ae1396"
  :revdesc "5cac5045398b"
  :keywords '("languages" "mode" "flymake")
  :authors '(("Dino Chiesa" . "dpchiesa@hotmail.com")
             ("Sam Graham" . "libflymake-emacsBLAHBLAHillusori.co.uk"))
  :maintainers '(("Sam Graham" . "libflymake-emacsBLAHBLAHillusori.co.uk")))
