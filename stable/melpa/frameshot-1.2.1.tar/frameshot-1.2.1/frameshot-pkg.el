;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frameshot" "1.2.1"
  "Take screenshots of a frame."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/frameshot"
  :commit "975450f325f0e29a73214deff011ad524f02bc74"
  :revdesc "v1.2.1-0-g975450f325f0"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev")))
