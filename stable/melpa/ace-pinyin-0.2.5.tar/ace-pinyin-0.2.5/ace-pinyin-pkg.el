;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-pinyin" "0.2.5"
  "Jump to Chinese characters using ace-jump-mode or avy."
  '((ace-jump-mode "2.0")
    (avy           "0.2.0")
    (pinyinlib     "0.1.0"))
  :url "https://github.com/cute-jumper/ace-pinyin"
  :commit "c444d8d6861dafd06dd41e694dc9db32652e3b7c"
  :revdesc "c444d8d6861d"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
