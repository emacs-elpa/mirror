;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bert" "0.1"
  "BERT serialization library for Emacs."
  ()
  :url "https://github.com/manzyuk/bert-el"
  :commit "302c776d9f8b7d5fc9be18fcfb141fdce55c4034"
  :revdesc "302c776d9f8b"
  :keywords '("comm" "data")
  :authors '(("Oleksandr Manzyuk" . "manzyuk@gmail.com"))
  :maintainers '(("Oleksandr Manzyuk" . "manzyuk@gmail.com")))
