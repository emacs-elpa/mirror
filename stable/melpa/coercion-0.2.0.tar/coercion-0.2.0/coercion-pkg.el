;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coercion" "0.2.0"
  "Naming convention style switch."
  '((emacs "29.1"))
  :url "https://github.com/eki3z/coercion.el"
  :commit "aa50f6c51a2363f7827e614c3e533152619dd050"
  :revdesc "aa50f6c51a23"
  :keywords '("convenience" "editing")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
