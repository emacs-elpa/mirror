;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpt-commit" "0.0.2"
  "Commit messages with GPT in Emacs."
  '((emacs   "27.1")
    (magit   "2.90")
    (request "0.3.2"))
  :url "https://github.com/ywkim/gpt-commit"
  :commit "e3bdc836c7f423622e5c7984735a7dab2c2f342b"
  :revdesc "e3bdc836c7f4"
  :authors '(("Youngwook Kim" . "youngwook.kim@gmail.com"))
  :maintainers '(("Youngwook Kim" . "youngwook.kim@gmail.com")))
