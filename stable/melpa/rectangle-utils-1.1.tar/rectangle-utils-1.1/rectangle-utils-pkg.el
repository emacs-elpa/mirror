;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rectangle-utils" "1.1"
  "Some useful rectangle functions."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/thierryvolpiatto/rectangle-utils"
  :commit "6fe38fdd48ef5305a908b94a043a966ac3f2053a"
  :revdesc "v1.1-0-g6fe38fdd48ef"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")))
