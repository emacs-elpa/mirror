;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-recent" "0.9"
  "Dired visited paths history."
  '((emacs "24"))
  :url "https://github.com/vifon/dired-recent.el"
  :commit "b7c90261fe878ba295fb98971f292be924fcea77"
  :revdesc "b7c90261fe87"
  :keywords '("files")
  :authors '(("Wojciech Siewierski" . "wojciechdotsiewierskiatonetdotpl"))
  :maintainers '(("Wojciech Siewierski" . "wojciechdotsiewierskiatonetdotpl")))
