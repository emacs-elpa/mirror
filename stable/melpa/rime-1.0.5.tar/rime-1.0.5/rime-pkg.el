;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rime" "1.0.5"
  "Rime input method."
  '((emacs    "26.3")
    (dash     "2.17.0")
    (cl-lib   "0.6.1")
    (popup    "0.5.3")
    (posframe "0.1.0"))
  :url "https://www.github.com/DogLooksGood/emacs-rime"
  :commit "b93e761209211f8a6de1bb4b8f1d36651564a8d9"
  :revdesc "b93e76120921"
  :keywords '("convenience" "input-method"))
