;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-codesearch" "0.3"
  "Consult interface for codesearch."
  '((emacs   "27.1")
    (consult "0.20"))
  :url "https://github.com/youngker/consult-codesearch"
  :commit "51df545bb57b468058245950322ae15f6c3a0ce2"
  :revdesc "51df545bb57b"
  :keywords '("tools")
  :authors '(("Youngjoo Lee" . "youngker@gmail.com"))
  :maintainers '(("Youngjoo Lee" . "youngker@gmail.com")))
