;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-vcsh" "0.4.1"
  "Magit vcsh integration."
  '((magit "2.90.1")
    (vcsh  "0.4")
    (emacs "24.4"))
  :url "https://gitlab.com/stepnem/magit-vcsh-el"
  :commit "7d2bfbcb0da6f50f63a277b5faefb7f112ffad94"
  :revdesc "7d2bfbcb0da6"
  :keywords '("vc" "files" "magit")
  :authors '(("těpán Němec" . "stepnem@gmail.com"))
  :maintainers '(("těpán Němec" . "stepnem@gmail.com")))
