;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nova-theme" "0.1.0"
  "A dark pastel color theme."
  '((emacs  "24")
    (cl-lib "0")
    (color  "0"))
  :url "https://github.com/muirmanders/emacs-nova-theme"
  :commit "1c096230c766f59b6b2d27065990b03eb40e6155"
  :revdesc "1c096230c766"
  :keywords '("theme" "dark" "nova" "pastel" "faces")
  :authors '(("Muir Manders" . "muir+emacs@mnd.rs"))
  :maintainers '(("Muir Manders" . "muir+emacs@mnd.rs")))
