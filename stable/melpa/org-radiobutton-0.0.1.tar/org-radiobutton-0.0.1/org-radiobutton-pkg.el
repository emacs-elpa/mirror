;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-radiobutton" "0.0.1"
  "Radiobutton for org-mode lists."
  '((dash "2.13.0"))
  :url "https://github.com/Fuco1/org-radiobutton"
  :commit "654bd2b8e8d58d9e3b1c0b2b4d96c2d79df904b6"
  :revdesc "654bd2b8e8d5"
  :keywords '("outlines")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
