;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slovak-holidays" "0.0.1"
  "Adds a list of slovak holidays to Emacs calendar."
  ()
  :url "https://github.com/Fuco1/slovak-holidays"
  :commit "566d441c71505dae19515aa96fdc61184bd1fb67"
  :revdesc "566d441c7150"
  :keywords '("calendar")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
