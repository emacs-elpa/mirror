;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "koishi-theme" "3.2"
  "A sweet theme inspired by Koishi's color tone."
  '((emacs "24.1"))
  :url "https://github.com/gynamics/koishi-theme.el"
  :commit "c719c98750ac41d4e3718a4aba5e4887e1d37c1b"
  :revdesc "c719c98750ac"
  :keywords '("faces"))
