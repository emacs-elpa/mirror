;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "5.24.0"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "065f8489c0cea7532982c8f0b63f3ed64f1837c0"
  :revdesc "065f8489c0ce"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :authors '(("Jeffrey Chu" . "jochu0@gmail.com")
             ("Lennart Staflin" . "lenst@lysator.liu.se")
             ("Phil Hagelberg" . "technomancy@gmail.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev")
             ("Artur Malabarba" . "bruce.connor.am@gmail.com")
             ("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
