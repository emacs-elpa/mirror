;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crux" "0.6.0"
  "A Collection of Ridiculously Useful eXtensions."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/crux"
  :commit "d8208e9408357fa7c35b394587983257f915c465"
  :revdesc "d8208e940835"
  :keywords '("convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
