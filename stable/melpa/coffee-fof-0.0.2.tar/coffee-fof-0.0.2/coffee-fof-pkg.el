;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coffee-fof" "0.0.2"
  "A `ff-find-other-file' wrapper for coffee-mode.el."
  '((coffee-mode "0.4.1"))
  :url "https://github.com/yasuyk/coffee-fof"
  :commit "82003ec2f79b6e9e005a4bb97adde4089664a1dd"
  :revdesc "82003ec2f79b"
  :keywords '("coffee-mode")
  :authors '(("Yasuyki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyki Oka" . "yasuyk@gmail.com")))
