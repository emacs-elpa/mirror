;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "genexpr-mode" "0.1"
  "Major mode for editing GenExpr files."
  '((emacs "27.1"))
  :url "https://github.com/larme/genexpr-mode"
  :commit "dd5136f18d086d60f50d4d8668753aa6039f8d7b"
  :revdesc "dd5136f18d08"
  :keywords '("languages" "dsp")
  :authors '(("Zhao Shenyang" . "dev@zsy.im"))
  :maintainers '(("Zhao Shenyang" . "dev@zsy.im")))
