;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x86-lookup" "1.2.1"
  "Jump to x86 instruction documentation."
  '((emacs  "24.3")
    (cl-lib "0.3"))
  :url "https://github.com/skeeto/x86-lookup"
  :commit "1573d61cc4457737b94624598a891c837fb52c16"
  :revdesc "1.2.1-0-g1573d61cc445"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
