;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-graphql" "1.1"
  "Org-Babel execution backend for GraphQL source blocks."
  '((emacs        "24.4")
    (graphql-mode "20191024.1221")
    (request      "0.3.2"))
  :url "https://github.com/jdormit/ob-graphql"
  :commit "5afba5bd4f8a4a925ccecc99b1504fd00238d426"
  :revdesc "5afba5bd4f8a"
  :authors '(("Jeremy Dormitzer" . "jeremy.dormitzer@gmail.com"))
  :maintainers '(("Jeremy Dormitzer" . "jeremy.dormitzer@gmail.com")))
