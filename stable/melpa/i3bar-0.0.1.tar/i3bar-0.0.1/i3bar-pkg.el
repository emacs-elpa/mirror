;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "i3bar" "0.0.1"
  "Display status from an i3status command in the tab bar."
  '((emacs "28.0"))
  :url "https://github.com/Stebalien/i3bar.el"
  :commit "3f5d2571b4ff47353a26e4c35aafaf8eea93fbdb"
  :revdesc "3f5d2571b4ff"
  :authors '(("Steven Allen" . "steven@stebalien.com"))
  :maintainers '(("Steven Allen" . "steven@stebalien.com")))
