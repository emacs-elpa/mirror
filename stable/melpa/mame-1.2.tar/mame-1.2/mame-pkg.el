;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mame" "1.2"
  "A MAME front-end."
  '((emacs "27.1"))
  :url "https://github.com/Iacob/elmame"
  :commit "f91cab8d32ceffdff9817f7c2371d7c43cbdd1ec"
  :revdesc "f91cab8d32ce"
  :authors '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers '(("Yong" . "luo.yong.name@gmail.com")))
