;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ttx-mode" "0.1.0"
  "TrueType/OpenType font viewer using ttx."
  '((emacs "30.0"))
  :url "https://github.com/wmedrano/ttx-mode"
  :commit "8e72d6510215d41564be67d3d8adeb735b5ca8db"
  :revdesc "8e72d6510215"
  :keywords '("tools" "fonts"))
