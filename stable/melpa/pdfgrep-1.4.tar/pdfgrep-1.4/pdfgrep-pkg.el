;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdfgrep" "1.4"
  "Run `pdfgrep' and display the results."
  '((emacs "24.4"))
  :url "https://github.com/jeremy-compostella/pdfgrep"
  :commit "e250376d97fc5240e07d81108bbca9b5a9ab50f4"
  :revdesc "e250376d97fc"
  :keywords '("extensions" "mail" "pdf" "grep")
  :authors '(("Jérémy Compostella" . "jeremy.compostella@gmail.com"))
  :maintainers '(("Jérémy Compostella" . "jeremy.compostella@gmail.com")))
