;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plim-mode" "1.0"
  "Major mode for editing Plim files."
  ()
  :url "https://github.com/dongweiming/plim-mode"
  :commit "c55204ebe07c1ce7d04da3de2a1c37d7fa45795d"
  :revdesc "c55204ebe07c"
  :keywords '("markup" "language"))
