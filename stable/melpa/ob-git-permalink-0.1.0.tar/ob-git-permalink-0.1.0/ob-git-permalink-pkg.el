;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-git-permalink" "0.1.0"
  "Easy code citation from repository hosting service."
  '((emacs "25.1"))
  :url "https://github.com/kijimaD/ob-git-permalink"
  :commit "933beadc754b108d541ccaa5bb0f017c41ef107a"
  :revdesc "933beadc754b"
  :keywords '("git" "link" "org-babel")
  :authors '(("kijima Daigo" . "norimaking777@gmail.com"))
  :maintainers '(("kijima Daigo" . "norimaking777@gmail.com")))
