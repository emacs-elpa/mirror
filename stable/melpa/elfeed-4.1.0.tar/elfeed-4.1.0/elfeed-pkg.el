;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.1.0"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "d08bb8e3d1e57f1b3941abcd8d141ac59315a5e4"
  :revdesc "4.1.0-0-gd08bb8e3d1e5"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
