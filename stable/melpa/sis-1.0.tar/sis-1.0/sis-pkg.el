;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "1.0"
  "Switch OS-native or Emacs-native input source smartly."
  '((emacs                    "25")
    (terminal-focus-reporting "0.0"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "91ab5b20cad8d751e25b19003da77706a09e30b2"
  :revdesc "91ab5b20cad8"
  :keywords '("convenience"))
