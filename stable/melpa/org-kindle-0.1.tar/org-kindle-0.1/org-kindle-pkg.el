;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-kindle" "0.1"
  "Send org link file to ebook reader."
  '((emacs  "25")
    (cl-lib "0.5")
    (seq    "2.20"))
  :url "https://github.com/stardiviner/org-kindle"
  :commit "63729de320910626f09f8c905a8cbd264b698b09"
  :revdesc "63729de32091"
  :keywords '("org" "link" "ebook" "kindle" "epub" "mobi")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
