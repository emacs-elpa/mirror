;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tango-2-theme" "1.0.0"
  "Tango 2 color theme for GNU Emacs 24."
  ()
  :commit "64e44c98e41ebbe3b827d54280e3b9615787daaa"
  :revdesc "64e44c98e41e")
