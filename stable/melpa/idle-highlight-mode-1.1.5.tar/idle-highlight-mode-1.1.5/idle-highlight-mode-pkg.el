;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idle-highlight-mode" "1.1.5"
  "Highlight the word the point is on."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-idle-highlight-mode"
  :commit "425f1b247ca5176d47ff1d8b07a6a9293a066f82"
  :revdesc "425f1b247ca5"
  :keywords '("convenience")
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
