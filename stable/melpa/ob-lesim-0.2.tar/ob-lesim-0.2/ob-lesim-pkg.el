;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-lesim" "0.2"
  "Org-babel functions for lesim-mode."
  '((emacs      "28.1")
    (org        "9.3")
    (lesim-mode "0.3.3"))
  :url "https://github.com/drghirlanda/ob-lesim"
  :commit "2e778651ee15b25af3d4e40a8554b892e77b7f50"
  :revdesc "2e778651ee15"
  :keywords '("languages" "tools")
  :authors '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainers '(("Stefano Ghirlanda" . "drghirlanda@gmail.com")))
