;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keycast" "1.4.9"
  "Show current command and its binding."
  '((emacs    "28.1")
    (compat   "31.1")
    (cond-let "1.1"))
  :url "https://github.com/tarsius/keycast"
  :commit "13d41878b64f9e8a811862b860024847c23cdd9e"
  :revdesc "v1.4.9-0-g13d41878b64f"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev")))
