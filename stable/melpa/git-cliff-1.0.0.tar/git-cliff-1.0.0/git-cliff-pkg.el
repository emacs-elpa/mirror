;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-cliff" "1.0.0"
  "Generate and update changelog using git-cliff."
  '((emacs     "29.1")
    (transient "0.6.0")
    (dash      "2.19.1"))
  :url "https://github.com/eki3z/git-cliff.el"
  :commit "936095b416edecd999a013e3cc0aab9a6050bdde"
  :revdesc "936095b416ed"
  :keywords '("tools")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
