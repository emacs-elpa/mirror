;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-ext" "0.0.0.20220617.19"
  "Extensions for *scratch*."
  '((emacs "24.1"))
  :url "https://github.com/kyanagi/scratch-ext-el"
  :commit "8bbe1649503bb2e3676643e6e49fde155c1d6c70"
  :revdesc "8bbe1649503b"
  :authors '(("Kouhei Yanagita" . "yanagi@shakenbu.org"))
  :maintainers '(("Kouhei Yanagita" . "yanagi@shakenbu.org")))
