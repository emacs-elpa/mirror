;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multi-vterm" "1.0"
  "Like multi-term.el but for vterm."
  '((emacs      "26.3")
    (vterm      "0.0")
    (projectile "1.2.0"))
  :url "https://github.com/suonlight/multi-libvterm"
  :commit "cbd2750784e0eb33ba2f8bac5801f5c0a0ba9f67"
  :revdesc "cbd2750784e0"
  :keywords '("terminals" "processes")
  :authors '(("Minh Nguyen-Hue" . "minh.nh1989@gmail.com"))
  :maintainers '(("Minh Nguyen-Hue" . "minh.nh1989@gmail.com")))
