;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popup-kill-ring" "0.0.0.20251130.15"
  "Interactively insert items from the kill-ring."
  '((emacs   "25.1")
    (pos-tip "0.4.6")
    (popup   "0.5.9"))
  :url "https://github.com/doomchild/popup-kill-ring"
  :commit "4558409b105ae5f6089081c238139f53cc3ae84f"
  :revdesc "4558409b105a"
  :keywords '("convenience" "popup" "kill-ring" "pos-tip")
  :authors '(("HAMANO Kiyoto" . "khiker.mail+elisp@gmail.com"))
  :maintainers '(("Lee Crabtree" . "lee.crabtree@gmail.com")))
