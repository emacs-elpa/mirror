;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mermaid-mode" "1.0"
  "Major mode for working with mermaid graphs."
  '((f     "0.20.0")
    (emacs "25.3"))
  :url "https://github.com/abrochard/mermaid-mode"
  :commit "690f906dce9bd264043bc068833f510425cfeca5"
  :revdesc "690f906dce9b"
  :keywords '("mermaid" "graphs" "tools" "processes"))
