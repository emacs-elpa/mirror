;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rubik" "1.2"
  "Rubik's Cube."
  '((cl-lib "0")
    (calc   "0")
    (emacs  "25.3"))
  :url "https://github.com/Kurvivor19/rubik-mode"
  :commit "7ec955639865ca8e99a941843e19b12be5015a47"
  :revdesc "7ec955639865"
  :keywords '("games")
  :authors '(("Ivan 'Kurvivor' Truskov" . "trus19@gmail.com"))
  :maintainers '(("Ivan 'Kurvivor' Truskov" . "trus19@gmail.com")))
