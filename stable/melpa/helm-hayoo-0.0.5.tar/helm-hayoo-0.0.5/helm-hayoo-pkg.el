;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-hayoo" "0.0.5"
  "Source and configured helm for searching hayoo."
  '((helm         "1.6.0")
    (json         "1.2")
    (haskell-mode "13.07"))
  :url "https://github.com/markus1189/helm-hayoo"
  :commit "f49a77e8b8704bb7eb0d1097eefb8010a6617664"
  :revdesc "0.0.5-0-gf49a77e8b870"
  :keywords '("helm")
  :authors '(("Markus Hauck" . "markus1189@gmail.com"))
  :maintainers '(("Markus Hauck" . "markus1189@gmail.com")))
