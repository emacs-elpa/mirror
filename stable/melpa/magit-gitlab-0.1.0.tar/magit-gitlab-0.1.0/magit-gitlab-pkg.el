;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gitlab" "0.1.0"
  "Magit plugin for manipulating GitLab merge requests."
  '((emacs     "26.1")
    (magit     "3.3.0")
    (ghub      "3.6.0")
    (transient "0.6.0"))
  :url "https://gitlab.com/arvidnl/magit-gitlab"
  :commit "cca91ae8b192bb5b50361aab1f94f4ff2bf9e969"
  :revdesc "0.1.0-0-gcca91ae8b192"
  :authors '(("Arvid Jakobsson" . "arvid.jakobsson@gmail.com"))
  :maintainers '(("Arvid Jakobsson" . "arvid.jakobsson@gmail.com")))
