;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "2.3"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "029d726c3309f148cff162758f60d0e6dbe18f76"
  :revdesc "029d726c3309"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
