;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iota" "1.0.2"
  "Replace marker with increasing integers."
  ()
  :url "https://git.sr.ht/~mango/iota"
  :commit "9dbf2741a2471044e58ccee6635ae8c6e311b7a8"
  :revdesc "v1.0.2-0-g9dbf2741a247"
  :keywords '("abbrev" "data" "wp")
  :authors '(("Thomas Voss" . "mail@thomasvoss.com"))
  :maintainers '(("Thomas Voss" . "mail@thomasvoss.com")))
