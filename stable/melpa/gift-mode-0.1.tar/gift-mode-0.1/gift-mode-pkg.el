;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gift-mode" "0.1"
  "Major mode for editing GIFT format quizzes."
  ()
  :url "https://github.com/csrhodes/gift-mode"
  :commit "0d6adae976ee0831877d4bf237090ff67fb76e1d"
  :revdesc "0d6adae976ee"
  :authors '(("Christophe Rhodes" . "christophe@rhodes.io"))
  :maintainers '(("Christophe Rhodes" . "christophe@rhodes.io")))
