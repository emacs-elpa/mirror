;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gcode-mode" "0.1"
  "Simple G-Code mode."
  '((emacs "24.4"))
  :url "https://gitlab.com/wavexx/gcode-mode.el"
  :commit "1bedadc3cd0a6fdb53e651c4bac3069870570ecb"
  :revdesc "1bedadc3cd0a"
  :keywords '("gcode" "languages" "highlight" "syntax")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
