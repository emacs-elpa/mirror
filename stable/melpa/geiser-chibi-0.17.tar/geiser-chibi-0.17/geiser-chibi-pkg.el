;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-chibi" "0.17"
  "Chibi Scheme's implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.18"))
  :url "https://gitlab.com/emacs-geiser/chibi"
  :commit "5a6a5a580ea45cd4974df21629a8d50cbe3d6e99"
  :revdesc "5a6a5a580ea4"
  :keywords '("languages" "chibi" "scheme" "geiser")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
