;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chordpro-mode" "2.7.0"
  "Major mode for ChordPro lead sheet file format."
  '((emacs  "29.1")
    (compat "29.1.4.1"))
  :url "https://git.sr.ht/~breatheoutbreathein/chordpro-mode.el/"
  :commit "7a412da298dcc290050c4c6ba3571c0975a815a9"
  :revdesc "2.7.0-0-g7a412da298dc"
  :keywords '("convenience")
  :authors '(("Howard Ding" . "hading2@gmail.com"))
  :maintainers '(("Howard Ding" . "hading2@gmail.com")))
