;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monokai-theme" "3.5.3"
  "A fruity color theme for Emacs."
  ()
  :url "https://github.com/oneKelvinSmith/monokai-emacs"
  :commit "1143c072f5153ae1a69807e5e8af163069b947d2"
  :revdesc "1143c072f515"
  :authors '(("Kelvin Smith" . "oneKelvinSmith@gmail.com"))
  :maintainers '(("Kelvin Smith" . "oneKelvinSmith@gmail.com")))
