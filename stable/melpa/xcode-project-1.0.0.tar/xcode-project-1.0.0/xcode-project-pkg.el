;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xcode-project" "1.0.0"
  "A package for reading Xcode project files."
  '((emacs "25"))
  :url "https://github.com/nhojb/xcode-project.git"
  :commit "f5548a26a1afc0b0d873556c25f6d8b6b9c2aa8c"
  :revdesc "f5548a26a1af"
  :keywords '("languages" "tools")
  :authors '(("John Buckley" . "john@olivetoast.com"))
  :maintainers '(("John Buckley" . "john@olivetoast.com")))
