;;; ai-code-kiro-cli.el --- Thin wrapper for Kiro CLI  -*- lexical-binding: t; -*-

;; Author: Jason Jenkins
;; SPDX-License-Identifier: Apache-2.0

;;; Commentary:
;;
;; Thin wrapper that reuses `ai-code-backends-infra' to run Kiro CLI.
;;
;;; Code:

(require 'ai-code-backends)
(require 'ai-code-backends-infra)

(defgroup ai-code-kiro-cli nil
  "Kiro CLI integration via `ai-code-backends-infra'."
  :group 'tools
  :prefix "ai-code-kiro-cli-")

(defcustom ai-code-kiro-cli-program "kiro-cli"
  "Path to the Kiro CLI executable."
  :type 'string
  :group 'ai-code-kiro-cli)

(defcustom ai-code-kiro-cli-program-switches nil
  "Command line switches to pass to Kiro CLI on startup."
  :type '(repeat string)
  :group 'ai-code-kiro-cli)

(defcustom ai-code-kiro-cli-trust-all-tools nil
  "When non-nil, pass --trust-all-tools to allow commands without confirmation."
  :type 'boolean
  :group 'ai-code-kiro-cli)

(defcustom ai-code-kiro-cli-agent nil
  "Agent/context profile to use.  When nil, use the default agent."
  :type '(choice (const :tag "Default" nil)
                 (string :tag "Agent name"))
  :group 'ai-code-kiro-cli)

(defconst ai-code-kiro-cli--session-prefix "kiro"
  "Session prefix used in Kiro CLI buffer names.")

(defvar ai-code-kiro-cli--processes (make-hash-table :test 'equal)
  "Hash table mapping Kiro session keys to processes.")

(defun ai-code-kiro-cli--build-args ()
  "Build the Kiro CLI argument list."
  (let ((args (list "chat")))
    (when ai-code-kiro-cli-trust-all-tools
      (setq args (append args '("--trust-all-tools"))))
    (when ai-code-kiro-cli-agent
      (setq args (append args (list "--agent" ai-code-kiro-cli-agent))))
    (when ai-code-kiro-cli-program-switches
      (setq args (append args ai-code-kiro-cli-program-switches)))
    args))

(defun ai-code-kiro-cli--build-command ()
  "Build the Kiro CLI command string."
  (mapconcat #'identity
             (cons ai-code-kiro-cli-program (ai-code-kiro-cli--build-args))
             " "))

;;;###autoload
(defun ai-code-kiro-cli (&optional arg)
  "Start Kiro CLI chat session.
With prefix ARG, prompt for CLI args using the current defaults
including chat, agent, trust flags, and `ai-code-kiro-cli-program-switches'."
  (interactive "P")
  (ai-code-backends-infra--start-cli-session
   (list :program ai-code-kiro-cli-program
         :switches (ai-code-kiro-cli--build-args)
         :label "Kiro"
         :process-table ai-code-kiro-cli--processes
         :session-prefix ai-code-kiro-cli--session-prefix
         :escape-function #'ai-code-kiro-cli-send-escape)
   arg))

;;;###autoload
(defun ai-code-kiro-cli-switch-to-buffer (&optional force-prompt)
  "Switch to the Kiro CLI buffer.
When FORCE-PROMPT is non-nil, prompt to select a session."
  (interactive "P")
  (ai-code-backends-infra--cli-switch-to-buffer
   "Kiro" ai-code-kiro-cli--session-prefix force-prompt))

;;;###autoload
(defun ai-code-kiro-cli-send-command (line)
  "Send LINE to Kiro CLI."
  (interactive "sKiro> ")
  (ai-code-backends-infra--cli-send-command
   "Kiro" ai-code-kiro-cli--session-prefix line))

;;;###autoload
(defun ai-code-kiro-cli-send-escape ()
  "Send escape key to Kiro CLI."
  (interactive)
  (ai-code-backends-infra--terminal-send-escape))

;;;###autoload
(defun ai-code-kiro-cli-resume (&optional arg)
  "Resume a previous Kiro CLI session.
Argument ARG is passed to the start command."
  (interactive "P")
  (let ((ai-code-kiro-cli-program-switches (append ai-code-kiro-cli-program-switches '("--resume"))))
    (ai-code-kiro-cli arg)))

(provide 'ai-code-kiro-cli)

;;; ai-code-kiro-cli.el ends here
