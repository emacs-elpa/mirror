;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "handoff" "0.0.1"
  "Get your hand of that mouse, damn it!."
  ()
  :url "https://github.com/rejeep/handoff.el"
  :commit "27146dbe8176b18119446f7df907ad130c3b23f0"
  :revdesc "27146dbe8176"
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
