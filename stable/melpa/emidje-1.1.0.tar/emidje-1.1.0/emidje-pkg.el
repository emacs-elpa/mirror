;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emidje" "1.1.0"
  "Test runner and report viewer for Midje."
  '((emacs "25")
    (cider "0.17.0")
    (seq   "2.16"))
  :url "https://github.com/nubank/emidje"
  :commit "e8577698bade8a8ea6bf394ab9a441e982058f19"
  :revdesc "e8577698bade"
  :keywords '("tools")
  :authors '(("Alan Ghelardi" . "alan.ghelardi@nubank.com.br"))
  :maintainers '(("Alan Ghelardi" . "alan.ghelardi@nubank.com.br")))
