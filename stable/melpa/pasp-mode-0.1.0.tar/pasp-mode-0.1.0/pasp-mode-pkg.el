;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pasp-mode" "0.1.0"
  "- A major mode for editing Potassco answer set programs."
  ()
  :url "https://github.com/santifa/pasp-mode"
  :commit "2d3dac626611d8c21719884266e10955b100436a"
  :revdesc "2d3dac626611"
  :keywords '("asp" "pasp" "answer set programs" "potassco answer set programs" "major mode"))
