;;; pasp-mode.el ---- A major mode for editing Potassco answer set programs. -*- lexical-binding: t -*-

;; Copyright (c) 2017 by Henrik Jürges

;; Author: Henrik Jürges
;; URL: https://github.com/santifa/pasp-mode
;; Package-Version: 0.1.0
;; Package-Revision: 2d3dac626611
;; Keywords: asp, pasp, Answer Set Programs, Potassco Answer Set Programs, Major mode

;; You can redistribute this program and/or modify it under the terms of the GNU
;; General Public License as published by the Free Software Foundation; either
;; GPL version 2 or 3.

;;; Commentary:

;; A major mode for editing Answer Set Programs, formally Potassco
;; Answer Set Programs (https://potassco.org/).
;; 
;; Answer Set Programs are mainly used to solve complex combinatorial
;; problems by impressive search methods.
;; The modeling language follows a declerative approach with a minimal
;; amount of fixed syntax constructs.

;;; Install

;; Open the file with emacs and run "M-x eval-buffer"
;; Open an ASP file and run "M-x pasp-mode"

;; To manually load this file within your emacs config
;; add this file to your load path and place 
;; (require 'pasp-mode)
;; in your init file.

;; See "M-x customize-mode pasp-mode" for information
;; about mode configuration.

;;; Features

;; - Syntax highlighting (predicates can be toggled)
;; - Commenting of blocks and standard
;; - Run ASP program from within emacs and get the compilation output
;; - Autoload mode when a *.lp file is opened 

;;; Todo

;; - Smart indentation based on nesting deepth
;; - Refactoring of predicates/variables (complete buffer and #program parts)
;; - Color compilation output
;; - Smart rearrange of compilation output (predicates separated, table...) 
;; - yas-snippet for rules; constraints; soft constraints; generation?

;;; Keybindings

;; "C-c C-e" - Call clingo with current buffer and an instance file
;; "C-c C-b" - Call clingo with current buffer

;; Remark

;; I'm not an elisp expert, this is a very basic major mode.
;; It is intended to get my hands dirty with elisp but also
;; to be a helpfull tool.
;; This mode should provide a basic enviroment for further
;; integration of Answer Set Programs into Emacs.

;; Ideas, issues and pull requests are highly welcome!

;;; Code:

(require 'compile)

;;; Customization

(defcustom pasp-mode-version "0.1.0"
  "Version of `pasp-mode'")

(defgroup pasp-mode nil
  "Major mode for editing Anwser Set Programs."
  :group 'languages
  :prefix "pasp-")

(defcustom pasp-indentation 2
  "Level of indentation."
  :type 'integer
  :group 'pasp-mode)

(defcustom pasp-highlight-constants t
  "Use font locking for predicates."
  :type 'boolean
  :group 'pasp-mode)

(defcustom pasp-clingo-path (executable-find "clingo")
  "Path to clingo binary used for execution."
  :type 'string
  :group 'pasp-mode)

(defcustom pasp-clingo-options ""
  "Command line options passed to clingo."
  :type 'string
  :group 'pasp-mode
  :safe #'stringp)

(defcustom pasp-pretty-symbols t
  "Use unicode characters where appropriate."
  :type 'boolean
  :group 'pasp-mode)

;;; Pretty Symbols

(defvar pasp-mode-hook
  (lambda ()
    (when pasp-pretty-symbols
      (push '(":-" . ?⊢) prettify-symbols-alist)
      (push '(">=" . ?≥) prettify-symbols-alist)
      (push '("<=" . ?≤) prettify-symbols-alist)
      (push '("!=" . ?≠) prettify-symbols-alist)
     (push '("not" . ?¬) prettify-symbols-alist))))

;;; Syntax table

(defvar pasp-mode-syntax-table nil "Syntax table for `pasp-mode`.")
(setq pasp-mode-syntax-table
      (let ((synTable (make-syntax-table)))
        ;; modify syntax table
        (modify-syntax-entry ?' "w" synTable)
        (modify-syntax-entry ?% "<" synTable)
        (modify-syntax-entry ?\n ">" synTable)
        synTable))

;;; Syntax highlighting

(defvar pasp-constant-face 'pasp-constant-face)
(defface pasp-constant-face
  '((t (:inherit font-lock-keyword-face :weight normal)))
  "Face for ASP constants (starting with lower case)."
  :group 'font-lock-highlighting-faces)

(defvar pasp-constuct-face 'pasp-construct-face)
(defface pasp-construct-face
  '((default (:inherit font-lock-builtin-face :height 1.1)))
  "Face for ASP base constructs."
  :group 'font-lock-highlighting-faces)

;; Syntax tables

(defvar pasp-highlighting nil
  "Regex list for syntax highlighting.")
(setq pasp-highlighting
      '(("not" . font-lock-negation-char-face)
        ("#[[:word:]]+" . font-lock-builtin-face)
        ("\\_<\\(_*[[:upper:]][[:word:]_']*\\)\\_>" . (1 font-lock-variable-name-face))
        ("_*[[:lower:]][[:word:]_']*" . pasp-constant-face)
        ;; the regex 2 lines above matches complete words
        ;; so constants next to non-word characters are not recognized  
        ("_*[[:upper:]][[:word:]_']*" . font-lock-variable-name-face)
        ("\\.\\|:-\\|:\\|_\\|;\\|:~\\|,\\|(\\|)\\|{\\|}\\|[\\|]" . pasp-construct-face)))

(defvar pasp-highlighting-no-constants nil
  "Regex list for syntax highlighting without ASP constants.")
(setq pasp-highlighting-no-constants
      '(("not" . font-lock-negation-char-face)
        ("#[[:word:]]+" . font-lock-builtin-face)
        ("\\_<\\(_*[[:upper:]][[:word:]_']*\\)\\_>" . (1 font-lock-variable-name-face))
        ("\\.\\|:-\\|:\\|_\\|;\\|:~\\|,\\|(\\|)\\|{\\|}" . pasp-construct-face)))

(defun pasp-choose-highlighting()
  "Toggle the syntax highlighting for constants.
Needs a mode restart."
  (if pasp-highlight-constants
      (setq font-lock-defaults '(pasp-highlighting))
    (setq font-lock-defaults '(pasp-highlighting-no-constants))))

;;; Compilation

(defvar pasp-error-regexp
  "^[  ]+at \\(?:[^\(\n]+ \(\\)?\\(\\(?:[a-zA-Z]:\\)?[a-zA-Z\.0-9_/\\-]+\\):\\([0-9]+\\):\\([0-9]+\\)\)?"
  "Taken from NodeJS -> only dummy impl.")

(defvar pasp-error-regexp-alist
  `((,pasp-error-regexp 1 2 3))
  "Taken from NodeJs -> only dummy impl.")

(defun pasp-compilation-filter ()
  "Filter clingo output. (Only dummy impl.)"
  (ansi-color-apply-on-region compilation-filter-start (point-max))
  (save-excursion
    (while (re-search-forward "^[\\[[0-9]+[a-z]" nil t)
      (replace-match ""))))

(define-compilation-mode pasp-compilation-mode "ASP"
  "Major mode for running ASP files."
  (progn
    (set (make-local-variable 'compilation-error-regexp-alist) pasp-error-regexp-alist)
    (add-hook 'compilation-filter-hook 'pasp-compilation-filter nil t)))

(defun pasp-generate-command (encoding &optional instance)
  "Generate Clingo call with some ASP input file."
  (if 'instance
      (concat pasp-clingo-path " " pasp-clingo-options " " encoding " " instance)
    (concat pasp-clingo-path " " pasp-clingo-options " " encoding)))

(defun pasp-run-clingo (encoding &optional instance)
  "Run Clingo.

Be aware: Partial ASP code may lead to abnormally exits while
the result is sufficient."
  (when (get-buffer "*clingo output*")
    (kill-buffer "*clingo output*"))
  (let ((test-command-to-run (pasp-generate-command encoding instance))
        (compilation-buffer-name-function (lambda (_) "" "*clingo output*")))
    (compile test-command-to-run 'pasp-compilation-mode)))

;;;###autoload
(defun pasp-run-buffer ()
  "Run clingo with the current buffer as input"
  (interactive)
  (pasp-run-clingo (buffer-file-name)))

;; save the last user input 
(setq pasp-last-instance "")

;;;###autoload
(defun pasp-run (instance)
  "Run clingo with the current buffer and some user provided instance as input."
  (interactive
   (list (read-file-name
          (format "Instance [%s]:" (file-name-nondirectory pasp-last-instance))
          nil pasp-last-instance)))
    (setq pasp-last-instance instance)
    (pasp-run-clingo (buffer-file-name) instance))

;;; Utility functions 

(defun pasp-reload-mode ()
    "Reload the PASP major mode."
  (interactive)
  (progn
    (unload-feature 'pasp-mode)
    (require 'pasp-mode)
    (pasp-mode)))

;;; Keymap

(progn
  (setq pasp-mode-map (make-sparse-keymap))
  (define-key pasp-mode-map (kbd "C-c C-b") 'pasp-run-buffer)
  (define-key pasp-mode-map (kbd "C-c C-e") 'pasp-run))

;;; File ending

;;;###autoload
(add-to-list 'auto-mode-alist '("\\.lp\\'" . pasp-mode))

;;; Define pasp mode

;;;###autoload
(define-derived-mode pasp-mode prog-mode "Potassco ASP"
  "A major mode for editing Answer Set Programs."
  ;;(setq font-lock-defaults '(pasp-highlights))
  (pasp-choose-highlighting)
  (set-syntax-table pasp-mode-syntax-table)
  (use-local-map pasp-mode-map)
  
  ;; define the syntax for un/comment region and dwim
  (setq-local comment-start "%")
  (setq-local comment-end "")
  (setq tab-width pasp-indentation))

;; add mode to feature list
(provide 'pasp-mode)
