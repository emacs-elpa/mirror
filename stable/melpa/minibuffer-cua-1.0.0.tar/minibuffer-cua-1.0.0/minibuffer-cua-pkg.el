;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minibuffer-cua" "1.0.0"
  "Make CUA mode's S-up/S-down work in minibuffer."
  ()
  :url "https://github.com/knu/minibuffer-cua.el"
  :commit "e8dcddc24d4f2e8d7987336fb58259e3cc78bbcb"
  :revdesc "e8dcddc24d4f"
  :keywords '("completion" "editing")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
