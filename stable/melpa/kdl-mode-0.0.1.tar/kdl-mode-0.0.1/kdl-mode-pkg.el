;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kdl-mode" "0.0.1"
  "Major mode for editing KDL files."
  ()
  :url "https://github.com/taquangtrung/emacs-kdl-mode"
  :commit "1cba5438c69730a7c17662028b63cd7a9b805d4b"
  :revdesc "1cba5438c697"
  :keywords '("languages"))
