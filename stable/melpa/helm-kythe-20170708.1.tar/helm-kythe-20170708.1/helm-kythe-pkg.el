;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-kythe" "20170708.1"
  "Google Kythe helm interface."
  '((emacs "25")
    (dash  "2.12.0")
    (helm  "2.0"))
  :url "https://github.com/MaskRay/emacs-helm-kythe"
  :commit "eabbef4948f8ec7c7b2fac498e9145dfdb10ca82"
  :revdesc "eabbef4948f8"
  :authors '(("Fangrui Song" . "i@maskray.me"))
  :maintainers '(("Fangrui Song" . "i@maskray.me")))
