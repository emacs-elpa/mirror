;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "link-hint" "0.1"
  "Use avy to open or copy visible urls."
  '((avy   "0.3.0")
    (emacs "24.1"))
  :url "https://github.com/noctuid/link-hint.el"
  :commit "046855358f92357a1326cd34fa1410c01aa79758"
  :revdesc "046855358f92"
  :keywords '("url")
  :authors '(("Lit Wakefield" . "noct@openmailbox.org"))
  :maintainers '(("Lit Wakefield" . "noct@openmailbox.org")))
