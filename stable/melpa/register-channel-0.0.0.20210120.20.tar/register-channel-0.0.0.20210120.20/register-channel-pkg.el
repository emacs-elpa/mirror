;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "register-channel" "0.0.0.20210120.20"
  "Jump around fast using registers."
  ()
  :url "https://github.com/YangZhao11/register-channel"
  :commit "ed7f563e92170b758dc878fcb5df88d46d5d44cc"
  :revdesc "ed7f563e9217"
  :keywords '("convenience")
  :authors '(("Yang Zhao" . "YangZhao11@users.noreply.github.com"))
  :maintainers '(("Yang Zhao" . "YangZhao11@users.noreply.github.com")))
