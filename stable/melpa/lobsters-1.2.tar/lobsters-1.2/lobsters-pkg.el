;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lobsters" "1.2"
  "A Lobsters client."
  '((emacs              "25.1")
    (request            "0.2.0")
    (visual-fill-column "2.4"))
  :url "https://github.com/tanrax/lobsters.el"
  :commit "58f91e5adc9660a54a3f6eb1cd49fbbeb2229b74"
  :revdesc "58f91e5adc96"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
