;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "newlisp-mode" "0.3.2"
  "NewLISP editing mode for Emacs."
  ()
  :url "https://github.com/kosh04/newlisp-mode"
  :commit "020b123ad846bd2380653618b9ec2b022ac53c7e"
  :revdesc "020b123ad846"
  :keywords '("language" "lisp" "newlisp")
  :authors '(("KOBAYASHI Shigeru" . "shigeru.kb[at]gmail.com"))
  :maintainers '(("KOBAYASHI Shigeru" . "shigeru.kb[at]gmail.com")))
