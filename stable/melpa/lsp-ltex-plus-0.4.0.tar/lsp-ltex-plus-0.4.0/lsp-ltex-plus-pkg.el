;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex-plus" "0.4.0"
  "Grammar and spell checking for LaTeX, Markdown, Org and more."
  '((emacs    "27.1")
    (lsp-mode "6.0"))
  :url "https://github.com/ltex-plus/emacs-ltex-plus"
  :commit "2dded9da2dbced4624ecad4ab51ee2ee62aa2cad"
  :revdesc "2dded9da2dbc"
  :keywords '("lsp" "grammar" "spelling" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
