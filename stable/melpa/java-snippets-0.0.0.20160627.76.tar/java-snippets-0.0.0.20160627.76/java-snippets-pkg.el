;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "java-snippets" "0.0.0.20160627.76"
  "Yasnippets for Java."
  '((yasnippet "0.8.0"))
  :url "https://github.com/nekop/yasnippet-java-mode"
  :commit "738523debb1018439bda0ce70e00248154a600ac"
  :revdesc "738523debb10")
