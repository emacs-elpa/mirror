;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "celestial-mode-line" "20180518"
  "Show lunar phase and sunrise/-set time in modeline."
  '((emacs "24"))
  :url "https://github.com/ecraven/celestial-mode-line"
  :commit "3f5794aca99b977f1592cf1ab4516ae7922196a1"
  :revdesc "3f5794aca99b"
  :keywords '("extensions")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Peter" . "craven@gmx.net")))
