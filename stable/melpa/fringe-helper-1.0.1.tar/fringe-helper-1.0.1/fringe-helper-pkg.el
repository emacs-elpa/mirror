;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fringe-helper" "1.0.1"
  "Helper functions for fringe bitmaps."
  ()
  :url "http://nschum.de/src/emacs/fringe-helper/"
  :commit "0f10a196c6e57222b8d4c94eafc40a96e7b20f1b"
  :revdesc "1.0.1-0-g0f10a196c6e5"
  :keywords '("lisp")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
