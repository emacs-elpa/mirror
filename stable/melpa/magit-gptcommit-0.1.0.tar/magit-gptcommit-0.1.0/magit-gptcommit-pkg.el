;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gptcommit" "0.1.0"
  "Git commit with help of gpt."
  '((emacs "25.1")
    (magit "2.90.1")
    (gpt   "0.1.0"))
  :url "https://github.com/douo/magit-gptcommit"
  :commit "33cca1f53a7751cf919b9d71cb6faa90ed6cbc8b"
  :revdesc "33cca1f53a77"
  :authors '(("Tiou Lims" . "dourokinga@gmail.com"))
  :maintainers '(("Tiou Lims" . "dourokinga@gmail.com")))
