;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "steam" "1.0"
  "Organize and launch Steam games from Emacs."
  ()
  :url "https://github.com/Kungsgeten/steam.el"
  :commit "d03c61cb0ada47dcf49e349f8b18ffe419c3d42a"
  :revdesc "d03c61cb0ada"
  :keywords '("games"))
