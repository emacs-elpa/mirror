;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-diff-flycheck" "0.1.0"
  "Report errors in diffs."
  '((magit    "2")
    (flycheck "31")
    (seq      "2")
    (emacs    "24.4"))
  :url "https://github.com/ragone/magit-diff-flycheck"
  :commit "95017c5ff2632f7b79341637386632d740825483"
  :revdesc "95017c5ff263"
  :keywords '("convenience" "matching")
  :authors '(("Alex Ragone" . "ragonedk@gmail.com.com"))
  :maintainers '(("Alex Ragone" . "ragonedk@gmail.com.com")))
