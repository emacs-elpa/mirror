;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prodigy" "1.0.0"
  "Manage external services."
  '((s     "1.8.0")
    (dash  "2.4.0")
    (f     "0.14.0")
    (emacs "27.1"))
  :url "https://github.com/rejeep/prodigy.el"
  :commit "b67e4112eaca7ef7c8596c4728e9bc53418982d7"
  :revdesc "b67e4112eaca"
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
