;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-node-inspect" "1.0.0"
  "Realgud front-end to newer \"node inspect\"."
  '((realgud       "1.4.5")
    (load-relative "1.2")
    (cl-lib        "0.5")
    (emacs         "24"))
  :url "https://github.com/realgud/realgud-node-inspect"
  :commit "73483bade33caa49f06a570b6c2e928e9632cfac"
  :revdesc "73483bade33c")
