;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gmail2bbdb" "0.0.6"
  "Import email and name into bbdb from vcard."
  ()
  :url "https://github.com/redguardtoo/gmail2bbdb"
  :commit "181ef6039227bb30a02041d8cfdc435551a7d948"
  :revdesc "181ef6039227"
  :keywords '("vcard" "bbdb" "email" "contact" "gmail")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
