;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transmission" "0.12.2"
  "Interface to a Transmission session."
  '((emacs     "24.4")
    (let-alist "1.0.5"))
  :url "https://github.com/holomorph/transmission"
  :commit "deb7090e1e3faf50b691c5b73148be690575c76b"
  :revdesc "0.12.2-0-gdeb7090e1e3f"
  :keywords '("comm" "tools")
  :authors '(("Mark Oteiza" . "mvoteiza@udel.edu"))
  :maintainers '(("Mark Oteiza" . "mvoteiza@udel.edu")))
