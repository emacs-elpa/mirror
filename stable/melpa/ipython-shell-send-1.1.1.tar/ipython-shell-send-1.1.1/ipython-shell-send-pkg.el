;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ipython-shell-send" "1.1.1"
  "Send code (including magics) to ipython shell."
  '((emacs "24"))
  :url "https://github.com/jackkamm/ipython-shell-send-el"
  :commit "0faed86faff02a361f23ce5fc923d0e9b09bb2da"
  :revdesc "0faed86faff0"
  :keywords '("tools" "processes")
  :authors '(("Jack Kamm" . "jackkamm@gmail.com"))
  :maintainers '(("Jack Kamm" . "jackkamm@gmail.com")))
