;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-custom-cookies" "0.1"
  "Custom cookies for org-mode."
  '((cl-lib "0.7"))
  :url "https://github.com/gsingh93/org-custom-cookies"
  :commit "19fe728fea09d6532014697f473c2adc0c1b60ac"
  :revdesc "19fe728fea09"
  :authors '(("Gulshan Singh" . "gsingh2011@gmail.com"))
  :maintainers '(("Gulshan Singh" . "gsingh2011@gmail.com")))
