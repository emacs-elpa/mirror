;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "drone" "0.1"
  "A simple package."
  ()
  :url "https://github.com/olymk2/emacs-drone"
  :commit "bdcc68b93aeadb8395ec32211748ea58b1d3e392"
  :revdesc "bdcc68b93aea"
  :keywords '("drone" "tests" "ci")
  :authors '(("Oliver Marks" . "oly@digitaloctave.com"))
  :maintainers '(("Oliver Marks" . "oly@digitaloctave.com")))
