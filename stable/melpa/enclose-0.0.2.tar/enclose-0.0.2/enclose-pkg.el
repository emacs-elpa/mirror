;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enclose" "0.0.2"
  "Enclose cursor within punctuation pairs."
  ()
  :url "https://github.com/rejeep/enclose"
  :commit "8c3a9c050cb76f478049674069c1dac1b2a3ad81"
  :revdesc "8c3a9c050cb7"
  :keywords '("speed" "convenience")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
