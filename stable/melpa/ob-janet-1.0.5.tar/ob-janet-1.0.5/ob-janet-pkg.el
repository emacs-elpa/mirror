;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-janet" "1.0.5"
  "Org-Babel support for the Janet language."
  '((emacs "26.1")
    (org   "9.1"))
  :url "https://codeberg.org/zzkt/ob-janet"
  :commit "b39af99ed865e68a93f83f149ae0d2e13bf8f411"
  :revdesc "b39af99ed865"
  :keywords '("languages" "tools" "literate programming" "janet")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
