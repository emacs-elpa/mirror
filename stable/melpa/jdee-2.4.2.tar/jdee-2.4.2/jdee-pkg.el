;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jdee" "2.4.2"
  "Java Development Environment for Emacs."
  '((emacs    "24.3")
    (flycheck "30")
    (memoize  "1.0.1")
    (dash     "2.13.0")
    (s        "1.12.0"))
  :url "https://github.com/jdee-emacs/jdee"
  :commit "b510a29f1fc1bea218a6230fb219922775687c78"
  :revdesc "b510a29f1fc1"
  :keywords '("java" "tools")
  :authors '(("Paul Kinnucan" . "pkinnucan@attbi.com")))
