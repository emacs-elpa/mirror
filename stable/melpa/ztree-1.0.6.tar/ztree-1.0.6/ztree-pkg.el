;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ztree" "1.0.6"
  "Text mode directory tree."
  '((cl-lib "0"))
  :url "https://github.com/fourier/ztree"
  :commit "c9ad9136d52ca5a81475693864e255d29448f43f"
  :revdesc "c9ad9136d52c"
  :keywords '("files" "tools")
  :authors '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com"))
  :maintainers '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com")))
