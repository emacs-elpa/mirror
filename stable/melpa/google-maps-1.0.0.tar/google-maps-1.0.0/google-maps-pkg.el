;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "google-maps" "1.0.0"
  "Access Google Maps from Emacs."
  ()
  :url "https://github.com/jd/google-maps.el"
  :commit "90151ab59e693243ca8da660ce7b9ce361ea5126"
  :revdesc "1.0.0-0-g90151ab59e69"
  :keywords '("comm")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")))
