;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scopeline" "0.1"
  "Show scope info of blocks in buffer at end of scope."
  '((emacs       "25.1")
    (tree-sitter "0.15.0"))
  :url "https://github.com/meain/scopeline.el"
  :commit "af0f10188e965866b72ff472842f355a75c46cff"
  :revdesc "af0f10188e96"
  :keywords '("scope" "context" "tree-sitter" "convenience"))
