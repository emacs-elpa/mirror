;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "constant-theme" "2018.9"
  "A calm, dark, almost monochrome color theme."
  '((emacs "24.1"))
  :url "https://github.com/jannis/emacs-constant-theme"
  :commit "4d99dbcd577ad1e72fecece86d3b700cc5959555"
  :revdesc "4d99dbcd577a"
  :keywords '("themes")
  :authors '(("Jannis Pohlmann" . "contact@jannispohlmann.de"))
  :maintainers '(("Jannis Pohlmann" . "contact@jannispohlmann.de")))
