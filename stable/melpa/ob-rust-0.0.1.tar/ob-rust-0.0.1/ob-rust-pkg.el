;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-rust" "0.0.1"
  "Org-babel functions for rust evaluation."
  ()
  :url "http://orgmode.org"
  :commit "126ee38c6f560cac2ea6bbef034f92ff948d2664"
  :revdesc "126ee38c6f56"
  :keywords '("rust" "languages" "org" "babel"))
