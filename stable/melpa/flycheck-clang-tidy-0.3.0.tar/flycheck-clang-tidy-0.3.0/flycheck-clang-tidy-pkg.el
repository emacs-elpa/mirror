;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-clang-tidy" "0.3.0"
  "Flycheck syntax checker using clang-tidy."
  '((flycheck "0.30"))
  :url "https://github.com/ch1bo/flycheck-clang-tidy"
  :commit "2f89698ab0d78818875d5ef08d0b470a9ffc402f"
  :revdesc "0.3.0-0-g2f89698ab0d7"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Nagel" . "sebastian.nagel@ncoding.at"))
  :maintainers '(("tastytea" . "tastytea@tastytea.de")))
