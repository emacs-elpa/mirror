;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-comment" "0.0.1"
  "Smarter commenting."
  ()
  :url "https://github.com/paldepind/smart-comment"
  :commit "c6149090c7b34b0ca745d32e5310ac6b3a4758be"
  :revdesc "c6149090c7b3"
  :keywords '("lisp")
  :authors '(("Simon Friis Vindum" . "simon@vindum.io"))
  :maintainers '(("Simon Friis Vindum" . "simon@vindum.io")))
