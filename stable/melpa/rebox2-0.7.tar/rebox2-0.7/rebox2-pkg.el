;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rebox2" "0.7"
  "Handling of comment boxes in various styles."
  ()
  :url "https://github.com/lewang/rebox2"
  :commit "a8f8ea98a2a7eff510890c597658325dce144242"
  :revdesc "a8f8ea98a2a7")
