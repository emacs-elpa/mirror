;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.85"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "589307b8496ac8530d6de06cd7189d827b72e4b0"
  :revdesc "589307b8496a"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
