;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multitran" "0.4.16"
  "Interface to multitran."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/zevlg/multitran.el"
  :commit "6244e227bcf57eed391eecb34bae445f9c17e809"
  :revdesc "6244e227bcf5"
  :keywords '("dictionary" "hypermedia")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
