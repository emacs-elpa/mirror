;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-keypad" "0.1.5"
  "Modal command dispatch that speaks native Emacs keybindings."
  '((emacs     "29.1")
    (which-key "3.0"))
  :url "https://github.com/achyudh/evil-keypad"
  :commit "faa3ec151caa5c5f7a72e7c8351da47a626b2684"
  :revdesc "faa3ec151caa"
  :keywords '("evil" "keypad" "modal" "command" "dispatch")
  :authors '(("Achyudh Ram" . "mail@achyudh.me"))
  :maintainers '(("Achyudh Ram" . "mail@achyudh.me")))
