;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "open-color" "0.0.1"
  "Open Color color palette."
  '((emacs "25.1"))
  :url "https://github.com/a13/open-color.el"
  :commit "74cee7acc6a054d2fbdf847dd7ddccfbe8f81db1"
  :revdesc "74cee7acc6a0"
  :keywords '("faces")
  :authors '(("DK" . "a13@users.noreply.github.com"))
  :maintainers '(("DK" . "a13@users.noreply.github.com")))
