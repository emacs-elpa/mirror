;;; toggle-quotes.el --- Toggle between single and double quoted string

;; Copyright (C) 2014 Jim Tian

;; Author: Jim Tian <tianjin.sc@gmail.com>
;; Package-Version: 0.1.0
;; Package-Revision: aebf252f6201

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 3, or (at your option)
;; any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with GNU Emacs; see the file COPYING.  If not, write to the
;; Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
;; Boston, MA 02110-1301, USA.

;;; Commentary:
;;
;; `toggle-quotes' toggles the single-quoted string at point to
;; double-quoted one, and vice versa.
;;
;;; Code:

(provide 'toggle-quotes)
;;; toggle-quotes.el ends here
