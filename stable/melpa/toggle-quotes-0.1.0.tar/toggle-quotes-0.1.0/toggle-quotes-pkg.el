;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toggle-quotes" "0.1.0"
  "Toggle between single and double quoted string."
  ()
  :url "https://github.com/toctan/toggle-quotes.el"
  :commit "aebf252f6201353c9f8fa13ac0d99b71f6574654"
  :revdesc "aebf252f6201"
  :authors '(("Jim Tian" . "tianjin.sc@gmail.com"))
  :maintainers '(("Jim Tian" . "tianjin.sc@gmail.com")))
