;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "0.5.1"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "30.2")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "fb48fe679206dab90bdb5006da5b6f2fb9b09200"
  :revdesc "v0.5.1-0-gfb48fe679206"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
