;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-dao" "0.1.0"
  "Org Babel Functions for Dao."
  ()
  :url "https://github.com/xuchunyang/ob-dao"
  :commit "22d43a79af79afee5a3da69545d20280278b9026"
  :revdesc "22d43a79af79"
  :keywords '("literate programming" "reproducible research" "org" "babel" "dao")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
