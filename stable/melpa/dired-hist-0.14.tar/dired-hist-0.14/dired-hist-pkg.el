;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-hist" "0.14"
  "Traverse Dired buffer's history: back, forward."
  '((emacs "27.1"))
  :url "https://codeberg.org/Anoncheg/dired-hist"
  :commit "bcbfa60e2de0d86a38740d72bea7e4f25ccc35c8"
  :revdesc "bcbfa60e2de0"
  :keywords '("convenience" "dired" "history")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
