;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zotelo" "1.3"
  "Manage Zotero collections from emacs."
  ()
  :url "https://github.com/vitoshka/zotelo"
  :commit "56eaaa76f80bd15710e68af4a1e585394af987d3"
  :revdesc "56eaaa76f80b"
  :keywords '("zotero" "emacs" "reftex" "bibtex" "mozrepl" "bibliography manager"))
