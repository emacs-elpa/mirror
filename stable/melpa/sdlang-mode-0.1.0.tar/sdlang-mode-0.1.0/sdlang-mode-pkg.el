;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sdlang-mode" "0.1.0"
  "Major mode for Simple Declarative Language files."
  '((emacs "24.0"))
  :url "https://github.com/CyberShadow/sdlang-mode"
  :commit "1d084467e48eb4c0ee7b9dd7ae0d3ecb28aa88e8"
  :revdesc "1d084467e48e"
  :keywords '("languages"))
