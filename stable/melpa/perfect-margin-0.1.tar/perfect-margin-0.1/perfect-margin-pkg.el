;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perfect-margin" "0.1"
  "Auto center windows, work with minimap and/or linum-mode."
  ()
  :url "https://github.com/mpwang/perfect-margin"
  :commit "1ee79056a7e990ca4f6dc253c33b8c73ae343e9c"
  :revdesc "1ee79056a7e9"
  :keywords '("convenience" "frames")
  :authors '(("Randall Wang" . "randall.wjz@gmail.com"))
  :maintainers '(("Randall Wang" . "randall.wjz@gmail.com")))
