;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hal-mode" "0.1"
  "Major mode for editing HAL files."
  '((generic-x "19.0"))
  :url "https://github.com/strahlex/hal-mode/"
  :commit "eeeba86efc7a41a013b8749a45b9db3b21d3d7d2"
  :revdesc "eeeba86efc7a"
  :keywords '("language"))
