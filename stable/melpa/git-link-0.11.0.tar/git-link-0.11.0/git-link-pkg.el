;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-link" "0.11.0"
  "Get the GitHub/Bitbucket/GitLab URL for a buffer location."
  '((emacs "24.3"))
  :url "https://github.com/sshaw/git-link"
  :commit "ca1a170343448c6d5d265ec12f934d865f7e0aee"
  :revdesc "ca1a17034344"
  :keywords '("git" "vc" "github" "bitbucket" "gitlab" "sourcehut" "aws" "azure" "convenience")
  :authors '(("Skye Shaw" . "skye.shaw@gmail.com"))
  :maintainers '(("Skye Shaw" . "skye.shaw@gmail.com")))
