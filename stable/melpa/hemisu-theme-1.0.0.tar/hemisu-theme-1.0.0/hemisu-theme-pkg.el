;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hemisu-theme" "1.0.0"
  "Hemisu for Emacs."
  ()
  :url "http://github/anrzejsliwa/django-theme"
  :commit "4d00f226b3166a97bb69b28314f9c595f3318c9e"
  :revdesc "4d00f226b316")
