;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tablist" "1.3"
  "Extended tabulated-list-mode."
  '((emacs "25.1"))
  :url "https://github.com/emacsorphanage/tablist"
  :commit "01f065e387ffe6b7a41f180f257cd12551c7a9c2"
  :revdesc "v1.3-0-g01f065e387ff"
  :keywords '("extensions" "lisp")
  :authors '(("Andreas Politz" . "politza@fh-trier.de"))
  :maintainers '(("Andreas Politz" . "politza@fh-trier.de")))
