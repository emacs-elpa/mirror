;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clips-mode" "0.7"
  "Clips editing mode."
  ()
  :url "https://github.com/clips-mode/clips-mode"
  :commit "a3ab4a3e958d54a16544ec38fe6338f27df20817"
  :revdesc "v0.7-0-ga3ab4a3e958d"
  :keywords '("clips")
  :authors '(("David E. Young" . "david.young@fnc.fujitsu.com")
             ("Andrey Kotlarski" . "m00naticus@gmail.com")
             ("Grant Rettke" . "grettke@acm.org"))
  :maintainers '(("Grant Rettke" . "grettke@acm.org")))
