;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-indent-mode" "0.126"
  "Auto indent Minor mode."
  ()
  :url "https://github.com/mlf176f2/auto-indent-mode.el/"
  :commit "ad7032ee058a74405d04d775b0b384351536bc53"
  :revdesc "v0.126-0-gad7032ee058a"
  :keywords '("auto" "indentation"))
