;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "struct-completion" "0.1.0"
  "Keyword slot completion for cl-defstruct constructors."
  '((emacs "29.1"))
  :url "https://github.com/gggion/struct-completion.el"
  :commit "68cc1742a8efa8967b76befe7df5473f7708a21c"
  :revdesc "68cc1742a8ef"
  :keywords '("lisp" "completion")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
