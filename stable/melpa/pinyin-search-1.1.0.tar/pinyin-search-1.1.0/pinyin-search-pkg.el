;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-search" "1.1.0"
  "Search Chinese by Pinyin."
  ()
  :url "https://github.com/xuchunyang/pinyin-search.el"
  :commit "5895cccfa6b43263ee243c5642cc16dd9a69fb4e"
  :revdesc "5895cccfa6b4"
  :keywords '("chinese" "search")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
