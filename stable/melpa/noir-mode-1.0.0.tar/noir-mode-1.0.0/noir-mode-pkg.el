;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noir-mode" "1.0.0"
  "Description."
  '((emacs     "25.1")
    (rust-mode "1.0.5"))
  :url "https://github.com/hhamud/noir-mode"
  :commit "aa6686e15a63498af327cc64f1d79e84c60bda42"
  :revdesc "aa6686e15a63"
  :keywords '("languages"))
