;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fixmee" "0.8.6"
  "Quickly navigate to FIXME notices in code."
  '((button-lock    "1.0.2")
    (nav-flash      "1.0.0")
    (back-button    "0.6.0")
    (smartrep       "0.0.3")
    (string-utils   "0.3.2")
    (tabulated-list "0"))
  :url "https://github.com/rolandwalker/fixmee"
  :commit "aa3be8ad9fcc9c0c7ff15f70cda4ba77de96dd74"
  :revdesc "v0.8.6-0-gaa3be8ad9fcc"
  :keywords '("navigation" "convenience")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
