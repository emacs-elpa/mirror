;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-yamllint" "0.1.4"
  "YAML linter with yamllint."
  '((emacs "26.1"))
  :url "https://github.com/shaohme/flymake-yamllint"
  :commit "f269e6614993f3c56d545e7d7b225ca2ba1da342"
  :revdesc "f269e6614993"
  :authors '(("Martin Kjær Jørgensen" . "mkj@gotu.dk"))
  :maintainers '(("Martin Kjær Jørgensen" . "mkj@gotu.dk")))
