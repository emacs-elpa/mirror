;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-try-hard" "0.1"
  "Get all completions from company backends."
  '((emacs   "24.3")
    (company "0.8.0")
    (dash    "2.0"))
  :url "https://github.com/Wilfred/company-try-hard"
  :commit "84c46f90d9d68d53ec8f21e7ec99f63bce91c648"
  :revdesc "84c46f90d9d6"
  :keywords '("matching")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
