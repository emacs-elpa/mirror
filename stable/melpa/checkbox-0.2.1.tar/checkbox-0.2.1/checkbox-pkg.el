;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "checkbox" "0.2.1"
  "Quick manipulation of textual checkboxes."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/camdez/checkbox.el"
  :commit "2afc2011fa35ccfa0ce9ef46cb1896911fa340d1"
  :revdesc "2afc2011fa35"
  :keywords '("convenience")
  :authors '(("Cameron Desautels" . "camdez@gmail.com"))
  :maintainers '(("Cameron Desautels" . "camdez@gmail.com")))
