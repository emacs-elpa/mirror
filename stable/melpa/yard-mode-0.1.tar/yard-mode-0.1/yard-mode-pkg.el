;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yard-mode" "0.1"
  "Minor mode for Ruby YARD comments."
  ()
  :url "https://github.com/pd/yard-mode.el"
  :commit "78792f6a6fbff4f1bc955f494fdb11378e7f8095"
  :revdesc "78792f6a6fbf")
