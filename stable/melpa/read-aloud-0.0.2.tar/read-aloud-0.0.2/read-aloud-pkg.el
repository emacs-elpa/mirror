;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "read-aloud" "0.0.2"
  "A simple interface to TTS engines."
  '((emacs "24.4"))
  :url "https://github.com/gromnitsky/read-aloud.el"
  :commit "d5f80ab72054a957aed25224639c1779cae5f4d1"
  :revdesc "d5f80ab72054"
  :keywords '("multimedia")
  :authors '(("Alexander Gromnitsky" . "alexander.gromnitsky@gmail.com"))
  :maintainers '(("Alexander Gromnitsky" . "alexander.gromnitsky@gmail.com")))
