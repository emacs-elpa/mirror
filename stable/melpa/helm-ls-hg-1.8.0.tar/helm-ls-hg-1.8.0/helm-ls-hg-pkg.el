;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ls-hg" "1.8.0"
  "List hg files in hg project."
  '((helm "1.7.8"))
  :url "https://github.com/emacs-helm/helm-ls-hg"
  :commit "61b91a22fcfb62d0fc56e361ec01ce96973c7165"
  :revdesc "v1.8.0-0-g61b91a22fcfb")
