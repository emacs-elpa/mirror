;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typespec-ts-mode" "0.1"
  "Emacs major mode for TypeSpec (using tree-sitter)."
  '((emacs "29.1"))
  :url "https://github.com/pradyuman/typespec-ts-mode"
  :commit "0ddc9bf972c5b3833208a01bab21c2ce63fe93f3"
  :revdesc "0ddc9bf972c5"
  :keywords '("languages" "tree-sitter" "typespec")
  :authors '(("Pradyuman Vig" . "me@pmn.co"))
  :maintainers '(("Pradyuman Vig" . "me@pmn.co")))
