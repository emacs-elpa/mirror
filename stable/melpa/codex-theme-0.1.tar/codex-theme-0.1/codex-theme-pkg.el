;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codex-theme" "0.1"
  "Codex theme, a simple high contrast theme."
  ()
  :url "https://github.com/hsnovel/codex-theme"
  :commit "bb070de43e34a5d4b333c80fb0cfb2560648bd6f"
  :revdesc "bb070de43e34"
  :authors '(("ağan Korkmaz" . "root@hsnovel.net"))
  :maintainers '(("ağan Korkmaz" . "root@hsnovel.net")))
