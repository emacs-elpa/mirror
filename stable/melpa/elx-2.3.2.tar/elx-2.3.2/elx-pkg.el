;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elx" "2.3.2"
  "Extract information from Emacs Lisp libraries."
  '((emacs  "29.1")
    (compat "30.1")
    (llama  "1.0"))
  :url "https://github.com/emacscollective/elx"
  :commit "5c700de6d3b4163b0a3ed3060f491c22b4bfaa85"
  :revdesc "v2.3.2-0-g5c700de6d3b4"
  :keywords '("docs" "libraries" "packages")
  :authors '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev")))
