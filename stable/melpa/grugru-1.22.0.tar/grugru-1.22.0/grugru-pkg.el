;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grugru" "1.22.0"
  "Rotate text at point."
  '((emacs "24.4"))
  :url "https://github.com/ROCKTAKEY/grugru"
  :commit "2c743b7a981daf86cdfa3deab88a6c68a8d4e5a2"
  :revdesc "2c743b7a981d"
  :keywords '("convenience" "abbrev" "tools")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
