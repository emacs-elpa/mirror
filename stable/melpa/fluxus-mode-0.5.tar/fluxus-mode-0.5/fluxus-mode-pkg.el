;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fluxus-mode" "0.5"
  "Major mode for interfacing with the Fluxus live coding environment."
  '((osc "0.1"))
  :url "https://github.com/defaultxr/fluxus-mode"
  :commit "2bdb0f33b6fed84bc46e6147f744fc6c042cf32c"
  :revdesc "2bdb0f33b6fe"
  :keywords '("languages")
  :authors '(("modula t." . "defaultxr@gmail.com"))
  :maintainers '(("modula t." . "defaultxr@gmail.com")))
