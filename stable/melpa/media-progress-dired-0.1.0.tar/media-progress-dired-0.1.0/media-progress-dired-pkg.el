;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "media-progress-dired" "0.1.0"
  "Display position where media player stopped in dired buffer."
  ()
  :url "https://github.com/jumper047/media-progress"
  :commit "3bdf2cc841c1408efc2bb86c2d8e5e68da02451a"
  :revdesc "3bdf2cc841c1"
  :keywords '("files" "convenience")
  :authors '(("Arthur Miller" . "arthur.miller@live.com"))
  :maintainers '(("Arthur Miller" . "arthur.miller@live.com")))
