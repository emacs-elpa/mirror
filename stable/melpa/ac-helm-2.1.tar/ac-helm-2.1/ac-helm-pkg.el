;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-helm" "2.1"
  "Auto Complete with Helm."
  '((helm          "20130328")
    (auto-complete "1.4.0")
    (popup         "0.5.0"))
  :url "https://github.com/yasuyk/ac-helm"
  :commit "f2110576b0eb35850a7f638c1a991a9fa0c8da3a"
  :revdesc "2.1-0-gf2110576b0eb"
  :keywords '("completion" "convenience" "helm")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org")
             ("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
