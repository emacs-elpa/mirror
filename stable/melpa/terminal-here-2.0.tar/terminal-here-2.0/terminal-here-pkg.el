;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "terminal-here" "2.0"
  "Run an external terminal in current directory."
  '((emacs "25.1"))
  :url "https://github.com/davidshepherd7/terminal-here"
  :commit "c16a500926416c09cd2faee6ab9541686b51e34f"
  :revdesc "c16a50092641"
  :keywords '("tools" "frames")
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
