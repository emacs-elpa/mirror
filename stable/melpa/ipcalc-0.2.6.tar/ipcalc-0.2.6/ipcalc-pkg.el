;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ipcalc" "0.2.6"
  "IP subnet calculator."
  '((cl-lib "0.5"))
  :url "https://github.com/dotemacs/ipcalc.el"
  :commit "633004ccd7bda43941643428490100dfd84a891f"
  :revdesc "633004ccd7bd"
  :keywords '("networking" "tools")
  :authors '(("Aleksandar Simic" . "asimic@gmail.com"))
  :maintainers '(("Aleksandar Simic" . "asimic@gmail.com")))
