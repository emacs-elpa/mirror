;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wakib-keys" "1.0.0"
  "Minor Mode for Modern Keybindings."
  '((emacs "24.4"))
  :url "https://github.com/darkstego/wakib-keys/"
  :commit "85a96e0476d620add31e6e73481dbcf57cabc13e"
  :revdesc "85a96e0476d6"
  :keywords '("convenience" "keybindings" "keys"))
