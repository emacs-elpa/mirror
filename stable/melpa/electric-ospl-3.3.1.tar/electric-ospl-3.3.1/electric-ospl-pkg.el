;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-ospl" "3.3.1"
  "Electric OSPL Mode."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~swflint/electric-ospl-mode"
  :commit "a17f7312ef48eba1586c7d0637336eb19aee057e"
  :revdesc "v3.3.1-0-ga17f7312ef48"
  :keywords '("convenience" "text")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
