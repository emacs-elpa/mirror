;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-hungry-delete" "0.1"
  "Smart hungry deletion of whitespace."
  ()
  :url "https://github.com/hrehfeld/emacs-smart-hungry-delete"
  :commit "8f06e4dd5b936cc329e5cb20d8e5176b8a6ccc41"
  :revdesc "8f06e4dd5b93"
  :keywords '("convenience")
  :authors '(("Hauke Rehfeld" . "emacs@haukerehfeld.de"))
  :maintainers '(("Hauke Rehfeld" . "emacs@haukerehfeld.de")))
