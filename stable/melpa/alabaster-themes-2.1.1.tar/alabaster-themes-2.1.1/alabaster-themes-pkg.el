;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alabaster-themes" "2.1.1"
  "Alabaster themes collection."
  '((emacs "28.1"))
  :url "https://github.com/vedang/alabaster-themes"
  :commit "73b9500231f4d6313a4088f85f45b3d95226e639"
  :revdesc "73b9500231f4"
  :keywords '("faces" "theme" "minimal"))
