;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stgit" "2.6.0"
  "Major mode for StGit interaction."
  ()
  :url "http://stacked-git.github.io"
  :commit "41e81189613ff3060fa5cc372e871f61cbcd78c2"
  :revdesc "v2.6.0-0-g41e81189613f"
  :authors '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainers '(("David Kågedal" . "davidk@lysator.liu.se")))
