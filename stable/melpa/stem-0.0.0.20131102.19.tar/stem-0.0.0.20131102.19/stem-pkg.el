;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stem" "0.0.0.20131102.19"
  "Routines for stemming."
  ()
  :url "https://github.com/yuutayamada/stem"
  :commit "dd704c3447bd5d3f5ac0a4840f8987d4f855d87e"
  :revdesc "dd704c3447bd"
  :keywords '("stemming")
  :authors '(("Tsuchiya Masatoshi" . "tsuchiya@pine.kuee.kyoto-u.ac.jp"))
  :maintainers '(("Tsuchiya Masatoshi" . "tsuchiya@pine.kuee.kyoto-u.ac.jp")))
