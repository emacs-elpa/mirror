;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-mt" "0.9"
  "Helm multi-term management."
  '((emacs      "24")
    (helm       "0.0")
    (multi-term "0.0")
    (cl-lib     "0.5"))
  :url "https://github.com/dfdeshom/helm-mt"
  :commit "d2bff4100118483bc398c56d0ff095294209265b"
  :revdesc "d2bff4100118"
  :keywords '("helm" "multi-term")
  :authors '(("Didier Deshommes" . "dfdeshom@gmail.com"))
  :maintainers '(("Didier Deshommes" . "dfdeshom@gmail.com")))
