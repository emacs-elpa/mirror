;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-dict" "1.2.8"
  "A backend that emulates ac-source-dictionary."
  '((emacs       "24.4")
    (company     "0.8.12")
    (parent-mode "2.3"))
  :url "https://github.com/hlissner/emacs-company-dict"
  :commit "cd7b8394f6014c57897f65d335d6b2bd65dab1f4"
  :revdesc "cd7b8394f601"
  :keywords '("company" "dictionary" "ac-source-dictionary")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "henrik@lissner.net")))
