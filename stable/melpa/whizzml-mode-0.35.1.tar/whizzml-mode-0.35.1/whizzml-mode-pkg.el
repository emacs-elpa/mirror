;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whizzml-mode" "0.35.1"
  "Programming mode for editing WhizzML files."
  '((emacs "24.4"))
  :url "https://github.com/whizzml/whizzml-mode"
  :commit "65fa17f8c1dc50dcb90277b64019c2846a317293"
  :revdesc "65fa17f8c1dc"
  :keywords '("languages" "lisp")
  :authors '(("Jose Antonio Ortega Ruiz" . "jao@bigml.com"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "jao@bigml.com")))
