;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpmc-queue" "0.1.1"
  "A multiple-producer-multiple-consumer queue."
  '((emacs "26.0")
    (queue "0.2.0"))
  :url "https://github.com/smizoe/mpmc-queue"
  :commit "4775ddcb120528828ef1fcb7ee761524a0907a31"
  :revdesc "0.1.1-0-g4775ddcb1205"
  :keywords '("lisp" "async")
  :authors '(("Sho Mizoe" . "sho.mizoe@gmail.com"))
  :maintainers '(("Sho Mizoe" . "sho.mizoe@gmail.com")))
