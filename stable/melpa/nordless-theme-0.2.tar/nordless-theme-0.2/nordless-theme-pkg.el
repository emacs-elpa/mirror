;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nordless-theme" "0.2"
  "A mostly colorless version of nord-theme."
  '((colorless-themes "0.1"))
  :url "https://git.sr.ht/~lthms/colorless-themes.el"
  :commit "8e539097185704444a5dd5545924de92c11ba767"
  :revdesc "0.2-0-g8e5390971857"
  :keywords '("faces" "theme")
  :authors '(("Thomas Letan" . "contact@thomasletan.fr"))
  :maintainers '(("Thomas Letan" . "contact@thomasletan.fr")))
