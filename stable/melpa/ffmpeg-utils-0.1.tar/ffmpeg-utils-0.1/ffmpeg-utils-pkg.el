;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ffmpeg-utils" "0.1"
  "FFmpeg command utilities wrappers."
  '((emacs     "25.1")
    (alert     "1.2")
    (transient "0.1.0")
    (osx-lib   "0.1"))
  :url "https://repo.or.cz/ffmpeg-utils.git"
  :commit "2c4db969c161da83956a685b4c008490dfe7de3e"
  :revdesc "2c4db969c161"
  :keywords '("multimedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
