;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emoji-github" "0.2.3"
  "Display list of GitHub's emoji.  (cheat sheet)."
  '((emacs   "24.4")
    (emojify "1.0")
    (request "0.3.0"))
  :url "https://github.com/jcs-elpa/emoji-github"
  :commit "d512c2babb412820945444c6daf309b470e2eb12"
  :revdesc "d512c2babb41"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
