;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-html5slide" "0.1"
  "Export org-mode to HTML5 slide."
  ()
  :url "https://github.com/coldnew/org-html5slide"
  :commit "416f015f90a7ee62a0ca3594352fd4d11cece377"
  :revdesc "416f015f90a7"
  :keywords '("html" "presentation")
  :authors '(("coldnew" . "coldnew.tw@gmail.com"))
  :maintainers '(("coldnew" . "coldnew.tw@gmail.com")))
