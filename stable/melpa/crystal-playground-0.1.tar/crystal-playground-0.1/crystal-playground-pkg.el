;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crystal-playground" "0.1"
  "Local crystal playground for short code snippets."
  '((emacs        "24.3")
    (crystal-mode "0.1.2"))
  :url "https://github.com/jasonrobot/crystal-playground"
  :commit "25c65360446779f9fb4968bc2ae01abcc152d919"
  :revdesc "25c653604467"
  :keywords '("tools" "crystal"))
