;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clang-format+" "1.0.0"
  "Clang-format minor mode."
  '((emacs        "24.3")
    (clang-format "0"))
  :url "https://github.com/SavchenkoValeriy/clang-format+"
  :commit "311101ba5e08bc6b5c28c3b4ba5ca0f786bd4dac"
  :revdesc "311101ba5e08"
  :keywords '("c" "c++" "clang-format")
  :authors '(("Valeriy Savchenko" . "sinmipt@gmail.com"))
  :maintainers '(("Valeriy Savchenko" . "sinmipt@gmail.com")))
