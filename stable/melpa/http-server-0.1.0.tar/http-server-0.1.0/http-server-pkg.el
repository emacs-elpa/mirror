;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-server" "0.1.0"
  "Speaks HTTP for you."
  '((emacs "30.1"))
  :url "https://codeberg.org/martenlienen/http-server.el"
  :commit "bc250b796e95de9b27317272c8980911159df719"
  :revdesc "bc250b796e95"
  :keywords '("comm")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
