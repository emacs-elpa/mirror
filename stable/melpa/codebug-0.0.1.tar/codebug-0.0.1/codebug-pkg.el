;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codebug" "0.0.1"
  "Interact with codebug."
  ()
  :url "http://www.shanedowling.com/"
  :commit "f3ca684d459f80e944483c9c5a02e96552943155"
  :revdesc "f3ca684d459f")
