;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom" "1.3"
  "DOM implementation and manipulation library."
  '((cl-lib "0.5"))
  :url "http://www.github.com/toroidal-code/doom.el/"
  :commit "5e2d3f54e5b84eaa533cbdb6cf17b1b6009f0730"
  :revdesc "5e2d3f54e5b8"
  :keywords '("xml" "doom")
  :authors '(("Alex Schroeder" . "alex@gnu.org")
             ("Henrik.Motakef" . "elisp@henrik-motakef.de")
             ("Katherine Whitlock" . "toroidal-code@gmail.com")))
