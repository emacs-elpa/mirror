;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bfbuilder" "1.0.1"
  "A brainfuck development environment with interactive debugger."
  '((cl-lib "0.3")
    (emacs  "24.4"))
  :url "http://hins11.yu-yake.com/"
  :commit "22b2d4a0c9e81876cfbd4d2c756cee45a495051e"
  :revdesc "22b2d4a0c9e8")
