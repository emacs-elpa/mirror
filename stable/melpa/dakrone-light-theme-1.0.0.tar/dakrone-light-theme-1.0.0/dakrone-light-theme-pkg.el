;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dakrone-light-theme" "1.0.0"
  "Dakrone's custom light theme."
  ()
  :url "https://github.com/dakrone/dakrone-light-theme"
  :commit "e8c121c277a8d1f5d9b7a8e5b894e58b015e2b93"
  :revdesc "e8c121c277a8"
  :keywords '("color" "themes")
  :authors '(("Lee Hinman" . "lee_AT_writequit.org"))
  :maintainers '(("Lee Hinman" . "lee_AT_writequit.org")))
