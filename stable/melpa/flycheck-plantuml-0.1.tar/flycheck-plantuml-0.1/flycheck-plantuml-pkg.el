;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-plantuml" "0.1"
  "Integrate plantuml with flycheck."
  '((flycheck      "0.24")
    (emacs         "24.4")
    (plantuml-mode "1.2.2"))
  :url "https://github.com/alexmurray/flycheck-plantuml"
  :commit "faa60184bea6303ec96604b9d2391803c650ee11"
  :revdesc "faa60184bea6"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
