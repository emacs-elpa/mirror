;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.6.15.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "12aa4b1db9d92577047e37608b8ba72f98e0e6c0"
  :revdesc "12aa4b1db9d9"
  :keywords '("languages"))
