;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daemons" "2.1.0"
  "UI for managing init system daemons (services)."
  '((emacs  "25.1")
    (s      "1.13.0")
    (compat "29.1.4.2"))
  :url "https://github.com/cbowdon/daemons.el"
  :commit "0dc7f1ec81fa70b3cafdc394413fe14fd3a413e4"
  :revdesc "0dc7f1ec81fa"
  :keywords '("unix" "convenience"))
