;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minitest" "0.10.0"
  "An Emacs mode for ruby minitest files."
  '((dash "1.0.0"))
  :url "https://github.com/arthurnn/minitest-emacs"
  :commit "ddd152c990a528ad09a696bfad23afa4330ea4d7"
  :revdesc "ddd152c990a5")
