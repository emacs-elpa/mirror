;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "region-occurrences-highlighter" "1.6.2"
  "Mark occurrences of current region (selection)."
  '((emacs "26.1"))
  :url "https://github.com/alvarogonzalezsotillo/region-occurrences-highlighter"
  :commit "5bcc35244411d0f1f93badd7330eac97f316991b"
  :revdesc "5bcc35244411"
  :keywords '("convenience")
  :authors '(("lvaro González Sotillo" . "alvarogonzalezsotillo@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
