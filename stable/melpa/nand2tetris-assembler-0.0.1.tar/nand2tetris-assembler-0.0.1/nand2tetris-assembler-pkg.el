;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nand2tetris-assembler" "0.0.1"
  "Assembler For the Nand2tetris Course."
  '((company   "0.5")
    (cl-lib    "0.5.0")
    (yasnippet "0.8.0"))
  :url "http://www.github.com/CestDiego/nand2tetris-assembler.el/"
  :commit "9e1f9f4c68bc1321d2b2e8af4b4e3d3b2413502b"
  :revdesc "9e1f9f4c68bc"
  :keywords '("nand2tetris-assembler" "hdl")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")))
