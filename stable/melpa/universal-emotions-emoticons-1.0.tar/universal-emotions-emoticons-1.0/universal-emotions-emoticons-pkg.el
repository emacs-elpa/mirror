;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "universal-emotions-emoticons" "1.0"
  "Emoticons For The Six Universal Expressions."
  '((emacs "24.4"))
  :url "https://github.com/grettke/universal-emotions-emoticons"
  :commit "ba9d435d7360e6f98fb16f2e3edcb7761b36e3b0"
  :revdesc "ba9d435d7360"
  :keywords '("convenience" "docs" "languages")
  :authors '(("Grant Rettke" . "gcr@wisdomandwonder.com"))
  :maintainers '((nil . "gcr@wisdomandwonder.com")))
