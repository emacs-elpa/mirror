;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nushell-mode" "0.2.0"
  "Major mode for Nushell scripts."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/nushell-mode"
  :commit "be6b51b5eeaf8486812d8eb51877c60d8c9346c6"
  :revdesc "be6b51b5eeaf"
  :keywords '("languages" "unix")
  :authors '(("Azzam S.A" . "vcs@azzamsa.com"))
  :maintainers '(("Azzam S.A" . "vcs@azzamsa.com")))
