;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-tube" "0.15"
  "YouTube integration for Elfeed."
  '((emacs  "27.1")
    (elfeed "3.4.1")
    (aio    "1.0"))
  :url "https://github.com/karthink/elfeed-tube"
  :commit "7e1409e41628d61d8197ca248d910182ae4fc520"
  :revdesc "7e1409e41628"
  :keywords '("news" "hypermedia" "convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
