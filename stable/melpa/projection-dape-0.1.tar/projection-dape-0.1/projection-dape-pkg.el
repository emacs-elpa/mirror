;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projection-dape" "0.1"
  "Projection integration for `dape'."
  '((emacs      "29.1")
    (projection "0.1")
    (dape       "0.8"))
  :url "https://github.com/mohkale/projection"
  :commit "20548689eead0a86fcc921491047f392fd6b120f"
  :revdesc "20548689eead"
  :keywords '("project" "convenience")
  :authors '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@kisara.moe")))
