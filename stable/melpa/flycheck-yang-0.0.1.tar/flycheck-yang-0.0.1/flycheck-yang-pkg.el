;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-yang" "0.0.1"
  "YANG flycheck checker."
  '((yang-mode "0.9.4")
    (flycheck  "0.18"))
  :url "https://github.com/andaru/flycheck-yang"
  :commit "c5f65fe3f710f73d56e04d077868719afc1ebfaf"
  :revdesc "c5f65fe3f710"
  :authors '(("Andrew Fort" . "(@andaru)"))
  :maintainers '(("Andrew Fort" . "(@andaru)")))
