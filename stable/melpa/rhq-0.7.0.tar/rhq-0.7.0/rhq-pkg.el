;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rhq" "0.7.0"
  "Client for rhq."
  '((emacs "24.4"))
  :url "https://github.com/ROCKTAKEY/rhq"
  :commit "80c1d59a66dceb3f9e0af9319720f8e4e4895c2c"
  :revdesc "v0.7.0-0-g80c1d59a66dc"
  :keywords '("tools" "extensions")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
