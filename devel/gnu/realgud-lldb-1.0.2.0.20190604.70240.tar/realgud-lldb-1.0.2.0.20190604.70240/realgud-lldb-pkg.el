;; Generated package description from realgud-lldb.el  -*- no-byte-compile: t -*-
(define-package "realgud-lldb" "1.0.2.0.20190604.70240" "Realgud front-end to lldb" '((load-relative "1.3.1") (realgud "1.5.0") (emacs "25")) :authors '(("Rocky Bernstein" . "rocky@gnu.org")) :maintainer '("Rocky Bernstein" . "rocky@gnu.org") :url "http://github.com/realgud/realgud-lldb")
