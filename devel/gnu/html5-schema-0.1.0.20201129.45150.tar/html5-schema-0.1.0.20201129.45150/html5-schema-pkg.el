;; Generated package description from html5-schema.el  -*- no-byte-compile: t -*-
(define-package "html5-schema" "0.1.0.20201129.45150" "Add HTML5 schemas for use by nXML" 'nil :keywords '("html" "xml") :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca")) :maintainer '("Stefan Monnier" . "monnier@iro.umontreal.ca") :url "https://github.com/validator/validator")
