;; Generated package description from myers.el  -*- no-byte-compile: t -*-
(define-package "myers" "0.1.0.20201129.944" "Random-access singly-linked lists" '((emacs "25")) :url "https://elpa.gnu.org/packages/myers.html" :keywords '("list" "containers") :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca")) :maintainer '("Stefan Monnier" . "monnier@iro.umontreal.ca"))
