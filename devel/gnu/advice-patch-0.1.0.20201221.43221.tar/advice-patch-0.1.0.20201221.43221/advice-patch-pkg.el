;; Generated package description from advice-patch.el  -*- no-byte-compile: t -*-
(define-package "advice-patch" "0.1.0.20201221.43221" "Use patches to advise the inside of functions" '((emacs "24.4")) :url "https://elpa.gnu.org/packages/advice-patch.html" :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca")) :maintainer '("Stefan Monnier" . "monnier@iro.umontreal.ca"))
