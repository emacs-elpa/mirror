;; Generated package description from realgud-ipdb.el  -*- no-byte-compile: t -*-
(define-package "realgud-ipdb" "1.0.0.0.20190604.20934" "Realgud front-end to ipdb" '((realgud "1.5.0") (load-relative "1.3.1") (emacs "25")) :authors '(("Rocky Bernstein" . "rocky@gnu.org")) :maintainer '("Rocky Bernstein" . "rocky@gnu.org") :url "http://github.com/rocky/realgud-ipdb")
