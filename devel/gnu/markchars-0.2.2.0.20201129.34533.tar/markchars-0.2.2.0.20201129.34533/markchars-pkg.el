;; Generated package description from markchars.el  -*- no-byte-compile: t -*-
(define-package "markchars" "0.2.2.0.20201129.34533" "Mark chars fitting certain characteristics" 'nil :url "https://elpa.gnu.org/packages/markchars.html" :authors '(("Lennart Borgman" . "lennart.borgman@gmail.com")) :maintainer '("Lennart Borgman" . "lennart.borgman@gmail.com"))
