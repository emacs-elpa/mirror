;; Generated package description from pspp-mode.el  -*- no-byte-compile: t -*-
(define-package "pspp-mode" "1.1.0.20200706.84553" "Major mode for editing PSPP files" 'nil :url "https://elpa.gnu.org/packages/pspp-mode.html" :keywords '("pspp" "major-mode") :authors '(("Scott Andrew Borton" . "scott@pp.htv.fi")) :maintainer '("John Darrington" . "john@darrington.wattle.id.au"))
