;; Generated package description from vlf.el  -*- no-byte-compile: t -*-
(define-package "vlf" "1.7.2.0.20201128.55141" "View Large Files" 'nil :keywords '("large files" "utilities") :maintainer '("Andrey Kotlarski" . "m00naticus@gmail.com") :url "https://github.com/m00natic/vlfi")
