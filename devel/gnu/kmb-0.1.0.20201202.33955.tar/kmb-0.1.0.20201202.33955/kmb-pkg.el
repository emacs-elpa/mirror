;; Generated package description from kmb.el  -*- no-byte-compile: t -*-
(define-package "kmb" "0.1.0.20201202.33955" "Kill buffers matching a regexp w/o confirmation" '((emacs "24.1")) :url "https://elpa.gnu.org/packages/kmb.html" :keywords '("lisp" "convenience") :authors '(("Tino Calancha" . "tino.calancha@gmail.com")) :maintainer '("Tino Calancha" . "tino.calancha@gmail.com"))
