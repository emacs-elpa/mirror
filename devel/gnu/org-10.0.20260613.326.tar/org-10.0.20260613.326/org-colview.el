;;; org-colview.el --- Column View in Org            -*- lexical-binding: t; -*-

;; Copyright (C) 2004-2026 Free Software Foundation, Inc.

;; Author: Carsten Dominik <carsten.dominik@gmail.com>
;; Maintainer: Slawomir Grochowski <slawomir.grochowski@gmail.com>
;; Keywords: outlines, hypermedia, calendar, text
;; URL: https://orgmode.org
;;
;; This file is part of GNU Emacs.
;;
;; GNU Emacs is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; GNU Emacs is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with GNU Emacs.  If not, see <https://www.gnu.org/licenses/>.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;;; Commentary:

;; This file contains the column view for Org.

;;; Code:
;;;; Require other packages

(require 'org-macs)
(org-assert-version)

(require 'cl-lib)
(require 'org)

(declare-function org-agenda-redo "org-agenda" (&optional all))
(declare-function org-agenda-do-context-action "org-agenda" ())
(declare-function org-clock-sum-today "org-clock" (&optional headline-filter))
(declare-function org-element-extract "org-element-ast" (node))
(declare-function org-element-interpret-data "org-element" (data))
(declare-function org-element-map "org-element" (data types fun &optional info first-match no-recursion with-affiliated no-undefer))
(declare-function org-element-parse-secondary-string "org-element" (string restriction &optional parent))
(declare-function org-element-property "org-element-ast" (property node))
(declare-function org-element-restriction "org-element" (element))
(declare-function org-element-type-p "org-element-ast" (node types))
(declare-function org-link-display-format "ol" (s))
(declare-function org-link-open-from-string "ol" (s &optional arg))
(declare-function face-remap-remove-relative "face-remap" (cookie))
(declare-function face-remap-add-relative "face-remap" (face &rest specs))

(defvar org-agenda-columns-add-appointments-to-effort-sum)
(defvar org-agenda-columns-active) ;; defined in org-agenda.el
(defvar org-agenda-columns-compute-summary-properties)
(defvar org-agenda-columns-show-summaries)
(defvar org-agenda-view-columns-initially)
(defvar org-columns-summary-types-default) ; defined below


;;;; Customizable variables

(defcustom org-columns-checkbox-allowed-values '("[ ]" "[X]")
  "Allowed values for columns with SUMMARY-TYPE that uses checkbox.
The affected summary types are \"X%\", \"X/\", and \"X\" (see info
node `(org)Column attributes')."
  :group 'org-properties
  :package-version '(Org . "9.6")
  :type '(repeat (choice
                  (const :tag "Unchecked [ ]" "[ ]")
                  (const :tag "Checked [X]" "[X]")
                  (const :tag "No checkbox" "")
                  (const :tag "Intermediate state [-]" "[-]")
                  (string :tag "Arbitrary string"))))

(defcustom org-columns-modify-value-for-display-function nil
  "Function that modifies values for display in column view.
For example, it can be used to cut out a certain part from a timestamp.
The function must take 2 arguments:

column-title    The title of the column (*not* the property name)
value           The value that should be modified.

The function should return the value that should be displayed,
or nil if the normal value should be used."
  :group 'org-properties
  :type '(choice (const nil) (function)))

(defcustom org-columns-summary-types nil
  "Alist between operators and summarize functions.

Each association follows the pattern (LABEL . SUMMARIZE),
or (LABEL SUMMARIZE COLLECT) where

  LABEL is a string used in #+COLUMNS definition describing the
  summary type.  It can contain any character but \"}\".  It is
  case-sensitive.

  SUMMARIZE is a function called with two arguments.  The first
  argument is a non-empty list of values, as non-empty strings.
  The second one is a format string or nil.  It has to return
  a string summarizing the list of values.

  COLLECT is a function called with one argument, a property
  name.  It is called in the context of a headline and must
  return the collected property, or the empty string.  You can
  use this to only collect a property if a related conditional
  properties is set, e.g., to return VACATION_DAYS only if
  CONFIRMED is true.

Note that the return value can become one value for a higher-order
summary, so the function is expected to handle its own output.

Types defined in this variable take precedence over those defined
in `org-columns-summary-types-default', which see."
  :group 'org-properties
  :version "26.1"
  :package-version '(Org . "9.0")
  :type '(alist :key-type (string :tag "       Label")
		:value-type
		(choice (function :tag "Summarize")
			(list :tag "Collect and summarize"
			      (function :tag "Summarize")
			      (function :tag "Collect")))))

(defcustom org-columns-dblock-formatter #'org-columns-dblock-write-default
  "Function to format data in column view dynamic blocks.
For more information, see `org-columns-dblock-write-default'."
  :group 'org-properties
  :package-version '(Org . "9.7")
  :type 'function)


;;; Column View

;;;; State

(defvar-local org-columns-overlays nil
  "Holds the list of current column overlays.")
(put 'org-columns-overlays 'permanent-local t)

(defvar-local org-columns-global nil
  "Local variable, holds non-nil when current columns are global.")

(defvar-local org-columns-current-fmt nil
  "Local variable, holds the currently active column format.")

(defvar-local org-columns-current-fmt-compiled nil
  "Local variable, holds the currently active column format.
This is the compiled version of the format.")

(defvar-local org-columns-current-maxwidths nil
  "Currently active maximum column widths, as a vector.")

(defvar-local org-columns-begin-marker nil
  "Points to the position where a column creation command was last called.")

(defvar-local org-columns-top-level-marker nil
  "Points to the position where the current columns region starts.")

(defvar org-columns--time 0.0
  "Number of seconds since the epoch, as a floating point number.")

(defvar org-columns-map (make-sparse-keymap)
  "The keymap valid in column display.")

;;;; Column specifications

(cl-defstruct (org-columns--spec
	       (:type list)
	       (:constructor org-columns--make-spec
		   (property title width operator format-string)))
  "Compiled column specification."
  property title width operator format-string)

(defun org-columns--spec-at-point ()
  "Return the column specification for the column at point.
Point must be on a column view overlay, where the current text
column indexes `org-columns-current-fmt-compiled'."
  (nth (org-current-text-column) org-columns-current-fmt-compiled))

;;;; Keymap and menu

(defun org-columns-content ()
  "Switch to content view while in column view."
  (interactive nil org-mode)
  (org-cycle-overview)
  (org-cycle-content))

(org-defkey org-columns-map "c"        #'org-columns-content)
(org-defkey org-columns-map "o"        #'org-overview)
(org-defkey org-columns-map "e"        #'org-columns-edit-value)
(org-defkey org-columns-map "\C-c\C-t" #'org-columns-todo)
(org-defkey org-columns-map "\C-c\C-c" #'org-columns-toggle-or-columns-quit)
(org-defkey org-columns-map "\C-c\C-o" #'org-columns-open-link)
(org-defkey org-columns-map "v"        #'org-columns-show-value)
(org-defkey org-columns-map "q"        #'org-columns-quit)
(org-defkey org-columns-map "r"        #'org-columns-redo)
(org-defkey org-columns-map "g"        #'org-columns-redo)
(org-defkey org-columns-map [left]     #'backward-char)
(org-defkey org-columns-map "\M-b"     #'backward-char)
(org-defkey org-columns-map "a"        #'org-columns-edit-allowed)
(org-defkey org-columns-map "s"        #'org-columns-edit-attributes)
(org-defkey org-columns-map "\M-f"     #'forward-char)
(org-defkey org-columns-map [right]    #'forward-char)
(org-defkey org-columns-map [up]       #'org-columns-move-up)
(org-defkey org-columns-map [down]     #'org-columns-move-down)
(org-defkey org-columns-map [(shift right)] #'org-columns-next-allowed-value)
(org-defkey org-columns-map "n" #'org-columns-next-allowed-value)
(org-defkey org-columns-map [(shift left)] #'org-columns-previous-allowed-value)
(org-defkey org-columns-map "p" #'org-columns-previous-allowed-value)
(org-defkey org-columns-map "<" #'org-columns-narrow)
(org-defkey org-columns-map ">" #'org-columns-widen)
(org-defkey org-columns-map [(meta right)] #'org-columns-move-right)
(org-defkey org-columns-map [(meta left)]  #'org-columns-move-left)
(org-defkey org-columns-map [(meta down)]  #'org-columns-move-row-down)
(org-defkey org-columns-map [(meta up)]  #'org-columns-move-row-up)
(org-defkey org-columns-map [(shift meta right)] #'org-columns-new)
(org-defkey org-columns-map [(shift meta left)]  #'org-columns-delete)
(dotimes (i 10)
  (org-defkey org-columns-map (number-to-string i)
	      (lambda () (interactive)
		(org-columns-next-allowed-value nil i))))

(easy-menu-define org-columns-menu org-columns-map "Org Column Menu."
  '("Column"
    ["Edit property" org-columns-edit-value t]
    ["Next allowed value" org-columns-next-allowed-value t]
    ["Previous allowed value" org-columns-previous-allowed-value t]
    ["Show full value" org-columns-show-value t]
    ["Edit allowed values" org-columns-edit-allowed t]
    "--"
    ["Edit column attributes" org-columns-edit-attributes t]
    ["Increase column width" org-columns-widen t]
    ["Decrease column width" org-columns-narrow t]
    "--"
    ["Move column right" org-columns-move-right t]
    ["Move column left" org-columns-move-left t]
    ["Move row up" org-columns-move-row-up t]
    ["Move row down" org-columns-move-row-down t]
    ["Add column" org-columns-new t]
    ["Delete column" org-columns-delete t]
    "--"
    ["CONTENTS" org-columns-content t]
    ["OVERVIEW" org-overview t]
    ["Refresh column view" org-columns-redo t]
    "--"
    ["Open link" org-columns-open-link t]
    "--"
    ["Quit" org-columns-quit t]))

;;;; Value collection

(defun org-columns--displayed-value (spec value &optional no-star)
  "Return displayed value for specification SPEC in current entry.

SPEC is a column format specification as stored in
`org-columns-current-fmt-compiled'.  VALUE is the real value to
display, as a string.

When NO-STAR is non-nil, do not add asterisks before displayed
value for ITEM property."
  (or (and (functionp org-columns-modify-value-for-display-function)
	   (funcall org-columns-modify-value-for-display-function
		    (org-columns--spec-title spec)
		    value))
      (pcase spec
	(`("ITEM" . ,_)
	 (let ((stars
		(and (not no-star)
		     (concat (make-string (1- (org-current-level))
					  (if org-hide-leading-stars ?\s ?*))
			     "* "))))
	   (concat stars (org-link-display-format value))))
	(`(,(or "DEADLINE" "SCHEDULED" "TIMESTAMP") . ,_)
	 (replace-regexp-in-string org-ts-regexp "[\\1]" value))
	(`(,_ ,_ ,_ ,_ nil) value)
	;; If FORMAT-STRING is set, assume we are displaying a number and
	;; obey to the format string.
	(`(,_ ,_ ,_ ,_ ,format-string) (format format-string (string-to-number value)))
	(_ (error "Invalid column specification format: %S" spec)))))

(defun org-columns--agenda-effort-fallback (property agenda-marker)
  "Return appointment duration as fallback value for Effort column.
PROPERTY is the column property name.  AGENDA-MARKER is the marker
pointing to the agenda line; it is non-nil only when called from
`org-agenda-columns', which gates this fallback."
  (and org-agenda-columns-add-appointments-to-effort-sum
       agenda-marker
       (string= property (upcase org-effort-property))
       (let ((duration (get-text-property
                        (marker-position agenda-marker)
                        'duration
                        (marker-buffer agenda-marker))))
         (and duration
              (propertize (org-duration-from-minutes duration)
                          'face 'org-warning)))))

(defun org-columns--collect-values (&optional compiled-format agenda-marker)
  "Collect values for columns on the current line.

Return a list of triplets (SPEC VALUE DISPLAYED-VALUE) suitable for
`org-columns--display-line'.

This function assumes `org-columns-current-fmt-compiled' is set
in the current buffer.  However, it is possible to override it
with optional argument COMPILED-FORMAT.

The optional argument AGENDA-MARKER is used when called from the
agenda to pass a marker to the agenda line.  When non-nil, ITEM is
displayed without leading stars."
  (let ((summaries (get-text-property (point) 'org-summaries))
	(agenda-mode (and agenda-marker t))
	(compiled-format (or compiled-format org-columns-current-fmt-compiled))
	(entry-element (org-element-at-point)))
    (mapcar
     (lambda (spec)
       (let* ((property (org-columns--spec-property spec))
	      (value (or (cdr (assoc spec summaries))
			 (org-entry-get entry-element property 'selective t)
			 (org-columns--agenda-effort-fallback property agenda-marker)
			 "")))
	 (list spec value (org-columns--displayed-value spec value agenda-mode))))
     compiled-format)))

(defun org-columns--collect-rows ()
  "Collect column view rows in the current scope."
  (org-scan-tags
   (lambda ()
     (cons (point-marker) (org-columns--collect-values)))
   t
   org--matcher-tags-todo-only))

(defun org-columns--compute-clock-summaries ()
  "Compute clock summaries needed by the current column format."
  (when (assoc "CLOCKSUM" org-columns-current-fmt-compiled)
    (org-clock-sum))
  (when (assoc "CLOCKSUM_T" org-columns-current-fmt-compiled)
    (org-clock-sum-today)))

;;;; Column widths

(defun org-columns--update-column-width (spec cell widths)
  "Update WIDTHS according to SPEC and CELL.
WIDTHS is the current tail of the column widths list.  CELL is a
list (SPEC VALUE DISPLAYED-VALUE), as returned by
`org-columns--collect-values'."
  (unless (wholenump (org-columns--spec-width spec))
    (setcar widths
	    (max (car widths)
                 (string-width (nth 2 cell))))))

(defun org-columns--set-widths (rows)
  "Compute the maximum column widths from the format and ROWS.
This function sets `org-columns-current-maxwidths' as a vector of
integers greater than 0.

ROWS is a list of entries.  Each entry is a cons cell:

  (POSITION . ((SPEC VALUE DISPLAYED-VALUE) ...))

where:

  POSITION       a marker (or integer) pointing to the buffer position
                 where this cell row's column overlay are displayed

  Each element of the cdr is a list (SPEC VALUE DISPLAYED-VALUE) where
  VALUE is the raw property value as a string (or \"\" if empty)
  and DISPLAYED-VALUE is the value as it should be displayed, as a string.
  SPEC is a list as returned by `org-columns-compile-format'."
  (setq org-columns-current-maxwidths
	(let ((widths (mapcar (lambda (spec)
				(pcase spec
				  (`(,_ ,_ ,(and width (pred wholenump)) . ,_) width)
				  (`(,_ ,title . ,_) (string-width title))))
			      org-columns-current-fmt-compiled)))
	  (dolist (row rows)
	    (let ((remaining-triplets (cdr row))
		  (remaining-specs org-columns-current-fmt-compiled)
		  (remaining-widths widths))
	      (while (and remaining-triplets remaining-specs remaining-widths)
		(org-columns--update-column-width (car remaining-specs)
                                       (car remaining-triplets)
                                       remaining-widths)
		(pop remaining-triplets)
		(pop remaining-specs)
		(pop remaining-widths))))
	  (apply #'vector widths))))

;;;; Overlay rendering

;;;;; Overlay helpers

(defun org-columns--new-overlay (beg end &optional string face)
  "Create a new column overlay and add it to the list."
  (let ((ov (make-overlay beg end)))
    (overlay-put ov 'face (or face 'secondary-selection))
    (org-overlay-display ov string face)
    (push ov org-columns-overlays)
    ov))

(defun org-columns--cell-format-string (width &optional lastp)
  "Return `format' template for a column overlay cell of WIDTH characters.
The template pads and truncates its argument to WIDTH characters,
followed by \" | \" separator.  When optional argument LASTP is
non-nil, omit the trailing space after the separator, since no
further column follows."
  (concat (format "%%-%d.%ds |" width width)
	  (unless lastp " ")))

(defun org-columns--propertize-tags (tag-text)
  "Apply Org tag faces to TAG-TEXT."
  (if (not org-tags-special-faces-re)
      (propertize tag-text 'face 'org-tag)
    (replace-regexp-in-string
     org-tags-special-faces-re
     (lambda (tag) (propertize tag 'face (org-get-tag-face tag)))
     tag-text nil nil 1)))

(defun org-columns--overlay-text
    (displayed-value cell-format-string width property value)
  "Return decorated DISPLAYED-VALUE string for column overlay display.
CELL-FORMAT-STRING is a `format' string.  WIDTH is the width of the
column, as an integer.  PROPERTY identifies the column and is used
to select faces for the displayed cell text.  VALUE is the raw
property value before it is modified by `org-columns--displayed-value'."
  (format cell-format-string
          (let ((cell-text (org-columns-add-ellipses displayed-value width)))
            (pcase property
              ("PRIORITY" (propertize cell-text 'face (org-get-priority-face value)))
              ("TAGS" (org-columns--propertize-tags cell-text))
              ("TODO" (propertize cell-text 'face (org-get-todo-face value)))
              (_ cell-text)))))

(defvar org-columns--read-only-string nil)

;;;;; Line rendering

(defun org-columns--pad-line-for-overlays ()
  "Pad current line with spaces, one per column if needed.
Kludge: column display modifies the buffer here, which it should not.
Each column is rendered as an overlay anchored on a character, so the
underlying line must contain at least as many characters as there are
columns in `org-columns-current-fmt-compiled'.  Short lines (e.g.
empty headlines) are padded with trailing spaces under
`inhibit-read-only' so the overlays have something to attach to.
FIXME: find a way to display columns without inserting characters."
  (let ((columns (length org-columns-current-fmt-compiled))
	(chars (- (line-end-position) (line-beginning-position))))
    (when (> columns chars)
      (save-excursion
	(end-of-line)
	(let ((inhibit-read-only t))
	  (insert (make-string (- columns chars) ?\s)))))))

(defun org-columns--line-face (dateline)
  "Return the column overlay face for the current line.
DATELINE non-nil selects the agenda dateline variant."
  (let* ((level-face (and (looking-at "\\(\\**\\)\\(\\* \\)")
			  (org-get-level-face 2)))
	 (ref-face (or level-face
		       (and (eq major-mode 'org-agenda-mode)
			    (org-get-at-bol 'face))
		       'default)))
    (cons (list :foreground (if (facep ref-face)
				(face-attribute ref-face :foreground)
			      (foreground-color-at-point))
		:family (face-attribute 'default :family))
	  (list (if dateline 'org-agenda-column-dateline 'org-column)
		ref-face))))

(defun org-columns--mark-line-read-only ()
  "Mark the column view rendered line as read-only.
The property covers from the previous line-end through the next
line-beginning, keeping the rendered overlay region uneditable."
  (with-silent-modifications
    (let ((inhibit-read-only t))
      (put-text-property
       (line-end-position 0)
       (line-beginning-position 2)
       'read-only
       (or org-columns--read-only-string
	   (setq org-columns--read-only-string
		 (substitute-command-keys
		  "Type \\<org-columns-map>`\\[org-columns-edit-value]' \
to edit property" t)))))))

(defun org-columns--make-row (columns face)
  "Create and install the overlay for each column on the next character."
  (let ((i 0)
	(last (1- (length columns))))
    (dolist (column columns)
      (pcase column
	(`(,spec ,value ,displayed-value)
	 (let* ((property (org-columns--spec-property spec))
		(width (aref org-columns-current-maxwidths i))
		(cell-format-string
		 (org-columns--cell-format-string width (= i last))))
	   (org-columns--make-cell-overlay
	    displayed-value cell-format-string width property value face))))
      (forward-char)
      (cl-incf i))))

(defun org-columns--make-cell-overlay
    (displayed-value cell-format-string width property value face)
  "Place an overlay rendering one column on the next character at point.
The overlay covers a single character starting at point and shows
DISPLAYED-VALUE formatted with CELL-FORMAT-STRING to WIDTH, associated
with column PROPERTY whose raw value is VALUE.  FACE is applied to the
overlay.  Point advances by one character so the next column may be
installed."
  (let ((ov (org-columns--new-overlay
	     (point) (1+ (point))
	     (org-columns--overlay-text
	      displayed-value cell-format-string width property value)
	     face)))
    (overlay-put ov 'keymap org-columns-map)
    (overlay-put ov 'org-columns-key property)
    (overlay-put ov 'org-columns-value value)
    (overlay-put ov 'org-columns-value-modified displayed-value)
    (overlay-put ov 'org-columns-format cell-format-string)
    (overlay-put ov 'line-prefix "")
    (overlay-put ov 'wrap-prefix "")))

(defun org-columns--hide-rest-of-line ()
  "Make the rest of the line disappear using overlays."
  (let ((ov (org-columns--new-overlay (point) (line-end-position))))
    (overlay-put ov 'invisible t)
    (overlay-put ov 'keymap org-columns-map)
    (overlay-put ov 'line-prefix "")
    (overlay-put ov 'wrap-prefix ""))
  (let ((ov (make-overlay (1- (line-end-position))
			  (line-beginning-position 2))))
    (overlay-put ov 'keymap org-columns-map)
    (push ov org-columns-overlays)))

(defun org-columns--display-line (columns &optional dateline)
  "Overlay the current line with column display.
COLUMNS is a list of triplets (SPEC VALUE DISPLAYED-VALUE).  Optional
argument DATELINE is non-nil when the face used should be
`org-agenda-column-dateline'."
  (org-columns--remap-header-line)
  (save-excursion
    (forward-line 0)
    (let ((face (org-columns--line-face dateline)))
      (org-columns--pad-line-for-overlays)
      (org-columns--make-row columns face)
      (org-columns--hide-rest-of-line)
      (org-columns--mark-line-read-only))))

;;;; Display string formatting

(defun org-columns--truncate-below-width (string width)
  "Return a substring of STRING no wider than WIDTH.
This substring must start at 0, and must be the longest possible
substring whose `string-width' does not exceed WIDTH."
  (declare (side-effect-free t))
  (let ((end (min width (length string))) res)
    (while (and end (>= end 0))
      (let* ((curr (string-width (substring string 0 end)))
             (excess (- curr width)))
        (if (> excess 0)
            (cl-decf end (max 1 (/ excess 2)))
          (setq res (substring string 0 end) end nil))))
    res))

(defun org-columns-add-ellipses (string width)
  "Truncate STRING with WIDTH characters, with ellipses."
  (cond
   ((<= (string-width string) width) string)
   ((<= width (string-width org-columns-ellipses))
    (org-columns--truncate-below-width org-columns-ellipses width))
   (t (concat
       (org-columns--truncate-below-width
        string (- width (string-width org-columns-ellipses)))
       org-columns-ellipses))))

;;;; View environment

(defvar org-columns-inhibit-recalculation nil
  "Inhibit recomputing of columns when building column view.
When non-nil, neither column summaries nor clock summaries are
recomputed.")
(defvar org-columns-flyspell-was-active nil
  "Remember the state of `flyspell-mode' before column view.
Flyspell mode can cause problems in column view, so it is turned off
for the duration of the command.")
(defvar org-columns-org-num-was-active nil
  "Remember the state of `org-num-mode' before column view.
Org-num mode can cause problems in column view, so it is turned off
for the duration of the command.")
(defvar org-colview-initial-truncate-line-value nil
  "Remember the value of `truncate-lines' across colview.")

(defun org-columns--suspend-conflicting-modes ()
  "Suspend minor modes that conflict with column view."
  (when (setq-local org-columns-flyspell-was-active
                    (bound-and-true-p flyspell-mode))
    (flyspell-mode 0))
  (when (setq-local org-columns-org-num-was-active
                    (bound-and-true-p org-num-mode))
    (org-num-mode 0)))

(defun org-columns--resume-conflicting-modes ()
  "Resume minor modes that were suspended by column view."
  (when org-columns-flyspell-was-active
    (flyspell-mode 1))
  (when org-columns-org-num-was-active
    (org-num-mode 1)))

(defun org-columns--suspend-line-wrapping ()
  "Suspend line wrapping for column view by forcing `truncate-lines'.
Saved value is restored by `org-columns--resume-line-wrapping'."
  (unless (local-variable-p 'org-colview-initial-truncate-line-value)
    (setq-local org-colview-initial-truncate-line-value truncate-lines))
  (unless global-visual-line-mode
    (setq truncate-lines t)))

(defun org-columns--resume-line-wrapping ()
  "Resume line wrapping suspended by `org-columns--suspend-line-wrapping'."
  (when (local-variable-p 'org-colview-initial-truncate-line-value)
    (setq truncate-lines org-colview-initial-truncate-line-value)))

(defun org-columns--suspend-display-environment ()
  "Suspend display state that conflicts with column view."
  (org-columns--suspend-conflicting-modes)
  (org-columns--suspend-line-wrapping))

(defun org-columns--resume-display-environment ()
  "Resume display state suspended by column view."
  (org-columns--resume-conflicting-modes)
  (org-columns--resume-line-wrapping))

;;;; Header line

(defvar org-columns-full-header-line-format nil
  "The full header line format, will be shifted by horizontal scrolling." )
(defvar org-previous-header-line-format nil
  "The header line format before column view was turned on.")
(defvar header-line-format)
(defvar-local org-columns-header-line-remap nil
  "Store the relative remapping of column header-line.
This is needed to later remove this relative remapping.")
(defvar org-columns-previous-hscroll 0)

(defun org-columns--remap-header-line ()
  "Remap the header line to default face if not already done."
  (unless org-columns-header-line-remap
    (setq org-columns-header-line-remap
	  (face-remap-add-relative 'header-line '(:inherit default)))))

(defun org-columns--display-header-line ()
  "Prepare the table heading with column titles for the window's header line."
  (let ((header "")
	(linum-offset (org-line-number-display-width 'columns))
	(i 0)
	(last (1- (length org-columns-current-fmt-compiled))))
    (dolist (column org-columns-current-fmt-compiled)
      (pcase column
	(`(,property ,title . ,_)
	 (let* ((width (aref org-columns-current-maxwidths i))
		(cell-format-string (org-columns--cell-format-string width (= i last))))
	   (setq header
		 (concat header (format cell-format-string (or title property)))))))
      (cl-incf i))
    (setq-local org-previous-header-line-format header-line-format)
    (setq org-columns-full-header-line-format
	  (concat
	   (org-add-props " " nil 'display `(space :align-to ,linum-offset))
	   (org-add-props header nil 'face 'org-column-title)))
    (setq org-columns-previous-hscroll -1)
    (add-hook 'post-command-hook #'org-columns-hscroll-title nil 'local)))

(defun org-columns-hscroll-title ()
  "Set the `header-line-format' so that it scrolls along with the table."
  (sit-for .0001) ; need to force a redisplay to update window-hscroll
  (let ((hscroll (window-hscroll)))
    (when (/= org-columns-previous-hscroll hscroll)
      (setq header-line-format
	    (concat (substring org-columns-full-header-line-format 0 1)
		    (substring org-columns-full-header-line-format
			       (min (length org-columns-full-header-line-format)
				    (1+ hscroll))))
	    org-columns-previous-hscroll hscroll)
      (force-mode-line-update))))

;;;; Removing overlays / quitting

;;;###autoload
(defun org-columns-remove-overlays ()
  "Remove all currently active column overlays."
  (interactive nil org-mode org-agenda-mode)
  (when org-columns-header-line-remap
    (face-remap-remove-relative org-columns-header-line-remap)
    (setq org-columns-header-line-remap nil))
  (when (markerp org-columns-begin-marker)
    (set-marker org-columns-begin-marker nil))
  (when (markerp org-columns-top-level-marker)
    (set-marker org-columns-top-level-marker nil))
  (when org-columns-overlays
    (when (local-variable-p 'org-previous-header-line-format)
      (setq header-line-format org-previous-header-line-format)
      (kill-local-variable 'org-previous-header-line-format)
      (remove-hook 'post-command-hook #'org-columns-hscroll-title 'local))
    (with-silent-modifications
      (mapc #'delete-overlay org-columns-overlays)
      (setq org-columns-overlays nil)
      (let ((inhibit-read-only t))
	(remove-text-properties (point-min) (point-max) '(read-only t))))
    (org-columns--resume-display-environment)))

(defun org-columns-quit ()
  "Remove the column overlays and in this way exit column editing."
  (interactive nil org-mode org-agenda-mode)
  (org-columns-remove-overlays)
  (if (not (eq major-mode 'org-agenda-mode))
      (setq org-columns-current-fmt nil)
    (setq org-agenda-columns-active nil)
    (message
     "Modification not yet reflected in Agenda buffer, use `r' to refresh")))

;;;; Cell actions

(defun org-columns-show-value ()
  "Show the full value of the property."
  (interactive nil org-mode org-agenda-mode)
  (let ((value (get-char-property (point) 'org-columns-value)))
    (message "Value is: %s" (or value ""))))

(defun org-columns-todo (&optional _arg)
  "Change the TODO state during column view."
  (interactive "P" org-mode org-agenda-mode)
  (org-columns-edit-value "TODO"))

(defun org-columns-toggle-or-columns-quit ()
  "Toggle checkbox at point, or quit column view."
  (interactive nil org-mode org-agenda-mode)
  (or (org-columns--toggle)
      (org-columns-quit)))

(defun org-columns--toggle ()
  "Toggle checkbox at point.  Return non-nil if toggle happened, else nil.
See info documentation about realizing a suitable checkbox."
  (when (string-match "\\`\\[[ xX-]\\]\\'"
		      (get-char-property (point) 'org-columns-value))
    (org-columns-next-allowed-value)
    t))

(defun org-columns-open-link (&optional arg)
  (interactive "P" org-mode org-agenda-mode)
  (let ((value (get-char-property (point) 'org-columns-value)))
    (org-link-open-from-string value arg)))

;;;; Cell editing and value selection

(defun org-columns-check-computed ()
  "Throw an error if current column value is computed."
  (let ((spec (org-columns--spec-at-point)))
    (and
     (org-columns--spec-operator spec)
     (assoc spec (get-text-property (line-beginning-position) 'org-summaries))
     (error "This value is computed from the entry's children"))))

(defun org-columns--update-agenda-single-file (pom)
  "Update `org-agenda-columns' for the file containing POM.
Preserves the current format and updates only the single file."
  (let* ((org-overriding-columns-format org-columns-current-fmt)
	 (buffer (marker-buffer pom))
	 (org-agenda-contributing-files
	  (list (with-current-buffer buffer
		  (buffer-file-name (buffer-base-buffer))))))
    (org-agenda-columns)))

(defun org-columns--execute-and-update (action pom key col)
  "Execute ACTION and update column view.
POM is the point or marker for the heading.
KEY is the column key.
COL is the column to move to after update."
  (cond
   ((eq major-mode 'org-agenda-mode)
    (org-columns--call action)
    (org-columns--update-agenda-single-file pom))
   (t
    (let ((inhibit-read-only t))
      (with-silent-modifications
	(remove-text-properties (line-end-position 0) (line-end-position)
				'(read-only t)))
      (org-columns--call action))
    ;; Some properties can modify headline (e.g., "TODO"), and
    ;; possible shuffle overlays.  Make sure they are still all at
    ;; the right place on the current line.
    (when (member key '("ITEM" "TODO" "PRIORITY" "TAGS"))
      (let ((org-columns-inhibit-recalculation)) (org-columns-redo)))
    (org-columns-update key)
    (org-move-to-column col))))

(defun org-columns-edit-value (&optional key)
  "Edit the value of the property at point in column view.
Where possible, use the standard interface for changing this line."
  (interactive nil org-mode org-agenda-mode)
  (org-columns-check-computed)
  (let* ((col (current-column))
	 (bol (line-beginning-position))
	 (pom (or (get-text-property bol 'org-hd-marker) (point)))
	 (key (or key (get-char-property (point) 'org-columns-key)))
	 (org-columns--time (float-time))
	 (action
	  (cl-flet ((command-action (command)
		      (lambda ()
			(org-with-point-at pom
			  (call-interactively command)))))
	    (pcase key
	      ("BEAMER_ENV" (command-action #'org-beamer-select-environment))
	      ("CLOCKSUM" (user-error "This special column cannot be edited"))
	      ("DEADLINE" (command-action #'org-deadline))
	      ("ITEM" (command-action #'org-edit-headline))
	      ("PRIORITY" (command-action #'org-priority))
	      ("SCHEDULED" (command-action #'org-schedule))
	      ("TAGS"
	       (lambda ()
		 (org-with-point-at pom
		   (let ((org-fast-tag-selection-single-key
			  (if (eq org-fast-tag-selection-single-key 'expert)
			      t
			    org-fast-tag-selection-single-key)))
		     (call-interactively #'org-set-tags-command)))))
	      ("TODO" (command-action #'org-todo))
	      (_
	       (let* ((allowed (org-property-get-allowed-values pom key 'table))
		      (value (get-char-property (point) 'org-columns-value))
		      (nval (org-trim
			     (if (null allowed) (read-string "Edit: " value)
			       (completing-read
				"Value: " allowed nil
				(not (get-text-property
				      0 'org-unrestricted (caar allowed))))))))
		 (and (not (equal nval value))
		      (lambda () (org-entry-put pom key nval)))))))))
    (when action
      (org-columns--execute-and-update action pom key col))))

(defun org-columns-edit-allowed ()
  "Edit the list of allowed values for the current property."
  (interactive nil org-mode org-agenda-mode)
  (let* ((pom (or (org-get-at-bol 'org-marker)
		  (org-get-at-bol 'org-hd-marker)
		  (point)))
	 (key (concat (or (get-char-property (point) 'org-columns-key)
			  (user-error "No column to edit at point"))
		      "_ALL"))
	 (allowed (org-entry-get pom key t))
	 (new-value (read-string "Allowed: " allowed)))
    ;; FIXME: Cover editing TODO, TAGS etc in-buffer settings.????
    ;; FIXME: Write back to #+PROPERTY setting if that is needed.
    (org-entry-put
     (cond ((marker-position org-entry-property-inherited-from)
	    org-entry-property-inherited-from)
	   ((marker-position org-columns-top-level-marker)
	    org-columns-top-level-marker)
	   (t pom))
     key new-value)))

(defun org-columns--call (fun)
  "Call function FUN while preserving heading visibility.
FUN is a function called with no argument."
  (let ((hide-body (and (/= (line-end-position) (point-max))
			(save-excursion
			  (move-beginning-of-line 2)
			  (org-at-heading-p)))))
    (unwind-protect (funcall fun)
      (when hide-body (org-fold-hide-entry)))))

(defun org-columns-previous-allowed-value ()
  "Switch to the previous allowed value for this column."
  (interactive nil org-mode org-agenda-mode)
  (org-columns-next-allowed-value t))

(defun org-columns-next-allowed-value (&optional previous nth)
  "Switch to the next allowed value for this column.
When PREVIOUS is set, go to the previous value.  When NTH is
an integer, select that value."
  (interactive nil org-mode org-agenda-mode)
  (org-columns-check-computed)
  (let* ((visible-column (current-column))
	 (key (get-char-property (point) 'org-columns-key))
	 (value (get-char-property (point) 'org-columns-value))
	 (pom (or (get-text-property (line-beginning-position) 'org-hd-marker)
		  (point)))
	 (allowed
	  (let ((all
		 (or (org-property-get-allowed-values pom key)
		     (and (member (org-columns--spec-operator
				   (org-columns--spec-at-point))
				  '("X" "X/" "X%"))
			  org-columns-checkbox-allowed-values)
		     (org-colview-construct-allowed-dates value))))
	    (if previous (reverse all) all))))
    (when (equal key "ITEM") (error "Cannot edit item headline from here"))
    (unless (or allowed (member key '("SCHEDULED" "DEADLINE" "CLOCKSUM")))
      (error "Allowed values for this property have not been defined"))
    (let* ((l (length allowed))
	   (new
	    (cond
	     ((member key '("SCHEDULED" "DEADLINE" "CLOCKSUM"))
	      (if previous 'earlier 'later))
	     ((integerp nth)
	      (when (> (abs nth) l)
		(user-error "Only %d allowed values for property `%s'" l key))
	      (nth (mod (1- nth) l) allowed))
	     ((member value allowed)
	      (when (= l 1) (error "Only one allowed value for this property"))
	      (or (nth 1 (member value allowed)) (car allowed)))
	     (t (car allowed))))
	   (action (lambda () (org-entry-put pom key new))))
      (org-columns--execute-and-update action pom key visible-column))))

(defun org-colview-construct-allowed-dates (s)
  "Construct a list of three dates around the date in S.
This respects the format of the timestamp in S, active or non-active,
and also including time or not.  S must be just a timestamp, no text
around it."
  (when (and s (string-match (concat "^" org-ts-regexp3 "$") s))
    (let* ((time (org-parse-time-string s 'nodefaults))
	   (active (equal (string-to-char s) ?<))
	   (fmt (org-time-stamp-format (decoded-time-minute time) (not active)))
	   time-before time-after)
      (setf (decoded-time-second time) (or (decoded-time-second time) 0))
      (setf (decoded-time-minute time) (or (decoded-time-minute time) 0))
      (setf (decoded-time-hour time) (or (decoded-time-hour time) 0))
      (setq time-before (copy-sequence time))
      (setq time-after (copy-sequence time))
      (setf (decoded-time-day time-before) (1- (decoded-time-day time)))
      (setf (decoded-time-day time-after) (1+ (decoded-time-day time)))
      (mapcar (lambda (x) (format-time-string fmt (org-encode-time x)))
	      (list time-before time time-after)))))

;;;; Format selection and startup

(defvar org-overriding-columns-format nil
  "When set, overrides any other format definition for the agenda.
Don't set this, this is meant for dynamic scoping.  Set
`org-columns-default-format' and `org-columns-default-format-for-agenda'
instead.  You should use this variable only in the local settings
section for a custom agenda view.")

(defvar-local org-local-columns-format nil
  "When set, overrides any other format definition for the agenda.
This can be set as a buffer local value to avoid interfering with
dynamic scoping for `org-overriding-columns-format'.")

;;;###autoload
(defun org-columns-get-format-and-top-level ()
  (prog1 (org-columns-get-format)
    (org-columns-goto-top-level)))

(defun org-columns--get-columns-keyword ()
  "Return the first COLUMNS keyword value in the current buffer."
  (cdr (assoc "COLUMNS" (org-collect-keywords '("COLUMNS") '("COLUMNS")))))

(defun org-columns-get-format (&optional columns-format)
  "Return column format specifications.
When optional argument COLUMNS-FORMAT is non-nil, use it as the
current specifications.  This function also sets
`org-columns-current-fmt-compiled' and
`org-columns-current-fmt'.

Empty or whitespace-only COLUMNS values are ignored and fall
back to the next source, ultimately to
`org-columns-default-format'."
  (interactive nil org-mode)
  (let ((selected-columns-format
	 (or (org-string-nw-p columns-format)
	     (org-string-nw-p (org-entry-get nil "COLUMNS" t))
	     (org-string-nw-p (org-columns--get-columns-keyword))
	     org-columns-default-format)))
    (setq org-columns-current-fmt selected-columns-format)
    (org-columns-compile-format selected-columns-format)
    selected-columns-format))

(defun org-columns-goto-top-level ()
  "Move to the beginning of the column view area.
Also sets `org-columns-top-level-marker' to the new position."
  (goto-char
   (setq org-columns-top-level-marker
	 (org-move-marker
	  org-columns-top-level-marker
	  (cond ((org-before-first-heading-p) (point-min))
		((org-entry-get nil "COLUMNS" t) org-entry-property-inherited-from)
		(t (org-back-to-heading) (point)))))))

(defun org-columns--display-rows (rows)
  "Display the header line and ROWS as column view overlays.
ROWS must be a non-empty list of collected column rows."
  (org-columns--set-widths rows)
  (org-columns--display-header-line)
  (org-columns--suspend-display-environment)
  (dolist (row rows)
    (goto-char (car row))
    (org-columns--display-line (cdr row))))

(defun org-columns--prepare-rows (global columns-format)
  "Set up column view and return rows for the current scope.
When GLOBAL is non-nil, use the whole buffer as the scope.  Otherwise,
use the subtree selected by `org-columns-goto-top-level'.  When
COLUMNS-FORMAT is non-nil, use it instead of the format selected from
the buffer."
  (when global (goto-char (point-min)))
  (setq org-columns-begin-marker
	(org-move-marker org-columns-begin-marker))
  (org-columns-goto-top-level)
  (org-columns-get-format columns-format)
  (unless org-columns-inhibit-recalculation (org-columns-compute-all))
  (save-restriction
    (when (and (not global) (org-at-heading-p))
      (narrow-to-region (point) (org-end-of-subtree t t)))
    (unless org-columns-inhibit-recalculation
      (org-columns--compute-clock-summaries))
    (org-columns--collect-rows)))

;;;###autoload
(defun org-columns (&optional global columns-format)
  "Turn on column view on an Org mode file.

Column view applies to the whole buffer if point is before the first
headline.  Otherwise, it applies to the first ancestor setting
\"COLUMNS\" property.  If there is none, it defaults to the current
headline.  With a `\\[universal-argument]' prefix argument, GLOBAL,
turn on column view for the whole buffer unconditionally.

When COLUMNS-FORMAT is non-nil, use it as the column format."
  (interactive "P" org-mode)
  (org-columns-remove-overlays)
  (setq-local org-columns-global global)
  (save-excursion
    (when-let* ((rows (org-columns--prepare-rows global columns-format)))
      (org-columns--display-rows rows))))

;;;; Column definition editing

(defun org-columns--summary-types-completion-function (string pred flag)
  "Complete column summary type operators.
STRING, PRED, and FLAG are the usual arguments for completion
table functions."
  (let* ((summary-types (append org-columns-summary-types
				org-columns-summary-types-default))
	 (candidates (delete-dups
		      (cons '("" "") (mapcar #'car summary-types))))
	 (annotation-function
	  (lambda (string)
	    (let* ((doc (ignore-errors
			  (documentation (cdr (assoc string summary-types)))))
		   (doc (and doc (substring doc 0 (string-search "\n" doc)))))
	      (if doc (format " -- %s" doc) ""))))
	 (completion-table
	  (org-completion-table-with-metadata
	   (lambda (str predicate action)
	     (complete-with-action action candidates str predicate))
	   `(metadata . ((annotation-function . ,annotation-function))))))
    (complete-with-action flag completion-table string pred)))

(defun org-columns-new (&optional spec &rest attributes)
  "Insert a new column, to the left of the current column.
Interactively fill attributes for new column.  When column format
specification SPEC is provided, edit it instead.

When optional argument ATTRIBUTES is provided, it should be a list of
column specification attributes to create the new column
non-interactively.  See `org-columns-compile-format' for details."
  (interactive nil org-mode org-agenda-mode)
  (let ((new (or attributes
		 (let ((prop
			(completing-read
			 "Property: "
			 (mapcar #'list (org-buffer-property-keys t nil t))
			 nil nil (org-columns--spec-property spec))))
		   (list prop
                         ;; Discard useless whitespace-only titles.
			 (org-string-nw-p
                          (read-string (format "Column title [%s]: " prop)
				       (org-columns--spec-title spec)))
			 ;; Use `read-string' instead of `read-number'
			 ;; to allow empty width.
			 (let ((w (read-string
				   "Column width: "
				   (and (org-columns--spec-width spec)
					(number-to-string
					 (org-columns--spec-width spec))))))
			   (and (org-string-nw-p w) (string-to-number w)))
			 (org-string-nw-p
                          (completing-read
                           "Summary: "
                           'org-columns--summary-types-completion-function
                           nil t (org-columns--spec-operator spec)))
			 (org-string-nw-p
			  (read-string "Format: "
				       (org-columns--spec-format-string spec))))))))
    (if spec
	(pcase-let ((`(,property ,title ,width ,operator ,format-string) new))
	  (setf (org-columns--spec-property spec) property
		(org-columns--spec-title spec) title
		(org-columns--spec-width spec) width
		(org-columns--spec-operator spec) operator
		(org-columns--spec-format-string spec) format-string))
      (push new (nthcdr (org-current-text-column) org-columns-current-fmt-compiled)))
    (org-columns-store-format)
    (org-columns-redo)))

(defun org-columns-delete ()
  "Delete the column at point from column view."
  (interactive nil org-mode org-agenda-mode)
  (let ((spec (org-columns--spec-at-point)))
    (when (y-or-n-p (format "Are you sure you want to remove column %S? "
			    (org-columns--spec-title spec)))
      (setq org-columns-current-fmt-compiled
	    (delq spec org-columns-current-fmt-compiled))
      (org-columns-store-format)
      ;; This may leave a now wrong value in a node property.  However
      ;; updating it may prove counter-intuitive.  See comments in
      ;; `org-columns-move-right' for details.
      (let ((org-columns-inhibit-recalculation t)) (org-columns-redo))
      (when (>= (org-current-text-column) (length org-columns-current-fmt-compiled))
	(backward-char)))))

(defun org-columns-edit-attributes ()
  "Edit the attributes of the current column."
  (interactive nil org-mode org-agenda-mode)
  (org-columns-new (org-columns--spec-at-point)))

(defun org-columns-widen (arg)
  "Make the column wider by ARG characters."
  (interactive "p" org-mode org-agenda-mode)
  (let* ((n (org-current-text-column))
	 (spec (org-columns--spec-at-point))
	 (width (aref org-columns-current-maxwidths n)))
    (setq width (max 1 (+ width arg)))
    (setf (org-columns--spec-width spec) width)
    (org-columns-store-format)
    (let ((org-columns-inhibit-recalculation t)) (org-columns-redo))))

(defun org-columns-narrow (arg)
  "Make the column narrower by ARG characters."
  (interactive "p" org-mode org-agenda-mode)
  (org-columns-widen (- arg)))

;;;; Navigation and reordering

(defun org-columns--move-cursor (up)
  "Move cursor up or down one row.
When UP is non-nil, move up; otherwise, move down."
  (let ((col (current-column)))
    (forward-line (if up -1 1))
    (while (and (org-invisible-p2) (not (if up (bobp) (eobp))))
      (forward-line (if up -1 1)))
    (move-to-column col)
    (when (derived-mode-p 'org-agenda-mode)
      (org-agenda-do-context-action))))

(defun org-columns-move-up ()
  "Move cursor up one row.
When in agenda column view, also call `org-agenda-do-context-action'."
  (interactive nil org-mode org-agenda-mode)
  (org-columns--move-cursor t))

(defun org-columns-move-down ()
  "Move cursor down one row.
When in agenda column view, also call `org-agenda-do-context-action'."
  (interactive nil org-mode org-agenda-mode)
  (org-columns--move-cursor nil))

(defun org-columns-move-right ()
  "Swap this column with the one to the right."
  (interactive nil org-mode org-agenda-mode)
  (let* ((n (org-current-text-column))
	 (cell (nthcdr n org-columns-current-fmt-compiled))
	 e)
    (when (>= n (1- (length org-columns-current-fmt-compiled)))
      (error "Cannot shift this column further to the right"))
    (setq e (car cell))
    (setcar cell (car (cdr cell)))
    (setcdr cell (cons e (cdr (cdr cell))))
    (org-columns-store-format)
    ;; Do not compute again properties, since we're just moving
    ;; columns around.  It can put a property value a bit off when
    ;; switching between an non-computed and a computed value for the
    ;; same property, e.g. from "%A %A{+}" to "%A{+} %A".
    ;;
    ;; In this case, the value needs to be updated since the first
    ;; column related to a property determines how its value is
    ;; computed.  However, (correctly) updating the value could be
    ;; surprising, so we leave it as-is nonetheless.
    (let ((org-columns-inhibit-recalculation t)) (org-columns-redo))
    (forward-char 1)))

(defun org-columns-move-left ()
  "Swap this column with the one to the left."
  (interactive nil org-mode org-agenda-mode)
  (let* ((n (org-current-text-column)))
    (when (= n 0)
      (error "Cannot shift this column further to the left"))
    (backward-char 1)
    (org-columns-move-right)
    (backward-char 1)))

(defun org-columns--move-row (&optional up)
  "Move the current table row down.
With non-nil optional argument UP, move it up."
  (let ((inhibit-read-only t)
        (col (current-column)))
    (if up (org-move-subtree-up)
      (org-move-subtree-down))
    (let ((org-columns-inhibit-recalculation t))
      (org-columns-redo)
      (move-to-column col))))

(defun org-columns-move-row-down ()
  "Move the current table row down."
  (interactive nil org-mode)
  (org-columns--move-row))

(defun org-columns-move-row-up ()
  "Move the current table row up."
  (interactive nil org-mode)
  (org-columns--move-row 'up))

;;;; Display update

(defun org-columns-update (property)
  "Recompute PROPERTY, and update its display in column view."
  (org-columns-compute property)
  (org-with-wide-buffer
   (let ((upcase-property (upcase property)))
     (dolist (ov org-columns-overlays)
       (let ((key (overlay-get ov 'org-columns-key)))
	 (when (and key (equal key upcase-property) (overlay-start ov))
	   (goto-char (overlay-start ov))
	   (let* ((column (org-current-text-column))
		  (spec (org-columns--spec-at-point))
		  (value
		   (or (cdr (assoc spec
				   (get-text-property (line-beginning-position)
						      'org-summaries)))
		       (org-entry-get (point) key))))
	     (when value
	       (let ((displayed-value (org-columns--displayed-value spec value))
		     (cell-format-string (overlay-get ov 'org-columns-format))
		     (width
		      (aref org-columns-current-maxwidths column)))
		 (overlay-put ov 'org-columns-value value)
		 (overlay-put ov 'org-columns-value-modified displayed-value)
		 (overlay-put ov 'display
                              (org-columns--overlay-text
			       displayed-value cell-format-string width property value)))))))))))

(defun org-columns-redo ()
  "Construct the column display again."
  (interactive nil org-mode org-agenda-mode)
  (when org-columns-overlays
    (message "Recomputing columns...")
    (org-with-point-at org-columns-begin-marker
      (org-columns-remove-overlays)
      (if (derived-mode-p 'org-mode)
	  ;; Since we already know the column format, provide it
	  ;; instead of computing again.
	  (org-columns org-columns-global org-columns-current-fmt)
	(org-agenda-redo)
	(org-agenda-columns)))
    (message "Recomputing columns...done")))

;;;; Format storage

(defun org-columns--replace-columns-keyword (columns-format)
  "Replace the first COLUMNS keyword value with COLUMNS-FORMAT.
Return non-nil when a COLUMNS keyword was replaced."
  (let ((case-fold-search t))
    (catch :found
      (while (re-search-forward "^[ \t]*#\\+COLUMNS:\\(.*\\)" nil t)
        (let ((element (save-match-data (org-element-at-point))))
          (when (and (org-element-type-p element 'keyword)
                     (equal (org-element-property :key element) "COLUMNS"))
            (replace-match (concat " " columns-format) t t nil 1)
            (throw :found t))))
      nil)))

(defun org-columns--insert-columns-keyword (columns-format)
  "Insert COLUMNS-FORMAT as a COLUMNS keyword before the first heading."
  (goto-char (point-min))
  ;; FIXME: This preserves the historical behavior of inserting the
  ;; keyword before the first heading.  A better policy may be to insert
  ;; it after the initial block of file-level keywords.
  (unless (org-at-heading-p) (outline-next-heading))
  (let ((inhibit-read-only t))
    (insert-before-markers "#+COLUMNS: " columns-format "\n")))

(defun org-columns-store-format ()
  "Store the text version of the current column format.
The format is stored either in the COLUMNS property of the entry
starting the current column display, or in a #+COLUMNS line of
the current buffer."
  (let ((columns-format
	 (org-columns-uncompile-format org-columns-current-fmt-compiled)))
    (setq-local org-columns-current-fmt columns-format)
    (when org-columns-overlays
      (org-with-point-at org-columns-top-level-marker
	(if (and (org-at-heading-p) (org-entry-get nil "COLUMNS"))
	    (org-entry-put nil "COLUMNS" columns-format)
	  (goto-char (point-min))
	  (unless (org-columns--replace-columns-keyword columns-format)
	    (org-columns--insert-columns-keyword columns-format))
	  (setq-local org-columns-default-format columns-format))))))

;;;; Format compilation

(defun org-columns-uncompile-format (compiled)
  "Turn the compiled column format back into a string representation.

COMPILED is an alist, as returned by `org-columns-compile-format'."
  (mapconcat
   (lambda (spec)
     (pcase spec
       (`(,prop ,title ,width ,operator ,format-string)
	(concat "%"
		(and width (number-to-string width))
		prop
		(and title (not (equal prop title)) (format "(%s)" title))
		(cond ((not operator) nil)
		      ((equal operator "$") (format "{%s}" operator))
		      (format-string (format "{%s;%s}" operator format-string))
		      (t (format "{%s}" operator)))))))
   compiled " "))

(defun org-columns-compile-format (columns-format)
  "Compile COLUMNS-FORMAT into a list of specifications.

The result is a list with one entry per column.  Each entry has the
form (PROPERTY TITLE WIDTH OPERATOR FORMAT-STRING), where:

  PROPERTY       Property name, as an upper-case string.
  TITLE          Column title, as a string.
  WIDTH          Column width, as an integer, or nil for automatic width.
  OPERATOR       Summary operator, as a string, or nil.
  FORMAT-STRING  Format string for `format', used for computed values, or nil.

Set and return `org-columns-current-fmt-compiled'."
  (setq org-columns-current-fmt-compiled
        (cl-loop
         with start = 0
         while (string-match
                (rx "%"
                    (optional (group (+ digit)))
                    (group (one-or-more (in alnum "_-")))
                    (optional "(" (group (zero-or-more (not (any ")")))) ")")
                    (optional "{" (group (zero-or-more (not (any "}")))) "}")
                    (zero-or-more space))
                columns-format start)
         do (setq start (match-end 0))
         collect
         (let* ((width (and (match-end 1)
			    (string-to-number
			     (match-string 1 columns-format))))
                (prop (match-string-no-properties 2 columns-format))
                (title (or (org-string-nw-p
			    (match-string-no-properties 3 columns-format))
                           prop))
                (operator
		 (org-string-nw-p
		  (match-string-no-properties 4 columns-format))))
           (if operator
               (seq-let (operator format-string) (split-string operator ";")
                 (org-columns--make-spec
		  (upcase prop) title width operator
		  (if (equal operator "$") "%.2f" format-string)))
             (org-columns--make-spec (upcase prop) title width nil nil))))))


;;;; Column View Summary

;;;;; Summary helpers

(defun org-columns--age-to-minutes (s)
  "Turn age string S into a number of minutes.
An age is either computed from a given timestamp, or indicated
as a canonical duration, i.e., using units defined in
`org-duration-canonical-units'."
  (cond
   ((string-match-p org-ts-regexp s)
    (/ (- org-columns--time
	  (float-time (org-time-string-to-time s)))
       60))
   ((org-duration-p s) (org-duration-to-minutes s t)) ;skip user units
   (t (user-error "Invalid age: %S" s))))

(defun org-columns--format-age (minutes)
  "Format MINUTES float as an age string."
  (org-duration-from-minutes minutes
			     '(("d" . nil) ("h" . nil) ("min" . nil))
			     t))	;ignore user's custom units

(defun org-columns--summary-apply-times (fun times)
  "Apply FUN to time values TIMES.
Return the result as a duration."
  (org-duration-from-minutes
   (apply fun (mapcar #'org-duration-to-minutes times))
   (org-duration-h:mm-only-p times)))

(defun org-columns--summary-type (operator)
  "Return summary type definition for OPERATOR."
  (or (assoc operator org-columns-summary-types)
      (assoc operator org-columns-summary-types-default)
      (error "Unknown %S operator" operator)))

(defun org-columns--summarize-function (operator)
  "Return summary function associated with OPERATOR.
Return nil if OPERATOR is known but has no summerize function."
  (pcase (org-columns--summary-type operator)
    (`(,_ . ,(and (pred functionp) summarize-function)) summarize-function)
    (`(,_ ,summarize-function ,_) summarize-function)
    (_ (error "Invalid definition for operator %S" operator))))

(defun org-columns--collect-function (operator)
  "Return collect function associated with OPERATOR.
Return nil if OPERATOR is known but has no collect function."
  (pcase (org-columns--summary-type operator)
    (`(,_ . ,(pred functionp)) nil)
    (`(,_ ,_ ,collect-function) collect-function)
    (_ (error "Invalid definition for operator %S" operator))))

;;;;; Tree summary computation

(defun org-columns--put-summary (pos spec summary)
  "Set SUMMARY for SPEC in `org-summaries' at POS."
  (let* ((summaries (get-text-property pos 'org-summaries))
	 (old (assoc spec summaries)))
    (if old (setcdr old summary)
      (push (cons spec summary) summaries)
      (with-silent-modifications
	(add-text-properties
	 pos (1+ pos) (list 'org-summaries summaries))))))

(defun org-columns--update-summary-property (property current-value computed-value)
  "Update PROPERTY at point when it exists, even if empty.
Do not create PROPERTY when it does not already exist.  An empty
CURRENT-VALUE still counts as an existing property; replace it
with COMPUTED-VALUE when they differ.

Trim COMPUTED-VALUE before comparing and storing it, since
user-provided formats or custom summary functions may introduce
surrounding whitespace, which is not significant in property values."
  (let ((new-value (org-trim computed-value)))
    (when (and current-value (not (equal current-value new-value)))
      (org-entry-put (point) property new-value))))

(defun org-columns--summarizable-operator (spec)
  "Return SPEC operator when its property can be summarized.
Special properties cannot be collected nor summarized, because
they have their own way to be computed."
  (let ((property (org-columns--spec-property spec)))
    (and (not (member property org-special-properties))
	 (org-columns--spec-operator spec))))

(defun org-columns--clear-values-below-level (values-by-level level deepest-level)
  "Clear accumulated values below LEVEL in VALUES-BY-LEVEL.
DEEPEST-LEVEL is the deepest index to clear."
  (cl-loop for deeper-level from (1+ level) to deepest-level
	   do (aset values-by-level deeper-level nil)))

(defun org-columns--compute-spec (spec &optional update-property-p)
  "Update tree according to SPEC.
SPEC is a column format specification.  When optional argument
UPDATE-PROPERTY-P is non-nil, summarized values can replace
existing ones in properties drawers."
  (when-let* ((operator (org-columns--summarizable-operator spec)))
    (let* ((deepest-level 29)	;Hard-code deepest level.
	   (values-by-level (make-vector (1+ deepest-level) nil))
	   (current-level deepest-level)
	   previous-level
	   (property (org-columns--spec-property spec))
	   (format-string (org-columns--spec-format-string spec))
	   (collect-function (org-columns--collect-function operator))
	   (summarize-function (org-columns--summarize-function operator)))
      (org-with-wide-buffer
       ;; Find the region to compute.
       (goto-char org-columns-top-level-marker)
       (org-end-of-subtree t)
       ;; Walk the tree from the back and do the computations.
       (while (re-search-backward
	       org-outline-regexp-bol org-columns-top-level-marker t)
	 (setq previous-level current-level)
	 (setq current-level (org-reduced-level (org-outline-level)))
	 (let* ((pos (match-beginning 0))
		(current-value (if collect-function
				   (funcall collect-function property)
				 (org-entry-get (point) property)))
		(value-nonempty-p (org-string-nw-p current-value)))
	   (cond
	    ((< current-level previous-level)
	     ;; Collect values from lower levels and inline tasks here
	     ;; and summarize them using SUMMARIZE-FUNCTION.  Store them in text
	     ;; property `org-summaries', in alist whose key is SPEC.
	     (let* ((values (and summarize-function
				 (cl-loop for l from (1+ current-level) to deepest-level
					  append (aref values-by-level l))))
		    (summary (and values
				  (funcall summarize-function values format-string))))
	       (cond
		(summary
		 (org-columns--put-summary pos spec summary)
		 (when update-property-p
		   (org-columns--update-summary-property property current-value summary))
		 (push summary (aref values-by-level current-level)))
		(value-nonempty-p
		 (push current-value (aref values-by-level current-level))))
	       (org-columns--clear-values-below-level
		values-by-level current-level deepest-level)))
	    (value-nonempty-p
	     (push current-value (aref values-by-level current-level))))))))))

;;;###autoload
(defun org-columns-compute (property)
  "Summarize the values of PROPERTY hierarchically.
Also update existing values for PROPERTY according to the first
column specification."
  (let ((update-property-p t)
	(upcase-prop (upcase property)))
    (dolist (spec org-columns-current-fmt-compiled)
      (when (equal (org-columns--spec-property spec) upcase-prop)
	(org-columns--compute-spec spec update-property-p)
	;; Only the first matching spec can update the property drawer,
	;; because the drawer has a single value for each property.  For
	;; example, with column format "%A{min} %A{max}", both summaries
	;; are stored in the `org-summaries' text property, but only
	;; %A{min} updates the :A: property; %A{max} is computed for
	;; display only.
	(setq update-property-p nil)))))

(defun org-columns-compute-all ()
  "Compute all columns that have operators defined."
  (with-silent-modifications
    (remove-text-properties (point-min) (point-max) '(org-summaries t)))
  (let ((org-columns--time (float-time))
	seen)
    (dolist (spec org-columns-current-fmt-compiled)
      (let* ((property (org-columns--spec-property spec))
             (update-property-p (not (member property seen))))
	(org-columns--compute-spec spec update-property-p)
	(push property seen)))))

;;;;; Summary operators

(defconst org-columns-summary-types-default
  '(("+"     . org-columns--summary-sum)
    ("$"     . org-columns--summary-currencies)
    ("X"     . org-columns--summary-checkbox)
    ("X/"    . org-columns--summary-checkbox-count)
    ("X%"    . org-columns--summary-checkbox-percent)
    ("max"   . org-columns--summary-max)
    ("mean"  . org-columns--summary-mean)
    ("min"   . org-columns--summary-min)
    (":"     . org-columns--summary-sum-times)
    (":max"  . org-columns--summary-max-time)
    (":mean" . org-columns--summary-mean-time)
    (":min"  . org-columns--summary-min-time)
    ("@max"  . org-columns--summary-max-age)
    ("@mean" . org-columns--summary-mean-age)
    ("@min"  . org-columns--summary-min-age)
    ("est+"  . org-columns--summary-estimate))
  "Map operators to summary functions.
See `org-columns-summary-types' for details.")

(defun org-columns--summary-sum (values format-string)
  "Compute the sum of VALUES.
When FORMAT-STRING is non-nil, use it to format the result."
  (format (or format-string "%s") (apply #'+ (mapcar #'string-to-number values))))

(defun org-columns--summary-currencies (values _)
  "Compute the sum of VALUES, with two decimals."
  (format "%.2f" (apply #'+ (mapcar #'string-to-number values))))

(defun org-columns--summary-checkbox (check-boxes _)
  "Summarize CHECK-BOXES with a check-box."
  (let ((done (cl-count "[X]" check-boxes :test #'equal))
	(all (length check-boxes)))
    (cond ((= done all) "[X]")
	  ((> done 0) "[-]")
	  (t "[ ]"))))

(defun org-columns--summary-checkbox-count (check-boxes _)
  "Summarize CHECK-BOXES with a check-box cookie."
  (format "[%d/%d]"
	  (cl-count-if (lambda (b) (or (equal b "[X]")
				       (string-match-p "\\[\\([1-9]\\)/\\1\\]" b)))
		       check-boxes)
	  (length check-boxes)))

(defun org-columns--summary-checkbox-percent (check-boxes _)
  "Summarize CHECK-BOXES with a check-box percent."
  (org-format-percent-cookie (cl-count-if (lambda (b) (member b '("[X]" "[100%]")))
                                          check-boxes)
                             (length check-boxes)))

(defun org-columns--summary-min (values format-string)
  "Compute the minimum of VALUES.
When FORMAT-STRING is non-nil, use it to format the result."
  (format (or format-string "%s")
	  (apply #'min (mapcar #'string-to-number values))))

(defun org-columns--summary-max (values format-string)
  "Compute the maximum of VALUES.
When FORMAT-STRING is non-nil, use it to format the result."
  (format (or format-string "%s")
	  (apply #'max (mapcar #'string-to-number values))))

(defun org-columns--summary-mean (values format-string)
  "Compute the mean of VALUES.
When FORMAT-STRING is non-nil, use it to format the result."
  (format (or format-string "%s")
	  (/ (apply #'+ (mapcar #'string-to-number values))
	     (float (length values)))))

(defun org-columns--summary-sum-times (times _)
  "Sum TIMES."
  (org-columns--summary-apply-times #'+ times))

(defun org-columns--summary-min-time (times _)
  "Compute the minimum time among TIMES."
  (org-columns--summary-apply-times #'min times))

(defun org-columns--summary-max-time (times _)
  "Compute the maximum time among TIMES."
  (org-columns--summary-apply-times #'max times))

(defun org-columns--summary-mean-time (times _)
  "Compute the mean time among TIMES."
  (org-columns--summary-apply-times
   (lambda (&rest values) (/ (apply #'+ values) (float (length values))))
   times))

(defun org-columns--summary-min-age (ages _)
  "Compute the minimum age among AGES."
  (org-columns--format-age
   (apply #'min (mapcar #'org-columns--age-to-minutes ages))))

(defun org-columns--summary-max-age (ages _)
  "Compute the maximum age among AGES."
  (org-columns--format-age
   (apply #'max (mapcar #'org-columns--age-to-minutes ages))))

(defun org-columns--summary-mean-age (ages _)
  "Compute the mean age among AGES."
  (org-columns--format-age
   (/ (apply #'+ (mapcar #'org-columns--age-to-minutes ages))
      (float (length ages)))))

(defun org-columns--summary-estimate (estimates _)
  "Combine a list of estimates, using mean and variance.
The mean and variance of the result will be the sum of the means
and variances (respectively) of the individual estimates."
  (let ((mean 0)
        (var 0))
    (dolist (e estimates)
      (pcase (mapcar #'string-to-number (split-string e "-"))
	(`(,low ,high)
	 (let ((m (/ (+ low high) 2.0)))
	   (cl-incf mean m)
	   (cl-incf var (- (/ (+ (* low low) (* high high)) 2.0) (* m m)))))
	(`(,value) (cl-incf mean value))))
    (let ((sd (sqrt var)))
      (format "%s-%s"
	      (format "%.0f" (- mean sd))
	      (format "%.0f" (+ mean sd))))))



;;; Dynamic block for Column view

;;;; Capturing

(defun org-columns--capture-view
    (maxlevel match skip-empty exclude-tags columns-format local)
  "Get the column view of the current buffer.

MAXLEVEL sets the level limit.  SKIP-EMPTY tells whether to skip
empty rows, an empty row being one where all the column view
specifiers but ITEM are empty.  EXCLUDE-TAGS is a list of tags
that will be excluded from the resulting view.  COLUMNS-FORMAT is
a column format string, or nil.  When LOCAL is non-nil, only
capture headings in current subtree.

This function returns a list containing the title row and all other
rows.  Each row is either a list, or the symbol `hline'.  The first list
is the heading row as a list of strings with the column titles according
to COLUMNS-FORMAT.  All subsequent lists each represent a body row as a
list whose first element is an integer indicating the outline level of
the entry, and whose remaining elements are strings with the contents
for the columns according to COLUMNS-FORMAT."
  (org-columns (not local) columns-format)
  (goto-char org-columns-top-level-marker)
  (let ((columns (length org-columns-current-fmt-compiled))
	(has-item (assoc "ITEM" org-columns-current-fmt-compiled))
	table)
    (org-map-entries
     (lambda ()
       (when (get-char-property (point) 'org-columns-key)
	 (let (row)
	   (dotimes (i columns)
	     (let* ((col (+ (line-beginning-position) i))
		    (p (get-char-property col 'org-columns-key)))
	       (push (get-char-property col
					(if (string= p "ITEM")
					    'org-columns-value
					  'org-columns-value-modified))
		     row)))
	   (unless (or
		    (and skip-empty
			 (let ((r (delete-dups (remove "" row))))
			   (or (null r) (and has-item (= (length r) 1)))))
		    (and exclude-tags
			 (cl-some (lambda (tag) (member tag exclude-tags))
				  (org-get-tags))))
	     (push (cons (org-reduced-level (org-current-level)) (nreverse row))
		   table)))))
     (if match
         (concat match (and maxlevel (format "+LEVEL<=%d" maxlevel)))
       (and maxlevel (format "LEVEL<=%d" maxlevel)))
     (and local 'tree)
     'archive 'comment)
    (org-columns-quit)
    ;; Add column titles and a horizontal rule in front of the table.
    (cons (mapcar #'org-columns--spec-title org-columns-current-fmt-compiled)
	  (cons 'hline (nreverse table)))))

(defun org-columns--clean-item (item)
  "Remove sensitive contents from string ITEM.
This includes objects that may not be duplicated within
a document, e.g., a target, or those forbidden in tables, e.g.,
an inline src-block."
  (let ((data (org-element-parse-secondary-string
	       item (org-element-restriction 'headline))))
    (org-element-map data
	'(footnote-reference inline-babel-call inline-src-block target
			     radio-target statistics-cookie)
      #'org-element-extract)
    (org-quote-vert
     (org-no-properties
      (org-element-interpret-data data)))))

;;;; Writing

;;;###autoload
(defun org-dblock-write:columnview (params)
  "Write the column view table.

PARAMS is a property list of parameters:

`:id' (mandatory)

    The ID property of the entry where column view should be
    built.  When the symbol `local', call locally.  When `global'
    call column view with the cursor at the beginning of the
    buffer (usually this means that the whole buffer switches to
    column view).  When \"file:path/to/file.org\", invoke column
    view at the start of that file.  Otherwise, the ID is located
    using `org-id-find'.

`:exclude-tags'

    List of tags to exclude from column view table.

`:format'

    When non-nil, specify the column view format to use.

`:hlines'

    When non-nil, insert a hline before each item.  When
    a number, insert a hline before each level inferior or equal
    to that number.

`:indent'

    When non-nil, indent each ITEM field according to its level.

`:match'

    When set to a string, use this as a tags/property match filter.

`:maxlevel'

    When set to a number, don't capture headlines below this level.

`:skip-empty-rows'

    When non-nil, skip rows where all specifiers other than ITEM
    are empty.

`:vlines'

    When non-nil, make each column a column group to enforce
    vertical lines.

`:link'

    Link the item headlines in the table to their origins.

`:formatter'

    A function to format the data and insert it into the
    buffer.  Overrides the default formatting function set in
    `org-columns-dblock-formatter'."
  (let ((table
	 (let ((id (plist-get params :id))
	       view-file view-pos)
	   (pcase id
	     (`global nil)
	     ((or `local `nil) (setq view-pos (point)))
	     ((and (let id-string (format "%s" id))
		   (guard (string-match "^file:\\(.*\\)" id-string)))
	      (setq view-file (match-string-no-properties 1 id-string))
	      (unless (file-exists-p view-file)
		(user-error "No such file: %S" id-string)))
	     ((and (let idpos (org-find-entry-with-id id)) (guard idpos))
	      (setq view-pos idpos))
	     ((let `(,filename . ,position) (org-id-find id))
	      (setq view-file filename)
	      (setq view-pos position))
	     (_ (user-error "Cannot find entry with :ID: %s" id)))
	   (with-current-buffer (if view-file (org-get-agenda-file-buffer view-file)
				  (current-buffer))
	     (org-with-wide-buffer
	      (when view-pos (goto-char view-pos))
	      (org-columns--capture-view (plist-get params :maxlevel)
					 (plist-get params :match)
					 (plist-get params :skip-empty-rows)
					 (plist-get params :exclude-tags)
					 (plist-get params :format)
					 view-pos)))))
        (formatter (or (plist-get params :formatter)
                       org-columns-dblock-formatter
                       #'org-columns-dblock-write-default)))
    (funcall formatter (point) table params)))

(defun org-columns-dblock-write-default (ipos table params)
  "Write out a column view table at position IPOS in the current buffer.
TABLE is a table with data as produced by `org-columns--capture-view'.
PARAMS is the parameter property list obtained from the dynamic block
definition."
  (let ((link (plist-get params :link))
	(width-specs
	 (mapcar #'org-columns--spec-width
		 org-columns-current-fmt-compiled)))
    (when table
      ;; Prune level information from the table.  Also normalize
      ;; headings: remove stars, add indentation entities, if
      ;; required, and possibly precede some of them with a horizontal
      ;; rule.
      (let ((item-index
	     (let ((p (assoc "ITEM" org-columns-current-fmt-compiled)))
	       (and p (cl-position p
				   org-columns-current-fmt-compiled
				   :test #'equal))))
	    (hlines (plist-get params :hlines))
	    (indent (plist-get params :indent))
	    new-table)
	;; Copy header and first rule.
	(push (pop table) new-table)
	(push (pop table) new-table)
	(dolist (row table (setq table (nreverse new-table)))
	  (let ((level (car row)))
	    (when (and (not (eq (car new-table) 'hline))
		       (or (eq hlines t)
			   (and (numberp hlines) (<= level hlines))))
	      (push 'hline new-table))
	    (when item-index
	      (let* ((raw (nth item-index (cdr row)))
		     (cleaned (org-columns--clean-item raw))
		     (item (if (not link) cleaned
			     (let ((search (org-link-heading-search-string raw)))
			       (org-link-make-string
				(if (not (buffer-file-name)) search
				  (format "file:%s::%s" (buffer-file-name) search))
				cleaned)))))
		(setf (nth item-index (cdr row))
		      (if (and indent (> level 1))
			  (concat "\\_" (make-string (* 2 (1- level)) ?\s) item)
			item))))
	    (push (cdr row) new-table))))
      (when (plist-get params :vlines)
	(setq table
	      (let ((size (length org-columns-current-fmt-compiled)))
		(append (mapcar (lambda (x) (if (eq 'hline x) x (cons "" x)))
				table)
			(list (cons "/" (make-list size "<>")))))))
      (when (seq-find #'identity width-specs)
        ;; There are width specifiers in column format.  Pass them
        ;; to the resulting table, adding alignment field as the first
        ;; row.
        (push (mapcar (lambda (width) (when width (format "<%d>" width))) width-specs) table))
      ;; now insert the table into the buffer
      (goto-char ipos)
      (let ((content-lines (org-split-string (plist-get params :content) "\n"))
	    recalc)
	;; Insert affiliated keywords before the table.
	(when content-lines
	  (while (string-match-p "\\`[ \t]*#\\+" (car content-lines))
	    (insert (string-trim-left (pop content-lines)) "\n")))
	(save-excursion
	  ;; Insert table at point.
	  (insert
	   (mapconcat (lambda (row)
			(if (eq row 'hline) "|-|"
			  (format "|%s|" (mapconcat #'identity row "|"))))
		      table
		      "\n"))
	  ;; Insert TBLFM lines following table.
	  (let ((case-fold-search t))
	    (dolist (line content-lines)
	      (when (string-match-p "\\`[ \t]*#\\+TBLFM:" line)
		(insert "\n" (string-trim-left line))
		(unless recalc (setq recalc t))))))
	(when recalc (org-table-recalculate 'all t))
	(org-table-align)
        (when (seq-find #'identity width-specs)
          (org-table-shrink))))))

;;;; Insertion and registration

;;;###autoload
(defun org-columns-insert-dblock ()
  "Create a dynamic block capturing a column view table."
  (interactive nil org-mode)
  (let ((id (completing-read
	     "Capture columns (local, global, entry with :ID: property) [local]: "
	     (append '(("global") ("local"))
		     (mapcar #'list (org-property-values "ID"))))))
    (org-create-dblock
     (list :name "columnview"
	   :hlines 1
	   :id (cond ((string= id "global") 'global)
		     ((member id '("" "local")) 'local)
		     (id)))))
  (org-update-dblock))

;;;###autoload
(eval-after-load 'org
  '(progn
     (org-dynamic-block-define "columnview" #'org-columns-insert-dblock)))


;;; Column view in the agenda

;;;###autoload
(defun org-agenda-columns ()
  "Turn on or update column view in the agenda."
  (interactive nil org-agenda-mode)
  (org-columns-remove-overlays)
  (setq org-columns-begin-marker
	(org-move-marker org-columns-begin-marker))
  (let* ((org-columns--time (float-time))
	 (org-done-keywords org-done-keywords-for-agenda)
	 (columns-format
	  (cond
	   ((bound-and-true-p org-overriding-columns-format))
	   ((bound-and-true-p org-local-columns-format))
	   ((bound-and-true-p org-columns-default-format-for-agenda))
	   ((let ((m (org-get-at-bol 'org-hd-marker)))
	      (and m
		   (or (org-entry-get m "COLUMNS" t)
		       (with-current-buffer (marker-buffer m)
			 org-columns-default-format)))))
	   ((and (local-variable-p 'org-columns-current-fmt)
		 org-columns-current-fmt))
	   ((let ((m (next-single-property-change (point-min) 'org-hd-marker)))
	      (and m
		   (let ((m (get-text-property m 'org-hd-marker)))
		     (or (org-entry-get m "COLUMNS" t)
			 (with-current-buffer (marker-buffer m)
			   org-columns-default-format))))))
	   (t org-columns-default-format)))
	 (compiled-format (org-columns-compile-format columns-format)))
    (setq org-columns-current-fmt columns-format)
    (when org-agenda-columns-compute-summary-properties
      (org-agenda-colview-compute org-columns-current-fmt-compiled))
    (save-excursion
      ;; Collect properties for each headline in current view.
      (goto-char (point-min))
      (let (cache)
	(while (not (eobp))
	  (let ((m (org-get-at-bol 'org-hd-marker)))
	    (when m
	      (push (cons (line-beginning-position)
			  ;; `org-columns-current-fmt-compiled' is
			  ;; initialized but only set locally to the
			  ;; agenda buffer.  Since current buffer is
			  ;; changing, we need to force the original
			  ;; compiled-format there.
                          (let ((agenda-marker (point-marker)))
			    (org-with-point-at m
			      (org-columns--collect-values compiled-format agenda-marker))))
		    cache)))
	  (forward-line))
	(when cache
	  (org-columns--set-widths cache)
	  (org-columns--display-header-line)
	  (org-columns--suspend-conflicting-modes)
	  (dolist (entry cache)
	    (goto-char (car entry))
	    (org-columns--display-line (cdr entry)))
	  (setq-local org-agenda-columns-active t)
	  (when org-agenda-columns-show-summaries
	    (org-agenda-colview-summarize cache)))))))

(defun org-agenda-colview-summarize (cache)
  "Summarize the summarizable columns in column view in the agenda.
This will add overlays to the date lines, to show the summary for each day."
  (let ((summary-format (mapcar
	      (lambda (spec)
		(pcase spec
		  (`(,property ,title ,width . ,_)
		   (if (member property '("CLOCKSUM" "CLOCKSUM_T"))
		       (org-columns--make-spec property title width ":" nil)
		     spec))))
	      org-columns-current-fmt-compiled)))
    ;; Ensure there's at least one summation column.
    (when (cl-some #'org-columns--spec-operator summary-format)
      (goto-char (point-max))
      (catch :complete
	(while t
	  (when (or (get-text-property (point) 'org-date-line)
		    (eq (get-text-property (point) 'face)
			'org-agenda-structure))
	    ;; OK, this is a date line that should be used.
	    (let (entries)
	      (let (rest)
		(dolist (c cache)
		  (if (> (car c) (point))
		      (push c entries)
		    (push c rest)))
		(setq cache rest))
	      ;; ENTRIES contains entries below the current one.
	      ;; CACHE is the rest.  Compute the summaries for the
	      ;; properties we want, set nil properties for the rest.
	      (when (setq entries (mapcar #'cdr entries))
		(org-columns--display-line
		 (mapcar
		  (lambda (spec)
		    (pcase spec
		      (`("ITEM" . ,_)
		       ;; Replace ITEM with current date.  Preserve
		       ;; properties for fontification.
		       (let ((date (buffer-substring
				    (line-beginning-position)
				    (line-end-position))))
			 (list spec date date)))
		      (`(,_ ,_ ,_ nil ,_) (list spec "" ""))
		      (`(,_ ,_ ,_ ,operator ,format-string)
		       (let* ((summarize-function
			       (org-columns--summarize-function operator))
			      (values
			       ;; Use real values for summary, not
			       ;; those prepared for display.
			       (delq nil
				     (mapcar
				      (lambda (e) (org-string-nw-p
					      (nth 1 (assoc spec e))))
				      entries)))
			      (final (if values
					 (funcall summarize-function
						  values format-string)
				       "")))
			 (unless (equal final "")
			   (put-text-property 0 (length final)
					      'face 'bold final))
			 (list spec final final)))))
		  summary-format)
		 'dateline))))
	  (if (bobp) (throw :complete t) (forward-line -1)))))))

(defun org-agenda-colview-compute (compiled-format)
  "Compute the relevant columns in the contributing source buffers."
  (dolist (file org-agenda-contributing-files)
    (let ((b (find-buffer-visiting file)))
      (with-current-buffer (or (buffer-base-buffer b) b)
	(org-with-wide-buffer
	 (with-silent-modifications
	   (remove-text-properties (point-min) (point-max) '(org-summaries t)))
	 (goto-char (point-min))
	 (org-columns-get-format-and-top-level)
	 (dolist (spec compiled-format)
	   (let ((prop (org-columns--spec-property spec)))
	     (cond
	      ((equal prop "CLOCKSUM") (org-clock-sum))
	      ((equal prop "CLOCKSUM_T") (org-clock-sum-today))
	      ((and (org-columns--spec-operator spec)
		    (let ((a (assoc prop org-columns-current-fmt-compiled)))
		      (equal (org-columns--spec-operator a)
			     (org-columns--spec-operator spec))))
	       (org-columns-compute prop))))))))))


(provide 'org-colview)

;; Local variables:
;; generated-autoload-file: "org-loaddefs.el"
;; End:

;;; org-colview.el ends here
