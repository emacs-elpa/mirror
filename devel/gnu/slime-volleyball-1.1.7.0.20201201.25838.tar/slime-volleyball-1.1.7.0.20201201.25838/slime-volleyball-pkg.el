;; Generated package description from slime-volleyball.el  -*- no-byte-compile: t -*-
(define-package "slime-volleyball" "1.1.7.0.20201201.25838" "An SVG Slime Volleyball Game" '((cl-lib "0.5")) :url "https://elpa.gnu.org/packages/slime-volleyball.html" :keywords '("games") :authors '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org")) :maintainer '("Thomas Fitzsimmons" . "fitzsim@fitzsim.org"))
