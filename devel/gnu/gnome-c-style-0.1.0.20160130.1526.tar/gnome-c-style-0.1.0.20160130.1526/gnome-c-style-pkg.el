;; Generated package description from gnome-c-style.el  -*- no-byte-compile: t -*-
(define-package "gnome-c-style" "0.1.0.20160130.1526" "minor mode for editing GNOME-style C source code" 'nil :url "https://elpa.gnu.org/packages/gnome-c-style.html" :keywords '("gnome" "c" "coding style") :authors '(("Daiki Ueno" . "ueno@gnu.org")) :maintainer '("Daiki Ueno" . "ueno@gnu.org"))
