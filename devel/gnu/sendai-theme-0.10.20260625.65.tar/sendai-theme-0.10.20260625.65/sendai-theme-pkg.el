;; Generated package description from sendai-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sendai-theme" "0.10.20260625.65" "A cool blue color theme" '((emacs "27.1")) :commit "3b6d5ab74f68fcb11cc1b5d189a30d619fd40ffd" :url "https://github.com/jimporter/sendai-theme")
