;; Generated package description from ampc.el  -*- no-byte-compile: t -*-
(define-package "ampc" "0.2.0.20201130.21145" "Asynchronous Music Player Controller" 'nil :url "https://elpa.gnu.org/packages/ampc.html" :keywords '("ampc" "mpc" "mpd") :authors '(("Christopher Schmidt" . "christopher@ch.ristopher.com")) :maintainer '(nil . "emacs-devel@gnu.org"))
