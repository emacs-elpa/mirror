;; Generated package description from timerfunctions.el  -*- no-byte-compile: t -*-
(define-package "timerfunctions" "1.4.2.0.20201130.35323" "Enhanced versions of some timer.el functions" '((cl-lib "0.5") (emacs "24")) :url "https://elpa.gnu.org/packages/timerfunctions.html" :authors '(("Dave Goel" . "deego3@gmail.com")) :maintainer '("Dave Goel" . "deego3@gmail.com"))
