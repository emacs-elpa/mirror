;; Generated package description from realgud-jdb.el  -*- no-byte-compile: t -*-
(define-package "realgud-jdb" "1.0.0.0.20190525.35710" "Realgud front-end to Java's jdb debugger\"" '((realgud "1.4.5") (load-relative "1.2") (cl-lib "0.5") (emacs "25")) :authors '(("Rocky Bernstein" . "rocky@gnu.org")) :maintainer '("Rocky Bernstein" . "rocky@gnu.org") :url "http://github.com/realgud/realgud-jdb")
