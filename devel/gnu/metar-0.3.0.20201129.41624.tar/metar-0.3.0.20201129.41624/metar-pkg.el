;; Generated package description from metar.el  -*- no-byte-compile: t -*-
(define-package "metar" "0.3.0.20201129.41624" "Retrieve and decode METAR weather information" '((cl-lib "0.5")) :url "https://elpa.gnu.org/packages/metar.html" :keywords '("comm") :authors '(("Mario Lang" . "mlang@delysid.org")) :maintainer '("Mario Lang" . "mlang@delysid.org"))
