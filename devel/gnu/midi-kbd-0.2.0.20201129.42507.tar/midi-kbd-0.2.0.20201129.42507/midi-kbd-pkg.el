;; Generated package description from midi-kbd.el  -*- no-byte-compile: t -*-
(define-package "midi-kbd" "0.2.0.20201129.42507" "Create keyboard events from Midi input" '((emacs "25")) :url "https://elpa.gnu.org/packages/midi-kbd.html" :keywords '("convenience" "hardware" "multimedia") :authors '(("David Kastrup" . "dak@gnu.org")) :maintainer '("David Kastrup" . "dak@gnu.org"))
