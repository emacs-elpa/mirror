;; Generated package description from ace-window.el  -*- no-byte-compile: t -*-
(define-package "ace-window" "0.9.0.0.20150521.51628" "Quickly switch windows." '((avy "0.2.0")) :keywords '("window" "location") :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com")) :maintainer '("Oleh Krehel" . "ohwoeowho@gmail.com") :url "https://github.com/abo-abo/ace-window")
