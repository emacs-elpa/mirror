;; Generated package description from coffee-mode.el  -*- no-byte-compile: t -*-
(define-package "coffee-mode" "0.4.1.1.0.20211010.122650" "Major mode for CoffeeScript files" 'nil :authors '(("Chris Wanstrath" . "chris@ozmm.org")) :maintainer '("Chris Wanstrath" . "chris@ozmm.org") :keywords '("coffeescript" "major" "mode") :url "http://github.com/defunkt/coffee-mode")
