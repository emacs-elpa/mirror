;; Generated package description from sisu-mode.el  -*- no-byte-compile: t -*-
(define-package "sisu-mode" "7.1.8.0.20201129.51759" "Major mode for SiSU markup text" 'nil :keywords '("text" "syntax" "processes" "tools") :authors '(("Ralph Amissah & Ambrose Kofi Laing")) :maintainer '("Ralph Amissah" . "ralph.amissah@gmail.com") :url "http://www.sisudoc.org/")
