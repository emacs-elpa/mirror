;; Generated package description from shen-mode.el  -*- no-byte-compile: t -*-
(define-package "shen-mode" "0.1.0.20201129.51414" "A major mode for editing shen source code" 'nil :url "https://elpa.gnu.org/packages/shen-mode.html" :keywords '("languages" "shen") :authors '(("Eric Schulte" . "schulte.eric@gmail.com")) :maintainer '("Eric Schulte" . "schulte.eric@gmail.com"))
