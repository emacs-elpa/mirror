;; Generated package description from vcl-mode.el  -*- no-byte-compile: t -*-
(define-package "vcl-mode" "1.1.0.20201128.1542" "Major mode for Varnish Configuration Language" 'nil :url "https://elpa.gnu.org/packages/vcl-mode.html" :keywords '("varnish" "vcl") :authors '(("Sergey Poznyakoff" . "gray@gnu.org.ua")) :maintainer '("Sergey Poznyakoff" . "gray@gnu.org.ua"))
