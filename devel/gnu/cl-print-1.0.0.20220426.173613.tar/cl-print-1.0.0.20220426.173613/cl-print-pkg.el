;; Generated package description from cl-print.el  -*- no-byte-compile: t -*-
(define-package "cl-print" "1.0.0.20220426.173613" "CL-style generic printing" '((emacs "25")) :commit "d4e3e548f5519e98c2fc842daf73a6acac7faa70" :url "https://elpa.gnu.org/packages/cl-print.html" :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca")) :maintainer '("Stefan Monnier" . "monnier@iro.umontreal.ca"))
