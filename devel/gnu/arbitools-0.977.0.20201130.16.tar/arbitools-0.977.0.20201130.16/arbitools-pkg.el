;; Generated package description from arbitools.el  -*- no-byte-compile: t -*-
(define-package "arbitools" "0.977.0.20201130.16" "Package for chess tournaments administration" '((cl-lib "0.5")) :url "https://elpa.gnu.org/packages/arbitools.html" :authors '(("David Gonzalez Gandara" . "dggandara@member.fsf.org")) :maintainer '("David Gonzalez Gandara" . "dggandara@member.fsf.org"))
