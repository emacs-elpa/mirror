;; Generated package description from project.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "project" "0.11.2.0.20260610.24" "Operations on the current project" '((emacs "26.1") (xref "1.7.0")) :commit "4c12da0888d155d3a5dcc01bae30f21b3cccfcc3" :url "https://elpa.gnu.org/packages/project.html")
