;; Generated package description from parsec.el  -*- no-byte-compile: t -*-
(define-package "parsec" "0.1.3.0.20161028.2605" "Parser combinator library" '((emacs "24") (cl-lib "0.5")) :keywords '("extensions") :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com")) :maintainer '("Junpeng Qiu" . "qjpchmail@gmail.com") :url "https://github.com/cute-jumper/parsec.el")
