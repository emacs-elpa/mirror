;; Generated package description from org-translate.el  -*- no-byte-compile: t -*-
(define-package "org-translate" "0.1.3.0.20201210.11528" "Org-based translation environment" '((emacs "25.1") (org "9.1")) :url "https://elpa.gnu.org/packages/org-translate.html" :authors '(("Eric Abrahamsen" . "eric@ericabrahamsen.net")) :maintainer '("Eric Abrahamsen" . "eric@ericabrahamsen.net"))
