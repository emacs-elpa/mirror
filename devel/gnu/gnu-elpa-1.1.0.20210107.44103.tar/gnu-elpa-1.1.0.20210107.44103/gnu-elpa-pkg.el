;; Generated package description from gnu-elpa.el  -*- no-byte-compile: t -*-
(define-package "gnu-elpa" "1.1.0.20210107.44103" "Advertize GNU ELPA packages" '((emacs "25.1")) :url "https://elpa.gnu.org/packages/gnu-elpa.html" :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca")) :maintainer '("Stefan Monnier" . "monnier@iro.umontreal.ca"))
