;; Generated package description from memory-usage.el  -*- no-byte-compile: t -*-
(define-package "memory-usage" "0.2.0.20201202.33908" "Analyze the memory usage of Emacs in various ways" 'nil :url "https://elpa.gnu.org/packages/memory-usage.html" :keywords '("maint") :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca")) :maintainer '("Stefan Monnier" . "monnier@iro.umontreal.ca"))
