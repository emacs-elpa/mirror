;; Generated package description from dbus-codegen.el  -*- no-byte-compile: t -*-
(define-package "dbus-codegen" "0.1.0.20201128.31326" "Lisp code generation for D-Bus." '((cl-lib "0.5")) :url "https://elpa.gnu.org/packages/dbus-codegen.html" :keywords '("comm" "dbus" "convenience") :authors '(("Daiki Ueno" . "ueno@gnu.org")) :maintainer '(nil . "emacs-devel@gnu.org"))
