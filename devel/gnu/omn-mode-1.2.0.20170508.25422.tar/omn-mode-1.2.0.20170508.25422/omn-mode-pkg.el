;; Generated package description from omn-mode.el  -*- no-byte-compile: t -*-
(define-package "omn-mode" "1.2.0.20170508.25422" "Support for OWL Manchester Notation" 'nil :url "https://elpa.gnu.org/packages/omn-mode.html" :authors '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk")) :maintainer '("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
