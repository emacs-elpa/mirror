;; Generated package description from gle-mode.el  -*- no-byte-compile: t -*-
(define-package "gle-mode" "1.1.0.20201129.45701" "Major mode to edit Graphics Layout Engine files" '((cl-lib "0.5")) :url "https://elpa.gnu.org/packages/gle-mode.html" :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca")) :maintainer '("Stefan Monnier" . "monnier@iro.umontreal.ca"))
