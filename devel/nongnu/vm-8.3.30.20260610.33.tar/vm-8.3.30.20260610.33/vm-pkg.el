;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "8.3.30.20260610.33" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "2f33c4bb2d2e8ac6f0f63f62b60dda439b1d07ce" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
