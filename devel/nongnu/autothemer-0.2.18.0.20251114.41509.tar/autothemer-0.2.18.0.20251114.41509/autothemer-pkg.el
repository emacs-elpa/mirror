;; Generated package description from autothemer.el  -*- no-byte-compile: t -*-
(define-package "autothemer" "0.2.18.0.20251114.41509" "Conveniently define themes" '((dash "2.10.0") (emacs "26.1")) :commit "e62bf83414abd8b1cefafb7480612faa30ed7878" :maintainer '("Jason Milkins" . "jasonm23@gmail.com") :url "https://github.com/jasonm23/autothemer")
