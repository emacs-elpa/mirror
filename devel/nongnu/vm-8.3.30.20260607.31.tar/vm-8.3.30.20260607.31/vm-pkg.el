;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "8.3.30.20260607.31" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "7640eda4df2fc587f348218e3c44ba05db935bd5" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
