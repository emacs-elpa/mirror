;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.320.20260518.142203" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "41317b78dda1531e48d002df89694fb7878ca34d" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
