;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.60.20260124.135141" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "75c13f91b6eb40b8855dfe8ac55f8f7dac876caa" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
