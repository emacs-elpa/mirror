;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.15.0.0.20260527.20" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "7c082d878b824a5a0a7f778c039c319aed84be89" :keywords '("extensions") :url "https://github.com/okamsn/loopy")
