;; Generated package description from evil.el  -*- no-byte-compile: t -*-
(define-package "evil" "1.15.0.0.20251108.13841" "Extensible vi layer" '((emacs "24.1") (cl-lib "0.5") (goto-chg "1.6") (nadvice "0.3")) :commit "729d9a58b387704011a115c9200614e32da3cefc" :maintainer '("Tom Dalziel" . "tom.dalziel@gmail.com") :keywords '("emulations") :url "https://github.com/emacs-evil/evil")
