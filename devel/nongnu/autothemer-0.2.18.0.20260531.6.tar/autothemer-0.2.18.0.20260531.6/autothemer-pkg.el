;; Generated package description from autothemer.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "autothemer" "0.2.18.0.20260531.6" "Conveniently define themes" '((dash "2.10.0") (emacs "26.1")) :commit "811beeca5b273903516d393fc39401f100343aea" :maintainer '("Jason Milkins" . "jasonm23@gmail.com") :url "https://github.com/jasonm23/autothemer")
