;; Generated package description from sesman.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sesman" "0.3.30.20260615.20" "Generic Session Manager" '((emacs "25")) :commit "faa605312c852f97f30c2a47f42c88027f135a55" :keywords '("process") :url "https://github.com/vspinu/sesman")
