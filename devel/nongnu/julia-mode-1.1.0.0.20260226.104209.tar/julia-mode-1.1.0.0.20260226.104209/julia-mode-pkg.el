;; Generated package description from julia-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "julia-mode" "1.1.0.0.20260226.104209" "Major mode for editing Julia source code" '((emacs "26.1")) :commit "1478898ea0ab1ae21ec053fcc81c6b42136a2224" :keywords '("languages") :url "https://github.com/JuliaEditorSupport/julia-emacs")
