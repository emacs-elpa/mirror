;; Generated package description from dart-mode.el  -*- no-byte-compile: t -*-
(define-package "dart-mode" "1.0.7.0.20251203.195437" "Major mode for editing Dart files" '((emacs "27.1")) :commit "773e9ebc74a258af2db395b01febfb652a42f3ab" :maintainer '("Jen-Chieh Shen" . "jcs090218@gmail.com") :keywords '("languages") :url "https://github.com/emacsorphanage/dart-mode")
