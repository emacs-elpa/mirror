;; Generated package description from xml-rpc.el  -*- no-byte-compile: t -*-
(define-package "xml-rpc" "1.6.17.0.20251122.185743" "An elisp implementation of clientside XML-RPC" '((emacs "24.1")) :commit "56593e877468682eef355b35dbb405ddce54bd53" :maintainer '("Mark A. Hershberger" . "mah@everybody.org") :keywords '("xml" "rpc" "network" "comm") :url "http://github.com/xml-rpc-el/xml-rpc-el")
