;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.15.0.0.20260620.25" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "6c94e02f814781bd51232db2fa117f21f3b9eed6" :keywords '("extensions") :url "https://github.com/okamsn/loopy")
