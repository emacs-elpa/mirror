;; Generated package description from go-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "go-mode" "1.6.0.0.20260510.170713" "Major mode for the Go programming language" '((emacs "26.1")) :commit "8aaaa9d2574d7862ecbbe1ff369e88fe3796c8be" :keywords '("languages" "go") :url "https://github.com/dominikh/go-mode.el")
