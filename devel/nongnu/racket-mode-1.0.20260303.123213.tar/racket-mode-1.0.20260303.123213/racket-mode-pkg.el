;; Generated package description from racket-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "racket-mode" "1.0.20260303.123213" "Racket editing, REPL, and more" '((emacs "25.1") (compat "30.0.2.0")) :commit "e5f22ad408740ec517a436ec19b74ce1398e61bc" :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")) :url "https://www.racket-mode.com/")
