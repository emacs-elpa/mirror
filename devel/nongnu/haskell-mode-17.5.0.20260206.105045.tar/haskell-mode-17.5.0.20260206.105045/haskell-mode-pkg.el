;; Generated package description from haskell-mode.el  -*- no-byte-compile: t -*-
(define-package "haskell-mode" "17.5.0.20260206.105045" "A Haskell editing mode" '((emacs "25.1")) :commit "2dd755a5fa11577a9388af88f385d2a8e18f7a8d" :keywords '("haskell" "cabal" "ghc" "repl" "languages") :url "https://github.com/haskell/haskell-mode")
