;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.320.20260609.48" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "2b738afe69a573e3729423a78216e8befc8d0502" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
