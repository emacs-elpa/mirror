;; Generated package description from meow.el  -*- no-byte-compile: t -*-
(define-package "meow" "1.5.0.0.20250914.165407" "Yet Another modal editing" '((emacs "27.1")) :commit "2246f593552c6208bac533de9af04b085fafa6fa" :keywords '("convenience" "modal-editing") :url "https://www.github.com/DogLooksGood/meow")
