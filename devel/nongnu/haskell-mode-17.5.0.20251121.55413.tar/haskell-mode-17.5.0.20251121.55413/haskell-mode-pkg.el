;; Generated package description from haskell-mode.el  -*- no-byte-compile: t -*-
(define-package "haskell-mode" "17.5.0.20251121.55413" "A Haskell editing mode" '((emacs "25.1")) :commit "383b4b77753ef83420c7a755f86e1ec4770f551b" :keywords '("haskell" "cabal" "ghc" "repl" "languages") :url "https://github.com/haskell/haskell-mode")
