;; Generated package description from rfc-mode.el  -*- no-byte-compile: t -*-
(define-package "rfc-mode" "1.4.2.0.20231013.135347" "RFC document browser and viewer" '((emacs "25.1")) :commit "ab09db78d9d1baa4da4f926930833598e1e978ce" :authors '(("Nicolas Martyanoff" . "nicolas@n16f.net")) :maintainer '("Nicolas Martyanoff" . "nicolas@n16f.net") :url "https://github.com/galdor/rfc-mode")
