;; Generated package description from rfc-mode.el  -*- no-byte-compile: t -*-
(define-package "rfc-mode" "1.4.2.0.20260127.180740" "RFC document browser and viewer" '((emacs "25.1")) :commit "2d3dcd649e291eeb93091560b504f96162371c32" :authors '(("Nicolas Martyanoff" . "nicolas@n16f.net")) :maintainer '("Nicolas Martyanoff" . "nicolas@n16f.net") :url "https://github.com/galdor/rfc-mode")
