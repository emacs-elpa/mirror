;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.15.0.0.20260619.24" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "e7b05b7a4d0d3dba1935c0bd70db34ec65510959" :keywords '("extensions") :url "https://github.com/okamsn/loopy")
