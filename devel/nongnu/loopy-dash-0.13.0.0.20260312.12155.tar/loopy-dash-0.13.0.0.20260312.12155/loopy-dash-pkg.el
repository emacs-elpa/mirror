;; Generated package description from loopy-dash.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy-dash" "0.13.0.0.20260312.12155" "Dash destructuring for `loopy'" '((emacs "28.1") (loopy "0.13.0") (dash "2.20")) :commit "23e4eec784a53828a916a03439fa87f22ef8f800" :keywords '("extensions") :url "https://github.com/okamsn/loopy-dash")
