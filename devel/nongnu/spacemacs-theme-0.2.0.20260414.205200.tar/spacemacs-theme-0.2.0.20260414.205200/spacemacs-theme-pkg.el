;; Generated package description from spacemacs-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "spacemacs-theme" "0.2.0.20260414.205200" "Color theme with a dark and light versions." '((emacs "24")) :commit "789d20c55cd01f757929d0232dd1d5227c84ad7e" :keywords '("color" "theme") :url "https://github.com/nashamri/spacemacs-theme")
