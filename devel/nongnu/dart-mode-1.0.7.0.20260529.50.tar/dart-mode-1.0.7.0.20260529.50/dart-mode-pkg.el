;; Generated package description from dart-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "dart-mode" "1.0.7.0.20260529.50" "Major mode for editing Dart files" '((emacs "27.1")) :commit "793d7bcc18a2636ebafe06450356c08ea6d638ca" :maintainer '("Jen-Chieh Shen" . "jcs090218@gmail.com") :keywords '("languages") :url "https://github.com/emacsorphanage/dart-mode")
