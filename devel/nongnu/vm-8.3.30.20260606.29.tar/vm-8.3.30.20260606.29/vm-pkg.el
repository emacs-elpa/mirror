;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "8.3.30.20260606.29" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "b3f21ea2a77767fc7189138dd7c8862df652382f" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
