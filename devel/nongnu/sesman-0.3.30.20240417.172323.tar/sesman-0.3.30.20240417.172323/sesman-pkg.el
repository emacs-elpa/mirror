;; Generated package description from sesman.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sesman" "0.3.30.20240417.172323" "Generic Session Manager" '((emacs "25")) :commit "7bca68dbbab0af26a6a23be1ff5fa97f9a18e022" :keywords '("process") :url "https://github.com/vspinu/sesman")
