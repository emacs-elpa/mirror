
##########
Change Log
##########

- In development
  - Add support for matching against inherited faces.
  - Add support for camel-case word delimiting.

- Version 0.4 (2023-01-06)
  - Rename ``global-spell-fu-mode`` to ``spell-fu-global-mode``,
    ``global-spell-fu-ignore-buffer`` to ``spell-fu-global-ignore-buffer``.
  - Add ``spell-fu-debug`` variable, to support debugging why dictionaries are not loading.
  - Add ``spell-fu-reset`` to re-generate cache.
  - Fix #31, failure to detect updated personal dictionary when it's a symlink.
  - Stealthy font locking now checks words even when outside the view,
    so stealthy font locking ensures words are checked.
  - Fix #13, failure to properly generate word-list cache on MS-Windows.
  - Support buffer local word-lists via ``spell-fu-buffer-session-localwords``.
  - Fix faces of overlays (such as ``hl-line-mode``) no longer mask other faces when selecting words to check.
  - Support for multiple dictionaries at once.
  - Reduce idle overlay fragmentation.
  - Idle timers now update buffers that have lost focus.
  - Fix for disabling ``spell-fu-mode`` preventing other buffers that have ``spell-fu-mode`` enabled from updating.
  - Changes to the face are now treated as word separators.

    This fixes spell checking in situations where characters are escaped for example ``"test\nterm"``,
    will use the ``\n`` as a divider when escape characters use a different face.
  - ``global-spell-fu-mode`` no longer enables spell-fu for modes derived from ``special-mode``
    such as package list for example (fixes ``#15``).
  - Support conditionally disabling ``global-spell-fu-mode`` via
    ``global-spell-fu-ignore-buffer`` & ``global-spell-fu-ignore-modes``.

- Version 0.3 (2021-03-28)

  - Support affix expansion when calling ``aspell`` (some non English dictionaries use this).
  - Use explicit ``utf-8`` encoding, (fixes issue #8).
  - Improve default ``spell-fu-word-regexp`` to better differentiate quoted text from apostrophes (fixes issue #3).

- Version 0.2 (2020-04-26)

  - Add support personal dictionary manipulation: ``spell-fu-word-add``, ``spell-fu-word-remove``.
  - Add support for stepping over errors with: ``spell-fu-goto-next-error``, ``spell-fu-goto-previous-error``.
  - Add support for checking the whole buffer with: ``spell-fu-buffer``.

- Version 0.1 (2020-04-14)

  Initial release.
