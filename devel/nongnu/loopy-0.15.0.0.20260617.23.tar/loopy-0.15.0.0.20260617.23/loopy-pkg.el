;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.15.0.0.20260617.23" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "474b57bc2b65ac92e200c351d91a322b308ea1bc" :keywords '("extensions") :url "https://github.com/okamsn/loopy")
