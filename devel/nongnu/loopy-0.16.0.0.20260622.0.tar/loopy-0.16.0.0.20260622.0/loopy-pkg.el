;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.16.0.0.20260622.0" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "09fecad848c8671902ceae7d74afecdd29a84ac5" :keywords '("extensions") :url "https://github.com/okamsn/loopy")
