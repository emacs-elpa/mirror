;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.15.0.0.20260312.10626" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "fa9a2ec58cea974d6065ca508b669085e3128bee" :keywords '("extensions") :url "https://github.com/okamsn/loopy")
