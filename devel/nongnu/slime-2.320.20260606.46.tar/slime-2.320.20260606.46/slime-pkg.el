;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.320.20260606.46" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "61d51932ceaed18867e47486de39eb15c163bd2b" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
