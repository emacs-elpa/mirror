;; Generated package description from scala-mode.el  -*- no-byte-compile: t -*-
(define-package "scala-mode" "1.1.1.0.20241231.83915" "Major mode for editing Scala" '((emacs "25.1")) :commit "661337d8aa0a0cb418184c83757661603de3b2e3" :keywords '("languages") :url "https://github.com/hvesalai/emacs-scala-mode")
