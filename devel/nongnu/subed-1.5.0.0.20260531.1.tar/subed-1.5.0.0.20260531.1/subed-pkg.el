;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.0.0.20260531.1" "A major mode for editing subtitles" '((emacs "25.1")) :commit "df63931c4165c25b79ccbe0050974a81eaf5ec49" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
