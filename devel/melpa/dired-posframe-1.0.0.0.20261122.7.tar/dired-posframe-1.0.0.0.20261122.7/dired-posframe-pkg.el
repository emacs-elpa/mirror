;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-posframe" "1.0.0.0.20261122.7"
  "Peep Dired items using posframe."
  '((emacs    "26.1")
    (posframe "0.7"))
  :url "https://github.com/conao3/dired-posframe.el"
  :commit "847270c1c49f378d92d45681dcdaa13316c6f345"
  :revdesc "847270c1c49f"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
