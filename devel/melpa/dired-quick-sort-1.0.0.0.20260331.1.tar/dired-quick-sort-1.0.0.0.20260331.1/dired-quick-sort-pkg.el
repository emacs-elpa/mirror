;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-quick-sort" "1.0.0.0.20260331.1"
  "Persistent quick sorting of Dired buffers in various ways."
  '((emacs "28"))
  :url "https://gitlab.com/xuhdev/dired-quick-sort"
  :commit "3c9b41799b0424eb78f54caba56e4de1d7224e8b"
  :revdesc "3c9b41799b04"
  :keywords '("convenience" "files")
  :authors '(("Hong Xu" . "hong@topbug.net"))
  :maintainers '(("Hong Xu" . "hong@topbug.net")))
