;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kodi-remote" "0.0.0.20190622.125"
  "Remote Control for Kodi."
  '((request   "0.2.0")
    (let-alist "1.0.4")
    (json      "1.4")
    (cl-lib    "0.5")
    (f         "20190109.906"))
  :url "https://github.com/spiderbit/kodi-remote.el"
  :commit "f5e932036c16e2b61a63020e006fc601e38d181e"
  :revdesc "f5e932036c16"
  :keywords '("kodi" "tools" "convinience")
  :authors '(("Stefan Huchler" . "stefan.huchler@mail.de"))
  :maintainers '(("Stefan Huchler" . "stefan.huchler@mail.de")))
