;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-org-clock" "0.2.2.0.20200810.3"
  "Counsel commands for org-clock."
  '((emacs "25.1")
    (ivy   "0.10.0")
    (dash  "2.0"))
  :url "https://github.com/akirak/counsel-org-clock"
  :commit "a32bb85205e877cc57f62765c225e8b288536918"
  :revdesc "a32bb85205e8"
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
