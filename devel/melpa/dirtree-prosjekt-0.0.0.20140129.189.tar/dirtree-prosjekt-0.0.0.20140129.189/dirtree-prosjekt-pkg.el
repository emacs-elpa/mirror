;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirtree-prosjekt" "0.0.0.20140129.189"
  "Dirtree integration for prosjekt."
  '((prosjekt "0.3")
    (dirtree  "0.01"))
  :url "https://github.com/abingham/prosjekt"
  :commit "03e06910589ba5cd736868793eb436b3233c6a26"
  :revdesc "03e06910589b"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
