;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async" "1.9.9.0.20260729.33"
  "Asynchronous processing in Emacs."
  '((emacs "24.4"))
  :url "https://github.com/jwiegley/emacs-async"
  :commit "4fdcb061a166e0d6ccc27d3829a28e04415ae825"
  :revdesc "v1.9.9-33-g4fdcb061a166"
  :keywords '("async")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
