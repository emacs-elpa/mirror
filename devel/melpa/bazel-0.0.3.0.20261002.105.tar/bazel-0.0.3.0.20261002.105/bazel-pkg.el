;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3.0.20261002.105"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "f5b4119c7215ce9a52c7bc74b83d8378682daeab"
  :revdesc "f5b4119c7215"
  :keywords '("build tools" "languages"))
