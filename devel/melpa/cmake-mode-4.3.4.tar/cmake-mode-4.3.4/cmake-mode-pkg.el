;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-mode" "4.3.4"
  "Major-mode for editing CMake sources."
  '((emacs "24.1"))
  :commit "c2fd48014f39786ba5c5e51b983d1cdcf05aa269"
  :revdesc "v4.3.4-0-gc2fd48014f39")
