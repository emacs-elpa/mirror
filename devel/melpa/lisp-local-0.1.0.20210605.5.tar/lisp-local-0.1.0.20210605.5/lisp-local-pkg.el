;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-local" "0.1.0.20210605.5"
  "Allow different Lisp indentation in each buffer."
  '((emacs "24.3"))
  :url "https://github.com/lispunion/emacs-lisp-local"
  :commit "22e221c9330d2b5dc07e8b2caa34c83ac7c20b0d"
  :revdesc "0.1-5-g22e221c9330d"
  :keywords '("languages" "lisp")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
