;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2.0.20260828.45"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "6430b36140ca9fac0109bbb63efa7b9cc27edf62"
  :revdesc "6430b36140ca"
  :keywords '("faces" "files" "q"))
