;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dizzee" "0.1.1.0.20171201.6"
  "Utilities for managing subprocesses in Emacs."
  ()
  :url "https://github.com/davidmiller/dizzee"
  :commit "e3cf1c2ea5d0fc00747524b6f3c5b905d0a8c8e1"
  :revdesc "e3cf1c2ea5d0"
  :keywords '("emacs" "processes")
  :authors '(("David Miller" . "david@deadpansincerity.com"))
  :maintainers '(("David Miller" . "david@deadpansincerity.com")))
