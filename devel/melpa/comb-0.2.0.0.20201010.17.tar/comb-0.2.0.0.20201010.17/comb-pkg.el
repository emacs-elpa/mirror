;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comb" "0.2.0.0.20201010.17"
  "Interactive code auditing and grep tool."
  '((emacs "25.1"))
  :url "https://github.com/cyrus-and/comb"
  :commit "31f3e94afb2a7f7d18d30c2468a0c683700f7a66"
  :revdesc "31f3e94afb2a"
  :keywords '("matching")
  :authors '(("Andrea Cardaci" . "cyrus.and@gmail.com"))
  :maintainers '(("Andrea Cardaci" . "cyrus.and@gmail.com")))
