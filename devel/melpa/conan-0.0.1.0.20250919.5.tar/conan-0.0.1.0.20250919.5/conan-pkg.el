;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conan" "0.0.1.0.20250919.5"
  "Generate flags for c++ using conan 2.0."
  '((emacs "29.1")
    (s     "1.7.0")
    (f     "0.20.0"))
  :url "https://github.com/Carl2/conan-elisp"
  :commit "0c3cca9e832e837a037f8c88438cca979891b131"
  :revdesc "0c3cca9e832e"
  :keywords '("tools"))
