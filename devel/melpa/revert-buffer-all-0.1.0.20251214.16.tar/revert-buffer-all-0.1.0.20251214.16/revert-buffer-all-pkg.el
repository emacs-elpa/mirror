;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "revert-buffer-all" "0.1.0.20251214.16"
  "Revert all open buffers."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-buffer-revert-all"
  :commit "e00fc97fe469265b31a9790f40f1e8b749380b01"
  :revdesc "e00fc97fe469"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
