;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outshine" "3.0.1.0.20220326.60"
  "Outline with outshine outshines outline."
  '((outorg "2.0")
    (cl-lib "0.5"))
  :url "https://github.com/alphapapa/outshine"
  :commit "bf1eed10dd7a89b63d0fc014944033db397c1e23"
  :revdesc "v3.0.1-60-gbf1eed10dd7a"
  :keywords '("convenience" "outlines" "org")
  :maintainers '(("Thibault Polge" . "thibault@thb.lt")))
