;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "circom-mode" "0.1.0.20250604.5"
  "Major mode for editing Circom circuit."
  '((emacs "24.3"))
  :url "https://github.com/taquangtrung/emacs-circom-mode"
  :commit "80240776507ac2454546a8999bcfb6c39ab04a32"
  :revdesc "80240776507a"
  :keywords '("languages"))
