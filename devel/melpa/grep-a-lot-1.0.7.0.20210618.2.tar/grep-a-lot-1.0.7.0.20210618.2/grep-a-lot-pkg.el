;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grep-a-lot" "1.0.7.0.20210618.2"
  "Manages multiple search results buffers for grep.el."
  ()
  :url "https://github.com/ZungBang/emacs-grep-a-lot"
  :commit "223819dbea049bdeb5f97f9849fce139a5f16a75"
  :revdesc "223819dbea04"
  :keywords '("tools" "convenience" "search")
  :authors '(("Avi Rozen" . "avi.rozen@gmail.com"))
  :maintainers '(("Avi Rozen" . "avi.rozen@gmail.com")))
