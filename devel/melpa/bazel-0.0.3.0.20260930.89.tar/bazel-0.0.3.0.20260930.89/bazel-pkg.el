;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3.0.20260930.89"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "c71e002b1d252a5e3d2ba72c3178865adf1e78d0"
  :revdesc "c71e002b1d25"
  :keywords '("build tools" "languages"))
