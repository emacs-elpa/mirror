;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.14.0.20260826.6"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "213ec2b5afe1da4e15090808c00871f8cb3b730a"
  :revdesc "2.14-6-g213ec2b5afe1"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
