;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "govc" "0.56.0"
  "Interface to govc for managing VMware ESXi and vCenter."
  '((emacs       "24.3")
    (dash        "1.5.0")
    (s           "1.9.0")
    (magit-popup "2.0.50")
    (json-mode   "1.6.0"))
  :url "https://github.com/vmware/govmomi/tree/main/govc/emacs"
  :commit "81608f9b9725d64e4ed447b9a338c9f03dbf8840"
  :revdesc "v0.56.0-0-g81608f9b9725"
  :keywords '("convenience"))
