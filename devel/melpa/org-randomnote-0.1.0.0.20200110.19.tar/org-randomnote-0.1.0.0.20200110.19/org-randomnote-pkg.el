;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-randomnote" "0.1.0.0.20200110.19"
  "Find a random note in your Org-Mode files."
  '((f    "0.19.0")
    (dash "2.12.0")
    (org  "0"))
  :url "https://github.com/mwfogleman/org-randomnote"
  :commit "ea8cf4385970637efffff8f79e14576ba6d7ad13"
  :revdesc "ea8cf4385970"
  :authors '(("Michael Fogleman" . "michaelwfogleman@gmail.com"))
  :maintainers '(("Michael Fogleman" . "michaelwfogleman@gmail.com")))
