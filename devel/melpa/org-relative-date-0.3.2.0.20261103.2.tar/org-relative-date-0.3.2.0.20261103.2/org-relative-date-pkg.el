;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-relative-date" "0.3.2.0.20261103.2"
  "Live relative-date overlays on org timestamps."
  '((emacs "27.1")
    (org   "9.1"))
  :url "https://github.com/RobertPlant/org-relative-date"
  :commit "e5e06c6f91261d928f31561d4bb66b6a8e044365"
  :revdesc "e5e06c6f9126"
  :keywords '("calendar" "org" "convenience")
  :authors '(("Rob Plant" . "rob@robertplant.io"))
  :maintainers '(("Rob Plant" . "rob@robertplant.io")))
