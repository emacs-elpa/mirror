;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-rfc" "1.0.20240901.96"
  "RFC Back-End for Org Export Engine."
  '((emacs "24.3")
    (org   "8.3"))
  :url "https://github.com/choppsv1/org-rfc-export"
  :commit "ab66ace2f6306828c0842fdd729e018cc2395c94"
  :revdesc "ab66ace2f630"
  :keywords '("org" "rfc" "wp" "xml")
  :authors '(("Christian Hopps" . "chopps@devhopps.com"))
  :maintainers '(("Christian Hopps" . "chopps@devhopps.com")))
