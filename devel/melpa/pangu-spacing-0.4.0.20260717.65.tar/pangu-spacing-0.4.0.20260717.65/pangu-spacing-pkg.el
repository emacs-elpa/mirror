;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pangu-spacing" "0.4.0.20260717.65"
  "Minor-mode to add space between Chinese and English characters."
  ()
  :url "https://github.com/coldnew/pangu-spacing"
  :commit "72de84e999aafa753a635b14bb199fc46d322945"
  :revdesc "72de84e999aa"
  :authors '(("coldnew" . "coldnew.tw@gmail.com"))
  :maintainers '(("coldnew" . "coldnew.tw@gmail.com")))
