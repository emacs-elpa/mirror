;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.98.2.0.20261022.1"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "f57ad5e361621a38549d47ee5bd9cd1106cc07ef"
  :revdesc "f57ad5e36162")
