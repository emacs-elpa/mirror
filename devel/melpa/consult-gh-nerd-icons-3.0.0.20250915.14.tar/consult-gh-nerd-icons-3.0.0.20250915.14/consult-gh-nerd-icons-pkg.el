;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh-nerd-icons" "3.0.0.20250915.14"
  "Nerd icons integration for consult-gh."
  '((emacs      "29.4")
    (nerd-icons "0.1.0")
    (consult-gh "3.0"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "feba9c563f3919401c89dd4008d23ae0896c47ce"
  :revdesc "feba9c563f39"
  :keywords '("matching" "git" "repositories" "completion"))
