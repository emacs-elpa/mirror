;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "0.1.1.0.20260606.28"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "af491d225771af377d65961e8a5f251b82a0a09a"
  :revdesc "af491d225771"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
