;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-clang" "0.1.0.20140409.15"
  "Auto Completion source for clang for GNU Emacs."
  '((auto-complete "1.3.1"))
  :url "https://github.com/brianjcj/auto-complete-clang"
  :commit "a195db1d0593b4fb97efe50885e12aa6764d998c"
  :revdesc "a195db1d0593"
  :keywords '("completion" "convenience")
  :authors '(("Brian Jiang" . "brianjcj@gmail.com"))
  :maintainers '(("Brian Jiang" . "brianjcj@gmail.com")))
