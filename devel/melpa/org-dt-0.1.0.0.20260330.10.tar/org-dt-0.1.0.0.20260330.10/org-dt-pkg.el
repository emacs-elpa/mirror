;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-dt" "0.1.0.0.20260330.10"
  "Dynamic templating loader."
  '((emacs "29.1"))
  :url "https://codeberg.org/niqc/org-dynamic-templates"
  :commit "aad20f4e6208077825f4b6cd8fc90dffcc1f5cbd"
  :revdesc "aad20f4e6208"
  :keywords '("convenience"))
