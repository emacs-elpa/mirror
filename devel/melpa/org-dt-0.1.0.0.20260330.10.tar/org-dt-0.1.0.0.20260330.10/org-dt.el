;;; org-dt.el --- Dynamic templating loader -*- lexical-binding: t -*-

;; Package-Version: 0.1.0.0.20260330.10
;; Package-Revision: aad20f4e6208
;; Package-Requires: ((emacs "29.1"))
;; Keywords: convenience
;; URL: https://codeberg.org/niqc/org-dynamic-templates

;; SPDX-License-Identifier: AGPL-3.0-or-later

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU Affero General Public License as
;; published by the Free Software Foundation, either version 3 of the
;; License, or (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU Affero General Public License for more details.

;; You should have received a copy of the GNU Affero General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Define template folder for org files, you can define a folder and all org files
;; are converted in a template

;;; Code:

(require 'cl-lib)
(require 'project)

(defgroup org-dt nil
  "Dynamic templates loaded from directories."
  :group 'org-dt)

(defcustom org-dt-templates-folder "templates"
  "Folder to save your templates."
  :type 'string
  :group 'org-dt)

(defcustom org-dt-capture-target "~/.notes/hello.org"
  "Target used in the file for dynamic templates."
  :type '(choice
          (string :tag "Target string")
          (function :tag "Function that returns the target"))
  :group 'org-dt)

(defcustom org-dt-using-roam nil
  "Define as t if you use org roam."
  :type 'boolean
  :group 'org-dt)

(defvar org-dt--always-use-last-category nil
  "If non-nil, always reuse the last template category.")

(defvar org-dt--last-template-category nil
  "Last template category used.")

(defun org-dt--templates-dir ()
  "Return current directory."
  (when-let* ((project (project-current)))
    (expand-file-name org-dt-templates-folder
                      (project-root project))))

(defun org-dt-toggle-always-use-last-category ()
  "Toggle always using the last template category."
  (interactive)
  (setq org-dt--always-use-last-category
        (not org-dt--always-use-last-category))
  (message "Always use last category: %s"
           (if org-dt--always-use-last-category "enabled" "disabled")))

(defun org-dt--generate-key (name used-keys)
  "Generate unique key for template.
Argument NAME Name of template.
Argument USED-KEYS List of used keys."
  (let ((chars (string-to-list name))
        key)
    (while (and chars (member (setq key (string (pop chars))) used-keys)))
    (or key
        (number-to-string (length used-keys)))))

(defun org-dt--select-template-dir (root)
  "Select template directory.
Argument ROOT Root directory."
  (let* ((dirs
          (cons root
                (seq-filter
                 #'file-directory-p
                 (directory-files-recursively root "" t))))
         (names
          (mapcar
           (lambda (dir)
             (let ((rel (file-relative-name dir root)))
               (if (string= rel ".")
                   "root"
                 rel)))
           dirs)))

    (cond
     (org-dt--always-use-last-category
      (or org-dt--last-template-category root))
     (t
      (let* ((choice (completing-read "Template category: " names nil t))
             (dir (if (string= choice "root")
                      root
                    (expand-file-name choice root))))
        (setq org-dt--last-template-category dir)
        dir)))))


(defun org-dt--resolve-capture-target ()
  "Resolve if org-dt-capture-target is a function or string."
  (if (functionp org-dt-capture-target)
      (funcall org-dt-capture-target)
    org-dt-capture-target))

(defun org-dt--set-templates (templates)
  "Define template for org or roam.
Argument TEMPLATES List of templates to define."
  (set (if org-dt-using-roam
           'org-roam-capture-templates
         'org-capture-templates)
       templates))

(defun org-dt-load-templates ()
  "Load templates from project root folder."
  (interactive)
  (when-let* ((root (org-dt--templates-dir))
              ((file-directory-p root))
              (dir (org-dt--select-template-dir root))
              (files (sort (directory-files dir t "\\.org$")
                           #'string<)))
    (let ((used-keys '())
          (target (org-dt--resolve-capture-target)))
      (org-dt--set-templates
       (cl-loop
        for file in files
        for name = (file-name-base file)
        for key = (org-dt--generate-key name used-keys)
        do (push key used-keys)
        collect
        (if org-dt-using-roam
            `(,key ,name
                   plain
                   (file ,file)
                   :if-new
                   (file ,target)
                   :unnarrowed t)
          `(,key ,name
                 plain
                 (file ,target)
                 (file, file)
                 :unnarrowed t)))))))

(provide 'org-dt)
;;; org-dt.el ends here
