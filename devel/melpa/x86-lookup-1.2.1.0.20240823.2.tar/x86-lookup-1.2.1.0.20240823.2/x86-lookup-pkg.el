;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x86-lookup" "1.2.1.0.20240823.2"
  "Jump to x86 instruction documentation."
  '((emacs  "24.3")
    (cl-lib "0.3"))
  :url "https://github.com/skeeto/x86-lookup"
  :commit "0a6e4faceb3c313c3ee0ac4b086326a7553c1d8b"
  :revdesc "1.2.1-2-g0a6e4faceb3c"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
