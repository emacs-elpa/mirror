;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3.0.20260820.66"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "0a5dec6508afdbcc79d98300717c5be530f12497"
  :revdesc "0a5dec6508af"
  :keywords '("build tools" "languages"))
