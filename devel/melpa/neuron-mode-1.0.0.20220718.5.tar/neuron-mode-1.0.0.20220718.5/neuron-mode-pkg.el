;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neuron-mode" "1.0.0.20220718.5"
  "Major mode for editing zettelkasten notes using neuron."
  '((emacs         "26.3")
    (f             "0.20.0")
    (s             "1.12.0")
    (markdown-mode "2.3")
    (company       "0.9.13"))
  :url "https://github.com/felko/neuron-mode"
  :commit "33bc73f9a2ef1c6855bb12fec08e15a8cf4a6c6e"
  :revdesc "33bc73f9a2ef"
  :keywords '("outlines")
  :authors '(("felko" . "http://github/felko"))
  :maintainers '(("felko" . "http://github/felko")))
