;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jscs" "0.1.0.0.20151015.25"
  "Consistent JavaScript editing using JSCS."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/papaeye/emacs-jscs"
  :commit "9d39d0f2355e69a020bf76242504f3a33e013ccf"
  :revdesc "9d39d0f2355e"
  :keywords '("languages" "convenience")
  :authors '(("papaeye" . "papaeye@gmail.com"))
  :maintainers '(("papaeye" . "papaeye@gmail.com")))
