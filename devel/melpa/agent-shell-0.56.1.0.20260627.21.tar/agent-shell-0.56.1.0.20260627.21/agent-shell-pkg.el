;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.56.1.0.20260627.21"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.1")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "064c040ee498991c7115cf61943165d9d031f1e7"
  :revdesc "064c040ee498")
