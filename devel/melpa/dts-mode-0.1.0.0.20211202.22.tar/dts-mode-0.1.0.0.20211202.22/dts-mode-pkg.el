;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dts-mode" "0.1.0.0.20211202.22"
  "Major mode for Devicetree source code."
  ()
  :url "https://github.com/bgamari/dts-mode"
  :commit "32517e7eeeccc785b7c669fd5e93c5df45597ef1"
  :revdesc "32517e7eeecc"
  :keywords '("languages")
  :authors '(("Ben Gamari" . "ben@smart-cactus.org"))
  :maintainers '(("Ben Gamari" . "ben@smart-cactus.org")))
