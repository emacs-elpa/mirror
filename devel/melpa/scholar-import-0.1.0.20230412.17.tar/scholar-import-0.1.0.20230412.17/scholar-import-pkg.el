;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scholar-import" "0.1.0.20230412.17"
  "Import Bibtex & PDF from Google Scholar."
  '((emacs    "26.1")
    (org      "9.0")
    (request  "0.3.0")
    (s        "1.10.0")
    (parsebib "4.2"))
  :url "https://github.com/teeann/scholar-import"
  :commit "2456367578caa7fd768e30238ce080687faa0a25"
  :revdesc "2456367578ca"
  :authors '(("Anh T Nguyen" . "https://github.com/teeann"))
  :maintainers '(("Anh T Nguyen" . "https://github.com/teeann")))
