;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "3.8"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "788735b54e5ad9d33137613aebae055443e3e05e"
  :revdesc "3.8-0-g788735b54e5a"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
