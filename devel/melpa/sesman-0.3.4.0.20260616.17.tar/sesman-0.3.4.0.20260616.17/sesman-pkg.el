;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sesman" "0.3.4.0.20260616.17"
  "Generic Session Manager."
  '((emacs "25"))
  :url "https://github.com/vspinu/sesman"
  :commit "7eb733acb33e610a53979fa7fc13393eeda3cc53"
  :revdesc "7eb733acb33e"
  :keywords '("process"))
