;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simplecov" "2.0.0.20221206.2"
  "Colorize untested ruby code."
  '((dash  "2.19")
    (emacs "28"))
  :url "https://github.org/zenspider/elisp"
  :commit "215f2bdc5d2ef9b4439779ba4d3129210c9f34ab"
  :revdesc "215f2bdc5d2e"
  :keywords '("tools" "languages")
  :authors '(("Ryan Davis" . "ryand-ruby@zenspider.com"))
  :maintainers '(("Ryan Davis" . "ryand-ruby@zenspider.com")))
