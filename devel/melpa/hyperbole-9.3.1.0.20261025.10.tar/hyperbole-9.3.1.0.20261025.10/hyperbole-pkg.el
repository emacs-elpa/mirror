;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.3.1.0.20261025.10"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "a88cef59a57121b866ce91d2df68e1a82e59e757"
  :revdesc "hyperbole-9.3.1-10-ga88cef59a571"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")
                 ("Mats Lidell" . "matsl@gnu.org")))
