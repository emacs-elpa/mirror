;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "4.0.0.0.20260922.435"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "26.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "0dd5947e030d005efe1888331e84bd5a7e3e79b5"
  :revdesc "0dd5947e030d")
