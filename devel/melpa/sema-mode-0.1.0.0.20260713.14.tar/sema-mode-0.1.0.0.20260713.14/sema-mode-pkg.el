;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sema-mode" "0.1.0.0.20260713.14"
  "Major mode for editing Sema files."
  '((emacs "25.1"))
  :url "https://github.com/sema-lisp/emacs-sema"
  :commit "296c970854225ffa2f1a9944835f07e40b5cd7b0"
  :revdesc "296c97085422"
  :keywords '("languages" "lisp")
  :authors '(("Helge Sverre" . "helge.sverre@gmail.com"))
  :maintainers '(("Helge Sverre" . "helge.sverre@gmail.com")))
