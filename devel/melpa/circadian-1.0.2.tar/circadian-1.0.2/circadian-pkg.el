;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "circadian" "1.0.2"
  "Theme-switching based on daytime."
  '((emacs "27.2"))
  :url "https://github.com/GuidoSchmidt/circadian"
  :commit "181bb35ba9416bdede255c9fa6b86a2d60115f94"
  :revdesc "1.0.2-0-g181bb35ba941"
  :keywords '("themes")
  :maintainers '(("Guido Schmidt" . "git@guidoschmidt.cc")))
