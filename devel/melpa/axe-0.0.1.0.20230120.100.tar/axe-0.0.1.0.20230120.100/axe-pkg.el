;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "axe" "0.0.1.0.20230120.100"
  "AWS Extensions."
  '((emacs     "25.1")
    (hmac      "0.0")
    (request   "0.3.2")
    (s         "1.12.0")
    (xmlgen    "0.5")
    (dash      "2.17.0")
    (mimetypes "1.0"))
  :url "https://github.com/cniles/axe"
  :commit "5168d4f4c33861a071285df34f17fce92137d497"
  :revdesc "5168d4f4c338"
  :authors '(("Craig Niles" . "niles.catgmail.com"))
  :maintainers '(("Craig Niles" . "niles.catgmail.com")))
