;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "renpy-mode" "0.0.0.20251118.90"
  "Major mode for editing Ren'Py files."
  '((emacs "27.1"))
  :url "https://github.com/Reagankm/renpy-mode"
  :commit "f4b7512af930efbf6a9be8dd7d43f47031acba40"
  :revdesc "f4b7512af930"
  :keywords '("languages")
  :authors '(("Dave Love" . "fx@gnu.org"))
  :maintainers '(("Reagan Middlebrook" . "reagankm@gmail.com")))
