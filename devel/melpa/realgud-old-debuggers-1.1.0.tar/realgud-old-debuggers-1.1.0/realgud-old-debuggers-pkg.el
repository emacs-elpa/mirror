;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-old-debuggers" "1.1.0"
  "Realgud front-end to older lesser-used debuggers."
  '((realgud       "1.4.5")
    (load-relative "1.2")
    (cl-lib        "0.5")
    (emacs         "24"))
  :url "https://github.com/rocky/realgud-old-debuggers"
  :commit "0fad38283e885c452160232e01adf3f6ae51983b"
  :revdesc "0fad38283e88")
