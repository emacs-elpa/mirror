;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.77.2.0.20260920.16"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "3bd32a16f4eededd54e190d94318f536ed4fac7c"
  :revdesc "3bd32a16f4ee")
