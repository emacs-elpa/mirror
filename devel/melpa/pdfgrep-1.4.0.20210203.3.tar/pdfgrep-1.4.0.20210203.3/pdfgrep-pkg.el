;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdfgrep" "1.4.0.20210203.3"
  "Run `pdfgrep' and display the results."
  '((emacs "24.4"))
  :url "https://github.com/jeremy-compostella/pdfgrep"
  :commit "a4ca0a1e6521de93f28bb6736a5344b4974d144c"
  :revdesc "a4ca0a1e6521"
  :keywords '("extensions" "mail" "pdf" "grep")
  :authors '(("Jérémy Compostella" . "jeremy.compostella@gmail.com"))
  :maintainers '(("Jérémy Compostella" . "jeremy.compostella@gmail.com")))
