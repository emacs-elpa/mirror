;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "point-stack" "1.1.0.20200427.6"
  "Back and forward navigation through buffer locations."
  ()
  :url "https://github.com/dgutov/point-stack"
  :commit "cddcea2c91038710c245819b3cda2dd739726134"
  :revdesc "cddcea2c9103"
  :authors '(("Matt Harrison" . "matthewharrison@gmail.com")
             ("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainers '(("Matt Harrison" . "matthewharrison@gmail.com")
                 ("Dmitry Gutov" . "dgutov@yandex.ru")))
