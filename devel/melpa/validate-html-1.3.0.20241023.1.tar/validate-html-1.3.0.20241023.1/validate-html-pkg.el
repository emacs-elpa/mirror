;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "validate-html" "1.3.0.20241023.1"
  "Compilation mode for W3C HTML Validator."
  '((emacs "25.1"))
  :url "https://github.com/arthurgleckler/validate-html"
  :commit "4285c492d8a28025ffce7ee717e2aefc905bea66"
  :revdesc "4285c492d8a2"
  :keywords '("languages" "tools")
  :authors '(("Arthur A. Gleckler" . "melpa4aag@speechcode.com"))
  :maintainers '(("Arthur A. Gleckler" . "melpa4aag@speechcode.com")))
