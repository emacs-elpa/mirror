;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "straight-overview" "0.4.0"
  "Selective upgrade UI for straight.el packages."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/straight-overview"
  :commit "c00edee3fc72b87b8eca9fb901975dc988eb4e6f"
  :revdesc "v0.4.0-0-gc00edee3fc72"
  :keywords '("convenience" "tools" "vc")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
