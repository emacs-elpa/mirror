;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-project" "0.2.0.0.20240602.1"
  "Terminal management for project.el."
  '((emacs        "28.1")
    (term-manager "0.1.0"))
  :url "https://www.github.com/IvanMalison/term-manager"
  :commit "25353734c65cd5cc952e4893b552629ca1d0d37f"
  :revdesc "25353734c65c"
  :keywords '("project" "tools" "terminals" "vc")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com")
             ("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")
                 ("ROCKTAKEY" . "rocktakey@gmail.com")))
