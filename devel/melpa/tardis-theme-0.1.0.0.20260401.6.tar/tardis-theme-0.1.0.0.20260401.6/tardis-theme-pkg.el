;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tardis-theme" "0.1.0.0.20260401.6"
  "Quantum Country Theme."
  '((emacs "25.1"))
  :url "https://github.com/antonhibl/tardis-theme"
  :commit "15deab6b9234eb5e44ac8ecce0d307effa19c970"
  :revdesc "15deab6b9234"
  :keywords '("convenience")
  :authors '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainers '(("Anton Hibl" . "antonhibl11@gmail.com")))
