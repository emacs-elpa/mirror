;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "2.4.0.20260723.2"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/osm"
  :commit "2041694815e9b143e7703513efd2a620e7d55080"
  :revdesc "2.4-2-g2041694815e9"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
