;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prism" "0.3.5.0.20241024.8"
  "Customizable, depth-based syntax coloring."
  '((emacs  "27.1")
    (compat "29.1.4.5")
    (dash   "2.14.1"))
  :url "https://github.com/alphapapa/prism.el"
  :commit "2fa8eb5a9ca62a548d33befef4517e5d0266eb28"
  :revdesc "v0.3.5-8-g2fa8eb5a9ca6"
  :keywords '("faces" "lisp")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
