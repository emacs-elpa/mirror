;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "desktop-environment" "0.5.0.0.20250821.29"
  "Helps you control your GNU/Linux computer."
  '((emacs "25.1"))
  :url "https://gitlab.petton.fr/DamienCassou/desktop-environment"
  :commit "1f16fa0fcc1b5b33773a8e334a60133a046e9fc7"
  :revdesc "1f16fa0fcc1b"
  :authors '(("Damien Cassou" . "damien@cassou.me")
             ("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")
                 ("Nicolas Petton" . "nicolas@petton.fr")))
