;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "api-credit" "1.1.2.0.20261030.1"
  "AI API balance in the modeline."
  '((emacs "25.1"))
  :url "https://github.com/OverbearingPearl/api-credit"
  :commit "eae6abab47c70c609bb6fd37251ee8a4667f044b"
  :revdesc "eae6abab47c7"
  :keywords '("comm" "convenience")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
