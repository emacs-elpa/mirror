;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eyebrowse-restore" "1.0.0.20240304.14"
  "Persistent Eyebrowse for all frames."
  '((emacs     "26.3")
    (eyebrowse "0.7.8")
    (dash      "2.19.1")
    (s         "1.13.0"))
  :url "https://github.com/FrostyX/eyebrowse-restore"
  :commit "abb3877e12b41740305741deec37ca681b896e82"
  :revdesc "abb3877e12b4"
  :keywords '("convenience" "eyebrowse" "helm" "persistent")
  :authors '(("Jakub Kadlčík" . "frostyx@email.cz"))
  :maintainers '(("Jakub Kadlčík" . "frostyx@email.cz")))
