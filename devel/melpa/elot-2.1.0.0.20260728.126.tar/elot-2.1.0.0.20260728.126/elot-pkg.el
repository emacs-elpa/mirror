;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elot" "2.1.0.0.20260728.126"
  "Emacs Literate Ontology Tool (ELOT)."
  '((emacs "30.1"))
  :url "https://github.com/johanwk/elot"
  :commit "17ec3c65c5c02c4dd25b6d7a1d34bf4fe257724e"
  :revdesc "v2.1.0-126-g17ec3c65c5c0"
  :keywords '("languages" "outlines" "tools" "org" "ontology")
  :authors '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com"))
  :maintainers '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com")))
