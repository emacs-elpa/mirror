;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "1.1.0.0.20260702.35"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.4.0")
    (vui    "1.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "5db5148108c56ec88a904e07760b67e78f0528e2"
  :revdesc "v1.1.0-35-g5db5148108c5"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
