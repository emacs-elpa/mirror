;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "0.18.0.0.20260701.14"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "49339c87d895d0726280811b325bb631f08aec69"
  :revdesc "v0.18.0-14-g49339c87d895"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
