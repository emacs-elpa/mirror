;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-search" "1.1.0.0.20230919.8"
  "Search Chinese by Pinyin."
  '((pinyinlib "0.1.0"))
  :url "https://github.com/xuchunyang/pinyin-search.el"
  :commit "3632bb98a5b8c0a396cd0a9d107e323e1ed3b7e7"
  :revdesc "3632bb98a5b8"
  :keywords '("chinese" "search")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
