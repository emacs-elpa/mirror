;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magma-mode" "0.0.0.20211018.404"
  "Mode for editing Magma source code."
  '((emacs  "24.3")
    (cl-lib "0.3")
    (dash   "2.6.0")
    (f      "0.17.1"))
  :url "https://github.com/ThibautVerron/magma-mode"
  :commit "11428d18ce3742334923d14ff2a8f493e7bd5ef0"
  :revdesc "11428d18ce37")
