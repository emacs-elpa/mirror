;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "4.0.9.0.20261105.9"
  "Development files for Helm."
  '((emacs "25.1")
    (async "2.0"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "2db8969b52fa316bc44da562317538a2eb7cfc5c"
  :revdesc "v4.0.9-9-g2db8969b52fa"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
