;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "powershell" "0.1.0.20251122.51"
  "Mode for editing PowerShell scripts."
  '((emacs "24.5"))
  :url "https://github.com/jschaf/powershell.el"
  :commit "ae60e11c96cc1767f05ce0cab6a917240ce2e37a"
  :revdesc "ae60e11c96cc"
  :keywords '("powershell" "languages")
  :authors '(("Frédéric Perrin" . "fredericperrinreselfr"))
  :maintainers '(("Juergen Hoetzel" . "juergen@hoetzel.info")))
