;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.4.0.0.20260901.51"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "f07a8f9b119b92110f30d81a14b36fb7a476020c"
  :revdesc "f07a8f9b119b"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
