;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "4.2.1.0.20260922.129"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "8af4db0f7ee63b9382c28f6db1f5b60e6203e0b3"
  :revdesc "8af4db0f7ee6"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
