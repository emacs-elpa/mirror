;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.2.0.20261017.10"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "29.1")
    (llm     "0.30.0")
    (vui     "20261017.1157"))
  :url "https://github.com/ahyatt/ekg"
  :commit "0efa71af9ccdf06d0e4e118c43c2708b5393c150"
  :revdesc "0efa71af9ccd"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
