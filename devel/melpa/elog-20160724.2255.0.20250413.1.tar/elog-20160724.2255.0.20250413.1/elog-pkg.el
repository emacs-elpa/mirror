;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elog" "20160724.2255.0.20250413.1"
  "Logging library extended from logito."
  '((emacs "23.2"))
  :url "https://github.com/lujun9972/elog"
  :commit "c65288fd32eb187d3e63d4a7799a69e57da0eab4"
  :revdesc "c65288fd32eb"
  :keywords '("lisp" "tool" "log")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
