;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "1.11.0.20260804.6"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "2fc993932d2df9270c3f85f8215f73600b78145c"
  :revdesc "2fc993932d2d"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
