;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wgsl-mode" "1.0.0.20231118.24"
  "Syntax highlighting for the WebGPU Shading Language."
  '((emacs "24"))
  :url "https://github.com/acowley/wgsl-mode"
  :commit "003a4e99491fa2a0b777f74658e6ffc70fd3a8c2"
  :revdesc "003a4e99491f"
  :keywords '("wgsl" "c"))
