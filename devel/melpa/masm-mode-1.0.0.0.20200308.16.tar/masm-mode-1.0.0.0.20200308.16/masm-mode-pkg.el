;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "masm-mode" "1.0.0.0.20200308.16"
  "MASM x86 and x64 assembly major mode."
  '((emacs "25.1"))
  :url "https://github.com/YiGeeker/masm-mode"
  :commit "ab63524d195332ec9f703783704231606e69c292"
  :revdesc "ab63524d1953"
  :keywords '("languages")
  :authors '(("YiGeeker" . "zyfchinese@yeah.net"))
  :maintainers '(("YiGeeker" . "zyfchinese@yeah.net")))
