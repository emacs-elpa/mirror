;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ag" "0.48.0.20201031.1"
  "A front-end for ag ('the silver searcher'), the C ack replacement."
  '((dash   "2.8.0")
    (s      "1.9.0")
    (cl-lib "0.5"))
  :url "https://github.com/Wilfred/ag.el"
  :commit "ed7e32064f92f1315cecbfc43f120bbc7508672c"
  :revdesc "0.48-1-ged7e32064f92"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
