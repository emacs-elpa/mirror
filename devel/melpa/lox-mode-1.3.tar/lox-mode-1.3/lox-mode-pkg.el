;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lox-mode" "1.3"
  "Major mode for the Lox programming language."
  '((emacs "24.3"))
  :url "https://github.com/timmyjose-projects/lox-mode"
  :commit "083a2299e188a516d1e46ef2dd1cbb89db1aec49"
  :revdesc "083a2299e188"
  :keywords '("languages" "lox")
  :authors '(("Timmy Jose" . "zoltan.jose@gmail.com"))
  :maintainers '(("Timmy Jose" . "zoltan.jose@gmail.com")))
