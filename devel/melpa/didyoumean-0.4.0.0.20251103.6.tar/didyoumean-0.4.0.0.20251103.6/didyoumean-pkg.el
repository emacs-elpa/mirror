;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "didyoumean" "0.4.0.0.20251103.6"
  "Did you mean to open another file?."
  '((emacs "24.4"))
  :url "https://gitlab.com/kisaragi-hiu/didyoumean.el"
  :commit "398fc3bf8ea520cd0517076bdc9b609cc6858c80"
  :revdesc "398fc3bf8ea5"
  :keywords '("convenience")
  :authors '(("Kisaragi Hiu" . "mail@kisaragi-hiu.com"))
  :maintainers '(("Kisaragi Hiu" . "mail@kisaragi-hiu.com")))
