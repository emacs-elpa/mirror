;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "0.18.0.0.20261022.71"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "7249ededfda01cf27fbb5188f0515ec4e26452c5"
  :revdesc "v0.18.0-71-g7249ededfda0"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
