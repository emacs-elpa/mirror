;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fyure" "0.0.1.0.20130216.1"
  "An interface to fix Japanese hyoki-yure."
  ()
  :url "https://github.com/mooz/fyure"
  :commit "b6977f1eb148e8b63259f7233b55bb050e44d9b8"
  :revdesc "b6977f1eb148"
  :keywords '("languages")
  :authors '(("Masafumi Oyamada" . "stillpedant@gmail.com"))
  :maintainers '(("Masafumi Oyamada" . "stillpedant@gmail.com")))
