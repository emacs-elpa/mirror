;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forest-blue-theme" "0.1.0.20160627.5"
  "Emacs theme with a dark background."
  '((emacs "24"))
  :url "https://github.com/olkinn/forest-blue-emacs"
  :commit "58096ce1a25615d2bae806c3775bae3e2775019d"
  :revdesc "58096ce1a256")
