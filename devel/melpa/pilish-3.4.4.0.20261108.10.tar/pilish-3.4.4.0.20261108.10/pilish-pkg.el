;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.4.4.0.20261108.10"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.5.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "ad21650836c68700091975d752bc174d3ad122d0"
  :revdesc "v3.4.4-10-gad21650836c6"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
