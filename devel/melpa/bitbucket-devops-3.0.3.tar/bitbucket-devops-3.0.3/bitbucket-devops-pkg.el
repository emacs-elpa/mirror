;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbucket-devops" "3.0.3"
  "Bitbucket Cloud DevOps workflows."
  '((emacs         "29.1")
    (magit         "4.0.0")
    (markdown-mode "2.6")
    (transient     "0.3.0")
    (yaml          "1.2.3"))
  :url "https://github.com/will-abb/bitbucket-devops.el"
  :commit "f0e3322a2db359b9e82e09f8f55490f251f5d122"
  :revdesc "v3.0.3-0-gf0e3322a2db3"
  :keywords '("tools" "vc")
  :authors '(("Will Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("Will Bosch-Bello" . "williamsbosch@gmail.com")))
