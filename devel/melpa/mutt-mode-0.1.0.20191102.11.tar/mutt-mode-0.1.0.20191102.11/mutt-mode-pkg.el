;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mutt-mode" "0.1.0.20191102.11"
  "Major mode for editing mutt configuration."
  '((emacs "24"))
  :url "https://gitlab.com/flexw/mutt-mode"
  :commit "1d495de49e6f536459b00d5396a2f5ce5ad4757b"
  :revdesc "1d495de49e6f"
  :keywords '("languages")
  :authors '(("Felix Weilbach" . "felix.weilbach@t-online.de"))
  :maintainers '(("Felix Weilbach" . "felix.weilbach@t-online.de")))
