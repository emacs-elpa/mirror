;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modular-config" "0.0.5.0.20210726.2"
  "Organize your config into small and loadable modules."
  '((emacs "25.1"))
  :url "https://github.com/SidharthArya/modular-config.el"
  :commit "043907d96efff70dfaea1e721de90bd35970e8bd"
  :revdesc "043907d96eff"
  :keywords '("startup" "lisp" "tools")
  :authors '(("Sidharth Arya" . "sidhartharya10@gmail.com"))
  :maintainers '(("Sidharth Arya" . "sidhartharya10@gmail.com")))
