;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fsharp-ts-mode" "0.1.0.0.20260624.50"
  "Major mode for F# code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/fsharp-ts-mode"
  :commit "a7a4f0612456e992c5e3420b3296ed2c1d3c472c"
  :revdesc "a7a4f0612456"
  :keywords '("languages" "fsharp")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
