;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scroll-on-jump" "0.3.0.20260730.3"
  "Scroll when jumping to a new point."
  '((emacs "26.2"))
  :url "https://codeberg.org/ideasman42/emacs-scroll-on-jump"
  :commit "4f903331db2c15fb4427ededca2d764d8f65db64"
  :revdesc "4f903331db2c"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
