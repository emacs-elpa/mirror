;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tuareg" "3.1.0.0.20260626.1"
  "OCaml mode."
  '((emacs "26.3"))
  :url "https://github.com/ocaml/tuareg"
  :commit "2d67d53a66fbf9d83c0416dba3275080b1bc6dfd"
  :revdesc "3.1.0-1-g2d67d53a66fb"
  :keywords '("ocaml" "languages")
  :authors '(("Albert Cohen" . "Albert.Cohen@inria.fr")
             ("Sam Steingold" . "sds@gnu.org")
             ("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
             ("Till Varoquaux" . "till@pps.jussieu.fr")
             ("Sean McLaughlin" . "seanmcl@gmail.com")
             ("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainers '(("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
                 ("Stefan Monnier" . "monnier@iro.umontreal.ca")))
