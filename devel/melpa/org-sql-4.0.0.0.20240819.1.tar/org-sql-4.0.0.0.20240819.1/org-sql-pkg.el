;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-sql" "4.0.0.0.20240819.1"
  "Org-Mode SQL converter."
  '((emacs  "27.1")
    (s      "1.13")
    (f      "0.20.0")
    (dash   "2.19.1")
    (org-ml "5.8.8"))
  :url "https://github.com/ndwarshuis/org-sql"
  :commit "3dbf11d692cf0d5e64235ad4041ed0b5a6775064"
  :revdesc "3dbf11d692cf"
  :keywords '("org-mode" "data")
  :authors '(("Nathan Dwarshuis" . "natedwarshuis@gmail.com"))
  :maintainers '(("Nathan Dwarshuis" . "natedwarshuis@gmail.com")))
