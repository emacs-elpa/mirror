;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "1.27.0.0.20260716.58"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "5c4ebd83871fcff28f9019d5e4309f61241e19e7"
  :revdesc "5c4ebd83871f"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
