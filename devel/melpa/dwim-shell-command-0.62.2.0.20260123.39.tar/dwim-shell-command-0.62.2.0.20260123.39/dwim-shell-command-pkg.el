;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwim-shell-command" "0.62.2.0.20260123.39"
  "Shell commands with DWIM behaviour."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/dwim-shell-command"
  :commit "a408b7826bb4535e7a14e16848ad41820d63411f"
  :revdesc "a408b7826bb4")
