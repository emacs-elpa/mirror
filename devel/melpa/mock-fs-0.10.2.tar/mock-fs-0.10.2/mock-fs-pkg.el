;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mock-fs" "0.10.2"
  "Virtual filesystem for Emacs Lisp tests."
  '((emacs "27.1"))
  :url "https://codeberg.org/Trevoke/mock-fs.el"
  :commit "b15c34281d076d6aa1ea5820368307694952e2ce"
  :revdesc "v0.10.2-0-gb15c34281d07"
  :keywords '("testing" "files"))
