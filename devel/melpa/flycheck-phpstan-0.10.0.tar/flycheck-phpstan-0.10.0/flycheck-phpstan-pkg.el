;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-phpstan" "0.10.0"
  "Flycheck integration for PHPStan."
  '((emacs    "27.1")
    (flycheck "26")
    (phpstan  "0.10.0"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "00942a5d5b28560bd08f7355d131074772bb7a01"
  :revdesc "00942a5d5b28"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
