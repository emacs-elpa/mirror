;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loophole" "0.8.3.0.20221126.29"
  "Manage temporary key bindings."
  '((emacs "27.1"))
  :url "https://github.com/0x60df/loophole"
  :commit "dadc3fadc68b13501c4dbe89109f30deb0d3441a"
  :revdesc "dadc3fadc68b"
  :keywords '("convenience")
  :authors '(("0x60DF" . "0x60df@gmail.com"))
  :maintainers '(("0x60DF" . "0x60df@gmail.com")))
