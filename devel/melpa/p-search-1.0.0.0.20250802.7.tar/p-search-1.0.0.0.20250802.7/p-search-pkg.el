;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "p-search" "1.0.0.0.20250802.7"
  "Local Search Engine for Emacs."
  '((emacs  "29.1")
    (compat "29.1"))
  :url "https://github.com/zkry/p-search"
  :commit "c382c80947a95825e258332d6f89bd6be496d914"
  :revdesc "c382c80947a9"
  :keywords '("tools"))
