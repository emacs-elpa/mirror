;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cort" "7.1.0.0.20261122.51"
  "Simplify extended unit test framework."
  '((emacs  "24.1")
    (ansi   "0.4.1")
    (cl-lib "0.7.1"))
  :url "https://github.com/conao3/cort.el"
  :commit "34c371cc275187a8343a8503d478b58dee8f47ad"
  :revdesc "34c371cc2751"
  :keywords '("test" "lisp")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
