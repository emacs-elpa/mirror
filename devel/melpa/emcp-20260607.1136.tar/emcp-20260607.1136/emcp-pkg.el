;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260607.1136"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.1.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "87706812c6cb1f90f751b0ebd5f13a602ba1d6ab"
  :revdesc "87706812c6cb"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
