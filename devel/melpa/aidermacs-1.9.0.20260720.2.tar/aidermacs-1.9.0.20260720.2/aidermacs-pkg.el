;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "1.9.0.20260720.2"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "3ce8b3c0f8e659d80d6acde4fd8f48fa6a6c0cac"
  :revdesc "3ce8b3c0f8e6"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
