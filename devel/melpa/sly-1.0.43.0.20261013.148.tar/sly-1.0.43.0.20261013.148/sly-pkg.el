;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "1.0.43.0.20261013.148"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.5"))
  :url "https://github.com/joaotavora/sly"
  :commit "9b3477a5dc6c9a4496d4fbb6804349961e861835"
  :revdesc "9b3477a5dc6c"
  :keywords '("languages" "lisp" "sly"))
