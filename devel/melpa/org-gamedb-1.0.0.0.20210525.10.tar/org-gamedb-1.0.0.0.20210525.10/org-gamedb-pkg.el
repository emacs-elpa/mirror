;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-gamedb" "1.0.0.0.20210525.10"
  "Track video games in org-mode with giantbomb.com's API."
  '((emacs "25.1"))
  :url "https://github.com/repelliuss/org-gamedb"
  :commit "f283b6f6a7e8ad090405be57202caa3d3c424447"
  :revdesc "f283b6f6a7e8"
  :keywords '("outlines" "org" "games" "convenience" "api")
  :authors '(("repelliuss" . "https://github.com/repelliuss"))
  :maintainers '(("repelliuss" . "repelliuss@gmail.com")))
