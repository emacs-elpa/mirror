;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bibliothek" "0.2.0.0.20190124.53"
  "Managing a digital library of PDFs."
  '((emacs     "24.4")
    (pdf-tools "0.70")
    (a         "0.1.0alpha4"))
  :url "https://dev.gkayaalp.com/elisp/index.html#bibliothek-el"
  :commit "b19b37be332bada6b18d4d895edf6ce78ab420c4"
  :revdesc "b19b37be332b"
  :keywords '("tools")
  :authors '(("Göktuğ Kayaalp" . "self@gkayaalp.com"))
  :maintainers '(("Göktuğ Kayaalp" . "self@gkayaalp.com")))
