;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "obsidian-theme" "0.1.0.20170719.13"
  "Port of the eclipse obsidian theme."
  ()
  :url "https://github.com/mswift42/obsidian-theme"
  :commit "f45efb2ebe9942466c1db6abbe2d0e6847b785ea"
  :revdesc "f45efb2ebe99")
