;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dianyou" "0.0.3.0.20210525.5"
  "Search and analyze mails in Gnus."
  '((emacs "24.4"))
  :url "https://github.com/redguardtoo/dianyou"
  :commit "f77d9e76be5d8022fa6ee5426144f13f38dd09f2"
  :revdesc "f77d9e76be5d"
  :keywords '("mail")
  :authors '(("Chen Bin" . "chenbinDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmailDOTcom")))
