;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-switch-shell" "1.0.0.20210713.24"
  "A Helm source for switching between shell buffers."
  '((emacs "25.1")
    (helm  "2.8.8"))
  :url "https://github.com/jamesnvc/helm-switch-shell"
  :commit "8d7ba1d99ff12a8f1d6ce3b9684ae8aebf494cf3"
  :revdesc "8d7ba1d99ff1"
  :keywords '("matching" "processes" "terminals" "tools")
  :authors '(("James N. V. Cash" . "james.cash@occasionallycogent.com"))
  :maintainers '(("James N. V. Cash" . "james.cash@occasionallycogent.com")))
