;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-clipmenu" "0.0.1.0.20220202.15"
  "Ivy client for clipmenu."
  '((emacs "26.1")
    (f     "0.20.0")
    (s     "1.12.0")
    (dash  "2.16.0")
    (ivy   "0.13.0"))
  :url "https://github.com/wpcarro/ivy-clipmenu.el"
  :commit "7c200cd4732821187084fad23547ee3f58365062"
  :revdesc "7c200cd47328"
  :authors '(("William Carroll" . "wpcarro@gmail.com"))
  :maintainers '(("William Carroll" . "wpcarro@gmail.com")))
