;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-json" "0.3.0.0.20260626.42"
  "JSON export backend for Org mode."
  '((emacs "26.1")
    (org   "9")
    (s     "1.12"))
  :url "https://github.com/jlumpe/ox-json"
  :commit "d47aa8cbe91c19627755f1a2ae2af389a508b6f4"
  :revdesc "d47aa8cbe91c"
  :keywords '("outlines")
  :authors '(("Jared Lumpe" . "jared@jaredlumpe.com"))
  :maintainers '(("Jared Lumpe" . "jared@jaredlumpe.com")))
