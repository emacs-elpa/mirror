;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.57.3.0.20260704.42"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "720cecd2ee51349a90595c0bf3296ec5b94396c7"
  :revdesc "720cecd2ee51")
