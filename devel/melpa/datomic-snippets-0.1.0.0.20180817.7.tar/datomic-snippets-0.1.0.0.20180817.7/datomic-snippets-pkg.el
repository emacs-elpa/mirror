;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "datomic-snippets" "0.1.0.0.20180817.7"
  "Yasnippets for Datomic."
  '((s         "1.4.0")
    (dash      "1.2.0")
    (yasnippet "0.6.1"))
  :url "https://github.com/magnars/datomic-snippets"
  :commit "4a14228840d5252e13d2bf6209670f26345bbb84"
  :revdesc "4a14228840d5"
  :keywords '("snippets")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
