;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-dim-other-buffers" "2.2.3.0.20260731.2"
  "Makes windows without focus less prominent."
  '((emacs "27.1"))
  :url "https://github.com/mina86/auto-dim-other-buffers.el"
  :commit "640a32f6ccdd9d93279342882be2389e1d3abd01"
  :revdesc "640a32f6ccdd"
  :keywords '("faces")
  :authors '(("Michal Nazarewicz" . "mina86@mina86.com"))
  :maintainers '(("Michal Nazarewicz" . "mina86@mina86.com")))
