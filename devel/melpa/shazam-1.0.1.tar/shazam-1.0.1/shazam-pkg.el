;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shazam" "1.0.1"
  "Shazam Interface (macOS only)."
  '((emacs "30.1"))
  :url "https://github.com/kickingvegas/shazam"
  :commit "0e5a97c59b5972a728138fc06b2ff371d42c8b55"
  :revdesc "0e5a97c59b59"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
