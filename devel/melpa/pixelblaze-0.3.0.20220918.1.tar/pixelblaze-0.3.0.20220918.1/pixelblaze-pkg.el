;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pixelblaze" "0.3.0.20220918.1"
  "Interact with a Pixelblaze via Websocket."
  '((emacs     "27.1")
    (websocket "1.13"))
  :url "https://github.com/mgsb/emacs-pixelblaze"
  :commit "564a093f700a3292cbffb3887dd3a8d789f54e6d"
  :revdesc "564a093f700a"
  :keywords '("games" "pixelblaze" "neopixel" "ws2812" "sk6812")
  :authors '(("Mark Grosen" . "mark@grosen.org"))
  :maintainers '(("Mark Grosen" . "mark@grosen.org")))
