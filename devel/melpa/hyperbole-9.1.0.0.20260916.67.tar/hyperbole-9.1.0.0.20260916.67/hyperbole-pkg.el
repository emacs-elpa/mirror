;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.1.0.0.20260916.67"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "2412b9ae68d0a9f2f70e3ad3f4c543cc07c332a4"
  :revdesc "2412b9ae68d0"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")
                 ("Mats Lidell" . "matsl@gnu.org")))
