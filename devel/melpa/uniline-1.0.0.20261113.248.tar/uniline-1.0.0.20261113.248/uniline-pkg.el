;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "1.0.0.20261113.248"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "6a9fd2f152ad69134de3048f9939fdda945c8275"
  :revdesc "6a9fd2f152ad"
  :keywords '("convenience" "text"))
