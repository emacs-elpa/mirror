;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moonscript" "0.0.0.20170831.39"
  "Major mode for editing MoonScript code."
  '((cl-lib "0.5")
    (emacs  "24"))
  :url "https://github.com/k2052/moonscript-mode"
  :commit "56f90471e2ced2b0a177aed4d8c2f854797e9cc7"
  :revdesc "56f90471e2ce"
  :authors '((nil . "@GriffinSchneider")
             (nil . "@k2052")
             (nil . "@EmacsFodder"))
  :maintainers '((nil . "@GriffinSchneider")
                 (nil . "@k2052")
                 (nil . "@EmacsFodder")))
