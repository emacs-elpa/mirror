;;; magent-agent-job.el --- Durable child-agent job state  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Jamie Cui
;; SPDX-License-Identifier: GPL-3.0-or-later
;; Assisted-by: Codex:GPT-5.6, Magent:deepseek-v4-pro

;; Author: Jamie Cui <jamie.cui@outlook.com>
;; Keywords: tools, ai

;;; Commentary:

;; Data structures for persistent child-agent jobs.  This is the
;; foundation for a Codex-style collaborative agent lifecycle; tool
;; handlers and UI integration are layered on top.

;;; Code:

(require 'cl-lib)
(require 'magent-config)
(require 'magent-json)

(defconst magent-agent-job-statuses
  '(queued running waiting completed failed closed cancelled)
  "Valid lifecycle statuses for a Magent child-agent job.")

(defvar magent-agent-job--last-id-stem nil
  "Timestamp stem used for the most recently generated agent job id.")

(defvar magent-agent-job--last-id-seq 0
  "Sequence number used when multiple agent jobs are created in one second.")

(defvar magent-agent-job--runtimes (make-hash-table :test #'equal)
  "Non-persistent live runtime state keyed by child-agent job id.")

(defvar magent-agent-job--observers (make-hash-table :test #'equal)
  "Status observers keyed by child-agent job id.")

(cl-defstruct (magent-agent-job
               (:constructor magent-agent-job--create)
               (:copier nil))
  id
  parent-session-id
  agent-name
  task-name
  status
  prompt
  created-at
  updated-at
  transcript
  result
  error
  metadata)

(defun magent-agent-job-status-p (status)
  "Return non-nil when STATUS is a valid agent job status."
  (memq status magent-agent-job-statuses))

(defun magent-agent-job--coerce-status (status)
  "Return STATUS as a valid status symbol, or signal an error."
  (let ((symbol (cond
                 ((null status) 'queued)
                 ((symbolp status) status)
                 ((stringp status) (intern status))
                 (t status))))
    (unless (magent-agent-job-status-p symbol)
      (error "Invalid agent job status: %S" status))
    symbol))

(defun magent-agent-job-generate-id ()
  "Generate a stable, human-readable child-agent job id."
  (let ((stem (format-time-string "agent-%Y%m%d-%H%M%S")))
    (if (equal stem magent-agent-job--last-id-stem)
        (cl-incf magent-agent-job--last-id-seq)
      (setq magent-agent-job--last-id-stem stem
            magent-agent-job--last-id-seq 0))
    (if (> magent-agent-job--last-id-seq 0)
        (format "%s-%d" stem magent-agent-job--last-id-seq)
      stem)))

(defun magent-agent-job-create (&rest args)
  "Create a `magent-agent-job' from keyword ARGS.
Recognized keys are `:id', `:parent-session-id', `:agent-name',
`:task-name', `:status', `:prompt', `:created-at', `:updated-at',
`:transcript', `:result', `:error', and `:metadata'."
  (let* ((now (float-time))
         (status (magent-agent-job--coerce-status
                  (plist-get args :status)))
         (created-at (or (plist-get args :created-at) now)))
    (magent-agent-job--create
     :id (or (plist-get args :id)
             (magent-agent-job-generate-id))
     :parent-session-id (plist-get args :parent-session-id)
     :agent-name (plist-get args :agent-name)
     :task-name (plist-get args :task-name)
     :status status
     :prompt (plist-get args :prompt)
     :created-at created-at
     :updated-at (or (plist-get args :updated-at) created-at)
     :transcript (plist-get args :transcript)
     :result (plist-get args :result)
     :error (plist-get args :error)
     :metadata (plist-get args :metadata))))

(defun magent-agent-job-set-status (job status &optional result error)
  "Set JOB to STATUS and optionally record RESULT or ERROR.
Return JOB."
  (let ((status (magent-agent-job--coerce-status status)))
    (setf (magent-agent-job-status job) status)
    (when (memq status '(queued running waiting))
      (setf (magent-agent-job-result job) nil
            (magent-agent-job-error job) nil)))
  (setf (magent-agent-job-updated-at job) (float-time))
  (when result
    (setf (magent-agent-job-result job) result))
  (when error
    (setf (magent-agent-job-error job) error))
  (dolist (entry (copy-sequence
                  (gethash (magent-agent-job-id job)
                           magent-agent-job--observers)))
    (condition-case observer-error
        (funcall (cdr entry) job)
      (error
       (message "Magent child-agent observer error: %s"
                (error-message-string observer-error)))))
  job)

(defun magent-agent-job-runtime (job-id)
  "Return live runtime state for child-agent JOB-ID."
  (gethash job-id magent-agent-job--runtimes))

(defun magent-agent-job-put-runtime (job-id runtime)
  "Store live RUNTIME for child-agent JOB-ID."
  (puthash job-id runtime magent-agent-job--runtimes)
  runtime)

(defun magent-agent-job-clear-runtime (job-id)
  "Remove live runtime state for child-agent JOB-ID."
  (remhash job-id magent-agent-job--runtimes))

(defun magent-agent-job-add-observer (job observer)
  "Observe JOB status changes with OBSERVER and return an opaque token."
  (let* ((job-id (magent-agent-job-id job))
         (token (cons job-id (gensym "magent-agent-job-observer-"))))
    (puthash job-id
             (cons (cons token observer)
                   (gethash job-id magent-agent-job--observers))
             magent-agent-job--observers)
    token))

(defun magent-agent-job-remove-observer (token)
  "Remove the child-agent status observer identified by TOKEN."
  (when (consp token)
    (let* ((job-id (car token))
           (remaining
            (cl-remove token
                       (gethash job-id magent-agent-job--observers)
                       :key #'car :test #'eq)))
      (if remaining
          (puthash job-id remaining magent-agent-job--observers)
        (remhash job-id magent-agent-job--observers))))
  nil)

(defun magent-agent-job-reconcile-after-restart (job &optional detail)
  "Cancel non-durable JOB state after an Emacs restart.
DETAIL defaults to a stable explanatory message.  Return non-nil when JOB
was changed."
  (when (memq (magent-agent-job-status job) '(queued running waiting))
    (magent-agent-job-set-status
     job 'cancelled nil (or detail "Interrupted by Emacs restart"))
    t))

(defun magent-agent-job-find (jobs id)
  "Return the job with ID from JOBS, or nil."
  (cl-find id jobs :key #'magent-agent-job-id :test #'equal))

(defun magent-agent-job--alist-get (key alist)
  "Return KEY from ALIST."
  (cdr (assq key alist)))

(defconst magent-agent-job--alist-keys
  '(id parent-session-id agent-name task-name status prompt created-at
       updated-at transcript result error metadata)
  "Fields in the current persisted child-agent job schema.")

(defun magent-agent-job-to-alist (job)
  "Convert JOB to a JSON-serializable alist."
  `((id . ,(magent-agent-job-id job))
    (parent-session-id . ,(magent-agent-job-parent-session-id job))
    (agent-name . ,(magent-agent-job-agent-name job))
    (task-name . ,(magent-agent-job-task-name job))
    (status . ,(symbol-name (magent-agent-job-status job)))
    (prompt . ,(magent-agent-job-prompt job))
    (created-at . ,(magent-agent-job-created-at job))
    (updated-at . ,(magent-agent-job-updated-at job))
    (transcript . ,(vconcat
                    (mapcar #'magent-json-safe-value
                            (or (magent-agent-job-transcript job) nil))))
    (result . ,(let ((result (magent-agent-job-result job)))
                 (and result (magent-json-safe-value result))))
    (error . ,(let ((error (magent-agent-job-error job)))
                (and error (magent-json-safe-value error))))
    (metadata . ,(let ((metadata (magent-agent-job-metadata job)))
                   (and metadata (magent-json-safe-value metadata))))))

(defun magent-agent-job-from-alist (alist)
  "Create a `magent-agent-job' from JSON-decoded ALIST."
  (unless (and (listp alist) (cl-every #'consp alist))
    (error "Invalid child-agent job object: expected an alist"))
  (let ((actual (mapcar #'car alist)))
    (unless (and (= (length actual) (length magent-agent-job--alist-keys))
                 (null (cl-set-exclusive-or
                        actual magent-agent-job--alist-keys :test #'eq)))
      (error "Invalid child-agent job fields: expected %S, got %S"
             magent-agent-job--alist-keys actual)))
  (dolist (key '(id status created-at updated-at))
    (unless (magent-agent-job--alist-get key alist)
      (error "Invalid child-agent job: required field %s is empty" key)))
  (magent-agent-job-create
   :id (magent-agent-job--alist-get 'id alist)
   :parent-session-id (magent-agent-job--alist-get 'parent-session-id alist)
   :agent-name (magent-agent-job--alist-get 'agent-name alist)
   :task-name (magent-agent-job--alist-get 'task-name alist)
   :status (magent-agent-job--alist-get 'status alist)
   :prompt (magent-agent-job--alist-get 'prompt alist)
   :created-at (magent-agent-job--alist-get 'created-at alist)
   :updated-at (magent-agent-job--alist-get 'updated-at alist)
   :transcript (magent-agent-job--alist-get 'transcript alist)
   :result (magent-agent-job--alist-get 'result alist)
   :error (magent-agent-job--alist-get 'error alist)
   :metadata (magent-agent-job--alist-get 'metadata alist)))

(provide 'magent-agent-job)
;;; magent-agent-job.el ends here
