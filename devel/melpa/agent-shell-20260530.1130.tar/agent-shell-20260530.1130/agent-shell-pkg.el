;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260530.1130"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "aa54cbd0fd8cc32e002fa46d572af50cce074cc3"
  :revdesc "aa54cbd0fd8c")
