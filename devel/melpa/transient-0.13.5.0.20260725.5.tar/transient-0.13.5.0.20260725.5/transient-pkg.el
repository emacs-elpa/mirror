;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "0.13.5.0.20260725.5"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "91c25496972566d6b1b4411c1bb7a7e669355a4c"
  :revdesc "v0.13.5-5-g91c254969725"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
