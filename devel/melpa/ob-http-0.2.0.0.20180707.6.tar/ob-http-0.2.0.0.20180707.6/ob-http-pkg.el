;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-http" "0.2.0.0.20180707.6"
  "Http request in org-mode babel."
  '((s      "1.9.0")
    (cl-lib "0.5"))
  :url "https://github.com/zweifisch/ob-http"
  :commit "b1428ea2a63bcb510e7382a1bf5fe82b19c104a7"
  :revdesc "b1428ea2a63b"
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
