;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "date2name" "0.0.1.0.20190630.15"
  "Package to prepend ISO Timestamps to files."
  '((emacs "24.4"))
  :url "https://github.com/DerBeutlin/date2name.el"
  :commit "1d239e4d647ad8ba5cd23a8d4012a9f10bcf7d7d"
  :revdesc "1d239e4d647a"
  :keywords '("files" "convenience"))
