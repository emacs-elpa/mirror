;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pungi" "1.1"
  "Integrates jedi with virtualenv and buildout python environments."
  '((jedi   "0.2.0alpha2")
    (pyvenv "1.5"))
  :url "https://github.com/mgrbyte/pungi"
  :commit "41c9f8b7795e083bfd63ba0d06c789c250998723"
  :revdesc "1.1-0-g41c9f8b7795e"
  :keywords '("convenience")
  :authors '(("Matthew Russell" . "matthew.russell@horizon5.org"))
  :maintainers '(("Matthew Russell" . "matthew.russell@horizon5.org")))
