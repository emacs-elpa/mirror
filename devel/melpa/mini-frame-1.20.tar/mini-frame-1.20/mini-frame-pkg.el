;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mini-frame" "1.20"
  "Show minibuffer in child frame on read-from-minibuffer."
  '((emacs "26.1"))
  :url "https://github.com/muffinmad/emacs-mini-frame"
  :commit "066af90bb2c9a52ff0bfbcdb25539e1b92b68586"
  :revdesc "066af90bb2c9"
  :keywords '("frames")
  :authors '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com"))
  :maintainers '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com")))
