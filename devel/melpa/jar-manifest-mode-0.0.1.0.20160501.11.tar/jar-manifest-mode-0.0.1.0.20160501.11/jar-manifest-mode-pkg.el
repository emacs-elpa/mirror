;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jar-manifest-mode" "0.0.1.0.20160501.11"
  "Major mode to edit JAR manifest files."
  ()
  :url "https://github.com/omajid/jar-manifest-mode"
  :commit "270dae14c481300f75ed96dad3a5ae42ca928a1d"
  :revdesc "270dae14c481"
  :keywords '("convenience" "languages")
  :authors '(("Omair Majid" . "omair.majid@gmail.com"))
  :maintainers '(("Omair Majid" . "omair.majid@gmail.com")))
