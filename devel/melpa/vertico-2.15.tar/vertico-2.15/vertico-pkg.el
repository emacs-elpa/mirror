;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "2.15"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "a9998a777f1d92348f84d091bb15b87df933a7a2"
  :revdesc "2.15-0-ga9998a777f1d"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
