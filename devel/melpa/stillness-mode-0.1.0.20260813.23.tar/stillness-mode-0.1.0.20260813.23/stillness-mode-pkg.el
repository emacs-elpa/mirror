;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stillness-mode" "0.1.0.20260813.23"
  "Prevent windows from jumping on minibuffer activation."
  '((emacs "26.1")
    (dash  "2.18.0"))
  :url "https://github.com/neeasade/stillness-mode.el"
  :commit "91ef22692967ab2099d2fa87313976bffa6afe66"
  :revdesc "91ef22692967"
  :keywords '("convenience"))
