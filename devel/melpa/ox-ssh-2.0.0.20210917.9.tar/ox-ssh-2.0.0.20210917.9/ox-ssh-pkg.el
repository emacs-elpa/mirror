;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-ssh" "2.0.0.20210917.9"
  "SSH Config Backend for Org Export Engine."
  '((emacs "24.4"))
  :url "https://github.com/dantecatalfamo/ox-ssh"
  :commit "be3b39160da6ae37b1f1cd175ed854ac41d1cb63"
  :revdesc "be3b39160da6"
  :keywords '("outlines" "org" "ssh"))
