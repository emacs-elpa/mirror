;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "foreman-mode" "0.0.1.0.20170725.4"
  "View and manage Procfile-based applications."
  '((s               "1.9.0")
    (dash            "2.10.0")
    (dash-functional "1.2.0")
    (f               "0.17.2")
    (emacs           "24"))
  :url "https://github.com/zweifisch/foreman-mode"
  :commit "22b3bb13134b617870ed1e888af739f4818be929"
  :revdesc "22b3bb13134b"
  :keywords '("foreman")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
