;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "0.7.0.0.20260724.2"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3"))
  :url "https://codeberg.org/guix/emacs-guix"
  :commit "addac35e3fcb7a812b239c4aa76eada1743d0921"
  :revdesc "v0.7.0-2-gaddac35e3fcb"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
