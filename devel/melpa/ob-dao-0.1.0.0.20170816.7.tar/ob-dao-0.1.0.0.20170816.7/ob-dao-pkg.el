;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-dao" "0.1.0.0.20170816.7"
  "Org Babel Functions for Dao."
  '((org "8"))
  :url "https://github.com/xuchunyang/ob-dao"
  :commit "8c62bd800b1f572860e30be4b72c71fa415a2e31"
  :revdesc "8c62bd800b1f"
  :keywords '("literate programming" "reproducible research" "org" "babel" "dao")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
