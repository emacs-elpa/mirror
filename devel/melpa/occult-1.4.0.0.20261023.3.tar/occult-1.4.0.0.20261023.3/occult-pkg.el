;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occult" "1.4.0.0.20261023.3"
  "Collapse and reveal buffer regions."
  '((emacs "29.1"))
  :url "https://github.com/agzam/occult.el"
  :commit "5a3364d5addeef21ca68964e677fdf8f8b0314be"
  :revdesc "1.4.0-3-g5a3364d5adde"
  :keywords '("convenience")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
