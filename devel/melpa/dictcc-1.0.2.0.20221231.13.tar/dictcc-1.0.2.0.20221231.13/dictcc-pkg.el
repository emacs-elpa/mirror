;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dictcc" "1.0.2.0.20221231.13"
  "Look up translations on dict.cc."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/martenlienen/dictcc.el"
  :commit "30b505759e5a97c2aaa8b0e8ea5e187fdf625c65"
  :revdesc "30b505759e5a"
  :keywords '("convenience")
  :authors '(("Marten Lienen" . "marten.lienen@gmail.com"))
  :maintainers '(("Marten Lienen" . "marten.lienen@gmail.com")))
