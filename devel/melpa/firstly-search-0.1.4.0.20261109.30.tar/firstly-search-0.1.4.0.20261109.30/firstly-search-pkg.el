;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "0.1.4.0.20261109.30"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "27f9401b40fd6a68aec0fe2934948c69dec58c21"
  :revdesc "27f9401b40fd"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
