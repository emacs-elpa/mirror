;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ancient-theme" "1.0.0.0.20260322.15"
  "A theme about ruins."
  '((emacs "29.1"))
  :url "https://github.com/thomasbestvina/ancient-theme"
  :commit "6b5c5a016a8460739215aac8eeb16be9fa357b4e"
  :revdesc "6b5c5a016a84"
  :keywords '("faces" "theme")
  :authors '(("Thomas Bestvina" . "bestvinathomas@gmail.com"))
  :maintainers '(("Thomas Bestvina" . "bestvinathomas@gmail.com")))
