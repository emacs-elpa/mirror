;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redshank" "0.0.0.20180730.77"
  "Common Lisp Editing Extensions."
  '((paredit "21"))
  :url "https://github.com/emacsattic/redshank"
  :commit "d059c5841044aa163664f8bf87c1d981bf0a04fe"
  :revdesc "d059c5841044"
  :keywords '("languages" "lisp")
  :authors '(("Michael Weber" . "michaelw@foldr.org"))
  :maintainers '(("Michael Weber" . "michaelw@foldr.org")))
