;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rom-party" "0.1.0.0.20250627.35"
  "Rendition of jklm.fun's \"Bomb Party\" game."
  '((emacs  "28")
    (dash   "2.17.0")
    (f      "0.2.0")
    (s      "1.12.0")
    (ht     "2.3")
    (extmap "1.3")
    (compat "29.1.4.4")
    (async  "1.9.7"))
  :url "https://github.com/LaurenceWarne/rom-party.el"
  :commit "3664be5a15431c54f1bf04d2597ca546956edb6f"
  :revdesc "0.1.0-35-g3664be5a1543")
