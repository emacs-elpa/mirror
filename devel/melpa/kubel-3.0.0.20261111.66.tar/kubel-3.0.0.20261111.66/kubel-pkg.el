;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel" "3.0.0.20261111.66"
  "Control Kubernetes with limited permissions."
  '((transient "0.1.0")
    (emacs     "25.3")
    (dash      "2.12.0")
    (s         "1.2.0")
    (yaml-mode "0.0.14"))
  :url "https://github.com/abrochard/kubel"
  :commit "fdb90f6e4fad8e0d460c8cb9417bdc6e2b8ff30f"
  :revdesc "fdb90f6e4fad"
  :keywords '("kubernetes" "k8s" "tools" "processes"))
