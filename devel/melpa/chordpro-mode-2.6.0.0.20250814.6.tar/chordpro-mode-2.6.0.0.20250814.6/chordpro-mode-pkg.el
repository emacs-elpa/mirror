;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chordpro-mode" "2.6.0.0.20250814.6"
  "Major mode for ChordPro lead sheet file format."
  '((emacs  "29.1")
    (compat "29.1.4.1"))
  :url "https://git.sr.ht/~breatheoutbreathein/chordpro-mode.el/"
  :commit "ae6db74f2078e4ee3d6262ac1344df9c1ab87527"
  :revdesc "2.6.0-6-gae6db74f2078"
  :keywords '("convenience")
  :authors '(("Howard Ding" . "hading2@gmail.com"))
  :maintainers '(("Howard Ding" . "hading2@gmail.com")))
