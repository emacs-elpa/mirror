;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "1.0.5.0.20260621.79"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "fb0b04fe6c6c46ad59f8691668339f53c6d9da57"
  :revdesc "cfn-mode/v1.0.5-79-gfb0b04fe6c6c"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
