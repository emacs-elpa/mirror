;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php" "2.8.3.0.20261105.2"
  "Auto Completion source for PHP."
  '((ac-php-core   "2.0")
    (auto-complete "1.4.0")
    (yasnippet     "0.8.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "bb0911bd0edfb5fdf6d685dd520510379572c304"
  :revdesc "v2.8.3-2-gbb0911bd0edf"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
