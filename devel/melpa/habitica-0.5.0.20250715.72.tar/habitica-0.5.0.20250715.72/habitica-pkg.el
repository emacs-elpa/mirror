;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "habitica" "0.5.0.20250715.72"
  "Interface for habitica.com."
  '((org   "8.3.5")
    (emacs "24.3"))
  :url "https://github.com/abrochard/emacs-habitica"
  :commit "de82cd5a1283ae4035602a86b2c92dd23d467ccf"
  :revdesc "de82cd5a1283"
  :keywords '("habitica" "todo"))
