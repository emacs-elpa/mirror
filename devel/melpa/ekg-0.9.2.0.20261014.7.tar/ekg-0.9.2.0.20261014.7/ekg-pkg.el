;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.2.0.20261014.7"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "93387bbaf42cd891d075b967b46f7334a967b4f9"
  :revdesc "93387bbaf42c"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
