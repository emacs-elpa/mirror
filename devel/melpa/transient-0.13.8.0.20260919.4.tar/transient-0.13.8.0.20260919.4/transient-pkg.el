;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "0.13.8.0.20260919.4"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "c713048f3708139b34018746a59fbc886d2c8d02"
  :revdesc "v0.13.8-4-gc713048f3708"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
