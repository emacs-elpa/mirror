;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elot" "2.1.0.0.20260804.131"
  "Emacs Literate Ontology Tool (ELOT)."
  '((emacs "30.1"))
  :url "https://github.com/johanwk/elot"
  :commit "1c94cb4e961cbb1d79879d30f5ced6fd86945237"
  :revdesc "v2.1.0-131-g1c94cb4e961c"
  :keywords '("languages" "outlines" "tools" "org" "ontology")
  :authors '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com"))
  :maintainers '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com")))
