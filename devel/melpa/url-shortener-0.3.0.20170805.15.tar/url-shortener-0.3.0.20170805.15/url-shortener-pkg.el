;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "url-shortener" "0.3.0.20170805.15"
  "Shorten long url and expand tinyurl."
  ()
  :url "https://github.com/yuyang0/url-shortener"
  :commit "06db8270213b9e352d6c335b0663059a1353d05e"
  :revdesc "06db8270213b"
  :authors '(("Yu Yang" . "yy2012cn@NOSPAM.gmail.com"))
  :maintainers '(("Yu Yang" . "yy2012cn@NOSPAM.gmail.com")))
