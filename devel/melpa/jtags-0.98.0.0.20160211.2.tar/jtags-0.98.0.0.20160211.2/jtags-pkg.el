;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jtags" "0.98.0.0.20160211.2"
  "Enhanced tags functionality for Java development."
  ()
  :url "http://jtags.sourceforge.net"
  :commit "f7d29e1635ef7ee4ee2cdb8f1f6ab83e1015c84a"
  :revdesc "f7d29e1635ef"
  :keywords '("languages" "tools")
  :authors '(("Alexander Baltatzis" . "alexander@baltatzis.com")
             ("Johan Dykstrom" . "jody4711-sf@yahoo.se"))
  :maintainers '(("Johan Dykstrom" . "jody4711-sf@yahoo.se")))
