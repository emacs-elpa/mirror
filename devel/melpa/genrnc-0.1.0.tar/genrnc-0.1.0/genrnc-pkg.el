;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "genrnc" "0.1.0"
  "Generate RELAX NG Compact Schema from RELAX NG Schema, XML Schema and DTD."
  '((deferred   "0.3.1")
    (concurrent "0.3")
    (log4e      "0.2.0")
    (yaxception "0.1"))
  :url "https://github.com/aki2o/emacs-genrnc"
  :commit "da75b1966a73ad215ec2ced4522c25f4d0bf1f9a"
  :revdesc "da75b1966a73"
  :keywords '("xml")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
