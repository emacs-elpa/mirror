;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "searchq" "20150224.1800.0.20150829.15"
  "Framework of queued search tasks using GREP, ACK, AG and more."
  '((emacs "24.3"))
  :url "https://github.com/tcw165/searchq"
  :commit "dd510d55ad66a82c6ef022cfe7c4a73ad5365f82"
  :revdesc "dd510d55ad66")
