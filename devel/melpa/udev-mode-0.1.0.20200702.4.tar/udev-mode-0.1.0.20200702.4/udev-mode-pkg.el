;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "udev-mode" "0.1.0.20200702.4"
  "Major mode for editing udev rules files."
  '((emacs "24"))
  :url "https://github.com/benley/emacs-udev-mode"
  :commit "5ca236980662141518603672ebdbdf863756da5a"
  :revdesc "5ca236980662"
  :keywords '("languages" "unix")
  :authors '(("Benjamin Staffin" . "benley@gmail.com"))
  :maintainers '(("Benjamin Staffin" . "benley@gmail.com")))
