;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "say-what-im-doing" "0.2.0.20160706.2"
  "Dictate what you're doing with text to speech."
  ()
  :url "https://github.com/benaiah/say-what-im-doing"
  :commit "5b2ce6783b02805bcac1107a149bfba3852cd9d5"
  :revdesc "5b2ce6783b02"
  :keywords '("text to speech" "dumb" "funny"))
