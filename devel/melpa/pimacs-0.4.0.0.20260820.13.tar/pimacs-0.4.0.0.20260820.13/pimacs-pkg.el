;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.4.0.0.20260820.13"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "a293a69996b183f9c3f55d54855dfd1e7086b3ec"
  :revdesc "a293a69996b1"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
