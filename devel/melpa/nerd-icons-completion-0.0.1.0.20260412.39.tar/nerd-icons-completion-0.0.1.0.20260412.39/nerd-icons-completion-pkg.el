;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons-completion" "0.0.1.0.20260412.39"
  "Add icons to completion candidates."
  '((emacs      "25.1")
    (nerd-icons "0.0.1")
    (compat     "30"))
  :url "https://github.com/rainstormstudio/nerd-icons-completion"
  :commit "45b585d972192a3eaeb239e15e55de7f46f8920a"
  :revdesc "45b585d97219"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")))
