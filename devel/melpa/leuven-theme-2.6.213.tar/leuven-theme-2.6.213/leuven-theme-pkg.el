;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leuven-theme" "2.6.213"
  "Elegant Emacs color theme for a white background."
  ()
  :url "https://github.com/fniessen/emacs-leuven-theme"
  :commit "c3546e6a84c138fd8cdbd33998fefcf834c45018"
  :revdesc "c3546e6a84c1"
  :keywords '("color" "theme")
  :authors '(("Fabrice Niessen" . ""))
  :maintainers '(("Fabrice Niessen" . "")))
