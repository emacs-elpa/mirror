;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "2.8.0"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (md-ts-mode          "0.3.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "1824dad6178548daf15286b0b0dc4430ede67c32"
  :revdesc "v2.8.0-0-g1824dad61785"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
