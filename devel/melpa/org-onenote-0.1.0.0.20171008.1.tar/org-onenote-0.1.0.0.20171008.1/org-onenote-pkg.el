;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-onenote" "0.1.0.0.20171008.1"
  "Export org-mode document to onenote."
  '((oauth2  "0.11")
    (request "0.2.0")
    (org     "8.2.10"))
  :url "https://github.com/ifree/org-onenote"
  :commit "5ce5cf4edb143180e0b185ac26826d39ae5bc929"
  :revdesc "5ce5cf4edb14"
  :keywords '("tools" "docs" "org-mode" "onenote")
  :authors '(("Frei Zhang" . "ifree0@gmail.com"))
  :maintainers '(("Frei Zhang" . "ifree0@gmail.com")))
