;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsonl" "0.0.1.0.20190623.3"
  "Utility functions for working with line-delimited JSON."
  '((emacs "25"))
  :url "https://github.com/ebpa/jsonl.el"
  :commit "3dd0b7bb2b4bce9f9de7367941f0cc78f82049c9"
  :revdesc "3dd0b7bb2b4b"
  :keywords '("tools")
  :authors '(("Erik Anderson" . "erik@ebpa.link"))
  :maintainers '(("Erik Anderson" . "erik@ebpa.link")))
