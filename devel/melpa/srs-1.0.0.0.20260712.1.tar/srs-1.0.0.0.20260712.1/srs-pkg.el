;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "1.0.0.0.20260712.1"
  "Spaced repetition in plain text."
  '((emacs     "30.2")
    (transient "0.12.0"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "dd90d0948818e2a783aca4900ac95b84bd3f9d99"
  :revdesc "dd90d0948818"
  :keywords '("hypermedia" "srs" "memory")
  :authors '(("Duncan Britt" . "duncanbritt.com"))
  :maintainers '(("Duncan Britt" . "duncanbritt.com")))
