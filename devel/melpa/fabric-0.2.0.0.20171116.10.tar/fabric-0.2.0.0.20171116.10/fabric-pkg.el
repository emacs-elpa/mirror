;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fabric" "0.2.0.0.20171116.10"
  "Launch Fabric using Emacs."
  ()
  :url "https://github.com/nlamirault/fabric.el"
  :commit "df79be341d0b34ed23850f9894136092fa5fea8c"
  :revdesc "0.2.0-10-gdf79be341d0b"
  :keywords '("python" "fabric")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@chmouel.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@chmouel.com")))
