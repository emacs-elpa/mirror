;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nonogram" "1.0.0.0.20260909.10"
  "Play nonogram (picross) puzzles with SVG graphics."
  '((emacs "27.1"))
  :url "https://git.andros.dev/andros/nonogram.el"
  :commit "b72785e325d4ad1f61bc2c49e24e8e5bc5e16305"
  :revdesc "b72785e325d4"
  :keywords '("games")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
