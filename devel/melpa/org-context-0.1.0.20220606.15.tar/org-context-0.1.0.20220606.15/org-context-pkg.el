;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-context" "0.1.0.20220606.15"
  "Contextual capture and agenda commands for Org-mode."
  ()
  :url "https://github.com/thisirs/org-context"
  :commit "47bd45149cb74dab2ebecccfb918f6f8502a4f2c"
  :revdesc "47bd45149cb7"
  :keywords '("org" "capture" "agenda" "convenience")
  :authors '(("Sylvain Rousseau" . "thisirsatgmaildotcom"))
  :maintainers '(("Sylvain Rousseau" . "thisirsatgmaildotcom")))
