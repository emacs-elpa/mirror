;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dfmt" "0.1.0.0.20170728.19"
  "Emacs Interface to D indenting/formatting tool dfmt."
  ()
  :url "https://github.com/qsimpleq/elisp-dfmt"
  :commit "21b9094e907b7ac53f5ecb4ff4539613a9d12434"
  :revdesc "21b9094e907b"
  :keywords '("tools" "convenience" "languages" "dlang")
  :maintainers '(("Kirill Babikhin" . "qsimpleq")))
