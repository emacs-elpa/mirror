;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wordreference" "0.2.0.20260509.182"
  "Interface for wordreference.com."
  '((emacs "28.1"))
  :url "https://codeberg.org/martianh/wordreference.el"
  :commit "6b1e321ec48ae6eadc06ed25f018c384e396644b"
  :revdesc "6b1e321ec48a"
  :keywords '("convenience" "translate" "wp" "dictionary")
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
