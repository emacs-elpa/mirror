;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pest-mode" "0.1.0.0.20221231.4"
  "Major mode for editing Pest files."
  '((emacs "26.3"))
  :url "https://github.com/ksqsf/pest-mode"
  :commit "8023a92ce59c34dcd1587cbd85ed144f206ddb89"
  :revdesc "v0.1.0-4-g8023a92ce59c"
  :keywords '("languages")
  :authors '(("ksqsf" . "i@ksqsf.moe"))
  :maintainers '(("ksqsf" . "i@ksqsf.moe")))
