;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-screen" "0.0.0.20241228.21"
  "Simple screen configuration manager."
  ()
  :url "https://github.com/wachikun/simple-screen"
  :commit "66eb5ddab259025ef5790084ca33018c266d6940"
  :revdesc "66eb5ddab259"
  :keywords '("tools")
  :authors '(("Tadashi Watanabe" . "wac@umiushi.org"))
  :maintainers '(("Tadashi Watanabe" . "wac@umiushi.org")))
