;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "figlet" "0.5.0.20160218.6"
  "Annoy people with big, ascii art text."
  ()
  :url "https://github.com/jpkotta/figlet"
  :commit "19a38783a90e151faf047ff233a21a729db0cea9"
  :revdesc "19a38783a90e"
  :authors '(("Philip Jackson" . "phil@shellarchive.co.uk"))
  :maintainers '(("Philip Jackson" . "phil@shellarchive.co.uk")))
