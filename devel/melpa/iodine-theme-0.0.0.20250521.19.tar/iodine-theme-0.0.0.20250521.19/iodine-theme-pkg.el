;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iodine-theme" "0.0.0.20250521.19"
  "A light emacs color theme."
  '((emacs "24"))
  :url "https://github.com/srdja/iodine-theme"
  :commit "305691881ddf9ba0ad698979f133394bd132f180"
  :revdesc "305691881ddf"
  :keywords '("themes")
  :authors '(("Srđan Panić" . "srdja.panic@gmail.com"))
  :maintainers '(("Srđan Panić" . "srdja.panic@gmail.com")))
