;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noir-ts-mode" "1.0.1"
  "Tree-sitter support for Noir."
  '((emacs "29.1"))
  :url "https://github.com/hhamud/noir-ts-mode"
  :commit "64af37811e0ab91ab1bc333d0961e15b66356944"
  :revdesc "v1.0.1-0-g64af37811e0a"
  :keywords '("noir" "languages" "tree-sitter")
  :authors '(("Hamza Hamud" . "self@hamzahamud.com"))
  :maintainers '(("Hamza Hamud" . "self@hamzahamud.com")))
