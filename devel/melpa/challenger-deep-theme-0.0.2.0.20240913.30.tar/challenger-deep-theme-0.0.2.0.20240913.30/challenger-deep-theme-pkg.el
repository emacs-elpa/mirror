;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "challenger-deep-theme" "0.0.2.0.20240913.30"
  "Challenger-deep Theme."
  '((emacs "24"))
  :url "https://github.com/challenger-deep-theme/emacs"
  :commit "8f688eda0d9b138e41e21d2ca246c89c3547002f"
  :revdesc "8f688eda0d9b")
