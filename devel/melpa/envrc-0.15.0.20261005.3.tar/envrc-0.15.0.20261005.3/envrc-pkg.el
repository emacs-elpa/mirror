;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "0.15.0.20261005.3"
  "Buffer-local `direnv' support with choice of sync/async."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "ab2853255e376719778ff94d8b718a37cf3e719a"
  :revdesc "ab2853255e37"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
