;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ptemplate" "2.5.1.0.20210324.4"
  "Project templates."
  '((emacs     "25.1")
    (yasnippet "0.13.0"))
  :url "https://github.com/nbfalcon/ptemplate"
  :commit "b81cc7be8865745c3a60177a244d2a69729ab21b"
  :revdesc "b81cc7be8865"
  :authors '(("Nikita Bloshchanevich" . "nikblos@outlook.com"))
  :maintainers '(("Nikita Bloshchanevich" . "nikblos@outlook.com")))
