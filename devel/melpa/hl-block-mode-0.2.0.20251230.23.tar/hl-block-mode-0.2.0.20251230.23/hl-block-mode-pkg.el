;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-block-mode" "0.2.0.20251230.23"
  "Highlighting nested blocks."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-block-mode"
  :commit "8f66a89196dec2f9b5f9a58b769e64c190493064"
  :revdesc "8f66a89196de"
  :keywords '("convenience" "faces")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
