;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "1.3.0.0.20260916.4"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "c8a4a43f3106ca667e03439301181c2b887996bc"
  :revdesc "1.3.0-4-gc8a4a43f3106"
  :keywords '("convenience" "frames" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
