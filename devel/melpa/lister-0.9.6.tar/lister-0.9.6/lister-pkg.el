;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lister" "0.9.6"
  "Yet another list printer."
  '((emacs "26.1"))
  :url "https://github.com/publicimageltd/lister"
  :commit "84fbba7450ac02cbb844727a28b6f245f553df7b"
  :revdesc "84fbba7450ac"
  :keywords '("lisp")
  :authors '((nil . "joerg@joergvolbers.de"))
  :maintainers '((nil . "joerg@joergvolbers.de")))
