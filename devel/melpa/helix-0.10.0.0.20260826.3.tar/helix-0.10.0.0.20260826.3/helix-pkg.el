;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "0.10.0.0.20260826.3"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "4a8aeafa5ca43c68dcd2a23a1906e0a4221fe35d"
  :revdesc "4a8aeafa5ca4"
  :keywords '("convenience"))
