;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hass" "3.0.2.0.20230529.11"
  "Interact with Home Assistant."
  '((emacs     "25.1")
    (request   "0.3.3")
    (websocket "1.13"))
  :url "https://github.com/purplg/hass"
  :commit "4c9da37c5217177d43dbd2cb9cd458c01b834c54"
  :revdesc "4c9da37c5217")
