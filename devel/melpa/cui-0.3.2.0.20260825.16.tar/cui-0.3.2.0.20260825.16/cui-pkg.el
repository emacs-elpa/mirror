;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "0.3.2.0.20260825.16"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "bba8d2c3821138452f3e404d3769e8b4a2b715e7"
  :revdesc "bba8d2c38211"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
