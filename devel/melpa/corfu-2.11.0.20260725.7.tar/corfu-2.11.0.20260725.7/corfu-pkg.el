;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.11.0.20260725.7"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "8b8e99148f9ef6b75034a1cf5cc78bac0c521a93"
  :revdesc "2.11-7-g8b8e99148f9e"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
