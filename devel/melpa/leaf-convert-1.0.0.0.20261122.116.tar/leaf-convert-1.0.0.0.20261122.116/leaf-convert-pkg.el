;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-convert" "1.0.0.0.20261122.116"
  "Convert many format to leaf format."
  '((emacs         "26.1")
    (leaf          "4.5.5")
    (leaf-keywords "2.0.8")
    (ppp           "2.2.4"))
  :url "https://github.com/conao3/leaf-convert.el"
  :commit "c92e42df9938682271ae0b77f9b16efdf427d467"
  :revdesc "c92e42df9938"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
