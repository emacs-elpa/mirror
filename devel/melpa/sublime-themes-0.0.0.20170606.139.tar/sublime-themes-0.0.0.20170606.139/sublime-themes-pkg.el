;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sublime-themes" "0.0.0.20170606.139"
  "A collection of themes based on Sublime Text."
  ()
  :url "https://github.com/owainlewis/emacs-color-themes"
  :commit "60ee40af82eb55b79d5ed4026f1911326311603f"
  :revdesc "60ee40af82eb"
  :keywords '("faces")
  :authors '(("Owain Lewis" . "owain@owainlewis.com"))
  :maintainers '(("Owain Lewis" . "owain@owainlewis.com")))
