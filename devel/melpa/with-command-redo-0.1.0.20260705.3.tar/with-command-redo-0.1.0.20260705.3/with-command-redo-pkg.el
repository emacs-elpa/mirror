;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-command-redo" "0.1.0.20260705.3"
  "Repeat commands with automatic undo."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-with-command-redo"
  :commit "4fcb6a584fe2f0fa8feb93355470d4675b715dd0"
  :revdesc "4fcb6a584fe2"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
