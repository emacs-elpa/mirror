;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ialign" "0.5.0.0.20251102.7"
  "Interactive align-regexp."
  '((emacs "25.1"))
  :url "https://github.com/mkcms/ialign"
  :commit "2a7472bdb782f5af021bfbdc4c32424d54c005dd"
  :revdesc "v0.5.0-7-g2a7472bdb782"
  :keywords '("tools" "editing" "align" "interactive")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
