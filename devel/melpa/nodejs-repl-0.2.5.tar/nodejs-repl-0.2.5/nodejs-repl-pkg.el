;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nodejs-repl" "0.2.5"
  "Run Node.js REPL."
  ()
  :url "https://github.com/abicky/nodejs-repl.el"
  :commit "cc74729c8494a4d3555fac6d3a3fd0e0ff4ac50a"
  :revdesc "cc74729c8494")
