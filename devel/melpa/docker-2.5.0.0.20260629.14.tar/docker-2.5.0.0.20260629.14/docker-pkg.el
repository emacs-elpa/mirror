;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "2.5.0.0.20260629.14"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "09132b633ace9928a4838f743dd3bf5aa9829e1a"
  :revdesc "2.5.0-14-g09132b633ace"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
