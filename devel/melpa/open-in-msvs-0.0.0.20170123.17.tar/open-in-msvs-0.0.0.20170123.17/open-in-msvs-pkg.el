;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "open-in-msvs" "0.0.0.20170123.17"
  "Open current file:line:column in Microsoft Visual Studio."
  ()
  :url "https://github.com/evgeny-panasyuk/open-in-msvs"
  :commit "e0d071c83188ad5db8f3297d6ce784b4ed554a04"
  :revdesc "e0d071c83188"
  :keywords '("convenience" "usability" "integration" "visual studio" "msvs" "ide"))
