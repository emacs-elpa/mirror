;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "0.1.20"
  "Nucleo-backed completion style."
  '((emacs "29.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "d156a20a3d968cf35e3b11b05691bacd88106eb4"
  :revdesc "d156a20a3d96"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
