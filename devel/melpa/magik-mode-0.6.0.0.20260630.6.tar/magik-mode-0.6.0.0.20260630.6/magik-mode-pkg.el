;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "0.6.0.0.20260630.6"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "6853b0f4c45471f7c2e3381f3738a785bf044861"
  :revdesc "6853b0f4c454"
  :keywords '("languages"))
