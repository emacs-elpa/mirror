;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "1.1.0.0.20260916.9"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "36771aa456cc3fd9c82361272bec3527044daaf6"
  :revdesc "v1.1.0-9-g36771aa456cc"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
