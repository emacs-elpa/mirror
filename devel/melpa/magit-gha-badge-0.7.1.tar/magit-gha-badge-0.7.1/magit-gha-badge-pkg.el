;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gha-badge" "0.7.1"
  "GitHub Actions status badge in the magit status buffer."
  '((emacs "29.1")
    (magit "4.0.0")
    (ghub  "4.0.0"))
  :url "https://github.com/agzam/magit-gha-badge.el"
  :commit "0618e8f2f6c29b524803294cd366001ba7708176"
  :revdesc "0.7.1-0-g0618e8f2f6c2"
  :keywords '("vc" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
