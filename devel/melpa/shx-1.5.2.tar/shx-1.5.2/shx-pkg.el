;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shx" "1.5.2"
  "Extras for the comint-mode shell."
  '((emacs "24.4"))
  :url "https://github.com/riscy/shx-for-emacs"
  :commit "019975297b4abbf9474172f4981e565152e9aa34"
  :revdesc "019975297b4a"
  :keywords '("terminals" "processes" "comint" "shell" "repl")
  :maintainers '(("Chris Rayner" . "dchrisrayner@gmail.com")))
