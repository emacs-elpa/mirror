;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "3.18.3.0.20260819.7"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.34.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "7466daf5ec82504eab0fe2a68652830776f0baa8"
  :revdesc "3.18.3-7-g7466daf5ec82"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
