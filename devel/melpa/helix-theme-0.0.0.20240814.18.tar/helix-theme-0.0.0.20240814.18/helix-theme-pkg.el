;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix-theme" "0.0.0.20240814.18"
  "Color theme inspired by Helix editor's default colors."
  ()
  :url "https://github.com/ibakepunk/helix-theme"
  :commit "8c70b48fe5fbb392d237b6be2ae9da7b84236320"
  :revdesc "8c70b48fe5fb"
  :keywords '("faces"))
