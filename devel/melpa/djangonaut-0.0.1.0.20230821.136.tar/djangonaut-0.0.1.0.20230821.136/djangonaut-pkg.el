;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "djangonaut" "0.0.1.0.20230821.136"
  "Minor mode to interact with Django projects."
  '((emacs       "25.2")
    (magit-popup "2.6.0")
    (pythonic    "0.1.0")
    (f           "0.20.0")
    (s           "1.12.0"))
  :url "https://github.com/proofit404/djangonaut"
  :commit "f360e3b39dc830a0380e82b6f3c475a466d7dda6"
  :revdesc "f360e3b39dc8"
  :keywords '("convenience" "django")
  :authors '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers '(("Artem Malyshev" . "proofit404@gmail.com")))
