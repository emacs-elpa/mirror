;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tagged" "0.0.4.0.20220926.9"
  "Dynamic block for tagged org-mode todos."
  '((s     "1.13.0")
    (dash  "2.19.1")
    (emacs "28.1")
    (org   "9.5.2"))
  :url "https://github.com/gizmomogwai/org-tagged"
  :commit "4b0174473772fca976426e982bb3f4a3037c1e37"
  :revdesc "v0.0.4-9-g4b0174473772"
  :keywords '("org-mode" "org" "gtd" "tools")
  :authors '(("Christian Köstlin" . "christian.koestlin@gmail.com"))
  :maintainers '(("Christian Köstlin" . "christian.koestlin@gmail.com")))
