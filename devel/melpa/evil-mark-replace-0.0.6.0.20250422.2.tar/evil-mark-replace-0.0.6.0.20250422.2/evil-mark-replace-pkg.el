;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-mark-replace" "0.0.6.0.20250422.2"
  "Replace the thing in marked area."
  '((evil "1.14.0"))
  :url "https://github.com/redguardtoo/evil-mark-replace"
  :commit "90ee84748582be05fa8f9a02872321a08b455282"
  :revdesc "90ee84748582"
  :keywords '("convenience")
  :authors '(("Chen Bin" . "chenbinDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmailDOTcom")))
