;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dpaste" "0.2.0.20160303.25"
  "Emacs integration for dpaste.com."
  ()
  :url "https://github.com/gregnewman/dpaste.el"
  :commit "e7a1a18de77f752eb0dbb4b878925f2265538d0b"
  :revdesc "e7a1a18de77f"
  :keywords '("paste" "pastie" "pastebin" "dpaste" "python")
  :authors '(("Greg Newman" . "greg@gregnewman.org")
             ("Guilherme Gondim" . "semente@taurinus.org"))
  :maintainers '(("Greg Newman" . "greg@gregnewman.org")))
