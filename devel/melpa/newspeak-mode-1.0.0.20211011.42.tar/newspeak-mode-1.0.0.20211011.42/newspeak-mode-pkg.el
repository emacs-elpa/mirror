;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "newspeak-mode" "1.0.0.20211011.42"
  "Major mode for the Newspeak programming language."
  '((emacs "24.3"))
  :url "https://github.com/danielsz/newspeak-mode"
  :commit "f76aee3a1f7ff032ed9ef2d3a092f84c8c985e19"
  :revdesc "f76aee3a1f7f"
  :maintainers '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com")))
