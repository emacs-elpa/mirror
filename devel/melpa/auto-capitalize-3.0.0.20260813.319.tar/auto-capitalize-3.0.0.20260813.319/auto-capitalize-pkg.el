;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-capitalize" "3.0.0.20260813.319"
  "Automatic capitalization with batteries included."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/abdulnafe-t/auto-capitalize.el"
  :commit "b19e574cb374f96f96704a427fa6fc565e29d095"
  :revdesc "b19e574cb374"
  :keywords '("text" "wp" "convenience")
  :maintainers '(("Abdulnafé Toulaïmat" . "abdulnafe.toulaimat@gmail.com")))
