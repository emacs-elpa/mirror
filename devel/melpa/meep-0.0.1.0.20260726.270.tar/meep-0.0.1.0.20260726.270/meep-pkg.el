;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "0.0.1.0.20260726.270"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "661eccd771ea14b5fe517417261b153aed41d2e5"
  :revdesc "661eccd771ea"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
