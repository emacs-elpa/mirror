;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacs-everywhere" "0.3.0.0.20251028.1"
  "System-wide popup windows for quick edits."
  '((emacs "28.1"))
  :url "https://github.com/tecosaur/emacs-everywhere"
  :commit "09a6a64dd07a712aad8ef1d0b99c086f025540d3"
  :revdesc "09a6a64dd07a"
  :keywords '("convenience" "frames")
  :authors '(("TEC" . "https://github.com/tecosaur"))
  :maintainers '(("TEC" . "contact@tecosaur.net")))
