;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.2.0.0.20260702.1"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "2e8190092ff1c68fa4aa260ecce5d026dc89345c"
  :revdesc "v0.2.0-1-g2e8190092ff1"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
