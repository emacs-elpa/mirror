;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minimal-session-saver" "0.6.2.0.20250228.17"
  "Very lean session saver."
  ()
  :url "https://github.com/rolandwalker/minimal-session-saver"
  :commit "1146d071c370bc3de33538e2d20172a9cca29ba2"
  :revdesc "v0.6.2-17-g1146d071c370"
  :keywords '("tools" "frames" "project")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
