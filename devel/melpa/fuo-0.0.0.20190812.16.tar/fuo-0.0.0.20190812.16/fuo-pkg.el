;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuo" "0.0.0.20190812.16"
  "Feeluown client."
  '((emacs "24.4"))
  :url "https://github.com/cosven/emacs-fuo"
  :commit "0e4122f94a336a50c02bc96652d25ac3d74bedeb"
  :revdesc "0e4122f94a33"
  :keywords '("feeluown" "multimedia" "unix")
  :authors '(("cosven" . "yinshaowen241@gmail.com"))
  :maintainers '(("cosven" . "yinshaowen241@gmail.com")))
