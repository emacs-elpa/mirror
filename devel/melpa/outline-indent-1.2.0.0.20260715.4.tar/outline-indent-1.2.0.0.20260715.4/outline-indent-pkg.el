;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "1.2.0.0.20260715.4"
  "Folding text based on indentation (origami alternative)."
  '((emacs    "26.1")
    (kirigami "1.0.5"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "6e12bf82611644584536f87f49d51042b2ec0339"
  :revdesc "1.2.0-4-g6e12bf826116"
  :keywords '("outlines")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
