;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "2.1.0.0.20261027.2"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "26a6811270f38463ede0470d0901dab83650d4a4"
  :revdesc "v2.1.0-2-g26a6811270f3"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
