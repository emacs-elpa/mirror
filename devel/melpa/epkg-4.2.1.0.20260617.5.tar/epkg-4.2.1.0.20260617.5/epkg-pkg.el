;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "4.2.1.0.20260617.5"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.0")
    (closql   "2.4")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "636490387d8fef3dc4d54b0b7cdc7ffe947663a1"
  :revdesc "v4.2.1-5-g636490387d8f"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
