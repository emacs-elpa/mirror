;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rings" "1.0.1.0.20160531.4"
  "Buffer rings. Like tabs, but better."
  ()
  :url "https://github.com/konr/rings"
  :commit "3590b222eb80652cbd27866f066bd3571d86edfc"
  :revdesc "3590b222eb80"
  :keywords '("utilities" "productivity"))
