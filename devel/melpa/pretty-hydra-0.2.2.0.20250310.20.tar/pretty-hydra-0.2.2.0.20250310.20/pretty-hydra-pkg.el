;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pretty-hydra" "0.2.2.0.20250310.20"
  "A macro for creating nice-looking hydras."
  '((hydra  "0.15.0")
    (s      "1.12.0")
    (dash   "2.18.0")
    (emacs  "24")
    (compat "29.1.4.1"))
  :url "https://github.com/jerrypnz/major-mode-hydra.el"
  :commit "2494d71e24b61c1f5ef2dc17885e2f65bf98b3b2"
  :revdesc "0.2.2-20-g2494d71e24b6"
  :authors '(("Jerry Peng" . "pr2jerry@gmail.com"))
  :maintainers '(("Jerry Peng" . "pr2jerry@gmail.com")))
