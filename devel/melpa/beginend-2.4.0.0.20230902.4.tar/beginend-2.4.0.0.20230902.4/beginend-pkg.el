;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beginend" "2.4.0.0.20230902.4"
  "Redefine M-< and M-> for some modes."
  '((emacs "25.3"))
  :url "https://github.com/DamienCassou/beginend"
  :commit "2d3536971b7cca597ba3404c30b5d1ce9d56f1fe"
  :revdesc "v2.4.0-4-g2d3536971b7c"
  :authors '(("Damien Cassou" . "damien@cassou.me")
             ("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")
                 ("Matus Goljer" . "matus.goljer@gmail.com")))
