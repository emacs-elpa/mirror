;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guide-key" "1.2.5.0.20150108.5"
  "Guide the following key bindings automatically and dynamically."
  '((dash   "2.10.0")
    (popwin "0.3.0")
    (s      "1.9.0"))
  :url "https://github.com/kai2nenobu/guide-key"
  :commit "9236d287a7272e307fb941237390a96037c8c0a2"
  :revdesc "v1.2.5-5-g9236d287a727"
  :keywords '("help" "convenience")
  :authors '(("Tsunenobu Kai" . "kai2nenobu@gmail.com"))
  :maintainers '(("Tsunenobu Kai" . "kai2nenobu@gmail.com")))
