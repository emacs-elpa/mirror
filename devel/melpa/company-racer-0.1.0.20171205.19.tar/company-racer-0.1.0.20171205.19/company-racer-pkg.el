;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-racer" "0.1.0.20171205.19"
  "Company integration for racer."
  '((emacs    "24.4")
    (cl-lib   "0.5")
    (company  "0.8.0")
    (deferred "0.3.1"))
  :url "https://github.com/emacs-pe/company-racer"
  :commit "a00381c9d416f375f783fcb6ae8d40669ce1f567"
  :revdesc "a00381c9d416"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
