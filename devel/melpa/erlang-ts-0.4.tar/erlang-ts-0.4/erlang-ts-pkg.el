;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang-ts" "0.4"
  "Major modes for editing Erlang."
  '((emacs  "29.2")
    (erlang "27.2"))
  :url "https://github.com/erlang/emacs-erlang-ts"
  :commit "4e9095be49630dc279c70033245a7e1051614f92"
  :revdesc "v0.4-0-g4e9095be4963"
  :keywords '("erlang" "languages" "treesitter"))
