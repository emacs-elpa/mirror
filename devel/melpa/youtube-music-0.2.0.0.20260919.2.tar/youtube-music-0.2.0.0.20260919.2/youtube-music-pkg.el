;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youtube-music" "0.2.0.0.20260919.2"
  "YouTube Music client."
  '((emacs "29.1"))
  :url "https://github.com/cyberkm/emacs-youtube-music"
  :commit "c71ed8180d14acb9fc7d7b4d64b708e1f25d1bea"
  :revdesc "c71ed8180d14"
  :keywords '("multimedia" "youtube" "music")
  :authors '(("Pavel Bibergal" . "pavel@keewano.com"))
  :maintainers '(("Pavel Bibergal" . "pavel@keewano.com")))
