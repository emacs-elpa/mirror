;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-latex-impatient" "0.1.0.0.20221111.29"
  "Preview org-latex Fragments Instantly via MathJax."
  '((emacs    "26")
    (s        "1.8.0")
    (posframe "0.8.0")
    (org      "9.3")
    (dash     "2.17.0"))
  :url "https://github.com/yangsheng6810/org-latex-instant-preview"
  :commit "031025a8be9bf7255aa047388d027642cd2d6183"
  :revdesc "031025a8be9b"
  :keywords '("tex" "tools")
  :authors '(("Sheng Yang" . "styang@fastmail.com"))
  :maintainers '(("Sheng Yang" . "styang@fastmail.com")))
