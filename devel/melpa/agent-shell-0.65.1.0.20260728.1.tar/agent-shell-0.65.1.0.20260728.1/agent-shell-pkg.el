;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.65.1.0.20260728.1"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4bda0217822f1c7a79935e269d40656f3b190c1a"
  :revdesc "4bda0217822f")
