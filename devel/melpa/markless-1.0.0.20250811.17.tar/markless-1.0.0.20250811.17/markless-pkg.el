;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markless" "1.0.0.20250811.17"
  "Major mode for Markless documents."
  '((emacs "24.4"))
  :url "https://shirakumo.org/docs/markless.el/"
  :commit "f8bd797f4d5962fec1dcf9807fba8cf0be17b2f9"
  :revdesc "f8bd797f4d59"
  :keywords '("languages" "wp")
  :authors '(("Yukari Hafner" . "shinmera@tymoon.eu"))
  :maintainers '(("Yukari Hafner" . "shinmera@tymoon.eu")))
