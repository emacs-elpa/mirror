;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tidy" "0.1.0.20241212.40"
  "A minor mode to tidy org-mode buffers."
  '((emacs "27.1")
    (dash  "2.19.1"))
  :url "https://github.com/jxq0/org-tidy"
  :commit "0bea3a2ceaa999e0ad195ba525c5c1dcf5fba43b"
  :revdesc "0bea3a2ceaa9"
  :keywords '("convenience" "org")
  :authors '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainers '(("Xuqing Jia" . "jxq@jxq.me")))
