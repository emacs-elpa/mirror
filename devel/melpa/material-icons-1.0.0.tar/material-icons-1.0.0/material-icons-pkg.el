;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "material-icons" "1.0.0"
  "Material Icon Theme integration."
  '((emacs "27.1"))
  :url "https://github.com/zHaOdANiuu/material-icons.el"
  :commit "230d44da047083faf3a90dc56ade06430ad49e7e"
  :revdesc "230d44da0470"
  :keywords '("convenience" "icons" "svg" "theme")
  :authors '(("Daniu Zhao" . "zhaodaniu1@gmail.com"))
  :maintainers '(("Daniu Zhao" . "zhaodaniu1@gmail.com")))
