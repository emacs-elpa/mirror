;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-coffeescript" "1.0.0.0.20180126.6"
  "Org-babel functions for coffee-script evaluation, and fully implementation!."
  '((emacs "24.4"))
  :url "https://github.com/brantou/ob-coffeescript"
  :commit "5a5bb04aea9c2a6eab5b05f90f5c7cb6de7b4261"
  :revdesc "5a5bb04aea9c"
  :keywords '("coffee-script" "literate programming" "reproducible research")
  :authors '(("Brantou" . "brantou89@gmail.com"))
  :maintainers '(("Brantou" . "brantou89@gmail.com")))
