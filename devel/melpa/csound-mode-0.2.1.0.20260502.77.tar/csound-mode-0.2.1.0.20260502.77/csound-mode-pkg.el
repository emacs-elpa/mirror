;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "csound-mode" "0.2.1.0.20260502.77"
  "A major mode for interacting and coding Csound."
  '((emacs     "25")
    (shut-up   "0.3.2")
    (multi     "2.0.1")
    (dash      "2.16.0")
    (highlight "0"))
  :url "https://github.com/hlolli/csound-mode"
  :commit "fb8152be0cfccd498c3d9f6bf4f550cfa96c416a"
  :revdesc "fb8152be0cfc"
  :authors '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers '(("Hlöðver Sigurðsson" . "hlolli@gmail.com")))
