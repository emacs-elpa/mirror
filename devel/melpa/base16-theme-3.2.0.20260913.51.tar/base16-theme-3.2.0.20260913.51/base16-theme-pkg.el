;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "3.2.0.20260913.51"
  "A set of base16 themes for your favorite editor."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "c66ddd7415bddfecfc4e1095b50cde5391270375"
  :revdesc "c66ddd7415bd"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
