;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.2.0.0.20260909.8"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "48dc501cdb52cec9aa75038e1a368da24eec87d8"
  :revdesc "4.2.0-8-g48dc501cdb52"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
