;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monroe" "0.3.1.0.20220915.60"
  "Yet another client for nREPL."
  ()
  :url "http://www.github.com/sanel/monroe"
  :commit "8f809e4aa0a35ec2d1c880aacf59e6bc317a566f"
  :revdesc "8f809e4aa0a3"
  :keywords '("languages" "clojure" "nrepl" "lisp")
  :authors '(("Sanel Zukan" . "sanelz@gmail.com"))
  :maintainers '(("Sanel Zukan" . "sanelz@gmail.com")))
