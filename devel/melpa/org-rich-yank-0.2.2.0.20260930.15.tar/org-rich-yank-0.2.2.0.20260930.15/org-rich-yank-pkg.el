;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-rich-yank" "0.2.2.0.20260930.15"
  "Paste with org-mode markup and link to source."
  '((emacs "25.1"))
  :url "https://github.com/unhammer/org-rich-yank"
  :commit "a8adcac661ca3c862a517010eef006bf929c6638"
  :revdesc "v0.2.2-15-ga8adcac661ca"
  :keywords '("convenience" "hypermedia" "org")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
