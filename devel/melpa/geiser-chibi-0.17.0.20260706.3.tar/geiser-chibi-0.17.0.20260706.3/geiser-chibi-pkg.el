;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-chibi" "0.17.0.20260706.3"
  "Chibi Scheme's implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.18"))
  :url "https://gitlab.com/emacs-geiser/chibi"
  :commit "98cda369db3faf7268dd3b1705bb914dd6dad56a"
  :revdesc "98cda369db3f"
  :keywords '("languages" "chibi" "scheme" "geiser")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
