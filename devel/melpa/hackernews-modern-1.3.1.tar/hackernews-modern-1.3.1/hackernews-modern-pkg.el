;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hackernews-modern" "1.3.1"
  "Hacker News client with modern widget UI."
  '((emacs              "28.1")
    (visual-fill-column "2.2")
    (async-http-queue   "0.1.0"))
  :url "https://git.andros.dev/andros/hackernews-modern-el"
  :commit "75387ca2d736c90cde414f03dfc4b5a03477d4f0"
  :revdesc "75387ca2d736"
  :keywords '("comm" "hypermedia" "news")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
