;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pubmed" "0.6.2"
  "Interface to PubMed."
  '((emacs     "26.1")
    (esxml     "0.3.4")
    (s         "1.12.0")
    (unidecode "0.2"))
  :url "https://gitlab.com/fvdbeek/emacs-pubmed"
  :commit "b2fbc124cabf0d373845763adf882e9d89ff5daa"
  :revdesc "b2fbc124cabf"
  :keywords '("pubmed" "hypermedia")
  :authors '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com"))
  :maintainers '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com")))
