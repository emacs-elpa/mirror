;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sentence-navigation" "0.1.0.20220522.30"
  "Commands to navigate one-spaced sentences."
  '((ample-regexps "0.1")
    (cl-lib        "0.5")
    (emacs         "24.4"))
  :url "https://github.com/noctuid/emacs-sentence-navigation"
  :commit "ea6e94a5518643acda5b6e98e4e7f47dfc107d29"
  :revdesc "ea6e94a55186"
  :keywords '("sentence" "evil")
  :authors '(("Fox Kiester" . "noct@openmailbox.org"))
  :maintainers '(("Fox Kiester" . "noct@openmailbox.org")))
