;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "universal-emotions-emoticons" "1.0.0.20180729.10"
  "Emoticons For The Six Universal Expressions."
  '((emacs "24.4"))
  :url "https://github.com/grettke/universal-emotions-emoticons"
  :commit "9cedd09ee65cb9fa71f27b0ab46a8353bdc00902"
  :revdesc "9cedd09ee65c"
  :keywords '("convenience" "docs" "languages")
  :authors '(("Grant Rettke" . "gcr@wisdomandwonder.com"))
  :maintainers '((nil . "gcr@wisdomandwonder.com")))
