;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dix" "0.4.1.0.20250430.15"
  "Apertium XML editing minor mode."
  '((cl-lib "0.5")
    (emacs  "26.2"))
  :url "http://wiki.apertium.org/wiki/Emacs"
  :commit "c833800623eaeab74b4d578a2d0219882320c0d2"
  :revdesc "0.4.1-15-gc833800623ea"
  :keywords '("languages")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
