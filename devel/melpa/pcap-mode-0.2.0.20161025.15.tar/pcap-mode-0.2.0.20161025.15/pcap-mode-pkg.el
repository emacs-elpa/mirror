;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcap-mode" "0.2.0.20161025.15"
  "Major mode for working with PCAP files."
  '((emacs "24.3"))
  :url "https://github.com/apconole/pcap-mode"
  :commit "52780669af0ade136f84d73f21b4dbb7ab655416"
  :revdesc "52780669af0a"
  :keywords '("pcap" "packets" "tcpdump" "wireshark" "tshark")
  :authors '(("Aaron Conole" . "aconole@bytheb.org"))
  :maintainers '(("Aaron Conole" . "aconole@bytheb.org")))
