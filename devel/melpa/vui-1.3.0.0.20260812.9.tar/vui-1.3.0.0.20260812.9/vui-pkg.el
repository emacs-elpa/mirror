;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.3.0.0.20260812.9"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "d0c2fea0a2b245acb22d6d8e2a2441fd6508b8b0"
  :revdesc "d0c2fea0a2b2"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
