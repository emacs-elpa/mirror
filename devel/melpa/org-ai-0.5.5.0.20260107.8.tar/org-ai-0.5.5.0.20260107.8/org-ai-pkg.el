;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ai" "0.5.5.0.20260107.8"
  "Use ChatGPT and other LLMs in org-mode and beyond."
  '((emacs     "27.1")
    (websocket "1.15"))
  :url "https://github.com/rksm/org-ai"
  :commit "71a6ea50555531f627a69aa0584d3a19060050a4"
  :revdesc "71a6ea505555"
  :authors '(("Robert Krahn" . "robert@kra.hn"))
  :maintainers '(("Robert Krahn" . "robert@kra.hn")))
