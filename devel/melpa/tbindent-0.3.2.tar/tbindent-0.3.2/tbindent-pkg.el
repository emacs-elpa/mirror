;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tbindent" "0.3.2"
  "Edit space-indented file in tab-indented buffer."
  '((emacs "24.3"))
  :url "https://github.com/pierre-rouleau/tab-based-indent"
  :commit "473e3bd7e13f7d5868688e3dc274b96e705c279f"
  :revdesc "473e3bd7e13f"
  :keywords '("convenience" "languages")
  :authors '(("Pierre Rouleau" . "prouleau001@gmail.com"))
  :maintainers '(("Pierre Rouleau" . "prouleau001@gmail.com")))
