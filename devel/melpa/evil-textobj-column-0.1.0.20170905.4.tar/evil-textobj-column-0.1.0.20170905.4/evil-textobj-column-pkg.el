;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-column" "0.1.0.20170905.4"
  "Provides column text objects."
  '((names "0.5")
    (emacs "24")
    (evil  "0"))
  :url "https://github.com/noctuid/evil-textobj-column"
  :commit "835d7036d0bc9a6e44fc9b7c54ccf2a7c01428cd"
  :revdesc "835d7036d0bc"
  :keywords '("evil" "column" "text-object")
  :authors '(("Fox Kiester" . "noct@openmailbox.org"))
  :maintainers '(("Fox Kiester" . "noct@openmailbox.org")))
