;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shimbun" "0.0.0.20260827.6194"
  "Interfacing with web newspapers."
  ()
  :url "https://github.com/emacs-w3m/emacs-w3m"
  :commit "584d593763082c3b31552025b6d95b7d9427cc39"
  :revdesc "584d59376308"
  :keywords '("news")
  :authors '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
             ("Akihiro Arisawa" . "ari@mbf.sphere.ne.jp")
             ("Yuuichi Teranishi" . "teranisi@gohome.org")
             ("Katsumi Yamaoka" . "yamaoka@jpl.org"))
  :maintainers '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
                 ("Akihiro Arisawa" . "ari@mbf.sphere.ne.jp")
                 ("Yuuichi Teranishi" . "teranisi@gohome.org")
                 ("Katsumi Yamaoka" . "yamaoka@jpl.org")))
