;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "processing-mode" "1.0.0.20171022.47"
  "Major mode for Processing 2.0."
  ()
  :url "https://github.com/ptrv/processing2-emacs"
  :commit "448aba82970c98322629eaf2746e73be6c30c98e"
  :revdesc "448aba82970c"
  :keywords '("languages" "snippets")
  :authors '(("Peter Vasil" . "mail@petervasil.net"))
  :maintainers '(("Peter Vasil" . "mail@petervasil.net")))
