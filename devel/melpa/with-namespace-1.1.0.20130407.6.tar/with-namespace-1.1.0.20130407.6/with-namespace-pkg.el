;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-namespace" "1.1.0.20130407.6"
  "Interoperable elisp namespaces."
  '((dash "1.1.0")
    (loop "1.1"))
  :url "https://github.com/Wilfred/with-namespace.el"
  :commit "36828a40428c8e53c117f2df830b2f7a59ddd306"
  :revdesc "36828a40428c"
  :keywords '("namespaces")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
