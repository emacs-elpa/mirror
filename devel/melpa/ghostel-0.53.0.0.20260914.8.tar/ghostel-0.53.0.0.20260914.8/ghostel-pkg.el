;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.53.0.0.20260914.8"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "7531ba4d1f854923dce3eedd024d3f28fbca5931"
  :revdesc "7531ba4d1f85"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
