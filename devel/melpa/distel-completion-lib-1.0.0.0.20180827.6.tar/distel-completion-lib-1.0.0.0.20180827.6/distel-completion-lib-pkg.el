;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "distel-completion-lib" "1.0.0.0.20180827.6"
  "Completion library for Erlang/Distel."
  ()
  :url "github.com/sebastiw/distel-completion"
  :commit "acc4c0a5521904203d797fe96b08e5fae4233c7e"
  :revdesc "acc4c0a55219"
  :keywords '("erlang" "distel" "completion"))
