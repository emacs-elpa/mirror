;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fantom-theme" "1.0.0.20200328.3"
  "Dark theme based on Phantom Code for VSCode."
  '((emacs "24.1"))
  :url "https://github.com/adsva/fantom-emacs-theme"
  :commit "2c1c7fd53086c2ff86ee0961642c3b58e2343c08"
  :revdesc "2c1c7fd53086")
