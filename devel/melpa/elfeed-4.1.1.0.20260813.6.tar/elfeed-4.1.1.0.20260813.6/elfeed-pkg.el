;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.1.1.0.20260813.6"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "687305f99713bff6c32120ee8dd471f001c3dc86"
  :revdesc "4.1.1-6-g687305f99713"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
