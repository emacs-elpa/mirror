;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eselect-news" "0.1.0.0.20260222.2"
  "Read Gentoo eselect news."
  '((emacs "27.1"))
  :url "https://gitlab.com/cestrand/emacs-eselect-news"
  :commit "562191c013a20348bd1adbf3be564c6e1d3c52b6"
  :revdesc "v0.1.0-2-g562191c013a2"
  :keywords '("gentoo" "convenience")
  :authors '(("Marcin Kolenda" . "https://gitlab.com/cestrand"))
  :maintainers '(("Marcin Kolenda" . "https://gitlab.com/cestrand")))
