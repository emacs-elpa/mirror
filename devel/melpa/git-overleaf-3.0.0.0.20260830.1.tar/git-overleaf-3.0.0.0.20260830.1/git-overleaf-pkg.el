;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-overleaf" "3.0.0.0.20260830.1"
  "Clone, push, and pull full Overleaf projects with Git."
  '((emacs         "29.4")
    (websocket     "1.15")
    (webdriver     "0.1")
    (magit-section "4.5")
    (transient     "0.7.2"))
  :url "https://github.com/Jamie-Cui/git-overleaf"
  :commit "fd95a80bd2c15c9c4aa189b257654be02d041c7e"
  :revdesc "fd95a80bd2c1"
  :keywords '("hypermedia" "tex" "tools")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
