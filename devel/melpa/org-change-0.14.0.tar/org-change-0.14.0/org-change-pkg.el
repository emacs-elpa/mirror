;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "0.14.0"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "e23dc3653a843526dab9c93f3dcca663d4706f63"
  :revdesc "e23dc3653a84"
  :keywords '("wp" "convenience"))
