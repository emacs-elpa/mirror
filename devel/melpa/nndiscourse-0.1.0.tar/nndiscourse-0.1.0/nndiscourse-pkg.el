;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nndiscourse" "0.1.0"
  "Gnus backend for Discourse."
  '((emacs    "27.1")
    (rbenv    "0.0.3")
    (json-rpc "0.0.1"))
  :url "https://github.com/dickmao/nndiscourse"
  :commit "c8aaf40d3d8f10b0bbb40fa60a2d98c864b05aaf"
  :revdesc "c8aaf40d3d8f"
  :keywords '("news")
  :authors '(("dickmao" . "githubid:dickmao"))
  :maintainers '(("dickmao" . "githubid:dickmao")))
