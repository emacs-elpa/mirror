;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-snooze" "0.1.0.0.20181229.1"
  "Snooze your code, doc and feed."
  '((emacs "24.4"))
  :url "https://github.com/xueeinstein/org-snooze.el"
  :commit "8799adc14a20f3489063d279ff69312de3180bf9"
  :revdesc "8799adc14a20"
  :keywords '("extensions"))
