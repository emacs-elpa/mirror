;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zoutline" "0.2.0.0.20220102.6"
  "Simple outline library."
  ()
  :url "https://github.com/abo-abo/zoutline"
  :commit "32857c6c4b9b0bcbed14d825a10b91a98d5fed0a"
  :revdesc "32857c6c4b9b"
  :keywords '("outline")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
