;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "0.1.0.0.20260714.280"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "339277c5240a5c624644214b0f230cfa39511da8"
  :revdesc "339277c5240a"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
