;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "actionscript-mode" "7.2.2.0.20180527.21"
  "A simple mode for editing Actionscript 3 files."
  ()
  :url "https://codeberg.org/austinhaas/actionscript-mode"
  :commit "65abd58e198458a8e46748c5962c41d80d60c4ea"
  :revdesc "65abd58e1984"
  :keywords '("language" "modes"))
