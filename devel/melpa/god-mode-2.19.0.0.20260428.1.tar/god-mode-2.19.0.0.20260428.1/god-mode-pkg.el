;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "god-mode" "2.19.0.0.20260428.1"
  "Minor mode for God-like command entering."
  '((emacs "26.3"))
  :url "https://github.com/emacsorphanage/god-mode"
  :commit "4deb47444dd21c67521908cef8b11ab377bfbd6f"
  :revdesc "4deb47444dd2"
  :authors '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainers '(("Chris Done" . "chrisdone@gmail.com")))
