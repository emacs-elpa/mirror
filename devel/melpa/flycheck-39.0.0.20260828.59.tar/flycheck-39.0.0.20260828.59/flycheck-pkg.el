;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "39.0.0.20260828.59"
  "On-the-fly syntax checking."
  '((emacs "28.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "53d8077d44e78f8dcf1d8c2f55cb91c2845b6158"
  :revdesc "53d8077d44e7"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
