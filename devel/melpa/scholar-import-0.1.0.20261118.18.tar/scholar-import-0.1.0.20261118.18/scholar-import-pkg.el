;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scholar-import" "0.1.0.20261118.18"
  "Import Bibtex & PDF from Google Scholar."
  '((emacs    "26.1")
    (org      "9.0")
    (request  "0.3.0")
    (s        "1.10.0")
    (parsebib "4.2"))
  :url "https://github.com/teeann/scholar-import"
  :commit "50aa6f563e4907a5f3107b95af48fce44a5f18cd"
  :revdesc "50aa6f563e49"
  :authors '(("Anh T Nguyen" . "https://github.com/teeann"))
  :maintainers '(("Anh T Nguyen" . "https://github.com/teeann")))
