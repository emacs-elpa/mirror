;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "0.12.0.0.20260916.28"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "3bbd5489d9c3208a62852302bcac65e7085dfa9d"
  :revdesc "3bbd5489d9c3"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
