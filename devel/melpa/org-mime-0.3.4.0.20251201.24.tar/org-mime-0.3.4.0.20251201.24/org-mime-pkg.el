;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mime" "0.3.4.0.20251201.24"
  "Org html export for text/html MIME emails."
  '((emacs "27.1"))
  :url "https://github.com/org-mime/org-mime"
  :commit "ffaad784a8597ee52842a578c01bd347d3e0281d"
  :revdesc "ffaad784a859"
  :keywords '("mime" "mail" "email" "html")
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
