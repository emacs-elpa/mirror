;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "0.1.1.0.20260828.33"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "c7578a7dc12a75ca23c8d59ec76099cc943bf87d"
  :revdesc "c7578a7dc12a"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
