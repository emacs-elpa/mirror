;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "6.2.0.0.20261031.28"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (markdown-mode  "2.0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "15c31db659eb4978933c4d3ca034cf3f9ce02fff"
  :revdesc "v6.2.0-28-g15c31db659eb"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
