;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jest-test-mode" "0.1.0.20231209.41"
  "Minor mode for running Node.js tests using jest."
  '((emacs "25.1"))
  :url "https://github.com/rymndhng/jest-test-mode.el"
  :commit "a397507d8bb41e4aa6b97994f1d7512e78d3dee3"
  :revdesc "a397507d8bb4"
  :authors '(("Raymond Huang" . "rymndhng@gmail.com"))
  :maintainers '(("Raymond Huang" . "rymndhng@gmail.com")))
