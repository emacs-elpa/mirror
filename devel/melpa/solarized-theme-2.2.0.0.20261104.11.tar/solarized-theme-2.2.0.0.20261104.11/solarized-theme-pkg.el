;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solarized-theme" "2.2.0.0.20261104.11"
  "The Solarized color theme."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/solarized-emacs"
  :commit "bd7e3a92e09f361a037c98cfe7c8f1eafda76254"
  :revdesc "bd7e3a92e09f"
  :keywords '("convenience" "themes" "solarized")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
