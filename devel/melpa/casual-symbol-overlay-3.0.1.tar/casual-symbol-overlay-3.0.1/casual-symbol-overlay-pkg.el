;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual-symbol-overlay" "3.0.1"
  "Transient UI for Symbol Overlay."
  '((emacs          "30.1")
    (casual         "3.0.0")
    (symbol-overlay "4.2"))
  :url "https://github.com/kickingvegas/casual-symbol-overlay"
  :commit "7e706755324f1ff1d44d81f6b69e9978acd0104b"
  :revdesc "7e706755324f"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
