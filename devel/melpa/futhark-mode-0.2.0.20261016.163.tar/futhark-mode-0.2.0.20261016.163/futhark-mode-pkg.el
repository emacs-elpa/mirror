;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "futhark-mode" "0.2.0.20261016.163"
  "Major mode for editing Futhark source files."
  '((emacs       "24.3")
    (cl-lib      "0.5")
    (reformatter "0.4"))
  :url "https://github.com/diku-dk/futhark-mode"
  :commit "ac68bc3a2a0cf77679b55c118e00098467b821a8"
  :revdesc "ac68bc3a2a0c"
  :keywords '("languages"))
