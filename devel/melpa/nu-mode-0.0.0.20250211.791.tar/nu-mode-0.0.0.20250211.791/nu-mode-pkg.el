;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nu-mode" "0.0.0.20250211.791"
  "Modern Emacs Keybinding."
  '((undo-tree       "0.6.5")
    (ace-window      "0")
    (lv              "0")
    (avy             "0")
    (which-key       "0")
    (transpose-frame "0"))
  :url "https://github.com/pyluyten/emacs-nu"
  :commit "6510bc3f22e921aeb8ef3190bca1f432acc2870e"
  :revdesc "6510bc3f22e9")
