;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gams-ac" "1.1.0.20180423.3"
  "Auto-complete source file for GAMS mode."
  '((emacs         "24")
    (auto-complete "1.0")
    (gams-mode     "4.0"))
  :url "https://github.com/ShiroTakeda/gams-ac"
  :commit "66d04ff36033f54205c19bc1d893e926d4dbf02e"
  :revdesc "66d04ff36033"
  :keywords '("languages" "tools" "gams-mode" "auto-complete"))
