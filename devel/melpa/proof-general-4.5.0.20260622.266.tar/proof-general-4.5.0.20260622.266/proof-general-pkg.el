;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "4.5.0.20260622.266"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "38e3f59d4b650fbfb9649c84f24adbc9056ffa30"
  :revdesc "v4.5-266-g38e3f59d4b65"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
