;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-compile" "2.1.4.0.20260925.1"
  "Automatically compile Emacs Lisp libraries."
  '((emacs "28.1"))
  :url "https://github.com/emacscollective/auto-compile"
  :commit "5bc1bb6df6815b8d1070db1450de94dd47c3b917"
  :revdesc "v2.1.4-1-g5bc1bb6df681"
  :keywords '("compile" "convenience" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev")))
