;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outrespace" "0.1.0.20220218.24"
  "Some c++ namespace utility functions."
  '((emacs "24.4"))
  :url "https://github.com/articuluxe/outrespace.git"
  :commit "3c8efa5e7903d88a2e81178a5def627f37379ee4"
  :revdesc "3c8efa5e7903"
  :keywords '("tools" "c++" "namespace")
  :authors '(("Dan Harms" . "danielrharms@gmail.com"))
  :maintainers '(("Dan Harms" . "danielrharms@gmail.com")))
