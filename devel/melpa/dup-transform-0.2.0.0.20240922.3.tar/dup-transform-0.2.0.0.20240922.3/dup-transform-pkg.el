;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dup-transform" "0.2.0.0.20240922.3"
  "RGB/XY graphics code helpers."
  '((emacs "29.1"))
  :url "https://github.com/garyo/dup-transform.el"
  :commit "6cbfb9b6fdf811a4e1e2ddad993fb16f35ec7622"
  :revdesc "6cbfb9b6fdf8"
  :keywords '("graphics" "tools" "convenience" "c++" "3d" "video" "rgb")
  :authors '(("Gary Oberbrunner" . "garyo@darkstarsystems.com"))
  :maintainers '(("Gary Oberbrunner" . "garyo@darkstarsystems.com")))
