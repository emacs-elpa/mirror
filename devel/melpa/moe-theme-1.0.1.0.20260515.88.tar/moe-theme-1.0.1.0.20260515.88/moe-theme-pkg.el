;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moe-theme" "1.0.1.0.20260515.88"
  "A colorful eye-candy theme. Moe, moe, kyun!."
  ()
  :url "https://github.com/kuanyui/moe-theme.el"
  :commit "c7d711e940a6c4e7a2270830aeaf52c1ce789455"
  :revdesc "c7d711e940a6"
  :keywords '("themes")
  :authors '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainers '(("kuanyui" . "azazabc123@gmail.com")))
