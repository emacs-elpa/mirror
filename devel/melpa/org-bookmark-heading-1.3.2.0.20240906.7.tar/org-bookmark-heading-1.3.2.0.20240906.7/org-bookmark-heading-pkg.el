;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bookmark-heading" "1.3.2.0.20240906.7"
  "Emacs bookmark support for Org mode."
  '((emacs  "25.1")
    (compat "29.1.4.5"))
  :url "https://github.com/alphapapa/org-bookmark-heading"
  :commit "bcab006ec42d7e2c92875c7170df193de2ee55f5"
  :revdesc "v1.3.2-7-gbcab006ec42d"
  :keywords '("hypermedia" "outlines")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
