;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.7.0.0.20260924.122"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "86d63b63d257c11961826afce49a4844d526f73c"
  :revdesc "86d63b63d257"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
