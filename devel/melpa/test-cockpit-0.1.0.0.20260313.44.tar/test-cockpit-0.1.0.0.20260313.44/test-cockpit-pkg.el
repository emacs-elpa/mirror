;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "0.1.0.0.20260313.44"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (transient  "0.7.0")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "eaa2c9346085ccf1fb7e7a9430255b50c057ea15"
  :revdesc "eaa2c9346085"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
