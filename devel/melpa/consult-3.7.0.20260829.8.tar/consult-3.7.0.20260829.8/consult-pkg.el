;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "3.7.0.20260829.8"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "3a2441ddb08d9897eb266cda4935fa91a767e1d5"
  :revdesc "3.7-8-g3a2441ddb08d"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
