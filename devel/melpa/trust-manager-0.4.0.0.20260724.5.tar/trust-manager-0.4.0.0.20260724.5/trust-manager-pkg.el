;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trust-manager" "0.4.0.0.20260724.5"
  "Convenient trust management."
  '((emacs "30.1"))
  :url "https://git.sr.ht/~eshel/trust-manager"
  :commit "0ff311bb59c9f1bb1ecdf413fa2bfa353bf389d7"
  :revdesc "v0.4.0-5-g0ff311bb59c9"
  :keywords '("security" "trust" "files")
  :authors '(("Eshel Yaron" . "me@eshelyaron.com"))
  :maintainers '(("Eshel Yaron" . "me@eshelyaron.com")))
