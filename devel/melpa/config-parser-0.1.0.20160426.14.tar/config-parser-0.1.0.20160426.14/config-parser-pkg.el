;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "config-parser" "0.1.0.20160426.14"
  "A library for parsing config file."
  '((emacs "24.4"))
  :url "https://github.com/lujun9972/el-config-parser"
  :commit "85d559e7889d8f5b98b8794b79426ae25ec3caa5"
  :revdesc "85d559e7889d"
  :keywords '("convenience" "config")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
