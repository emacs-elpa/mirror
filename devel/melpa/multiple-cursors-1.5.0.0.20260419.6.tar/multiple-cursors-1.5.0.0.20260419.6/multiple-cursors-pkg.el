;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multiple-cursors" "1.5.0.0.20260419.6"
  "Multiple cursors for Emacs."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/magnars/multiple-cursors.el"
  :commit "94b8b07a4bab87f803123723b68227565429dfa1"
  :revdesc "1.5.0-6-g94b8b07a4bab"
  :keywords '("editing" "cursors")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
