;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuz" "1.3.0.0.20200104.16"
  "Fast and precise fuzzy scoring/matching utils."
  '((emacs "25.1"))
  :url "https://github.com/cireu/fuz.el"
  :commit "0b6b64cebde5675be3a28520ee16234db48d3b8b"
  :revdesc "1.3.0-16-g0b6b64cebde5"
  :keywords '("lisp")
  :authors '(("Zhu Zihao" . "all_but_last@163.com"))
  :maintainers '(("Zhu Zihao" . "all_but_last@163.com")))
