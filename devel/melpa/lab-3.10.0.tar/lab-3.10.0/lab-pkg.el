;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab" "3.10.0"
  "An interface for GitLab."
  '((emacs       "27.1")
    (request     "0.3.2")
    (s           "1.10.0")
    (f           "0.20.0")
    (compat      "29.1.4.4")
    (promise     "1.1")
    (async-await "1.1"))
  :url "https://github.com/isamert/lab.el"
  :commit "8c33f35b490a12a8d4bc57954a946fe4d12abb81"
  :revdesc "v3.10.0-0-g8c33f35b490a"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
