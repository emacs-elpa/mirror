;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-jump-helm-line" "0.5.0.0.20160918.1"
  "Ace-jump to a candidate in helm window."
  '((avy  "0.4.0")
    (helm "1.6.3"))
  :url "https://github.com/cute-jumper/ace-jump-helm-line"
  :commit "1483055255df3f8ae349f7520f05b1e43ea3ed37"
  :revdesc "1483055255df"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
