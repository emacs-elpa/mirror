;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darcula-theme" "0.0.0.20260914.48"
  "Inspired by IntelliJ's Darcula theme."
  ()
  :url "https://gitlab.com/fommil/emacs-darcula-theme"
  :commit "33a1b12ea0823cfa82ab8d6d5b67c2d2217994f3"
  :revdesc "33a1b12ea082"
  :keywords '("faces")
  :authors '(("Sam Halliday" . "Sam.Halliday@gmail.com"))
  :maintainers '(("Sam Halliday" . "Sam.Halliday@gmail.com")))
