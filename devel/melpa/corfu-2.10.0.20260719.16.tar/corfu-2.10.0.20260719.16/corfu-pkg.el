;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.10.0.20260719.16"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "991224fc0387f005f4ffa896b35eca70b54c651a"
  :revdesc "2.10-16-g991224fc0387"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
