;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-ffuf" "0.9.0.20221004.17"
  "Babel functions for ffuf."
  '((emacs "28.1"))
  :url "https://github.com/daniel-ts/ob-ffuf"
  :commit "5310a3e766a252ac34f8cb2307c4e48e982f5611"
  :revdesc "5310a3e766a2"
  :keywords '("comm" "tools")
  :maintainers '(("Daniel Tschertkow" . "daniel.tschertkow@posteo.de")))
