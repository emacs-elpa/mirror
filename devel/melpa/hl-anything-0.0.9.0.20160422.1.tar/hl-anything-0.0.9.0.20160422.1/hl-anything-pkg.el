;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-anything" "0.0.9.0.20160422.1"
  "Highlight symbols, selections, enclosing parens and more."
  '((emacs "24.3"))
  :url "https://github.com/hl-anything/hl-anything-emacs"
  :commit "c2e50f91a05d6c43e8a1c169f709cd1f23e47b0a"
  :revdesc "c2e50f91a05d")
