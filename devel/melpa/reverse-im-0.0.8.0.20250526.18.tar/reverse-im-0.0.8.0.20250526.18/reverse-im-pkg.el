;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reverse-im" "0.0.8.0.20250526.18"
  "Reverse mapping for non-default system layouts."
  '((emacs "25.1")
    (seq   "2.23"))
  :url "https://github.com/a13/reverse-im.el"
  :commit "20d5f0514a761f0a06284b2adf0baf4bf7b93db2"
  :revdesc "20d5f0514a76"
  :keywords '("i18n")
  :authors '(("Juri Linkov" . "juri@jurta.org"))
  :maintainers '(("DK" . "a13@users.noreply.github.com")))
