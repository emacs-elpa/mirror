;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lingr" "0.2.0.20100807.7"
  "Lingr Client for GNU Emacs."
  ()
  :url "https://github.com/lugecy/lingr-el"
  :commit "4215a8704492d3c860097cbe2649936c22c196df"
  :revdesc "v0.2-7-g4215a8704492"
  :keywords '("chat" "client" "internet")
  :authors '(("lugecy" . "lugecy@gmail.com"))
  :maintainers '(("lugecy" . "lugecy@gmail.com")))
