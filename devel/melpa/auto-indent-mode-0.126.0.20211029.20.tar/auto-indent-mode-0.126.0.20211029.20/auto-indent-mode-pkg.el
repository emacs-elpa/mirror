;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-indent-mode" "0.126.0.20211029.20"
  "Auto indent Minor mode."
  ()
  :url "https://github.com/mlf176f2/auto-indent-mode.el/"
  :commit "664006b67329a8e27330541547f8c2187dab947c"
  :revdesc "v0.126-20-g664006b67329"
  :keywords '("auto" "indentation"))
