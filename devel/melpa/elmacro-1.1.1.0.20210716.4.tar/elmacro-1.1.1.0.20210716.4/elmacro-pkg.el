;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elmacro" "1.1.1.0.20210716.4"
  "Convert keyboard macros to emacs lisp."
  '((s    "1.11.0")
    (dash "2.13.0"))
  :url "https://github.com/Silex/elmacro"
  :commit "d2e05012cee4f54fab6d8d8d6aced6e5eeef4f31"
  :revdesc "1.1.1-4-gd2e05012cee4"
  :keywords '("macro" "elisp" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
