;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bbdb" "1.1.0.20260722.52"
  "Helm interface for bbdb."
  '((emacs "26.1")
    (helm  "1.5")
    (bbdb  "3.1.2"))
  :url "https://github.com/emacs-helm/helm-bbdb"
  :commit "fd44655b6016d955852e4e6e35c8929b7db439ca"
  :revdesc "v1.1-52-gfd44655b6016"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Jonathan Gregory" . "jgrg@autistici.org")))
