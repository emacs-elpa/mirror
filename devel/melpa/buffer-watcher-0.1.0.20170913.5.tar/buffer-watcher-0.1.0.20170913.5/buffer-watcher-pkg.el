;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-watcher" "0.1.0.20170913.5"
  "Easily run shell scripts per filetype/directory when a buffer is saved."
  '((f      "0.16.2")
    (cl-lib "0.5"))
  :url "https://github.com/NicolasPetton/buffer-watcher"
  :commit "b32c67c8a5d724257d759f4c903d0dedc32246ef"
  :revdesc "0.1-5-gb32c67c8a5d7"
  :authors '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")))
