;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sudoku" "1.4.0.20191015.8"
  "Simple sudoku game, can download puzzles."
  '((emacs "24.4"))
  :url "https://github.com/zevlg/sudoku.el"
  :commit "b1924fd244a5fa284de9d67b66fbd69164b37318"
  :revdesc "b1924fd244a5"
  :keywords '("games")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
