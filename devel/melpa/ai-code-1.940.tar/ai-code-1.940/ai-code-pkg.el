;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.940"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "d9eb2457b0c63f74eaf42cdd60a4fb810fe87737"
  :revdesc "d9eb2457b0c6"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
