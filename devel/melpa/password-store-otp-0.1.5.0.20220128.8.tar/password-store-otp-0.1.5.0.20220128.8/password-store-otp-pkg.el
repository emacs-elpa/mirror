;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "password-store-otp" "0.1.5.0.20220128.8"
  "Password store (pass) OTP extension support."
  '((emacs          "25")
    (s              "1.9.0")
    (password-store "0.1"))
  :url "https://github.com/volrath/password-store-otp.el"
  :commit "be3a00a981921ed1b2f78012944dc25eb5a0beca"
  :revdesc "0.1.5-8-gbe3a00a98192"
  :keywords '("tools" "pass"))
