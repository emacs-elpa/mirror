;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "0.3.2.0.20260909.22"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "59d9bd8783238817df3f34583b5ae3d9600768e4"
  :revdesc "59d9bd878323"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
