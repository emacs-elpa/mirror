;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "3.6.0.20260731.7"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "6af0dc99ff8eb8da3ca24bf9abd9a72354dcc5e1"
  :revdesc "3.6-7-g6af0dc99ff8e"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
