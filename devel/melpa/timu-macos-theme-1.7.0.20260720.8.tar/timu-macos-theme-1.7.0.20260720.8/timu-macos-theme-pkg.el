;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-macos-theme" "1.7.0.20260720.8"
  "Color theme inspired by the macOS UI."
  '((emacs "27.1"))
  :url "https://gitlab.com/aimebertrand/timu-macos-theme"
  :commit "3f9019a1ea467058388d2919b3d75c1feb859d7d"
  :revdesc "3f9019a1ea46"
  :keywords '("faces" "themes")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
