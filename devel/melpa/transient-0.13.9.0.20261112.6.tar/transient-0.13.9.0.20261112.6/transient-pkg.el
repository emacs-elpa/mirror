;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "0.13.9.0.20261112.6"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "d424c0d980a37413e193b8e615d1af624ef96b17"
  :revdesc "v0.13.9-6-gd424c0d980a3"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
