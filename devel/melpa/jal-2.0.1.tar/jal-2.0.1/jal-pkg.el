;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jal" "2.0.1"
  "Java Agent Loader (JAL) for JDTLS."
  '((emacs "28.1"))
  :url "https://github.com/saulotoledo/java-agent-loader"
  :commit "2d3f4b23ef4fa3883d2397877ec62ff5fb2b94af"
  :revdesc "2d3f4b23ef4f"
  :keywords '("java" "languages" "tools")
  :authors '(("Saulo Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo Toledo" . "saulotoledo@gmail.com")))
