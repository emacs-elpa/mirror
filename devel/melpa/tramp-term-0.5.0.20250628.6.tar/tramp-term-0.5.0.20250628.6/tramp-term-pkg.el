;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tramp-term" "0.5.0.20250628.6"
  "Automatic setup of directory tracking in ssh sessions."
  ()
  :url "https://github.com/randymorris/tramp-term.el"
  :commit "4af42a379bfdbb6549d52a7c3460ba59264f19da"
  :revdesc "4af42a379bfd"
  :keywords '("comm" "terminals")
  :authors '(("Randy Morris" . "randy.morris@archlinux.us"))
  :maintainers '(("Randy Morris" . "randy.morris@archlinux.us")))
