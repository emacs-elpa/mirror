;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ext" "0.9.0.0.20260916.5"
  "SystemVerilog Extensions."
  '((emacs           "29.1")
    (verilog-mode    "2024.3.1.121933719")
    (verilog-ts-mode "0.6.0")
    (lsp-mode        "8.0.0")
    (rg              "2.3.0")
    (hydra           "0.15.0")
    (apheleia        "3.1")
    (yasnippet       "0.14.0")
    (flycheck        "32")
    (async           "1.9.7"))
  :url "https://github.com/gmlarumbe/verilog-ext"
  :commit "168fcee51bede972235e96dfccf7ab8c0c835e9d"
  :revdesc "168fcee51bed"
  :keywords '("verilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
