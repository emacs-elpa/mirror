;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nsis-mode" "0.44.0.20260331.33"
  "NSIS-mode."
  ()
  :url "https://github.com/mlf176f2/nsis-mode"
  :commit "0e1ec26a3943865f33e5590e26f5bc31684ad67e"
  :revdesc "v0.44-33-g0e1ec26a3943"
  :keywords '("nsis"))
