;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nand2tetris-assembler" "0.0.1.0.20171201.26"
  "Assembler For the Nand2tetris Course."
  '((nand2tetris "1.1.0"))
  :url "http://www.github.com/CestDiego/nand2tetris-assembler.el/"
  :commit "fe37ee41367ceff6f7d7a472a5f80cf1285e1e01"
  :revdesc "fe37ee41367c"
  :keywords '("nand2tetris-assembler" "hdl")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")))
