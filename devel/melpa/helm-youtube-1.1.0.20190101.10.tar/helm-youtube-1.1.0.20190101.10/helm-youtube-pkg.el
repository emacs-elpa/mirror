;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-youtube" "1.1.0.20190101.10"
  "Query YouTube and play videos in your browser."
  '((request "0.2.0")
    (helm    "2.3.1")
    (cl-lib  "0.5"))
  :url "https://github.com/maximus12793/helm-youtube"
  :commit "e7272f1648c7fa836ea5ac1a61770b4931ab4709"
  :revdesc "e7272f1648c7"
  :keywords '("youtube" "multimedia")
  :authors '(("Maximilian Roquemore" . "maximus12793@gmail.com"))
  :maintainers '(("Maximilian Roquemore" . "maximus12793@gmail.com")))
