;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fish-completion" "1.2.0.20240518.8"
  "Fish completion for pcomplete (shell and Eshell)."
  '((emacs "25.1"))
  :url "https://gitlab.com/Ambrevar/emacs-fish-completion"
  :commit "1256f137a2039805d4e87f8e6c11a162ed019587"
  :revdesc "1256f137a203"
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
