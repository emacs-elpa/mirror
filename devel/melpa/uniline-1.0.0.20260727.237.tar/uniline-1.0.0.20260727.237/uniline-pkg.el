;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "1.0.0.20260727.237"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "7760d4ae1d111ac60e9d2ff6820315df72369b77"
  :revdesc "7760d4ae1d11"
  :keywords '("convenience" "text"))
