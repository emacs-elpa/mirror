;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "1.0.0.20261009.20"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "3240cda37d6511b1679a4eedfdf439c5ae633969"
  :revdesc "3240cda37d65"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
