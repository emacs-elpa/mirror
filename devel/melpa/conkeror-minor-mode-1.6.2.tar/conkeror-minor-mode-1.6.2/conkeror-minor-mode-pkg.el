;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conkeror-minor-mode" "1.6.2"
  "Mode for editing conkeror javascript files."
  ()
  :url "https://github.com/Bruce-Connor/conkeror-minor-mode"
  :commit "476e81c27b056e21c192391fe674a2bf875466b0"
  :revdesc "476e81c27b05"
  :keywords '("programming" "tools")
  :authors '(("Artur Malabarba" . "bruce.connor.am@gmail.com"))
  :maintainers '(("Artur Malabarba" . "bruce.connor.am@gmail.com")))
