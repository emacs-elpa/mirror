;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sql-trino" "0.1.0.0.20220826.7"
  "Adds Trino support to SQLi mode."
  '((emacs "24.4"))
  :url "https://github.com/regadas/sql-trino"
  :commit "624a879ec0d03cae8a92f26d21d88c831e15eb41"
  :revdesc "624a879ec0d0"
  :keywords '("tools")
  :authors '(("Filipe Regadas" . "oss@regadas.email"))
  :maintainers '(("Filipe Regadas" . "oss@regadas.email")))
