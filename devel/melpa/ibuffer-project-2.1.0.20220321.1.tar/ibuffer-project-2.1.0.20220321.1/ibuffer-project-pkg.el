;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-project" "2.1.0.20220321.1"
  "Group ibuffer's list by project or any function."
  '((emacs "25.1"))
  :url "https://github.com/muffinmad/emacs-ibuffer-project"
  :commit "bfc0ec1f27b02b8ab816dcfd9073e5d78dae1aed"
  :revdesc "bfc0ec1f27b0"
  :keywords '("tools")
  :authors '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com"))
  :maintainers '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com")))
