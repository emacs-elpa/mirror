;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "launchctl" "1.0.0.20210611.18"
  "Interface to launchctl on Mac OS X."
  '((emacs "24.1"))
  :url "https://github.com/pekingduck/launchctl-el"
  :commit "c9b7e93f5ec6fa504dfb03d60571cf3e5dc38e12"
  :revdesc "c9b7e93f5ec6"
  :keywords '("tools" "convenience")
  :authors '(("Peking Duck" . "github.com/pekingduck"))
  :maintainers '(("Peking Duck" . "github.com/pekingduck")))
