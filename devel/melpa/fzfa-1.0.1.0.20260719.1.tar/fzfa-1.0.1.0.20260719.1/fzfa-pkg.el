;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0.1.0.20260719.1"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.2"))
  :url "https://github.com/jojojames/fzfa"
  :commit "427ff74d62abcd4ee1729d8743fde69cd1a722f9"
  :revdesc "427ff74d62ab"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
