;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pillar" "1.0.0"
  "Major mode for editing Pillar files."
  '((makey "0.3"))
  :url "https://github.com/DamienCassou/pillar-mode"
  :commit "13a7f676544cc66005ccd8e6fc1c25e4ccd6f909"
  :revdesc "13a7f676544c"
  :keywords '("markup" "major-mode")
  :authors '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainers '(("Damien Cassou" . "damien.cassou@gmail.com")))
