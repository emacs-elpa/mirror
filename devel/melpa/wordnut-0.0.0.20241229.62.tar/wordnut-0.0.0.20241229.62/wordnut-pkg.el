;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wordnut" "0.0.0.20241229.62"
  "[No description available]."
  '((emacs "24.4"))
  :url "https://github.com/gromnitsky/wordnut"
  :commit "dffc75a455d0d4458b7555f4c051c51d71c8e18a"
  :revdesc "dffc75a455d0")
