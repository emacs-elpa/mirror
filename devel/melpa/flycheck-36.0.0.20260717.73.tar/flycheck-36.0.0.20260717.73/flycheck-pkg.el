;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "36.0.0.20260717.73"
  "On-the-fly syntax checking."
  '((emacs "28.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "2a0d9b2e6281e2dccd7e611000dfeccd52b4ae5b"
  :revdesc "2a0d9b2e6281"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
