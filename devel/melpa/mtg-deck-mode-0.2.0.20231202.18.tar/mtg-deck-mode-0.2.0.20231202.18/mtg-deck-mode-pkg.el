;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mtg-deck-mode" "0.2.0.20231202.18"
  "Major mode to edit MTG decks."
  '((emacs "25.1"))
  :url "https://github.com/mattiasb/mtg-deck-mode"
  :commit "3cb3866951feae40531c0a2e4fa72c0f2989c36c"
  :revdesc "v0.2-18-g3cb3866951fe"
  :keywords '("data" "mtg" "magic"))
