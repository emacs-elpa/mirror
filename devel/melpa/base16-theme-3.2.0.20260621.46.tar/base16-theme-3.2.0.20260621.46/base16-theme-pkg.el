;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "3.2.0.20260621.46"
  "A set of base16 themes for your favorite editor."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "93b118e5ae7477361d1120db32508cb9756eb145"
  :revdesc "93b118e5ae74"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
