;; base16-embers-light-theme.el -- A base16 colorscheme

;;; Commentary:
;; Base16: (https://github.com/tinted-theming/home)

;;; Authors:
;; Scheme: Jannik Siebert (https://github.com/janniks)
;; Template: Kaleb Elwert <belak@coded.io>

;;; Code:

(require 'base16-theme)

(defvar base16-embers-light-theme-colors
  '(:base00 "#dbd6d1"
    :base01 "#beb6ae"
    :base02 "#a39a90"
    :base03 "#8a8075"
    :base04 "#5a5047"
    :base05 "#433b32"
    :base06 "#2c2620"
    :base07 "#16130f"
    :base08 "#826d57"
    :base09 "#828257"
    :base0A "#6d8257"
    :base0B "#57826d"
    :base0C "#576d82"
    :base0D "#6d5782"
    :base0E "#82576d"
    :base0F "#825757")
  "All colors for Base16 Embers Light are defined here.")

;; Define the theme
(deftheme base16-embers-light)

;; Add all the faces to the theme
(base16-theme-define 'base16-embers-light base16-embers-light-theme-colors)

;; Mark the theme as provided
(provide-theme 'base16-embers-light)

(provide 'base16-embers-light-theme)

;;; base16-embers-light-theme.el ends here
