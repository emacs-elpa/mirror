;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-gleam" "0.1.1.0.20260221.1"
  "Org Babel functions for Gleam."
  '((emacs "29.1"))
  :url "https://github.com/takeokunn/ob-gleam"
  :commit "31a521c165426954e565ea368da81c4500885f30"
  :revdesc "31a521c16542"
  :keywords '("languages" "tools")
  :authors '(("takeokunn" . "bararararatty@gmail.com"))
  :maintainers '(("takeokunn" . "bararararatty@gmail.com")))
