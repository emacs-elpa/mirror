;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "madhat2r-theme" "0.1.0.20170203.12"
  "Dark color theme that is easy on the eyes."
  '((emacs "24"))
  :url "https://github.com/madhat2r/madhat2r-theme"
  :commit "6b387f09de055cfcc15d74981cd4f32f8f9a7323"
  :revdesc "6b387f09de05"
  :keywords '("color" "theme"))
