;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-select-account" "0.10.0.20170722.6"
  "Select an account before writing a mail in gnus."
  ()
  :url "https://github.com/tumashu/gnus-select-account"
  :commit "ddc8c135eeaf90f5b6692a033af2badae36e68ce"
  :revdesc "ddc8c135eeaf"
  :keywords '("convenience")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
