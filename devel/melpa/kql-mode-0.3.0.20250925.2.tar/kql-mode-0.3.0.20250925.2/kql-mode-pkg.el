;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kql-mode" "0.3.0.20250925.2"
  "Major mode for highlighting KQL."
  '((emacs "26.1"))
  :url "https://gitlab.com/aimebertrand/kql-mode"
  :commit "6ea203a6f21332eeab33875908da01607740947d"
  :revdesc "6ea203a6f213"
  :keywords '("files" "languages" "azure" "entra" "kql" "faces" "syntax" "major-mode"))
