;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pc-bufsw" "3.2.0.20201011.16"
  "PC style quick buffer switcher."
  ()
  :url "https://github.com/ibukanov/pc-bufsw"
  :commit "a7295e4813d636d5a20605d134acd42e4e4fe8fa"
  :revdesc "a7295e4813d6"
  :keywords '("buffer")
  :authors '(("Igor Bukanov" . "igor@mir2.org"))
  :maintainers '(("Igor Bukanov" . "igor@mir2.org")))
