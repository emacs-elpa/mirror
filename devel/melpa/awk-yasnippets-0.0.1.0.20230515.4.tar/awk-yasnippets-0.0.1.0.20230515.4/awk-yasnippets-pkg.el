;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awk-yasnippets" "0.0.1.0.20230515.4"
  "Yasnippets for AWK."
  '((emacs     "26.3")
    (yasnippet "0.8.0"))
  :url "https://github.com/uberkael/awk-yasnippets"
  :commit "12e8e0b49878099bda5d3e4915cc3c738c87b95c"
  :revdesc "12e8e0b49878"
  :keywords '("extensions")
  :maintainers '(("Adriano Martinez" . "uberkael@gmail.com")))
