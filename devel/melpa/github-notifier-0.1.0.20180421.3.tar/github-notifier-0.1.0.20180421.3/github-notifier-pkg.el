;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-notifier" "0.1.0.20180421.3"
  "Displays your GitHub notifications unread count in mode-line."
  '((emacs "24"))
  :url "https://github.com/xuchunyang/github-notifier.el"
  :commit "274f3812926ea371346f639fcee98066f6e8c96f"
  :revdesc "274f3812926e"
  :keywords '("github" "mode-line")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
