;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-latex" "0.19.1.0.20261009.4"
  "Preview LaTeX math as SVG in LaTeX buffers."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.20.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "9e32304e5e10ddaa3d1ac604b9311f81a5b0841d"
  :revdesc "v0.19.1-4-g9e32304e5e10"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
