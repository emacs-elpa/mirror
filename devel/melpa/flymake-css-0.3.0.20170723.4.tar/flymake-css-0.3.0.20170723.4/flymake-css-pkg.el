;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-css" "0.3.0.20170723.4"
  "Flymake support for css using csslint."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-css"
  :commit "de090163ba289910ceeb61b13368ce42d0f2dfd8"
  :revdesc "de090163ba28"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
