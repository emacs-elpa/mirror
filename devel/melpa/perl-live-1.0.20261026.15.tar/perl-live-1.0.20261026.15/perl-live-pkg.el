;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perl-live" "1.0.20261026.15"
  "Evaluate Perl in persistent project sessions."
  '((emacs "28.1"))
  :url "https://github.com/vividsnow/perl-live"
  :commit "d1f9a0e965821dac1af3eb174262d189d1d04da7"
  :revdesc "d1f9a0e96582"
  :keywords '("languages" "processes")
  :authors '(("vividsnow" . "https://github.com/vividsnow"))
  :maintainers '(("vividsnow" . "https://github.com/vividsnow")))
