;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lively" "0.2.0.20171005.4"
  "Interactively updating text."
  ()
  :url "https://github.com/purcell/lively"
  :commit "348675828c6a81bfa1ac311ca465aad813542c1b"
  :revdesc "348675828c6a"
  :authors '(("Luke Gorrie" . "luke@bup.co.nz"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
