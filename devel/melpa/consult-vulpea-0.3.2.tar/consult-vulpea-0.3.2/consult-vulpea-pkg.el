;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-vulpea" "0.3.2"
  "Use Consult in tandem with Vulpea."
  '((emacs   "28.1")
    (vulpea  "2.0.0")
    (consult "2.2"))
  :url "https://github.com/fabcontigiani/consult-vulpea"
  :commit "1a5546866a7a89cd77b07e0eb4d524f47faa2ae1"
  :revdesc "1a5546866a7a"
  :keywords '("convenience" "notes" "vulpea")
  :authors '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com"))
  :maintainers '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com")))
