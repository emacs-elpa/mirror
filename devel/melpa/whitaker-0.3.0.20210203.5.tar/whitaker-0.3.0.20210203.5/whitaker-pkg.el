;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whitaker" "0.3.0.20210203.5"
  "Comint interface for Whitaker's Words."
  '((emacs "25"))
  :url "https://github.com/Fuco1/whitaker"
  :commit "a6fda24ccb69a18c0706633326d5cc4fcfaed83a"
  :revdesc "a6fda24ccb69"
  :keywords '("processes")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
