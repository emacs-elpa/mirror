;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.1.5.0.20260613.5"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "948cccf6499415005a43112e5daadc6ecc57fa1c"
  :revdesc "1.1.5-5-g948cccf64994"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
