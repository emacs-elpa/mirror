;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arxiv-citation" "0.1.0.20230713.16"
  "Utility functions for dealing with arXiv papers."
  '((emacs "25.1")
    (dash  "2.19.1")
    (s     "1.12.0"))
  :url "https://gitlab.com/slotThe/arXiv-citation"
  :commit "04de0dae1121fb92c30b393449c6f8d6d940dbed"
  :revdesc "04de0dae1121"
  :keywords '("convenience")
  :authors '(("Tony Zorman" . "soliditsallgood@mailbox.org"))
  :maintainers '(("Tony Zorman" . "soliditsallgood@mailbox.org")))
