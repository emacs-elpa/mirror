;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abs-mode" "1.7.0.20260415.9"
  "Major mode for the modeling language Abs."
  '((emacs      "27.1")
    (erlang     "2.8")
    (maude-mode "0.3")
    (flymake    "1.0")
    (yasnippet  "0.14.0"))
  :url "https://github.com/abstools/abs-mode"
  :commit "a4b8d0caa61db2f37b77e15055fad8324c35f4ae"
  :revdesc "v1.7-9-ga4b8d0caa61d"
  :keywords '("languages")
  :authors '(("Rudi Schlatte" . "rudi@constantly.at"))
  :maintainers '(("Rudi Schlatte" . "rudi@constantly.at")))
