;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-vulpea" "0.3.1.0.20260913.2"
  "Use Consult in tandem with Vulpea."
  '((emacs   "28.1")
    (vulpea  "2.0.0")
    (consult "2.2"))
  :url "https://github.com/fabcontigiani/consult-vulpea"
  :commit "5f680838394fff51a9fb5c98ade3ddb29add7ac5"
  :revdesc "5f680838394f"
  :keywords '("convenience" "notes" "vulpea")
  :authors '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com"))
  :maintainers '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com")))
