;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "button-lock" "1.0.2.0.20230304.16"
  "Clickable text defined by regular expression."
  ()
  :url "https://github.com/rolandwalker/button-lock"
  :commit "1f7a89ca05b6167af7d1337ad23a5d923486caac"
  :revdesc "v1.0.2-16-g1f7a89ca05b6"
  :keywords '("mouse" "button" "hypermedia" "extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
