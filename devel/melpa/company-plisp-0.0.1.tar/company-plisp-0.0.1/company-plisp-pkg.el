;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-plisp" "0.0.1"
  "Company mode backend for PicoLisp language."
  '((emacs   "25")
    (s       "1.2.0")
    (company "0.8.12")
    (dash    "2.12.0")
    (cl-lib  "0.5"))
  :url "https://gitlab.com/sasanidas/company-plisp"
  :commit "0e6941e1832faafb2176238339667edd482acd95"
  :revdesc "0e6941e1832f"
  :keywords '("company" "plisp" "convenience" "auto-completion")
  :authors '(("Fermin MF" . "fmfs@posteo.net"))
  :maintainers '(("Fermin MF" . "fmfs@posteo.net")))
