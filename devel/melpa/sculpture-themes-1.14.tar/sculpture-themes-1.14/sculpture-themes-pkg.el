;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "1.14"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "8fc579d1f42487288ab467f0f6ef050f6ab81801"
  :revdesc "8fc579d1f424"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
