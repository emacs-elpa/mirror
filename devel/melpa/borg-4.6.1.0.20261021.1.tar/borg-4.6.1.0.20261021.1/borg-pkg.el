;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.6.1.0.20261021.1"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "3dc77282f8bbe01a4e9bcd5328ae12ed1195fa47"
  :revdesc "v4.6.1-1-g3dc77282f8bb"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
