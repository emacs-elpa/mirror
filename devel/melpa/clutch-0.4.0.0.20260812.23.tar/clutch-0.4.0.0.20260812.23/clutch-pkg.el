;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.4.0.0.20260812.23"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "3887c8c1a98128af619ef2e64952dfbf148a8508"
  :revdesc "3887c8c1a981"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
