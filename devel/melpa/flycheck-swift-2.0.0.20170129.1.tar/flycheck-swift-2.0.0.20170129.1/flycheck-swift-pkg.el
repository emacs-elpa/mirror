;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-swift" "2.0.0.20170129.1"
  "Flycheck extension for Apple's Swift."
  '((emacs    "24.4")
    (flycheck "0.25"))
  :url "https://github.com/swift-emacs/flycheck-swift"
  :commit "c6c416a1b7a7d346e5c040e4e4065abc68d3a844"
  :revdesc "c6c416a1b7a7"
  :keywords '("languages" "swift")
  :authors '(("Chris Barrett" . "chris.d.barrett@me.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.com")
             ("Arthur Evstifeev" . "lod@pisem.net"))
  :maintainers '(("Chris Barrett" . "chris.d.barrett@me.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.com")
                 ("Arthur Evstifeev" . "lod@pisem.net")))
