;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-pullrequest" "1.0.0.20170116.4"
  "Create and fetch Github Pull requests with ease."
  '((emacs   "24.4")
    (request "0.2.0")
    (dash    "2.11.0")
    (magit   "2.10.0"))
  :url "https://github.com/jakoblind/github-pullrequest"
  :commit "471816e09d1e140a0975911fe020c6c659f71209"
  :revdesc "471816e09d1e"
  :keywords '("tools")
  :authors '(("Jakob Lind" . "karl.jakob.lind@gmail.com"))
  :maintainers '(("Jakob Lind" . "karl.jakob.lind@gmail.com")))
