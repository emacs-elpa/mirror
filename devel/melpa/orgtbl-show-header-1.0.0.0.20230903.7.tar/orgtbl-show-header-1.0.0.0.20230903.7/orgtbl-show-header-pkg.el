;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-show-header" "1.0.0.0.20230903.7"
  "Show the header of the current column in the minibuffer."
  ()
  :url "https://github.com/DamienCassou/orgtbl-show-header"
  :commit "1ab18f5afa2b01e67618ada0d40e6b7a65d9d14c"
  :revdesc "1ab18f5afa2b"
  :authors '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainers '(("Damien Cassou" . "damien.cassou@gmail.com")))
