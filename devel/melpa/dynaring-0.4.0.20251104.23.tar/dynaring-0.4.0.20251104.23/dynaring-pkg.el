;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dynaring" "0.4.0.20251104.23"
  "A dynamically sized ring structure."
  '((emacs "25.1"))
  :url "https://github.com/countvajhula/dynaring"
  :commit "d74e4f36da97a64baa023e5b2519bfaac7d8b02b"
  :revdesc "0.4-23-gd74e4f36da97"
  :authors '(("Mike Mattie" . "codermattie@gmail.com")
             ("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
