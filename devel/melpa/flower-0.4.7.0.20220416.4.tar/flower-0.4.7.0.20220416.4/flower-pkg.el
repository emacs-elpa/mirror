;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flower" "0.4.7.0.20220416.4"
  "Emacs task tracker client."
  '((emacs   "24.4")
    (clomacs "0.0.4"))
  :url "https://github.com/FlowerAutomation/flower"
  :commit "047846409867b2dd0ba4e2047a414b498680cd9c"
  :revdesc "047846409867"
  :keywords '("hypermedia" "outlines" "tools" "vc")
  :authors '(("Sergey Sobko" . "flower@tpg.am"))
  :maintainers '(("Sergey Sobko" . "flower@tpg.am")))
