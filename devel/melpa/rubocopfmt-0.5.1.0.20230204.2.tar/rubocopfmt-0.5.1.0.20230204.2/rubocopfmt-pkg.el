;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rubocopfmt" "0.5.1.0.20230204.2"
  "Minor-mode to format Ruby code with RuboCop on save."
  '((cl-lib "0.5"))
  :url "https://github.com/jimeh/rubocopfmt.el"
  :commit "1c6f4f1da755c9e60eb475eb9530320726904341"
  :revdesc "0.5.1-2-g1c6f4f1da755"
  :keywords '("convenience" "wp" "edit" "ruby" "rubocop"))
