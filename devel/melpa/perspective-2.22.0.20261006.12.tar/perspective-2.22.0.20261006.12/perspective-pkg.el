;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective" "2.22.0.20261006.12"
  "Switch between named \"perspectives\" of the editor."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/nex3/perspective-el"
  :commit "718518e4cbfe6d34161bf9415a8d083777b2fbba"
  :revdesc "2.22-12-g718518e4cbfe"
  :keywords '("workspace" "convenience" "frames")
  :authors '(("Natalie Weizenbaum" . "nex342@gmail.com"))
  :maintainers '(("Natalie Weizenbaum" . "nex342@gmail.com")))
