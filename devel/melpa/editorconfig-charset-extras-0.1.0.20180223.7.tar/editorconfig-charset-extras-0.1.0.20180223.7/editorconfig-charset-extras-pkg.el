;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "editorconfig-charset-extras" "0.1.0.20180223.7"
  "Extra EditorConfig Charset Support."
  '((editorconfig "0.6.0"))
  :url "https://github.com/10sr/editorconfig-charset-extras-el"
  :commit "ddf60923c6f4841cb593b2ea04c9c710a01d262f"
  :revdesc "ddf60923c6f4"
  :keywords '("tools")
  :authors '(("10sr" . "8.slashes@gmail.com"))
  :maintainers '(("10sr" . "8.slashes@gmail.com")))
