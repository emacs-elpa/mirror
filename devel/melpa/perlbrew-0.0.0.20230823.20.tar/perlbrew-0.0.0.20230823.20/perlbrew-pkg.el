;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perlbrew" "0.0.0.20230823.20"
  "A perlbrew wrapper for Emacs."
  ()
  :url "https://github.com/kentaro/perlbrew.el"
  :commit "527b7f6a6a5edd2b779ae98029e60994391c0903"
  :revdesc "527b7f6a6a5e"
  :keywords '("emacs" "perl")
  :authors '(("Kentaro Kuribayashi" . "kentarok@gmail.com"))
  :maintainers '(("Kentaro Kuribayashi" . "kentarok@gmail.com")))
