;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "total-recall" "0.10"
  "Spaced repetition system."
  '((emacs "29.4"))
  :url "https://github.com/phf-1/total-recall"
  :commit "dba59b6f10829d5a3373f1ad6fc4b4a73134180b"
  :revdesc "dba59b6f1082"
  :authors '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com"))
  :maintainers '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com")))
