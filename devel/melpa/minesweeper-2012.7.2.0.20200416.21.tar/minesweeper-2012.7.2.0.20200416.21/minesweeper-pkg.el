;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minesweeper" "2012.7.2.0.20200416.21"
  "Play minesweeper in Emacs."
  ()
  :url "https://hg.sr.ht/~zck/minesweeper"
  :commit "d4248e3c9b3e9e7277cb9e6d081330611898f334"
  :revdesc "d4248e3c9b3e"
  :keywords '("game" "fun" "minesweeper" "inane" "diversion")
  :authors '(("Zachary Kanfer" . "zkanfer@gmail.com"))
  :maintainers '(("Zachary Kanfer" . "zkanfer@gmail.com")))
