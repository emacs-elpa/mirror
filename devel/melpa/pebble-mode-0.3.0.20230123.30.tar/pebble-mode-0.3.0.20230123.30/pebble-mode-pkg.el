;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pebble-mode" "0.3.0.20230123.30"
  "A major mode for pebble."
  '((emacs "24.3"))
  :url "https://github.com/ArneBab/pebble-mode"
  :commit "bcbc76aa89196338f12a8ddfe4486edf83c19c5e"
  :revdesc "bcbc76aa8919")
