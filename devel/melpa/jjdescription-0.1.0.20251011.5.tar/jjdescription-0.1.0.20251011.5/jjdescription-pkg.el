;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jjdescription" "0.1.0.20251011.5"
  "Major mode for editing Jujutsu description files."
  '((emacs "25.1"))
  :url "https://github.com/necaris/jjdescription.el"
  :commit "cd2478f0e2f92cb823110caba22fe0eaafeed07e"
  :revdesc "cd2478f0e2f9"
  :authors '(("Rami Chowdhury" . "rami.chowdhury@gmail.com"))
  :maintainers '(("Rami Chowdhury" . "rami.chowdhury@gmail.com")))
