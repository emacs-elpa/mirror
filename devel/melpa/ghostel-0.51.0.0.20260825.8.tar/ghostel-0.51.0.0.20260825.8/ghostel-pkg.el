;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.51.0.0.20260825.8"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "d8ee7a9ef523e054d35987349ed14ee1d791aad2"
  :revdesc "d8ee7a9ef523"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
