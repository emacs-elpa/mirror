;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-stars" "0.1.0.20190517.8"
  "Browse your Github Stars."
  '((emacs "25.1")
    (ghub  "2.0.0"))
  :url "https://github.com/xuchunyang/github-stars.el"
  :commit "bb79c80574cfff865342b6e262f2c9762edb4c15"
  :revdesc "bb79c80574cf"
  :keywords '("tools")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
