;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "po-mode" "2.32.0.20260217.5"
  "Major mode for GNU gettext PO files."
  '((emacs "23"))
  :commit "27538dd0938d5a941833d503afc9dba13dcf16fe"
  :revdesc "27538dd0938d"
  :keywords '("i18n" "gettext"))
