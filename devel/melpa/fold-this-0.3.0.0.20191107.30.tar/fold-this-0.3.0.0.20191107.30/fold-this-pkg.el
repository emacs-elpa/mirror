;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fold-this" "0.3.0.0.20191107.30"
  "Just fold this region please."
  ()
  :url "https://github.com/magnars/fold-this.el"
  :commit "c3912c738cf0515f65162479c55999e2992afce5"
  :revdesc "0.3.0-30-gc3912c738cf0"
  :keywords '("convenience")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
