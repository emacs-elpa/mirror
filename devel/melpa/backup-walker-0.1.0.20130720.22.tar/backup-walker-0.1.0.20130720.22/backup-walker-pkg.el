;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "backup-walker" "0.1.0.20130720.22"
  "Quickly traverse all backups of a file."
  ()
  :url "https://github.com/lewang/backup-walker"
  :commit "934a4128c122972ac32bb9952addf279a60a94da"
  :revdesc "934a4128c122"
  :keywords '("backup"))
