;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "1.0.0.0.20261019.438"
  "Friendly AI assistant for Ollama and cloud LLMs."
  '((emacs     "29.1")
    (transient "0.4.0"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "20121360ea56a5422c530e8a439e48c1bc761d44"
  :revdesc "20121360ea56"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
