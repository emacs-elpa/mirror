;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gleam-ts-mode" "1.0.0.0.20260902.5"
  "Major mode for Gleam."
  '((emacs "29.1"))
  :url "https://github.com/gleam-lang/gleam-mode"
  :commit "5fd0ad952e60ee0032688cb7c2d9fd09e79eff62"
  :revdesc "5fd0ad952e60"
  :keywords '("languages" "gleam")
  :authors '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainers '(("Jonathan Arnett" . "jonathan.arnett@protonmail.com")))
