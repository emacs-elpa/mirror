;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "2.32.0.20260827.64"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "d93a570f57600611d534893fa381d0cf10b85e23"
  :revdesc "d93a570f5760"
  :keywords '("languages" "lisp" "slime"))
