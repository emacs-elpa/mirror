;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-manage" "20260614.1819"
  "Manage buffers."
  '((emacs          "26.1")
    (choice-program "0.13")
    (dash           "2.17.0"))
  :url "https://github.com/plandes/buffer-manage"
  :commit "3eb4e5771ae4dc2c203d54111a32a6204949dcac"
  :revdesc "3eb4e5771ae4"
  :keywords '("internal" "maint"))
