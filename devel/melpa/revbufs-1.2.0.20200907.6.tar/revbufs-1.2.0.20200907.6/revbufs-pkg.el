;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "revbufs" "1.2.0.20200907.6"
  "Reverts all out-of-date buffers safely."
  ()
  :url "http://www.neilvandyke.org/revbufs/"
  :commit "df3c02d3063951582c693ae12547993cec8256e2"
  :revdesc "1.2-6-gdf3c02d30639"
  :keywords '("convenience" "buffers")
  :authors '(("Neil Van Dyke" . "neil@neilvandyke.org"))
  :maintainers '(("Sam Kleinman" . "sam@tychoish.com")))
