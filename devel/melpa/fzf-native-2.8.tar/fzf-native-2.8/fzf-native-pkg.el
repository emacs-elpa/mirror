;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "2.8"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "16caa6e448bb7dc3b556f314acbc323c125871e5"
  :revdesc "16caa6e448bb"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
