;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddskk-posframe" "1.0.0.0.20261122.54"
  "Show Henkan tooltip for ddskk via posframe."
  '((emacs    "26.1")
    (posframe "1.5.1")
    (ddskk    "17.2"))
  :url "https://github.com/conao3/ddskk-posframe.el"
  :commit "d468d62cbb5cd057a558ee920b7c62ea453d4e46"
  :revdesc "d468d62cbb5c"
  :keywords '("tooltip" "convenience" "posframe")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
