;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "0.2.4.0.20261007.30"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "be8d9c9598dcd03906858d64ea4d3aebee252058"
  :revdesc "be8d9c9598dc"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
