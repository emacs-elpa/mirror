;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pydoc" "0.1.0.20250910.39"
  "Functional, syntax highlighted pydoc navigation."
  ()
  :url "https://github.com/statmobile/pydoc"
  :commit "5e76e74538ac3201ad7a3526ecf16d9ac7e73310"
  :revdesc "5e76e74538ac"
  :keywords '("pydoc" "python")
  :authors '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainers '(("Brian J. Lopes" . "statmobile@gmail.com")))
