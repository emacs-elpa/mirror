;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "impatient-showdown" "0.1.2.0.20260101.57"
  "Preview markdown buffer live over HTTP using showdown."
  '((emacs          "24.3")
    (impatient-mode "1.1"))
  :url "https://github.com/jcs-elpa/impatient-showdown"
  :commit "19c4f7b2561bce8b0e186655660a22ed369707eb"
  :revdesc "19c4f7b2561b"
  :keywords '("convenience" "live" "preview" "markdown" "http" "server" "impatient")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
