;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sdml-mode" "0.2.0.0.20251030.17"
  "Major mode for SDML."
  '((emacs              "28.1")
    (tree-sitter        "0.18.0")
    (tree-sitter-indent "0.4"))
  :url "https://github.com/sdm-lang/emacs-sdml-mode"
  :commit "3b2430df46a026e70a69da019afa8f40a8ed9225"
  :revdesc "v0.2.0-17-g3b2430df46a0"
  :keywords '("languages" "tools")
  :authors '(("Simon Johnston" . "johnstonskj@gmail.com"))
  :maintainers '(("Simon Johnston" . "johnstonskj@gmail.com")))
