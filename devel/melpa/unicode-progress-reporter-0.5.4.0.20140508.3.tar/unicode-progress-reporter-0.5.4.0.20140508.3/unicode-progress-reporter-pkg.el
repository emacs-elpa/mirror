;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-progress-reporter" "0.5.4.0.20140508.3"
  "Progress-reporter with fancy characters."
  '((emacs           "24.1.0")
    (ucs-utils       "0.7.6")
    (list-utils      "0.4.2")
    (persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/unicode-progress-reporter"
  :commit "17415a96144506e5ffa49377d4c814023e06f425"
  :revdesc "v0.5.4-3-g17415a961445"
  :keywords '("interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
