;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "0.34.1.0.20260326.5"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "07094dac902e452d59533e4d01e8177afaa0cfd1"
  :revdesc "0.34.1-5-g07094dac902e"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
