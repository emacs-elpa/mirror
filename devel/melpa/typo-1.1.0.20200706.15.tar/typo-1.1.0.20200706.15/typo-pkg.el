;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typo" "1.1.0.20200706.15"
  "Minor mode for typographic editing."
  ()
  :url "https://github.com/jorgenschaefer/typoel"
  :commit "173ebe4fc7ac38f344b16e6eaf41f79e38f20d57"
  :revdesc "v1.1-15-g173ebe4fc7ac"
  :keywords '("convenience" "wp")
  :authors '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainers '(("Jorgen Schaefer" . "forcer@forcix.cx")))
