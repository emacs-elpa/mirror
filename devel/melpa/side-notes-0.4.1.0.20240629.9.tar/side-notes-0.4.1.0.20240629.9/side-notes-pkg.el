;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "side-notes" "0.4.1.0.20240629.9"
  "Easy access to a directory notes file."
  '((emacs "24.4"))
  :url "https://github.com/rnkn/side-notes"
  :commit "96a142dfd5768d66b1d574027e13c572e4c82a87"
  :revdesc "96a142dfd576"
  :keywords '("convenience")
  :authors '(("Paul W. Rankin" . "rnkn@rnkn.xyz"))
  :maintainers '(("Paul W. Rankin" . "rnkn@rnkn.xyz")))
