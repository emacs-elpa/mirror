;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "6.3.1.0.20260710.59"
  "Edit, debug, develop, run Python programs."
  '((emacs "24"))
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "dbbfaa9bbfa1e330f4d9ec81b3793fbb2a297ecd"
  :revdesc "6.3.1-59-gdbbfaa9bbfa1"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
