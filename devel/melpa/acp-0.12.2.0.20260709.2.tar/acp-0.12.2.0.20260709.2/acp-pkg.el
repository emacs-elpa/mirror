;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "0.12.2.0.20260709.2"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "5140f4121156707245567b8fc3072d4c3b5c867f"
  :revdesc "5140f4121156")
