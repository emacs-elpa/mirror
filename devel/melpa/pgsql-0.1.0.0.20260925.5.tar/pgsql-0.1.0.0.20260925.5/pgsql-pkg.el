;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "0.1.0.0.20260925.5"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "9dbf135d16393c9d849ebd85543a6143fc42a8f9"
  :revdesc "v0.1.0-5-g9dbf135d1639"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
