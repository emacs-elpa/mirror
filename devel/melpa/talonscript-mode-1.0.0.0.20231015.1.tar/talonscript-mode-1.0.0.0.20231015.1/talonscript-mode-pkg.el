;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "talonscript-mode" "1.0.0.0.20231015.1"
  "Major mode for Talon Voice's .talon files."
  '((emacs "24.3"))
  :url "https://github.com/jcaw/talonscript-mode"
  :commit "b5e78b7866c9dee5f8bc5ce3924e1916c46e2b9b"
  :revdesc "b5e78b7866c9"
  :keywords '("languages")
  :authors '(("Jcaw" . "toastedjcaw@gmail.com"))
  :maintainers '(("Jcaw" . "toastedjcaw@gmail.com")))
