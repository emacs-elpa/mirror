;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spotlight" "0.2.0.0.20200109.20"
  "Search files with Mac OS X spotlight."
  '((emacs   "24.1")
    (swiper  "0.6.0")
    (counsel "0.6.0"))
  :url "http://www.pragmaticemacs.com"
  :commit "ea71f4fd380c51e50c47bb25855af4f40e4d8da0"
  :revdesc "ea71f4fd380c"
  :keywords '("search" "external")
  :authors '(("Ben Maughan" . "benmaughan@gmail.com"))
  :maintainers '(("Ben Maughan" . "benmaughan@gmail.com")))
