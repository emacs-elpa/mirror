;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "1.4.0.0.20260928.141"
  "Major mode for Godot's GDScript language."
  '((emacs "29.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "fc7b7ece95da9ca0ffaafc602ac9c861f533f331"
  :revdesc "fc7b7ece95da"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
