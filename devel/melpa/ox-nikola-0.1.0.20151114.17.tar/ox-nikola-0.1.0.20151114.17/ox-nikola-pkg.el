;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-nikola" "0.1.0.20151114.17"
  "Export Nikola articles using org-mode."
  '((emacs  "24.4")
    (org    "8.2.4")
    (ox-rst "0.2"))
  :url "https://github.com/masayuko/ox-nikola"
  :commit "5bcbc1a38f6619f62294194f13ca0cd4ca14dd48"
  :revdesc "5bcbc1a38f66"
  :keywords '("org" "nikola")
  :authors '(("IGARASHI Masanao" . "syoux2@gmail.com"))
  :maintainers '(("IGARASHI Masanao" . "syoux2@gmail.com")))
