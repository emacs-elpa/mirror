;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.0.2.0.20260907.2"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.3.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "894d1e7be124ecbdfcb203d9c22b627b61620ace"
  :revdesc "v3.0.2-2-g894d1e7be124"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
