;;; gptel-annotate.el --- Annotate files or buffers with LLMs  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Karthik Chikmagalur

;; Author: Karthik Chikmagalur <karthikchikmagalur@gmail.com>
;; Package-Version: 0.0.5.0.20260928.3
;; Package-Revision: ec65d175b7a1
;; Package-Requires: ((emacs "29.1") (compat "30.1.0.0") (gptel "0.9.9.5"))
;; Keywords: comm
;; URL: https://github.com/karthink/gptel-annotate

;; SPDX-License-Identifier: GPL-3.0-or-later

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; `gptel-annotate' is an extension for `gptel' that allows you to use Large
;; Language Models (LLMs) to annotate buffers or files with suggestions,
;; warnings, or notes.  It usees Emacs' built-in Flymake minor mode to
;; display the LLM-generated diagnostics.
;;
;; Usage:
;;
;; There are two ways: as a command or as a gptel preset.  The latter is
;; generally more useful.
;;
;; To annotate a file or buffer, run `M-x gptel-annotate'.  This command prompts
;; for the instructions to send to the LLM and the target sources (files or
;; buffers) to annotate.  By default, it annotates the current buffer, but with
;; a prefix argument (`C-u') it lets you specify multiple buffers and files.
;;
;; When used in a regular chat session you can omit the instructions to read
;; them from the prompt in the chat buffer instead.
;;
;; In addition to the interactive command, `gptel-annotate' can be used
;; directly within any prompt by applying the `gptel-annotate'
;; preset, by inserting `@gptel-annotate' followed by file or buffer names in
;; the prompt.  For instance, consider this hypothetical prompt:
;;
;; ------------------------------------------------------------------------
;; *prompt*: Highlight any flaws in the design and architecture of the
;; work-in-progress "sidle" and "viewport" libraries, ignoring any low level
;; issues that will be caught by the byte-compiler.
;;
;; @gptel-annotate sidle.el "viewport.el"
;; ------------------------------------------------------------------------
;;
;; When typed anywhere in Emacs and sent with `gptel-send', this request will
;; include the contents of the buffers (or files) "sidle.el" and "viewport.el",
;; and the LLM's targeted responses will be displayed as flymake annotations in
;; these two buffers.  (Using "quotes" around the buffer/file names is
;; recommended.)
;;
;; You can also include the @gptel-annotate cookie without specifying any
;; buffers or files, and the LLM will attempt to annotate the right buffer based
;; on the conversation context.  This is useful if the LLM has already examined
;; the source location in earlier conversation turns.  Example:
;;
;; ------------------------------------------------------------------------
;; *prompt*: Provide a short summary of each link in the blog
;; post, along with a readability rating out of 10.  @gptel-annotate
;; ------------------------------------------------------------------------
;;
;; Presumably, it is clear in this context which buffer "blog post" refers to.
;;
;; The LLM's response is parsed, and annotations are automatically
;; applied to the relevant buffers as Flymake diagnostics.

;;; Code:

(require 'cl-lib)
(require 'gptel)
(require 'subr-x)
(require 'flymake)
(require 'thingatpt)

;;;; Variables and user options
(defcustom gptel-annotate-post-hook nil
  "Hook called when a `gptel-annotate' session ends."
  :group 'gptel-annotate
  :type 'hook)

(defvar-keymap gptel-annotate-actions-map
  :doc "Actions on gptel annotation at point."
  "C-c C-k"      #'gptel-annotate-clear
  "C-c C-a"      #'gptel-annotate-accept
  "C-c C-i"      #'gptel-annotate-inspect
  "C-<down-mouse-1>"  #'gptel-annotate-accept-mouse)

(defvar gptel-annotate-response-schema
  '( :type object
     :properties
     ( :items
       ( :type array
         :minItems 0
         :items
         ( :type object
           :properties
           ( :file_name
             ( :type string
               :description "Name of the file or buffer to which this diagnostic applies.")
             :start_line
             ( :type integer
               :description "Starting line number of text to which this diagnostic applies")
             :text (:type string :description "Buffer or file text to which this diagnostic applies")
             :diagnostic (:type string :description "Brief diagnostic note or warning.")
             :replacement_text ( :type string
                                 :description "Exact replacement text or fix for this diagnostic.  \
Must be left empty if no replacement is required and this is only a note.")))))))

(defvar-local gptel-annotate--sources nil
  "List of sources (buffers or files) for which annotations are generated.
This is intended to be set buffer-locally or let-bound by
`gptel-annotate' at the time of request.")

(defvar-local gptel-annotate--diagnostics nil
  "Diagnostics generated by `gptel-annotate' for a buffer.
This is a list of vectors, one for each call to `gptel-annotate' in that
buffer.")

(defvar gptel-annotate-preset-capf--marker (make-marker)
  "Marker for rich completions with the \"@gptel-annotate\" preset.")

(defconst gptel-annotate--response-buffer "*gptel-annotate*"
  "Buffer holding intermediate LLM responses (like reasoning).
Its main purpose is as a sink to avoid spewing text everywhere in
`gptel-annotate' requests.")

;;;; Flymake backend setup
(defun gptel-annotate--find-text-bounds (text)
  "Find bounds of TEXT near point heuristically."
  ;; TODO: Use word-search-forward/backward in text-mode bufs
  (or (and (or (save-excursion (search-forward text nil t))
               (search-backward text nil t))
           (cons (match-beginning 0)    ;word-search matches trailing whitespace
                 (progn (goto-char (match-beginning 0)) (end-of-line)
                        (min (point) (match-end 0)))))
      (when (length> text 80)      ;Heuristic: look for chunks and adjust bounds
        (cl-loop
         with chunk-size = (floor (length text) 4)
         with rem = (mod (length text) 4)
         for idx in '(1 2 3)        ;We search for each quarter of TEXT
         for offset =             ;Record any whitespace offset at chunk start
         (cl-loop for i from 0
                  for pos = (+ (* idx chunk-size) i)
                  unless (and (<= pos (length text))
                              (memq (aref text pos) '(?  ?\t ?\n)))
                  return i)
         for split-text =
         (word-search-regexp
          (substring text (+ (* idx chunk-size) (or offset 0)) (* (1+ idx) chunk-size)) t)
         ;; Description of `word-search-regexp' is wrong; lax does handle word
         ;; boundary at front of text:
         if (string-prefix-p "\\<" split-text)
         do (setq split-text (substring split-text 2))
         if (or (save-excursion (re-search-forward split-text nil t))
                (re-search-backward split-text nil t))
         return
         (let* ((start (- (match-beginning 0) (* idx chunk-size) (or offset 0)))
                (end (min (+ (match-end 0) (* (- 2 idx) chunk-size) rem)
                          (progn (goto-char start) (line-end-position)))))
           (cons start end))))))

(defun gptel-annotate--make-diagnostics (array buffer &optional offset-beg)
  "Return a list of flymake diagnostics from ARRAY for BUFFER.

Start from char OFFSET-BEG if provided."
  ;; ARRAY corresponds to the diagnostics JSON schema used in the LLM response.
  (save-excursion
    (delq nil
          (mapcar
           (pcase-lambda ((map :start_line :text :diagnostic :replacement_text))
             (when (and diagnostic (not (string-empty-p diagnostic)))
               (goto-char (or offset-beg (point-min)))
               (forward-line (1- start_line))
               (and-let* (((stringp text))
                          (bounds (gptel-annotate--find-text-bounds text)))
                 (flymake-make-diagnostic
                  buffer (car bounds) (cdr bounds)
                  (if (and replacement_text
                           (not (string-blank-p replacement_text)))
                      :warning :note)
                  diagnostic (list diagnostic replacement_text)
                  `((gptel-annotate . t)
                    ;; (mouse-face . highlight)
                    (keymap . ,gptel-annotate-actions-map))))))
           array))))

(defun gptel-annotate--flymake-setup (response info)
  "Start flymake with diagnostics from RESPONSE.

INFO is the request plist containing the source buffers for the
diagnostics."
  (unless (string-match-p "\\`\\s-*{" response)
    ;; Try to handle partially schema-compliant responses
    ;; TODO: substring to closing "}" and ignore trailing garbage
    (when-let* ((brace-start (string-search "{" response)))
      (setq response (substring response brace-start))))

  (let ((source-buffers))
    (condition-case-unless-debug nil
        (let ((diag-array (plist-get (gptel--json-read-string response) :items)))
          ;; Gather list of sources (live buffers to which diagnostics apply)
          (dolist (source (ensure-list
                           (or (plist-get (plist-get info :context) :annotate)
                               ;; No explicit source list, get sources from diagnostics in response
                               (delete-dups
                                (mapcar (lambda (diag) (plist-get diag :file_name)) diag-array)))))
            (cond
             ((and-let* ((source-buf (get-buffer source)))
                (if (buffer-live-p source-buf)
                    (push source-buf source-buffers)
                  (display-warning
                   'gptel-annotate
                   (format "Source buffer %s has been killed, aborting gptel annotation in this buffer"
                           source))
                  nil)))
             ((if-let* (((file-readable-p source))
                        (buf (or (find-buffer-visiting source) (find-file-noselect source))))
                  (push buf source-buffers)
                (display-warning
                 'gptel-annotate
                 (format "Source file %s not readable, aborting gptel annotation in this file"
                         source))))))

          ;; Set up flymake diagnostics in source buffers
          (when source-buffers
            (let ((setup (lambda (buf arr)
                           "Create annotations in BUF from ARR."
                           (with-current-buffer buf
                             (push arr gptel-annotate--diagnostics)
                             (add-hook 'flymake-diagnostic-functions
                                       #'gptel-annotate-flymake nil t)
                             (if flymake-mode (flymake-start nil t) (flymake-mode 1))))))
              (if (= (length source-buffers) 1) ;most common case
                  (funcall setup (car source-buffers) diag-array)
                ;; Sort diag-array elements by buffer and set up each one
                (cl-loop with diags-alist
                         for diag across diag-array
                         for dest = (let ((f (plist-get diag :file_name)))
                                      (or (get-buffer f)
                                          (find-buffer-visiting f)))
                         if dest do (push diag (alist-get it diags-alist))
                         finally do
                         (cl-loop for (buf . buf-diags) in diags-alist
                                  do (funcall setup buf (vconcat buf-diags))))))))
      (error
       (with-current-buffer (get-buffer-create gptel-annotate--response-buffer)
         (goto-char (point-max)) (insert response))
       (message "`gptel-annotate' could not parse LLM response. \
See buffer %s for the raw annotation"
                (propertize gptel-annotate--response-buffer 'face 'bold)))
      (:success (message "gptel-annotations available in: %s"
                         (mapconcat (lambda (b) (propertize (buffer-name b) 'face 'bold))
                                    source-buffers ", "))
                (run-hook-with-args 'gptel-annotate-post-hook source-buffers)))))

(cl-defun gptel-annotate-flymake
    (report-fn &key _recent-changes _changes-start _changes-end &allow-other-keys)
  "Report suggestions or errors generated by LLMs.

REPORT-FN is the flymake callback, see `flymake-diagnostic-functions'."
  (when gptel-annotate--diagnostics
    (funcall report-fn
             (gptel-annotate--make-diagnostics (car gptel-annotate--diagnostics)
                                               (current-buffer)))))

;;;; Flymake backend dispatch actions

(defsubst gptel-annotate--diag-at (&optional pos)
  "Find any gptel annotation flymake diagnostic at POS."
  (cl-some
   (lambda (diag) (and (alist-get 'gptel-annotate
                             (flymake--diag-overlay-properties diag))
                  diag))
   (flymake-diagnostics pos)))

(defun gptel-annotate--all-diags ()
  "Return all gptel annotation flymake diagnostics in the buffer."
  (cl-remove-if-not
   (lambda (diag) (alist-get 'gptel-annotate
                        (flymake--diag-overlay-properties diag)))
   (flymake-diagnostics)))

(defun gptel-annotate--clear (diag)
  "Remove flymake DIAG from gptel annotations."
  (setcar gptel-annotate--diagnostics
          (cl-delete diag (car gptel-annotate--diagnostics)
                     :test (lambda (dg stored)
                             (equal (car (flymake-diagnostic-data dg))
                                    (plist-get stored :diagnostic))))))

(defun gptel-annotate--rotate-group ()
  "Cycle to the next available gptel annotations group."
  (when gptel-annotate--diagnostics
    (setq gptel-annotate--diagnostics
          (append (cdr gptel-annotate--diagnostics)
                  (list (car gptel-annotate--diagnostics))))))

(defun gptel-annotate-clear (pos &optional all)
  "Clear gptel annotation(s) at POS, defaulting to point.
With prefix argument ALL, clear all annotations in the current group
after prompting for confirmation."
  (interactive (list (point) current-prefix-arg))
  (if all
      (when (or noninteractive
                (y-or-n-p "Clear all gptel annotations in group? "))
        (pop gptel-annotate--diagnostics)
        (flymake-start))
    (if-let* ((diag (gptel-annotate--diag-at pos)))
        (progn (gptel-annotate--clear diag)
               (if (and (consp gptel-annotate--diagnostics)
                        (memq (car gptel-annotate--diagnostics)
                              (list [] nil)))
                   (pop gptel-annotate--diagnostics))
               (flymake-start))
      (message "No annotation found at point"))))

;;;; Text replacement actions
(defun gptel-annotate-accept (pos)
  "Replace annotated text at POS with the LLM-suggested replacement.
If there is no annotation at POS, or the annotation has no replacement
text, display a message instead."
  (interactive (list (point)))
  (if-let* ((diag (gptel-annotate--diag-at pos))
            (ov (flymake--diag-overlay diag))
            (replacement (cadr (flymake-diagnostic-data diag)))
            ((not (string-blank-p replacement))))
      (progn
        (gptel-annotate--clear diag)
        (let ((beg (overlay-start ov))
              (end (overlay-end ov)))
          (delete-overlay ov)
          (save-excursion
            (goto-char beg)
            (delete-region beg end)
            (insert-and-inherit replacement)))
        (when (and (consp gptel-annotate--diagnostics)
                   (memq (car gptel-annotate--diagnostics) (list [] nil)))
          (pop gptel-annotate--diagnostics))
        (flymake-start))
    (message (if (gptel-annotate--diag-at pos)
                 "No replacement text available for annotation at point"
               "No gptel annotation at point"))))

(defun gptel-annotate-accept-mouse (event)
  "Replace annotated text at the mouse click position.
EVENT is the mouse click event."
  (interactive "e")
  (gptel-annotate-accept (posn-point (event-start event))))

(defun gptel-annotate--show-replacement (diag)
  "Show an inline replacement preview for DIAG on its overlay."
  (let ((ov (flymake--diag-overlay diag))
        (replacement (cadr (flymake-diagnostic-data diag))))
    (overlay-put
     ov 'after-string
     (concat (propertize "→" 'face '(:inherit bold shadow))
             (propertize replacement 'face 'diff-added)))
    (overlay-put ov 'face 'diff-removed)
    (keymap-set (overlay-get ov 'keymap) "q" #'gptel-annotate-inspect)))

(defun gptel-annotate--hide-replacement (diag)
  "Hide the inline replacement preview for DIAG."
  (let ((ov (flymake--diag-overlay diag)))
    (overlay-put ov 'after-string nil)
    (overlay-put ov 'face 'flymake-warning)
    (keymap-unset (overlay-get ov 'keymap) "q")))

(defun gptel-annotate-inspect (pos &optional all)
  "Toggle an inline preview of the replacement for annotation at POS.
Calling again clears the preview.

With prefix argument ALL, toggle previews for all annotations in the
buffer: if any are currently shown, hide them all; otherwise show all
that have replacement text."
  (interactive (list (point) current-prefix-arg))
  (require 'diff-mode)
  (let* ((candidates (if all (gptel-annotate--all-diags)
                       (list (gptel-annotate--diag-at pos))))
         (diags (cl-delete-if-not
                 (lambda (diag)
                   (and diag
                        (let ((rep (cadr (flymake-diagnostic-data diag))))
                          (and rep (not (string-blank-p rep))))))
                 candidates)))
    (cond
     ((null diags)
      (message
       (cond
        (all "No replaceable gptel annotations in buffer")
        ((gptel-annotate--diag-at pos)
         "No replacement text available to preview for annotation at point")
        (t "No gptel annotation at point"))))
     ;; If any are currently showing, hide all
     ((cl-some (lambda (d) (overlay-get (flymake--diag-overlay d) 'after-string))
               diags)
      (mapc #'gptel-annotate--hide-replacement diags))
     ;; Otherwise show all
     (t
      (mapc #'gptel-annotate--show-replacement diags)))))

;;;; gptel request setup

(defun gptel-annotate--request-context (fsm)
  "Prepare the request in FSM for annotation.
Store `gptel-annotate--sources' as the request context and wrap the
existing callback (or the default gptel callback) with an
annotation-aware handler."
  (let* ((info (gptel-fsm-info fsm))
         (stream (plist-get info :stream))
         (state (plist-get info :context))
         (cb (plist-get info :callback)))
    (plist-put info :context
               (plist-put state :annotate gptel-annotate--sources))
    (plist-put info :callback
               (if stream
                   (gptel-annotate--wrap-stream-callback
                    (or cb #'gptel-curl--stream-insert-response))
                 (gptel-annotate--wrap-callback
                  (or cb #'gptel--insert-response))))))

(defmacro gptel-annotate--call-inner (callback response info raw)
  "Call `gptel-request' CALLBACK with RESPONSE accounting for arity.

INFO is the request plist, RAW is used internally by `gptel-send' for
formatting parts of responses."
  ;; gptel-send's default callbacks have an arity of 3 because they call
  ;; themselves for inserting special blocks
  `(if (> (cdr (func-arity ,callback)) 2)
       (funcall ,callback ,response ,info ,raw) ;plumb everything else through
     (funcall ,callback ,response ,info)))

(defun gptel-annotate--wrap-callback (callback)
  "Wrap FSM's CALLBACK to annotate the required buffers or files."
  (lambda (response info &optional raw)
    (pcase response
      ((pred stringp)                   ;we take over (for annotation)
       (let ((flymake-setup-buf
              (if (buffer-live-p (plist-get info :buffer))
                  (plist-get info :buffer) (current-buffer))))
         ;; Try to handle relative paths to files to be annotated correctly
         (with-current-buffer flymake-setup-buf
           (gptel-annotate--flymake-setup response info))))
      (_ (gptel-annotate--call-inner callback response info raw)))))

;; FIXME: Broken for Anthropic (and Anthropic only)
(defun gptel-annotate--wrap-stream-callback (callback)
  "Wrap FSM's streaming CALLBACK to annotate the required buffers or files."
  (let (accum-response)
    (lambda (response info &optional raw)
      (pcase response
        ((pred stringp)
         (push response accum-response))
        ('t                             ;Streaming is done
         (gptel-annotate--call-inner callback response info raw)
         (if-let* ((tool-use (plist-get info :tool-use))) ;Did we stop to run tools?
             (setq accum-response nil)  ;Yes, so do nothing
           (let ((flymake-setup-buf
                  (if (buffer-live-p (plist-get info :buffer))
                      (plist-get info :buffer) (current-buffer))))
             ;; Try to handle relative paths to files to be annotated correctly
             (with-current-buffer flymake-setup-buf
               (gptel-annotate--flymake-setup
                (apply #'concat (nreverse accum-response)) info)))
           (setq accum-response nil)))
        (_ (gptel-annotate--call-inner callback response info raw))))))

(defun gptel-annotate-system-prompt-default ()
  "Create a system prompt instructing the LLM to annotate SOURCES."
  (format
   "\n\n<response_format>
To carry out the user's instructions, generate annotations for the %s \
file(s) or buffer(s)%saccording to the provided JSON schema.  \
These will be included as diagnostics (notes or linter-style suggestions) in the buffers.

Respond ONLY in the provided JSON schema.
</response_format>"
   (if gptel-annotate--sources "following" "relevant")
   (if gptel-annotate--sources
       (concat
        ":\n\n"
        (mapconcat
         (lambda (source) (concat "- " (if (bufferp source) (buffer-name source) source)))
         (ensure-list gptel-annotate--sources) "\n")
        "\n\n")
     " (deduced from context), ")))

(defvar gptel-annotate-system-prompt #'gptel-annotate-system-prompt-default)

(defun gptel-annotate--pre ()
  "Parse file or buffer names after point into `gptel-annotate--sources'."
  (skip-syntax-forward " " (line-end-position))
  (while-let ((_ (not (or (eolp) (eobp))))
              (source (if (eq (char-after) ?\")
                          (read (current-buffer))
                        (prog1 (thing-at-point 'filename)
                          (goto-char (match-end 0))))))
    (skip-syntax-forward " " (line-end-position))
    (cl-callf substring-no-properties source)
    (cond
     ((file-readable-p source)
      (if (or (file-regular-p source)
              (and (file-directory-p source)
                   (or noninteractive
                       (y-or-n-p
                        (format "Annotate ALL files in directory \"%s\"? "
                                (file-name-as-directory source))))))
          (push source gptel-annotate--sources)
        (user-error "gptel-annotate request canceled")))
     ((buffer-live-p (get-buffer source))
      (push (get-buffer source) gptel-annotate--sources))
     (t (unless (or noninteractive
                    (y-or-n-p
                     (format "Cannot find source \"%s\" to @annotate, \
continue with gptel request? " source)))
          (user-error "gptel-annotate request aborted"))
      (message "Ignoring @annotate %s, file not readable" source))))
  gptel-annotate--sources)

(defun gptel-annotate-preset-capf ()
  "Completion-at-point function for the \"@gptel-annotate\" preset.

When point follows an \"@gptel-annotate\" trigger on the current line,
this provides completion over buffer names and file names relative to
`default-directory'.  Buffer/file names are inserted quoted."
  (save-excursion
    (when-let* ((p (point))
                (num (skip-chars-backward "^[:space:]\""))
                (prefix-pos
                 (search-backward "@gptel-annotate" (line-beginning-position) t)))
      (move-marker gptel-annotate-preset-capf--marker (+ p num) (current-buffer))
      (list (+ p num) p
            ;; TODO: Add completion metadata/annotation support
            (completion-table-merge #'internal-complete-buffer
                                    #'read-file-name-internal)
            :exclusive 'no
            :exit-function
            (lambda (str status)
              (when (memq status '(finished sole exact))
                ;; We would prefer to use `completion-in-region--data' to
                ;; replace the match, but it's only populated by Emacs' default
                ;; completion system.
                ;; Handle offsets to accommodate existing "quotes"
                (let ((before (if (equal (char-before gptel-annotate-preset-capf--marker) ?\")
                                  1 0))
                      (after  (if (equal (char-after) ?\") 1 0)))
                  (delete-region (- gptel-annotate-preset-capf--marker before)
                                 (+ (point) after)))
                  (move-marker gptel-annotate-preset-capf--marker nil)
                  ;; Insert quoted buffer/file name
                  (insert (format "%S" (substring-no-properties str)))))))))

(defun gptel-annotate--augment-system-prompt (sys)
  "Return a gptel system prompt function including annotation instructions.

SYS is the original system prompt, to be augmented."
  (lambda ()
    (list (concat (car (gptel--parse-directive
                        gptel-annotate-system-prompt 'raw))
                  (car (gptel--parse-directive sys 'raw))))))

(defvar gptel-annotate--preset
  (list
   :description "Annotate buffers with LLM responses/diagnostics.  \
Specify files or buffers to annotate by listing them after @gptel-annotate."
   :prompt-transform-functions
   `(:function ,(lambda (ptf) (cons #'gptel-annotate--request-context ptf)))
   :use-context 'system
   :context `( :function
               ,(lambda (context) (nconc gptel-annotate--sources context)))
   :schema gptel-annotate-response-schema
   :system `(:function ,#'gptel-annotate--augment-system-prompt))
  "Base preset for `gptel-annotate' requests.

To be useful, this needs to be combined with some way of setting
`gptel-annotate--sources', the list of sources (files or buffers to
annotate).")

;; Add a preset meant for calling from the prompt using @gptel-annotate
(apply #'gptel-make-preset 'gptel-annotate
       :pre #'gptel-annotate--pre gptel-annotate--preset)

(defun gptel-annotate-rotate (arg)
  "Rotate through gptel annotation groups in this buffer.
ARG is the number of groups to rotate."
  (interactive "p")
  (cond
   ((null (car-safe gptel-annotate--diagnostics))
    (message "No gptel annotations available!"))
   ((null (cdr-safe gptel-annotate--diagnostics))
    (message "No other gptel annotations available!"))
   (t (dotimes (_ (abs arg)) (gptel-annotate--rotate-group))))
  (when flymake-mode (flymake-start)))

;;;###autoload
(defun gptel-annotate (sources prompt)
  "Annotate SOURCES (files or buffers) with LLM suggestions.

SOURCES is the current buffer by default.  If `prefix-arg' is set, query
for buffers and files to annotate instead.  Multiple buffers and files
can be specified.

PROMPT contains the instructions, read from the buffer at point (like
`gptel-send') or explicitly provided.

The annotations are displayed using flymake."
  (interactive
   (let ((source-bufs
          (if current-prefix-arg
              (completing-read-multiple "Annotate buffer(s) (empty for none):"
                                        #'internal-complete-buffer nil t)
            (list (buffer-name))))
         (source-files
          (and current-prefix-arg
               (completing-read-multiple "Annotate file(s) (empty for none): "
                                         #'read-file-name-internal nil t)))
         (p (read-string "Instructions for annotating \
(leave empty to read from conversation at point): ")))
     (list (nconc (mapcar #'get-buffer source-bufs) source-files)
           (if (string-blank-p p) nil p))))
  (unless sources
    (user-error "No sources (files or buffers) specified, canceling gptel-annotate"))
  (let ((gptel-annotate--sources sources)
        (fsm (gptel-make-fsm
              :table gptel-send--transitions
              :handlers gptel-send--handlers)))
    (gptel-with-preset gptel-annotate--preset
      (gptel-request prompt
        ;; FIXME: :schema cannot be applied via `gptel-with-preset'
        :schema gptel-annotate-response-schema
        :stream gptel-stream
        :transforms gptel-prompt-transform-functions
        :fsm fsm))
    ;; Assume that unless we are in a chat buffer, it's not safe to insert the
    ;; response accoutrements (like the reasoning text) here.
    (let ((info (gptel-fsm-info fsm)))
      (unless (buffer-local-value 'gptel-mode (plist-get info :buffer))
        (with-current-buffer (get-buffer-create gptel-annotate--response-buffer)
          (goto-char (point-max)) (insert "\n\n")
          (move-marker (plist-get info :position) (point) (current-buffer)))))
    (message "Querying %s for annotations..."
             (thread-first (gptel-fsm-info fsm)
                           (plist-get :backend)
                           (or gptel-backend)
                           (gptel-backend-name)))
    (gptel--update-status " Waiting..." 'warning)))

(provide 'gptel-annotate)
;;; gptel-annotate.el ends here
