;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "20260611.2103"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "272d9e23b147747ff2fd9c0550a81a86b276caa2"
  :revdesc "272d9e23b147"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
