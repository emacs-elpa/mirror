;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-llm" "0.1.0.0.20251208.7"
  "Use `llm' as an Org Babel language."
  '((emacs "27.1"))
  :url "https://github.com/sunflowerseastar/ob-llm"
  :commit "16237613f3ce1fd909544ef8acc402674c482ed0"
  :revdesc "16237613f3ce"
  :keywords '("llm" "org-mode" "tools" "convenience" "org" "babel")
  :authors '(("Grant Surlyn" . "grant@sunflowerseastar.com"))
  :maintainers '(("Grant Surlyn" . "grant@sunflowerseastar.com")))
