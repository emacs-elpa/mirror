;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-spotify-plus" "0.1.0.20190913.33"
  "Control Spotify search and select music with Helm."
  '((emacs "24.4")
    (helm  "2.0.0")
    (multi "2.0.1"))
  :url "https://github.com/wandersoncferreira/helm-spotify-plus"
  :commit "c3922ec368250965e483876cde5880d88a40a71b"
  :revdesc "c3922ec36825"
  :authors '(("Wanderson Ferreira and Luis Moneda" . "https://github.com/lgmoneda"))
  :maintainers '(("Wanderson Ferreira and Luis Moneda" . "https://github.com/lgmoneda")))
