;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-box" "1.14.1.0.20260903.24"
  "Display documentation in childframe."
  '((emacs "27.1"))
  :url "https://github.com/casouri/eldoc-box"
  :commit "89900de72dca291d5914ffc5da701b3170704229"
  :revdesc "89900de72dca"
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
