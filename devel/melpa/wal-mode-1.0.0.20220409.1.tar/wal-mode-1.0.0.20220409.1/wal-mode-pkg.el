;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wal-mode" "1.0.0.20220409.1"
  "A major mode for the WAL programming language."
  '((emacs "25.1"))
  :url "https://github.com/LucasKl/wal-major-mode"
  :commit "16733847f04af1929e590ff3e41f554baa3ba640"
  :revdesc "16733847f04a"
  :keywords '("languages")
  :authors '(("Lucas Klemmer" . "lucas.klemmer@jku.at"))
  :maintainers '(("Lucas Klemmer" . "lucas.klemmer@jku.at")))
