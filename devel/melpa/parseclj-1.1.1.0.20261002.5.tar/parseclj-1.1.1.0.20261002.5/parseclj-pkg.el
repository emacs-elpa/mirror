;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parseclj" "1.1.1.0.20261002.5"
  "Clojure/EDN parser."
  '((emacs "26.1"))
  :url "https://github.com/clojure-emacs/parseclj"
  :commit "99771739844cc567db6836649cfc7068c5741a4f"
  :revdesc "v1.1.1-5-g99771739844c"
  :keywords '("lisp" "clojure" "edn" "parser")
  :authors '(("Arne Brasseur" . "arne@arnebrasseur.net"))
  :maintainers '(("Arne Brasseur" . "arne@arnebrasseur.net")))
