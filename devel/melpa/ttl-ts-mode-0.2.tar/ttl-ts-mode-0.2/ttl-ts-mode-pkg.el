;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ttl-ts-mode" "0.2"
  "RDF Turtle editing mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/nutcase/ttl-ts-mode"
  :commit "2c6ad692170e95bd881cd3d62564aa8ee7b00539"
  :revdesc "2c6ad692170e"
  :keywords '("languages" "files" "rdf" "turtle" "treesitter")
  :authors '(("Julian Flake" . "flake@uni-koblenz.de"))
  :maintainers '(("Julian Flake" . "flake@uni-koblenz.de")))
