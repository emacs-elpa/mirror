;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2.0.20260830.47"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "0c9656d5bf80e998b4de426ee1885c724a3c5b43"
  :revdesc "0c9656d5bf80"
  :keywords '("faces" "files" "q"))
