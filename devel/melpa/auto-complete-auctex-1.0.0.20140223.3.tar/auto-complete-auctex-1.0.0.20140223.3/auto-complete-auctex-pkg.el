;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-auctex" "1.0.0.20140223.3"
  "Auto-completion for auctex."
  '((yasnippet     "0.6.1")
    (auto-complete "1.4"))
  :url "https://github.com/emacsattic/auto-complete-auctex"
  :commit "855633f668bcc4b9408396742a7cb84e0c4a2f77"
  :revdesc "855633f668bc"
  :authors '(("Christopher Monsanto" . "chris@monsan.to"))
  :maintainers '(("Christopher Monsanto" . "chris@monsan.to")))
