;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.2.0.0.20260707.14"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "9b1114241427f4d80436a1a901c3375333a626a9"
  :revdesc "v0.2.0-14-g9b1114241427"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
