;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesky" "0.1.4.0.20261113.1"
  "A Bluesky client."
  '((emacs "30.1")
    (plz   "0.9.0")
    (futur "1.7")
    (vui   "1.0.0"))
  :url "https://github.com/ahyatt/emacs-bluesky"
  :commit "6c62cb518c9f6d0932036e5ed64d370ff35634eb"
  :revdesc "6c62cb518c9f"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
