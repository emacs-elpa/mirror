;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "what-the-commit" "1.0.0.20150901.9"
  "Random commit message generator."
  ()
  :url "http://barbarito.me/"
  :commit "42604410cfd5be715c8aa730aef4673773454e8b"
  :revdesc "42604410cfd5"
  :keywords '("git" "commit" "message")
  :authors '(("Dan Barbarito" . "dan@barbarito.me"))
  :maintainers '(("Dan Barbarito" . "dan@barbarito.me")))
