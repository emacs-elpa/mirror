;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "0.4.1.0.20260620.3"
  "Create releases of Emacs packages."
  '((emacs    "30.1")
    (compat   "31.0")
    (cond-let "1.1")
    (elx      "2.3")
    (llama    "1.0")
    (magit    "4.5"))
  :url "https://github.com/magit/sisyphus"
  :commit "dd4ae5d52c9d862c2ebeb1c72422ba0f6e22e62b"
  :revdesc "v0.4.1-3-gdd4ae5d52c9d"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
