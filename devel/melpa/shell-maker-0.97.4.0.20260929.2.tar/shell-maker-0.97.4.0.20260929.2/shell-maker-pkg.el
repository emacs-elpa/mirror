;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.97.4.0.20260929.2"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "2fa9c3f72339fd7bc755bc166428b139720e5d0d"
  :revdesc "2fa9c3f72339")
