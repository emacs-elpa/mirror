;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "password-vault" "20131104"
  "A Password manager for Emacs."
  '((cl-lib "0.2")
    (emacs  "24"))
  :url "https://github.com/PuercoPop/password-vault"
  :commit "56bc893372a435b4fb3c8937c7f811bca3475f12"
  :revdesc "56bc893372a4"
  :keywords '("password" "productivity")
  :authors '(("Javier PuercoPop Olaechea" . "pirata@gmail.com"))
  :maintainers '(("Javier PuercoPop Olaechea" . "pirata@gmail.com")))
