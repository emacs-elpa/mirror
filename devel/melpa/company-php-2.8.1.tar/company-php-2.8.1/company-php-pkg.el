;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-php" "2.8.1"
  "A company back-end for PHP."
  '((cl-lib      "0.5")
    (ac-php-core "2.0")
    (company     "0.9"))
  :url "https://github.com/xcwen/ac-php"
  :commit "b626cc6b3a343b2431f2e13b241b1612da5fc3f4"
  :revdesc "v2.8.1-0-gb626cc6b3a34"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
