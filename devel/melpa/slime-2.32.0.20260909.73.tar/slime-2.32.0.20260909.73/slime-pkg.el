;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "2.32.0.20260909.73"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "a93bb5e00235b72ce086faca13b33955f44b416e"
  :revdesc "a93bb5e00235"
  :keywords '("languages" "lisp" "slime"))
