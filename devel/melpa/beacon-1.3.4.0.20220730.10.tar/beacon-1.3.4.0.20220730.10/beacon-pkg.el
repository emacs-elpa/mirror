;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beacon" "1.3.4.0.20220730.10"
  "Highlight the cursor whenever the window scrolls."
  '((emacs "25.1"))
  :url "https://github.com/Malabarba/beacon"
  :commit "85261a928ae0ec3b41e639f05291ffd6bf7c231c"
  :revdesc "85261a928ae0"
  :keywords '("convenience")
  :authors '(("Artur Malabarba" . "emacs@endlessparentheses.com"))
  :maintainers '(("Artur Malabarba" . "emacs@endlessparentheses.com")))
