;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spotify" "0.3.4.0.20250106.2"
  "Control the spotify application from emacs."
  '((cl-lib "0.5"))
  :url "https://codeberg.org/rwv/spotify-el"
  :commit "d918b5187638e0c44a2a2584f3980244b6aae3fa"
  :revdesc "0.3.4-2-gd918b5187638"
  :keywords '("convenience"))
