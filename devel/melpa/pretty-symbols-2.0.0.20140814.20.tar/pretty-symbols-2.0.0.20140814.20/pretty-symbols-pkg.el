;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pretty-symbols" "2.0.0.20140814.20"
  "Draw tokens as Unicode glyphs."
  ()
  :url "https://github.com/drothlis/pretty-symbols"
  :commit "ab82b3fba129fae14e4031eb7fd648c1a92d0e71"
  :revdesc "ab82b3fba129"
  :keywords '("faces")
  :authors '(("David Röthlisberger" . "david@rothlis.net"))
  :maintainers '(("David Röthlisberger" . "david@rothlis.net")))
