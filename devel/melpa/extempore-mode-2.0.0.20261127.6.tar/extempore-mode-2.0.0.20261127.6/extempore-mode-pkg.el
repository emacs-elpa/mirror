;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "extempore-mode" "2.0.0.20261127.6"
  "Major mode for Extempore source files."
  '((emacs "29.1"))
  :url "https://github.com/extemporelang/extempore-emacs-mode"
  :commit "a4d175d5e226b1d4f6534b194b11a45f58bf1103"
  :revdesc "a4d175d5e226"
  :keywords '("languages" "lisp" "extempore")
  :authors '(("Ben Swift" . "ben@benswift.me"))
  :maintainers '(("Ben Swift" . "ben@benswift.me")))
