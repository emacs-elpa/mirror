;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gmail-message-mode" "1.4"
  "A major-mode for editing gmail messages using markdown syntax."
  '((ham-mode "1.0"))
  :url "https://github.com/Bruce-Connor/gmail-message-mode"
  :commit "ec36672a9dc93c09ebe2f77597b498d11883d008"
  :revdesc "ec36672a9dc9"
  :keywords '("mail" "convenience" "emulation")
  :authors '(("Artur Malabarba" . "bruce.connor.am@gmail.com"))
  :maintainers '(("Artur Malabarba" . "bruce.connor.am@gmail.com")))
