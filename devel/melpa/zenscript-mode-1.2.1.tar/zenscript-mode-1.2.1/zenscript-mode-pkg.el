;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zenscript-mode" "1.2.1"
  "Major mode for ZenScript."
  '((emacs "25.1"))
  :url "https://github.com/eutropius225/zenscript-mode"
  :commit "c33b4525502459fe60dd76b383e19919d450aeb8"
  :revdesc "c33b45255024")
