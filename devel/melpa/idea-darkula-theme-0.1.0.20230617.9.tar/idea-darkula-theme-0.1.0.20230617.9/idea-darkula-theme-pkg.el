;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idea-darkula-theme" "0.1.0.20230617.9"
  "Color theme based on IntelliJ IDEA Darkula color theme."
  '((emacs "24.1"))
  :url "https://github.com/fourier/idea-darkula-theme"
  :commit "2ba08b6b7c0f75d460d81e1f02114a6449bb1868"
  :revdesc "2ba08b6b7c0f"
  :keywords '("themes")
  :authors '(("Alexey Veretennikov" . "alexeydotveretennikovatgmaildotcom"))
  :maintainers '(("Alexey Veretennikov" . "alexeydotveretennikovatgmaildotcom")))
