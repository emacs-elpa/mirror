;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "2.7.0.20260725.3"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/cape"
  :commit "c9b949e20b35a9f6f3ab8d11e1d2f76cc7a2e4d3"
  :revdesc "2.7-3-gc9b949e20b35"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
