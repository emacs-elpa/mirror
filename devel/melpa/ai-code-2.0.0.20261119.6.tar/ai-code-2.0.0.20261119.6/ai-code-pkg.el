;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "2.0.0.20261119.6"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a0363f5efe6f3ac7f3ba5984726cd64c57ee5fe6"
  :revdesc "a0363f5efe6f"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
