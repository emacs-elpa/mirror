;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "4.0.0.0.20260609.424"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "26.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "b0ee99feb2dcae5e304ad735d82d488f2191a51c"
  :revdesc "b0ee99feb2dc")
