;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http-server" "0.1.0.0.20260609.5"
  "Speaks HTTP for you."
  '((emacs "30.1"))
  :url "https://codeberg.org/martenlienen/http-server.el"
  :commit "4285bd3e4b67983cb783f46afc736032f895882d"
  :revdesc "4285bd3e4b67"
  :keywords '("comm")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
