;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "artbollocks-mode" "1.2.0"
  "Improve your writing (especially about art)."
  '((emacs "25.1"))
  :url "https://github.com/sachac/artbollocks-mode"
  :commit "63d20ed2846226f45b35eded69a776143a772ea4"
  :revdesc "63d20ed28462"
  :authors '(("Rob Myers" . "rob@robmyers.org")
             ("Sacha Chua" . "sacha@sachachua.com"))
  :maintainers '(("Rob Myers" . "rob@robmyers.org")
                 ("Sacha Chua" . "sacha@sachachua.com")))
