;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-black" "1.2.0.0.20240520.3"
  "Reformat Python using python-black."
  '((emacs       "25")
    (dash        "2.16.0")
    (reformatter "0.3"))
  :url "https://github.com/wbolster/emacs-python-black"
  :commit "4da1519345b3d5c513d82ef0d39536dd9c626d42"
  :revdesc "1.2.0-3-g4da1519345b3"
  :keywords '("languages")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
