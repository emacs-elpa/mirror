;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pyflakes" "0.1.0.20240124.14"
  "Support pyflakes in flycheck."
  '((flycheck "0.18"))
  :url "https://github.com/Wilfred/flycheck-pyflakes"
  :commit "60db5908747faf3831f055eddc6d3b5deafa7384"
  :revdesc "60db5908747f"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
