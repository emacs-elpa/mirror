;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jaword" "1.0.1.0.20210306.3"
  "Minor-mode for handling Japanese words better."
  '((tinysegmenter "0.1")
    (emacs         "25.1"))
  :url "http://zk-phi.github.io/"
  :commit "783544a265f91b2e568b52311afb36e3691d5ad3"
  :revdesc "783544a265f9")
