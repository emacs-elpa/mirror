;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.58.1.0.20260712.15"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "369570450da95082339c849b058936d6187399a1"
  :revdesc "369570450da9")
