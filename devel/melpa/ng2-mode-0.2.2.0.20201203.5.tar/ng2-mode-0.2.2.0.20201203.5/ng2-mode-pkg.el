;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ng2-mode" "0.2.2.0.20201203.5"
  "Major modes for editing Angular 2."
  '((typescript-mode "0.1"))
  :url "https://github.com/AdamNiederer/ng2-mode"
  :commit "d341f177c6e4fb9d99b8639943ab5fc9184e2715"
  :revdesc "0.2.2-5-gd341f177c6e4"
  :keywords '("typescript" "angular" "angular2" "template")
  :authors '(("Adam Niederer" . "adam.niederer@gmail.com"))
  :maintainers '(("Adam Niederer" . "adam.niederer@gmail.com")))
