;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "4.0.7.0.20261022.92"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.8")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "ab8ad31f24e97174fcebaba60506232da86f631b"
  :revdesc "v4.0.7-92-gab8ad31f24e9"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
