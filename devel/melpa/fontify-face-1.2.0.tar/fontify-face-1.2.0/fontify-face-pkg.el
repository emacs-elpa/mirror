;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fontify-face" "1.2.0"
  "Fontify symbols representing faces with that face."
  '((emacs "25.1"))
  :url "https://github.com/Fuco1/fontify-face"
  :commit "014a18fa56e0be3ff4d6ff7a82d9028bac5c15fc"
  :revdesc "014a18fa56e0"
  :keywords '("faces")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
