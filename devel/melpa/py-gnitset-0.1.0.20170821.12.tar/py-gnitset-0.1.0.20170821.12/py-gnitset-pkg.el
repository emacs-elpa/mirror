;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-gnitset" "0.1.0.20170821.12"
  "Run your Python tests any way you'd like."
  ()
  :url "https://www.github.com/quodlibetor/py-gnitset"
  :commit "1e993cc29cbc31e06fe1e335dec198e21972fa55"
  :revdesc "1e993cc29cbc"
  :authors '(("Brandon W Maister" . "quodlibetor@gmail.com"))
  :maintainers '(("Brandon W Maister" . "quodlibetor@gmail.com")))
