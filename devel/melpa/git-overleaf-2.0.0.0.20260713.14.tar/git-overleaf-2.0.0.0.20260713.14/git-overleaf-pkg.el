;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-overleaf" "2.0.0.0.20260713.14"
  "Clone, push, and pull full Overleaf projects with Git."
  '((emacs         "29.4")
    (websocket     "1.15")
    (webdriver     "0.1")
    (magit-section "4.5"))
  :url "https://github.com/Jamie-Cui/git-overleaf"
  :commit "2559016e1fac95889ba04a0ac9c59c85a267d176"
  :revdesc "2559016e1fac"
  :keywords '("hypermedia" "tex" "tools")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
