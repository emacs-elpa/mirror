;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zero-input-panel-posframe" "1.0.1.0.20240526.1"
  "Posframe based zero-input panel implementation."
  '((emacs      "24.4")
    (zero-input "2.9.0")
    (posframe   "1.4.3"))
  :url "https://gitlab.emacsos.com/sylecn/zero-el"
  :commit "714102090ba87b75a06b87792df696f6f48c2ea8"
  :revdesc "714102090ba8")
