;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rum-mode" "1.2.0.20180127.2"
  "Major mode for Rum programming language."
  '((emacs "24"))
  :url "https://github.com/rumlang/rum-mode"
  :commit "161471e6476d232d479f9767535918920811d7bf"
  :revdesc "161471e6476d"
  :keywords '("rum" "languages" "lisp")
  :authors '(("Avelino" . "t@avelino.xxx"))
  :maintainers '(("Avelino" . "t@avelino.xxx")))
