;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-osc" "0.0.0.20190402.19"
  "Non-resident support for osc version-control."
  ()
  :url "https://github.com/aspiers/vc-osc"
  :commit "bf5a515ed85f7d7cdfe66ed5bf4ef7554f8561e5"
  :revdesc "bf5a515ed85f"
  :maintainers '(("Adam Spiers" . "aspiers@suse.com")))
