;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "0.9.1.0.20260715.119"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "610f61cb0165ca03ff033284fb515fb51c83cc95"
  :revdesc "610f61cb0165"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
