;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.74.3"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "bfd4c8f77c042e69b30320973dab9616ac389ced"
  :revdesc "bfd4c8f77c04")
