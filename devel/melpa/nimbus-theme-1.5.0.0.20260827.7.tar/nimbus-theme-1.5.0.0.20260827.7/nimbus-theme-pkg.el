;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nimbus-theme" "1.5.0.0.20260827.7"
  "Nimbus dark theme."
  '((emacs "27.1"))
  :url "https://github.com/mrcnski/nimbus-theme"
  :commit "78b39a5cd4d3d7265d685736721363b35eac1f88"
  :revdesc "78b39a5cd4d3"
  :keywords '("faces")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
