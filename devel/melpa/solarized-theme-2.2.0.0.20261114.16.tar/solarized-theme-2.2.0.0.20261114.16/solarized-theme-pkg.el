;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solarized-theme" "2.2.0.0.20261114.16"
  "The Solarized color theme."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/solarized-emacs"
  :commit "0f2c881f1e1d3a66894a1cba73fbe79bd141787b"
  :revdesc "0f2c881f1e1d"
  :keywords '("convenience" "themes" "solarized")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
