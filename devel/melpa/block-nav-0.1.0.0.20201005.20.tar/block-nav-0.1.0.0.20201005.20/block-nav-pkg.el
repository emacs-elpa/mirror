;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "block-nav" "0.1.0.0.20201005.20"
  "Jump across indentation levels for quick navigation."
  '((emacs "25.1"))
  :url "https://github.com/nixin72/block-nav.el"
  :commit "bc02e545cfd9a048a8df777669a426a8edc2321f"
  :revdesc "bc02e545cfd9"
  :keywords '("convenience")
  :authors '(("Philip Dumaresq" . "phdumaresq@protonmail.com"))
  :maintainers '(("Philip Dumaresq" . "phdumaresq@protonmail.com")))
