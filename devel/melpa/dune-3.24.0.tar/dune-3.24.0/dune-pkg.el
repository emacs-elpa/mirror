;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dune" "3.24.0"
  "Integration with the dune build system."
  ()
  :url "https://github.com/ocaml/dune"
  :commit "47f64de764078db6edb2698958b5270a17bffb05"
  :revdesc "3.24.0-0-g47f64de76407")
