;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loc-changes" "1.1.0.20261031.20"
  "Keep track of positions even after buffer changes."
  '((emacs  "24.4")
    (compat "30.1.0.1"))
  :url "https://github.com/rocky/emacs-loc-changes"
  :commit "f2d236992a90c3f7a470284ca939d1faf33f00b8"
  :revdesc "f2d236992a90"
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
