;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-leap" "0.4.1.0.20160831.3"
  "Leap between lines by typing keywords."
  '((emacs "24.3"))
  :url "https://github.com/MartinRykfors/key-leap"
  :commit "b3f6ef15c8a13870475d5af159fa24b30f97dea0"
  :revdesc "b3f6ef15c8a1"
  :keywords '("point" "convenience")
  :authors '(("Martin Rykfors" . "martinrykfors@gmail.com"))
  :maintainers '(("Martin Rykfors" . "martinrykfors@gmail.com")))
