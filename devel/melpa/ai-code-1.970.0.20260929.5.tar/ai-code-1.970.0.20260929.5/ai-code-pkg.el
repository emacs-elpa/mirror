;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.970.0.20260929.5"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "d2dbe345b93b4d45bfed9ccb9055a693fa895d9f"
  :revdesc "d2dbe345b93b"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
