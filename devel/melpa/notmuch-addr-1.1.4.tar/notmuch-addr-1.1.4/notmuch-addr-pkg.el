;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-addr" "1.1.4"
  "Improved address completion for Notmuch."
  '((emacs   "29.1")
    (compat  "31.0")
    (notmuch "0.39"))
  :url "https://github.com/tarsius/notmuch-addr"
  :commit "0cb6f9e0dc0e27b31b4849630f7e74bafaa78758"
  :revdesc "v1.1.4-0-g0cb6f9e0dc0e"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-addr@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-addr@jonas.bernoulli.dev")))
