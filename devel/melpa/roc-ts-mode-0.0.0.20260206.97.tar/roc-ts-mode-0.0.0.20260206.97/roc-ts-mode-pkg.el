;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "roc-ts-mode" "0.0.0.20260206.97"
  "Roc programming language mode."
  '((emacs "29.1"))
  :url "https://gitlab.com/tad-lispy/roc-ts-mode"
  :commit "00aa6d23192a85c4f8e2905c1aa526fefec51f20"
  :revdesc "00aa6d23192a"
  :keywords '("languages")
  :authors '(("Tad Lispy" . "tadeusz@lazurski.pl")
             ("Ajai Khatri Nelson" . "emacs@ajai.dev"))
  :maintainers '(("Tad Lispy" . "tadeusz@lazurski.pl")
                 ("Ajai Khatri Nelson" . "emacs@ajai.dev")))
