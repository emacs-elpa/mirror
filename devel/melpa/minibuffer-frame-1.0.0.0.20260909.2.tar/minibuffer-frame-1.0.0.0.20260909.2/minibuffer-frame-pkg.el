;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minibuffer-frame" "1.0.0.0.20260909.2"
  "Minibuffer in centered child frame."
  '((emacs "28.1"))
  :url "https://github.com/zHaOdANiuu/minibuffer-frame"
  :commit "f8205be3bbae4199a618f06a753cc91a5c378e01"
  :revdesc "f8205be3bbae"
  :keywords '("convenience" "minibuffer" "child-frame")
  :authors '(("zhaodaniu" . "zhaodaniu1@gmail.com"))
  :maintainers '(("zhaodaniu" . "zhaodaniu1@gmail.com")))
