;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-wikipedia" "0.0.0.20240912.24"
  "Wikipedia suggestions."
  '((helm  "3.6")
    (emacs "25.1"))
  :url "https://github.com/emacs-helm/helm-wikipedia"
  :commit "e4b9434785e2a421af6e16ba50ea51eb54c7e490"
  :revdesc "e4b9434785e2")
