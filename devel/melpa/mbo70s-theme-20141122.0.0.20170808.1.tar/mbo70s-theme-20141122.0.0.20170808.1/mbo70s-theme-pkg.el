;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mbo70s-theme" "20141122.0.0.20170808.1"
  "70s style palette, with similarities to mbo theme."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "bed3db8965708ed4e9482b224a9b084765c052f2"
  :revdesc "bed3db896570")
