;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-kill" "0.9.4.0.20260121.9"
  "Kill & mark things easily."
  '((emacs  "25")
    (cl-lib "0.5"))
  :url "https://github.com/leoliu/easy-kill"
  :commit "98cbae5d8c378ad14d612d7c88a78484c49a80b8"
  :revdesc "98cbae5d8c37"
  :keywords '("killing" "convenience")
  :authors '(("Leo Liu" . "sdl.web@gmail.com"))
  :maintainers '(("Leo Liu" . "sdl.web@gmail.com")))
