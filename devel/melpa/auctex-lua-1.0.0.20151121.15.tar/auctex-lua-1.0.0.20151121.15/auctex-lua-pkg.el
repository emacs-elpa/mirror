;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auctex-lua" "1.0.0.20151121.15"
  "Lua editing support for AUCTeX."
  '((auctex   "11.86")
    (lua-mode "20130419"))
  :url "https://github.com/vermiculus/auctex-lua"
  :commit "799cd8ac10c96991bb63d9aa60528ae5d8c786b5"
  :revdesc "799cd8ac10c9"
  :keywords '("latex" "lua")
  :authors '(("Sean Allred" . "(seallred@smcm.edu)"))
  :maintainers '(("Sean Allred" . "(seallred@smcm.edu)")))
