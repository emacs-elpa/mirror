;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hayoo" "0.1.0.20140831.3"
  "Query hayoo and show results in a tabulated buffer."
  '((emacs "24")
    (json  "1.3"))
  :url "https://github.com/benma/hayoo.el/"
  :commit "3ca2fb0c4d5f337d0410c21b2702dd147014e984"
  :revdesc "3ca2fb0c4d5f"
  :keywords '("hayoo" "haskell")
  :authors '(("Marko Bencun" . "mbencun@gmail.com"))
  :maintainers '(("Marko Bencun" . "mbencun@gmail.com")))
