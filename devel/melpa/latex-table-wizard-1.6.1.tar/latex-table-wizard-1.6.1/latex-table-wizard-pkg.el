;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-table-wizard" "1.6.1"
  "Magic editing of LaTeX tables."
  '((emacs     "27.1")
    (auctex    "12.1")
    (transient "0.3.7"))
  :url "https://github.com/enricoflor/latex-table-wizard"
  :commit "0eece7940a32eb82e5418fadba0189b0dd84ddd1"
  :revdesc "0eece7940a32"
  :keywords '("convenience" "tex")
  :authors '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers '(("Enrico Flor" . "enrico@eflor.net")))
