;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-lobsters" "0.1.0.20200818.15"
  "Browse lobste.rs stories with ivy."
  '((ivy    "0.8.0")
    (cl-lib "0.5"))
  :url "https://github.com/julienXX/ivy-lobsters"
  :commit "3f7f90751d15ebcf91253ef3cda18c0aa7d856ff"
  :revdesc "3f7f90751d15"
  :authors '(("Julien Blanchard" . "https://github.com/julienXX"))
  :maintainers '(("Julien Blanchard" . "https://github.com/julienXX")))
