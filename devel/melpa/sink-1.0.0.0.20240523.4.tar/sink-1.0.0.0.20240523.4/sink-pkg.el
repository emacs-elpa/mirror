;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sink" "1.0.0.0.20240523.4"
  "Receive messages from the plan9 plumber."
  '((emacs "25.1"))
  :url "https://github.com/alcah/sink.el"
  :commit "a14e1cc0a051543723c043a5ece081ce9a567ddd"
  :revdesc "a14e1cc0a051")
