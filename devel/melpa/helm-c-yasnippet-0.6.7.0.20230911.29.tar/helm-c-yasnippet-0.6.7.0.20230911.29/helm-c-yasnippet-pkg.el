;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-c-yasnippet" "0.6.7.0.20230911.29"
  "Helm source for yasnippet.el."
  '((emacs     "25.1")
    (helm      "1.7.7")
    (yasnippet "0.8.0"))
  :url "https://github.com/emacs-jp/helm-c-yasnippet"
  :commit "c6c9a14a65d11de967be593e5bead3196c1f4ecf"
  :revdesc "0.6.7-29-gc6c9a14a65d1"
  :keywords '("convenience" "emulation")
  :authors '(("Kenji.I" . "ken.imakaado@gmail.com"))
  :maintainers '(("Kenji.I" . "ken.imakaado@gmail.com")))
