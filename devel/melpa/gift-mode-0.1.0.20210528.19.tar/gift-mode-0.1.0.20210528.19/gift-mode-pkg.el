;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gift-mode" "0.1.0.20210528.19"
  "Major mode for editing GIFT format quizzes."
  ()
  :url "https://github.com/csrhodes/gift-mode"
  :commit "c93354e8fe1173b22f398f17b127875807f15b87"
  :revdesc "c93354e8fe11"
  :authors '(("Christophe Rhodes" . "christophe@rhodes.io"))
  :maintainers '(("Christophe Rhodes" . "christophe@rhodes.io")))
