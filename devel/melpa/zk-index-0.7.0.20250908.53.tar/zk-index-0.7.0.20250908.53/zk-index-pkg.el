;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-index" "0.7.0.20250908.53"
  "Index for zk."
  '((emacs "28.1")
    (zk    "0.9"))
  :url "https://github.com/localauthor/zk"
  :commit "302e494324066d63f317b54c4db75d173914c521"
  :revdesc "302e49432406"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
