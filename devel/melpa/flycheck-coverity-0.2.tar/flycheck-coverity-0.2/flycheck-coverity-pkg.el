;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-coverity" "0.2"
  "Integrate Coverity with flycheck."
  '((flycheck "0.24")
    (dash     "2.12.0")
    (emacs    "24.4"))
  :url "https://github.com/alexmurray/flycheck-coverity"
  :commit "cb211e3dd50413a5042eb20175be518214591c9d"
  :revdesc "cb211e3dd504"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
