;;; nix-shebang.el --- Handle nix shebang header -*- lexical-binding: t -*-

;; Author: Matthew Bauer <mjbauer95@gmail.com>
;; Homepage: https://github.com/NixOS/nix-mode
;; Keywords: nix, languages, tools, unix

;; This file is NOT part of GNU Emacs.

;;; Commentary:

;; This detects file headers that look like:
;; #!/usr/bin/env nix-shell
;; #!nix-shell -i bash

;; and correctly detects their file modes.

;;; Code:

(require 'files)

(defvar nix-shebang-interpreter-regexp "#![ \t]*nix-shell -i \\([^ \t\n]+\\)"
  "Regexp for nix-shell -i header.")

(defun nix-shebang-get-interpreter ()
  "Get interpreter string from nix-shell -i file."
  (save-excursion
    (goto-char (point-min))
    (forward-line 1)
    (when (looking-at nix-shebang-interpreter-regexp)
      (match-string 1))))

(defun nix-shebang-mode ()
  "Detect and run file’s interpreter mode."
  (let* ((interpreter (nix-shebang-get-interpreter))
         (mode (and interpreter
                    (assoc-default interpreter
                                   (mapcar (lambda (e)
                                             (cons
                                              (format "\\`%s\\'" (car e))
                                              (cdr e)))
                                           interpreter-mode-alist)
                                   #'string-match-p))))
    (when mode
      (funcall mode))))

;;;###autoload
(add-to-list 'interpreter-mode-alist '("nix-shell" . nix-shebang-mode))

(provide 'nix-shebang)
;;; nix-shebang.el ends here
