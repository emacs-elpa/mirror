;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0.0.20260630.346"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.1"))
  :url "https://github.com/jojojames/fzfa"
  :commit "950b9dcca9c6f68b0fafdd58a8ab6e694b312837"
  :revdesc "950b9dcca9c6"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
