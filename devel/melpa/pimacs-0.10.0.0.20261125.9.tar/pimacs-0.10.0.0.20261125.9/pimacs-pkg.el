;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.10.0.0.20261125.9"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "3ae066bc3fc260e437ecc43e14ff96c53d273f27"
  :revdesc "3ae066bc3fc2"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
