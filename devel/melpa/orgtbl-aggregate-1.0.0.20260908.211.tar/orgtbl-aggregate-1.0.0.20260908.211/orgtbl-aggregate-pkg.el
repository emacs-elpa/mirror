;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "1.0.0.20260908.211"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "eb5cb1a1396fc9c09f5ad0bb1430075c2a031de3"
  :revdesc "eb5cb1a1396f"
  :keywords '("data" "extensions"))
