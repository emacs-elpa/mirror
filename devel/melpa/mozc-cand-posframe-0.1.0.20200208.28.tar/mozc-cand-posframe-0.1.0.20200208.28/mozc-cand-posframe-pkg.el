;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc-cand-posframe" "0.1.0.20200208.28"
  "Posframe frontend for mozc.el."
  '((emacs    "26.1")
    (posframe "0.5.0")
    (mozc     "20180101.800")
    (s        "1.12"))
  :url "https://github.com/akirak/mozc-posframe"
  :commit "1d07d5055381008ccbb29b97315d140e09a7ee95"
  :revdesc "1d07d5055381"
  :keywords '("i18n" "tooltip")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
