;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bbdb" "1.1.0.20190728.39"
  "Helm interface for bbdb."
  '((emacs "24.3")
    (helm  "1.5")
    (bbdb  "3.1.2"))
  :url "https://github.com/emacs-helm/helm-bbdb"
  :commit "db69114ff1af8bf48b5a222242e3a8dd6e101e67"
  :revdesc "v1.1-39-gdb69114ff1af")
