;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "foreign-regexp" "2.0.0.0.20200325.14"
  "Search and replace by foreign regexp."
  ()
  :url "https://github.com/k-talo/foreign-regexp.el"
  :commit "e2dd47f2160cadc194eb156e7c76c3c869e6706e"
  :revdesc "e2dd47f2160c"
  :keywords '("convenience" "emulations" "matching" "tools" "unix" "wp")
  :authors '(("K-talo Miyazaki" . "KeitarodotMiyazakiatgmaildotcom"))
  :maintainers '(("K-talo Miyazaki" . "KeitarodotMiyazakiatgmaildotcom")))
