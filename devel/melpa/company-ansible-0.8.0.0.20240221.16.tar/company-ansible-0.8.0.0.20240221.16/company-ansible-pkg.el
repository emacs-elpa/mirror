;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ansible" "0.8.0.0.20240221.16"
  "A company back-end for ansible."
  '((emacs   "24.4")
    (company "0.8.12"))
  :url "https://github.com/krzysztof-magosa/company-ansible"
  :commit "338922601cf9e8ada863fe6f2dd9d5145d9983b0"
  :revdesc "338922601cf9"
  :keywords '("ansible")
  :authors '(("Krzysztof Magosa" . "krzysztof@magosa.pl"))
  :maintainers '(("Krzysztof Magosa" . "krzysztof@magosa.pl")))
