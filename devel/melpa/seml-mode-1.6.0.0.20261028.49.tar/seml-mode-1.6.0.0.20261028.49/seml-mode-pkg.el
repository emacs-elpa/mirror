;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seml-mode" "1.6.0.0.20261028.49"
  "Major-mode for SEML, S-Expression Markup Language, file."
  '((emacs          "27.1")
    (impatient-mode "1.1")
    (htmlize        "1.59")
    (web-mode       "17.3.20"))
  :url "https://github.com/conao3/seml-mode.el"
  :commit "04557e546af3a6ed52cb7b5361c99b9d4607712c"
  :revdesc "04557e546af3"
  :keywords '("lisp" "html")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
