;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ytdious" "0.1.0.0.20210228.19"
  "Query / Preview YouTube via Invidious."
  '((emacs "25.3"))
  :url "https://github.com/spiderbit/ytdious"
  :commit "941460b51e43ef6764e15e2b9c4af54c3e56115f"
  :revdesc "941460b51e43"
  :keywords '("youtube" "matching" "multimedia"))
