;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rase" "1.1"
  "Run At Sun Event daemon."
  ()
  :url "https://github.com/m00natic/rase/"
  :commit "59b5f7e8102570b65040e8d55781c7ea28de7338"
  :revdesc "59b5f7e81025"
  :keywords '("solar" "sunrise" "sunset" "midday" "midnight")
  :authors '(("Andrey Kotlarski" . "m00naticus@gmail.com"))
  :maintainers '(("Andrey Kotlarski" . "m00naticus@gmail.com")))
