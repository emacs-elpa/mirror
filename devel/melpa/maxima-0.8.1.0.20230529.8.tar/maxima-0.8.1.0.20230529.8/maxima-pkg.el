;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maxima" "0.8.1.0.20230529.8"
  "Major mode for Maxima."
  '((emacs       "26.1")
    (s           "1.11.0")
    (test-simple "1.3.0"))
  :url "https://gitlab.com/sasanidas/maxima"
  :commit "2de798f6644753772553cd0420d3c419ed50dd0b"
  :revdesc "2de798f66447"
  :keywords '("maxima" "tools" "math")
  :maintainers '(("Fermin Munoz" . "fmfs@posteo.net")))
