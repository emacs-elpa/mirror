;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "semantic-thrift" "0.0.1.0.20260103.26"
  "Thrift LALR parser."
  '((thrift "0.0.1")
    (emacs  "28.2"))
  :url "https://github.com/jerryxgh/semantic-thrift"
  :commit "75d972e91ac97f1378eb6891300361044dfc6624"
  :revdesc "75d972e91ac9"
  :keywords '("extensions" "thrift" "semantic")
  :authors '((nil . "GuanghuiXugh_xu@qq.com"))
  :maintainers '((nil . "GuanghuiXugh_xu@qq.com")))
