;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "0.1.0.20260810.135"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "37701e3ba0e3c0a30f086f93aef634cb5d2ee454"
  :revdesc "37701e3ba0e3"
  :keywords '("data" "extensions"))
