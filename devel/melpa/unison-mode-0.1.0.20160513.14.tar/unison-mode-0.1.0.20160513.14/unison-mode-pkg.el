;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison-mode" "0.1.0.20160513.14"
  "Syntax highlighting for unison file synchronization program."
  ()
  :url "https://github.com/impaktor/unison-mode"
  :commit "0bd6a65c0d12f87fcf7bdff15fe54444959b93bf"
  :revdesc "0bd6a65c0d12"
  :keywords '("symchronization" "unison")
  :authors '(("Karl Fogelmark" . "karlfogel@gmail.com"))
  :maintainers '(("Karl Fogelmark" . "karlfogel@gmail.com")))
