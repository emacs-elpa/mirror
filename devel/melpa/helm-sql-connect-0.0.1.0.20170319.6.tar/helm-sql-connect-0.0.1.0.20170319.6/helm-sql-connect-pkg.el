;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-sql-connect" "0.0.1.0.20170319.6"
  "Choose a database to connect to via Helm."
  '((helm "0.0.0"))
  :url "https://github.com/eric-hansen/helm-sql-connect"
  :commit "5aead55b6f8636140945714d8c332b287ab9ef10"
  :revdesc "5aead55b6f86"
  :keywords '("tools" "convenience" "comm")
  :authors '(("Eric Hansen" . "hansen.c.eric@gmail.com"))
  :maintainers '(("Eric Hansen" . "hansen.c.eric@gmail.com")))
