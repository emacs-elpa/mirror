;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "applescript-mode" "0.1.0.20210802.11"
  "Major mode for editing AppleScript source."
  '((emacs "24.3"))
  :url "https://github.com/emacsorphanage/applescript-mode"
  :commit "00c141bbff46c89a96598b605dee05dd1d89f624"
  :revdesc "00c141bbff46"
  :keywords '("languages" "tools")
  :authors '(("sakito" . "sakito@users.sourceforge.jp"))
  :maintainers '(("sakito" . "sakito@users.sourceforge.jp")))
