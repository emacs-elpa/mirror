;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-labeler" "3.0.0"
  "Simplify equation labeling in LaTeX."
  '((emacs "28.1"))
  :url "https://github.com/X9hRRDys/latex-labeler"
  :commit "6ca15d7dea4f8b2fc0878f6be19438e84061e894"
  :revdesc "v3.0.0-0-g6ca15d7dea4f"
  :keywords '("tools"))
