;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "djinni-mode" "1.0.0.20190303.6"
  "Major-mode for editing Djinni files."
  '((emacs "24.4"))
  :url "https://github.com/danielmartin/djinni-mode"
  :commit "f0da31d8f45c4b1b2341cf88ec7f2d2e7d16267f"
  :revdesc "f0da31d8f45c"
  :keywords '("languages")
  :authors '(("Daniel Martín" . "mardani29@yahoo.es"))
  :maintainers '(("Daniel Martín" . "mardani29@yahoo.es")))
