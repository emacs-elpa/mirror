;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "attrap" "1.2.0.20260806.3"
  "ATtempt To Repair At Point."
  '((dash  "2.12.0")
    (emacs "25.1")
    (f     "0.19.0")
    (s     "1.11.0"))
  :url "https://github.com/jyp/attrap"
  :commit "22d68a9f8270c5e7d1ab02e01d84f3e45a630a49"
  :revdesc "22d68a9f8270"
  :keywords '("programming" "tools")
  :authors '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com"))
  :maintainers '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com")))
