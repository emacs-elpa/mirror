;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leuven-theme" "2.6.812"
  "Elegant Emacs color theme for a white background."
  ()
  :url "https://github.com/fniessen/emacs-leuven-theme"
  :commit "34d03aba2babc1d6982e620ecedb7da2ef24f606"
  :revdesc "v2.6.0812-0-g34d03aba2bab"
  :keywords '("color" "theme")
  :authors '(("Fabrice Niessen" . ""))
  :maintainers '(("Fabrice Niessen" . "")))
