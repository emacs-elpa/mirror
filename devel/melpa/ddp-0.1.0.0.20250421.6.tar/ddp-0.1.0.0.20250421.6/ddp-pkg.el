;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddp" "0.1.0.0.20250421.6"
  "Dynamic Data Processor with cmd tools."
  '((emacs "29.1"))
  :url "https://github.com/eki3z/ddp.el"
  :commit "ee02e658f3bf8f26115e2dd61c713137e01227a9"
  :revdesc "ee02e658f3bf"
  :keywords '("tools")
  :authors '(("Eki Zhang" . "liuyinz@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz@gmail.com")))
