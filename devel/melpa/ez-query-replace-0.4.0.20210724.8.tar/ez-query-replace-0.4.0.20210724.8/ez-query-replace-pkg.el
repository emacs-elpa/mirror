;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ez-query-replace" "0.4.0.20210724.8"
  "A smarter context-sensitive query-replace that can be reapplied."
  '((dash "1.2.0")
    (s    "1.11.0"))
  :url "https://github.com/Wilfred/ez-query-replace"
  :commit "2b68472f4007a73908c3b242e83ac5a7587967ff"
  :revdesc "2b68472f4007"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
