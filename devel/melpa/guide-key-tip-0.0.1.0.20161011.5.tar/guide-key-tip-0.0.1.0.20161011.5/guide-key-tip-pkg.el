;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guide-key-tip" "0.0.1.0.20161011.5"
  "Show guide-key.el hints using pos-tip.el."
  '((guide-key "1.2.3")
    (pos-tip   "0.4.5"))
  :url "https://github.com/aki2o/guide-key-tip"
  :commit "02c5d4b0b65f3e91be5a47f0ff1ae5e86e00c64e"
  :revdesc "02c5d4b0b65f"
  :keywords '("help" "convenience" "tooltip")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
