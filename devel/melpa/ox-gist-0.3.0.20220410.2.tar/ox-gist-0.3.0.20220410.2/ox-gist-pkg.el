;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-gist" "0.3.0.20220410.2"
  "Export Org mode buffers and subtrees to GitHub gists."
  '((emacs "26.1")
    (gist  "1.4.0")
    (s     "1.12.0"))
  :url "https://github.com/punchagan/org2gist/"
  :commit "e9f1f11af0e97fee30c2b15b56c236b1f4e1f400"
  :revdesc "e9f1f11af0e9"
  :keywords '("org" "lisp" "gist" "github")
  :authors '(("Puneeth Chaganti" . "punchagan+emacs@muse-amuse.in"))
  :maintainers '(("Puneeth Chaganti" . "punchagan+emacs@muse-amuse.in")))
