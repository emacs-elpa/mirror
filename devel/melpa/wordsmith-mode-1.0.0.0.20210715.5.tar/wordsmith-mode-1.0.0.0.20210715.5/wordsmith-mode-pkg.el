;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wordsmith-mode" "1.0.0.0.20210715.5"
  "Syntax analysis and NLP text-processing in Emacs (OSX-only)."
  ()
  :url "https://github.com/emacsattic/wordsmith-mode"
  :commit "5d40ceaa2b8d41ab3634ca377ceb6a74deeb2287"
  :revdesc "1.0.0-5-g5d40ceaa2b8d"
  :authors '(("istib" . "istib@thebati.net"))
  :maintainers '(("istib" . "istib@thebati.net")))
