;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-themes" "2.3.0.0.20260117.121"
  "An opinionated pack of modern color-themes."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/doomemacs/themes"
  :commit "53645a905dfb3055db52f5d418d5ef612027e062"
  :revdesc "v2.3.0-121-g53645a905dfb"
  :keywords '("themes" "faces")
  :authors '(("Henrik Lissner" . "contact@henrik.io"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
