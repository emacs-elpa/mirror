;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-case" "2.2.2.0.20150417.18"
  "Insert camelCase, snake_case words without \"Shift\"ing."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "984b6a4c6c4cdcefeecb59e941f5f184cc1dedff"
  :revdesc "984b6a4c6c4c")
