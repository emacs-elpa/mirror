;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.16.0.0.20261020.3"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.67.1")
    (latex-to-svg-backend "0.16.1"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "974322dfd058c8e2baf4b6c1b996c015375b48f9"
  :revdesc "v0.16.0-3-g974322dfd058"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
