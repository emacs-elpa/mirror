;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.10.0.0.20260918.1"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.66.1")
    (latex-to-svg-backend "0.9.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "339fe2216831befc8e875448664ea00095f6ae22"
  :revdesc "v0.10.0-1-g339fe2216831"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
