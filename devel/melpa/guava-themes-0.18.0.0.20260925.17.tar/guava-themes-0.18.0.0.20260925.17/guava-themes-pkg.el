;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "0.18.0.0.20260925.17"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "c3faccde138eb5d9b35d1c68676199b22070decb"
  :revdesc "v0.18.0-17-gc3faccde138e"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
