;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anaphora" "1.0.4.0.20260720.4"
  "Anaphoric macros providing implicit temp variables."
  ()
  :url "https://github.com/rolandwalker/anaphora"
  :commit "d22ae8afd3b3bf6a383f6a6c27522893b57130b1"
  :revdesc "v1.0.4-4-gd22ae8afd3b3"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
