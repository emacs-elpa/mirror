;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "5.1.0.0.20261010.1"
  "Curate an Emacs Lisp package archive."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://github.com/melpa/package-build"
  :commit "4e9248a949531b1c781926dcbcf3768c4eccfc75"
  :revdesc "v5.1.0-1-g4e9248a94953"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
