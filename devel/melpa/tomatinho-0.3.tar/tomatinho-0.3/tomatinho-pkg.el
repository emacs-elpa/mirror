;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tomatinho" "0.3"
  "Simple and beautiful pomodoro timer."
  ()
  :url "https://github.com/konr/tomatinho"
  :commit "b53354b9b9f496c0388d6a573b06b7d6fc53d0bd"
  :revdesc "b53354b9b9f4"
  :keywords '("time" "productivity" "pomodoro technique")
  :authors '(("Konrad Scorciapino" . "scorciapino@gmail.com"))
  :maintainers '(("Konrad Scorciapino" . "scorciapino@gmail.com")))
