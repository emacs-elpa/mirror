;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parseclj" "1.1.1.0.20260526.2"
  "Clojure/EDN parser."
  '((emacs "25"))
  :url "https://github.com/clojure-emacs/parseclj"
  :commit "ca828c202c026e45bd60503984cf510d904cae50"
  :revdesc "v1.1.1-2-gca828c202c02"
  :keywords '("lisp" "clojure" "edn" "parser")
  :authors '(("Arne Brasseur" . "arne@arnebrasseur.net"))
  :maintainers '(("Arne Brasseur" . "arne@arnebrasseur.net")))
