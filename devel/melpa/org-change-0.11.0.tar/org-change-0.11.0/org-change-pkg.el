;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "0.11.0"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "d03c6dd75a3732ba242924846086b7c1d1817daf"
  :revdesc "d03c6dd75a37"
  :keywords '("wp" "convenience"))
