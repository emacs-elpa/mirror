;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpa-clone" "0.4.0.0.20240229.10"
  "Clone ELPA archive."
  '((emacs "24.4"))
  :url "https://github.com/dochang/elpa-clone"
  :commit "3c77587a6ab6cdf041f969d8606407e575374022"
  :revdesc "0.4.0-10-g3c77587a6ab6"
  :keywords '("comm" "elpa" "clone" "mirror")
  :authors '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainers '(("ZHANG Weiyi" . "dochang@gmail.com")))
