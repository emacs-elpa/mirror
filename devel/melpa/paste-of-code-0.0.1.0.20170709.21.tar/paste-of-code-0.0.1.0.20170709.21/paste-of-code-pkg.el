;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paste-of-code" "0.0.1.0.20170709.21"
  "Paste code on https://paste.ofcode.org."
  '((emacs   "24.3")
    (request "0.2.0"))
  :url "https://github.com/spebern/paste-of-code.el"
  :commit "92d258e8ec98598d847ecab82903f9224c7c2050"
  :revdesc "92d258e8ec98"
  :keywords '("lisp")
  :authors '(("Bernhard Specht" . "bernhard@specht.net"))
  :maintainers '(("Bernhard Specht" . "bernhard@specht.net")))
