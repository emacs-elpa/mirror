;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hima-theme" "0.1.0.20250807.12"
  "A minimal theme with pretty colors."
  '((emacs "25.1"))
  :url "https://github.com/meain/hima-theme"
  :commit "637367be2b87a57b0dcc12dc9dd30a854d3281b4"
  :revdesc "637367be2b87"
  :keywords '("faces"))
