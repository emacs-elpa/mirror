;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mingus" "0.34.0.20230518.28"
  "MPD Interface."
  '((libmpdee "2.2"))
  :url "https://github.com/pft/mingus"
  :commit "3fa9b95552eb062eb245321abb7f442c458618dc"
  :revdesc "3fa9b95552eb"
  :keywords '("multimedia" "elisp" "music" "mpd")
  :authors '(("Niels Giesen" . "pfton#emacs"))
  :maintainers '(("Niels Giesen" . "pfton#emacs")))
