;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-cal" "2.0.0.20251030.37"
  "Calendar view for diary."
  '((emacs "28.1")
    (calfw "2.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "57be107b20625c13ed010cb0f70a603a61d47629"
  :revdesc "v2.0-37-g57be107b2062"
  :keywords '("calendar" "org")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
