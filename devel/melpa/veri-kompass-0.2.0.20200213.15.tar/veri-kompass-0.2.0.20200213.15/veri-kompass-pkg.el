;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "veri-kompass" "0.2.0.20200213.15"
  "Verilog codebase navigation facility."
  '((emacs  "25")
    (cl-lib "0.5")
    (org    "8.2.0"))
  :url "https://gitlab.com/koral/veri-kompass"
  :commit "271903cdf92db05898ee7cffb65641f30fa08280"
  :revdesc "271903cdf92d"
  :keywords '("languages" "extensions" "verilog" "hardware" "rtl")
  :maintainers '((nil . "andrea_corallo@yahoo.it")))
