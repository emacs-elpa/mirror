;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "0.19.4"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "24914f0d679c6adaa7aaa0de46fefb7a11cb1094"
  :revdesc "v0.19.4-0-g24914f0d679c"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
