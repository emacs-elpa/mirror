;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-firefox-evil" "1.0.0.20250311.42"
  "Evil-mode implementation of exwm-firefox-core."
  '((emacs             "24.4")
    (exwm              "0.16")
    (evil              "1.0.0")
    (exwm-firefox-core "1.0"))
  :url "https://github.com/walseb/exwm-firefox-evil"
  :commit "c87d601de9bad4d3cbf41c69281073b465a66769"
  :revdesc "c87d601de9ba"
  :keywords '("extensions")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
