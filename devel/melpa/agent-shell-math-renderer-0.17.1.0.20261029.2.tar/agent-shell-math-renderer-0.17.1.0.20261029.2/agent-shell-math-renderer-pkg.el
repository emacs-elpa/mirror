;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.17.1.0.20261029.2"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.89.4")
    (latex-to-svg-backend "0.18.1"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "b3bf1dc644e248ba31db62dc32d2911b30eba335"
  :revdesc "v0.17.1-2-gb3bf1dc644e2"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
