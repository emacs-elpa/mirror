;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "json-process-client" "0.2.0.0.20250330.22"
  "Interact with a TCP process using JSON."
  '((emacs "27.1"))
  :url "https://github.com/DamienCassou/json-process-client"
  :commit "6485953fe6eff62938fd08720811c6fdd09d7d22"
  :revdesc "v0.2.0-22-g6485953fe6ef"
  :authors '(("Nicolas Petton" . "nicolas@petton.fr")
             ("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")
                 ("Damien Cassou" . "damien@cassou.me")))
