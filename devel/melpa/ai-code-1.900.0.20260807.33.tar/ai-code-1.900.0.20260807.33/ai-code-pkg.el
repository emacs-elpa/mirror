;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.900.0.20260807.33"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "adb438b0b5597624ad3dc46b73c20aef4f52d8c9"
  :revdesc "adb438b0b559"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
