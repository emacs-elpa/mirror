;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epm" "0.1"
  "Emacs Package Manager."
  '((emacs "24.3")
    (epl   "0.8"))
  :url "https://github.com/xuchunyang/epm"
  :commit "6375ddbf93c5f25647f6ebb25b54045b3c93a5be"
  :revdesc "6375ddbf93c5"
  :authors '(("Chunyang Xu" . "xuchunyang.me@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang.me@gmail.com")))
