;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chef-mode" "0.1.0.20180628.12"
  "Minor mode for editing an opscode chef repository."
  ()
  :url "https://github.com/mpasternacki/chef-mode"
  :commit "048d691cb63981ae235763d4a6ced4af5c729924"
  :revdesc "048d691cb639"
  :keywords '("chef" "knife")
  :authors '(("Maciej Pasternacki" . "maciej@pasternacki.net"))
  :maintainers '(("Maciej Pasternacki" . "maciej@pasternacki.net")))
