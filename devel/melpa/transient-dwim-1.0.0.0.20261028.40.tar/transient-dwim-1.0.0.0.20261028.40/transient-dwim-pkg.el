;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient-dwim" "1.0.0.0.20261028.40"
  "Useful preset transient commands."
  '((emacs     "28.1")
    (transient "0.13.8"))
  :url "https://github.com/conao3/transient-dwim.el"
  :commit "7a53e1d53bb86f33a8c4a0580b7c1555ffe51c4f"
  :revdesc "7a53e1d53bb8"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
