;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "windsize" "0.1.0.20181029.4"
  "Simple, intuitive window resizing."
  ()
  :url "https://github.com/grammati/windsize"
  :commit "62c2846bbe95b0a73e996c75e4a644d05f57aaaa"
  :revdesc "62c2846bbe95"
  :keywords '("window" "resizing" "convenience")
  :authors '(("Chris Perkins" . "chrisperkins99@gmail.com"))
  :maintainers '(("Chris Perkins" . "chrisperkins99@gmail.com")))
