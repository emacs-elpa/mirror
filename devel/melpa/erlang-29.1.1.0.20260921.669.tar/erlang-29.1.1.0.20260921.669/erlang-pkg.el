;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "29.1.1.0.20260921.669"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "45693a65cdcda876a496ac56b9b3b93adffc5265"
  :revdesc "45693a65cdcd"
  :keywords '("erlang" "languages" "processes"))
