;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "2.0.20261022.349"
  "46 new custom blocks & 56 link types for Org-mode."
  '((s     "1.13.1")
    (dash  "2.18.1")
    (emacs "28.2")
    (org   "9.8")
    (lf    "26.10.1")
    (seq   "2.0"))
  :url "https://alhassy.com/org-special-block-extras"
  :commit "70499e68df7f0382d81d25b04920a560172d483c"
  :revdesc "70499e68df7f"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
