;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tumble" "1.5.0.20160112.13"
  "An Tumblr mode for Emacs."
  '((http-post-simple "0")
    (cl-lib           "0.5"))
  :url "https://github.com/febuiles/tumble"
  :commit "e8fd7643cccf2b6ea4170f0c5f1f87d007e7fa00"
  :revdesc "1.5-13-ge8fd7643cccf"
  :keywords '("tumblr")
  :authors '(("Federico Builes" . "federico.builes@gmail.com"))
  :maintainers '(("Federico Builes" . "federico.builes@gmail.com")))
