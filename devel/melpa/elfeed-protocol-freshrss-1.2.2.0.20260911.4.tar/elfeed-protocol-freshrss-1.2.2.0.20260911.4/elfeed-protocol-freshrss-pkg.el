;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-protocol-freshrss" "1.2.2.0.20260911.4"
  "FreshRSS protocol for elfeed."
  '((emacs            "29.1")
    (elfeed           "4.0.0")
    (elfeed-protocol  "1.0.0")
    (deferred         "0.5.1")
    (request          "0.3.2")
    (request-deferred "0.3.2"))
  :url "https://codeberg.org/lou/elfeed-protocol-freshrss"
  :commit "997db2e6849daccdcc7d936f15ce8ed892ad7bbe"
  :revdesc "997db2e6849d"
  :authors '(("Lou Woell" . "lou@repetitions.de"))
  :maintainers '(("Lou Woell" . "lou@repetitions.de")))
