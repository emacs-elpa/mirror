;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ajnc" "20260907.0.20261108.8"
  "A Janet (Spork) Netrepl Client."
  '((emacs "28.1"))
  :url "https://codeberg.org/zzkt/ajnc"
  :commit "ef420b2c50b4f2a5231060aeaf939e0acca09198"
  :revdesc "ef420b2c50b4"
  :keywords '("tools" "programming" "janet" "repl" "netrepl")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
