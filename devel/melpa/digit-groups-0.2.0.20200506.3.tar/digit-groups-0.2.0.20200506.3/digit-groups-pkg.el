;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "digit-groups" "0.2.0.20200506.3"
  "Highlight place-value positions in numbers."
  '((dash "2.11.0"))
  :url "https://github.com/adamsmd/digit-groups/"
  :commit "7b81930cad19b8b7913b7eedbcb498964bfdcbdb"
  :revdesc "7b81930cad19"
  :authors '(("Michael D. Adams" . "http://michaeldadams.org"))
  :maintainers '(("Michael D. Adams" . "http://michaeldadams.org")))
