;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "36.0.0.20260717.79"
  "On-the-fly syntax checking."
  '((emacs "28.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "51efdbcf43e1b97a52b828be7906c1abd413d693"
  :revdesc "51efdbcf43e1"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
