;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gemini-write" "1.0.3"
  "Elpher for Titan."
  '((emacs       "26")
    (elpher      "2.8.0")
    (gemini-mode "1.0.0"))
  :url "https://alexschroeder.ch/cgit/gemini-write"
  :commit "2a7d07d0ce4c5b8750f3ff1182ad94ee616734c8"
  :revdesc "2a7d07d0ce4c"
  :keywords '("comm" "gemini")
  :authors '(("Alex Schroeder" . "alex@gnu.org"))
  :maintainers '(("Alex Schroeder" . "alex@gnu.org")))
