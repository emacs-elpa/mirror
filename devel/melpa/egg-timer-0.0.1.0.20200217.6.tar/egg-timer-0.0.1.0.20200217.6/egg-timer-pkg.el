;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "egg-timer" "0.0.1.0.20200217.6"
  "Commonly used intervals for setting timers while working."
  '((emacs "25.1"))
  :url "https://github.com/wpcarro/egg-timer.el"
  :commit "53a9e9d20453ea4b0198ca413b8b5069a0b30b38"
  :revdesc "53a9e9d20453"
  :authors '(("William Carroll" . "wpcarro@gmail.com"))
  :maintainers '(("William Carroll" . "wpcarro@gmail.com")))
