;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-projectile" "0.3.2.0.20260725.3"
  "Ivy integration for Projectile."
  '((counsel    "0.13.4")
    (projectile "2.5.0"))
  :url "https://github.com/ericdanan/counsel-projectile"
  :commit "5d86232d52d25790ee333f8f361507db39555291"
  :revdesc "5d86232d52d2"
  :keywords '("project" "convenience"))
