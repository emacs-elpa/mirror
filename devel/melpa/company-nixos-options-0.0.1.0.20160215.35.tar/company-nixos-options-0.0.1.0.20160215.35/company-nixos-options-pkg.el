;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-nixos-options" "0.0.1.0.20160215.35"
  "Company Backend for nixos-options."
  '((company       "0.8.0")
    (nixos-options "0.0.1")
    (cl-lib        "0.5.0"))
  :url "http://www.github.com/travisbhartwell/nix-emacs/"
  :commit "a4e1d9ea9f2e773170caa3afbe54ecdf73d04ec8"
  :revdesc "a4e1d9ea9f2e"
  :keywords '("unix")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com")
             ("Travis B. Hartwell" . "nafai@travishartwell.net"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")
                 ("Travis B. Hartwell" . "nafai@travishartwell.net")))
