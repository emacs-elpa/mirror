;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-elm" "0.0.0.20200528.35"
  "Org-babel functions for elm evaluation."
  '((emacs "26.1")
    (org   "9.3"))
  :url "https://www.bonfacemunyoki.com"
  :commit "d3a9fbc2f56416894c9aed65ea9a20cc1d98f15d"
  :revdesc "d3a9fbc2f564"
  :keywords '("languages" "tools"))
