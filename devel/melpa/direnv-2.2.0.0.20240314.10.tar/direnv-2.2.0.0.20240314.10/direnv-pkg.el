;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "direnv" "2.2.0.0.20240314.10"
  "Direnv integration."
  '((emacs "25.1")
    (dash  "2.12.0"))
  :url "https://github.com/wbolster/emacs-direnv"
  :commit "c0bf3b81c7a97e2a0d06d05495e86848254fcc1f"
  :revdesc "2.2.0-10-gc0bf3b81c7a9"
  :keywords '("direnv" "environment" "processes" "unix" "tools")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
