;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "license-templates" "0.1.3.0.20260101.66"
  "Create LICENSE using GitHub API."
  '((emacs   "24.3")
    (request "0.3.0"))
  :url "https://github.com/jcs-elpa/license-templates"
  :commit "c53a4e9f748be1a9c4c032602b927f9ab5a16702"
  :revdesc "c53a4e9f748b"
  :keywords '("convenience" "license" "api" "template")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
