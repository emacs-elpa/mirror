;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "workgroups" "0.0.0.20110726.106"
  "Workgroups for windows (for Emacs)."
  ()
  :url "https://github.com/tlh/workgroups.el"
  :commit "9572b3492ee09054dc329f64ed846c962b395e39"
  :revdesc "9572b3492ee0"
  :keywords '("session" "management" "window-configuration" "persistence")
  :authors '(("tlh" . "thunkout@gmail.com"))
  :maintainers '(("tlh" . "thunkout@gmail.com")))
