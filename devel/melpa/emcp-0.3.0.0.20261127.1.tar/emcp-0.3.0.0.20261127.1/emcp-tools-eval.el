;;; emcp-tools-eval.el --- Gated code evaluation tool for EMCP -*- lexical-binding: t -*-

;; Author: Marten Lienen <ml@martenlienen.com>

;;; License

;; This file is part of EMCP.

;; EMCP is free software: you can redistribute it and/or modify it under the terms of the
;; GNU General Public License as published by the Free Software Foundation, either version
;; 3 of the License, or (at your option) any later version.

;; EMCP is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
;; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
;; PURPOSE.  See the GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License along with EMCP.  If
;; not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; An MCP tool to allow agents to evaluate arbitrary Emacs Lisp.  Each call goes through a
;; confirmation buffer; the user can also enable a server-wide accept or reject mode.

;;; Code:

(require 'cl-lib)
(require 'cl-print)
(require 'pp)
(require 'seq)
(require 'subr-x)

(require 'emcp-confirm)
(require 'emcp-core)

(define-error 'emcp-tools-eval-parse-error
              "Failed to parse Emacs Lisp source"
              'emcp-error)

(defgroup emcp-tools-eval ()
  "Gated Emacs Lisp evaluation tool for EMCP."
  :group 'emcp)

;; The description of the max_chars argument repeats this value, so that
;; agents know the limit
(defconst emcp-tools-eval--default-max-chars 10000
  "Default maximum number of characters of an eval result.

Longer results are truncated, so that agents do not fill their context
by accident.  Agents can choose another limit per call.")

(defcustom emcp-tools-eval-default-policy 'ask
  "Default action when no server mode applies.

t    always accept without prompting,
nil  always reject without prompting,
ask  open the confirmation buffer."
  :group 'emcp-tools-eval
  :type '(choice (const :tag "Always accept" t)
                 (const :tag "Always reject" nil)
                 (const :tag "Ask the user" ask)))

;;; Parsing

(defun emcp-tools-eval--describe-position (pos)
  "Describe POS in the current buffer for a parse error message.

Return the line and column of POS followed by the text of its line and
a caret under POS."
  (save-excursion
    (goto-char pos)
    (format "line %d, column %d:\n%s\n%s^"
            (line-number-at-pos)
            (1+ (current-column))
            (buffer-substring-no-properties (line-beginning-position)
                                            (line-end-position))
            ;; Keep tabs, so that the caret lines up under them
            (replace-regexp-in-string
             "[^\t]" " " (buffer-substring-no-properties
                          (line-beginning-position) pos)))))

(defun emcp-tools-eval--describe-incomplete ()
  "Describe why the Lisp code in the current buffer is incomplete."
  ;; The mode's `syntax-propertize-function' handles character literals
  ;; such as ?\" and ?(
  (delay-mode-hooks (emacs-lisp-mode))
  (let ((ppss (syntax-ppss (point-max))))
    (cond
     ((nth 3 ppss)
      (format "Unterminated string starting at %s"
              (emcp-tools-eval--describe-position (nth 8 ppss))))
     ((nth 1 ppss)
      (format "%d unclosed parenthes%s, the innermost opens at %s"
              (car ppss)
              (if (= (car ppss) 1) "is" "es")
              (emcp-tools-eval--describe-position (nth 1 ppss))))
     (t "Incomplete input"))))

(defun emcp-tools-eval--parse (code)
  "Parse CODE into a single canonical form.

Returns the form on success, signals `emcp-tools-eval-parse-error' with
a message on failure.  The message points to the problem in CODE, so
that agents do not need to count parentheses themselves.  Multiple
top-level forms are wrapped in (progn ...)."
  (with-temp-buffer
    (with-syntax-table emacs-lisp-mode-syntax-table
      (insert code)
      (goto-char (point-min))
      (let (forms)
        (condition-case err
            (while (progn (forward-comment (buffer-size))
                          (not (eobp)))
              (push (read (current-buffer)) forms))
          (end-of-file
           (signal 'emcp-tools-eval-parse-error
                   (list (emcp-tools-eval--describe-incomplete))))
          (invalid-read-syntax
           (signal 'emcp-tools-eval-parse-error
                   (list
                    (pcase err
                      ;; Reading from a buffer reports the line and the
                      ;; display column after the offending character
                      (`(,_ ,what ,line ,column)
                       (goto-char (point-min))
                       (forward-line (1- line))
                       (move-to-column (max 0 (1- column)))
                       (format "Invalid Lisp syntax \"%s\" at %s"
                               what (emcp-tools-eval--describe-position (point))))
                      (_ (format "Invalid Lisp syntax: %s"
                                 (error-message-string err))))))))
        (pcase (nreverse forms)
          ('() (signal 'emcp-tools-eval-parse-error
                       '("No forms in the code argument")))
          (`(,single) single)
          (forms `(progn ,@forms)))))))

;;; Authorization

(defun emcp-tools-eval--authorize (server)
  "Authorize an eval call on SERVER.

Return t (accept), nil (reject), or `ask' (ask user)."
  (pcase (emcp--server-mode server :emcp-tools-eval-mode)
    ('accept t)
    ('reject nil)
    ('ask 'ask)
    (_ emcp-tools-eval-default-policy)))

;;; Confirmation buffer

(defun emcp-tools-eval--copy-code-to-kill-ring ()
  "Copy the code under review to the `kill-ring' without closing the buffer."
  (interactive)
  (kill-new (plist-get (plist-get emcp-confirm--pending :data) :code))
  (message "EMCP: code copied to kill-ring"))

(defun emcp-tools-eval--apply-action (action server)
  "Convert ACTION into a decision about an eval call on SERVER.

May record a server mode in SERVER."
  (pcase action
    ('yes-once    t)
    ('no-once     nil)
    ('cancel      nil)
    ('mode-accept
     (setf (emcp--server-mode server :emcp-tools-eval-mode) 'accept)
     t)
    ('mode-reject
     (setf (emcp--server-mode server :emcp-tools-eval-mode) 'reject)
     nil)))

(defun emcp-tools-eval--fontify-elisp (str)
  "Return STR with `emacs-lisp-mode' font-lock applied.

Uses a temp buffer in `emacs-lisp-mode' and `font-lock-ensure' so that
the returned string carries text properties that the confirmation
buffer (in `emcp-confirm-mode', a `special-mode' derivative without
font-lock of its own) renders directly."
  (with-temp-buffer
    (insert str)
    (delay-mode-hooks (emacs-lisp-mode))
    (font-lock-ensure)
    (buffer-string)))

(defun emcp-tools-eval--prompt (context form async callback)
  "Open the confirmation buffer for FORM in the tool call CONTEXT.

ASYNC non-nil means that FORM ends the call later via `respond'.

CALLBACK is invoked with a t or nil decision and its reason, `user' if
the user picked an action or `cancel' if the client cancelled the
request."
  (let* ((pretty (string-trim (pp-to-string form)))
         (code (emcp-tools-eval--fontify-elisp pretty)))
    (emcp-confirm-prompt
     context
     :title (if async "evaluate asynchronously" "evaluate")
     :body code
     :data (list :code code)
     :on-dismiss 'no-once
     :on-cancel 'cancel
     :groups
     `(( :title "Accept?"
         :actions ((?y "Yes" :result yes-once)
                   (?n "No"  :result no-once)))
       ( :title "Server mode (applies to all subsequent eval calls on this server)"
         :actions ((?a "Always accept" :result mode-accept)
                   (?r "Always reject" :result mode-reject)))
       ( :actions ((?w "Copy code to kill-ring"
                       :command emcp-tools-eval--copy-code-to-kill-ring))))
     :callback (lambda (action)
                 (funcall callback
                          (emcp-tools-eval--apply-action
                           action (emcp-context-server context))
                          (if (eq action 'cancel) 'cancel 'user))))))

;;; Decision logging

(defun emcp-tools-eval--format-log (decision reason form &optional async)
  "Format a single decision-log line.

DECISION is t (accept) or nil (reject).  REASON is a symbol describing
why this decision was made: `user', `mode', `default' or `cancel' if the
client cancelled the request.  FORM is the form that was decided on and
ASYNC whether it is evaluated asynchronously."
  (let ((pp (string-trim (pp-to-string form))))
    (format "eval %s %s%s %s"
            (if decision "ACCEPT" "REJECT")
            (symbol-name reason)
            (if async " async" "")
            (if (> (length pp) 80) (concat (substring pp 0 77) "...") pp))))

;;; The tool

(defun emcp-tools-eval--decision-source (server)
  "Return why an eval call on SERVER was decided without asking the user.

Used only for logging.  The result is `mode' if SERVER has an
accept/reject mode set and `default' if the decision comes from
`emcp-tools-eval-default-policy'."
  (if (memq (emcp--server-mode server :emcp-tools-eval-mode) '(accept reject))
      'mode
    'default))

(defun emcp-tools-eval--user-window ()
  "Return the window that the user works in.

This is the selected window, or the window from which the minibuffer was
entered.  Windows of confirmation buffers do not count, because the user
only answers in them, so fall back to the most recently used other
window then."
  (cl-flet ((confirm-p (window)
              (eq (buffer-local-value 'major-mode (window-buffer window))
                  'emcp-confirm-mode)))
    (let ((window (or (minibuffer-selected-window) (selected-window))))
      (if (or (window-minibuffer-p window) (confirm-p window))
          (or (car (sort (seq-remove #'confirm-p (window-list nil 'no-minibuf))
                         :key #'window-use-time :reverse t))
              window)
        window))))

(defvar emcp-tools-eval--printing nil
  "Non-nil while the eval tool prints a result.

The `cl-print-object' methods below only apply while this is t.")

(cl-defmethod cl-print-object ((object hash-table) stream
                               &context (emcp-tools-eval--printing (eql t)))
  "Print hash table OBJECT with its contents to STREAM.

`cl-print' elides hash tables, but agents often need their contents.
Only applies while EMCP-TOOLS-EVAL--PRINTING is t."
  (princ (format "#s(hash-table test %s data (" (hash-table-test object)) stream)
  (let ((first t))
    (maphash (lambda (key value)
               (if first (setq first nil) (princ " " stream))
               (cl-print-object key stream)
               (princ " " stream)
               (cl-print-object value stream))
             object))
  (princ "))" stream))

(cl-defmethod cl-print-object ((object string) stream
                               &context (emcp-tools-eval--printing (eql t)))
  "Print string OBJECT to STREAM without text properties.

Text properties mostly bury the text, e.g. fontification.  Only applies
while EMCP-TOOLS-EVAL--PRINTING is t."
  (cl-call-next-method (substring-no-properties object) stream))

(defun emcp-tools-eval--print (value &optional max-chars)
  "Print VALUE for the agent, stopping after MAX-CHARS characters.

Return (TEXT . TRUNCATED).  TRUNCATED is nil if TEXT is complete, the
full length if TEXT is cut off and the full length is known, and t
otherwise.  MAX-CHARS of nil or 0 means no limit.

Strings are returned as is to avoid double quoting and escaping
newlines etc.  This simplifies the output for the agent and is usually
not a problem, because the agent wrote the code, so they know which type
of value to expect.  It also lets the agent print a value in any way
they like.

Other values are printed with `cl-prin1' like in backtraces, which
shows functions as #f(...) instead of byte-code and structs with their
slot names.

Text properties are dropped everywhere, because they mostly bury the
text, e.g. fontification in buffer contents."
  (let ((limit (and (natnump max-chars) (> max-chars 0) max-chars)))
    (if (stringp value)
        (if (and limit (> (length value) limit))
            (cons (substring-no-properties value 0 limit) (length value))
          (cons (substring-no-properties value) nil))
      (let ((emcp-tools-eval--printing t)
            ;; Also avoids cl-print's quadratic cycle check on long lists
            (print-circle t)
            (print-escape-control-characters t)
            (print-escape-newlines t))
        (if (not limit)
            ;; Drop the buttons of ellipses
            (cons (substring-no-properties (cl-prin1-to-string value)) nil)
          (let* ((chars nil)
                 (count 0)
                 (truncated
                  (catch 'emcp-tools-eval--limit
                    (cl-prin1 value (lambda (char)
                                      (when (= count limit)
                                        (throw 'emcp-tools-eval--limit t))
                                      (push char chars)
                                      (cl-incf count)))
                    nil)))
            (cons (concat (nreverse chars)) truncated)))))))

(defun emcp-tools-eval--format-result (text truncated)
  "Format the printed result TEXT for the agent.

TRUNCATED is as returned by `emcp-tools-eval--print'."
  (concat
   (format "```emacs-lisp\n%s\n```" text)
   (when truncated
     (format "\n[Truncated %s. Tweak max_chars to see more.]"
             (if (natnump truncated)
                 (format "to the first %d of %d characters" (length text) truncated)
               (format "after the first %d characters" (length text)))))))

(defun emcp-tools-eval--eval-form (form window buffer max-chars async send-result)
  "Evaluate FORM and call SEND-RESULT with the MCP tool result alist.

FORM runs with WINDOW selected and BUFFER current, the user's window
and its buffer when the request arrived.  Both only apply during the
evaluation, so that the user's layout stays as it is.  If either is
gone, fall back to the user's window and its buffer now.

If ASYNC is non-nil, the value of FORM is ignored.  Instead, FORM can
call the local function `respond' with the result value at any time,
e.g. from a timer.  Errors during the evaluation of FORM itself still
end the call.

The printed result is truncated to MAX-CHARS characters, nil or 0 means
no limit."
  (cl-flet ((fail (text)
              (funcall send-result `((content . [((type . "text") (text . ,text))])
                                     (isError . t))))
            (respond (value)
              (pcase-let ((`(,text . ,truncated) (emcp-tools-eval--print value max-chars)))
                (funcall send-result
                         `((content . [((type . "text")
                                        (text . ,(emcp-tools-eval--format-result
                                                  text truncated)))]))))))
    (condition-case err
        (let ((value (with-selected-window (if (window-live-p window)
                                               window
                                             (emcp-tools-eval--user-window))
                       (with-current-buffer (if (buffer-live-p buffer)
                                                buffer
                                              (window-buffer (selected-window)))
                         (eval (if async
                                   `(cl-flet ((respond ',#'respond)) ,form)
                                 form)
                               t)))))
          (unless async
            (respond value)))
      (quit (fail "Evaluation interrupted: the user pressed C-g."))
      (error
       (fail (format "Lisp error (%s): %s"
                     (car err) (error-message-string err)))))))

(defun emcp-tools-eval--rejection-message (reason)
  "Explain to the agent why an eval call was rejected for REASON.

REASON is one of the reasons of `emcp-tools-eval--format-log'."
  (pcase reason
    ('user "The user rejected the evaluation.")
    ('mode "Rejected without asking the user, because the server is in reject \
mode for eval.  The user can change the mode in `emcp-server-manager'.")
    ('default "Rejected without asking the user, because \
`emcp-tools-eval-default-policy' rejects all evaluations.")
    ('cancel "The request was cancelled before the user decided.")))

(emcp-deftool emcp-tools-eval
    ((code "Multiple top-level forms are wrapped in an implicit `progn'.")
     (max_chars "Truncate the result after this many characters, 0 or less for no limit.  Defaults to 10000."
                :type "integer" :default nil)
     (async "If true, the code returns by calling (respond VALUE) asynchronously."
            :type "boolean" :default nil))
  "Evaluate Emacs Lisp.

To enhance the safety of letting an agent execute arbitrary code, every
tool call goes through a confirmation buffer.  The user can also enable
an accept or reject mode for the whole server."
  :name "eval"
  :title "Evaluate Emacs Lisp"
  :summary "Evaluate Emacs Lisp, e.g. to run commands, change state, reload code or test ideas"
  :annotations (:destructive t :idempotent nil :open-world t)
  :description "Evaluate Emacs Lisp in the user's running Emacs and return the value of the last form.

Depending on the server's mode, the user may have to approve each call.
The call then waits until the user accepts or rejects the code, so a
slow or timed-out call may mean that the user has not answered yet
rather than that Emacs hangs.

A string value is returned verbatim, without quotes or escapes.  Other
values are printed with a modified cl-prin1 for better printing of
functions, structs and hash tables.  Text properties are dropped from all
strings.  To see them or other elided information, return a string such
as (prin1-to-string VALUE).

The code runs in the window and buffer that the user has selected at the
time the tool call arrives with lexical-binding.  The user might be
using Emacs while the code runs, so:
- Do not change the user's windows, frames, themes or buffers
  unnecessarily.  Use temporary buffers and restore state with
  unwind-protect.
- Name every advice, hook function and timer that you add, and remove
  it when you are done.
- Do not block with sleep-for, sit-for or busy loops for more than about
  a second, because that freezes the user's editor.  Wait with async
  instead.

With async true, the call ends when the code calls the local
function (respond VALUE) to return VALUE, e.g. from a timer, process
sentinel or hook.  Errors in such callbacks do not reach you, so catch
them and pass them to respond.  If respond is never called, the call
continues until the client times out."
  :async t
  (condition-case err
      (let* ((max-chars (if max_chars
                            (max 0 (truncate max_chars))
                          emcp-tools-eval--default-max-chars))
             ;; The context of the request, before any confirmation
             (window (emcp-tools-eval--user-window))
             (buffer (window-buffer window))
             (form (emcp-tools-eval--parse code))
             (decision (emcp-tools-eval--authorize server)))
        (cl-flet ((maybe-eval (accept reason)
                    (emcp--log server context
                      (info (emcp-tools-eval--format-log accept reason form async)))
                    (if accept
                        (emcp-tools-eval--eval-form
                         form window buffer max-chars async #'send-result)
                      (send-result
                       `((content . [((type . "text")
                                      (text . ,(emcp-tools-eval--rejection-message
                                                reason)))])
                         (isError . t))))))
          (if (eq decision 'ask)
              (emcp-tools-eval--prompt context form async #'maybe-eval)
            (maybe-eval decision (emcp-tools-eval--decision-source server)))))
    (emcp-tools-eval-parse-error
     (emcp--log server context
       (info (format "eval REJECT parse-error %s" (cadr err))))
     (send-result
      `((content . [((type . "text")
                     (text . ,(format "Parse error: %s" (cadr err))))])
        (isError . t))))))

(provide 'emcp-tools-eval)
;;; emcp-tools-eval.el ends here
