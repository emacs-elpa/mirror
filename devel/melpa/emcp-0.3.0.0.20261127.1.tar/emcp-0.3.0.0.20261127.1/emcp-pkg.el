;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "0.3.0.0.20261127.1"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.2.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "9c74b28f1e043dd0e70389966a0eaba66b090a51"
  :revdesc "9c74b28f1e04"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
