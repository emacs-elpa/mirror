;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejson-mode" "0.5.2.0.20190720.6"
  "Major mode for editing ejson files."
  '((emacs "25"))
  :url "https://github.com/dantecatalfamo/ejson-mode"
  :commit "9630dfac9549779711dbe89e621f516bb4b3a354"
  :revdesc "9630dfac9549"
  :keywords '("convenience" "languages" "tools"))
