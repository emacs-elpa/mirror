;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "1.0.0"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "3cf51316db1dcef64a01399ec82499b742d911e9"
  :revdesc "v1.0.0-0-g3cf51316db1d"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
