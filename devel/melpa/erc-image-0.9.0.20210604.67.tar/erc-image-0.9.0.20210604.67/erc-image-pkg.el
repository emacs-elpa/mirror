;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-image" "0.9.0.20210604.67"
  "Show received image urls in the ERC buffer."
  ()
  :url "https://github.com/kidd/erc-image.el"
  :commit "883084f0801d46a5ccf183e51ae9a734755bbb97"
  :revdesc "883084f0801d"
  :keywords '("multimedia")
  :authors '(("Jon de Andrés Frías" . "jondeandres@gmail.com")
             ("Raimon Grau Cuscó" . "raimonster@gmail.com"))
  :maintainers '(("Jon de Andrés Frías" . "jondeandres@gmail.com")
                 ("Raimon Grau Cuscó" . "raimonster@gmail.com")))
