;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simpleclip" "1.0.10.0.20250505.14"
  "Simplified access to the system clipboard."
  ()
  :url "https://github.com/rolandwalker/simpleclip"
  :commit "105b7adce212fdc9bbcbe7801531669a658c735b"
  :revdesc "v1.0.10-14-g105b7adce212"
  :keywords '("convenience")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
