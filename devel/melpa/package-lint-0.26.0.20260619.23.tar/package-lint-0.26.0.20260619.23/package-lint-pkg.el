;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-lint" "0.26.0.20260619.23"
  "A linting library for elisp package authors."
  '((emacs     "25.1")
    (let-alist "1.0.6"))
  :url "https://github.com/purcell/package-lint"
  :commit "35996f478d81e51dae4fa30d051f741895d07399"
  :revdesc "35996f478d81"
  :keywords '("lisp")
  :authors '(("Steve Purcell" . "steve@sanityinc.com")
             ("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")
                 ("Fanael Linithien" . "fanael4@gmail.com")))
