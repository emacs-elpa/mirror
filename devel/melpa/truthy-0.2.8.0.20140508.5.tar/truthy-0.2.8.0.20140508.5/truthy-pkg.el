;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truthy" "0.2.8.0.20140508.5"
  "Test the content of a value."
  '((list-utils "0.4.2"))
  :url "https://github.com/rolandwalker/truthy"
  :commit "782cee08fbb13f9be71ce8e88d980ec14db24a0f"
  :revdesc "v0.2.8-5-g782cee08fbb1"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
