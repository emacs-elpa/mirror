;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "0.5.0.0.20260625.22"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "cd1eb493ad911e1907588b559ea79cd899f2d6d1"
  :revdesc "cd1eb493ad91"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
