;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fixmee" "0.8.6.0.20230415.6"
  "Quickly navigate to FIXME notices in code."
  '((button-lock    "1.0.2")
    (nav-flash      "1.0.0")
    (back-button    "0.6.0")
    (smartrep       "0.0.3")
    (string-utils   "0.3.2")
    (tabulated-list "0"))
  :url "https://github.com/rolandwalker/fixmee"
  :commit "54500aaa8ae019034dc170af33f43465f5f03123"
  :revdesc "v0.8.6-6-g54500aaa8ae0"
  :keywords '("navigation" "convenience")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
