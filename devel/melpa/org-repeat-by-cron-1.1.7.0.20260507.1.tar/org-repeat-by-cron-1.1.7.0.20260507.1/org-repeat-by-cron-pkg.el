;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-repeat-by-cron" "1.1.7.0.20260507.1"
  "An Org mode task repeater based on Cron expressions."
  '((emacs "24.4"))
  :url "https://github.com/TomoeMami/org-repeat-by-cron.el"
  :commit "889944d9ee09fb4f09c3f7104c133a469dd242fd"
  :revdesc "889944d9ee09"
  :keywords '("calendar")
  :authors '(("TomoeMami" . "trembleafterme@outlook.com"))
  :maintainers '(("TomoeMami" . "trembleafterme@outlook.com")))
