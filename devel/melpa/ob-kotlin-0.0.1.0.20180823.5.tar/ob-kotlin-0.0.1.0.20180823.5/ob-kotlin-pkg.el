;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-kotlin" "0.0.1.0.20180823.5"
  "Org-babel functions for kotlin evaluation."
  '((org "8"))
  :url "https://github.com/zweifisch/ob-kotlin"
  :commit "b817ffb7fd03a25897eb2aba24af2035bbe3cfa8"
  :revdesc "b817ffb7fd03"
  :keywords '("org" "babel" "kotlin")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
