;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modalka" "0.1.5.0.20260802.44"
  "Modal editing your way."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/modalka"
  :commit "85d0901645982238341ba94b7c14439825dd95b5"
  :revdesc "85d090164598"
  :keywords '("convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
