;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neato-graph-bar" "1.0.0.0.20181130.16"
  "Neat-o graph bars CPU/memory etc."
  '((emacs "24.3"))
  :url "https://gitlab.com/RobertCochran/neato-graph-bar"
  :commit "a7ae35afd67911e8924f36e646bce0d3e3c1bbe6"
  :revdesc "a7ae35afd679"
  :authors '(("Robert Cochran" . "robert-git@cochranmail.com"))
  :maintainers '(("Robert Cochran" . "robert-git@cochranmail.com")))
