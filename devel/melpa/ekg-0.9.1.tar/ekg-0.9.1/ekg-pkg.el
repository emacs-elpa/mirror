;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.1"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "f1401f4189143dcfce5cd7d68231462d7a8873ec"
  :revdesc "f1401f418914"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
