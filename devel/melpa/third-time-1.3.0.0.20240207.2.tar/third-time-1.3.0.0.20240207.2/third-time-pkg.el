;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "third-time" "1.3.0.0.20240207.2"
  "Third Time: A Better Way to Work."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~swflint/third-time"
  :commit "093b74be860fac389fb173caef5fabf61e417eef"
  :revdesc "v1.3.0-2-g093b74be860f"
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
