;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xterm-keybinder" "0.1.0.0.20160523.108"
  "Let you extra keybinds in xterm/urxvt."
  '((emacs     "24.3")
    (cl-lib    "0.5")
    (let-alist "1.0.1"))
  :url "https://github.com/yuutayamada/xterm-keybinder-el"
  :commit "b29c4f700b0fa0c9f627f6725b36462b8fab06d6"
  :revdesc "b29c4f700b0f"
  :keywords '("convenient")
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
