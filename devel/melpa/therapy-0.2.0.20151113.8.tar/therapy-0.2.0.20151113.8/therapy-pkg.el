;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "therapy" "0.2.0.20151113.8"
  "Hooks for managing multiple Python major versions."
  '((emacs "24"))
  :url "https://github.com/abingham/therapy"
  :commit "775a92bb7b6b0fcc5b38c0b5198a9d0a1bef788a"
  :revdesc "775a92bb7b6b"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
