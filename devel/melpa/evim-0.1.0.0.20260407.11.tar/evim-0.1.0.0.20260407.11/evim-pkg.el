;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evim" "0.1.0.0.20260407.11"
  "Evil Visual Multi - Multiple cursors for evil-mode."
  '((emacs "27.1")
    (evil  "1.14.0"))
  :url "https://github.com/Prgebish/evim"
  :commit "746b22bea4c9b4c120472b8f6b319bbced50221e"
  :revdesc "746b22bea4c9"
  :keywords '("convenience" "emulations")
  :authors '(("Vadim Pavlov" . "vadim198527@gmail.com"))
  :maintainers '(("Vadim Pavlov" . "vadim198527@gmail.com")))
