;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.8.0.0.20261001.10"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "e0d204735ebe8e770ebe895f1524cc899973c7a3"
  :revdesc "e0d204735ebe"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
