;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emoji-cheat-sheet-plus" "1.2.2"
  "Emoji-cheat-sheet for emacs."
  '((emacs "24")
    (helm  "1.6.4"))
  :url "https://github.com/syl20bnr/emacs-emoji-cheat-sheet-plus"
  :commit "ffcc84d7060dfa000148e7f8be4fd6701593a74f"
  :revdesc "ffcc84d7060d"
  :keywords '("emacs" "emoji"))
