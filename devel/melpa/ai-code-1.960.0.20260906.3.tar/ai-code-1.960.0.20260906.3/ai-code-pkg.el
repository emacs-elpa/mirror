;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.960.0.20260906.3"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e79f1af6820ac18278c2ff60458a0bcbc733216b"
  :revdesc "e79f1af6820a"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
