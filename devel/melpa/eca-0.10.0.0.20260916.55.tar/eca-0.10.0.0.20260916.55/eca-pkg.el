;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "0.10.0.0.20260916.55"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "0dc74a863a3729c4397f7fe6264a366dbb8504c3"
  :revdesc "0dc74a863a37"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
