;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "posix-manual" "0.1.0.20231215.2"
  "POSIX manual page lookup."
  '((emacs "24"))
  :url "https://github.com/lassik/emacs-posix-manual"
  :commit "428b10d011082a57db0ce310fad6cd092267e139"
  :revdesc "0.1-2-g428b10d01108"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
