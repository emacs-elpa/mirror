;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyenv-mode" "0.1.0.0.20230821.18"
  "Integrate pyenv with python-mode."
  '((emacs    "25.1")
    (pythonic "0.1.0"))
  :url "https://github.com/proofit404/pyenv-mode"
  :commit "6820aa6673e6a51ace88611a58b423b5b1effb19"
  :revdesc "6820aa6673e6"
  :authors '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers '(("Artem Malyshev" . "proofit404@gmail.com")))
