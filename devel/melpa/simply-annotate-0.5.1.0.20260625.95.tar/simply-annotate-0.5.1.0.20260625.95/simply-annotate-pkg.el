;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "0.5.1.0.20260625.95"
  "Enhanced annotation system with threading."
  '((emacs     "28.1")
    (transient "0.4"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "2d2b75ab8fcd4d0690e67f1b210ce02133023d6c"
  :revdesc "2d2b75ab8fcd"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
