;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3.0.20260807.18"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "da00930b754e7a45ebaa8d1ea6e50c7dd134bb1f"
  :revdesc "da00930b754e"
  :keywords '("build tools" "languages"))
