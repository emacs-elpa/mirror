;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recall" "0.0.1.0.20250120.47"
  "Recall Emacs subprocess."
  '((emacs "29.1"))
  :url "https://github.com/svaante/recall"
  :commit "a8f961e9a5d6b609ee1934a0ae68ed003ee4987b"
  :revdesc "a8f961e9a5d6"
  :maintainers '(("Daniel Pettersson" . "daniel@dpettersson.net")))
