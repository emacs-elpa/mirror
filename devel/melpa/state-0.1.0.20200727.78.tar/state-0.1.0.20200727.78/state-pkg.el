;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "state" "0.1.0.20200727.78"
  "Quick navigation between workspaces."
  '((emacs "24"))
  :url "https://github.com/thisirs/state.git"
  :commit "8cd9210f17c1b134274a7352b996839aed9a7d8c"
  :revdesc "8cd9210f17c1"
  :keywords '("convenience" "workspaces")
  :authors '(("Sylvain Rousseau" . "thisirsatgmaildotcom"))
  :maintainers '(("Sylvain Rousseau" . "thisirsatgmaildotcom")))
