;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chroma" "1.1.0.0.20240716.8"
  "Color manipulation library."
  '((emacs "24.1"))
  :url "https://github.com/galdor/chroma"
  :commit "89324b476498bdfc657079040cfbbe33d1da48a3"
  :revdesc "v1.1.0-8-g89324b476498"
  :authors '(("Nicolas Martyanoff" . "nicolas@n16f.net"))
  :maintainers '(("Nicolas Martyanoff" . "nicolas@n16f.net")))
