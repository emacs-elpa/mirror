;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-markdown" "0.22.2"
  "Preview Markdown LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.22.2"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "4bd14405ab5c12bf4f7507402371d70b5c5ed063"
  :revdesc "v0.22.2-0-g4bd14405ab5c"
  :keywords '("tex" "markdown" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
