;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grammarly" "0.3.0.0.20251231.69"
  "Grammarly API interface."
  '((emacs     "26.1")
    (s         "1.12.0")
    (request   "0.3.0")
    (websocket "1.6"))
  :url "https://github.com/emacs-grammarly/grammarly"
  :commit "aa079dca01e7dc35d993bdbdf2bcdccaf93a3d56"
  :revdesc "aa079dca01e7"
  :keywords '("convenience" "grammar" "api" "interface" "english")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
