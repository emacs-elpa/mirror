;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.10.12.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "74a05852ec0c57cbe2d672b717accbdd4835c1c3"
  :revdesc "74a05852ec0c"
  :keywords '("languages"))
