;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "communinfo" "1.0"
  "Community maintained Info-url-alist."
  '((emacs "30"))
  :url "https://codeberg.org/mekeor/communinfo"
  :commit "a562535f385f1ff7a154b01047e4e2c9efc2dd65"
  :revdesc "a562535f385f"
  :keywords '("docs")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
