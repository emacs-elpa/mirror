;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "win-switch" "1.1.4"
  "Fast, dynamic bindings for window-switching/resizing."
  ()
  :url "http://www.stat.cmu.edu/~genovese/emacs/win-switch/"
  :commit "954eb5e4c5737f0c06368c42a7f1c3dd374d782f"
  :revdesc "v1.1.4-0-g954eb5e4c573"
  :keywords '("window" "switch" "key bindings" "ergonomic" "efficient")
  :authors '(("Christopher Genovese" . "genovese@cmu.edu"))
  :maintainers '(("Christopher R. Genovese" . "genovese@cmu.edu")))
