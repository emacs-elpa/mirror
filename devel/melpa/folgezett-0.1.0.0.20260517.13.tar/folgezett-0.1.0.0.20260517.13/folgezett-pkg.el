;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "folgezett" "0.1.0.0.20260517.13"
  "Folgezettel IDs for org-roam."
  '((emacs    "27.2")
    (org-roam "2.0.0"))
  :url "https://github.com/landerwells/folgezett.el"
  :commit "8b60ab378fd83a4fc9abc15c82bdcd3cdb2c507d"
  :revdesc "8b60ab378fd8"
  :keywords '("outlines" "tools" "org-roam" "zettelkasten")
  :authors '(("Lander Wells" . "landerwells@gmail.com"))
  :maintainers '(("Lander Wells" . "landerwells@gmail.com")))
