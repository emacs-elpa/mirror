;;; folgezett.el --- Folgezettel IDs for org-roam -*- lexical-binding: t; -*-

;; Copyright (C) 2025-2026 Lander Wells

;; Author: Lander Wells <landerwells@gmail.com>
;; Assisted by: Opus 4.7
;; Package-Version: 0.1.0.0.20260517.13
;; Package-Revision: 8b60ab378fd8
;; Package-Requires: ((emacs "27.2") (org-roam "2.0.0"))
;; Keywords: outlines tools org-roam zettelkasten
;; Homepage: https://github.com/landerwells/folgezett.el
;; SPDX-License-Identifier: GPL-3.0-or-later

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; folgezett.el implements the Luhmann folgezettel system for org-roam.
;;
;; When a new org-roam note is captured, the user is prompted to choose where
;; it belongs: a new chain, a branch off an existing note, or a continuation of
;; an existing chain.  A folgezettel ID is generated and stored in the
;; FOLGEZETTEL_ID property.  Branches and continuations record their parent in
;; FOLGEZETTEL_PARENT_ID.
;;
;; ID structure (alternating number/letter segments):
;;
;;   New chains:         1.1, 2.1, 3.1, ...
;;   Same chain:         1.1, 1.2, 1.3, ...
;;   Branches of 1.1:    1.1a, 1.1b, 1.1c, ...
;;   Branches of 1.1a:   1.1a1, 1.1a2, 1.1a3, ...
;;   Branches of 1.1a1:  1.1a1a, 1.1a1b, ...
;;
;; When picking an anchor note, you choose either to (b)ranch off it
;; (the new note becomes its child, e.g. 1.1 → 1.1a) or to (c)ontinue
;; its chain (the new note becomes its sibling, e.g. 1.1 → 1.2).
;;
;; Quick start:
;;
;;   (with-eval-after-load 'org-roam
;;     (require 'folgezett)
;;     (folgezett-setup))
;;
;; Commands:
;;
;;   folgezett-assign-id          Manually assign or reassign an ID
;;   folgezett-remove-id          Remove the ID and parent properties
;;   folgezett-reparent           Re-parent current note (ID only)
;;   folgezett-reparent-subtree   Re-parent + recursively update descendants
;;   folgezett-goto-parent        Jump to the parent note
;;   folgezett-list-children      Pick and jump to a direct child
;;   folgezett-show-tree          Display the full folgezettel tree
;;
;; Evil users: RET in the tree buffer is bound for Emacs state only.
;; To use it in normal/motion state, add this to your configuration:
;;
;;   (with-eval-after-load 'folgezett
;;     (with-eval-after-load 'evil
;;       (evil-define-key* '(normal motion) folgezett-tree-mode-map
;;         (kbd "RET") #'folgezett-tree-visit-node)))

;;; Code:

(require 'org-roam)
(require 'org-roam-node)
(require 'cl-lib)
(require 'subr-x)

;;;; ── Customization ────────────────────────────────────────────────────────

(defgroup folgezett nil
  "Folgezettel ID system for org-roam."
  :group 'org-roam
  :prefix "folgezett-")

(defcustom folgezett-id-property "FOLGEZETTEL_ID"
  "Org property name that stores a note's folgezettel ID."
  :type 'string
  :group 'folgezett)

(defcustom folgezett-parent-property "FOLGEZETTEL_PARENT_ID"
  "Org property name that stores the parent note's org-roam node ID."
  :type 'string
  :group 'folgezett)

(defcustom folgezett-include-id-in-filename nil
  "When non-nil, prepend the folgezettel ID to the note's filename.
Capture renaming happens after finalization, once Org has expanded the
capture template and the note title is available."
  :type 'boolean
  :group 'folgezett)

(defcustom folgezett-capture-keys nil
  "Capture template keys that trigger folgezettel assignment.
When nil (the default), every new node capture triggers assignment."
  :type '(repeat string)
  :group 'folgezett)

(defcustom folgezett-show-id-in-completions t
  "When non-nil, show folgezettel IDs in org-roam node completions.
Takes effect when `folgezett-setup' or
`folgezett-enable-completion-display' is called."
  :type 'boolean
  :group 'folgezett)

(defcustom folgezett-export-parent-label "Previous"
  "Label prefix for the parent link injected during export.
When non-nil, `org-export-before-processing-functions' inserts a
line of the form \"LABEL: [[id:…][Title]]\" at the top of the
note body (after any property drawer and #+keyword lines, before
the first content), so ox-hugo and other backends render a parent
backlink without the link being stored on disk.  Set to nil to
disable."
  :type '(choice (const :tag "Disabled" nil) string)
  :group 'folgezett)

(defcustom folgezett-db-link-parent nil
  "When non-nil, inject parent links into org-roam's database.
This advises `org-roam-db-update-file' so that the FOLGEZETTEL_PARENT_ID
property is registered as an `id' link in org-roam's links table.
The result is that parent-child relationships appear in backlinks,
the org-roam buffer, and org-roam-ui — without adding any text to
your note files.  Requires `org-roam-db-sync' after enabling."
  :type 'boolean
  :group 'folgezett)

;;;; ── ID Helpers ───────────────────────────────────────────────────────────

(defun folgezett--ends-in-digit-p (id)
  "Return non-nil if ID ends with a digit."
  (and (stringp id)
       (not (string-empty-p id))
       (string-match-p "[0-9]$" id)))

(defun folgezett--strip-last-segment (id)
  "Remove the final segment of ID and return the result.
Returns nil when ID is already root-level (no parent)."
  (cond
   ;; Ends in a letter: strip that one character
   ((string-match "^\\(.*\\)[a-z]$" id)
    (let ((prefix (match-string 1 id)))
      (and (not (string-empty-p prefix)) prefix)))
   ;; Ends in digits preceded by a letter: strip digit run
   ((string-match "^\\(.*[a-z]\\)[0-9]+$" id)
    (match-string 1 id))
   ;; Root ID (e.g. "1.1") — no parent
   (t nil)))

(defun folgezett--increment-id (id)
  "Increment the terminal segment of ID to produce the next sibling.
Letter terminal: a→b … y→z.  Digit terminal: 1→2 … 9→10."
  (cond
   ((string-match "^\\(.*\\)\\([a-z]\\)$" id)
    (let ((letter (string-to-char (match-string 2 id))))
      (when (= letter ?z)
        (user-error "Folgezettel: exhausted letters at ID %s" id))
      (concat (match-string 1 id) (char-to-string (1+ letter)))))
   ((string-match "^\\(.*\\)\\([0-9]+\\)$" id)
    (concat (match-string 1 id)
            (number-to-string (1+ (string-to-number (match-string 2 id))))))
   (t (user-error "Cannot increment folgezettel ID: %s" id))))

(defun folgezett--first-child-id (parent-id)
  "Return the ID of the first child of PARENT-ID.
Number-terminal parents get a letter suffix; letter-terminal get a digit."
  (if (folgezett--ends-in-digit-p parent-id)
      (concat parent-id "a")
    (concat parent-id "1")))

(defun folgezett--direct-child-p (parent-id candidate-id)
  "Return non-nil if CANDIDATE-ID is a direct child of PARENT-ID."
  (and (string-prefix-p parent-id candidate-id)
       (let ((suffix (substring candidate-id (length parent-id))))
         (if (folgezett--ends-in-digit-p parent-id)
             (string-match-p "^[a-z]$" suffix)
           (string-match-p "^[0-9]+$" suffix)))))

(defun folgezett--id-depth (id)
  "Return the 0-based depth of ID in the folgezettel tree (root = 0)."
  (let ((segments 0)
        (pos 0)
        (len (length id)))
    (while (< pos len)
      (cond
       ((and (string-match "[0-9]+" id pos)
             (= (match-beginning 0) pos))
        (setq pos (match-end 0))
        (cl-incf segments))
       ((and (string-match "[a-z]+" id pos)
             (= (match-beginning 0) pos))
        (setq pos (match-end 0))
        (cl-incf segments))
       (t (cl-incf pos))))
    (max 0 (- segments 2))))

(defun folgezett--id-segments (id)
  "Parse ID into a list of segments.
Digit runs become integers; letter runs remain strings."
  (let (segments
        (pos 0)
        (len (length id)))
    (while (< pos len)
      (cond
       ((and (string-match "[0-9]+" id pos)
             (= (match-beginning 0) pos))
        (push (string-to-number (match-string 0 id)) segments)
        (setq pos (match-end 0)))
       ((and (string-match "[a-z]+" id pos)
             (= (match-beginning 0) pos))
        (push (match-string 0 id) segments)
        (setq pos (match-end 0)))
       (t (cl-incf pos))))
    (nreverse segments)))

(defun folgezett--id< (a b)
  "Return non-nil if A comes before B in natural folgezettel order.
Numbers compare numerically (so 1.2 < 1.10) and letters lexically."
  (let ((as (folgezett--id-segments a))
        (bs (folgezett--id-segments b))
        (result nil)
        (decided nil))
    (while (and as bs (not decided))
      (let ((x (pop as))
            (y (pop bs)))
        (cond
         ((and (numberp x) (numberp y))
          (cond ((< x y) (setq result t decided t))
                ((> x y) (setq decided t))))
         ((and (stringp x) (stringp y))
          (cond ((string< x y) (setq result t decided t))
                ((string> x y) (setq decided t))))
         ((numberp x) (setq result t decided t))
         (t (setq decided t)))))
    (if decided result (and (null as) (consp bs)))))

;;;; ── Database Access ──────────────────────────────────────────────────────

(defun folgezett--all-nodes ()
  "Return an alist of (fz-id . org-roam-node) for nodes that have a folgezettel ID."
  (let (result)
    (dolist (node (org-roam-node-list))
      (when-let ((fz-id (cdr (assoc folgezett-id-property
                                    (org-roam-node-properties node)))))
        (push (cons fz-id node) result)))
    result))

(defun folgezett--all-ids ()
  "Return a list of all existing folgezettel ID strings."
  (mapcar #'car (folgezett--all-nodes)))

(defun folgezett--node-by-fz-id (fz-id)
  "Return the org-roam node whose folgezettel ID equals FZ-ID, or nil."
  (cdr (assoc fz-id (folgezett--all-nodes))))

;;;; ── Next-ID Computation ──────────────────────────────────────────────────

(defun folgezett--max-id (ids)
  "Return the greatest sibling ID from the list IDS."
  (cl-reduce
   (lambda (best id)
     (if (and (folgezett--ends-in-digit-p best)
              (folgezett--ends-in-digit-p id))
         ;; Both digit-terminal: compare numerically on the trailing number
         (progn
           (string-match "[0-9]+$" best)
           (let ((bn (string-to-number (match-string 0 best))))
             (string-match "[0-9]+$" id)
             (if (> (string-to-number (match-string 0 id)) bn) id best)))
       ;; Otherwise alphabetic comparison suffices
       (if (string> id best) id best)))
   ids))

(defun folgezett--next-child-id (parent-id &optional exclude-id)
  "Return the next available child ID for PARENT-ID.
EXCLUDE-ID, if provided, is omitted from the sibling list (used when
re-parenting so the note's own current ID does not inflate the counter)."
  (let* ((all      (folgezett--all-ids))
         (children (cl-remove-if-not
                    (lambda (id)
                      (and (folgezett--direct-child-p parent-id id)
                           (not (equal id exclude-id))))
                    all)))
    (if children
        (folgezett--increment-id (folgezett--max-id children))
      (folgezett--first-child-id parent-id))))

(defun folgezett--next-root-id ()
  "Return the next available root-level folgezettel ID (e.g. \"1.1\", \"2.1\")."
  (let* ((all   (folgezett--all-ids))
         (roots (cl-remove-if-not
                 (lambda (id) (string-match-p "^[0-9]+\\.[0-9]+$" id))
                 all)))
    (if roots
        (let ((max-n (apply #'max
                            (mapcar (lambda (id)
                                      (string-to-number
                                       (car (split-string id "\\."))))
                                    roots))))
          (format "%d.1" (1+ max-n)))
      "1.1")))

(defun folgezett--next-sibling-id (fz-id &optional exclude-id)
  "Return the next sibling ID for FZ-ID.
For chain-root IDs (e.g. \"1.1\"), returns the next ID in the same chain
\(e.g. \"1.2\").  Otherwise returns the next sibling under FZ-ID's parent.
EXCLUDE-ID, if provided, is omitted from sibling counting."
  (cond
   ((string-match "^\\([0-9]+\\)\\.[0-9]+$" fz-id)
    (let* ((chain    (match-string 1 fz-id))
           (re       (concat "^" (regexp-quote chain) "\\.[0-9]+$"))
           (all      (folgezett--all-ids))
           (siblings (cl-remove-if-not
                      (lambda (id)
                        (and (string-match-p re id)
                             (not (equal id exclude-id))))
                      all)))
      (if siblings
          (folgezett--increment-id (folgezett--max-id siblings))
        (concat chain ".1"))))
   (t
    (let ((parent (folgezett--strip-last-segment fz-id)))
      (unless parent
        (user-error "Cannot determine parent of folgezettel ID: %s" fz-id))
      (folgezett--next-child-id parent exclude-id)))))

;;;; ── Placement Selection UI ───────────────────────────────────────────────

(defun folgezett--select-place ()
  "Prompt for the placement of a new folgezettel note.
Returns one of:
  (:root)              — start a new chain (e.g. 2.1 if chain 1 exists)
  (:branch . NODE)     — add a new branch off NODE (NODE becomes parent)
  (:continue . NODE)   — continue NODE's chain (new note is NODE's sibling)"
  (let* ((nodes-alist (folgezett--all-nodes))
         (root-label  "[New chain — top-level note]")
         (candidates
          (cons (cons root-label nil)
                (mapcar (lambda (entry)
                          (cons (format "%-10s  %s"
                                        (car entry)
                                        (org-roam-node-title (cdr entry)))
                                (cdr entry)))
                        (sort nodes-alist
                              (lambda (a b) (string< (car a) (car b)))))))
         (choice (completing-read "Folgezettel anchor: "
                                  (mapcar #'car candidates)
                                  nil t nil nil root-label))
         (node (cdr (assoc choice candidates))))
    (if (null node)
        (list :root)
      (let* ((fz-id           (cdr (assoc folgezett-id-property
                                          (org-roam-node-properties node))))
             (branch-preview  (folgezett--next-child-id fz-id))
             (sibling-preview (folgezett--next-sibling-id fz-id))
             (key (read-char-choice
                   (format "(b)ranch → %s    (c)ontinue chain → %s    "
                           branch-preview sibling-preview)
                   '(?b ?c))))
        (cl-case key
          (?b (cons :branch node))
          (?c (cons :continue node)))))))

;;;; ── Core: Assign ID ──────────────────────────────────────────────────────

(defun folgezett--prompt-for-id (&optional exclude-id)
  "Prompt for placement and return (NEW-FZ-ID . PARENT-NODE-ID).
PARENT-NODE-ID is the org-roam node ID to record as
`folgezett-parent-property', or nil when the new note has no folgezettel
parent.  Branching makes the anchor the parent; continuing a chain makes
the new note a sibling of the anchor (so they share a parent).
EXCLUDE-ID, if given, is omitted from sibling counting (used during
re-parenting so the note's own current ID does not inflate the counter)."
  (let* ((place  (folgezett--select-place))
         (kind   (car place))
         (anchor (cdr place)))
    (pcase kind
      (:root (cons (folgezett--next-root-id) nil))
      (:branch
       (let ((anchor-fz-id (cdr (assoc folgezett-id-property
                                       (org-roam-node-properties anchor)))))
         (cons (folgezett--next-child-id anchor-fz-id exclude-id)
               (org-roam-node-id anchor))))
      (:continue
       (let* ((anchor-fz-id   (cdr (assoc folgezett-id-property
                                          (org-roam-node-properties anchor))))
              (parent-roam-id (cdr (assoc folgezett-parent-property
                                          (org-roam-node-properties anchor)))))
         (cons (folgezett--next-sibling-id anchor-fz-id exclude-id)
               parent-roam-id))))))

(defun folgezett--set-properties (fz-id parent-node-id)
  "Set FOLGEZETTEL_ID to FZ-ID and FOLGEZETTEL_PARENT_ID to PARENT-NODE-ID.
When PARENT-NODE-ID is nil the parent property is removed.
Always writes to the org-roam node at point (file-level or heading)
rather than wherever point happens to be, so the property drawer is
not created in the body — which would shift `#+title:' out of where
org-roam-db looks for it and blank the title in the cache."
  (save-excursion
    (when-let ((node (org-roam-node-at-point)))
      (goto-char (org-roam-node-point node)))
    (org-set-property folgezett-id-property fz-id)
    (if parent-node-id
        (org-set-property folgezett-parent-property parent-node-id)
      (org-delete-property folgezett-parent-property))))

;;;###autoload
(defun folgezett-assign-id ()
  "Assign (or reassign) a folgezettel ID to the org-roam node at point.
Prompts for a placement, derives the next appropriate ID, and sets
the FOLGEZETTEL_ID (and optionally FOLGEZETTEL_PARENT_ID) property."
  (interactive)
  (unless (org-roam-node-at-point)
    (user-error "No org-roam node at point"))
  (let* ((existing-fz-id (cdr (assoc folgezett-id-property
                                      (org-roam-node-properties
                                       (org-roam-node-at-point)))))
         (id-pair   (folgezett--prompt-for-id existing-fz-id))
         (new-fz-id (car id-pair))
         (parent-id (cdr id-pair)))
    (folgezett--set-properties new-fz-id parent-id)
    (save-buffer)
    (when folgezett-include-id-in-filename
      (folgezett--rename-file-with-id new-fz-id))
    (org-roam-db-update-file)
    (message "folgezett: assigned ID %s" new-fz-id)
    new-fz-id))

;;;###autoload
(defun folgezett-remove-id ()
  "Remove all folgezettel state from the org-roam node at point.
Deletes the FOLGEZETTEL_ID and FOLGEZETTEL_PARENT_ID properties and,
when `folgezett-include-id-in-filename' is non-nil, strips the
leading ID from the buffer's filename."
  (interactive)
  (let* ((node (or (org-roam-node-at-point)
                   (user-error "No org-roam node at point")))
         (fz-id (cdr (assoc folgezett-id-property
                            (org-roam-node-properties node)))))
    (unless fz-id
      (user-error "Note has no folgezettel ID"))
    (save-excursion
      (org-delete-property folgezett-id-property)
      (org-delete-property folgezett-parent-property))
    (when folgezett-include-id-in-filename
      (folgezett--rename-file-without-id fz-id))
    (save-buffer)
    (org-roam-db-update-file)
    (message "folgezett: removed ID %s" fz-id)))

;;;; ── File Renaming ────────────────────────────────────────────────────────

(defun folgezett--buffer-fz-id ()
  "Return the first folgezettel ID found in the current buffer, or nil."
  (or (when-let ((node (org-roam-node-at-point)))
        (cdr (assoc folgezett-id-property
                    (org-roam-node-properties node))))
      (save-excursion
        (org-with-wide-buffer
         (goto-char (point-min))
         (when (re-search-forward
                (concat "^[ \t]*:" (regexp-quote folgezett-id-property)
                        ":[ \t]+\\(.+\\)$")
                nil t)
           (string-trim (match-string-no-properties 1)))))))

(defun folgezett--sanitize-filename-component (s)
  "Strip filesystem-hostile characters from S for use in a filename."
  (replace-regexp-in-string "[/\\\\:\0]+" "-" s))

(defun folgezett--buffer-title ()
  "Return the current buffer's `#+title:' keyword value, or nil."
  (let ((kw (cdr (assoc "TITLE" (org-collect-keywords '("title"))))))
    (and kw (string-join kw " "))))

(defun folgezett--rename-file-with-id (fz-id)
  "Rename the current buffer's file to \"FZ-ID Title.EXT\".
Saves the buffer first so the on-disk content is consistent before
`rename-file' triggers org-roam's autosync re-indexing."
  (when-let* ((file  (buffer-file-name))
              (dir   (file-name-directory file))
              (title (or (folgezett--buffer-title)
                         (when-let ((node (org-roam-node-at-point)))
                           (org-roam-node-title node))))
              ((not (string-empty-p title)))
              (ext   (or (file-name-extension file t) ".org"))
              (new-base (folgezett--sanitize-filename-component
                         (concat fz-id " " title ext)))
              (new-file (expand-file-name new-base dir)))
    (unless (string= file new-file)
      (when (buffer-modified-p) (save-buffer))
      (rename-file file new-file 1)
      (set-visited-file-name new-file t t)
      (message "folgezett: renamed → %s"
               (file-name-nondirectory new-file)))))

(defun folgezett--rename-file-without-id (fz-id)
  "Strip a leading \"FZ-ID \" prefix from the current buffer's filename."
  (when-let* ((file (buffer-file-name))
              (dir  (file-name-directory file))
              (base (file-name-nondirectory file))
              (prefix (concat fz-id " ")))
    (when (string-prefix-p prefix base)
      (let* ((new-base (substring base (length prefix)))
             (new-file (expand-file-name new-base dir)))
        (unless (string= file new-file)
          (rename-file file new-file 1)
          (set-visited-file-name new-file t t)
          (message "folgezett: renamed → %s" new-base))))))

;;;; ── Re-parenting ─────────────────────────────────────────────────────────

;;;###autoload
(defun folgezett-reparent ()
  "Choose a new parent and reassign the folgezettel ID of the current note.
Only the current note is updated; descendants keep their existing IDs.
See `folgezett-reparent-subtree' to update descendants as well."
  (interactive)
  (folgezett-assign-id))

(defun folgezett--descendants (fz-id)
  "Return a sorted list of all folgezettel IDs descended from FZ-ID."
  (sort (cl-remove-if-not
         (lambda (id)
           (and (string-prefix-p fz-id id) (not (string= fz-id id))))
         (folgezett--all-ids))
        #'string<))

(defun folgezett--remap-descendants (old-prefix new-prefix)
  "Replace OLD-PREFIX with NEW-PREFIX on every descendant ID."
  (dolist (old-id (folgezett--descendants old-prefix))
    (when-let ((node (folgezett--node-by-fz-id old-id)))
      (let ((new-id (concat new-prefix (substring old-id (length old-prefix)))))
        (with-current-buffer (find-file-noselect (org-roam-node-file node))
          (save-excursion
            (org-set-property folgezett-id-property new-id))
          (save-buffer))
        (message "folgezett: %s → %s" old-id new-id)))))

;;;###autoload
(defun folgezett-reparent-subtree ()
  "Re-parent the current note and recursively update all descendant IDs.
The structural suffix of each descendant is preserved; only the
leading prefix (the old ID of the re-parented note) is replaced."
  (interactive)
  (let* ((node (or (org-roam-node-at-point)
                   (user-error "No org-roam node at point")))
         (old-fz-id (cdr (assoc folgezett-id-property
                                 (org-roam-node-properties node)))))
    (unless old-fz-id
      (user-error "No folgezettel ID — run `folgezett-assign-id' first"))
    (let ((new-fz-id (folgezett-assign-id)))
      (when (and new-fz-id (not (string= old-fz-id new-fz-id)))
        (folgezett--remap-descendants old-fz-id new-fz-id)
        (message "folgezett: subtree %s → %s complete" old-fz-id new-fz-id)))))

;;;; ── Navigation ───────────────────────────────────────────────────────────

;;;###autoload
(defun folgezett-goto-parent ()
  "Visit the parent of the org-roam node at point."
  (interactive)
  (let* ((node (or (org-roam-node-at-point)
                   (user-error "No org-roam node at point")))
         (parent-node-id (cdr (assoc folgezett-parent-property
                                      (org-roam-node-properties node)))))
    (if parent-node-id
        (org-roam-node-visit (org-roam-node-from-id parent-node-id))
      (message "folgezett: this note is root-level (no parent)."))))

;;;###autoload
(defun folgezett-list-children ()
  "Select and visit a direct child of the org-roam node at point."
  (interactive)
  (let* ((node (or (org-roam-node-at-point)
                   (user-error "No org-roam node at point")))
         (fz-id (cdr (assoc folgezett-id-property
                             (org-roam-node-properties node)))))
    (unless fz-id
      (user-error "Current note has no folgezettel ID"))
    (let* ((all      (folgezett--all-nodes))
           (children (cl-remove-if-not
                      (lambda (e) (folgezett--direct-child-p fz-id (car e)))
                      all)))
      (if (null children)
          (message "folgezett: %s has no children." fz-id)
        (let* ((cands  (sort children (lambda (a b) (string< (car a) (car b)))))
               (labels (mapcar (lambda (e)
                                 (cons (format "%-8s  %s"
                                               (car e)
                                               (org-roam-node-title (cdr e)))
                                       (cdr e)))
                               cands))
               (choice (completing-read
                        (format "Children of %s: " fz-id)
                        (mapcar #'car labels) nil t))
               (target (cdr (assoc choice labels))))
          (when target (org-roam-node-visit target)))))))

;;;; ── Tree View ────────────────────────────────────────────────────────────

(defvar folgezett-tree-mode-map
  (let ((map (make-sparse-keymap)))
    (set-keymap-parent map special-mode-map)
    (define-key map (kbd "RET") #'folgezett-tree-visit-node)
    map)
  "Keymap for `folgezett-tree-mode'.")

(define-derived-mode folgezett-tree-mode special-mode "Fz-Tree"
  "Major mode for the *Folgezettel Tree* buffer.
\\<folgezett-tree-mode-map>
\\[folgezett-tree-visit-node] Visit the note on the current line."
  :group 'folgezett)

(defun folgezett-tree-visit-node ()
  "Visit the org-roam node on the current line and close the tree buffer."
  (interactive)
  (if-let ((node (get-text-property (line-beginning-position) 'folgezett-node)))
      (let ((buf (current-buffer)))
        (quit-window)
        (kill-buffer buf)
        (org-roam-node-visit node))
    (user-error "No folgezettel node on this line")))

(defun folgezett--tree-children (parent-id nodes-alist)
  "Return entries in NODES-ALIST that are direct children of PARENT-ID.
PARENT-ID nil returns chain roots (e.g. \"1.1\", \"2.1\")."
  (sort
   (cl-remove-if-not
    (lambda (entry)
      (let ((id (car entry)))
        (if (null parent-id)
            (string-match-p "^[0-9]+\\.[0-9]+$" id)
          (folgezett--direct-child-p parent-id id))))
    nodes-alist)
   (lambda (a b) (folgezett--id< (car a) (car b)))))

(defun folgezett--tree-render (parent-id depth nodes-alist)
  "Insert children of PARENT-ID at DEPTH, recursively, from NODES-ALIST."
  (dolist (entry (folgezett--tree-children parent-id nodes-alist))
    (let* ((fz-id (car entry))
           (node  (cdr entry))
           (pad   (make-string (* depth 2) ?\s))
           (title (or (org-roam-node-title node) ""))
           (line  (format "%s%-8s  %s\n" pad fz-id title)))
      (insert (propertize line 'folgezett-node node))
      (folgezett--tree-render fz-id (1+ depth) nodes-alist))))

;;;###autoload
(defun folgezett-show-tree ()
  "Display the full folgezettel hierarchy in a dedicated buffer."
  (interactive)
  (let ((nodes-alist (folgezett--all-nodes)))
    (with-current-buffer (get-buffer-create "*Folgezettel Tree*")
      (let ((inhibit-read-only t))
        (erase-buffer)
        (insert "Folgezettel Tree\n")
        (insert (make-string 60 ?─) "\n\n")
        (if (null nodes-alist)
            (insert "  (no folgezettel notes found)\n")
          (folgezett--tree-render nil 0 nodes-alist))
        (insert "\n"))
      (folgezett-tree-mode)
      (goto-char (point-min))
      (pop-to-buffer (current-buffer)))))

;;;; ── Completion Display ───────────────────────────────────────────────────

(cl-defmethod org-roam-node-folgezettel-id ((node org-roam-node))
  "Return the folgezettel ID of NODE, or an empty string."
  (or (cdr (assoc folgezett-id-property (org-roam-node-properties node)))
      ""))

;;;###autoload
(defun folgezett-enable-completion-display ()
  "Add folgezettel IDs to `org-roam-node-display-template'."
  (setq org-roam-node-display-template
        (concat "${folgezettel-id:8} ${title:*} "
                (propertize "${tags:20}" 'face 'org-tag))))

;;;; ── DB Integration (parent backlinks) ────────────────────────────────────

(defun folgezett--db-insert-parent-links (&optional _file-path &rest _)
  "Insert link rows for FOLGEZETTEL_PARENT_ID properties.
Designed as :after advice on `org-roam-db-update-file'.  For every
node in the current buffer that has a parent property, a synthetic
link record is added to org-roam's links table so that backlinks and
the graph reflect the folgezettel parent-child relationship."
  (org-with-wide-buffer
    (goto-char (point-min))
    (while (re-search-forward
            (concat ":" folgezett-parent-property ":[ \t]+\\(.+\\)") nil t)
      (let ((parent-id (string-trim (match-string-no-properties 1)))
            (source    (org-roam-id-at-point)))
        (when (and source (not (string-empty-p parent-id)))
          (org-roam-db-query
           [:insert :into links :values $v1]
           (vector (point) source parent-id "id" '(:outline nil))))))))

;;;; ── Export Integration ───────────────────────────────────────────────────

(defun folgezett--export-inject-parent (_backend)
  "Inject a \"Previous: …\" line into the export buffer before parsing.
Meant for `org-export-before-processing-functions': Org runs this
on a temporary copy of the buffer, so the inserted line does not
modify the file on disk.  The line is placed after any top-level
property drawer and #+keyword: lines, before the first body
content.  Honours `folgezett-export-parent-label' — when nil, does
nothing."
  (when folgezett-export-parent-label
    (org-with-wide-buffer
     (goto-char (point-min))
     (when (re-search-forward
            (concat "^[ \t]*:" folgezett-parent-property ":[ \t]+\\(.+\\)$")
            nil t)
       (let* ((parent-id (string-trim (match-string-no-properties 1)))
              (node (and (not (string-empty-p parent-id))
                         (ignore-errors (org-roam-node-from-id parent-id))))
              (title (and node (org-roam-node-title node))))
         (when (and node title)
           (goto-char (point-min))
           (when (looking-at-p "[ \t]*:PROPERTIES:")
             (re-search-forward "^[ \t]*:END:[ \t]*\n" nil t))
           (while (looking-at "^\\(?:[ \t]*#\\+[^\n]*\\|[ \t]*\\)\n")
             (goto-char (match-end 0)))
           (insert (format "%s: [[id:%s][%s]]\n\n"
                           folgezett-export-parent-label
                           parent-id title))))))))

;;;; ── Capture Hook ─────────────────────────────────────────────────────────

(defun folgezett--capture-finalize-hook ()
  "Rename newly captured notes after Org has expanded the capture template.
`org-roam-capture-new-node-hook' runs before the template body is fully
inserted, so the final title/filename is not always available there.  This
hook runs after finalization and can safely prepend the assigned ID to the
file name when `folgezett-include-id-in-filename' is non-nil."
  (when folgezett-include-id-in-filename
    (when-let* ((marker (bound-and-true-p org-capture-last-stored-marker))
                (buffer (marker-buffer marker))
                ((buffer-live-p buffer)))
      (with-current-buffer buffer
        (save-excursion
          (goto-char marker)
          (when-let ((fz-id (folgezett--buffer-fz-id)))
            (folgezett--rename-file-with-id fz-id)
            (save-buffer)
            (ignore-errors (org-roam-db-update-file))))))))

(defun folgezett--capture-hook ()
  "Hook for `org-roam-capture-new-node-hook'.
Prompts for a placement and writes folgezettel properties to the new node.
Skips the node if it already has a folgezettel ID, and respects
`folgezett-capture-keys' when it is non-nil."
  (when (or (null folgezett-capture-keys)
            (member (plist-get org-capture-plist :key)
                    folgezett-capture-keys))
    (let* ((node     (org-roam-node-at-point))
           (existing (when node
                       (cdr (assoc folgezett-id-property
                                   (org-roam-node-properties node))))))
      (unless existing
        (let* ((id-pair   (folgezett--prompt-for-id))
               (new-fz-id (car id-pair))
               (parent-id (cdr id-pair)))
          (save-excursion
            (when node (goto-char (org-roam-node-point node)))
            (folgezett--set-properties new-fz-id parent-id))
          (message "folgezett: assigned ID %s" new-fz-id))))))

;;;; ── Mode & Setup ─────────────────────────────────────────────────────────

;;;###autoload
(define-minor-mode folgezett-mode
  "Global minor mode: assign folgezettel IDs when capturing new org-roam nodes."
  :global t
  :group 'folgezett
  :lighter " Fz"
  (if folgezett-mode
      (progn
        (add-hook 'org-roam-capture-new-node-hook
                  #'folgezett--capture-hook)
        (add-hook 'org-capture-after-finalize-hook
                  #'folgezett--capture-finalize-hook)
        (add-hook 'org-export-before-processing-functions
                  #'folgezett--export-inject-parent)
        (when folgezett-db-link-parent
          (advice-add 'org-roam-db-update-file :after
                      #'folgezett--db-insert-parent-links)))
    (remove-hook 'org-roam-capture-new-node-hook
                 #'folgezett--capture-hook)
    (remove-hook 'org-capture-after-finalize-hook
                 #'folgezett--capture-finalize-hook)
    (remove-hook 'org-export-before-processing-functions
                 #'folgezett--export-inject-parent)
    (advice-remove 'org-roam-db-update-file
                   #'folgezett--db-insert-parent-links)))

;;;###autoload
(defun folgezett-setup ()
  "Enable folgezett and integrate it with org-roam.

Call this after org-roam is loaded:

  (with-eval-after-load \\='org-roam
    (require \\='folgezett)
    (folgezett-setup))"
  (folgezett-mode 1)
  (when folgezett-show-id-in-completions
    (folgezett-enable-completion-display)))

(provide 'folgezett)

;;; folgezett.el ends here
