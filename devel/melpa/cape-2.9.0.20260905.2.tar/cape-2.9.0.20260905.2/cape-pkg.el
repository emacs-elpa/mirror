;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "2.9.0.20260905.2"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/cape"
  :commit "1c543fce9151821e8400258aefcfdee2fb24920d"
  :revdesc "2.9-2-g1c543fce9151"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
