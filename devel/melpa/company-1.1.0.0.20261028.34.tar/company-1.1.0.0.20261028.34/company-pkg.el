;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "1.1.0.0.20261028.34"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "0029cbb435c7fc68ceff0987fae0256f1ccf0507"
  :revdesc "1.1.0-34-g0029cbb435c7"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
