;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pytest-pdb-break" "0.0.10"
  "A pytest PDB launcher."
  '((emacs "25"))
  :url "https://github.com/poppyschmo/pytest-pdb-break"
  :commit "05d227493b7b96f3556cba22f215cb85f9282020"
  :revdesc "0.0.10-0-g05d227493b7b"
  :keywords '("languages" "tools")
  :authors '(("Jane Soko" . "poppyschmo@protonmail.com"))
  :maintainers '(("Jane Soko" . "poppyschmo@protonmail.com")))
