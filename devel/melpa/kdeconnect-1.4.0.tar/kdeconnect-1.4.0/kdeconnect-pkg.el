;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kdeconnect" "1.4.0"
  "An interface for KDE Connect."
  '((emacs "25.1"))
  :url "https://github.com/carldotac/kdeconnect.el"
  :commit "daee28249b852cc52f4f32d35704a97af5cc4b7d"
  :revdesc "daee28249b85"
  :keywords '("convenience")
  :authors '(("Carl Lieberman" . "dev@carl.ac"))
  :maintainers '(("Carl Lieberman" . "dev@carl.ac")))
