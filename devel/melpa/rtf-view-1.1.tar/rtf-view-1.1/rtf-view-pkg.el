;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rtf-view" "1.1"
  "View Rich Text Format files."
  '((emacs "24.1"))
  :url "https://github.com/danielcmccarthy/rtf-view.git"
  :commit "81197d08020ed07e97f4479963002d81c115b647"
  :revdesc "81197d08020e"
  :keywords '("files" "data")
  :authors '(("Dan McCarthy" . "daniel.c.mccarthy@gmail.com"))
  :maintainers '(("Dan McCarthy" . "daniel.c.mccarthy@gmail.com")))
