;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cort" "7.1.0.0.20260516.47"
  "Simplify extended unit test framework."
  '((emacs  "24.1")
    (ansi   "0.4.1")
    (cl-lib "0.7.1"))
  :url "https://github.com/conao3/cort.el"
  :commit "851a8669f14a1cfc3b0f9d6bf046139cb5bb7470"
  :revdesc "851a8669f14a"
  :keywords '("test" "lisp")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
