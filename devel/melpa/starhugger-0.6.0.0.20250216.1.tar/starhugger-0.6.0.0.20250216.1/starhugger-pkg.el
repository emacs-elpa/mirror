;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "starhugger" "0.6.0.0.20250216.1"
  "Hugging Face/AI-powered text & code completion client."
  '((emacs   "28.2")
    (compat  "29.1.4.0")
    (dash    "2.18.0")
    (s       "1.13.1")
    (spinner "1.7.4")
    (request "0.3.2"))
  :url "https://gitlab.com/daanturo/starhugger.el"
  :commit "c9753808184eaa9328b6ada18bfe418150b92eac"
  :revdesc "c9753808184e"
  :keywords '("completion" "convenience" "languages"))
