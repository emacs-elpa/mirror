;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "1.0.1.0.20260704.7"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "d4b62957688cac3cb957de634bce0b27b0eb1ed5"
  :revdesc "1.0.1-7-gd4b62957688c"
  :keywords '("maint")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
