;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-cua-dwim" "0.5.0.20120203.1"
  "Org-mode and Cua mode compatibility layer."
  ()
  :url "https://github.com/mattfidler/org-cua-dwim.el"
  :commit "a55d6c7009fc0b22f1110c07de629acc955c85e4"
  :revdesc "a55d6c7009fc"
  :keywords '("org-mode" "cua-mode"))
