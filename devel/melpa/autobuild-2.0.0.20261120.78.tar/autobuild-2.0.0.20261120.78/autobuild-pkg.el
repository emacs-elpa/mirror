;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autobuild" "2.0.0.20261120.78"
  "Define and execute build rules and compilation pipelines."
  '((emacs   "26.1")
    (selcand "0.0.3"))
  :url "https://github.com/erjoalgo/autobuild"
  :commit "23743a2875f69dfa64a7f441132896d7c64b79b9"
  :revdesc "v2.0-78-g23743a2875f6"
  :keywords '("compile" "build" "pipeline" "autobuild" "extensions" "processes" "tools")
  :maintainers '(("concat \"erjoalgo\" \"@\" \"gmail\" \".com\"" . "")))
