;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-cspell" "0.1.0.20240304.8"
  "A Flymake backend for CSpell."
  '((emacs "26.1"))
  :url "https://github.com/fritzgrabo/flymake-cspell"
  :commit "a573c07142cd0142c4cc1affd57f96b4d5c229b3"
  :revdesc "a573c07142cd"
  :keywords '("wp")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
