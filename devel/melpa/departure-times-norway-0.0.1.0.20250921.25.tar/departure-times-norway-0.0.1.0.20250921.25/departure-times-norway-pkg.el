;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "departure-times-norway" "0.0.1.0.20250921.25"
  "Display public transport departure times in Norway."
  '((emacs   "27.1")
    (persist "0.6.1"))
  :url "https://github.com/hsolg/emacs-departure-times-norway"
  :commit "3b0559bc55099cb025df63715ed9029885b64c39"
  :revdesc "3b0559bc5509"
  :authors '(("Henrik Solgaard" . "henrik.solgaard@gmail.com"))
  :maintainers '(("Henrik Solgaard" . "henrik.solgaard@gmail.com")))
