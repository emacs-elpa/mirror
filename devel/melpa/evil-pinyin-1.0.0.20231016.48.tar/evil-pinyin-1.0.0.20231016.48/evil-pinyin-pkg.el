;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-pinyin" "1.0.0.20231016.48"
  "Evil search Chinese characters by pinyin."
  '((emacs "25")
    (names "0.5")
    (evil  "1"))
  :url "https://github.com/laishulu/evil-pinyin"
  :commit "0fae5ad8761417f027b33230382a50f826ad3bfb"
  :revdesc "0fae5ad87614"
  :keywords '("extensions"))
