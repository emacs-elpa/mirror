;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jg-quicknav" "1.4.0.0.20170809.8"
  "Quickly navigate the file system to find a file."
  '((s      "1.9.0")
    (cl-lib "0.5"))
  :url "https://github.com/jeffgran/jg-quicknav"
  :commit "c8d53e774d63e68a944092c08a026b57da741038"
  :revdesc "c8d53e774d63"
  :keywords '("navigation")
  :authors '(("Jeff Gran" . "jeff@jeffgran.com"))
  :maintainers '(("Jeff Gran" . "jeff@jeffgran.com")))
