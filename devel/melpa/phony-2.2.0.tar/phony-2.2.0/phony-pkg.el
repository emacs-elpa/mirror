;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phony" "2.2.0"
  "Define voice commands."
  '((emacs      "29.1")
    (simulacrum "2.0.0"))
  :url "https://github.com/ErikPrantare/phony.el"
  :commit "3a4625225fd710d31d9e90affcd77a7325864365"
  :revdesc "3a4625225fd7"
  :keywords '("files")
  :authors '(("Erik Präntare" . "erik@prantare.xyz"))
  :maintainers '(("Erik Präntare" . "erik@prantare.xyz")))
