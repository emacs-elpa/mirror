;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "1.0.0.20261005.245"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "3b63e3bfc348037c3d244cd235370e93105e0fd0"
  :revdesc "3b63e3bfc348"
  :keywords '("convenience" "text"))
