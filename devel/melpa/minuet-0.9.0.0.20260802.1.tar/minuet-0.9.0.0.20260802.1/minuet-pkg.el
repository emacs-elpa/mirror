;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "0.9.0.0.20260802.1"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "eb1cae8f8ce8d640a558bdf1a663d195b357b8f4"
  :revdesc "v0.9.0-1-geb1cae8f8ce8"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
