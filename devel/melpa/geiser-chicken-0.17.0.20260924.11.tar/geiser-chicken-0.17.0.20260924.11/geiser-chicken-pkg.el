;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-chicken" "0.17.0.20260924.11"
  "Chicken's implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.19"))
  :url "https://gitlab.com/emacs-geiser/chicken"
  :commit "74610c900b671dd40c1bd7114c991781e0621102"
  :revdesc "74610c900b67"
  :keywords '("languages" "chicken" "scheme" "geiser"))
