;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "caddyfile-mode" "0.2.0.20220626.10"
  "Major mode for Caddy configuration files."
  '((emacs "25")
    (loop  "1.3"))
  :url "https://github.com/Schnouki/caddyfile-mode/"
  :commit "fc41148f5a7eb320f070666f046fb9d88cf17680"
  :revdesc "v0.2-10-gfc41148f5a7e"
  :keywords '("languages")
  :authors '(("Thomas Jost" . "schnouki@schnouki.net"))
  :maintainers '(("Thomas Jost" . "schnouki@schnouki.net")))
