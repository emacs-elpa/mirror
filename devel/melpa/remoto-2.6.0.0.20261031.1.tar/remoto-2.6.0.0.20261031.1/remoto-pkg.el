;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "2.6.0.0.20261031.1"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "788417b9bc2a6b706663479138961e65b8ef5e4c"
  :revdesc "2.6.0-1-g788417b9bc2a"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
