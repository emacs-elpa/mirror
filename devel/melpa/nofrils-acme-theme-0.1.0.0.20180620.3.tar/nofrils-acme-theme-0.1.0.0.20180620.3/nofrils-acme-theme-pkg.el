;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nofrils-acme-theme" "0.1.0.0.20180620.3"
  "Port of \"No Frils Acme\" Vim theme."
  '((emacs "24"))
  :url "https://gitlab.com/esessoms/nofrils-theme"
  :commit "98ad7bfaff1d85b33dc162645670285b067c6f92"
  :revdesc "0.1.0-3-g98ad7bfaff1d"
  :authors '(("Eric Sessoms" . "esessoms@protonmail.com"))
  :maintainers '(("Eric Sessoms" . "esessoms@protonmail.com")))
