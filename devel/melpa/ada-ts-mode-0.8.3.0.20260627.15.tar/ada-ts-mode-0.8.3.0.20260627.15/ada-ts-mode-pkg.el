;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ada-ts-mode" "0.8.3.0.20260627.15"
  "Major mode for Ada using Tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/brownts/ada-ts-mode"
  :commit "32fcf68dba7463902481b256cdecad08e4b5b0a7"
  :revdesc "32fcf68dba74"
  :keywords '("ada" "languages" "tree-sitter")
  :authors '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainers '(("Troy Brown" . "brownts@troybrown.dev")))
