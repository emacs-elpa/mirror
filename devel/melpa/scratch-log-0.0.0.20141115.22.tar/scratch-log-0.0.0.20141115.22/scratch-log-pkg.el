;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-log" "0.0.0.20141115.22"
  "Utility for *scratch* buffer."
  ()
  :url "https://github.com/mori-dev/scratch-log"
  :commit "1168f7f16d36ca0f4ddf2bb98881f8db62cc5dc0"
  :revdesc "1168f7f16d36"
  :authors '(("kmori" . "morihenotegami@gmail.com"))
  :maintainers '(("kmori" . "morihenotegami@gmail.com")))
