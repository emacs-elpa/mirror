;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-jedi" "1.2.2.0.20261102.5"
  "Lsp client plugin for Python Jedi Language Server."
  '((emacs    "25.1")
    (lsp-mode "6.0"))
  :url "https://github.com/fredcamps/lsp-jedi"
  :commit "3080c6a4568d7bdadee5269dcf83af6ab97c021e"
  :revdesc "3080c6a4568d"
  :keywords '("language-server" "tools" "python" "jedi" "ide")
  :authors '(("Fred Campos" . "fred.tecnologia@gmail.com")))
