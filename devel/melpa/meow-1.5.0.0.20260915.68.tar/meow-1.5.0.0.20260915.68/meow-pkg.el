;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "1.5.0.0.20260915.68"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://www.github.com/DogLooksGood/meow"
  :commit "8aebed9f8cd8d865501b780e63acbeef55da231b"
  :revdesc "8aebed9f8cd8"
  :keywords '("convenience" "modal-editing"))
