;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-phpcs" "1.1"
  "Making flymake work with PHP CodeSniffer."
  '((flymake-easy "0.9"))
  :url "https://github.com/senda-akiha/flymake-phpcs/"
  :commit "f947ba3066c1fa903d2ec69d67bf84413f51eb3f"
  :revdesc "f947ba3066c1"
  :keywords '("flymake" "phpcs" "php"))
