;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fontsloth" "0.20.0.0.20261108.38"
  "Elisp otf/ttf font loader/renderer."
  '((async  "1.9.7")
    (f      "0.20.0")
    (logito "0.1")
    (pcache "0.5")
    (emacs  "28.1"))
  :url "https://github.com/jollm/fontsloth"
  :commit "f77dec891f04d5d2f30671a9f81bb5b68d2f08f4"
  :revdesc "v0.20.0-38-gf77dec891f04"
  :keywords '("data" "font" "rasterization" "ttf" "otf")
  :authors '(("Jo Gay" . "jo.gay@mailfence.com"))
  :maintainers '(("Jo Gay" . "jo.gay@mailfence.com")))
