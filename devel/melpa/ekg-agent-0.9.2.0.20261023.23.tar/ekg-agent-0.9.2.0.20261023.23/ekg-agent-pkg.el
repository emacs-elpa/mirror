;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "0.9.2.0.20261023.23"
  "Agentic actions for ekg."
  '((emacs "28.1")
    (ekg   "0.10.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "b3a58d7a524b6e20537335d6a0a4e2aec9200911"
  :revdesc "b3a58d7a524b"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
