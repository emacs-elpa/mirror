;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plaster" "1.0.0.20250821.35"
  "Pasting to a plaster host with buffers."
  '((emacs "24.3"))
  :url "https://shirakumo.org/docs/plaster/"
  :commit "9d77d89aef9ea438e4e0a144256f0ccbe3072a7c"
  :revdesc "9d77d89aef9e"
  :keywords '("convenience" "paste service")
  :authors '(("Yukari Hafner" . "shinmera@tymoon.eu"))
  :maintainers '(("Yukari Hafner" . "shinmera@tymoon.eu")))
