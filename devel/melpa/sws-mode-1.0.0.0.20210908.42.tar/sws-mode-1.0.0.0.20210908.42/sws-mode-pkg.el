;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sws-mode" "1.0.0.0.20210908.42"
  "(S)ignificant (W)hite(S)pace mode."
  ()
  :url "https://github.com/brianc/jade-mode"
  :commit "111460b056838854e470a6383041a99f843b93ee"
  :revdesc "v1.0.0-42-g111460b05683"
  :keywords '("languages"))
