;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inhibit-mouse" "1.0.4.0.20260906.9"
  "Deactivate mouse input (alternative to disable-mouse)."
  '((emacs "24.1"))
  :url "https://github.com/jamescherti/inhibit-mouse.el"
  :commit "0fa6082b4da1de468a014f9fd1a46165dca5fc5f"
  :revdesc "1.0.4-9-g0fa6082b4da1"
  :keywords '("convenience" "mouse")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
