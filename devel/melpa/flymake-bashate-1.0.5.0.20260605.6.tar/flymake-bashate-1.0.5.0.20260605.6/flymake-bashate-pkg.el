;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-bashate" "1.0.5.0.20260605.6"
  "A Flymake backend for bashate, a Bash scripts style checker."
  '((flymake-quickdef "1.0.0")
    (emacs            "27.1"))
  :url "https://github.com/jamescherti/flymake-bashate.el"
  :commit "e36eab741444112bcc1a0cd95b7eb878b82e31da"
  :revdesc "1.0.5-6-ge36eab741444"
  :keywords '("tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
