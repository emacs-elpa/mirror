;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-transient" "1.2.2"
  "Command dispatchers for Notmuch."
  '((emacs     "29.1")
    (compat    "31.0")
    (notmuch   "0.39")
    (transient "0.13"))
  :url "https://github.com/tarsius/notmuch-transient"
  :commit "e60942fce3cb1f6a11533500c670ca4ac22186e5"
  :revdesc "v1.2.2-0-ge60942fce3cb"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev")))
