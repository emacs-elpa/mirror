;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab" "3.9.0.0.20260804.3"
  "An interface for GitLab."
  '((emacs       "27.1")
    (request     "0.3.2")
    (s           "1.10.0")
    (f           "0.20.0")
    (compat      "29.1.4.4")
    (promise     "1.1")
    (async-await "1.1"))
  :url "https://github.com/isamert/lab.el"
  :commit "bde40714ebdf896d497dd0ebc8db6fc365c97f0c"
  :revdesc "v3.9.0-3-gbde40714ebdf"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
