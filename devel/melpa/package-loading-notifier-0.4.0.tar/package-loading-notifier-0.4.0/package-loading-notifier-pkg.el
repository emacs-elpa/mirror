;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-loading-notifier" "0.4.0"
  "Notify a package is being loaded."
  '((emacs "25.1"))
  :url "https://github.com/tttuuu888/package-loading-notifier"
  :commit "4090fe019de5b35fa316cbdd9c6673cf977461f7"
  :revdesc "4090fe019de5"
  :keywords '("convenience" "faces" "config" "startup")
  :authors '(("SeungKi Kim" . "tttuuu888@gmail.com"))
  :maintainers '(("SeungKi Kim" . "tttuuu888@gmail.com")))
