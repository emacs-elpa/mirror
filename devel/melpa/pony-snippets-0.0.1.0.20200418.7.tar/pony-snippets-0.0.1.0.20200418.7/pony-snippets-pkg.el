;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pony-snippets" "0.0.1.0.20200418.7"
  "Yasnippets for Pony."
  '((yasnippet "0.8.0"))
  :url "https://github.com/seantallen/pony-snippets"
  :commit "115a0d5066f89554bee9cb1045bcda5a18ebd441"
  :revdesc "115a0d5066f8"
  :keywords '("snippets" "pony"))
