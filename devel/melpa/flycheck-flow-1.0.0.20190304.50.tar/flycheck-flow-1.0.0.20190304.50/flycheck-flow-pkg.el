;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-flow" "1.0.0.20190304.50"
  "Support Flow in flycheck."
  '((flycheck "0.18")
    (json     "1.4"))
  :url "https://github.com/lbolla/emacs-flycheck-flow"
  :commit "9e8e52cfc98af6a23fd906f9cb5d5d470d8cf82d"
  :revdesc "9e8e52cfc98a"
  :authors '(("Lorenzo Bolla" . "lbolla@gmail.com"))
  :maintainers '(("Lorenzo Bolla" . "lbolla@gmail.com")))
