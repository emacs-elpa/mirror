;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xwwp-follow-link-helm" "0.1.0.20200917.12"
  "Link navigation in `xwidget-webkit' sessions using `helm'."
  '((emacs "26.1")
    (xwwp  "0.1"))
  :url "https://github.com/canatella/xwwp"
  :commit "99670ec37e2083eada9691a342441d2fa4589002"
  :revdesc "99670ec37e20"
  :keywords '("convenience"))
