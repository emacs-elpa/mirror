;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ca65-mode" "0.3.3"
  "Major mode for ca65 assembly files."
  '((emacs "26.1"))
  :url "https://github.com/wendelscardua/ca65-mode"
  :commit "590d90cc0e1c1864dd7ce03df99b741ba866d52a"
  :revdesc "590d90cc0e1c"
  :keywords '("languages" "assembly" "ca65" "6502")
  :authors '(("Wendel Scardua" . "wendel@scardua.net"))
  :maintainers '(("Wendel Scardua" . "wendel@scardua.net")))
