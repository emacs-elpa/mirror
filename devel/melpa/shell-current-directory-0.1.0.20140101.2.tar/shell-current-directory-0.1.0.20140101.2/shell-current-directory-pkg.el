;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-current-directory" "0.1.0.20140101.2"
  "Create new shell based on buffer directory."
  ()
  :url "https://github.com/metaperl/shell-current-directory"
  :commit "bf843771bf9a4aa05e054ade799eb8862f3be89a"
  :revdesc "bf843771bf9a"
  :keywords '("shell" "comint"))
