;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "etherpad" "0.1.0.20230530.25"
  "Interface to the Etherpad API."
  '((emacs     "27.1")
    (request   "0.3")
    (let-alist "0.0")
    (websocket "1.12")
    (parsec    "0.1")
    (0xc       "0.1"))
  :url "https://github.com/zzkt/ethermacs"
  :commit "29409bf9ff05b74d942c1cd7a421eeec2ef96e49"
  :revdesc "29409bf9ff05"
  :keywords '("comm" "etherpad" "collaborative editing")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
