;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-zap" "0.1.4.0.20190801.8"
  "Zap to char using `avy'."
  '((avy "0.2.0"))
  :url "https://github.com/cute-jumper/avy-zap"
  :commit "7c8d1f40e43d03e2f6c1696bfa547526528ce8cb"
  :revdesc "7c8d1f40e43d"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
