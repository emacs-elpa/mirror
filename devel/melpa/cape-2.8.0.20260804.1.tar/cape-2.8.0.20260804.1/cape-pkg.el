;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "2.8.0.20260804.1"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/cape"
  :commit "96c26eb54ef27c404554272489b8f9d78f113a2b"
  :revdesc "2.8-1-g96c26eb54ef2"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
