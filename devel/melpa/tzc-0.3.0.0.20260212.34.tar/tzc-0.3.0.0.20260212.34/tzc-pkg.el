;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tzc" "0.3.0.0.20260212.34"
  "Converts time between different time zones."
  '((emacs "28.1"))
  :url "https://github.com/md-arif-shaikh/tzc"
  :commit "05f97298e7b20aefb41c16abe3eeae162dd1e2f9"
  :revdesc "05f97298e7b2"
  :keywords '("convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
