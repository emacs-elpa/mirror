;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winring" "6.0"
  "Window configuration rings."
  ()
  :url "https://gitlab.com/warsaw/winring"
  :commit "286bd61536396e262295a442b7a5ed49cbcc81d9"
  :revdesc "286bd6153639"
  :keywords '("frames" "tools"))
