;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yafolding" "0.4.2"
  "Folding code blocks based on indentation."
  '((emacs "28.1"))
  :url "https://github.com/emacsorphanage/yafolding"
  :commit "77d36147a07d82a558788b180e4f0a983a3ed906"
  :revdesc "v0.4.2-0-g77d36147a07d"
  :keywords '("folding")
  :authors '(("Zeno Zeng" . "zenoofzeng@gmail.com"))
  :maintainers '(("Zeno Zeng" . "zenoofzeng@gmail.com")))
