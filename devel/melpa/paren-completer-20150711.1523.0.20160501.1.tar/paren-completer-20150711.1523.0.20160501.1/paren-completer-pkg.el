;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paren-completer" "20150711.1523.0.20160501.1"
  "Automatically, language agnostically, fill in delimiters."
  '((emacs "24.3"))
  :url "https://github.com/MatthewBregg/paren-completer"
  :commit "74183a8e13fa1266271bdcbcb4bfb29a4f915f0a"
  :revdesc "74183a8e13fa"
  :keywords '("convenience"))
