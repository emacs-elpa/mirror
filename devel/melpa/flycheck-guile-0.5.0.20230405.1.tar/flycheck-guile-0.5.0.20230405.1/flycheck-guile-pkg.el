;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-guile" "0.5.0.20230405.1"
  "A Flycheck checker for GNU Guile."
  '((emacs    "25.1")
    (flycheck "0.22")
    (geiser   "0.20"))
  :url "https://notabug.org/flatwhatson/flycheck-guile"
  :commit "dd7bbdc48fd21cf8d270c913c56cd580f8ec3d03"
  :revdesc "dd7bbdc48fd2"
  :authors '(("Ricardo Wurmus" . "rekado@elephly.net"))
  :maintainers '(("Andrew Whatson" . "whatson@tailcall.au")))
