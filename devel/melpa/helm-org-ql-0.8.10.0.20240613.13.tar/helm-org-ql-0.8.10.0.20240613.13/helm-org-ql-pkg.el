;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-org-ql" "0.8.10.0.20240613.13"
  "Helm support for org-ql."
  '((emacs    "26.1")
    (compat   "29.1.4.5")
    (dash     "2.18.1")
    (s        "1.12.0")
    (helm-org "1.0")
    (org-ql   "0.6-pre"))
  :url "https://github.com/alphapapa/org-ql"
  :commit "f7c3a61e32e8da62da1e69a2a79ec5b333a7d1f5"
  :revdesc "f7c3a61e32e8"
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
