;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.44.0.0.20260714.4"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f00d73563524dec28c458b1b22eb1b7ae721e822"
  :revdesc "f00d73563524"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
