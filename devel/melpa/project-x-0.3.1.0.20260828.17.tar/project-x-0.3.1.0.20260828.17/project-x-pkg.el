;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-x" "0.3.1.0.20260828.17"
  "Extra convenience features for project.el."
  '((emacs "28.1"))
  :url "https://github.com/vmargb/project-x"
  :commit "20c30a0fec47035b47a4e2222edf81810d06fd9d"
  :revdesc "20c30a0fec47"
  :keywords '("project" "convenience" "session" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("vmargb" . "https://github.com/vmargb")))
