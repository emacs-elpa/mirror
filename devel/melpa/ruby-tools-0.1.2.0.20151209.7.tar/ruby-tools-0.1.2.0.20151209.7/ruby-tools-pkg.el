;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-tools" "0.1.2.0.20151209.7"
  "Collection of handy functions for ruby-mode."
  ()
  :url "https://github.com/rejeep/ruby-tools"
  :commit "6b97066b58a4f82eb2ecea6434a0a7e981aa4c18"
  :revdesc "6b97066b58a4"
  :keywords '("speed" "convenience" "ruby")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
