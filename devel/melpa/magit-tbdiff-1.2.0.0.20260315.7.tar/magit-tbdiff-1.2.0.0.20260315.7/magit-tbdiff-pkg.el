;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-tbdiff" "1.2.0.0.20260315.7"
  "Magit extension for range diffs."
  '((emacs "26.1")
    (magit "4.0.0"))
  :url "https://github.com/magit/magit-tbdiff"
  :commit "e7391536e23a0d6d28cc4b153db3f446a51da8b7"
  :revdesc "v1.2.0-7-ge7391536e23a"
  :keywords '("vc" "tools")
  :authors '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainers '(("Kyle Meyer" . "kyle@kyleam.com")))
