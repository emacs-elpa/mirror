;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reddigg" "0.7.0"
  "A reader for redditt."
  '((emacs   "26.3")
    (promise "1.1")
    (ht      "2.3")
    (org     "9.2"))
  :url "https://github.com/thanhvg/emacs-reddigg"
  :commit "07e0e1fcf72df49f481ccc535fa55531fcb05658"
  :revdesc "07e0e1fcf72d"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
