;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "k8s-mode" "0.2.0.0.20250408.5"
  "Major mode for Kubernetes configuration file."
  '((emacs     "24.3")
    (yaml-mode "0.0.10"))
  :url "https://github.com/TxGVNN/emacs-k8s-mode"
  :commit "39a189d1e030aa108e90a82fd40f0042b1e69b21"
  :revdesc "39a189d1e030"
  :authors '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers '(("Giap Tran" . "txgvnn@gmail.com")))
