;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-ocaml" "0.4.2.0.20260810.8"
  "Flycheck: OCaml support."
  '((emacs     "24.3")
    (flycheck  "32")
    (merlin    "3.0.1")
    (let-alist "1.0.3"))
  :url "https://github.com/flycheck/flycheck-ocaml"
  :commit "e302792ba72ad57b262e1ab79799960d49a4278d"
  :revdesc "e302792ba72a"
  :keywords '("convenience" "tools" "languages" "ocaml")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
