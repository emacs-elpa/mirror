;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.49.0.0.20260806.9"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5a60bc10fbb716fb37eb212c1764107015b59176"
  :revdesc "5a60bc10fbb7"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
