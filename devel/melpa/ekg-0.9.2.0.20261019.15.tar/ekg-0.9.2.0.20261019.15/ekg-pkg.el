;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.2.0.20261019.15"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "29.1")
    (llm     "0.30.0")
    (vui     "20261017.1157"))
  :url "https://github.com/ahyatt/ekg"
  :commit "64103fb03b925fc2f1821dd3623f3d0b2cdd8182"
  :revdesc "64103fb03b92"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
