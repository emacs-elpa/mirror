;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elscreen-multi-term" "0.1.3.0.20200417.4"
  "Multi term for elscreen."
  '((emacs      "24.4")
    (elscreen   "1.4.6")
    (multi-term "1.3"))
  :url "https://github.com/wamei/elscreen-multi-term"
  :commit "4ea89bae0444d9d4377515929f76cb3e98140f1f"
  :revdesc "4ea89bae0444"
  :keywords '("elscreen" "multi term")
  :authors '(("wamei" . "wamei.cho@gmail.com"))
  :maintainers '(("wamei" . "wamei.cho@gmail.com")))
