;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.83.4"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6cb9d9adc9f002a363353303047fab33d920db56"
  :revdesc "6cb9d9adc9f0")
