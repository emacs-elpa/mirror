;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tfl" "0.4.0"
  "Transport for London meets Orgmode."
  '((org    "0.16.2")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/storax/org-tfl"
  :commit "f0d7d39106a1de5457f5160cddd98ab892b61066"
  :revdesc "0.4.0-0-gf0d7d39106a1"
  :keywords '("org" "tfl")
  :authors '((nil . "zuber[dot]david[at]gmx[dot]de"))
  :maintainers '((nil . "zuber[dot]david[at]gmx[dot]de")))
