;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lentic" "0.11.0.20240303.43"
  "One buffer as a view of another."
  '((emacs    "25")
    (m-buffer "0.13")
    (dash     "2.5.0"))
  :url "https://github.com/phillord/lentic"
  :commit "180c1082c016de790f9e6596b63329657c83ce20"
  :revdesc "180c1082c016"
  :authors '(("Phillip Lord" . "phillip.lord@russet.org.uk"))
  :maintainers '(("Phillip Lord" . "phillip.lord@russet.org.uk")))
