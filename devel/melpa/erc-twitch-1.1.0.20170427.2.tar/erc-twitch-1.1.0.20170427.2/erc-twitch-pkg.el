;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-twitch" "1.1.0.20170427.2"
  "Support for Twitch emotes for ERC."
  '((json "1.3")
    (erc  "5.0"))
  :url "https://github.com/vibhavp/erc-twitch"
  :commit "53c6af0cb72e56d897d30a40e7e5066668d6b5ec"
  :revdesc "53c6af0cb72e"
  :keywords '("twitch" "erc" "emotes")
  :authors '(("Vibhav Pant" . "vibhavp@gmail.com"))
  :maintainers '(("Vibhav Pant" . "vibhavp@gmail.com")))
