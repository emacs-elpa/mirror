;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "4.0.7.0.20260719.26"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "c6b3e31a5ed90bb93a7084793bc7ea82f33f6938"
  :revdesc "v4.0.7-26-gc6b3e31a5ed9"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
