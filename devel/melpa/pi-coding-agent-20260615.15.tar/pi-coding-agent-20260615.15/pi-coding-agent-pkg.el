;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260615.15"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (md-ts-mode          "0.3.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "52a15168d18ec083428eb361d25e23e8e1d9b50a"
  :revdesc "52a15168d18e"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
