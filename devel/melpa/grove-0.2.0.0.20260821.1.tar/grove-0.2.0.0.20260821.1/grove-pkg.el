;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grove" "0.2.0.0.20260821.1"
  "Obsidian-like note-taking for org files."
  '((emacs "29.1"))
  :url "https://github.com/jonathanchu/grove"
  :commit "b396cf6a19f804d1cc71bdd2a2229a6ca63abd2d"
  :revdesc "b396cf6a19f8"
  :keywords '("notes" "outlines" "tools")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
