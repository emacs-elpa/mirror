;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "4.0.1.0.20260630.68"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "2d657ba7b8803576d868aca85028ab4a664129f6"
  :revdesc "2d657ba7b880"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
