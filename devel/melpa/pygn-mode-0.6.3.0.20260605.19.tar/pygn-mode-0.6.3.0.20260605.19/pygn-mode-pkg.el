;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pygn-mode" "0.6.3.0.20260605.19"
  "Major-mode for chess PGN files, powered by Python."
  '((emacs             "27.1")
    (tree-sitter       "0.18.0")
    (tree-sitter-langs "0.12.242")
    (uci-mode          "0.5.4")
    (nav-flash         "1.0.0")
    (ivy               "0.10.0"))
  :url "https://github.com/dwcoates/pygn-mode"
  :commit "6eed5ea66d37ae25c4db98ca21b164a98234b59e"
  :revdesc "v0.6.3-19-g6eed5ea66d37"
  :keywords '("data" "games" "chess"))
