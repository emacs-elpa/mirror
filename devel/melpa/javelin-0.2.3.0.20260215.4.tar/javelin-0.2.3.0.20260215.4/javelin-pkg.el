;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "javelin" "0.2.3.0.20260215.4"
  "Implementation of harpoon: bookmarks on steroids."
  '((emacs "28.1"))
  :url "https://github.com/DamianB-BitFlipper/javelin.el"
  :commit "e2f1ccad5a7ad0dd38f62773723353081d57bae8"
  :revdesc "e2f1ccad5a7a"
  :keywords '("tools" "languages"))
