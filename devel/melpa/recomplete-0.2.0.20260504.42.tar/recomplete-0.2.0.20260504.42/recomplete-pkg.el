;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recomplete" "0.2.0.20260504.42"
  "Immediately (re)complete actions."
  '((emacs             "29.1")
    (with-command-redo "0.1"))
  :url "https://codeberg.org/ideasman42/emacs-recomplete"
  :commit "d8e2b35a65910fee40cebee39153c1e6bc462cc1"
  :revdesc "d8e2b35a6591"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
