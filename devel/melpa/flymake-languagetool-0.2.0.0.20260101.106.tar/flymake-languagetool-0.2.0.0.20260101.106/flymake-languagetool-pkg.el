;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-languagetool" "0.2.0.0.20260101.106"
  "Flymake support for LanguageTool."
  '((emacs  "27.1")
    (compat "29.1.4.4"))
  :url "https://github.com/emacs-languagetool/flymake-languagetool"
  :commit "2fcba271ab1b8fc301812615a8c072c108ad96b3"
  :revdesc "2fcba271ab1b"
  :keywords '("convenience" "grammar" "check")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com")
             ("Trey Peacock" . "git@treypeacock.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Trey Peacock" . "git@treypeacock.com")))
