;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambdapi-mode" "3.0.0.0.20260701.109"
  "A major mode for editing Lambdapi source code."
  '((emacs             "27.1")
    (eglot             "1.6")
    (math-symbol-lists "1.2.1")
    (highlight         "20190710.1527"))
  :url "https://github.com/Deducteam/lambdapi"
  :commit "d4fcaa80d2ac820be9928e4c75a6a0ad723d2c30"
  :revdesc "3.0.0-109-gd4fcaa80d2ac"
  :keywords '("languages")
  :maintainers '(("Deducteam" . "dedukti-dev@inria.fr")))
