;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "protobuf-mode" "36.2"
  "Major mode for editing protocol buffers."
  ()
  :url "https://github.com/protocolbuffers/protobuf"
  :commit "2c74169b34066ceb8ddb6b882fcb3fb32d737a55"
  :revdesc "v36.2-0-g2c74169b3406"
  :keywords '("google" "protobuf" "languages")
  :authors '(("Alexandre Vassalotti" . "alexandre@peadrop.com"))
  :maintainers '(("Alexandre Vassalotti" . "alexandre@peadrop.com")))
