;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frameshot" "1.2.2.0.20260925.3"
  "Take screenshots of a frame."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/frameshot"
  :commit "19eb7525a1fe556bf2e6f40656b76f2abdb4e095"
  :revdesc "v1.2.2-3-g19eb7525a1fe"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev")))
