;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-color-stamp" "0.1.0.20130529.4"
  "Edit a hex color stamp, using a QT or the internal color picker."
  '((es-lib "0.2")
    (cl-lib "1.0"))
  :url "https://github.com/sabof/edit-color-stamp"
  :commit "32dc1ca5bcf3dcf83fad5e39b55dc5b77becb3d3"
  :revdesc "32dc1ca5bcf3")
