;;; org-auto-export-pandoc.el --- Add org auto export with pandoc  -*- lexical-binding: t; -*-

;; Copyright (C) 2010-2021 Yonggan also known as y0ngg4n


;; Author: Yonggan <yonggan@obco.pro>
;; Maintainer: Yonggan <yonggan@obco.pro>
;; Created: 05.10.2024

;; Keywords: convenience
;; URL: https://github.com/Y0ngg4n/org-auto-export-pandoc.git
;; Package-Version: 0.0.1.0.20241026.7
;; Package-Revision: 4c63da7ed3c6
;; SPDX-License-Identifier: GPL-3.0-only
;; This file is not part of GNU Emacs.

;; Package-Requires: ((ox-pandoc "2.0") (emacs "24.1"))

;;; Commentary:
;; This package provides the functionality to automatically export
;; with org-pandoc-export-* modes.
;; Add this hook if you want to execute it on save:
;; (add-hook 'after-save-hook 'org-auto-export-pandoc)
;; It adds a hook to exute it when you save the file. It will look
;; for the following tag:
;; #+auto-export-pandoc: to-markdown
;; You can add the tag muliple times to export to multiple formats:
;; #+auto-export-pandoc: to-markdown
;; #+auto-export-pandoc: to-latex-pdf
;; #+auto-export-pandoc: to-html5

(require 'ox-pandoc)



;;; Code:

(defun org-auto-export-pandoc ()
  "Exports to the predefined formats in your \"org-mode\" file via pandoc."
  (interactive)
  (when (derived-mode-p 'org-mode)  ;; Check if we are in org-mode
    (save-excursion
      (goto-char (point-min))  ;; Go to the beginning of the buffer
      (while (re-search-forward "^#\\+auto-export-pandoc: \\(.*\\)$" nil t)
        (let ((export-format (match-string 1))) ;;
          (funcall (intern (concat "org-pandoc-export-" export-format))))))))


(provide 'org-auto-export-pandoc)

;;; org-auto-export-pandoc.el ends here
