;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cljr-ivy" "0.1.0.20200602.7"
  "Access clojure refactor with ivy completion."
  '((clj-refactor "2.5.0")
    (ivy          "0.13.0")
    (emacs        "24.3")
    (cl-lib       "0.6.1"))
  :url "https://github.com/wandersoncferreira/cljr-ivy"
  :commit "18e6e3526e872010a643c91aa71ff1d429431b83"
  :revdesc "18e6e3526e87"
  :keywords '("convenience" "matching")
  :authors '(("Wanderson Ferreira" . "iagwanderson@gmail.com"))
  :maintainers '(("Wanderson Ferreira" . "iagwanderson@gmail.com")))
