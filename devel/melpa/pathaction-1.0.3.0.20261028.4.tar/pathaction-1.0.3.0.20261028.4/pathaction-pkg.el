;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "1.0.3.0.20261028.4"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "0bee2e0184a5e6de9d00dc2845235a67fbacd379"
  :revdesc "1.0.3-4-g0bee2e0184a5"
  :keywords '("tools" "processes" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
