;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "1.9.0"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://codeberg.org/mclear-tools/tabspaces"
  :commit "33f224f38ff354f83f7d9c0a9f3c5b8bf888d9d6"
  :revdesc "33f224f38ff3"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
