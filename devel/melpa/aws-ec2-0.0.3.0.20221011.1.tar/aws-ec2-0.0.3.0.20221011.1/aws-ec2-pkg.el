;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aws-ec2" "0.0.3.0.20221011.1"
  "Manage AWS EC2 instances."
  '((emacs "24.4")
    (dash  "2.12.1")
    (tblui "0.1.0"))
  :url "https://github.com/Yuki-Inoue/aws.el"
  :commit "7b500097ac3c2addbe1644f78595dc2ea4eb87c4"
  :revdesc "7b500097ac3c"
  :authors '(("Yuki Inoue" . "inouetakahiroki_at_gmail.com"))
  :maintainers '(("Yuki Inoue" . "inouetakahiroki_at_gmail.com")))
