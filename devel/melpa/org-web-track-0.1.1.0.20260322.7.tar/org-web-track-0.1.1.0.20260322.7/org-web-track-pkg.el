;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-web-track" "0.1.1.0.20260322.7"
  "Web data tracking framework in Org Mode."
  '((emacs   "29.1")
    (request "0.3.0")
    (enlive  "0.0.1")
    (gnuplot "0.8.1"))
  :url "https://github.com/p-snow/org-web-track"
  :commit "d61668bb9059da8c6d1e69ce980a14ca9da137dc"
  :revdesc "d61668bb9059"
  :keywords '("org" "agenda" "web" "hypermedia")
  :authors '(("p-snow" . "public@p-snow.org"))
  :maintainers '(("p-snow" . "public@p-snow.org")))
