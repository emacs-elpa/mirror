;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hotfuzz" "1.0"
  "Fuzzy completion style."
  '((emacs "27.1"))
  :url "https://github.com/axelf4/hotfuzz"
  :commit "cb0ce382d98cbc35ea55f4533b3c321119ed18b7"
  :revdesc "cb0ce382d98c"
  :keywords '("matching")
  :authors '(("Axel Forsman" . "axel@axelf.se"))
  :maintainers '(("Axel Forsman" . "axel@axelf.se")))
