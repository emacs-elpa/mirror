;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "1.0.8"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "092ae42ac385ff611bf79437b8e2d430e855d4f5"
  :revdesc "1.0.8-0-g092ae42ac385"
  :keywords '("convenience" "files" "tools"))
