;;; quick-fasd.el --- Integration for the command-line tool `fasd' -*- lexical-binding: t; -*-

;; Copyright (C) 2024-2026 James Cherti
;; Copyright (C) 2013-2021 steckerhalter

;; Maintainer: James Cherti
;; Original Author: steckerhalter
;; Package-Version: 1.0.8
;; Package-Revision: 1.0.8-0-g092ae42ac385
;; URL: https://github.com/jamescherti/quick-fasd.el
;; Keywords: convenience, files, tools
;; Package-Requires: ((emacs "26.1"))
;; SPDX-License-Identifier: GPL-3.0-or-later

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; The `quick-fasd' package integrates the `fasd' command-line utility into
;; Emacs. The `fasd' cli tracks frequently and recently accessed files and
;; directories, ranking them by frecency (frequency and recency). Instead of
;; navigating through directory hierarchies or typing full paths, `quick-fasd'
;; can quickly find previously accessed files and directories.
;;
;; The main advantage of `quick-fasd' is that it allows Emacs and the terminal
;; to share the same Fasd navigation history. For example, a directory
;; frequently visited from the terminal can be quickly accessed from Emacs, and
;; files opened in Emacs become available for navigation from the terminal.
;;
;; After enabling `quick-fasd-mode':
;;
;; - It automatically adds all visited files and directories to the local Fasd
;;   database.
;; - 'M-x quick-fasd-find-path' provides interactive prompts to filter and
;;   select candidates from the Fasd index. This allows you to open recent files
;;   and jump to frequent directories without leaving the editor.
;; - When called from the minibuffer, the `(quick-fasd-find-path)' function
;;   appends the selected path to the prompt for easier completion.
;;
;; URL: https://github.com/jamescherti/quick-fasd.el

;;; Code:

;;; Variables

(defgroup quick-fasd nil
  "Quickly accessing previously-visited files and directories using Fasd."
  :group 'convenience
  :prefix "quick-fasd-")

(defcustom quick-fasd-enable-initial-prompt nil
  "When non-nil, prompt the user for a query first.

When nil, return all fasd paths immediately for completion.

Setting this to nil is useful when using completion frameworks such as Consult,
Vertico, or Orderless, allowing them to handle filtering instead of fasd.
However, fetching all paths from fasd can be slower for large file databases and
may produce an overwhelming number of candidates."
  :type 'boolean
  :group 'quick-fasd)

;; TODO make this type function
(defcustom quick-fasd-file-manager 'find-file
  "Default file manager used by `quick-fasd-find-path-action'."
  :type '(radio
          (const
           :tag "find-file, the built-in function to edit files and directories"
           find-file)
          (const :tag "Dired, the default Emacs file manager" dired)
          (const :tag "Deer, Ranger's file manager" deer)
          (function :tag "Custom file manager function"))
  :group 'quick-fasd)

(defcustom quick-fasd-command-args '("-a")
  "List of flags passed to the fasd command.
This controls which types of entries are returned.

Available options:
  - `-a': Match files and directories
  - `-d': Match directories only
  - `-f': Match files only
  - `-r': Match by rank only
  - `-t': Match by recent access only

Multiple flags can be combined by adding them to the list. This allows
customizing the default behavior of `quick-fasd' searches."
  :type '(repeat string)
  :group 'quick-fasd)

(defcustom quick-fasd-executable-path "fasd"
  "Path to the Fasd executable or its command name (e.g., fasd)."
  :type 'string
  :group 'quick-fasd)

(defcustom quick-fasd-minibuffer-insert-path t
  "Control how `quick-fasd-find-path' behaves in the minibuffer.

If non-nil, the selected path is inserted directly into the minibuffer.
If nil, `quick-fasd-find-path' opens the directory instead of inserting the
path."
  :type 'boolean
  :group 'quick-fasd)

(defcustom quick-fasd-idle-delay 0.5
  "Idle delay in seconds before adding queued buffers to the Fasd database.
When set to 0 or nil, paths are added immediately without an idle timer."
  :type '(choice (number :tag "Idle delay in seconds")
                 (const :tag "Immediate (no delay)" nil))
  :group 'quick-fasd)

(defcustom quick-fasd-debug nil
  "When non-nil, display debug messages in the echo area for operations."
  :type 'boolean
  :group 'quick-fasd)

(defcustom quick-fasd-ignore-temporary-directories t
  "If non-nil, ignore files in standard Emacs temporary directories.
This checks against the variable `temporary-file-directory' and the TMPDIR
environment variable."
  :type 'boolean
  :group 'quick-fasd)

(defvar quick-fasd-mode-lighter " QFasd"
  "Default lighter string for `quick-fasd-mode'.")

(defcustom quick-fasd-ignore-directories '("\\`/run/")
  "List of regular expressions matching directories to ignore."
  :type '(repeat string)
  :group 'quick-fasd)

(defcustom quick-fasd-ignore-files '("\\.elc\\'")
  "List of regular expressions matching file names/extensions to ignore."
  :type '(repeat string)
  :group 'quick-fasd)

;;; Internal functions

(defvar quick-fasd--last-file nil
  "Tracks the most recently added file to prevent redundant fasd updates.")

(defvar quick-fasd--last-dir nil
  "Tracks the most recently added directory to prevent redundant fasd updates.")

(defvar quick-fasd--idle-timer nil
  "Timer used to defer adding paths to the Fasd database.")

(defvar quick-fasd--pending-buffers nil
  "List of buffers waiting to be added to the Fasd database.")

(defmacro quick-fasd--debug (format-str &rest args)
  "Display message using FORMAT-STR and ARGS if `quick-fasd-debug' is non-nil."
  `(when quick-fasd-debug
     (let ((inhibit-message t))
       (message (concat "[quick-fasd] " ,format-str) ,@args))))

(defun quick-fasd--get-fasd-executable-path ()
  "Return the path to the `fasd' executable or signal an error if not found."
  (let ((result (executable-find quick-fasd-executable-path)))
    (unless (and result
                 (file-regular-p result)
                 (file-executable-p result))
      (user-error "Fasd executable not found: %s" quick-fasd-executable-path))
    result))

(defun quick-fasd-find-path-action (file)
  "Open FILE with appropriate file manager or prompt if unreadable."
  (if (file-readable-p file)
      (if (file-directory-p file)
          (funcall quick-fasd-file-manager file)
        (find-file file))
    (user-error "[quick-fasd] No such file or directory %s" file)))

(defun quick-fasd--get-file (prefix query)
  "Use fasd to open a file or directory and return the selected path.
Signal a user error if no results are found.
Optionally pass QUERY to avoid prompt.
PREFIX is the same prefix as `quick-fasd-find-path'."
  (let* ((fasd-executable (quick-fasd--get-fasd-executable-path))
         (prefix-value (prefix-numeric-value prefix))
         (fasd-args (cond
                     ((= prefix-value -1) '("-f"))
                     ((= prefix-value 0) '("-d"))
                     (t quick-fasd-command-args))))
    (unless query
      (setq query (if quick-fasd-enable-initial-prompt
                      (read-from-minibuffer "Fasd: ")
                    "")))
    (let* ((prompt "Fasd: ")
           ;; Prepend "--" before QUERY so queries starting with "-" are not
           ;; parsed as command-line options by fasd, and default
           ;; `completing-read' to the first result while rejecting empty string
           ;; selections.
           (process-args (append '("-l" "-R")
                                 fasd-args
                                 (unless (string= query "")
                                   (list "--" query))))
           (results
            (let ((default-directory temporary-file-directory))
              (apply #'process-lines fasd-executable process-args)))
           ;; fasd -l -R already supplies the desired order. Create a completion
           ;; table that preserves fasd's native sorting and tells Emacs these
           ;; are file paths.
           (collection (lambda (string pred action)
                         (if (eq action 'metadata)
                             '(metadata (display-sort-function . identity)
                                        (cycle-sort-function . identity)
                                        (category . file))
                           (complete-with-action action results string pred))))
           (file (when results
                   (setq this-command 'quick-fasd-find-path)
                   (completing-read prompt collection nil t nil nil (car results)))))
      (if (and file (not (string= file "")))
          file
        (user-error "[quick-fasd] Fasd found nothing for: %S" query)))))

(defun quick-fasd--add-buffer-to-db (buffer)
  "Add the file or directory of BUFFER to the Fasd database."
  (when (buffer-live-p buffer)
    (with-current-buffer buffer
      (let* ((path (if (derived-mode-p 'dired-mode)
                       default-directory
                     (buffer-file-name (buffer-base-buffer)))))
        (when (and (stringp path)
                   (not (file-remote-p path)))
          ;; Standardize the path and ensure it is absolute
          (setq path (expand-file-name path))

          (if (quick-fasd--should-ignore-p path)
              (quick-fasd--debug "Ignored: %s" path)
            (let ((regular-file (file-regular-p path)))
              ;; File logic
              (when regular-file
                (unless (equal path quick-fasd--last-file)
                  (quick-fasd-add-path path)
                  (setq quick-fasd--last-file path)))

              ;; Directory logic
              (when (or regular-file (file-directory-p path))
                (let ((dir (if regular-file
                               (file-name-directory path)
                             (file-name-as-directory path))))
                  (when (and dir (not (equal dir quick-fasd--last-dir)))
                    (quick-fasd-add-path dir)
                    (setq quick-fasd--last-dir dir)))))))))))

(defun quick-fasd--cancel-timer ()
  "Cancel the `quick-fasd--idle-timer' timer."
  (when (timerp quick-fasd--idle-timer)
    (cancel-timer quick-fasd--idle-timer))
  (setq quick-fasd--idle-timer nil))

(defun quick-fasd--process-pending-buffers ()
  "Process all buffers queued in `quick-fasd--pending-buffers'."
  (quick-fasd--cancel-timer)
  (let ((buffers (nreverse quick-fasd--pending-buffers)))
    ;; Clear the global queue before processing starts
    (setq quick-fasd--pending-buffers nil)
    (dolist (buffer buffers)
      (condition-case err
          (quick-fasd--add-buffer-to-db buffer)
        (error
         (message "[quick-fasd] Error: %s"
                  (error-message-string err)))))))

(defun quick-fasd--hook-add-path-to-db ()
  "Add current file or directory to the Fasd database."
  (let ((buffer (current-buffer)))
    (if (and (numberp quick-fasd-idle-delay)
             (> quick-fasd-idle-delay 0))
        (progn
          (setq quick-fasd--pending-buffers
                (cons buffer (delq buffer quick-fasd--pending-buffers)))
          (quick-fasd--cancel-timer)
          (setq quick-fasd--idle-timer
                (run-with-idle-timer quick-fasd-idle-delay nil
                                     #'quick-fasd--process-pending-buffers)))
      (condition-case err
          (quick-fasd--add-buffer-to-db buffer)
        (error
         (message "[quick-fasd] Error: %s"
                  (error-message-string err)))))))

(defun quick-fasd--should-ignore-p (path)
  "Return non-nil if PATH should be ignored based on ignore lists."
  (if (and quick-fasd-ignore-temporary-directories
           (or (and temporary-file-directory
                    (file-in-directory-p path temporary-file-directory))
               (and (not (memq system-type '(windows-nt ms-dos)))
                    (or (file-in-directory-p path "/tmp/")
                        (file-in-directory-p path "/var/tmp/")
                        (let ((tmpdir (getenv "TMPDIR")))
                          (and tmpdir
                               (not (string= tmpdir ""))
                               (file-in-directory-p path tmpdir)))))))
      t
    (catch 'found
      (let* ((is-dir (file-directory-p path))
             (match-path (if is-dir (file-name-as-directory path) path)))
        (dolist (regexp quick-fasd-ignore-directories)
          (when (string-match-p regexp match-path)
            (throw 'found t)))
        (unless is-dir
          (let ((file-name (file-name-nondirectory path)))
            (dolist (regexp quick-fasd-ignore-files)
              (when (string-match-p regexp file-name)
                (throw 'found t))))))
      nil)))

;;; Functions

(defun quick-fasd-delete-path (path)
  "Delete PATH from the Fasd database."
  (when (stringp path)
    (let ((expanded-path (expand-file-name path))
          (fasd-executable (quick-fasd--get-fasd-executable-path))
          ;; Run the subprocess from the temporary directory so it can start
          ;; even if the buffer's working directory has been deleted.
          (default-directory temporary-file-directory))
      (let ((exit-code (call-process fasd-executable nil nil nil "-D"
                                     expanded-path)))
        (unless (equal exit-code 0)
          (error "[quick-fasd] Fasd failed to delete %s: %s"
                 expanded-path exit-code))
        (quick-fasd--debug "Deleted path: %s" expanded-path)))))

(defun quick-fasd-add-path (path &optional async)
  "Add PATH to the Fasd database.
If ASYNC is non-nil, add the path in the background."
  (when (stringp path)
    (let* ((expanded-path (expand-file-name path))
           (fasd-executable (quick-fasd--get-fasd-executable-path))
           (default-directory temporary-file-directory))
      (if async
          ;; Asynchronous execution
          (set-process-sentinel
           (start-process "*fasd*" nil fasd-executable "--add" expanded-path)
           (lambda (proc _event)
             (when (memq (process-status proc) '(exit signal))
               (if (and (eq (process-status proc) 'exit)
                        (zerop (process-exit-status proc)))
                   (quick-fasd--debug "Added path (async): %s" expanded-path)
                 (message "[quick-fasd] Fasd failed to add %s: %s"
                          expanded-path (process-exit-status proc))))))
        ;; Synchronous execution
        (let ((exit-code (call-process fasd-executable nil nil nil "--add"
                                       expanded-path)))
          (unless (equal exit-code 0)
            (error "[quick-fasd] Fasd failed to add %s: %s"
                   expanded-path exit-code))
          (quick-fasd--debug "Added path (sync): %s" expanded-path))))))

(defun quick-fasd--find-file-hook ()
  "Add existing files to fasd, or defer new files until their first save."
  (let ((path (buffer-file-name (buffer-base-buffer))))
    ;; Check `file-remote-p' before `file-exists-p' to avoid synchronous TRAMP
    ;; connections on remote buffers, and resolve base buffer for indirect
    ;; buffers.
    (when (and (stringp path) (not (file-remote-p path)))
      (if (not (file-exists-p path))
          ;; File does not exist yet. Attach a buffer-local after-save hook. The
          ;; 't' at the end makes this hook local to the current buffer.
          (add-hook 'after-save-hook #'quick-fasd--after-save-hook nil t)
        ;; File exists, add it to fasd immediately.
        (quick-fasd--hook-add-path-to-db)))))

(defun quick-fasd--after-save-hook ()
  "Add a newly saved file to fasd and remove this hook."
  ;; Remove the buffer-local hook so it never runs on subsequent saves and guard
  ;; execution with `quick-fasd-mode' so buffers saved after disabling the mode
  ;; do not update the database.
  (remove-hook 'after-save-hook #'quick-fasd--after-save-hook t)
  (when (bound-and-true-p quick-fasd-mode)
    (quick-fasd--hook-add-path-to-db)))

;;; Interactive functions

;;;###autoload
(defun quick-fasd-find-path (&optional prefix query)
  "Use fasd to open a file or directory.
Optionally pass QUERY to avoid prompt.
If PREFIX is 0 consider only directories.
If PREFIX is -1 consider only files.
Otherwise, use `quick-fasd-command-args', which by default lists both files and
directories."
  (interactive "P")
  (if (and quick-fasd-minibuffer-insert-path
           (minibufferp))
      (let* ((enable-recursive-minibuffers t)
             (file (quick-fasd--get-file prefix query)))
        (when file
          (when (file-directory-p file)
            (setq file (file-name-as-directory file)))
          (insert file)))
    (let ((file (quick-fasd--get-file prefix query)))
      (when file
        (quick-fasd-find-path-action file)))))

;;;###autoload
(defun quick-fasd-find-file (&optional query)
  "Use fasd to find and open a file.
Optionally pass QUERY to bypass the prompt."
  (interactive)
  (quick-fasd-find-path -1 query))

;;;###autoload
(defun quick-fasd-find-directory (&optional query)
  "Use fasd to find and open a directory.
Optionally pass QUERY to bypass the prompt."
  (interactive)
  (quick-fasd-find-path 0 query))

;;;###autoload
(define-minor-mode quick-fasd-mode
  "Integration for the command-line tool `fasd'."
  :global t
  :group 'quick-fasd
  :lighter quick-fasd-mode-lighter
  (if quick-fasd-mode
      (progn
        (add-hook 'find-file-hook #'quick-fasd--find-file-hook)
        (add-hook 'dired-mode-hook #'quick-fasd--hook-add-path-to-db))
    (quick-fasd--cancel-timer)
    (setq quick-fasd--pending-buffers nil
          quick-fasd--last-file nil
          quick-fasd--last-dir nil)
    (remove-hook 'find-file-hook #'quick-fasd--find-file-hook)
    (remove-hook 'dired-mode-hook #'quick-fasd--hook-add-path-to-db)
    ;; Clean up any buffer-local `after-save-hook' entries left on unsaved
    ;; buffers when disabling `quick-fasd-mode'.
    (dolist (buf (buffer-list))
      (with-current-buffer buf
        (remove-hook 'after-save-hook #'quick-fasd--after-save-hook t)))))

;;; Provide

(provide 'quick-fasd)

;;; quick-fasd.el ends here
