;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "0.5.2.0.20261107.33"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "d57ba8dec870d53778ab7f09b5a2295b9dafe7d1"
  :revdesc "d57ba8dec870"
  :keywords '("convenience" "gptel" "llm")
  :authors '(("Kevin Montag" . "https://github.com/kmontag"))
  :maintainers '(("Kevin Montag" . "https://github.com/kmontag")))
