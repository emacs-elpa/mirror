;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-spice" "0.3.0.0.20201013.2"
  "Extra spice for emacs lisp programming."
  ()
  :url "https://github.com/vedang/el-spice"
  :commit "a1adde201ee10881b522e67aa2c605378943a28d"
  :revdesc "0.3.0-2-ga1adde201ee1"
  :keywords '("languages" "extensions")
  :authors '(("Vedang Manerikar" . "vedang.manerikar@gmail.com"))
  :maintainers '(("Vedang Manerikar" . "vedang.manerikar@gmail.com")))
