;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "twilight-bright-theme" "0.1.0.0.20130605.11"
  "A Emacs 24 faces port of the TextMate theme."
  ()
  :url "https://github.com/jimeh/twilight-bright-theme.el"
  :commit "9859474333fee9f907474dbd8763f617e8bfd89c"
  :revdesc "9859474333fe"
  :keywords '("themes")
  :authors '(("Jim Myhrberg" . "contact@jimeh.me"))
  :maintainers '(("Jim Myhrberg" . "contact@jimeh.me")))
