;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2ansi" "0.2.1"
  "Syntax highlighting for `less', powered by Emacs."
  '((emacs         "25.1")
    (face-explorer "0.0.7"))
  :url "https://github.com/Lindydancer/e2ansi"
  :commit "9edc8eb3dbd33be09864ff660b44d9d0f5002b3c"
  :revdesc "9edc8eb3dbd3"
  :keywords '("faces" "languages"))
