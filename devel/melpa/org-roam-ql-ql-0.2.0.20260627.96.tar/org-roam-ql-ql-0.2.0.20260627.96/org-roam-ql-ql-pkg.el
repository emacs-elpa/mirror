;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql-ql" "0.2.0.20260627.96"
  "Integrating org-roam and org-ql."
  '((emacs       "28")
    (org-roam-ql "0.1")
    (org-ql      "0.8.2")
    (org-roam    "2.2.0")
    (s           "1.12.0")
    (transient   "0.4"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "196e6cd37f3eb7418ef250664d62b2cbd67a88e3"
  :revdesc "196e6cd37f3e")
