;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.2.0.20261013.6"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "1b3954416bcdc081e459e6dce9c2a50d57ae6e9c"
  :revdesc "1b3954416bcd"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
