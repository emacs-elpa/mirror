;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bookmarks" "1.2.0.20260905.51"
  "Manage bookmarks in Org mode."
  '((emacs      "29.1")
    (nerd-icons "0.1.0")
    (seq        "2.24"))
  :url "https://repo.or.cz/org-bookmarks.git"
  :commit "e0bf976214011e521bc450b96212906b6a6fb48c"
  :revdesc "e0bf97621401"
  :keywords '("outline" "matching" "hypermedia" "org")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
