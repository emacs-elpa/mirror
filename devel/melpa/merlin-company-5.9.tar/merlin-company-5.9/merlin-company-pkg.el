;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "merlin-company" "5.9"
  "Merlin and company mode integration."
  '((emacs   "25.1")
    (merlin  "3")
    (company "0.9"))
  :url "https://github.com/ocaml/merlin"
  :commit "55fbf4bf27429a1b1e4a32295a9cdd54d470b534"
  :revdesc "v5.9-0-g55fbf4bf2742"
  :keywords '("ocaml" "languages")
  :authors '(("Simon Castellan" . "simon.castellaniuwt.fr")
             ("Frédéric Bour" . "frederic.bourlakaban.net")
             ("Thomas Refis" . "thomas.refisgmail.com"))
  :maintainers '(("Simon Castellan" . "simon.castellaniuwt.fr")
                 ("Frédéric Bour" . "frederic.bourlakaban.net")
                 ("Thomas Refis" . "thomas.refisgmail.com")))
