;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "catmacs" "0.1.1.0.20170826.25"
  "Simple CAT interface for Yaesu Transceivers."
  '((emacs "24"))
  :url "https://bitbucket.org/pymaximus/catmacs"
  :commit "6ea9ee195661fe95355413856476c45dcc8e24e8"
  :revdesc "0.1.1-25-g6ea9ee195661"
  :keywords '("comm" "hardware")
  :authors '(("Frank Singleton" . "b17flyboy@gmail.com"))
  :maintainers '(("Frank Singleton" . "b17flyboy@gmail.com")))
