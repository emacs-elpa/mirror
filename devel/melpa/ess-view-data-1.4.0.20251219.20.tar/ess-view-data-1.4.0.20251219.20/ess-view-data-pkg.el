;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-view-data" "1.4.0.20251219.20"
  "View Data."
  '((emacs     "26.1")
    (ess       "18.10.1")
    (csv-mode  "1.12")
    (transient "0.3.7"))
  :url "https://github.com/ShuguangSun/ess-view-data"
  :commit "7dcbd23d4cef2030753d16e1ca1811d3466484e7"
  :revdesc "7dcbd23d4cef"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
