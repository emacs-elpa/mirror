;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comint-hyperlink" "0.1.6.0.20211026.1"
  "Create hyperlinks in comint for SGR URL control sequences."
  '((emacs "24.3"))
  :url "https://github.com/matthewbauer/comint-hyperlink"
  :commit "905f2db1f95950899301b9f71faed9e9362cf5dc"
  :revdesc "905f2db1f959"
  :keywords '("comint" "shell" "processes" "hypermedia" "terminals")
  :authors '(("Matthew Bauer" . "mjbauer95@gmail.com"))
  :maintainers '(("Matthew Bauer" . "mjbauer95@gmail.com")))
