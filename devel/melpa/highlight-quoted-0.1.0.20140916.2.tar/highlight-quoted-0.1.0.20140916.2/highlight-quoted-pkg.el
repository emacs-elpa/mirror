;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-quoted" "0.1.0.20140916.2"
  "Highlight Lisp quotes and quoted symbols."
  '((emacs "24"))
  :url "https://github.com/Fanael/highlight-quoted"
  :commit "ec9108486cf7f21f9a0b13f81369849b3b525f1f"
  :revdesc "ec9108486cf7"
  :authors '(("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers '(("Fanael Linithien" . "fanael4@gmail.com")))
