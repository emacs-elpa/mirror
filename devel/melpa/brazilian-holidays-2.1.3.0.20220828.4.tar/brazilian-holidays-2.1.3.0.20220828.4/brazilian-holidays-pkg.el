;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brazilian-holidays" "2.1.3.0.20220828.4"
  "Brazilian holidays."
  '((emacs "26"))
  :url "https://github.com/jadler/brazilian-holidays"
  :commit "03206ea673df49c91a8f924db799620713d86240"
  :revdesc "2.1.3-4-g03206ea673df"
  :keywords '("calendar" "holidays" "brazilian")
  :authors '(("Jaguaraquem A. Reinaldo" . "jaguar.adler@gmail.com"))
  :maintainers '(("Jaguaraquem A. Reinaldo" . "jaguar.adler@gmail.com")))
