;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hutch" "0.1.0.0.20261106.32"
  "AI code review for magit."
  '((emacs     "29.1")
    (magit     "4.0")
    (transient "0.7.4")
    (gptel     "0.9.9.4")
    (svg-lib   "0.3"))
  :url "https://github.com/adjaecent/magit-hutch"
  :commit "8db8a7168859d16571c2cd5fc594faa08a904953"
  :revdesc "8db8a7168859"
  :authors '(("Akshay Gupta" . "mail@kitallis.in"))
  :maintainers '(("Akshay Gupta" . "mail@kitallis.in")))
