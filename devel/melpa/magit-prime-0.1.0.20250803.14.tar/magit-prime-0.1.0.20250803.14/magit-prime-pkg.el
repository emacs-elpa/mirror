;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-prime" "0.1.0.20250803.14"
  "Prime cache before Magit refresh."
  '((emacs "27.1")
    (magit "3.0.0"))
  :url "https://github.com/Azkae/magit-prime"
  :commit "ebd58f95a564d69baa21a456471a2584673df78d"
  :revdesc "ebd58f95a564"
  :authors '(("Romain Ouabdelkader" . "romain.ouabdelkader@gmail.com"))
  :maintainers '(("Romain Ouabdelkader" . "romain.ouabdelkader@gmail.com")))
