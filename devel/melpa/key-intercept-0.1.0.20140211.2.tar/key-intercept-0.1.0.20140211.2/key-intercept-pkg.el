;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-intercept" "0.1.0.20140211.2"
  "Intercept prefix keys."
  ()
  :url "https://github.com/tarao/key-intercept-el"
  :commit "d9a60edb4ce893f2d3d94f242164fdcc62d43cf2"
  :revdesc "d9a60edb4ce8"
  :keywords '("keyboard")
  :authors '(("INA Lintaro" . "tarao.gnnatgmail.com"))
  :maintainers '(("INA Lintaro" . "tarao.gnnatgmail.com")))
