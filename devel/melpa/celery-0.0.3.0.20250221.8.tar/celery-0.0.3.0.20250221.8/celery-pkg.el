;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "celery" "0.0.3.0.20250221.8"
  "A minor mode to draw stats from celery and more?."
  '((emacs    "24")
    (dash     "2.18.0")
    (s        "1.9.0")
    (deferred "0.3.2"))
  :url "https://github.com/ardumont/emacs-celery"
  :commit "c689a47176d09a99382a4daecbe42ded94d4d649"
  :revdesc "c689a47176d0"
  :keywords '("celery" "convenience")
  :authors '(("ardumont" . "eniotna.t@gmail.com"))
  :maintainers '(("ardumont" . "eniotna.t@gmail.com")))
