;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wfnames" "1.2.0.20260706.4"
  "Edit filenames."
  '((emacs "24.4"))
  :url "https://github.com/thierryvolpiatto/wfnames"
  :commit "d8839fa42a24f7c781cd2d8c3f40eda31faa19be"
  :revdesc "v1.2-4-gd8839fa42a24"
  :keywords '("wfnames" "convenience" "files" "editing" "helm")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
