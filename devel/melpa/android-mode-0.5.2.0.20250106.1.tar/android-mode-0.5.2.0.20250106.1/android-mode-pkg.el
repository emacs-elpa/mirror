;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "android-mode" "0.5.2.0.20250106.1"
  "Minor mode for Android application development."
  ()
  :url "https://codeberg.org/rwv/android-mode"
  :commit "67f7c0d7d37605efc7f055b76d731556861c3eb9"
  :revdesc "0.5.2-1-g67f7c0d7d376"
  :keywords '("tools" "processes"))
