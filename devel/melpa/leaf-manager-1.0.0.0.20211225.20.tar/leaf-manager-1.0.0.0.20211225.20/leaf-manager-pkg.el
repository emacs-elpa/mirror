;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-manager" "1.0.0.0.20211225.20"
  "Configuration manager for leaf based init.el."
  '((emacs        "26.1")
    (leaf         "4.1")
    (leaf-convert "1.0")
    (ppp          "2.1"))
  :url "https://github.com/conao3/leaf-manager.el"
  :commit "a9fb7fda1432d0cf6bd8546d98a11b3fbe1d84e6"
  :revdesc "a9fb7fda1432"
  :keywords '("convenience" "leaf")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
