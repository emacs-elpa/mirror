;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-dashboard" "1.0.0.20171223.26"
  "Visually summarize progress in org files."
  '((cl-lib "0.5"))
  :url "https://github.com/bard/org-dashboard"
  :commit "02c0699771d199075a286e4502340ca6e7c9e831"
  :revdesc "02c0699771d1"
  :keywords '("outlines" "calendar")
  :authors '(("Massimiliano Mirra" . "hyperstruct@gmail.com"))
  :maintainers '(("Massimiliano Mirra" . "hyperstruct@gmail.com")))
