;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darkokai-theme" "0.1.1.0.20260316.22"
  "A darker variant on Monokai."
  ()
  :url "https://github.com/sjrmanning/darkokai"
  :commit "bd1e2bc33a81b331cc7747cd2f405f793348061d"
  :revdesc "bd1e2bc33a81")
