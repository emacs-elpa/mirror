;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tex-smart-umlauts" "1.5.0"
  "Smart umlaut conversion for TeX."
  ()
  :url "http://hub.darcs.net/lyro/tex-smart-umlauts"
  :commit "b28bac71990e0442616157fdb64494179df5575e"
  :revdesc "b28bac71990e"
  :keywords '("tex" "wp")
  :authors '(("Frank Fischer" . "frank-fischeratshadow-soft.de"))
  :maintainers '(("Frank Fischer" . "frank-fischeratshadow-soft.de")))
