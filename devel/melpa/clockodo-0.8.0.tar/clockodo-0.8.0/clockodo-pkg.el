;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clockodo" "0.8.0"
  "A small integration for the clockodo api."
  '((emacs   "26.1")
    (request "0.3.2")
    (ts      "0.2.2")
    (org     "8"))
  :url "https://github.com/santifa/clockodo-el"
  :commit "6329aaebc4373edaa4cd1d046582a4cc36db4888"
  :revdesc "6329aaebc437"
  :keywords '("tools" "clockodo")
  :authors '(("Henrik Jürges" . "juerges.henrik@gmail.com"))
  :maintainers '(("Henrik Jürges" . "juerges.henrik@gmail.com")))
