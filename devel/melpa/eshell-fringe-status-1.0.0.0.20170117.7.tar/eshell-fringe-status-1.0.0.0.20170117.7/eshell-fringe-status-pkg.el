;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-fringe-status" "1.0.0.0.20170117.7"
  "Show last status in fringe."
  ()
  :url "http://projects.ryuslash.org/eshell-fringe-status/"
  :commit "adc6997c68e39c0d52a2af1b2fd5cf2057783797"
  :revdesc "adc6997c68e3"
  :authors '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainers '(("Tom Willemse" . "tom@ryuslash.org")))
