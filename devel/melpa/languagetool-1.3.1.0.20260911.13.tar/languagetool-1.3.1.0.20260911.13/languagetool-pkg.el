;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "languagetool" "1.3.1.0.20260911.13"
  "LanguageTool integration for grammar and spell check."
  '((emacs "27.1"))
  :url "https://github.com/PillFall/languagetool.el"
  :commit "4be8f9e6da54867b03b26135008be91b0e7da675"
  :revdesc "v1.3.1-13-g4be8f9e6da54"
  :keywords '("grammar" "text" "docs" "tools" "convenience" "checker")
  :authors '(("Joar Buitrago" . "jebuitragoc@unal.edu.co"))
  :maintainers '(("Joar Buitrago" . "jebuitragoc@unal.edu.co")))
