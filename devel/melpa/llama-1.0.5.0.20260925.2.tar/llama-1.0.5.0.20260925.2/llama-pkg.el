;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llama" "1.0.5.0.20260925.2"
  "Compact syntax for short lambda."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/tarsius/llama"
  :commit "8e4aeb81824a1d08e183220258fdfad1a0e03ada"
  :revdesc "v1.0.5-2-g8e4aeb81824a"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.llama@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.llama@jonas.bernoulli.dev")))
