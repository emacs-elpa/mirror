;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soria-theme" "0.4.2.0.20250703.8"
  "A xoria256 theme with some colors from openSUSE."
  '((emacs "25.1"))
  :url "https://github.com/mssola/soria"
  :commit "65581530155b097fc314a19b2851a7dffcfd3790"
  :revdesc "v0.4.2-8-g65581530155b"
  :keywords '("faces")
  :authors '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainers '(("Miquel Sabaté Solà" . "mikisabate@gmail.com")))
