;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyasm-mode" "1.0.0.0.20260122.15"
  "Mode for editing assembler code."
  '((emacs  "24.4")
    (compat "30.1.0.1"))
  :url "https://github.com/rocky/emacs-pyasm-mode"
  :commit "b9434097b5454a2b28440d72ec4eadbdff44f651"
  :revdesc "b9434097b545"
  :keywords '("languages")
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '((nil . "rocky@gnu.org")))
