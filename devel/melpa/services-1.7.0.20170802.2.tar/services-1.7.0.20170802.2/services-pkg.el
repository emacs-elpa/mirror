;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "services" "1.7.0.20170802.2"
  "Services database access functions."
  '((cl-lib "0.5"))
  :url "https://github.com/davep/services.el"
  :commit "04c7986041a33dfa0b0ae57c7d6fbd600548c596"
  :revdesc "04c7986041a3"
  :keywords '("convenience" "net" "services")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
