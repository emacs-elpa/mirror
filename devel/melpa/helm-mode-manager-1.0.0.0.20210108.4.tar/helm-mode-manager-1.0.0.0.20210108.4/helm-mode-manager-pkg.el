;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-mode-manager" "1.0.0.0.20210108.4"
  "Select and toggle major and minor modes with helm."
  '((helm "1.5.3"))
  :url "https://github.com/istib/helm-mode-manager"
  :commit "7df8ed3ddd46a0402838b748d317c01454346164"
  :revdesc "1.0.0-4-g7df8ed3ddd46")
