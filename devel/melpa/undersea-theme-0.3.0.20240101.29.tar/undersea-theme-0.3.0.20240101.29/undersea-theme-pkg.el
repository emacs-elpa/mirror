;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undersea-theme" "0.3.0.20240101.29"
  "Theme styled after undersea imagery."
  '((emacs "24.3"))
  :url "https://github.com/jcs-elpa/undersea-theme"
  :commit "0730e21187367003c533e67cdb676a423a8dccd0"
  :revdesc "0730e2118736"
  :keywords '("theme" "sea")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
