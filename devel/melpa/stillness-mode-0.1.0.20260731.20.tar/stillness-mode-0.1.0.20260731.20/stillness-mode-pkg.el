;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stillness-mode" "0.1.0.20260731.20"
  "Prevent windows from jumping on minibuffer activation."
  '((emacs "26.1")
    (dash  "2.18.0"))
  :url "https://github.com/neeasade/stillness-mode.el"
  :commit "a4dde63e4f6632f5476a236d0647e16a3c8d846b"
  :revdesc "a4dde63e4f66"
  :keywords '("convenience"))
