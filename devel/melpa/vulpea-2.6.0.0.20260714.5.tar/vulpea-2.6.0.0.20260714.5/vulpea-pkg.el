;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.6.0.0.20260714.5"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "4bf6edeb32aaa5e686c7d4eaf80cecf38b6fd390"
  :revdesc "4bf6edeb32aa"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
