;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-alert" "1.3.0.20260905.3"
  "Notifications when commands complete in term.el and eat."
  '((emacs    "24.0")
    (term-cmd "1.1")
    (alert    "1.1")
    (f        "0.18.2"))
  :url "https://codeberg.org/calliecameron/term-alert"
  :commit "a9181a0c71a31cca3974932c933b6ed9ab747397"
  :revdesc "a9181a0c71a3"
  :keywords '("notifications" "processes")
  :authors '(("Callie Cameron" . "cjcameron7@gmail.com"))
  :maintainers '(("Callie Cameron" . "cjcameron7@gmail.com")))
