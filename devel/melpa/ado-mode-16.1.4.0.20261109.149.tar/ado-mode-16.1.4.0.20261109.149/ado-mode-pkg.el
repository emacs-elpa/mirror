;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ado-mode" "16.1.4.0.20261109.149"
  "Major mode for editing Stata-related files."
  '((emacs "25.1"))
  :url "https://github.com/louabill/ado-mode"
  :commit "a6c2a60f62828214cdf2769b96910924ba51b494"
  :revdesc "16.1.4-149-ga6c2a60f6282"
  :keywords '("tools" "languages" "files" "convenience" "stata" "mata" "ado")
  :authors '(("Bill Rising" . "brising@alum.mit.edu"))
  :maintainers '(("Bill Rising" . "brising@alum.mit.edu")))
