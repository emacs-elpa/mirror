;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "1.1.5.0.20260710.3"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "c2f03438f62915e71a780ca1cb05b94fe2871a71"
  :revdesc "1.1.5-3-gc2f03438f629"
  :keywords '("frames")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
