;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iterator" "1.1.0.20250504.1"
  "A library to create and use elisp iterators objects."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/thierryvolpiatto/iterator"
  :commit "9cbe0d1153ce03d11c75f1d2b010091092b476ea"
  :revdesc "9cbe0d1153ce"
  :authors '(("Thierry Volpiatto" . "thierrydotvolpiattoatgmaildotcom"))
  :maintainers '(("Thierry Volpiatto" . "thierrydotvolpiattoatgmaildotcom")))
