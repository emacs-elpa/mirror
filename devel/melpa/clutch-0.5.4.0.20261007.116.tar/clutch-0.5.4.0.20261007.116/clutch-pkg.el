;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.4.0.20261007.116"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "fdef15fd926d4ed9c89bca282ec15e2375717429"
  :revdesc "fdef15fd926d"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
