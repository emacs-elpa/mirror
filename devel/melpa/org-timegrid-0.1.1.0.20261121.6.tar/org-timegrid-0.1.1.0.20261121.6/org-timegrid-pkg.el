;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "0.1.1.0.20261121.6"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "04333960c7a4e304b8c4f27233c99a07aaedfda1"
  :revdesc "v0.1.1-6-g04333960c7a4"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
