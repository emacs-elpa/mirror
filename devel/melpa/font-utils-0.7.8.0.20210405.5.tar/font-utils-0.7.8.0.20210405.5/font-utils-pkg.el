;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "font-utils" "0.7.8.0.20210405.5"
  "Utility functions for working with fonts."
  '((persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/font-utils"
  :commit "abc572eb0dc30a26584c0058c3fe6c7273a10003"
  :revdesc "v0.7.8-5-gabc572eb0dc3"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
