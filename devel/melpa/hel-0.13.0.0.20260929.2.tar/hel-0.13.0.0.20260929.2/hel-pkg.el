;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hel" "0.13.0.0.20260929.2"
  "Helix Emulation Layer."
  '((emacs        "29.1")
    (dash         "2.19.1")
    (avy          "0.5.0")
    (pcre2el      "1.12")
    (ultra-scroll "0.6"))
  :url "https://github.com/helheim-emacs/hel"
  :commit "8e0a5cd6780cc4ec0d899632968176075d4d9ed0"
  :revdesc "8e0a5cd6780c"
  :authors '(("Yuriy Artemyev" . "anuvyklack@gmail.com"))
  :maintainers '(("Yuriy Artemyev" . "anuvyklack@gmail.com")))
