;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scrooge" "0.2.0.20180630.9"
  "Major mode for Twitter Scrooge files."
  '((emacs  "24")
    (cl-lib "0.5")
    (dash   "2.13.0")
    (thrift "0.9.3"))
  :url "https://github.com/cosmicexplorer/emacs-scrooge"
  :commit "0a8c58e9e6708abe4ef7e415bc1e0472318bb1b0"
  :revdesc "0a8c58e9e670"
  :keywords '("scrooge" "thrift")
  :authors '(("Daniel McClanahan" . "danieldmcclanahan@gmail.com"))
  :maintainers '(("Daniel McClanahan" . "danieldmcclanahan@gmail.com")))
