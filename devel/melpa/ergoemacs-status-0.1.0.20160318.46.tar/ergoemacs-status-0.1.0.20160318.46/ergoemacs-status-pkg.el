;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ergoemacs-status" "0.1.0.20160318.46"
  "Adaptive Status Bar / Mode Line."
  '((powerline  "2.3")
    (mode-icons "0.1.0"))
  :url "https://github.com/ergoemacs/ergoemacs-status"
  :commit "d952cc2361adf6eb4d6af60950ad4ab699c81320"
  :revdesc "d952cc2361ad")
