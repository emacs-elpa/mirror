;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minibuffer-cua" "1.0.0.0.20130906.1"
  "Make CUA mode's S-up/S-down work in minibuffer."
  ()
  :url "https://github.com/knu/minibuffer-cua.el"
  :commit "adc4979a64f8b36e05960e9afa0746dfa9e2e4c7"
  :revdesc "adc4979a64f8"
  :keywords '("completion" "editing")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
