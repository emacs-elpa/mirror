;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cake-inflector" "1.1.1.0.20140415.1"
  "Lazy porting CakePHP infrector.php to el."
  '((s "1.9.0"))
  :url "https://github.com/k1LoW/emacs-cake-inflector"
  :commit "d9c6298fbca53efeb6f0f37140395659d9a6d7cc"
  :revdesc "d9c6298fbca5"
  :authors '((nil . "k1low[at]101000lab[dot]org"))
  :maintainers '((nil . "k1low[at]101000lab[dot]org")))
