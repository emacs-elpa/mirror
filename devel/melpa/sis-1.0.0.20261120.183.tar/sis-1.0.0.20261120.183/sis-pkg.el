;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "1.0.0.20261120.183"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "e6709418acf13257a394cce9769a20dfb03b8e8f"
  :revdesc "e6709418acf1"
  :keywords '("convenience"))
