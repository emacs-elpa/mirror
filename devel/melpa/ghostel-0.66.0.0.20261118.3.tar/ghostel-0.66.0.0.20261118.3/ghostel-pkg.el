;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.66.0.0.20261118.3"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "79198bdd33021b92e8b5459dce6615d200acd3f9"
  :revdesc "79198bdd3302"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
