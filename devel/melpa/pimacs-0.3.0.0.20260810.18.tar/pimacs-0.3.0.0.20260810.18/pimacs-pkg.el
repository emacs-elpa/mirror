;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.3.0.0.20260810.18"
  "Emacs Client for Pi."
  '((emacs         "29.1")
    (compat        "31.0")
    (markdown-mode "2.8")
    (timeout       "2.1.7")
    (pcre2el       "1.12")
    (spinner       "1.7")
    (transient     "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "099f5a74238e43a79048c6ba2b291ddb3f318e85"
  :revdesc "099f5a74238e"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
