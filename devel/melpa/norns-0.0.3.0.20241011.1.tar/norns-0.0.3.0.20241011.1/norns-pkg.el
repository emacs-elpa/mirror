;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "norns" "0.0.3.0.20241011.1"
  "Interactive development environment for monome norns."
  '((emacs     "27.1")
    (dash      "2.17.0")
    (s         "1.12.0")
    (f         "0.20.0")
    (request   "0.3.2")
    (websocket "1.13")
    (lua-mode  "20221218.605"))
  :url "https://github.com/p3r7/norns.el"
  :commit "d08eed8555a619a13aa99cfa2ef40e199e86114c"
  :revdesc "d08eed8555a6"
  :keywords '("processes" "terminals"))
