;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "1.7.0.20260630.1"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "ae727267fded58a0715c9d3e11997d6027c06b4c"
  :revdesc "ae727267fded"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
