;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "etherpad" "1.0.2.0.20261125.2"
  "Collaborative editing via Etherpad."
  '((emacs     "29.1")
    (websocket "1.12"))
  :url "https://codeberg.org/zzkt/ethermacs"
  :commit "cc0a77909b907355a90854e292912bba75eb954d"
  :revdesc "v1.0.2-2-gcc0a77909b90"
  :keywords '("comm" "etherpad" "collaborative editing")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
