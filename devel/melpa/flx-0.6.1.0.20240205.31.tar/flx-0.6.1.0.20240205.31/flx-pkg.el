;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flx" "0.6.1.0.20240205.31"
  "Fuzzy matching with good sorting."
  '((cl-lib "0.3"))
  :url "https://github.com/lewang/flx"
  :commit "4b1346eb9a8a76ee9c9dede69738c63ad97ac5b6"
  :revdesc "4b1346eb9a8a")
