;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wisp-mode" "1.0.13.0.20260707.13"
  "Tools for wisp: the Whitespace-to-Lisp preprocessor."
  '((emacs "24.4"))
  :url "http://www.draketo.de/english/wisp"
  :commit "9fb7658fc44fe0e030a9f7c05a9de38937861c18"
  :revdesc "v1.0.13-12-m9fb7658fc44f"
  :keywords '("languages" "lisp" "scheme")
  :authors '(("Arne Babenhauserheide" . "arne_bab@web.de"))
  :maintainers '(("Arne Babenhauserheide" . "arne_bab@web.de")))
