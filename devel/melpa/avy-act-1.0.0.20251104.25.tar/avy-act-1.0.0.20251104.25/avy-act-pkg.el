;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-act" "1.0.0.20251104.25"
  "Commands that let avy act from a distance."
  '((avy   "0.5.0")
    (emacs "29.1"))
  :url "https://gitlab.com/nameiwillforget/avy-act"
  :commit "61b0bf036da3755ded04f8bc295a8a54407ea758"
  :revdesc "61b0bf036da3"
  :keywords '("tools" "convenience")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
