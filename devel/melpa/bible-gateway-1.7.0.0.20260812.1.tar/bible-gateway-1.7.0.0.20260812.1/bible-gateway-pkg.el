;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "1.7.0.0.20260812.1"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "2c8367b10798b6f03a618f061cbcb7ce509b88e1"
  :revdesc "2c8367b10798"
  :keywords '("convenience" "comm" "hypermedia"))
