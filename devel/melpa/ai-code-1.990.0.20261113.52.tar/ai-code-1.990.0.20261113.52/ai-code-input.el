;;; ai-code-input.el --- Helm completion for ai-code.el -*- lexical-binding: t; -*-

;; Author: Kang Tu <tninja@gmail.com>
;; Keywords: convenience, tools
;; URL: https://github.com/tninja/ai-code-interface.el
;; SPDX-License-Identifier: Apache-2.0

;;; Commentary:
;; Optional Helm completion interface for ai-code.el
;; To use this, ensure both ai-code.el and helm are installed.

;;; Code:

(require 'cl-lib)  ; For `cl-subseq`
(require 'imenu)
(require 'magit)
(require 'ai-code-utils)
(require 'ai-code-session-link)
(require 'ai-code-compose)
(require 'subr-x)

(declare-function browse-url "browse-url" (url &optional new-window))
(declare-function helm-comp-read "helm-mode" (prompt collection &rest args))
(declare-function ai-code-backends-infra--session-buffer-p "ai-code-backends-infra" (buffer))
(declare-function ai-code-backends-infra--linkify-session-region "ai-code-backends-infra" (start end))
(declare-function ai-code-backends-infra--terminal-send-string "ai-code-backends-infra" (string))
(declare-function ai-code-backends-infra--terminal-send-backspace "ai-code-backends-infra" ())
(declare-function ai-code--prompt-filepath-candidates "ai-code-prompt-mode" ())
(declare-function ai-code--insert-prompt "ai-code-prompt-mode"
                  (prompt-text &optional send-function))
(defvar ai-code--prompt-already-edited)
(declare-function whisper-run "whisper" ())
(declare-function treesit-node-parent "treesit" (node))

(eval-when-compile
  (defvar whisper-after-transcription-hook))

(defconst ai-code--speech-to-text-buffer-name "*whisper-stdout*"
  "Buffer name used by whisper.el transcription output.")

(defconst ai-code--speech-to-text-actions
  '("Insert to current buffer"
    "Send to AI coding session"
    "Copy to clipboard")
  "Completion choices for speech-to-text transcription handling.")

;;;###autoload
(defun ai-code-plain-read-string (prompt &optional initial-input _candidate-list)
  "Read a string from the user with PROMPT and optional INITIAL-INPUT.
_CANDIDATE-LIST is accepted for interface compatibility but ignored.
Uses `read-string' directly to avoid `helm-mode' intercepting `completing-read'."
  (read-string prompt initial-input 'ai-code-read-string-history))

(defvar ai-code--read-string-fn #'ai-code-plain-read-string
  "Function used by `ai-code-read-string' to read user input.")

;;;###autoload
(defun ai-code-read-string (prompt &optional initial-input candidate-list)
  "Read a string from the user with PROMPT and optional INITIAL-INPUT.
CANDIDATE-LIST provides additional completion options if provided."
  (funcall ai-code--read-string-fn prompt initial-input candidate-list))

(defun ai-code--long-prompt-p (text)
  "Return non-nil when TEXT spans more than two lines.
Such text is edited with the multi-line editor instead of the default
reader, and with a compose buffer when `ai-code-use-compose-buffer' is set."
  (and text
       (> (length (split-string text "\n")) 2)))

(defun ai-code--read-prompt (prompt-label initial-prompt &optional force-compose)
  "Edit INITIAL-PROMPT with PROMPT-LABEL using the configured reader.
FORCE-COMPOSE always opens the compose buffer.  Otherwise long prompts
use compose only when enabled, retaining the existing minibuffer readers.
Return nil when compose is cancelled."
  (cond
   ((or force-compose
        (and ai-code-use-compose-buffer (ai-code--long-prompt-p initial-prompt)))
    (ai-code-compose-read prompt-label initial-prompt))
   ((ai-code--long-prompt-p initial-prompt)
    (read-string prompt-label initial-prompt))
   (t (ai-code-read-string prompt-label initial-prompt))))

(cl-defun ai-code--confirm-and-send (prompt-label initial-prompt
                                                  &key force-compose after-edit)
  "Edit INITIAL-PROMPT with PROMPT-LABEL, then send to AI once.
FORCE-COMPOSE always uses compose.  AFTER-EDIT, when non-nil, transforms
the accepted text before sending, for example to append mandatory rules.
Cancellation or blank text skips the transform and all send side effects."
  (when-let ((prompt (ai-code--read-prompt prompt-label initial-prompt force-compose)))
    (unless (string-blank-p prompt)
      (let ((ai-code--prompt-already-edited t))
        (ai-code--insert-prompt (if after-edit (funcall after-edit prompt) prompt))))))

(defun ai-code--read-input-history (file)
  "Read the saved input history list from FILE.
Return a cons of (READABLE . ENTRIES).  READABLE is nil only when FILE
exists but does not parse as a list, which tells the caller it must not
replace the file with a freshly built history.  Non-string elements are
dropped: a history truncated by a non-nil `print-length' reads back with
an ellipsis symbol in it."
  (if (not (file-exists-p file))
      (cons t '())
    (condition-case nil
        (with-temp-buffer
          (insert-file-contents file)
          (let ((content (buffer-string)))
            (if (string-empty-p content)
                (cons t '())
              (let ((entries (read content)))
                (if (listp entries)
                    (cons t (cl-remove-if-not #'stringp entries))
                  (cons nil '()))))))
      (error (cons nil '())))))

(defun ai-code--write-input-history (file entries)
  "Save ENTRIES to FILE, keeping at most the 1000 most recent.
Text properties are stripped and printing is left unbounded so the file
always reads back as the list that was written."
  (with-temp-file file
    (let ((print-circle nil)
          (print-length nil)
          (print-level nil)
          (recent (cl-subseq entries 0 (min (length entries) 1000))))
      (insert (prin1-to-string (mapcar #'substring-no-properties recent))))))

(defun ai-code-helm-read-string-with-history (prompt history-file-name &optional initial-input candidate-list)
  "Read a string with Helm completion using specified history file.
PROMPT is the prompt string.
HISTORY-FILE-NAME is the base name for history file.
INITIAL-INPUT is optional initial input string.
CANDIDATE-LIST is an optional list of candidate strings to show before history."
  ;; Load history from file
  (let* ((helm-history-file (expand-file-name history-file-name user-emacs-directory))
         (loaded-history (ai-code--read-input-history helm-history-file))
         ;; Use only Helm history, no CLI history
         (history (cdr loaded-history))
         ;; Extract the most recent item from history (if exists)
         (most-recent (when history
                        (car history)))
         ;; Remove the first item to add it back later
         (rest-history (when history
                         (cl-remove-duplicates (cdr history) :test #'equal)))
         ;; Combine completion list: most recent + candidates + separator + rest of history
         (completion-list
          (append
           ;; If most recent item exists, put it at the top
           (when most-recent
             (list most-recent))
           ;; Add candidate list
           (or candidate-list '())
           ;; Add separator and rest of history
           (when rest-history
             (cons "==================== HISTORY ========================================" rest-history))))
         ;; Read input with helm
         (input (helm-comp-read
                 prompt
                 completion-list
                 :must-match nil
                 :name "Helm Read String, Use C-c C-y to edit selected command. C-b and C-f to move cursor during editing"
                 :fuzzy nil
                 :initial-input initial-input)))
    ;; Add to history if non-empty, single-line and save.  Never rewrite a
    ;; history file we failed to parse: that would replace every saved entry
    ;; with this single input.
    (cond
     ((not (car loaded-history))
      (message "AI Code: %s could not be parsed, input history not saved"
               helm-history-file))
     ((or (string-empty-p input) (string-match "\n" input)) nil)
     (t
      (ai-code--write-input-history helm-history-file (cons input history))))
    input))

(defun ai-code-helm-read-string (prompt &optional initial-input candidate-list)
  "Read a string with Helm completion for ai-code, showing historical inputs.
PROMPT is the prompt string.
INITIAL-INPUT is optional initial input string.
CANDIDATE-LIST is an optional list of candidate strings to show before history."
  (ai-code-helm-read-string-with-history prompt "ai-code-helm-read-string-history.el" initial-input candidate-list))

(defun ai-code--speech-to-text-apply-transcription (origin-buffer)
  "Read transcription from current buffer and apply a chosen speech action.
The transcription is obtained from the current buffer, then if
ORIGIN-BUFFER is still live and the transcription is non-empty,
prompt the user to choose an action (insert into ORIGIN-BUFFER,
send to an AI coding session, or copy to the clipboard) and
perform that action."
  (let ((transcription
         (string-trim
          (buffer-substring-no-properties (point-min) (point-max)))))
    (when (and (buffer-live-p origin-buffer)
               (not (string-empty-p transcription)))
      (ai-code--speech-to-text-handle-action
       origin-buffer
       transcription
       (completing-read "Choose speech action: "
                        ai-code--speech-to-text-actions
                        nil t)))))

(defun ai-code--speech-to-text-handle-action (origin-buffer transcription action)
  "Handle speech ACTION for TRANSCRIPTION from ORIGIN-BUFFER."
  (pcase action
    ("Insert to current buffer"
     (with-current-buffer origin-buffer
       (insert transcription)))
    ("Send to AI coding session"
     (ai-code--speech-to-text-send-prompt origin-buffer transcription))
    ("Copy to clipboard"
     (kill-new transcription))))

(defun ai-code--speech-to-text-send-prompt (origin-buffer transcription)
  "Edit TRANSCRIPTION from ORIGIN-BUFFER and send the result to the AI session."
  (require 'ai-code-prompt-mode)
  (with-current-buffer origin-buffer
    (ai-code--confirm-and-send "Send to AI: " transcription)))

;;;###autoload
(defun ai-code-speech-to-text-input ()
  "Record audio with whisper.el, then choose how to use the transcription.

After recording and transcription, you can insert the text at point in the
original buffer, send it to an AI coding session, or copy it to the clipboard."
  (interactive)
  (unless (require 'whisper nil t)
    (user-error "Whisper.el is not available, please install it first"))
  (let ((origin-buffer (current-buffer)))
    (with-current-buffer (get-buffer-create ai-code--speech-to-text-buffer-name)
      (erase-buffer)
      (setq-local whisper-after-transcription-hook nil)
      (add-hook 'whisper-after-transcription-hook
                (lambda ()
                  (ai-code--speech-to-text-apply-transcription origin-buffer))
                nil t)
      (whisper-run)
      (message "Recording audio. Press RET when you are done.")
      (while (not (equal ?\r (read-char)))
        (sit-for 0.5))
      (whisper-run))))

;;;###autoload
(when (featurep 'helm)
  (setq ai-code--read-string-fn #'ai-code-helm-read-string))

(defun ai-code--enable-helm-read-string (&rest _args)
  "Enable Helm-backed prompt reading after Helm is loaded."
  (when (featurep 'helm)
    (setq ai-code--read-string-fn #'ai-code-helm-read-string)
    (remove-hook 'after-load-functions #'ai-code--enable-helm-read-string)))

(unless (featurep 'helm)
  (add-hook 'after-load-functions #'ai-code--enable-helm-read-string))


(defun ai-code--imenu-subalist-p (payload)
  "Return non-nil when PAYLOAD resembles an imenu sub-alist."
  (and (listp payload)
       (cl-some (lambda (entry)
                  (and (consp entry) (stringp (car entry))))
                payload)))

(defun ai-code--imenu-item-position (payload)
  "Extract buffer position from imenu PAYLOAD."
  (cond
   ((or (integerp payload) (markerp payload)) payload)
   ((overlayp payload) (overlay-start payload))
   ((and (consp payload)
         (or (integerp (car payload))
             (markerp (car payload))))
    (car payload))
   (t nil)))

(defun ai-code--extract-symbol-from-line (line)
  "Extract a likely symbol identifier from LINE."
  (let ((patterns
         '("^[ \t]*\\(?:async[ \t]+\\)?\\(?:def\\|class\\|function\\|func\\|fn\\|sub\\|proc\\|method\\|interface\\|struct\\|enum\\|type\\|trait\\|module\\|namespace\\)[ \t]+\\([[:word:]_.$:\\-]+\\)"
           "^[ \t]*\\([[:word:]_.$:\\-]+\\)[ \t]*("
           "^[ \t]*\\([[:word:]_.$:\\-]+\\)[ \t]*[{: ]")))
    (catch 'found
      (dolist (pattern patterns)
        (when (string-match pattern line)
          (let ((name (match-string 1 line)))
            (throw 'found (replace-regexp-in-string ":+\\'" "" name)))))
      nil)))

(defun ai-code--imenu-symbol-from-position (payload)
  "Extract a symbol name from PAYLOAD position as fallback."
  (when-let* ((pos (ai-code--imenu-item-position payload)))
    (save-excursion
      (goto-char pos)
      (ai-code--extract-symbol-from-line
       (buffer-substring-no-properties
        (line-beginning-position)
        (line-end-position))))))

(defun ai-code--imenu-noise-name-p (name)
  "Return non-nil when NAME resembles an imenu group/template label."
  (or (not (stringp name))
      (string-empty-p (string-trim name))
      (string-match-p "\\`\\*.*\\*\\'" name)
      (string-match-p "\\`[0-9]+\\'" name)))

(defun ai-code--normalize-imenu-symbol-name (name payload)
  "Normalize imenu NAME using PAYLOAD as fallback source."
  (let ((trimmed (and (stringp name) (string-trim name))))
    (if (and trimmed (not (ai-code--imenu-noise-name-p trimmed)))
        trimmed
      (ai-code--imenu-symbol-from-position payload))))

(defun ai-code--flatten-imenu-index (index)
  "Flatten imenu INDEX into a list of useful symbol names."
  (let (result)
    (dolist (item index)
      (when (consp item)
        (let ((name (car item))
              (payload (cdr item)))
          (if (ai-code--imenu-subalist-p payload)
              (setq result (append result (ai-code--flatten-imenu-index payload)))
            (when-let* ((symbol (ai-code--normalize-imenu-symbol-name name payload)))
              (push symbol result))))))
    result))

(defun ai-code--get-functions-from-buffer (buffer)
  "Get a list of function/symbol names from BUFFER using imenu."
  (with-current-buffer buffer
    (when (derived-mode-p 'prog-mode)
      (condition-case nil
          (let ((imenu-auto-rescan t)
                (index (imenu--make-index-alist t)))
            (ai-code--flatten-imenu-index index))
        (error nil)))))

;;;###autoload
(defun ai-code-insert-function-at-point ()
  "Insert a function name selected from current windows' `prog-mode' buffers."
  (interactive)
  (let ((functions nil))
    (dolist (window (window-list))
      (let ((buffer (window-buffer window)))
        (setq functions (append (ai-code--get-functions-from-buffer buffer) functions))))
    (setq functions (sort (delete-dups (cl-remove-if-not #'stringp functions)) #'string<))
      (let ((selected (completing-read "Insert function: " functions nil nil)))
        (when (and selected (not (string-empty-p selected)))
          (insert selected)))))

(defvar ai-code-prompt-filepath-completion-enabled nil
  "Non-nil enables @ file completion inside comments and AI sessions.")

(defun ai-code--any-ai-session-active-p ()
  "Return non-nil when any AI session buffer is active."
  (when (fboundp 'ai-code-backends-infra--session-buffer-p)
    (let ((active nil))
      (dolist (buf (buffer-list))
        (when (and (not active)
                   (ai-code-backends-infra--session-buffer-p buf))
          (setq active t)))
      active)))

(defun ai-code--comment-context-p ()
  "Return non-nil when point is inside a comment."
  (nth 4 (syntax-ppss)))

(defun ai-code--hash-completion-target-file (&optional end-pos)
  "Return an absolute file path for @relative path ending at END-POS.
END-POS defaults to the current '#' position."
  (when-let* ((git-root (ai-code--git-root)))
    (let* ((end (or end-pos (1- (point))))
           (start (save-excursion
                    (goto-char end)
                    (skip-chars-backward "A-Za-z0-9_./-")
                    (point)))
           (has-at (save-excursion
                     (goto-char start)
                     (eq (char-before) ?@)))
           (relative-path (and has-at
                               (< start end)
                               (buffer-substring-no-properties start end))))
      (when relative-path
        (let ((file (expand-file-name relative-path git-root)))
          (when (and (file-regular-p file)
                     (string-prefix-p git-root (file-truename file)))
            file))))))

(defun ai-code--imenu-symbol-self-entry-p (entry)
  "Return non-nil when ENTRY is an Imenu node's self-position entry.
Tree-sitter-backed Imenu uses a whitespace-only name for this entry when a
symbol also contains nested entries."
  (and (consp entry)
       (stringp (car entry))
       (string-empty-p (string-trim (car entry)))
       (ai-code--imenu-item-position (cdr entry))))

(defun ai-code--imenu-symbol-self-position (payload)
  "Return the self position encoded in nested Imenu PAYLOAD, or nil."
  (when-let* ((entry (cl-find-if #'ai-code--imenu-symbol-self-entry-p payload)))
    (ai-code--imenu-item-position (cdr entry))))

(defun ai-code--imenu-symbol-position-number (position)
  "Return POSITION as a usable position in the current buffer, or nil."
  (let ((pos (cond
              ((integerp position) position)
              ((and (markerp position)
                    (eq (marker-buffer position) (current-buffer)))
               (marker-position position)))))
    (when (and pos (<= (point-min) pos) (<= pos (point-max))) pos)))

(defun ai-code--imenu-unadorned-name (name)
  "Return NAME without a trailing Imenu presentation label.
For example, Python's `run (def)' label still identifies `run'."
  (when (stringp name)
    (replace-regexp-in-string
     "\\(?: ([^()\n]+)\\(?:\\.\\.\\.\\)?\\|\\.\\.\\.\\)\\'" "" name)))

(defun ai-code--imenu-name-extends-p (qualified name)
  "Return non-nil if QUALIFIED identifies NAME with optional enclosing types."
  (let ((qualified (ai-code--imenu-unadorned-name qualified))
        (name (ai-code--imenu-unadorned-name name)))
    (and qualified name (not (string-empty-p name))
         (or (equal qualified name)
             (string-suffix-p (concat "." name) qualified)))))

(defun ai-code--imenu-qualified-name (parent-prefix name)
  "Return NAME qualified by PARENT-PREFIX without duplicating a prefix."
  (cond
   ((or (null parent-prefix) (string-empty-p parent-prefix)) name)
   ((string-prefix-p (concat parent-prefix ".") name) name)
   (t (concat parent-prefix "." name))))

(defun ai-code--imenu-treesit-qualified-name-at-position (position)
  "Return the full Tree-sitter qualified scope name at POSITION, or nil.
Imenu remains the symbol-discovery source; this helper only enriches one
discovered Imenu position with enclosing type information."
  (when (and (ai-code--treesit-available-p)
             (fboundp 'treesit-node-parent))
    (save-excursion
      (goto-char position)
      (when-let* ((node (ai-code--treesit-defun-at-point)))
        (let* ((node-is-type (ai-code--treesit-class-like-node-p node))
               (function-name
                (unless node-is-type
                  (ai-code--treesit-node-name node)))
               (current (if node-is-type
                            node
                          (treesit-node-parent node)))
               (type-names nil))
          (while current
            (when (ai-code--treesit-class-like-node-p current)
              (when-let* ((name (ai-code--treesit-node-name current)))
                (push name type-names)))
            (setq current (treesit-node-parent current)))
          (let ((parts (append type-names
                               (when function-name (list function-name)))))
            (when parts
              (mapconcat #'identity parts "."))))))))

(defun ai-code--imenu-symbol-record (name payload parent-prefix &optional position)
  "Build a symbol record from Imenu NAME and PAYLOAD under PARENT-PREFIX.
POSITION overrides the position extracted from PAYLOAD."
  (when-let* ((symbol (ignore-errors
                       (ai-code--normalize-imenu-symbol-name name payload)))
              ((not (string-empty-p symbol))))
    (list :name symbol
          :qualified (ai-code--imenu-qualified-name parent-prefix symbol)
          :position (or position (ai-code--imenu-item-position payload)))))

(defun ai-code--imenu-collect-symbol-records (index &optional parent-prefix)
  "Collect symbol records from Imenu INDEX while preserving hierarchy.
PARENT-PREFIX is the qualified name of the semantic container.  Plain
category/group nodes are traversed without becoming part of that name."
  (let (records)
    (dolist (item index (nreverse records))
      (when (consp item)
        (let ((name (car item))
              (payload (cdr item)))
          (cond
           ((equal item imenu--rescan-item)
            nil)
           ((ai-code--imenu-symbol-self-entry-p item)
            nil)
           ((imenu--subalist-p item)
            (if-let* ((self-position (ai-code--imenu-symbol-self-position payload))
                      (record (ai-code--imenu-symbol-record
                               name payload parent-prefix self-position)))
                (let* ((qualified (plist-get record :qualified))
                       (children (cl-remove-if
                                  #'ai-code--imenu-symbol-self-entry-p
                                  payload)))
                  (push record records)
                  (dolist (child (ai-code--imenu-collect-symbol-records
                                  children qualified))
                    (push child records)))
              ;; Category nodes such as "Function" or "Class" have no
              ;; self-position and therefore do not qualify their children.
              (dolist (child (ai-code--imenu-collect-symbol-records
                              payload parent-prefix))
                (push child records))))
           (t
            (when-let* ((record (ai-code--imenu-symbol-record
                                 name payload parent-prefix)))
              (push record records)))))))))

(defun ai-code--imenu-record-position-less-p (left right)
  "Return non-nil when LEFT appears before RIGHT in the source buffer."
  (let ((left-pos (ai-code--imenu-symbol-position-number
                   (plist-get left :position)))
        (right-pos (ai-code--imenu-symbol-position-number
                    (plist-get right :position))))
    (cond
     ((and left-pos right-pos) (< left-pos right-pos))
     (left-pos t)
     (right-pos nil)
     (t nil))))

(defun ai-code--imenu-symbol-header-at-position (position name)
  "Return the best declaration header available at POSITION.
When Tree-sitter is active, use the existing semantic scope helper for a
precise declaration header only when it identifies NAME.  Otherwise use
the source line rather than an unrelated enclosing definition."
  (when-let* ((pos (ai-code--imenu-symbol-position-number position)))
    (save-excursion
      (goto-char pos)
      (let ((scope (when (ai-code--treesit-available-p)
                     (ignore-errors (ai-code--current-scope-context pos)))))
        (or (and (ai-code--imenu-name-extends-p name (plist-get scope :function-name))
                 (plist-get scope :function-header))
            (and (ai-code--imenu-name-extends-p name (plist-get scope :class-name))
                 (plist-get scope :class-header))
            (string-trim
             (buffer-substring-no-properties
              (line-beginning-position)
              (line-end-position))))))))

(defun ai-code--imenu-enrich-symbol-record (record)
  "Add line and declaration header metadata to Imenu symbol RECORD."
  (let* ((position (plist-get record :position))
         (pos (ai-code--imenu-symbol-position-number position)))
    (when pos
      (when-let* ((qualified (ignore-errors
                              (ai-code--imenu-treesit-qualified-name-at-position pos)))
                  ((ai-code--imenu-name-extends-p qualified (plist-get record :qualified))))
        (setq record (plist-put record :qualified qualified)))
      (setq record (plist-put record :line (line-number-at-pos pos)))
      (setq record
            (plist-put record :header
                       (ignore-errors
                         (ai-code--imenu-symbol-header-at-position
                          pos (plist-get record :name))))))
    record))

(defvar-local ai-code--imenu-index-tick nil
  "`buffer-chars-modified-tick' when ai-code last built the Imenu index.")

(defun ai-code--imenu-index ()
  "Return the current buffer's Imenu index, rescanning only after edits."
  (let* ((tick (buffer-chars-modified-tick))
         (imenu-auto-rescan (not (and imenu--index-alist
                                      (eql tick ai-code--imenu-index-tick))))
         (index (imenu--make-index-alist t)))
    (setq ai-code--imenu-index-tick tick)
    index))

(defun ai-code--file-symbol-records--imenu (buffer)
  "Return Imenu symbol records from BUFFER in source-definition order."
  (with-current-buffer buffer
    (save-excursion
      (save-restriction
        (widen)
        (condition-case nil
            (let* ((index (ai-code--imenu-index))
                   (records (ai-code--imenu-collect-symbol-records index)))
              (setq records (cl-stable-sort records #'ai-code--imenu-record-position-less-p))
              (mapcar #'ai-code--imenu-enrich-symbol-record records))
          (error nil))))))

(defun ai-code--file-symbol-candidates--imenu (buffer)
  "Return qualified Imenu symbol candidates from BUFFER in source order."
  (delete-dups
   (delq nil
         (mapcar (lambda (record) (plist-get record :qualified))
                 (ai-code--file-symbol-records--imenu buffer)))))

(defun ai-code--choose-symbol-annotation-alist (symbols-or-buffer)
  "Return completion annotations for SYMBOLS-OR-BUFFER.
SYMBOLS-OR-BUFFER is either a list of Imenu symbol records or a buffer.
Each result maps a qualified name to a declaration header and line number."
  (let ((records (if (bufferp symbols-or-buffer)
                     (ai-code--file-symbol-records--imenu symbols-or-buffer)
                   symbols-or-buffer)))
    (delq nil
          (mapcar
           (lambda (record)
             (when-let* ((qualified (plist-get record :qualified))
                         ((or (plist-get record :header)
                              (plist-get record :line))))
               (cons qualified
                     (format " %s  line %s"
                             (or (plist-get record :header) "")
                             (or (plist-get record :line) "")))))
           records))))

(defun ai-code--choose-symbol-from-file (file)
  "Prompt user to select a symbol from FILE and return it.
Symbol discovery always goes through Imenu.  Header and line metadata are
shown through `completion-extra-properties'."
  (when-let* ((buffer (ignore-errors (find-file-noselect file t)))
              (records (ai-code--file-symbol-records--imenu buffer)))
    (let* ((candidates
            (delete-dups
             (delq nil
                   (mapcar (lambda (record) (plist-get record :qualified))
                           records))))
           (annotation-alist
            (ai-code--choose-symbol-annotation-alist records)))
      (when candidates
        (let ((completion-extra-properties
               (when annotation-alist
                 (list :annotation-function
                       (lambda (candidate)
                         (cdr (assoc candidate annotation-alist)))))))
          (condition-case nil
              (completing-read
               "Symbol: "
               (lambda (string predicate action)
                 (if (eq action 'metadata)
                     '(metadata (display-sort-function . identity)
                                (cycle-sort-function . identity))
                   (complete-with-action action candidates string predicate)))
               nil nil)
            (quit nil)))))))

(defun ai-code--comment-filepath-capf ()
  "Provide completion candidates for @file paths inside comments."
  (when (and ai-code-prompt-filepath-completion-enabled
             (ai-code--comment-context-p)
             (buffer-file-name)
             (not (minibufferp))
             (ai-code--git-root))
    (let ((end (point))
          (start (save-excursion
                   (skip-chars-backward "A-Za-z0-9_./-")
                   (when (eq (char-before) ?@)
                     (1- (point))))))
      (when start
        (let ((candidates (ai-code--prompt-filepath-candidates)))
          (when candidates
            (list start end candidates :exclusive 'no)))))))

(defun ai-code--comment-auto-trigger-filepath-completion ()
  "Auto trigger file path/symbol completion in comments."
  (when (and ai-code-prompt-filepath-completion-enabled
             (ai-code--comment-context-p)
             (buffer-file-name)
             (not (minibufferp)))
    (pcase (char-before)
      (?@
       (let ((candidates (ai-code--prompt-filepath-candidates)))
         (when candidates
           (let ((choice (completing-read "File: " candidates nil nil)))
             (when (and choice (not (string-empty-p choice)))
               (delete-char -1)  ; Remove the '@' we just typed
               (insert choice))))))
      (?#
       (when-let* ((file (ai-code--hash-completion-target-file (1- (point))))
                   (symbol (ai-code--choose-symbol-from-file file)))
         (when (not (string-empty-p symbol))
           (delete-char -1)  ; Remove the '#' we just typed
          (insert "#" symbol)))))))

(defun ai-code--session-auto-trigger-filepath-completion ()
  "Auto trigger file path/symbol completion in AI session buffers."
  (when (and ai-code-prompt-filepath-completion-enabled
             (fboundp 'ai-code-backends-infra--session-buffer-p)
             (ai-code-backends-infra--session-buffer-p (current-buffer))
             (not (minibufferp))
             (ai-code--git-root))
    (pcase (char-before)
      (?@
       (let ((candidates (ai-code--prompt-filepath-candidates)))
         (when candidates
           (let ((choice (completing-read "File: " candidates nil nil)))
             (when (and choice (not (string-empty-p choice)))
               (ai-code-backends-infra--terminal-send-backspace)
               (ai-code-backends-infra--terminal-send-string choice))))))
      (?#
       (when-let* ((file (ai-code--hash-completion-target-file (1- (point))))
                   (symbol (ai-code--choose-symbol-from-file file)))
         (when (not (string-empty-p symbol))
           (ai-code-backends-infra--terminal-send-backspace)
           (ai-code-backends-infra--terminal-send-string (concat "#" symbol))))))))

(defun ai-code--session-handle-at-input ()
  "Handle '@' input in AI session buffers with optional filepath completion."
  (interactive)
  (let ((should-complete
         (and ai-code-prompt-filepath-completion-enabled
              (fboundp 'ai-code-backends-infra--session-buffer-p)
              (ai-code-backends-infra--session-buffer-p (current-buffer))
              (not (minibufferp))
              (ai-code--git-root))))
    (ai-code-backends-infra--terminal-send-string "@")
    (when should-complete
      (let ((candidates (ai-code--prompt-filepath-candidates)))
        (when candidates
          (let ((choice (condition-case nil
                            (completing-read "File: " candidates nil nil)
                          (quit nil))))
            (when (and choice (not (string-empty-p choice)))
              (ai-code-backends-infra--terminal-send-backspace)
              (ai-code-backends-infra--terminal-send-string choice))))))))

(defun ai-code--session-handle-hash-input ()
  "Handle '#' input in AI session buffers with optional symbol completion."
  (interactive)
  (let* ((should-complete
          (and ai-code-prompt-filepath-completion-enabled
               (fboundp 'ai-code-backends-infra--session-buffer-p)
               (ai-code-backends-infra--session-buffer-p (current-buffer))
               (not (minibufferp))
               (ai-code--git-root)))
         (file (and should-complete
                    (ai-code--hash-completion-target-file (point)))))
    (ai-code-backends-infra--terminal-send-string "#")
    (when-let* ((symbol (and file (ai-code--choose-symbol-from-file file))))
      (when (not (string-empty-p symbol))
        (ai-code-backends-infra--terminal-send-backspace)
        (ai-code-backends-infra--terminal-send-string (concat "#" symbol))))))

(defun ai-code--comment-filepath-setup ()
  "Ensure comment @ completion is available in the current buffer."
  (add-hook 'completion-at-point-functions #'ai-code--comment-filepath-capf nil t))

;;;###autoload
(define-minor-mode ai-code-prompt-filepath-completion-mode
  "Toggle @ file completion in comments and AI sessions across all buffers."
  :global t
  :group 'ai-code
  (setq ai-code-prompt-filepath-completion-enabled
        ai-code-prompt-filepath-completion-mode)
  (if ai-code-prompt-filepath-completion-mode
      (progn
        (add-hook 'post-self-insert-hook
                  #'ai-code--comment-auto-trigger-filepath-completion)
        (add-hook 'post-self-insert-hook
                  #'ai-code--session-auto-trigger-filepath-completion)
        (add-hook 'after-change-major-mode-hook #'ai-code--comment-filepath-setup)
        (dolist (buf (buffer-list))
          (with-current-buffer buf
            (ai-code--comment-filepath-setup))))
    (remove-hook 'post-self-insert-hook
                 #'ai-code--comment-auto-trigger-filepath-completion)
    (remove-hook 'post-self-insert-hook
                 #'ai-code--session-auto-trigger-filepath-completion)
    (remove-hook 'after-change-major-mode-hook #'ai-code--comment-filepath-setup)
    (dolist (buf (buffer-list))
      (with-current-buffer buf
        (remove-hook 'completion-at-point-functions
                     #'ai-code--comment-filepath-capf t)))))

;;;###autoload
(defun ai-code-toggle-filepath-completion ()
  "Toggle @ file completion in comments and AI sessions across all buffers."
  (interactive)
  (if ai-code-prompt-filepath-completion-mode
      (ai-code-prompt-filepath-completion-mode -1)
    (ai-code-prompt-filepath-completion-mode 1))
  (message "Filepath @ completion is %s"
           (if ai-code-prompt-filepath-completion-mode "enabled" "disabled")))

;; Keep @ filepath completion available out of the box.
(unless ai-code-prompt-filepath-completion-mode
  (ai-code-prompt-filepath-completion-mode 1))

;;; Code Link Navigation

(defconst ai-code--session-link-file-base-regexp
  "@?[[:alnum:]_./~-]*[./][[:alnum:]_./~-]+"
  "Regexp matching the base path portion of a session file link.")

(defconst ai-code--session-link-file-regexp
  (concat ai-code--session-link-file-base-regexp
          "\\(?:"
          ":[0-9]+:[0-9]+"
          "\\|:[0-9]+"
          "\\|:L[0-9]+\\(?:-[0-9]+\\)?"
          "\\|#[Ll][0-9]+\\(?:-[Ll]?[0-9]+\\)?"
          "\\|([0-9]+\\(?:,[0-9]+\\)?)"
          "\\)?")
  "Regexp matching clickable file-like session links.")

(defconst ai-code--session-link-url-regexp
  "https?://[^][\"'`()<>[:space:]]+"
  "Regexp matching clickable http/https session links.")

(defconst ai-code--session-clickable-link-regexp
  (concat "\\(?:" ai-code--session-link-url-regexp
          "\\)\\|\\(?:" ai-code--session-link-file-regexp
          "\\)")
  "Regexp matching file and URL links in session buffers.")

(defun ai-code--session-link-property-at-point ()
  "Return the clickable session link text at point, or nil."
  (or (get-text-property (point) 'ai-code-session-link)
      (when (not (bobp))
        (get-text-property (1- (point)) 'ai-code-session-link))))

(defun ai-code--session-link-bounds-at-point ()
  "Return bounds of the clickable session link at point, or nil."
  (if-let* ((text (ai-code--session-link-property-at-point)))
      (let* ((prop-pos (if (get-text-property (point) 'ai-code-session-link)
                           (point)
                         (1- (point))))
             (start (or (previous-single-property-change
                         (1+ prop-pos) 'ai-code-session-link nil (point-min))
                        (point-min)))
             (end (or (next-single-property-change
                       prop-pos 'ai-code-session-link nil (point-max))
                      (point-max))))
        (when (equal (buffer-substring-no-properties start end) text)
          (cons start end)))
    (let ((point (point))
          (line-start (line-beginning-position))
          (line-end (line-end-position))
          bounds)
      (save-excursion
        (goto-char line-start)
        (while (and (not bounds)
                    (re-search-forward ai-code--session-clickable-link-regexp line-end t))
          (when (and (<= (match-beginning 0) point)
                     (<= point (match-end 0)))
            (setq bounds (cons (match-beginning 0) (match-end 0))))))
      bounds)))

(defun ai-code--session-link-text-at-point ()
  "Return the clickable session link text at point, or nil."
  (or (ai-code--session-link-property-at-point)
      (when-let* ((bounds (ai-code--session-link-bounds-at-point)))
        (buffer-substring-no-properties (car bounds) (cdr bounds)))))

(defun ai-code--parse-session-link (text)
  "Parse TEXT as a session link and return a plist."
  (when (and text (not (string-empty-p (string-trim text))))
    (cond
     ((string-match-p "\\`https?://" text)
      (list :url text))
     ((string-match "^\\(.*?\\):\\([0-9]+\\):\\([0-9]+\\)$" text)
      (list :file (match-string 1 text)
            :line-start (string-to-number (match-string 2 text))
            :column-start (string-to-number (match-string 3 text))))
     ((string-match "^\\(.*\\)#[Ll]\\([0-9]+\\)-[Ll]?\\([0-9]+\\)$" text)
      (list :file (match-string 1 text)
            :line-start (string-to-number (match-string 2 text))))
     ((string-match "^\\(.*\\)#[Ll]\\([0-9]+\\)$" text)
      (list :file (match-string 1 text)
            :line-start (string-to-number (match-string 2 text))))
     ((string-match "^\\(.*\\)(\\([0-9]+\\),\\([0-9]+\\))$" text)
      (list :file (match-string 1 text)
            :line-start (string-to-number (match-string 2 text))
            :column-start (string-to-number (match-string 3 text))))
     ((string-match "^\\(.*\\)(\\([0-9]+\\))$" text)
      (list :file (match-string 1 text)
            :line-start (string-to-number (match-string 2 text))))
     ((string-match "^\\(.*\\):L\\([0-9]+\\)-\\([0-9]+\\)$" text)
      (list :file (match-string 1 text)
            :line-start (string-to-number (match-string 2 text))))
     ((string-match "^\\(.*\\):L\\([0-9]+\\)$" text)
      (list :file (match-string 1 text)
            :line-start (string-to-number (match-string 2 text))))
     ((string-match "^\\(.*?\\):\\([0-9]+\\)\\(?:-\\([0-9]+\\)\\)?$" text)
      (list :file (match-string 1 text)
            :line-start (string-to-number (match-string 2 text))))
     ((string-match-p "[./]" text)
      (list :file text))
     (t nil))))


(defun ai-code--project-file-candidates (filename)
  "Return possible project file matches for FILENAME."
  (when-let* ((raw filename)
              (filename (ai-code-session-link--normalize-file raw))
              ((not (string-empty-p filename))))
    (let* ((root (ai-code--session-project-root))
           (project-files (ai-code-session-link--project-files root))
           (exact-root (expand-file-name filename root))
           (exact-default (expand-file-name filename default-directory))
           (matches
            (append
             (when (and (file-name-absolute-p filename) (file-exists-p filename))
               (list filename))
             (when (file-exists-p exact-root)
               (list exact-root))
             (when (file-exists-p exact-default)
               (list exact-default))
             (ai-code-session-link--matching-project-files
              filename root project-files))))
      (delete-dups matches))))

(defun ai-code--read-session-link-candidate (prompt candidates)
  "Read one item from CANDIDATES using PROMPT."
  (let* ((choices (delete-dups (copy-sequence candidates)))
         (default (car choices)))
    (when choices
      (completing-read prompt choices nil t nil nil default))))

(defun ai-code--existing-absolute-session-path (filename)
  "Return an existing absolute local path for FILENAME, or nil."
  (when-let* ((normalized (ai-code-session-link--normalize-file filename)))
    (when (file-name-absolute-p normalized)
      (ai-code-session-link--resolve-existing-local-path normalized nil))))

(defun ai-code--find-project-file (filename)
  "Locate FILENAME within the current project."
  (or (ai-code--existing-absolute-session-path filename)
        (when-let* ((candidates (ai-code--project-file-candidates filename)))
          (if (= (length candidates) 1)
              (car candidates)
            (ai-code--read-session-link-candidate
             (format "Choose file for %s: " filename)
             candidates)))))

(defun ai-code-session-navigate-link-at-mouse (event)
  "Navigate to the session link clicked by mouse EVENT."
  (interactive "e")
  (let* ((start (event-start event))
         (window (posn-window start))
         (position (posn-point start)))
    (when (window-live-p window)
      (select-window window)
      (when (integer-or-marker-p position)
        (goto-char position)
        (ai-code-session-navigate-link-at-point)))))

(defun ai-code--session-image-link-file-at-point (text)
  "Return the resolved image file for session link TEXT at point."
  (and text
       (ai-code-session-link--image-preview-link-file text)))

(defun ai-code--open-session-link-file (text link &optional resolved-file)
  "Open the file described by LINK for session link TEXT.
Optional RESOLVED-FILE is an existing absolute file path to open directly."
  (when-let* ((file (plist-get link :file))
              (abs-file (or resolved-file
                            (ai-code--find-project-file file))))
    (find-file-other-window abs-file)
    (when-let* ((line-start (plist-get link :line-start)))
      (goto-char (point-min))
      (forward-line (1- line-start))
      (when-let* ((column-start (plist-get link :column-start)))
        (when (> column-start 0)
          (move-to-column (1- column-start)))))
    (message "Navigated to %s" text)
    t))

;;;###autoload
(defun ai-code-session-navigate-link-at-point ()
  "Navigate to the file or URL session link at point."
  (interactive)
  (let* ((text (ai-code--session-link-text-at-point))
         (link (and text (ai-code--parse-session-link text)))
         (image-file
          (and link
               (ai-code--session-image-link-file-at-point text))))
    (cond
     ((not link)
      (message "No code link found at point"))
     ((when-let* ((url (plist-get link :url)))
        (browse-url url)
        (message "Opened URL: %s" url)
        t))
     ((ai-code--open-session-link-file text link image-file))
     (t
      (message "No code link found at point")))))

(provide 'ai-code-input)

;;; ai-code-input.el ends here
