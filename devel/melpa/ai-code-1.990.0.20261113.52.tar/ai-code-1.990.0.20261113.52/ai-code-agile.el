;;; ai-code-agile.el --- Agile practices operations for AI Code Interface -*- lexical-binding: t; -*-

;; Author: Kang Tu <tninja@gmail.com>
;; SPDX-License-Identifier: Apache-2.0

;;; Commentary:
;; This file provides agile practice operations such as refactoring and TDD cycle
;; for the AI Code Interface package.  Migrated from aider-agile.el.

;;; Code:

(defvar ai-code--harness-loading)

(require 'ai-code-input)
(require 'ai-code-magit)
(require 'ai-code-prompt-mode)
(require 'ai-code-session)
(let ((ai-code--harness-loading t))
  (require 'ai-code-change))
(require 'subr-x)
(require 'thingatpt)
(require 'which-func)

(declare-function ai-code--insert-prompt "ai-code-prompt-mode"
                  (prompt-text &optional send-function))
(declare-function ai-code--compose-code-change-brief
                  "ai-code-change" (&rest plist))
(declare-function ai-code--get-context-files-string "ai-code-utils")
(declare-function ai-code--current-line-scope-context "ai-code-utils" ())
(declare-function ai-code--scope-context-for-region "ai-code-utils" (beg end))
(declare-function ai-code--format-scope-context "ai-code-utils" (context))
(declare-function ai-code--git-root "ai-code-utils" (&optional dir))
(declare-function magit-get-current-branch "magit-git" ())
(declare-function magit-git-string "magit-git" (&rest args))
(declare-function magit-rev-verify "magit-git" (&rest args))
(declare-function ai-code-derive-topic-unit-tests "ai-code-doc" ())
(declare-function dired-current-directory "dired" ())

(defvar ai-code-change--generic-note)

(defconst ai-code--refactoring-techniques-catalog
  '((:name "Suggest Refactoring Strategy"
           :scopes (region global)
           :description "Let the LLM analyze the context and suggest the best refactoring technique.")
    (:name "Value-driven Simplification"
           :scopes (region global)
           :description "Discuss which complexity is worth keeping, guided by business value.")
    (:name "Extract Method"
           :scopes (region global)
           :description "Extract the selected code into a new method named [METHOD_NAME]. Identify parameters and return values needed, and place the new method in an appropriate location."
           :parameters ((:placeholder "[METHOD_NAME]"
                         :prompt "New method name: "
                         :default-fn ai-code--refactoring--method-candidate)))
    (:name "Extract Variable"
           :scopes (region global)
           :description "Replace this complex expression with a well-named variable [VARIABLE_NAME]. Choose a name that clearly explains the expression's purpose."
           :parameters ((:placeholder "[VARIABLE_NAME]"
                         :prompt "New variable name: "
                         :default-fn ai-code--refactoring--symbol-candidate)))
    (:name "Extract Parameter"
           :scopes (region global)
           :description "Extract this expression into a new parameter named [PARAMETER_NAME] for the containing function. Update all call sites to pass this value as an argument."
           :parameters ((:placeholder "[PARAMETER_NAME]"
                         :prompt "New parameter name: "
                         :default-fn ai-code--refactoring--symbol-candidate)))
    (:name "Extract Field"
           :scopes (region global)
           :description "Extract this expression into a class field named [FIELD_NAME]. Initialize the field appropriately and replace the expression with a reference to the field."
           :parameters ((:placeholder "[FIELD_NAME]"
                         :prompt "New field name: "
                         :default-fn ai-code--refactoring--symbol-candidate)))
    (:name "Decompose Conditional"
           :scopes (region global)
           :description "Break down this complex conditional into smaller, more readable pieces. Extract conditions and branches into well-named methods that express the high-level logic.")
    (:name "Replace Nested Conditional with Guard Clauses"
           :scopes (region global)
           :description "Simplify nested conditional logic by using guard clauses. Check for edge cases or simple conditions first and return early.")
    (:name "Replace Magic Number with Symbolic Constant"
           :scopes (region global)
           :description "Replace the selected magic number or string literal with a well-named constant [CONSTANT_NAME]. Define the constant appropriately."
           :parameters ((:placeholder "[CONSTANT_NAME]"
                         :prompt "Constant name: ")))
    (:name "Introduce Assertion"
           :scopes (region global)
           :description "Add an assertion to document an assumption about the program state. Specify the condition to assert [ASSERTION_CONDITION]."
           :parameters ((:placeholder "[ASSERTION_CONDITION]"
                         :prompt "Assertion condition: ")))
    (:name "Consolidate Conditional Expression"
           :scopes (region global)
           :description "Combine multiple conditional checks that lead to the same result into a single, clearer conditional expression.")
    (:name "Inline Method"
           :scopes (region global)
           :description "Replace calls to method [METHOD_NAME] with its body. Ensure the inlining doesn't change behavior or introduce bugs, and remove the original method if it's no longer needed."
           :parameters ((:placeholder "[METHOD_NAME]"
                         :prompt "Method to inline: "
                         :default-fn ai-code--refactoring--method-candidate)))
    (:name "Inline Variable"
           :scopes (region global)
           :description "Replace all references to variable [VARIABLE_NAME] with its value. Ensure the inlining doesn't change behavior or introduce bugs."
           :parameters ((:placeholder "[VARIABLE_NAME]"
                         :prompt "Variable to inline: "
                         :default-fn ai-code--refactoring--symbol-candidate)))
    (:name "Inline Temp"
           :scopes (region global)
           :description "Replace a temporary variable that is assigned once with its expression to simplify the code.")
    (:name "Replace Temp with Query"
           :scopes (region global)
           :description "Replace temporary variables that simply hold calculation results with self-explanatory query methods.")
    (:name "Introduce Explaining Variable"
           :scopes (region global)
           :description "Introduce a well-named variable to clarify a complex expression and improve readability.")
    (:name "Split Temporary Variable"
           :scopes (region global)
           :description "Split a temporary variable that is assigned multiple times into separate variables for each responsibility.")
    (:name "Remove Assignments to Parameters"
           :scopes (region global)
           :description "Avoid reassigning parameters inside a method; instead, use local variables to preserve intent.")
    (:name "Replace Method with Method Object"
           :scopes (region global)
           :description "Turn a complex method into its own object to break down temporary variables and simplify logic.")
    (:name "Substitute Algorithm"
           :scopes (region global)
           :description "Replace an existing algorithm with a clearer or more efficient one while keeping behavior intact.")
    (:name "Move Method"
           :scopes (region global)
           :description "Move method [METHOD_NAME] to class [TARGET_CLASS]. Update all references to use the new location and consider creating a delegation if needed."
           :parameters ((:placeholder "[METHOD_NAME]"
                         :prompt "Method to move: "
                         :default-fn ai-code--refactoring--method-candidate)
                        (:placeholder "[TARGET_CLASS]"
                         :prompt "Target class: ")))
    (:name "Move Field"
           :scopes (region global)
           :description "Relocate a field to the class that makes the most sense for ownership. Update access points and encapsulate if needed.")
    (:name "Extract Class"
           :scopes (region global)
           :description "Extract related fields and methods into a new class named [NEW_CLASS_NAME]. Update the original class to use the new class."
           :parameters ((:placeholder "[NEW_CLASS_NAME]"
                         :prompt "New class name: ")))
    (:name "Inline Class"
           :scopes (region global)
           :description "Merge a class whose responsibilities are too small back into its parent, updating all references.")
    (:name "Hide Delegate"
           :scopes (region global)
           :description "Remove delegation leakage by adding wrapper methods so clients only talk to the main object.")
    (:name "Remove Middle Man"
           :scopes (region global)
           :description "Eliminate unnecessary delegation wrappers and let clients access the related object directly.")
    (:name "Introduce Foreign Method"
           :scopes (region global)
           :description "Add helper methods in client code when you cannot modify the server class to host the logic.")
    (:name "Introduce Local Extension"
           :scopes (region global)
           :description "Extend third-party classes locally via wrappers or subclasses to add behavior safely.")
    (:name "Encapsulate Field"
           :scopes (region global)
           :description "Make the field [FIELD_NAME] private and provide public getter and setter methods for access. Update all direct accesses to use these methods."
           :parameters ((:placeholder "[FIELD_NAME]"
                         :prompt "Field to encapsulate: "
                         :default-fn ai-code--refactoring--symbol-candidate)))
    (:name "Self Encapsulate Field"
           :scopes (region global)
           :description "Access a field through getter and setter methods even inside its own class to simplify future changes.")
    (:name "Replace Data Value with Object"
           :scopes (region global)
           :description "Turn a simple data value into a dedicated object to better express behavior and constraints.")
    (:name "Change Value to Reference"
           :scopes (region global)
           :description "Convert a value object into a shared reference when identity and shared state become important.")
    (:name "Change Reference to Value"
           :scopes (region global)
           :description "Convert a reference object into an immutable value when sharing state is unnecessary.")
    (:name "Replace Array with Object"
           :scopes (region global)
           :description "Replace arrays that mix different kinds of data with well-named objects and fields.")
    (:name "Duplicate Observed Data"
           :scopes (region global)
           :description "Maintain local copies of observed data so domain logic can work without tight coupling to the observer.")
    (:name "Change Unidirectional Association to Bidirectional"
           :scopes (region global)
           :description "Introduce links in both directions when objects need to navigate to each other.")
    (:name "Change Bidirectional Association to Unidirectional"
           :scopes (region global)
           :description "Remove unnecessary reverse links when only one-way navigation is required.")
    (:name "Encapsulate Collection"
           :scopes (region global)
           :description "Ensure collection fields return read-only views and expose modifier methods to protect invariants.")
    (:name "Replace Type Code with Class"
           :scopes (region global)
           :description "Replace primitive type codes with dedicated classes to capture behavior and validation.")
    (:name "Replace Type Code with Subclasses"
           :scopes (region global)
           :description "Substitute type codes with subclasses to leverage polymorphism for specialized behavior.")
    (:name "Replace Type Code with State/Strategy"
           :scopes (region global)
           :description "Transform a type code into State or Strategy objects to vary behavior dynamically.")
    (:name "Replace Subclass with Fields"
           :scopes (region global)
           :description "Flatten simple subclasses by replacing them with fields when inheritance no longer adds value.")
    (:name "Consolidate Duplicate Conditional Fragments"
           :scopes (region global)
           :description "Move repeated code inside conditionals to a single location executed in all paths.")
    (:name "Remove Control Flag"
           :scopes (region global)
           :description "Eliminate control flags by using `return`, `break`, or `continue` to control flow more directly.")
    (:name "Introduce Null Object"
           :scopes (region global)
           :description "Introduce a null object that encapsulates the default do-nothing behavior instead of handling null checks.")
    (:name "Rename Variable/Method"
           :scopes (region global)
           :description "Rename [CURRENT_NAME] to [NEW_NAME]. Ensure all references are updated consistently following naming conventions appropriate for this codebase."
           :parameters ((:placeholder "[CURRENT_NAME]"
                         :prompt "Current name: "
                         :default-fn ai-code--refactoring--symbol-candidate)
                        (:placeholder "[NEW_NAME]"
                         :prompt-fn ai-code--refactoring--rename-new-name-prompt)))
    (:name "Change Method Signature"
           :scopes (region global)
           :description "Update method [METHOD_NAME] signature to [NEW_SIGNATURE]. Adjust all call sites, documentation, and overloads to match the new contract."
           :parameters ((:placeholder "[METHOD_NAME]"
                         :prompt "Method to change signature: "
                         :default-fn ai-code--refactoring--method-candidate)
                        (:placeholder "[NEW_SIGNATURE]"
                         :prompt "Describe the new signature (parameters, return type, etc.): ")))
    (:name "Introduce Constant"
           :scopes (region global)
           :description "Introduce a named constant [CONSTANT_NAME] for the selected literal or expression, choose the proper scope, and replace relevant usages."
           :parameters ((:placeholder "[CONSTANT_NAME]"
                         :prompt "Constant name: "
                         :default-fn ai-code--refactoring--symbol-candidate)))
    (:name "Introduce Field"
           :scopes (region global)
           :description "Promote the selected value to a class field named [FIELD_NAME], decide initialization timing, and replace repeated computations."
           :parameters ((:placeholder "[FIELD_NAME]"
                         :prompt "Introduced field name: "
                         :default-fn ai-code--refactoring--symbol-candidate)))
    (:name "Introduce Property"
           :scopes (region global)
           :description "Wrap field [FIELD_NAME] with a property named [PROPERTY_NAME], generating accessor logic that follows project conventions."
           :parameters ((:placeholder "[FIELD_NAME]"
                         :prompt "Existing field to wrap: "
                         :default-fn ai-code--refactoring--symbol-candidate)
                        (:placeholder "[PROPERTY_NAME]"
                         :prompt "Property name: "
                         :default-fn ai-code--refactoring--symbol-candidate)))
    (:name "Safe Delete"
           :scopes (region global)
           :description "Remove [ELEMENT_NAME] only after verifying there are no remaining usages. Update dependent code or tests to keep the project consistent."
           :parameters ((:placeholder "[ELEMENT_NAME]"
                         :prompt "Element to delete safely: "
                         :default-fn ai-code--refactoring--symbol-candidate)))
    (:name "Convert Anonymous Class to Lambda"
           :scopes (region global)
           :description "Convert the selected anonymous class implementing [INTERFACE_NAME] into an equivalent lambda expression or method reference if the language supports it."
           :parameters ((:placeholder "[INTERFACE_NAME]"
                         :prompt "Functional interface or delegate type: "
                         :default-fn ai-code--refactoring--symbol-candidate)))
    (:name "Add Parameter"
           :scopes (region global)
           :description "Add a new parameter to a method to supply the data it actually needs, updating all callers.")
    (:name "Remove Parameter"
           :scopes (region global)
           :description "Eliminate a parameter that is no longer used and update all callers accordingly.")
    (:name "Separate Query from Modifier"
           :scopes (region global)
           :description "Split a method that both queries and alters state into two methods with single responsibilities.")
    (:name "Parameterize Method"
           :scopes (region global)
           :description "Turn similar methods that differ only in values into a single method that accepts parameters for the variation.")
    (:name "Replace Parameter with Explicit Methods"
           :scopes (region global)
           :description "Replace a parameter that selects different behaviors with explicitly named methods for each case.")
    (:name "Preserve Whole Object"
           :scopes (region global)
           :description "Pass the entire object to a method instead of individual fields so related data travels together.")
    (:name "Replace Parameter with Method"
           :scopes (region global)
           :description "Remove parameters that can be derived inside the method and call helper queries instead.")
    (:name "Introduce Parameter Object"
           :scopes (region global)
           :description "Replace these related parameters with a single parameter object named [OBJECT_NAME]. Create an appropriate class for the parameter object."
           :parameters ((:placeholder "[OBJECT_NAME]"
                         :prompt "Parameter object name: ")))
    (:name "Remove Setting Method"
           :scopes (region global)
           :description "Eliminate setter methods for fields that should be immutable after construction.")
    (:name "Hide Method"
           :scopes (region global)
           :description "Reduce the visibility of methods that are only intended for internal use.")
    (:name "Replace Constructor with Factory Method"
           :scopes (region global)
           :description "Wrap object creation in a factory method when more descriptive names or varied creation logic is required.")
    (:name "Replace Error Code with Exception"
           :scopes (region global)
           :description "Throw an exception instead of returning an error code to signal failure states.")
    (:name "Replace Exception with Test"
           :scopes (region global)
           :description "Perform explicit checks before performing work to avoid using exceptions for normal control flow.")
    (:name "Pull Up Method"
           :scopes (region global)
           :description "Move method [METHOD_NAME] from the current class to its superclass [SUPERCLASS_NAME]. Ensure the method is applicable to the superclass context."
           :parameters ((:placeholder "[METHOD_NAME]"
                         :prompt "Method to pull up: "
                         :default-fn ai-code--refactoring--method-candidate)
                        (:placeholder "[SUPERCLASS_NAME]"
                         :prompt "Superclass name: ")))
    (:name "Pull Up Field"
           :scopes (region global)
           :description "Move common fields from subclasses into the superclass to centralize shared state.")
    (:name "Pull Up Constructor Body"
           :scopes (region global)
           :description "Move duplicated constructor logic from subclasses into the superclass constructor.")
    (:name "Push Down Method"
           :scopes (region global)
           :description "Move method [METHOD_NAME] from the current class to specific subclass(es) [SUBCLASS_NAMES] where it is actually used."
           :parameters ((:placeholder "[METHOD_NAME]"
                         :prompt "Method to push down: "
                         :default-fn ai-code--refactoring--method-candidate)
                        (:placeholder "[SUBCLASS_NAMES]"
                         :prompt "Comma-separated subclass names: ")))
    (:name "Push Down Field"
           :scopes (region global)
           :description "Move fields that are only used in some subclasses down into those specific subclasses.")
    (:name "Extract Subclass"
           :scopes (region global)
           :description "Create a new subclass when a class has behavior or data used only in some instances.")
    (:name "Extract Superclass"
           :scopes (region global)
           :description "Factor out common behavior or data into a new superclass shared by multiple classes.")
    (:name "Extract Interface"
           :scopes (region global)
           :description "Introduce an interface to capture common protocol without sharing implementation.")
    (:name "Collapse Hierarchy"
           :scopes (region global)
           :description "Flatten inheritance when subclass and superclass differ too little to justify separation.")
    (:name "Form Template Method"
           :scopes (region global)
           :description "Create a template method in a superclass to outline an algorithm while subclasses fill in the steps.")
    (:name "Replace Inheritance with Delegation"
           :scopes (region global)
           :description "Swap inheritance for delegation when only part of the behavior should be reused.")
    (:name "Replace Delegation with Inheritance"
           :scopes (region global)
           :description "Simplify a delegation chain by adopting inheritance when the relationship is truly is-a.")
    (:name "Tease Apart Inheritance"
           :scopes (global)
           :description "Separate intertwined inheritance hierarchies so each hierarchy represents a single responsibility.")
    (:name "Convert Procedural Design to Objects"
           :scopes (global)
           :description "Restructure procedural code into cohesive objects that encapsulate data and behavior.")
    (:name "Separate Domain from Presentation"
           :scopes (global)
           :description "Split domain logic from UI or presentation concerns to improve testability and reuse.")
    (:name "Extract Hierarchy"
           :scopes (global)
           :description "Introduce a new hierarchy to clarify different responsibilities and support future extension."))
  "Catalog of refactoring techniques curated from Martin Fowler's \"Refactoring\".")

(defconst ai-code--refactoring-suggestion-default-instruction
  "Analyze the code context below. Identify potential refactoring opportunities (e.g., complexity, duplication, clarity) and make the code easy to understand. Do not change code logic. Suggest the most impactful refactoring technique and explain why."
  "Default instruction for refactoring suggestion prompts.")

(defconst ai-code--refactoring-suggestion-default-label
  "General refactoring analysis"
  "Default short description for refactoring suggestion prompts.")

(defconst ai-code--refactoring-suggestion-presets
  `((,ai-code--refactoring-suggestion-default-label . ,ai-code--refactoring-suggestion-default-instruction)
    ("Improve readability and testability" . "Analyze the code context below. Focus on making the code easier to understand, improving readability, and increasing testability. Do not change code logic. Suggest the most impactful refactoring technique and explain why.")
    ("Reduce complexity" . "Analyze the code context below. Focus on reducing complexity and simplifying control flow. Do not change code logic. Suggest the most impactful refactoring technique and explain why.")
    ("Remove duplication" . "Analyze the code context below. Focus on removing duplication and consolidating repeated logic. Do not change code logic. Suggest the most impactful refactoring technique and explain why.")
    ("Clarify naming and responsibilities" . "Analyze the code context below. Focus on clarifying naming and separating responsibilities more cleanly. Do not change code logic. Suggest the most impactful refactoring technique and explain why."))
  "Preset refactoring suggestion prompts keyed by short description.")

(defun ai-code--read-refactoring-suggestion-instruction ()
  "Read a refactoring suggestion instruction with editable completion."
  (let* ((selected-description
          (completing-read "Select refactoring goal: "
                           (mapcar #'car ai-code--refactoring-suggestion-presets)
                           nil t nil nil ai-code--refactoring-suggestion-default-label))
         (default-instruction
          (or (cdr (assoc selected-description ai-code--refactoring-suggestion-presets))
              ai-code--refactoring-suggestion-default-instruction)))
    (ai-code-read-string "Edit suggestion request: " default-instruction)))

(defun ai-code--refactoring--ensure-string (value)
  "Return VALUE coerced to a string when appropriate."
  (cond
   ((null value) "")
   ((stringp value) value)
   ((symbolp value) (symbol-name value))
   (t (format "%s" value))))

(defun ai-code--refactoring--method-candidate (context _values)
  "Suggest a method name based on CONTEXT or point."
  (ai-code--refactoring--ensure-string
   (or (plist-get context :current-function)
       (thing-at-point 'symbol t))))

(defun ai-code--refactoring--symbol-candidate (_context _values)
  "Suggest a symbol name at point."
  (ai-code--refactoring--ensure-string
   (thing-at-point 'symbol t)))

(defun ai-code--refactoring--find-technique (technique-name)
  "Find technique entry in catalog by TECHNIQUE-NAME."
  (catch 'found
    (dolist (entry ai-code--refactoring-techniques-catalog nil)
      (when (string= technique-name (plist-get entry :name))
        (throw 'found entry)))))

(defun ai-code--refactoring--get-placeholder (values placeholder)
  "Retrieve previously captured PLACEHOLDER value from VALUES."
  (cdr (assoc placeholder values)))

(defun ai-code--refactoring--rename-new-name-prompt (_context values _default)
  "Build prompt for rename using VALUES."
  (let ((current (ai-code--refactoring--get-placeholder values "[CURRENT_NAME]")))
    (if current
        (format "Rename '%s' to: " current)
      "New name: ")))

(defun ai-code--refactoring--resolve-parameter (spec context values)
  "Resolve parameter value defined by SPEC using CONTEXT and VALUES."
  (let* ((value-fn (plist-get spec :value-fn))
         (value (if value-fn
                    (funcall value-fn context values)
                  (let* ((default (ai-code--refactoring--ensure-string
                                   (let ((default-fn (plist-get spec :default-fn)))
                                     (if default-fn
                                         (funcall default-fn context values)
                                       (plist-get spec :default)))))
                         (raw-prompt (let ((prompt-fn (plist-get spec :prompt-fn)))
                                       (cond
                                        (prompt-fn (funcall prompt-fn context values default))
                                        ((plist-get spec :prompt) (plist-get spec :prompt))
                                        (t nil))))
                         (prompt (if raw-prompt
                                     (concat raw-prompt "(leave empty or type 'default' for AI to decide) ")
                                   nil))
                         (user-input (if prompt
                                         (ai-code-read-string prompt "default")
                                       "default")))
                    (if (or (null user-input)
                            (string= "" user-input)
                            (string= "default" user-input))
                        ""
                      user-input)))))
    (ai-code--refactoring--ensure-string value)))

(defun ai-code--refactoring-targets-git-root (targets)
  "Return Git root for refactoring TARGETS or current directory."
  (or (ai-code--git-root (car targets))
      (ai-code--git-root default-directory)))

(defun ai-code--get-refactoring-context ()
  "Get the current context for refactoring."
  (let* ((dired-targets (when (derived-mode-p 'dired-mode)
                        (or (plist-get (ai-code--dired-context) :files)
                            (user-error "No file or directory selected in Dired"))))
         (region-active (and (not dired-targets) (region-active-p)))
         (scope-context (unless dired-targets
                          (if region-active
                              (ai-code--scope-context-for-region
                               (region-beginning) (region-end))
                            (ai-code--current-line-scope-context))))
         (current-function (plist-get scope-context :function-name))
         (semantic-scope (unless dired-targets
                           (ai-code--format-scope-context scope-context)))
         (file-name (unless dired-targets
                      (when buffer-file-name
                        (file-name-nondirectory buffer-file-name)))))
    (list :region-active region-active
          :region-text (when region-active
                         (buffer-substring-no-properties (region-beginning) (region-end)))
          :current-function current-function
          :semantic-scope semantic-scope
          :file-name file-name
          :dired-targets dired-targets
          :context-description (cond
                                (dired-targets
                                 (if (= (length dired-targets) 1)
                                     (format "for '%s'"
                                             (file-name-nondirectory
                                              (directory-file-name (car dired-targets))))
                                   "for selected files/directories"))
                                (current-function (format "in function '%s'" current-function))
                                (file-name (format "in file '%s'" file-name))
                                (t "in current context")))))

(defun ai-code--refactoring-context-files-string (context)
  "Return a refactoring file context string for CONTEXT.
Uses @-prefixed Git-relative paths when a Git root is available,
otherwise falls back to absolute paths."
  (let ((dired-targets (plist-get context :dired-targets)))
    (if dired-targets
        (let* ((git-root (ai-code--refactoring-targets-git-root dired-targets))
               (paths (mapcar (lambda (path)
                                (if git-root
                                    (concat "@" (file-relative-name path git-root))
                                  path))
                              dired-targets)))
          (concat "\nFiles:\n" (mapconcat #'identity paths "\n")))
      (ai-code--get-context-files-string))))

(defconst ai-code--refactoring-code-change-boundaries
  (concat
   "Preserve existing behavior. Make only the requested refactoring. "
   "Avoid unrelated cleanup, feature changes, or broad rewrites.")
  "Boundaries for structured refactoring code-change briefs.")

(defun ai-code--agile-current-scope-string (&optional function-name file-info)
  "Return scope text for current agile prompt.
FUNCTION-NAME is the current function when available.
FILE-INFO is additional visible-file context."
  (let* ((scope-context
          (if (region-active-p)
              (ai-code--scope-context-for-region
               (region-beginning) (region-end))
            (ai-code--current-line-scope-context)))
         (semantic-scope (ai-code--format-scope-context scope-context)))
    (concat
     (if buffer-file-name
         (format "Current file: %s" buffer-file-name)
       (format "Current buffer: %s" (buffer-name)))
     (cond
      ((not (string-empty-p semantic-scope)) (concat "\n" semantic-scope))
      (function-name (format "\nFunction: %s" function-name)))
     file-info)))

(defun ai-code--refactoring-scope-string (context file-info)
  "Return structured scope text for refactoring CONTEXT and FILE-INFO."
  (let ((region-active (plist-get context :region-active))
        (region-text (plist-get context :region-text))
        (current-function (plist-get context :current-function))
        (semantic-scope (plist-get context :semantic-scope))
        (dired-targets (plist-get context :dired-targets))
        (context-description (plist-get context :context-description))
        (file-name (plist-get context :file-name)))
    (concat
     (cond
      (dired-targets
       (concat "Selected files/directories:\n"
               (mapconcat #'identity dired-targets "\n")))
      (buffer-file-name
       (format "Current file: %s" buffer-file-name))
      (file-name
       (format "Current file: %s" file-name))
      (t
       (format "Current buffer: %s" (buffer-name))))
     (when context-description
       (format "\nRefactoring context: %s" context-description))
     (cond
      ((and semantic-scope (not (string-empty-p semantic-scope)))
       (concat "\n" semantic-scope))
      (current-function (format "\nFunction: %s" current-function)))
     (when region-active
       (format "\nSelected code:\n%s" region-text))
     file-info)))

(defun ai-code--get-refactoring-techniques (region-active)
  "Return appropriate refactoring techniques based on REGION-ACTIVE."
  (let ((scope (if region-active 'region 'global))
        (result nil))
    (dolist (entry ai-code--refactoring-techniques-catalog (nreverse result))
      (when (memq scope (plist-get entry :scopes))
        (push (cons (plist-get entry :name)
                    (plist-get entry :description))
              result)))))

(defun ai-code--process-refactoring-parameters (selected-technique technique-description context)
  "Process parameters for SELECTED-TECHNIQUE using CONTEXT.
TECHNIQUE-DESCRIPTION is the base prompt text."
  (let* ((entry (ai-code--refactoring--find-technique selected-technique))
         (parameters (plist-get entry :parameters))
         (final-description technique-description)
         (values nil))
    ;; First, resolve all parameter values and store them.
    (dolist (spec parameters)
      (let* ((placeholder (plist-get spec :placeholder))
             (value (ai-code--refactoring--resolve-parameter spec context values)))
        (when placeholder
          (push (cons placeholder value) values))))

    ;; Second, iterate through the resolved values and perform substitutions.
    ;; Process in reverse order of parameter definition.
    ;; Rationale: If a placeholder is a substring of another, or if the prompt contains
    ;; optional clauses (e.g., "to <target> with <modifier>"), substituting in forward order
    ;; can cause incorrect replacements or leave behind awkward text when a placeholder is empty.
    ;; For example, given the prompt "Rename <entity> to <target> with <modifier>", if <target>
    ;; is empty and we process <entity> first, we might replace <entity> and then be left with
    ;; "Rename foo to  with <modifier>", making it harder to cleanly remove "to ".
    ;; By processing in reverse order, we remove or replace the later placeholders first,
    ;; ensuring that any optional text (like "to", "with") associated with an empty placeholder
    ;; is also removed, resulting in a more natural prompt.
    ;; Example:
    ;;   Prompt: "Rename <entity> to <target> with <modifier>"
    ;;   Parameters: <entity>="foo", <target>="", <modifier>="logging"
    ;;   Result: "Rename foo with logging"
    (dolist (param-pair (nreverse values) final-description)
      (let* ((placeholder (car param-pair))
             (resolved-value (cdr param-pair)))
        (if (string= "" resolved-value)
            ;; If resolved value is empty, remove the placeholder and potentially
            ;; any preceding descriptive text like " to ", " named ", " with ".
            ;; The regex accounts for optional whitespace and common prepositions/conjunctions.
            (setq final-description (replace-regexp-in-string
                                     (concat "\\s-*\\(?:to\\|named\\|with\\|for\\|in\\)?\\s-*\\(" (regexp-quote placeholder) "\\)")
                                     ""
                                     final-description
                                     t t))
          ;; If resolved value is not empty, replace the placeholder with its value.
          (setq final-description (replace-regexp-in-string
                                   (regexp-quote placeholder)
                                   resolved-value
                                   final-description
                                   t t)))))
    ;; Finally, clean up any multiple spaces that might have been introduced
    ;; and trim leading/trailing spaces.
    (setq final-description (replace-regexp-in-string "  +" " " final-description t t))
    (string-trim final-description)))

(defun ai-code--handle-specific-refactoring (selected-technique all-techniques context tdd-mode)
  "Handle the case where a specific refactoring technique is chosen.
Uses SELECTED-TECHNIQUE, ALL-TECHNIQUES, CONTEXT, and TDD-MODE.
If TDD-MODE is non-nil, adds TDD constraints to the instruction."
  (let* ((context-description (plist-get context :context-description))
         (technique-description (cdr (assoc selected-technique all-techniques)))
         (prompt-with-params (ai-code--process-refactoring-parameters
                              selected-technique technique-description context))
         (base-instruction (format "%s %s. %s"
                                   selected-technique
                                   context-description
                                   prompt-with-params))
         ;; Add TDD constraint if in TDD mode
         (tdd-constraint (if tdd-mode " Ensure all tests still pass after refactoring." ""))
         (initial-instruction (concat base-instruction tdd-constraint ". Go ahead and make the code change."))
         (final-instruction (ai-code-read-string "Edit refactoring instruction: " initial-instruction))
         ;; Add file information to context
         (file-info (ai-code--get-context-files-string))
         (command (ai-code--compose-code-change-brief
                   :goal final-instruction
                   :scope (ai-code--refactoring-scope-string context file-info)
                   :boundaries ai-code--refactoring-code-change-boundaries
                   :code-change-note ai-code-change--generic-note))
         (message-suffix (if tdd-mode " during TDD refactor stage" "")))
    (when (ai-code--insert-prompt command)
      (message "%s refactoring request sent to AI Code Interface%s. After code refactored, better to re-run unit-tests."
               selected-technique message-suffix))))

(defun ai-code--handle-ask-llm-suggestion (context tdd-mode)
  "Handle the case where the user asks the LLM for a refactoring suggestion.
Uses CONTEXT and TDD-MODE.
If TDD-MODE is non-nil, adds TDD constraints to the prompt."
  (let* ((region-active (plist-get context :region-active))
         (region-text (plist-get context :region-text))
         (current-function (plist-get context :current-function))
         (dired-targets (plist-get context :dired-targets))
         (context-info (cond
                        (region-active "Selected code region")
                        (dired-targets "Selected files/directories")
                        (current-function (format "Function '%s'" current-function))
                        (t ;; use current buffer file name when no region/function
                         (let ((fname (plist-get context :file-name)))
                           (format "File '%s'" (or fname "All added files"))))))
         (code-snippet (if region-active
                           (format "\n```\n%s\n```" region-text)
                         ""))
                ;; Get the main instruction from the user
                 (user-instruction (ai-code--read-refactoring-suggestion-instruction))
                 ;; Add TDD constraint if in TDD mode
                 (tdd-constraint (if tdd-mode " Ensure all tests still pass after refactoring." ""))
                 ;; Add file information to context
                 (file-info (ai-code--refactoring-context-files-string context))
                 ;; Construct the prompt using user input and context
         (base-prompt (format "%s Context: %s%s%s"
                              user-instruction
                              context-info
                              file-info
                             code-snippet))
        (prompt (concat base-prompt tdd-constraint))
        (message-suffix (if tdd-mode " during TDD refactor stage" "")))
    ;; Send the prompt using the ai-code--insert-prompt function
    (when (ai-code--insert-prompt prompt)
      ;; Inform the user
      (message "Requesting refactoring suggestion from AI Code Interface%s. If you are happy with the suggestion, use 'go ahead' to accept the change"
               message-suffix))))

(defconst ai-code--value-simplification-discussion
  (concat
   "Value-driven Simplification: investigate before recommending changes. "
   "Start with a bounded search of the relevant diff or topic, then inspect "
   "callers, tests, and documented constraints as needed. Do not read the "
   "entire repository or paste a large diff into the response. "
   "Briefly identify one consequential source of complexity with file/line "
   "evidence, distinguish code facts from guesses about business intent, "
   "and identify affected core paths and behavior that may need protection. "
   "Ask ONE high-value question at a time about business value, historical "
   "constraints, what the user would keep, and how the user would simplify. "
   "Do not assume that fewer lines are better or prescribe a full plan. "
   "Wait for the user's answer. Challenge their proposal with concrete "
   "dependencies, invariants, and risks; invite revisions. The user makes "
   "the keep/simplify/delete decision. Only after the user's direction, "
   "propose one small, independently verifiable next step with relevant "
   "tests and rollback considerations. Discuss only: do not edit code, "
   "remove behavior, or run mutating commands without explicit user approval.")
  "Shared human-led discussion instructions for value simplification.")

(defun ai-code--value-simplification-default-base ()
  "Return a likely base ref for the current Git branch, or nil."
  (or (let ((remote-head (magit-git-string
                          "symbolic-ref" "--quiet" "--short"
                          "refs/remotes/origin/HEAD")))
        (and remote-head (not (string-empty-p remote-head)) remote-head))
      (and (magit-rev-verify "main") "main")
      (and (magit-rev-verify "master") "master")))

(defun ai-code--handle-value-driven-simplification ()
  "Discuss business value and code complexity in a branch or repository topic."
  (let* ((root (or (ai-code--git-root)
                   (user-error "Value-driven Simplification requires a Git repository")))
         (default-directory (file-name-as-directory root))
         (scope (completing-read "Analyze: "
                                 '("Current Branch" "Repository Topic")
                                 nil t))
         (branch-p (string= scope "Current Branch"))
         (branch (when branch-p (or (magit-get-current-branch) "HEAD")))
         (base (when branch-p
                 (string-trim (ai-code-read-string
                               "Compare with base branch/ref: "
                               (ai-code--value-simplification-default-base)))))
         (merge-base (when branch-p
                       (unless (and (not (string-empty-p base))
                                    (magit-rev-verify base))
                         (user-error "Select an existing base branch or ref"))
                       (or (magit-git-string "merge-base" base "HEAD")
                           (user-error "No common ancestor with %s" base))))
         (include-worktree (and branch-p
                                (y-or-n-p "Include uncommitted changes (including relevant untracked files)? ")))
         (topic (string-trim
                 (ai-code-read-string
                  (if branch-p "Narrow to topic (optional): " "Repository topic: ")))))
    (unless (or branch-p (not (string-empty-p topic)))
      (user-error "Enter a repository topic"))
    (let ((prompt
           (concat
            ai-code--value-simplification-discussion
            "\n\nRepository: " root
            "\nScope: " scope
            (if branch-p
                (format
                 (concat "\nCurrent branch: %s\nSelected base: %s"
                         "\nMerge-base commit: %s"
                         "\nUncommitted changes: %s"
                         "\nInspect committed changes from the merge-base to HEAD, "
                         "including relevant tests. %s")
                 branch base merge-base
                 (if include-worktree "included" "excluded")
                 (if include-worktree
                     (concat "Also inspect staged and unstaged changes and "
                             "relevant untracked files; label their provenance separately.")
                   (concat "Do not include index, working tree, or untracked "
                           "changes. When reading affected files, use the "
                           "committed HEAD version rather than the working "
                           "copy so the analysis respects this choice.")))
              (concat "\nLocate relevant implementation, callers, tests, and "
                      "documented constraints incrementally."))
            (unless (string-empty-p topic) (concat "\nTopic: " topic))
            (or (ai-code--get-context-files-string) ""))))
      (ai-code-with-prompt-policy ()
        (when (ai-code--insert-prompt prompt)
          (message "Value-driven Simplification discussion sent to AI Code Interface"))))))

;;;###autoload
(defun ai-code-refactor-book-method (&optional tdd-mode)
  "Apply refactoring techniques or request suggestions.
Uses current context (function, class, selected region).
If TDD-MODE is non-nil, adjusts prompts and instructions for the
TDD refactor stage."
  ;; The `interactive` spec needs to handle the optional argument if called directly,
  ;; but here it's primarily called programmatically from ai-code-tdd-cycle or interactively without args.
  ;; For interactive calls, tdd-mode will be nil.
  (interactive)
  (let* ((context (ai-code--get-refactoring-context))
         (dired-targets (plist-get context :dired-targets))
         (region-active (plist-get context :region-active)))
    (if dired-targets
        (ai-code--handle-ask-llm-suggestion context tdd-mode)
      (let* ((all-techniques (ai-code--get-refactoring-techniques region-active))
             (technique-names (mapcar #'car all-techniques))
             (prompt-prefix (if tdd-mode "Select TDD refactoring technique" "Select refactoring technique"))
             (prompt-suffix (if region-active " for selected region: " ": "))
             (prompt (concat prompt-prefix prompt-suffix))
             (selected-technique (completing-read prompt technique-names nil t)))
        ;; Dispatch to appropriate handler based on user selection
        (cond
         ((string= selected-technique "Suggest Refactoring Strategy")
          (ai-code--handle-ask-llm-suggestion context tdd-mode))
         ((string= selected-technique "Value-driven Simplification")
          (ai-code--handle-value-driven-simplification))
         (t (ai-code--handle-specific-refactoring
             selected-technique all-techniques context tdd-mode)))))))

(defun ai-code--ensure-test-buffer-visible ()
  "Ensure that at least one buffer in the current windows is a test file.
A test file is identified by having \\='test\\=' in its name (case insensitive).
If no such buffer is found, report a user-error."
  (let ((has-test-buffer nil)
        (case-fold-search t))
    (dolist (win (window-list))
      (when (string-match-p "test" (buffer-name (window-buffer win)))
        (setq has-test-buffer t)))
    ;; test buffer is must need. non-test buffer is not a must need.
    ;; since test buffer is sufficient for bootstrapping
    (unless has-test-buffer
      (user-error "No test file found in current windows.  Please open a test file first"))))

(defconst ai-code--high-value-tests-instruction
  (concat
   "Prefer a small set of high-value tests. Cover only distinct behaviors, "
   "important edge cases, or regressions that materially increase confidence. "
   "Do not add low-value or duplicate tests.")
  "Instruction included in test-writing prompts to emphasize quality over quantity.
This guidance exists to discourage AI from generating excessive, low-value, or
duplicate tests.")

(defconst ai-code--tdd-test-pattern-instruction
  (concat
   "\nFollow the test-code pattern in the current project. Write the test-code in the test-file. If the test-file does not exist, create it using the same test-filename pattern used in this repository. "
   ai-code--high-value-tests-instruction
   " If the tests use random values (for example random numbers or UUIDs), make them reproducible by fixing the random seed or replacing them with deterministic fixtures.")
  "Instruction appended to TDD prompts to enforce the project's test pattern.")

(defconst ai-code--tdd-run-test-after-this-stage-instruction
  " Run test after this stage and output the summary of test result. State whether the result matches the goal of this stage. List the files changed and exact test command / result. List the public API / log key / config key change if there is."
  "Instruction appended to single-stage TDD prompts.")

(defconst ai-code--tdd-run-test-after-each-stage-instruction
  " Run test after each stage and output the summary of test result. For each stage, list the stage name, files changed, exact test command / result, and whether the result matches the goal of that stage. List the public API / log key / config key change if there is."
  "Instruction appended to multi-stage TDD prompts.")

(defconst ai-code--tdd-red-green-base-instruction
  " Follow strict TDD stages. Do not skip stages. Stage 1 - Red: update only test code and write the smallest failing test that captures the requested behavior. Do not modify source code during Red. Stage 2 - Green: after confirming the new test fails for the expected reason, update the minimum source code needed to make it pass. Do not refactor during Green."
  "Base instruction shared by Red+Green style TDD prompts.")

(defconst ai-code--tdd-red-green-tail-instruction
  " Keep the changes narrowly scoped to the requested behavior. Only update the relevant test and source code. Do not add extra features or unrelated cleanup."
  "Trailing instruction shared by Red+Green style TDD prompts.")

(defconst ai-code--tdd-with-refactoring-extension-instruction
  " Stage 3 - Blue: after Green is passing, refactor only the files changed in Red/Green. Preserve behavior and do not add features. First review the code diff (including tests) and identify the highest-impact cleanup. Then apply focused refactoring that improves readability, keeps classes/functions small and cohesive / easy to test, reduces duplication, and simplifies naming and control flow."
  "Refactoring extension shared by Red+Green+Blue style TDD prompts.")

(defconst ai-code--tdd-red-boundaries
  (concat
   "Follow TDD principles - write only the test now, not the implementation. "
   "The test should fail when run because the functionality doesn't exist yet. "
   "Only update test file code.")
  "Boundaries for Red-stage structured code-change briefs.")

(defconst ai-code--tdd-green-boundaries
  (concat
   "Follow TDD principles - implement the minimum source code needed to make "
   "the failing test pass. Do not refactor during Green.")
  "Boundaries for Green-stage structured code-change briefs.")

(defconst ai-code--tdd-failure-fix-boundaries
  (concat
   "Follow TDD principles - fix only the failing behavior described by the "
   "test output. Keep the change narrowly scoped and avoid unrelated cleanup.")
  "Boundaries for TDD failure-fix structured code-change briefs.")

(defconst ai-code--tdd-red-green-boundaries
  (string-trim
   (concat ai-code--tdd-red-green-base-instruction
           ai-code--tdd-red-green-tail-instruction))
  "Boundaries for Red+Green structured code-change briefs.")

(defconst ai-code--tdd-red-green-blue-boundaries
  (string-trim
   (concat ai-code--tdd-red-green-base-instruction
           ai-code--tdd-with-refactoring-extension-instruction
           ai-code--tdd-red-green-tail-instruction))
  "Boundaries for Red+Green+Blue structured code-change briefs.")

(defun ai-code--tdd-compose-code-change-brief (goal function-name boundaries instruction)
  "Return a structured TDD code-change brief.
GOAL is the requested task, FUNCTION-NAME is the current function,
BOUNDARIES defines the stage limits, and INSTRUCTION is appended guidance."
  (ai-code--compose-code-change-brief
   :goal goal
   :scope (ai-code--agile-current-scope-string
           function-name
           (ai-code--get-context-files-string))
   :boundaries boundaries
   :code-change-note instruction))

(defun ai-code--tdd-red-stage (function-name)
  "Handle the Red stage of TDD for FUNCTION-NAME: Write a failing test."
  (let ((test-pattern-instruction ai-code--tdd-test-pattern-instruction))
    (if (and (region-active-p) (not (derived-mode-p 'prog-mode)))
        ;; If there is a selected region, and it is not a prog-mode derived buffer,
        ;; assume this is the information / exception of failed test.
        ;; Use it as initial prompt to fix the source code.
        (let* ((failure-info (buffer-substring-no-properties (region-beginning) (region-end)))
               (prompt (ai-code-read-string "Confirm test failure to fix: " failure-info))
               (tdd-instructions
                (ai-code--tdd-compose-code-change-brief
                 (format "Fix the code to resolve the following error:\n%s" prompt)
                 function-name
                 ai-code--tdd-failure-fix-boundaries
                 test-pattern-instruction)))
          (ai-code--insert-prompt tdd-instructions))
      ;; Original path: write a failing test
      (ai-code--ensure-test-buffer-visible)
      (let* ((feature-desc (ai-code-read-string
                             (if function-name
                                 (format "Describe the feature to test for '%s': " function-name)
                               "Describe the feature to test: ") "Implement test functions using test cases described in the comments."))
             (tdd-instructions
              (ai-code--tdd-compose-code-change-brief
               feature-desc
               function-name
               ai-code--tdd-red-boundaries
               (concat ai-code--tdd-run-test-after-this-stage-instruction
                       test-pattern-instruction))))
        (ai-code--insert-prompt tdd-instructions)))))

(defun ai-code--tdd-source-function-context-p (function-name)
  "Return non-nil when FUNCTION-NAME is in a non-test source buffer."
  (and function-name
       buffer-file-name
       (derived-mode-p 'prog-mode)
       (let ((case-fold-search t))
         (not (string-match-p "test" (file-name-nondirectory buffer-file-name))))))

(defun ai-code--write-test (function-name &optional region-text)
  "Write a test for FUNCTION-NAME in the corresponding test file.
When REGION-TEXT is non-nil, use the selected code as the context for the test."
  (let* ((source-file (and buffer-file-name (file-name-nondirectory buffer-file-name)))
         (test-file-hint (if source-file
                             (format "the corresponding test file for %s, following test pattern of this repo"
                                     source-file)
                           "the corresponding test file"))
         (context-target (if region-text "the selected region" function-name))
         (write-test-desc (ai-code-read-string
                           "Write test instruction: "
                           (format "Write test for '%s' in %s."
                                   context-target
                                   test-file-hint)))
         (region-scope (when region-text
                         (format "\nSelected code:\n%s" region-text)))
         (tdd-instructions
          (ai-code--compose-code-change-brief
           :goal write-test-desc
           :scope (concat (ai-code--agile-current-scope-string
                           function-name
                           (ai-code--get-context-files-string))
                          (or region-scope ""))
           :boundaries "Follow TDD principles - write only the test now, not the implementation. Only update test file code."
           :code-change-note ai-code--tdd-test-pattern-instruction)))
    (ai-code--insert-prompt tdd-instructions)))


(defun ai-code--acceptance-test-task-references ()
  "Return task references for the current worktree without guessing a task.
Prefer the current Org file, then task files attached to matching sessions."
  (let ((org-file (and (derived-mode-p 'org-mode)
                       (stringp buffer-file-name)
                       (string-suffix-p ".org" buffer-file-name)
                       (expand-file-name buffer-file-name))))
    (if org-file
        (concat
         (format "Current Org file: @%s" org-file)
         (when-let ((line (save-excursion
                            (when (ignore-errors (org-back-to-heading t))
                              (line-number-at-pos nil t)))))
           (format " (section begins at line %d)" line))
         (when (buffer-modified-p)
           "\nWARNING: Unsaved Org edits may be absent from @file. Ask the user to save or provide the original text."))
      (let* ((root (ai-code--session-project-root t))
             (tasks
              (when root
                (delete-dups
                 (delq nil
                       (mapcar
                        (lambda (session)
                          (let ((task (ai-code-session-task-file session))
                                (dir (ai-code-session-repo-root session)))
                            (when (and (stringp task) (file-readable-p task)
                                       (stringp dir)
                                       (string= (file-truename root)
                                                (file-truename dir)))
                              task)))
                        (ai-code-session-list)))))))
        (cond
         ((null tasks) nil)
         ((= (length tasks) 1)
          (format "AI session's task file in this worktree: @%s" (car tasks)))
         (t (concat "Multiple tasks in this worktree; confirm the correct one:\n"
                    (mapconcat (lambda (file) (concat "- @" file))
                               tasks "\n"))))))))

(defconst ai-code--acceptance-test-only-boundary
  (concat "\n\nACCEPTANCE-TEST-ONLY: Change only test code and necessary "
          "test fixtures, never implementation code, documentation, "
          "configuration, or Git state; do not commit or push. "
          "Report defects rather than fixing implementation. "
          "These are agent instructions, not enforced permissions.")
  "Test-only boundaries appended after the user edits the prompt.")

(defun ai-code--acceptance-test-prompt (requirements function-name
                                                    selected-requirements source-region)
  "Create an acceptance-test prompt based on human REQUIREMENTS.
FUNCTION-NAME is the code scope; SELECTED-REQUIREMENTS is an Org selection;
SOURCE-REGION is code context, never a source of requirements."
  (string-join
   (delq nil
         (list
          "Goal:\nWrite a few high-value acceptance tests showing whether this feature or change satisfies its real requirements."
          (format "User requirements or original reference:\n%s"
                  (if (string-blank-p (or requirements ""))
                      "(not supplied)" requirements))
          (when (not (string-blank-p (or selected-requirements "")))
            (format "Selected Org context (check provenance):\n%s"
                    selected-requirements))
          (when-let ((task (ai-code--acceptance-test-task-references)))
            (format "Task context:\n%s" task))
          (format "Target code:\nWorking checkout: %s\n%s"
                  (ai-code--session-project-root)
                  (ai-code--agile-current-scope-string
                   function-name (ai-code--get-context-files-string)))
          (when (not (string-blank-p (or source-region "")))
            (format "Selected code (scope, not requirements):\n%s"
                    source-region))
          (concat
           "Source of truth:\n"
           "1. Prefer explicit human requirements and original linked issues, "
           "specifications and decisions. If not provided, inspect original "
           "references in the current Org section, linked task file, or "
           "current AI coding session history.\n"
           "2. Never derive acceptance criteria merely from implementation "
           "behavior, a PR description, AI summaries, or intermediate plans.\n"
           "3. State observable criteria and source links before editing. "
           "If sources are absent or conflicting, ask the user rather "
           "than inventing criteria or asserting acceptance.")
          (concat
           "Test strategy:\n"
           "- Prefer deterministic, maintainable end-to-end tests of user-visible "
           "workflows when feasible; otherwise select integration or unit "
           "tests that best demonstrate the requirement. Explain the choice; "
           "avoid introducing heavy BDD infrastructure.\n"
           "- Reuse the project's test framework, naming and patterns. "
           "Cover distinct valuable cases and important failures; avoid "
           "duplicate, brittle or low-value tests.\n"
           "- Write concise comments next to tests connecting each scenario "
           "to its original requirement/reference and explaining why it matters.\n"
           "- Keep assertions externally observable and tests deterministic. "
           "Run tests; do not modify implementation to make failing tests pass.")
          (concat
           "Boundaries and evidence:\n"
           "Edit only tests and essential test-only fixtures. Never change "
           "production code, docs, config or Git state; do not commit/push. "
           "Report requirement-to-test mapping, paths, exact commands and "
           "results, failures, uncovered criteria, and uncertainty. "
           "Passing tests alone do not prove full requirement coverage.")))
   "\n\n"))

(defun ai-code--acceptance-test-stage (function-name
                                      &optional selected-requirements source-region)
  "Compose an acceptance-test request for FUNCTION-NAME.
SELECTED-REQUIREMENTS and SOURCE-REGION are captured before menu input."
  (let* ((requirements (ai-code-read-string
                        "Acceptance requirements or URL (RET to infer): " ""))
         (prompt (ai-code--acceptance-test-prompt
                  requirements function-name selected-requirements source-region))
         ;; Send the reviewed text unchanged, and only to this project's session.
         (ai-code-prompt-preprocess-filepaths nil)
         (ai-code--prompt-project-only t))
    (ai-code-with-prompt-policy ()
      (ai-code--confirm-and-send
       "Edit acceptance-test request: " prompt :force-compose t
       :after-edit (lambda (edited)
                     (concat edited ai-code--acceptance-test-only-boundary))))))

(defun ai-code--tdd-red-green-stage (function-name)
  "Handle the Red + Green stage for FUNCTION-NAME in one prompt."
  ;; (ai-code--ensure-test-buffer-visible)
  (let* ((feature-desc (ai-code-read-string
                        (if function-name
                            (format "Describe the feature to test for '%s': " function-name)
                          "Describe the feature to test: ")
                        "Implement test functions using test cases described in the comments."))
         (tdd-instructions
          (ai-code--tdd-compose-code-change-brief
           feature-desc
           function-name
           ai-code--tdd-red-green-boundaries
           (concat ai-code--tdd-run-test-after-each-stage-instruction
                   ai-code--tdd-test-pattern-instruction))))
    (ai-code--insert-prompt tdd-instructions)))

(defun ai-code--tdd-red-green-blue-stage (function-name)
  "Handle the Red + Green + Blue stage for FUNCTION-NAME in one prompt."
  ;; (ai-code--ensure-test-buffer-visible)
  (let* ((feature-desc (ai-code-read-string
                        (if function-name
                            (format "Describe the feature to test for '%s': " function-name)
                          "Describe the feature to test: ")
                        "Implement test functions using test cases described in the comments."))
         (tdd-instructions
          (ai-code--tdd-compose-code-change-brief
           feature-desc
           function-name
           ai-code--tdd-red-green-blue-boundaries
           (concat ai-code--tdd-run-test-after-each-stage-instruction
                   ai-code--tdd-test-pattern-instruction))))
    (ai-code--insert-prompt tdd-instructions)))

(defun ai-code--tdd-green-stage (function-name)
  "Handle the Green stage of TDD for FUNCTION-NAME: Make the test pass.
If current file is a test file (contains \\='test\\=' in name), provide prompt
to fix code."
  (ai-code--ensure-test-buffer-visible)
  (let* ((is-test-buffer (and (buffer-file-name) (string-match-p "test" (buffer-file-name))))
         (initial-input
          (if is-test-buffer
              (format "Current test file: %s\ntest function: %s\n is failing. Please fix the code to make the test pass.\nTest failure details: "
                      (file-name-nondirectory (buffer-file-name))
                      (or function-name "some test functions"))
            (if function-name
                (format "Implement function '%s' to make tests pass: " function-name)
              "Implement the minimal code needed to make the failing test pass: ")))
         (implementation-desc (ai-code-read-string "Implementation instruction: " initial-input))
         (tdd-instructions
          (ai-code--tdd-compose-code-change-brief
           implementation-desc
           function-name
           ai-code--tdd-green-boundaries
           ai-code--tdd-run-test-after-this-stage-instruction)))
    (ai-code--insert-prompt tdd-instructions)))

(defun ai-code--run-test-ai-assisted ()
  "Send a prompt to AI to run a test command with current context."
  (let* ((is-dired (derived-mode-p 'dired-mode))
         (scope-context
          (unless is-dired
            (if (region-active-p)
                (ai-code--scope-context-for-region
                 (region-beginning) (region-end))
              (ai-code--current-line-scope-context))))
         (function-name (plist-get scope-context :function-name))
         (semantic-scope (unless is-dired
                           (ai-code--format-scope-context scope-context)))
         (scope-details (if (string-empty-p (or semantic-scope ""))
                            ""
                          (concat "\n" semantic-scope)))
         (file-info (unless is-dired (ai-code--get-context-files-string)))
         (error-handling-instruction
          (concat "\n\nIf any test fails:"
                  "\n1. Analyze the test failure output carefully to identify which test(s) failed"
                  "\n2. Investigate the root cause by examining the test code and related source files"
                  "\n3. Provide a clear explanation of what went wrong"
                  "\n4. Suggest specific code fixes for user approval before making any changes"))
         (initial-input
          (cond
           (is-dired
            (format "Run the tests for source code in directory '%s' using appropriate test runner.%s"
                    (dired-current-directory)
                    error-handling-instruction))
           (function-name
            (format "Run the tests for the current function '%s' using appropriate test runner.%s%s%s"
                    function-name
                    scope-details
                    file-info
                    error-handling-instruction))
           (t
            (format "Run the tests for the current file using appropriate test runner.%s%s%s"
                    scope-details
                    file-info
                    error-handling-instruction))))
         (prompt (ai-code-read-string "Send to AI: " initial-input)))
    (ai-code--insert-prompt prompt)))

;;;###autoload
(defun ai-code-run-test ()
  "Prompt AI to run relevant test commands for the current context."
  ;; DONE: remove pytest / jest / ert usage here, simply call ai-code--run-test-ai-assisted
  ;; DONE: Remove related information from README / autoloads / @test as well, since we want to keep the @test running experience consistent across languages and rely on AI to figure out the test pattern and command.
  (interactive)
  (ai-code--run-test-ai-assisted))

;;;###autoload
(defun ai-code-tdd-cycle ()
  "Guide through Test Driven Development cycle (Red-Green-Refactor).
In Magit, add tests for existing hunk changes; the agent runs verification.
Helps users follow Kent Beck's TDD methodology with AI assistance.
Works with both source code and test files that have been added to ai-code."
  (interactive)
  (if (derived-mode-p 'magit-mode)
      (ai-code-magit-prompt 'tests)
    ;; DONE: use-write-test-stage should also support selected region. If there is selected region, we can use it as the context for writing a test. If there is no selected region, we can use the current function name as the context for writing a test.
    ;; DONE: ai-code-derive-topic-unit-tests should be added as the last option of C-c a t, purpose is to derive the test code as tutorial and learning material for the user for given topic.
    (let* ((region-active (region-active-p))
           (scope-context
            (if region-active
                (ai-code--scope-context-for-region
                 (region-beginning) (region-end))
              (ai-code--current-line-scope-context)))
           (function-name (plist-get scope-context :function-name))
           ;; Capture region text early, before completing-read may deactivate the mark.
           ;; Only capture when in a non-test source buffer so it mirrors the same guard
           ;; used by ai-code--tdd-source-function-context-p.
           (region-text (when (and region-active
                                   buffer-file-name
                                   (derived-mode-p 'prog-mode)
                                   (let ((case-fold-search t))
                                     (not (string-match-p "test" (file-name-nondirectory buffer-file-name)))))
                          (buffer-substring-no-properties (region-beginning) (region-end))))
           (selected-requirements
            (when (and region-active (derived-mode-p 'org-mode))
              (buffer-substring-no-properties (region-beginning) (region-end))))
           (use-write-test-stage (or (ai-code--tdd-source-function-context-p function-name)
                                     (and region-text (not (string-empty-p region-text)))))
           (red-stage-label (cond
                             ((and use-write-test-stage region-text)
                              "1. Red (Write test for selected region)")
                             (use-write-test-stage
                              (format "1. Red (Write test for %s)" function-name))
                             (t
                              "1. Red (Write failing test)")))
           (cycle-stage (completing-read
                         "Select TDD stage: "
                         (list "0. Run unit-tests"
                               red-stage-label
                               "2. Green (Make test pass)"
                               "3. Blue (Refactor, improve code quality)"
                               "4. Red + Green (One prompt)"
                               "5. Red + Green + Blue (One prompt)"
                               "6. Learning tests (Derive unit tests as a tutorial for a topic)"
                               "7. Acceptance tests (Verify feature requirements)")
                         nil t))
           (stage-num (string-to-number (substring cycle-stage 0 1))))
      (cond
       ;; Run tests
       ((= stage-num 0) (ai-code-run-test))
       ;; Red stage - write failing test
       ((= stage-num 1)
        (if use-write-test-stage
            (ai-code--write-test function-name region-text)
          (ai-code--tdd-red-stage function-name)))
       ;; Green stage - make test pass
       ((= stage-num 2) (ai-code--tdd-green-stage function-name))
       ;; Refactor stage - call the main refactoring function in TDD mode
       ((= stage-num 3) (ai-code-refactor-book-method t))
       ;; Red + Green combined in one prompt
       ((= stage-num 4) (ai-code--tdd-red-green-stage function-name))
       ;; Red + Green + Blue combined in one prompt
       ((= stage-num 5) (ai-code--tdd-red-green-blue-stage function-name))
       ;; Learning tests - derive unit tests as a tutorial for a topic
       ((= stage-num 6) (ai-code-derive-topic-unit-tests))
       ((= stage-num 7)
        (ai-code--acceptance-test-stage
         function-name selected-requirements region-text))))))

(provide 'ai-code-agile)

;; Load prompt harnesses after entry commands are defined.
(unless (bound-and-true-p ai-code--harness-loading)
  (require 'ai-code-harness))

;;; ai-code-agile.el ends here
