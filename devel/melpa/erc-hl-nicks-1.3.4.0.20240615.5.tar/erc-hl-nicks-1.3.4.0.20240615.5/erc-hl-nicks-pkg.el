;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-hl-nicks" "1.3.4.0.20240615.5"
  "ERC nick highlighter that ignores uniquifying chars when colorizing."
  ()
  :url "http://www.github.com/leathekd/erc-hl-nicks"
  :commit "fd2759bde20c25226a332c3d19aed6c7f135bf10"
  :revdesc "fd2759bde20c"
  :authors '(("David Leatherman" . "leathekd@gmail.com"))
  :maintainers '(("David Leatherman" . "leathekd@gmail.com")))
