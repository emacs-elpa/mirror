;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-config" "1.0.3"
  "Find and evaluate .dir-config.el (dir-locals alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/dir-config.el"
  :commit "b6d15df03f921fbac12914cc480615d4164485fc"
  :revdesc "1.0.3-0-gb6d15df03f92"
  :keywords '("convenience" "files" "lisp")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
