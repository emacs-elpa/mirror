;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blitzmax-mode" "1.0.0.0.20250221.36"
  "A major mode for editing BlitzMax source code."
  '((emacs "24.1"))
  :url "https://www.sodaware.net/dev/tools/blitzmax-mode/"
  :commit "adf6444ca4cea047b5532495e9692ed044224ea4"
  :revdesc "adf6444ca4ce"
  :keywords '("languages" "blitzmax"))
