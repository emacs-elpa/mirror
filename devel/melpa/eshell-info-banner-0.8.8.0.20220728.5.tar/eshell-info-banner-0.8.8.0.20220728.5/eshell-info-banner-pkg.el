;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-info-banner" "0.8.8.0.20220728.5"
  "System information as your Eshell banner."
  '((emacs "25.1")
    (s     "1"))
  :url "https://github.com/Phundrak/eshell-info-banner.el"
  :commit "987e69a66276ca057798896c606e5c5d5fb9ee5c"
  :revdesc "987e69a66276"
  :authors '(("Lucien Cartier-Tilet" . "lucien@phundrak.com"))
  :maintainers '(("Lucien Cartier-Tilet" . "lucien@phundrak.com")))
