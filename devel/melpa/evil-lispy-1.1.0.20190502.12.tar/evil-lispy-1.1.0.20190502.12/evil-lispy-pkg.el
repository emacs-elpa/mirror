;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-lispy" "1.1.0.20190502.12"
  "Precision Lisp editing with Evil and Lispy."
  '((lispy "0.26.0")
    (evil  "1.2.12")
    (hydra "0.13.5"))
  :url "https://github.com/sp3ctum/evil-lispy"
  :commit "ed317f7fccbdbeea8aa04a91b1b1f48a0e2ddc4e"
  :revdesc "ed317f7fccbd"
  :keywords '("lisp")
  :authors '(("Brandon Carrell" . "brandoncarrell@gmail.com")
             ("Mika Vilpas" . "mika.vilpas@gmail.com"))
  :maintainers '(("Brandon Carrell" . "brandoncarrell@gmail.com")
                 ("Mika Vilpas" . "mika.vilpas@gmail.com")))
