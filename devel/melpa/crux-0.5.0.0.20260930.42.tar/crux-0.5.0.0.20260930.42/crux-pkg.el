;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crux" "0.5.0.0.20260930.42"
  "A Collection of Ridiculously Useful eXtensions."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/crux"
  :commit "e09244a61e6637ff698bb51a371aa25fa37482a9"
  :revdesc "e09244a61e66"
  :keywords '("convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
