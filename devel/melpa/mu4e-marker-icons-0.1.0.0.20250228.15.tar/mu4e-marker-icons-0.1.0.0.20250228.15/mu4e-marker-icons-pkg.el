;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-marker-icons" "0.1.0.0.20250228.15"
  "Display icons for mu4e markers."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/mu4e-marker-icons.git"
  :commit "13541181d5144ee91d570ab74558abce194b083f"
  :revdesc "13541181d514"
  :keywords '("mail")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
