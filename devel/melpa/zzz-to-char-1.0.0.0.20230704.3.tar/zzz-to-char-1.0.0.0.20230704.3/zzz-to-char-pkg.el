;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zzz-to-char" "1.0.0.0.20230704.3"
  "Fancy version of `zap-to-char' command."
  '((emacs "24.4")
    (avy   "0.3.0"))
  :url "https://github.com/mrkkrp/zzz-to-char"
  :commit "5945432d74feb2d1cd3520b185b3ab5dca35e0eb"
  :revdesc "5945432d74fe"
  :keywords '("convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
