;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-phpactor" "0.1.0.0.20261007.260"
  "A company-mode backend for Phpactor."
  '((emacs    "24.3")
    (company  "0.9.6")
    (phpactor "0.1.0"))
  :url "https://github.com/emacs-php/phpactor.el"
  :commit "00c74783c152bb568d4bda76ce8438c03fdf97fa"
  :revdesc "00c74783c152"
  :keywords '("tools" "php")
  :authors '(("Martin Tang" . "martin.tang365@gmail.com")
             ("Mikael Kermorgant" . "mikael@kgtech.fi"))
  :maintainers '(("Martin Tang" . "martin.tang365@gmail.com")
                 ("Mikael Kermorgant" . "mikael@kgtech.fi")))
