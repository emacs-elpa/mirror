;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-convert" "1.0.0.0.20260516.112"
  "Convert many format to leaf format."
  '((emacs         "26.1")
    (leaf          "4.5.5")
    (leaf-keywords "2.0.8")
    (ppp           "2.2.4"))
  :url "https://github.com/conao3/leaf-convert.el"
  :commit "37967565c023596d863d9cd45527a024c5922553"
  :revdesc "37967565c023"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
