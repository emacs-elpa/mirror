;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-flycheck" "0.2.0.20260829.13"
  "Use flycheck checkers as flymake backends."
  '((flycheck "31")
    (emacs    "27.1"))
  :url "https://github.com/purcell/flymake-flycheck"
  :commit "4dd5b2ed972989128f0f1a170a97e57606004e06"
  :revdesc "4dd5b2ed9729"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
