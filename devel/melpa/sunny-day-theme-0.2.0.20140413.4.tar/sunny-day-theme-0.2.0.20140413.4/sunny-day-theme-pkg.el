;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sunny-day-theme" "0.2.0.20140413.4"
  "Emacs24 theme with a light background."
  ()
  :url "https://github.com/mswift42/sunny-day-theme"
  :commit "420e0a6eb33fcc9b75c2c9e88ab60a975d782a00"
  :revdesc "420e0a6eb33f")
