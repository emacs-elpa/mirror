;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "1.8.1"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "0dd7b55e54031e5e1db364f80150f004733abf22"
  :revdesc "0dd7b55e5403"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
