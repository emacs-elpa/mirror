;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "0.4.0.20261125.29"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "e6b119ccd4ea052ac000371028a40ca582015817"
  :revdesc "e6b119ccd4ea"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
