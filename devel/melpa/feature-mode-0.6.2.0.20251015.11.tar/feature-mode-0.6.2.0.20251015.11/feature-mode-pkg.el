;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "feature-mode" "0.6.2.0.20251015.11"
  "Major mode for editing Gherkin (i.e. Cucumber) user stories."
  '((emacs "28.1"))
  :url "https://github.com/freesteph/cucumber.el"
  :commit "8d43c37ddf986af769870da27c31c1911f35b205"
  :revdesc "8d43c37ddf98")
