;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "0.1.0.0.20260716.281"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "8c19cb0885468fb1d38692739212a8681c50296d"
  :revdesc "8c19cb088546"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
