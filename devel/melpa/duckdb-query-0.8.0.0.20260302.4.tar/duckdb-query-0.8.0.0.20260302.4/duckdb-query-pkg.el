;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "duckdb-query" "0.8.0.0.20260302.4"
  "DuckDB query results as native Elisp data structures."
  '((emacs "28.1"))
  :url "https://github.com/gggion/duckdb-query.el"
  :commit "b93d0b20120d734d7a264bea9ed8b41290345151"
  :revdesc "b93d0b20120d"
  :keywords '("data" "sql")
  :authors '(("Gino Cornejo" . "gggion123@gmail.com"))
  :maintainers '(("Gino Cornejo" . "gggion123@gmail.com")))
