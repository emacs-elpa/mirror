;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coffee-fof" "0.0.2.0.20131012.9"
  "A coffee-mode configuration for `ff-find-other-file'."
  '((coffee-mode "0.4.1"))
  :url "https://github.com/yasuyk/coffee-fof"
  :commit "211529594bc074721c6cbc4edb73a63cc05f89ac"
  :revdesc "211529594bc0"
  :keywords '("coffee-mode")
  :authors '(("Yasuyki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyki Oka" . "yasuyk@gmail.com")))
