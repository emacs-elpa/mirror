;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "0.13.8.0.20261024.17"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "318b039872a419feaf3ca3584e89936642627ca9"
  :revdesc "v0.13.8-17-g318b039872a4"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
