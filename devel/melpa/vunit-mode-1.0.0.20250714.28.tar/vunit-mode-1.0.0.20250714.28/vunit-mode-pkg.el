;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vunit-mode" "1.0.0.20250714.28"
  "VUnit Runner Interface."
  '((hydra "0.14.0")
    (emacs "24.3"))
  :url "https://github.com/embed-me"
  :commit "b26ecc46464a57eb00bf62b15c0d717774ec804e"
  :revdesc "b26ecc46464a"
  :keywords '("vunit" "python" "tools")
  :authors '(("Lukas Lichtl" . "support@embed-me.com"))
  :maintainers '(("Lukas Lichtl" . "support@embed-me.com")))
