;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.1.0.20260729.3"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "c8edca9430dd84ebb077ee9e1eaff28d4d28fc7c"
  :revdesc "c8edca9430dd"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
