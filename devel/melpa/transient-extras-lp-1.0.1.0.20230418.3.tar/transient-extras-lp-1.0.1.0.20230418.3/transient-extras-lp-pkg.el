;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient-extras-lp" "1.0.1.0.20230418.3"
  "A transient interface to lp."
  '((emacs            "28.1")
    (transient-extras "1.0.0"))
  :url "https://github.com/haji-ali/transient-extras.git"
  :commit "00a4b22882399c0355a2026b1a1c98974e669e62"
  :revdesc "00a4b2288239"
  :keywords '("convenience")
  :authors '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com")))
