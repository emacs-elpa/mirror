;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zpl-mode" "20180712.0.20180906.1"
  "ZIMPL major mode."
  '((emacs "24.3"))
  :url "https://github.com/ax487/zpl-mode.git"
  :commit "35e7e23c6baf31b5e65dd7405c8ab9b13c70637e"
  :revdesc "35e7e23c6baf")
