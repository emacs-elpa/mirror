;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ivy-search" "0.1.8"
  "Full text search for org files powered by ivy."
  '((emacs  "26.1")
    (ivy    "0.10.0")
    (org    "0.10.0")
    (beacon "1.3.4"))
  :url "https://github.com/beacoder/org-ivy-search"
  :commit "5aa418961c6dae576e800df459ad6dbd7740b4b4"
  :revdesc "5aa418961c6d"
  :keywords '("convenience" "tool" "org")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
