;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "freeradius-mode" "1.0.0.0.20190401.4"
  "Major mode for FreeRadius server config files."
  '((emacs "24.4"))
  :url "https://github.com/VersBinarii/freeradius-mode"
  :commit "cf8bf0359cf6c77848facbd24b764b3e111b4c2d"
  :revdesc "cf8bf0359cf6")
