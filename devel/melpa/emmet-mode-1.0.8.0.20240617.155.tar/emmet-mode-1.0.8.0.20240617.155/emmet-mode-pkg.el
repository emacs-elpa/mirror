;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emmet-mode" "1.0.8.0.20240617.155"
  "Unofficial Emmet's support for emacs."
  ()
  :url "https://github.com/smihica/emmet-mode"
  :commit "322d3bb112fced57d63b44863357f7a0b7eee1e3"
  :revdesc "322d3bb112fc"
  :keywords '("convenience")
  :authors '(("Shin Aoyama" . "smihica@gmail.com"))
  :maintainers '(("Shin Aoyama" . "smihica@gmail.com")))
