;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyfun-mode" "0.10.0.0.20261124.31"
  "Major mode for the Pyfun language."
  '((emacs "29.1"))
  :url "https://github.com/simontreanor/Pyfun"
  :commit "fae92c25d190129710336f31340dc36ea4ae3c3f"
  :revdesc "fae92c25d190"
  :keywords '("languages")
  :authors '(("Simon Treanor" . "https://github.com/simontreanor"))
  :maintainers '(("Simon Treanor" . "https://github.com/simontreanor")))
