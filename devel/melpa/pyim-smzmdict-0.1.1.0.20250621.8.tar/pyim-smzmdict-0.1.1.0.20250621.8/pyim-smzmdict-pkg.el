;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyim-smzmdict" "0.1.1.0.20250621.8"
  "Strange scheMas of ZhengMa dict for pyim."
  '((pyim "5.3.4"))
  :url "https://github.com/cor5corpii/pyim-smzmdict"
  :commit "853908d2ae88a30038dd03a7cd3f00aeabd89ac2"
  :revdesc "853908d2ae88"
  :keywords '("convenience" "pyim" "chinese" "zhengma")
  :maintainers '(("Yuanchen Xie" . "xieych@outlook.com")))
