;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lognav-mode" "0.0.12"
  "Navigate Log Error Messages."
  '((emacs "24.3"))
  :url "https://github.com/ellisvelo/lognav-mode.git"
  :commit "139da9eb356b4432f416d1db49fdbfa46fb1bf8d"
  :revdesc "139da9eb356b"
  :keywords '("log" "error" "lognav-mode" "convenience")
  :authors '(("Shawn Ellis" . "shawn.ellis17@gmail.com"))
  :maintainers '(("Shawn Ellis" . "shawn.ellis17@gmail.com")))
