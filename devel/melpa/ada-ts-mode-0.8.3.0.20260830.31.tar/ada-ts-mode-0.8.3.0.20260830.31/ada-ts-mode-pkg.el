;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ada-ts-mode" "0.8.3.0.20260830.31"
  "Major mode for Ada using Tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/brownts/ada-ts-mode"
  :commit "234393fb9d0cc8e3c6f726a3bbc001437ed136e7"
  :revdesc "234393fb9d0c"
  :keywords '("ada" "languages" "tree-sitter")
  :authors '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainers '(("Troy Brown" . "brownts@troybrown.dev")))
