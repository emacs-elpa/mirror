;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-elfeed" "1.0.0.20251013.7"
  "Helm interface for Elfeed."
  '((emacs  "29.1")
    (helm   "3.9.6")
    (elfeed "3.4.2"))
  :url "https://codeberg.org/timmli/helm-elfeed"
  :commit "4d1c853548e3425bc72a0c2fd4be9a3672382d51"
  :revdesc "4d1c853548e3"
  :keywords '("matching")
  :authors '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de"))
  :maintainers '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de")))
