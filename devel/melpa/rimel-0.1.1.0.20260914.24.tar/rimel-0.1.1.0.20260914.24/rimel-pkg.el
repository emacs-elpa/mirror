;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "0.1.1.0.20260914.24"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.11"))
  :url "https://github.com/emacs-rime/rimel"
  :commit "e05f4b0eb2d6d5f9212e91bab5e4b3314db8ff0e"
  :revdesc "e05f4b0eb2d6"
  :keywords '("convenience" "chinese" "input-method" "rime"))
