;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-test" "0.0.0.20190819.44"
  "Browse and execute tests with ivy."
  '((emacs "25.1")
    (ivy   "0.11.0")
    (s     "1.12.0"))
  :url "https://github.com/xmagpie/counsel-test"
  :commit "f0ea446def59a3a8ca40e868fe9d82de268b2abe"
  :revdesc "f0ea446def59"
  :keywords '("tools" "ivy" "counsel" "testing" "ctest" "pytest")
  :authors '(("Konstantin Sorokin" . "sorokin.kc@gmail.com"))
  :maintainers '(("Konstantin Sorokin" . "sorokin.kc@gmail.com")))
