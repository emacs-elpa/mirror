;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-selected" "0.9.1.0.20171223.1"
  "Helm extension for selected.el."
  '((emacs    "24.4")
    (helm     "2.8.6")
    (selected "1.01"))
  :url "https://github.com/takaxp/helm-selected"
  :commit "d2609cdfce14052ab2d9c23761d4fe56966a8ed1"
  :revdesc "d2609cdfce14"
  :keywords '("extensions" "convenience")
  :authors '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg"))
  :maintainers '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg")))
