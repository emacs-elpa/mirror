;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "northcode-theme" "0.1.0.20180423.4"
  "A dark theme focused on blue and orange colors."
  '((emacs "24"))
  :url "https://github.com/Northcode/northcode-theme.el"
  :commit "4d3750461ba25ec45321318b5f1af4e8fdf16147"
  :revdesc "4d3750461ba2"
  :authors '(("Andreas Larsen" . "andreas@northcode.no"))
  :maintainers '(("Andreas Larsen" . "andreas@northcode.no")))
