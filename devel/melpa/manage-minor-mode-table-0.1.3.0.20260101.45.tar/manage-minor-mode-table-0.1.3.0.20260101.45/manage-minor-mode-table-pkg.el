;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "manage-minor-mode-table" "0.1.3.0.20260101.45"
  "Manage minor-modes in table."
  '((emacs             "25.1")
    (manage-minor-mode "1.1"))
  :url "https://github.com/jcs-elpa/manage-minor-mode-table"
  :commit "15730e65792ba5e774562c2311c1674cedd7786e"
  :revdesc "15730e65792b"
  :keywords '("tools" "minor-mode" "manage")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
