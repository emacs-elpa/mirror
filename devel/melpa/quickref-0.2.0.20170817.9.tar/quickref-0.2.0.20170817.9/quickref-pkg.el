;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quickref" "0.2.0.20170817.9"
  "Display relevant notes-to-self in the echo area."
  '((dash "1.0.3")
    (s    "1.0.0"))
  :url "https://github.com/pd/quickref.el"
  :commit "f368c8b8219bb90498c5ab84e26f00eedaa234cf"
  :revdesc "f368c8b8219b")
