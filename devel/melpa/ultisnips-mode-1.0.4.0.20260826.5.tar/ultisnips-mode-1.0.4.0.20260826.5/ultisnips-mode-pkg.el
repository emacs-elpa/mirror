;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "1.0.4.0.20260826.5"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "993076575d073544c8b7d683750d01c3d1030e31"
  :revdesc "1.0.4-5-g993076575d07"
  :keywords '("languages" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
