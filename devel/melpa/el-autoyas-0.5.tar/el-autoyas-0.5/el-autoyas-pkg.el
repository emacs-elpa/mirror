;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-autoyas" "0.5"
  "Automatically create Emacs-Lisp Yasnippets."
  ()
  :url "https://github.com/mlf176f2/el-autoyas.el"
  :commit "bde0251ecb504f585dfa27c205c8e312655310cc"
  :revdesc "v0.5-0-gbde0251ecb50"
  :keywords '("emacs" "lisp" "mode" "yasnippet"))
