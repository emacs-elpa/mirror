;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thingopt" "0.0.0.20160520.6"
  "Thing at Point optional utilities."
  ()
  :url "https://github.com/emacsorphanage/thingopt"
  :commit "5679815852652479f3b3c9f3a98affc927384b2c"
  :revdesc "567981585265"
  :keywords '("convenience")
  :authors '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainers '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com")))
