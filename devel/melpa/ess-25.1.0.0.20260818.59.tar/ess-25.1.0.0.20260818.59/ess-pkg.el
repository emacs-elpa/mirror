;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess" "25.1.0.0.20260818.59"
  "Emacs Speaks Statistics."
  '((emacs "25.1"))
  :url "https://ess.r-project.org/"
  :commit "369a84876c42567ff01627c1b9df0750a727056b"
  :revdesc "v25.01.0-59-g369a84876c42"
  :authors '(("David Smith" . "dsmith@stats.adelaide.edu.au")
             ("A.J. Rossini" . "blindglobe@gmail.com")
             ("Richard M. Heiberger" . "rmh@temple.edu")
             ("Kurt Hornik" . "Kurt.Hornik@R-project.org")
             ("Martin Maechler" . "maechler@stat.math.ethz.ch")
             ("Rodney A. Sparapani" . "rsparapa@mcw.edu")
             ("Stephen Eglen" . "stephen@gnu.org")
             ("Sebastian P. Luque" . "spluque@gmail.com")
             ("Henning Redestig" . "henning.red@googlemail.com")
             ("Vitalie Spinu" . "spinuvit@gmail.com")
             ("Lionel Henry" . "lionel.hry@gmail.com")
             ("J. Alexander Branham" . "alex.branham@gmail.com"))
  :maintainers '(("ESS Core Team" . "ESS-core@r-project.org")))
