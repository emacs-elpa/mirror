;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-id-cleanup" "1.7.1.0.20230922.2"
  "Interactively find, present and maybe delete unused IDs of org-id."
  '((org   "9.3")
    (dash  "2.12")
    (emacs "26.3"))
  :url "https://github.com/marcIhm/org-id-cleanup"
  :commit "45b598c7971d149ce4eae5f790469d89f691c8e6"
  :revdesc "1.7.1-2-g45b598c7971d"
  :authors '(("Marc Ihm" . "marc@ihm.name"))
  :maintainers '(("Marc Ihm" . "marc@ihm.name")))
