;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lirve" "1.5.0.0.20260708.3"
  "Learn irregular verbs in English."
  '((emacs "26.1"))
  :url "https://git.andros.dev/andros/lirve.el"
  :commit "b8dfa92eb51bde15c269dede50342f0b94240a49"
  :revdesc "b8dfa92eb51b"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
