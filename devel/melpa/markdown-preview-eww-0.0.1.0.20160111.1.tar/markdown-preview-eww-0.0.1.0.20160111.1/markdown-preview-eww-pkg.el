;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-preview-eww" "0.0.1.0.20160111.1"
  "Realtime preview by eww."
  '((emacs "24.4"))
  :url "https://github.com/niku/markdown-preview-eww"
  :commit "5853f836425c877c8a956501f0adda137ef1d3b7"
  :revdesc "5853f836425c"
  :authors '(("niku" . "niku@niku.name"))
  :maintainers '(("niku" . "niku@niku.name")))
