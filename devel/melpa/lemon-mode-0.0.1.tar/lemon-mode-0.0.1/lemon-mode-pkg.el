;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lemon-mode" "0.0.1"
  "A major mode for editing lemon grammar files."
  ()
  :url "https://github.com/mooz/lemon-mode"
  :commit "155bfced6c9afc8072a0133d3d1baa54c6d67430"
  :revdesc "155bfced6c9a"
  :keywords '("lemon")
  :authors '(("mooz" . "stillpedant@gmail.com"))
  :maintainers '(("mooz" . "stillpedant@gmail.com")))
