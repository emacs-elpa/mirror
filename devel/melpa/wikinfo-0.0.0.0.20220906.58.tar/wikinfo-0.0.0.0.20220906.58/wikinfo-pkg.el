;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wikinfo" "0.0.0.0.20220906.58"
  "Scrape Wikipedia Infoboxes."
  '((emacs "27.1"))
  :url "https://github.com/progfolio/wikinfo"
  :commit "bf395c9aaf6be7fda371be611005737d52417fec"
  :revdesc "bf395c9aaf6b"
  :keywords '("org" "convenience")
  :authors '(("Nicholas Vollmer" . "progfolio@protonmail.com"))
  :maintainers '(("Nicholas Vollmer" . "progfolio@protonmail.com")))
