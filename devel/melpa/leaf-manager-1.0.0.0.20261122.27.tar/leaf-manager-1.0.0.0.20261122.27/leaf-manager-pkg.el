;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-manager" "1.0.0.0.20261122.27"
  "Configuration manager for leaf based init.el."
  '((emacs        "26.1")
    (leaf         "4.1")
    (leaf-convert "1.0")
    (ppp          "2.1"))
  :url "https://github.com/conao3/leaf-manager.el"
  :commit "87eac3af495aa03352d56acd94e6a25156078b6f"
  :revdesc "87eac3af495a"
  :keywords '("convenience" "leaf")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
