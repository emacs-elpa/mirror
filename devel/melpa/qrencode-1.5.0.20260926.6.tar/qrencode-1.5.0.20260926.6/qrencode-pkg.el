;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "1.5.0.20260926.6"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "06b9be56aff40072b54d211261998b24f0c3cf9b"
  :revdesc "v1.5-6-g06b9be56aff4"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
