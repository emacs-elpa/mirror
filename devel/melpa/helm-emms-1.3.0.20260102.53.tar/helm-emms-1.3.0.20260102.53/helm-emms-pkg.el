;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-emms" "1.3.0.20260102.53"
  "Emms for Helm."
  '((helm   "1.5")
    (emms   "6.0")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/emacs-helm/helm-emms"
  :commit "ae442c2a338c9335cd8e2b27be623b135cde6107"
  :revdesc "v1.3-53-gae442c2a338c"
  :keywords '("multimedia" "emms")
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")))
