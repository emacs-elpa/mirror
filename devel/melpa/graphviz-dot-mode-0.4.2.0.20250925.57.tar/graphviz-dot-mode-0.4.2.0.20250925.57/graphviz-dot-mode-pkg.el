;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphviz-dot-mode" "0.4.2.0.20250925.57"
  "Mode for the dot-language used by graphviz (att)."
  '((emacs "25.0"))
  :url "https://ppareit.github.io/graphviz-dot-mode/"
  :commit "516c151b845a3eb2da73eb4ee648ad99172087ac"
  :revdesc "v0.4.2-57-g516c151b845a"
  :keywords '("mode" "dot" "dot-language" "dotlanguage" "graphviz" "graphs" "att")
  :authors '(("Pieter Pareit" . "pieter.pareit@gmail.com")
             ("Rubens Ramos" . "rubensrATusers.sourceforge.net"))
  :maintainers '(("Pieter Pareit" . "pieter.pareit@gmail.com")))
