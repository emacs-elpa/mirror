;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "objed" "0.8.1.0.20200911.199"
  "Navigate and edit text objects."
  '((emacs  "25")
    (cl-lib "0.5"))
  :url "https://github.com/clemera/objed"
  :commit "e93dda73bd932563d35e76f1c2f1b50895b640cf"
  :revdesc "e93dda73bd93"
  :keywords '("convenience")
  :authors '(("Clemens Radermacher" . "clemera@posteo.net"))
  :maintainers '(("Clemens Radermacher" . "clemera@posteo.net")))
