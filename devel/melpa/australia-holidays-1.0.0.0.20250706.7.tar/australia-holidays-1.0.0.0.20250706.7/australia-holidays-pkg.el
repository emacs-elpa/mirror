;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "australia-holidays" "1.0.0.0.20250706.7"
  "Australian holidays for calendar."
  '((emacs "24.1"))
  :url "https://github.com/jmibanez/australia-holidays.el"
  :commit "a73bbc940bc953164b8ed77e61e65a7a3aff4da5"
  :revdesc "a73bbc940bc9"
  :keywords '("calendar")
  :authors '(("JM Ibañez" . "jm@jmibanez.com"))
  :maintainers '(("JM Ibañez" . "jm@jmibanez.com")))
