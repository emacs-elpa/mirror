;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-yapf" "2016.1"
  "Use yapf to beautify a Python buffer."
  ()
  :url "https://github.com/paetzke/py-yapf.el"
  :commit "a878304202ad827a1f3de3dce1badd9ca8731146"
  :revdesc "a878304202ad"
  :authors '(("Friedrich Paetzke" . "f.paetzke@gmail.com"))
  :maintainers '(("Friedrich Paetzke" . "f.paetzke@gmail.com")))
