;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "engine-mode" "2.2.4.0.20240906.13"
  "Define and query search engines."
  '((emacs "24.4"))
  :url "https://github.com/hrs/engine-mode"
  :commit "1cfdaef7e019aecc1b648036c3434c99d6d308bc"
  :revdesc "1cfdaef7e019"
  :authors '(("Robin Schwartz" . "hello@robinschwartz.me"))
  :maintainers '(("Robin Schwartz" . "hello@robinschwartz.me")))
