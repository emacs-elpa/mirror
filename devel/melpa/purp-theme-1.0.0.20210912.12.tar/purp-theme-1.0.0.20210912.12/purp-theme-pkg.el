;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "purp-theme" "1.0.0.20210912.12"
  "A dark color theme with few colors."
  ()
  :url "https://github.com/gnuvince/purp"
  :commit "8d3510e1ed995b8323cd5205626ddde6386a76ca"
  :revdesc "8d3510e1ed99"
  :keywords '("faces")
  :authors '(("Vincent Foley" . "vfoley@gmail.com"))
  :maintainers '(("Vincent Foley" . "vfoley@gmail.com")))
