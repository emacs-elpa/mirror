;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xref-js2" "1.6.0.20240504.8"
  "Jump to references/definitions using ag & js2-mode's AST."
  '((emacs    "25.1")
    (js2-mode "20150909"))
  :url "https://github.com/NicolasPetton/xref-js2"
  :commit "e215af9eedac69b40942fff9d5514704f9f4d43e"
  :revdesc "e215af9eedac"
  :keywords '("javascript" "convenience" "tools")
  :authors '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")))
