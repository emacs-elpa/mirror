;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "czech-holidays" "0.0.1.0.20160113.10"
  "Adds a list of Czech public holidays to Emacs calendar."
  ()
  :url "https://github.com/chkhd/czech-holidays"
  :commit "d19828122cf3322bcf50601cefa4ac385d2d8f82"
  :revdesc "d19828122cf3"
  :keywords '("calendar")
  :authors '(("David Chkhikvadze" . "david.chk@outlook.com"))
  :maintainers '(("David Chkhikvadze" . "david.chk@outlook.com")))
