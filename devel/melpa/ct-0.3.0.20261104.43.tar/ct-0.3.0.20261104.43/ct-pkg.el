;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ct" "0.3.0.20261104.43"
  "Color Tools - a color api."
  '((emacs "26.1")
    (dash  "2.18.0")
    (hsluv "1.0.0"))
  :url "https://github.com/neeasade/ct.el"
  :commit "99c34adf2c2242444467f69ae2aee7dd7eaae594"
  :revdesc "99c34adf2c22"
  :keywords '("convenience" "color" "theming" "background" "rgb" "hsv" "hsl" "hct" "lab" "oklab" "oklch"))
