;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pamparam" "0.1.0.0.20210105.9"
  "Simple and fast flashcards."
  '((emacs        "26.1")
    (lispy        "0.27.0")
    (worf         "0.1.0")
    (ivy-posframe "0.5.5"))
  :url "https://github.com/abo-abo/pamparam"
  :commit "0ba91149095bee8c43688c68f83f4d365fbe6771"
  :revdesc "0ba91149095b"
  :keywords '("outlines" "hypermedia" "flashcards" "memory")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
