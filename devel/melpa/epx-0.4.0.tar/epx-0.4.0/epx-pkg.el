;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epx" "0.4.0"
  "Manage and run project-specific shell commands."
  '((emacs "29.1"))
  :url "https://git.sr.ht/~alex-iam/epx"
  :commit "300aa795f6ff130b1a21aa637c1831b8aa866d6a"
  :revdesc "300aa795f6ff"
  :keywords '("project" "shell" "tools")
  :authors '(("Oleksandr Korzh" . "alex@korzh.me"))
  :maintainers '(("Oleksandr Korzh" . "alex@korzh.me")))
