;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "0.1.0.20260705.133"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "cd637a44e69b8ac3bdb9d99bee5066be279da1d8"
  :revdesc "cd637a44e69b"
  :keywords '("data" "extensions"))
