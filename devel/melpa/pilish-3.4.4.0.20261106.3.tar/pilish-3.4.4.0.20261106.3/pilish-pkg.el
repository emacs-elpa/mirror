;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.4.4.0.20261106.3"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.5.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "a01a0f7ed1c5a1717085cac34ad3db664a610326"
  :revdesc "v3.4.4-3-ga01a0f7ed1c5"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
