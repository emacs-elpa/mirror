;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edebug-inline-result" "0.1.0.20220820.19"
  "Show Edebug result inline."
  '((emacs "25.1"))
  :url "https://repo.or.cz/edebug-inline-result.git"
  :commit "90e401ae3e7b3c85da8b24af940fd97f5e744625"
  :revdesc "90e401ae3e7b"
  :keywords '("extensions" "lisp" "tools")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
