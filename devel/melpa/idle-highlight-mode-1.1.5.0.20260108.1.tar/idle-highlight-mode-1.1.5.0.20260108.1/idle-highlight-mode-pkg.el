;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idle-highlight-mode" "1.1.5.0.20260108.1"
  "Highlight the word the point is on."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-idle-highlight-mode"
  :commit "83aa002c837fc6c6e4ce7069c169875beeb1d41e"
  :revdesc "83aa002c837f"
  :keywords '("convenience")
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
