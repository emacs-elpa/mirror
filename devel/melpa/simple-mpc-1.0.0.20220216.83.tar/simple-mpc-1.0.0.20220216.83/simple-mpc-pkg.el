;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-mpc" "1.0.0.20220216.83"
  "Provides a simple interface to mpc."
  '((s "1.10.0"))
  :url "https://github.com/jorenvo/simple-mpc"
  :commit "57ee14ada8aec477ddde5e4f632c8d3d99a66535"
  :revdesc "57ee14ada8ae"
  :keywords '("multimedia" "mpd" "mpc")
  :authors '(("Joren Van Onder" . "joren@jvo.sh"))
  :maintainers '(("Joren Van Onder" . "joren@jvo.sh")))
