;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orderless" "1.7.0.20260830.6"
  "Completion style for matching regexps in any order."
  '((emacs  "27.1")
    (compat "31"))
  :url "https://github.com/oantolin/orderless"
  :commit "51f677f464424ce3c46e3deacb7709784795a03b"
  :revdesc "1.7-6-g51f677f46442"
  :keywords '("matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
