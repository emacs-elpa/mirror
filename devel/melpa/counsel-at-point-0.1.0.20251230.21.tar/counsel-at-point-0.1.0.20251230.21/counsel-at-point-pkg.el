;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-at-point" "0.1.0.20251230.21"
  "Context-sensitive project search."
  '((emacs   "29.1")
    (counsel "0.13.0"))
  :url "https://codeberg.org/ideasman42/emacs-counsel-at-point"
  :commit "720347962085ed4f0efe5db797882cf3f35ad68c"
  :revdesc "720347962085"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
