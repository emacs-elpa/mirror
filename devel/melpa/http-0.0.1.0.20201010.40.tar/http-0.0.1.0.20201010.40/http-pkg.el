;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "http" "0.0.1.0.20201010.40"
  "Yet another HTTP client."
  '((emacs         "24.4")
    (request       "0.2.0")
    (edit-indirect "0.1.4"))
  :url "https://github.com/emacs-pe/http.el"
  :commit "5fdceed1fbf36e274e578e349a53ce922c574774"
  :revdesc "5fdceed1fbf3"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
