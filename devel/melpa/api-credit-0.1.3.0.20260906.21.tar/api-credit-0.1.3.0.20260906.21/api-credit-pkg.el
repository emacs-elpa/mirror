;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "api-credit" "0.1.3.0.20260906.21"
  "AI API balance in the modeline."
  '((emacs "25.1"))
  :url "https://github.com/OverbearingPearl/api-credit"
  :commit "40a8188c489ce320a364364c0a8ab48245319ea9"
  :revdesc "40a8188c489c"
  :keywords '("comm" "convenience")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
