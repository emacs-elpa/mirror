;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-toodledo" "2.1.0.0.20150301.173"
  "Toodledo integration for Emacs Org mode."
  '((request-deferred "0.2.0")
    (emacs            "24")
    (cl-lib           "0.5"))
  :url "https://github.com/myuhe/org-toodledo"
  :commit "01b53b637f304b89cd3bf2d29009b5ed6ad9466d"
  :revdesc "2.1.0-173-g01b53b637f30"
  :keywords '("outlines" "data")
  :authors '(("Christopher J. White" . "emacs@grierwhite.com"))
  :maintainers '(("Christopher J. White" . "emacs@grierwhite.com")))
