;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-json" "0.4.0"
  "JSON export backend for Org mode."
  '((emacs "27.1")
    (org   "9.4")
    (s     "1.12"))
  :url "https://github.com/jlumpe/ox-json"
  :commit "3fa63a260fc58b09eed5dd8c36904ae80148adbe"
  :revdesc "3fa63a260fc5"
  :keywords '("outlines")
  :authors '(("Jared Lumpe" . "jared@jaredlumpe.com"))
  :maintainers '(("Jared Lumpe" . "jared@jaredlumpe.com")))
