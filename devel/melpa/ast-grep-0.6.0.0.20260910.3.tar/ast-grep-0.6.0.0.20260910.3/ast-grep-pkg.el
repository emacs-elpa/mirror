;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ast-grep" "0.6.0.0.20260910.3"
  "Search code using ast-grep with completing-read interface."
  '((emacs "28.1"))
  :url "https://github.com/sunskyxh/ast-grep.el"
  :commit "0f3e68622f5a83165bf017fe43d8050344cbb411"
  :revdesc "0f3e68622f5a"
  :keywords '("tools" "matching")
  :authors '(("SunskyXH" . "sunskyxh@gmail.com"))
  :maintainers '(("SunskyXH" . "sunskyxh@gmail.com")))
