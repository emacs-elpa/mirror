;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "1.0.0.0.20260715.434"
  "Friendly AI assistant for Ollama and cloud LLMs."
  '((emacs     "29.1")
    (transient "0.4.0"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "296dd738e43b91bd877743acd7e57139d437cc97"
  :revdesc "296dd738e43b"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
