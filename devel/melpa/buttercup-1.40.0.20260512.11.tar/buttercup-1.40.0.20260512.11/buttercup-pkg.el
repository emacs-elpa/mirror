;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buttercup" "1.40.0.20260512.11"
  "Behavior-Driven Emacs Lisp Testing."
  '((emacs "24.4"))
  :url "https://github.com/jorgenschaefer/emacs-buttercup"
  :commit "39c8e762408a166a5afa03b8e79dd8d1a0de5caa"
  :revdesc "v1.40-11-g39c8e762408a"
  :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainers '(("Ola Nilsson" . "ola.nilsson@gmail.com")))
