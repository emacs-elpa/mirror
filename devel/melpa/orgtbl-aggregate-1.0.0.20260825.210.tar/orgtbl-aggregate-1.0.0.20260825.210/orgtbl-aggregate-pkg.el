;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "1.0.0.20260825.210"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "a4348971a8f0645d41ebe143e4de808c0eaeaa03"
  :revdesc "a4348971a8f0"
  :keywords '("data" "extensions"))
