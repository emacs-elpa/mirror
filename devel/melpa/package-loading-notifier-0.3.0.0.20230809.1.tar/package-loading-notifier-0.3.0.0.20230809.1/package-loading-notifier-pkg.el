;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-loading-notifier" "0.3.0.0.20230809.1"
  "Notify a package is being loaded."
  '((emacs "25"))
  :url "https://github.com/tttuuu888/package-loading-notifier"
  :commit "f64f994cb1a55f9d59444deaec884bff0ed2b26e"
  :revdesc "f64f994cb1a5"
  :keywords '("convenience" "faces" "config" "startup")
  :authors '(("SeungKi Kim" . "tttuuu888@gmail.com"))
  :maintainers '(("SeungKi Kim" . "tttuuu888@gmail.com")))
