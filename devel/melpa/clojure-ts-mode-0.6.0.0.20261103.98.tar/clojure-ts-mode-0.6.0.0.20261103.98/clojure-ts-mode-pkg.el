;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "0.6.0.0.20261103.98"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "https://github.com/clojure-emacs/clojure-ts-mode"
  :commit "51df988a3874e2f02a64f2d67b6ef97c7fc987b8"
  :revdesc "51df988a3874"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :authors '(("Danny Freeman" . "danny@dfreeman.email")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
