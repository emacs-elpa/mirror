;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wwtime" "1.5.0.20151122.4"
  "Insert a time of day with appropriate world-wide localization."
  ()
  :url "https://github.com/ndw/wwtime"
  :commit "d04d8fa814b5d3644efaeb28f25520ada69acbbd"
  :revdesc "d04d8fa814b5"
  :keywords '("time")
  :authors '(("Norman Walsh" . "ndw@nwalsh.com"))
  :maintainers '(("Norman Walsh" . "ndw@nwalsh.com")))
