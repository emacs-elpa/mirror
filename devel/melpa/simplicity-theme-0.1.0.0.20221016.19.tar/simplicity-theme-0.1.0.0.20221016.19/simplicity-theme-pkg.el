;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simplicity-theme" "0.1.0.0.20221016.19"
  "A minimalist dark theme."
  '((emacs "24.1"))
  :url "https://github.com/smallwat3r/emacs-simplicity-theme"
  :commit "f4aab6aa07b536688eb62355b83dde5fcd16e049"
  :revdesc "f4aab6aa07b5"
  :keywords '("faces" "theme" "minimal")
  :authors '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com"))
  :maintainers '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com")))
