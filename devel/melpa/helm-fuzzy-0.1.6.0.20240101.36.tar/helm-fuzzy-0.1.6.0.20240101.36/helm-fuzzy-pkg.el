;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-fuzzy" "0.1.6.0.20240101.36"
  "Fuzzy matching for helm source."
  '((emacs "24.4")
    (helm  "1.7.9")
    (flx   "0.5"))
  :url "https://github.com/jcs-elpa/helm-fuzzy"
  :commit "6ae944c04464bf5984e4180c8353c7fdcf17f672"
  :revdesc "6ae944c04464"
  :keywords '("matching" "fuzzy" "helm" "source")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
