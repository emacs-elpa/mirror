;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yagist" "0.8.12.0.20160418.6"
  "Yet Another Emacs integration for gist.github.com."
  '((cl-lib "0.3"))
  :url "https://github.com/mhayashi1120/yagist.el"
  :commit "10da4baa272ff0f7052f17debecc340764c7003f"
  :revdesc "10da4baa272f"
  :keywords '("tools")
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
