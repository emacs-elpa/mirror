;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tiles" "0.6"
  "Tagged Instant Lightweight Emacs Snippets."
  '((emacs "29.1"))
  :url "https://github.com/ctanas/tiles"
  :commit "6af198873367b99454ff0db5133c2382a0e26242"
  :revdesc "6af198873367"
  :keywords '("files" "text" "convenience")
  :authors '(("Claudiu Tănăselia" . "https://www.tanaselia.ro"))
  :maintainers '(("Claudiu Tănăselia" . "https://www.tanaselia.ro")))
