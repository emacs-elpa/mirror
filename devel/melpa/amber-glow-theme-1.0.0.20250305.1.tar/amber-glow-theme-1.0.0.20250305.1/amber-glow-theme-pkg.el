;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amber-glow-theme" "1.0.0.20250305.1"
  "A warm and inviting theme."
  '((emacs "24.1"))
  :url "https://github.com/madara123pain/unique-emacs-theme-pack"
  :commit "43afeb68b3ba0394f8cc925ebb90e9a6620b4b28"
  :revdesc "43afeb68b3ba"
  :keywords '("faces" "theme" "warm" "amber" "glow" "dark"))
