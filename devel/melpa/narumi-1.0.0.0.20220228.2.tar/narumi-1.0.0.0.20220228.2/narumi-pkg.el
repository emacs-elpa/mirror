;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "narumi" "1.0.0.0.20220228.2"
  "A dashboard that displays a ramdom sampled image."
  '((emacs "26.1"))
  :url "https://github.com/nryotaro/narumi"
  :commit "2f23f03a7b94766799f26605e167b259a4a90903"
  :revdesc "2f23f03a7b94")
