;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "2.2.0"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "73f0ff412b073d9fa489cd755d8dd6e2b05359f1"
  :revdesc "73f0ff412b07"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
