;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-line" "1.6.0.20261119.4"
  "Custom and simple mode line."
  '((emacs "29.1"))
  :url "https://gitlab.com/aimebertrand/timu-line"
  :commit "1031b5c49fc2488249bb92b5f5363696b9ce6847"
  :revdesc "1031b5c49fc2"
  :keywords '("modeline" "frames" "ui")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
