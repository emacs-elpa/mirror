;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-summary" "0.1.0.0.20260607.28"
  "Feed summary interface for elfeed."
  '((emacs         "27.1")
    (magit-section "3.3.0")
    (elfeed        "3.4.1"))
  :url "https://github.com/SqrtMinusOne/elfeed-summary.el"
  :commit "d8f237530c05c8be3093af295d3f5d530c2d3130"
  :revdesc "d8f237530c05"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
