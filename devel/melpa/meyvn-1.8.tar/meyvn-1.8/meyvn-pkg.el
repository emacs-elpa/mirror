;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meyvn" "1.8"
  "Meyvn client."
  '((emacs    "28.1")
    (cider    "0.23")
    (s        "1.12")
    (dash     "2.17")
    (parseedn "1.1.0")
    (parseclj "1.1.0")
    (geiser   "0.12"))
  :url "https://github.com/danielsz/meyvn-el"
  :commit "48c12b8d7d79c1b35d54d195d1ce4c7113ef5215"
  :revdesc "48c12b8d7d79"
  :authors '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com"))
  :maintainers '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com")))
