;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "1.10.0.0.20260802.7"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://codeberg.org/mclear-tools/tabspaces"
  :commit "5254c8b8352bcb036cc6096af2d35e7e4da02c2c"
  :revdesc "5254c8b8352b"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
