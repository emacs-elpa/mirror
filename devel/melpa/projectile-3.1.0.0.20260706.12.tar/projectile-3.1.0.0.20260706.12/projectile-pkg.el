;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.1.0.0.20260706.12"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "fe578beeca120bb5ff1ce8f16ba9b083b7d3e79e"
  :revdesc "v3.1.0-12-gfe578beeca12"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
