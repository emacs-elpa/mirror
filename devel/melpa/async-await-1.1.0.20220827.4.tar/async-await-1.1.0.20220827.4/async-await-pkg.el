;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async-await" "1.1.0.20220827.4"
  "Async/Await."
  '((emacs   "25.1")
    (promise "1.1")
    (iter2   "0.9.10"))
  :url "https://github.com/chuntaro/emacs-async-await"
  :commit "e0d15e8057ed7520100bc50c5552278292ebcb07"
  :revdesc "1.1-4-ge0d15e8057ed"
  :keywords '("async" "await" "convenience")
  :authors '(("chuntaro" . "chuntaro@sakura-games.jp"))
  :maintainers '(("chuntaro" . "chuntaro@sakura-games.jp")))
