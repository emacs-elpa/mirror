;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "1.4.0.0.20260728.139"
  "Major mode for Godot's GDScript language."
  '((emacs "29.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "2a7efd55946b61e0a3e40700db5c53ce3b8807b9"
  :revdesc "2a7efd55946b"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
