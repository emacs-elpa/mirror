;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mozc-im" "0.1.0.20160412.10"
  "Mozc with input-method-function interface."
  '((mozc "0"))
  :url "https://github.com/d5884/mozc-im"
  :commit "df614a1076c28a11551fb3e822868bae47e855a5"
  :revdesc "df614a1076c2"
  :keywords '("i18n" "extentions")
  :authors '(("Daisuke Kobayashi" . "d5884jp@gmail.com"))
  :maintainers '(("Daisuke Kobayashi" . "d5884jp@gmail.com")))
