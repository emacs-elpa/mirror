;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "execline" "1.1"
  "Major mode for editing execline scripts."
  '((emacs "26.1")
    (s     "1.6.0"))
  :url "https://gitlab.com/KAction/emacs-execline"
  :commit "c75dd9b2c54d8e59fc35fd4bd98d8e213948a3f5"
  :revdesc "v1.1-0-gc75dd9b2c54d"
  :keywords '("tools" "unix" "languages")
  :authors '(("Dmitry Bogatov" . "KAction@debian.org"))
  :maintainers '(("Dmitry Bogatov" . "KAction@debian.org")))
