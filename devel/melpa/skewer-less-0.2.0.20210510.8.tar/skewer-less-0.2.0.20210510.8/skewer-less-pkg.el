;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "skewer-less" "0.2.0.20210510.8"
  "Skewer support for live LESS stylesheet updates."
  '((skewer-mode "1.5.3"))
  :url "https://github.com/purcell/skewer-less"
  :commit "baa973581c2ab7326db65803df97d1a7382b6564"
  :revdesc "baa973581c2a"
  :keywords '("languages" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
