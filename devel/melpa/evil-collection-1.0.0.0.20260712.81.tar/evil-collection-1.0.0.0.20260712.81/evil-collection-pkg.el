;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "1.0.0.0.20260712.81"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "a55c082c59ad811f56627400db3018dfba41e8e2"
  :revdesc "a55c082c59ad"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
