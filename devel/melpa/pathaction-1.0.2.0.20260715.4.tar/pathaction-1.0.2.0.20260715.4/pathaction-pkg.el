;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "1.0.2.0.20260715.4"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "5d80485e7f006a827fcd9b55f40481785abf31ee"
  :revdesc "1.0.2-4-g5d80485e7f00"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
