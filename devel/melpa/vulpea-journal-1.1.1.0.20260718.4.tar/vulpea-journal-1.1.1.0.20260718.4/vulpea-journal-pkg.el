;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-journal" "1.1.1.0.20260718.4"
  "Daily note interface for vulpea."
  '((emacs     "29.1")
    (vulpea    "2.5.0")
    (vulpea-ui "1.1.0")
    (vui       "1.3.0")
    (dash      "2.20.0"))
  :url "https://github.com/d12frosted/vulpea-journal"
  :commit "3bd4fbbae8deece4d595f39e6f629b6cfeaf888f"
  :revdesc "v1.1.1-4-g3bd4fbbae8de"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
