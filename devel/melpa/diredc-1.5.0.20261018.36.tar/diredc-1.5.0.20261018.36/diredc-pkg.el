;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "1.5.0.20261018.36"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "29b90c68a9548cd8005319fa44b42b55dc7657c1"
  :revdesc "29b90c68a954"
  :keywords '("files"))
