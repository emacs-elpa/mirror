;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-rectangle" "1.1.4.0.20200911.2"
  "Another rectangle-mark command (rewrite of rect-mark)."
  ()
  :url "http://zk-phi.github.io/"
  :commit "43ee8aea9998b34a9fdb28d7da2e4f75e4154030"
  :revdesc "43ee8aea9998")
