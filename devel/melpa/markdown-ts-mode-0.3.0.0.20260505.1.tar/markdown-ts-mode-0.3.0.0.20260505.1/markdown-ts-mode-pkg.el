;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-ts-mode" "0.3.0.0.20260505.1"
  "Major mode for Markdown using Treesitter."
  '((emacs "29.1"))
  :url "https://github.com/LionyxML/markdown-ts-mode"
  :commit "e7e78ec55213909d2b70e3dd943b776f622cc991"
  :revdesc "e7e78ec55213"
  :keywords '("languages" "matching" "faces"))
