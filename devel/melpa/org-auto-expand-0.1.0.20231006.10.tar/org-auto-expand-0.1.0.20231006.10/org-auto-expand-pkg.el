;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-auto-expand" "0.1.0.20231006.10"
  "Automatically expand certain headings."
  '((emacs "26.1")
    (org   "9.6"))
  :url "https://github.com/alphapapa/org-auto-expand"
  :commit "86e3b24e894ab377ea005b1a574e77daace0451d"
  :revdesc "0.1-10-g86e3b24e894a"
  :keywords '("convenience" "outlines" "org")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
