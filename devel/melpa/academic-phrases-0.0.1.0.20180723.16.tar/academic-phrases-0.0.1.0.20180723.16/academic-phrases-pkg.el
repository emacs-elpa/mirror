;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "academic-phrases" "0.0.1.0.20180723.16"
  "Bypass that mental block when writing your papers."
  '((dash  "2.12.0")
    (s     "1.12.0")
    (ht    "2.0")
    (emacs "24"))
  :url "https://github.com/nashamri/academic-phrases"
  :commit "25d9cf67feac6359cb213f061735e2679c84187f"
  :revdesc "25d9cf67feac"
  :keywords '("academic" "convenience" "papers" "writing" "wp")
  :authors '(("Nasser Alshammari" . "designernasser@gmail.com"))
  :maintainers '(("Nasser Alshammari" . "designernasser@gmail.com")))
