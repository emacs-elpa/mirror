;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nickel-mode" "0.0.0.20240514.47"
  "A major mode for editing Nickel source code."
  '((emacs "24.3"))
  :url "https://github.com/nickel-lang/nickel-mode"
  :commit "71441281e66500e978e10eb44d58e33a28f55b4e"
  :revdesc "71441281e665"
  :keywords '("languages" "configuration-language" "configuration" "nickel" "infrastructure")
  :authors '(("The Nickel Team" . "(nickel-lang@tweag.io)"))
  :maintainers '(("The Nickel Team" . "(nickel-lang@tweag.io)")))
