;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.5.3.0.20260826.26"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "c6118f3779659ed2ff8ec8f651bd66c8eea3d2bf"
  :revdesc "v4.5.3-26-gc6118f377965"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
