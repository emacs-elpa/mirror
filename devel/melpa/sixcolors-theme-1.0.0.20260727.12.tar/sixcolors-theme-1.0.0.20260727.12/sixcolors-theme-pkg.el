;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sixcolors-theme" "1.0.0.20260727.12"
  "Just another theme."
  '((emacs "27.1"))
  :url "https://github.com/mastro35/sixcolors-theme"
  :commit "b547ee2c9501dbf0f70e2189d4a4eb189ebb3d1b"
  :revdesc "b547ee2c9501"
  :keywords '("faces" "colors" "apple" "sixcolors" "vintage" "dark")
  :authors '(("Davide Mastromatteo" . "mastro35@gmail.com"))
  :maintainers '(("Davide Mastromatteo" . "mastro35@gmail.com")))
