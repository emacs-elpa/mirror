;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js2-closure" "2.2.1"
  "Google Closure dependency manager."
  '((js2-mode "20150909"))
  :url "https://github.com/jart/js2-closure"
  :commit "74a75f001a8bc2b9c02b9e8b4557f7ee3c5f84fb"
  :revdesc "74a75f001a8b"
  :keywords '("javascript" "closure")
  :authors '(("Justine Tunney" . "jart@google.com"))
  :maintainers '(("Justine Tunney" . "jart@google.com")))
