;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.3.0.0.20261022.4"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.4.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "1d55b65dece0ca66353cfc83e652b32acaa25196"
  :revdesc "v3.3.0-4-g1d55b65dece0"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
