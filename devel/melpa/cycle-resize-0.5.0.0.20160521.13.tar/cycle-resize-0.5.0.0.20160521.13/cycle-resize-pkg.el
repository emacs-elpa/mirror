;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cycle-resize" "0.5.0.0.20160521.13"
  "Cycle resize the current window horizontally or vertically."
  ()
  :url "https://github.com/pierre-lecocq/cycle-resize"
  :commit "7d255d6fe85f12c967a0f7fcfcf18633be194c88"
  :revdesc "7d255d6fe85f")
