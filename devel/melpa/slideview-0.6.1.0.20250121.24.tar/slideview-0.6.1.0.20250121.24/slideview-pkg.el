;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slideview" "0.6.1.0.20250121.24"
  "File slideshow."
  '((emacs "25.1"))
  :url "https://github.com/mhayashi1120/Emacs-slideview"
  :commit "4d7c8b91d339126b4c5a6365362aadb90ee0e7f9"
  :revdesc "4d7c8b91d339"
  :keywords '("files")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
