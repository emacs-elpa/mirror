;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3.0.20260929.86"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "a05648f9c770f2446df0c6319a6a1b710b5891bc"
  :revdesc "a05648f9c770"
  :keywords '("build tools" "languages"))
