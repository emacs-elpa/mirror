;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.2.4"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "ef3b7507c756dd9cff4f905748c5be6493f48a26"
  :revdesc "1.2.4-0-gef3b7507c756"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
