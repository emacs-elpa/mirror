;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lesim-mode" "0.3.4.0.20260318.6"
  "Major mode for Learning Simulator scripts."
  '((emacs "28.1"))
  :url "https://github.com/drghirlanda/lesim-mode"
  :commit "8524702bcf9285c60066d38b4e9935b5bf053d38"
  :revdesc "8524702bcf92"
  :keywords '("languages" "faces")
  :authors '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainers '(("Stefano Ghirlanda" . "drghirlanda@gmail.com")))
