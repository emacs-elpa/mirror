;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rats" "0.2.0.0.20170818.14"
  "Rapid testing suite for Go."
  '((s       "1.10.0")
    (go-mode "1.3.1")
    (cl-lib  "0.5"))
  :url "https://github.com/ane/rats.el"
  :commit "a6d55aebcc54f669c6c6ffedf84364c4097903cc"
  :revdesc "0.2.0-14-ga6d55aebcc54"
  :keywords '("go")
  :authors '(("Antoine Kalmbach" . "ane@iki.fi"))
  :maintainers '(("Antoine Kalmbach" . "ane@iki.fi")))
