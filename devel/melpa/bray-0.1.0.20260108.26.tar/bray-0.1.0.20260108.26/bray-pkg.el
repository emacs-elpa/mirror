;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bray" "0.1.0.20260108.26"
  "Lightweight modal editing."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-bray"
  :commit "ad06429ac60a5e90e2c2de6ea24ec561cecfb2d0"
  :revdesc "ad06429ac60a"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
