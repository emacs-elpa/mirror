;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chronos" "1.3.0.20240525.5"
  "Multiple simultaneous countdown / countup timers."
  '((emacs "27.1"))
  :url "https://github.com/DarkBuffalo/chronos"
  :commit "5ea0bf7c3881ea905e280446342539b242401979"
  :revdesc "5ea0bf7c3881"
  :keywords '("calendar")
  :authors '(("David Knight" . "dxknight@opmbx.org"))
  :maintainers '(("David Knight" . "dxknight@opmbx.org")))
