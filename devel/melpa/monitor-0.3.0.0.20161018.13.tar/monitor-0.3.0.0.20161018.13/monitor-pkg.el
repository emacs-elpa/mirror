;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monitor" "0.3.0.0.20161018.13"
  "Utilities for monitoring expressions."
  '((dash "2.13.0"))
  :url "https://github.com/guiltydolphin/monitor"
  :commit "63f4643a0ee81616dbb692b8b03bae21df2283e2"
  :revdesc "63f4643a0ee8"
  :keywords '("lisp" "monitor" "utility")
  :authors '(("Ben Moon" . "software@guiltydolphin.com"))
  :maintainers '(("Ben Moon" . "software@guiltydolphin.com")))
