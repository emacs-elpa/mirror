;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "6.3.0"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "c30926dcd2bcbc7c2d89d3e5d2b631735bd1c92b"
  :revdesc "v6.3.0-0-gc30926dcd2bc"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
