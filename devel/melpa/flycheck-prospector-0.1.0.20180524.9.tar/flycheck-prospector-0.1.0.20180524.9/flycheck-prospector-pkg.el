;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-prospector" "0.1.0.20180524.9"
  "Support prospector in flycheck."
  '((flycheck "0.22"))
  :url "https://github.com/chocoelho/flycheck-prospector"
  :commit "d5b81adb5c8261b935baf0a614dd4b776280392e"
  :revdesc "d5b81adb5c82"
  :authors '(("Carlos Coelho" . "carlospecter@gmail.com"))
  :maintainers '(("Carlos Coelho" . "carlospecter@gmail.com")))
