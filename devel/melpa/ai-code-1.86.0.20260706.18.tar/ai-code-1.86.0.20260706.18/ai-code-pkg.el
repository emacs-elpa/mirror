;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.86.0.20260706.18"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "55c5dfaaab8b0de40f6f389969c9cea21c0fd09e"
  :revdesc "55c5dfaaab8b"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
