;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wanderlust" "0.0.0.20251102.4898"
  "Yet Another Message Interface on Emacsen."
  '((emacs "24.5")
    (apel  "0")
    (flim  "0")
    (semi  "0"))
  :url "https://github.com/emacsmirror/wanderlust"
  :commit "9414fc386945870913e5183817593596315eddd8"
  :revdesc "9414fc386945"
  :keywords '("mail" "net news")
  :authors '(("Yuuichi Teranishi" . "teranisi@gohome.org")
             ("Masahiro MURATA" . "muse@ba2.so-net.ne.jp"))
  :maintainers '(("Yuuichi Teranishi" . "teranisi@gohome.org")
                 ("Masahiro MURATA" . "muse@ba2.so-net.ne.jp")))
