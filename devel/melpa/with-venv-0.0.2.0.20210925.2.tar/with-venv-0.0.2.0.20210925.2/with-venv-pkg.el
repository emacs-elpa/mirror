;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-venv" "0.0.2.0.20210925.2"
  "Execute with Python virtual environment activated."
  '((cl-lib "0.5")
    (emacs  "24.4"))
  :url "https://github.com/10sr/with-venv-el"
  :commit "773192d892ec0341e023d8b5e80639f8eb79f2a5"
  :revdesc "773192d892ec"
  :keywords '("processes" "python" "venv")
  :authors '(("10sr" . "8.slashes[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8.slashes[at]gmail[dot]com")))
