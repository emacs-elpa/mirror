;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ssass-mode" "0.2.0.20200211.4"
  "Edit Sass without a Turing Machine."
  '((emacs "24.3"))
  :url "https://github.com/AdamNiederer/ssass-mode"
  :commit "96f557887ad97a0066a60c54f92b7234b8407016"
  :revdesc "0.2-4-g96f557887ad9"
  :keywords '("languages" "sass")
  :authors '(("Adam Niederer" . "adam.niederer@gmail.com"))
  :maintainers '(("Adam Niederer" . "adam.niederer@gmail.com")))
