;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undohist" "0.3.0.0.20260103.19"
  "Persistent undo history for GNU Emacs."
  '((cl-lib "1.0"))
  :url "https://github.com/emacsorphanage/undohist"
  :commit "8ff68451ff65da9dcc035607f82a0bac5cf4a545"
  :revdesc "0.3.0-19-g8ff68451ff65"
  :keywords '("convenience")
  :authors '(("MATSUYAMA Tomohiro" . "m2ym.pub@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
