;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lentic-server" "0.2"
  "Web Server for Emacs Literate Source."
  '((lentic     "0.8")
    (web-server "0.1.1"))
  :url "https://github.com/phillord/lentic-server"
  :commit "732b88e7a183707ba65c38e8b3517cac42572644"
  :revdesc "732b88e7a183"
  :authors '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
  :maintainers '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk")))
