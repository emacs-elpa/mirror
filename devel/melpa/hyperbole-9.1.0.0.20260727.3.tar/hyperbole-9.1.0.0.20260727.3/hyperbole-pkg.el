;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.1.0.0.20260727.3"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "89755af46aace89d2f2ab7c47ef48b4131d1fd08"
  :revdesc "89755af46aac"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")
                 ("Mats Lidell" . "matsl@gnu.org")))
