;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-toml" "0.1.0.20211026.19"
  "TOML table name at point for ElDoc."
  '((emacs "24.4"))
  :url "https://github.com/it-is-wednesday/eldoc-toml"
  :commit "61106be3c3f3a5b293c3f285eec8c6f400142b6d"
  :revdesc "61106be3c3f3"
  :keywords '("data")
  :authors '(("Maor Kadosh" . "git@avocadosh.xyz"))
  :maintainers '(("Maor Kadosh" . "git@avocadosh.xyz")))
