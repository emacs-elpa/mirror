;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-fill-struct" "0.1.0.20230308.5"
  "Fill struct for golang."
  '((emacs "24"))
  :url "https://github.com/s-kostyaev/go-fill-struct"
  :commit "9e2e4be5af716ecadba809e73ddc95d4c772b2d9"
  :revdesc "9e2e4be5af71"
  :keywords '("tools")
  :authors '(("Sergey Kostyaev" . "feo.me@ya.ru"))
  :maintainers '(("Sergey Kostyaev" . "feo.me@ya.ru")))
