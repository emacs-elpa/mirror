;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jit-lock-stealth-progress" "0.1.0.20240616.14"
  "JIT lock stealth mode-line progress."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-jit-lock-stealth-progress"
  :commit "caf256543cfe5404333f5cf914a478d14b2ec102"
  :revdesc "caf256543cfe"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
