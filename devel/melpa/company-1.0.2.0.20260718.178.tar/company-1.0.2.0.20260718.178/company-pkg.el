;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "1.0.2.0.20260718.178"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "24a4a6b129546a1ce2fcb3e3c5948259dff00685"
  :revdesc "24a4a6b12954"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
