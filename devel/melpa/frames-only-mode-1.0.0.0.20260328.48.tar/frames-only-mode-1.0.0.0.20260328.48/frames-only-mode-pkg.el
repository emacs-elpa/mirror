;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frames-only-mode" "1.0.0.0.20260328.48"
  "Use frames instead of Emacs windows."
  '((emacs "28.1"))
  :url "https://github.com/davidshepherd7/frames-only-mode"
  :commit "ba54b8ff096b3317fc4a28ca5bbb8e46199c2b8d"
  :revdesc "ba54b8ff096b"
  :keywords '("frames" "windows")
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
