;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-add-tags" "0.4.0.20211122.3"
  "Add field tags for struct fields."
  '((emacs "24.3")
    (s     "1.11.0"))
  :url "https://github.com/syohex/emacs-go-add-tags"
  :commit "93ecde9f82bc960493eaf6921d46a5adc3699ffc"
  :revdesc "93ecde9f82bc"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
