;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qso" "1.0.1.0.20260906.10"
  "Amateur radio QSO logging."
  '((emacs "25.1"))
  :url "https://github.com/K6SM/Emacs-QSO-Logger"
  :commit "a8945aa7855d913215c406fca4c604f4662df2b3"
  :revdesc "a8945aa7855d"
  :keywords '("comm" "hamradio" "adif" "logging"))
