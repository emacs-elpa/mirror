;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-modern" "1.14.0.20260707.4"
  "Modern looks for Org."
  '((emacs  "29.1")
    (org    "9.6")
    (compat "31"))
  :url "https://github.com/minad/org-modern"
  :commit "d41bedbab849745bd10e300b8d93a17bc78a5ad6"
  :revdesc "1.14-4-gd41bedbab849"
  :keywords '("outlines" "hypermedia" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
