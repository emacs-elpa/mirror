;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbake" "0.1.0.20260704.73"
  "Running bitbake from emacs."
  '((emacs    "24.1")
    (dash     "2.6.0")
    (mmm-mode "0.5.4")
    (s        "1.10.0"))
  :url "https://github.com/canatella/bitbake-el"
  :commit "96ee67ddc74bee6ab143ce2ec620f9128ae48806"
  :revdesc "96ee67ddc74b"
  :keywords '("convenience"))
