;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-noisegate" "0.1.0.0.20200502.7"
  "Run Golang tests with Noise Gate."
  '((emacs "24.4"))
  :url "https://github.com/go-noisegate/go-noisegate.el"
  :commit "825d1fb05ec329f938c4c5bed23592f54d326f80"
  :revdesc "825d1fb05ec3"
  :keywords '("languages" "go" "test"))
