;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monotropic-theme" "0.1.0.20211116.19"
  "Monotropic Theme."
  '((emacs "24"))
  :url "https://github.com/caffo/monotropic-theme"
  :commit "f32a04b5bfee9cbcce4b223f17228d1142a28211"
  :revdesc "f32a04b5bfee")
