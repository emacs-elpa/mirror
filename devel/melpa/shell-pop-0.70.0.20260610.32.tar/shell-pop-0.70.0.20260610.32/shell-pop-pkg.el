;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-pop" "0.70.0.20260610.32"
  "Easily toggle a shell window with a single keystroke."
  '((emacs "26.1"))
  :url "https://github.com/kyagi/shell-pop-el"
  :commit "446b1691454e65be648dcb7e316639aa7dd73be2"
  :revdesc "0.70-32-g446b1691454e"
  :keywords '("shell" "terminal" "tools")
  :authors '(("Kazuo YAGI" . "kazuo.yagi@gmail.com"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
