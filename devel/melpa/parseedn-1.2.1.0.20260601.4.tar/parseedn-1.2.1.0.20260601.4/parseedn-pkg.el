;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parseedn" "1.2.1.0.20260601.4"
  "Clojure/EDN parser."
  '((emacs    "26")
    (parseclj "1.1.1")
    (map      "2"))
  :url "http://www.github.com/clojure-emacs/parseedn"
  :commit "1a28a88e2aabd99b41e02f491d6b8874ec128d7d"
  :revdesc "v1.2.1-4-g1a28a88e2aab"
  :keywords '("lisp" "clojure" "edn" "parser")
  :authors '(("Arne Brasseur" . "arne@arnebrasseur.net"))
  :maintainers '(("Arne Brasseur" . "arne@arnebrasseur.net")))
