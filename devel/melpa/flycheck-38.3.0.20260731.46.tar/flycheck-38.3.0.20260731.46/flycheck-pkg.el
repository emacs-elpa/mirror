;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "38.3.0.20260731.46"
  "On-the-fly syntax checking."
  '((emacs "28.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "62e8f1cf99ac9b67b62cf205affb0260c8838a10"
  :revdesc "62e8f1cf99ac"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
