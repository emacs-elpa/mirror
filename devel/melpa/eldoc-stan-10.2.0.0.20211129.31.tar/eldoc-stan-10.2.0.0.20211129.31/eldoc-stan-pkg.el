;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-stan" "10.2.0.0.20211129.31"
  "Eldoc support for stan functions."
  '((emacs     "25")
    (stan-mode "10.3.0"))
  :url "https://github.com/stan-dev/stan-mode/tree/master/eldoc-stan"
  :commit "150bbbe5fd3ad2b5a3dbfba9d291e66eeea1a581"
  :revdesc "150bbbe5fd3a"
  :keywords '("help" "tools")
  :authors '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu"))
  :maintainers '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu")))
