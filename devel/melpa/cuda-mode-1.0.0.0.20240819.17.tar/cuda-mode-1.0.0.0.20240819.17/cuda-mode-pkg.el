;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cuda-mode" "1.0.0.0.20240819.17"
  "NVIDIA CUDA Major Mode derived from C++-mode."
  '((compat "29"))
  :url "https://github.com/chachi/cuda-mode"
  :commit "c3dae31b3d1abedf4d0b98840127e2cac73d6ad8"
  :revdesc "1.0.0-17-gc3dae31b3d1a"
  :keywords '("c" "languages" "cuda")
  :authors '(("Jack Morrison" . "jackmorrison1@gmail.com"))
  :maintainers '(("Jack Morrison" . "jackmorrison1@gmail.com")))
