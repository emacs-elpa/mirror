;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ignoramus" "0.7.4.0.20220611.19"
  "Ignore backups, build files, et al."
  '((emacs "24.3"))
  :url "https://github.com/rolandwalker/ignoramus"
  :commit "f5e4a66191be12c2fc3cf42a5e0849fcc8518a3f"
  :revdesc "f5e4a66191be"
  :keywords '("convenience" "tools")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
