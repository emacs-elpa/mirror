;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-pydoc" "0.7.0.20220721.6"
  "Pydoc with helm interface."
  '((helm-core "3.6.0")
    (emacs     "24.4"))
  :url "https://github.com/syohex/emacs-helm-pydoc"
  :commit "cac7b8953adcab85e898bc42b699c3afde5d33c6"
  :revdesc "cac7b8953adc"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
