;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "4.5.0.20260825.270"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "9799d01c357f9c35634887dffb3276b6d7adb1ac"
  :revdesc "v4.5-270-g9799d01c357f"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
