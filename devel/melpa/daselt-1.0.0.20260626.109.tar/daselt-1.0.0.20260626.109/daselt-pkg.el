;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "1.0.0.20260626.109"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "288211ee4789392aa1b5ea9c665c6e9fd04b3a84"
  :revdesc "288211ee4789"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
