;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocaml-eglot" "1.4.0.0.20261012.1"
  "An OCaml companion for Eglot."
  '((emacs "29.1"))
  :url "https://github.com/tarides/ocaml-eglot"
  :commit "b4e34770655bd7f68cab68931b29279b4b88733c"
  :revdesc "b4e34770655b"
  :keywords '("ocaml" "languages")
  :authors '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com"))
  :maintainers '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com")))
