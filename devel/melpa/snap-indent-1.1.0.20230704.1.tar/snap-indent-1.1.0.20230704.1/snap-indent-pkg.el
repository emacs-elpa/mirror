;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snap-indent" "1.1.0.20230704.1"
  "Simple automatic indentation."
  '((emacs "24.1"))
  :url "https://github.com/jeffvalk/snap-indent"
  :commit "c4e49295aa1a2678c0e9232c12448fd944aced8e"
  :revdesc "c4e49295aa1a"
  :keywords '("indent" "tools" "convenience")
  :authors '(("Jeff Valk" . "jv@jeffvalk.com"))
  :maintainers '(("Jeff Valk" . "jv@jeffvalk.com")))
