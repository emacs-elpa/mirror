;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-fuz" "1.3.0.0.20200812.18"
  "Integrate Helm and Fuz."
  '((emacs "25.1")
    (fuz   "1.4.0")
    (helm  "3.6"))
  :url "https://github.com/cireu/fuz.el"
  :commit "fee874aa35d2ee6b12b836290b5c8eaa44175a28"
  :revdesc "1.3.0-18-gfee874aa35d2"
  :keywords '("convenience")
  :authors '(("Zhu Zihao" . "all_but_last@163.com"))
  :maintainers '(("Zhu Zihao" . "all_but_last@163.com")))
