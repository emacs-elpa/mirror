;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "1.10.0.0.20260830.195"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "3d9552c575fd14ac98ac97bf3c19cdef39f79305"
  :revdesc "3d9552c575fd"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
