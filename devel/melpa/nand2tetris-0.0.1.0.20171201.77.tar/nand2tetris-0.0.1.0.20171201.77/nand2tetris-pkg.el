;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nand2tetris" "0.0.1.0.20171201.77"
  "Major mode for HDL files in the nand2tetris course."
  '((emacs "24"))
  :url "http://www.github.com/CestDiego/nand2tetris.el/"
  :commit "fe37ee41367ceff6f7d7a472a5f80cf1285e1e01"
  :revdesc "fe37ee41367c"
  :keywords '("nand2tetris" "hdl")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")))
