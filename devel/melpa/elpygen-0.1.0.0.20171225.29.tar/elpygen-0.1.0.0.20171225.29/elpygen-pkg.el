;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpygen" "0.1.0.0.20171225.29"
  "Generate a Python function/method using a symbol under point."
  '((emacs     "25")
    (yasnippet "0.8.0"))
  :url "https://github.com/vkazanov/elpygen"
  :commit "21929c997a05968f9eefe52b85a76ceaab3b0d81"
  :revdesc "21929c997a05"
  :keywords '("python" "languages" "tools")
  :authors '(("Vladimir Kazanov" . "vkazanov@inbox.ru"))
  :maintainers '(("Vladimir Kazanov" . "vkazanov@inbox.ru")))
