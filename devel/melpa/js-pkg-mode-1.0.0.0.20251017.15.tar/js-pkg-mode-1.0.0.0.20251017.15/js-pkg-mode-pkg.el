;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-pkg-mode" "1.0.0.0.20251017.15"
  "Minor mode for working with javascript projects."
  '((emacs "25.1"))
  :url "https://github.com/ovistoica/js-pkg-mode"
  :commit "4d7248b829b62c7ed8509c13bd959e78466bef77"
  :revdesc "4d7248b829b6"
  :keywords '("convenience" "project" "javascript" "package-manager")
  :authors '(("Ovi Stoica" . "ovidiu.stoica1094@gmail.com"))
  :maintainers '(("Ovi Stoica" . "ovidiu.stoica1094@gmail.com")))
