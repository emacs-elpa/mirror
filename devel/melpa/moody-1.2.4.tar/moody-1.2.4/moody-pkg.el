;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moody" "1.2.4"
  "Tabs and ribbons for the mode line."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/tarsius/moody"
  :commit "e7ef0d911e2abd92c8ac630490c97bc754efce21"
  :revdesc "v1.2.4-0-ge7ef0d911e2a"
  :keywords '("faces")
  :authors '(("Jonas Bernoulli" . "emacs.moody@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.moody@jonas.bernoulli.dev")))
