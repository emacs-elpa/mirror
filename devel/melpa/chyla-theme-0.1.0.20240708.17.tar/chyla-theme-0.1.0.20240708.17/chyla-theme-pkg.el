;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chyla-theme" "0.1.0.20240708.17"
  "Chyla.org - green color theme."
  '((emacs "24.1"))
  :url "https://github.com/chyla/ChylaThemeForEmacs"
  :commit "c2bb425eaff0975e0c7081f282d291f7853f8376"
  :revdesc "c2bb425eaff0")
