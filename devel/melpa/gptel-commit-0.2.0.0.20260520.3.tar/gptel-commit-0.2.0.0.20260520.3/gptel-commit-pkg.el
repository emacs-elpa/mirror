;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-commit" "0.2.0.0.20260520.3"
  "Generate commit message with gptel."
  '((emacs "27.1")
    (gptel "0.9.8"))
  :url "https://github.com/lakkiy/gptel-commit"
  :commit "c354320fc6a2f3df4594d524d78a7effa765636e"
  :revdesc "c354320fc6a2"
  :keywords '("vc" "convenience")
  :authors '(("Liu Bo" . "liubolovelife@gmail.com"))
  :maintainers '(("Liu Bo" . "liubolovelife@gmail.com")))
