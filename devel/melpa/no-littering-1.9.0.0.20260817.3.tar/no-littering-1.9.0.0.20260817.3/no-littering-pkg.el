;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "1.9.0.0.20260817.3"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "22235d2790d086db418c1b487e6cd700a8fa8237"
  :revdesc "v1.9.0-3-g22235d2790d0"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
