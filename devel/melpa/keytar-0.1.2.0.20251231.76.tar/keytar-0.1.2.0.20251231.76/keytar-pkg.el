;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keytar" "0.1.2.0.20251231.76"
  "Emacs Lisp interface for node-keytar."
  '((emacs "24.4"))
  :url "https://github.com/emacs-grammarly/keytar"
  :commit "f0485df065bcdc8f446be3e00aa77a43629ec84e"
  :revdesc "f0485df065bc"
  :keywords '("convenience" "keytar" "password" "credential" "secret" "security")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
