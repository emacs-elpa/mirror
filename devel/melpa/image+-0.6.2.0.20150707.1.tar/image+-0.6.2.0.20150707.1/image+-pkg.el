;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "image+" "0.6.2.0.20150707.1"
  "Image manipulate extensions for Emacs."
  '((cl-lib "0.3"))
  :url "https://github.com/mhayashi1120/Emacs-imagex"
  :commit "6834d0c09bb4df9ecc0d7a559bd7827fed48fffc"
  :revdesc "6834d0c09bb4"
  :keywords '("multimedia" "extensions")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
