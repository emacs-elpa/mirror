;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nlinum-hl" "1.0.6.0.20211112.3"
  "Heal nlinum's line numbers."
  '((emacs  "24.4")
    (nlinum "1.7")
    (cl-lib "0.5"))
  :url "https://github.com/hlissner/emacs-nlinum-hl"
  :commit "22f8d75ecdaab67e0d6d0d2da4766358456ca4f5"
  :revdesc "22f8d75ecdaa"
  :keywords '("nlinum" "highlight" "current" "line" "faces")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "git@henrik.io")))
