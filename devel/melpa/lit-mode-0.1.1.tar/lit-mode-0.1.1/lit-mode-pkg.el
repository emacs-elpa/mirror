;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lit-mode" "0.1.1"
  "Major mode for lit."
  ()
  :url "https://github.com/HectorAE/lit-mode"
  :commit "c61c403afc8333a5649c5421ab1a6341dc1c7d92"
  :revdesc "0.1.1-0-gc61c403afc83"
  :keywords '("languages" "tools")
  :authors '(("Hector A Escobedo" . "ninjahector.escobedo@gmail.com"))
  :maintainers '(("Hector A Escobedo" . "ninjahector.escobedo@gmail.com")))
