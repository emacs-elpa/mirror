;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "0.10.0.0.20260911.6"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "2a4b4b8bcdab33ae168e5084c8ee76348ef5358a"
  :revdesc "2a4b4b8bcdab"
  :keywords '("convenience"))
