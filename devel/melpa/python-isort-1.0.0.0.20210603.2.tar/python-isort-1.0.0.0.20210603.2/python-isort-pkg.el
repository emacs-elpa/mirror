;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-isort" "1.0.0.0.20210603.2"
  "Reformat python-mode buffer with isort."
  '((emacs       "26")
    (reformatter "0.6"))
  :url "https://github.com/wyuenho/emacs-python-isort"
  :commit "339814df22b87eebca02137e581f65d6283fce97"
  :revdesc "339814df22b8"
  :keywords '("languages")
  :authors '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
