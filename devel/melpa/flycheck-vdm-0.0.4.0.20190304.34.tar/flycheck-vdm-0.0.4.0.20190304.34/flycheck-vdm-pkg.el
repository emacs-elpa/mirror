;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-vdm" "0.0.4.0.20190304.34"
  "Syntax checking for vdm-mode."
  '((emacs    "24")
    (flycheck "32-cvs")
    (vdm-mode "0.0.4"))
  :url "https://github.com/peterwvj/vdm-mode"
  :commit "103993147b24325ef68099d087dce9ac501f02f9"
  :revdesc "103993147b24"
  :keywords '("languages")
  :authors '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com"))
  :maintainers '(("Peter W. V. Tran-Jørgensen" . "peter.w.v.jorgensen@gmail.com")))
