;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "web-narrow-mode" "0.1.0.0.20170407.8"
  "Quick narrow code block in web-mode."
  '((web-mode "14.0.27"))
  :url "https://github.com/Qquanwei/web-narrow-mode"
  :commit "b25fae07844875d5b62d14b98442c88817b7e139"
  :revdesc "b25fae078448"
  :keywords '("web-mode" "react" "narrow" "web")
  :authors '(("Qquanwei" . "quanwei9958@126.com"))
  :maintainers '(("Johan Andersson" . "quanwei9958@126.com")))
