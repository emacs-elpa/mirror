;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyvenv" "1.21.0.20211014.10"
  "Python virtual environment interface."
  ()
  :url "https://github.com/jorgenschaefer/pyvenv"
  :commit "31ea715f2164dd611e7fc77b26390ef3ca93509b"
  :revdesc "31ea715f2164"
  :keywords '("python" "virtualenv" "tools")
  :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainers '(("Jorgen Schaefer" . "contact@jorgenschaefer.de")))
