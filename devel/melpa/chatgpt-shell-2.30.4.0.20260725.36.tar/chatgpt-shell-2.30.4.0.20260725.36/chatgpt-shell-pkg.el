;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "2.30.4.0.20260725.36"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.82.3")
    (transient   "0.9.3"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "49827c8d0746a2f3e1bc68f5f3d73363b7db3db6"
  :revdesc "49827c8d0746")
