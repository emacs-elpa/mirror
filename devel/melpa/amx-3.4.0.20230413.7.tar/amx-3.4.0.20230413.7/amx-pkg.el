;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amx" "3.4.0.20230413.7"
  "Alternative M-x with extra features."
  '((emacs "24.4")
    (s     "0"))
  :url "https://github.com/DarwinAwardWinner/amx/"
  :commit "1c2428d21e9d2ee8bee944b572a39ca8c91ca13b"
  :revdesc "1c2428d21e9d"
  :keywords '("convenience" "usability" "completion")
  :authors '(("Ryan C. Thompson" . "rct@thompsonclan.org")
             ("Cornelius Mika" . "cornelius.mika@gmail.com"))
  :maintainers '(("Ryan C. Thompson" . "rct@thompsonclan.org")))
