;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shfmt" "0.1.0.20250709.25"
  "Reformat shell scripts using shfmt."
  '((emacs       "24")
    (reformatter "0.3"))
  :url "https://github.com/purcell/emacs-shfmt"
  :commit "c81cb23fed1a77732b972ea036d74cbeb7c13bb1"
  :revdesc "c81cb23fed1a"
  :keywords '("languages")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
