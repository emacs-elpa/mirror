;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "0.15.1.0.20260503.24"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "a666c5917a44458a103e99587239fa7db67b9072"
  :revdesc "a666c5917a44"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
