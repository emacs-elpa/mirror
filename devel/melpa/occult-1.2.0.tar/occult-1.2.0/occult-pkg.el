;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occult" "1.2.0"
  "Collapse and reveal buffer regions."
  '((emacs "29.1"))
  :url "https://github.com/agzam/occult.el"
  :commit "74006325af1d96af3f26dc2dbf02baccc03d83f1"
  :revdesc "74006325af1d"
  :keywords '("convenience")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
