;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dynamic-spaces" "0.0.1"
  "Don't move text separated by multiple spaces."
  ()
  :url "https://github.com/Lindydancer/dynamic-spaces"
  :commit "dade49afa9eb2700a02de0333935a28b39b15b7b"
  :revdesc "dade49afa9eb"
  :keywords '("convenience"))
