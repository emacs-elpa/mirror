;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dune" "3.24.2"
  "Integration with the dune build system."
  ()
  :url "https://github.com/ocaml/dune"
  :commit "ce734ac25ffb06994a4530426bb06ee8cda19e50"
  :revdesc "3.24.2-0-gce734ac25ffb")
