;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "use-proxy" "1.2.1"
  "Enable/Disable proxies respecting your HTTP/HTTPS env."
  '((exec-path-from-shell "1.12")
    (emacs                "26.2"))
  :url "https://github.com/rayw000/use-proxy"
  :commit "43499194224483b27628fdf99f6f9ff6e731d844"
  :revdesc "434991942244"
  :keywords '("proxy" "comm")
  :authors '(("Ray Wang" . "ray.hackmylife@gmail.com"))
  :maintainers '(("Ray Wang" . "ray.hackmylife@gmail.com")))
