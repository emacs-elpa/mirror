;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tongbu" "0.0.0.20200414.75"
  "A web server to share text or files between two devices."
  '((emacs      "25.1")
    (web-server "0.1.2"))
  :url "https://github.com/xuchunyang/tongbu.el"
  :commit "6f6e5c5446f0c5735357ab520b249ab97295653e"
  :revdesc "6f6e5c5446f0"
  :keywords '("tools"))
