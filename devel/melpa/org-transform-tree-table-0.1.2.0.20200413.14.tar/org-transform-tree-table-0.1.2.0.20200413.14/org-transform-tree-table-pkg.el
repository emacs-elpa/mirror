;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-transform-tree-table" "0.1.2.0.20200413.14"
  "Transform org-mode tree with properties to a table, and the other way around."
  '((dash "2.10.0")
    (s    "1.3.0"))
  :url "https://github.com/jplindstrom/emacs-org-transform-tree-table"
  :commit "d84e7fb87bf2d5fc2be252500de0cddf20facf4f"
  :revdesc "0.1.2-14-gd84e7fb87bf2"
  :keywords '("org-mode" "table" "org-table" "tree" "csv" "convert")
  :authors '(("Johan Lindstrom" . "buzzwordninjanot_this_bit@googlemail.com"))
  :maintainers '(("Johan Lindstrom" . "buzzwordninjanot_this_bit@googlemail.com")))
