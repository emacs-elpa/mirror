;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daml-lsp" "1.0"
  "LSP client definition for daml."
  '((daml-mode "1.0")
    (dash      "2.18.0")
    (f         "0.20.0")
    (ht        "2.3")
    (lsp-mode  "7.0"))
  :url "https://github.com/bartfaitamas/daml-mode"
  :commit "26ea6a1b34c49aaa5a2b395a0468c8af710bfab7"
  :revdesc "26ea6a1b34c4")
