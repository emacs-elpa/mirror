;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "biome" "0.1.0.0.20261029.86"
  "Bountiful Interface to Open Meteo for Emacs."
  '((emacs     "27.1")
    (transient "0.9.2")
    (ct        "0.2")
    (request   "0.3.3")
    (compat    "29.1.4.1"))
  :url "https://github.com/SqrtMinusOne/biome"
  :commit "1d6a909efd209f9d9e4ed80ad64b04749bee9c9a"
  :revdesc "1d6a909efd20"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
