;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hiwin" "1.2.0.20150825.25"
  "Visible active window mode."
  ()
  :url "https://github.com/yoshida-mediba/hiwin-mode"
  :commit "6ee8ed051405653bd9b7332d7e9fbb591d954051"
  :revdesc "6ee8ed051405"
  :keywords '("faces" "editing" "emulating"))
