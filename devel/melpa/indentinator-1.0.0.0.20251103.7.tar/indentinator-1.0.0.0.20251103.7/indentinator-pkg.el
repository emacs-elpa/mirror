;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indentinator" "1.0.0.0.20251103.7"
  "Automatically indent code."
  '((emacs "25.1"))
  :url "https://github.com/xendk/indentinator.el"
  :commit "79ddeb38d9679616b7a843a88b22866f3b3cd9f6"
  :revdesc "v1.0.0-7-g79ddeb38d967"
  :keywords '("convenience")
  :authors '(("Thomas Fini Hansen" . "xen@xen.dk"))
  :maintainers '(("Thomas Fini Hansen" . "xen@xen.dk")))
