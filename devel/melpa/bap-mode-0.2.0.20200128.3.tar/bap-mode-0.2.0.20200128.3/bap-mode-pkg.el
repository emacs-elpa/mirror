;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bap-mode" "0.2.0.20200128.3"
  "Major-mode for BAP's IR."
  ()
  :url "https://github.com/fkie-cad/bap-mode"
  :commit "8969679f60db0aa918d35f40d959c0a9c723b111"
  :revdesc "8969679f60db"
  :keywords '("languages")
  :authors '(("Thomas Barabosch" . "http://github/tbarabosch"))
  :maintainers '(("Thomas Barabosch" . "thomas.barabosch@fkie.fraunhofer.de")))
