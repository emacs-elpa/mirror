;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "0.14.3.0.20260907.4"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "2a6f2d4600860bd2ab1988253b241f5a39ba59e5"
  :revdesc "2a6f2d460086")
