;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-x" "0.1.0.0.20260725.17"
  "Extended flex completion style."
  '((emacs "30.1"))
  :url "https://github.com/kn66/flex-x"
  :commit "40034af091ad4acdf92aafbfe3a1ca1409e92821"
  :revdesc "40034af091ad"
  :keywords '("convenience" "matching")
  :authors '(("kn66" . "https://github.com/kn66"))
  :maintainers '(("kn66" . "https://github.com/kn66")))
