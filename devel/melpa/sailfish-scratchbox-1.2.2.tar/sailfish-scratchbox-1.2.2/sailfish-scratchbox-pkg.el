;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sailfish-scratchbox" "1.2.2"
  "Sailfish OS scratchbox inside the emacs."
  ()
  :url "https://github.com/vityafx/sailfish-scratchbox.el"
  :commit "bb5ed0f0b0cd72f2eb1af065b7587ec81866b089"
  :revdesc "bb5ed0f0b0cd"
  :keywords '("sb2" "mb2" "building" "scratchbox" "sailfish")
  :authors '(("V. V. Polevoy" . "fx@thefx.co"))
  :maintainers '(("V. V. Polevoy" . "fx@thefx.co")))
