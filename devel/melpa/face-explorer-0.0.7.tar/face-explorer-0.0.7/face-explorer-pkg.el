;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "face-explorer" "0.0.7"
  "Tools for faces and text properties."
  '((emacs "24.1"))
  :url "https://github.com/Lindydancer/face-explorer"
  :commit "8a92383db3df635f2d988ad5a312db945cd4fe4f"
  :revdesc "8a92383db3df"
  :keywords '("faces"))
