;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fold-dwim" "1.2.0.20140208.2"
  "Unified user interface for Emacs folding modes."
  ()
  :url "http://www.dur.ac.uk/p.j.heslin/Software/Emacs"
  :commit "c46f4bb2ce91b4e307136320e72c28dd50b6cd8b"
  :revdesc "1.2-2-gc46f4bb2ce91"
  :authors '(("Peter Heslin" . "p.j.heslin@dur.ac.uk"))
  :maintainers '(("Peter Heslin" . "p.j.heslin@dur.ac.uk")))
