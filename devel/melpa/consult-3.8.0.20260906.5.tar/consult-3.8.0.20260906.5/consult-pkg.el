;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "3.8.0.20260906.5"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "4587c6ef80f042d1ae8af2cf6c5a20544865b294"
  :revdesc "3.8-5-g4587c6ef80f0"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
