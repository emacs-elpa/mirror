;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "porthole" "0.3.0"
  "RPC Servers in Emacs."
  '((emacs           "26")
    (web-server      "0.1.2")
    (f               "0.19.0")
    (json-rpc-server "0.1.2"))
  :url "https://github.com/jcaw/porthole"
  :commit "9e68b419acf9245208f8094e10041b7f04511473"
  :revdesc "v0.3.0-0-g9e68b419acf9"
  :keywords '("comm" "rpc" "http" "json"))
