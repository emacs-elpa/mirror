;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesound" "0.3.0.20260616.1"
  "Play, pause, resume music on a Bluesound player."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~rwv/bluesound-el/"
  :commit "3a99edc4232d41a9cd13b846c7a4f27036256d29"
  :revdesc "0.3-1-g3a99edc4232d"
  :keywords '("convenience" "multimedia"))
