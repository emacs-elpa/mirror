;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "2.1.0.0.20261110.7"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "04c7fed164b42522165baba7645b7d9e22247f7c"
  :revdesc "v2.1.0-7-g04c7fed164b4"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
