;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "1.0.0.20260918.179"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "787b724579d871fa0e647db2bf309f030842ff5c"
  :revdesc "787b724579d8"
  :keywords '("convenience"))
