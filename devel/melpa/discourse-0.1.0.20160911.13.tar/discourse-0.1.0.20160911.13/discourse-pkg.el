;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "discourse" "0.1.0.20160911.13"
  "Discourse api."
  '((cl-lib  "0.5")
    (request "0.2")
    (s       "1.11.0"))
  :url "https://github.com/lujun9972/discourse-api"
  :commit "a86c7e608851e186fe12e892a573994f08c8e65e"
  :revdesc "a86c7e608851"
  :keywords '("lisp" "discourse")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
