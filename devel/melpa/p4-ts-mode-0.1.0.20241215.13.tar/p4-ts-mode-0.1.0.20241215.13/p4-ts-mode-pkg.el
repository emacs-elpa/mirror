;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "p4-ts-mode" "0.1.0.20241215.13"
  "Major mode for the P4_16 programming language."
  '((emacs   "29.1")
    (xcscope "1.0"))
  :url "https://github.com/oxidecomputer/p4-ts-mode"
  :commit "a2b8a0ecde12b23487dff2bb85b2a9dcd1962cb8"
  :revdesc "a2b8a0ecde12"
  :keywords '("languages" "p4_16" "p4")
  :authors '(("Zeeshan Lakhani" . "zeeshan@oxidecomputer.com"))
  :maintainers '(("Zeeshan Lakhani" . "zeeshan@oxidecomputer.com")))
