;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smbc" "0.2.1.0.20171229.6"
  "View SMBC from Emacs."
  ()
  :url "https://github.com/sakshamsharma/emacs-smbc"
  :commit "10538e3d575ba6ef3c94d555af2744b42dfd36c7"
  :revdesc "10538e3d575b"
  :keywords '("smbc" "webcomic")
  :authors '(("Saksham Sharma" . "saksham0808@gmail.com"))
  :maintainers '(("Saksham Sharma" . "saksham0808@gmail.com")))
