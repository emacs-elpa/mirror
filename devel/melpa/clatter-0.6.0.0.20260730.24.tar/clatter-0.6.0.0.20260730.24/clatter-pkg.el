;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.6.0.0.20260730.24"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "b3c28e1f01b16454ed26ce99c8646382a028f174"
  :revdesc "b3c28e1f01b1"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
