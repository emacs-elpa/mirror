;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "signel" "0.1.1.0.20260130.14"
  "Signal client via signal-cli JSON-RPC."
  '((emacs "27.1"))
  :url "https://github.com/keenban/signel"
  :commit "5b309ddd8668344310ae7e9f93b6b756da28d9b4"
  :revdesc "5b309ddd8668"
  :authors '(("Keenan Salandy" . "keenan@salandy.dev"))
  :maintainers '(("Keenan Salandy" . "keenan@salandy.dev")))
