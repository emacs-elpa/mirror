;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ta" "1.5.0.20160619.3"
  "A tool to deal with Chinese homophonic characters."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/kuanyui/ta.el"
  :commit "668ad41e71f374f8c32c8d0532f3d8485b355d35"
  :revdesc "668ad41e71f3"
  :keywords '("tools")
  :authors '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainers '(("kuanyui" . "azazabc123@gmail.com")))
