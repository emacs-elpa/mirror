;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.16.0.0.20261021.6"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.67.1")
    (latex-to-svg-backend "0.17.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "f5fc96e1fe241767903c29e1457dee28fc20d000"
  :revdesc "v0.16.0-6-gf5fc96e1fe24"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
