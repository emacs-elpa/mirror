;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-shift" "0.3.0.20251125.2"
  "Smart shift text left/right."
  ()
  :url "https://github.com/hbin/smart-shift"
  :commit "b9958f042f974e09a7e9442431a1f9cbd8404f8a"
  :revdesc "b9958f042f97"
  :keywords '("convenience" "tools")
  :authors '(("Bin Huang" . "huangbin88@foxmail.com"))
  :maintainers '(("Bin Huang" . "huangbin88@foxmail.com")))
