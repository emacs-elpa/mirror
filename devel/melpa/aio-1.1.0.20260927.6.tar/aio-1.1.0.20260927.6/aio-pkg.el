;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aio" "1.1.0.20260927.6"
  "Async/await for Emacs Lisp."
  '((emacs "26.1"))
  :url "https://github.com/skeeto/emacs-aio"
  :commit "d76914b08339e24b3ad7d24ced17e22d13492a37"
  :revdesc "1.1-6-gd76914b08339"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
