;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "draft-mode" "0.1.1"
  "Rough drafting for Emacs."
  ()
  :url "https://github.com/gaudecker/draft-mode"
  :commit "4779fb32daf53746459da2def7e08004492d4f18"
  :revdesc "0.1.1-0-g4779fb32daf5"
  :keywords '("draft" "drafting")
  :authors '(("Eeli Reilin" . "gaudecker@fea.st"))
  :maintainers '(("Eeli Reilin" . "gaudecker@fea.st")))
