;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compdef" "0.2.0.20200304.40"
  "A local completion definer."
  '((emacs "24.4"))
  :url "https://gitlab.com/jjzmajic/compdef"
  :commit "30fb5846ed851efee641ce8c5d8879ad36cd7ac6"
  :revdesc "30fb5846ed85"
  :keywords '("convenience"))
