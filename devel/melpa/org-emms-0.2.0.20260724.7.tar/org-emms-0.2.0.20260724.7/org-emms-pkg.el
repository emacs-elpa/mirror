;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-emms" "0.2.0.20260724.7"
  "Playback multimedia files from Org documents."
  '((emacs "24.1")
    (org   "9.3")
    (emms  "0.0"))
  :url "https://git.sr.ht/~jagrg/org-emms"
  :commit "a2353886f5b0986a48080e0cf882db4bebc993b0"
  :revdesc "a2353886f5b0"
  :keywords '("multimedia")
  :authors '(("Jonathan Gregory" . "jgrgatautisticidotorg"))
  :maintainers '(("Jonathan Gregory" . "jgrgatautisticidotorg")))
