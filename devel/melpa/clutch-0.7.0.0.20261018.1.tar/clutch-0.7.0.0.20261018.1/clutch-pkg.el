;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.7.0.0.20261018.1"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "67796f7baad38d6bcae67ecae77a89861e816bda"
  :revdesc "67796f7baad3"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
