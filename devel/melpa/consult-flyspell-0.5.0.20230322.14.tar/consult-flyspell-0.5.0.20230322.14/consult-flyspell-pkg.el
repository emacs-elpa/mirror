;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-flyspell" "0.5.0.20230322.14"
  "Consult integration for flyspell."
  '((emacs   "25.1")
    (consult "0.12"))
  :url "https://gitlab.com/OlMon/consult-flyspell"
  :commit "7011e6634598530ea2d874e7e7389dc1bb94e1ca"
  :revdesc "7011e6634598"
  :keywords '("convenience"))
