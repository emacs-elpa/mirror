;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "0.2.0.20261121.12"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "92e3c9e2ff04e186050b9848a3b91e163759d19f"
  :revdesc "92e3c9e2ff04"
  :keywords '("matching" "convenience")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
