;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minibuf-isearch" "1.7.1"
  "Incremental search on minibuffer history."
  ()
  :url "https://github.com/knagano/minibuf-isearch"
  :commit "2846c6ac369ee623dad4cd3c8a7a6d9078965516"
  :revdesc "2846c6ac369e"
  :keywords '("minibuffer" "history" "incremental search")
  :authors '(("Keiichiro Nagano" . "knagano@sodan.org")
             ("Hideyuki SHIRAI" . "shirai@meadowy.org"))
  :maintainers '(("Keiichiro Nagano" . "knagano@sodan.org")
                 ("Hideyuki SHIRAI" . "shirai@meadowy.org")))
