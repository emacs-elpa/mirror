;;; clj-refactor.el --- A collection of commands for refactoring Clojure code -*- lexical-binding: t -*-

;; Copyright © 2012-2014 Magnar Sveen
;; Copyright © 2014-2026 Magnar Sveen, Lars Andersen, Benedek Fazekas, Bozhidar Batsov

;; Author: Magnar Sveen <magnars@gmail.com>
;;         Lars Andersen <expez@expez.com>
;;         Benedek Fazekas <benedek.fazekas@gmail.com>
;;         Bozhidar Batsov <bozhidar@batsov.dev>
;; Package-Version: 4.2.0.0.20261113.19
;; Package-Revision: ead38a975732
;; Keywords: convenience, clojure, cider

;; Package-Requires: ((emacs "28.1") (yasnippet "0.6.1") (paredit "24") (clojure-mode "5.18.0") (cider "2.0.0") (parseedn "1.2.0") (transient "0.4.1") (spinner "1.7"))

;; This program is free software; you can redistribute it and/or
;; modify it under the terms of the GNU General Public License
;; as published by the Free Software Foundation; either version 3
;; of the License, or (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; See README.md at https://github.com/clojure-emacs/clj-refactor.el

;;; Code:

(require 'seq)

(require 'yasnippet)
(require 'paredit)
(require 'clojure-mode)
(require 'cider)
(require 'parseedn)
(require 'transient)
(require 'spinner)
(require 'subword)

(defgroup cljr nil
  "Clojure refactoring facilities."
  :prefix "cljr-"
  :group 'clojure
  :link '(url-link :tag "GitHub"
                   "https://github.com/clojure-emacs/clj-refactor.el"))

(defcustom cljr-add-ns-to-blank-clj-files t
  "If t, automatically add a ns form to new .clj files."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-auto-sort-ns t
  "If t, sort ns form after any command that changes it."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-magic-requires t
  "Whether to automatically require common namespaces when they are used.
These are the namespaces listed in `cljr-magic-require-namespaces'
and suggested by the `cljr-suggest-libspecs' middleware op.

If this variable is `:prompt', typing the short form followed by
`\\[cljr-slash]' will ask if you want to add the corresponding require
statement to the ns form.
Any other non-nil value means to add the form without asking."
  :type '(choice (const :tag "true" t)
                 (const :tag "prompt" :prompt)
                 (const :tag "false" nil)))

(defcustom cljr-magic-require-namespaces
  '(("edn"  . "clojure.edn")
    ("io"     "clojure.java.io" :only ("clj"))
    ("math" . "clojure.math")
    ("set"  . "clojure.set")
    ("str"  . "clojure.string")
    ("walk" . "clojure.walk")
    ("zip"  . "clojure.zip"))
  "Alist of aliases to namespace libspec recommendations for `\\[cljr-slash]'.

Each entry is either a cons of the alias and the full namespace, e.g.
\(\"str\" . \"clojure.string\"), or a list of the alias, the namespace and
optional keywords:

- `:only' limits the recommendation to the given language contexts (clj,
  cljs), e.g. (\"io\" \"clojure.java.io\" :only (\"clj\")).
- `:artifact' names the Maven/Clojars coordinate that provides the
  namespace, e.g. (\"json\" \"cheshire.core\" :artifact \"cheshire/cheshire\").
  When the namespace isn't on the classpath, `cljr-slash' can offer to add
  and hotload that artifact (see `cljr-slash-add-missing-libs')."
  :type '(alist :key-type (string :tag "Short alias")
                :value-type sexp)
  :safe #'listp)

(defcustom cljr-slash-add-missing-libs t
  "Whether `cljr-slash' offers to add and hotload a missing library.

When an alias in `cljr-magic-require-namespaces' carries an `:artifact'
coordinate and the namespace it resolves to isn't on the classpath,
`cljr-slash' asks whether to add that artifact as a project dependency and
hotload it (the hotload itself still honors `cljr-hotload-dependencies').
Set to nil to disable."
  :type 'boolean
  :package-version '(clj-refactor . "4.0.0")
  :safe #'booleanp)

(defcustom cljr-project-clean-prompt t
  "If t, `cljr-project-clean' asks before doing anything.
If nil, the project clean functions are run without warning."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-project-clean-functions
  (list #'cljr--clean-or-sort-ns)
  "List of functions called by `cljr-project-clean'.
These are called on all .clj files in the project."
  :type '(repeat function)
  :safe #'listp)

(defcustom cljr-project-clean-exceptions '("dev/user.clj" "project.clj" "boot.clj")
  "A list of files that `cljr-project-clean' should avoid."
  :type '(repeat string)
  :safe #'listp)

(defcustom cljr-hotload-dependencies t
  "If t, newly added dependencies are also hotloaded into the repl.
This only applies to dependencies added by `cljr-add-project-dependency'."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-favor-private-functions t
  "If t, refactorings insert private function declarations."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-favor-prefix-notation nil
  "If t, `cljr-clean-ns' favors prefix notation in the ns form."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-insert-newline-after-require t
  "If t, `cljr-clean-ns' will place a newline after the `:require` and `:import` tokens."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-auto-clean-ns t
  "If t, call `cljr-clean-ns' after commands that change the ns."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-populate-artifact-cache-on-startup t
  "If t, the middleware will eagerly populate the artifact cache.
This makes `cljr-add-project-dependency' as snappy as can be."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-warn-on-eval t
  "If t, warn the user before running any op that requires ASTs to be built,
that the project will be evaled.

If this is not preferred the op will
be aborted.  Also effectively overrides `cljr-eagerly-build-asts-on-startup'
so if this is on the AST cache is not warmed at startup or after certain
operations."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-eagerly-build-asts-on-startup t
  "If t, the middleware will eagerly populate the ast cache.
This makes `cljr-find-usages' and `cljr-rename-symbol' as snappy
as can be."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-suppress-middleware-warnings nil
  "If t, no middleware warnings are printed to the repl."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-suppress-no-project-warning nil
  "If t, no warning is printed when starting a REPL outside a project.
By default, a warning is printed in this case since clj-refactor
will not work as expected in such REPLs."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-ignore-analyzer-errors nil
  "If t, `cljr-find-usages' `cljr-inline-symbol' `cljr-rename-symbol' ignores namespaces that cannot be analyzed.
If any namespaces presents an analyzer error, it is skipped and
the command carries on looking for the given symbol in those
namespaces which can be analyzed.

If nil, `cljr-find-usages'  `cljr-inline-symbol' `cljr-rename-symbol'
won't run if there is a broken namespace in the project.

Either way, the namespace of the buffer the command is invoked from
has to be analyzable, as that's where the symbol at point is resolved.
If it isn't, make sure it loads cleanly (e.g. with `cider-load-buffer')."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-auto-eval-ns-form t
  "When t, refactorings which change the ns form also trigger its re-evaluation."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-midje-test-declaration "[midje.sweet :as midje]"
  "The require form to use when midje is in use."
  :type 'string
  :safe #'stringp)

(defcustom cljr-expectations-test-declaration "[expectations :as e]"
  "The require form to use when expectations is in use."
  :type 'string
  :safe #'stringp)

(defcustom cljr-cljc-clojure-test-declaration "#?(:clj [clojure.test :as t]
:cljs [cljs.test :as t :include-macros true])"
  "The require form to use when clojure.test and cljs.test is in use in a cljc file."
  :type 'string
  :safe #'stringp)

(defcustom cljr-cljs-clojure-test-declaration "[cljs.test :as t :include-macros true]"
  "The require form to use when cljs.test is in use in a cljs file."
  :type 'string
  :safe #'stringp)

(defcustom cljr-clojure-test-declaration "[clojure.test :as t]"
  "The require form to use when clojure.test is in use in a clj file."
  :type 'string
  :safe #'stringp)

(defcustom cljr-clojure-test-namespace-under-test-alias  "sut"
  "The package alias to use for the namespace under test."
  :type 'string
  :safe #'stringp)

(defcustom cljr-inject-dependencies-at-jack-in t
  "When nil, do not inject repl dependencies (most likely nREPL middlewares)
at `cider-jack-in' time."
  :type 'boolean
  :safe #'booleanp)

(defcustom cljr-libspec-whitelist
  '("^cljsns" "^slingshot.test" "^monger.joda-time" "^monger.json")
  "List of regexes to match against libspec names which shouldn't be pruned.

This is useful when `clean-ns' should leave a libspec alone even
if it appears to be unused."
  :type '(repeat string)
  :safe #'listp)

(defvar cljr-minimum-clojure-version "1.8.0"
  "The oldest Clojure version supported by our middleware.")

(defvar clj-refactor-map (make-sparse-keymap))

(defvar cljr--add-require-snippet
  "${1:[${2:${3:} :as ${4:${3:$(cljr--ns-name yas-text)}}}]}"
  "The snippet used in `cljr-add-require-to-ns'.")

(defun cljr--ns-name (ns)
  "Return the last name in a full NS."
  (replace-regexp-in-string ".*\\." "" ns))

(defvar cljr--add-use-snippet "[$1 :refer ${2:[$3]}]"
  "The snippet used in `cljr-add-use-to-ns'.")

(defvar *cljr--noninteractive* nil
  "t, when our interactive functions are called programmatically.")

(defvar cljr--file-column-pattern
  "^\\(.+?\\):\\([1-9][0-9]*\\):\\([0-9][0-9]*\\): "
  "A regexp pattern that groups output into filename,
line number and column number.")

(defvar cljr--debug-mode nil)

(defvar cljr--occurrences nil)
(defvar cljr--signature-rows nil
  "Rows shown in the change-signature edit buffer, in display order.
Each row is a plist: `:origin' (index into the original params, or nil
for an added param), `:name', `:default' (call-site placeholder for
added params), `:removed' and `:rest'.")
(defvar cljr--signature-original-params nil
  "The function's original parameter names, as read from its arglist.")
(defvar cljr--change-signature-buffer "*cljr-change-signature*")
(defvar cljr--manual-intervention-buffer "*cljr-manual-intervention*")
(defvar cljr--find-symbol-buffer "*cljr-find-usages*")
(defvar cljr--post-command-messages nil "Message(s) to display after the current command is done.")

(defcustom cljr-before-warming-ast-cache-hook nil
  "Runs before each time the AST is loaded."
  :type 'hook)

(defcustom cljr-after-warming-ast-cache-hook nil
  "Runs after each time the AST is loaded."
  :type 'hook)

(defcustom cljr-middleware-timeout 120
  "Seconds to wait for the middleware to answer a request before giving up.
A safety net, so that a hung request or a dropped connection doesn't leave
a command waiting forever.  Raise it if analyzing your project legitimately
takes longer, or set it to nil to wait indefinitely."
  :type '(choice (integer :tag "Seconds")
                 (const :tag "Wait indefinitely" nil))
  :package-version '(clj-refactor . "4.3.0"))

(defcustom cljr-middleware-ignored-paths nil
  "List of (Java style) regexes to paths that should be ignored by the middleware."
  :type '(repeat string)
  :safe #'listp)

;;; Buffer Local Declarations

;; tracking state of find-symbol buffer

(defvar-local cljr--occurrence-count 0 "Counts occurrences of found symbols.")

(defvar-local cljr--num-syms -1 "Keeps track of overall number of symbol occurrences.")

(defvar-local cljr--occurrence-ids '() "Keeps track of already processed symbol occurrences.")

(defmacro cljr--update-file (filename &rest body)
  "If there is an open buffer for FILENAME, then change that.
Otherwise open the file and do the changes non-interactively."
  (declare (debug (form body))
           (indent 1))
  (let ((fn (make-symbol "filename"))
        (bf (make-symbol "buffer"))
        (wo (make-symbol "was-open")))
    `(let* ((,fn ,filename)
            (,wo (get-file-buffer ,fn))
            (,bf (find-file-noselect ,fn)))
       (when ,bf
         (set-buffer ,bf)
         ,@body
         (save-buffer)
         (when (not ,wo)
           ;; Don't accumulate open buffers, since this can slow down Emacs for large projects:
           (kill-buffer))))))

(defvar cljr--opened-buffers 'unset
  "Collector for buffers opened during a project-wide operation.
Bound to a list by `cljr--with-opened-buffers'; otherwise the symbol
`unset', which means `cljr--find-file-noselect' does not record anything.")

(defun cljr--find-file-noselect (file)
  "Like `find-file-noselect' for FILE, but track newly-opened buffers.
When called within `cljr--with-opened-buffers', a buffer opened here for a
file that wasn't already being visited is collected so the wrapper can
kill it afterwards.  This avoids the buffer accumulation that slows Emacs
down on large project-wide refactorings (rename, inline, change
signature)."
  (let ((already (get-file-buffer file))
        (buffer (find-file-noselect file)))
    (when (and (null already) (listp cljr--opened-buffers))
      (push buffer cljr--opened-buffers))
    (cljr--refactoring-snapshot file buffer (and already t))
    buffer))

(defmacro cljr--with-opened-buffers (&rest body)
  "Run BODY, then kill any file buffers it opened via `cljr--find-file-noselect'.
Buffers that were already being visited before BODY ran are left alone."
  (declare (indent 0) (debug (body)))
  `(let ((cljr--opened-buffers nil))
     (unwind-protect
         (progn ,@body)
       (dolist (buffer cljr--opened-buffers)
         (when (buffer-live-p buffer)
           (kill-buffer buffer))))))

;; ------ project-wide refactoring preview -------

(defcustom cljr-preview-refactorings t
  "If t, preview destructive project-wide refactorings before applying them.
`cljr-rename-symbol' and `cljr-change-function-signature' rewrite files
across the whole project.  When this is non-nil, their edits are gathered
first and shown as a diff; nothing is written to disk until you confirm.
Either way, `cljr-undo-last-refactoring' reverts the last one that was
applied."
  :type 'boolean
  :package-version '(clj-refactor . "4.0.0")
  :safe #'booleanp)

(defvar cljr--refactoring-active nil
  "Description of the in-progress previewable refactoring, or nil.
While non-nil, `cljr--save-buffer' defers writes and
`cljr--find-file-noselect' snapshots each file it opens.")

(defvar cljr--refactoring-files nil
  "Hash-table for the active refactoring: file -> plist.
The plist has `:buffer' (the visiting buffer), `:original' (its content
before the refactoring) and `:was-open' (whether it was already being
visited).")

(defvar cljr--refactoring-opened nil
  "Buffers opened during the active refactoring, to kill when it finishes.")

(defvar cljr--last-refactoring nil
  "Alist (file . original-content) of the last applied refactoring.
Used by `cljr-undo-last-refactoring'.")

(defconst cljr--refactoring-preview-buffer "*cljr-refactoring-preview*")

(defun cljr--save-buffer ()
  "Save the current buffer, unless a preview session wants to defer it.
During a previewable refactoring the edits are left in the buffer and
written only once the user confirms."
  (if cljr--refactoring-active
      (set-buffer-modified-p t)
    (save-buffer)))

(defun cljr--start-refactoring (description)
  "Begin a previewable refactoring described by DESCRIPTION."
  (setq cljr--refactoring-active description
        cljr--refactoring-files (make-hash-table :test #'equal)
        cljr--refactoring-opened nil))

(defun cljr--refactoring-snapshot (file buffer already-open)
  "Record BUFFER's current content as the pre-refactoring state of FILE.
Also records whether the buffer already had unsaved changes, so aborting
can restore that state rather than silently marking it saved."
  (when (and cljr--refactoring-active
             (not (gethash file cljr--refactoring-files)))
    (puthash file (list :buffer buffer
                        :original (with-current-buffer buffer
                                    (buffer-substring-no-properties
                                     (point-min) (point-max)))
                        :was-open already-open
                        :was-modified (buffer-modified-p buffer))
             cljr--refactoring-files)
    (unless already-open
      (push buffer cljr--refactoring-opened))))

(defun cljr--refactoring-changed-files ()
  "Return an alist (file . plist) of files whose buffer content changed."
  (let (changed)
    (maphash (lambda (file rec)
               (let ((current (with-current-buffer (plist-get rec :buffer)
                                (buffer-substring-no-properties
                                 (point-min) (point-max)))))
                 (unless (string= current (plist-get rec :original))
                   (push (cons file rec) changed))))
             cljr--refactoring-files)
    (nreverse changed)))

(defun cljr--unified-diff (label original current)
  "Return a unified diff between ORIGINAL and CURRENT, headed with LABEL.
Falls back to a one-line summary when no `diff' program is available."
  (let ((old (make-temp-file "cljr-old"))
        (new (make-temp-file "cljr-new")))
    (unwind-protect
        (condition-case nil
            (progn
              (with-temp-file old (insert original))
              (with-temp-file new (insert current))
              (with-temp-buffer
                (call-process diff-command nil t nil "-u"
                              "--label" (concat "a/" label) old
                              "--label" (concat "b/" label) new)
                (buffer-string)))
          (error (format "--- a/%s\n+++ b/%s\n(diff unavailable)\n" label label)))
      (delete-file old)
      (delete-file new))))

(defun cljr--show-refactoring-preview (changed)
  "Show a diff of the CHANGED files in the preview buffer."
  (let ((buffer (get-buffer-create cljr--refactoring-preview-buffer))
        (root (ignore-errors (file-name-as-directory (cljr--project-dir)))))
    (with-current-buffer buffer
      (let ((inhibit-read-only t))
        (erase-buffer)
        (dolist (entry changed)
          (let* ((file (car entry))
                 (rec (cdr entry))
                 (label (if root (string-remove-prefix root file) file)))
            (insert (cljr--unified-diff
                     label
                     (plist-get rec :original)
                     (with-current-buffer (plist-get rec :buffer)
                       (buffer-substring-no-properties (point-min) (point-max)))))))
        (diff-mode)
        (goto-char (point-min))
        (setq header-line-format
              (format " %s - %d file(s).  Confirm in the minibuffer."
                      cljr--refactoring-active (length changed)))))
    (display-buffer buffer)))

(defun cljr--apply-refactoring ()
  "Write out the pending edits and remember them for undo.
Only files whose content actually changed are saved, so a target buffer
that had unrelated unsaved edits but wasn't touched isn't written out."
  (let (snapshots)
    (dolist (entry (cljr--refactoring-changed-files))
      (with-current-buffer (plist-get (cdr entry) :buffer)
        (push (cons (car entry) (plist-get (cdr entry) :original)) snapshots)
        (save-buffer)))
    (setq cljr--last-refactoring (nreverse snapshots)))
  (cljr--finish-refactoring))

(defun cljr--abort-refactoring ()
  "Revert the pending edits without writing anything.
Restores each changed buffer's original content and its original
modified state, so a buffer that had unsaved edits before the
refactoring keeps them (and stays marked modified)."
  (dolist (entry (cljr--refactoring-changed-files))
    (let ((rec (cdr entry)))
      (with-current-buffer (plist-get rec :buffer)
        (let ((pt (point))
              (inhibit-read-only t))
          (erase-buffer)
          (insert (plist-get rec :original))
          (goto-char (min pt (point-max)))
          (set-buffer-modified-p (plist-get rec :was-modified))))))
  (cljr--finish-refactoring))

(defun cljr--finish-refactoring ()
  "Tear down the active refactoring session."
  (dolist (buffer cljr--refactoring-opened)
    (when (buffer-live-p buffer)
      (kill-buffer buffer)))
  (when (get-buffer cljr--refactoring-preview-buffer)
    (kill-buffer cljr--refactoring-preview-buffer))
  (setq cljr--refactoring-active nil
        cljr--refactoring-files nil
        cljr--refactoring-opened nil))

(defun cljr--run-previewable-refactoring (description thunk)
  "Run THUNK, which performs the edits of a project-wide refactoring.
When `cljr-preview-refactorings' is non-nil, gather the edits without
saving, show them as a diff described by DESCRIPTION, and apply them only
if the user confirms.  Return non-nil when the edits were applied."
  (if (not cljr-preview-refactorings)
      (progn (cljr--with-opened-buffers (funcall thunk)) t)
    (unwind-protect
        (progn
          (cljr--start-refactoring description)
          (funcall thunk)
          (let ((changed (cljr--refactoring-changed-files)))
            (cond
             ((null changed)
              (cljr--finish-refactoring)
              (cljr--post-command-message "No changes to apply")
              nil)
             (t
              (cljr--show-refactoring-preview changed)
              (if (y-or-n-p (format "Apply %s to %d file(s)? "
                                    description (length changed)))
                  (progn (cljr--apply-refactoring) t)
                (cljr--abort-refactoring)
                nil)))))
      (when cljr--refactoring-active
        (cljr--abort-refactoring)))))

;;;###autoload
(defun cljr-undo-last-refactoring ()
  "Revert every file changed by the last applied project-wide refactoring.
This overwrites those files, so any edits made since the refactoring are
lost; you're asked to confirm first."
  (interactive)
  (unless cljr--last-refactoring
    (user-error "No refactoring to undo"))
  (let ((count (length cljr--last-refactoring)))
    (when (yes-or-no-p
           (format "Revert %d file(s) to before the last refactoring? " count))
      (dolist (entry cljr--last-refactoring)
        (with-current-buffer (find-file-noselect (car entry))
          (let ((pt (point))
                (inhibit-read-only t))
            (erase-buffer)
            (insert (cdr entry))
            (goto-char (min pt (point-max)))
            (save-buffer))))
      (setq cljr--last-refactoring nil)
      (cljr--post-command-message "Reverted %d file(s)" count))))

(define-key clj-refactor-map [remap paredit-raise-sexp] 'cljr-raise-sexp)
(define-key clj-refactor-map [remap paredit-splice-sexp-killing-backward] 'cljr-splice-sexp-killing-backward)
(define-key clj-refactor-map [remap paredit-splice-sexp-killing-forward] 'cljr-splice-sexp-killing-forward)
(defvar cider-ns-magic-requires)

(defun cljr--slash-binding (command)
  "Return COMMAND, unless `/' should stay a plain `/'.
That's when `cljr-magic-requires' is off, or CIDER's own magic requires
\(`cider-ns-magic-requires') are on, which run after a plain `/'."
  (and cljr-magic-requires
       (not (bound-and-true-p cider-ns-magic-requires))
       command))

(define-key clj-refactor-map (kbd "/") '(menu-item "" cljr-slash :filter cljr--slash-binding))

(defun cljr--vector-at-point-p ()
  (eq (char-after) ?\[))

(defun cljr--fix-special-modifier-combinations (key)
  (cl-case key
    ("C-s-i" "s-TAB")
    ("C-s-m" "s-RET")
    (otherwise key)))

(defun cljr--key-pairs-with-modifier (modifier keys)
  (read-kbd-macro
   (string-join
    (seq-map
     (lambda (it)
       (cljr--fix-special-modifier-combinations (concat modifier (char-to-string it))))
     (string-to-list keys)) " ")))

(defun cljr--key-pairs-with-prefix (prefix keys)
  (read-kbd-macro (concat prefix " " keys)))

(defvar cljr--all-helpers
  '(("ai" . (cljr-add-import-to-ns "Add import to ns" ?i ("ns")))
    ("am" . (cljr-add-missing-libspec "Add missing libspec" ?m ("ns")))
    ("ap" . (cljr-add-project-dependency "Add project dependency" ?p ("ns" "project")))
    ("ar" . (cljr-add-require-to-ns "Add require to ns" ?r ("ns")))
    ("as" . (cljr-add-stubs "Add stubs for the interface/protocol at point" ?s ("toplevel-form")))
    ("au" . (cljr-add-use-to-ns "Add use to ns" ?U ("ns")))
    ("ci" . (clojure-cycle-if "Cycle if" ?I ("code")))
    ("cn" . (cljr-clean-ns "Clean ns" ?c ("ns")))
    ("cp" . (clojure-cycle-privacy "Cycle privacy" ?P ("toplevel-form")))
    ("cs" . (cljr-change-function-signature "Change function signature" ?C ("toplevel-form" "project")))
    ("ct" . (cljr-cycle-thread "Cycle thread" ?t ("code")))
    ("dk" . (cljr-destructure-keys "Destructure keys" ?d ("code")))
    ("ec" . (cljr-extract-constant "Extract constant" ?c ("toplevel-form")))
    ("ed" . (cljr-extract-def "Extract form as def" ?D ("toplevel-form")))
    ("ef" . (cljr-extract-function "Extract function" ?e ("toplevel-form")))
    ("el" . (cljr-expand-let "Expand let" ?e ("code")))
    ("fe" . (cljr-create-fn-from-example "Create function from example" ?f ("toplevel-form")))
    ("fu" . (cljr-find-usages "Find usages" ?u ("project" "code")))
    ("hd" . (cljr-hotload-dependency "Hotload dependency" ?h ("project")))
    ("il" . (clojure-introduce-let "Introduce let" ?l ("code")))
    ("is" . (cljr-inline-symbol "Inline symbol" ?i ("project" "toplevel-form" "code")))
    ("mf" . (cljr-move-form "Move form" ?m ("toplevel-form" "project")))
    ("ml" . (clojure-move-to-let "Move to let" ?m ("code")))
    ("pc" . (cljr-project-clean "Project clean" ?c ("project")))
    ("pf" . (cljr-promote-function "Promote function" ?p ("code" "toplevel-form")))
    ("rd" . (cljr-reify-to-defrecord "Reify to defrecord" ?R ("toplevel-form")))
    ("rf" . (cljr-rename-file-or-dir "Rename file-or-dir" ?r ("project" "toplevel-form")))
    ("rl" . (cljr-remove-let "Remove let" ?r ("code")))
    ("rm" . (cljr-require-macro "Add to or extend the require-macros form" ?M ("ns")))
    ("rs" . (cljr-rename-symbol "Rename symbol" ?s ("project" "code")))
    ("sc" . (cljr-show-changelog "Show the project's changelog" ?c ("cljr")))
    ("sp" . (cljr-sort-project-dependencies "Sort project dependencies" ?S ("project")))
    ("sr" . (cljr-stop-referring "Stop referring" ?t ("ns")))
    ("tf" . (clojure-thread-first-all "Thread first all" ?f ("code")))
    ("th" . (clojure-thread "Thread" ?T ("code")))
    ("tl" . (clojure-thread-last-all "Thread last all" ?L ("code")))
    ("ua" . (clojure-unwind-all "Unwind all" ?U ("code")))
    ("up" . (cljr-update-project-dependencies "Update project dependencies" ?U ("project")))
    ("ur" . (cljr-undo-last-refactoring "Undo last project-wide refactoring" ?z ("project")))
    ("uw" . (clojure-unwind "Unwind" ?w ("code")))
    ("ad" . (cljr-add-declaration "Add declaration" ?d ("toplevel-form")))
    ("hh" . (clj-refactor-menu "Menu of refactorings" ?h ("cljr")))
    ("?" . (cljr-describe-refactoring "Describe refactoring" ?d ("cljr")))))

(defun cljr--add-keybindings (key-fn)
  "Build the keymap from the list of keys/functions in `cljr--all-helpers'."
  (dolist (details cljr--all-helpers)
    (let ((key (car details))
          (fn (cadr details)))
      (define-key clj-refactor-map (funcall key-fn key) fn))))

;;;###autoload
(defun cljr-add-keybindings-with-prefix (prefix)
  "Bind keys in `cljr--all-helpers' under a PREFIX key."
  (cljr--add-keybindings (apply-partially 'cljr--key-pairs-with-prefix prefix)))

;;;###autoload
(defun cljr-add-keybindings-with-modifier (modifier)
  "Bind keys in `cljr--all-helpers' under a MODIFIER key."
  (cljr--add-keybindings (apply-partially 'cljr--key-pairs-with-modifier modifier)))


;; ------ transient menu -----------

(defun cljr--menu-toggle-description (label enabled)
  "Format the transient toggle LABEL, showing whether it is ENABLED."
  (format "%s %s" (if enabled "[X]" "[ ]") label))

(transient-define-suffix cljr--toggle-warn-on-eval ()
  "Toggle `cljr-warn-on-eval' from the menu."
  :transient t
  :description (lambda ()
                 (cljr--menu-toggle-description "Warn before evaluating code"
                                                cljr-warn-on-eval))
  (interactive)
  (setq cljr-warn-on-eval (not cljr-warn-on-eval)))

(transient-define-suffix cljr--toggle-auto-clean-ns ()
  "Toggle `cljr-auto-clean-ns' from the menu."
  :transient t
  :description (lambda ()
                 (cljr--menu-toggle-description "Auto clean-ns after ns changes"
                                                cljr-auto-clean-ns))
  (interactive)
  (setq cljr-auto-clean-ns (not cljr-auto-clean-ns)))

(transient-define-suffix cljr--toggle-favor-private-functions ()
  "Toggle `cljr-favor-private-functions' from the menu."
  :transient t
  :description (lambda ()
                 (cljr--menu-toggle-description "Favor private functions"
                                                cljr-favor-private-functions))
  (interactive)
  (setq cljr-favor-private-functions (not cljr-favor-private-functions)))

(transient-define-suffix cljr--toggle-hotload-dependencies ()
  "Toggle `cljr-hotload-dependencies' from the menu."
  :transient t
  :description (lambda ()
                 (cljr--menu-toggle-description "Hotload added dependencies"
                                                cljr-hotload-dependencies))
  (interactive)
  (setq cljr-hotload-dependencies (not cljr-hotload-dependencies)))

(transient-define-suffix cljr--toggle-ignore-analyzer-errors ()
  "Toggle `cljr-ignore-analyzer-errors' from the menu."
  :transient t
  :description (lambda ()
                 (cljr--menu-toggle-description "Ignore analyzer errors"
                                                cljr-ignore-analyzer-errors))
  (interactive)
  (setq cljr-ignore-analyzer-errors (not cljr-ignore-analyzer-errors)))

;;;###autoload (autoload 'clj-refactor-menu "clj-refactor" nil t)
(transient-define-prefix clj-refactor-menu ()
  "A transient menu of clj-refactor commands, grouped by category.

The entries mirror the two-letter keybindings, so the menu doubles as a
way to learn them.  The Options section toggles common settings for the
current session."
  [["Namespace"
    ("ai" "Add import to ns" cljr-add-import-to-ns)
    ("am" "Add missing libspec" cljr-add-missing-libspec)
    ("ar" "Add require to ns" cljr-add-require-to-ns)
    ("au" "Add use to ns" cljr-add-use-to-ns)
    ("cn" "Clean ns" cljr-clean-ns)
    ("rm" "Require macro" cljr-require-macro)
    ("sr" "Stop referring" cljr-stop-referring)
    ("ap" "Add project dependency" cljr-add-project-dependency)]
   ["Code"
    ("ci" "Cycle if" clojure-cycle-if)
    ("ct" "Cycle thread" cljr-cycle-thread)
    ("dk" "Destructure keys" cljr-destructure-keys)
    ("il" "Introduce let" clojure-introduce-let)
    ("el" "Expand let" cljr-expand-let)
    ("ml" "Move to let" clojure-move-to-let)
    ("rl" "Remove let" cljr-remove-let)
    ("pf" "Promote function" cljr-promote-function)
    ("tf" "Thread first all" clojure-thread-first-all)
    ("th" "Thread" clojure-thread)
    ("tl" "Thread last all" clojure-thread-last-all)
    ("ua" "Unwind all" clojure-unwind-all)
    ("uw" "Unwind" clojure-unwind)]
   ["Top-level form"
    ("ad" "Add declaration" cljr-add-declaration)
    ("as" "Add stubs for interface/protocol" cljr-add-stubs)
    ("cp" "Cycle privacy" clojure-cycle-privacy)
    ("cs" "Change function signature" cljr-change-function-signature)
    ("ec" "Extract constant" cljr-extract-constant)
    ("ed" "Extract form as def" cljr-extract-def)
    ("ef" "Extract function" cljr-extract-function)
    ("fe" "Create function from example" cljr-create-fn-from-example)
    ("mf" "Move form" cljr-move-form)
    ("rd" "Reify to defrecord" cljr-reify-to-defrecord)]]
  [["Project"
    ("fu" "Find usages" cljr-find-usages)
    ("rs" "Rename symbol" cljr-rename-symbol)
    ("ur" "Undo last refactoring" cljr-undo-last-refactoring)
    ("rf" "Rename file-or-dir" cljr-rename-file-or-dir)
    ("is" "Inline symbol" cljr-inline-symbol)
    ("pc" "Project clean" cljr-project-clean)
    ("hd" "Hotload dependency" cljr-hotload-dependency)
    ("sp" "Sort project dependencies" cljr-sort-project-dependencies)
    ("up" "Update project dependencies" cljr-update-project-dependencies)]
   ["clj-refactor"
    ("sc" "Show the changelog" cljr-show-changelog)
    ("?" "Describe refactoring" cljr-describe-refactoring)]
   ["Convert collection to"
    ;; These commands live in clojure-mode; surfaced here for discoverability.
    ("xl" "List" clojure-convert-collection-to-list)
    ("xq" "Quoted list" clojure-convert-collection-to-quoted-list)
    ("xm" "Map" clojure-convert-collection-to-map)
    ("xv" "Vector" clojure-convert-collection-to-vector)
    ("xs" "Set" clojure-convert-collection-to-set)]
   ["Options"
    ("W" cljr--toggle-warn-on-eval)
    ("N" cljr--toggle-auto-clean-ns)
    ("P" cljr--toggle-favor-private-functions)
    ("H" cljr--toggle-hotload-dependencies)
    ("E" cljr--toggle-ignore-analyzer-errors)]])


;; ------ utilities -----------

(defun cljr--extract-sexp ()
  (buffer-substring (point) (cljr--point-after 'paredit-forward)))

(defun cljr--delete-sexp ()
  (delete-region (point) (cljr--point-after 'paredit-forward)))

(defun cljr--extract-sexp-as-list (&optional with-whitespace)
  "Returns list of strings representing the elements of the SEXP at point.

If optional `with-whitespace' is T sexp elements are not trimmed."
  (save-excursion
    (let* ((beg (progn (paredit-backward-up)
                       (forward-char)
                       (point)))
           (end (1- (cljr--point-after 'paredit-forward-up)))
           sexp-elems)
      (while (/= (point) end)
        (paredit-forward)
        (let ((sexp-elem (buffer-substring-no-properties beg (point))))
          (push (if with-whitespace sexp-elem (string-trim sexp-elem)) sexp-elems))
        (setq beg (point)))
      (nreverse sexp-elems))))

(defun cljr--extract-region (beg end)
  (prog1
      (buffer-substring-no-properties beg end)
    (delete-region beg end)))

(defun cljr--comment-line-p ()
  (save-excursion
    (goto-char (line-beginning-position))
    (looking-at "\\s-*;+")))

(defun cljr--search-forward-within-sexp (s &optional save-excursion regexp)
  "Searches forward for S in the current sexp.

if SAVE-EXCURSION is T POINT does not move."
  (let ((bound (save-excursion (forward-list 1) (point)))
        (f (if regexp
               're-search-forward
             'search-forward)))
    (if save-excursion
        (save-excursion
          (funcall f s bound t))
      (funcall f s bound t))))

(defun cljr--goto-toplevel ()
  (paredit-backward-up (cljr--depth-at-point))
  (when (looking-back "#" 1)
    (backward-char)))

(defun cljr--top-level-p ()
  "T unless we're in an s-expression or string."
  (= (cljr--depth-at-point) 0))

(defun cljr--depth-at-point ()
  "Returns the depth in s-expressions, or strings, at point."
  (let ((depth (car (paredit-current-parse-state))))
    (if (paredit-in-string-p)
        (1+ depth)
      depth)))

(defun cljr--cleanup-whitespace (stuff)
  "Removes blank lines preceding `stuff' as well as trailing whitespace."
  (with-temp-buffer
    (insert stuff)
    (goto-char (point-min))
    (delete-blank-lines)
    (when (looking-at "[ \t]*$")
      (delete-region (line-beginning-position) (line-end-position)))
    (let ((delete-trailing-lines t))
      (delete-trailing-whitespace)
      (buffer-substring-no-properties (point-min) (point-max)))))

(defun cljr--delete-line ()
  "Deletes the current line without introducing whitespace errors."
  (delete-region (line-beginning-position) (line-end-position))
  (join-line)
  (paredit-forward-delete 1))

(defun cljr--looking-at-dependency-p ()
  (or
   ;; boot & leiningen dependency vector
   (looking-at "\\[[^[[:space:]]+[[:space:]]+\"")
   ;; clj dependency style
   (looking-at "\\([a-z0-9\-\./]+\\)[[:space:]]*\{.*\\(:mvn\\|:local\\|:git\\)/\\(root\\|version\\|url\\)[[:space:]]+\\(\"[^\"]+\"\\)")))

(defun cljr--just-one-blank-line ()
  "Ensure there's only one blank line at POINT."
  (newline 2)
  (forward-line -1)
  (delete-blank-lines))

(defun cljr--point-after (&rest actions)
  "Returns POINT after performing ACTIONS.

An action is either the symbol of a function or a two element
list of (fn args) to pass to `apply''"
  (save-excursion
    (dolist (fn-and-args actions)
      (let ((f (if (listp fn-and-args) (car fn-and-args) fn-and-args))
            (args (if (listp fn-and-args) (cdr fn-and-args) nil)))
        (apply f args)))
    (point)))

(defun cljr--whitespacep (s)
  "True if S contains only whitespace."
  (or (null s) (string-blank-p (string-trim s))))

(defun cljr--make-room-for-toplevel-form ()
  (if (cljr--whitespacep (buffer-substring-no-properties (point) (point-max)))
      ;; make room at end of buffer
      (progn (open-line 2)
             (delete-blank-lines)
             (open-line 1)
             (forward-line))
    (cljr--goto-toplevel)
    (goto-char (line-beginning-position))
    (open-line 2)))

(defun cljr--new-toplevel-form (form)
  "Insert a new toplevel FORM before the form containing POINT."
  (cljr--make-room-for-toplevel-form)
  (insert form))

(defun cljr--goto-toplevel-forward ()
  "Move forward and up until we reach toplevel."
  (paredit-forward-up (cljr--depth-at-point)))

(defun cljr--indent-defun ()
  "Indent the toplevel form containing point."
  (indent-region (cljr--point-after 'cljr--goto-toplevel)
                 (cljr--point-after 'cljr--goto-toplevel-forward)))

(defun cljr--point-at-text-matching
    (regexp direction &optional bound noerror count)
  "Return the point after searching in DIRECTION for TEXT.

DIRECTION is either :forward or :backward.

the optional arguments are passed on the to search function.  See
e.g. `re-search-forward'"
  (save-excursion
    (cond
     ;; NOTE: non-optional direction is intentional because I think it
     ;; improves readability greatly at the call site
     ((eq direction :forward)
      (re-search-forward regexp bound noerror count))
     ((eq direction :backward)
      (re-search-backward regexp bound noerror count))
     (t (error "Only know how to search :forward or :backward, you asked for '%s'"
               direction)))))

(defun cljr--inside-prefixed-libspec-vector-p ()
  "If we're inside a prefixed libspec vector then point is assumed to be just inside the vector.

Note that this function also moves point from the suffix to the prefix."
  (and (looking-back "\\[" 1)
       (progn (paredit-backward-up 2)
              (paredit-forward-down)
              (looking-back "\\[" 1))))

(defun cljr--resolve-alias (alias)
  "Look up ALIAS in the ns form.

if alias is util and the ns-from contains

(:require [refactor-nrepl [util s-expresions]])
refactor-nrepl.util will be returned."
  (save-excursion
    (cljr--goto-ns)
    (when (re-search-forward
           (format ":as\\(-alias\\)?\\s-*\n*\\s-*%s\\_>" (regexp-quote alias))
           (cljr--point-after 'paredit-forward)
           :noerror)
      (paredit-backward-up)
      (paredit-forward-down)
      (let ((ns (buffer-substring-no-properties
                 (point)
                 (cljr--point-after 'paredit-forward))))
        (if (cljr--inside-prefixed-libspec-vector-p)
            (format "%s.%s" (buffer-substring-no-properties
                             (point) (cljr--point-after 'paredit-forward))
                    ns)
          ns)))))

(defun cljr--point-for-anon-function ()
  "Returns the location of point,
if the point is currently placed at the opening parentheses of an anonymous function."
  (cond
   ((looking-at "(fn \\(\\_<[^ ]+\\_>[[:space:]\n]+\\)?\\[")
    (point))
   ((and (eq (char-before) ?#) (eq (char-after) ?\())
    (1- (point)))))

(defun cljr--goto-fn-definition ()
  (if (zerop (car (paredit-current-parse-state)))
      (user-error "Not inside a s-expression")
    (let* ((pt-orig (point))
           (search-bound (cljr--point-after 'cljr--goto-toplevel))
           found-fn-p)
      (while (not found-fn-p)
        (paredit-backward-up)
        (if-let* ((fn-beg (cljr--point-for-anon-function)))
            (let ((fn-end (save-excursion (paredit-forward) (point))))
              (when (and (< fn-beg pt-orig) (< pt-orig fn-end))
                (setq found-fn-p t)
                (when (looking-back "#" 1)
                  (backward-char))))
          (when (<= (point) search-bound)
            (user-error "Can't find definition of anonymous function")))))))

(defun cljr--remove-tramp-prefix-from-msg (entry)
  (let* ((k (car entry))
         (v (cadr entry)))
    (list k
          (if (and (member k '("file" "dir" "path" "old-path" "new-path"))
                   (stringp v))
              (if-let* ((p (cider-tramp-prefix)))
                  (string-remove-prefix p v)
                v)
            v))))

(defconst cljr--middleware-op-prefix "refactor/"
  "Namespace prefix for refactor-nrepl's op names.
refactor-nrepl registers every op under both its bare name (e.g.
`clean-ns') and this namespaced form (e.g. `refactor/clean-ns'), and
treats the namespaced form as canonical - the bare names are slated for
removal in a future refactor-nrepl major release.  We use the namespaced
form (available since refactor-nrepl 3.13.0) so op names can't collide
with those of other middleware.")

(defun cljr--middleware-op (op)
  "Return refactor-nrepl op OP as its canonical namespaced name."
  (concat cljr--middleware-op-prefix op))

(defun cljr--resolve-op (op)
  "Resolve the bare refactor-nrepl OP name against the current connection.
Prefer the canonical namespaced form (see `cljr--middleware-op'), but fall
back to the bare name when only that is advertised - refactor-nrepl older
than 3.13.0 doesn't know the namespaced ops.  When there's no connection to
consult, or neither form is supported, return the namespaced form so error
messages show the canonical name."
  (let ((namespaced (cljr--middleware-op op)))
    (cond ((not (cider-connected-p)) namespaced)
          ((cider-nrepl-op-supported-p namespaced) namespaced)
          ((cider-nrepl-op-supported-p op) op)
          (t namespaced))))

(defun cljr--create-msg (op &rest kvs)
  "Create a msg for the middleware for OP and optionally include the kv pairs KVS.

OP is given as its bare refactor-nrepl name and is resolved to the form the
connected middleware supports (see `cljr--resolve-op').  All config settings
are included in the created msg."
  (cl-assert (cl-evenp (length kvs)) nil "Can't create msg to send to the middleware.\
  Received an uneven number of kv pairs: %s " kvs)
  (apply #'list
         "op" (cljr--resolve-op op)

         "prefix-rewriting"
         (if cljr-favor-prefix-notation
             "true"
           "false")

         "insert-newline-after-require"
         (if cljr-insert-newline-after-require
             "true"
           "false")

         "debug"
         (if cljr--debug-mode
             "true"
           "false")

         (seq-mapcat #'cljr--remove-tramp-prefix-from-msg
                     (seq-partition kvs 2))))

(defun cljr--post-command-message (format-string &rest args)
  "Display msg in a post command hook, to ensure it doesn't drown in emacs' general chatter."
  (push (apply #'format format-string args)
        cljr--post-command-messages))

(defun cljr--post-command-hook ()
  (seq-map #'message cljr--post-command-messages)
  (setq cljr--post-command-messages nil))

(defun cljr--obsolete-notice (command)
  "Say what replaces COMMAND, the first time it runs as a command.
Emacs says so itself, but the command's own messages would cover it, so
this takes over Emacs's notice, which it only gives once a session."
  (when (and (eq this-command command)
             (not (get command 'command-execute-obsolete-warned)))
    (put command 'command-execute-obsolete-warned t)
    (let ((current (car (get command 'byte-obsolete-info))))
      ;; Queued first, it's shown last, after the command's own messages
      (cljr--post-command-message
       "%s" (if (stringp current)
                (format-message "`%s' is obsolete; %s" command current)
              (format-message "`%s' is obsolete; use `%s' instead." command current))))))

;; Not top-level `make-obsolete' forms, which the byte-compiler evaluates
;; too, recording the replacements as symbols with positions in the
;; Emacs that compiles them (e.g. the one installing the package).
(dolist (obsolete '((cljr-add-require-to-ns . cider-ns-add-require)
                    (cljr-add-import-to-ns . cider-ns-add-import)
                    (cljr-add-missing-libspec . cider-ns-add-missing)
                    (cljr-slash . "set `cider-ns-magic-requires' instead.")
                    (cljr-clean-ns . cider-ns-clean)))
  (make-obsolete (car obsolete) (cdr obsolete) "4.1.0"))

(defun cljr-show-changelog ()
  "Show the changelog for `clj-refactor'.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-show-changelog"
  (interactive)
  (find-file (format "%s/CHANGELOG.md" (file-name-directory (locate-library "clj-refactor"))))
  (when (fboundp 'markdown-mode)
    (markdown-mode))
  (view-mode 1))


;; ------ reify protocol defrecord -----------

(defun cljr--goto-reify ()
  (let ((point (point)))
    (while (not (or (cljr--top-level-p)
                    (looking-at-p "(reify")))
      (paredit-backward-up))
    (unless (looking-at-p "(reify")
      (goto-char point)
      (error "Can't find call to reify"))))

(defun cljr-reify-to-defrecord ()
  "Replace a call to reify with a call to a new constructor.
A new record is created to define this constructor."
  (interactive "")
  (cljr--goto-reify)
  (let ((record-name (cljr--prompt-user-for "Name of new record: "))
        (reify-sexp (clojure-delete-and-extract-sexp))
        (placeholder "#85dffa31d"))
    (insert placeholder)
    (cljr--new-toplevel-form reify-sexp)
    (paredit-backward)
    (paredit-forward-down)
    (clojure-delete-and-extract-sexp)
    (insert "defrecord " record-name " []")
    (if (looking-at-p "[ \t]*$")
        (forward-line)
      (newline-and-indent))
    (cljr--goto-toplevel)
    (indent-region (point) (cljr--point-after 'paredit-forward))
    (re-search-forward placeholder)
    (paredit-backward)
    (clojure-delete-and-extract-sexp)
    (insert "("record-name ".)")
    (paredit-backward-down)))

;; ------ file -----------

(defun cljr--locate-project-file (file)
  (ignore-errors
    (file-truename
     (locate-dominating-file default-directory file))))

(defun cljr--project-dir ()
  (or
   (thread-last '("project.clj" "build.boot" "deps.edn" "shadow-cljs.edn" "pom.xml")
                (mapcar 'cljr--locate-project-file)
                (delete 'nil)
                car)
   ""))

(defun cljr--inside-project-p ()
  "Return non-nil if `default-directory' is inside a Clojure project."
  (not (string-empty-p (cljr--project-dir))))

(defun cljr--project-file ()
  (let ((project-dir (cljr--project-dir)))
    (or (let ((file (expand-file-name "project.clj" project-dir)))
          (and (file-exists-p file) file))
        (let ((file (expand-file-name "build.boot" project-dir)))
          (and (file-exists-p file) file))
        (let ((file (expand-file-name "deps.edn" project-dir)))
          (and (file-exists-p file) file))
        (let ((file (expand-file-name "shadow-cljs.edn" project-dir)))
          (and (file-exists-p file) file))
        (let ((file (expand-file-name "pom.xml" project-dir)))
          (and (file-exists-p file) file)))))

(defun cljr--project-files ()
  (split-string (shell-command-to-string
                 (format "find %s -type f \\( %s -or %s \\) %s | head -n %s"
                         (cljr--project-dir)
                         (format "-name \"%s\"" "*.clj")
                         (format "-name \"%s\"" "*.cljc")
                         "-not -regex \".*svn.*\""
                         1000))))

(defun cljr--project-with-deps-p (project-file)
  (string-match "/deps.edn$" project-file))

(defun cljr--buffers-visiting-dir (dir)
  (seq-filter (lambda (buf)
                (when-let* ((path (buffer-file-name buf)))
                  (string-prefix-p dir path :ignore-case)))
              (buffer-list)))

(defun cljr--revisit-buffers (buffers new-dir active)
  "After moving a directory revisit all files visited by BUFFERS by looking them up in NEW-DIR.

ACTIVE is the buffer the user was looking at when the command was issued, and should be left focused."
  (let ((files (directory-files new-dir))
        (new-dir (if (string-suffix-p "/" new-dir) new-dir (format "%s/" new-dir)))
        (same-file (lambda (buf f)
                     (when (string= (file-name-nondirectory f)
                                    (file-name-nondirectory (buffer-file-name buf)))
                       f))))
    (dolist (buf buffers)
      (find-file
       (format "%s%s" new-dir (seq-some (apply-partially same-file buf) files)))
      (kill-buffer buf))
    (find-file (format "%s/%s" new-dir (seq-some (apply-partially same-file active) files)))))


(defcustom cljr-print-right-margin 72
  "Will be forwarded to `clojure.pprint/*print-right-margin*' when refactor-nrepl pretty-prints ns forms,
as performed after `clean-ns', `rename-file-or-dir', etc.
You can set it to the string \"nil\" for disabling line wrapping.

See also: `cljr-print-miser-width'."
  :type '(choice integer string)
  :safe (lambda (s) (or (integerp s) (stringp s)))
  :package-version "3.2.0")

(defcustom cljr-print-miser-width 40
  "Will be forwarded to `clojure.pprint/*print-miser-width*' when refactor-nrepl pretty-prints ns forms,
as performed after `clean-ns', `rename-file-or-dir', etc.

You can set it to the string \"nil\" for disabling line wrapping.

See also: `cljr-print-right-margin'."
  :type '(choice integer string)
  :safe (lambda (s) (or (integerp s) (stringp s)))
  :package-version "3.2.0")

;;;###autoload
(defun cljr-rename-file-or-dir (old-path new-path)
  "Rename a file or directory of files.
Buffers visiting any affected file are killed and the
corresponding files are revisited.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-rename-file-or-dir"
  (interactive
   (let ((old (read-file-name "Old path: " nil nil 'mustmatch "")))
     (list old
           (if (file-directory-p old)
               (read-directory-name "New path: " old)
             (read-file-name "New path: "
                             (file-name-directory old)
                             nil nil
                             (file-name-nondirectory old))))))
  (cljr--ensure-op-supported "rename-file-or-dir")
  (when (cljr--asts-y-or-n-p)
    (let* ((active-buffer (current-buffer))
           (affected-buffers (when (file-directory-p old-path)
                               (cljr--buffers-visiting-dir old-path)))
           (old-path (expand-file-name old-path))
           (new-path (cljr--maybe-replace-dash-in-file-name (expand-file-name new-path)))
           (nrepl-new-path (funcall cider-to-nrepl-filename-function new-path))
           (nrepl-old-path (funcall cider-to-nrepl-filename-function old-path)))
      (when (y-or-n-p (format "Really rename %s to %s?" old-path new-path))
        ;; Renaming a file rewrites references to it across the whole project,
        ;; which can take a while, so run it asynchronously and finish up in the
        ;; callback rather than freezing Emacs on a synchronous round-trip.
        (message "Renaming %s..." old-path)
        (cljr--call-middleware-async-collect
         (cljr--create-msg "rename-file-or-dir"
                           "old-path" nrepl-old-path
                           "new-path" nrepl-new-path
                           "print-right-margin" cljr-print-right-margin
                           "print-miser-width" cljr-print-miser-width)
         "touched"
         (lambda (changed-files)
           (let ((changed-files-count (length changed-files)))
             (cond
              ((null changed-files) (message "Rename complete! No files affected."))
              ((= changed-files-count 1) (message "Renamed %s to %s." old-path new-path))
              (t (message "Rename complete! %s files affected." changed-files-count)))
             (when (and (> changed-files-count 0) (not cljr-warn-on-eval))
               (cljr--warm-ast-cache)))
           (if affected-buffers
               (cljr--revisit-buffers affected-buffers new-path active-buffer)
             (when (buffer-live-p active-buffer)
               (kill-buffer active-buffer))
             (find-file new-path))))))))

;;;###autoload
(defun cljr-rename-file (new-path)
  (interactive
   (let ((old (buffer-file-name)))
     (list (read-file-name "New path: "
                           (file-name-directory old)
                           nil nil
                           (file-name-nondirectory old)))))
  (cljr-rename-file-or-dir (buffer-file-name) new-path))

(defun cljr--op-supported-p (op)
  "Is the refactor-nrepl OP (bare name) provided by the current middleware?
Checks the canonical namespaced form (see `cljr--middleware-op') as well as
the bare one, so old middleware that only advertises the bare names counts
as support too - matching the op resolution `cljr--create-msg' performs."
  ;; Guard on the connection first: `cider-nrepl-op-supported-p' resolves the
  ;; REPL with the `ensure' flag and signals `No linked CIDER sessions' when
  ;; nothing is connected.  We want a plain nil there, so the offline fallbacks
  ;; that gate on this predicate (`cljr-slash', `cljr-clean-ns', ...) can kick in.
  (and (cider-connected-p)
       (or (cider-nrepl-op-supported-p (cljr--middleware-op op))
           (cider-nrepl-op-supported-p op))))

(defun cljr--assert-middleware ()
  (unless (featurep 'cider)
    (user-error "CIDER isn't installed"))
  (unless (cider-connected-p)
    (user-error "CIDER isn't connected"))
  (unless (cljr--op-supported-p "find-symbol")
    (user-error "The refactor-nrepl middleware isn't available. \
Did you remember to install it?")))

(defun cljr--ensure-op-supported (op)
  "Check for support of middleware op OP.

Signal an error if it is not supported, otherwise return OP."
  (cljr--assert-middleware)
  (if (cljr--op-supported-p op)
      op
    (user-error "Can't find nREPL middleware providing op \"%s\".  \
Please, install (or update) refactor-nrepl %s and restart the REPL"
                op (upcase cljr-injected-middleware-version))))

(defun cljr--assert-leiningen-project ()
  (unless (string= (file-name-nondirectory (or (cljr--project-file) ""))
                   "project.clj")
    (user-error "Can't find project.clj")))

;; ------ ns statements -----------

(defun cljr--goto-ns ()
  "Go to the first namespace defining form in the buffer."
  (goto-char (point-min))
  (if (re-search-forward clojure-namespace-regexp nil t)
      (cljr--goto-toplevel)
    (user-error "No namespace declaration found")))

(defun cljr--goto-closest-ns ()
  "Go to the closest namespace defining form.
Go to the namespace form closest to point and above it.  If there is
no namespace form above point, return the first one in the buffer."
  (save-restriction
    (widen)
    ;; The closest ns form above point.
    (when (or (re-search-backward clojure-namespace-regexp nil t)
              ;; Or any form at all.
              (and (goto-char (point-min))
                   (re-search-forward clojure-namespace-regexp nil t)))
      (cljr--goto-toplevel))))

(defun cljr--goto-cljs-branch ()
  "Move POINT to the cljs branch of the reader conditional following point."
  (if (re-search-forward ":cljs" (cljr--point-after 'paredit-forward) :no-error)
      (save-excursion
        (paredit-backward-up)
        (unless (looking-back "#\?@?" 3)
          (user-error "No cljs branch found")))
    (user-error "No cljs branch found")))

(defun cljr--insert-in-ns (type &optional cljs?)
  "Insert another clause into the TYPE clause of the ns statement.

TYPE is :require, :use etc.

If CLJS? is T we insert in the cljs part of the ns declaration."
  (cljr--goto-ns)
  (when cljs?
    (cljr--goto-cljs-branch))
  (if (cljr--search-forward-within-sexp (concat "("
                                                type
                                                ;; match e.g. `require' but not `require-macros',
                                                ;; or vice versa.
                                                ;; See https://github.com/clojure-emacs/clj-refactor.el/issues/512
                                                "\\(?:$\\|[^-a-zA-Z]\\)")
                                        nil
                                        t)
      (if (looking-at " *)")
          (progn
            (search-backward "(")
            (forward-list 1)
            (forward-char -1)
            (insert " "))
        (search-backward "(")
        (forward-list 1)
        (forward-char -1)
        (newline-and-indent))
    (forward-list 1)
    (forward-char -1)
    (newline-and-indent)
    (insert "(" type " )")
    (forward-char -1)))

(defun cljr--project-depends-on-p (package)
  (with-current-buffer
      (find-file-noselect (cljr--project-file))
    (goto-char (point-min))
    (search-forward package nil t)))

(defun cljr--find-source-ns-of-test-ns (test-ns test-file)
  (let* ((ns-chunks (split-string test-ns "[.]" t))
         (test-name (car (last ns-chunks)))
         (src-dir-name (replace-regexp-in-string "test/" "src/" (file-name-directory test-file) t t))
         (replace-underscore (apply-partially 'replace-regexp-in-string "_" "-"))
         (src-ns (car (seq-filter (lambda (it) (or (string-prefix-p it test-name)
                                                   (string-suffix-p it test-name)))
                                  (seq-map (lambda (file-name)
                                             (funcall replace-underscore
                                                      (file-name-sans-extension file-name)))
                                           (directory-files src-dir-name))))))
    (when src-ns
      (mapconcat 'identity (append (butlast ns-chunks) (list src-ns)) "."))))

(defun cljr--cljs-file-p (&optional buf)
  "Is BUF, or the current buffer, visiting a cljs file?"
  (when-let* ((bfn (buffer-file-name (or buf (current-buffer)))))
    (string-equal (file-name-extension bfn)
                  "cljs")))

(defun cljr--cljc-file-p (&optional buf)
  "Is BUF, or the current buffer, visiting a cljc file?"
  (when-let* ((bfn (buffer-file-name (or buf (current-buffer)))))
    (string-equal (file-name-extension bfn)
                  "cljc")))

(defun cljr--clj-file-p (&optional buf)
  "Is BUF, or the current buffer, visiting a clj file?"
  (or (eq major-mode 'clojure-mode)
      (when-let* ((bfn (buffer-file-name (or buf (current-buffer)))))
        (string-equal (file-name-extension bfn)
                      "clj"))))

(defun cljr--add-test-declarations ()
  (save-excursion
    (let* ((ns (clojure-find-ns))
           (source-ns (cljr--find-source-ns-of-test-ns ns (buffer-file-name))))
      (when source-ns
        (cljr--insert-in-ns ":require")
        (insert "[" source-ns " :as "
                cljr-clojure-test-namespace-under-test-alias "]"))
      (cljr--insert-in-ns ":require")
      (insert (cond
               ((cljr--project-depends-on-p "midje")
                cljr-midje-test-declaration)
               ((cljr--project-depends-on-p "expectations")
                cljr-expectations-test-declaration)
               ((cljr--cljs-file-p)
                cljr-cljs-clojure-test-declaration)
               ((cljr--cljc-file-p)
                cljr-cljc-clojure-test-declaration)
               (t cljr-clojure-test-declaration))))
    (indent-region (point-min) (point-max))))

(defun cljr--in-tests-p ()
  "Check whether the current file is a test file.

Two checks are made - whether the namespace of the file has the
word test in it and whether the file lives under the test/ directory."
  (or (string-match-p "\\btest\\b" (clojure-find-ns))
      (string-match-p "/test" (buffer-file-name))))

(defun cljr--clojure-ish-filename-p (file-name)
  (or (string-suffix-p ".clj" file-name)
      (string-suffix-p ".cljs" file-name)
      (string-suffix-p ".cljx" file-name)
      (string-suffix-p ".cljc" file-name)))

(defun cljr--clojure-filename-p (&optional file-name)
  (or (string-suffix-p ".clj" (or file-name (buffer-file-name)))
      (string-suffix-p ".cljc" (or file-name (buffer-file-name)))))

(defun cljr--add-ns-if-blank-clj-file ()
  (ignore-errors
    (when (and cljr-add-ns-to-blank-clj-files
               (cljr--clojure-ish-filename-p (buffer-file-name))
               (= (point-min) (point-max)))
      (insert (format "(ns %s)\n\n" (cider-expected-ns)))
      (when (cljr--in-tests-p)
        (cljr--add-test-declarations)))))

(add-hook 'find-file-hook 'cljr--add-ns-if-blank-clj-file)

(defun cljr--dash-in-file-name-p (file-name)
  (and file-name (string-match-p "-[^/]+\.clj[sxc]?$" file-name)))

(defun cljr--maybe-replace-dash-in-file-name (file-name)
  (if (and (cljr--dash-in-file-name-p file-name)
           (yes-or-no-p "The file name contains dashes. Replace with underscores? "))
      (concat (file-name-directory file-name)
              (replace-regexp-in-string "-" "_" (file-name-nondirectory file-name)))
    file-name))

(defun cljr--ensure-no-dashes-in-filename ()
  (when (and (buffer-file-name)
             (not (file-exists-p (buffer-file-name))) ; only new files
             (cljr--dash-in-file-name-p (buffer-file-name)))
    (let ((new-name (cljr--maybe-replace-dash-in-file-name (buffer-file-name))))
      (rename-buffer new-name)
      (set-visited-file-name new-name)
      (message "Changed file name to '%s'"
               (file-name-nondirectory new-name)))))

(add-hook 'find-file-hook 'cljr--ensure-no-dashes-in-filename)

(defun cljr--get-ns-statements (statement-type)
  (save-excursion
    (cljr--goto-ns)
    (when (cljr--search-forward-within-sexp (concat "(" statement-type))
      (let ((beg (point)))
        (paredit-forward-up)
        (paredit-backward-down)
        (buffer-substring-no-properties beg (point))))))

(defun cljr--get-ns-statements-as-list (statement-type)
  (save-excursion
    (cljr--goto-ns)
    (when (cljr--search-forward-within-sexp (concat "(" statement-type))
      (cljr--extract-sexp-as-list t))))

(defun cljr--extract-sexp-content (sexp)
  (replace-regexp-in-string "\\[?(?]?)?" "" sexp))

(defun cljr--maybe-clean-ns ()
  (when (and cljr-auto-clean-ns (cider-connected-p)
             (cljr--op-supported-p "clean-ns"))
    (let ((*cljr--noninteractive* t))
      (cljr--clean-or-sort-ns))))

(defvar cljr--tmp-marker (make-marker))

(defun cljr--pop-tmp-marker-after-yasnippet-1 (&rest _)
  (goto-char cljr--tmp-marker)
  (set-marker cljr--tmp-marker nil)
  (remove-hook 'yas-after-exit-snippet-hook
               'cljr--pop-tmp-marker-after-yasnippet-1 :local))

(defun cljr--pop-tmp-marker-after-yasnippet ()
  (add-hook 'yas-after-exit-snippet-hook
            'cljr--pop-tmp-marker-after-yasnippet-1 nil :local))

(defun cljr--maybe-eval-ns-form-and-remove-hook ()
  (cljr--maybe-eval-ns-form)
  (remove-hook 'yas-after-exit-snippet-hook
               'cljr--maybe-eval-ns-form-and-remove-hook :local))

(defun cljr--sort-ns ()
  "Sort the ns form syntactically via `clojure-sort-ns'.
`clojure-sort-ns' walks the form with `forward-sexp' assuming
syntax-table-based movement; under clojure-ts-mode's tree-sitter-based
`forward-sexp-function' the sort silently does nothing, so force the
default movement here."
  (let ((forward-sexp-function nil))
    (clojure-sort-ns)))

(defun cljr--maybe-sort-ns ()
  (when cljr-auto-sort-ns
    (if (and (cider-connected-p) (cljr--op-supported-p "clean-ns"))
        (cljr--clean-ns nil :no-pruning)
      ;; Offline: sort the ns form syntactically via clojure-mode, quietly,
      ;; so this stays useful without a running REPL.
      (let ((inhibit-message t))
        (ignore-errors (cljr--sort-ns))))))

(defun cljr--sort-and-remove-hook (&rest _)
  (cljr--maybe-sort-ns)
  (remove-hook 'yas-after-exit-snippet-hook
               'cljr--sort-and-remove-hook :local))

(defun cljr--add-yas-ns-updated-hook ()
  (add-hook 'yas-after-exit-snippet-hook 'cljr--sort-and-remove-hook nil :local)
  (add-hook 'yas-after-exit-snippet-hook
            'cljr--maybe-eval-ns-form-and-remove-hook nil :local))

(defun cljr--add-to-ns (type snippet &optional cljs?)
  "Expand SNIPPET in the TYPE clause of the ns form.
TYPE is :require, :import etc.  If CLJS? is non-nil, act on the cljs
part of the ns declaration.  Point goes back to where it was once the
snippet is done, or right away if there's no place for the snippet."
  ;; The marker all buffers share may be waiting on a snippet elsewhere,
  ;; so it's left alone until there's a snippet to expand here.
  (let ((origin (point-marker)))
    (condition-case err
        (cljr--insert-in-ns type cljs?)
      (error
       (goto-char origin)
       (set-marker origin nil)
       (signal (car err) (cdr err))))
    (set-marker cljr--tmp-marker origin)
    (set-marker origin nil))
  (cljr--pop-tmp-marker-after-yasnippet)
  (cljr--add-yas-ns-updated-hook)
  (yas-expand-snippet snippet))

;;;###autoload
(defun cljr-add-require-to-ns (cljs?)
  "Add a require statement to the ns form in current buffer.

With a prefix act on the cljs part of the ns declaration.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-add-require-to-ns"
  (interactive "P")
  (cljr--obsolete-notice 'cljr-add-require-to-ns)
  (cljr--add-to-ns ":require" cljr--add-require-snippet cljs?))

;;;###autoload
(defun cljr-add-use-to-ns (cljs?)
  "Add a use statement to the buffer's ns form.

With a prefix act on the cljs part of the ns declaration.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-add-use-to-ns"
  (interactive "P")
  (cljr--add-to-ns ":require" cljr--add-use-snippet cljs?))

;;;###autoload
(defun cljr-add-import-to-ns (&optional cljs?)
  "Add an import statement to the buffer's ns form.

With a prefix act on the cljs part of the ns declaration.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-add-import-to-ns"
  (interactive "P")
  (cljr--obsolete-notice 'cljr-add-import-to-ns)
  (cljr--add-to-ns ":import" "$1" cljs?))

(defun cljr--extract-refer-all-namespaces ()
  "Returns a list of all the namespaces that are required with :refer :all"
  (cljr--goto-ns)
  (when (search-forward ":require" nil t)
    (let (nses
          (require-end (save-excursion
                         (progn
                           (paredit-backward-up)
                           (paredit-forward)
                           (point)))))
      (if (not (save-excursion (re-search-forward ":refer\s:all" require-end t)))
          (message "There is no :refer :all in the ns declaration.")
        (while (re-search-forward ":refer\s:all" require-end t)
          (paredit-backward-up)
          (let ((prefix (save-excursion
                          (when (progn
                                  (paredit-backward-up)
                                  (not (looking-at-p "(:require")))
                            (paredit-forward-down)
                            (buffer-substring (point) (cljr--point-after 'paredit-forward)))))
                (ns (progn
                      (paredit-forward-down)
                      (buffer-substring (point) (cljr--point-after 'paredit-forward)))))
            (push
             (if prefix
                 (concat prefix "." ns)
               ns)
             nses)
            (paredit-forward-up)))
        (nreverse nses)))))

;;;###autoload
(defun cljr-require-macro ()
  "Add a require statement for a macro to the ns form in current buffer.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-require-macro"
  (interactive)
  (cljr--add-to-ns ":require-macros" cljr--add-require-snippet))

;;;###autoload
(defun cljr-stop-referring ()
  "Stop referring to vars in the namespace at point.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-stop-referring"
  (interactive)
  (save-excursion
    (paredit-backward-up)
    (unless (looking-at "\\[")
      (user-error "Place cursor on the namespace whose vars you want to stop referring to"))
    (paredit-backward-up)
    (unless (looking-at "(:require")
      (user-error "Place cursor on the namespace whose vars you want to stop referring to")))
  (save-excursion
    (paredit-backward-up)
    (let* ((bound (save-excursion
                    (paredit-forward)
                    (point)))
           (ns (save-excursion
                 (paredit-forward-down)
                 (let ((beg (point)))
                   (paredit-forward)
                   (buffer-substring-no-properties beg (point)))))
           (alias (save-excursion
                    (paredit-forward-down)
                    (when (search-forward " :as " bound t)
                      (let ((beg (point)))
                        (paredit-forward)
                        (buffer-substring-no-properties beg (point)))))))
      (unless (re-search-forward ":refer" bound t)
        (user-error "No :refer clause found"))
      (if (looking-at "\s*:all")
          (progn
            (paredit-backward-up)
            (cljr--replace-refer-all ns alias))
        (paredit-forward-down)
        (let* ((beg (point))
               (str (progn (paredit-forward-up)
                           (paredit-backward-down)
                           (buffer-substring-no-properties beg (point))))
               (symbols (split-string (string-trim str) " " t)))
          (paredit-backward-up)
          (paredit-backward)
          (clojure-delete-and-extract-sexp)
          (clojure-delete-and-extract-sexp)
          (cond
           ((looking-at-p "\\s-*[\\w:]+")
            (just-one-space))

           ((looking-back "\\w+ " 3)
            (just-one-space 0))

           (t (join-line)))
          (cljr--add-ns-prefix (or alias ns) symbols))))))

(defun cljr--add-ns-prefix (ns symbols)
  "Adds an NS prefix to every symbol in SYMBOLS."
  (save-excursion
    (cljr--goto-ns)
    (paredit-forward)
    (let ((case-fold-search nil))
      (while (re-search-forward (regexp-opt symbols 'symbols) nil t)
        (when (save-excursion
                (paredit-backward-up)
                (not (looking-at "\"")))
          (paredit-backward)
          (insert ns "/")
          (paredit-forward))))))

(defun cljr--insert-with-proper-whitespace (forms)
  (open-line 2)
  (forward-line 2)
  (let ((p (point)))
    (insert forms)
    (open-line 2)
    (forward-line)
    (cljr--just-one-blank-line)
    (save-excursion
      (goto-char p)
      (cljr--just-one-blank-line))))

(defun cljr--slice-at (pattern s)
  "Slice S up at every index matching PATTERN."
  (let ((slices (split-string s pattern)))
    (cons (car slices) (mapcar (lambda (slice) (concat pattern slice)) (cdr slices)))))

;;;###autoload
(defun cljr-move-form ()
  "Move the form containing POINT to a new namespace.

If REGION is active, move all forms contained by region.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-move-form"
  (interactive)
  (let* ((forms (if (region-active-p)
                    (let ((beg (region-beginning))
                          (end (region-end)))
                      (prog2
                          (paredit-check-region-for-delete beg end)
                          (buffer-substring-no-properties beg end)
                        (delete-region beg end)))
                  (cljr--goto-toplevel)
                  (prog1 (clojure-delete-and-extract-sexp)
                    (join-line)
                    (join-line)
                    (unless (eobp)
                      (delete-char 1)))))
         (forms (cljr--cleanup-whitespace forms))
         (requires (cl-rest (cljr--get-ns-statements-as-list ":require"))))
    (let (ns names target-ns-alias
             (target-ns-regexp-template "[\(\[]\\s-*%s")
             (target-ns-alias-template ":as\\s-*\n*\\s-*\\(.*\\)\\_>\\s-*\n*\\s-*[\]\)]"))
      (save-window-excursion
        (find-file (read-file-name "Move form to file: "))
        (setq ns (cljr--current-namespace)
              names (cljr--name-of-defns forms)
              target-ns-alias (when-let* ((filtered-require (seq-find
                                                             (lambda (it)
                                                               (string-match-p (format target-ns-regexp-template ns) it))
                                                             requires)))
                                (thread-last filtered-require
                                             (cljr--slice-at ":as")
                                             last
                                             car
                                             (replace-regexp-in-string target-ns-alias-template "\\1")
                                             string-trim)))
        (goto-char (point-max))
        (cljr--insert-with-proper-whitespace
         (cljr--remove-references-of-target-ns forms ns target-ns-alias))
        ;; The target has no use for a libspec of itself.
        (when-let* ((requires (seq-remove (lambda (it)
                                            (string-match-p (format target-ns-regexp-template ns) it))
                                          requires)))
          (cljr--insert-in-ns ":require")
          (insert (string-trim (apply #'concat requires)))
          (cljr--clean-or-sort-ns))
        (save-buffer))
      (cljr--update-ns-after-moving-fns ns (nreverse names))
      (cljr--clean-or-sort-ns)))
  (cljr--just-one-blank-line))

(defun cljr--remove-references-of-target-ns (forms ns alias)
  (thread-last (replace-regexp-in-string (format "\\_<%s/" alias) "" forms)
               (replace-regexp-in-string (format "\\_<%s/" ns) "")))

(defun cljr--update-ns-after-moving-fns (ns &optional refer-names)
  "Updates the current ns declaration,
after moving defn forms out of the current file and to NS.

Optionally refers the names in REFER-NAMES."
  (save-excursion
    (cljr--goto-ns)
    (let* ((ns-present-p (cljr--search-forward-within-sexp ns :save-excursion))
           (refer-present-p (cljr--search-forward-within-sexp ":refer" :save-excursion))
           (refer-all-p (cljr--search-forward-within-sexp ":refer :all" :save-excursion))
           (require-present-p (cljr--search-forward-within-sexp
                               (concat ":require [" ns)
                               :save-excursion)))
      (if ns-present-p
          (unless (or refer-all-p (null refer-names))
            (if refer-present-p
                (cljr--append-names-to-refer ns refer-names)
              (when require-present-p
                (cljr--append-refer-clause ns refer-names))))
        (cljr--new-require-clause ns refer-names)))))

(defun cljr--append-refer-clause (ns refer-names)
  "Appends :refer [REFER-NAMES] to the :require clause for NS."
  (save-excursion
    (cljr--goto-ns)
    (re-search-forward ":require")
    (re-search-forward ns)
    (paredit-forward-up)
    (backward-char)
    (insert " :refer [" (string-join refer-names  " ") "]")))

(defun cljr--append-names-to-refer (ns names)
  "Append NAMES to the :refer vector for NS."
  (save-excursion
    (cljr--goto-ns)
    (re-search-forward ":require")
    (re-search-forward ns)
    (re-search-forward ":refer")
    (paredit-forward)
    (backward-char)
    (insert (format " %s" (string-join names  " ")))))

(defun cljr--new-require-clause (ns &optional refer-names)
  "Creates a new :require clause for NS.

Optionally adds :refer [REFER-NAMES] clause."
  (cljr--insert-in-ns ":require")
  (insert "[" ns "]")
  (when refer-names
    (cljr--append-refer-clause ns refer-names)))

(defmacro cljr--with-string-content (s &rest body)
  (declare (debug (form body))
           (indent 1))
  `(with-temp-buffer
     (delay-mode-hooks
       (clojure-mode)
       (insert ,s)
       (goto-char (point-min))
       ,@body)))

(defun cljr--name-of-defns (string-with-defns &optional include-private)
  "Returns a list of the function names in STRING-WITH-DEFNS,
optionally including those that are declared private."
  (cljr--with-string-content string-with-defns
    (let ((count (paredit-count-sexps-forward))
          (names '()))
      (dotimes (_ count)
        (paredit-forward-down)
        (cljr--goto-toplevel)
        (forward-char)
        (if (and include-private (looking-at "defn-"))
            (push (cljr--name-of-current-def) names)
          (when (looking-at "defn ")
            (push (cljr--name-of-current-def) names)))
        (paredit-forward-up))
      names)))

(defun cljr--current-namespace ()
  (save-excursion
    (cljr--goto-ns)
    (forward-char)
    (paredit-forward)
    (forward-char)
    (let ((beg (point))
          (end (cljr--point-after 'paredit-forward)))
      (buffer-substring-no-properties beg end))))

;; ------ declare statements -----------

(defun cljr--goto-declare ()
  (goto-char (point-min))
  (if (re-search-forward "(declare" nil t)
      (paredit-forward-up)
    (cljr--goto-ns)
    (paredit-forward)
    (open-line 2)
    (forward-line 2)
    (insert "(declare)")))

(defun cljr--name-of-current-def ()
  (cljr--goto-toplevel)
  (ignore-errors (forward-char))
  (when (looking-at "\\(.+/\\)?def")
    (paredit-forward)
    (while (looking-at " ^")
      (paredit-forward))
    (forward-char)
    (let ((beg (point))
          (end (cljr--point-after 'paredit-forward)))
      (buffer-substring-no-properties beg end))))

(defun cljr--already-declared-p (def)
  (save-excursion
    (cljr--goto-declare)
    ;; `def' is a symbol name; quote it and match on symbol boundaries so
    ;; names containing regexp specials (*foo*, valid?, +, ...) work and we
    ;; don't match a longer symbol that merely contains it.
    (re-search-backward (concat "\\_<" (regexp-quote def) "\\_>")
                        (cljr--point-after 'paredit-backward) :no-error)))

(defun cljr--add-declaration (def)
  (when (cljr--already-declared-p def)
    (user-error "%s is already declared" def))
  (save-excursion
    (cljr--goto-declare)
    (backward-char)
    (insert " " def)
    (cljr--post-command-message "Added declaration for %s" def)))

;;;###autoload
(defun cljr-add-declaration (for-thing-at-point-p)
  "Add a declare for the current def near the top of the buffer.

With a prefix add a declaration for the symbol under the cursor instead.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-add-declaration"
  (interactive "P")
  (if-let* ((def (and (not for-thing-at-point-p)
                      (save-excursion (cljr--name-of-current-def)))))
      (cljr--add-declaration def)
    (cljr--add-declaration (cider-symbol-at-point))))

;; ------ extract constant ----------------

(defun cljr--existing-group-of-defs-p ()
  "Is there a group of defs at the beginning of the namespace?"
  (save-excursion
    (cljr--goto-ns)
    (paredit-forward)
    (cljr--skip-past-whitespace-and-comments)
    (looking-at-p "(def ")))

(defun cljr--prepare-to-append-to-existing-group-of-defs ()
  "Place point at the end of the final def form,
in the group of defs appearing at the start of the ns.

Point is assumed to be just after the ns form."
  (cljr--skip-past-whitespace-and-comments)
  (while (looking-at-p "(def ")
    (paredit-forward)
    (forward-line)
    (cljr--skip-past-whitespace-and-comments))
  (paredit-backward)
  (paredit-forward))

(defun cljr--prepare-to-insert-new-def ()
  "Skip past all previously defined vars at the beginning of the ns."
  (cljr--goto-ns)
  (paredit-forward)
  (if (cljr--existing-group-of-defs-p)
      (cljr--prepare-to-append-to-existing-group-of-defs)
    (insert "\n")))

(defun cljr--extract-def-at-point (&optional const?)
  (let ((name (let ((highlight (cljr--highlight-sexp)))
                (unwind-protect
                    (cljr--prompt-user-for "Name: ")
                  (delete-overlay highlight))))
        (body (clojure-delete-and-extract-sexp))
        const-pos)
    (save-excursion
      (cljr--prepare-to-insert-new-def)
      (insert "\n(def ")
      (when const?
        (insert "^:const "))
      (insert name)
      (insert " " body ")")
      (setq const-pos (point)))
    (insert name)
    (save-excursion
      (query-replace body name nil const-pos (point-max)))))

;;;###autoload
(defun cljr-extract-constant ()
  "Extract form at (or above) point as a constant.
Create a def for it at the top level, and replace its current
occurrence with the defined name.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-extract-constant"
  (interactive)
  (cljr--extract-def-at-point :const))

;;;###autoload
(defun cljr-extract-def ()
  "Extract form at (or above) point as a def.
Create a def for it at the top level, and replace its current
occurrence with the defined name.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-extract-def"
  (interactive)
  (cljr--extract-def-at-point))

(defun cljr--goto-thread ()
  (while (not (or (cljr--top-level-p)
                  (looking-at "\(.*->>?[\n\r\t ]")))
    (paredit-backward-up)))

(defun cljr--reindent-thread ()
  (cljr--goto-thread)
  (let ((beg (point))
        (end (cljr--point-after 'paredit-forward)))
    (indent-region beg end)))

;;;###autoload
(defun cljr-cycle-thread ()
  "Cycle a threading macro between -> and ->>.
Also applies to other versions of the macros, like cond->.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-cycle-thread"
  (interactive)
  (save-excursion
    (cljr--goto-thread)
    (cond
     ((looking-at ".*->>")
      (paredit-forward-down)
      (paredit-forward)
      (backward-char)
      (delete-region (point) (+ 1 (point)))
      (cljr--reindent-thread))

     ((looking-at ".*->[^>]")
      (paredit-forward-down)
      (paredit-forward)
      (insert ">")
      (cljr--reindent-thread))

     (t (user-error "Point is not inside a threading macro")))))

;; ------ let binding ----------

(define-obsolete-function-alias 'cljr-introduce-let #'clojure-introduce-let "4.0.0")

(defun cljr--get-let-bindings ()
  "Returns a list of lists.

The inner lists contain two elements first is the binding, second is the init-expr"
  (seq-partition (clojure--read-let-bindings) 2))

(defun cljr--replace-sexp-with-binding (binding)
  (save-excursion
    (let ((bind-var (car binding))
          (init-expr (car (last binding)))
          (end (cljr--point-after 'clojure--goto-let 'paredit-forward)))
      (while (re-search-forward (clojure--sexp-regexp init-expr) end t)
        (replace-match (concat "\\1" bind-var "\\2"))))))

(defun cljr--one-shot-keybinding (key command)
  (set-transient-map
   (let ((map (make-sparse-keymap)))
     (define-key map (kbd key) command)
     map) t))

(defun cljr--paredit-convolute-no-advice ()
  (if (not (advice-member-p #'clojure--replace-let-bindings-and-indent 'paredit-convolute-sexp))
      (paredit-convolute-sexp)
    (advice-remove 'paredit-convolute-sexp #'clojure--replace-let-bindings-and-indent)
    (paredit-convolute-sexp)
    (advice-add 'paredit-convolute-sexp :after #'clojure--replace-let-bindings-and-indent)))

;;;###autoload
(defun cljr-expand-let ()
  "Expand the let form above point by one level.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-expand-let"
  (interactive)
  (clojure--goto-let)
  (paredit-forward-down 2)
  (paredit-forward-up)
  (cljr--skip-past-whitespace-and-comments)
  (cljr--paredit-convolute-no-advice)
  (mapc 'cljr--replace-sexp-with-binding (cljr--get-let-bindings))
  (cljr--one-shot-keybinding "l" 'cljr-expand-let))

(define-obsolete-function-alias 'cljr-move-to-let #'clojure-move-to-let "4.0.0")

(defun cljr--eliminate-let ()
  "Remove a the nearest let form.

This function only does the actual removal."
  (clojure--goto-let)
  (paredit-forward-down)
  (paredit-forward 2)
  (paredit-splice-sexp-killing-backward))

(defun cljr--let-body-start ()
  "Return the position of the start of the nearest let form's body."
  (save-excursion
    (clojure--goto-let)
    (down-list)
    (forward-sexp 2) ; past the `let' symbol and the bindings vector
    (point)))

(defun cljr--inline-let-binding (bind-var init-expr limit)
  "Replace occurrences of BIND-VAR with INIT-EXPR up to LIMIT.
BIND-VAR and INIT-EXPR are strings; LIMIT is a marker.  Only whole-symbol
occurrences are replaced (see `clojure--sexp-regexp'); INIT-EXPR is
inserted literally."
  (let ((case-fold-search nil))
    (while (re-search-forward (clojure--sexp-regexp bind-var) limit t)
      ;; the symbol sits between the two boundary chars (groups 1 and 2)
      (let ((beg (match-end 1))
            (end (match-beginning 2)))
        (delete-region beg end)
        (goto-char beg)
        (insert init-expr)))))

(defun cljr-remove-let ()
  "Inline all bindings of the nearest let form and remove it.

This is a local edit and does not require a running REPL.  Bindings are
inlined in reverse order, so a binding that refers to an earlier one is
resolved correctly.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-remove-let"
  (interactive)
  (save-excursion
    (clojure--goto-let)
    (let ((bindings (cljr--get-let-bindings))
          (body-end (save-excursion (clojure--goto-let) (forward-sexp) (point-marker))))
      (dolist (binding (reverse bindings))
        (save-excursion
          (goto-char (cljr--let-body-start))
          (cljr--inline-let-binding (car binding) (car (last binding)) body-end)))
      (cljr--eliminate-let))))

;; ------ Destructuring ----

;;;###autoload
(defun cljr-destructure-keys ()
  "Change a symbol binding at point to a destructuring bind.
Keys to use in the destructuring are inferred from the code, and
their usage is replaced with the new local variables.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-destructure-keys"
  (interactive)
  (save-excursion
    (paredit-backward-up)
    (unless (looking-at "\\[")
      (user-error "Place point on the symbol to destructure inside the [let form]")))
  (let* ((symbol (cider-symbol-at-point))
         (re (concat "(:\\(\\sw\\|\\s_\\)+ " (regexp-quote symbol) ")"))
         (bound (save-excursion
                  (paredit-backward-up 2)
                  (paredit-forward)
                  (point)))
         symbols include-as)
    (save-excursion ;; collect all symbols
      (paredit-forward)
      (while (re-search-forward re bound t)
        (paredit-backward)
        (paredit-forward-down)
        (paredit-raise-sexp)
        (delete-char 1)
        (setq symbols (cons (cider-symbol-at-point) symbols))))
    (save-excursion ;; find new bound
      (paredit-backward-up 2)
      (paredit-forward)
      (setq bound (point)))
    (save-excursion ;; are there any more usages of symbol?
      (paredit-forward-up)
      (when (re-search-forward (regexp-opt (list symbol) 'symbols) bound t)
        (setq include-as t)))
    (when (looking-back "\\s_\\|\\sw" 3)
      (paredit-backward))
    (kill-sexp)
    (insert "{:keys [" (string-join (seq-uniq (reverse symbols)) " ") "]"
            (if include-as (concat " :as " symbol) "") "}")))

;; ------ Cycling ----------

;;;###autoload
(defun cljr-raise-sexp (&optional argument)
  "Like paredit-raise-sexp, but removes # in front of function literals and sets."
  (interactive "P")
  (paredit-raise-sexp argument)
  (when (looking-back " #" 2)
    (delete-char -1)))

;;;###autoload
(defun cljr-splice-sexp-killing-backward (&optional argument)
  "Like paredit-splice-sexp-killing-backward, but removes # in front of function literals and sets."
  (interactive "P")
  (paredit-splice-sexp-killing-backward argument)
  (when (looking-back " #" 2)
    (delete-char -1)))

;;;###autoload
(defun cljr-splice-sexp-killing-forward (&optional argument)
  "Like paredit-splice-sexp-killing-backward,
but removes # in front of function literals and sets."
  (interactive "P")
  (save-excursion
    (paredit-backward-up)
    (when (looking-back " #" 2)
      (delete-char -1)))
  (paredit-splice-sexp-killing-forward argument))

;; ------ magic requires -------

(defun cljr--beginning-of-reader-conditional ()
  "Return position of beginning of containing reader conditional.

Otherwise `nil' if outside of reader conditional."
  (save-excursion
    (let ((reader-start nil))
      (while (not (or reader-start (cljr--top-level-p)))
        (backward-up-list)
        (when (looking-back (regexp-opt (list "#\?@" "#\?")) (- (point) 3))
          (setq reader-start (1+ (point)))))
      reader-start)))

(defun cljr--reader-conditional-context ()
  "Returns keyword name of closest language context containing point.

Otherwise `nil' if outside conditional or unable to find a
context. Valid outputs include, but are not limited to `:clj',
`:cljs', `:cljr', `:bb', or `:default' as strings."
  ;; it shouldn't fail, but we can leave it like this until considered fully time-proven.
  (condition-case nil
      (save-excursion
        (let ((starting-point (point))
              (language nil))
          (when-let* ((reader-start (cljr--beginning-of-reader-conditional)))
            (goto-char reader-start)
            (while (and (<= (point) starting-point) (not language))
              (if-let* ((current (cider-symbol-at-point)))
                  ;; attempt to move forward a language/context pair. Accept if
                  ;; starting point was before next language pair, or if last pair,
                  ;; or end of file.
                  (when (or (< starting-point
                               (condition-case nil
                                   (progn (cider-start-of-next-sexp 2)
                                          (point)) ; start of next context
                                 (error (1+ starting-point))))
                            (= (point) (point-max)))
                    (setq language current))
                ;; otherwise move out of bounds of search to exit without language
                (goto-char (1+ starting-point))))
            language)))
    (error nil)))

(defvar cljr--suggest-libspecs-cache (make-hash-table :test #'equal)
  "Cache of `cljr-suggest-libspecs' results used by `cljr-slash'.
Maps a (alias-ref buffer-context point-context) key to a
\(timestamp . candidates) cons.  `cljr-slash' fires on every `/'
keystroke, so caching keeps the common case (typing the same alias, e.g.
`str/', repeatedly) from doing a middleware round-trip each time.  The
entries expire per `cljr-artifact-cache-ttl'.")

(defun cljr--call-middleware-suggest-libspec (alias-ref language-context)
  "Suggest namespace require libspecs for an alias.

Returns a candidate list of libspec entry strings. An alias
\"set\" might return (\"[clojure.set :as set]\").

`alias-ref' is a string representing a namespace alias entered by
the user.

`language-context' is a 2 element tuple representing the language
context of the buffer, and the context of the reader conditional
where the alias is being used. Assume same context as
buffer if context at current point is nil. See
`cljr--language-context-at-point' for details on this tuple.

Passes through the custom `cljr-magic-require-namespaces' so that
users can specify default recommended alias prefixes that may not
appear in the project yet.

Results are cached per alias and language context (see
`cljr--suggest-libspecs-cache' and `cljr-artifact-cache-ttl'), since
`cljr-slash' calls this on every `/' keystroke."
  (let* ((buffer-context (car language-context))
         (point-context (cadr language-context))
         (key (list alias-ref buffer-context point-context))
         (cached (gethash key cljr--suggest-libspecs-cache)))
    (if (cljr--cache-fresh-p cached)
        (cdr cached)
      (let ((candidates
             (thread-first "cljr-suggest-libspecs"
                           cljr--ensure-op-supported
                           (cljr--create-msg "lib-prefix" alias-ref
                                             "buffer-language-context" buffer-context
                                             "input-language-context" (or point-context buffer-context)
                                             "preferred-aliases" (let ((print-length nil) ;; prevent large lists from being serialized with `...`, which would cause issues
                                                                       (print-level nil))
                                                                   (prin1-to-string cljr-magic-require-namespaces)))
                           (cljr--call-middleware-sync "suggestions")
                           parseedn-read-str
                           (seq-into 'list))))
        (puthash key (cons (float-time) candidates) cljr--suggest-libspecs-cache)
        candidates))))

(defun cljr--language-context-at-point ()
  "Detects the current language-context at a given point.

Returns a tuple, the first value represents the language context
of the file, the second represents the language context at the
current point if it is within a reader conditional. If a given
value is unknown, it will be expressed as nil.

Reader conditionals are forms like #?(:clj (expr)) or
#?@(:cljs (expr) :default (expr2)) (see
URL`https://clojure.org/guides/reader_conditionals'). As
example, `(\"cljc\", \"cljs\")' represents a point in a cljs path
of a reader conditional inside of a cljc file."
  (let ((cljc? (cljr--cljc-file-p)))
    (list (cond (cljc?
                 "cljc")
                ((cljr--cljs-file-p)
                 "cljs")
                ((cljr--clj-file-p)
                 "clj"))
          (when-let* ((context (when cljc?
                                 (cljr--reader-conditional-context))))
            (string-remove-prefix ":" context)))))

(defun cljr--prompt-or-select-libspec (candidates)
  "Prompts for namespace selection or returns only candidate.

This will auto-select the only candidate if `cljr-magic-requires'
is not set to `:prompt'."
  (cond
   ((or (> (length candidates) 1) (eq :prompt cljr-magic-requires))
    (completing-read "Add require: " candidates nil))
   ((= (length candidates) 1)
    (seq-first candidates))))

(defun cljr--js-alias-p (alias)
  (and (string-equal "js" alias)
       (or (member "cljs" (cljr--language-context-at-point))
           (cljr--cljs-file-p))))

(defun cljr--ns-alias-at-point ()
  "Returns the (alias)/ just prior to the point excluding the trailing slash."
  (buffer-substring-no-properties
   (cljr--point-after
    ;; word or symbol constituent
    '(skip-syntax-backward "w_")
    ;; ignore prefix digits, #', ', `, :, and ::, that are not part of the
    ;; symbol, and can occur in various orderings.
    '(re-search-forward "[0-9`':#]*" nil t))
   (1- (point))))

(defun cljr--in-keyword-sans-alias-p ()
  "Checks if thing at point is keyword without an alias."
  (let ((sym (cider-symbol-at-point)))
    (and (cljr--keywordp sym)
         (not (string-match-p "::.+" (cljr--symbol-prefix sym))))))

(defun cljr--in-map-destructuring? ()
  "True when `point' is inside a destructuring form."
  (ignore-errors
    (save-excursion
      (paredit-backward-up 2)
      (paredit-forward-down)
      (looking-at-p ":keys"))))

(defun cljr--in-ns-above-point-p ()
  (save-excursion
    (cljr--goto-closest-ns)
    (looking-at-p "(\\s-*in-ns")))

(defun cljr--in-reader-literal-p ()
  (save-excursion
    (clojure-backward-logical-sexp 1)
    (looking-at-p "#")))

(defun cljr--in-number-p ()
  (save-excursion
    (backward-sexp 1)
    (looking-at-p "[-+0-9]")))

(defun cljr--unresolved-alias-ref (alias-ref)
  "Return `alias-ref' if the alias is unresolved or nil.

Filters out existing alias in the namespace, or a global alias
 like `js' in cljs."
  (unless (or (cljr--js-alias-p alias-ref)
              (cljr--resolve-alias alias-ref))
    alias-ref))

(defun cljr--insert-require-libspec (libspec)
  "Inserts a require `libspec' in the namespace of the current file."
  (save-excursion
    (cljr--insert-in-ns ":require")
    (insert libspec)
    (ignore-errors (cljr--maybe-eval-ns-form))
    (cljr--indent-defun)
    (cljr--post-command-message "Required %s" libspec)))

(defun cljr--slash-suggest-op-available-p ()
  "Non-nil when the `cljr-suggest-libspecs' middleware op can be used.
When it can't (e.g. no REPL is connected yet), `cljr-slash' falls back to
the static `cljr-magic-require-namespaces' table."
  (cljr--op-supported-p "cljr-suggest-libspecs"))

(defun cljr--magic-require-libspec-from-table (alias-ref)
  "Return a libspec string for ALIAS-REF from `cljr-magic-require-namespaces'.
Return nil when the alias isn't in the table, or when the table entry is
restricted (via `:only') to language contexts that exclude the current
one.  This is the offline fallback used by `cljr-slash' when the
suggest-libspecs middleware isn't available."
  (when-let* ((entry (assoc alias-ref cljr-magic-require-namespaces)))
    (let (ns only)
      (if (consp (cdr entry))
          (setq ns (cadr entry)
                only (plist-get (cddr entry) :only))
        (setq ns (cdr entry)))
      (let ((context (car (cljr--language-context-at-point))))
        (when (or (null only)
                  (equal context "cljc")
                  (member context only))
          (format "[%s :as %s]" ns alias-ref))))))

(defun cljr--slash-suggested-libspec (alias-ref)
  "Return a libspec string to require for ALIAS-REF, or nil.
Use the `cljr-suggest-libspecs' middleware op when it is available, and
otherwise fall back to `cljr-magic-require-namespaces', so that common
aliases still work without a running REPL."
  (if (cljr--slash-suggest-op-available-p)
      (cljr--prompt-or-select-libspec
       (cljr--call-middleware-suggest-libspec alias-ref (cljr--language-context-at-point)))
    (cljr--magic-require-libspec-from-table alias-ref)))

(defun cljr--magic-require-artifact (alias-ref)
  "Return the `:artifact' coordinate configured for ALIAS-REF, or nil.
See `cljr-magic-require-namespaces'."
  (when-let* ((entry (assoc alias-ref cljr-magic-require-namespaces))
              ((consp (cdr entry))))
    (plist-get (cddr entry) :artifact)))

(defun cljr--libspec-ns (libspec)
  "Return the namespace part of LIBSPEC as a string.
E.g. \"[foo.bar :as fb]\" -> \"foo.bar\".  Returns nil if LIBSPEC can't be
parsed."
  (ignore-errors
    (symbol-name (aref (car (read-from-string libspec)) 0))))

(defun cljr--ns-on-classpath-p (ns)
  "Return non-nil when NS resolves to a file on the classpath.
Requires a connected REPL; returns nil when disconnected."
  (and (cider-connected-p)
       (ignore-errors (cider-sync-request:ns-path ns))))

(defun cljr--slash-maybe-add-missing-lib (alias-ref libspec)
  "Offer to add and hotload the library that provides LIBSPEC's namespace.

Only acts when `cljr-slash-add-missing-libs' is non-nil, ALIAS-REF has an
`:artifact' configured in `cljr-magic-require-namespaces', a REPL is
connected, and the namespace isn't already on the classpath.  Adds (with
confirmation) the artifact at its latest version, hotloading it per
`cljr-hotload-dependencies'."
  (when-let* (((and cljr-slash-add-missing-libs (cider-connected-p)))
              (artifact (cljr--magic-require-artifact alias-ref))
              (ns (cljr--libspec-ns libspec))
              ((not (cljr--ns-on-classpath-p ns))))
    (when (y-or-n-p (format "%s isn't on the classpath.  Add and hotload %s? "
                            ns artifact))
      (if-let* ((version (car (cljr--get-versions-from-middleware artifact))))
          (cljr--add-project-dependency artifact version)
        (user-error "Couldn't find any versions of %s" artifact)))))

;;;###autoload
(defun cljr-slash ()
  "Inserts `/' as normal, but also checks for common namespace shorthands to require.
If `cljr-magic-requires' is non-nil, executing this command after one
of the aliases listed in `cljr-magic-require-namespaces', or any alias
used elsewhere in the project, will add the corresponding require statement
to the ns form."
  (interactive)
  (cljr--obsolete-notice 'cljr-slash)
  (insert "/")
  (when-let* ((alias-ref (and cljr-magic-requires
                              (not (cljr--in-map-destructuring?))
                              (not (cljr--in-ns-above-point-p))
                              (not (cljr--in-reader-literal-p))
                              (not (cider-in-comment-p))
                              (not (cider-in-string-p))
                              (not (cljr--in-keyword-sans-alias-p))
                              (not (cljr--in-number-p))
                              (clojure-find-ns)
                              (cljr--unresolved-alias-ref (cljr--ns-alias-at-point)))))
    ;; Use the `cljr-suggest-libspecs' middleware op when it's available,
    ;; otherwise fall back to the static `cljr-magic-require-namespaces'
    ;; table so common aliases still work without a running REPL.
    (when-let* ((libspec (cljr--slash-suggested-libspec alias-ref)))
      ;; only insert a require if a candidate exists and was selected
      (cljr--slash-maybe-add-missing-lib alias-ref libspec)
      (cljr--insert-require-libspec libspec))))

;; ------ project clean --------

(defun cljr--excluded-from-project-clean-p (filename)
  (member (thread-last filename
                       (string-remove-prefix (cljr--project-dir))
                       (string-remove-prefix "/"))
          cljr-project-clean-exceptions))

;;;###autoload
(defun cljr-project-clean ()
  "Run `cljr-project-clean-functions' on every clojure file,
then sorts the project's dependency vectors.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-project-clean"
  (interactive)
  (when (or (not cljr-project-clean-prompt)
            (yes-or-no-p "Cleaning your project might change many of your clj files. Do you want to proceed?"))
    (let* ((*cljr--noninteractive* t)
           (files (seq-filter (lambda (filename)
                                (and (cljr--clojure-filename-p filename)
                                     (not (cljr--excluded-from-project-clean-p filename))))
                              (cljr--project-files)))
           (reporter (make-progress-reporter "Cleaning project..." 0 (max 1 (length files))))
           (i 0))
      (dolist (filename files)
        (cljr--update-file filename
          (ignore-errors (seq-map 'funcall cljr-project-clean-functions)))
        (progress-reporter-update reporter (setq i (1+ i)) filename))
      (progress-reporter-done reporter))
    (if (and (cider-connected-p) (not cljr-warn-on-eval) (cljr--op-supported-p "warm-ast-cache"))
        (cljr--warm-ast-cache))
    (cljr--post-command-message "Project clean done.")))

(defun cljr--extract-dependency-name ()
  (cl-assert (cljr--looking-at-dependency-p))
  (forward-char)
  (prog1
      (buffer-substring-no-properties
       (point)
       (cljr--point-after '(re-search-forward "\\s-") 'backward-char))
    (backward-char)
    (clojure-delete-and-extract-sexp)
    (delete-region (line-beginning-position) (line-end-position))
    (forward-line)
    (join-line)))

(defun cljr--empty-buffer-p (&optional buffer)
  (with-current-buffer (or buffer (current-buffer))
    (save-excursion
      (goto-char (point-min))
      (not (re-search-forward "[^ \t\n]" nil t)))))

(defun cljr--extract-next-dependency-name ()
  (while (not (or (cljr--empty-buffer-p)
                  (cljr--looking-at-dependency-p)))
    (delete-char 1))
  (when (cljr--looking-at-dependency-p)
    (cljr--extract-dependency-name)))

(defun cljr--get-sorted-dependency-names (deps)
  "Strips metadata and comments."
  (with-temp-buffer
    (let ((names (list)))
      (insert (thread-last deps (string-remove-prefix "[") (string-remove-suffix "]")))
      (goto-char (point-min))
      (while (not (cljr--empty-buffer-p))
        (push (cljr--extract-next-dependency-name) names))
      (string-join (seq-sort #'string< names) "\n "))))

(defun cljr--prepare-sort-buffer (sorted-names vectors-and-meta dividing-line)
  (insert sorted-names)
  (goto-char (point-max))
  (open-line 1)
  (forward-line)
  (insert dividing-line)
  (open-line 1)
  (forward-line)
  (insert vectors-and-meta))

(defun cljr--sort-dependency-vectors-with-meta-and-comments (dividing-line)
  ;;; The buffer looks like this:
  ;;; foo/bar
  ;;; <dividing-line>
  ;;; ^:src-dep [foo/bar "0.1.1"]

  ;;; Until we cross the dividing line, take a sorted line, find
  ;;; its equal in the raw content below and move that vector with meta and
  ;;; comments to the end of the buffer
  (goto-char (point-min))
  (while (not (looking-at dividing-line))
    (let ((dep (string-trim (cljr--extract-region (point) (line-end-position))))
          start end vector-and-meta)
      (forward-line)
      (join-line)
      (re-search-forward dividing-line)
      (re-search-forward (concat "\\[" dep "\\s-+\""))
      (paredit-backward-up 2)
      (while (not (looking-back "^\\s-*" (line-beginning-position)))
        (forward-char -1))
      (while (save-excursion (forward-line -1) (cljr--comment-line-p))
        (forward-line -1))
      (setq start (point))
      (re-search-forward (concat "\\[" dep "\\s-+\""))
      (setq end (max (line-end-position)
                     (cljr--point-after
                      '(paredit-forward-up 2) '(move-end-of-line 1))))
      (setq vector-and-meta (buffer-substring-no-properties start end))
      (delete-region start end)
      (forward-line)
      (join-line)
      (goto-char (point-max))
      (open-line 1)
      (forward-line)
      (insert vector-and-meta)
      (goto-char (point-min))))
  (cljr--delete-line))

(defun cljr--sort-dependency-vectors (sorted-names vectors-and-meta)
  (with-temp-buffer
    (let ((dividing-line "<===============================>"))
      (cljr--prepare-sort-buffer sorted-names vectors-and-meta dividing-line)
      (cljr--sort-dependency-vectors-with-meta-and-comments dividing-line)
      (concat "[" (string-trim (buffer-substring-no-properties (point) (point-max))) "]"))))

;;;###autoload
(defun cljr-sort-project-dependencies ()
  "Sorts all dependency vectors in `project.clj'.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-sort-project-dependencies"
  (interactive)
  (let ((project-file (cljr--project-file)))
    (if (cljr--project-with-deps-p project-file)
        (user-error "Dependencies sorting not supported in deps.edn yet")
      (cljr--update-file project-file
        (goto-char (point-min))
        (while (re-search-forward ":dependencies" (point-max) t)
          ;; Boot has quoted vectors, leiningen does not
          (while (not (looking-at-p "\\["))
            (forward-char))
          (thread-first (buffer-substring-no-properties (point)
                                                        (cljr--point-after 'paredit-forward))
                        cljr--get-sorted-dependency-names
                        (cljr--sort-dependency-vectors (thread-last (clojure-delete-and-extract-sexp)
                                                                    (string-remove-prefix "[")
                                                                    (string-remove-suffix "]")))
                        insert))
        (indent-region (point-min) (point-max))
        (save-buffer)))))

(defconst cljr--sync-progress-delay 1
  "Seconds a synchronous middleware request runs before saying so.")

(defun cljr--call-middleware-sync (request &optional key)
  "Call the middleware with REQUEST.

If it's present KEY indicates the key to extract from the response.

Emacs is blocked until the response arrives, so a request that's taking a
while says so in the echo area.  It is abandoned with an error after
`cljr-middleware-timeout' seconds."
  (let* ((nrepl-sync-request-timeout cljr-middleware-timeout)
         (announced nil)
         (timer (run-at-time cljr--sync-progress-delay nil
                             (lambda ()
                               (setq announced t)
                               (message "Waiting for refactor-nrepl (%s)... (C-g to abort)"
                                        (cadr (member "op" request))))))
         (response (unwind-protect
                       (thread-first request cider-nrepl-sync-request cljr--maybe-rethrow-error)
                     (cancel-timer timer)
                     (when announced (message nil)))))
    (if key
        (nrepl-dict-get response key)
      response)))

(defun cljr--call-middleware-async (request &optional callback)
  (cider-nrepl-send-request request callback))

(defun cljr--start-request-timer (what on-timeout)
  "Give up on a middleware request after `cljr-middleware-timeout' seconds.
Call ON-TIMEOUT then, and tell the user that WHAT timed out.  Return the
timer, or nil when the timeout is disabled."
  (when cljr-middleware-timeout
    (run-at-time cljr-middleware-timeout nil
                 (lambda ()
                   (when (funcall on-timeout)
                     (message "clj-refactor: %s timed out after %s seconds (see `cljr-middleware-timeout')"
                              what cljr-middleware-timeout))))))

(defun cljr--stop-spinner (buffer)
  "Stop any mode-line spinner running in BUFFER."
  (when (buffer-live-p buffer)
    (with-current-buffer buffer
      (when (bound-and-true-p spinner-current)
        (spinner-stop)))))

(defun cljr--call-middleware-async-collect (request key callback)
  "Send REQUEST to the middleware asynchronously and keep Emacs responsive.

The response messages are accumulated; once the request is done the merged
response is checked for a middleware error and then CALLBACK is called with
the value of KEY (or the whole response when KEY is nil).  A middleware
error is reported to the user rather than signaled out of the nREPL filter,
and the request is abandoned with a message if it doesn't finish within
`cljr-middleware-timeout'.  A mode-line spinner runs in the calling
buffer meanwhile.  This is the non-blocking counterpart to
`cljr--call-middleware-sync' for commands that just act on a single result."
  (let ((accumulator (nrepl-dict))
        (settled nil)
        (spinner-buffer (current-buffer))
        timer)
    (cider-spinner-start spinner-buffer)
    (setq timer (cljr--start-request-timer
                 (format "the %s request" (cadr (member "op" request)))
                 (lambda ()
                   (unless settled
                     (setq settled t)
                     (cljr--stop-spinner spinner-buffer)
                     t))))
    (cljr--call-middleware-async
     request
     (lambda (response)
       (setq accumulator (nrepl-dict-merge accumulator response))
       (when (and (not settled)
                  (member "done" (nrepl-dict-get response "status")))
         (setq settled t)
         (when (timerp timer) (cancel-timer timer))
         (cljr--stop-spinner spinner-buffer)
         (condition-case err
             (progn
               (cljr--maybe-rethrow-error accumulator)
               (funcall callback (if key
                                     (nrepl-dict-get accumulator key)
                                   accumulator)))
           (error (message "clj-refactor: %s" (error-message-string err)))))))))

(defcustom cljr-artifact-cache-ttl 300
  "Number of seconds to cache middleware lookups whose results change rarely.

This governs two Emacs-side caches:

- The dependency commands (`cljr-add-project-dependency' and friends) fetch
  the list of available artifacts, and the versions of a given artifact.
- `cljr-slash' fetches libspec suggestions for an unresolved alias on every
  `/' keystroke.

Caching these for this many seconds avoids a middleware round-trip on every
invocation.  Set to nil to disable the caches."
  :type '(choice (const :tag "Disable" nil) integer)
  :package-version '(clj-refactor . "4.0.0")
  :safe (lambda (x) (or (null x) (integerp x))))

;; Each cache entry is a cons of (timestamp . value).
(defvar cljr--artifacts-cache nil
  "Cached artifact list, as a cons of (timestamp . artifacts).")

(defvar cljr--versions-cache (make-hash-table :test #'equal)
  "Per-artifact version cache, mapping artifact to (timestamp . versions).")

(defun cljr--cache-fresh-p (entry)
  "Return non-nil if cache ENTRY is present and within `cljr-artifact-cache-ttl'."
  (and cljr-artifact-cache-ttl
       entry
       (< (- (float-time) (car entry)) cljr-artifact-cache-ttl)))

(defun cljr--get-artifacts-from-middleware (force)
  (if (and (not force) (cljr--cache-fresh-p cljr--artifacts-cache))
      (cdr cljr--artifacts-cache)
    (message "Retrieving list of available libraries...")
    (let* ((request (cljr--create-msg "artifact-list" "force" (if force "true" "false")))
           (artifacts (cljr--call-middleware-sync request "artifacts")))
      (if artifacts
          (progn
            (setq cljr--artifacts-cache (cons (float-time) artifacts))
            artifacts)
        (user-error "Empty artifact list received from middleware")))))

(defun cljr--cache-artifacts-from-response (response)
  "Populate `cljr--artifacts-cache' from an async artifact-list RESPONSE.
Does nothing for responses without an \"artifacts\" entry (e.g. the
trailing status message), so the Emacs-side cache is only replaced once
the list actually arrives."
  (when-let* ((artifacts (nrepl-dict-get response "artifacts")))
    (setq cljr--artifacts-cache (cons (float-time) artifacts))
    (when cljr--debug-mode
      (message "Artifact cache updated"))))

(defun cljr--update-artifact-cache ()
  (cljr--call-middleware-async (cljr--create-msg "artifact-list"
                                                 "force" "true")
                               #'cljr--cache-artifacts-from-response))

(defun cljr--init-artifact-cache ()
  (cljr--call-middleware-async (cljr--create-msg "artifact-list"
                                                 "force" "false")
                               #'cljr--cache-artifacts-from-response))

(defun cljr--dictionary-lessp (str1 str2)
  "Return t if STR1 is < STR2 when doing a dictionary compare,
(splitting the string at numbers and doing numeric compare with them).
It is optimized for version comparisons, in that empty strings are sorted
before non-empty. This lets 1.7.0 be sorted above 1.7.0-RC1."
  (let ((str1-components (cljr--dict-split (downcase str1)))
        (str2-components (cljr--dict-split (downcase str2))))
    (cljr--dict-lessp str1-components str2-components)))

(defun cljr--dict-lessp (slist1 slist2)
  "Compare the two lists of strings and numbers."
  (cond ((null slist1)
         (not (null slist2)))
        ((null slist2)
         t)
        ((and (numberp (car slist1))
              (stringp (car slist2)))
         t)
        ((and (numberp (car slist2))
              (stringp (car slist1)))
         nil)
        ((and (numberp (car slist1))
              (numberp (car slist2)))
         (or (< (car slist1) (car slist2))
             (and (= (car slist1) (car slist2))
                  (cljr--dict-lessp (cdr slist1) (cdr slist2)))))
        (t
         (or (string-lessp (car slist1) (car slist2))
             (and (string-equal (car slist1) (car slist2))
                  (cljr--dict-lessp (cdr slist1) (cdr slist2)))))))

(defun cljr--dict-split (str)
  "split a string into a list of number and non-number components"
  (save-match-data
    (let ((res nil))
      (while (and str (not (string-equal "" str)))
        (let ((p (string-match "[0-9]+" str)))
          (cond ((null p)
                 (setq res (cons str res))
                 (setq str nil))
                ((= p 0)
                 (setq res (cons (string-to-number (match-string 0 str)) res))
                 (setq str (substring str (match-end 0))))
                (t
                 (setq res (cons (substring str 0 (match-beginning 0)) res))
                 (setq str (substring str (match-beginning 0)))))))
      (reverse res))))

(defun cljr--get-versions-from-middleware (artifact)
  (let ((cached (gethash artifact cljr--versions-cache)))
    (if (cljr--cache-fresh-p cached)
        (cdr cached)
      (let* ((request (cljr--create-msg "artifact-versions" "artifact" artifact))
             (versions (nreverse (sort (cljr--call-middleware-sync request "versions") 'cljr--dictionary-lessp))))
        (if versions
            (progn
              (puthash artifact (cons (float-time) versions) cljr--versions-cache)
              versions)
          (error "Empty version list received from middleware"))))))

(defun cljr--prompt-user-for (prompt &optional choices)
  "Prompt the user with PROMPT.

If CHOICES is provided provide a completed read among the
possible choices. If the choice is trivial, return it."
  (if choices
      (if (= (length choices) 1)
          (cl-first choices)
        (completing-read prompt choices nil nil nil nil (car choices)))
    (read-from-minibuffer prompt)))

(defun cljr--insert-into-leiningen-dependencies (artifact version)
  (unless (re-search-forward ":dependencies" nil :no-error)
    (user-error "Couldn't find a `:dependencies' vector in the project file"))
  (paredit-forward)
  (paredit-backward-down)
  (newline-and-indent)
  (insert "[" artifact " \"" version "\"]"))

(defun cljr--insert-into-clj-dependencies (artifact version)
  (unless (re-search-forward ":deps" nil :no-error)
    (user-error "Couldn't find a `:deps' map in the project file"))
  (forward-sexp)
  (backward-char)
  (newline-and-indent)
  (let ((artifact (if (string-match-p "^.+/.+$" artifact)
                      artifact
                    (format "%s/%s" artifact artifact))))
    (insert artifact " {:mvn/version \"" version "\"}")))


(defun cljr--add-project-dependency (artifact version)
  (let* ((project-file (cljr--project-file))
         (deps (cljr--project-with-deps-p project-file)))
    (cljr--update-file project-file
      (goto-char (point-min))
      (if deps
          (cljr--insert-into-clj-dependencies artifact version)
        (cljr--insert-into-leiningen-dependencies artifact version))
      (cljr--post-command-message "Added %s version %s as a project dependency" artifact version)
      (when cljr-hotload-dependencies
        (if deps
            (back-to-indentation)
          (paredit-backward-down))
        (cljr-hotload-dependency)))))

;;;###autoload
(defun cljr-add-project-dependency (force)
  "Add a dependency to the project's `deps.edn' or `project.clj'.

With a prefix arg FORCE, refresh the cached artifact list first.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-add-project-dependency"
  (interactive "P")
  (cljr--ensure-op-supported "artifact-list")
  (when-let* ((lib-name (thread-last (cljr--get-artifacts-from-middleware force)
                                     (cljr--prompt-user-for "Artifact: ")))
              (version (thread-last (cljr--get-versions-from-middleware lib-name)
                                    (cljr--prompt-user-for "Version: "))))
    (cljr--add-project-dependency lib-name version)))

;;;###autoload
(defun cljr-update-project-dependency (&optional version)
  "Update the version of the dependency at point."
  (interactive)
  (unless version
    (cljr--ensure-op-supported "artifact-list"))
  (unless (cljr--looking-at-dependency-p)
    (user-error "Place cursor in front of dependency to update"))
  (save-excursion
    (let (lib-name
          (lein-style (cljr--vector-at-point-p)))
      (if lein-style
          (paredit-forward-down))
      (setq lib-name (cljr--extract-sexp))
      (paredit-forward)
      (skip-syntax-forward " ")
      (let ((artifact-version (or version
                                  (thread-last (cljr--get-versions-from-middleware lib-name)
                                               (cljr--prompt-user-for (concat lib-name " version: "))))))
        (cljr--delete-sexp)
        (if lein-style
            (insert "\"" artifact-version "\"")
          (insert "\{:mvn/version \"" artifact-version "\"\}")))))
  (when cljr-hotload-dependencies
    (cljr-hotload-dependency)))

;;;###autoload
(defun cljr-update-project-dependencies ()
  "Update all project dependencies.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-update-project-dependencies"
  (interactive)
  (cljr--ensure-op-supported "artifact-list")
  (let ((project-file (cljr--project-file)))
    (find-file project-file)
    (goto-char (point-min))
    (let (cljr-hotload-dependencies)
      (if (cljr--project-with-deps-p project-file)
          (cljr--update-dependencies ":deps" "}" 2)
        (cljr--update-dependencies ":dependencies" "]" 1)))))

(defun cljr--update-dependencies (keyword dependency-closing-brace forward-count)
  (while (re-search-forward keyword (point-max) t)
    (paredit-forward-down)
    (cljr--skip-past-whitespace-and-comments)
    (while (not (looking-at dependency-closing-brace))
      (let ((highlight (cljr--highlight-sexp)))
        (unwind-protect
            (cljr-update-project-dependency)
          (delete-overlay highlight)))
      (paredit-forward forward-count)
      (cljr--skip-past-whitespace-and-comments))))

(defun cljr--skip-past-whitespace-and-comments ()
  (skip-syntax-forward " >")
  (while (looking-at ";")
    (move-end-of-line 1)
    (forward-char)
    (skip-syntax-forward " >")))

(defun cljr--extract-anon-fn-name (sexp-str)
  (when (string-match "(fn \\(\\_<[^ ]+\\_>\\)?" sexp-str)
    (match-string-no-properties 1 sexp-str)))

(defun cljr--highlight (start end)
  (let ((overlay (make-overlay start end)))
    (overlay-put overlay 'face 'secondary-selection)
    (overlay-put overlay 'priority 100)
    overlay))

(defun cljr--highlight-sexp ()
  (cljr--highlight (point) (cljr--point-after 'paredit-forward)))

(defun cljr--string-present-p (s)
  (not (or (null s) (string-empty-p s))))

(defun cljr--promote-fn ()
  (save-excursion
    (let* ((locals (save-excursion (paredit-forward-down)
                                   (cljr--call-middleware-to-find-used-locals
                                    (buffer-file-name) (line-number-at-pos)
                                    (1+ (current-column)))))
           (fn (cljr--extract-sexp))
           (namedp (cljr--extract-anon-fn-name fn))
           (name (or namedp
                     (let ((highlight (cljr--highlight-sexp)))
                       (unwind-protect
                           (read-string "Name: ")
                         (delete-overlay highlight)))))
           fn-start)
      (cljr--delete-sexp)
      (save-excursion
        (cljr--new-toplevel-form fn)
        (paredit-backward-down)
        (cljr--goto-fn-definition)
        (setq fn-start (point))
        (forward-char)
        (insert "de")
        (paredit-forward)
        (when cljr-favor-private-functions
          (if clojure-use-metadata-for-privacy
              (insert " ^:private")
            (insert "-")))
        (when (not namedp)
          (insert " ")
          (newline)
          (backward-char)
          (insert name))
        (re-search-forward "\\[")
        (when (cljr--string-present-p locals)
          (insert locals)
          (unless (looking-at-p "\\]")
            (insert " ")))
        (paredit-forward-up)
        (unless (looking-at "\s*?$")
          (newline))
        (indent-region fn-start (cljr--point-after 'paredit-forward-up)))
      (when (cljr--string-present-p locals)
        (insert (format "(partial  %s)" locals))
        (backward-char (length (concat " " locals ")"))))
      (insert name))))

(defun cljr--promote-to-defn ()
  "Promote the `fn' at point to a top-level `defn'.
Uses the `find-used-locals' middleware op to build the argument list, so
it requires a connected REPL."
  (cljr--ensure-op-supported "find-used-locals")
  (when (cljr--asts-y-or-n-p)
    (cljr--promote-fn)))

;;;###autoload
(defun cljr-promote-function (promote-to-defn)
  "Promote a function literal to an fn, or an fn to a defn.
With prefix PROMOTE-TO-DEFN, promote to a defn even if it is a
function literal.

Promoting a `#(...)' literal to `(fn ...)' is a local edit (it delegates
to `clojure-promote-fn-literal') and needs no REPL.  Promoting an `fn' to
a top-level `defn' uses the `find-used-locals' middleware op to build the
argument list, so it requires a connected REPL.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-promote-function"
  (interactive "P")
  (save-excursion
    (cond
     ;; Already in the right place.
     ((or (looking-at-p "#(")
          (looking-at-p "(fn")))
     ;; Right after the #.
     ((and (eq (char-after) ?\()
           (eq (char-before) ?#))
      (forward-char -1))
     ;; Possibly inside a function.
     (t (cljr--goto-fn-definition)))
    ;; Now promote it.
    (if (looking-at "#(")
        (let ((start (point)))
          (clojure-promote-fn-literal)
          (when promote-to-defn
            ;; The fn is where the literal was, wherever point ended up.
            (goto-char start)
            (cljr--promote-to-defn)))
      (cljr--promote-to-defn))))

(defun cljr--insert-in-find-symbol-buffer (occurrence)
  (save-excursion
    (pop-to-buffer cljr--find-symbol-buffer)
    (goto-char (point-max))
    (insert occurrence)))

(defun cljr--find-symbol (symbol ns callback)
  (let* ((filename (funcall cider-to-nrepl-filename-function (buffer-file-name)))
         (line (line-number-at-pos))
         (column (1+ (current-column)))
         (dir (funcall cider-to-nrepl-filename-function (cljr--project-dir)))
         (find-symbol-request
          (cljr--create-msg "find-symbol"
                            "ns" ns
                            "dir" dir
                            "file" filename
                            "line" line
                            "column" column
                            "name" symbol
                            "ignore-paths" cljr-middleware-ignored-paths
                            "ignore-errors"
                            (if cljr-ignore-analyzer-errors "true" "false"))))
    (with-current-buffer (cider-current-repl)
      (setq cljr--occurrence-count 0)
      (setq cljr--num-syms -1)
      (setq cljr--occurrence-ids '()))
    (cljr--call-middleware-async find-symbol-request callback)))

(defun cljr--skipped-files (response)
  "Return the files the search that ended with RESPONSE had to skip.
With `cljr-ignore-analyzer-errors' the middleware carries on past files it
can't analyze, and lists them in its final message.  Each one is a hash
table with a :file and an :error."
  (when-let* ((skipped (nrepl-dict-get response "skipped")))
    (append (parseedn-read-str skipped) nil)))

(defun cljr--skipped-files-summary (skipped)
  "Describe the SKIPPED files, as returned by `cljr--skipped-files'."
  (format "%d file%s couldn't be analyzed and %s skipped: %s"
          (length skipped)
          (if (= (length skipped) 1) "" "s")
          (if (= (length skipped) 1) "was" "were")
          (mapconcat (lambda (file)
                       (cljr--project-relative-path (cljr--get-valid-filename file)))
                     skipped ", ")))

(defun cljr--find-symbol-occurrences (symbol ns callback)
  "Asynchronously find occurrences of SYMBOL in NS, keeping Emacs responsive.

The middleware streams one occurrence per message and a final `count'.
Collect the occurrences (dropping any duplicate location) and, once the
search finishes, call CALLBACK with the full list.  CALLBACK is run in the
command loop rather than the nREPL process filter, so it may prompt or pop
up buffers safely.  A middleware error is reported to the user, and the
search is abandoned with a message if `count' never arrives within
`cljr-middleware-timeout'.  The user is told about any files the search
had to skip, as their occurrences are missing from the list.  This is the collecting counterpart to
`cljr--find-symbol', which streams occurrences to a per-message callback."
  (let ((occurrences '())
        (seen '())
        (settled nil)
        (spinner-buffer (current-buffer))
        timer)
    (cider-spinner-start spinner-buffer)
    (setq timer (cljr--start-request-timer
                 "finding occurrences"
                 (lambda ()
                   (unless settled
                     (setq settled t)
                     (cljr--stop-spinner spinner-buffer)
                     t))))
    (cljr--find-symbol
     symbol ns
     (lambda (response)
       (unless settled
         (condition-case err
             (progn
               (cljr--maybe-rethrow-error response)
               ;; `count' is the middleware's terminal message; fall back to the
               ;; nREPL `done' status in case it ever finishes without one.
               (if (or (nrepl-dict-get response "count")
                       (member "done" (nrepl-dict-get response "status")))
                   (let ((result (nreverse occurrences))
                         (skipped (when-let* ((files (cljr--skipped-files response)))
                                    (cljr--skipped-files-summary files))))
                     (setq settled t)
                     (when (timerp timer) (cancel-timer timer))
                     (cljr--stop-spinner spinner-buffer)
                     (run-at-time 0 nil
                                  (lambda ()
                                    ;; Queued first, it's shown last, after
                                    ;; whatever the callback has to say.
                                    (when skipped
                                      (cljr--post-command-message
                                       "%s" skipped))
                                    (funcall callback result))))
                 (when-let* ((data (nrepl-dict-get response "occurrence")))
                   (let* ((occurrence (parseedn-read-str data))
                          (id (format "%s:%s:%s"
                                      (cljr--get-valid-filename occurrence)
                                      (gethash :line-beg occurrence)
                                      (gethash :col-beg occurrence))))
                     (unless (member id seen)
                       (push id seen)
                       (push occurrence occurrences))))))
           (error
            (setq settled t)
            (when (timerp timer) (cancel-timer timer))
            (cljr--stop-spinner spinner-buffer)
            (message "clj-refactor: %s" (error-message-string err)))))))))

(defun cljr--first-line (s)
  (thread-first s (split-string "\\(\r\n\\|[\n\r]\\)") car string-trim))

(defun cljr--project-relative-path (path)
  "Denormalize PATH to make it relative to the project root."
  (string-remove-prefix (cljr--project-dir) path))

(defun cljr--get-valid-filename (hash)
  "Get :file value from the hash table and convert path if necessary.

Translate it back to TRAMP notation if needed."
  (let ((file (funcall cider-from-nrepl-filename-function (gethash :file hash)))
        (current (funcall cider-from-nrepl-filename-function (buffer-file-name))))
    (if (tramp-tramp-file-p current)
        (concat (cider-tramp-prefix) file)
      file)))

(defun cljr--format-symbol-occurrence (occurrence)
  (let ((file (cljr--get-valid-filename occurrence))
        (line (gethash :line-beg occurrence))
        (col (1- (gethash :col-beg occurrence)))
        (match (gethash :match occurrence)))
    (format "%s:%s:%s: %s\n" (cljr--project-relative-path file) line col
            (cljr--first-line match))))

(defun cljr--format-and-insert-symbol-occurrence (occurrence-resp)
  "Insert the occurrence in OCCURRENCE-RESP into the find usages buffer.
Return the total number of occurrences once the search is finished, and
nil until then."
  ;; The middleware sends either an occurrence or a final count, never
  ;; both in the same message.
  (cljr--maybe-rethrow-error occurrence-resp)
  (if-let* ((count (nrepl-dict-get occurrence-resp "count")))
      (progn
        (setq cljr--num-syms count)
        (when (= cljr--occurrence-count cljr--num-syms)
          (cljr--finalise-find-symbol-buffer
           cljr--num-syms (cljr--skipped-files occurrence-resp)))
        count)
    (when-let* ((occurrence-data (nrepl-dict-get occurrence-resp "occurrence")))
      (let* ((occurrence (parseedn-read-str occurrence-data))
             (occurrence-id (format "%s%s"
                                    (cljr--get-valid-filename occurrence)
                                    (gethash :line-beg occurrence))))
        (cl-incf cljr--occurrence-count)
        (unless (member occurrence-id cljr--occurrence-ids)
          (setq cljr--occurrence-ids
                (cons occurrence-id cljr--occurrence-ids))
          (thread-last occurrence
                       cljr--format-symbol-occurrence
                       cljr--insert-in-find-symbol-buffer)))
      nil)))

(defun cljr--find-usages-handler (name spinner-buffer)
  "Return the response handler for a find usages search for NAME.
It stops the spinner in SPINNER-BUFFER once the search is over.  A
middleware error is reported with `message' rather than signaled, as the
handler runs in the nREPL process filter.  The search is abandoned with
a message if it doesn't finish within `cljr-middleware-timeout'."
  (let* ((settled nil)
         (timer nil)
         (settle (lambda ()
                   (setq settled t)
                   (when (timerp timer) (cancel-timer timer))
                   (cljr--stop-spinner spinner-buffer))))
    (setq timer (cljr--start-request-timer
                 "finding usages"
                 (lambda ()
                   (unless settled
                     (funcall settle)
                     t))))
    (lambda (response)
      (unless settled
        (condition-case err
            (when-let* ((total (cljr--format-and-insert-symbol-occurrence response)))
              (funcall settle)
              ;; The results buffer only pops up with the first occurrence.
              (when (zerop total)
                (if-let* ((skipped (cljr--skipped-files response)))
                    (message "No occurrences of %s found, but %s"
                             name (cljr--skipped-files-summary skipped))
                  (message "No occurrences of %s found" name))))
          (error
           (funcall settle)
           (message "clj-refactor: %s" (error-message-string err))))))))

(defun cljr--finalise-find-symbol-buffer (total &optional skipped)
  "Add the footer to the find usages buffer, once all TOTAL occurrences are in.
SKIPPED are the files the search couldn't analyze, as returned by
`cljr--skipped-files'."
  (with-current-buffer "*cljr-find-usages*"
    (goto-char (point-max))
    (insert (format "\nFind symbol finished: %d occurrence%s found"
                    total (if (= total 1) "" "s")))
    (when skipped
      (insert (format "\n\n%d file%s couldn't be analyzed, so any occurrences there are missing:\n"
                      (length skipped) (if (= (length skipped) 1) "" "s")))
      (dolist (file skipped)
        (insert (format "  %s (%s)\n"
                        (cljr--project-relative-path (cljr--get-valid-filename file))
                        (cljr--first-line (gethash :error file))))))
    ;; Place point on first occurrence
    (goto-char (point-min))
    (forward-line 2)))

(defun cljr--setup-find-symbol-buffer (symbol-name)
  (save-window-excursion
    (when (get-buffer cljr--find-symbol-buffer)
      (kill-buffer cljr--find-symbol-buffer))
    (pop-to-buffer cljr--find-symbol-buffer)
    (with-current-buffer "*cljr-find-usages*"
      (insert (format "'%s' occurs in the following places:\n\n" symbol-name))
      (grep-mode)
      (set (make-local-variable 'compilation-error-regexp-alist)
           (list 'compilation-cljr-nogroup))
      (set (make-local-variable 'compilation-error-regexp-alist-alist)
           (list (cons 'compilation-cljr-nogroup (list cljr--file-column-pattern 1 2 3))))
      (setq buffer-read-only nil)
      (setq-local compilation-search-path (list (cljr--project-dir))))))

(defun cljr--asts-y-or-n-p ()
  (or
   (not cljr-warn-on-eval)
   (y-or-n-p "To perform this op the project needs to be evaluated.\n  Analyzing a large project might take a while: hit C-g to abort.\n  (Set cljr-warn-on-eval to nil to analyze the project without warning)\n  Do you want to proceed?")))

;;;###autoload
(defun cljr-find-usages ()
  "Find all usages of the symbol at point in the project.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-find-usages"
  (interactive)
  (cljr--ensure-op-supported "find-symbol")
  (unless (cider-symbol-at-point)
    (user-error "No symbol at point"))
  (when (cljr--asts-y-or-n-p)
    (save-buffer)
    (let* ((cljr--find-symbol-buffer "*cljr-find-usages*")
           (symbol (cider-symbol-at-point))
           (var-info (cljr--var-info symbol))
           (ns (nrepl-dict-get var-info "ns"))
           (name (or (nrepl-dict-get var-info "name") symbol)))
      (cljr--setup-find-symbol-buffer name)
      (cider-spinner-start (current-buffer))
      (cljr--find-symbol name ns
                         (cljr--find-usages-handler name (current-buffer))))))

(defun cljr--rename-occurrence (file line-beg col-beg line-end col-end name new-name)
  (save-excursion
    (with-current-buffer
        (cljr--find-file-noselect file)
      (let* ((name (thread-last name cljr--symbol-suffix regexp-quote))
             (search-limit (save-excursion
                             (progn
                               (goto-char (point-min))
                               (forward-line (1- line-end))
                               (move-to-column (1- col-end))
                               (point)))))
        (goto-char (point-min))
        (forward-line (1- line-beg))
        (move-to-column (1- col-beg))
        ;; When the match is a definition, the position of the symbol
        ;; isn't returned but the beginning of the defining form
        (when (looking-at-p "(\\s-*def")
          (re-search-forward name)
          (paredit-backward))
        (when (re-search-forward (format "\\(.+/\\)?\\(%s\\)" name) search-limit t)
          (replace-match (format "\\1%s" new-name) t)))
      (cljr--save-buffer))))

(defun cljr--rename-occurrences (occurrences new-name)
  (cljr--run-previewable-refactoring
   (format "Rename %d occurrence(s)" (length occurrences))
   (lambda ()
     (dolist (symbol-meta occurrences)
       (let* ((file (cljr--get-valid-filename symbol-meta))
              (line-beg (gethash :line-beg symbol-meta))
              (col-beg (gethash :col-beg symbol-meta))
              (line-end (gethash :line-end symbol-meta))
              (col-end (gethash :col-end symbol-meta))
              (name (gethash :name symbol-meta))
              (new-name* (if (stringp new-name)
                             new-name
                           (funcall new-name name))))
         (cljr--rename-occurrence file line-beg col-beg line-end col-end name new-name*))))))

;;;###autoload
(defun cljr-rename-symbol (&optional new-name)
  "Rename the symbol at point and all of its occurrences.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-rename-symbol"
  (interactive)
  (when (buffer-narrowed-p)
    (error "Cannot rename symbols while narrowing is in effect"))
  (cljr--ensure-op-supported "find-symbol")
  (unless (cider-symbol-at-point)
    (user-error "No symbol at point"))
  (when (cljr--asts-y-or-n-p)
    (save-buffer)
    (let* ((symbol (cider-symbol-at-point))
           (var-info (cljr--var-info symbol))
           (symbol-name (nrepl-dict-get var-info "name"))
           (ns (nrepl-dict-get var-info "ns"))
           (name (or symbol-name symbol))
           (new-name (or new-name (read-from-minibuffer "New name: "
                                                        (cljr--symbol-suffix symbol)))))
      (when (string-blank-p new-name)
        (user-error "The new name can't be empty"))
      (when (string= new-name (cljr--symbol-suffix symbol))
        (user-error "The new name is the same as the old one"))
      ;; Finding every occurrence analyses the whole project, which can be
      ;; slow, so do it asynchronously and rename in the callback rather than
      ;; freezing Emacs on a synchronous round-trip.
      (unless *cljr--noninteractive*
        (message "Finding occurrences of %s... (%s to interrupt)" name
                 (substitute-command-keys "\\[cider-interrupt]")))
      (cljr--find-symbol-occurrences
       name ns
       (lambda (occurrences)
         (cond
          ((null occurrences)
           (message "No occurrences of %s found" name))
          ((cljr--rename-occurrences occurrences new-name)
           (cljr--post-command-message "Renamed %s occurrences of %s" (length occurrences) name)
           (unless cljr-warn-on-eval
             (cljr--warm-ast-cache)))))))))

(defun cljr--replace-refer-all-with-alias (ns publics-occurrences alias)
  (let ((ns-last-token (car (last (split-string ns "\\.")))))
    (when (re-search-forward (format "\\(%s\\).*?\\([\]\)]\\)" ns-last-token) nil t)
      (replace-match (format "\\1 :as %s\\2" alias)))
    (perform-replace (format "%s/" alias) "" nil nil t)
    (cljr--rename-occurrences publics-occurrences (lambda (old-name) (concat alias "/" old-name)))))

(defun cljr--replace-refer-all (ns alias)
  "Replaces :refer :all style require with alias :as style require.

Also adds the alias prefix to all occurrences of public symbols
in the namespace."
  (cljr--ensure-op-supported "find-used-publics")
  (let ((filename (funcall cider-to-nrepl-filename-function (buffer-file-name))))
    (let* ((alias (or alias
                      (cljr--prompt-user-for (format "alias for [%s]: " ns))))
           (request
            (cljr--create-msg "find-used-publics"
                              "used-ns" ns
                              "file" filename))
           (occurrences (thread-last (cljr--call-middleware-sync request "used-publics")
                                     (parseedn-read-str))))
      (cljr--replace-refer-all-with-alias ns occurrences alias))))

(defun cljr--maybe-nses-in-bad-state (response)
  (let ((asts-in-bad-state (seq-filter
                            (lambda (it)
                              (not (stringp (car (last it)))))
                            (thread-first (nrepl-dict-get response "ast-statuses")
                                          parseedn-read-str
                                          (seq-partition 2)))))
    (when (not (= 0 (length asts-in-bad-state)))
      (user-error (concat "Some namespaces are in a bad state: "
                          (string-join
                           (seq-map
                            (lambda (it)
                              (format "error \"%s\" in %s" (car (last (car (last it)))) (car it)))
                            asts-in-bad-state) "; "))))))

(defun cljr--warm-ast-cache ()
  (run-hooks 'cljr-before-warming-ast-cache-hook)
  (cljr--call-middleware-async
   (cljr--create-msg "warm-ast-cache"
                     "ignore-paths" cljr-middleware-ignored-paths)
   (lambda (res)
     (run-hook-with-args 'cljr-after-warming-ast-cache-hook res)
     (cljr--maybe-rethrow-error res)
     (cljr--maybe-nses-in-bad-state res)
     (when cljr--debug-mode
       (message "AST index updated")))))

(defun cljr--replace-ns (new-ns)
  (save-excursion
    (cljr--goto-ns)
    (let ((begin (point)))
      (forward-sexp)
      (let ((old-ns (buffer-substring begin (point))))
        (when (not (string-equal old-ns (string-trim-right new-ns)))
          (delete-region begin (point))
          (insert new-ns)
          (cljr--just-one-blank-line))))))

(defun cljr--clean-ns (&optional path no-prune?)
  "If PATH is passed use, that instead of the path to the current buffer.

If NO-PRUNE is passed, the default is overridden and unused stuff isn't \
removed."
  ;; Don't save prematurely when called from `cljr-project-clean'
  (unless (and *cljr--noninteractive*
               (not (buffer-modified-p)))
    (save-buffer))
  (let* ((path (funcall cider-to-nrepl-filename-function (or path (buffer-file-name))))
         (relative-path (cljr--project-relative-path path)))
    (when-let* ((new-ns (cljr--call-middleware-sync
                         (cljr--create-msg "clean-ns"
                                           "path" path
                                           "relative-path" relative-path
                                           "always-return-ns-form" "true"
                                           "libspec-whitelist" cljr-libspec-whitelist
                                           "print-right-margin" cljr-print-right-margin
                                           "print-miser-width" cljr-print-miser-width
                                           "prune-ns-form" (if no-prune? "false"
                                                             "true"))
                         "ns")))
      (cljr--replace-ns new-ns))
    (unless *cljr--noninteractive*
      (cljr--post-command-message "Namespace form cleaned!"))))

(defun cljr--clean-or-sort-ns ()
  "Clean the ns form with the middleware, or sort it without."
  (if (cljr--op-supported-p "clean-ns")
      (progn
        (cider-eval-ns-form)
        (cljr--clean-ns))
    (cljr--sort-ns)
    (cljr--post-command-message
     "Sorted the ns form (pruning unused libspecs needs the refactor-nrepl middleware).")))

;;;###autoload
(defun cljr-clean-ns ()
  "Clean the ns form for the current buffer.

With the refactor-nrepl middleware available, unused libspecs are
pruned and the ns form is sorted and reformatted.  Without a REPL, fall
back to sorting the ns form with `clojure-sort-ns' - pruning needs
analysis, so it is skipped.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-clean-ns"
  (interactive)
  (cljr--obsolete-notice 'cljr-clean-ns)
  (cljr--clean-or-sort-ns))

(defun cljr--uses-completion-framework-p ()
  "Whether the user is using something richer than the stock `completing-read'."
  (or (not (eq completing-read-function #'completing-read-default))
      (member 'ido-completing-read+ package-activated-list)))

(defun cljr--narrow-candidates (candidates symbol)
  (cond
   ((= (length candidates) 0)
    (error "Couldn't find any symbols matching `%s' on classpath" (cljr--symbol-suffix symbol)))

   ((seq-every-p (lambda (m)
                   (gethash :already-interned m))
                 candidates)
    (error "`%s' is already interned into the current namespace" (cljr--symbol-suffix symbol)))

   (t (let* ((candidates (seq-remove (lambda (m)
                                       (gethash :already-interned m))
                                     candidates))
             (tag (if (seq-every-p (lambda (m)
                                     (eq :class (gethash :type m)))
                                   candidates)
                      "Import"
                    "Require"))
             (prompt-text (if (cljr--uses-completion-framework-p)
                              (format "%s: " tag )
                            (format "%s (hit your 'complete' keybinding for options): " tag)))
             (names (seq-map (lambda (c)
                               (propertize (symbol-name (gethash :name c)) 'face 'font-lock-type-face))
                             candidates))
             (name (intern-soft (cljr--prompt-user-for prompt-text names))))
        (seq-find (lambda (c)
                    (equal name (gethash :name c)))
                  candidates)))))

(defun cljr--insert-libspec-verbosely (libspec)
  (insert (format "%s" libspec))
  (cljr--indent-defun)
  (cljr--post-command-message "%s added to ns" libspec))

(defun cljr--insert-missing-import (missing)
  (save-excursion
    (cljr--insert-in-ns ":import")
    (cljr--insert-libspec-verbosely missing)))

(defun cljr--qualified-symbol-p (symbol)
  (thread-last symbol
               (format "%s")
               regexp-quote
               (string-match-p "/")
               null
               not))

(defun cljr--symbol-prefix (symbol)
  "Extracts the prefix from a symbol.

java.util.Date => java.util
str/split => str
split => ''"
  (cond ((cljr--qualified-symbol-p symbol) (car (split-string symbol "/")))
        ((string-match-p "\\w+\\.\\w+" symbol)
         (string-join (butlast (split-string symbol "\\.")) "."))
        (t "")))

(defun cljr--insert-missing-require (symbol missing-symbol type)
  "Require MISSING-SYMBOL.

Inspect SYMBOL, the thing at point, to find out whether we have
to create an alias or refer."
  (save-excursion
    (cljr--insert-in-ns ":require")
    (let ((missing (format "%s" missing-symbol))
          (alias? (cljr--qualified-symbol-p symbol)))
      (cond
       ;;  defrecord / deftype where the package must be required
       ((eq type :type)
        (cljr--insert-libspec-verbosely (cljr--symbol-prefix missing)))
       ;; Fully qualified symbol
       ((and (cljr--qualified-symbol-p symbol)
             (string= (cljr--symbol-prefix symbol) missing))
        (cljr--insert-libspec-verbosely missing))
       (alias?
        (cljr--insert-libspec-verbosely (format "[%s :as %s]" missing
                                                (cljr--symbol-prefix symbol))))
       (t (cljr--insert-libspec-verbosely (format "[%s :refer [%s]]"
                                                  missing symbol)))))))

(defun cljr--add-missing-libspec (symbol candidates)
  (let* ((candidate (cljr--narrow-candidates candidates symbol))
         (missing-symbol (gethash :name candidate))
         (type (gethash :type candidate)))
    (cond ((eq type :ns) (cljr--insert-missing-require symbol missing-symbol type))
          ((eq type :type)
           ;; We need to both require the ns, to trigger compilation,
           ;; and then import the java class

           ;; In the line below we're assuming that all clojure code
           ;; will prefer - over _ when naming namespaces :(
           (progn (cljr--insert-missing-require
                   symbol
                   (replace-regexp-in-string "_" "-" (format "%s" missing-symbol)) type)
                  (cljr--insert-missing-import missing-symbol)))
          ((eq type :class) (cljr--insert-missing-import missing-symbol))
          (t (error (format "Unknown type %s" type))))))

(defun cljr--symbol-suffix (symbol)
  "Extracts the suffix from a symbol.

java.util.Date => Date
Date => Date
clojure.string/split => split
str/split => split"
  (let ((name (cljr--normalize-symbol-name symbol)))
    (cond
     ((string-match-p "\\w+\\.\\w+" name)
      (thread-first name (split-string "\\.") last car cljr--symbol-suffix))
     ((cljr--qualified-symbol-p name)
      (thread-first name (split-string "/") cadr cljr--symbol-suffix))
     (t name))))

(defun cljr--normalize-symbol-name (name)
  "Removes reader macros and quoting.

Date. -> Date
@sym => sym
#\\='sym => sym
\\='sym => sym
~sym => sym
~@sym => sym"
  (cond
   ((string-suffix-p "." name)
    (thread-last name (string-remove-suffix ".") cljr--normalize-symbol-name))
   ((string-prefix-p "#'" name)
    (thread-last name (string-remove-prefix "#'") cljr--normalize-symbol-name))
   ((string-prefix-p "'" name)
    (thread-last name (string-remove-prefix "'") cljr--normalize-symbol-name))
   ((string-prefix-p "~" name)
    (thread-last name (string-remove-prefix "~") cljr--normalize-symbol-name))
   ((string-prefix-p "~@" name)
    (thread-last name (string-remove-prefix "~@") cljr--normalize-symbol-name))
   ((string-prefix-p "@" name)
    (thread-last name (string-remove-prefix "@") cljr--normalize-symbol-name))
   (t name)))

(defun cljr--call-middleware-to-resolve-missing (symbol &optional ns)
  ;; Just so this part can be mocked out in a step definition
  (let ((request (cljr--create-msg "resolve-missing"
                                   "symbol" symbol
                                   "session"
                                   (cider-nrepl-eval-session))))
    (when ns
      (setq request (append request (list "ns" ns))))
    (when-let* ((candidates (thread-first request
                                          (cljr--call-middleware-sync "candidates"))))
      (parseedn-read-str candidates))))

(defun cljr--get-error-value (response)
  "Gets the error value from the middleware response.

We can't simply call `nrepl-dict-get' because the error value
itself might be `nil'."
  (cl-assert (nrepl-dict-p response) nil
             "Response from middleware isn't an nrepl-dict!")
  (if-let* ((err (nrepl-dict-get response "err")))
      (error (format "Error in nrepl-refactor: %s" err))
    (let* ((maybe-error-and-rest
            (seq-drop-while (lambda (e)
                              (not (and (stringp e) (string-equal e "error"))))
                            response))
           (maybe-error (car maybe-error-and-rest)))
      (when (and (stringp maybe-error) (string-equal maybe-error "error"))
        (or (cadr maybe-error-and-rest)
            (format "Error 'nil' returned from middleware. %s"
                    "Please contact your local administrator."))))))

(defun cljr--format-escape (msg)
  "Make the message consumable by format."
  (replace-regexp-in-string "%" "%%" msg))

(defun cljr--maybe-rethrow-error (response)
  "Signal an error if the middleware's RESPONSE is one, else return it.
A request that was interrupted (e.g. with `cider-interrupt') counts as
one: whatever came back before that is incomplete."
  (when (member "interrupted" (nrepl-dict-get response "status"))
    (user-error "Interrupted"))
  (if-let* ((err (cljr--get-error-value response)))
      (error (cljr--format-escape err))
    response))

(defun cljr--maybe-eval-ns-form ()
  (when (and cljr-auto-eval-ns-form (cider-connected-p))
    (cider-eval-ns-form)))

(defun cljr--add-missing-libspec-from-alias (symbol)
  "Add a require for the alias of SYMBOL from `cljr-magic-require-namespaces'.

Handles the `alias/name' case the same way `cljr-slash' does: it works
without a REPL (via the static table) and, when `cljr-slash-add-missing-libs'
is set and the alias has an `:artifact', can offer to add and hotload the
library.  Returns non-nil when it added a require."
  (when-let* ((alias (and symbol
                          (string-search "/" symbol)
                          (car (split-string symbol "/"))))
              (alias-ref (and (clojure-find-ns)
                              (cljr--unresolved-alias-ref alias)))
              (libspec (cljr--slash-suggested-libspec alias-ref)))
    (cljr--slash-maybe-add-missing-lib alias-ref libspec)
    (cljr--insert-require-libspec libspec)
    t))

;;;###autoload
(defun cljr-add-missing-libspec ()
  "Requires or imports the symbol at point.

If the symbol at point is of the form str/join then the ns
containing join will be aliased to str.

Uses refactor-nrepl's `resolve-missing' op when it is available.  When it
isn't (e.g. no REPL is connected) or it finds nothing, falls back to
resolving an `alias/name' symbol via `cljr-magic-require-namespaces', so
common aliases still work offline and a missing library can be added (see
`cljr-slash-add-missing-libs').

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-add-missing-libspec"
  (interactive)
  (cljr--obsolete-notice 'cljr-add-missing-libspec)
  (let ((symbol (cider-symbol-at-point)))
    (if (cljr--op-supported-p "resolve-missing")
        (let ((candidates (cljr--call-middleware-to-resolve-missing symbol (cider-current-ns))))
          (cond
           ((and candidates (< 0 (length candidates)))
            (cljr--add-missing-libspec symbol candidates)
            (cljr--maybe-clean-ns)
            (cljr--maybe-eval-ns-form))
           ((cljr--add-missing-libspec-from-alias symbol))
           (t (cljr--post-command-message "Can't find `%s' on classpath"
                                          (cljr--symbol-suffix symbol)))))
      (or (cljr--add-missing-libspec-from-alias symbol)
          (user-error "Can't resolve `%s': the refactor-nrepl `resolve-missing' \
op isn't available and the alias isn't in `cljr-magic-require-namespaces'"
                      symbol)))))

(defun cljr--dependency-at-point ()
  "Returns project dependency at point.

Recognizes both leiningen- and deps.edn-style dependencies,
but the latter is always transformed back to Leiningen dependency vector
which is what nrepl backend expects for hot-loading."
  (save-excursion
    (ignore-errors
      (while (not (cljr--looking-at-dependency-p))
        (paredit-backward-up))

      (if (cljr--vector-at-point-p)
          (buffer-substring-no-properties (point)
                                          (cljr--point-after 'paredit-forward))
        (concat "["
                (match-string-no-properties 1)
                " "
                (match-string-no-properties 4)
                "]")))))

(defun cljr--hotload-dependency-callback (response)
  (cljr--maybe-rethrow-error response)
  (cljr--post-command-message "Hotloaded %s" (nrepl-dict-get response "dependency")))

(defun cljr--assert-dependency-vector (string)
  (with-temp-buffer
    (insert string)
    (goto-char (point-min))
    (cl-assert (cljr--looking-at-dependency-p) nil
               (format
                (concat "Expected dependency vector of type "
                        "[org.clojure \"1.7.0\"] or "
                        "org.clojure {:mvn/version \"1.7.0\"}, but got '%s'")
                string)))
  string)

;;;###autoload
(defun cljr-hotload-dependency ()
  "Download a dependency (if needed) and hotload it into the current repl session.

Defaults to the dependency vector at point, but prompts if none is found.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-hotload-dependency"
  (interactive)
  (cljr--ensure-op-supported "hotload-dependency")
  (let ((dependency-vector (or (cljr--dependency-at-point)
                               (cljr--prompt-user-for "Dependency vector: "))))
    (cljr--assert-dependency-vector dependency-vector)
    ;; Hotloading may have to download the dependency first.
    (cljr--call-middleware-async-collect
     (cljr--create-msg "hotload-dependency" "coordinates" dependency-vector)
     nil
     #'cljr--hotload-dependency-callback)))

(defun cljr--defn-str (&optional public)
  (if public
      "(defn "
    (concat "(defn"
            (if cljr-favor-private-functions
                (if clojure-use-metadata-for-privacy
                    " ^:private "
                  "- ")
              " "))))

(defun cljr--call-middleware-to-find-used-locals (file line column)
  (let ((file (funcall cider-to-nrepl-filename-function file)))
    (string-join
     (cljr--call-middleware-sync
      (cljr--create-msg "find-used-locals" "file" file "line" line
                        "column" column)
      "used-locals") " ")))

(defun cljr--goto-enclosing-sexp ()
  (let ((sexp-regexp (rx (or "(" "#{" "{" "["))))
    (unless (looking-at sexp-regexp)
      (paredit-backward-up))
    (when (looking-back "#" 1)
      (forward-char -1))))

;;;###autoload
(defun cljr-extract-function ()
  "Extract the form at (or above) point as a top-level defn.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-extract-function"
  (interactive)
  (cljr--ensure-op-supported "find-used-locals")
  (when (cljr--asts-y-or-n-p)
    (save-buffer)
    (cljr--goto-enclosing-sexp)
    (let* ((unbound (cljr--call-middleware-to-find-used-locals
                     (buffer-file-name) (line-number-at-pos)
                     ;; +1 because the middleware expects indexing from 1
                     ;; +1 more because point has to be inside the sexp,
                     ;; not on the opening paren
                     (+ (current-column) 2)))
           (name (let ((highlight (cljr--highlight-sexp)))
                   (unwind-protect
                       (cljr--prompt-user-for "Name: ")
                     (delete-overlay highlight))))
           (body (clojure-delete-and-extract-sexp)))
      (save-excursion
        (cljr--make-room-for-toplevel-form)
        (insert (cljr--defn-str))
        (insert name)
        (newline)
        (indent-according-to-mode)
        (insert "[" unbound "]")
        (newline-and-indent)
        (insert body ")"))
      (insert "(")
      (insert name)
      (save-excursion
        (unless (string-blank-p unbound)
          (insert " " unbound))
        (insert ")")))))

(defun cljr--at-end-of-symbol-at-point ()
  (looking-back (regexp-quote (cider-symbol-at-point)) (line-beginning-position)))

(defun cljr--insert-function-stubs (functions)
  (unless (cljr--at-end-of-symbol-at-point)
    (paredit-forward))
  (save-excursion
    (dolist (fn functions)
      (newline-and-indent)
      (insert "(" (gethash :name fn) " " (gethash :parameter-list fn) ")")))
  (when (> (length functions) 0)
    ;; Move cursor to point where the first functino body goes
    (paredit-forward-down)
    (paredit-forward 2)))

;;;###autoload
(defun cljr-add-stubs ()
  "Adds implementation stubs for the interface or protocol at point.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-add-stubs"
  (interactive)
  (cljr--ensure-op-supported "stubs-for-interface")
  (let* ((interface (cider-symbol-at-point))
         (prefix? (cljr--symbol-prefix interface))
         (alias? (cljr--resolve-alias prefix?))
         (interface (if (not (string-blank-p prefix?))
                        (if alias?
                            (format "%s/%s" alias? (cljr--symbol-suffix interface))
                          interface)
                      (format "%s/%s" (cider-current-ns) interface)))
         (functions (parseedn-read-str (cljr--call-middleware-sync
                                        (cljr--create-msg "stubs-for-interface"
                                                          "interface" interface)
                                        "functions"))))
    (cljr--insert-function-stubs functions)))

(defun cljr--delete-definition (definition)
  "Delete a definition as part of inlining a symbol."
  (let ((file (cljr--get-valid-filename definition))
        (line-beg (gethash :line-beg definition))
        (col-beg (gethash :col-beg definition)))
    (with-current-buffer (cljr--find-file-noselect file)
      (goto-char (point-min))
      (forward-line (1- line-beg))
      (forward-char (1- col-beg))
      (clojure-delete-and-extract-sexp)
      (when (clojure--inside-let-binding-p)
        (clojure-delete-and-extract-sexp)
        (if (save-excursion (cljr--get-let-bindings))
            (progn
              (while (looking-at-p "\s*\n")
                (forward-line)
                (join-line))
              (when (looking-at-p "]")
                ;; we just deleted the last binding in the vector
                (join-line)))
          (cljr--eliminate-let))
        (cljr--indent-defun))
      (cond
       ;; Nothing for a blank line to separate at the top of the file.
       ((bobp) (skip-chars-forward " \t\n")
        (delete-region (point-min) (point)))
       ((looking-at-p "\s*\n")
        (cljr--just-one-blank-line)))
      (cljr--save-buffer))))

(defun cljr--sort-occurrences (occurrences)
  "Sort the OCCURRENCES so the last ones in the file comes first."
  (seq-sort (lambda (o1 o2)
              (let ((o1-line (gethash :line-beg o1))
                    (o2-line (gethash :line-beg o2))
                    (o1-col (gethash :col-beg o1))
                    (o2-col (gethash :col-beg o2)))
                (cond
                 ((< o1-line o2-line) o2)
                 ((> o1-line o2-line) o1)
                 ((< o1-col o2-col ) o2)
                 ((> o1-col o2-col) o1)
                 (t (error "Sort occurrences failed to compare %s %s %s %s"
                           o1-line o2-line o1-col o2-col)))))
            occurrences))

(defun cljr--inline-fn-at-call-site (def call-site)
  "Point is at a call site, where the sexp call-site has just been extracted."
  (let ((args (cl-rest call-site))
        (params (with-temp-buffer
                  (insert def)
                  (goto-char (point-min))
                  (paredit-forward-down 2)
                  (cljr--extract-sexp-as-list)))
        (def (with-temp-buffer
               (insert def)
               (goto-char (point-min))
               (paredit-forward-down 2)
               (paredit-forward-up)
               (paredit-splice-sexp-killing-backward)
               (buffer-string))))
    (dotimes (i (length args))
      (setq def (replace-regexp-in-string (format "\\_<%s\\_>" (nth i params))
                                          (nth i args) def t t)))
    (insert def)))

(defun cljr--inline-symbol (definition occurrences)
  (cljr--run-previewable-refactoring
   "Inline symbol"
   (lambda ()
     (let* ((def (gethash :definition definition))
            (inline-fn-p (string-prefix-p "(fn" def)))
       (dolist (symbol-meta (cljr--sort-occurrences occurrences))
         (let* ((file (cljr--get-valid-filename symbol-meta))
                (line-beg (gethash :line-beg symbol-meta))
                (col-beg (gethash :col-beg symbol-meta)))
           (with-current-buffer (cljr--find-file-noselect file)
             (goto-char (point-min))
             (forward-line (1- line-beg))
             (forward-char (1- col-beg))
             (let* ((call-site-p (and inline-fn-p
                                      (looking-back "(\s*" (line-beginning-position))))
                    (sexp (if call-site-p
                              (prog1 (cljr--extract-sexp-as-list)
                                (paredit-backward-up)
                                (clojure-delete-and-extract-sexp))
                            (clojure-delete-and-extract-sexp))))
               (if call-site-p
                   (cljr--inline-fn-at-call-site def sexp)
                 (insert def))))))
       (cljr--save-buffer)
       (cljr--delete-definition definition)))))

(defun cljr--var-info (&optional symbol all)
  "Like `cider-var-info' but also handles locally bound vars.

If SYMBOL is passed we assume it's a global var and look it up.

If SYMBOL is nil the symbol at point is used and we consider
locals in that context.

If the symbol is bound locally nil will be returned.

ALL has the same meaning as for `cider-var-info'"
  (if symbol
      (cider-var-info symbol all)
    (let ((used-locals (split-string (cljr--call-middleware-to-find-used-locals
                                      (expand-file-name (buffer-file-name))
                                      (line-number-at-pos) (1+ (current-column))) " "))
          (symbol (cider-symbol-at-point)))
      (unless (member symbol used-locals)
        (cider-var-info symbol all)))))

;;;###autoload
(defun cljr-inline-symbol ()
  "Inline the symbol at point.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-inline-symbol"
  (interactive)
  (cljr--ensure-op-supported "extract-definition")
  (when (cljr--asts-y-or-n-p)
    (save-buffer)
    (save-excursion
      (let* ((filename (funcall cider-to-nrepl-filename-function (buffer-file-name)))
             (line (line-number-at-pos))
             (column (1+ (current-column)))
             (dir (cljr--project-dir))
             (symbol (cider-symbol-at-point))
             (var-info (cljr--var-info))
             (ns (or (nrepl-dict-get var-info "ns") (cider-current-ns)))
             (symbol-name (or (nrepl-dict-get var-info "name") symbol))
             (extract-definition-request (list
                                          "op" (cljr--resolve-op "extract-definition")
                                          "ns" ns
                                          "dir" dir
                                          "file" filename
                                          "line" line
                                          "column" column
                                          "name" symbol-name
                                          "ignore-errors"
                                          (if cljr-ignore-analyzer-errors "true" "false")))
             (response (parseedn-read-str (cljr--call-middleware-sync
                                           extract-definition-request "definition")))
             (definition (gethash :definition response))
             (occurrences (gethash :occurrences response)))
        (when (and (cljr--inline-symbol definition occurrences)
                   (not *cljr--noninteractive*))
          (if occurrences
              (cljr--post-command-message "Inlined %s occurrence(s) of '%s'" (length occurrences) symbol)
            (cljr--post-command-message "No occurrences of '%s' found.  Deleted the definition." symbol)))))
    (cljr--indent-defun)))

(defconst cljr-version "4.2.0"
  "The current version of clj-refactor.")

(defun cljr--pkg-version ()
  "Extract the package version from its package metadata."
  (package-get-version))

(defun cljr--version ()
  "Retrieve the version."
  (if (string-match-p "-snapshot" cljr-version)
      (let ((pkg-version (cljr--pkg-version)))
        (if pkg-version
            ;; snapshot versions include the MELPA package version
            (format "%s (package: %s)" cljr-version pkg-version)
          cljr-version))
    cljr-version))

;; We used to derive the version out of `(cljr--version)`,
;; but now prefer a fixed version to fully decouple things and prevent unforeseen behavior.
;; This suits better our current pace of development.
(defcustom cljr-injected-middleware-version "3.16.0"
  "The refactor-nrepl version to be injected.

You can customize this in order to try out new releases.

If customizing it, you most likely should
`(setq cljr-suppress-middleware-warnings nil)' too,
for avoiding a warning that would be irrelevant for this case."
  :type 'string
  :safe #'stringp
  :package-version "3.0.0")

(defun cljr--middleware-version ()
  "Return the version of the connected refactor-nrepl, or nil.
A failed probe returns nil (with the error reported as a message)
instead of signaling: CIDER 2.0's senders reject unsupported ops
client-side, and this probe runs from `cider-connected-hook' where an
error would abort the rest of the startup checks - including the
out-of-sync warning itself."
  (condition-case err
      (cljr--call-middleware-sync (cljr--create-msg "version") "version")
    (error (message "clj-refactor: middleware version probe failed: %s"
                    (error-message-string err))
           nil)))

(defun cljr--check-middleware-version ()
  "Check whether clj-refactor and nrepl-refactor versions are the same."
  (if (cljr--inside-project-p)
      (let ((refactor-nrepl-version (or (cljr--middleware-version)
                                        "n/a")))
        (unless (string-equal (downcase refactor-nrepl-version)
                              (downcase cljr-injected-middleware-version))
          (cider-repl-emit-interactive-stderr
           (format "WARNING: clj-refactor and refactor-nrepl are out of sync.
Their versions are %s and %s, respectively.
You can mute this warning by changing cljr-suppress-middleware-warnings."
                   (cljr--version) refactor-nrepl-version))))
    (unless cljr-suppress-no-project-warning
      (cider-repl-emit-interactive-stderr
       "WARNING: No Clojure project was detected. The
refactor-nrepl middleware was not enabled. (You can mute this
warning by customizing `cljr-suppress-no-project-warning'.)"))))

;;;###autoload
(defun cljr-version ()
  "Returns the version of the middleware as well as this package."
  (interactive)
  (message "clj-refactor %s, refactor-nrepl %s"
           (cljr--version)
           (or (cljr--middleware-version)
               "is unreachable")))

;;;###autoload
(defun cljr-toggle-debug-mode ()
  (interactive)
  (setq cljr--debug-mode (not cljr--debug-mode))
  (if cljr--debug-mode
      (message "Debug mode on")
    (message "Debug mode off")))

(defun cljr--check-clojure-version ()
  (if-let* ((clojure-version (cider--clojure-version)))
      (when (version< clojure-version cljr-minimum-clojure-version)
        (cider-repl-emit-interactive-stderr
         (format "WARNING: Clojure version (%s) is not supported (minimum %s). The refactor-nrepl middleware won't work and has been disabled!"
                 clojure-version cljr-minimum-clojure-version)))
    (cider-repl-emit-interactive-stderr
     (format "WARNING: Can't determine Clojure version.  The refactor-nrepl middleware requires clojure %s (or newer)" cljr-minimum-clojure-version))))

(defun cljr--init-middleware ()
  (unless cljr-suppress-middleware-warnings
    (cljr--check-clojure-version)
    (cljr--check-middleware-version))
  ;; Best effort; don't freak people out with errors
  (ignore-errors
    (when (cljr--middleware-version) ; check if middleware is running
      (when cljr-populate-artifact-cache-on-startup
        (cljr--init-artifact-cache))
      (when (and (not cljr-warn-on-eval)
                 cljr-eagerly-build-asts-on-startup)
        (cljr--warm-ast-cache)))))

(defvar cljr--list-fold-function-names
  '("map" "mapv" "pmap" "keep" "mapcat" "filter" "remove" "take-while" "drop-while"
    "group-by" "partition-by" "some" "every?" "not-every?" "not-any?"))

(defvar cljr--list-fold-function-names-with-index
  '("map-indexed" "keep-indexed"))

(defun cljr--chop-prefix (prefix s)
  "Remove PREFIX if it is at the start of S."
  (declare (pure t) (side-effect-free t))
  (let ((pos (length prefix)))
    (if (and (>= (length s) (length prefix))
             (string= prefix (substring s 0 pos)))
        (substring s pos)
      s)))

(defun cljr--ns-path (ns-name)
  "Find the file path to the ns named NS-NAME."
  (cider-ensure-session)
  ;; No explicit op-support check: `cider-sync-request:ns-path' sends the
  ;; namespaced `cider/ns-path' op, whose support modern CIDER enforces in the
  ;; nREPL sender automatically.
  (cljr--chop-prefix "file:"
                     (cider-sync-request:ns-path ns-name)))

;;;###autoload
(defun cljr-create-fn-from-example ()
  "Create a top-level defn for the symbol at point.
The context in which symbol is being used should be that of a
function, and the arglist of the defn is guessed from this
context.

For instance, if the symbol is the first argument of a `map'
call, the defn is created with one argument. If it is the first
argument of a `reduce', the defn will take two arguments.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-create-fn-from-example"
  (interactive)
  (while (cljr--keywordp (car (cljr--extract-sexp-as-list)))
    (paredit-backward-up))
  (let* ((sexp-forms* (cljr--extract-sexp-as-list))
         (fn-name (car sexp-forms*))
         (symbol-at-point (or (cider-symbol-at-point) ""))
         (parent-fn (ignore-errors
                      (save-excursion
                        (paredit-backward-up 2)
                        (forward-char)
                        (cljr--extract-sexp))))
         (args (cl-rest (cond
                         ((or (string= parent-fn "->")
                              (string= parent-fn "->>"))
                          (save-excursion
                            (paredit-backward-up)
                            (cljr--unwind-and-extract-this-as-list fn-name)))

                         ((or (string= fn-name "->")
                              (string= fn-name "->>"))
                          (save-excursion
                            (setq fn-name symbol-at-point)
                            (cljr--unwind-and-extract-this-as-list fn-name)))

                         (:else sexp-forms*))))
         (prefix (cljr--symbol-prefix symbol-at-point))
         (path (when (cljr--string-present-p prefix)
                 (cljr--ns-path (cljr--resolve-alias prefix)))))
    (push-mark)
    (if (cljr--symbolp symbol-at-point)
        (cond ((string= fn-name "update")
               (cljr--create-fn-from-update args path))

              ((string= fn-name "update-in")
               (cljr--create-fn-from-update-in path))

              ((string= fn-name "sort-by")
               (cljr--create-fn-from-sort-by args path))

              ((string= fn-name "sort")
               (cljr--create-fn-from-sort args path))

              ((string= fn-name "reduce")
               (cljr--create-fn-from-reduce args path))

              ((string= fn-name "repeatedly")
               (cljr--insert-example-fn symbol-at-point nil path))

              ((member fn-name cljr--list-fold-function-names)
               (cljr--create-fn-from-list-fold args path))

              ((member fn-name cljr--list-fold-function-names-with-index)
               (cljr--create-fn-from-list-fold-with-index args path))

              ((and (featurep 'cider) (cider-connected-p)
                    (cljr--var-info fn-name :all))
               (cljr--insert-example-fn symbol-at-point (list "args") path))

              (:else
               (cljr--insert-example-fn fn-name args path)))
      (cljr--insert-example-fn fn-name args path))))

(defun cljr--singularize-string (word)
  "Return a naive English singular form of WORD.
Covers the common cases good enough for guessing parameter names in
`cljr-create-fn-from-example'; it is not a full inflection engine."
  (cond
   ((string-match-p "[^aeiou]ies\\'" word)
    (concat (substring word 0 -3) "y"))
   ((string-match-p "\\(?:ss\\|sh\\|ch\\|x\\|z\\)es\\'" word)
    (substring word 0 -2))
   ((and (string-suffix-p "s" word)
         (not (string-suffix-p "ss" word)))
    (substring word 0 -1))
   (t word)))

(defun cljr--pluralize-string (word)
  "Return a naive English plural form of WORD.
See `cljr--singularize-string' for the caveats."
  (cond
   ((string-match-p "[^aeiou]y\\'" word)
    (concat (substring word 0 -1) "ies"))
   ((string-match-p "\\(?:s\\|sh\\|ch\\|x\\|z\\)\\'" word)
    (concat word "es"))
   (t (concat word "s"))))

(defun cljr--inflect-last-word (f s)
  (when s
    (save-match-data
      (let* ((words (split-string s "-"))
             (last-word (car (last words)))
             (prefix (butlast words)))
        (mapconcat 'identity
                   (append prefix (list (funcall f last-word)))
                   "-")))))

(defun cljr--create-fn-from-list-fold (args path)
  (cljr--insert-example-fn (car args)
                           (seq-map
                            (lambda (it)
                              (when-let* ((name (cljr--guess-param-name it)))
                                (cljr--inflect-last-word 'cljr--singularize-string name)))
                            (cdr args))
                           path))

(defun cljr--create-fn-from-list-fold-with-index (args path)
  (cljr--insert-example-fn (car args)
                           (cons "index"
                                 (seq-map
                                  (lambda (it)
                                    (when-let* ((name (cljr--guess-param-name it)))
                                      (cljr--inflect-last-word 'cljr--singularize-string name)))
                                  (cdr args)))
                           path))

(defun cljr--create-fn-from-update (args path)
  (let ((keyfn (cadr args)))
    (cljr--insert-example-fn (cider-symbol-at-point)
                             (if (cljr--keywordp keyfn)
                                 (list (string-remove-prefix ":" keyfn))
                               (list 0))
                             path)))

(defun cljr--create-fn-from-update-in (path)
  (let ((last-path-entry (save-excursion
                           (paredit-backward-down)
                           (cider-symbol-at-point))))
    (cljr--insert-example-fn (cider-symbol-at-point)
                             (if (cljr--keywordp last-path-entry)
                                 (list (string-remove-prefix ":" last-path-entry))
                               (list 0))
                             path)))

(defun cljr--create-fn-from-sort (args path)
  (let* ((fn-name (cider-symbol-at-point))
         (param-name (when-let* ((coll-name (cljr--guess-param-name (car (last args)))))
                       (cljr--inflect-last-word 'cljr--singularize-string coll-name))))
    (cljr--insert-example-fn fn-name
                             (if param-name
                                 (list (concat param-name "-a")
                                       (concat param-name "-b"))
                               (list "a" "b"))
                             path)))

(defun cljr--create-fn-from-sort-by (args path)
  (let* ((fn-name (cider-symbol-at-point))
         (making-comparator? (and (string= fn-name (cadr args))
                                  (= 3 (length args))))
         (param-name (if making-comparator?
                         (when (cljr--keywordp (car args))
                           (string-remove-prefix ":" (car args)))
                       (when-let* ((coll-name (cljr--guess-param-name (car (last args)))))
                         (cljr--inflect-last-word 'cljr--singularize-string coll-name)))))
    (cljr--insert-example-fn fn-name
                             (if making-comparator?
                                 (if param-name
                                     (list (concat param-name "-a")
                                           (concat param-name "-b"))
                                   (list "a" "b"))
                               (list param-name))
                             path)))

(defun cljr--create-fn-from-reduce (args path)
  (cljr--insert-example-fn
   (car args)
   (list (or (and (= 3 (length args))
                  (cljr--guess-param-name (nth 1 args)))
             "acc")
         (when-let* ((name (cljr--guess-param-name (car (last args)))))
           (cljr--inflect-last-word 'cljr--singularize-string name)))
   path))

(defun cljr--unwind-and-extract-this-as-list (name)
  (let* ((parent-sexp (progn
                        (paredit-backward-up)
                        (cljr--extract-sexp)))
         (unwound (cljr--unwind-s parent-sexp)))
    (cljr--with-string-content unwound
      (search-forward (concat "(" name))
      (cljr--extract-sexp-as-list))))

(defun cljr--unwind-s (s)
  (if (string-prefix-p "(->" s)
      (cljr--with-string-content s
        (clojure-unwind-all)
        (buffer-substring (point-min) (point-max)))
    s))

(defun cljr--keywordp (s)
  (string-match-p "^::?[^0-9:[{(\"][^[{(\"]*$"
                  (replace-regexp-in-string "\n" " " s)))

(defun cljr--symbolp (s)
  "True when S is a symbol."
  (string-match-p "^[^0-9:[{(\"][^[{(\"]*$"
                  (replace-regexp-in-string "\n" " " s)))

(defun cljr--keyword-lookup-p (s)
  (string-match "^(:\\([^ 0-9:[{(\"][^[{(\"]+\\) " s))

(defun cljr--first-fn-call-s (s)
  (cljr--with-string-content s
    (when (looking-at "(")
      (paredit-forward-down)
      (cljr--extract-sexp))))

(defun cljr--first-arg-s (s)
  (cljr--with-string-content s
    (paredit-forward-down)
    (paredit-forward)
    (cljr--skip-past-whitespace-and-comments)
    (cljr--extract-sexp)))

(defun cljr--last-arg-s (s)
  (cljr--with-string-content s
    (paredit-forward)
    (paredit-backward-down)
    (paredit-backward)
    (cljr--extract-sexp)))

(defvar cljr--fns-that-get-item-out-of-coll
  (list "first" "second" "last" "fnext" "nth" "rand-nth"))

(defun cljr--strip-keyword-ns (s)
  (when (string-match "[^/]+$" s)
    (substring s (car (match-data)) (car (cdr (match-data))))))

(defun cljr--dashed-words (s)
  "Take the string S and replace all the word separators with '-',
and make the whole string lower-cased."
  (with-temp-buffer
    (insert s)
    (goto-char (point-min))
    (while (not (eobp))
      (subword-forward)
      (insert " "))
    (mapconcat 'identity (split-string (downcase (buffer-string))) "-")))

(defun cljr--guess-param-name (form)
  (let* ((prepped-form (cljr--strip-off-semantic-noops
                        (cljr--unwind-s form)))
         (fn-call (cljr--first-fn-call-s prepped-form)))
    (cond
     ((cljr--symbolp prepped-form)
      prepped-form)
     ((cljr--keyword-lookup-p prepped-form)
      (cljr--strip-keyword-ns (match-string 1 prepped-form)))
     ((and fn-call (string-suffix-p "." fn-call))
      (cljr--dashed-words (car (last (split-string fn-call "\\." t)))))
     ((and fn-call (string-prefix-p "create-" fn-call))
      (string-remove-prefix "create-" fn-call))
     ((and fn-call (string-prefix-p ".get" fn-call))
      (cljr--dashed-words (string-remove-prefix ".get" fn-call)))
     ((string= "get-in" fn-call)
      (cljr--find-param-name-from-get-in prepped-form))
     ((string= "get" fn-call)
      (cljr--find-param-name-from-get prepped-form))
     ((string= "repeat" fn-call)
      (cljr--pluralize-string
       (cljr--guess-param-name (cljr--last-arg-s prepped-form))))
     ((member fn-call cljr--fns-that-get-item-out-of-coll)
      (cljr--inflect-last-word 'cljr--singularize-string
                               (cljr--guess-param-name (cljr--first-arg-s prepped-form)))))))

(defvar cljr--semantic-noops--first-position
  (list "assoc" "assoc-in" "update" "update-in" "dissoc" "conj" "concat"
        "cycle" "rest" "nthrest" "nthnext" "next" "nnext" "butlast"
        "reverse" "vec" "set" "distinct"))

(defvar cljr--semantic-noops--last-position
  (list "filter" "filterv" "remove" "take-nth" "cons" "drop" "drop-while"
        "take-last" "take" "take-while" "drop-last" "sort" "sort-by"))

(defun cljr--strip-off-semantic-noops (form)
  "The idea here is that each of these functions,
when called on something, doesn't truly change what that something is,
so we can ignore them when trying to figure out a name for a parameter."
  (cljr--with-string-content form
    (let* ((fn-at-point (lambda ()
                          (ignore-errors
                            (save-excursion
                              (paredit-forward-down)
                              (cljr--extract-sexp)))))
           (fn (funcall fn-at-point)))
      (while (or (member fn cljr--semantic-noops--first-position)
                 (member fn cljr--semantic-noops--last-position))
        (if (member fn cljr--semantic-noops--first-position)
            (progn
              (paredit-forward-down)
              (paredit-forward)
              (cljr--skip-past-whitespace-and-comments))
          (paredit-forward)
          (paredit-backward-down)
          (paredit-backward))
        (setq fn (funcall fn-at-point))))
    (cljr--extract-sexp)))

(defun cljr--find-param-name-from-get-in (form)
  (let ((last-path-entry (cljr--with-string-content form
                           (paredit-forward-down)
                           (paredit-forward 3)
                           (paredit-backward-down)
                           (cider-symbol-at-point))))
    (when (cljr--keywordp last-path-entry)
      (string-remove-prefix ":" last-path-entry))))

(defun cljr--find-param-name-from-get (form)
  (let ((key (cljr--with-string-content form
               (paredit-forward-down)
               (paredit-forward 2)
               (cljr--skip-past-whitespace-and-comments)
               (cljr--extract-sexp))))
    (when (cljr--keywordp key)
      (string-remove-prefix ":" key))))

(defun cljr--insert-example-fn (name args path)
  "Create a new function from NAME and ARGS.

If PATH is non-nil append the new function to the end of the file
at PATH."
  (let* ((params (lambda (word i)
                   (format "${%s:%s}" (+ i 1)
                           (or (and word (cljr--guess-param-name word))
                               (format "arg%s" i)))))
         (stub (concat (cljr--defn-str path)
                       (if path (cljr--symbol-suffix name) name)
                       " ["
                       (string-join (seq-map-indexed params args)  " ")
                       "]\n$0)")))
    (when path
      (find-file-other-window path)
      (goto-char (point-max)))
    (cljr--make-room-for-toplevel-form)
    (yas-expand-snippet stub)))

;;;###autoload
(defun cljr-describe-refactoring (cljr-fn)
  "Open the wiki page for one of the available refactorings in a browser.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-describe-refactoring"
  (interactive
   (list (cljr--prompt-user-for
          "Refactoring to describe: "
          ;; Only the cljr-* commands have their own wiki pages; the
          ;; clojure-mode commands surfaced in the menu don't.
          (thread-last cljr--all-helpers
                       (mapcar (lambda (entry) (symbol-name (cadr entry))))
                       (seq-filter (lambda (name) (string-prefix-p "cljr-" name)))))))
  (browse-url (concat "https://github.com/clojure-emacs/clj-refactor.el/wiki/" cljr-fn)))

(defun cljr--parse-arglists (arglists-str)
  "Parse ARGLISTS-STR into a list of arities.

Each arity is a list of parameter-name strings.  ARGLISTS-STR carries one
arity per line, each bracketed, e.g. \"[name greeting]\" for a single
arity or \"[x]\\n[x y]\" for several.  A `&' rest marker is kept as its
own element, matching how the rest of the machinery treats it."
  (thread-last (split-string (string-trim arglists-str) "\n" t)
               (seq-map #'string-trim)
               (seq-map (lambda (arity)
                          (let ((inner (string-trim (substring arity 1 -1))))
                            (unless (string= inner "")
                              (split-string inner " " t)))))))

(defun cljr--get-function-arities (fn)
  "Retrieve FN's parameter lists, one per arity."
  (let* ((info (cljr--var-info fn))
         (arglists-str (nrepl-dict-get info "arglists-str")))
    (unless arglists-str
      (error "Couldn't retrieve the parameter list for %s" fn))
    (cljr--parse-arglists arglists-str)))

(defun cljr--choose-arity (arities)
  "Return the parameter list to edit from ARITIES.
Prompts when the function has more than one arity."
  (if (= (length arities) 1)
      (car arities)
    (let* ((labels (seq-map (lambda (a) (format "[%s]" (string-join a " "))) arities))
           (choice (completing-read "Change which arity? " labels nil t)))
      (nth (seq-position labels choice) arities))))

(defvar cljr--change-signature-mode-map
  (let ((keymap (make-sparse-keymap)))
    (define-key keymap (kbd "M-n") #'cljr--move-param-down)
    (define-key keymap (kbd "M-p") #'cljr--move-param-up)
    (define-key keymap (kbd "e") #'cljr--edit-parameter-name)
    (define-key keymap (kbd "a") #'cljr--add-parameter)
    (define-key keymap (kbd "k") #'cljr--remove-parameter)
    (define-key keymap (kbd "d") #'cljr--remove-parameter)
    (define-key keymap (kbd "C-c C-k") #'cljr--abort-signature-edit)
    (define-key keymap (kbd "q") #'cljr--abort-signature-edit)
    (define-key keymap (kbd "C-c C-c") #'cljr--commit-signature-edit)
    (define-key keymap (kbd "RET") #'cljr--commit-signature-edit)
    keymap))

(defun cljr--abort-signature-edit ()
  (interactive)
  (kill-buffer cljr--change-signature-buffer))

(defun cljr--render-signature-rows ()
  "Redraw the change-signature buffer from `cljr--signature-rows'.
Keeps point on the same row across redraws."
  (let ((inhibit-read-only t)
        (target (max 0 (min (1- (line-number-at-pos))
                            (1- (length cljr--signature-rows))))))
    (erase-buffer)
    (dolist (row cljr--signature-rows)
      (insert (plist-get row :name))
      (cond ((plist-get row :removed) (insert "  ; to be removed"))
            ((null (plist-get row :origin))
             (insert (format "  ; new param (call sites get %s)"
                             (plist-get row :default)))))
      (insert "\n"))
    (insert "\n")
    (insert "# M-n / M-p  reorder    e  rename    a  add param    k  remove param\n")
    (insert "# RET or C-c C-c  apply    q or C-c C-k  abort")
    (goto-char (point-min))
    (forward-line target))
  (setq buffer-read-only t))

(defun cljr--current-signature-row-index ()
  "Index into `cljr--signature-rows' of the row at point, or nil."
  (let ((i (1- (line-number-at-pos))))
    (when (and (>= i 0) (< i (length cljr--signature-rows)))
      i)))

(defun cljr--move-param-down ()
  "Move the parameter on the current line down one position."
  (interactive)
  (let ((i (cljr--current-signature-row-index)))
    (when (and i (< (1+ i) (length cljr--signature-rows)))
      (when (or (plist-get (nth i cljr--signature-rows) :rest)
                (plist-get (nth (1+ i) cljr--signature-rows) :rest))
        (error "Can't move the rest parameter"))
      (let ((a (nth i cljr--signature-rows))
            (b (nth (1+ i) cljr--signature-rows)))
        (setf (nth i cljr--signature-rows) b
              (nth (1+ i) cljr--signature-rows) a))
      (cljr--render-signature-rows)
      (goto-char (point-min))
      (forward-line (1+ i)))))

(defun cljr--move-param-up ()
  "Move the parameter on the current line up one position."
  (interactive)
  (let ((i (cljr--current-signature-row-index)))
    (when (and i (> i 0))
      (when (or (plist-get (nth i cljr--signature-rows) :rest)
                (plist-get (nth (1- i) cljr--signature-rows) :rest))
        (error "Can't move the rest parameter"))
      (let ((a (nth i cljr--signature-rows))
            (b (nth (1- i) cljr--signature-rows)))
        (setf (nth i cljr--signature-rows) b
              (nth (1- i) cljr--signature-rows) a))
      (cljr--render-signature-rows)
      (goto-char (point-min))
      (forward-line (1- i)))))

(defun cljr--edit-parameter-name ()
  "Rename the parameter on the current line."
  (interactive)
  (let ((i (cljr--current-signature-row-index)))
    (when i
      (let* ((row (nth i cljr--signature-rows))
             (new-name (string-trim
                        (read-from-minibuffer "New parameter name: "
                                              (plist-get row :name)))))
        (when (string= new-name "")
          (error "Parameter name can't be empty"))
        (setf (nth i cljr--signature-rows) (plist-put row :name new-name))
        (cljr--render-signature-rows)))))

(defun cljr--add-parameter ()
  "Add a new parameter to the signature.
The parameter is appended after the fixed parameters (before any rest
parameter).  You're prompted for its name and for the placeholder to
insert at call sites."
  (interactive)
  (let* ((name (string-trim (read-from-minibuffer "New parameter name: ")))
         (default (string-trim
                   (read-from-minibuffer "Placeholder to insert at call sites: " "nil")))
         (pos (or (seq-position cljr--signature-rows t
                                (lambda (row _) (plist-get row :rest)))
                  (length cljr--signature-rows)))
         (new-row (list :origin nil :name name
                        :default (if (string= default "") "nil" default)
                        :removed nil :rest nil)))
    (when (string= name "")
      (error "Parameter name can't be empty"))
    (setq cljr--signature-rows
          (append (seq-take cljr--signature-rows pos)
                  (list new-row)
                  (seq-drop cljr--signature-rows pos)))
    (cljr--render-signature-rows)
    (goto-char (point-min))
    (forward-line pos)))

(defun cljr--remove-parameter ()
  "Mark the parameter on the current line for removal (toggles).
An added parameter is dropped outright.  Removals aren't applied to call
sites automatically - they're routed to the manual-intervention buffer."
  (interactive)
  (let ((i (cljr--current-signature-row-index)))
    (when i
      (let ((row (nth i cljr--signature-rows)))
        (when (plist-get row :rest)
          (error "Can't remove the rest parameter"))
        (if (plist-get row :origin)
            (setf (nth i cljr--signature-rows)
                  (plist-put row :removed (not (plist-get row :removed))))
          (setq cljr--signature-rows
                (append (seq-take cljr--signature-rows i)
                        (seq-drop cljr--signature-rows (1+ i)))))
        (cljr--render-signature-rows)))))

(defun cljr--signature-rows-to-changes (rows original-params)
  "Build the tagged `signature-changes' list from edit-buffer ROWS.
ORIGINAL-PARAMS supplies each kept/removed row's original name."
  (let ((j 0) changes)
    (dolist (row rows)
      (let ((origin (plist-get row :origin))
            (removed (plist-get row :removed))
            (name (plist-get row :name)))
        (cond
         ((and removed origin)
          (let ((h (make-hash-table)))
            (puthash :op :remove h)
            (puthash :old-index origin h)
            (puthash :old-name (nth origin original-params) h)
            (push h changes)))
         (removed nil)                  ; added then removed: nothing to do
         (origin
          (let ((h (make-hash-table)))
            (puthash :op :keep h)
            (puthash :old-index origin h)
            (puthash :new-index j h)
            (puthash :old-name (nth origin original-params) h)
            (puthash :new-name name h)
            (push h changes))
          (setq j (1+ j)))
         (t
          (let ((h (make-hash-table)))
            (puthash :op :add h)
            (puthash :new-index j h)
            (puthash :new-name name h)
            (puthash :default (plist-get row :default) h)
            (push h changes))
          (setq j (1+ j))))))
    (nreverse changes)))

(defun cljr--defnp (match)
  (string-match-p (rx (seq line-start (* whitespace) "("
                           (? (+ (or (in "a-z") (in "A-z") (in "0-9")
                                     (in "-") (in "._/"))))
                           "defn"))
                  match))

(defun cljr--update-parameter-name (new-name)
  (cljr--skip-past-whitespace-and-comments)
  (forward-char)
  (cljr-rename-symbol new-name))

(defun cljr--forward-parameter ()
  "Move point forward across one parameter.

This includes skipping past any type information added by
prismatic/schema and moving paste any whitespace"
  (paredit-forward)
  (cljr--skip-past-whitespace-and-comments)
  (when (looking-at-p ":-")
    (paredit-forward 2))
  (cljr--skip-past-whitespace-and-comments))

(defun cljr--change-op (change)
  "The operation tag for CHANGE.

Entries default to `:keep' (reorder/rename) when they carry no `:op',
for backward compatibility with the pre-add/remove model.  The other
tags are `:add' (a new parameter, with a `:default' placeholder for call
sites and a `:new-name' for the definition) and `:remove' (a dropped
parameter)."
  (or (gethash :op change) :keep))

(defun cljr--signature-has-add-p (signature-changes)
  (seq-some (lambda (c) (eq (cljr--change-op c) :add)) signature-changes))

(defun cljr--signature-has-remove-p (signature-changes)
  (seq-some (lambda (c) (eq (cljr--change-op c) :remove)) signature-changes))

(defun cljr--signature-variadic-p (signature-changes)
  "Non-nil when the signature has a `&' rest parameter.
Call sites of a variadic function can't be rewritten positionally, since
the number of arguments varies, so they're left for manual review."
  (seq-some (lambda (c) (equal (gethash :old-name c) "&")) signature-changes))

(defun cljr--old-signature-changes (signature-changes)
  "The changes present in the OLD signature (`:keep' + `:remove').

Sorted by `:old-index', so they line up with the parameters as they
appear in the lambda list before editing."
  (thread-last signature-changes
               (seq-remove (lambda (c) (eq (cljr--change-op c) :add)))
               (seq-sort-by (lambda (c) (gethash :old-index c)) #'<)))

(defun cljr--new-signature-changes (signature-changes)
  "The changes present in the NEW signature (`:keep' + `:add').

Sorted by `:new-index', i.e. the order the parameters should end up in."
  (thread-last signature-changes
               (seq-remove (lambda (c) (eq (cljr--change-op c) :remove)))
               (seq-sort-by (lambda (c) (gethash :new-index c)) #'<)))

(defun cljr--old-arity (signature-changes)
  "Number of parameters in the OLD signature."
  (length (cljr--old-signature-changes signature-changes)))

(defun cljr--signature-structurally-changed-p (signature-changes)
  "Non-nil when the parameter structure (order or count) changes.

Pure renames don't count - they're applied in place and don't touch call
sites."
  (or (cljr--signature-has-add-p signature-changes)
      (cljr--signature-has-remove-p signature-changes)
      (seq-some (lambda (c) (and (eq (cljr--change-op c) :keep)
                                 (/= (gethash :new-index c) (gethash :old-index c))))
                signature-changes)))

(defun cljr--insert-new-signature (signature-changes add-fn old-values)
  "Insert the new parameter (or argument) sequence at point.

Walks the entries in `:new-index' order.  A `:keep' entry re-inserts the
element of OLD-VALUES (a vector indexed by `:old-index') that it refers
to; an `:add' entry inserts the string returned by ADD-FN for it."
  (let ((new (cljr--new-signature-changes signature-changes))
        (leading t))
    (dolist (change new)
      (unless leading (insert " "))
      (setq leading nil)
      (if (eq (cljr--change-op change) :add)
          (insert (funcall add-fn change))
        (insert (aref old-values (gethash :old-index change)))))))

(defun cljr--update-signature-names (signature-changes)
  "Point is assumed to be at the the first character in the lambda list.

Renames kept parameters in place, walking past every old parameter."
  (dolist (change (cljr--old-signature-changes signature-changes))
    (when (and (eq (cljr--change-op change) :keep)
               (not (string= (gethash :new-name change)
                             (gethash :old-name change))))
      (cljr--update-parameter-name (gethash :new-name change)))
    (cljr--forward-parameter)))

(defun cljr--delete-and-extract-region (beg end)
  (prog1
      (buffer-substring-no-properties beg end)
    (delete-region beg end)))

(defun cljr--delete-and-extract-function-parameter ()
  (cljr--skip-past-whitespace-and-comments)
  (let (parameter)
    (push (cljr--delete-and-extract-region
           (point) (cljr--point-after 'paredit-forward))
          parameter)
    (delete-region (point) (cljr--point-after
                            'cljr--skip-past-whitespace-and-comments))
    (when (looking-at-p ":-")
      (push (cljr--delete-and-extract-region
             (point) (cljr--point-after '(paredit-forward 2)))
            parameter))
    (delete-region (point) (cljr--point-after
                            'cljr--skip-past-whitespace-and-comments))
    (string-join (nreverse parameter) " ")))

(defun cljr--maybe-wrap-form ()
  "Insert newlines in or prior to the current form to prevent long lines.

Point is assumed to be at the end of the form."
  (let ((breakpoint (or (and (boundp 'whitespace-line-column)
                             whitespace-line-column)
                        80)))
    (when (> (current-column) breakpoint)
      (paredit-backward-up)
      (if (and (not (looking-back "^\\s-*" (line-beginning-position))) (looking-at-p "\\["))
          (newline-and-indent) ; Put lambdalist on its own line
        (paredit-forward-down)
        (cljr--forward-parameter) ; don't break right after ( or [
        (while (save-excursion (cljr--forward-parameter)
                               (< (current-column) breakpoint))
          (cljr--forward-parameter))
        (newline-and-indent)))))

(defun cljr--update-signature-order (signature-changes)
  "Point is assumed to be at the first character in the lambda list.

Rebuilds the lambda list: reorders kept parameters, inserts added
parameters (by name), and drops removed ones."
  (when (cljr--signature-structurally-changed-p signature-changes)
    (let ((params (make-vector (cljr--old-arity signature-changes) nil)))
      ;; extract the old parameters, left to right, so index = `:old-index'
      (dotimes (i (cljr--old-arity signature-changes))
        (aset params i (cljr--delete-and-extract-function-parameter)))
      ;; leave point in empty lambda list
      (paredit-backward-up)
      (paredit-forward-down)
      (delete-region (point) (cljr--point-after 'cljr--skip-past-whitespace-and-comments))
      (cljr--insert-new-signature signature-changes
                                  (lambda (change) (gethash :new-name change))
                                  params)
      (cljr--maybe-wrap-form))))

(defun cljr--count-lambda-list-params ()
  "Return the number of parameters in the lambda list at point.

Point must be at the opening bracket.  Schema type annotations (`:- T')
are skipped, and a `&' rest marker counts as a parameter, so the count
lines up with `cljr--parse-arglists'."
  (save-excursion
    (let ((end (cljr--point-after 'paredit-forward))
          (count 0))
      (paredit-forward-down)
      (cljr--skip-past-whitespace-and-comments)
      (while (< (point) (1- end))
        (cljr--forward-parameter)
        (setq count (1+ count)))
      count)))

(defun cljr--goto-arity-lambda-list (arg-count)
  "Move into the lambda list of the arity that has ARG-COUNT parameters.

Point is assumed to be just prior to the function definition.  Handles
both single-arity defns (a bare lambda list) and multi-arity defns (each
arity wrapped in a list).  Signals an error if no matching arity exists.

E.g. with ARG-COUNT 2, move point from here:  |(defn foo [bar baz] ...)
to here:  (defn foo [|bar baz] ...)"
  (paredit-forward-down)
  (let ((defn-end (save-excursion (paredit-forward-up) (1- (point))))
        (target nil))
    (cljr--skip-past-whitespace-and-comments)
    (while (and (not target) (< (point) defn-end))
      (cond
       ;; single-arity: a bare lambda list
       ((looking-at-p "\\[")
        (when (= (cljr--count-lambda-list-params) arg-count)
          (setq target (point))))
       ;; multi-arity: a clause like ([params] body ...)
       ((looking-at-p "(")
        (setq target (save-excursion
                       (paredit-forward-down)
                       (cljr--skip-past-whitespace-and-comments)
                       (when (and (looking-at-p "\\[")
                                  (= (cljr--count-lambda-list-params) arg-count))
                         (point))))))
      (unless target
        (paredit-forward)
        (cljr--skip-past-whitespace-and-comments)))
    (unless target
      (error "Couldn't find an arity with %d parameter(s)" arg-count))
    (goto-char target)
    (paredit-forward-down)))

(defun cljr--update-function-signature (signature-changes)
  "Point is assumed to be just prior to the function definition we're about to update."
  (let ((arg-count (cljr--old-arity signature-changes)))
    (cljr--goto-arity-lambda-list arg-count)
    (cljr--update-signature-names signature-changes)
    (cljr--goto-toplevel)
    (cljr--goto-arity-lambda-list arg-count)
    (cljr--update-signature-order signature-changes)))

(defun cljr--call-site-p (fn)
  "Is point at a call-site for FN?"
  (save-excursion
    (ignore-errors
      (paredit-backward-up)
      (paredit-forward-down)
      (string-suffix-p (cljr--symbol-suffix fn) (cider-symbol-at-point)))))

(defun cljr--call-site-arg-count ()
  "Return the number of arguments at the call site.
Point is assumed to be at the function name being called.

Counts sexps, so `#_'-ignored forms and `#?'-reader conditionals in the
argument list are miscounted; such a call may not match its arity and be
left unchanged."
  (save-excursion
    (paredit-backward-up)
    (let ((end (cljr--point-after 'paredit-forward))
          ;; start at -1 so the function name itself isn't counted
          (count -1))
      (paredit-forward-down)
      (cljr--skip-past-whitespace-and-comments)
      (while (< (point) (1- end))
        (cljr--forward-parameter)
        (setq count (1+ count)))
      count)))

(defun cljr--no-changes-to-parameter-order-p (signature-changes)
  (seq-every-p (lambda (e) (= (gethash :new-index e) (gethash :old-index e)))
               signature-changes))

(defun cljr--update-call-site (signature-changes)
  "Point is assumed to be at the name of the function being called.

Rebuilds the argument list: reorders kept arguments and inserts each
added parameter's `:default' placeholder.  Removals are never applied
here - they're routed to the manual-intervention buffer by the caller."
  (when (cljr--signature-structurally-changed-p signature-changes)
    (cljr--forward-parameter)
    (let ((args (make-vector (cljr--old-arity signature-changes) nil)))
      (dotimes (i (cljr--old-arity signature-changes))
        (aset args i (cljr--delete-and-extract-function-parameter)))
      (cljr--insert-new-signature signature-changes
                                  (lambda (change) (gethash :default change))
                                  args)
      (cljr--maybe-wrap-form))))

(defun cljr--append-to-manual-intervention-buffer ()
  "Append the current line to the buffer of stuff requiring manual intervention."
  (let ((line (string-trim (buffer-substring-no-properties
                            (line-beginning-position) (line-end-position))))
        (linum (line-number-at-pos))
        (file (buffer-file-name)))
    (with-current-buffer (get-buffer-create cljr--manual-intervention-buffer)
      (goto-char (point-max))
      (insert (format "%s:%s: %s\n" file linum line)))))

(defun cljr--update-apply-call-site (signature-changes)
  "Update a call-site where apply is used to call the function whose signature we're currently editing.

point is assumed to be at the function name"
  (unless (cljr--no-changes-to-parameter-order-p signature-changes)
    (let ((num-args 0)
          (max-index (thread-last signature-changes
                                  (seq-map (lambda (c) (let ((new  (gethash :new-index c))
                                                             (old (gethash :old-index c)))
                                                         (if (/= old new)
                                                             (max old new)))))
                                  (seq-remove #'null)
                                  (apply #'max)))
          beg end)
      (cljr--skip-past-whitespace-and-comments)
      (setq beg (point))
      (paredit-forward)
      (setq end (cljr--point-after 'paredit-forward-up))
      (while (< (save-excursion (cljr--point-after 'cljr--forward-parameter)) end)
        (cljr--forward-parameter)
        (setq num-args (1+ num-args)))
      (if (>=  max-index (1- num-args))
          ;; Some of the arguments in the final list of args to apply have changed
          (cljr--append-to-manual-intervention-buffer)
        (goto-char beg)
        (cljr--update-call-site signature-changes)))))

(defun cljr--update-partial-call-site (signature-changes)
  "Update a call-site with partial application of the function whose signature we're currently editing.

This only handles the case where we have (partial my-fn a b c)
and only parameters a b or c are affected.

point is assumed to be at the function name"
  (unless (cljr--no-changes-to-parameter-order-p signature-changes)
    (let ((num-partials 0)
          (max-index (thread-last signature-changes
                                  (seq-map (lambda (c) (let ((new  (gethash :new-index c))
                                                             (old (gethash :old-index c)))
                                                         (when (/= old new)
                                                           (max old new)))))
                                  (seq-remove #'null)
                                  (apply #'max)))
          beg end)
      (setq beg (point))
      (cljr--skip-past-whitespace-and-comments)
      (paredit-forward 1)
      (setq end (cljr--point-after 'paredit-forward-up))
      (while (< (save-excursion (cljr--point-after 'cljr--forward-parameter)) end)
        (cljr--forward-parameter)
        (setq num-partials (1+ num-partials)))
      (if (>=  max-index num-partials)
          (cljr--append-to-manual-intervention-buffer)
        (goto-char beg)
        (cljr--update-call-site (seq-remove (lambda (c)
                                              (>= (gethash :new-index c) num-partials))
                                            signature-changes))))))

(defun cljr--apply-call-site-p ()
  "Is the function invocation at this place being done using apply?

Point is assumed to be at the function being called."
  (ignore-errors
    (save-excursion
      (paredit-backward-up)
      (paredit-forward-down)
      (looking-at-p "apply"))))

(defun cljr--partial-call-site-p ()
  "Is the function invocation at this place being done using partial.

Point is assumed to be at the function being called."
  (ignore-errors
    (save-excursion
      (paredit-backward-up)
      (paredit-forward-down)
      (looking-at-p "partial"))))

(defun cljr--ignorable-occurrence-p ()
  (save-excursion
    (cljr--goto-toplevel)
    (looking-at-p "\\s-*(ns")))

(defun cljr--change-function-signature (occurrences signature-changes)
  ;; SIGNATURE-CHANGES is a list of hashmaps, each tagged with an `:op'
  ;; (see `cljr--change-op'):
  ;;   :keep   - :old-index :new-index :old-name :new-name (reorder/rename)
  ;;   :add    - :new-index :new-name :default (placeholder at call sites)
  ;;   :remove - :old-index :old-name
  ;; Indexing is from 0.  An entry with no `:op' is treated as `:keep'.
  ;; The OCCURRENCES are the same as those returned by `cljr--find-symbol'
  (let* ((*cljr--noninteractive* t)
         (applied
          (cljr--run-previewable-refactoring
           "Change function signature"
           (lambda ()
             (dolist (symbol-meta occurrences)
               (let ((file (cljr--get-valid-filename symbol-meta))
                     (line-beg (gethash :line-beg symbol-meta))
                     (col-beg (gethash :col-beg symbol-meta))
                     (name (gethash :name symbol-meta))
                     (match (gethash :match symbol-meta)))
                 (with-current-buffer
                     (cljr--find-file-noselect file)
                   (goto-char (point-min))
                   (forward-line (1- line-beg))
                   (move-to-column (1- col-beg))
                   (cond
                     ((cljr--ignorable-occurrence-p) :do-nothing)
                     ;; Direct call site.
                     ((cljr--call-site-p name)
                      (cond
                        ;; Variadic functions can't be rewritten positionally (their
                        ;; call-site arg count varies), so leave them for review.
                        ((cljr--signature-variadic-p signature-changes)
                         (cljr--append-to-manual-intervention-buffer))
                        ;; A call to a different arity than the one being changed - the
                        ;; arg count doesn't match - is correct as is, so leave it.
                        ((/= (cljr--call-site-arg-count)
                             (cljr--old-arity signature-changes))
                         :do-nothing)
                        ;; Removing a parameter is destructive - an argument might have
                        ;; side effects or be needed elsewhere - so never auto-delete
                        ;; it; route the call site to manual review.
                        ((cljr--signature-has-remove-p signature-changes)
                         (cljr--append-to-manual-intervention-buffer))
                        (t (cljr--update-call-site signature-changes))))
                     ;; `apply'/`partial' sites can only be handled for pure reorders;
                     ;; an added or removed arg would land in the wrong spot, so bail.
                     ((cljr--partial-call-site-p)
                      (if (or (cljr--signature-has-add-p signature-changes)
                              (cljr--signature-has-remove-p signature-changes))
                          (cljr--append-to-manual-intervention-buffer)
                          (cljr--update-partial-call-site signature-changes)))
                     ((cljr--apply-call-site-p)
                      (if (or (cljr--signature-has-add-p signature-changes)
                              (cljr--signature-has-remove-p signature-changes))
                          (cljr--append-to-manual-intervention-buffer)
                          (cljr--update-apply-call-site signature-changes)))
                     ;; The definition itself.  `cljr--defnp' is a loose match on the
                     ;; occurrence line, so it must stay last - a call that happens to
                     ;; sit on a `(defn ...)' line is a call site, handled above.
                     ((cljr--defnp match)
                      (cljr--update-function-signature signature-changes))
                     (t (cljr--append-to-manual-intervention-buffer)))
                   (cljr--save-buffer))))))))
    (when (and applied
               (not (cljr--empty-buffer-p
                     (get-buffer-create cljr--manual-intervention-buffer))))
      (pop-to-buffer cljr--manual-intervention-buffer)
      (goto-char (point-min))
      (insert "The following occurrence(s) couldn't be handled automatically:\n\n")
      (grep-mode)
      (setq-local compilation-search-path (list (cljr--project-dir))))))

(defun cljr--commit-signature-edit ()
  (interactive)
  (let ((changes (cljr--signature-rows-to-changes
                  cljr--signature-rows cljr--signature-original-params)))
    (cljr--change-function-signature cljr--occurrences changes))
  (kill-buffer cljr--change-signature-buffer))

(define-derived-mode cljr--change-signature-mode fundamental-mode
  "Change Signature"
  "Major mode for refactoring function signatures.")

(defun cljr--setup-change-signature-buffer (control-buffer params)
  (when (get-buffer control-buffer)
    (kill-buffer control-buffer))
  (pop-to-buffer control-buffer)
  (cljr--change-signature-mode)
  (setq cljr--signature-original-params params)
  (setq cljr--signature-rows
        (let ((seen-rest nil) rows)
          (dotimes (i (length params))
            (let ((name (nth i params)))
              (when (string= name "&") (setq seen-rest t))
              (push (list :origin i :name name :default nil
                          :removed nil :rest seen-rest)
                    rows)))
          (nreverse rows)))
  (cljr--render-signature-rows))

;;;###autoload
(defun cljr-change-function-signature ()
  "Change the function signature of the function at point.

For a multi-arity function you're asked which arity to change; only that
arity's definition and the call sites with a matching number of
arguments are updated.

See: https://github.com/clojure-emacs/clj-refactor.el/wiki/cljr-change-function-signature"
  (interactive)
  (cljr--ensure-op-supported "find-symbol")
  (when (cljr--asts-y-or-n-p)
    (let* ((fn (cider-symbol-at-point))
           (params (cljr--choose-arity (cljr--get-function-arities fn)))
           (var-info (cljr--var-info fn))
           (ns (nrepl-dict-get var-info "ns")))
      ;; Finding every call site analyses the whole project, which can be
      ;; slow, so do it asynchronously and open the edit buffer in the
      ;; callback rather than freezing Emacs on a synchronous round-trip.
      (unless *cljr--noninteractive* (message "Finding occurrences of %s..." fn))
      (cljr--find-symbol-occurrences
       fn ns
       (lambda (occurrences)
         (setq cljr--occurrences occurrences)
         (when (get-buffer cljr--manual-intervention-buffer)
           (kill-buffer cljr--manual-intervention-buffer))
         (cljr--setup-change-signature-buffer cljr--change-signature-buffer params)
         (pop-to-buffer cljr--change-signature-buffer))))))

;;;###autoload
(defun cljr--inject-middleware-p (&rest _)
  "Return non-nil if nREPL middleware should be injected."
  (cljr--inside-project-p))

;;;###autoload
(defun cljr--inject-jack-in-dependencies ()
  "Inject the REPL dependencies of clj-refactor at `cider-jack-in'.
If injecting the dependencies is not preferred set
`cljr-inject-dependencies-at-jack-in' to nil."
  (when (and cljr-inject-dependencies-at-jack-in
             (fboundp 'cider-add-to-alist)
             (boundp 'cider-preferred-build-tool)
             (boundp 'cider-jack-in-dependencies)
             (boundp 'cider-jack-in-lein-plugins)
             (boundp 'cider-jack-in-nrepl-middlewares))

    (when (not (eq cider-preferred-build-tool 'lein))
      (cider-add-to-alist 'cider-jack-in-dependencies
                          "refactor-nrepl/refactor-nrepl" cljr-injected-middleware-version))

    (add-to-list 'cider-jack-in-lein-plugins `("refactor-nrepl/refactor-nrepl" ,cljr-injected-middleware-version
                                               :predicate cljr--inject-middleware-p))
    (add-to-list 'cider-jack-in-nrepl-middlewares '("refactor-nrepl.middleware/wrap-refactor"
                                                    :predicate cljr--inject-middleware-p))))

;;;###autoload
(with-eval-after-load 'cider
  (cljr--inject-jack-in-dependencies))

(add-hook 'cider-connected-hook #'cljr--init-middleware)

;; ------ minor mode -----------
;;;###autoload
(define-minor-mode clj-refactor-mode
  "A mode to keep the clj-refactor keybindings."
  :init-value nil
  :lighter " cljr"
  :keymap clj-refactor-map
  :global nil
  (if clj-refactor-mode
      (add-hook 'post-command-hook #'cljr--post-command-hook :append :local)
    (remove-hook 'post-command-hook #'cljr--post-command-hook :local)))

(provide 'clj-refactor)
;;; clj-refactor.el ends here
