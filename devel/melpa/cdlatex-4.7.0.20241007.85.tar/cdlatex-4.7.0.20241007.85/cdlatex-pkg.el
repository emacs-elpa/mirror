;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cdlatex" "4.7.0.20241007.85"
  "Fast input methods for LaTeX environments and math."
  ()
  :url "https://github.com/cdominik/cdlatex"
  :commit "fac070f0164ac9f5859cb4cccba7d29a65c337f3"
  :revdesc "fac070f0164a"
  :keywords '("tex")
  :authors '(("Carsten Dominik" . "carsten.dominik@gmail.com"))
  :maintainers '(("Carsten Dominik" . "carsten.dominik@gmail.com")))
