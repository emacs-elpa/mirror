;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ktlint" "1.0.0.20180831.7"
  "Flymake extension for Ktlint."
  '((emacs "26.1"))
  :url "https://github.com/jojojames/flymake-ktlint"
  :commit "bea8bf350802c06756efd4e6dfba65f31dc41d78"
  :revdesc "bea8bf350802"
  :keywords '("languages" "ktlint")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
