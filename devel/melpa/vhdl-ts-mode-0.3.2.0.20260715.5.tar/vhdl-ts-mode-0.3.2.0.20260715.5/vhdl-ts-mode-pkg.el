;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ts-mode" "0.3.2.0.20260715.5"
  "VHDL Tree-sitter major mode."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/vhdl-ts-mode"
  :commit "2af6fcabc3deacb4668ea60af4840279b944495d"
  :revdesc "2af6fcabc3de"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
