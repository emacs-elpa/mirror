;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.4.1.0.20261030.1"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.5.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "528eb5b5d0bb57de8890d2dec559a18a5f4631cc"
  :revdesc "v3.4.1-1-g528eb5b5d0bb"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
