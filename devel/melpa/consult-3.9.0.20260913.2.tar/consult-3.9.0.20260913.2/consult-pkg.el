;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "3.9.0.20260913.2"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "9979fbb02e633267d0f6bc6cafa266fe87a0007f"
  :revdesc "3.9-2-g9979fbb02e63"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
