;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.97.2.0.20260820.2"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "ab4f8ebaf4ef7a7db4762c5d5075baea580044ba"
  :revdesc "ab4f8ebaf4ef")
