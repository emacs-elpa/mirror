;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "1.2.3.0.20260806.265"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "2d0e5c0f164ff9bacada4a8034f8ccc9c4f78683"
  :revdesc "2d0e5c0f164f"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
