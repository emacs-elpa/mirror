;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tomorrow-night-deepblue-theme" "1.2.4.0.20260710.17"
  "The Tomorrow Night Deepblue color theme."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/tomorrow-night-deepblue-theme.el"
  :commit "38e601d69e5741463e6d725100234d0c6e3e5741"
  :revdesc "1.2.4-17-g38e601d69e57"
  :keywords '("faces" "themes")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
