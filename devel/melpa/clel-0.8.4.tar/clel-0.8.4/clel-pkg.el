;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clel" "0.8.4"
  "Runtime library for ClojureElisp."
  '((emacs "28.1"))
  :url "https://github.com/BuddhiLW/clojure-elisp"
  :commit "a6a65777e2ee432ac9bd273ec9baa849f1d1f2bc"
  :revdesc "a6a65777e2ee"
  :keywords '("languages" "lisp" "clojure")
  :authors '(("Pedro G. Branquinho" . "pedrogbranquinho@gmail.com"))
  :maintainers '(("Pedro G. Branquinho" . "pedrogbranquinho@gmail.com")))
