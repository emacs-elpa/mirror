;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-qiita" "1.1.3"
  "Qiita with helm interface."
  '((emacs "24")
    (helm  "2.8.2"))
  :url "https://github.com/masutaka/emacs-helm-qiita"
  :commit "5f82010c595f8e122aa3f68148ba8d8ccb1333d8"
  :revdesc "1.1.3-0-g5f82010c595f"
  :authors '(("Takashi Masuda" . "masutaka.net@gmail.com"))
  :maintainers '(("Takashi Masuda" . "masutaka.net@gmail.com")))
