;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2.0.20260823.32"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "67dd45bb91f05909f6e0913201565e1c9e1e6729"
  :revdesc "67dd45bb91f0"
  :keywords '("faces" "files" "q"))
