;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "handlebars-mode" "1.4.0.20150211.17"
  "A major mode for editing Handlebars files."
  ()
  :url "https://github.com/danielevans/handlebars-mode"
  :commit "81f6b73fea8f397807781a1b51568397af21a6ef"
  :revdesc "81f6b73fea8f")
