;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "3.6.0.0.20260813.5"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "08786dd55a0eef28b4dc6f5490fdc3f157b9f313"
  :revdesc "08786dd55a0e"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
