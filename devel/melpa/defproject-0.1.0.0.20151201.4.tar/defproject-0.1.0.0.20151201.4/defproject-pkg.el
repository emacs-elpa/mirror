;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "defproject" "0.1.0.0.20151201.4"
  "Manager dir-locals and project specific variables."
  '((emacs "24"))
  :url "https://github.com/kotfic/defproject"
  :commit "674d48a5e34cb4bba76faa38ee901322ec649086"
  :revdesc "674d48a5e34c"
  :keywords '("convenience")
  :authors '((nil . "kotfic@gmail.com"))
  :maintainers '((nil . "kotfic@gmail.com")))
