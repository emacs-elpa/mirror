;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parenthesis-face" "1.2.4"
  "A face for parentheses."
  '((emacs "30.1"))
  :url "https://github.com/tarsius/paren-face"
  :commit "57307b5ea75e07d2dc0c64c7e3eeadee3369a7aa"
  :revdesc "v1.2.4-0-g57307b5ea75e"
  :keywords '("faces" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev")))
