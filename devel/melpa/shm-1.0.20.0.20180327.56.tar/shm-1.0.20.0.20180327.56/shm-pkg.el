;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shm" "1.0.20.0.20180327.56"
  "Structured Haskell Mode."
  ()
  :url "https://github.com/projectional-haskell/structured-haskell-mode"
  :commit "7f9df73f45d107017c18ce4835bbc190dfe6782e"
  :revdesc "7f9df73f45d1"
  :keywords '("development" "haskell" "structured")
  :authors '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainers '(("Chris Done" . "chrisdone@gmail.com")))
