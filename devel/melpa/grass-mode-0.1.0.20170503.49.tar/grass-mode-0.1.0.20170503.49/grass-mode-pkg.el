;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grass-mode" "0.1.0.20170503.49"
  "Provides Emacs modes for interacting with the GRASS GIS program."
  '((cl-lib "0.2")
    (dash   "2.8.0"))
  :url "https://github.com/plantarum/grass-mode"
  :commit "f17e330dfde6a1b81a9b33d019fc0dff890f482d"
  :revdesc "f17e330dfde6"
  :keywords '("grass" "gis")
  :authors '(("Tyler Smith" . "tyler@plantarum.ca"))
  :maintainers '(("Tyler Smith" . "tyler@plantarum.ca")))
