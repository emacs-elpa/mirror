;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rhq" "0.7.0.0.20230731.14"
  "Client for rhq."
  '((emacs "24.4"))
  :url "https://github.com/ROCKTAKEY/rhq"
  :commit "9f571787bf0781c78c277db82394fb9a692ec21e"
  :revdesc "v0.7.0-14-g9f571787bf07"
  :keywords '("tools" "extensions")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
