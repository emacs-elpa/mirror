;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.59.0.0.20261019.2"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b7a2216b0e66fdce72c9bc7161415d4a37a6e1cc"
  :revdesc "b7a2216b0e66"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
