;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cider-decompile" "0.0.2.0.20151122.2"
  "Decompilation extension for cider."
  '((cider      "0.3.0")
    (javap-mode "9"))
  :url "http://www.github.com/clojure-emacs/cider-decompile"
  :commit "5d87035f3c3c14025e8f01c0c53d0ce2c8f56651"
  :revdesc "5d87035f3c3c"
  :keywords '("languages" "clojure" "cider"))
