;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "0.2.0.20260627.95"
  "Interface to query and view results from org-roam."
  '((emacs         "28")
    (org-roam      "2.2.0")
    (s             "1.12.0")
    (magit-section "3.3.0")
    (transient     "0.4")
    (dash          "2.0"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "cfc28de50d9d1c499e2af6dcb43cb25e5540512e"
  :revdesc "cfc28de50d9d")
