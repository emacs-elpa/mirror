;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "0.13.7.0.20260825.3"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "9ac2d48909e1d34890a4a17581d6693dcc867800"
  :revdesc "v0.13.7-3-g9ac2d48909e1"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
