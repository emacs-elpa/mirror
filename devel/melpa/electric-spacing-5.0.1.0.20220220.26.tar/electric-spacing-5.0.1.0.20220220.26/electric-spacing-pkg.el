;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-spacing" "5.0.1.0.20220220.26"
  "Insert operators with surrounding spaces smartly."
  ()
  :url "https://github.com/xwl/electric-spacing"
  :commit "c37b2502512dd49a8311d7c34e9bfd1af3d4dbcd"
  :revdesc "c37b2502512d"
  :authors '(("William Xu" . "william.xwl@gmail.com"))
  :maintainers '(("William Xu" . "william.xwl@gmail.com")))
