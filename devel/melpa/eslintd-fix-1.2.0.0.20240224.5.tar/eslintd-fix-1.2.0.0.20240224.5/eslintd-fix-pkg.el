;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eslintd-fix" "1.2.0.0.20240224.5"
  "Use eslint_d to automatically fix js files."
  '((dash  "2.12.0")
    (emacs "26.3"))
  :url "https://github.com/aaronjensen/eslintd-fix"
  :commit "99665b66686cc5974499cec4aff1e29faef1c028"
  :revdesc "v1.2.0-5-g99665b66686c"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
