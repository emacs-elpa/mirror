;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "1.0.6.0.20260701.3"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "c741d0a21a06b6878518dd75983eb7ca65ddc385"
  :revdesc "1.0.6-3-gc741d0a21a06"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
