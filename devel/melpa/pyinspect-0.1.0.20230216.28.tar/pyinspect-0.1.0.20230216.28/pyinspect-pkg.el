;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyinspect" "0.1.0.20230216.28"
  "Python object inspector."
  '((emacs "27.1"))
  :url "https://github.com/it-is-wednesday/pyinspect.el"
  :commit "4437dc589d0c1eb0ca80bf0d005ee27d15cf69fc"
  :revdesc "4437dc589d0c"
  :keywords '("tools")
  :authors '(("Maor Kadosh" . "git@avocadosh.xyz"))
  :maintainers '(("Maor Kadosh" . "git@avocadosh.xyz")))
