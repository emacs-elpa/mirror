;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.9.7.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "3e73ebb14d65b9cff855f6c3ad17daee5730031b"
  :revdesc "3e73ebb14d65"
  :keywords '("languages"))
