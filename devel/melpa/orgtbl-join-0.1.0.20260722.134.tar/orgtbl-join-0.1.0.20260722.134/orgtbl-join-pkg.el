;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "0.1.0.20260722.134"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "5c3a95d2f549f74546c9ade3b1f09a007530947c"
  :revdesc "5c3a95d2f549"
  :keywords '("data" "extensions"))
