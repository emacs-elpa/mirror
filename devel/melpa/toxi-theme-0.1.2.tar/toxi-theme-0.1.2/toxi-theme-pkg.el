;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toxi-theme" "0.1.2"
  "A dark color theme by toxi."
  '((emacs "24"))
  :url "http://bitbucket.org/postspectacular/toxi-theme/"
  :commit "9e572c6e149249b96f64722cf6f86c3aaf5f2ede"
  :revdesc "9e572c6e1492"
  :authors '(("Karsten Schmidt" . "info@postspectacular.com"))
  :maintainers '(("Karsten Schmidt" . "info@postspectacular.com")))
