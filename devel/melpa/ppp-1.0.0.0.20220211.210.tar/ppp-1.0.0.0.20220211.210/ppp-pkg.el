;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ppp" "1.0.0.0.20220211.210"
  "Extended pretty printer for Emacs Lisp."
  '((emacs "25.1"))
  :url "https://github.com/conao3/ppp.el"
  :commit "d5d854c3006dfd268e62c7f91c2aad6f86a505b5"
  :revdesc "d5d854c3006d"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
