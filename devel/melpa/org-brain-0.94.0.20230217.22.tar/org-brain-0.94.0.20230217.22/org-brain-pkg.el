;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-brain" "0.94.0.20230217.22"
  "Org-mode concept mapping."
  '((emacs "25.1")
    (org   "9.2"))
  :url "https://github.com/Kungsgeten/org-brain"
  :commit "2bad7732aae1a3051e2a14de2e30f970bbe43c25"
  :revdesc "2bad7732aae1"
  :keywords '("outlines" "hypermedia")
  :authors '(("Erik Sjöstrand" . "sjostrand.erik@gmail.com"))
  :maintainers '(("Erik Sjöstrand" . "sjostrand.erik@gmail.com")))
