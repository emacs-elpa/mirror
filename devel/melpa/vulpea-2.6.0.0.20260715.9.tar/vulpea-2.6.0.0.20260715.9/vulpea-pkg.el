;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.6.0.0.20260715.9"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "68d1fdd30b99e518008347ff4f1c5323e022c24f"
  :revdesc "68d1fdd30b99"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
