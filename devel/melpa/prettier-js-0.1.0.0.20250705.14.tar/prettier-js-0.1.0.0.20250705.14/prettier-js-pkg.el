;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "0.1.0.0.20250705.14"
  "Minor mode to format code on file save."
  '((emacs "28.1"))
  :url "https://github.com/prettier/prettier-emacs"
  :commit "1ce7a310b000200e333f0015b87d910672ebdb7e"
  :revdesc "1ce7a310b000"
  :keywords '("convenience" "wp" "edit" "js"))
