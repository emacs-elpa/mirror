;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.10.0.20260718.12"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "fb799537a1e37bf3740a7f4f04eb90c08a02b8d8"
  :revdesc "2.10-12-gfb799537a1e3"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
