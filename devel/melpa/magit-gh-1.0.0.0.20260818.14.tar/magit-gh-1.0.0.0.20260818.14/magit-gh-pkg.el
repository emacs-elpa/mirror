;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gh" "1.0.0.0.20260818.14"
  "GitHub CLI integration for Magit."
  '((emacs     "29.1")
    (magit     "4.0.0")
    (transient "0.5.0"))
  :url "https://github.com/jonathanchu/magit-gh"
  :commit "17edb32ace7d4374559e337c927c6e34550c52ba"
  :revdesc "17edb32ace7d"
  :keywords '("git" "tools" "vc" "github")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
