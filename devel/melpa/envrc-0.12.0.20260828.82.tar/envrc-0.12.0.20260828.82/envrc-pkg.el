;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "0.12.0.20260828.82"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "1089ca8215b18216832a6c1599f3610b8f47dfd5"
  :revdesc "1089ca8215b1"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
