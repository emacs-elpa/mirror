;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.1.0.20260801.166"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "160313fb252a98c9109720dfdf528ee408591fc3"
  :revdesc "160313fb252a"
  :keywords '("faces" "files" "q"))
