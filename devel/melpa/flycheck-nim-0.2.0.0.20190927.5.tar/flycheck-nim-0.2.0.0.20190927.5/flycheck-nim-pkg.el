;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-nim" "0.2.0.0.20190927.5"
  "Defines a flycheck syntax checker for nim."
  '((dash     "2.4.0")
    (flycheck "0.20"))
  :url "https://github.com/ALSchwalm/flycheck-nim"
  :commit "ddfade51001571c2399f78bcc509e0aa8eb752a4"
  :revdesc "ddfade510015"
  :authors '(("Adam Schwalm" . "adamschwalm@gmail.com"))
  :maintainers '(("Adam Schwalm" . "adamschwalm@gmail.com")))
