;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "media-progress-dired" "0.1.0.0.20230527.11"
  "Display position where media player stopped in dired buffer."
  '((emacs          "28.1")
    (media-progress "0.1.0"))
  :url "https://github.com/jumper047/media-progress"
  :commit "438a37019383eef35e45875b3e4df3fca4eaf39f"
  :revdesc "438a37019383"
  :keywords '("files" "convenience")
  :authors '(("Dmitriy Pshonko" . "http://github.com/jumper047"))
  :maintainers '(("Dmitriy Pshonko" . "http://github.com/jumper047")))
