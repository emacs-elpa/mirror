;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-apt" "1.1.0.20231005.4"
  "Helm interface for Debian/Ubuntu packages (apt-*)."
  '((helm  "3.9.5")
    (emacs "25.1"))
  :url "https://github.com/emacs-helm/helm-apt"
  :commit "3ddbb62f483d2bbdbfcab4160040eaad22a82d67"
  :revdesc "v1.1-4-g3ddbb62f483d"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
