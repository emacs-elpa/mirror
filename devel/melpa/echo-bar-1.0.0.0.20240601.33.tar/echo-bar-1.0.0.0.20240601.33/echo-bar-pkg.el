;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "echo-bar" "1.0.0.0.20240601.33"
  "Turn the echo area into a custom status bar."
  ()
  :url "https://github.com/qaiviq/echo-bar.el"
  :commit "80f5a8bbd8ac848d4a69796c9568b4a55958e974"
  :revdesc "80f5a8bbd8ac"
  :keywords '("convenience" "tools")
  :authors '(("Adam Tillou" . "qaiviq@gmail.com"))
  :maintainers '(("Adam Tillou" . "qaiviq@gmail.com")))
