;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gobgen" "0.0.1.0.20161020.7"
  "Generate GObject descendants using a detailed form."
  '((emacs "24.4"))
  :url "https://github.com/gergelypolonkai/gobgen.el"
  :commit "ed2c2b0d217deae293096f3cf14aa492791ddd4f"
  :revdesc "ed2c2b0d217d"
  :keywords '("gobject" "glib" "gtk" "helper" "utilities")
  :authors '(("Gergely Polonkai" . "gergely@polonkai.eu"))
  :maintainers '(("Gergely Polonkai" . "gergely@polonkai.eu")))
