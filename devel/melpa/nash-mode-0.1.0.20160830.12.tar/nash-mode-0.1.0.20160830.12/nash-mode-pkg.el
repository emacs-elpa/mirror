;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nash-mode" "0.1.0.20160830.12"
  "Nash major mode."
  ()
  :url "https://github.com/tiago4orion/nash-mode.el"
  :commit "bb7ae728a16812a0ef506483b877f6221c92ca9c"
  :revdesc "bb7ae728a168"
  :keywords '("nash" "languages"))
