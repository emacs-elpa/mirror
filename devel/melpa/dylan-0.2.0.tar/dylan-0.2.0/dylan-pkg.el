;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dylan" "0.2.0"
  "Dylan editing modes."
  '((emacs "25.1"))
  :url "https://opendylan.org/"
  :commit "c22f339b5394d26af4961192825e58ae766965ec"
  :revdesc "c22f339b5394")
