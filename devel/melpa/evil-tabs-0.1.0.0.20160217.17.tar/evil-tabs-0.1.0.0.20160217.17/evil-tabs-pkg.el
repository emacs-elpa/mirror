;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-tabs" "0.1.0.0.20160217.17"
  "Integrating Vim-style tabs for Evil mode users."
  '((evil     "0.0.0")
    (elscreen "0.0.0"))
  :url "https://github.com/krisajenkins/evil-tabs"
  :commit "53d3314a810017b6056ab6796aef671f5ea1c063"
  :revdesc "53d3314a8100"
  :keywords '("evil" "tab" "tabs" "vim")
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
