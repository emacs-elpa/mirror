;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-jira" "0.1.0.20180802.3"
  "Helm bindings for JIRA/Bitbucket/stash."
  '((emacs  "25")
    (cl-lib "0.5")
    (helm   "1.9.9"))
  :url "https://github.com/DeX3/helm-jira"
  :commit "75d6ed5bd7a041fa8c1adb21cbbbe57b5a7c7cc7"
  :revdesc "75d6ed5bd7a0"
  :keywords '("tools" "helm" "jira" "bitbucket" "stash")
  :authors '(("Roman Decker" . "romandotdeckeratgmaildotcom"))
  :maintainers '(("Roman Decker" . "romandotdeckeratgmaildotcom")))
