;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oboe" "2.3"
  "A simple temporary buffer management framework."
  '((emacs "30.1"))
  :url "https://github.com/gynamics/oboe.el"
  :commit "07bd775c04b7c6cf552e34fb7ff5f7df9bb2f81c"
  :revdesc "07bd775c04b7"
  :keywords '("convenience")
  :maintainers '(("gynamics" . "gynamics@coldbench.top")))
