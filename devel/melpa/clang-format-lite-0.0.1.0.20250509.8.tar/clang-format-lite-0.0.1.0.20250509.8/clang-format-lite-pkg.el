;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clang-format-lite" "0.0.1.0.20250509.8"
  "Format code on-save with clang-format, supports remote files."
  ()
  :url "https://github.com/arteen1000/clang-format-lite"
  :commit "46681aada7f93170a7e073332a43f8b19ee7b4c5"
  :revdesc "46681aada7f9"
  :keywords '("tools" "c" "c++" "clang-format" "formatting")
  :authors '(("Arteen Abrishami" . "arteen@ucla.edu"))
  :maintainers '(("Arteen Abrishami" . "arteen@ucla.edu")))
