;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk" "0.7.0.20250908.53"
  "Functions for working with Zettelkasten-style linked notes."
  '((emacs "28.1"))
  :url "https://github.com/localauthor/zk"
  :commit "302e494324066d63f317b54c4db75d173914c521"
  :revdesc "302e49432406"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
