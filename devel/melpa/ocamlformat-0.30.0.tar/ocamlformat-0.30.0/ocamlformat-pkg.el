;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocamlformat" "0.30.0"
  "Utility functions to format ocaml code."
  '((emacs "24.3"))
  :url "https://github.com/ocaml-ppx/ocamlformat"
  :commit "8700adc1dad91f5d38eac7dc857e881c3674db86"
  :revdesc "0.30.0-0-g8700adc1dad9"
  :keywords '("languages" "ocaml"))
