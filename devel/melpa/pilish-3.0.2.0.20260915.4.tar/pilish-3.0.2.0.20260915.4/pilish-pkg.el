;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.0.2.0.20260915.4"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.3.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "1be0e08bf0e84363f7a5dc818c1e0cd218f65dff"
  :revdesc "v3.0.2-4-g1be0e08bf0e8"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
