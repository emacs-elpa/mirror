;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "workgroups2" "1.2.1.0.20230328.104"
  "Save&load multiple named workspaces (or \"workgroups\")."
  '((emacs "25.1"))
  :url "https://github.com/pashinin/workgroups2"
  :commit "aff9d76b7be5eed33f30be2fabf111818749cbd5"
  :revdesc "aff9d76b7be5"
  :keywords '("session" "management" "window-configuration" "persistence")
  :authors '(("Sergey Pashinin" . "sergeyatpashinindotcom"))
  :maintainers '(("Sergey Pashinin" . "sergeyatpashinindotcom")))
