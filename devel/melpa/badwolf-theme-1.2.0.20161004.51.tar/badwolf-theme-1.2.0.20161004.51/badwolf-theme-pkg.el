;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "badwolf-theme" "1.2.0.20161004.51"
  "Bad Wolf color theme."
  '((emacs "24"))
  :url "https://github.com/bkruczyk/badwolf-emacs"
  :commit "ea01a3d9358e968f75e3ed15dec6a2a96ce3d9a1"
  :revdesc "1.2-51-gea01a3d9358e"
  :keywords '("themes")
  :authors '(("bkruczyk" . "bartlomiej.kruczyk@gmail.com"))
  :maintainers '(("bkruczyk" . "bartlomiej.kruczyk@gmail.com")))
