;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difflayer" "0.6.1"
  "Overlay diffs on selected regions."
  '((emacs "29.1"))
  :url "https://github.com/precompute/legit"
  :commit "b27ec3bafa41cd2ccd45336efbe77823fc124927"
  :revdesc "b27ec3bafa41"
  :authors '(("precompute" . "git@precompute.net"))
  :maintainers '(("precompute" . "git@precompute.net")))
