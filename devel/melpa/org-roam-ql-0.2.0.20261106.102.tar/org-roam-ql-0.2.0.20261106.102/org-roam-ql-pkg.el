;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "0.2.0.20261106.102"
  "Interface to query and view results from org-roam."
  '((emacs         "28")
    (org-roam      "2.2.0")
    (s             "1.12.0")
    (magit-section "3.3.0")
    (transient     "0.4")
    (dash          "2.0"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "78860617b61afe5bb6603e2e357e856a3e2f656d"
  :revdesc "78860617b61a")
