;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "0.1.0.0.20260612.44"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.1.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "19523208ee78d6548a8f8ad6aa2e296a6836d4db"
  :revdesc "19523208ee78"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
