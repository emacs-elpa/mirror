;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occult" "1.4.0.0.20260913.2"
  "Collapse and reveal buffer regions."
  '((emacs "29.1"))
  :url "https://github.com/agzam/occult.el"
  :commit "41fd9afdd6a3a8c6e9e3d0ccae89592a8757ad34"
  :revdesc "1.4.0-2-g41fd9afdd6a3"
  :keywords '("convenience")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
