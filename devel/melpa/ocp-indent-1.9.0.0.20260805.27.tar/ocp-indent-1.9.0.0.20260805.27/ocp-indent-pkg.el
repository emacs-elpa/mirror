;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocp-indent" "1.9.0.0.20260805.27"
  "Automatic indentation with ocp-indent."
  ()
  :url "http://www.typerex.org/ocp-indent.html"
  :commit "d5f0d27b3caf7ae2397f8b26ecc5776997643945"
  :revdesc "1.9.0-27-gd5f0d27b3caf"
  :keywords '("ocaml" "languages"))
