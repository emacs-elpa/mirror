;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "togetherly" "0.1.1.0.20170426.2"
  "Allow multiple clients to edit a single buffer online."
  '((cl-lib "0.3"))
  :url "http://hins11.yu-yake.com/"
  :commit "65072b1d5e04c7098c318ebf1af279f596039ef9"
  :revdesc "65072b1d5e04")
