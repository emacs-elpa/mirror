;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-sourcekit" "0.1.0.20260507.39"
  "Sourcekit-lsp client for lsp-mode."
  '((emacs    "29.1")
    (lsp-mode "5"))
  :url "https://github.com/emacs-lsp/lsp-sourcekit"
  :commit "252decc7ae53170eb1c67f97ff3e7f576dd13734"
  :revdesc "252decc7ae53"
  :keywords '("languages" "lsp" "swift" "objective-c" "c++"))
