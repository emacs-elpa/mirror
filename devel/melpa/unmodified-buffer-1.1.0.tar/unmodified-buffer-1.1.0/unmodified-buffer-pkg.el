;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unmodified-buffer" "1.1.0"
  "Auto revert modified buffer state."
  '((emacs "24.1"))
  :url "https://github.com/arthurcgusmao/unmodified-buffer"
  :commit "9095a3f870aa570804a11d75aba0952294199715"
  :revdesc "9095a3f870aa")
