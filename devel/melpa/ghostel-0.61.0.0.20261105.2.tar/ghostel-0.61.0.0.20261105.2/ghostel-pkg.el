;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.61.0.0.20261105.2"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "7bf0ad4c2213eddc4635d3203dedf2530a3ba2fa"
  :revdesc "7bf0ad4c2213"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
