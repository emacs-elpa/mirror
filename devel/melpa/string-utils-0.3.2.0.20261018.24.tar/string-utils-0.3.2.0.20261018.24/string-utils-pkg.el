;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "string-utils" "0.3.2.0.20261018.24"
  "String-manipulation utilities."
  '((emacs      "24.3")
    (list-utils "0.4.2"))
  :url "https://github.com/rolandwalker/string-utils"
  :commit "9a804861bf93fb5fe6bd8020afa68b15ea02003a"
  :revdesc "v0.3.2-24-g9a804861bf93"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
