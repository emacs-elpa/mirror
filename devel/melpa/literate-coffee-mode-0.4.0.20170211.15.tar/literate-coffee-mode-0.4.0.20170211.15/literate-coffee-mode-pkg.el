;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "literate-coffee-mode" "0.4.0.20170211.15"
  "Major-mode for Literate CoffeeScript."
  '((coffee-mode "0.5.0"))
  :url "https://github.com/syohex/emacs-literate-coffee-mode"
  :commit "ef34c3a5b813ef078d44c29887761950ab6821c7"
  :revdesc "ef34c3a5b813"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
