;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "0.3.1.0.20261123.4"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "1ca14ff06a40000977d186df3b73c55d33a8c07f"
  :revdesc "1ca14ff06a40"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
