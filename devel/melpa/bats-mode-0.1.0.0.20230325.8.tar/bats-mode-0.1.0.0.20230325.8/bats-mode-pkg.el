;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bats-mode" "0.1.0.0.20230325.8"
  "Emacs mode for editing and running Bats tests."
  ()
  :url "https://github.com/dougm/bats-mode"
  :commit "fa88930b1baba101ae6474f289a239a236a7d19f"
  :revdesc "fa88930b1bab"
  :keywords '("bats" "tests"))
