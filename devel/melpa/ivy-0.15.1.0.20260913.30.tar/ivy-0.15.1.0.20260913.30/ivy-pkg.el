;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy" "0.15.1.0.20260913.30"
  "Incremental Vertical completYon."
  '((emacs "24.5"))
  :url "https://github.com/abo-abo/swiper"
  :commit "7b267e29cd47b2036eafbc212683a721bd2b7dd0"
  :revdesc "0.15.1-30-g7b267e29cd47"
  :keywords '("matching")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
