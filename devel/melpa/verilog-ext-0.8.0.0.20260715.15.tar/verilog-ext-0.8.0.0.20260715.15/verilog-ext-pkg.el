;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ext" "0.8.0.0.20260715.15"
  "SystemVerilog Extensions."
  '((emacs           "29.1")
    (verilog-mode    "2024.3.1.121933719")
    (verilog-ts-mode "0.5.0")
    (lsp-mode        "8.0.0")
    (rg              "2.3.0")
    (hydra           "0.15.0")
    (apheleia        "3.1")
    (yasnippet       "0.14.0")
    (flycheck        "32")
    (async           "1.9.7"))
  :url "https://github.com/gmlarumbe/verilog-ext"
  :commit "21f1d16840f6f4c544c4ab819a0fc7c86a4127a0"
  :revdesc "21f1d16840f6"
  :keywords '("verilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
