;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260615.128"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "160b063474bac1e37a4f7d442429d7cfc8a9502c"
  :revdesc "160b063474ba"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
