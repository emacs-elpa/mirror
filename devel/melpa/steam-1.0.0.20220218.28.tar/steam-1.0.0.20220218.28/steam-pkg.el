;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "steam" "1.0.0.20220218.28"
  "Organize and launch Steam games."
  '((cl-lib "0.5"))
  :url "https://github.com/Kungsgeten/steam.el"
  :commit "20aa58c5ccd85f6c4f288a14e79adc66e691cd23"
  :revdesc "20aa58c5ccd8"
  :keywords '("games"))
