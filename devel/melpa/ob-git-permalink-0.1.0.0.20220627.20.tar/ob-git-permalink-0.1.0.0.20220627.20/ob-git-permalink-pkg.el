;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-git-permalink" "0.1.0.0.20220627.20"
  "Import GitHub code given a permalink."
  '((emacs "25.1"))
  :url "https://github.com/kijimaD/ob-git-permalink"
  :commit "14224327a6b34c804b0e90d37b80630a80c56c0a"
  :revdesc "14224327a6b3"
  :keywords '("docs" "convenience")
  :authors '(("kijima Daigo" . "norimaking777@gmail.com"))
  :maintainers '(("kijima Daigo" . "norimaking777@gmail.com")))
