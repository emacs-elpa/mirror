;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nova-theme" "0.1.0.0.20260508.43"
  "A dark, pastel color theme."
  '((emacs "24.3"))
  :url "https://github.com/muirmanders/emacs-nova-theme"
  :commit "84915bcaf5b5ac3accd39853a17b59483e38a8ac"
  :revdesc "84915bcaf5b5"
  :keywords '("theme" "dark" "nova" "pastel" "faces")
  :authors '(("Muir Manders" . "muir+emacs@mnd.rs"))
  :maintainers '(("Muir Manders" . "muir+emacs@mnd.rs")))
