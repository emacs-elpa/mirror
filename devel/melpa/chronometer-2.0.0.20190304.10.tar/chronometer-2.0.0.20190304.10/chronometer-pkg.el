;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chronometer" "2.0.0.20190304.10"
  "A [not so] simple chronometer."
  '((emacs "24"))
  :url "https://github.com/marcelotoledo/chronometer"
  :commit "8457b296ef87be339cbe47730b922757d60bdcd5"
  :revdesc "8457b296ef87"
  :keywords '("tools" "convenience")
  :authors '(("Marcelo Toledo" . "marcelo@marcelotoledo.com"))
  :maintainers '(("Marcelo Toledo" . "marcelo@marcelotoledo.com")))
