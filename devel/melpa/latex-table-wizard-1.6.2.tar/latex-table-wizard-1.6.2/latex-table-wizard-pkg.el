;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-table-wizard" "1.6.2"
  "Magic editing of LaTeX tables."
  '((emacs     "27.1")
    (auctex    "12.1")
    (transient "0.3.7"))
  :url "https://github.com/enricoflor/latex-table-wizard"
  :commit "7e30b492ec594e641727fb31d07291e767d0897a"
  :revdesc "7e30b492ec59"
  :keywords '("convenience" "tex")
  :authors '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers '(("Enrico Flor" . "enrico@eflor.net")))
