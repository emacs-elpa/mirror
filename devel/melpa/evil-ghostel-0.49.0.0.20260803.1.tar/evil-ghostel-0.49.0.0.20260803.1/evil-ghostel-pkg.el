;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "0.49.0.0.20260803.1"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.42.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "6fe0b0624f02d199ef07b52cae62300fe3612701"
  :revdesc "6fe0b0624f02"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
