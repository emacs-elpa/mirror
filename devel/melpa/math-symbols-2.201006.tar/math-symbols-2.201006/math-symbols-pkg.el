;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "math-symbols" "2.201006"
  "Math Symbol Input methods and conversion tools."
  ()
  :url "https://github.com/kawabata/math-symbols"
  :commit "091b81cb40ceaff97614999ffe85b572ace182f0"
  :revdesc "091b81cb40ce"
  :keywords '("i18n" "languages" "tex")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
