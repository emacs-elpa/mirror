;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-ipdb" "1.0.0.0.20200722.17"
  "Realgud front-end to ipdb."
  '((realgud       "1.5.0")
    (load-relative "1.3.1")
    (emacs         "25"))
  :url "https://github.com/realgud/realgud-ipdb"
  :commit "f18f907aa4ddd3e59dc19ca296d4ee2dc5e436b0"
  :revdesc "f18f907aa4dd"
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
