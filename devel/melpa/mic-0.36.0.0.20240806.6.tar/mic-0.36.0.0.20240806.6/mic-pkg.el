;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mic" "0.36.0.0.20240806.6"
  "Minimal and combinable configuration manager."
  '((emacs "26.1"))
  :url "https://github.com/ROCKTAKEY/mic"
  :commit "f552ddf397e899e9c2b96ef4e56a08cc8804a1c5"
  :revdesc "v0.36.0-6-gf552ddf397e8"
  :keywords '("convenience")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
