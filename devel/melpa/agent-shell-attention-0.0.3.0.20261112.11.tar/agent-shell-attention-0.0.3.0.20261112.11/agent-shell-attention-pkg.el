;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-attention" "0.0.3.0.20261112.11"
  "Mode-line attention tracker for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.52.2"))
  :url "https://github.com/ultronozm/agent-shell-attention.el"
  :commit "cc099725c41f144975d37abf108a9c879c716171"
  :revdesc "v0.0.3-11-gcc099725c41f"
  :keywords '("convenience")
  :authors '(("Paul D. Nelson" . "ultrono@gmail.com"))
  :maintainers '(("Paul D. Nelson" . "ultrono@gmail.com")))
