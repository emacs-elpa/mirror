;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eopengrok" "1.7.42"
  "Opengrok interface for emacs."
  '((s      "1.9.0")
    (dash   "2.10.0")
    (magit  "2.1.0")
    (cl-lib "0.5"))
  :url "https://github.com/youngker/eopengrok.el"
  :commit "83b1695774f8bdc322e528ade9dffe9b2e93f32a"
  :revdesc "83b1695774f8"
  :keywords '("tools")
  :authors '(("Youngjoo Lee" . "youngker@gmail.com"))
  :maintainers '(("Youngjoo Lee" . "youngker@gmail.com")))
