;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "v-mode" "0.0.1.0.20221007.87"
  "A major mode for the V programming language."
  '((emacs "25.1")
    (dash  "2.17.0")
    (hydra "0.15.0"))
  :url "https://github.com/damon-kwok/v-mode"
  :commit "84f26ab0f0f5b23133292674da9fa4558207c33d"
  :revdesc "84f26ab0f0f5"
  :keywords '("languages" "programming")
  :authors '(("Damon Kwok" . "damon-kwok@outlook.com"))
  :maintainers '(("Damon Kwok" . "damon-kwok@outlook.com")))
