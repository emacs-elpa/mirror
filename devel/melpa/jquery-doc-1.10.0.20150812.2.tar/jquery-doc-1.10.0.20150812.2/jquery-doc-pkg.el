;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jquery-doc" "1.10.0.20150812.2"
  "JQuery api documentation interface for emacs."
  ()
  :url "https://github.com/ananthakumaran/jquery-doc.el"
  :commit "24032284919b942ec27707d929bdd8bf48420062"
  :revdesc "24032284919b"
  :keywords '("docs" "jquery")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
