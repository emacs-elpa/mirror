;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-lint" "1.0.0.0.20260516.63"
  "Async indentation checker."
  '((emacs       "27.1")
    (async-await "1.1")
    (async       "1.9.7")
    (promise     "1.1"))
  :url "https://github.com/conao3/indent-lint.el"
  :commit "3660b10520d78dd545fd0c52d7e7a36dc602492d"
  :revdesc "3660b10520d7"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
