;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cubicle-mode" "1.2.0"
  "Major mode for the Cubicle model checker."
  ()
  :url "https://github.com/cubicle-model-checker/cubicle"
  :commit "7679c8452051ed5c89f891c72c6ada76757fc935"
  :revdesc "7679c8452051")
