;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scpaste" "0.7.0.0.20250706.13"
  "Paste to the web via scp."
  '((htmlize "1.39"))
  :url "https://git.sr.ht/~technomancy/scpaste"
  :commit "5203d3625c34e51433435dc466853aa36f4ebe21"
  :revdesc "0.7.0-13-g5203d3625c34"
  :keywords '("convenience" "hypermedia"))
