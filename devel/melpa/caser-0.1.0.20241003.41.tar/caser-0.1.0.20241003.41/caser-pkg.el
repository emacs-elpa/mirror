;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "caser" "0.1.0.20241003.41"
  "Change text casing from camelCase to UpperCamelCase to dash-case to snake_case."
  '((emacs "29.1"))
  :url "https://hg.sr.ht/~zck/caser.el"
  :commit "6ed8fe13ff6a4c39a831cf51b031a9e9fdcba5ff"
  :revdesc "6ed8fe13ff6a")
