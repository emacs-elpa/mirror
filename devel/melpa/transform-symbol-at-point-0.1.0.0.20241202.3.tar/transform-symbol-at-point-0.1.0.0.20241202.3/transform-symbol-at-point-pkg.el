;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transform-symbol-at-point" "0.1.0.0.20241202.3"
  "Transforming your symbols at point."
  '((emacs     "24")
    (s         "1.12.0")
    (transient "0.3.7"))
  :url "https://github.com/waymondo/transform-symbol-at-point"
  :commit "57911a5065a694bf0b404bde2ebf64b8ee8f5d89"
  :revdesc "57911a5065a6"
  :keywords '("convenience" "tools"))
