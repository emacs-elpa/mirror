;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haskell-snippets" "0.1.0.0.20210228.7"
  "Yasnippets for Haskell."
  '((cl-lib    "0.5")
    (yasnippet "0.8.0"))
  :url "https://github.com/haskell/haskell-snippets"
  :commit "1c29c4a68ce89848b8d371c6510d1de3b586c8b3"
  :revdesc "1c29c4a68ce8"
  :keywords '("snippets" "haskell")
  :authors '(("Luke Hoersten" . "luke@hoersten.org"))
  :maintainers '(("Luke Hoersten" . "luke@hoersten.org")))
