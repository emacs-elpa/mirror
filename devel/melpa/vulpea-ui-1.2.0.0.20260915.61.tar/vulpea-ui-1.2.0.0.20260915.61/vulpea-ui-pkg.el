;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "1.2.0.0.20260915.61"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.5.0")
    (vui    "1.3.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "d0cc70fcb4f1b06e05897288c33783c4cf4a571d"
  :revdesc "v1.2.0-61-gd0cc70fcb4f1"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
