;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-bigquery" "0.0.0.20251201.23"
  "Babel support for BigQuery."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://www.github.com/lhernanz/ob-bigquery"
  :commit "1ee7996e603faad6edc1eda09b51c25841262218"
  :revdesc "1ee7996e603f"
  :keywords '("lisp"))
