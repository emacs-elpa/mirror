;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "take-off" "0.0.1.0.20140531.14"
  "Emacs remote web access."
  '((emacs      "24.3")
    (web-server "0.1.0"))
  :url "https://github.com/tburette/take-off"
  :commit "aa9ea45566fc74febbb6ee9c409ecc4b59246215"
  :revdesc "aa9ea45566fc"
  :authors '(("Thomas Burette" . "burettethomas@gmail.com"))
  :maintainers '(("Thomas Burette" . "burettethomas@gmail.com")))
