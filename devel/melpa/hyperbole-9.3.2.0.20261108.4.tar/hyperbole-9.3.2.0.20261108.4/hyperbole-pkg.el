;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.3.2.0.20261108.4"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "80379ba33b281b3934fbbcf38a144e9053f2729f"
  :revdesc "hyperbole-9.3.2-4-g80379ba33b28"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")
                 ("Mats Lidell" . "matsl@gnu.org")))
