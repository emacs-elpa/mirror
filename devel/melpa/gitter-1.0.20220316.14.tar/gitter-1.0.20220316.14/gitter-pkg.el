;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitter" "1.0.20220316.14"
  "An Emacs Gitter client."
  '((emacs     "24.4")
    (let-alist "1.0.4"))
  :url "https://github.com/xuchunyang/gitter.el"
  :commit "49327c91eb50cfea633af8fd32b0643691d75cb7"
  :revdesc "49327c91eb50"
  :keywords '("gitter" "chat" "client" "internet")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
