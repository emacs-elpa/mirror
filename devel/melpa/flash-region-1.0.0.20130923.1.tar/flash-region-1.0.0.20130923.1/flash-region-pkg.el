;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flash-region" "1.0.0.20130923.1"
  "Flash a region."
  ()
  :url "https://github.com/Fuco1/flash-region"
  :commit "261b3597b23cdd40e5c14262a5687bcc6c1d0901"
  :revdesc "261b3597b23c"
  :keywords '("utility")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
