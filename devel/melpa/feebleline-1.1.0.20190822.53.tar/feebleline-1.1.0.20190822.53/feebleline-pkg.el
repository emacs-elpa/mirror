;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "feebleline" "1.1.0.20190822.53"
  "Replace modeline with a slimmer proxy."
  ()
  :url "https://github.com/tautologyclub/feebleline"
  :commit "b2f2db25cac77817bf0c49ea2cea6383556faea0"
  :revdesc "b2f2db25cac7"
  :authors '(("Benjamin Lindqvist" . "benjamin.lindqvist@gmail.com"))
  :maintainers '(("Benjamin Lindqvist" . "benjamin.lindqvist@gmail.com")))
