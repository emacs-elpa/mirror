;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "region-convert" "1.0.0"
  "Convert string in region by Lisp function."
  '((emacs "24.3"))
  :url "https://github.com/zonuexe/right-click-context"
  :commit "cb3ab0417d7b74e5edd34bf23a70737fc7bf1d3a"
  :revdesc "cb3ab0417d7b"
  :keywords '("region" "convenience")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
