;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gsettings" "1.1.0"
  "GSettings (Gnome) helpers."
  '((emacs    "24.3")
    (dash     "2.16.0")
    (gvariant "1.0.0")
    (s        "1.12.0"))
  :url "https://github.com/wbolster/emacs-gsettings"
  :commit "e911edf0c80f3bb9599b3b628425e510f0acb63f"
  :revdesc "1.1.0-0-ge911edf0c80f"
  :keywords '("languages")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
