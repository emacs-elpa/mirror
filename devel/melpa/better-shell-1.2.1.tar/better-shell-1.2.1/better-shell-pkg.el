;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "better-shell" "1.2.1"
  "Better shell management."
  '((emacs "24.4"))
  :url "https://github.com/killdash9/better-shell"
  :commit "70c787b981caeef8c5f8012b170eb7b9f167cd13"
  :revdesc "70c787b981ca"
  :keywords '("convenience")
  :authors '(("Russell Black" . "(killdash9@github)"))
  :maintainers '(("Russell Black" . "(killdash9@github)")))
