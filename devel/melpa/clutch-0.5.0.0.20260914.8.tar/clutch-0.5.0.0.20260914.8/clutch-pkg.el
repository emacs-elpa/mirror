;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.0.0.20260914.8"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "8cad904556c9ea059bb9259bffadc067b08c3595"
  :revdesc "8cad904556c9"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
