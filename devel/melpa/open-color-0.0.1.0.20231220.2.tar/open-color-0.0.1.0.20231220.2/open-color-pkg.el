;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "open-color" "0.0.1.0.20231220.2"
  "Open Color color palette."
  '((emacs "25.1"))
  :url "https://github.com/a13/open-color.el"
  :commit "4db381311d4b659922566236697a424f5f3fde6f"
  :revdesc "4db381311d4b"
  :keywords '("faces")
  :authors '(("DK" . "a13@users.noreply.github.com"))
  :maintainers '(("DK" . "a13@users.noreply.github.com")))
