;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "1.1.5.0.20260629.2"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "38ceb1d9a1fb3f67acaa11422f49c7ab5e744b52"
  :revdesc "1.1.5-2-g38ceb1d9a1fb"
  :keywords '("frames")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
