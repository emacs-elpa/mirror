;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-flycheck" "0.2.0.0.20260514.12"
  "Show flycheck errors with sideline."
  '((emacs    "28.1")
    (sideline "0.1.1")
    (flycheck "0.14")
    (ht       "2.4"))
  :url "https://github.com/emacs-sideline/sideline-flycheck"
  :commit "ceacbb060c382e31a47b7c7c09da0b42f4d091f5"
  :revdesc "ceacbb060c38"
  :keywords '("convenience" "flycheck")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
