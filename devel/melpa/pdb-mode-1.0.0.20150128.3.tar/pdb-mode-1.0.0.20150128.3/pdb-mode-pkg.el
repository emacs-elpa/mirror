;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdb-mode" "1.0.0.20150128.3"
  "Major mode for editing Protein Data Bank files."
  ()
  :url "http://bondxray.org/software/pdb-mode/"
  :commit "855fb18ebb73b5df30c8d7677c2bcd0f361b138a"
  :revdesc "855fb18ebb73"
  :keywords '("data" "pdb")
  :authors '((nil . "charles.bond@uwa.edu.au"))
  :maintainers '((nil . "aix.bing@gmail.com")))
