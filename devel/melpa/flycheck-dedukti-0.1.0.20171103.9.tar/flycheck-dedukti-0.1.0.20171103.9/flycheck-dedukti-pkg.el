;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-dedukti" "0.1.0.20171103.9"
  "Flycheck integration of Dedukti."
  '((flycheck     "0.19")
    (dedukti-mode "0.1"))
  :url "https://github.com/rafoo/flycheck-dedukti"
  :commit "3dbff5646355f39d57a3ec514f560a6b0082a1cd"
  :revdesc "3dbff5646355"
  :keywords '("convenience" "languages" "tools" "flycheck" "dedukti"))
