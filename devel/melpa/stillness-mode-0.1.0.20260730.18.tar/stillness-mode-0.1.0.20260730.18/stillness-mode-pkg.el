;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stillness-mode" "0.1.0.20260730.18"
  "Prevent windows from jumping on minibuffer activation."
  '((emacs "26.1")
    (dash  "2.18.0"))
  :url "https://github.com/neeasade/stillness-mode.el"
  :commit "aa875fa971c88ad1f79d3a523f0e71fff5511a16"
  :revdesc "aa875fa971c8"
  :keywords '("convenience"))
