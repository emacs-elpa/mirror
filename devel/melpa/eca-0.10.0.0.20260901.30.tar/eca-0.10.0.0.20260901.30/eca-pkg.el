;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "0.10.0.0.20260901.30"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "4d38c357ae1ad5272b1b4ea6f626a16975c88716"
  :revdesc "4d38c357ae1a"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
