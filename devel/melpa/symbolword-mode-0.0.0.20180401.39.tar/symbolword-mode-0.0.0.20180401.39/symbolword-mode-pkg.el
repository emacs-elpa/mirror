;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symbolword-mode" "0.0.0.20180401.39"
  "Modify word split."
  '((emacs "24")
    (f     "0.19.0"))
  :url "https://github.com/ncaq/symbolword-mode"
  :commit "920e57f4c2b09b28c5a0c8fe9ebdba9961822163"
  :revdesc "920e57f4c2b0"
  :authors '(("ncaq" . "ncaq@ncaq.net"))
  :maintainers '(("ncaq" . "ncaq@ncaq.net")))
