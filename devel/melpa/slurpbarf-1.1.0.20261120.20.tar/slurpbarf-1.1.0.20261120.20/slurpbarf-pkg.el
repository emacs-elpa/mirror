;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slurpbarf" "1.1.0.20261120.20"
  "Commands for slurping and barfing."
  '((emacs "29.1"))
  :url "https://codeberg.org/vilij/slurpbarf-elcute"
  :commit "e05b0c63c073e7baf134f1879ee3afea997766c2"
  :revdesc "e05b0c63c073"
  :keywords '("convenience" "lisp" "xml"))
