;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-hacks-utils" "0.0.1.0.20240629.440"
  "Utilities and helpers for dired-hacks collection."
  '((dash  "2.5.0")
    (emacs "24.3"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "63b04d17936c98cb4ad7ce6bc3331cda8e30c55a"
  :revdesc "63b04d17936c"
  :keywords '("files")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
