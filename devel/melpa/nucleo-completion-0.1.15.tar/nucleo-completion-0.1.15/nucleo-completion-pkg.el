;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "0.1.15"
  "Nucleo-backed completion style."
  '((emacs "27.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "0f07a5bcd384716a3b79ab9e82005bb54f721122"
  :revdesc "0f07a5bcd384"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
