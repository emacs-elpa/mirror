;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "2.23.0"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "ea01072d1492e0d0d5832ede596655c8bcc9e4ed"
  :revdesc "ea01072d1492"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
