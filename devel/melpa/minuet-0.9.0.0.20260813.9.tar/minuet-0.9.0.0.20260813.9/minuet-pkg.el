;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "0.9.0.0.20260813.9"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "9e7a7952dcf3e69f70e632530b13ccb245e449a1"
  :revdesc "v0.9.0-9-g9e7a7952dcf3"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
