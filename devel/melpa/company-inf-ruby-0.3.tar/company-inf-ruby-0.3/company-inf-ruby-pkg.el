;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-inf-ruby" "0.3"
  "Company-mode completion back-end for inf-ruby."
  '((company  "0.6.10")
    (inf-ruby "2.2.7")
    (emacs    "24.1"))
  :url "https://github.com/company-mode/company-inf-ruby"
  :commit "9c2eab3bb82e8838c54013026e6ffb51cccbd37e"
  :revdesc "9c2eab3bb82e"
  :authors '(("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainers '(("Dmitry Gutov" . "dgutov@yandex.ru")))
