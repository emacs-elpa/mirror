;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sdcv" "20220210.1412.0.20261002.2"
  "Interface for sdcv (StartDict console version)."
  '((emacs   "24.3")
    (popup   "0.5.3")
    (showtip "0.01")
    (pos-tip "0.4.6")
    (cl-lib  "0.3"))
  :url "https://repo.or.cz/sdcv.el.git"
  :commit "f0dd10f1ecdca7fc20a95fb05fb4b0d5a3fae579"
  :revdesc "f0dd10f1ecdc"
  :keywords '("startdict" "sdcv")
  :authors '(("Andy Stewart" . "lazycat.manatee@gmail.com"))
  :maintainers '(("Andy Stewart" . "lazycat.manatee@gmail.com")
                 (nil . "stardiviner(numbchild@gmail.com")))
