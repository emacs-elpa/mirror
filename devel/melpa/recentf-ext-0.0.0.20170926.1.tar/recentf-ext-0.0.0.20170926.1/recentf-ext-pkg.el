;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recentf-ext" "0.0.0.20170926.1"
  "Recentf extensions."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/download/recentf-ext.el"
  :commit "450de5f8544ed6414e88d4924d7daa5caa55b7fe"
  :revdesc "450de5f8544e"
  :keywords '("convenience" "files")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
