;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpvi" "1.3.0.0.20250831.4"
  "Watch video and take interactive video notes."
  '((emacs "28.1")
    (emms  "11"))
  :url "https://github.com/lorniu/mpvi"
  :commit "79a7bd0559b38b289e5463331a9f25336453f3aa"
  :revdesc "79a7bd0559b3"
  :keywords '("convenience" "docs" "multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
