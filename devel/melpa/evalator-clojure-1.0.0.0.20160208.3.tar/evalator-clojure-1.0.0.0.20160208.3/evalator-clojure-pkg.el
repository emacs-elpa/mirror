;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evalator-clojure" "1.0.0.0.20160208.3"
  "Clojure evaluation context for evalator via CIDER."
  '((cider    "0.10.0")
    (evalator "1.0.0"))
  :url "http://www.github.com/seanirby/evalator-clojure"
  :commit "caa4e0a137bdfada86593128a654e16aa617ad50"
  :revdesc "caa4e0a137bd"
  :keywords '("languages" "clojure" "cider" "helm")
  :maintainers '(("Sean Irby" . "sean.t.irby@gmail.com")))
