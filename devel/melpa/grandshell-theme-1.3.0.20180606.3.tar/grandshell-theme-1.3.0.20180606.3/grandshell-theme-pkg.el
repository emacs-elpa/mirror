;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grandshell-theme" "1.3.0.20180606.3"
  "Grand Shell color theme for Emacs > 24."
  ()
  :url "https://framagit.org/steckerhalter/grandshell-theme"
  :commit "0ed8e4273607dd4fcaa742b4097259233b09eda6"
  :revdesc "0ed8e4273607"
  :keywords '("color" "theme" "grand" "shell" "faces"))
