;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "0.1.3.0.20260808.14"
  "Time window based habits."
  '((emacs "29.1")
    (dash  "2.10.0"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "0f3e9101fed8e51680bfecb4c90849df87d48da8"
  :revdesc "v0.1.3-14-g0f3e9101fed8"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
