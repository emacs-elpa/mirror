;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms-soundcloud" "0.1.0.20131221.7"
  "EMMS source for Soundcloud audio sharing platform."
  '((emms "20131016")
    (json "1.2"))
  :url "https://github.com/osener/emms-soundcloud"
  :commit "87e5cbf9609d1f26c24dc834fdeb78b33d453c2b"
  :revdesc "87e5cbf9609d"
  :keywords '("emms" "soundcloud")
  :authors '(("Ozan Sener" . "ozan@ozansener.com"))
  :maintainers '(("Ozan Sener" . "ozan@ozansener.com")))
