;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.2.1.0.20260721.16"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "3e1ed4e5d2c4a855e7b5b083d925bf5a56236349"
  :revdesc "3e1ed4e5d2c4"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
