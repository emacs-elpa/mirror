;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "2.4"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/osm"
  :commit "d6167ca4f99bead657ac6f7f163c1fcf9b34267f"
  :revdesc "2.4-0-gd6167ca4f99b"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
