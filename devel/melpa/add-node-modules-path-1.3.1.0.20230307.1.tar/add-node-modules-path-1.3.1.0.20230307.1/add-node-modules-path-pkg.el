;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "add-node-modules-path" "1.3.1.0.20230307.1"
  "Add node_modules to your exec-path."
  '((s "1.12.0"))
  :url "https://github.com/codesuki/add-node-modules-path"
  :commit "841e93dfed50448da66c89a977c9182bb18796a1"
  :revdesc "841e93dfed50"
  :keywords '("javascript" "node" "node_modules" "eslint")
  :authors '(("Neri Marschik" . "marschik_neri@cyberagent.co.jp"))
  :maintainers '(("Neri Marschik" . "marschik_neri@cyberagent.co.jp")))
