;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "burly" "0.3.0.20240727.8"
  "Save and restore frame/window configurations with buffers."
  '((emacs "27.1")
    (map   "2.1"))
  :url "https://github.com/alphapapa/burly.el"
  :commit "d5b7133b5b629dd6bca29bb16660a9e472e82e25"
  :revdesc "v0.3-8-gd5b7133b5b62"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
