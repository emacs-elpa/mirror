;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fcopy" "7.0.0.20150304.2"
  "Funny Copy, set past point HERE then search copy text."
  ()
  :url "https://github.com/ataka/fcopy"
  :commit "e355f6ec889d8ecbdb096019c2dc660b1cec4941"
  :revdesc "e355f6ec889d"
  :keywords '("convenience")
  :authors '(("Masayuki Ataka" . "masayuki.ataka@gmail.com"))
  :maintainers '(("Masayuki Ataka" . "masayuki.ataka@gmail.com")))
