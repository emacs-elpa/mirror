;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "closure-lint-mode" "0.1.0.20101118.1"
  "Minor mode for the Closure Linter."
  ()
  :url "https://github.com/r0man/closure-lint-mode"
  :commit "bc3d2fd5c35580bf1b8af43b12484c95a343b4b5"
  :revdesc "bc3d2fd5c355"
  :keywords '("tools" "closure" "javascript" "lint" "flymake")
  :authors '(("Roman Scherer" . "roman@burningswell.com"))
  :maintainers '(("Roman Scherer" . "roman@burningswell.com")))
