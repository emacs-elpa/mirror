;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "1.0.5.0.20261031.2"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "0c7f937161b04d6fe632d9db2a60516051f6442d"
  :revdesc "1.0.5-2-g0c7f937161b0"
  :keywords '("convenience" "files" "tools"))
