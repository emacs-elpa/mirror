;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-visualstar" "0.2.0.0.20260926.3"
  "Starts a * or # search from the visual selection."
  '((emacs "24.4")
    (evil  "0"))
  :url "https://github.com/bling/evil-visualstar"
  :commit "fdad5552a0060272e129e85d011968ec5b65ac52"
  :revdesc "fdad5552a006"
  :keywords '("evil" "vim" "visualstar"))
