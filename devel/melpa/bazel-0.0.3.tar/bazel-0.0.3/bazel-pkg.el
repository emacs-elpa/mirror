;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazelbuild/emacs-bazel-mode"
  :commit "2a418b499cb7b294e2c5616d37fa1d03ad8889c9"
  :revdesc "2a418b499cb7"
  :keywords '("build tools" "languages"))
