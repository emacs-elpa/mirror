;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "0.6.5.0.20260828.17"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "fb372c480d5aa671cc7ebb6e81109a81474f9684"
  :revdesc "fb372c480d5a"
  :keywords '("languages"))
