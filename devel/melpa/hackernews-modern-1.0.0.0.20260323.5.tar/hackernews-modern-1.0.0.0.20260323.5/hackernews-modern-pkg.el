;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hackernews-modern" "1.0.0.0.20260323.5"
  "Hacker News client with modern widget UI."
  '((emacs              "28.1")
    (visual-fill-column "2.2")
    (async-http-queue   "0.1.0"))
  :url "https://git.andros.dev/andros/hackernews-modern-el"
  :commit "a90b247e9ed007b1e9e0a5ef77c08670ba0a3953"
  :revdesc "a90b247e9ed0"
  :keywords '("comm" "hypermedia" "news")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
