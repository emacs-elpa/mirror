;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corsair" "0.1.0.20260505.10"
  "Text accumulation enhancements for GPTel."
  '((emacs "28.1")
    (gptel "0.9.0"))
  :url "https://github.com/rob137/Corsair"
  :commit "412285e1feeba9c6e0e3a103d64396cef1e73d51"
  :revdesc "412285e1feeb"
  :keywords '("convenience" "tools")
  :authors '(("Robert Kirby" . "corsair.el.package@gmail.com"))
  :maintainers '(("Robert Kirby" . "corsair.el.package@gmail.com")))
