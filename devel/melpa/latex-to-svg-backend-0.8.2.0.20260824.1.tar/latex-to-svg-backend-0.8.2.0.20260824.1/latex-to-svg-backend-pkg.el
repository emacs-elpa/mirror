;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-backend" "0.8.2.0.20260824.1"
  "Content-addressed LaTeX-to-SVG image rendering."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/latex-to-svg-backend"
  :commit "37c5159e347f03061240a3acab071e3478bf22c8"
  :revdesc "v0.8.2-1-g37c5159e347f"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
