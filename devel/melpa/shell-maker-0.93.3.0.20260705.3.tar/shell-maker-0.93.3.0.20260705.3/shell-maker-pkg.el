;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.93.3.0.20260705.3"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "55607423f052c6be72b1a5da394427c9faaa413d"
  :revdesc "55607423f052")
