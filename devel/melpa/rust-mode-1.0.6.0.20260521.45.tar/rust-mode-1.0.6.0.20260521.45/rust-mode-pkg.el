;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rust-mode" "1.0.6.0.20260521.45"
  "A major-mode for editing Rust source code."
  '((emacs "25.1"))
  :url "https://github.com/rust-lang/rust-mode"
  :commit "ed401a65743359b8de11ee9ced0e1da39946cefd"
  :revdesc "1.0.6-45-ged401a657433"
  :keywords '("languages")
  :authors '(("Mozilla" . "rust-mode@noreply.github.com"))
  :maintainers '(("Mozilla" . "rust-mode@noreply.github.com")))
