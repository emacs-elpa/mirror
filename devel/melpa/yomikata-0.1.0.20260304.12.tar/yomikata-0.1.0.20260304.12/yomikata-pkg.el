;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yomikata" "0.1.0.20260304.12"
  "Annotates Japanese text with reading tooltips."
  '((emacs "29.1"))
  :url "https://github.com/melissaboiko/yomikata-tips.el"
  :commit "697c04d958a999cf1e65c09b9bc144a67f9d4819"
  :revdesc "697c04d958a9"
  :keywords '("i18n" "mouse" "text")
  :authors '(("Melissa Boiko" . "melissa@namakajiri.net"))
  :maintainers '(("Melissa Boiko" . "melissa@namakajiri.net")))
