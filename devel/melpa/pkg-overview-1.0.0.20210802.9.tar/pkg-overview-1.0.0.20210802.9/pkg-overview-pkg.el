;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pkg-overview" "1.0.0.20210802.9"
  "Make org documentation from elisp source file."
  '((emacs "24.3"))
  :url "https://github.com/Boruch-Baum/emacs-pkg-overview"
  :commit "9b2e416758a6c107bb8cc670ec4d2627f82d5590"
  :revdesc "9b2e416758a6"
  :keywords '("docs" "help" "lisp" "maint" "outlines" "tools")
  :authors '(("Boruch Baum" . "boruch_baum@gmx.com"))
  :maintainers '(("Boruch Baum" . "boruch_baum@gmx.com")))
