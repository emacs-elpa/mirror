;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stumpwm-mode" "0.0.0.20171027.170"
  "Special lisp mode for evaluating code into running stumpwm."
  ()
  :url "https://github.com/stumpwm/stumpwm-contrib"
  :commit "333d210cacc7ebac76e14dfc8c0139f0e399c9a7"
  :revdesc "333d210cacc7"
  :keywords '("comm" "lisp" "tools"))
