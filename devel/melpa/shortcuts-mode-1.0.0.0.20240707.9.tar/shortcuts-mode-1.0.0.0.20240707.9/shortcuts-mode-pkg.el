;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shortcuts-mode" "1.0.0.0.20240707.9"
  "Minor mode providing a buffer shortcut bar."
  '((emacs "25.1"))
  :url "https://github.com/tetron/shortcuts-mode"
  :commit "a781ae97e33f5a0bf75058c21a7784032e22b28d"
  :revdesc "a781ae97e33f"
  :keywords '("lisp")
  :authors '(("Peter Amstutz" . "tetron@interreality.org"))
  :maintainers '(("Peter Amstutz" . "tetron@interreality.org")))
