;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sunburn-theme" "1.0.0.20201216.23"
  "A low contrast color theme."
  '((emacs "24"))
  :url "https://github.com/mvarela/Sunburn-Theme"
  :commit "6b5c14c76dcdfdb099102ef7a388b2f0c6f1951d"
  :revdesc "6b5c14c76dcd"
  :authors '(("Martín Varela" . "(martin@varela.fi)"))
  :maintainers '(("Martín Varela" . "(martin@varela.fi)")))
