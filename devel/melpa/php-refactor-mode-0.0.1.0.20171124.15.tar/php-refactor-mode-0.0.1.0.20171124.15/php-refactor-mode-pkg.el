;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-refactor-mode" "0.0.1.0.20171124.15"
  "Minor mode to quickly and safely perform common refactorings."
  ()
  :url "https://github.com/keelerm84/php-refactor-mode.el"
  :commit "d06dabd9ca743a04067e02282b69d7b7467fb4b7"
  :revdesc "d06dabd9ca74"
  :keywords '("php" "refactor")
  :authors '(("Matthew M. Keeler" . "keelerm84@gmail.com"))
  :maintainers '(("Matthew M. Keeler" . "keelerm84@gmail.com")))
