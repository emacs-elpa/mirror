;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esonify" "0.0.0.20190110.3"
  "Sonify your code."
  '((deferred "0.3.1")
    (cl-lib   "0.5"))
  :url "https://github.com/oflatt/esonify"
  :commit "bdc79d4ab2e3c449b5bef46e5cabc552beeed5c6"
  :revdesc "bdc79d4ab2e3"
  :authors '(("Oliver Flatt" . "oflatt@gmail.com"))
  :maintainers '(("Oliver Flatt" . "oflatt@gmail.com")))
