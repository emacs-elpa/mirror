;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "web" "0.5.2.0.20141231.3"
  "Useful HTTP client."
  '((dash "2.9.0")
    (s    "1.5.0"))
  :url "https://github.com/nicferrier/emacs-web"
  :commit "483188dac4bc6b409b985c9dae45f3324a425efd"
  :revdesc "483188dac4bc"
  :keywords '("lisp" "http" "hypermedia")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
