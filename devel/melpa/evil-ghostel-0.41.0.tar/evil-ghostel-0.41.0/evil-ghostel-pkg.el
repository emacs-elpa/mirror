;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "0.41.0"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.41.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "b8a302bcf48424d5f5965ab84fbbd958616f30db"
  :revdesc "b8a302bcf484"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
