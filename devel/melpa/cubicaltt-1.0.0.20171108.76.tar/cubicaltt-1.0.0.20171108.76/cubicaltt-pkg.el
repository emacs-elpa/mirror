;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cubicaltt" "1.0.0.20171108.76"
  "Mode for cubical type theory."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/mortberg/cubicaltt"
  :commit "a867f3d66172020e30dd0614bd7b50f90b6fddd7"
  :revdesc "a867f3d66172"
  :keywords '("languages"))
