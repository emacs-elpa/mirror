;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-fsharp" "2.0.0.20250403.51"
  "Fsharp-mode eglot integration."
  '((emacs       "27.1")
    (eglot       "1.4")
    (fsharp-mode "1.10")
    (jsonrpc     "1.0.14"))
  :url "https://github.com/fsharp/emacs-fsharp-mode"
  :commit "8d08f057889bcd19812d17d955865428626d8c47"
  :revdesc "8d08f057889b"
  :keywords '("languages")
  :authors '(("Jürgen Hötzel" . "juergen@hoetzel.info"))
  :maintainers '(("Jürgen Hötzel" . "juergen@hoetzel.info")))
