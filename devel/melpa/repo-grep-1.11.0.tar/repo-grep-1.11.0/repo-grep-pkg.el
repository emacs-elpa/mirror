;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repo-grep" "1.11.0"
  "Project-wide grep search."
  '((emacs "27.1"))
  :url "https://github.com/BHFock/repo-grep"
  :commit "237bba04c330e079f04bbd0f03721c97ccffec01"
  :revdesc "1.11.0-0-g237bba04c330"
  :keywords '("tools" "search" "grep" "convenience" "project"))
