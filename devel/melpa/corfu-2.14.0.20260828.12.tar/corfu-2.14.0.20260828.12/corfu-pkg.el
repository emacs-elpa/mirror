;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.14.0.20260828.12"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "c68f993d2df82bfab8a973c6f1af047dc3543093"
  :revdesc "2.14-12-gc68f993d2df8"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
