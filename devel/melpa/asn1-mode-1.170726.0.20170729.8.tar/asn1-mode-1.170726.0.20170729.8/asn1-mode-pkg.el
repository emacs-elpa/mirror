;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asn1-mode" "1.170726.0.20170729.8"
  "ASN.1/GDMO mode for GNU Emacs."
  '((emacs "24.3")
    (s     "1.10.0"))
  :url "https://github.com/kawabata/asn1-mode/"
  :commit "d5d4a8259daf708411699bcea85d322f18beb972"
  :revdesc "d5d4a8259daf"
  :keywords '("languages" "processes" "tools")
  :authors '(("Taichi Kawabata" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi Kawabata" . "kawabata.taichi_at_gmail.com")))
