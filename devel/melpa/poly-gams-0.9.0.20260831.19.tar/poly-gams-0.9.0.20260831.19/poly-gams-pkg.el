;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-gams" "0.9.0.20260831.19"
  "Polymode for GAMS."
  '((emacs     "25")
    (polymode  "0.2.2")
    (gams-mode "6.12"))
  :url "https://github.com/ShiroTakeda/poly-gams"
  :commit "d081611a0ba716fd43e500e05cf70829271775a9"
  :revdesc "d081611a0ba7"
  :keywords '("languages" "multi-modes" "gams"))
