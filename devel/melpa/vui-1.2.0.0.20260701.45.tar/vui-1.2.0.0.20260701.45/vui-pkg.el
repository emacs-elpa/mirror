;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.2.0.0.20260701.45"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "f16a7987f69ae934c5b1d7aab1965013ab3ac80a"
  :revdesc "f16a7987f69a"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
