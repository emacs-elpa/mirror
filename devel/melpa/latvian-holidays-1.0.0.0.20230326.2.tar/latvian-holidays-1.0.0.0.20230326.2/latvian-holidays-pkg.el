;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latvian-holidays" "1.0.0.0.20230326.2"
  "Latvian holidays for the calendar."
  ()
  :url "https://github.com/ashumilov/latvian-holidays"
  :commit "6b82f3bd9682c97f19a65b7d359ce7a02ec9cfec"
  :revdesc "6b82f3bd9682"
  :keywords '("calendar")
  :authors '(("Alexander Shumilov" . "alexander.shumilov@me.com"))
  :maintainers '(("Alexander Shumilov" . "alexander.shumilov@me.com")))
