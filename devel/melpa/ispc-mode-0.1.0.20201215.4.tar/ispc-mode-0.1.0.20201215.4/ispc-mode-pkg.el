;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ispc-mode" "0.1.0.20201215.4"
  "Syntax coloring for ispc programs."
  ()
  :url "https://github.com/Munksgaard/ispc-mode"
  :commit "bedfff2528157d4bb0b75927c459631bebe2b1ce"
  :revdesc "bedfff252815"
  :keywords '("c" "ispc")
  :authors '(("Philip Munksgaard" . "philip@munksgaard.me"))
  :maintainers '(("Philip Munksgaard" . "philip@munksgaard.me")))
