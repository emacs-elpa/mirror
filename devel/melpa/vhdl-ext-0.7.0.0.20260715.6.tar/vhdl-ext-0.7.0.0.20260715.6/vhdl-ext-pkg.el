;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ext" "0.7.0.0.20260715.6"
  "VHDL Extensions."
  '((emacs        "29.1")
    (vhdl-ts-mode "0.3.2")
    (lsp-mode     "8.0.0")
    (rg           "2.3.0")
    (hydra        "0.15.0")
    (flycheck     "32")
    (async        "1.9.7"))
  :url "https://github.com/gmlarumbe/vhdl-ext"
  :commit "7aecaa634140af3b69ac29e7e28cd9309dd872a7"
  :revdesc "7aecaa634140"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
