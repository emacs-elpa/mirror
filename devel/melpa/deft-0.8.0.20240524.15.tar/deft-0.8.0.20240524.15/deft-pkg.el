;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "deft" "0.8.0.20240524.15"
  "Quickly browse, filter, and edit plain text notes."
  ()
  :url "https://jblevins.org/projects/deft/"
  :commit "b369d7225d86551882568788a23c5497b232509c"
  :revdesc "v0.8-15-gb369d7225d86"
  :keywords '("plain text" "notes" "simplenote" "notational velocity")
  :authors '(("Jason R. Blevins" . "jrblevin@xbeta.org"))
  :maintainers '(("Jason R. Blevins" . "jrblevin@xbeta.org")))
