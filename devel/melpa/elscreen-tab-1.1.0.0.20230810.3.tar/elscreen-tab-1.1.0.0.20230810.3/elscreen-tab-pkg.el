;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elscreen-tab" "1.1.0.0.20230810.3"
  "Minor mode to display tabs of elscreen in a dedicated buffer."
  '((emacs    "26")
    (elscreen "20180321")
    (dash     "2.14.1"))
  :url "https://github.com/aki-s/elscreen-tab"
  :commit "21c1f3d3ec47f8b5e31bb0b26b4f60864e49e966"
  :revdesc "1.1.0-3-g21c1f3d3ec47"
  :keywords '("tools" "extensions")
  :authors '(("Aki Syunsuke" . "sunny.day.dev@gmail.com"))
  :maintainers '(("Aki Syunsuke" . "sunny.day.dev@gmail.com")))
