;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dedicated" "1.0.0.0.20151202.2"
  "A very simple minor mode for dedicated buffers."
  ()
  :url "https://github.com/emacsorphanage/dedicated"
  :commit "f47b504c0c56fa5ab9d1028417ca1f65a713a2f0"
  :revdesc "1.0.0-2-gf47b504c0c56"
  :keywords '("dedicated" "buffer")
  :authors '(("Eric Crampton" . "eric@atdesk.com"))
  :maintainers '(("Eric Crampton" . "eric@atdesk.com")))
