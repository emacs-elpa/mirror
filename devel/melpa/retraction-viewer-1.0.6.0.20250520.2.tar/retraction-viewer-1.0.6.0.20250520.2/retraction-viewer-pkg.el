;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "retraction-viewer" "1.0.6.0.20250520.2"
  "View retraction information for current citation."
  '((emacs "27.1")
    (plz   "0.9.1"))
  :url "https://git.sr.ht/~swflint/retraction-viewer"
  :commit "8c913286dcb4bfdbb96c1e87770fae8ec644a966"
  :revdesc "v1.0.6-2-g8c913286dcb4"
  :keywords '("bib" "tex" "data")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
