;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "desktop-mail-user-agent" "0.1.0.20210519.4"
  "Call OS default mail program to compose mail."
  '((emacs "24.3"))
  :url "https://github.com/lassik/emacs-desktop-mail-user-agent"
  :commit "caac672ef7e4ddced960fa31cef3a6ba5d7ab451"
  :revdesc "0.1-4-gcaac672ef7e4"
  :keywords '("mail")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
