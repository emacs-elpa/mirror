;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ts-mode" "0.3.3"
  "VHDL Tree-sitter major mode."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/vhdl-ts-mode"
  :commit "a9bfb0dffb5f994b11b7921d5e145ea40e9a68a2"
  :revdesc "a9bfb0dffb5f"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
