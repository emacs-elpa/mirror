;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ulisp-mode" "0.1.0.0.20240807.7"
  "Major mode for editing and evaluate uLisp."
  '((emacs "25.1"))
  :url "https://codeberg.org/deadblackclover/ulisp-mode"
  :commit "7f52f030e5bf6e98ba9eee75631a6e2b95f90583"
  :revdesc "7f52f030e5bf"
  :keywords '("languages")
  :authors '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com"))
  :maintainers '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com")))
