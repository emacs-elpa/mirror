;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf" "4.1.0.0.20261122.219"
  "Simplify your init.el configuration, extended use-package."
  '((emacs "24.1"))
  :url "https://github.com/conao3/leaf.el"
  :commit "ab9f56cdbefcb539f84184de976716c122adceb2"
  :revdesc "ab9f56cdbefc"
  :keywords '("lisp" "settings")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
