;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpdel" "2.1.1.0.20260114.2"
  "Play and control your MPD music."
  '((emacs    "25.1")
    (libmpdel "1.2.0")
    (navigel  "0.7.0"))
  :url "https://github.com/mpdel/mpdel"
  :commit "64cf50aca68064c2857ed0e5a8fddb2075d97090"
  :revdesc "v2.1.1-2-g64cf50aca680"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
