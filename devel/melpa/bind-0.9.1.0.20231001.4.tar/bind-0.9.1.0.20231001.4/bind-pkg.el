;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bind" "0.9.1.0.20231001.4"
  "Bind commands to keys."
  '((emacs "25.1"))
  :url "https://github.com/repelliuss/bind"
  :commit "4c1698a7c1c9f3d45559c3be871d87d76a1cbe00"
  :revdesc "4c1698a7c1c9"
  :authors '(("repelliuss" . "https://github.com/repelliuss"))
  :maintainers '(("repelliuss" . "repelliuss@gmail.com")))
