;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuff" "0.1.0.20170202.6"
  "Find files with findutils, recursively."
  '((seq "2.3"))
  :url "https://github.com/joelmo/fuff"
  :commit "278e849913df87bd8756c59382282d87474802c3"
  :revdesc "278e849913df"
  :keywords '("files" "project" "convenience"))
