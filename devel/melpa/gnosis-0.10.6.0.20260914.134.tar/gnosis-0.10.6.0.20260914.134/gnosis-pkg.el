;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "0.10.6.0.20260914.134"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "190a68ecaa0fc3f30255985764317c73e558c575"
  :revdesc "190a68ecaa0f"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
