;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term+mux" "0.1.0.20140211.9"
  "Term+ terminal multiplexer and session management."
  '((term+     "0.1")
    (tab-group "0.1"))
  :url "https://github.com/tarao/term+-el"
  :commit "81b60e80cf008472bfd7fad9233af2ef722c208a"
  :revdesc "81b60e80cf00"
  :keywords '("terminal" "emulation")
  :authors '(("INA Lintaro" . "tarao.gnnatgmail.com"))
  :maintainers '(("INA Lintaro" . "tarao.gnnatgmail.com")))
