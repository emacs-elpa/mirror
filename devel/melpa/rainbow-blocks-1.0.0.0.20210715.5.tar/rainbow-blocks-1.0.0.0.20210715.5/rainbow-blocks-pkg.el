;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rainbow-blocks" "1.0.0.0.20210715.5"
  "Block syntax highlighting for lisp code."
  ()
  :url "https://github.com/istib/rainbow-blocks"
  :commit "83c4d6e77a1e25d3d2d124a4e90d5b084f3e15a5"
  :revdesc "1.0.0-5-g83c4d6e77a1e")
