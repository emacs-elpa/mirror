;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amaranth-dark-theme" "0.1.0.0.20251228.2"
  "Amaranth Dark theme."
  '((emacs "24.1"))
  :url "https://github.com/a9sk/amaranth-dark-theme"
  :commit "624e0b5ef632b3adfdc03e44dce7a98cd48d47ed"
  :revdesc "624e0b5ef632"
  :authors '(("Emiliano Rizzonelli" . "emiliano.rizzonelli@proton.me"))
  :maintainers '(("Emiliano Rizzonelli" . "emiliano.rizzonelli@proton.me")))
