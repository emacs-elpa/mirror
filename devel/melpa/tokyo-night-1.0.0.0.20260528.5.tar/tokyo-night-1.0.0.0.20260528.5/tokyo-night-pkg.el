;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "1.0.0.0.20260528.5"
  "Tokyo Night color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "92037072b6e9a48d5d736bf8a76731936ea94410"
  :revdesc "92037072b6e9"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
