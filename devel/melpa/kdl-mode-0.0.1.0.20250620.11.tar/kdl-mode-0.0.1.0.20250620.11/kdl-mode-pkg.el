;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kdl-mode" "0.0.1.0.20250620.11"
  "Major mode for editing KDL files."
  '((emacs "29.1"))
  :url "https://github.com/taquangtrung/emacs-kdl-mode"
  :commit "0723706e1248bf07b2761f630ad0de2393a76aeb"
  :revdesc "0723706e1248"
  :keywords '("languages"))
