;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20261124.376"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "5c2280b480cbcab90462213d74fbfb06ec528325"
  :revdesc "5c2280b480cb")
