;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transmission" "0.12.2.0.20250524.37"
  "Interface to a Transmission session."
  '((emacs     "24.4")
    (let-alist "1.0.5"))
  :url "https://github.com/holomorph/transmission"
  :commit "ae36637fe63e530c7b8baa59bf566a99e40fbfe4"
  :revdesc "0.12.2-37-gae36637fe63e"
  :keywords '("comm" "tools")
  :authors '(("Mark Oteiza" . "mvoteiza@udel.edu"))
  :maintainers '(("Mark Oteiza" . "mvoteiza@udel.edu")))
