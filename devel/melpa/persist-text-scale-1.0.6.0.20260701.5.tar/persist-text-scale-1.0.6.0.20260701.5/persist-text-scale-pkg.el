;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "1.0.6.0.20260701.5"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "7de30c4f49b88c7981b0a82f70e9909d8397173c"
  :revdesc "1.0.6-5-g7de30c4f49b8"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
