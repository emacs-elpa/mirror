;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zone-sl" "1.160201"
  "Zone out with steam locomotives."
  '((emacs "24.3"))
  :url "https://github.com/kawabata/zone-sl"
  :commit "737b21b4b35c28a487ad8a31598e745bc183b209"
  :revdesc "737b21b4b35c"
  :keywords '("games")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
