;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.53.0.0.20260913.5"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "9bf8c7a7f624eaba60d46b7b1123d29c39a2f4da"
  :revdesc "9bf8c7a7f624"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
