;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-alert" "1.4.0"
  "Notifications when commands complete in term.el and eat."
  '((emacs    "24.0")
    (term-cmd "1.1.0")
    (alert    "1.1")
    (f        "0.18.2"))
  :url "https://codeberg.org/calliecameron/term-alert"
  :commit "e52a4dde17e04dc8e1cd63742f92dc551fdad1a9"
  :revdesc "v1.4.0-0-ge52a4dde17e0"
  :keywords '("notifications" "processes")
  :authors '(("Callie Cameron" . "cjcameron7@gmail.com"))
  :maintainers '(("Callie Cameron" . "cjcameron7@gmail.com")))
