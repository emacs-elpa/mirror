;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-clolyze" "1.0.0"
  "Add Clolyze to to flycheck."
  '((flycheck "0.25")
    (emacs    "24"))
  :url "https://github.com/DLaps/flycheck-clolyze"
  :commit "9a3300eac22a7ff96accf37fa2d761c13cc38020"
  :revdesc "9a3300eac22a"
  :authors '(("Daniel Laps" . "daniel.laps@hhu.de"))
  :maintainers '(("Daniel Laps" . "daniel.laps@hhu.de")))
