;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-spotify" "0.5.2"
  "Control Spotify search and select music with Ivy."
  '((emacs "25.1")
    (ivy   "0.13.0"))
  :url "https://github.com/Lautaro-Garcia/counsel-spotify"
  :commit "2743ad52a9def53534fd505397fbe1ac49e53015"
  :revdesc "2743ad52a9de"
  :authors '(("Lautaro García" . "https://github.com/Lautaro-Garcia"))
  :maintainers '(("Lautaro García" . "https://github.com/Lautaro-Garcia")))
