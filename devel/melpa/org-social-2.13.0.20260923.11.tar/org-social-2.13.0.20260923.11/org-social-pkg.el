;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "2.13.0.20260923.11"
  "An Org-social client."
  '((emacs            "30.1")
    (org              "9.0")
    (request          "0.3.0")
    (seq              "2.20")
    (emojify          "1.2")
    (async-http-queue "0.1"))
  :url "https://git.andros.dev/org-social/org-social.el"
  :commit "1037ec1b03d3afbb418bec7aa3e21d2b10a1bbba"
  :revdesc "1037ec1b03d3"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
