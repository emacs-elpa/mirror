;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "2.5.0.0.20260930.64"
  "Interface to Docker."
  '((aio       "1.2")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "4f76b01a0f0ad71bdc22bad2d8846d8c48ef1955"
  :revdesc "2.5.0-64-g4f76b01a0f0a"
  :keywords '("files" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
