;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-firefox" "1.3.0.20260826.13"
  "Firefox bookmarks."
  '((helm   "1.5")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/emacs-helm/helm-firefox"
  :commit "e91c290574df3ad514fc2bb3ffb3851fcadd0157"
  :revdesc "v1.3-13-ge91c290574df")
