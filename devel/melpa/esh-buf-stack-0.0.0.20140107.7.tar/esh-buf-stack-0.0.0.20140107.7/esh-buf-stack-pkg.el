;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esh-buf-stack" "0.0.0.20140107.7"
  "Add a buffer stack feature to Eshell."
  ()
  :url "https://github.com/tom-tan/esh-buf-stack"
  :commit "ea5da9ce8566ffe2e013f0e588701cb0825258b6"
  :revdesc "ea5da9ce8566"
  :keywords '("eshell" "extensions")
  :authors '(("Tomoya Tanjo" . "ttanjo@gmail.com"))
  :maintainers '(("Tomoya Tanjo" . "ttanjo@gmail.com")))
