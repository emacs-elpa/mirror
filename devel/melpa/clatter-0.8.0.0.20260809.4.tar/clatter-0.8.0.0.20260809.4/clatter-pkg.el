;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.8.0.0.20260809.4"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "c2204dbcec0260b34e799a3c4f68b941522fed27"
  :revdesc "v0.8.0-4-gc2204dbcec02"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
