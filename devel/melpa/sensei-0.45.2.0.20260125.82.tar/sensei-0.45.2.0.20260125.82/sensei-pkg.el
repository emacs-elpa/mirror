;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sensei" "0.45.2.0.20260125.82"
  "A client for sensei."
  '((emacs      "27.1")
    (projectile "2.5.0")
    (request    "0.3.2"))
  :url "https://abailly.github.io/sensei"
  :commit "4257ca13aaabfeee7be245e1efd00a5b189e7c9a"
  :revdesc "4257ca13aaab"
  :keywords '("hypermedia")
  :authors '(("Arnaud Bailly" . "arnaud@pankzsoft.com"))
  :maintainers '(("Arnaud Bailly" . "arnaud@pankzsoft.com")))
