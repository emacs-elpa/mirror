;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browsel" "0.94.0.20260726.5"
  "WebSocket bridge to a Chrome/Firefox extension."
  '((emacs     "27.1")
    (websocket "1.13")
    (org       "9.8"))
  :url "https://github.com/dmgerman/browsel"
  :commit "5dfb28fbfc92480c9175e0dd99ba4b397cb5bc0b"
  :revdesc "5dfb28fbfc92"
  :keywords '("comm" "tools" "browser" "org")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
