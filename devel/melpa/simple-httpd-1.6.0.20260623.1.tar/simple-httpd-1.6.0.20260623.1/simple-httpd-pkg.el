;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "1.6.0.20260623.1"
  "Pure Elisp HTTP server."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "ceb208f96601be09397fc9e64fa96014ac1c8739"
  :revdesc "1.6-1-gceb208f96601"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
