;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enlive" "0.0.1.0.20170725.2"
  "Query html document with css selectors."
  ()
  :url "https://github.com/zweifisch/enlive"
  :commit "604a8ca272b6889f114e2b5a13adb5b1dc4bae86"
  :revdesc "604a8ca272b6"
  :keywords '("css" "selector" "query")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
