;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "2.0.20261117.431"
  "Org's *bold*, [[links]], red:text work in details, graph, math."
  '((s     "1.13.1")
    (dash  "2.18.1")
    (emacs "28.2")
    (org   "9.8")
    (lf    "26.10.1")
    (seq   "2.0"))
  :url "https://alhassy.com/org-special-block-extras"
  :commit "8c6e5b3845f0bc8fb10f4d665faf58ed31a7474b"
  :revdesc "8c6e5b3845f0"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
