;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "1.6.0.20261105.6"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "c0e293f798ef1c908ec6e3567e703d36f9b66c20"
  :revdesc "c0e293f798ef"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
