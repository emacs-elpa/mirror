;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sakura-theme" "1.0.1.0.20240921.6"
  "Filled with cherry blossoms."
  '((autothemer "0.2")
    (emacs      "24"))
  :url "https://github.com/emacsfodder/emacs-theme-sakura"
  :commit "22d36d0a9b05e4e24ec701c585145b032e42bc7a"
  :revdesc "22d36d0a9b05"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
