;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mhc" "1.2.7.0.20250904.11"
  "Message Harmonized Calendaring system."
  '((calfw "20150703"))
  :url "http://www.quickhack.net/mhc"
  :commit "2e5e6260363744f124bd0ca22ac7d5962e32fd87"
  :revdesc "v1.2.7-11-g2e5e62603637"
  :keywords '("calendar")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
