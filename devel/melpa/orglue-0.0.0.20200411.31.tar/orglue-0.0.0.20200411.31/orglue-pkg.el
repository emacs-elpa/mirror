;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orglue" "0.0.0.20200411.31"
  "More functionality to org-mode."
  '((org  "9.3")
    (epic "0.2"))
  :url "https://github.com/yoshinari-nomura/orglue"
  :commit "9d5a8e24be9acb8c55bb4d6aa8b98e30e2677401"
  :revdesc "9d5a8e24be9a"
  :keywords '("org")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
