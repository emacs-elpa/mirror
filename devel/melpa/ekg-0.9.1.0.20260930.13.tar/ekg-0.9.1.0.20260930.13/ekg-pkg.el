;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.1.0.20260930.13"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "d9a22b88f3c0d7f3b6d7295bab0449288d24d13c"
  :revdesc "d9a22b88f3c0"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
