;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotate" "1.4.3.0.20260514.244"
  "Annotate files without changing them."
  '((emacs "27.1"))
  :url "https://github.com/bastibe/annotate.el"
  :commit "347525024f319ab50735ef324e8900aecda3724c"
  :revdesc "347525024f31"
  :maintainers '(("Bastian Bechtold" . "bastibe.dev@mailbox.org")
                 ("cage" . "cage-dev@twistfold.it")))
