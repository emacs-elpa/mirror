;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "1.3.1.0.20261028.8"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "7953bf66397d0da3c6378b6885cad5ed73993fcc"
  :revdesc "1.3.1-8-g7953bf66397d"
  :keywords '("convenience" "frames" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
