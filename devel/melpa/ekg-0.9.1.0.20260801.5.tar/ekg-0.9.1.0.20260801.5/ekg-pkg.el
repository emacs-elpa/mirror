;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.1.0.20260801.5"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "a36218cf6e645d9ef451cb3935efeb507005f019"
  :revdesc "a36218cf6e64"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
