;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-cursor" "0.2.0.20221221.1"
  "Change cursor automatically depending on mode."
  '((emacs "25.1"))
  :url "https://github.com/duckwork/electric-cursor"
  :commit "bc09aa8c5d3cc32e3e6452cbf8018fc1ea772b73"
  :revdesc "bc09aa8c5d3c"
  :keywords '("terminals" "frames")
  :authors '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainers '(("Case Duckworth" . "acdw@acdw.net")))
