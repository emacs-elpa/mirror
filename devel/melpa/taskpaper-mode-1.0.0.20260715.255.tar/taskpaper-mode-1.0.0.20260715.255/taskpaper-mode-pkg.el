;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskpaper-mode" "1.0.0.20260715.255"
  "Major mode for TaskPaper files."
  '((emacs "25.1"))
  :url "https://github.com/saf-dmitry/taskpaper-mode"
  :commit "0f8747a8736a6e1bff6cc401144799bdef0e69ed"
  :revdesc "0f8747a8736a"
  :keywords '("outlines" "notetaking" "task management" "productivity" "taskpaper")
  :authors '(("Dmitry Safronov" . "saf.dmitry@gmail.com"))
  :maintainers '(("Dmitry Safronov" . "saf.dmitry@gmail.com")))
