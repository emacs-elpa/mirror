;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mark-thing-at" "1.1.0"
  "Mark a pattern at the current point."
  '((emacs          "26")
    (choice-program "0.14"))
  :url "https://github.com/plandes/mark-thing-at"
  :commit "a9a6c824ede52825a1dea8d880776ad20f12f488"
  :revdesc "v1.1.0-0-ga9a6c824ede5"
  :keywords '("mark" "point" "lisp"))
