;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "0.4.1.0.20260902.3"
  "Highlight window and cursor at switching."
  '((emacs "26.1"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "484a21c502eb3d136008e45b36112b0fb0a77aad"
  :revdesc "484a21c502eb"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
