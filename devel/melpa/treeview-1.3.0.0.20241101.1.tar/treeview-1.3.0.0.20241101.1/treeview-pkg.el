;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treeview" "1.3.0.0.20241101.1"
  "A generic tree navigation library."
  '((emacs "25.1"))
  :url "https://github.com/tilmanrassy/emacs-treeview"
  :commit "9a1a16f84fc3c368443641f7a71aa2407ad91d38"
  :revdesc "v1.3.0-1-g9a1a16f84fc3"
  :keywords '("lisp" "tools" "internal" "convenience")
  :authors '(("Tilman Rassy" . "tilman.rassy@googlemail.com"))
  :maintainers '(("Tilman Rassy" . "tilman.rassy@googlemail.com")))
