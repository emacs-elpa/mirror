;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitignore-templates" "1.0.0.20210814.2"
  "Create .gitignore using GitHub or gitignore.io API."
  '((emacs "24.3"))
  :url "https://github.com/xuchunyang/gitignore-templates.el"
  :commit "d28cd1cec00242b688861648d36d086818b06099"
  :revdesc "d28cd1cec002"
  :keywords '("tools"))
