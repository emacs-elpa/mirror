;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "binclock" "1.12"
  "Display the current time using a binary clock."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/davep/binclock.el"
  :commit "aac5a907be45d4b1225188440f4bc7c5dcae68f7"
  :revdesc "aac5a907be45"
  :keywords '("games" "time" "display")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
