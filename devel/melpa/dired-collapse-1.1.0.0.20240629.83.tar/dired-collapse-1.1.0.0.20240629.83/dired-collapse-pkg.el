;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-collapse" "1.1.0.0.20240629.83"
  "Collapse unique nested paths in dired listing."
  '((f                 "0.19.0")
    (s                 "1.13.1")
    (dired-hacks-utils "0.0.1")
    (emacs             "24"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "d1a85901c892ba7ec273995070a43cbbbe5d0b37"
  :revdesc "d1a85901c892"
  :keywords '("files")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
