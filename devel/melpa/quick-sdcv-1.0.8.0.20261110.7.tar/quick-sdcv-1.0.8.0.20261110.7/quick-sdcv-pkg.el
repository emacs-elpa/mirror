;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "1.0.8.0.20261110.7"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "c689c93fad9be15dca8f8d45ae19a8ca78d65563"
  :revdesc "1.0.8-7-gc689c93fad9b"
  :keywords '("tools" "convenience" "text"))
