;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-emmet" "0.0.0.20131015.10"
  "Auto-complete sources for emmet-mode's snippets."
  '((emmet-mode    "1.0.2")
    (auto-complete "1.4"))
  :url "https://github.com/yasuyk/ac-emmet"
  :commit "88f24876ee3b759978d4614a758280b5d512d543"
  :revdesc "88f24876ee3b"
  :keywords '("completion" "convenience" "emmet")
  :authors '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
