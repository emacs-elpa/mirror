;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "0.1.1.0.20260826.30"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "43744a5591e43022d53bb1743bde1961b018fc91"
  :revdesc "43744a5591e4"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
