;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sbt-mode" "2.0.0.0.20261102.36"
  "Interactive support for sbt projects."
  '((emacs "24.4"))
  :url "https://github.com/hvesalai/emacs-sbt-mode"
  :commit "3da084aa438179913f1fdd770f0be136c6f66322"
  :revdesc "v2.0.0-36-g3da084aa4381"
  :keywords '("languages"))
