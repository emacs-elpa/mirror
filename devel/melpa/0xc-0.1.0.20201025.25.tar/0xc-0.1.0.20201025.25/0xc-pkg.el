;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "0xc" "0.1.0.20201025.25"
  "Base conversion made easy."
  '((emacs "24.4")
    (s     "1.11.0"))
  :url "https://github.com/AdamNiederer/0xc"
  :commit "5bd6c0c901d03d1f24a3ddcf3a62d3b6d2428c80"
  :revdesc "5bd6c0c901d0"
  :keywords '("base" "conversion")
  :authors '(("Adam Niederer" . "adam.niederer@gmail.com"))
  :maintainers '(("Adam Niederer" . "adam.niederer@gmail.com")))
