;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cypher-mode" "0.0.6.0.20151110.12"
  "Major mode for editing cypher scripts."
  ()
  :url "https://github.com/fxbois/cypher-mode"
  :commit "ce8543d7877c736c574a17b49874c9dcdc7a06d6"
  :revdesc "ce8543d7877c"
  :keywords '("cypher" "graph")
  :authors '(("François-Xavier Bois" . "fxboisATGoogleMailService")))
