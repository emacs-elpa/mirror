;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-autoexport" "1.2.0.20250502.4"
  "Auto-export org file on save."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://git.sr.ht/~zondo/org-autoexport"
  :commit "90b8646ad1c8d658fcb142b34a3cdecc1f48b469"
  :revdesc "90b8646ad1c8"
  :keywords '("org" "wp")
  :authors '(("Glenn Hutchings" . "zondo42@gmail.com"))
  :maintainers '(("Glenn Hutchings" . "zondo42@gmail.com")))
