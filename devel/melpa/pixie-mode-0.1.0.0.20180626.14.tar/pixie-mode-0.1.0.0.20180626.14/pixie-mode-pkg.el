;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pixie-mode" "0.1.0.0.20180626.14"
  "Major mode for Pixie-lang."
  '((clojure-mode "3.0.1")
    (inf-clojure  "1.0.0"))
  :url "https://github.com/johnwalker/pixie-mode"
  :commit "a40c2632cfbe948852a5cdcfd44e6a65db11834d"
  :revdesc "a40c2632cfbe"
  :authors '(("John Walker" . "john.lou.walker@gmail.com"))
  :maintainers '(("John Walker" . "john.lou.walker@gmail.com")))
