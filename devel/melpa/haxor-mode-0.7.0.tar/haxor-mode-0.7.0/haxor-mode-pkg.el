;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haxor-mode" "0.7.0"
  "Major mode for editing Haxor Assembly Files."
  '((emacs "24.0"))
  :url "https://github.com/krzysztof-magosa/haxor-mode"
  :commit "6fa25a8e6b6a59481bc0354c2fe1e0ed53cbdc91"
  :revdesc "6fa25a8e6b6a"
  :keywords '("haxor")
  :authors '(("Krzysztof Magosa" . "krzysztof@magosa.pl"))
  :maintainers '(("Krzysztof Magosa" . "krzysztof@magosa.pl")))
