;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bibtex-capf" "1.0.0.20260726.12"
  "Completion at point for bibtex."
  '((emacs    "27.1")
    (parsebib "3.0")
    (org      "9.5"))
  :url "https://codeberg.org/mclear-tools/bibtex-capf"
  :commit "a8312160b0cd568f1ce6d0328e33ae890a5d5b9e"
  :revdesc "a8312160b0cd"
  :keywords '("bibtex" "convenience"))
