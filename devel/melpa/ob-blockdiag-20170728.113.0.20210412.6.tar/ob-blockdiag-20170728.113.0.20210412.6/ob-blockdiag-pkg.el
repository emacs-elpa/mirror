;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-blockdiag" "20170728.113.0.20210412.6"
  "Org-babel functions for blockdiag evaluation."
  ()
  :url "https://github.com/corpix/ob-blockdiag.el"
  :commit "e997644e81cc67a7092e6e9bb13c66f160491efb"
  :revdesc "e997644e81cc"
  :keywords '("tools" "convenience"))
