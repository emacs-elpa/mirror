;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maces-game" "0.1.0.20170903.15"
  "Another anagram game."
  '((dash   "2.12.0")
    (cl-lib "0.5")
    (emacs  "24"))
  :url "https://github.com/pawelbx/anagram-game"
  :commit "6a067422d305ac51612842930ed6686dc615ffec"
  :revdesc "6a067422d305"
  :keywords '("games" "word games" "anagram")
  :authors '(("Pawel Bokota" . "pawelb.lnx@gmail.com"))
  :maintainers '(("Pawel Bokota" . "pawelb.lnx@gmail.com")))
