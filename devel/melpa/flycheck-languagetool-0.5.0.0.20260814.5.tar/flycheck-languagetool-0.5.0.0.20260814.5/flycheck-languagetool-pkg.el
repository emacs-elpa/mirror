;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-languagetool" "0.5.0.0.20260814.5"
  "Flycheck support for LanguageTool."
  '((emacs    "27.1")
    (flycheck "38"))
  :url "https://github.com/emacs-languagetool/flycheck-languagetool"
  :commit "722071e6c49331cc2c9ee14ed9f228dd6ac489d9"
  :revdesc "722071e6c493"
  :keywords '("convenience" "grammar" "check")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com")
             ("Peter Oliver" . "git@mavit.org.uk"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Peter Oliver" . "git@mavit.org.uk")))
