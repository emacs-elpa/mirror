;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-leading-spaces" "0.1.0.20151216.6"
  "Highlight leading spaces."
  '((emacs "24.4"))
  :url "https://github.com/mrBliss/highlight-leading-spaces"
  :commit "840db19d863dd97993fd9f893f5be501627b6354"
  :revdesc "840db19d863d"
  :authors '(("Thomas Winant" . "dewinant@gmail.com"))
  :maintainers '(("Thomas Winant" . "dewinant@gmail.com")))
