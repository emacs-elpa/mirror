;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shelldon" "1.0.0.20220325.28"
  "An enhanced shell interface."
  '((emacs "27.1"))
  :url "https://github.com/Overdr0ne/shelldon"
  :commit "8d073ce580e7782ed863fc6e19dc33b4f73c0d79"
  :revdesc "8d073ce580e7"
  :keywords '("tools" "convenience")
  :authors '(("overdr0ne" . "scmorris.dev@gmail.com"))
  :maintainers '(("overdr0ne" . "scmorris.dev@gmail.com")))
