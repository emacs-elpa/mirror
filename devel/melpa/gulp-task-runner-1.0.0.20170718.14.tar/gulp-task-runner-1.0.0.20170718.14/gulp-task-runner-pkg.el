;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gulp-task-runner" "1.0.0.20170718.14"
  "Gulp task runner."
  ()
  :url "https://github.com/NicolasPetton/gulp-task-runner"
  :commit "877990e956b1d71e2d9c7c3e5a129ad199b9debb"
  :revdesc "877990e956b1"
  :keywords '("convenience" "javascript")
  :authors '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")))
