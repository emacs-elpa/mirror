;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bury-successful-compilation" "0.1.2.0.20181106.1"
  "Bury the *compilation* buffer after successful compilation."
  ()
  :url "https://github.com/EricCrosson/bury-successful-compilation"
  :commit "674644c844184605a1bb4f9487a60f7a780a6fe7"
  :revdesc "674644c84418"
  :keywords '("compilation")
  :authors '(("Eric Crosson" . "esc@ericcrosson.com"))
  :maintainers '(("Eric Crosson" . "esc@ericcrosson.com")))
