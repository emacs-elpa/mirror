;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "splitter" "0.1.0.0.20170809.12"
  "Manage window splits."
  ()
  :url "https://github.com/chumpage/chumpy-windows"
  :commit "6bdb51e9a346907d60a9625f6180bddd06be6674"
  :revdesc "6bdb51e9a346"
  :keywords '("frames" "convenience"))
