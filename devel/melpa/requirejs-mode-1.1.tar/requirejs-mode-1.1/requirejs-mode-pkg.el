;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "requirejs-mode" "1.1"
  "Improved AMD module management."
  ()
  :url "https://github.com/moricard/requirejs-mode"
  :commit "011849043098b6c4f27571625ae19071b53b8824"
  :revdesc "011849043098"
  :keywords '("javascript" "amd" "requirejs")
  :authors '(("Marc-Olivier Ricard" . "marco.ricard@gmail.com"))
  :maintainers '(("Marc-Olivier Ricard" . "marco.ricard@gmail.com")))
