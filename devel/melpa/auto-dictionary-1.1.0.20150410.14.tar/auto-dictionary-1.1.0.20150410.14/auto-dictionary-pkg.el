;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-dictionary" "1.1.0.20150410.14"
  "Automatic dictionary switcher for flyspell."
  ()
  :url "http://nschum.de/src/emacs/auto-dictionary/"
  :commit "b364e08009fe0062cf0927d8a0582fad5a12b8e7"
  :revdesc "1.1-14-gb364e08009fe"
  :keywords '("wp")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
