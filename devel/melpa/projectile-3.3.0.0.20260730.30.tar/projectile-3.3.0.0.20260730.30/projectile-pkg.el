;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.3.0.0.20260730.30"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "c94499f4f627112fdaae1cdb67e564c231174109"
  :revdesc "c94499f4f627"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
