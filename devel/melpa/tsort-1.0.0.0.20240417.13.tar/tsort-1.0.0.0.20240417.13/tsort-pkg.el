;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tsort" "1.0.0.0.20240417.13"
  "Topological sort for Emacs Lisp."
  '((emacs  "24.4")
    (compat "29.1.4.2"))
  :url "https://github.com/ehawkvu/tsort.el"
  :commit "32e4f5b7b6de6f012a51f3d7ec151579d7b3e4a7"
  :revdesc "32e4f5b7b6de"
  :keywords '("algorithm" "tools")
  :authors '(("Ethan Hawk" . "ethan.hawk@valpo.edu"))
  :maintainers '(("Ethan Hawk" . "ethan.hawk@valpo.edu")))
