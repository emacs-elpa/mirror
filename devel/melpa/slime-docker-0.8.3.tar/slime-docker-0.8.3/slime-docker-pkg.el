;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime-docker" "0.8.3"
  "Integration of SLIME with Docker containers."
  '((emacs        "24.4")
    (slime        "2.16")
    (docker-tramp "0.1"))
  :url "https://gitlab.common-lisp.net/cl-docker-images/slime-docker"
  :commit "c7d073720f2bd8e9f72a20309fff2afa4c4e798d"
  :revdesc "0.8.3-0-gc7d073720f2b"
  :keywords '("docker" "lisp" "slime"))
