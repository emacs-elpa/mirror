;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idle-require" "1.0.0.20090715.3"
  "Load elisp libraries while Emacs is idle."
  ()
  :url "http://nschum.de/src/emacs/idle-require/"
  :commit "33592bb098223b4432d7a35a1d65ab83f47c1ec1"
  :revdesc "33592bb09822"
  :keywords '("internal")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
