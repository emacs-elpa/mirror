;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "benchstat" "1.0.0.0.20171014.5"
  "Proper benchmarking made simple."
  ()
  :url "https://github.com/Quasilyte/benchstat.el"
  :commit "fee86f521f22ef0f99564903d63e2023b591fc7f"
  :revdesc "v1.0.0-5-gfee86f521f22"
  :keywords '("lisp")
  :authors '(("Iskander Sharipov" . "quasilyte@gmail.com"))
  :maintainers '(("Iskander Sharipov" . "quasilyte@gmail.com")))
