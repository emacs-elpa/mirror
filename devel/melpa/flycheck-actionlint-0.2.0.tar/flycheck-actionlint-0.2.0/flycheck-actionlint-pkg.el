;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-actionlint" "0.2.0"
  "Flycheck integration for actionlint."
  '((emacs    "26")
    (flycheck "32"))
  :url "https://github.com/tirimia/flycheck-actionlint"
  :commit "f3baf396b534f8b874d3ae885cc1dd53b5098dff"
  :revdesc "f3baf396b534"
  :keywords '("convenience" "github" "linter" "flycheck"))
