;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-patch" "3.1.1.0.20260907.1"
  "Future-proof your Elisp."
  '((emacs "26"))
  :url "https://github.com/radian-software/el-patch"
  :commit "6eefe13ac8d985c730c83b676cee9c55579eeb91"
  :revdesc "6eefe13ac8d9"
  :keywords '("extensions")
  :authors '(("Radian LLC" . "contact+el-patch@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+el-patch@radian.codes")))
