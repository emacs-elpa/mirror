;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.4.0.0.20260811.5"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "fcd8f2b7d9e67623bfcdcb3ab874d31016badeae"
  :revdesc "fcd8f2b7d9e6"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
