;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-sync-snippets" "1.0.0.20210111.18"
  "Export snippets to org-mode and vice versa."
  '((org   "8.3.5")
    (emacs "24.3")
    (f     "0.17.3"))
  :url "https://github.com/abrochard/org-sync-snippets"
  :commit "88f995dea188b8a645a3388c42b62a2bb88953d3"
  :revdesc "88f995dea188"
  :keywords '("snippet" "org-mode" "yasnippet" "tools"))
