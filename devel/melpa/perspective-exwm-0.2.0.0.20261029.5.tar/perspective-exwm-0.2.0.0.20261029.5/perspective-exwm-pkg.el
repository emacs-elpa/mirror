;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective-exwm" "0.2.0.0.20261029.5"
  "Better integration for perspective.el and EXWM."
  '((emacs       "27.1")
    (burly       "0.2-pre")
    (exwm        "0.26")
    (perspective "2.17"))
  :url "https://github.com/SqrtMinusOne/perspective-exwm.el"
  :commit "c2eee98c0f6e4fd07aad87aa5fb46cfdc43b845d"
  :revdesc "c2eee98c0f6e"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
