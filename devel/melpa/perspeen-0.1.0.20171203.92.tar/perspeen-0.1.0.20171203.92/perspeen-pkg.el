;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspeen" "0.1.0.20171203.92"
  "An package for multi-workspace."
  '((emacs     "25.0")
    (powerline "2.4"))
  :url "https://github.com/seudut/perspeen"
  :commit "edb70c530bda50ff3d1756e32a703d5fef5e5480"
  :revdesc "edb70c530bda"
  :keywords '("lisp")
  :authors '(("Peng Li" . "seudut@gmail.com"))
  :maintainers '(("Peng Li" . "seudut@gmail.com")))
