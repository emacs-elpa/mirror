;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "owdriver" "0.4.0"
  "Quickly perform various actions on other windows."
  '((log4e      "0.4.1")
    (yaxception "1.0.0"))
  :url "https://github.com/aki2o/owdriver"
  :commit "ae96f3ff7aca560a872c77d40999f1527f7f84eb"
  :revdesc "ae96f3ff7aca"
  :keywords '("convenience")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
