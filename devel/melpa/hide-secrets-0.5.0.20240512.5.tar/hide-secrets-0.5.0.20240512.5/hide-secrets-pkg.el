;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hide-secrets" "0.5.0.20240512.5"
  "A package for hiding secrets in buffers."
  '((emacs "29.1"))
  :url "https://gitlab.com/ostseepinguin1/hide-secrets-el"
  :commit "e774f3fdacd875707fde25e32f8760e54a440689"
  :revdesc "e774f3fdacd8"
  :keywords '("tools")
  :authors '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainers '(("Sebastian Meisel" . "sebastian.meisel@gmail.com")))
