;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soundcloud" "20150501"
  "A SoundCloud client for Emacs."
  '((emms             "20131016")
    (json             "1.2")
    (deferred         "0.3.1")
    (string-utils     "0.3.2")
    (request          "20140316.417")
    (request-deferred "20130526.1015"))
  :url "https://github.com/thieman/soundcloud.el"
  :commit "f998d4276ea90258909c698f6a5a51fccb667c08"
  :revdesc "f998d4276ea9"
  :keywords '("soundcloud" "music" "audio")
  :authors '(("Travis Thieman" . "travis.thieman@gmail.com"))
  :maintainers '(("Travis Thieman" . "travis.thieman@gmail.com")))
