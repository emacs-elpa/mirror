;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-calendar" "0.1.2"
  "Russian holidays and conferences. Updated 2025-09-30."
  '((emacs "29.4"))
  :url "https://github.com/Anoncheg1/emacs-russian-calendar"
  :commit "23d222041dba8e5dad07542e0dc7dd3fc8419112"
  :revdesc "23d222041dba"
  :keywords '("calendar" "holidays"))
