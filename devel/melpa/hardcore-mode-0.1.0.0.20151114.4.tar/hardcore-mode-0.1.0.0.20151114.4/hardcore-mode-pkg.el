;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hardcore-mode" "0.1.0.0.20151114.4"
  "Disable arrow keys + optionally backspace and return."
  ()
  :url "https://github.com/magnars/hardcore-mode.el"
  :commit "b1dda19692b4a7a58a689e81784a9b35be39e70d"
  :revdesc "0.1.0-4-gb1dda19692b4"
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
