;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f90-ts-mode" "0.4.0.0.20260924.43"
  "Tree-sitter based Fortran 90 mode."
  '((emacs "29.1"))
  :url "https://github.com/mscfd/emacs-f90-ts-mode"
  :commit "2265f40de237a4967a9ae379e1a5b60f5b5370ae"
  :revdesc "v0.4.0-43-g2265f40de237"
  :keywords '("languages" "treesitter" "fortran")
  :authors '(("Martin Stein" . "mscfd@gmx.net"))
  :maintainers '(("Martin Stein" . "mscfd@gmx.net")))
