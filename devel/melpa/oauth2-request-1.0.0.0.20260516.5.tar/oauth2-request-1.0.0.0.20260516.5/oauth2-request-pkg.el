;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oauth2-request" "1.0.0.0.20260516.5"
  "OAuth2 request package interface."
  '((emacs   "27.1")
    (oauth2  "0.18.4")
    (request "0.3.3"))
  :url "https://github.com/conao3/oauth2-request.el"
  :commit "f6b7ba42ecdfd4cc3588bd57bbb345bdae9b9cd6"
  :revdesc "f6b7ba42ecdf"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
