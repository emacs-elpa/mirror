;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "2.5.0.0.20260701.15"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "a1f23ec1355011ec85c25bb6232b5eba810659ee"
  :revdesc "2.5.0-15-ga1f23ec13550"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
