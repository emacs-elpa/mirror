;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ast-grep" "0.5.0"
  "Search code using ast-grep with completing-read interface."
  '((emacs "28.1"))
  :url "https://github.com/sunskyxh/ast-grep.el"
  :commit "a996a45ad197114f06609f5abc4a2bccb5bb3908"
  :revdesc "a996a45ad197"
  :keywords '("tools" "matching")
  :authors '(("SunskyxXH" . "sunskyxh@gmail.com"))
  :maintainers '(("SunskyxXH" . "sunskyxh@gmail.com")))
