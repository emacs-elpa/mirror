;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "0.43"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (compat    "31")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "ab7e2f03bbb966649f682c44aaf22690d24fd021"
  :revdesc "ab7e2f03bbb9"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
