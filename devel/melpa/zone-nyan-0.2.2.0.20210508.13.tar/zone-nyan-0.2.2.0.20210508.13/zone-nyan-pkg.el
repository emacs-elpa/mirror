;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zone-nyan" "0.2.2.0.20210508.13"
  "Zone out with nyan cat."
  '((emacs "24.3")
    (esxml "0.3.1"))
  :url "https://depp.brause.cc/zone-nyan"
  :commit "38b6e9f1f5871e9166b00a1db44680caa56773be"
  :revdesc "38b6e9f1f587"
  :keywords '("games")
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
