;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.0.1.0.20260719.1271"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "a517c813cd40597a2f9ecb2370607147846e2125"
  :revdesc "a517c813cd40"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
