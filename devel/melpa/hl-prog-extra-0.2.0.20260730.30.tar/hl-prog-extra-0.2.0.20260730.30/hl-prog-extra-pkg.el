;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-prog-extra" "0.2.0.20260730.30"
  "Customizable highlighting for source-code."
  '((emacs "26.2"))
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra"
  :commit "d7c857f3e18d2de83afe582412466dd1c8cbfa67"
  :revdesc "d7c857f3e18d"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
