;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.0.0.20260831.4"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "89d1d3442c8670dc7aa938b05bab907137f10615"
  :revdesc "89d1d3442c86"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
