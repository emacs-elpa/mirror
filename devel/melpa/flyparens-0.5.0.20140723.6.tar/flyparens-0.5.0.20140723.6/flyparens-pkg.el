;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyparens" "0.5.0.20140723.6"
  "Check for unbalanced parens on the fly."
  ()
  :url "https://github.com/jiyoo/flyparens"
  :commit "af9b8cfd647d0e5f97684d613dc2eea7cfc19398"
  :revdesc "af9b8cfd647d"
  :keywords '("faces" "convenience" "lisp" "matching" "parentheses" "parens"))
