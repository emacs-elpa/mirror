;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-tube" "0.15.0.20261011.49"
  "YouTube integration for Elfeed."
  '((emacs  "27.1")
    (elfeed "3.4.2")
    (aio    "1.0"))
  :url "https://github.com/karthink/elfeed-tube"
  :commit "35766b2b8fdce210ff51ecb226aee79e1f303d0c"
  :revdesc "35766b2b8fdc"
  :keywords '("news" "hypermedia" "convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
