;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beans" "1.0.20221114.2"
  "Major mode for Beans grammar."
  '((emacs "24.3"))
  :url "https://github.com/TheBlackBeans/emacs-beans"
  :commit "0d04b79222812aa4978b6486a9ccac461850fe7a"
  :revdesc "0d04b7922281")
