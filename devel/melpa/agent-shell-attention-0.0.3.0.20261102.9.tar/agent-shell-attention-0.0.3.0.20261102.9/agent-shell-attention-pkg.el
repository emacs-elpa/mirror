;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-attention" "0.0.3.0.20261102.9"
  "Mode-line attention tracker for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.47.1"))
  :url "https://github.com/ultronozm/agent-shell-attention.el"
  :commit "8d5116f174fc35177aedc0f967a8fa3d6784aa1b"
  :revdesc "v0.0.3-9-g8d5116f174fc"
  :keywords '("convenience")
  :authors '(("Paul D. Nelson" . "ultrono@gmail.com"))
  :maintainers '(("Paul D. Nelson" . "ultrono@gmail.com")))
