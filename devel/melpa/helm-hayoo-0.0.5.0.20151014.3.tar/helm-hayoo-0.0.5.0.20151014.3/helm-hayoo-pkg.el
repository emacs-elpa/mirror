;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-hayoo" "0.0.5.0.20151014.3"
  "Source and configured helm for searching hayoo."
  '((helm         "1.6.0")
    (json         "1.2")
    (haskell-mode "13.07"))
  :url "https://github.com/markus1189/helm-hayoo"
  :commit "dd4c0c8c87521026edf1b808c4de01fa19b7c693"
  :revdesc "0.0.5-3-gdd4c0c8c8752"
  :keywords '("helm")
  :authors '(("Markus Hauck" . "markus1189@gmail.com"))
  :maintainers '(("Markus Hauck" . "markus1189@gmail.com")))
