;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "4.0.7.0.20260806.41"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "a1b40f38d653d2a6ae48eb64d90818b0fcb386e5"
  :revdesc "v4.0.7-41-ga1b40f38d653"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
