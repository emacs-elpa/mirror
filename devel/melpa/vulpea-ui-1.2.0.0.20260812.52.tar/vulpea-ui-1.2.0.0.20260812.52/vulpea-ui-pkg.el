;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "1.2.0.0.20260812.52"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.5.0")
    (vui    "1.3.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "d0068de942cc750cd4f3e7b00627bf5cc68a2d0d"
  :revdesc "v1.2.0-52-gd0068de942cc"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
