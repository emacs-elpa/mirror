;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pueue" "2.1.0.0.20230219.2"
  "Interface for pueue."
  '((emacs       "28.1")
    (with-editor "3.0.4"))
  :url "https://github.com/xFA25E/pueue"
  :commit "386e43d46cbf68470d040b422061ac2ba1629749"
  :revdesc "2.1.0-2-g386e43d46cbf"
  :keywords '("processes")
  :authors '(("Valeriy Litkovskyy" . "vlr.ltkvsk@protonmail.com"))
  :maintainers '(("Valeriy Litkovskyy" . "vlr.ltkvsk@protonmail.com")))
