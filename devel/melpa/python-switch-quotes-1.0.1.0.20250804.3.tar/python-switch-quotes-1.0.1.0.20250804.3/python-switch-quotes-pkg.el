;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-switch-quotes" "1.0.1.0.20250804.3"
  "Cycle between single and double quotes in python strings."
  '((emacs "24.3"))
  :url "https://github.com/werehuman/python-switch-quotes"
  :commit "dc3bf1d7c206168605f4df7a605bc4615d296cd6"
  :revdesc "dc3bf1d7c206"
  :keywords '("python" "tools" "convenience")
  :authors '(("Vladimir Lagunov" . "lagunov.vladimir@gmail.com"))
  :maintainers '(("Vladimir Lagunov" . "lagunov.vladimir@gmail.com")))
