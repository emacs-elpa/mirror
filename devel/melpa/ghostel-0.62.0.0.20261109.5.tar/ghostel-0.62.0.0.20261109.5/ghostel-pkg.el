;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.62.0.0.20261109.5"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "91c86d21bb611167960ba503e8b22262bb8d5993"
  :revdesc "91c86d21bb61"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
