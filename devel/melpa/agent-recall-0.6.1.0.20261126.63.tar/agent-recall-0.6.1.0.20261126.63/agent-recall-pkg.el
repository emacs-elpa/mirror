;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "0.6.1.0.20261126.63"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "7b2019592d6c8b057e2211cd98d52934c5134031"
  :revdesc "7b2019592d6c"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
