;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "makefile-executor" "20230224.0.20260716.2"
  "Commands for conveniently running makefile targets."
  '((emacs "27.1")
    (dash  "2.11.0")
    (f     "0.11.0")
    (s     "1.10.0"))
  :url "https://github.com/Olivia5k/makefile-executor.el"
  :commit "b22e10f528def19da9b1575546f62693555e6b22"
  :revdesc "b22e10f528de"
  :keywords '("processes")
  :authors '(("Olivia Thiderman" . "olivia@thiderman.org"))
  :maintainers '(("Olivia Thiderman" . "olivia@thiderman.org")))
