;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "merlin-eldoc" "1.3.0.20230213.10"
  "Eldoc for OCaml and Reason."
  '((emacs  "24.4")
    (merlin "3.0"))
  :url "https://github.com/khady/merlin-eldoc"
  :commit "bf8edc63d85b35e4def352fa7ce4ea39f43e1fd8"
  :revdesc "bf8edc63d85b"
  :keywords '("merlin" "ocaml" "languages" "eldoc")
  :authors '(("Louis Roché" . "louis@louisroche.net"))
  :maintainers '(("Louis Roché" . "louis@louisroche.net")))
