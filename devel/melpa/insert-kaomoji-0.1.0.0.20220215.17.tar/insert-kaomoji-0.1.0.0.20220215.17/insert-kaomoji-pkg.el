;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insert-kaomoji" "0.1.0.0.20220215.17"
  "Easily insert kaomojis."
  '((emacs "24.4"))
  :url "https://git.sr.ht/~pkal/insert-kaomoji"
  :commit "974bb7dc02059253e032c501b2c3c0ece448d472"
  :revdesc "974bb7dc0205"
  :keywords '("wp")
  :authors '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainers '(("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht")))
