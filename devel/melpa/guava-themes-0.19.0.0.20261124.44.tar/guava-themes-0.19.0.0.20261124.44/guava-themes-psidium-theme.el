;;; guava-themes-psidium-theme.el --- A theme inspired by guava colors -*- lexical-binding: t; -*-

;; Copyright (C) 2025-2026

;; Author: Geralld Borbón <geralldborbon@gmail.com>
;; Created: Dec 07, 2025
;; Keywords: themes, faces, color
;; URL: http://github.com/bormoge/guava-themes
;; Package-Requires: ((emacs "24.1"))
;; SPDX-License-Identifier: GPL-3.0-or-later

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; A theme inspired by guava colors.
;;
;;; Code:

(require 'guava-themes)

(deftheme guava-themes-psidium "A theme inspired by guava colors.")

(let* (
      (psidium-class '((class color) (min-colors 257)))
      (psidium-black                     "#000000")
      (psidium-white                     "#FFFFFF")

      (psidium-green                     "#599b48")
      (psidium-light-green               "#28bb6b")
      (psidium-guava-green               "#aecd34")
      (psidium-deep-green                "#097d2c")

      (psidium-red-orange                "#cd605f")
      (psidium-red                       "#c1153b")
      (psidium-pink                      "#F8767C")

      (psidium-brown                     "#785f46")

      ;; (psidium-light-blue                "#3791c0")
      (psidium-blue                      "#2a4ad9")
      (psidium-deep-blue                 "#483d8b")
      (psidium-cyan                      "#00afaf")
      (psidium-dark-cyan                 "#006969")

      (psidium-purple                    "#812db2")

      (psidium-fg-1                      "#000000")
      (psidium-fg-2                      "#3c3c3c")
      (psidium-bg-1                      "#F1EECE")
      (psidium-highlight                 "#dddaba")
      (psidium-shadow                    "#7f7f7f")
      (psidium-tooltip                   "#ffffe0")
      (psidium-region-1                  "#ffbe9b")
      (psidium-region-2                  "#8cb4d1")

      (psidium-error                     "#FF0000")
      (psidium-warning                   "#d6c800")
      (psidium-success                   "#228B22")
      (psidium-change                    "#2a4ad9")

      (psidium-mode-line                 "#F8767C")
      (psidium-mode-line-inactive        "#aecd34")
      (psidium-mode-line-modified        "#F8EDC6")
      (psidium-bell                      "#76BEF8")

      (psidium-tab-1                     psidium-mode-line)
      (psidium-tab-2                     psidium-mode-line-inactive)
      (psidium-tab-3                     psidium-light-green)

      (psidium-fl-comment                psidium-green)
      (psidium-fl-string                 psidium-brown)
      (psidium-fl-keyword                psidium-red)
      (psidium-fl-builtin                psidium-pink)
      (psidium-fl-type                   psidium-deep-green)
      (psidium-fl-function-name          psidium-light-green)
      (psidium-fl-variable-name          psidium-purple)
      (psidium-fl-constant               psidium-blue)
      (psidium-fl-warning                psidium-warning)
      (psidium-fl-punctuation            psidium-fg-2)
      (psidium-fl-negation-char          psidium-deep-blue)

      (psidium-diff-added                "#c8f0c8")
      (psidium-diff-removed              "#f0c8c8")
      (psidium-diff-refine-added         "#78f078")
      (psidium-diff-refine-removed       "#f07878")
      (psidium-diff-header               "#b4b4b4")
      (psidium-diff-file-header          "#8c8c8c")
      (psidium-diff-context              "#dcdcdc")
      (psidium-smerge-base               "#C8C8F0")

      (psidium-complementary-a-0         "#4680DE")
      (psidium-complementary-a-1         "#DE4680")

      (psidium-tetradic-a-0              psidium-mode-line-modified)
      (psidium-tetradic-a-1              "#F8C6EA")
      (psidium-tetradic-a-2              "#C6D1F8")
      (psidium-tetradic-a-3              "#C6F8D4")

      (psidium-tetradic-b-0              "#C94ED0")
      (psidium-tetradic-b-1              "#55D04E")
      (psidium-tetradic-b-2              "#D0894E")
      (psidium-tetradic-b-3              "#4E96D0"))

  (custom-theme-set-faces
   'guava-themes-psidium

   ;; built-in faces
   ;; with unique colors

   ;; default
   `(default ((,psidium-class (:foreground ,psidium-fg-1 :background ,psidium-bg-1))))

   ;; error, warning, success
   `(error ((,psidium-class (:foreground ,psidium-error :weight bold))))
   `(warning ((,psidium-class (:foreground ,psidium-warning :weight bold))))
   `(success ((,psidium-class (:foreground ,psidium-success :weight bold))))

   ;; highlight
   `(highlight ((,psidium-class (:background ,psidium-highlight))))

   ;; shadow
   `(shadow ((,psidium-class (:foreground ,psidium-shadow))))

   ;; tooltip
   `(tooltip ((,psidium-class (:weight bold :foreground ,psidium-black :background ,psidium-tooltip :inherit variable-pitch))))

   ;; region
   `(region ((,psidium-class (:background ,psidium-region-1 :extend t))))
   `(secondary-selection ((,psidium-class (:background ,psidium-region-2 :extend t))))

   ;; font-lock
   `(font-lock-comment-face ((,psidium-class (:foreground ,psidium-fl-comment :weight medium))))
   `(font-lock-string-face ((,psidium-class (:foreground ,psidium-fl-string :weight medium))))
   `(font-lock-keyword-face ((,psidium-class (:foreground ,psidium-fl-keyword :weight medium))))
   `(font-lock-builtin-face ((,psidium-class (:foreground ,psidium-fl-builtin :weight medium))))
   `(font-lock-type-face ((,psidium-class (:foreground ,psidium-fl-type :weight medium))))
   `(font-lock-function-name-face ((,psidium-class (:foreground ,psidium-fl-function-name :weight medium))))
   `(font-lock-variable-name-face ((,psidium-class (:foreground ,psidium-fl-variable-name :weight medium))))
   `(font-lock-constant-face ((,psidium-class (:foreground ,psidium-fl-constant :weight medium))))
   `(font-lock-warning-face ((,psidium-class (:foreground ,psidium-fl-warning :weight bold))))
   `(font-lock-punctuation-face ((,psidium-class (:foreground ,psidium-fl-punctuation :weight medium))))
   `(font-lock-negation-char-face ((,psidium-class (:foreground ,psidium-fl-negation-char :weight medium))))

   ;; built-in faces
   ;; with non-unique colors

   ;; cursor
   `(cursor ((,psidium-class (:foreground ,psidium-black :background ,psidium-mode-line))))

   ;; fringe
   `(fringe ((,psidium-class (:foreground ,psidium-fl-builtin :background ,psidium-bg-1))))
   `(diff-hl-change ((,psidium-class (:foreground ,psidium-change :background ,psidium-change))))
   `(diff-hl-insert ((,psidium-class (:foreground ,psidium-success :background ,psidium-success))))
   `(diff-hl-delete ((,psidium-class (:foreground ,psidium-error :background ,psidium-error))))

   ;; line-number
   `(line-number ((,psidium-class (:foreground ,psidium-fg-1 :inherit default))))
   `(line-number-current-line ((,psidium-class (:foreground ,psidium-mode-line :weight bold :inherit (highlight line-number)))))
   `(line-number-minor-tick ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-2 :inherit line-number))))
   `(line-number-major-tick ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-3 :inherit line-number))))

   ;; mode-line
   `(mode-line ((,psidium-class (:foreground ,psidium-white :background ,psidium-mode-line
                                             :box ,(if guava-themes-boxed-mode-line
                                                       '(:line-width -1 :style released-button)
                                                     'unspecified)))))
   `(mode-line-inactive ((,psidium-class (:background ,psidium-mode-line-inactive :inherit mode-line))))
   `(mode-line-emphasis ((,psidium-class (:weight bold))))
   `(mode-line-highlight ((,psidium-class (:foreground unspecified :background unspecified :box (:line-width 2 :color "grey40" :style released-button)))))
   `(guava-themes-visible-bell ((,psidium-class (:foreground ,psidium-white :background ,psidium-bell))))

   ;; minibuffer
   `(minibuffer-prompt ((,psidium-class (:weight bold :foreground ,psidium-mode-line))))

   ;; borders
   `(vertical-border ((,psidium-class (:foreground ,psidium-mode-line))))

   ;; header-line
   `(header-line ((,psidium-class (:background ,psidium-tab-1 :inherit mode-line))))
   `(which-func ((,psidium-class (:weight bold :foreground ,psidium-mode-line-modified))))

   ;; tab-bar
   `(tab-bar ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-2 :weight bold :inherit mode-line))))
   `(tab-bar-tab ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-1 :inherit tab-bar))))
   `(tab-bar-tab-inactive ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-2 :inherit tab-bar-tab))))

   ;; tab-line
   `(tab-line ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-2 :weight bold :inherit mode-line))))
   `(tab-line-tab ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-2 :inherit tab-line))))
   `(tab-line-tab-current ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-1 :inherit tab-line-tab))))
   `(tab-line-tab-inactive ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-2 :inherit tab-line-tab))))
   `(tab-line-tab-inactive-alternate ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-3 :inherit tab-line-tab))))
   `(tab-line-tab-modified ((,psidium-class (:foreground ,psidium-mode-line-modified :weight bold))))
   `(tab-line-tab-special ((,psidium-class (:slant italic :weight bold))))
   `(tab-line-highlight ((,psidium-class (:foreground unspecified :background unspecified :box (:line-width 2 :style released-button)))))

   ;; parentheses
   `(show-paren-match ((,psidium-class (:foreground ,psidium-black :background ,psidium-bell))))
   `(show-paren-mismatch ((,psidium-class (:foreground ,psidium-black :background ,psidium-error :inherit show-paren-match))))

   ;; trailing whitespaces
   `(trailing-whitespace ((,psidium-class (:background ,psidium-error))))

   ;; links
   `(link ((,psidium-class (:foreground ,psidium-cyan :underline t :weight bold))))
   `(link-visited ((,psidium-class (:foreground ,psidium-dark-cyan :underline t :weight bold))))

   ;; outline
   `(outline-1 ((,psidium-class (:foreground ,psidium-red :weight medium))))
   `(outline-2 ((,psidium-class (:foreground ,psidium-blue :weight medium))))
   `(outline-3 ((,psidium-class (:foreground ,psidium-deep-green :weight medium))))
   `(outline-4 ((,psidium-class (:foreground ,psidium-brown :weight medium))))
   `(outline-5 ((,psidium-class (:inherit outline-1))))
   `(outline-6 ((,psidium-class (:inherit outline-2))))
   `(outline-7 ((,psidium-class (:inherit outline-3))))
   `(outline-8 ((,psidium-class (:inherit outline-4))))

   ;; homoglyph, escape-glyph, nobreak-space (C-x 8 RET "FORM FEED") (C-x 8 RET "NO-BREAK SPACE")
   `(homoglyph ((,psidium-class (:foreground ,psidium-cyan))))
   `(escape-glyph ((,psidium-class (:inherit homoglyph))))
   `(nobreak-space ((,psidium-class (:box (:line-width (2 . 2)) :inherit homoglyph))))
   `(nobreak-hyphen ((,psidium-class (:inherit homoglyph))))

   ;; pulse-highlight-start-face
   ;; M-: (pulse-momentary-highlight-region (point-min) (point-max))
   `(pulse-highlight-start-face ((,psidium-class (:background ,psidium-cyan))))

   ;; help-key-binding
   `(help-key-binding ((,psidium-class (:foreground ,psidium-dark-cyan :background "grey96" :box (:line-width (-1 . -1) :color "grey80") :inherit fixed-pitch))))

   ;; diff
   `(diff-added ((,psidium-class (:foreground ,psidium-black :background ,psidium-diff-added :extend t :inherit diff-changed))))
   `(diff-removed ((,psidium-class (:foreground ,psidium-black :background ,psidium-diff-removed :extend t :inherit diff-changed))))
   `(diff-refine-added ((,psidium-class (:foreground ,psidium-black :background ,psidium-diff-refine-added :inherit diff-refine-changed))))
   `(diff-refine-removed ((,psidium-class (:foreground ,psidium-black :background ,psidium-diff-refine-removed :inherit diff-refine-changed))))
   `(diff-header ((,psidium-class (:foreground ,psidium-black :background ,psidium-diff-header :extend t))))
   `(diff-file-header ((,psidium-class (:weight bold :foreground ,psidium-black :background ,psidium-diff-file-header :extend t))))
   `(diff-context ((,psidium-class (:foreground ,psidium-black :background ,psidium-diff-context :extend t))))

   ;; smerge
   `(smerge-lower ((,psidium-class (:extend t :inherit diff-added))))
   `(smerge-upper ((,psidium-class (:extend t :inherit diff-removed))))
   `(smerge-markers ((,psidium-class (:extend t :inherit diff-context))))
   `(smerge-refined-added ((,psidium-class (:extend t :inherit diff-refine-added))))
   `(smerge-refined-removed ((,psidium-class (:extend t :inherit diff-refine-removed))))
   `(smerge-base ((,psidium-class (:foreground ,psidium-black :background ,psidium-smerge-base :extend t))))

   ;; completions
   `(completions-common-part ((,psidium-class (:foreground ,psidium-change :weight bold))))
   `(completions-first-difference ((,psidium-class (:foreground ,psidium-error :weight bold))))

   ;; org-faces
   `(org-todo ((,psidium-class (:foreground ,psidium-error :weight bold))))
   `(org-done ((,psidium-class (:foreground ,psidium-success :weight bold))))
   `(org-hide ((,psidium-class (:foreground ,psidium-bg-1))))
   `(org-table ((,psidium-class (:foreground ,psidium-deep-green))))
   `(org-table-header ((,psidium-class (:inverse-video t :inherit org-table))))
   `(org-date ((,psidium-class (:foreground ,psidium-pink))))
   `(org-date-selected ((,psidium-class (:foreground unspecified :inverse-video t :inherit org-date))))
   `(org-headline-todo ((,psidium-class (:foreground ,psidium-tetradic-b-2))))
   `(org-headline-done ((,psidium-class (:foreground ,psidium-tetradic-b-3))))
   `(org-document-title ((,psidium-class (:inherit font-lock-keyword-face))))
   `(org-document-info-keyword ((,psidium-class (:inherit shadow))))
   `(org-meta-line ((,psidium-class (:inherit font-lock-comment-face))))
   `(org-ellipsis ((,psidium-class (:foreground unspecified :underline nil))))

   ;; window-divider
   `(window-divider ((,psidium-class (:foreground ,psidium-tab-3))))
   `(window-divider-first-pixel ((,psidium-class (:inherit window-divider))))
   `(window-divider-last-pixel ((,psidium-class (:inherit window-divider))))

   ;; isearch (use "M-x isearch-forward-regexp foo-\([0-9]+\)\([a-z]+\)\([0-9]+\)" to check the group faces)
   `(isearch ((,psidium-class (:foreground ,psidium-white :background ,psidium-tetradic-b-2))))
   `(isearch-fail ((,psidium-class (:foreground ,psidium-white :background ,psidium-error))))
   `(lazy-highlight ((,psidium-class (:foreground ,psidium-white :background ,psidium-tetradic-b-3))))
   `(isearch-group-1 ((,psidium-class (:foreground ,psidium-white :background ,psidium-tetradic-b-0))))
   `(isearch-group-2 ((,psidium-class (:foreground ,psidium-white :background ,psidium-tetradic-b-1))))

   ;; replace (use "M-x occur" to check the match face)
   `(query-replace ((,psidium-class (:inherit isearch))))
   `(match ((,psidium-class (:inherit lazy-highlight))))

   ;; re-builder
   `(reb-match-0 ((,psidium-class (:background ,psidium-tetradic-b-0 :foreground ,psidium-white))))
   `(reb-match-1 ((,psidium-class (:background ,psidium-tetradic-b-1 :foreground ,psidium-white))))
   `(reb-match-2 ((,psidium-class (:background ,psidium-tetradic-b-2 :foreground ,psidium-white))))
   `(reb-match-3 ((,psidium-class (:background ,psidium-tetradic-b-3 :foreground ,psidium-white))))

   ;; custom
   ;; (progn (setopt custom-raised-buttons nil) (setq mouse-highlight t))
   `(custom-button ((,psidium-class (:foreground ,psidium-white :background ,psidium-mode-line :box (:line-width 2 :style released-button)))))
   `(custom-button-pressed ((,psidium-class (:foreground ,psidium-white :background ,psidium-mode-line :box (:line-width 2 :style pressed-button)))))
   `(custom-button-mouse ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-3 :box (:line-width 2 :style released-button)))))
   `(custom-button-unraised ((,psidium-class (:foreground ,psidium-mode-line :inherit underline))))
   `(custom-button-pressed-unraised ((,psidium-class (:foreground ,psidium-bell :inherit custom-button-unraised))))
   `(custom-comment ((,psidium-class (:background ,psidium-tab-3))))
   `(custom-variable-tag ((,psidium-class (:weight bold :foreground ,psidium-tab-2))))
   `(custom-group-tag ((,psidium-class (:height 1.2 :inherit (custom-variable-tag variable-pitch)))))
   `(custom-state ((,psidium-class (:foreground ,psidium-fl-keyword))))

   ;; widget
   `(widget-field ((,psidium-class (:background ,psidium-tab-3 :box (:line-width (1 . -1) :color "gray46") :extend t))))
   `(widget-single-line-field ((,psidium-class (:background ,psidium-tab-3))))

   ;; package
   `(package-status-dependency ((,psidium-class (:inherit (font-lock-string-face)))))

   ;; icomplete
   `(icomplete-selected-match ((,psidium-class (:weight bold :foreground ,psidium-mode-line :inherit (highlight)))))
   `(icomplete-first-match ((,psidium-class (:weight bold :foreground ,psidium-mode-line :inherit (highlight)))))

   ;; bookmark
   `(bookmark-face ((,psidium-class (:foreground ,psidium-mode-line :distant-foreground unspecified))))
   `(bookmark-menu-bookmark ((,psidium-class (:weight bold :inherit bookmark-face))))

   ;; flymake
   `(flymake-note ((,psidium-class (:underline (:style wave :color ,psidium-success)))))
   `(flymake-warning ((,psidium-class (:underline (:style wave :color ,psidium-warning)))))
   `(flymake-error ((,psidium-class (:underline (:style wave :color ,psidium-error)))))

   ;; eww
   `(eww-valid-certificate ((,psidium-class (:weight bold :foreground ,psidium-success))))
   `(eww-invalid-certificate ((,psidium-class (:weight bold :foreground ,psidium-error))))
   ;; Example of eww-form-text: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-text ((,psidium-class (:foreground ,psidium-fg-1 :background ,psidium-tab-3 :box (:line-width 1)))))
   ;; Example of eww-form-file: https://html.com/input-type-file/
   `(eww-form-file ((,psidium-class (:foreground ,psidium-fg-1 :background ,psidium-tab-2 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-select: http://savannah.gnu.org/projects/emacs/
   ;; Example of eww-form-select: https://git.kernel.org/pub/scm/editors/uemacs/uemacs.git/
   `(eww-form-select ((,psidium-class (:foreground ,psidium-fg-1 :background ,psidium-tab-1 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-submit: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-submit ((,psidium-class (:foreground ,psidium-fg-1 :background ,psidium-tab-2 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-checkbox: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-checkbox ((,psidium-class (:foreground ,psidium-fg-1 :background ,psidium-tab-1 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-textarea: https://en.wikipedia.org/w/index.php?title=Main_Page&action=edit
   `(eww-form-textarea ((,psidium-class (:foreground ,psidium-fg-1 :background ,psidium-tab-3 :box (:line-width 1 :color ,psidium-tab-1)))))


   ;; external packages

   ;; elfeed
   `(elfeed-search-tag-face ((,psidium-class (:foreground ,psidium-purple))))
   `(elfeed-search-date-face ((,psidium-class (:foreground ,psidium-deep-blue))))
   `(elfeed-search-feed-face ((,psidium-class (:foreground ,psidium-deep-green))))
   `(elfeed-search-title-face ((,psidium-class (:foreground ,psidium-brown))))
   `(elfeed-search-unread-title-face ((,psidium-class (:weight bold :foreground ,psidium-red))))
   `(elfeed-search-filter-face ((,psidium-class (:weight bold :foreground ,psidium-tetradic-a-1))))
   `(elfeed-search-last-update-face ((,psidium-class (:weight bold :foreground ,psidium-tetradic-a-1))))
   `(elfeed-search-unread-count-face ((,psidium-class (:weight bold :foreground ,psidium-tetradic-a-1))))

   `(elfeed-show-header-face ((,psidium-class (:inherit elfeed-search-date-face))))
   `(elfeed-show-author-face ((,psidium-class (:inherit elfeed-search-unread-title-face))))
   `(elfeed-show-title-face ((,psidium-class (:inherit elfeed-search-unread-title-face))))
   `(elfeed-show-date-face ((,psidium-class (:inherit elfeed-search-feed-face))))
   `(elfeed-show-feed-face ((,psidium-class (:inherit elfeed-search-feed-face))))
   `(elfeed-show-tags-face ((,psidium-class (:inherit elfeed-search-tag-face))))

   `(elfeed-log-info-level-face ((,psidium-class (:foreground ,psidium-success))))
   `(elfeed-log-debug-level-face ((,psidium-class (:foreground ,psidium-change))))
   `(elfeed-log-warn-level-face ((,psidium-class (:foreground ,psidium-warning))))
   `(elfeed-log-error-level-face ((,psidium-class (:foreground ,psidium-error))))

   ;; doom-modeline
   ;; doom-modeline-buffer-file-name-style
   `(doom-modeline-project-name ((,psidium-class (:foreground ,psidium-tetradic-a-3 :inherit (doom-modeline bold italic)))))
   `(doom-modeline-project-dir ((,psidium-class (:foreground ,psidium-tetradic-a-3 :inherit (doom-modeline bold)))))
   `(doom-modeline-project-root-dir ((,psidium-class (:foreground ,psidium-tetradic-a-2 :inherit (doom-modeline bold)))))
   `(doom-modeline-project-parent-dir ((,psidium-class (:foreground ,psidium-tetradic-a-2 :inherit (doom-modeline bold)))))
   `(doom-modeline-buffer-minor-mode ((,psidium-class (:foreground ,psidium-tetradic-a-1 :inherit (doom-modeline)))))
   `(doom-modeline-buffer-modified ((,psidium-class (:foreground ,psidium-tetradic-a-0 :inherit (doom-modeline warning bold)))))

   ;; corfu
   `(corfu-default ((,psidium-class (:foreground ,psidium-fg-1 :background ,psidium-bg-1))))
   `(corfu-current ((,psidium-class (:foreground unspecified :background unspecified :extend t :inherit highlight))))
   `(corfu-bar ((,psidium-class (:background ,psidium-shadow))))
   `(corfu-border ((,psidium-class (:background ,psidium-shadow))))

   ;; orderless
   `(orderless-match-face-0 ((,psidium-class (:foreground ,psidium-tetradic-b-0 :weight bold))))
   `(orderless-match-face-1 ((,psidium-class (:foreground ,psidium-tetradic-b-1 :weight bold))))
   `(orderless-match-face-2 ((,psidium-class (:foreground ,psidium-tetradic-b-2 :weight bold))))
   `(orderless-match-face-3 ((,psidium-class (:foreground ,psidium-tetradic-b-3 :weight bold))))

   ;; prescient (vertico-prescient-enable-filtering, corfu-prescient-enable-filtering)
   `(prescient-primary-highlight ((,psidium-class (:foreground ,psidium-complementary-a-0 :weight bold))))
   `(prescient-secondary-highlight ((,psidium-class (:foreground ,psidium-complementary-a-1 :underline t :weight bold))))

   ;; envrc
   `(envrc-mode-line-error-face ((,psidium-class (:inherit error))))
   `(envrc-mode-line-denied-face ((,psidium-class (:inherit warning))))
   `(envrc-mode-line-on-face ((,psidium-class (:inherit success))))
   `(envrc-mode-line-none-face ((,psidium-class (:inherit warning))))
   `(envrc-mode-line-running-face ((,psidium-class (:inherit warning))))

   ;; devdocs
   `(devdocs-code-block ((,psidium-class (:weight bold :background ,psidium-highlight :extend t))))

   ;; pdf-tools
   `(pdf-view-region ((,psidium-class (:foreground ,psidium-white :background ,psidium-tetradic-b-3 :inherit region))))

   ;; idle-highlight
   `(idle-highlight ((,psidium-class (:foreground ,psidium-white :background ,psidium-fl-builtin :inherit region))))

   ;; keycast
   `(keycast-command ((,psidium-class (:weight bold))))
   `(keycast-key ((,psidium-class (:foreground ,psidium-white :background ,psidium-tab-3 :box (:line-width -3 :style released-button) :inherit fixed-pitch))))

   ;; nerd-icons
   ;; nerd-icons-completion
   `(nerd-icons-completion-dir-face ((,psidium-class (:foreground unspecified :inherit font-lock-function-name-face))))))

(provide-theme 'guava-themes-psidium)

;; Local Variables:
;; no-byte-compile: t
;; indent-tabs-mode: nil
;; eval: (when (featurep 'package-lint-flymake) (package-lint-flymake-setup))
;; End:

;;; guava-themes-psidium-theme.el ends here
