;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "celestial-mode-line" "20180518.0.20230323.5"
  "Show lunar phase and sunrise/-set time in modeline."
  '((emacs "24"))
  :url "https://github.com/ecraven/celestial-mode-line"
  :commit "90056322d6664e2e2b593912e4d5e68f1468cafc"
  :revdesc "90056322d666"
  :keywords '("extensions")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Peter" . "craven@gmx.net")))
