;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hardhat" "0.4.6.0.20210515.3"
  "Protect against clobbering user-writable files."
  '((emacs     "24.3")
    (ignoramus "0.7.0"))
  :url "https://github.com/rolandwalker/hardhat"
  :commit "908cb130be3d56921a3687a00b974ba5eef3a11f"
  :revdesc "v0.4.6-3-g908cb130be3d"
  :keywords '("convenience")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
