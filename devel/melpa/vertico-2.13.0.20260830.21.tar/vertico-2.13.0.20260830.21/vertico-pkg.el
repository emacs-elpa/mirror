;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "2.13.0.20260830.21"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "cd2eb6daff6a5a68a11740aa363729ec6f8702d3"
  :revdesc "2.13-21-gcd2eb6daff6a"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
