;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ghci" "0.3.0.20190707.26"
  "Company backend which uses the current ghci process."
  '((company      "0.8.11")
    (haskell-mode "13"))
  :url "https://github.com/horellana/company-ghci"
  :commit "a1d25652583ab4666c5a78cac18cd8039776b50d"
  :revdesc "a1d25652583a"
  :authors '(("Hector Orellana" . "hofm92@gmail.com"))
  :maintainers '(("Hector Orellana" . "hofm92@gmail.com")))
