;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yml" "0.1.4.0.20261109.1"
  "Fast YAML parser (dynamic module)."
  '((emacs "26.1"))
  :url "https://github.com/isamert/yml.el"
  :commit "ca01e89df3fe44bd0dae128b5642bd6303dd9ded"
  :revdesc "v0.1.4-1-gca01e89df3fe"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
