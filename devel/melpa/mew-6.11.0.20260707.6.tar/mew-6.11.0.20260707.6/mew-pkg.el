;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20260707.6"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "880d4af5cadadfa3b0348c340f187aa45c0a870c"
  :revdesc "880d4af5cada")
