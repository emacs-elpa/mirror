;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-code-talks" "0.2.1.0.20180907.3"
  "Support for slides with live code in them."
  '((emacs                    "24")
    (cl-lib                   "0.5")
    (narrowed-page-navigation "0.1"))
  :url "https://github.com/david-christiansen/live-code-talks"
  :commit "97f16a9ee4e6ff3e0f9291eaead772c66e3e12ae"
  :revdesc "97f16a9ee4e6"
  :keywords '("docs" "multimedia")
  :authors '(("David Raymond Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Raymond Christiansen" . "david@davidchristiansen.dk")))
