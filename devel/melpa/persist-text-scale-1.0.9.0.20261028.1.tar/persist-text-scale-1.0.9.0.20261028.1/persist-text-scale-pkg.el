;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "1.0.9.0.20261028.1"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "25bfeb29593c5e9d24dab6557f1d430e1ac5d6bd"
  :revdesc "1.0.9-1-g25bfeb29593c"
  :keywords '("convenience" "faces")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
