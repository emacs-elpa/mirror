;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpr-ts-mode" "0.8.0.0.20260403.1"
  "Major mode for GNAT project files using Tree-Sitter."
  '((emacs "29.1"))
  :url "https://github.com/brownts/gpr-ts-mode"
  :commit "cd10a0963b4cf64966bb2e9413d787d83f5494d5"
  :revdesc "cd10a0963b4c"
  :keywords '("gpr" "gnat" "ada" "languages" "tree-sitter")
  :authors '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainers '(("Troy Brown" . "brownts@troybrown.dev")))
