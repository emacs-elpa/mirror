;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termint" "0.2.3.0.20260804.2"
  "Run REPLs in a terminal backend."
  '((emacs "29.1"))
  :url "https://github.com/milanglacier/termint.el"
  :commit "bf97d0a417902417febc2b6925152dab5610057f"
  :revdesc "v0.2.3-2-gbf97d0a41790"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
