;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soria-theme" "0.4.2.0.20260702.9"
  "A xoria256 theme with some colors from openSUSE."
  '((emacs "25.1"))
  :url "https://github.com/mssola/soria"
  :commit "bd83db9f83dff1cc717f9a6b4a2feab05031458a"
  :revdesc "v0.4.2-9-gbd83db9f83df"
  :keywords '("faces")
  :authors '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainers '(("Miquel Sabaté Solà" . "mikisabate@gmail.com")))
