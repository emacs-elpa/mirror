;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-annex" "1.9.0.0.20260315.8"
  "Control git-annex from Magit."
  '((emacs "26.1")
    (magit "4.0.0"))
  :url "https://github.com/magit/magit-annex"
  :commit "8ac55bdaab50cc1a5124d586ec79abadc3ca7b76"
  :revdesc "v1.9.0-8-g8ac55bdaab50"
  :keywords '("vc" "tools")
  :authors '(("Kyle Meyer" . "kyle@kyleam.com")
             ("Rémi Vanicat" . "vanicat@debian.org"))
  :maintainers '(("Kyle Meyer" . "kyle@kyleam.com")
                 ("Rémi Vanicat" . "vanicat@debian.org")))
