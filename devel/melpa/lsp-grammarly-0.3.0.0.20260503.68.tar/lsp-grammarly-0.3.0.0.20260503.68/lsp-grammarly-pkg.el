;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-grammarly" "0.3.0.0.20260503.68"
  "LSP Clients for Grammarly."
  '((emacs     "29.1")
    (lsp-mode  "6.1")
    (grammarly "0.3.0")
    (request   "0.3.0")
    (s         "1.12.0")
    (ht        "2.3"))
  :url "https://github.com/emacs-grammarly/lsp-grammarly"
  :commit "237a8322bee1982e926610c7d228fd0bc1e3bc50"
  :revdesc "237a8322bee1"
  :keywords '("convenience" "lsp" "grammarly" "checker")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
