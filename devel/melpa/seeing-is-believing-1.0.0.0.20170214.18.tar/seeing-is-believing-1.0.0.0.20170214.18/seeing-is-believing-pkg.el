;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seeing-is-believing" "1.0.0.0.20170214.18"
  "Minor mode for running the seeing-is-believing ruby gem."
  ()
  :url "https://github.com/jcinnamond/seeing-is-believing"
  :commit "fbbe246c0fda87bb26227bb826eebadb418a220f"
  :revdesc "fbbe246c0fda")
