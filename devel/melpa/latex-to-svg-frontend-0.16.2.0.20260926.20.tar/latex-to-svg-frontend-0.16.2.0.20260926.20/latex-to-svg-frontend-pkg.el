;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "0.16.2.0.20260926.20"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.10.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "323d0ea84b6bcb83cabbfebee84debf2abbb6427"
  :revdesc "v0.16.2-20-g323d0ea84b6b"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
