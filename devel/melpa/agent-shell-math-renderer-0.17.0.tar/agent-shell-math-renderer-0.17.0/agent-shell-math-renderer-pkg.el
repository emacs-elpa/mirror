;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.17.0"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.89.1")
    (latex-to-svg-backend "0.18.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "dee33f819c3bc01b8df7ee9b3e4d834dc0256bf6"
  :revdesc "v0.17.0-0-gdee33f819c3b"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
