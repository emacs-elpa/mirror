;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minizinc-ts-mode" "0.0.0.20250831.11"
  "Major mode for the MiniZinc constraint modeling language."
  '((emacs "29.1"))
  :url "https://github.com/AjaiKN/minizinc-ts-mode"
  :commit "c449cde23b8101c589a4cce20b01ea1933978be0"
  :revdesc "c449cde23b81"
  :keywords '("languages")
  :authors '(("Ajai Khatri Nelson" . "emacs@ajai.dev"))
  :maintainers '(("Ajai Khatri Nelson" . "emacs@ajai.dev")))
