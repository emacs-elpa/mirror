;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpmc-queue" "0.1.1.0.20180303.3"
  "A multiple-producer-multiple-consumer queue."
  '((emacs "26.0")
    (queue "0.2.0"))
  :url "https://github.com/smizoe/mpmc-queue"
  :commit "df07d6bef7468edb1d73ef73b8331b94d0e5d0ca"
  :revdesc "0.1.1-3-gdf07d6bef746"
  :keywords '("lisp" "async")
  :authors '(("Sho Mizoe" . "sho.mizoe@gmail.com"))
  :maintainers '(("Sho Mizoe" . "sho.mizoe@gmail.com")))
