;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "countdown-modeline" "1.3.2"
  "Display a color-coded countdown in the modeline."
  '((emacs "27.1"))
  :url "https://github.com/jholland82/countdown-modeline"
  :commit "7485863972bd941a786bc595d566e02a490bb352"
  :revdesc "v1.3.2-0-g7485863972bd"
  :keywords '("convenience" "modeline")
  :authors '(("Jeffrey Holland" . "jeff.holland@gmail.com"))
  :maintainers '(("Jeffrey Holland" . "jeff.holland@gmail.com")))
