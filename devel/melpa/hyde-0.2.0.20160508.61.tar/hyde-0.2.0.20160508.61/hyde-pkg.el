;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyde" "0.2.0.20160508.61"
  "Major mode to help create and manage Jekyll blogs."
  ()
  :url "https://github.com/nibrahim/Hyde"
  :commit "a8cd6ed00ecd8d7de0ded2f4867015b412b15b76"
  :revdesc "0.2-61-ga8cd6ed00ecd")
