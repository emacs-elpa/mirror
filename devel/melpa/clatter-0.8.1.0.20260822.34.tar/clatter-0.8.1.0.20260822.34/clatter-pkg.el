;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.8.1.0.20260822.34"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "e0b05926d8ef8432e9940b1f90d40ed5fd2052b8"
  :revdesc "e0b05926d8ef"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
