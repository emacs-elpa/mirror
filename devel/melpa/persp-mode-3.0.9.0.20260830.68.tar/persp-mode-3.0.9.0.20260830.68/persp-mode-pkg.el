;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persp-mode" "3.0.9.0.20260830.68"
  "Windows/buffers sets shared among frames + save/load."
  '((emacs "24.3"))
  :url "https://github.com/Bad-ptr/persp-mode.el"
  :commit "4cd5f47bd7208e4dbefe8053ec6d26271ce2ea88"
  :revdesc "4cd5f47bd720"
  :keywords '("perspectives" "session" "workspace" "persistence" "windows" "buffers" "convenience")
  :authors '(("Constantin Kulikov" . "zxnotdead@gmail.com"))
  :maintainers '(("Constantin Kulikov" . "zxnotdead@gmail.com")))
