;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-x" "0.1.0.0.20260713.12"
  "Extended flex completion style."
  '((emacs "30.1"))
  :url "https://github.com/kn66/flex-x"
  :commit "c5fba3d76b1eab42f9e524f0c48d6db61274aeb1"
  :revdesc "c5fba3d76b1e"
  :keywords '("convenience" "matching")
  :authors '(("kn66" . "https://github.com/kn66"))
  :maintainers '(("kn66" . "https://github.com/kn66")))
