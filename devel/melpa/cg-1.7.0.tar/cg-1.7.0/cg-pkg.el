;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cg" "1.7.0"
  "Major mode for editing Constraint Grammar files."
  '((emacs "26.1"))
  :url "https://edu.visl.dk/constraint_grammar.html"
  :commit "4dd86c3c926bc4af93aa046d3579832513a4cac2"
  :revdesc "4dd86c3c926b"
  :keywords '("languages")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
