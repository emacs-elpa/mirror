;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab" "3.9.0.0.20260802.1"
  "An interface for GitLab."
  '((emacs       "27.1")
    (request     "0.3.2")
    (s           "1.10.0")
    (f           "0.20.0")
    (compat      "29.1.4.4")
    (promise     "1.1")
    (async-await "1.1"))
  :url "https://github.com/isamert/lab.el"
  :commit "d17adf0a86f716527187c1504423b8b56d3d415c"
  :revdesc "v3.9.0-1-gd17adf0a86f7"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
