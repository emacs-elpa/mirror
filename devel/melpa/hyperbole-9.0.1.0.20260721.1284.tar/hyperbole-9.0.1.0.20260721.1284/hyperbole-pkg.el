;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.0.1.0.20260721.1284"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "ab89df9204d94739843bc87a192809dc7400d3f1"
  :revdesc "ab89df9204d9"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
