;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-caldav" "3.1.0.20260501.20"
  "Sync org files with external calendar through CalDAV."
  '((emacs "26.3")
    (org   "9.1"))
  :url "https://github.com/dengste/org-caldav/"
  :commit "14f541814df597395fddb44b6e4bdb7c20f72cbe"
  :revdesc "14f541814df5"
  :keywords '("calendar" "caldav")
  :authors '(("David Engster" . "deng@randomsample.de"))
  :maintainers '(("David Engster" . "deng@randomsample.de")))
