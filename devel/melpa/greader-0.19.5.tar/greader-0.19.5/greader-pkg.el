;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "0.19.5"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "5c304ad008d8688e4eccd9947ba5e410399bf021"
  :revdesc "v0.19.5-0-g5c304ad008d8"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
