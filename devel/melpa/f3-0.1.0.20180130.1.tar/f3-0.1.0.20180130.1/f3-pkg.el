;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f3" "0.1.0.20180130.1"
  "A helm interface to find."
  '((emacs  "24.3")
    (helm   "2.8.8")
    (cl-lib "0.5"))
  :url "https://github.com/cosmicexplorer/f3"
  :commit "000009ce4adf7a57eae80512f29c4ec2a1391ce5"
  :revdesc "000009ce4adf"
  :keywords '("find" "file" "files" "helm" "fast" "finder"))
