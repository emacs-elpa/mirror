;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zenburn-theme" "2.10.0"
  "A low contrast color theme for Emacs."
  ()
  :url "https://github.com/bbatsov/zenburn-emacs"
  :commit "8697934a57151de119744ea79fde83120e05b88d"
  :revdesc "8697934a5715"
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
