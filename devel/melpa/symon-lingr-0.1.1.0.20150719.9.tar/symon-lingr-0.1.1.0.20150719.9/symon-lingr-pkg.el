;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symon-lingr" "0.1.1.0.20150719.9"
  "A notification-based Lingr client powered by symon.el."
  '((symon  "1.1.2")
    (cl-lib "0.5"))
  :url "http://hins11.yu-yake.com/"
  :commit "056d1a473e36992ff5881e5ce6fdc331cead975f"
  :revdesc "056d1a473e36")
