;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chaos-mode" "0.0.1.0.20221227.1"
  "A major mode for the Chaos programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/chaos-mode"
  :commit "801d869c461166eb2face2554b9b7883a26374c6"
  :revdesc "801d869c4611"
  :keywords '("files" "chaos"))
