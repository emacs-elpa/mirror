;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "0.4.0.20261104.5"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "9345d91c59beb622f64173c77ff2988da9a1df21"
  :revdesc "9345d91c59be"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
