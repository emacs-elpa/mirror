;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "extempore-mode" "1.0.0.20220704.72"
  "Emacs major mode for Extempore source files."
  '((emacs "24.4"))
  :url "https://github.com/extemporelang/extempore-emacs-mode"
  :commit "92e0fff482a0a4dc2971c39581c5ea9e84ae5e1c"
  :revdesc "92e0fff482a0"
  :keywords '("extempore")
  :authors '(("Ben Swift" . "ben@benswift.me"))
  :maintainers '(("Ben Swift" . "ben@benswift.me")))
