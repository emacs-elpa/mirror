;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-browse" "0.8.8.0.20140508.2"
  "Web browsing helpers for OS X."
  '((string-utils    "0.3.2")
    (browse-url-dwim "0.6.6"))
  :url "https://github.com/rolandwalker/osx-browse"
  :commit "838b81625853e04919fbb56fd21f387762b2e3f5"
  :revdesc "v0.8.8-2-g838b81625853"
  :keywords '("hypermedia" "external")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
