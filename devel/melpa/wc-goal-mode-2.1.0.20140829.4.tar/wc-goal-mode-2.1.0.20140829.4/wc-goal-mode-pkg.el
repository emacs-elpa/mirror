;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wc-goal-mode" "2.1.0.20140829.4"
  "Running word count with goals (minor mode)."
  ()
  :url "https://github.com/bnbeckwith/wc-goal-mode"
  :commit "bf21ab9c5a449bcc20dd207a4915dcec218d2699"
  :revdesc "v2.1-4-gbf21ab9c5a44")
