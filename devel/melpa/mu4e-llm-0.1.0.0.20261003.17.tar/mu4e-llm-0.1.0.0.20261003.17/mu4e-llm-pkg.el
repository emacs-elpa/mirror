;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-llm" "0.1.0.0.20261003.17"
  "AI-powered email assistance for mu4e."
  '((emacs "28.1")
    (llm   "0.17"))
  :url "https://github.com/sillyfellow/mu4e-llm"
  :commit "9b87454d984b3f0ef00a95442b4ae7fd1beaefa0"
  :revdesc "v0.1.0-17-g9b87454d984b"
  :keywords '("mail" "convenience")
  :authors '(("Dr. Sandeep Sadanandan" . "sillyfellow@whybenormal.org"))
  :maintainers '(("Dr. Sandeep Sadanandan" . "sillyfellow@whybenormal.org")))
