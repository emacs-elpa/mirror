;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-restclient" "0.2.0.20250806.49"
  "Org-babel functions for restclient-mode."
  '((restclient "0"))
  :url "https://github.com/alf/ob-restclient.el"
  :commit "94dd9cd98ff50717135ed5089afb378616faf11a"
  :revdesc "94dd9cd98ff5"
  :keywords '("literate programming" "reproducible research"))
