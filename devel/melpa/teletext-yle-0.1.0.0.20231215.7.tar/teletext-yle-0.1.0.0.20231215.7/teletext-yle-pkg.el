;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "teletext-yle" "0.1.0.0.20231215.7"
  "Teletext provider for Finnish national network YLE."
  '((emacs    "24.3")
    (teletext "0.1"))
  :url "https://github.com/lassik/emacs-teletext-yle"
  :commit "59a287c26571db07e191ac86cdf0be312fec1964"
  :revdesc "59a287c26571"
  :keywords '("comm" "help" "hypermedia")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
