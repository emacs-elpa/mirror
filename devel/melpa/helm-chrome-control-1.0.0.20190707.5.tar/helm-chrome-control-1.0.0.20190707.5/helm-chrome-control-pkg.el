;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-chrome-control" "1.0.0.20190707.5"
  "Control Chrome tabs with Helm (macOS only)."
  '((emacs     "25.1")
    (helm-core "3.0"))
  :url "https://github.com/xuchunyang/helm-chrome-control"
  :commit "85c1473ef9baa43b6babe3a785a2742271069244"
  :revdesc "85c1473ef9ba")
