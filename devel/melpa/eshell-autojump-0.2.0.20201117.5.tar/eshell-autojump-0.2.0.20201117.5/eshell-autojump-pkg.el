;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-autojump" "0.2.0.20201117.5"
  "Autojump command for Eshell."
  ()
  :url "https://github.com/coldnew/eshell-autojump"
  :commit "c1056bfc6b46646ae1e606247689fef9aee621af"
  :revdesc "c1056bfc6b46"
  :maintainers '(("Lee" . "coldnew.tw@gmail.com")))
