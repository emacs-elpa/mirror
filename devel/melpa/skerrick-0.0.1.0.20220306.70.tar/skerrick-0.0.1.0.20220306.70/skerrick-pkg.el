;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "skerrick" "0.0.1.0.20220306.70"
  "REPL-driven development for NodeJS."
  '((emacs   "27.1")
    (request "0.3.2"))
  :url "https://github.com/anonimitoraf/skerrick"
  :commit "015de8369b8b6be0d4d1e21c24239a037350e87e"
  :revdesc "015de8369b8b"
  :keywords '("languages" "javascript" "js" "repl" "repl-driven")
  :authors '(("Rafael Nicdao" . "https://github.com/anonimitoraf"))
  :maintainers '(("Rafael Nicdao" . "nicdaoraf@gmail.com")))
