;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pine-script-mode" "3.5.4.0.20250826.2"
  "Major mode for TradingView Pine Script v6 and older."
  '((emacs "24"))
  :url "https://github.com/darrylhebbes/pine-script-mode"
  :commit "f8c8ae596ca6296b9d5f618ff5b82c223d007ed5"
  :revdesc "f8c8ae596ca6"
  :keywords '("extensions" "pinescript")
  :authors '(("Eric Crosson" . "eric.s.crosson@utexas.edu"))
  :maintainers '(("Darryl Hebbes" . "darryl.hebbes@gmail.com")))
