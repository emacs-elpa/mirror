;;; neocaml-repl.el --- OCaml toplevel integration for neocaml -*- lexical-binding: t; -*-

;; Copyright © 2025-2026 Bozhidar Batsov
;;
;; Author: Bozhidar Batsov <bozhidar@batsov.dev>

;; This file is not part of GNU Emacs.

;;; Commentary:

;; This library provides integration with the OCaml toplevel (REPL)
;; for the neocaml package.

;;; License:

;; This program is free software; you can redistribute it and/or
;; modify it under the terms of the GNU General Public License
;; as published by the Free Software Foundation; either version 3
;; of the License, or (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with GNU Emacs; see the file COPYING.  If not, write to the
;; Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
;; Boston, MA 02110-1301, USA.

;;; Code:

(require 'comint)
(require 'pulse)
(require 'subr-x)
(require 'neocaml)
(require 'neocaml-common)

(defgroup neocaml-repl nil
  "OCaml REPL (toplevel) integration for neocaml."
  :prefix "neocaml-repl-"
  :group 'neocaml)

(defcustom neocaml-repl-program-name "ocaml"
  "Program name for invoking an OCaml toplevel."
  :type 'string
  :group 'neocaml-repl
  :package-version '(neocaml . "0.1.0"))

(defcustom neocaml-repl-program-args '("-nopromptcont")
  "Command line arguments for `neocaml-repl-program-name'.

By default this passes \"-nopromptcont\" to the standard `ocaml` toplevel
to disable continuation prompts for multi-line input, which produces a
cleaner REPL experience in `comint' buffers.

If you use an alternative OCaml toplevel or REPL (for example, by setting
`neocaml-repl-program-name' to a program other than \"ocaml\"), that
program may not understand \"-nopromptcont\".  In such cases you should
customize this variable and remove or adapt the default flag so it matches
the command-line interface of the selected REPL."
  :type '(repeat string)
  :group 'neocaml-repl
  :package-version '(neocaml . "0.1.0"))

(defcustom neocaml-repl-buffer-name "*OCaml*"
  "Base name of the OCaml toplevel buffer.
Per-project REPLs derive their name from this (e.g. \"*OCaml: proj*\")."
  :type 'string
  :group 'neocaml-repl
  :package-version '(neocaml . "0.1.0"))

(defcustom neocaml-repl-flavor 'ocaml
  "Which OCaml toplevel `neocaml-repl' launches.
- `ocaml': the standard ocaml toplevel, using `neocaml-repl-program-name'
  and `neocaml-repl-program-args'.
- `utop': the utop toplevel.
- `dune-utop': `dune utop' for the current dune project, run from its
  root and following `neocaml-dune-program' and
  `neocaml-dune-use-opam-exec'.

Set this globally or per project via a `.dir-locals.el' file; the REPL
reads it when it starts."
  :type '(choice (const :tag "Standard ocaml toplevel" ocaml)
                 (const :tag "utop" utop)
                 (const :tag "dune utop" dune-utop))
  :safe (lambda (v) (memq v '(ocaml utop dune-utop)))
  :group 'neocaml-repl
  :package-version '(neocaml . "0.9.0"))

(defcustom neocaml-repl-history-file
  (expand-file-name "neocaml-repl-history" user-emacs-directory)
  "File to persist OCaml REPL input history across sessions.
Set to nil to disable history persistence."
  :type '(choice (file :tag "History file")
                 (const :tag "Disable" nil))
  :group 'neocaml-repl
  :package-version '(neocaml . "0.2.0"))

(defcustom neocaml-repl-history-size 1000
  "Maximum number of input history entries to persist."
  :type 'integer
  :group 'neocaml-repl
  :package-version '(neocaml . "0.2.0"))

(defcustom neocaml-repl-fontify-input t
  "When non-nil, fontify REPL input using tree-sitter via `neocaml-mode'.
This uses `comint-fontify-input-mode' (Emacs 29.1+) to provide full
syntax highlighting for OCaml code you type in the REPL, while REPL
output (errors, warnings, values) keeps its own highlighting.

Set to nil to use only the basic REPL font-lock keywords for input."
  :type 'boolean
  :group 'neocaml-repl
  :package-version '(neocaml . "0.6.0"))

(defcustom neocaml-repl-fontify-output t
  "When non-nil, fontify the toplevel's responses using tree-sitter.
The signatures in responses like \"val x : int list = [1; 2]\" are
fontified as `neocaml-interface-mode' would fontify them, and the
values as `neocaml-mode' would.

Set to nil to use only the basic REPL font-lock keywords for output."
  :type 'boolean
  :group 'neocaml-repl
  :package-version '(neocaml . "0.11.0"))

(defconst neocaml-repl--prompt-regexp
  "^\\(?:utop\\(?:\\[[0-9]+\\]\\)? \\)?# "
  "Regexp matching OCaml toplevel prompts.
Matches both the standard \"# \" prompt and utop's \"utop # \" / \"utop[0] # \".")

(defun neocaml-repl--after-prompts (regexp)
  "Return REGEXP, anchored with ^, made to match past the prompt as well.
Any number of prompts can come first: the toplevel's answer to a phrase
sent from a source buffer, which it doesn't echo, begins right after
the prompt."
  (concat "^\\(?:" (string-remove-prefix "^" comint-prompt-regexp) "\\)*"
          (string-remove-prefix "^" regexp)))

(defvar-local neocaml-repl--source-buffer nil
  "Source buffer from which the REPL was last invoked.
Used by `neocaml-repl-switch-to-source' to return to the source buffer.")

;;;; Per-project REPL buffers
;;
;; Each project gets its own dedicated REPL, so source files send to the
;; toplevel for their project.  The buffer name is derived from
;; `neocaml-repl-buffer-name' plus the project identifier; buffers outside
;; any project share the base name.

(defun neocaml-repl--project-id ()
  "Return a short identifier for the current buffer's project, or nil.
That's the name of the `project.el' project, or failing that of the
dune project.  When the dune project sits below the `project.el' root,
as in a monorepo, its path is appended (e.g. \"mono/pkg/a\"), so each
dune project gets a session of its own."
  (let ((project (when-let* ((proj (project-current)))
                   (file-name-as-directory (expand-file-name (project-root proj)))))
        (dune (neocaml-common-dune-project-root)))
    (when-let* ((root (or project dune)))
      (let ((name (file-name-nondirectory (directory-file-name root))))
        ;; Compare true names, since the two roots can be spelled
        ;; differently (through a symlink, say).
        (if (and project dune
                 (not (file-equal-p project dune))
                 (file-in-directory-p dune project))
            (concat name "/" (directory-file-name
                              (file-relative-name (file-truename dune)
                                                  (file-truename project))))
          name)))))

(defun neocaml-repl--buffer ()
  "Return the name of the REPL buffer for the current context.
In a REPL buffer, that is the buffer itself.  In a source buffer, it is
the per-project REPL derived from `neocaml-repl-buffer-name' and the
project identifier (or the base name when there is no project)."
  (cond
   ((derived-mode-p 'neocaml-repl-mode) (buffer-name))
   ((when-let* ((id (neocaml-repl--project-id)))
      (let ((base (if (string-suffix-p "*" neocaml-repl-buffer-name)
                      (substring neocaml-repl-buffer-name 0 -1)
                    neocaml-repl-buffer-name)))
        (format "%s: %s*" base id))))
   (t neocaml-repl-buffer-name)))

(defvar-local neocaml-repl--flavor nil
  "The flavor (toplevel kind) of this REPL buffer.
One of the symbols accepted by `neocaml-repl-flavor'.")

(defvar-local neocaml-repl--command-line nil
  "The (DIR PROGRAM . ARGS) this REPL buffer was started with.
Recorded so `neocaml-repl-restart' relaunches the same toplevel even
though it runs from the REPL buffer, which lacks the source's
directory-local `neocaml-repl-flavor'.")

(declare-function neocaml-dune--utop-command "neocaml-dune-interaction" ())

(defun neocaml-repl--command ()
  "Return (DIR PROGRAM . ARGS) for the current `neocaml-repl-flavor'.
DIR is the directory to run the toplevel in.  The `ocaml' flavor uses
`neocaml-repl-program-name' and `neocaml-repl-program-args', `utop' the
utop toplevel, both run from the current directory, and `dune-utop'
runs `dune utop' from the dune project root."
  (pcase neocaml-repl-flavor
    ('utop (list default-directory "utop"))
    ('dune-utop
     (require 'neocaml-dune-interaction)
     (neocaml-dune--utop-command))
    (_ (append (list default-directory neocaml-repl-program-name)
               neocaml-repl-program-args))))

(defun neocaml-repl--start-command (bufname command flavor)
  "Start a REPL in BUFNAME running COMMAND for FLAVOR, and return the buffer.
COMMAND is a (DIR PROGRAM . ARGS) list, as returned by
`neocaml-repl--command', and the toplevel runs in DIR.  Records FLAVOR
and COMMAND buffer-locally so the REPL can be restarted as the same
toplevel."
  (let ((buffer (get-buffer-create bufname)))
    (with-current-buffer buffer
      ;; A REPL buffer outlives its process, so set the directory every
      ;; time instead of keeping the one the buffer was first created in.
      (setq default-directory (car command))
      (apply #'make-comint-in-buffer "OCaml" buffer
             (cadr command) nil (cddr command))
      (neocaml-repl-mode)
      (setq neocaml-repl--flavor flavor)
      (setq neocaml-repl--command-line command)
      (setq mode-name (format "OCaml-REPL[%s]" flavor)))
    buffer))

(defun neocaml-repl--kill (bufname)
  "Kill the REPL process running in BUFNAME, if any."
  (when (comint-check-proc bufname)
    (let ((proc (get-buffer-process bufname)))
      (when proc
        (set-process-query-on-exit-flag proc nil)
        (delete-process proc)))))

(defvar neocaml-repl-mode-map
  (let ((map (make-sparse-keymap)))
    (set-keymap-parent map comint-mode-map)
    (define-key map (kbd "C-c C-z") #'neocaml-repl-switch-to-source)
    (easy-menu-define neocaml-repl-mode-menu map "OCaml REPL Menu"
      '("OCaml REPL"
        ["Switch to Source" neocaml-repl-switch-to-source
         :help "Switch back to the source buffer that last invoked the REPL"]
        "--"
        ["Interrupt" neocaml-repl-interrupt
         :help "Interrupt the OCaml toplevel process"]
        ["Restart" neocaml-repl-restart
         :help "Kill and restart the OCaml toplevel"]
        ["Clear Buffer" neocaml-repl-clear-buffer
         :help "Erase the REPL buffer contents"]
        "--"
        ["Customize OCaml REPL..." (customize-group 'neocaml-repl)
         :help "Customize the OCaml REPL settings"]))
    map)
  "Keymap for `neocaml-repl-mode'.")

;;;; Output fontification
;;
;; The toplevel answers a phrase with signature items like
;; "val x : int list = [1; 2]" or "type t = A | B", continuing long ones
;; on indented lines.  Each response is fontified in a hidden buffer, the
;; signature in `neocaml-interface-mode' and the value in `neocaml-mode',
;; and the faces it gets there are copied back.

(defconst neocaml-repl--response-regexp
  "\\(?:val\\|type\\|module\\|exception\\|class\\|external\\) \\|- :\\|Exception: "
  "Regexp matching the start of a toplevel response.")

(defconst neocaml-repl--elision-regexp "<[a-z][a-z ]*>\\|\\.\\.\\."
  "Regexp matching what the toplevel prints for the values it doesn't show.
That's <fun>, <abstr>, <unknown constructor> and the like, and the ...
standing for the rest of a long or deep value.")

(defconst neocaml-repl--fontify-max-length 4000
  "Length beyond which a response isn't fontified with tree-sitter.")

(defvar-local neocaml-repl--response-start nil
  "Regexp matching the start of a toplevel response after any prompts.
Its last group matches the response.  Nil in buffers that don't
fontify the toplevel's responses with tree-sitter.")

(defun neocaml-repl--fontify-buffer (mode)
  "Return the hidden buffer in MODE that fontifies toplevel output."
  (let ((name (format " *neocaml-fontify-%s*" mode)))
    (or (get-buffer name)
        (with-current-buffer (get-buffer-create name)
          ;; Only MODE's font-lock settings matter here, so keep the user's
          ;; mode hooks (Eglot and the like) from running.
          (delay-mode-hooks (funcall mode))
          (current-buffer)))))

(defun neocaml-repl--fontify-as (mode prefix beg end)
  "Fontify the text between BEG and END as MODE would after PREFIX.
Elided values (see `neocaml-repl--elision-regexp') outside strings
become units for the parse, so they don't break it up, and get no face."
  (let ((text (buffer-substring-no-properties beg end))
        (offset (- beg (length prefix) 1))
        (faces nil))
    (with-current-buffer (neocaml-repl--fontify-buffer mode)
      ;; Font-lock inhibits modification hooks, but this buffer needs
      ;; them to keep its `syntax-ppss' cache in step with its text.
      (let ((inhibit-modification-hooks nil)
            (elisions nil))
        (erase-buffer)
        (insert prefix text)
        (goto-char (point-min))
        (while (re-search-forward neocaml-repl--elision-regexp nil t)
          (unless (save-match-data (nth 8 (syntax-ppss)))
            (push (cons (match-beginning 0) (match-end 0)) elisions)
            (replace-match (concat "(" (make-string (- (match-end 0) (match-beginning 0) 2) ?\s) ")")
                           t t)))
        (font-lock-fontify-region (point-min) (point-max))
        (pcase-dolist (`(,start . ,end) elisions)
          (remove-text-properties start end '(face nil)))
        (let ((pos (1+ (length prefix))))
          (while (< pos (point-max))
            (let ((next (next-single-property-change pos 'face nil (point-max))))
              (when-let* ((face (get-text-property pos 'face)))
                (push (list (+ pos offset) (+ next offset) face) faces))
              (setq pos next))))))
    (pcase-dolist (`(,start ,end ,face) faces)
      (put-text-property start end 'face face))))

(defun neocaml-repl--value-start (beg end)
  "Return the position of the = before the value of the response at BEG.
Return nil if the response, which ends at END, has no value."
  (save-excursion
    (goto-char beg)
    (let ((found nil))
      ;; The type can only have an = inside brackets, in a package type's
      ;; constraints or an operator's name.
      (while (and (not found) (search-forward "=" end t))
        (when (zerop (car (save-excursion (parse-partial-sexp beg (1- (point))))))
          (setq found (1- (point)))))
      found)))

(defun neocaml-repl--fontify-response (beg end)
  "Fontify the toplevel response between BEG and END."
  (save-excursion
    (goto-char beg)
    (if (looking-at "Exception: ")
        (neocaml-repl--fontify-as 'neocaml-mode "let _ = " (match-end 0)
                                  (if (eq (char-before end) ?.) (1- end) end))
      (let ((value (and (looking-at-p "val \\|- :")
                        (neocaml-repl--value-start beg end)))
            (anonymous (eq (char-after beg) ?-)))
        ;; Fontify "- : t" as the specification of a value named x.
        (neocaml-repl--fontify-as 'neocaml-interface-mode (if anonymous "val x" "")
                                  (if anonymous (1+ beg) beg) (or value end))
        (when value
          (neocaml-repl--fontify-as 'neocaml-mode "let _ " value end))))))

(defun neocaml-repl--continuation-line-p ()
  "Return non-nil if the current line continues the output before it."
  (and (looking-at-p "[ \t]+[^ \t\n]")
       (eq (get-text-property (point) 'field) 'output)))

(defun neocaml-repl--response-end ()
  "Return the end of the response starting on the current line."
  (save-excursion
    (end-of-line)
    (let ((end (point)))
      (while (and (zerop (forward-line 1))
                  (neocaml-repl--continuation-line-p))
        (end-of-line)
        (setq end (point)))
      end)))

(defun neocaml-repl--fontify-responses (limit)
  "Fontify the toplevel responses starting before LIMIT with tree-sitter.
A font-lock matcher that does the fontification itself and returns nil.
Responses that start out with a `font-lock-face', like utop's errors
or output colored with ANSI escapes, keep it."
  (when neocaml-repl--response-start
    (let ((group (regexp-opt-depth neocaml-repl--response-start)))
      (while (re-search-forward neocaml-repl--response-start limit t)
        (when-let* ((beg (match-beginning group))
                    ((eq (get-text-property beg 'field) 'output))
                    ((not (get-text-property beg 'font-lock-face)))
                    (end (neocaml-repl--response-end)))
          (when (<= (- end beg) neocaml-repl--fontify-max-length)
            (neocaml-repl--fontify-response beg end))
          (goto-char end)))))
  nil)

(defvar font-lock-beg)
(defvar font-lock-end)

(defun neocaml-repl--extend-region ()
  "Extend the font-lock region over the whole responses at its ends.
Responses too long to be fontified with tree-sitter (see
`neocaml-repl--fontify-max-length') don't extend it.  For
`font-lock-extend-region-functions'."
  (let ((changed nil))
    (save-excursion
      (goto-char font-lock-beg)
      (forward-line 0)
      (let ((limit (- (point) neocaml-repl--fontify-max-length)))
        (while (and (neocaml-repl--continuation-line-p)
                    (> (point) limit)
                    (zerop (forward-line -1))))
        (when (and (> (point) limit) (< (point) font-lock-beg))
          (setq font-lock-beg (point)
                changed t)))
      (goto-char font-lock-end)
      (unless (bolp) (forward-line 1))
      (let ((limit (+ (point) neocaml-repl--fontify-max-length)))
        (while (and (neocaml-repl--continuation-line-p)
                    (< (point) limit)
                    (zerop (forward-line 1))))
        (when (and (< (point) limit) (> (point) font-lock-end))
          (setq font-lock-end (point)
                changed t))))
    changed))

(defun neocaml-repl--fontify-output-setup ()
  "Fontify the toplevel's responses in the current buffer with tree-sitter.
For a buffer whose font-lock keywords include
`neocaml-repl--fontify-responses'."
  (when (and (treesit-ready-p 'ocaml t) (treesit-ready-p 'ocaml-interface t))
    (setq neocaml-repl--response-start
          (neocaml-repl--after-prompts (concat "^\\(" neocaml-repl--response-regexp "\\)")))
    (add-hook 'font-lock-extend-region-functions #'neocaml-repl--extend-region nil t)))

(defun neocaml-repl--error-navigation-setup (&optional plain)
  "Make the locations of errors, warnings and backtraces in files clickable.
That's with `compilation-shell-minor-mode' and neocaml's OCaml error
regexp, made to match past the prompt (see
`neocaml-repl--after-prompts'), so it has to run after
`comint-prompt-regexp' is set.  With PLAIN, compilation's own
highlighting is off, for a transcript that already puts the warning
face on errors, which it would paint over."
  (when plain
    (setq-local compilation-mode-font-lock-keywords nil))
  (setq-local compilation-error-regexp-alist
              `((,(neocaml-repl--after-prompts neocaml--compilation-error-regexp)
                 ;; FILE LINE COLUMN TYPE HYPERLINK, then HIGHLIGHT
                 ,@(if plain
                       (seq-take neocaml--compilation-error-spec 5)
                     neocaml--compilation-error-spec))))
  (compilation-shell-minor-mode))

(defvar neocaml-repl-font-lock-keywords
  `(;; the toplevel's responses, with tree-sitter (`neocaml-repl-fontify-output')
    (neocaml-repl--fontify-responses)
    ("^\\(# *\\)\\([^;]*\\)\\(;;\\)" (1 font-lock-comment-face) (3 font-lock-comment-face))
    ;; errors, overriding the face `compilation-shell-minor-mode' gives
    ;; the word starting a "word:" line
    ("^\\(Error:\\)" (1 font-lock-warning-face t))
    ;; warnings ("Warning 26 [unused-var]:") and alerts
    ("^\\(\\(?:Warning\\|Alert\\)[^:\n]*:\\)" (1 font-lock-warning-face t))
    ;; uncaught exceptions, after the prompt when the phrase came from a
    ;; source buffer and wasn't echoed
    ("\\(?:^\\|# \\)\\(Exception:\\)" (1 font-lock-warning-face t))
    ;; values and types from result
    ("\\(val\\) \\([^:]*\\)\\( *:\\)" (1 font-lock-keyword-face) (2 font-lock-variable-name-face))
    ("\\(type\\) \\([^ =]*\\)" (1 font-lock-keyword-face) (2 font-lock-type-face))
    ;; prompt (standard "# " and utop's "utop # " / "utop[0] # ")
    (,neocaml-repl--prompt-regexp . font-lock-comment-face))
  "Font-lock keywords for the OCaml REPL buffer.
Highlights prompts, errors, warnings, and toplevel response values.")

(define-derived-mode neocaml-repl-mode comint-mode "OCaml-REPL"
  "Major mode for interacting with an OCaml toplevel.

\\{neocaml-repl-mode-map}"
  (setq comint-prompt-regexp neocaml-repl--prompt-regexp)
  (setq comint-prompt-read-only t)
  (setq comint-input-sender 'neocaml-repl--input-sender)
  (setq comint-process-echoes nil)
  ;; Strip ANSI escape sequences emitted by utop and other enhanced toplevels
  (ansi-color-for-comint-mode-on)
  (setq-local comment-start "(* ")
  (setq-local comment-end " *)")
  (setq-local comment-start-skip "(\\*+[ \t]*")
  (setq-local font-lock-defaults '(neocaml-repl-font-lock-keywords t))

  ;; Error navigation for the files the toplevel reports errors,
  ;; warnings and backtraces in (those loaded with #use, say)
  (neocaml-repl--error-navigation-setup)

  ;; Input history persistence
  (when neocaml-repl-history-file
    (setq comint-input-ring-file-name neocaml-repl-history-file)
    (setq comint-input-ring-size neocaml-repl-history-size)
    (setq comint-input-ignoredups t)
    (comint-read-input-ring t)
    (add-hook 'kill-buffer-hook #'comint-write-input-ring nil t))

  ;; Setup prettify-symbols (users enable prettify-symbols-mode via hooks)
  (setq-local prettify-symbols-alist (neocaml--prettify-symbols-alist))

  ;; Tree-sitter fontification for REPL input
  (when neocaml-repl-fontify-input
    (setq-local comint-indirect-setup-function #'neocaml-mode)
    (comint-fontify-input-mode))

  ;; Tree-sitter fontification for the toplevel's responses
  (when neocaml-repl-fontify-output
    (neocaml-repl--fontify-output-setup)))

(defun neocaml-repl--input-sender (proc input)
  "Send INPUT to PROC, appending `;;' terminator if missing.
Only checks whether the input ends with `;;' (ignoring trailing whitespace),
to avoid false positives from `;;' inside strings or comments."
  (let* ((trimmed (string-trim-right input))
         (terminated (string-suffix-p ";;" trimmed)))
    (comint-send-string proc (if terminated
                                 (concat input "\n")
                               (concat input "\n;;\n")))))

;;;###autoload
(defun neocaml-repl-start (&optional command)
  "Start an OCaml toplevel for the current buffer's project.
If a REPL for the project is already running, switch to its buffer.
COMMAND is the (DIR PROGRAM . ARGS) to run, by default the one for
`neocaml-repl-flavor'."
  (interactive)
  (let ((bufname (neocaml-repl--buffer)))
    (if (comint-check-proc bufname)
        (pop-to-buffer bufname)
      (pop-to-buffer
       (neocaml-repl--start-command bufname
                                    (or command (neocaml-repl--command))
                                    neocaml-repl-flavor)))))

(defun neocaml-repl-switch-to-source ()
  "Switch from the REPL back to the source buffer that last invoked it."
  (interactive)
  (if (and neocaml-repl--source-buffer
           (buffer-live-p neocaml-repl--source-buffer))
      (pop-to-buffer neocaml-repl--source-buffer)
    (message "No source buffer to return to")))

;;;###autoload
(defun neocaml-repl-switch-to-repl ()
  "Switch to the OCaml REPL, saving the current buffer as the source.
If a REPL is already running, switch to it; otherwise start a new one.
Use \\[neocaml-repl-switch-to-source] in the REPL to return."
  (interactive)
  (let* ((source (current-buffer))
         (bufname (neocaml-repl--buffer))
         (running (comint-check-proc bufname))
         (running-flavor (and running
                              (buffer-local-value 'neocaml-repl--flavor
                                                  (get-buffer bufname))))
         command)
    (cond
     ;; A REPL with a different toplevel is running; offer to restart it
     ;; with the requested flavor (this is how `neocaml-dune-utop' and a
     ;; changed `neocaml-repl-flavor' take effect).
     ((and running (not (eq running-flavor neocaml-repl-flavor))
           ;; Work out the command first, so one that can't run here
           ;; (`dune-utop' outside a dune project) fails before the
           ;; running REPL is killed.
           (setq command (neocaml-repl--command))
           (y-or-n-p (format "An existing %s REPL is running for this project; \
restart it as %s? " running-flavor neocaml-repl-flavor)))
      (neocaml-repl--kill bufname)
      (neocaml-repl-start command))
     (running (pop-to-buffer bufname))
     (t (neocaml-repl-start)))
    (with-current-buffer bufname
      (setq neocaml-repl--source-buffer source))))

;;;###autoload
(defun neocaml-repl-send-region (start end)
  "Send the region between START and END to the OCaml REPL."
  (interactive "r")
  (let ((text (buffer-substring-no-properties start end)))
    (neocaml-repl--ensure-repl-running)
    (neocaml-repl--input-sender (neocaml-repl--process) text)
    (pulse-momentary-highlight-region start end)))

;;;###autoload
(defun neocaml-repl-send-buffer ()
  "Send the entire buffer to the OCaml REPL."
  (interactive)
  (neocaml-repl-send-region (point-min) (point-max)))

;;;###autoload
(defun neocaml-repl-send-definition ()
  "Send the current definition to the OCaml REPL."
  (interactive)
  (if-let* ((node (treesit-defun-at-point))
            (start (treesit-node-start node))
            (end (treesit-node-end node)))
      (neocaml-repl-send-region start end)
    (user-error "No definition at point")))

(defun neocaml-repl--search-phrase-delimiter (direction)
  "Search for a `;;' phrase delimiter in DIRECTION (1 or -1).
Skips matches inside strings and comments.  Returns the position
after the delimiter (forward) or before it (backward), or nil."
  (let ((search-fn (if (> direction 0) #'search-forward #'search-backward))
        (found nil))
    (save-excursion
      (while (and (not found)
                  (funcall search-fn ";;" nil t))
        (let ((state (syntax-ppss)))
          (unless (or (nth 3 state) (nth 4 state))
            (setq found (if (> direction 0) (point) (match-beginning 0)))))))
    found))

(defun neocaml-repl--phrase-bounds ()
  "Return (START . END) of the phrase at point, bounded by `;;'.
START falls back to `point-min' and END to `point-max'."
  (cons (or (neocaml-repl--search-phrase-delimiter -1) (point-min))
        (or (neocaml-repl--search-phrase-delimiter 1) (point-max))))

;;;###autoload
(defun neocaml-repl-send-phrase ()
  "Send the current phrase (code between `;;' delimiters) to the OCaml REPL.
Skips `;;' that appear inside strings or comments."
  (interactive)
  (let ((bounds (neocaml-repl--phrase-bounds)))
    (neocaml-repl-send-region (car bounds) (cdr bounds))))

;;;###autoload
(defun neocaml-repl-send-phrase-and-step ()
  "Send the phrase at point to the OCaml REPL, then move to the next phrase.
Like `neocaml-repl-send-phrase', but advances point past the closing
`;;' to the start of the following phrase, so repeated invocations walk
through the buffer."
  (interactive)
  (let ((bounds (neocaml-repl--phrase-bounds)))
    (neocaml-repl-send-region (car bounds) (cdr bounds))
    (goto-char (cdr bounds))
    (skip-chars-forward " \t\n")))

(defun neocaml-repl--process ()
  "Return the REPL process for the current context, or nil if not running."
  (get-buffer-process (neocaml-repl--buffer)))

(defun neocaml-repl--ensure-repl-running ()
  "Start a REPL for the current buffer's project if one is not running."
  (unless (comint-check-proc (neocaml-repl--buffer))
    (neocaml-repl-start)))

;;;###autoload
(defun neocaml-repl-load-file (file)
  "Load FILE into the OCaml REPL via the `#use' directive."
  (interactive (list (buffer-file-name)))
  (unless file
    (user-error "Buffer is not visiting a file"))
  (neocaml-repl--ensure-repl-running)
  (neocaml-repl--input-sender (neocaml-repl--process)
                               (format "#use %S" file)))

(declare-function neocaml-dune--ocamlfind-libraries "neocaml-dune" (root))

(defun neocaml-repl--read-package ()
  "Read a findlib package name, completing over the installed packages.
The candidates come from `ocamlfind list' in the current project's opam
switch.  Any name can be entered, so this works without ocamlfind too."
  (require 'neocaml-dune)
  (completing-read "Require package: "
                   (neocaml-dune--ocamlfind-libraries
                    (neocaml-common-dune-project-root))))

;;;###autoload
(defun neocaml-repl-require (package)
  "Load the findlib PACKAGE into the OCaml REPL via the `#require' directive.
This needs the toplevel to have findlib loaded (e.g. via topfind or utop).
Interactively, complete over the installed findlib packages."
  (interactive (list (neocaml-repl--read-package)))
  (neocaml-repl--ensure-repl-running)
  (neocaml-repl--input-sender (neocaml-repl--process)
                               (format "#require %S" package)))

(defun neocaml-repl-clear-buffer ()
  "Clear the OCaml REPL buffer for the current context."
  (interactive)
  (with-current-buffer (neocaml-repl--buffer)
    (let ((inhibit-read-only t))
      (erase-buffer)
      (comint-send-input))))

(defun neocaml-repl-interrupt ()
  "Interrupt the OCaml REPL process for the current context."
  (interactive)
  (when (comint-check-proc (neocaml-repl--buffer))
    (interrupt-process (neocaml-repl--process))))

;;;###autoload
(defun neocaml-repl-restart ()
  "Restart the OCaml toplevel for the current buffer's project.
Kill the running process, if any, and start a fresh one in the same
buffer, preserving the toplevel flavor it was launched with (so e.g. a
`dune-utop' REPL comes back as `dune-utop', not the default toplevel)."
  (interactive)
  (let* ((bufname (neocaml-repl--buffer))
         (buf (get-buffer bufname))
         (flavor (and buf (buffer-local-value 'neocaml-repl--flavor buf)))
         (command (and buf (buffer-local-value 'neocaml-repl--command-line buf))))
    (neocaml-repl--kill bufname)
    (if (and command flavor)
        (pop-to-buffer (neocaml-repl--start-command bufname command flavor))
      (neocaml-repl-start))))

;; Installation of the toplevel integration
(defvar neocaml-repl-mode-hook nil
  "Hook run after entering OCaml toplevel mode.")

(defvar neocaml-repl-minor-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-c C-z") #'neocaml-repl-switch-to-repl)
    (define-key map (kbd "C-c C-c") #'neocaml-repl-send-definition)
    (define-key map (kbd "C-c C-r") #'neocaml-repl-send-region)
    (define-key map (kbd "C-c C-b") #'neocaml-repl-send-buffer)
    (define-key map (kbd "C-c C-e") #'neocaml-repl-send-phrase)
    (define-key map (kbd "C-c C-s") #'neocaml-repl-send-phrase-and-step)
    (define-key map (kbd "C-c C-u") #'neocaml-repl-load-file)
    (define-key map (kbd "C-c C-q") #'neocaml-repl-interrupt)
    (define-key map (kbd "C-c C-k") #'neocaml-repl-clear-buffer)

    (easy-menu-define neocaml-repl-minor-mode-menu map "OCaml REPL Menu"
      '("OCaml REPL"
        ["Start/Switch to REPL" neocaml-repl-switch-to-repl
         :help "Start the OCaml REPL or switch to a running one"]
        "--"
        ["Send Definition" neocaml-repl-send-definition
         :help "Send the definition at point to the REPL"]
        ["Send Region" neocaml-repl-send-region
         :enable (use-region-p)
         :help "Send the active region to the REPL"]
        ["Send Buffer" neocaml-repl-send-buffer
         :help "Send the whole buffer to the REPL"]
        ["Send Phrase" neocaml-repl-send-phrase
         :help "Send the phrase at point to the REPL"]
        ["Send Phrase and Step" neocaml-repl-send-phrase-and-step
         :help "Send the phrase at point, then move to the next phrase"]
        ["Load File" neocaml-repl-load-file
         :help "Load a file into the REPL with #use"]
        ["Require Package..." neocaml-repl-require
         :help "Load a findlib package into the REPL with #require"]
        "--"
        ["Interrupt REPL" neocaml-repl-interrupt
         :enable (comint-check-proc (neocaml-repl--buffer))
         :help "Interrupt the OCaml toplevel process"]
        ["Clear REPL Buffer" neocaml-repl-clear-buffer
         :enable (comint-check-proc (neocaml-repl--buffer))
         :help "Erase the REPL buffer contents"]))
    map)
  "Keymap for OCaml toplevel integration.")

;;;###autoload
(define-minor-mode neocaml-repl-minor-mode
  "Minor mode for interacting with the OCaml toplevel.

\\{neocaml-repl-minor-mode-map}"
  :init-value nil
  :lighter " OCaml-REPL"
  :keymap neocaml-repl-minor-mode-map
  :group 'neocaml-repl)

(provide 'neocaml-repl)

;;; neocaml-repl.el ends here
