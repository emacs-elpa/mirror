;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub+" "0.3.0.20191229.13"
  "A thick GitHub API client built on ghub."
  '((emacs   "25")
    (ghub    "2.0")
    (apiwrap "0.5"))
  :url "https://github.com/vermiculus/ghub-plus"
  :commit "b1adef2402d7599911d4dd447a987a0cea04e6fe"
  :revdesc "0.3-13-gb1adef2402d7"
  :keywords '("extensions" "multimedia" "tools")
  :authors '(("Sean Allred" . "code@seanallred.com"))
  :maintainers '(("Sean Allred" . "code@seanallred.com")))
