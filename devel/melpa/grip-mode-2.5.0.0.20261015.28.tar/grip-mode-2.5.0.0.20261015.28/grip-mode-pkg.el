;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grip-mode" "2.5.0.0.20261015.28"
  "Instant GitHub-flavored Markdown/Org preview using grip."
  '((emacs "24.4"))
  :url "https://github.com/seagle0128/grip-mode"
  :commit "70e3a6e8978a09dfd5d5d5ca675304f5c8993539"
  :revdesc "70e3a6e8978a"
  :keywords '("convenience" "markdown" "preview")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
