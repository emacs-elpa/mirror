;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "4.5.0.20261102.318"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "af05b1cac037f3bfb4e2355f37c21f0d8dcb7978"
  :revdesc "v4.5-318-gaf05b1cac037"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
