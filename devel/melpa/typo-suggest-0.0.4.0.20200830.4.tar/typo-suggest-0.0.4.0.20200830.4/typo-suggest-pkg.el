;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typo-suggest" "0.0.4.0.20200830.4"
  "Don't make typos with the help of helm and company."
  '((emacs   "24.3")
    (helm    "3.0")
    (company "0.9.10")
    (s       "1.12.0")
    (dash    "2.13.0"))
  :url "https://github.com/kadircancetin/typo-suggest"
  :commit "3014d18ae2f0b6b857bb613f373e034c743f4d2e"
  :revdesc "3014d18ae2f0"
  :keywords '("convenience" "wp")
  :authors '(("Kadir Can etin" . "kadircancetin@gmail.com"))
  :maintainers '(("Kadir Can etin" . "kadircancetin@gmail.com")))
