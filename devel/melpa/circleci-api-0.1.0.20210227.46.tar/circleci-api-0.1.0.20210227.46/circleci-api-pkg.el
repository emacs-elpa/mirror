;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "circleci-api" "0.1.0.20210227.46"
  "Bindings for the CircleCI API."
  '((emacs   "27")
    (request "0.3.2"))
  :url "https://github.com/sulami/circleci-api"
  :commit "1432b0ad0f32b03fec564c0815951d5e096c2f6a"
  :revdesc "1432b0ad0f32")
