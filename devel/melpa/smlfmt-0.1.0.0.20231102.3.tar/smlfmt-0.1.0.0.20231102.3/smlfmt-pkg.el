;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smlfmt" "0.1.0.0.20231102.3"
  "Format SML source code using the \"smlfmt\" program."
  '((emacs       "24")
    (reformatter "0.4"))
  :url "https://github.com/diku-dk/smlfmt.el"
  :commit "7a70cce029a7c37c5e976ab6b426f62561e4e352"
  :revdesc "7a70cce029a7"
  :keywords '("files" "tools")
  :authors '(("Troels Henriksen" . "athas@sigkill"))
  :maintainers '(("Troels Henriksen" . "athas@sigkill")))
