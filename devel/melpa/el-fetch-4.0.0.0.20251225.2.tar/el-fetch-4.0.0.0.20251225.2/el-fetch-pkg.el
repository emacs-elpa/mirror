;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-fetch" "4.0.0.0.20251225.2"
  "Show system information in Neofetch-like style (eg CPU, RAM)."
  '((emacs "25.1"))
  :url "https://gitlab.com/xgqt/xgqt-elisp-app-el-fetch"
  :commit "169e2bffe77b43577acbf83d7d8073b6808b880e"
  :revdesc "4.0.0-2-g169e2bffe77b"
  :keywords '("games")
  :authors '(("Maciej Barć" . "xgqt@xgqt.org"))
  :maintainers '(("Maciej Barć" . "xgqt@xgqt.org")))
