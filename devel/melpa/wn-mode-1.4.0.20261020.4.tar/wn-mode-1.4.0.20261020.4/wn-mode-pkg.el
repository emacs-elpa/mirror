;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wn-mode" "1.4.0.20261020.4"
  "Numeric window switching shortcuts."
  '((emacs "24"))
  :url "https://github.com/luismbo/wn-mode"
  :commit "609685fb1ac1ee2bc475ad5139d1475f51b6aa2c"
  :revdesc "609685fb1ac1"
  :keywords '("buffers" "windows" "switching-windows")
  :maintainers '(("Luís Oliveira" . "luismbo@gmail.com")))
