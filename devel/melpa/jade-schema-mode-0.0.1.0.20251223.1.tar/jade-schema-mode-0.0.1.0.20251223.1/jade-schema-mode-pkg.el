;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jade-schema-mode" "0.0.1.0.20251223.1"
  "A major-mode for navigating Jade Platform schema files."
  '((emacs "26.3"))
  :url "https://github.com/danjacka/jade-schema-mode"
  :commit "9cc4f9b780ff40afd8dde21ab7f53a16401c3d09"
  :revdesc "9cc4f9b780ff"
  :keywords '("languages" "tools")
  :authors '(("Dan Jacka" . "danjacka@gmail.com"))
  :maintainers '(("Dan Jacka" . "danjacka@gmail.com")))
