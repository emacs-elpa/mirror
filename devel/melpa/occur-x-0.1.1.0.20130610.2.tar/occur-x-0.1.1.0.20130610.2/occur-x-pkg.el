;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occur-x" "0.1.1.0.20130610.2"
  "Extra functionality for occur."
  ()
  :url "https://github.com/juan-leon/occur-x"
  :commit "352f5fab207d8a1d3dd048073ff127a83e97c82b"
  :revdesc "352f5fab207d"
  :keywords '("occur" "search" "convenience")
  :authors '(("Juan-Leon Lahoz" . "juanleon1@gmail.com"))
  :maintainers '(("Juan-Leon Lahoz" . "juanleon1@gmail.com")))
