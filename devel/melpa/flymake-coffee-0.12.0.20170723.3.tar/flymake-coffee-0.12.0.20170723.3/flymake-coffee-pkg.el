;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-coffee" "0.12.0.20170723.3"
  "A flymake handler for coffee script."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-coffee"
  :commit "dee295acf30820ed15fe0de17137d50bc27fc80c"
  :revdesc "dee295acf308"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
