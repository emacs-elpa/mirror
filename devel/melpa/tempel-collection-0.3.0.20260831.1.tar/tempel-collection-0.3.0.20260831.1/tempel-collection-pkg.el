;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel-collection" "0.3.0.20260831.1"
  "Collection of templates for Tempel."
  '((tempel "0.5")
    (emacs  "31.1"))
  :url "https://github.com/Crandel/tempel-collection"
  :commit "d7a4f361fc35fb3a29cc0b905515c558e685e766"
  :revdesc "d7a4f361fc35"
  :keywords '("tools")
  :authors '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
             ("Max Penet" . "mpenetr@s-exp.com")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
                 ("Max Penet" . "mpenetr@s-exp.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
