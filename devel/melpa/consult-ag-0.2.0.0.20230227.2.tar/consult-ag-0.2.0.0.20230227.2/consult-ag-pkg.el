;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ag" "0.2.0.0.20230227.2"
  "The silver searcher integration using Consult."
  '((emacs   "27.1")
    (consult "0.32"))
  :url "https://github.com/yadex205/consult-ag"
  :commit "9eb4df265aedf2628a714610c2ade6d2f21de053"
  :revdesc "9eb4df265aed"
  :authors '(("Kanon Kakuno and contributors" . "yadex205@outlook.jp"))
  :maintainers '(("Kanon Kakuno and contributors" . "yadex205@outlook.jp")))
