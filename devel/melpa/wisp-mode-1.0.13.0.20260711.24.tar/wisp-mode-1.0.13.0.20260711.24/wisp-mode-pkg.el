;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wisp-mode" "1.0.13.0.20260711.24"
  "Tools for wisp: the Whitespace-to-Lisp preprocessor."
  '((emacs "24.4"))
  :url "http://www.draketo.de/english/wisp"
  :commit "97cdd788b49ea385cdc423b411af37dacd3bc5f9"
  :revdesc "v1.0.13-23-m97cdd788b49e"
  :keywords '("languages" "lisp" "scheme")
  :authors '(("Arne Babenhauserheide" . "arne_bab@web.de"))
  :maintainers '(("Arne Babenhauserheide" . "arne_bab@web.de")))
