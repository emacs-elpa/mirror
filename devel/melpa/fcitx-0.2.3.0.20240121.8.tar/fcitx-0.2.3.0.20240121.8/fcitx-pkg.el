;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fcitx" "0.2.3.0.20240121.8"
  "Make fcitx better in Emacs."
  ()
  :url "https://github.com/cute-jumper/fcitx.el"
  :commit "b399482ed8db5893db2701df01db4c38cccda495"
  :revdesc "b399482ed8db"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
