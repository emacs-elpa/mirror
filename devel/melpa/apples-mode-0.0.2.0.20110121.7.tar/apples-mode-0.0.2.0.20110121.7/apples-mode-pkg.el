;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apples-mode" "0.0.2.0.20110121.7"
  "Major mode for editing and executing AppleScript code."
  ()
  :url "https://github.com/tequilasunset/apples-mode"
  :commit "83a9ab0d6ba82496e2f7df386909b1a55701fccb"
  :revdesc "83a9ab0d6ba8"
  :keywords '("applescript" "languages")
  :authors '(("tequilasunset" . "tequilasunset.mac@gmail.com"))
  :maintainers '(("tequilasunset" . "tequilasunset.mac@gmail.com")))
