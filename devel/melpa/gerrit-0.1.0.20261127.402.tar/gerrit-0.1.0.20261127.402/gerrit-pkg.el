;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gerrit" "0.1.0.20261127.402"
  "Gerrit client."
  '((emacs "29.1")
    (magit "2.13.1")
    (s     "1.12.0")
    (dash  "0.2.15"))
  :url "https://github.com/twmr/gerrit.el"
  :commit "7fc2e3da400c552db0d3a83c7a228e274b7a4bca"
  :revdesc "7fc2e3da400c"
  :keywords '("extensions")
  :authors '(("Thomas Wimmer" . "thomaswimmer@posteo.com"))
  :maintainers '(("Thomas Wimmer" . "thomaswimmer@posteo.com")))
