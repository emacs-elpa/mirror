;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "on-parens" "0.0.0.20210928.20"
  "Smartparens wrapper to fit with evil-mode/vim normal-state."
  '((dash        "2.10.0")
    (emacs       "24")
    (evil        "1.1.6")
    (smartparens "1.6.3"))
  :url "https://github.com/willghatch/emacs-on-parens"
  :commit "b8ee8cea45c9b34820fcb951f522f13e3736d216"
  :revdesc "b8ee8cea45c9"
  :keywords '("evil" "smartparens"))
