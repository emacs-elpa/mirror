;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "4.0.9.0.20261104.8"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.9")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "ed6f56ac26d4e253ddb5d2c01d1711c3d7799b9d"
  :revdesc "v4.0.9-8-ged6f56ac26d4"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
