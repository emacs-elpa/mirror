;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agda-lib-mode" "0.1.1.0.20251013.1"
  "Major mode for Agda library files."
  '((emacs "24.3"))
  :url "https://codeberg.org/heraplem/agda-lib-mode"
  :commit "1cf7d486753887736eef6cae2688b2a05f9c1854"
  :revdesc "1cf7d4867538"
  :keywords '("text")
  :authors '(("Nicholas Coltharp" . "mail@heraplem.xyz"))
  :maintainers '(("Nicholas Coltharp" . "mail@heraplem.xyz")))
