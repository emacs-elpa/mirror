;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "0.10.0.0.20261007.2"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "687a65b244efb0dfc6126322f0e128b23ba44cfb"
  :revdesc "687a65b244ef"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
