;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "direx-grep" "0.1.0"
  "Grep node of direx.el using incremental search like anything.el/helm.el."
  '((direx "0.1alpha"))
  :url "https://github.com/aki2o/direx-grep"
  :commit "1109a512a80b2673a70b18b8568514049017faad"
  :revdesc "1109a512a80b"
  :keywords '("convenience")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
