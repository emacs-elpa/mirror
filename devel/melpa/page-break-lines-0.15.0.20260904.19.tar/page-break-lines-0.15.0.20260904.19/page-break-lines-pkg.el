;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "page-break-lines" "0.15.0.20260904.19"
  "Display ^L page breaks as tidy horizontal lines."
  '((emacs "25.1"))
  :url "https://github.com/purcell/page-break-lines"
  :commit "185594378c2c2d4621f68512f86577eaa698c43f"
  :revdesc "185594378c2c"
  :keywords '("convenience" "faces")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
