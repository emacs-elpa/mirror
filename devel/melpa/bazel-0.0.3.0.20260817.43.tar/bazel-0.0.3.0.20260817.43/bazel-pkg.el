;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3.0.20260817.43"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "60e71e394d694d68c29cdc6f079a065a6404d79b"
  :revdesc "60e71e394d69"
  :keywords '("build tools" "languages"))
