;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fetch" "0.1.2.0.20131201.2"
  "Fetch and unpack resources."
  ()
  :url "https://github.com/crshd/fetch.el"
  :commit "3f2793afcbbc32f320e572453166f9354ecc6d06"
  :revdesc "3f2793afcbbc"
  :authors '(("Christian 'crshd' Brassat" . "christian.brassat@gmail.com"))
  :maintainers '(("Christian 'crshd' Brassat" . "christian.brassat@gmail.com")))
