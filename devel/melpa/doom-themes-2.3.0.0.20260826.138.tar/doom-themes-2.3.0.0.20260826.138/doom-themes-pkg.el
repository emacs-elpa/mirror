;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-themes" "2.3.0.0.20260826.138"
  "An opinionated pack of modern color-themes."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/doomemacs/themes"
  :commit "a59202912ad55014e53a685eee6cd94130bdd4fd"
  :revdesc "v2.3.0-138-ga59202912ad5"
  :keywords '("themes" "faces")
  :authors '(("Henrik Lissner" . "contact@henrik.io"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
