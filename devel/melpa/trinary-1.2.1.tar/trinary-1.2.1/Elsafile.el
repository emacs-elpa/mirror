(register-extensions cl)
