;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "0.1.0.0.20261004.112"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "1a8cc6aaac43663ca19f783f2846e35f9bd066c3"
  :revdesc "1a8cc6aaac43"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
