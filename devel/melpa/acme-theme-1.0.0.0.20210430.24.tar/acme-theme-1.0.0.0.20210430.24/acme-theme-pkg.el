;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acme-theme" "1.0.0.0.20210430.24"
  "A color theme based on Acme & Sam from Plan 9."
  ()
  :url "https://github.com/ianpan870102/acme-emacs-theme"
  :commit "ae8788b5851ea353fbb80ab586a3bbd5dc8e91aa"
  :revdesc "ae8788b5851e")
