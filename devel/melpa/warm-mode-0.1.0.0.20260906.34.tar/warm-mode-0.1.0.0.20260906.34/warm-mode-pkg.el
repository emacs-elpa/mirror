;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "warm-mode" "0.1.0.0.20260906.34"
  "Warm colors for nighttime coding."
  '((emacs "27.1"))
  :url "https://github.com/smallwat3r/emacs-warm-mode"
  :commit "56309813b86daf20b663b457221569b49c5199f2"
  :revdesc "56309813b86d"
  :keywords '("faces" "convenience")
  :authors '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com"))
  :maintainers '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com")))
