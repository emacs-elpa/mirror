;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-tex" "1.0.2.0.20230715.34"
  "Useful features for editing LaTeX in evil-mode."
  '((emacs  "26.1")
    (evil   "1.0")
    (auctex "11.88"))
  :url "https://github.com/iyefrat/evil-tex"
  :commit "5dd1e852c8fb9e6efa2b748e89786526483e7619"
  :revdesc "5dd1e852c8fb"
  :keywords '("tex" "emulation" "vi" "evil" "wp")
  :authors '(("Yoav Marco" . "https://github.com/ymarco")
             ("Itai Y. Efrat" . "https://github.com/iyefrat"))
  :maintainers '(("Yoav Marco" . "yoavm448@gmail.com")
                 ("Itai Y. Efrat" . "itai3397@gmail.com")))
