;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sticky-scroll-mode" "1.0.1.0.20241213.2"
  "Sticky scrolling."
  '((emacs "29.4"))
  :url "https://github.com/jclasley/sticky-mode"
  :commit "a1acf1065f88a586770d0eeddec376907d8320c6"
  :revdesc "a1acf1065f88"
  :keywords '("convenience" "extensions" "tools")
  :authors '(("Jon Lasley" . "jon.lasley+sticky@gmail.com"))
  :maintainers '(("Jon Lasley" . "jon.lasley+sticky@gmail.com")))
