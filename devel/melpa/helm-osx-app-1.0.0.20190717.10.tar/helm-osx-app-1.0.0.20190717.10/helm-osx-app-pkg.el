;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-osx-app" "1.0.0.20190717.10"
  "Launch macOS apps with helm."
  '((emacs     "25.1")
    (helm-core "3.0"))
  :url "https://github.com/xuchunyang/helm-osx-app"
  :commit "634ed5d721a20af265825a018e9df3ee6640daee"
  :revdesc "634ed5d721a2")
