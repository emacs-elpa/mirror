;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lastfm" "1.2.0.20260130.14"
  "Last.fm API for Emacs Lisp."
  '((emacs    "26.1")
    (request  "0.3.0")
    (anaphora "1.0.4")
    (memoize  "1.1")
    (elquery  "0.1.0")
    (s        "1.12.0"))
  :url "https://github.com/mihaiolteanu/lastfm.el/"
  :commit "d095474f2264174396e36148bac3ced80382d061"
  :revdesc "d095474f2264"
  :keywords '("multimedia" "api")
  :authors '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainers '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm")))
