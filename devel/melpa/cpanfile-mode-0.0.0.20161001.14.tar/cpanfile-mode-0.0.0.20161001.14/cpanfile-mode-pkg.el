;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cpanfile-mode" "0.0.0.20161001.14"
  "Major mode for cpanfiles."
  '((emacs "24.4"))
  :url "https://github.com/zakame/cpanfile-mode"
  :commit "b09908b4342b3aa97940159dbe91ac074ec98e0b"
  :revdesc "b09908b4342b"
  :keywords '("perl")
  :authors '(("Zak B. Elep" . "zakame@zakame.net"))
  :maintainers '(("Zak B. Elep" . "zakame@zakame.net")))
