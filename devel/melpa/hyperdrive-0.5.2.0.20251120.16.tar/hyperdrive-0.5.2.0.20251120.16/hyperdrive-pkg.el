;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperdrive" "0.5.2.0.20251120.16"
  "P2P filesystem."
  '((emacs              "28.1")
    (map                "3.0")
    (compat             "30.0.0.0")
    (org                "9.7.6")
    (plz                "0.9.1")
    (persist            "0.8")
    (taxy-magit-section "0.14")
    (transient          "0.8.0"))
  :url "https://git.sr.ht/~ushin/hyperdrive.el"
  :commit "cb4974672b4271004ddd5eea1962216752b730ab"
  :revdesc "v0.5.2-16-gcb4974672b42"
  :authors '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht")))
