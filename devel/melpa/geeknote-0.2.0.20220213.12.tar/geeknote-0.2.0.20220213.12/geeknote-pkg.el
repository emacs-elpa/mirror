;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geeknote" "0.2.0.20220213.12"
  "Use Evernote in Emacs through geeknote."
  '((emacs "24"))
  :url "https://github.com/avendael/emacs-geeknote"
  :commit "ce2738aebeeda35f9d31027e9b7bad0813b975c3"
  :revdesc "ce2738aebeed"
  :keywords '("evernote" "geeknote" "note" "emacs-evernote" "evernote-mode"))
