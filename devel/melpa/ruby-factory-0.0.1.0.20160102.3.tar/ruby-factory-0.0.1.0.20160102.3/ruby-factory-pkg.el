;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-factory" "0.0.1.0.20160102.3"
  "Minor mode for Ruby test object generation libraries."
  '((inflections "1.1"))
  :url "https://github.com/sshaw/ruby-factory-mode"
  :commit "2bb7ccc2fccb5257376a989aa395bc7b9eb1d55d"
  :revdesc "2bb7ccc2fccb"
  :keywords '("ruby" "rails" "convenience")
  :authors '(("Skye Shaw" . "skye.shaw@gmail.com"))
  :maintainers '(("Skye Shaw" . "skye.shaw@gmail.com")))
