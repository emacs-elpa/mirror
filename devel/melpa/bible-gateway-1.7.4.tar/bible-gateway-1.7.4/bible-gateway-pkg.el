;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "1.7.4"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "d2021a918e1b53cbc12f6d14f341970cbf0aca34"
  :revdesc "d2021a918e1b"
  :keywords '("convenience" "comm" "hypermedia"))
