;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-rtags" "0.2.0.20250801.909"
  "A front-end for rtags."
  '((helm  "2.0")
    (rtags "2.10"))
  :url "https://github.com/Andersbakken/rtags"
  :commit "dd6b20f7e57a30f32a8ccbb6c22038383dba746b"
  :revdesc "dd6b20f7e57a"
  :authors '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
             ("Anders Bakken" . "agbakken@gmail.com"))
  :maintainers '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
                 ("Anders Bakken" . "agbakken@gmail.com")))
