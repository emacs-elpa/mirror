;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "1.0.5.0.20260913.88"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "30b32e519a33a7659212148edc738044ba091336"
  :revdesc "cfn-mode/v1.0.5-88-g30b32e519a33"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
