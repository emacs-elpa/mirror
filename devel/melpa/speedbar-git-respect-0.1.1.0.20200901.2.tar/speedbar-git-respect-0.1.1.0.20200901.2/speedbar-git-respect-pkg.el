;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speedbar-git-respect" "0.1.1.0.20200901.2"
  "Particular respect git repo in speedbar."
  '((f     "0.8.0")
    (emacs "25.1"))
  :url "https://github.com/ukari/speedbar-git-respect"
  :commit "dd8f0849fc1dd21b42380e1a8c28a9a29acd9511"
  :revdesc "dd8f0849fc1d"
  :authors '(("Muromi Ukari" . "chendianbuji@gmail.com"))
  :maintainers '(("Muromi Ukari" . "chendianbuji@gmail.com")))
