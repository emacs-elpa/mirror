;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-persist-drawer" "0.0.4"
  "Use a project drawer with project-persist."
  ()
  :url "https://github.com/rdallasgray/project-persist-drawer.git"
  :commit "35bbe132a4fab6a0fec15ce6c0fd2fe6a4aa9626"
  :revdesc "0.0.4-0-g35bbe132a4fa"
  :keywords '("defaults")
  :authors '(("Robert Dallas Gray" . "mail@robertdallasgray.com"))
  :maintainers '(("Robert Dallas Gray" . "mail@robertdallasgray.com")))
