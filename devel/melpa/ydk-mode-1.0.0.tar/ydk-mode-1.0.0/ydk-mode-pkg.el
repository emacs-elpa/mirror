;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ydk-mode" "1.0.0"
  "Language support for Yu-Gi-Oh! deck files."
  ()
  :url "https://github.com/jacksonrayhamilton/ydk-mode"
  :commit "f3f125b29408e0b0a34fec27dcb7c02c5dbfd04e"
  :revdesc "v1.0.0-0-gf3f125b29408"
  :keywords '("faces" "games" "languages" "ydk" "yugioh" "yu-gi-oh")
  :authors '(("Jackson Ray Hamilton" . "jackson@jacksonrayhamilton.com"))
  :maintainers '(("Jackson Ray Hamilton" . "jackson@jacksonrayhamilton.com")))
