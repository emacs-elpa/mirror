;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "0.10.0"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "32acab3624160a7d0bb04c42babaa791729ab8b5"
  :revdesc "32acab362416"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
