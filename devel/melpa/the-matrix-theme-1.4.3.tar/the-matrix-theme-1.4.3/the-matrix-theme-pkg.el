;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "the-matrix-theme" "1.4.3"
  "Green-on-black dark theme inspired by \"The Matrix\" movie."
  '((emacs "26.1"))
  :url "https://github.com/monkeyjunglejuice/matrix-emacs-theme"
  :commit "fe0b8776191744359767ecc4113dda1ade4a5adb"
  :revdesc "fe0b87761917"
  :keywords '("faces" "theme")
  :authors '(("Dan Dee" . "monkeyjunglejuice@pm.me"))
  :maintainers '(("Dan Dee" . "monkeyjunglejuice@pm.me")))
