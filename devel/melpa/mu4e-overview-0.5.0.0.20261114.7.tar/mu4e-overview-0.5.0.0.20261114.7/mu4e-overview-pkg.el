;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-overview" "0.5.0.0.20261114.7"
  "Show overview of maildir."
  '((emacs "29"))
  :url "https://github.com/mkcms/mu4e-overview"
  :commit "e786fcf99e33f5142db327a0cfcc82bf4665c5cb"
  :revdesc "0.5.0-7-ge786fcf99e33"
  :keywords '("mail" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
