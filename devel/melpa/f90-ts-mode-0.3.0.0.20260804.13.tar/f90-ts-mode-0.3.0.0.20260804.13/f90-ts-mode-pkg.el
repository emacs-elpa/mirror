;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f90-ts-mode" "0.3.0.0.20260804.13"
  "Tree-sitter based Fortran 90 mode."
  '((emacs "30.1"))
  :url "https://github.com/mscfd/emacs-f90-ts-mode"
  :commit "90947017ad68c10e47c48928b9833e7436940327"
  :revdesc "v0.3.0-13-g90947017ad68"
  :keywords '("languages" "treesitter" "fortran")
  :authors '(("Martin Stein" . "mscfd@gmx.net"))
  :maintainers '(("Martin Stein" . "mscfd@gmx.net")))
