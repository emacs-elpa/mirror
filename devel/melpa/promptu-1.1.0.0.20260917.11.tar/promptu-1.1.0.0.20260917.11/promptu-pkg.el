;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "1.1.0.0.20260917.11"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "103a77d6cab489d70d96b2e666b65c1ea762940d"
  :revdesc "v1.1.0-11-g103a77d6cab4"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
