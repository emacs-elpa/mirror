;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260619.958"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "23a46c6f9d1ccca76d31cd68ffd3d170075a161f"
  :revdesc "23a46c6f9d1c"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
