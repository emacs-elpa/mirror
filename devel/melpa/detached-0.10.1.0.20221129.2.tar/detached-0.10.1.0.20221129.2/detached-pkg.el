;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "detached" "0.10.1.0.20221129.2"
  "A package to launch, and manage, detached processes."
  '((emacs "27.1"))
  :url "https://sr.ht/~niklaseklund/detached.el/"
  :commit "6b64d4d8064cee781e071e825857b442ea96c3d9"
  :revdesc "0.10.1-2-g6b64d4d8064c"
  :keywords '("convenience" "processes")
  :authors '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainers '(("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")))
