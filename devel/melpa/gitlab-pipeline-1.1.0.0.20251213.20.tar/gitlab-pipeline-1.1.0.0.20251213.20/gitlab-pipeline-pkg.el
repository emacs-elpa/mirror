;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitlab-pipeline" "1.1.0.0.20251213.20"
  "Get infomation about Gitlab pipelines."
  '((emacs "25.1")
    (ghub  "3.3.0"))
  :url "https://github.com/TxGVNN/gitlab-pipeline"
  :commit "0e35528cffa04e6d3621066c7406b2c1260a56ce"
  :revdesc "0e35528cffa0"
  :keywords '("comm" "tools" "git")
  :authors '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers '(("Giap Tran" . "txgvnn@gmail.com")))
