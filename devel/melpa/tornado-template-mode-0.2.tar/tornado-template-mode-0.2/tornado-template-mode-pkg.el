;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tornado-template-mode" "0.2"
  "A major mode for editing tornado templates."
  ()
  :url "https://github.com/paradoxxxzero/tornado-template-mode"
  :commit "667c0663dbbd279b6c345446b9f2bc50eb52b747"
  :revdesc "667c0663dbbd")
