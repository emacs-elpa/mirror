;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-json" "0.3.0.0.20260628.74"
  "JSON export backend for Org mode."
  '((emacs "26.1")
    (org   "9")
    (s     "1.12"))
  :url "https://github.com/jlumpe/ox-json"
  :commit "ad9b5f14ab29e76ca9c28bb1fa3d07792d5d3395"
  :revdesc "ad9b5f14ab29"
  :keywords '("outlines")
  :authors '(("Jared Lumpe" . "jared@jaredlumpe.com"))
  :maintainers '(("Jared Lumpe" . "jared@jaredlumpe.com")))
