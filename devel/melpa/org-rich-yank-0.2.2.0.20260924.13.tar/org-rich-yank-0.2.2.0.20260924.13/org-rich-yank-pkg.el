;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-rich-yank" "0.2.2.0.20260924.13"
  "Paste with org-mode markup and link to source."
  '((emacs "25.1"))
  :url "https://github.com/unhammer/org-rich-yank"
  :commit "f246cd3d27b8ca61f0a1ccff83309b3e3ef3d45e"
  :revdesc "v0.2.2-13-gf246cd3d27b8"
  :keywords '("convenience" "hypermedia" "org")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
