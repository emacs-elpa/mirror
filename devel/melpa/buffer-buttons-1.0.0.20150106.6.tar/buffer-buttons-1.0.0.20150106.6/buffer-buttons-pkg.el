;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-buttons" "1.0.0.20150106.6"
  "Define, save, and load code-safe buttons in files for emacs."
  ()
  :url "https://github.com/rpav/buffer-buttons"
  :commit "2feb8494fa7863b98256bc85da670d74a3a8a975"
  :revdesc "2feb8494fa78"
  :authors '(("Ryan Pavlik" . "rpavlik@gmail.com"))
  :maintainers '(("Ryan Pavlik" . "rpavlik@gmail.com")))
