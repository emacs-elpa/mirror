;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lms" "1.1"
  "Squeezebox / Logitech Media Server frontend."
  '((emacs "25.1"))
  :url "https://hg.serna.eu/emacs/lms"
  :commit "29593b4c18a570dfb2e60b196f24d407a1277daa"
  :revdesc "v1.1-0-m29593b4c18a5"
  :keywords '("multimedia")
  :authors '(("Iñigo Serna" . "inigoserna@gmx.com"))
  :maintainers '(("Iñigo Serna" . "inigoserna@gmx.com")))
