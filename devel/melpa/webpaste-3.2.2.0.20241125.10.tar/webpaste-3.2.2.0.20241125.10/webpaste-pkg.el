;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "webpaste" "3.2.2.0.20241125.10"
  "Paste to pastebin-like services."
  '((emacs   "24.4")
    (request "0.2.0")
    (cl-lib  "0.5"))
  :url "https://github.com/etu/webpaste.el"
  :commit "e2a41530257f04b7ad2198d333adcf247a05277c"
  :revdesc "3.2.2-10-ge2a41530257f"
  :keywords '("convenience" "comm" "paste")
  :authors '(("Elis etu Hirwing" . "elis@hirwing.se"))
  :maintainers '(("Elis etu Hirwing" . "elis@hirwing.se")))
