;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "1.8.0.20260705.2"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "2e804a3129758aaad4bd8c28f2eb625ec4794aab"
  :revdesc "2e804a312975"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
