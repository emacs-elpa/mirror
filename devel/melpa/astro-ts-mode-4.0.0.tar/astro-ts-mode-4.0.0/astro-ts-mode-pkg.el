;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "astro-ts-mode" "4.0.0"
  "Major mode for editing Astro templates."
  '((emacs "31"))
  :url "https://github.com/Sorixelle/astro-ts-mode"
  :commit "fcc299a0b5aade4fd996cbbb5db136348958ebe3"
  :revdesc "v4.0.0-0-gfcc299a0b5aa"
  :keywords '("languages")
  :authors '(("Ruby Iris Juric" . "ruby@srxl.me"))
  :maintainers '(("Ruby Iris Juric" . "ruby@srxl.me")))
