;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-browser" "0.1.0.0.20170720.5"
  "Render HTML in org-mode blocks."
  '((org "8"))
  :url "https://github.com/krisajenkins/ob-browser"
  :commit "a347d9df1c87b7eb660be8723982c7ad2563631a"
  :revdesc "a347d9df1c87"
  :keywords '("org" "babel" "browser" "phantomjs")
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
