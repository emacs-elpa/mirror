;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.2.2"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "ac0cff106805d729d08b9c287750e1f4958128c9"
  :revdesc "1.2.2-0-gac0cff106805"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
