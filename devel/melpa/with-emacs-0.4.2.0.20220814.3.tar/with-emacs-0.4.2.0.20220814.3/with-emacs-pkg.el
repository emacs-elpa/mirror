;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-emacs" "0.4.2.0.20220814.3"
  "Evaluate Emacs Lisp expressions in a separate Emacs process."
  '((emacs "24.4"))
  :url "https://github.com/twlz0ne/with-emacs.el"
  :commit "fb9ef454a4bb2d6de3415807b4858a20a9cc0dad"
  :revdesc "fb9ef454a4bb"
  :keywords '("tools")
  :authors '(("Gong Qijian" . "gongqijian@gmail.com"))
  :maintainers '(("Gong Qijian" . "gongqijian@gmail.com")))
