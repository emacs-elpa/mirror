;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wwg" "0.1.1.0.20210614.4"
  "Writer word goals."
  '((emacs "25.1"))
  :url "https://github.com/ag91/writer-word-goals"
  :commit "46c8a7c71275ced2c662c1222d4b85319f80dd83"
  :revdesc "46c8a7c71275"
  :keywords '("wp")
  :authors '((nil . "Andreaandrea-dev@hotmail.com"))
  :maintainers '((nil . "Andreaandrea-dev@hotmail.com")))
