;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mw-thesaurus" "2.2.0"
  "Merriam-Webster Thesaurus and Dictionary."
  '((emacs "27.1"))
  :url "https://github.com/agzam/mw-thesaurus.el"
  :commit "e500a35ab9d09bca28bbd2805163ae78bcbcaba7"
  :revdesc "2.2.0-0-ge500a35ab9d0"
  :keywords '("wp" "matching")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
