;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gmsh-mode" "0.1.0.0.20240223.7"
  "Highlight GMSH mesh generator script syntax."
  '((emacs "26.1"))
  :url "https://gitlab.com/matsievskiysv/gmsh-mode"
  :commit "324d09e6ef51ff9473cbfaf560979ed313df416b"
  :revdesc "324d09e6ef51"
  :keywords '("languages"))
