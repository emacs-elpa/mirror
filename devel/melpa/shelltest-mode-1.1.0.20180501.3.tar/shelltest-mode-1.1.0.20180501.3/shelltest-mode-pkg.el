;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shelltest-mode" "1.1.0.20180501.3"
  "Major mode for shelltestrunner."
  ()
  :url "https://github.com/rtrn/shelltest-mode"
  :commit "5fea8c9394380e822971a171905b6b5ab9be812d"
  :revdesc "5fea8c939438"
  :keywords '("languages")
  :authors '(("Dustin Fechner" . "dfe@rtrn.io"))
  :maintainers '(("Dustin Fechner" . "dfe@rtrn.io")))
