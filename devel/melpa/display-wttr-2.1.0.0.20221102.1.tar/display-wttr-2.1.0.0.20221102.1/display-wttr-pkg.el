;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "display-wttr" "2.1.0.0.20221102.1"
  "Display wttr(weather) in the mode line."
  '((emacs "27.1"))
  :url "https://github.com/josegpt/display-wttr"
  :commit "7062953d034e27c297d58748cf74dad552aa2873"
  :revdesc "7062953d034e"
  :authors '(("Jose G Perez Taveras" . "josegpt27@gmail.com"))
  :maintainers '(("Jose G Perez Taveras" . "josegpt27@gmail.com")))
