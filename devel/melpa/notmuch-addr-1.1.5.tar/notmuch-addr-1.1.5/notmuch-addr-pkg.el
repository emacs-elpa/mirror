;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-addr" "1.1.5"
  "Improved address completion for Notmuch."
  '((emacs   "29.1")
    (compat  "31.1")
    (notmuch "0.39"))
  :url "https://github.com/tarsius/notmuch-addr"
  :commit "2eca10cd91f2f33629f08364310f4140316f464e"
  :revdesc "v1.1.5-0-g2eca10cd91f2"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-addr@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-addr@jonas.bernoulli.dev")))
