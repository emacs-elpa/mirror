;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ksp-mode" "0.1.1"
  "Major mode for editing ksp files."
  '((emacs "27.1"))
  :url "https://github.com/youngker/ksp-mode.el"
  :commit "89b91b8ed6753867e30aa494e5d80325dfe25569"
  :revdesc "89b91b8ed675"
  :keywords '("ksp" "languages")
  :maintainers '(("YoungJoo Lee" . "youngker@gmail.com")))
