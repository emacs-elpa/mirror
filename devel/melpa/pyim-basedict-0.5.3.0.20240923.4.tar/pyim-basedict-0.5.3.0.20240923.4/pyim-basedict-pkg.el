;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyim-basedict" "0.5.3.0.20240923.4"
  "The default pinyin dict of pyim."
  '((pyim "3.7"))
  :url "https://github.com/tumashu/pyim-basedict"
  :commit "55d9b324831b0fc79ff62f1c6f21aad72341a114"
  :revdesc "55d9b324831b"
  :keywords '("convenience" "chinese" "pinyin" "input-method" "complete")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
