;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elbank" "1.2.0.20180316.17"
  "Personal finances reporting application."
  '((emacs "25")
    (seq   "2.16"))
  :url "https://github.com/NicolasPetton/elbank"
  :commit "6dbd21e31fdf7cf62491f6d24b8198d4f91a031b"
  :revdesc "1.2-17-g6dbd21e31fdf"
  :keywords '("tools" "personal-finances")
  :authors '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")))
