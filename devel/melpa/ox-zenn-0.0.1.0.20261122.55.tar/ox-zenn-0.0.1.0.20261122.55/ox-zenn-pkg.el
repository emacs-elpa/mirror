;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-zenn" "0.0.1.0.20261122.55"
  "Zenn flavored markdown backend for org export engine."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/conao3/ox-zenn.el"
  :commit "c7b86271c35fbdc78e563f492e8d538f28d1c4a3"
  :revdesc "c7b86271c35f"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
