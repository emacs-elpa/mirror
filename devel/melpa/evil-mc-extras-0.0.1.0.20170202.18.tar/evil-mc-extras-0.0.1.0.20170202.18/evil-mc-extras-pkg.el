;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-mc-extras" "0.0.1.0.20170202.18"
  "Extra functionality for evil-mc."
  '((emacs        "24.3")
    (evil         "1.2.12")
    (cl-lib       "0.5")
    (evil-mc      "0.0.2")
    (evil-numbers "0.4"))
  :url "https://github.com/gabesoft/evil-mc-extras"
  :commit "ba3252ae129c3b79aeb70ec3d276cbda32b00421"
  :revdesc "ba3252ae129c"
  :keywords '("evil" "editing" "multiple-cursors" "vim" "evil-multiple-cursors" "evil-mc" "evil-mc-extras")
  :authors '(("Gabriel Adomnicai" . "gabesoft@gmail.com"))
  :maintainers '(("Gabriel Adomnicai" . "gabesoft@gmail.com")))
