;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "0.3.0.0.20261016.1"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "61eb714f85f3142a8be998e5311f6cab62b9f29f"
  :revdesc "v0.3.0-1-g61eb714f85f3"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
