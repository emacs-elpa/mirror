;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "2.9.0.20260806.1"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "1618bed334898b04f3a16fb6fd9fdf0a250dab2f"
  :revdesc "2.9-1-g1618bed33489"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
