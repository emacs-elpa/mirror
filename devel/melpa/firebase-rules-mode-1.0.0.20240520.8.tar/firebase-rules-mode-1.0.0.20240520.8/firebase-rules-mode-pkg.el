;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firebase-rules-mode" "1.0.0.20240520.8"
  "Editing support for firebase.rules."
  '((emacs "24.3"))
  :url "https://github.com/dherbst/firebase-rules-mode"
  :commit "c88cb10251cdfce931e4fe48ce76eaa50cc7e791"
  :revdesc "c88cb10251cd"
  :keywords '("languages")
  :authors '(("Darrel Herbst" . "dherbst@gmail.com"))
  :maintainers '(("Darrel Herbst" . "dherbst@gmail.com")))
