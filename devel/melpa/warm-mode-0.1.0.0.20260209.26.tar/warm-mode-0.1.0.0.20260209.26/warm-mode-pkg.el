;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "warm-mode" "0.1.0.0.20260209.26"
  "Warm colors for nighttime coding."
  '((emacs "27.1"))
  :url "https://github.com/smallwat3r/emacs-warm-mode"
  :commit "27362826e970ed0e902bee3512d97dc02f196a7b"
  :revdesc "27362826e970"
  :keywords '("faces" "convenience")
  :authors '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com"))
  :maintainers '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com")))
