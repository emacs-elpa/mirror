;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "2.6.0.0.20260720.1"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (md-ts-mode          "0.3.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "3e6b04514592e0a38189552a686b9dbe51453bd7"
  :revdesc "v2.6.0-1-g3e6b04514592"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
