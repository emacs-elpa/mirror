;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "horizon-theme" "0.1.5.0.20200720.16"
  "A beautifully warm dual theme."
  '((emacs "24.3"))
  :url "https://github.com/aodhneine/horizon-theme.el"
  :commit "9595549c514a9376c61d5d303405f6a6982e9e46"
  :revdesc "9595549c514a"
  :authors '(("Aodnait taín" . "aodhneine@tuta.io"))
  :maintainers '(("Aodnait taín" . "aodhneine@tuta.io")))
