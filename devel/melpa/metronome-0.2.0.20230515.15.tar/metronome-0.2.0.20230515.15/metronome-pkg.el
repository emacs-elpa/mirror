;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metronome" "0.2.0.20230515.15"
  "The missing metronome for GNU Emacs."
  '((emacs "25.1"))
  :url "https://git.sr.ht/~jagrg/metronome"
  :commit "4811b54d800d1bb69fd501ffeab3adf86978362d"
  :revdesc "4811b54d800d"
  :authors '(("Jonathan Gregory" . "jgrgatautisticidotorg"))
  :maintainers '(("Jonathan Gregory" . "jgrgatautisticidotorg")))
