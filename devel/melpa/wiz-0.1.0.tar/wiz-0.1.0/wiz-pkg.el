;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wiz" "0.1.0"
  "Macros to simplify startup initialization."
  '((emacs                "29.1")
    (exec-path-from-shell "2.1"))
  :url "https://github.com/zonuexe/emacs-wiz"
  :commit "1b8b8d54e011dd989a52cde9596e077aa09e5894"
  :revdesc "1b8b8d54e011"
  :keywords '("convenience" "lisp")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
