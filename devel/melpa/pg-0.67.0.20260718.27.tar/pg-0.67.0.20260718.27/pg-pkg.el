;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "0.67.0.20260718.27"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "b6547e6fe09867f5d7a84b5c20d914e69af454bc"
  :revdesc "b6547e6fe098"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
