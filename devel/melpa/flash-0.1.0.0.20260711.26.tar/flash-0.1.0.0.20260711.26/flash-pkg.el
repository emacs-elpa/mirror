;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flash" "0.1.0.0.20260711.26"
  "Flash-style navigation."
  '((emacs "27.1"))
  :url "https://github.com/Prgebish/flash"
  :commit "db3bfa84866f143a0665d1b5a48c3b30dc7b528f"
  :revdesc "db3bfa84866f"
  :keywords '("convenience" "navigation")
  :authors '(("Vadim Pavlov" . "https://github.com/Prgebish"))
  :maintainers '(("Vadim Pavlov" . "https://github.com/Prgebish")))
