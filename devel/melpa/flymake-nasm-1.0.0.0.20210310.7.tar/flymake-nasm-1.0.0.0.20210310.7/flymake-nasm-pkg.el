;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-nasm" "1.0.0.0.20210310.7"
  "A flymake handler for asm-mode files using nasm."
  '((flymake-quickdef "1.0.0")
    (emacs            "26.1"))
  :url "https://github.com/juergenhoetzel/flymake-nasm"
  :commit "27e58d7f3a48ca6fc12238fe6c888a3fdffc3f75"
  :revdesc "27e58d7f3a48"
  :keywords '("tools" "languages")
  :authors '(("Jürgen Hötzel" . "juergen@hoetzel.info")))
