;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-cell" "1.0.0.20240126.37"
  "Support for MATLAB-like cells in python mode."
  '((emacs "25.1"))
  :url "https://github.com/thisch/python-cell.el"
  :commit "ea469071adc72f371698934c3709ee370ac6be6f"
  :revdesc "ea469071adc7"
  :keywords '("extensions" "python" "matlab" "cell")
  :authors '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainers '(("Thomas Hisch" . "t.hisch@gmail.com")))
