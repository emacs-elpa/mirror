;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jbeam-mode" "0.1.0.20251123.5"
  "Major mode for JBeam files."
  '((emacs "24.4"))
  :url "https://github.com/webdevred/jbeam-mode"
  :commit "7c16b603cb8e342533d20069603373a63a3ca7ca"
  :revdesc "7c16b603cb8e"
  :keywords '("languages"))
