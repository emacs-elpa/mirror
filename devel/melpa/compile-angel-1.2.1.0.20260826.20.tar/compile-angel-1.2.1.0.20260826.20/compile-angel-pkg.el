;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "1.2.1.0.20260826.20"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "0b44cc6042dd6846cf44598defa1f71cf40fdb8f"
  :revdesc "1.2.1-20-g0b44cc6042dd"
  :keywords '("lisp" "tools" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
