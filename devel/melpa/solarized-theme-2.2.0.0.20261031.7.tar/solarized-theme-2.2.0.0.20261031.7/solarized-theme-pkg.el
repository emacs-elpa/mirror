;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solarized-theme" "2.2.0.0.20261031.7"
  "The Solarized color theme."
  '((emacs "24.1"))
  :url "https://github.com/bbatsov/solarized-emacs"
  :commit "ce2bc214e5486b05c76beb8d9da0a5068e66bd0e"
  :revdesc "ce2bc214e548"
  :keywords '("convenience" "themes" "solarized")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
