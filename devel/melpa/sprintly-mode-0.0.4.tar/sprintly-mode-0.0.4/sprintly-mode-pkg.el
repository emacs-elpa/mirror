;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sprintly-mode" "0.0.4"
  "Major mode for dealing with sprint.ly."
  '((furl "0.0.2"))
  :url "https://github.com/sprintly/sprintly-mode"
  :commit "6695892bae5860b5268bf3ae62be990ee9b63c11"
  :revdesc "6695892bae58"
  :authors '(("Justin Lilly" . "justin@justinlilly.com"))
  :maintainers '(("Justin Lilly" . "justin@justinlilly.com")))
