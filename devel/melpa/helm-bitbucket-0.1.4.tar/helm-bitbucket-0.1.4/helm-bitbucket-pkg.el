;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bitbucket" "0.1.4"
  "Search Bitbucket with Helm."
  '((emacs     "24")
    (helm-core "3.6.0"))
  :url "https://github.com/dragonwasrobot/helm-bitbucket"
  :commit "9d07a274584ad364a2620c6389f86d90502f2640"
  :revdesc "9d07a274584a"
  :keywords '("matching")
  :authors '(("Peter Urbak" . "tolowercase@gmail.com"))
  :maintainers '(("Peter Urbak" . "tolowercase@gmail.com")))
