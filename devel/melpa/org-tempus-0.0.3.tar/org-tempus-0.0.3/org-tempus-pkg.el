;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tempus" "0.0.3"
  "Enhance Org time tracking."
  '((emacs "27.1"))
  :url "https://github.com/rul/org-tempus"
  :commit "1e69abcc89952934fc1f9dc318c8e113775b9451"
  :revdesc "0.0.3-0-g1e69abcc8995"
  :keywords '("calendar")
  :authors '(("Raul Benencia" . "id@rbenencia.name"))
  :maintainers '(("Raul Benencia" . "id@rbenencia.name")))
