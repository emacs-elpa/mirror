;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hatty" "1.3.0.0.20260420.22"
  "Query positions through hats."
  '((emacs "29.1"))
  :url "https://github.com/ErikPrantare/hatty.el"
  :commit "8af8aa074bf56c2aafd81238be2c6c2df6003664"
  :revdesc "8af8aa074bf5"
  :keywords '("convenience"))
