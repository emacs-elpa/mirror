;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shexc-ts-mode" "3.0.0.20260801.55"
  "Tree-sitter major mode for ShExC."
  '((emacs     "29.1")
    (transient "0.5.0")
    (compat    "29.1.4.4"))
  :url "https://github.com/ericprud/shexc-mode-for-emacs"
  :commit "626b85466d7885855288e0763c7783721052f2f1"
  :revdesc "v3.0-55-g626b85466d78"
  :keywords '("languages")
  :authors '(("Eric Prud'hommeaux" . "eric@w3.org"))
  :maintainers '(("Eric Prud'hommeaux" . "eric@w3.org")))
