;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "one" "1.1.0.20250824.8"
  "Static Site Generator for org-mode users."
  '((emacs   "28.1")
    (jack    "1.0")
    (htmlize "1.57"))
  :url "https://github.com/tonyaldon/one.el"
  :commit "0960d56c5a28820e28ba35fce9b204af0dcb558d"
  :revdesc "0960d56c5a28"
  :keywords '("hypermedia" "outlines")
  :authors '(("Tony Aldon" . "tony@tonyaldon.com"))
  :maintainers '(("Tony Aldon" . "tony@tonyaldon.com")))
