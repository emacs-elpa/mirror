;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "common-lisp-snippets" "0.1.2.0.20180226.3"
  "Yasnippets for Common Lisp."
  '((yasnippet "0.8.0"))
  :url "https://github.com/mrkkrp/common-lisp-snippets"
  :commit "1ddf808311ba4d9e8444a1cb50bd5ee75e4111f6"
  :revdesc "1ddf808311ba"
  :keywords '("snippets")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
