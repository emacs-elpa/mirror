;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "1.1.0.0.20260911.1"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "8a38de4a6c13038c4433e5eaf22fefe82e630291"
  :revdesc "v1.1.0-1-g8a38de4a6c13"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
