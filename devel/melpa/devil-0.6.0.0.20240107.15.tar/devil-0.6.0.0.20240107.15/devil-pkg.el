;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devil" "0.6.0.0.20240107.15"
  "Minor mode for translating key sequences."
  '((emacs "24.4"))
  :url "https://github.com/susam/devil"
  :commit "dd29681fe07f37c4acbff32a5767bddcbf3b5b80"
  :revdesc "0.6.0-15-gdd29681fe07f"
  :keywords '("convenience" "abbrev")
  :authors '(("Susam Pal" . "susam@susam.net"))
  :maintainers '(("Susam Pal" . "susam@susam.net")))
