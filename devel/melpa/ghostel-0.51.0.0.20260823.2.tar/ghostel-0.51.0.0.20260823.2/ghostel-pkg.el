;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.51.0.0.20260823.2"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "245438b0245028f701522b2cbddc9f07c81211e3"
  :revdesc "245438b02450"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
