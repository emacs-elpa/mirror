;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "my-repo-pins" "0.5"
  "Keep your git repositories organized."
  '((emacs "26.1"))
  :url "https://alternativebit.fr/projects/my-repo-pins/"
  :commit "e6fe3864e244e6db74b668d24857c04472b2d475"
  :revdesc "e6fe3864e244"
  :authors '(("Félix Baylac Jacqué" . "felixatalternativebit.fr"))
  :maintainers '(("Félix Baylac Jacqué" . "felixatalternativebit.fr")))
