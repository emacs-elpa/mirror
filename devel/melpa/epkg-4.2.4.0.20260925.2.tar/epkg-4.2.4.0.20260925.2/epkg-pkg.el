;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "4.2.4.0.20260925.2"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.0")
    (closql   "2.4")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "86b9f299b6ecb1ab62e5934025b3eaa27b69fb8f"
  :revdesc "v4.2.4-2-g86b9f299b6ec"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
