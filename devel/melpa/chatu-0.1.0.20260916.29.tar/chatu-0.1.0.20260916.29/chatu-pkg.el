;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatu" "0.1.0.20260916.29"
  "Convert and insert any images to org-mode or markdown buffer."
  '((org           "9.6.6")
    (emacs         "29.1")
    (plantuml-mode "1.2.9"))
  :url "https://github.com/kimim/chatu"
  :commit "ba58f2ca0d27676b11afc9fe071227424f5b369f"
  :revdesc "ba58f2ca0d27"
  :keywords '("multimedia" "convenience")
  :authors '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainers '(("Kimi Ma" . "kimi.im@outlook.com")))
