;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jknav" "0.0.1.0.20121006.16"
  "Automatically enable j/k keys for line-based navigation."
  ()
  :url "https://github.com/aculich/jknav.el"
  :commit "861245715c728503dad6573278fdd75c271dbf8b"
  :revdesc "861245715c72"
  :keywords '("keyboard" "navigation")
  :authors '(("Aaron Culich" . "aculich@gmail.com"))
  :maintainers '(("Aaron Culich" . "aculich@gmail.com")))
