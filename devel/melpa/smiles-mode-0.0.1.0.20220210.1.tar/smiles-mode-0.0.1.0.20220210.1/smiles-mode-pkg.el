;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smiles-mode" "0.0.1.0.20220210.1"
  "Major mode for SMILES."
  ()
  :url "https://repo.or.cz/smiles-mode.git"
  :commit "950a8b3224f8f069c82faeb0282d041f872d5550"
  :revdesc "950a8b3224f8"
  :keywords '("smiles")
  :authors '((nil . "JohnKitchinjkitchin@andrew.cmu.edu"))
  :maintainers '((nil . "JohnKitchinjkitchin@andrew.cmu.edu")))
