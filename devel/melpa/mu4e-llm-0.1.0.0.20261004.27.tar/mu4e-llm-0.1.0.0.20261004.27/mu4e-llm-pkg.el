;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-llm" "0.1.0.0.20261004.27"
  "AI-powered email assistance for mu4e."
  '((emacs "28.1")
    (llm   "0.17"))
  :url "https://github.com/sillyfellow/mu4e-llm"
  :commit "e55ca9b95b619298c9b70beeb8a4142960a379b2"
  :revdesc "v0.1.0-27-ge55ca9b95b61"
  :keywords '("mail" "convenience")
  :authors '(("Dr. Sandeep Sadanandan" . "sillyfellow@whybenormal.org"))
  :maintainers '(("Dr. Sandeep Sadanandan" . "sillyfellow@whybenormal.org")))
