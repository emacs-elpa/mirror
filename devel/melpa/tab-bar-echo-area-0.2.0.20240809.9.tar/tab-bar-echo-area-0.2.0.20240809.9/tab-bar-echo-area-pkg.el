;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tab-bar-echo-area" "0.2.0.20240809.9"
  "Display tab names of the tab bar in the echo area."
  '((emacs "27.1"))
  :url "https://github.com/fritzgrabo/tab-bar-echo-area"
  :commit "9ccff3b93385796bec1cd435674807c3907436dd"
  :revdesc "9ccff3b93385"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
