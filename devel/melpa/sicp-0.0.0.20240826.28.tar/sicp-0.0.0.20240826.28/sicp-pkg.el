;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sicp" "0.0.0.20240826.28"
  "Structure and Interpretation of Computer Programs in info format."
  ()
  :url "https://mitpress.mit.edu/sicp"
  :commit "552b44fd873b5cadde4e76d10cef4d6e21a4287a"
  :revdesc "552b44fd873b")
