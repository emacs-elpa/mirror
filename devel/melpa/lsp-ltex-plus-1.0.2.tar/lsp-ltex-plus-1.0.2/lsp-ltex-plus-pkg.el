;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex-plus" "1.0.2"
  "Grammar and spell checking for LaTeX, Markdown, Org and more."
  '((emacs "29.1"))
  :url "https://github.com/ltex-plus/emacs-ltex-plus"
  :commit "5943024b7df4617d3ef302c78761727a205f56d8"
  :revdesc "v1.0.2-0-g5943024b7df4"
  :keywords '("lsp" "grammar" "spelling" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
