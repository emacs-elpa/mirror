;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cljr-helm" "0.11.0.20220721.2"
  "Wraps clojure refactor commands with helm."
  '((clj-refactor "0.13.0")
    (helm-core    "3.6.0")
    (cl-lib       "0.5"))
  :url "https://github.com/philjackson/cljr-helm"
  :commit "2c1f9cbd892ec03335f671ea3f974ee2ff6078dc"
  :revdesc "2c1f9cbd892e"
  :keywords '("helm" "clojure" "refactor")
  :authors '(("Phil Jackson" . "phil@shellarchive.co.uk"))
  :maintainers '(("Phil Jackson" . "phil@shellarchive.co.uk")))
