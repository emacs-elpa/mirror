;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symbolist" "0.1.0.0.20211107.9"
  "List and interactively unbind Emacs Lisp symbols."
  '((emacs "24.5"))
  :url "https://github.com/lassik/emacs-symbolist"
  :commit "92b712734941a45da7d47fd61b95e4013ff53481"
  :revdesc "92b712734941"
  :keywords '("lisp" "maint")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
