;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.2.0.0.20260827.2"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "bff7a9852ddee43188781034109cabf937cb8baf"
  :revdesc "4.2.0-2-gbff7a9852dde"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
