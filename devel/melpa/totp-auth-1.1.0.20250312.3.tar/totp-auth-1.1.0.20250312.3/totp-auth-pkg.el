;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "totp-auth" "1.1.0.20250312.3"
  "RFC6238 TOTP."
  '((emacs  "27.1")
    (base32 "0.1"))
  :url "https://gitlab.com/fledermaus/totp.el"
  :commit "6acb5f3cdac840fc2d1e5c4b73a90f4c035d7116"
  :revdesc "6acb5f3cdac8"
  :keywords '("2fa" "two-factor" "totp" "otp" "password" "comm")
  :authors '(("Vivek Das Mohapatra" . "vivek@etla.org"))
  :maintainers '(("Vivek Das Mohapatra" . "vivek@etla.org")))
