;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-topics" "0.0.1.0.20250416.16"
  "Lookup PRs matching a query."
  '((emacs "29.4")
    (ts    "0.3"))
  :url "https://github.com/agzam/github-topics"
  :commit "296cb525c5387e5242b89950d2d84d258ff82fd2"
  :revdesc "296cb525c538"
  :keywords '("vc" "matching" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
