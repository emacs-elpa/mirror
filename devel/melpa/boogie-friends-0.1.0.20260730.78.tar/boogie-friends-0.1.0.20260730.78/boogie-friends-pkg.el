;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boogie-friends" "0.1.0.20260730.78"
  "A collection of programming modes for Boogie, Dafny, and Z3 (SMTLIB v2)."
  '((cl-lib    "0.5")
    (company   "0.8.12")
    (dash      "2.10.0")
    (flycheck  "0.23")
    (yasnippet "0.9.0.1")
    (emacs     "24.4"))
  :url "https://github.com/boogie-org/boogie-friends/"
  :commit "c53a1548df1a55d513ee89e83175c1803dbd2c3f"
  :revdesc "c53a1548df1a"
  :keywords '("convenience" "languages")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
