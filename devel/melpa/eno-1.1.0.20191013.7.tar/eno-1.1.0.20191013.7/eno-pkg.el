;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eno" "1.1.0.20191013.7"
  "Goto/copy/cut any word/symbol/line in view, similar to ace-jump/easymotion."
  '((dash          "2.12.1")
    (edit-at-point "1.0"))
  :url "https://github.com/enoson/eno.el"
  :commit "c5c6193687c0bede1ddf507c430cf8b0a6d272d9"
  :revdesc "c5c6193687c0"
  :authors '((nil . "e.enoson@gmail.com"))
  :maintainers '((nil . "e.enoson@gmail.com")))
