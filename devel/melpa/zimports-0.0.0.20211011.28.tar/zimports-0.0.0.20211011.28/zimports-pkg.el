;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zimports" "0.0.0.20211011.28"
  "Reformat python imports with zimports."
  '((emacs      "26.1")
    (projectile "2.1.0"))
  :url "https://github.com/schmir/zimports.el"
  :commit "76cf76bdc871cb0454a6fc555aeb1aa94f1b6e57"
  :revdesc "76cf76bdc871")
