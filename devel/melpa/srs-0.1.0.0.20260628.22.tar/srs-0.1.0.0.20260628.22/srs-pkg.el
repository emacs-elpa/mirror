;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "0.1.0.0.20260628.22"
  "Spaced repetition in plain text."
  '((emacs     "30.2")
    (transient "0.12.0"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "f708ecf2f0fb05c4b6738691d652643ea697b603"
  :revdesc "f708ecf2f0fb"
  :keywords '("hypermedia" "srs" "memory"))
