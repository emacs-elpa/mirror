;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.900.0.20260726.17"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "1367dca8b37de3eb31a87aab037fc404e9c25e73"
  :revdesc "1367dca8b37d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
