;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verify-url" "0.1.0.20160426.34"
  "Find out invalid urls in the buffer or region."
  '((cl-lib "0.5"))
  :url "https://github.com/lujun9972/verify-url"
  :commit "d6f3623cda8cd526a2d198619b137059cb1ba1ab"
  :revdesc "d6f3623cda8c"
  :keywords '("convenience" "usability" "url")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
