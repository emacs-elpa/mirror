;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-rsync" "0.7.0.20261005.14"
  "Allow rsync from dired buffers."
  '((s     "1.12.0")
    (dash  "2.0.0")
    (emacs "25.1"))
  :url "https://github.com/stsquad/dired-rsync"
  :commit "c313f8279fa39fd63a4ca039a728939b49ebf495"
  :revdesc "c313f8279fa3"
  :authors '(("Alex Bennée" . "alex@bennee.com"))
  :maintainers '(("Alex Bennée" . "alex@bennee.com")))
