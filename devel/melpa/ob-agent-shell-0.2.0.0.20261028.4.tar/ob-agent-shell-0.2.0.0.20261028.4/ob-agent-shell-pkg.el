;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-agent-shell" "0.2.0.0.20261028.4"
  "Org-babel backend for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.85.3")
    (org         "9.6"))
  :url "https://github.com/eddof13/ob-agent-shell"
  :commit "08c840edac37cf8af051882ba3564aa9e89cde9f"
  :revdesc "v0.2.0-4-g08c840edac37"
  :keywords '("tools" "convenience" "outlines")
  :authors '(("Eddie Jesinsky" . "eddie@jesinsky.com"))
  :maintainers '(("Eddie Jesinsky" . "eddie@jesinsky.com")))
