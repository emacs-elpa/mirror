;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.1.0.0.20260708.29"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "751181f23d7ebefa54dc474dde40151a7089ffcf"
  :revdesc "v3.1.0-29-g751181f23d7e"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
