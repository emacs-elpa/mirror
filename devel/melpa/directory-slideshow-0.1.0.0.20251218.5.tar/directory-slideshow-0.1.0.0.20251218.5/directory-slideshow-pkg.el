;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "directory-slideshow" "0.1.0.0.20251218.5"
  "Simple slideshows from files."
  '((emacs "29.4"))
  :url "https://github.com/Duncan-Britt/directory-slideshow"
  :commit "a54e6bc923f1f31867d7899ec179eb91f3dda300"
  :revdesc "a54e6bc923f1"
  :keywords '("multimedia"))
