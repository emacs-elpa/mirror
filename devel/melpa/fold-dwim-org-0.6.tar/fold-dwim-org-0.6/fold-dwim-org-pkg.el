;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fold-dwim-org" "0.6"
  "Fold DWIM bound to org key-strokes."
  '((fold-dwim "1.2"))
  :url "https://github.com/mlf176f2/fold-dwim-org"
  :commit "c09bb2b46d65afbd1d0febc6fded7495be7a3037"
  :revdesc "v0.6-0-gc09bb2b46d65"
  :keywords '("folding" "emacs" "org-mode"))
