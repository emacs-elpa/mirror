;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smooth-scrolling" "2.0.0.0.20161002.6"
  "Make emacs scroll smoothly."
  ()
  :url "https://github.com/aspiers/smooth-scrolling/"
  :commit "2462c13640aa4c75ab3ddad443fedc29acf68f84"
  :revdesc "v2.0.0-6-g2462c13640aa"
  :keywords '("convenience")
  :authors '(("Adam Spiers" . "emacs-ss@adamspiers.org")
             ("Jeremy Bondeson" . "jbondeson@gmail.com")
             ("Ryan C. Thompson" . "rct+github@thompsonclan.org"))
  :maintainers '(("Adam Spiers" . "emacs-ss@adamspiers.org")))
