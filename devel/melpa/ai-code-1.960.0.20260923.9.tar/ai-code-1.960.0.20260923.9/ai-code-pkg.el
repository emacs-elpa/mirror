;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.960.0.20260923.9"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "90a099710c994e8d95f180e88d79a4810644b692"
  :revdesc "90a099710c99"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
