;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "0.0.1.0.20260703.206"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "c205bd38b43bef7e9bba1b796a32d9bb848f96a9"
  :revdesc "c205bd38b43b"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
