;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bracket-face" "1.2.4.0.20260815.1"
  "A face for brackets."
  '((emacs "30.1"))
  :url "https://github.com/tarsius/paren-face"
  :commit "f9475c6a6e52e5047d9e87e31dec04833b1a0d4d"
  :revdesc "v1.2.4-1-gf9475c6a6e52"
  :keywords '("faces" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.paren-face@jonas.bernoulli.dev")))
