;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "4.0.0.0.20260709.428"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "26.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "f7761ab7070e8c0c1cfb97e571ba81c3377a7447"
  :revdesc "f7761ab7070e")
