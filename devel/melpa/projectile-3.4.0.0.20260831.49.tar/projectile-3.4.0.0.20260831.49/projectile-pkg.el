;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.4.0.0.20260831.49"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "9ed0b1be1f7428f6dcac3345f1b2442e06283a97"
  :revdesc "9ed0b1be1f74"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
