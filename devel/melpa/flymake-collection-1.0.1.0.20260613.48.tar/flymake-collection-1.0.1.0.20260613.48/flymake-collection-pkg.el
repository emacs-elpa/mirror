;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-collection" "1.0.1.0.20260613.48"
  "Collection of checkers for flymake, bringing flymake to the level of flycheck."
  '((emacs     "28.1")
    (let-alist "1.0")
    (flymake   "1.2.1"))
  :url "https://github.com/mohkale/flymake-collection"
  :commit "1c771edc125ae44d9574489f3989397027b17654"
  :revdesc "1c771edc125a"
  :keywords '("language" "tools")
  :authors '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@kisara.moe")))
