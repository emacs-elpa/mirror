;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-dsq" "0.1.0.20220915.22"
  "Babel functions for the `dsq` CLI tool by Multiprocess Labs."
  '((emacs "27.1"))
  :url "https://github.com/fritzgrabo/ob-dsq"
  :commit "e001b263af87993755319caefaf5d19e196e4e1b"
  :revdesc "e001b263af87"
  :keywords '("data" "tools")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
