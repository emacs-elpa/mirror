;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotated-completing-read" "0.1.0.20260927.57"
  "Ergonomic completing-read wrapper/helper."
  '((emacs "29.1"))
  :url "https://github.com/tychoish/annotated-completing-read"
  :commit "964c1e7b72f8333089e88b0990a9222f69a0dcd9"
  :revdesc "964c1e7b72f8"
  :keywords '("convenience" "matching")
  :authors '(("sam kleinman" . "garen@tychoish.com"))
  :maintainers '(("sam kleinman" . "garen@tychoish.com")))
