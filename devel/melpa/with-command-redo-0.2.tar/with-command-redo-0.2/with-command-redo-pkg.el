;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-command-redo" "0.2"
  "Repeat commands with automatic undo."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-with-command-redo"
  :commit "b3e3c86e2cbeb097552a1bff000905ad28de7907"
  :revdesc "b3e3c86e2cbe"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
