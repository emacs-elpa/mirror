;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verb" "3.2.0.0.20260818.3"
  "Organize and send HTTP requests."
  '((emacs "26.3"))
  :url "https://github.com/federicotdn/verb"
  :commit "8eca8cdb9eaebc49a7da068c74cfe52f2d37d76e"
  :revdesc "3.2.0-3-g8eca8cdb9eae"
  :keywords '("tools")
  :authors '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers '(("Federico Tedin" . "federicotedin@gmail.com")))
