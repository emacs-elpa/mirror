;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "2.0.0.20261128.18"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "c235a75f4329b531625a6652f8e48cd11354542f"
  :revdesc "c235a75f4329"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
