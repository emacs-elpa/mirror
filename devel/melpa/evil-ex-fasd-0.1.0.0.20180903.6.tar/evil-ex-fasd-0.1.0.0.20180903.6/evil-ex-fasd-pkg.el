;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ex-fasd" "0.1.0.0.20180903.6"
  "Using fasd right from evil-ex."
  '((emacs "24.4")
    (evil  "1.1.0")
    (fasd  "0"))
  :url "https://github.com/yqrashawn/evil-ex-fasd"
  :commit "ed8fbbe23a8a268d9dcbf1a6132e928ba2c655c5"
  :revdesc "ed8fbbe23a8a"
  :keywords '("tools" "fasd" "evil" "navigation")
  :authors '(("Rashawn Zhang" . "namy.19@gmail.com"))
  :maintainers '(("Rashawn Zhang" . "namy.19@gmail.com")))
