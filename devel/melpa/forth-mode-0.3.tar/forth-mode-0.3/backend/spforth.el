(provide 'spforth)
