;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vdiff-magit" "0.3.2.0.20260921.16"
  "Magit integration for vdiff."
  '((emacs     "24.4")
    (vdiff     "0.2.4")
    (magit     "2.10.0")
    (transient "0.1.0"))
  :url "https://github.com/justbur/emacs-vdiff-magit"
  :commit "56d03039e2aeac7474d3f758533d1a0bccaa9457"
  :revdesc "56d03039e2ae"
  :keywords '("diff")
  :authors '(("Justin Burkett" . "justin@burkett.cc"))
  :maintainers '(("Justin Burkett" . "justin@burkett.cc")))
