;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "4.0.9.0.20261108.11"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.9")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "4fdd575901eb7f92479db2bf7d34afa5395fb1ea"
  :revdesc "v4.0.9-11-g4fdd575901eb"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
