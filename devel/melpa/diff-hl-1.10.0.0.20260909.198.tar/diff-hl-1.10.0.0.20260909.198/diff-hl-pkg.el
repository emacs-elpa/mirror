;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "1.10.0.0.20260909.198"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "0e1d464b48172a1f1e2f36103d812c9fc6387c4e"
  :revdesc "0e1d464b4817"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
