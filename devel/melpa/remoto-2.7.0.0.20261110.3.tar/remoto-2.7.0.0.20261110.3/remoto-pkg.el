;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "2.7.0.0.20261110.3"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "509986753422b6f84731137df3b3bce44624e0f9"
  :revdesc "2.7.0-3-g509986753422"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
