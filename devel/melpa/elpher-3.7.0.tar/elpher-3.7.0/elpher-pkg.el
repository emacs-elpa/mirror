;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpher" "3.7.0"
  "A friendly gopher and gemini client."
  '((emacs "27.1"))
  :url "https://thelambdalab.xyz/elpher"
  :commit "d799c467a1f35934f96d33960d638ddf796f01ba"
  :revdesc "d799c467a1f3"
  :keywords '("comm" "gopher" "gemini")
  :authors '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainers '(("Tim Vaughan" . "plugd@thelambdalab.xyz")))
