;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-overleaf" "2.0.0.0.20260622.1"
  "Clone, push, and pull full Overleaf projects with Git."
  '((emacs         "29.4")
    (websocket     "1.15")
    (webdriver     "0.1")
    (magit-section "4.5"))
  :url "https://github.com/Jamie-Cui/git-overleaf"
  :commit "b7c8fd52568134d57a6760e6e0acb04f7a645942"
  :revdesc "b7c8fd525681"
  :keywords '("hypermedia" "tex" "tools")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
