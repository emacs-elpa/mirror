;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "back-button" "0.6.6.0.20220827.22"
  "Visual navigation through mark rings."
  '((nav-flash       "1.0.0")
    (smartrep        "0.0.3")
    (list-utils      "0.4.2")
    (persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/back-button"
  :commit "f8783c98a7fefc1d0419959c1b462c7dcadce5a8"
  :revdesc "v0.6.6-22-gf8783c98a7fe"
  :keywords '("convenience" "navigation" "interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
