;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compiler-explorer" "0.9.0.0.20261008.7"
  "Compiler explorer client (godbolt.org)."
  '((emacs "29.1")
    (plz   "0.9")
    (eldoc "1.15.0")
    (map   "3.3.1")
    (seq   "2.23"))
  :url "https://github.com/mkcms/compiler-explorer.el"
  :commit "3d85bb87d7b1ac3f942a5eaea82d6a0ab8853dcc"
  :revdesc "v0.9.0-7-g3d85bb87d7b1"
  :keywords '("c" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
