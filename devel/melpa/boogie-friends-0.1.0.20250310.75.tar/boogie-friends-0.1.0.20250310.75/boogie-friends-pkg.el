;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boogie-friends" "0.1.0.20250310.75"
  "A collection of programming modes for Boogie, Dafny, and Z3 (SMTLIB v2)."
  ()
  :url "https://github.com/boogie-org/boogie-friends/"
  :commit "54905dab2944e7e808aa9445727646d7a3855174"
  :revdesc "54905dab2944"
  :keywords '("convenience" "languages")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
