;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-haunt" "0.2.0.20230725.5"
  "Haunt-flavored HTML backend for the Org export engine."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~jakob/ox-haunt"
  :commit "1c8c70e3173f98206768c15cb2e4de706559f151"
  :revdesc "v0.2-5-g1c8c70e3173f"
  :keywords '("convenience" "hypermedia" "wp")
  :authors '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org"))
  :maintainers '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org")))
