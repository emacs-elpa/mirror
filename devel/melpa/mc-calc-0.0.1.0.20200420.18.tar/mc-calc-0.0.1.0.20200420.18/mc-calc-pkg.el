;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mc-calc" "0.0.1.0.20200420.18"
  "Combine multiple-cursors and calc."
  '((emacs            "24.4")
    (multiple-cursors "1.2.1"))
  :url "https://github.com/hatheroldev/mc-calc"
  :commit "74a046a5728919a4d1135ca62738326b0dde278c"
  :revdesc "74a046a57289"
  :keywords '("convenience")
  :authors '((nil . "FrankRolandhatheroldev@fgmail.com"))
  :maintainers '((nil . "FrankRolandhatheroldev@fgmail.com")))
