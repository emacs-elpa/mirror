;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "efire" "0.1.0.20151009.9"
  "Use campfire from Emacs."
  '((circe "1.2"))
  :url "https://github.com/capitaomorte/efire"
  :commit "d38dd6dd7974b7cb11bff6fd84846fd01163211a"
  :revdesc "d38dd6dd7974"
  :keywords '("convenience" "tools")
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
