;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "0.14.1"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "2c68f25dfe138ab5ec8f8decd23ea1426e349e7e"
  :revdesc "2c68f25dfe13")
