;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quotient" "0.1.0.20261121.23"
  "A library for generating random quotes using a text corpus."
  '((emacs  "25.1")
    (compat "30.1.0.1"))
  :url "https://github.com/tvirolai/quotient"
  :commit "f03b6a76f9fcfdc159d9406ee5f24263948045d2"
  :revdesc "f03b6a76f9fc"
  :keywords '("lisp")
  :authors '(("Tuomo Virolainen" . "tvirolai@soittakaaparanoid.mail.kapsi.fi"))
  :maintainers '(("Tuomo Virolainen" . "tvirolai@soittakaaparanoid.mail.kapsi.fi")))
