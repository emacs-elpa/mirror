;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typst-overlay" "0.8.1.0.20261103.2"
  "Overlay Typst equations."
  '((emacs "29.1"))
  :url "https://github.com/hesampakdaman/typst-overlay"
  :commit "79d9b70a81bed8dc0988016f64f138eecc991e13"
  :revdesc "79d9b70a81be"
  :keywords '("tools")
  :authors '(("Hesam Pakdaman" . "https://github.com/hesampakdaman"))
  :maintainers '(("Hesam Pakdaman" . "https://github.com/hesampakdaman")))
