;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "0.13.9.0.20261113.8"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "93423bb0c97aea87d49c50676ee63d1e5817c787"
  :revdesc "v0.13.9-8-g93423bb0c97a"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
