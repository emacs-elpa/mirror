;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-mode-line-tag" "0.1.0.20231215.6"
  "Display a buffer's project in its mode line."
  '((emacs "25.1"))
  :url "https://github.com/fritzgrabo/project-mode-line-tag"
  :commit "c63f254e006ddf6ad12c7dc15eed0484d57a8cb5"
  :revdesc "c63f254e006d"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
