;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "molar-mass" "1.0.0.20220922.3"
  "Calculates molar mass of a molecule."
  '((emacs "24.3"))
  :url "https://github.com/sergiruiztrepat/molar-mass.el"
  :commit "c3b686c4b621b45fa4b17857b4934eb4487d74f5"
  :revdesc "c3b686c4b621"
  :keywords '("convenience" "chemistry"))
