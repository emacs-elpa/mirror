;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-aider" "0.1.0.0.20250325.74"
  "Org Babel functions for Aider.el & Aidermacs integration."
  '((emacs "27.1")
    (org   "9.4"))
  :url "https://github.com/localredhead/ob-aider.el"
  :commit "f611b0e733323c04bbbcab710a78a87f47e5fc74"
  :revdesc "f611b0e73332"
  :keywords '("tools" "convenience" "languages" "org" "processes")
  :authors '(("Levi Strope" . "levi.strope@gmail.com"))
  :maintainers '(("Levi Strope" . "levi.strope@gmail.com")))
