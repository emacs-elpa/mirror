;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-semicolon" "0.2.1.0.20200909.4"
  "Insert semicolon smartly."
  '((emacs "26"))
  :url "https://github.com/iquiw/smart-semicolon"
  :commit "dd52a3e1a7b043fb88f799827c7b3e39f60a14f1"
  :revdesc "dd52a3e1a7b0"
  :authors '(("Iku Iwasa" . "iku.iwasa@gmail.com"))
  :maintainers '(("Iku Iwasa" . "iku.iwasa@gmail.com")))
