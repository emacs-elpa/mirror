;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mandm-theme" "20141112.923.0.20260513.21"
  "An M&M color theme."
  '((emacs "24.1"))
  :url "https://github.com/choppsv1/emacs-mandm-theme.git"
  :commit "c9ebcbe0518798cab3667762637062f0255bbad2"
  :revdesc "c9ebcbe05187"
  :authors '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainers '(("Christian Hopps" . "chopps@gmail.com")))
