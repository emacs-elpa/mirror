;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "palimpsest" "1.1.0.20260907.5"
  "Various deletion strategies when editing."
  ()
  :url "https://github.com/danielsz/Palimpsest"
  :commit "fe6dcf4680e6dede81970c4c46655d4ea01ec3aa"
  :revdesc "fe6dcf4680e6"
  :authors '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com"))
  :maintainers '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com")))
