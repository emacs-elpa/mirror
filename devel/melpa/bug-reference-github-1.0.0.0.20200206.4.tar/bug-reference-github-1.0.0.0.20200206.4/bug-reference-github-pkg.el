;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bug-reference-github" "1.0.0.0.20200206.4"
  "Set `bug-reference-url-format' in Github repos."
  ()
  :url "https://github.com/arnested/bug-reference-github"
  :commit "4e848472a5be464a3bc10a3c917322d1e344951a"
  :revdesc "v1.0.0-4-g4e848472a5be"
  :keywords '("programming" "tools")
  :authors '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainers '(("Arne Jørgensen" . "arne@arnested.dk")))
