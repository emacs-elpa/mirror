;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bmp" "0.6.2.0.20251005.1"
  "Version bumper for git projects."
  '((emacs "29"))
  :url "https://git.sr.ht/~lepisma/bmp"
  :commit "8f4fe653ee49860d764b789919bbd46a4a9d3768"
  :revdesc "8f4fe653ee49"
  :authors '(("Abhinav Tushar" . "lepisma@fastmail.com"))
  :maintainers '(("Abhinav Tushar" . "lepisma@fastmail.com")))
