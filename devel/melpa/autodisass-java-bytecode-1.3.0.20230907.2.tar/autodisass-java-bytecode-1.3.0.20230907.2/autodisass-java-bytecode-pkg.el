;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autodisass-java-bytecode" "1.3.0.20230907.2"
  "Automatically disassemble Java bytecode."
  ()
  :url "https://github.com/gbalats/autodisass-java-bytecode"
  :commit "02788145f5c70e9004c4eba5acffbb584fe7de37"
  :revdesc "02788145f5c7"
  :keywords '("convenience" "data" "files")
  :authors '(("George Balatsouras" . "gbalatsgmailcom"))
  :maintainers '(("George Balatsouras" . "gbalatsgmailcom")))
