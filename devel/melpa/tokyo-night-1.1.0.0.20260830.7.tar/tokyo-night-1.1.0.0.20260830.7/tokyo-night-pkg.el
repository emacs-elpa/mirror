;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "1.1.0.0.20260830.7"
  "Tokyo Night color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "390620dc6a6b76686437bbfa3d9cd7fde0ccb10b"
  :revdesc "390620dc6a6b"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
