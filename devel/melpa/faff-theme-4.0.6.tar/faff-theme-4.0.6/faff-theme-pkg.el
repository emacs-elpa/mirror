;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "4.0.6"
  "Light cornsilk theme with warm, earthy colors."
  '((emacs        "28.1")
    (modus-themes "5.0.0"))
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "374759dc41af124480d1ea383d8118f9010f58d2"
  :revdesc "374759dc41af"
  :keywords '("faces" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
