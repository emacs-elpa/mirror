;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20260926.137"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "5cb062e183f93f5ebc03c1344255bbadc94f9b81"
  :revdesc "5cb062e183f9")
