;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-nix" "0.1.0.20221224.5"
  "Simple org-babel support for nix."
  '((emacs "24.1"))
  :url "https://codeberg.org/theesm/ob-nix"
  :commit "76d71b37fb031f25bd52ff9c98b29292ebe0424e"
  :revdesc "76d71b37fb03"
  :keywords '("lisp" "tools")
  :authors '(("Wilko Meyer" . "w-devel@wmeyer.eu"))
  :maintainers '(("Wilko Meyer" . "w-devel@wmeyer.eu")))
