;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "1.32.2.0.20260928.2"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.31.1")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "72f91cf436a025fec5c5fbd0bb47df0556468bf7"
  :revdesc "72f91cf436a0"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
