;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "0.0.2.0.20261005.1"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "ee2b167d3b241d9621272cba9db04995bd8ad340"
  :revdesc "v0.0.2-1-gee2b167d3b24"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
