;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "samskritam" "0.3.0"
  "Sanskrit dictionaries, translation, and input."
  '((emacs     "28.1")
    (transient "0.3.0"))
  :url "https://github.com/thapakrish/samskritam"
  :commit "ebd4e688c242e6cfcde08c8563473be9283e893e"
  :revdesc "ebd4e688c242"
  :keywords '("samskrit" "sanskrit" "संस्कृत" "dictionary" "devanagari" "convenience" "language")
  :authors '(("Krishna Thapa" . "thapakrish@gmail.com"))
  :maintainers '(("Krishna Thapa" . "thapakrish@gmail.com")))
