;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.8.0"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "7284e039dca46a512e25288c9d644ce8f21aeea1"
  :revdesc "v0.8.0-0-g7284e039dca4"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
