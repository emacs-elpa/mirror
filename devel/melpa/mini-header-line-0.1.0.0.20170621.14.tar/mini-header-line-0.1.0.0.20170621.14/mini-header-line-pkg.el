;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mini-header-line" "0.1.0.0.20170621.14"
  "A minimal header-line."
  '((emacs "24.4"))
  :url "https://github.com/ksjogo/mini-header-line"
  :commit "73b6724e0a26c4528d93768191c8aa59e6bce2e5"
  :revdesc "73b6724e0a26"
  :keywords '("header-line" "mode-line"))
