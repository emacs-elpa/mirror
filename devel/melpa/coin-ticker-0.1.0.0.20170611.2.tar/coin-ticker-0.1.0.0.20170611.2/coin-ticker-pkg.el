;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coin-ticker" "0.1.0.0.20170611.2"
  "Show a cryptocurrency price ticker."
  '((request "0.3.0")
    (emacs   "25"))
  :url "https://github.com/eklitzke/coin-ticker-mode"
  :commit "45108e239e1d129c0cc1ff37f2870cf73087780b"
  :revdesc "45108e239e1d"
  :keywords '("news")
  :authors '(("Evan Klitzke" . "evan@eklitzke.org"))
  :maintainers '(("Evan Klitzke" . "evan@eklitzke.org")))
