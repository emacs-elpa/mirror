;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ext" "0.9.0.0.20260915.4"
  "SystemVerilog Extensions."
  '((emacs           "29.1")
    (verilog-mode    "2024.3.1.121933719")
    (verilog-ts-mode "0.6.0")
    (lsp-mode        "8.0.0")
    (rg              "2.3.0")
    (hydra           "0.15.0")
    (apheleia        "3.1")
    (yasnippet       "0.14.0")
    (flycheck        "32")
    (async           "1.9.7"))
  :url "https://github.com/gmlarumbe/verilog-ext"
  :commit "25bae4107e7aa644baebd7c41fe5003cd55c3b66"
  :revdesc "25bae4107e7a"
  :keywords '("verilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
