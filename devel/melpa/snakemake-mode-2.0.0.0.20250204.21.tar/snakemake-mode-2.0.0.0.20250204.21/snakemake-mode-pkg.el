;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snakemake-mode" "2.0.0.0.20250204.21"
  "Major mode for editing Snakemake files."
  '((emacs     "27.1")
    (transient "0.3.0"))
  :url "https://git.kyleam.com/snakemake-mode/about"
  :commit "e4751a951a53c4d4610b2eb17469a21177cab6bc"
  :revdesc "v2.0.0-21-ge4751a951a53"
  :keywords '("tools")
  :authors '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainers '(("Kyle Meyer" . "kyle@kyleam.com")))
