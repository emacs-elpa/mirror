;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "korean-holidays" "0.1.0.0.20260326.8"
  "Korean holidays for calendar."
  ()
  :url "https://github.com/tttuuu888/korean-holidays"
  :commit "465fc0e7e95354f75678c2d310edc74743414d1b"
  :revdesc "465fc0e7e953"
  :keywords '("calendar")
  :authors '(("SeungKi Kim" . "tttuuu888@gmail.com"))
  :maintainers '(("SeungKi Kim" . "tttuuu888@gmail.com")))
