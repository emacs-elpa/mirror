;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kivy-mode" "2.3.1.0.20250528.143"
  "Emacs major mode for editing Kivy files."
  ()
  :url "https://github.com/kivy/kivy"
  :commit "42a3d0a62eaa54890a1e6461ecfc6199ac26a1b0"
  :revdesc "42a3d0a62eaa"
  :authors '(("Dean Serenevy" . "dean@serenevy.net"))
  :maintainers '(("Dean Serenevy" . "dean@serenevy.net")))
