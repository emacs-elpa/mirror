;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpr-yasnippets" "0.5.0"
  "Yasnippets for GNAT project files."
  '((emacs     "24.4")
    (yasnippet "0.14.0"))
  :url "https://github.com/brownts/gpr-yasnippets"
  :commit "d66ea90e8e45f6d0c3bd62185967c26190117296"
  :revdesc "d66ea90e8e45"
  :keywords '("gpr" "gnat" "languages" "snippets")
  :authors '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainers '(("Troy Brown" . "brownts@troybrown.dev")))
