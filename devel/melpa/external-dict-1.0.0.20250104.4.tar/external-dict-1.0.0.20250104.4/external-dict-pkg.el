;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "external-dict" "1.0.0.20250104.4"
  "Query external dictionary like goldendict, Bob.app etc."
  '((emacs "25.1"))
  :url "https://repo.or.cz/external-dict.el.git"
  :commit "018cc2bad2e8bf29914d39b0119e836fa0f9dc18"
  :revdesc "018cc2bad2e8"
  :keywords '("wp" "processes")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
