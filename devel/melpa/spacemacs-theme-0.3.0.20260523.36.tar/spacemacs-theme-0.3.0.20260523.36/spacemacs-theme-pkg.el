;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spacemacs-theme" "0.3.0.20260523.36"
  "Color theme with a dark and light versions."
  '((emacs "24"))
  :url "https://github.com/nashamri/spacemacs-theme"
  :commit "cbd290dfde96f53a7b41730c7840850a8a7b8a02"
  :revdesc "cbd290dfde96"
  :keywords '("color" "theme"))
