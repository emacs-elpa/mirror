;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.43.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "df9b7e1ab3bb2a5305232f02f7619e4e2f0570b4"
  :revdesc "df9b7e1ab3bb"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
