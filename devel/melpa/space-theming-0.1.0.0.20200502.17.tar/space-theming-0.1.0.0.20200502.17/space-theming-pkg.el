;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "space-theming" "0.1.0.0.20200502.17"
  "Easilly override theme faces."
  '((emacs "24"))
  :url "https://github.com/p3r7/space-theming"
  :commit "31dca6954df643255175f7df68a86892aa3c71a7"
  :revdesc "31dca6954df6"
  :keywords '("faces"))
