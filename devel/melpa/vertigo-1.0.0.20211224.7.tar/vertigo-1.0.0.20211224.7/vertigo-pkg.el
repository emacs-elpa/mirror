;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertigo" "1.0.0.20211224.7"
  "Jump across lines using the home row."
  '((dash "2.11.0"))
  :url "https://github.com/noctuid/vertigo.el"
  :commit "280b30518529242ee36cd436bd2349c34c35abb0"
  :revdesc "v1.0-7-g280b30518529"
  :keywords '("vim" "vertigo")
  :authors '(("Fox Kiester" . "noct@posteo.net"))
  :maintainers '(("Fox Kiester" . "noct@posteo.net")))
