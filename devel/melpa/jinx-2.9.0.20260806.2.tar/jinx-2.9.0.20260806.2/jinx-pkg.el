;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "2.9.0.20260806.2"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "e859caedcaec6c2d6f621dd90c2bcf56d2954c4d"
  :revdesc "2.9-2-ge859caedcaec"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
