;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mip-mode" "0.0.0.20151127.34"
  "Virtual projects for emacs."
  ()
  :url "https://gitlab.com/gaudecker/mip-mode"
  :commit "7c88c383b4c7ed0a4c1dc397735f365c1fcb461c"
  :revdesc "7c88c383b4c7"
  :keywords '("workspaces" "workspace" "project" "projects" "mip-mode")
  :authors '(("Eeli Reilin" . "gaudecker@fea.st"))
  :maintainers '(("Eeli Reilin" . "gaudecker@fea.st")))
