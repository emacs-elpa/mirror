;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "purty-mode" "0.0.0.20131004.16"
  "Safely pretty-print greek letters, mathematical symbols, or anything else."
  ()
  :url "https://github.com/jcatw/purty-mode"
  :commit "ad48149bfd0c765796a728b22d679e03fc124328"
  :revdesc "ad48149bfd0c"
  :authors '(("James Atwood" . "jatwood@cs.umass.edu"))
  :maintainers '(("James Atwood" . "jatwood@cs.umass.edu")))
