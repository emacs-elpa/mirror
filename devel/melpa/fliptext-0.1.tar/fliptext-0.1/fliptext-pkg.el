;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fliptext" "0.1"
  "Input method for flipping characters upside down."
  ()
  :url "https://github.com/andre-r/fliptext.el"
  :commit "fd821f645ffebae6ae3894afa7ba7fc06f91afc6"
  :revdesc "fd821f645ffe"
  :keywords '("games" "i18n")
  :authors '(("André Riemann" . "andre.riemann@web.de"))
  :maintainers '(("André Riemann" . "andre.riemann@web.de")))
