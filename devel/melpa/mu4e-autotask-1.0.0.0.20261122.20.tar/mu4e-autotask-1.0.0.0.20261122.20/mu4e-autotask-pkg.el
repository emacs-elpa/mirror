;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-autotask" "1.0.0.0.20261122.20"
  "Email automation for mu4e."
  '((emacs "29.1"))
  :url "https://github.com/laurynas-biveinis/mu4e-autotask"
  :commit "67ce827d9ba6ba549c0981c04557b2037642aa46"
  :revdesc "1.0.0-20-g67ce827d9ba6"
  :keywords '("mail")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
