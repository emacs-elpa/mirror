;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "0.1.0.0.20261004.55"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (transient  "0.7.0")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "a3f7e876cbd719cf393ed7d1ea527caaf57b6a60"
  :revdesc "a3f7e876cbd7"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
