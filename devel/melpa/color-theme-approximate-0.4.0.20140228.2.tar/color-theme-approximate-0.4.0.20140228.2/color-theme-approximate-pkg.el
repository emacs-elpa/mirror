;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-approximate" "0.4.0.20140228.2"
  "Makes Emacs theme works on terminal transparently."
  ()
  :url "https://github.com/tungd/color-theme-approximate"
  :commit "f54301ca39bc5d2ffb000f233f8114184a3e7d71"
  :revdesc "f54301ca39bc"
  :authors '(("Tung Dao" . "me@tungdao.com"))
  :maintainers '(("Tung Dao" . "me@tungdao.com")))
