;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-ical" "2.0.0.20260426.44"
  "Calendar view for ical format."
  '((emacs "28.1")
    (calfw "2.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "24fa167af96a6e677aea7c6b9385f669b550ee2f"
  :revdesc "v2.0-44-g24fa167af96a"
  :keywords '("calendar" "ical")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
