;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "1.0.0.20260826.175"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "2becb4d66fdcfe89eccf43ac592557c6a402420a"
  :revdesc "2becb4d66fdc"
  :keywords '("convenience"))
