;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elx" "2.3.3.0.20260925.1"
  "Extract information from Emacs Lisp libraries."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/elx"
  :commit "afa00d06197ae54c1be75259d5091210f5bb9597"
  :revdesc "v2.3.3-1-gafa00d06197a"
  :keywords '("docs" "libraries" "packages")
  :authors '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev")))
