;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gsnip" "0.1.0.0.20220206.1"
  "A gitlab snippet client."
  '((emacs "26")
    (aio   "1.0")
    (log4e "0.3.3"))
  :url "https://github.com/kaiwk/gitlab-snippet"
  :commit "4d473b726b3f3b6bb7d1b5f66a9d368588ce0f86"
  :revdesc "4d473b726b3f"
  :keywords '("extensions" "tools")
  :authors '(("Wang Kai" . "kaiwkx@gmail.com"))
  :maintainers '(("Wang Kai" . "kaiwkx@gmail.com")))
