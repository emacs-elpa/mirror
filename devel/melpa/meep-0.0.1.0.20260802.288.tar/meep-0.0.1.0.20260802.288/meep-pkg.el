;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "0.0.1.0.20260802.288"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "9e3507a130c83dfd3b6c6b7f639161625c869c8d"
  :revdesc "9e3507a130c8"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
