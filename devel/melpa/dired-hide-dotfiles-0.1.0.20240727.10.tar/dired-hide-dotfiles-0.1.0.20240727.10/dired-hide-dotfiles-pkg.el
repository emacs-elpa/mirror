;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-hide-dotfiles" "0.1.0.20240727.10"
  "Hide dotfiles in dired."
  '((emacs "25.1"))
  :url "https://github.com/mattiasb/dired-hide-dotfiles"
  :commit "0d035ba8c5decc5957d50f3c64ef860b5c2093a1"
  :revdesc "v0.1-10-g0d035ba8c5de"
  :keywords '("files")
  :authors '(("Mattias Bengtsson" . "mattias.jc.bengtsson@gmail.com"))
  :maintainers '(("Mattias Bengtsson" . "mattias.jc.bengtsson@gmail.com")))
