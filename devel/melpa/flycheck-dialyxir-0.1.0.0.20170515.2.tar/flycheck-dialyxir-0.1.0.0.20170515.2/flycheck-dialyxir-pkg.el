;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-dialyxir" "0.1.0.0.20170515.2"
  "Flycheck checker for elixir dialyxir."
  '((flycheck "29"))
  :url "https://github.com/aaronjensen/flycheck-dialyxir"
  :commit "adfb73374cb2bee75724822972f405f2ec371199"
  :revdesc "adfb73374cb2"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
