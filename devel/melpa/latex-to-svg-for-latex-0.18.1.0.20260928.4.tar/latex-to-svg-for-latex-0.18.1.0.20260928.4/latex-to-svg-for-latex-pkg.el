;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-latex" "0.18.1.0.20260928.4"
  "Preview LaTeX math as SVG in LaTeX buffers."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.18.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "48d48b529501905eda922cd1c8ac46afbf0ea27b"
  :revdesc "v0.18.1-4-g48d48b529501"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
