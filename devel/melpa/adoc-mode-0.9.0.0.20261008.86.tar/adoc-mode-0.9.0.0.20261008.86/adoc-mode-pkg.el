;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "0.9.0.0.20261008.86"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "513b82b603429d95db9cbd389cb3b205d31c905f"
  :revdesc "513b82b60342"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
