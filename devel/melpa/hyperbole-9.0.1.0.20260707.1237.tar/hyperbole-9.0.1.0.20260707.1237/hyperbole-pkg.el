;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.0.1.0.20260707.1237"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "48762caeee9466e79a7952cf4c69f7d0278db060"
  :revdesc "48762caeee94"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
