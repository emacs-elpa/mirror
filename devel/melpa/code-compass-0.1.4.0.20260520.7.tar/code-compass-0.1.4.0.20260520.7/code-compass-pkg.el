;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-compass" "0.1.4.0.20260520.7"
  "Navigate software aided by metrics and visualization."
  '((emacs        "26.1")
    (s            "1.12.0")
    (dash         "2.13")
    (async        "1.9.7")
    (simple-httpd "1.5.1"))
  :url "https://github.com/ag91/code-compass"
  :commit "f5b96ab2f0866ab3dcae170a9953d7eb0ef52dbf"
  :revdesc "f5b96ab2f086"
  :keywords '("tools" "extensions" "help")
  :authors '(("Andrea" . "andrea-dev@hotmail.com"))
  :maintainers '(("Andrea" . "andrea-dev@hotmail.com")))
