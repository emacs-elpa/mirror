;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.6.0.0.20260730.26"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "5cc795be12f4e46b6cc2f2053986597f620254c6"
  :revdesc "5cc795be12f4"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
