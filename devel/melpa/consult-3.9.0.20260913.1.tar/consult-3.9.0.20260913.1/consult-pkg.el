;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "3.9.0.20260913.1"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "887ada3b684b233375435cf8f38eaafd240edcb4"
  :revdesc "3.9-1-g887ada3b684b"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
