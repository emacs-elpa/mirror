;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smyx-theme" "0.10.0.20240914.18"
  "Smyx Color Theme."
  ()
  :url "https://github.com/tacit7/smyx"
  :commit "ce6dc4b1c25ff8c1d6c9b9015e0199355c46be4d"
  :revdesc "ce6dc4b1c25f"
  :keywords '("color" "theme" "smyx")
  :authors '(("Uriel G Maldonado" . "uriel781@gmail.com"))
  :maintainers '(("Uriel G Maldonado" . "uriel781@gmail.com")))
