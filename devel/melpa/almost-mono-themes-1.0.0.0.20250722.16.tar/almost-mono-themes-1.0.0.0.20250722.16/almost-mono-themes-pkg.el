;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "almost-mono-themes" "1.0.0.0.20250722.16"
  "Almost monochromatic color themes."
  '((emacs "24"))
  :url "https://github.com/cryon/almost-mono-themes"
  :commit "1b739fef5f26a64ea22736012c3899d70c83df2d"
  :revdesc "1b739fef5f26"
  :keywords '("faces")
  :authors '(("John Olsson" . "john@cryon.se"))
  :maintainers '(("John Olsson" . "john@cryon.se")))
