;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "langtool-ignore-fonts" "0.3.0.20210526.3"
  "Force langtool to ignore certain fonts."
  '((emacs    "25.1")
    (langtool "2.2.1"))
  :url "https://github.com/cjl8zf/langtool-ignore-fonts"
  :commit "a5d04c3840c293f1b11db3c28e7210d0d20f53af"
  :revdesc "a5d04c3840c2"
  :authors '(("Christopher Lloyd" . "cjl8zf@virginia.edu"))
  :maintainers '(("Christopher Lloyd" . "cjl8zf@virginia.edu")))
