;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gruber-darker-theme" "0.6.0.20231026.36"
  "Gruber Darker color theme for Emacs 24."
  ()
  :url "https://github.com/rexim/gruber-darker-theme"
  :commit "2e9f99c41fe8ef0557e9ea0f3b94ef50c68b5557"
  :revdesc "2e9f99c41fe8"
  :authors '(("Alexey Kutepov" . "reximkut@gmail.com"))
  :maintainers '(("Alexey Kutepov" . "reximkut@gmail.com")))
