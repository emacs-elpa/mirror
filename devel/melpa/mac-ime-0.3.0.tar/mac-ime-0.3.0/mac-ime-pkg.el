;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mac-ime" "0.3.0"
  "Seamless macOS IME integration without any IME patches."
  '((emacs "27.1"))
  :url "https://github.com/ma0001/mac-ime"
  :commit "bec58817ea55871e06e5d2d62bad0d18f8ec7efa"
  :revdesc "bec58817ea55"
  :keywords '("i18n" "convenience"))
