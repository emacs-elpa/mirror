;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected" "1.2.0.20260523.4"
  "Keymap for when region is active."
  ()
  :url "https://github.com/Kungsgeten/selected.el"
  :commit "9f5a6324e4911515972989841f143696472f2374"
  :revdesc "9f5a6324e491"
  :keywords '("convenience"))
