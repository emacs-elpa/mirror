;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conventional" "1.0.0"
  "Enable conventional syntax."
  '((emacs "28.1"))
  :url "https://github.com/KeyWeeUsr/conventional"
  :commit "d4172953ddb8239108014ee82164892f08371b3b"
  :revdesc "1.0.0-0-gd4172953ddb8"
  :keywords '("convenience" "conventional" "mode" "helper" "git" "comment" "commit")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
