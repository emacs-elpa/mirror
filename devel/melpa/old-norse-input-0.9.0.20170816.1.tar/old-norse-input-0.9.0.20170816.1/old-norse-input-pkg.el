;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "old-norse-input" "0.9.0.20170816.1"
  "An input method for Old Norse."
  '((emacs "24"))
  :url "https://github.com/david-christiansen/emacs-old-norse-input"
  :commit "c2e21ee72c3768e9152aff6baf12a19cde1d0c53"
  :revdesc "c2e21ee72c37"
  :keywords '("languages")
  :authors '(("David Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Christiansen" . "david@davidchristiansen.dk")))
