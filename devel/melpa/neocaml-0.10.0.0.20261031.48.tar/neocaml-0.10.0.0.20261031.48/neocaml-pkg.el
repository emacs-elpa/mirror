;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "0.10.0.0.20261031.48"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "a07bcb779d15a00ce7fbbc5df779ffac10c53960"
  :revdesc "a07bcb779d15"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
