;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "related-files" "0.3.0.0.20230903.14"
  "Easily find files related to the current one."
  '((emacs "28.2"))
  :url "https://www.gnu.org/software/emacs/"
  :commit "8020f375013d5e83c9b8117d118d2402c63e66bb"
  :revdesc "v0.3.0-14-g8020f375013d"
  :keywords '("tools")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
