;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "4.5.0.0.20260803.14"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "0d64f2c99d886bf7aa1a64a2aa73d52bb8e8f912"
  :revdesc "0d64f2c99d88"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
