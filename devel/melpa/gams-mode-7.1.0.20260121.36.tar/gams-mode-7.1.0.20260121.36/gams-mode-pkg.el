;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gams-mode" "7.1.0.20260121.36"
  "Major mode for General Algebraic Modeling System (GAMS)."
  '((emacs "25.1"))
  :url "https://github.com/ShiroTakeda/gams-mode"
  :commit "eeb4cfcf98d113388a5d66b2fa65cb32563ef9af"
  :revdesc "eeb4cfcf98d1"
  :keywords '("languages" "tools" "gams"))
