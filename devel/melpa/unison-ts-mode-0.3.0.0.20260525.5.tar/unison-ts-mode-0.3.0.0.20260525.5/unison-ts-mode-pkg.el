;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison-ts-mode" "0.3.0.0.20260525.5"
  "Tree-sitter support for Unison."
  '((emacs "29.1"))
  :url "https://github.com/fmguerreiro/unison-ts-mode"
  :commit "31bbb4fbcba02075cebcdedb05d29568420bac9f"
  :revdesc "v0.3.0-5-g31bbb4fbcba0"
  :keywords '("languages" "unison" "tree-sitter")
  :authors '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com"))
  :maintainers '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com")))
