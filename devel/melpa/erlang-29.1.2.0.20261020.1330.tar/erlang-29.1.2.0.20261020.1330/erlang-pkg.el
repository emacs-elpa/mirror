;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "29.1.2.0.20261020.1330"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "81cad9494bf66b1c482f1bf2180f88275265cb68"
  :revdesc "OTP-29.1.2-1330-g81cad9494bf6"
  :keywords '("erlang" "languages" "processes"))
