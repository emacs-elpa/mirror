;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ede-php-autoload" "1.1.0.0.20230916.22"
  "Simple EDE PHP Project."
  ()
  :url "https://github.com/emacs-php/ede-php-autoload"
  :commit "a7c16292ecaf9b39321e7a99ccac259fcbf6c373"
  :revdesc "a7c16292ecaf"
  :keywords '("php" "project" "ede")
  :authors '(("Steven Rémot" . "steven.remot@gmail.com")
             ("original code for C++ by Eric M. Ludlam" . "eric@siege-engine.com"))
  :maintainers '(("Steven Rémot" . "steven.remot@gmail.com")
                 ("original code for C++ by Eric M. Ludlam" . "eric@siege-engine.com")))
