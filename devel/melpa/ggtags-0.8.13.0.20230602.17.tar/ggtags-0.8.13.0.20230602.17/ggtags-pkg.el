;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ggtags" "0.8.13.0.20230602.17"
  "Emacs frontend to GNU Global source code tagging system."
  '((emacs "25"))
  :url "https://github.com/leoliu/ggtags"
  :commit "4e3630c30fb836872b5d8f2ae3e5d5ae003365d8"
  :revdesc "4e3630c30fb8"
  :keywords '("tools" "convenience")
  :authors '(("Leo Liu" . "sdl.web@gmail.com"))
  :maintainers '(("Leo Liu" . "sdl.web@gmail.com")))
