;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sexp-diff" "0.0.0.20200314.9"
  "Diff sexps based on Levenshtein-like edit distance."
  '((emacs "25"))
  :url "https://github.com/xuchunyang/sexp-diff.el"
  :commit "4fea80f7b04c64b160a95bdc9d6de68c71096706"
  :revdesc "4fea80f7b04c"
  :keywords '("lisp"))
