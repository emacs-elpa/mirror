;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-enbox" "0.1.4.0.20140508.3"
  "Surround a string with box-drawing characters."
  '((string-utils    "0.3.2")
    (ucs-utils       "0.7.6")
    (list-utils      "0.4.2")
    (persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/unicode-enbox"
  :commit "4e8ac89b0460eaba6d6eaa8c463eb069660218fa"
  :revdesc "v0.1.4-3-g4e8ac89b0460"
  :keywords '("extensions" "interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
