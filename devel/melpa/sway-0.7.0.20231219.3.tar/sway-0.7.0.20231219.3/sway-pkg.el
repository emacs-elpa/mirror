;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sway" "0.7.0.20231219.3"
  "Communication with the Sway window manager."
  '((emacs "28.1"))
  :url "https://github.com/thblt/sway.el"
  :commit "84eae5e16a643eb00b0a422ded751cceb17cc8f0"
  :revdesc "0.7-3-g84eae5e16a64"
  :keywords '("frames")
  :authors '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainers '(("Thibault Polge" . "thibault@thb.lt")))
