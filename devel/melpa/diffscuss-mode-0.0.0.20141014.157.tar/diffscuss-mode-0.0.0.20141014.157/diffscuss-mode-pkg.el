;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diffscuss-mode" "0.0.0.20141014.157"
  "Major mode for diffscuss files."
  ()
  :url "https://github.com/tomheon/diffscuss"
  :commit "bbc6dbed4b97d1eb9ae5dae021ed1e066129bd98"
  :revdesc "bbc6dbed4b97"
  :keywords '("tools")
  :authors '(("Edmund Jorgensen" . "edmund@hut8labs.com"))
  :maintainers '(("Edmund Jorgensen" . "edmund@hut8labs.com")))
