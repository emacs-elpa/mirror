;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lfe-mode" "2.2.2.0.20260926.1"
  "Lisp Flavoured Erlang mode."
  ()
  :url "https://github.com/rvirding/lfe"
  :commit "387d0aa1092bdda0ca17481869e833b24f11971a"
  :revdesc "387d0aa1092b")
