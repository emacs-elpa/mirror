;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tiny-menu" "1.0.0.20220725.24"
  "Display tiny menus."
  '((emacs "24.4"))
  :url "https://github.com/aaronbieber/tiny-menu.el"
  :commit "17eacfd1d44cd4d5482d32eac63229230c3cd3fc"
  :revdesc "17eacfd1d44c"
  :keywords '("menu" "tools")
  :authors '(("Aaron Bieber" . "aaron@aaronbieber.com"))
  :maintainers '(("Aaron Bieber" . "aaron@aaronbieber.com")))
