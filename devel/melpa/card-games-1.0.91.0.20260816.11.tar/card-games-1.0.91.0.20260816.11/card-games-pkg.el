;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "card-games" "1.0.91.0.20260816.11"
  "Play card games (console + SVG)."
  '((emacs "26.1"))
  :url "https://code.bru.st/corwin/card-game.el"
  :commit "1a5d23d39eb3d7dfcdeabc8e99c2673fd4937434"
  :revdesc "1.0.91-11-g1a5d23d39eb3"
  :keywords '("games")
  :authors '(("Corwin Brust" . "corwin@bru.st"))
  :maintainers '(("Corwin Brust" . "corwin@bru.st")))
