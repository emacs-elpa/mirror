;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.4.0.20261005.36"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "d62e585441fcfc983f39c20f1649a922501fa75a"
  :revdesc "d62e585441fc"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
