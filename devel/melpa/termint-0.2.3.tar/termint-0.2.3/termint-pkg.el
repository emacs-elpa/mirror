;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termint" "0.2.3"
  "Run REPLs in a terminal backend."
  '((emacs "29.1"))
  :url "https://github.com/milanglacier/termint.el"
  :commit "f51ab6c4ef50eb8781560d3596335a6f7f668c7c"
  :revdesc "v0.2.3-0-gf51ab6c4ef50"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
