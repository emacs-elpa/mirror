;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gmail2bbdb" "0.0.6.0.20170423.2"
  "Import email and name into bbdb from vcard."
  ()
  :url "https://github.com/redguardtoo/gmail2bbdb"
  :commit "a84fa385cfaec7fc5f1518c368e52722da139f99"
  :revdesc "a84fa385cfae"
  :keywords '("vcard" "bbdb" "email" "contact" "gmail")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
