;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.55.0.0.20260917.1"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "026e345c6c7dce958c0cbdca687a859dfd7f5063"
  :revdesc "026e345c6c7d"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
