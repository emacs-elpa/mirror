;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml-mode" "0.1.3.0.20161107.15"
  "Major mode for editing TOML files."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/dryman/toml-mode.el"
  :commit "f6c61817b00f9c4a3cab1bae9c309e0fc45cdd06"
  :revdesc "f6c61817b00f"
  :keywords '("data" "toml")
  :authors '(("Felix Chern" . "idryman@gmail.com"))
  :maintainers '(("Felix Chern" . "idryman@gmail.com")))
