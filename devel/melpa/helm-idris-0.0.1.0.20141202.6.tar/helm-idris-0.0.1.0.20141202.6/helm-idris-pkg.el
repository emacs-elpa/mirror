;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-idris" "0.0.1.0.20141202.6"
  "A Helm datasource for Idris documentation, queried from the compiler."
  '((helm       "0.0.0")
    (idris-mode "0.9.14"))
  :url "https://github.com/david-christiansen/helm-idris"
  :commit "a2f45d6817974f318b55ad9b7fd19d5df132d47e"
  :revdesc "a2f45d681797"
  :keywords '("languages" "helm")
  :authors '(("David Raymond Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Raymond Christiansen" . "david@davidchristiansen.dk")))
