;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-x" "1.3.0.20201204.21"
  "Convert color themes to X11 resource settings."
  '((cl-lib "0.5"))
  :url "https://github.com/ajsquared/color-theme-x"
  :commit "ec853dd931d625e07116fbc91d8829bd15f90889"
  :revdesc "ec853dd931d6"
  :keywords '("convenience" "faces" "frames")
  :authors '(("Matthew Kennedy" . "mkennedy@killr.ath.cx"))
  :maintainers '(("Andrew Johnson" . "andrew@andrewjamesjohnson.com")))
