;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-systemd" "0.0.1.0.20210105.20"
  "Helm's systemd interface."
  '((emacs       "24.4")
    (helm        "1.9.2")
    (with-editor "2.5.0"))
  :url "https://github.com/Lompik/helm-systemd"
  :commit "8b26ab2d3a5b08c1e03c9312818512d7492bbc9a"
  :revdesc "8b26ab2d3a5b"
  :keywords '("convenience")
  :authors '((nil . "lompik@oriontabArch"))
  :maintainers '((nil . "lompik@oriontabArch")))
