;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "debian-el" "37.4.0.20260324.197"
  "Startup file for the debian-el package."
  ()
  :commit "d0f6cc8474fa0c022d738acdc159c1550188c991"
  :revdesc "37.4-197-gd0f6cc8474fa"
  :keywords '("debian" "apt" "elisp")
  :authors '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org"))
  :maintainers '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org")))
