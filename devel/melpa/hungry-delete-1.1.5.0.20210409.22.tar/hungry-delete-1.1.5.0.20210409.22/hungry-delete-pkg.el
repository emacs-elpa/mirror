;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hungry-delete" "1.1.5.0.20210409.22"
  "Hungry delete minor mode."
  ()
  :url "https://github.com/nflath/hungry-delete"
  :commit "d919e555e5c13a2edf4570f3ceec84f0ade71657"
  :revdesc "d919e555e5c1"
  :authors '(("Nathaniel Flath" . "flat0103@gmail.com"))
  :maintainers '(("Nathaniel Flath" . "flat0103@gmail.com")))
