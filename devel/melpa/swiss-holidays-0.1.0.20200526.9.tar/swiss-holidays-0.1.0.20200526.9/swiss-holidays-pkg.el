;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swiss-holidays" "0.1.0.20200526.9"
  "Swiss holidays for the calendar."
  ()
  :url "https://github.com/egli/swiss-holidays"
  :commit "0995c9685033a09466f5b2dceb7316362bde997a"
  :revdesc "0995c9685033"
  :keywords '("calendar")
  :authors '(("Christian Egli" . "christian.egli@alumni.ethz.ch"))
  :maintainers '(("Christian Egli" . "christian.egli@alumni.ethz.ch")))
