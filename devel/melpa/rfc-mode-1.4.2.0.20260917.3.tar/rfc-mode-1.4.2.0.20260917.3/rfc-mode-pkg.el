;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rfc-mode" "1.4.2.0.20260917.3"
  "RFC document browser and viewer."
  '((emacs "25.1"))
  :url "https://github.com/galdor/rfc-mode"
  :commit "cd2cd1a8d9cf08634c3b9ff768f085ffdacbac0c"
  :revdesc "v1.4.2-3-gcd2cd1a8d9cf"
  :authors '(("Nicolas Martyanoff" . "nicolas@n16f.net"))
  :maintainers '(("Nicolas Martyanoff" . "nicolas@n16f.net")))
