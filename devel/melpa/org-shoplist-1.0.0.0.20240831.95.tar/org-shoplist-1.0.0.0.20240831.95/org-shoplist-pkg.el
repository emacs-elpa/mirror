;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-shoplist" "1.0.0.0.20240831.95"
  "Eat the world."
  '((emacs "25"))
  :url "https://github.com/lordnik22"
  :commit "20c33b7310694742b814bf1ca3c05d3496d2a313"
  :revdesc "20c33b731069"
  :keywords '("extensions" "matching"))
