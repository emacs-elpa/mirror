;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-org-rifle" "1.7.1.0.20230821.10"
  "Rifle through your Org files."
  '((emacs "24.4")
    (dash  "2.12")
    (f     "0.18.1")
    (helm  "1.9.4")
    (s     "1.10.0"))
  :url "https://github.com/alphapapa/helm-org-rifle"
  :commit "03a52265040b8c6510a8269213d750c451779c38"
  :revdesc "1.7.1-10-g03a52265040b"
  :keywords '("hypermedia" "outlines")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
