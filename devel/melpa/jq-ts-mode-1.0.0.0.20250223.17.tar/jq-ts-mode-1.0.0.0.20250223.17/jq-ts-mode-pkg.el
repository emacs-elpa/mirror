;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jq-ts-mode" "1.0.0.0.20250223.17"
  "Tree-sitter support for jq buffers."
  '((emacs "29.1"))
  :url "https://github.com/nverno/jq-ts-mode"
  :commit "3ac689c3c38be9117076de0bcc15510e369016c9"
  :revdesc "3ac689c3c38b"
  :keywords '("jq" "languages" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
