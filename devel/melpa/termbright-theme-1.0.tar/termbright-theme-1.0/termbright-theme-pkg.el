;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termbright-theme" "1.0"
  "A more usable theme for white-on-black terminals."
  '((emacs "24.1"))
  :url "https://github.com/bmastenbrook/termbright-theme-el"
  :commit "bec6ab14336c0611e85f45486276004f16d20607"
  :revdesc "bec6ab14336c"
  :keywords '("themes")
  :authors '(("Brian Mastenbrook" . "brian@mastenbrook.net"))
  :maintainers '(("Brian Mastenbrook" . "brian@mastenbrook.net")))
