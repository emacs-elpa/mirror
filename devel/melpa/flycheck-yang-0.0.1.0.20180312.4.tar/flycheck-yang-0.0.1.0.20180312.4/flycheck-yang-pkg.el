;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-yang" "0.0.1.0.20180312.4"
  "YANG flycheck checker."
  '((yang-mode "0.9.4")
    (flycheck  "0.18"))
  :url "https://github.com/andaru/flycheck-yang"
  :commit "47881fc42ef0163c47064b72b5d6dbef4f83d778"
  :revdesc "47881fc42ef0"
  :authors '(("Andrew Fort" . "(@andaru)"))
  :maintainers '(("Andrew Fort" . "(@andaru)")))
