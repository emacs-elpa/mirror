;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pomidor" "0.6.1.0.20240601.9"
  "Simple and cool pomodoro timer."
  '((emacs "24.3")
    (alert "1.2")
    (dash  "2.17.0"))
  :url "https://github.com/TatriX/pomidor"
  :commit "de71c34a1a9aff745181107094d3389816dbeca5"
  :revdesc "v0.6.1-9-gde71c34a1a9a"
  :keywords '("tools" "time" "applications" "pomodoro technique")
  :authors '(("TatriX" . "tatrics@gmail.com"))
  :maintainers '(("TatriX" . "tatrics@gmail.com")))
