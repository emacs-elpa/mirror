;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsonian" "0.1.0.0.20260612.10"
  "A major mode for editing JSON files."
  '((emacs "27.1"))
  :url "https://github.com/iwahbe/jsonian"
  :commit "2709fb0140c92eb183c849fdc530fd59f4e4fd3d"
  :revdesc "2709fb0140c9")
