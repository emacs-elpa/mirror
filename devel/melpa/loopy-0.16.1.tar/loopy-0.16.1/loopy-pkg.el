;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "0.16.1"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://codeberg.org/okamsn/loopy"
  :commit "70427df284cc0a70a75c00be221fbabc433183c5"
  :revdesc "70427df284cc"
  :keywords '("extensions"))
