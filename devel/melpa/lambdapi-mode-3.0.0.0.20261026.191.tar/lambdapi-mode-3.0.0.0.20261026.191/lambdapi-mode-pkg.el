;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambdapi-mode" "3.0.0.0.20261026.191"
  "A major mode for editing Lambdapi source code."
  '((emacs             "27.1")
    (eglot             "1.6")
    (math-symbol-lists "1.2.1")
    (highlight         "20190710.1527"))
  :url "https://github.com/Deducteam/lambdapi"
  :commit "4c84f6fb413a1ac7b368cbe303f6b05dfbea1635"
  :revdesc "3.0.0-191-g4c84f6fb413a"
  :keywords '("languages")
  :maintainers '(("Deducteam" . "dedukti-dev@inria.fr")))
