;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.2.4.0.20260718.74"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "69397d14bf869ae6be2d07d04fbaaeaf4e812b1b"
  :revdesc "69397d14bf86"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
