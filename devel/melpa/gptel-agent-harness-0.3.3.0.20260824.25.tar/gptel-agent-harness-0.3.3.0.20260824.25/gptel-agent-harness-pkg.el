;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent-harness" "0.3.3.0.20260824.25"
  "Autonomous coding-agent harness for gptel-agent."
  '((emacs       "29.1")
    (compat      "30.1.0.0")
    (gptel       "0.9.9")
    (gptel-agent "0.0.1"))
  :url "https://github.com/beacoder/gptel-agent-harness"
  :commit "ed72d11dbb80b1a117f568b69fe6506ceee903d1"
  :revdesc "ed72d11dbb80"
  :keywords '("programming" "convenience" "ai" "agent")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
