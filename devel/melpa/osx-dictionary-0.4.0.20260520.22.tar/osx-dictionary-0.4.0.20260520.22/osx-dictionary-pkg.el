;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-dictionary" "0.4.0.20260520.22"
  "Interface for OSX Dictionary.app."
  '((cl-lib "0.5"))
  :url "https://github.com/xuchunyang/osx-dictionary.el"
  :commit "8e6897844c4d6ff6039b31569058273632afea16"
  :revdesc "8e6897844c4d"
  :keywords '("mac" "dictionary")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
