;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "htmlize" "1.59.0.20250724.1"
  "Convert buffer text and decorations to HTML."
  '((emacs "26.1"))
  :url "https://github.com/emacsorphanage/htmlize"
  :commit "c9a8196a59973fabb3763b28069af9a4822a5260"
  :revdesc "release/1.59-1-gc9a8196a5997"
  :keywords '("hypermedia" "extensions")
  :authors '(("Hrvoje Niksic" . "hniksic@gmail.com"))
  :maintainers '(("Hrvoje Niksic" . "hniksic@gmail.com")))
