;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snitch" "0.3.0.0.20210202.1"
  "An Emacs firewall."
  '((emacs "27.1"))
  :url "https://github.com/mrmekon/snitch-el"
  :commit "3b3e7f1bf612c4624764d1ec4b1a96e4d2850b05"
  :revdesc "snitch-0.3.0-1-g3b3e7f1bf612"
  :keywords '("processes" "comm")
  :authors '(("Trevor Bentley" . "snitch.el@x.mrmekon.com"))
  :maintainers '(("Trevor Bentley" . "snitch.el@x.mrmekon.com")))
