;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "0.1.0.0.20260710.26"
  "Spaced repetition in plain text."
  '((emacs     "30.2")
    (transient "0.12.0"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "71cd5b3c0dd449bbc43599824de20fac7593c53c"
  :revdesc "71cd5b3c0dd4"
  :keywords '("hypermedia" "srs" "memory")
  :authors '(("Duncan Britt" . "duncanbritt.com"))
  :maintainers '(("Duncan Britt" . "duncanbritt.com")))
