;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lxd-tramp" "0.1.0.20181023.3"
  "TRAMP integration for LXD containers."
  '((emacs  "24.4")
    (cl-lib "0.6"))
  :url "https://github.com/onixie/lxd-tramp.git"
  :commit "f335c76245f62b02cf67a9376eca6f3863c8a75a"
  :revdesc "f335c76245f6"
  :keywords '("lxd" "lxc" "convenience")
  :authors '(("Yc.S" . "onixie@gmail.com"))
  :maintainers '(("Yc.S" . "onixie@gmail.com")))
