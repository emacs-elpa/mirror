;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "1.2.5"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "8a195693ccc144f48d7dedf50e136be9a76b437c"
  :revdesc "1.2.5-0-g8a195693ccc1"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
