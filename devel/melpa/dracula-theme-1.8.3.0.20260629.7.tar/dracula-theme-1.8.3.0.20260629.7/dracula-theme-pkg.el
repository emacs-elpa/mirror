;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dracula-theme" "1.8.3.0.20260629.7"
  "Dracula Theme."
  '((emacs "24.3"))
  :url "https://github.com/dracula/emacs"
  :commit "fa562443129993e3408ea300595b230874da33db"
  :revdesc "v1.8.3-7-gfa5624431299"
  :maintainers '(("tienne Deparis" . "etienne@depar.is")))
