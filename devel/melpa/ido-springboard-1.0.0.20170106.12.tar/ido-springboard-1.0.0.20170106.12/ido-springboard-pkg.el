;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-springboard" "1.0.0.20170106.12"
  "Temporarily change default-directory for one command."
  ()
  :url "https://github.com/jwiegley/springboard"
  :commit "263a8cd4582c81bfc29d7db37d5267e2488b148c"
  :revdesc "263a8cd4582c"
  :keywords '("ido")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("John Wiegley" . "jwiegley@gmail.com")))
