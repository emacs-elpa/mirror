;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ppcompile" "0.1.0.20220619.80"
  "Ping-pong compile projects on remote machines."
  '((emacs "25.1"))
  :url "https://github.com/whatacold/ppcompile"
  :commit "4c287c9ebc0e78dbbe75195bb5eb3fe82e0bfaff"
  :revdesc "4c287c9ebc0e"
  :keywords '("tools")
  :authors '(("Guangwang Huang" . "whatacold@gmail.com")))
