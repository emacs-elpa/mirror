;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly-hello-world" "0.1.0.20200225.17"
  "A template SLY contrib."
  '((sly "1.0.0-beta2"))
  :url "https://github.com/capitaomorte/sly-hello-world"
  :commit "be257e9ad354db690c7378e89899335597348a0d"
  :revdesc "be257e9ad354"
  :keywords '("languages" "lisp" "sly")
  :authors '(("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("João Távora" . "joaotavora@gmail.com")))
