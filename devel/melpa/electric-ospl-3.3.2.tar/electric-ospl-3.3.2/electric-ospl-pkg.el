;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-ospl" "3.3.2"
  "Electric OSPL Mode."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~swflint/electric-ospl-mode"
  :commit "88ab5ca588b4cbd1ddd27757d390da19298b05bd"
  :revdesc "88ab5ca588b4"
  :keywords '("convenience" "text")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
