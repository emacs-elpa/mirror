;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.900.0.20260725.15"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e4dead6999898c559c9a88bb45fea713fb688588"
  :revdesc "e4dead699989"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
