;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spatial-window" "0.9.3.0.20260808.54"
  "Jump to windows using keyboard spatial mapping."
  '((emacs    "28.1")
    (posframe "1.0.0"))
  :url "https://github.com/lewang/spatial-window"
  :commit "62cde160ca14a3527902605e6e45b64ead87f2fa"
  :revdesc "62cde160ca14"
  :keywords '("convenience" "windows")
  :authors '(("Le Wang" . "lewang.dev.26@gmail.com"))
  :maintainers '(("Le Wang" . "lewang.dev.26@gmail.com")))
