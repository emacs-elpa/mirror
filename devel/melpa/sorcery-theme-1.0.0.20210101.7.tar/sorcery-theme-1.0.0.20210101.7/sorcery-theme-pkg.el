;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sorcery-theme" "1.0.0.20210101.7"
  "A D&D (Dark and Dusty) Theme."
  '((autothemer "0.2"))
  :url "https://github.com/vxid/emacs-theme-sorcery"
  :commit "5a1c4445b9e6e09589a299a9962a6973272a0c2f"
  :revdesc "5a1c4445b9e6"
  :authors '(("Maxime Tréca" . "maxime@gmail.com"))
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")))
