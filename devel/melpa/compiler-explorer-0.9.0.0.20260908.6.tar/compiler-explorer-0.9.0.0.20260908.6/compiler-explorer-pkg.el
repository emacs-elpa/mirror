;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compiler-explorer" "0.9.0.0.20260908.6"
  "Compiler explorer client (godbolt.org)."
  '((emacs "29.1")
    (plz   "0.9")
    (eldoc "1.15.0")
    (map   "3.3.1")
    (seq   "2.23"))
  :url "https://github.com/mkcms/compiler-explorer.el"
  :commit "7e4195a5ef2604f8f97392e62029e9e79c36d3bf"
  :revdesc "v0.9.0-6-g7e4195a5ef26"
  :keywords '("c" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
