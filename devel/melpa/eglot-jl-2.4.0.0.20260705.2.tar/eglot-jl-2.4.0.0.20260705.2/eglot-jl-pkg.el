;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-jl" "2.4.0.0.20260705.2"
  "Julia support for eglot."
  '((emacs      "25.1")
    (eglot      "1.4")
    (project    "0.8.1")
    (cl-generic "1.0"))
  :url "https://github.com/non-Jedi/eglot-jl"
  :commit "ebe4358b48827a85dd4c714bcc3db11842aa6c3c"
  :revdesc "v2.4.0-2-gebe4358b4882"
  :keywords '("convenience" "languages")
  :authors '(("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz"))
  :maintainers '(("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz")))
