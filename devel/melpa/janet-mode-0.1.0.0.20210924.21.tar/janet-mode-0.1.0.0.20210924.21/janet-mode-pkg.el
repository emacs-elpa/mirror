;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "janet-mode" "0.1.0.0.20210924.21"
  "Defines a major mode for Janet."
  '((emacs "24.3"))
  :url "https://github.com/ALSchwalm/janet-mode"
  :commit "9e3254a0249d720d5fa5603f1f8c3ed0612695af"
  :revdesc "9e3254a0249d"
  :authors '(("Adam Schwalm" . "adamschwalm@gmail.com"))
  :maintainers '(("Adam Schwalm" . "adamschwalm@gmail.com")))
