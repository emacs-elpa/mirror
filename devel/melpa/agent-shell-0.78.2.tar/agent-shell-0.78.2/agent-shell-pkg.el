;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.78.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "164332bcd459a23a6aaf7b4587905cef56aaff05"
  :revdesc "164332bcd459")
