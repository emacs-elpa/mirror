;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2.0.20260930.55"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "650829f40839117dee8b8fb83aeeacd24aba00a1"
  :revdesc "650829f40839"
  :keywords '("faces" "files" "q"))
