;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertica-snippets" "0.1.0.0.20250314.49"
  "Yasnippets for Vertica."
  '((yasnippet "0.6.1"))
  :url "https://github.com/baron42bba/vertica-snippets"
  :commit "5a77be72074c196cc419852d58c14703ff5ba55a"
  :revdesc "5a77be72074c"
  :keywords '("convenience" "snippets")
  :authors '(("Andreas Gerler" . "baron@bundesbrandschatzamt.de"))
  :maintainers '(("Andreas Gerler" . "baron@bundesbrandschatzamt.de")))
