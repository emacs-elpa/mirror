;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uimage" "0.0.0.20160901.28"
  "An iimage like mode with the ability to display url images."
  ()
  :url "https://github.com/lujun9972/uimage"
  :commit "9893d09160ef7e8c0ecdcd74fca99ffeb5f9d70d"
  :revdesc "9893d09160ef"
  :keywords '("lisp" "url" "image")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
