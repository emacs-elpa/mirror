;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitolite-clone" "0.1.0.0.20160609.15"
  "Clone gitolite repositories from a completing list."
  '((dash   "2.10.0")
    (s      "1.9.0")
    (pcache "0.3.1")
    (emacs  "24"))
  :url "https://github.com/IvanMalison/gitolite-clone"
  :commit "d8a4c2875c984e51137c980b5773f42703602721"
  :revdesc "d8a4c2875c98"
  :keywords '("gitolite" "clone" "git")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
