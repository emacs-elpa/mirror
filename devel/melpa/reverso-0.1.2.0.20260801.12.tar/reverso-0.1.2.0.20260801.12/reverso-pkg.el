;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reverso" "0.1.2.0.20260801.12"
  "Translation, grammar checking, context search."
  '((emacs     "27.1")
    (transient "0.3.7")
    (request   "0.3.2"))
  :url "https://github.com/SqrtMinusOne/reverso.el"
  :commit "a21f17162b5a391ae1220c6b1133af76ed3573a8"
  :revdesc "a21f17162b5a"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
