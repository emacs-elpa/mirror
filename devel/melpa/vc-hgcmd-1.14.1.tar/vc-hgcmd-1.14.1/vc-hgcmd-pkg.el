;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-hgcmd" "1.14.1"
  "VC mercurial backend that uses hg command server."
  '((emacs "25.1"))
  :url "https://github.com/muffinmad/emacs-vc-hgcmd"
  :commit "d044448965d31ca8214f8bca48487e4d9b9d9a0f"
  :revdesc "d044448965d3"
  :keywords '("vc")
  :authors '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com"))
  :maintainers '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com")))
