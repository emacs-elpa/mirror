;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smithers" "0.4.0.20210531.3"
  "A startup message featuring Mr C.M. Burns."
  '((emacs "26.1")
    (dash  "2.17.0")
    (org   "9.4.5"))
  :url "https://gitlab.com/mtekman/smithers.el"
  :commit "db9ed12a8d2c131b6d37b4e7aff01b8e3cec81a6"
  :revdesc "db9ed12a8d2c"
  :keywords '("games"))
