;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "38.3.0.20260803.54"
  "On-the-fly syntax checking."
  '((emacs "28.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "10d2c4ab71b6da103aa4fda70a67e72401b5a82c"
  :revdesc "10d2c4ab71b6"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
