;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cheerilee" "0.4.0.20160313.7"
  "Toolkit library."
  '((xelb "0.1"))
  :url "https://github.com/Vannil/cheerilee.el"
  :commit "41bd81b5b0bb657241ceda5be6af5e07254d7376"
  :revdesc "41bd81b5b0bb"
  :keywords '("multimedia" "tools")
  :authors '(("Alessio Vanni" . "vannilla@firemail.cc"))
  :maintainers '(("Alessio Vanni" . "vannilla@firemail.cc")))
