;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alectryon" "2.0.0.0.20260525.44"
  "Toggle between Code and markup."
  '((flycheck "31")
    (emacs    "25.1"))
  :url "https://github.com/cpitclaudel/alectryon"
  :commit "bf99e72c54579460769984ba668e46c235ad18d8"
  :revdesc "v2.0.0-44-gbf99e72c5457"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
