;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "double-press" "3.0.1.0.20250916.13"
  "Double-press key dispatcher."
  '((emacs "24.4"))
  :url "https://github.com/k-talo/double-press.el"
  :commit "380f7f1cab9045c9ef56b4b40c241037dc2c58d0"
  :revdesc "v3.0.1-13-g380f7f1cab90"
  :keywords '("abbrev" "convenience" "emulations" "wp")
  :authors '(("K-talo Miyazaki" . "Keitaro.Miyazaki@gmail.com"))
  :maintainers '(("K-talo Miyazaki" . "Keitaro.Miyazaki@gmail.com")))
