;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-go" "0.1.0.20190201.51"
  "Org-babel functions for go evaluation."
  ()
  :url "http://orgmode.org"
  :commit "2067ed55f4c1d33a43cb3f6948609d240a8915f5"
  :revdesc "2067ed55f4c1"
  :keywords '("golang" "go" "literate programming" "reproducible research"))
