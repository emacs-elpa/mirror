;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.13.1"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.67.1")
    (latex-to-svg-backend "0.14.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "c5507cd4570ec6237e2573bf01b6383e23f1109f"
  :revdesc "v0.13.1-0-gc5507cd4570e"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
