;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "json-par" "6.0.0.0.20261025.42"
  "Minor mode for structural editing of JSON."
  '((emacs "24.4"))
  :url "https://github.com/taku0/json-par"
  :commit "d3b491d9d50894f63a6110808dfe413d5e6a5c9e"
  :revdesc "d3b491d9d508"
  :keywords '("abbrev" "convenience" "files")
  :authors '(("taku0" . "mxxouy6x3m_github@tatapa.org"))
  :maintainers '(("taku0" . "mxxouy6x3m_github@tatapa.org")))
