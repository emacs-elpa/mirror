;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "2.13.0.20260525.4"
  "An Org-social client."
  '((emacs            "30.1")
    (org              "9.0")
    (request          "0.3.0")
    (seq              "2.20")
    (emojify          "1.2")
    (async-http-queue "0.1"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "754f16c45585fb733fd521558b572f03bc964708"
  :revdesc "754f16c45585"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
