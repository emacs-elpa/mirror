;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "0.9.9.0.20261110.6"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "5456068919ab7b0bfe7abc774a4ace1cbca8c1f4"
  :revdesc "5456068919ab"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
