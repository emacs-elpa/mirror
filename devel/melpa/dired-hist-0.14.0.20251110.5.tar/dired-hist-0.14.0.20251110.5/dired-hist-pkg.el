;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-hist" "0.14.0.20251110.5"
  "Traverse Dired buffer's history: back, forward."
  '((emacs "27.1"))
  :url "https://codeberg.org/Anoncheg/dired-hist"
  :commit "8cca7292086b849ef170d17bc6beafbc2d3228b6"
  :revdesc "8cca7292086b"
  :keywords '("convenience" "dired" "history")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
