;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-browse-url-in-article" "1.0.0.0.20260806.17"
  "Smarter browse-url for Gnus articles."
  '((emacs "27.1"))
  :url "https://github.com/jmibanez/gnus-browse-url-in-article"
  :commit "38c2360f88972bc3767008051325fe17cdc276f5"
  :revdesc "38c2360f8897"
  :keywords '("convenience" "mail" "gnus")
  :authors '(("JM Ibañez" . "jm@jmibanez.com"))
  :maintainers '(("JM Ibañez" . "jm@jmibanez.com")))
