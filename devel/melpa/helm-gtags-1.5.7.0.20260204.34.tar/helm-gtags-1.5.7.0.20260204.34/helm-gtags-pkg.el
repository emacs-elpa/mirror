;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-gtags" "1.5.7.0.20260204.34"
  "GNU GLOBAL helm interface."
  '((emacs "27.1")
    (helm  "3.0"))
  :url "https://github.com/syohex/emacs-helm-gtags"
  :commit "bfafd3d4a7f028d42f3f46c3273eaed930269ec6"
  :revdesc "bfafd3d4a7f0"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
