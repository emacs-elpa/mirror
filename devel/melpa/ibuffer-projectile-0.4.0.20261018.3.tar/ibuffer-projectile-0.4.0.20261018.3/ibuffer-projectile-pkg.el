;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-projectile" "0.4.0.20261018.3"
  "Group ibuffer's list by projectile root."
  '((projectile "0.11.0")
    (emacs      "25.1")
    (seq        "2"))
  :url "https://github.com/purcell/ibuffer-projectile"
  :commit "995873856cc4449b55b9bdae639bfddb0977454f"
  :revdesc "995873856cc4"
  :keywords '("convenience")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
