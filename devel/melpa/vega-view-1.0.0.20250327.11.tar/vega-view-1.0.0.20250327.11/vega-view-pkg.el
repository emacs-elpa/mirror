;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vega-view" "1.0.0.20250327.11"
  "Vega visualization viewer."
  '((emacs    "25")
    (cider    "0.24.0")
    (parseedn "0.1"))
  :url "https://www.github.com/applied-science/emacs-vega-view"
  :commit "36e7cc84b25e67b50c5ca677d5ca0f7b7c27469f"
  :revdesc "36e7cc84b25e"
  :keywords '("multimedia")
  :authors '(("Jack Rusher" . "jack@appliedscience.studio"))
  :maintainers '(("Jack Rusher" . "jack@appliedscience.studio")))
