;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jal" "2.0.0.0.20260721.7"
  "Java Agent Loader (JAL) for JDTLS."
  '((emacs "28.1"))
  :url "https://github.com/saulotoledo/java-agent-loader"
  :commit "e2dac4a10a50361f1e9641ff614f4906823e4331"
  :revdesc "e2dac4a10a50"
  :keywords '("java" "languages" "tools")
  :authors '(("Saulo Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo Toledo" . "saulotoledo@gmail.com")))
