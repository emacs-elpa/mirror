;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "skewer-mode" "1.9.0"
  "Live browser JavaScript, CSS, and HTML interaction."
  '((emacs        "24")
    (js2-mode     "20090723")
    (simple-httpd "1.4.0"))
  :url "https://github.com/skeeto/skewer-mode"
  :commit "d075c3013074f8c2efa4111e10fdec6bdee57496"
  :revdesc "1.9.0-0-gd075c3013074"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
