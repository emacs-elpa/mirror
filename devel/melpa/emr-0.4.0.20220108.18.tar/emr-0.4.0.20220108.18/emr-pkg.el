;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emr" "0.4.0.20220108.18"
  "Emacs refactoring system."
  '((s            "1.3.1")
    (dash         "1.2.0")
    (cl-lib       "0.2")
    (popup        "0.5.0")
    (emacs        "24.1")
    (list-utils   "0.3.0")
    (paredit      "24.0.0")
    (projectile   "0.9.1")
    (clang-format "0.0.1")
    (iedit        "0.97"))
  :url "https://github.com/Wilfred/emacs-refactor"
  :commit "cac1b52932926f56d7f6d2923732d20bbd20670d"
  :revdesc "cac1b5293292"
  :keywords '("tools" "convenience" "refactoring")
  :authors '(("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainers '(("Chris Barrett" . "chris.d.barrett@me.com")))
