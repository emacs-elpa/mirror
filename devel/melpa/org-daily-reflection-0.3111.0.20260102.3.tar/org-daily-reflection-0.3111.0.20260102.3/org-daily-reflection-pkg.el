;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-daily-reflection" "0.3111.0.20260102.3"
  "Concurrent display of org(-roam) dailies."
  '((emacs  "26.1")
    (org    "9.4")
    (compat "30.0.0.0"))
  :url "https://github.com/emacsomancer/org-daily-reflection"
  :commit "4f7a2a3b068de2ecee23634a340334fc873421b1"
  :revdesc "4f7a2a3b068d"
  :keywords '("convenience" "frames" "terminals" "tools" "window-system")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
