;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youtube-music" "0.1.0.0.20260623.17"
  "YouTube Music client."
  '((emacs "29.1"))
  :url "https://github.com/cyberkm/emacs-youtube-music"
  :commit "fcee7802eb8196f575450e3bf1c4f1ab4d5cdea4"
  :revdesc "fcee7802eb81"
  :keywords '("multimedia" "youtube" "music")
  :authors '(("Pavel Bibergal" . "pavel@keewano.com"))
  :maintainers '(("Pavel Bibergal" . "pavel@keewano.com")))
