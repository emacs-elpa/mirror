;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline-now-playing" "1.0.1.0.20260501.13"
  "Segment for Doom Modeline to show media player information."
  '((emacs         "26.1")
    (doom-modeline "3.0.0"))
  :url "https://github.com/elken/doom-modeline-now-playing"
  :commit "11e060f9e30c2ae3e95e71a18f3d0d91b7a54d97"
  :revdesc "11e060f9e30c"
  :authors '(("Ellis Kenyő" . "me@elken.dev"))
  :maintainers '(("Ellis Kenyő" . "me@elken.dev")))
