;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-sheet" "0.0.0.20130630.2"
  "Helm sources for sheet."
  '((helm "1.0"))
  :url "https://github.com/yasuyk/helm-sheet"
  :commit "d360b68d0ddb09aa1854e7b2f3cb39caeee26463"
  :revdesc "d360b68d0ddb"
  :keywords '("helm" "sheet")
  :authors '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
