;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "omni-scratch" "0.6.0"
  "Easy and mode-specific draft buffers."
  ()
  :url "https://github.com/AdrieanKhisbe/omni-scratch.el"
  :commit "636374c59c7d33c2f72c97ad8ba9fb4854f2324d"
  :revdesc "636374c59c7d"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Adrien Becchis" . "adriean.khisbe@live.fr"))
  :maintainers '(("Adrien Becchis" . "adriean.khisbe@live.fr")))
