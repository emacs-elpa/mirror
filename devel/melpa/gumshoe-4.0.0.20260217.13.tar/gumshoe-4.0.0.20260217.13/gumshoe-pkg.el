;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gumshoe" "4.0.0.20260217.13"
  "Scoped spatial and temporal POINT movement tracking."
  '((emacs "27.1"))
  :url "https://github.com/Overdr0ne/gumshoe"
  :commit "da71e889b5e890fecbacaeba0a4977c4657b4351"
  :revdesc "da71e889b5e8"
  :keywords '("tools"))
