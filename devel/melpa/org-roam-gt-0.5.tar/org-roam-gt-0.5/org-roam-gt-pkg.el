;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-gt" "0.5"
  "Improvements for org-roam."
  '((emacs    "30.1")
    (org      "9.8")
    (org-roam "2.2.2"))
  :url "https://github.com/dmgerman/org-roam-gt"
  :commit "f9dba85a6738db46613cb6e3f62332b0bebb8d7b"
  :revdesc "v0.5-0-gf9dba85a6738"
  :keywords '("outlines" "hypermedia")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
