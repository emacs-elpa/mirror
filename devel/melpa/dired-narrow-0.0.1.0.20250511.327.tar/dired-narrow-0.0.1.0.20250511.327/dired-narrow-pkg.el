;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-narrow" "0.0.1.0.20250511.327"
  "Live-narrowing of search results for dired."
  '((dash              "2.7.0")
    (dired-hacks-utils "0.0.1")
    (emacs             "24"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "bb5d1c3c8b0bb6025335dabb4b3639d60acc6a12"
  :revdesc "bb5d1c3c8b0b"
  :keywords '("files")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
