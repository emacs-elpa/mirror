;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "contextual" "1.0.1.0.20180726.2"
  "Contextual profile management system."
  '((emacs  "24")
    (dash   "2.12.1")
    (cl-lib "0.5"))
  :url "https://github.com/lshift-de/contextual"
  :commit "7ad2bb36426fd182d4d5ee7fd9be1cc0db8c7a84"
  :revdesc "1.0.1-2-g7ad2bb36426f"
  :keywords '("convenience" "tools")
  :authors '(("Alexander Kahl" . "ak@sodosopa.io"))
  :maintainers '(("Alexander Kahl" . "ak@sodosopa.io")))
