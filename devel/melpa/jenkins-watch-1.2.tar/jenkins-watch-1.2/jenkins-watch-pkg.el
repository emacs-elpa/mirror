;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jenkins-watch" "1.2"
  "Watch continuous integration build status."
  ()
  :url "https://github.com/ataylor284/jenkins-watch"
  :commit "37b84dfbd98240a57ff798e1ff8bc7dba2913577"
  :revdesc "37b84dfbd982"
  :authors '(("Andrew Taylor" . "ataylor@redtoad.ca"))
  :maintainers '(("Andrew Taylor" . "ataylor@redtoad.ca")))
