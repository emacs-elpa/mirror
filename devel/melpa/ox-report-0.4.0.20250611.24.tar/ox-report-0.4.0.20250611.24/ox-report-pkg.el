;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-report" "0.4.0.20250611.24"
  "Export your org file to minutes report PDF file."
  '((emacs   "24.4")
    (org-msg "3.9"))
  :url "https://github.com/DarkBuffalo/ox-report"
  :commit "81973dafc10fd06d46b8f7abaab9ac90ff5ccca2"
  :revdesc "81973dafc10f"
  :keywords '("org" "outlines" "report" "exporter" "meeting" "minutes")
  :authors '(("Matthias David" . "db@gnu.re"))
  :maintainers '(("Matthias David" . "db@gnu.re")))
