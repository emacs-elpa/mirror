;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-chat" "0.10.0.0.20260905.2"
  "Emacs client for Lisp Chat."
  '((emacs     "27.1")
    (websocket "1.12"))
  :url "https://github.com/ryukinix/lisp-chat"
  :commit "316cdd52134eca84e2782f6d7f7fa57549ebe92b"
  :revdesc "316cdd52134e"
  :keywords '("comm" "chat" "lisp")
  :authors '(("Manoel V. Machado" . "(manoel_vilela@engineer.com)"))
  :maintainers '(("Manoel V. Machado" . "(manoel_vilela@engineer.com)")))
