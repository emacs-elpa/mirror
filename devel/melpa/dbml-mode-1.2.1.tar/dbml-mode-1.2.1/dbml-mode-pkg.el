;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dbml-mode" "1.2.1"
  "Major mode for DBML."
  '((emacs "27.1"))
  :url "https://github.com/KeyWeeUsr/dbml-mode"
  :commit "fd2e4ec1356a63b05a15103631bd007bd089867c"
  :revdesc "1.2.1-0-gfd2e4ec1356a"
  :keywords '("convenience" "dbml" "language" "markup" "highlight" "dbdiagram" "diagram")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
