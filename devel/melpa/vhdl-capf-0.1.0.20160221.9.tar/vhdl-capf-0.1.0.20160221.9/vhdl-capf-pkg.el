;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-capf" "0.1.0.20160221.9"
  "Completion at point function (capf) for vhdl-mode."
  ()
  :url "https://github.com/sh-ow/vhdl-capf"
  :commit "290abe217050f33532bc9ccb04f894123402f414"
  :revdesc "290abe217050"
  :keywords '("convenience" "usability" "vhdl" "completion")
  :authors '(("sh-ow" . "sh-ow@users.noreply.github.com"))
  :maintainers '(("sh-ow" . "sh-ow@users.noreply.github.com")))
