;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ponylang-mode" "0.6.0.0.20250819.67"
  "A major mode for the Pony programming language."
  '((emacs "28.1"))
  :url "https://github.com/ponylang/ponylang-mode"
  :commit "7e6425f2c12538bfeffce754b32ba75a14c72cbd"
  :revdesc "7e6425f2c125"
  :keywords '("languages" "programming")
  :authors '(("Sean T Allen" . "sean@monkeysnatchbanana.com"))
  :maintainers '(("Sean T Allen" . "sean@monkeysnatchbanana.com")))
