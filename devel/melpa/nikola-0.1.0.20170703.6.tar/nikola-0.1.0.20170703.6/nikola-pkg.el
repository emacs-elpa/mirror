;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nikola" "0.1.0.20170703.6"
  "Simple wrapper for nikola."
  '((async "1.5")
    (emacs "24.3"))
  :url ": https://git.daemons.it/drymer/nikola.el"
  :commit "964715ac30943c9d6976999cad208dc60d09def0"
  :revdesc "964715ac3094"
  :keywords '(":" "nikola")
  :authors '(("drymer" . "drymer[AT]autistici.org"))
  :maintainers '(("drymer" . "drymer[AT]autistici.org")))
