;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-help" "0.0.0.20230118.12"
  "Display keybindings for repeat-mode."
  '((emacs "28.1"))
  :url "https://github.com/karthink/repeat-help"
  :commit "41dea6fba2edd6ac748d0ca7a6da4058290feede"
  :revdesc "41dea6fba2ed"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com")))
