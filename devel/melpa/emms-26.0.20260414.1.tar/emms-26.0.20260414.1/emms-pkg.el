;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms" "26.0.20260414.1"
  "The Emacs Multimedia System."
  '((cl-lib  "0.5")
    (nadvice "0.3")
    (seq     "0"))
  :url "https://www.gnu.org/software/emms/"
  :commit "6f704fd3c12f35e059700aaeb43ae64c35ad81b2"
  :revdesc "26-1-g6f704fd3c12f"
  :keywords '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :authors '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers '(("Yoni Rabkin" . "yrk@gnu.org")))
