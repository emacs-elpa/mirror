;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-smart-sluggify-title" "1.1.2"
  "Denoise denote titles to save filename length."
  '((emacs  "25.1")
    (denote "4.0.0"))
  :url "https://git.sr.ht/~swflint/denote-smart-sluggify-title"
  :commit "87c60e5e03c2e00855db81589ff1340bd6c5bcb5"
  :revdesc "87c60e5e03c2"
  :keywords '("convenience" "denote")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
