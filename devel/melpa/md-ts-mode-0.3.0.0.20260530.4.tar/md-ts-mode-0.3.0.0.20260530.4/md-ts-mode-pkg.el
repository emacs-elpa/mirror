;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "md-ts-mode" "0.3.0.0.20260530.4"
  "Major mode for Markdown using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/dnouri/md-ts-mode"
  :commit "95ae25162da092cb1d55d2be0c2c95e0591086c2"
  :revdesc "v0.3.0-4-g95ae25162da0"
  :keywords '("markdown" "languages" "tree-sitter")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
