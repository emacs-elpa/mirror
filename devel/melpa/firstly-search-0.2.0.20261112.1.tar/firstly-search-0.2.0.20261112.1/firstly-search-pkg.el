;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "0.2.0.20261112.1"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "32d2386ea7961c5a8c2b177d20248945911223dc"
  :revdesc "32d2386ea796"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
