;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-embark-collect" "1.2"
  "Use avy to jump to Embark Collect entries."
  '((emacs  "29.1")
    (embark "1.1")
    (avy    "0.5"))
  :url "https://github.com/oantolin/embark"
  :commit "27de48004242e98586b9c9661fdb6912f26fe70f"
  :revdesc "27de48004242"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
