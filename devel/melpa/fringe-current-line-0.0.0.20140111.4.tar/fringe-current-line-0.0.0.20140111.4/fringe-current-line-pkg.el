;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fringe-current-line" "0.0.0.20140111.4"
  "Show current line on the fringe."
  ()
  :url "https://github.com/kyanagi/fringe-current-line/raw/master/fringe-current-line.el"
  :commit "0ef000bac76abae30601222e6f06c7d133ab4942"
  :revdesc "0ef000bac76a"
  :authors '(("Kouhei Yanagita" . "yanagi@shakenbu.org"))
  :maintainers '(("Kouhei Yanagita" . "yanagi@shakenbu.org")))
