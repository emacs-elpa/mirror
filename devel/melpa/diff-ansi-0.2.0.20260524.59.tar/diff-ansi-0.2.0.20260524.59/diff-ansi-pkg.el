;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-ansi" "0.2.0.20260524.59"
  "Display diffs using alternative diffing tools."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi"
  :commit "2edacc2c6bda60b1be7bf5dfdde006a9a7018af5"
  :revdesc "2edacc2c6bda"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
