;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-status-emoji" "1.3"
  "Show flycheck status using cute, compact emoji."
  '((cl-lib    "0.1")
    (emacs     "24")
    (flycheck  "0.20")
    (let-alist "1.0"))
  :url "https://github.com/liblit/flycheck-status-emoji"
  :commit "4bd113ab42dec9544b66e0a27ed9008ce8148433"
  :revdesc "4bd113ab42de"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Ben Liblit" . "liblit@acm.org"))
  :maintainers '(("Ben Liblit" . "liblit@acm.org")))
