;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sparkweather" "0.1.2.0.20260317.11"
  "Weather forecasts with sparklines."
  '((emacs "29.1"))
  :url "https://github.com/aglet/sparkweather"
  :commit "4197bbbc21e4693b0e258b5a46429285f3419550"
  :revdesc "4197bbbc21e4"
  :keywords '("convenience" "weather")
  :authors '(("Robin Stephenson" . "robin@aglet.net"))
  :maintainers '(("Robin Stephenson" . "robin@aglet.net")))
