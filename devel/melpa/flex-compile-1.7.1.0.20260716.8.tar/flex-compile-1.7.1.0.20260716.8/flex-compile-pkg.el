;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-compile" "1.7.1.0.20260716.8"
  "Run, evaluate and compile across many languages."
  '((emacs         "26.1")
    (dash          "2.17.0")
    (buffer-manage "1.2.1"))
  :url "https://github.com/plandes/flex-compile"
  :commit "0bd757312b0118ed55d3f4eefe4adca983f588ec"
  :revdesc "v1.7.1-8-g0bd757312b01"
  :keywords '("compilation" "integration" "processes"))
