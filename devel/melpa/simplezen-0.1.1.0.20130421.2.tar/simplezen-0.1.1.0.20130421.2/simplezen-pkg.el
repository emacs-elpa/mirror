;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simplezen" "0.1.1.0.20130421.2"
  "A simple subset of zencoding-mode for Emacs."
  '((s    "1.4.0")
    (dash "1.1.0"))
  :url "https://github.com/magnars/simplezen.el"
  :commit "9f91554a3f7f4e9b2b5ec009effafbf12b091973"
  :revdesc "0.1.1-2-g9f91554a3f7f"
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
