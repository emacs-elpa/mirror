;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lux-mode" "1.0.0.20240108.75"
  "Major mode for editing lux files."
  '((emacs "24.3"))
  :url "https://github.com/hawk/lux"
  :commit "322f50143d164cd1375c9f5b432cd19095aedbad"
  :revdesc "322f50143d16")
