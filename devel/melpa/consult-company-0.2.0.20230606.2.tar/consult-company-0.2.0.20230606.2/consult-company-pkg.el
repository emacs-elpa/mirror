;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-company" "0.2.0.20230606.2"
  "Consult frontend for company."
  '((emacs   "27.1")
    (company "0.9")
    (consult "0.9"))
  :url "https://github.com/mohkale/consult-company"
  :commit "6e309fa9115c9ecd29aa27bff4e3b733979e5dbc"
  :revdesc "6e309fa9115c"
  :authors '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("mohsin kaleem" . "mohkale@kisara.moe")))
