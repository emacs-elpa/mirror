;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-shortcut" "0.0.1.0.20250223.9"
  "Bindings for shortcut.com in org-mode."
  '((plz   "0.9.1")
    (emacs "28.1"))
  :url "https://github.com/endi1/org-shortcut"
  :commit "5344d2011e749b59cb54ed405e7c2d4adcaa6539"
  :revdesc "5344d2011e74"
  :keywords '("comm")
  :authors '(("Endi Sukaj" . "endisukaj@gmail.com"))
  :maintainers '(("Endi Sukaj" . "endisukaj@gmail.com")))
