;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weak-ref" "2.0.0.20200217.5"
  "Weak references for Emacs Lisp."
  '((emacs "24.3"))
  :url "https://github.com/skeeto/elisp-weak-ref"
  :commit "24e8c37da6465e65ce9f866267bd3fa53c8899c6"
  :revdesc "2.0-5-g24e8c37da646"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
