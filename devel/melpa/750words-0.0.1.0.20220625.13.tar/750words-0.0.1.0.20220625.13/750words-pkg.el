;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "750words" "0.0.1.0.20220625.13"
  "Emacs integration and Org exporter for 750words.com."
  '((emacs "24.4"))
  :url "https://github.com/zzamboni/750words-client"
  :commit "43eee19428fc8f5a133192398510d7313eb33d97"
  :revdesc "43eee19428fc"
  :keywords '("files" "org" "writing")
  :authors '(("Diego Zamboni" . "https://github.com/zzamboni"))
  :maintainers '(("Diego Zamboni" . "diego@zzamboni.org")))
