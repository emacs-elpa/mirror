;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zetteldesk-kb" "1.2.0.0.20250405.2"
  "Keybindings for zetteldesk.el."
  '((zetteldesk       "1.0.1")
    (hydra            "0.15")
    (major-mode-hydra "0.2")
    (emacs            "24.1"))
  :url "https://github.com/Vidianos-Giannitsis/zetteldesk-kb.el"
  :commit "0196835c5d6df65d46a4f642b716e6901ad0f4c1"
  :revdesc "0196835c5d6d"
  :authors '(("Vidianos Giannitsis" . "vidianosgiannitsis@gmail.com"))
  :maintainers '(("Vidianos Giannitsis" . "vidianosgiannitsis@gmail.com")))
