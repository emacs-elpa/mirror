;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pacmacs" "0.0.1.0.20220106.390"
  "Pacman for Emacs."
  '((emacs  "24.4")
    (dash   "2.18.0")
    (cl-lib "0.5")
    (f      "0.18.0"))
  :url "https://github.com/codingteam/pacmacs.el"
  :commit "25a8c30210f6bd94634a7ff743a2f8be391ed3b3"
  :revdesc "25a8c30210f6"
  :authors '(("Codingteam" . "codingteam@conference.jabber.ru"))
  :maintainers '(("Alexey Kutepov" . "reximkut@gmail.com")))
