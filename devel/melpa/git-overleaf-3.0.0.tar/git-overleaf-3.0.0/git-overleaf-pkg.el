;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-overleaf" "3.0.0"
  "Clone, push, and pull full Overleaf projects with Git."
  '((emacs         "29.4")
    (websocket     "1.15")
    (webdriver     "0.1")
    (magit-section "4.5")
    (transient     "0.7.2"))
  :url "https://github.com/Jamie-Cui/git-overleaf"
  :commit "df667e84262041a574f94e8917df3ee439efa8c5"
  :revdesc "df667e842620"
  :keywords '("hypermedia" "tex" "tools")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
