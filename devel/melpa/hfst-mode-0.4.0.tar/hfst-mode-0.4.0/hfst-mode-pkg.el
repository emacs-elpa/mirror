;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hfst-mode" "0.4.0"
  "Major mode for editing HFST files."
  ()
  :url "http://wiki.apertium.org/wiki/Emacs"
  :commit "ac1bb9dd92545d3e7fdc05c83996c227cc15c6b8"
  :revdesc "0.4.0-0-gac1bb9dd9254"
  :keywords '("languages")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
