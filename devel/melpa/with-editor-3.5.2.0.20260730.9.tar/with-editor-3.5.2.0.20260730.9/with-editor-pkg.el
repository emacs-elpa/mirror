;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-editor" "3.5.2.0.20260730.9"
  "Use the Emacsclient as $EDITOR."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0"))
  :url "https://github.com/magit/with-editor"
  :commit "2671aa47e610cbb2763858507d881bdb90b1065a"
  :revdesc "v3.5.2-9-g2671aa47e610"
  :keywords '("processes" "terminals")
  :authors '(("Jonas Bernoulli" . "emacs.with-editor@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.with-editor@jonas.bernoulli.dev")))
