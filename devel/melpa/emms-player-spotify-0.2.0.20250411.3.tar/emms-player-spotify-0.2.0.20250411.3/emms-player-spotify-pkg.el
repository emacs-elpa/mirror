;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms-player-spotify" "0.2.0.20250411.3"
  "Spotify player for EMMS."
  '((emacs  "26.1")
    (compat "29.1")
    (emms   "18")
    (s      "1.13.0"))
  :url "https://github.com/sarg/emms-spotify"
  :commit "ca80431b00738e6130b924c64dc1f2cddadcc0b8"
  :revdesc "ca80431b0073"
  :authors '(("Sergey Trofimov" . "sarg@sarg.org.ru"))
  :maintainers '(("Sergey Trofimov" . "sarg@sarg.org.ru")))
