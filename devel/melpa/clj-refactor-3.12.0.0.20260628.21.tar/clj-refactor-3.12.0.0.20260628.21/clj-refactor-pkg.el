;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clj-refactor" "3.12.0.0.20260628.21"
  "A collection of commands for refactoring Clojure code."
  '((emacs            "28.1")
    (yasnippet        "0.6.1")
    (paredit          "24")
    (multiple-cursors "1.2.2")
    (clojure-mode     "5.18.0")
    (cider            "1.11.1")
    (parseedn         "1.2.0")
    (inflections      "2.6")
    (hydra            "0.13.2"))
  :url "https://github.com/clojure-emacs/clj-refactor.el"
  :commit "ac0af32d1cbd0548442ee9859f1882286f4393db"
  :revdesc "v3.12.0-21-gac0af32d1cbd"
  :keywords '("convenience" "clojure" "cider")
  :authors '(("Magnar Sveen" . "magnars@gmail.com")
             ("Lars Andersen" . "expez@expez.com")
             ("Benedek Fazekas" . "benedek.fazekas@gmail.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")
                 ("Lars Andersen" . "expez@expez.com")
                 ("Benedek Fazekas" . "benedek.fazekas@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
