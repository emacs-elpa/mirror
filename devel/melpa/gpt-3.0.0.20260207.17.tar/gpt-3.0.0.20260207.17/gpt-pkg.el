;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpt" "3.0.0.20260207.17"
  "Run instruction-following language models."
  '((emacs "28.1"))
  :url "https://github.com/stuhlmueller/gpt.el"
  :commit "9d4752674e6cbf57aee0bc013d99b4c8652e9f60"
  :revdesc "9d4752674e6c"
  :keywords '("openai" "anthropic" "claude" "language" "copilot" "convenience" "tools")
  :authors '(("Andreas Stuhlmueller" . "emacs@stuhlmueller.org"))
  :maintainers '(("Andreas Stuhlmueller" . "emacs@stuhlmueller.org")))
