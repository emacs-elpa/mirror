;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ml" "6.0.2.0.20250514.1"
  "Functional Org Mode API."
  '((emacs "27.1")
    (org   "9.7")
    (dash  "2.17")
    (s     "1.12"))
  :url "https://github.com/ndwarshuis/org-ml"
  :commit "e348f446746bd1699eae05a82dccd4276c6cc9a8"
  :revdesc "e348f446746b"
  :keywords '("org-mode" "outlines")
  :authors '(("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainers '(("Nathan Dwarshuis" . "ndwar@yavin4.ch")))
