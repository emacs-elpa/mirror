;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mallard-mode" "0.3.0.0.20131204.1"
  "Major mode for editing Mallard files."
  ()
  :url "https://github.com/jhradilek/emacs-mallard-mode"
  :commit "0a4cfede57bc31134495804ce513cc106de8de3c"
  :revdesc "v0.3.0-1-g0a4cfede57bc"
  :keywords '("xml" "mallard")
  :authors '(("Jaromir Hradilek" . "jhradilek@gmail.com"))
  :maintainers '(("Jaromir Hradilek" . "jhradilek@gmail.com")))
