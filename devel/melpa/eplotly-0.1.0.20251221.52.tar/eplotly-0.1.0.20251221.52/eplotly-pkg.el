;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eplotly" "0.1.0.20251221.52"
  "Create Plotly charts."
  '((emacs "26.1")
    (jack  "1.0")
    (f     "0.21.0"))
  :url "https://codeberg.org/GioBo/eplotly"
  :commit "7f36d03d7d3226da05c4e60a692f9a1055d92212"
  :revdesc "7f36d03d7d32"
  :keywords '("tools")
  :maintainers '(("GioBo" . "boccigionata@gmail.com")))
