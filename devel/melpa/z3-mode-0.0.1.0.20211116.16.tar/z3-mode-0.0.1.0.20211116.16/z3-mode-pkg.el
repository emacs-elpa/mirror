;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "z3-mode" "0.0.1.0.20211116.16"
  "A z3/SMTLIBv2 interactive development environment."
  '((flycheck "0.23")
    (emacs    "24"))
  :url "https://github.com/zv/z3-mode"
  :commit "0356cbe1e1e2b780ba0ddb4aaa055fa246a67931"
  :revdesc "0356cbe1e1e2"
  :keywords '("z3" "yices" "mathsat" "smt" "beaver")
  :authors '(("Zephyr Pellerin" . "zephyr.pellerin@gmail.com"))
  :maintainers '(("Zephyr Pellerin" . "zephyr.pellerin@gmail.com")))
