;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uuid" "0.0.3"
  "UUID's for EmacsLisp."
  ()
  :url "https://github.com/nicferrier/emacs-uuid"
  :commit "1519bfeb0e31602b840bc8dd35d7c7e732c159fe"
  :revdesc "1519bfeb0e31"
  :keywords '("lisp")
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
