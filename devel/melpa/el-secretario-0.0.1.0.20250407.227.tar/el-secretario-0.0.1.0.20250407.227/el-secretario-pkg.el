;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-secretario" "0.0.1.0.20250407.227"
  "Unify all your inboxes with the Emacs secretary."
  '((emacs    "27.1")
    (org-ql   "0.6-pre")
    (hercules "0.3"))
  :url "https://git.sr.ht/~zetagon/el-secretario"
  :commit "cb62184ee740df345665ba091267ca41f5895b04"
  :revdesc "cb62184ee740"
  :keywords '("convenience")
  :authors '(("Leo Okawa Ericson" . "https://sr.ht/~zetagon"))
  :maintainers '(("Leo Okawa Ericson" . "git@relevant-information.com")))
