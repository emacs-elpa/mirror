;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keychain-environment" "2.4.1.0.20251123.2"
  "Load keychain environment variables."
  ()
  :url "https://github.com/tarsius/keychain-environment"
  :commit "d2fa34404fe3a58bd7e708e73b77be43f46eb4cc"
  :revdesc "2.4.1-2-gd2fa34404fe3"
  :keywords '("gnupg" "pgp" "ssh")
  :authors '(("Paul Tipper" . "bluefooatgooglemaildotcom"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
