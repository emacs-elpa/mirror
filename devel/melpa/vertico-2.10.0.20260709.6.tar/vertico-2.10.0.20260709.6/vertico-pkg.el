;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "2.10.0.20260709.6"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "99b9ef78e653422466ee14f1672af3ee7f685ca4"
  :revdesc "2.10-6-g99b9ef78e653"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
