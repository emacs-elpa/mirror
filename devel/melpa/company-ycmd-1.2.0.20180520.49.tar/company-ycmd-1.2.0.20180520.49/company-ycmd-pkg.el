;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ycmd" "1.2.0.20180520.49"
  "Company-mode backend for ycmd."
  '((ycmd      "1.3")
    (company   "0.9.3")
    (deferred  "0.5.1")
    (s         "1.11.0")
    (dash      "2.13.0")
    (let-alist "1.0.5")
    (f         "0.19.0"))
  :url "https://github.com/abingham/emacs-ycmd"
  :commit "966594701c1eef1f6d4dad0c71c6d43a029977d7"
  :revdesc "966594701c1e"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com")
             ("Peter Vasil" . "mail@petervasil.net"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")
                 ("Peter Vasil" . "mail@petervasil.net")))
