;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cycle-at-point" "0.2.0.20260502.13"
  "Cycle (rotate) the word at point."
  '((emacs      "29.1")
    (recomplete "0.2"))
  :url "https://codeberg.org/ideasman42/emacs-cycle-at-point"
  :commit "0be4e5813250139697773275784a9a8d144f47b1"
  :revdesc "0be4e5813250"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
