;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slurm-mode" "0.0.0.20210519.50"
  "Interaction with the SLURM job scheduling system."
  ()
  :url "https://github.com/ffevotte/slurm.el"
  :commit "4e6ac09245313cf4018b8e5784b2fca8604269d7"
  :revdesc "4e6ac0924531")
