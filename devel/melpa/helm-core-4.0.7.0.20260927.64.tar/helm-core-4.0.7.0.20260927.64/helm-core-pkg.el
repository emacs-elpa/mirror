;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "4.0.7.0.20260927.64"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "d7c91f23211a64fcff0ee5d9bb09fc1063f85a62"
  :revdesc "v4.0.7-64-gd7c91f23211a"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
