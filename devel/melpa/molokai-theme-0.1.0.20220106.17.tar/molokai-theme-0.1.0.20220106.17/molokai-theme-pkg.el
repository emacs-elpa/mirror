;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "molokai-theme" "0.1.0.20220106.17"
  "Molokai theme with Emacs theme engine."
  ()
  :url "https://github.com/alloy-d/color-theme-molokai"
  :commit "cc53e997e7eff93b58ad16a376a292c1dd66044b"
  :revdesc "cc53e997e7ef"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
