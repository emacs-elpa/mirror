;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "0.5.1"
  "Create releases of Emacs packages."
  '((emacs    "30.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.7"))
  :url "https://github.com/magit/sisyphus"
  :commit "229bc02ea128c2524e19234d0f0c7f7b2648f211"
  :revdesc "v0.5.1-0-g229bc02ea128"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
