;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eww-lnum" "1.1.0.20150102.1"
  "Conkeror-like functionality for eww."
  ()
  :url "https://github.com/m00natic/eww-lnum"
  :commit "4b0ecec769919ecb05ca4fb15ec51911ba589929"
  :revdesc "4b0ecec76991"
  :keywords '("eww" "browse" "conkeror")
  :authors '(("Andrey Kotlarski" . "m00naticus@gmail.com"))
  :maintainers '(("Andrey Kotlarski" . "m00naticus@gmail.com")))
