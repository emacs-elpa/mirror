;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sniem" "1.3.0.20261125.5"
  "Hands-eased united editing method."
  '((emacs "27.1")
    (s     "2.12.0")
    (dash  "1.12.0"))
  :url "https://github.com/SpringHan/sniem.git"
  :commit "361c90b31756f62d7e97b3492c775373823f7f97"
  :revdesc "361c90b31756"
  :keywords '("convenience" "united-editing-method"))
