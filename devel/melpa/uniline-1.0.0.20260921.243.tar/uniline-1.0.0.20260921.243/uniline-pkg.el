;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "1.0.0.20260921.243"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "debb3a4ead66f91e14ce065bc579cdc26cad60cc"
  :revdesc "debb3a4ead66"
  :keywords '("convenience" "text"))
