;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-autoexport" "1.4.0.20261028.5"
  "Auto-export org file on save."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://git.sr.ht/~zondo/org-autoexport"
  :commit "d813f167be70f0bf13c75fa085ff8e42fb847b4a"
  :revdesc "d813f167be70"
  :keywords '("org" "wp")
  :authors '(("Glenn Hutchings" . "zondo42@gmail.com"))
  :maintainers '(("Glenn Hutchings" . "zondo42@gmail.com")))
