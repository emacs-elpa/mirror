;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnatune" "0.5.1.0.20151030.4"
  "Browse magnatune's music catalog."
  '((dash "2.9.0")
    (s    "1.9.0"))
  :url "https://github.com/eikek/magnatune.el"
  :commit "605b01505ba30589c77ebb4c96834b5072ccbdd4"
  :revdesc "605b01505ba3")
