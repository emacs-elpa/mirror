;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "0.21.0.0.20261013.9"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.14.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "16f8ac99a5b2456442eb5e8cd4100b11a8e4cb58"
  :revdesc "v0.21.0-9-g16f8ac99a5b2"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
