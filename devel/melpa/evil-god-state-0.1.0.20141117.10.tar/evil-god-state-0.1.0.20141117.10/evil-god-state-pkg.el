;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-god-state" "0.1.0.20141117.10"
  "Use god-mode keybindings in evil-mode."
  '((evil     "1.0.8")
    (god-mode "2.12.0"))
  :url "https://github.com/gridaphobe/evil-god-state"
  :commit "3d44197dc0a1fb40e7b7ff8717f8a8c339ce1d40"
  :revdesc "3d44197dc0a1"
  :keywords '("evil" "leader" "god-mode"))
