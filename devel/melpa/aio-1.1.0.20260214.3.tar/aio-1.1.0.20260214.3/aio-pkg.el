;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aio" "1.1.0.20260214.3"
  "Async/await for Emacs Lisp."
  '((emacs "26.1"))
  :url "https://github.com/skeeto/emacs-aio"
  :commit "0e94a06bb035953cbbb4242568b38ca15443ad4c"
  :revdesc "1.1-3-g0e94a06bb035"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
