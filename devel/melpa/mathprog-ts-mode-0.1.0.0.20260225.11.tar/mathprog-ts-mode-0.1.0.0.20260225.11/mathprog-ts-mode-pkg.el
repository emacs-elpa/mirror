;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mathprog-ts-mode" "0.1.0.0.20260225.11"
  "Major mode for the GNU MathProg modeling language."
  '((emacs "29.1"))
  :url "https://github.com/smoeding/mathprog-ts-mode"
  :commit "a45ccc2a252aaeb34fbd2c180d8b428bb38bebc1"
  :revdesc "a45ccc2a252a"
  :keywords '("languages")
  :authors '(("Stefan Möding" . "stm@kill-9.net"))
  :maintainers '(("Stefan Möding" . "stm@kill-9.net")))
