;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mw-thesaurus" "1.4.0"
  "Merriam-Webster Thesaurus."
  '((emacs "27.1"))
  :url "https://github.com/agzam/mw-thesaurus.el"
  :commit "76571627f29f12d36c354e2eb759412536f1bcaa"
  :revdesc "1.4.0-0-g76571627f29f"
  :keywords '("wp" "matching")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
