;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "2.30.4.0.20260918.38"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.82.3")
    (transient   "0.9.3"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "ed3bd8104c0e476b6cdf5787ba72b5e5dd1d39b0"
  :revdesc "ed3bd8104c0e")
