;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cobalt" "1.0.0.0.20180304.20"
  "Easily use the Cobalt.rs static site generator."
  '((emacs "24"))
  :url "https://github.com/cobalt-org/cobalt.el"
  :commit "634ace275697e188746ca22a30ff94380ec756be"
  :revdesc "634ace275697"
  :keywords '("convenience")
  :authors '(("Juan Karlo Licudine" . "accidentalrebel@gmail.com"))
  :maintainers '(("Juan Karlo Licudine" . "accidentalrebel@gmail.com")))
