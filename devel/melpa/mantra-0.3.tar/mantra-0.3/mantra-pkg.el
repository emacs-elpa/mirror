;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mantra" "0.3"
  "A system for scripting and parsing activity beyond macros."
  '((emacs  "27.1")
    (pubsub "0.1"))
  :url "https://github.com/countvajhula/mantra"
  :commit "49f885b8947662bc837297f5c8a225d65dafcacd"
  :revdesc "v0.3-0-g49f885b89476"
  :authors '(("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
