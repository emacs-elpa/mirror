;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gitlab" "0.1.0.0.20240707.15"
  "Magit plugin for manipulating GitLab merge requests."
  '((emacs     "26.1")
    (magit     "3.3.0")
    (ghub      "3.6.0")
    (transient "0.6.0"))
  :url "https://gitlab.com/arvidnl/magit-gitlab"
  :commit "6f10468f9091d02aa6f1ce4af914443209a7d2a5"
  :revdesc "0.1.0-15-g6f10468f9091"
  :authors '(("Arvid Jakobsson" . "arvid.jakobsson@gmail.com"))
  :maintainers '(("Arvid Jakobsson" . "arvid.jakobsson@gmail.com")))
