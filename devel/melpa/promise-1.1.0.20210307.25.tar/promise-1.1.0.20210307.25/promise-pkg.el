;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promise" "1.1.0.20210307.25"
  "Promises/A+."
  '((emacs "25.1"))
  :url "https://github.com/chuntaro/emacs-promise"
  :commit "cec51feb5f957e8febe6325335cf57dc2db6be30"
  :revdesc "1.1-25-gcec51feb5f95"
  :keywords '("async" "promise" "convenience")
  :authors '(("chuntaro" . "chuntaro@sakura-games.jp"))
  :maintainers '(("chuntaro" . "chuntaro@sakura-games.jp")))
