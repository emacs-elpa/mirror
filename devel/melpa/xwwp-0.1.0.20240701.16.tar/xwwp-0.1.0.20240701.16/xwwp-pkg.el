;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xwwp" "0.1.0.20240701.16"
  "Enhance xwidget webkit browser."
  '((emacs "26.1"))
  :url "https://github.com/canatella/xwwp"
  :commit "0c875e460d1c0637766204dc289ffbd0f2284194"
  :revdesc "0c875e460d1c"
  :keywords '("convenience"))
