;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "0.13.0.0.20260923.19"
  "Linked notes and spaced repetition."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.4.4"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "dd81341093c6428e0b5a1faca43802e6fa485f5a"
  :revdesc "dd81341093c6"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
