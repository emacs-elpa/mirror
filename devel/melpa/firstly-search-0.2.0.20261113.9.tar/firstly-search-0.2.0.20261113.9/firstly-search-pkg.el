;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "0.2.0.20261113.9"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "d5360f78fb050a9475c221bd593ca6b6df034d09"
  :revdesc "d5360f78fb05"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
