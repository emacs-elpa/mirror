;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-agenda-dock" "0.0.1.0.20260206.14"
  "Integrate org-mode with Gnome's Dock or KDE's taskbar."
  '((emacs "28.1")
    (dock  "0.0.1")
    (org   "9.0"))
  :url "https://github.com/hron/org-agenda-dock"
  :commit "5b4f86a97c45f873ce41ce56ce398d9ef3e92dff"
  :revdesc "5b4f86a97c45"
  :keywords '("convenience" "org" "dock" "desktop")
  :authors '(("Aleksei Gusev" . "aleksei.gusev@gmail.com"))
  :maintainers '(("Aleksei Gusev" . "aleksei.gusev@gmail.com")))
