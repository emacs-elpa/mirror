;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "egalgo" "1.0.2.0.20211105.19"
  "Genetic algorithm."
  '((emacs "24.3"))
  :url "https://github.com/ROCKTAKEY/egalgo"
  :commit "a56a86591351d53ca2add7c651757bfb0064fb22"
  :revdesc "a56a86591351"
  :keywords '("data")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
