;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperspace" "0.8.4.0.20230518.15"
  "Get there from here."
  '((emacs "25")
    (s     "1.12.0"))
  :url "https://github.com/ieure/hyperspace-el"
  :commit "f574d07fd8715e806ba4f0487b73c699963baed3"
  :revdesc "0.8.4-15-gf574d07fd871"
  :keywords '("tools" "convenience")
  :authors '(("Ian Eure" . "ian@retrospec.tv"))
  :maintainers '(("Ian Eure" . "ian@retrospec.tv")))
