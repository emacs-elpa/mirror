;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fxrd-mode" "1.0.0.20250705.4"
  "Major mode for editing fixed field width files."
  '((s "1.2"))
  :url "https://github.com/msherry/fxrd-mode"
  :commit "7f755e1ff4a6451bc97fcefef8e96f563311fb1a"
  :revdesc "1.0-4-g7f755e1ff4a6"
  :keywords '("convenience")
  :authors '(("Marc Sherry" . "(msherry@gmail.com)"))
  :maintainers '(("Marc Sherry" . "(msherry@gmail.com)")))
