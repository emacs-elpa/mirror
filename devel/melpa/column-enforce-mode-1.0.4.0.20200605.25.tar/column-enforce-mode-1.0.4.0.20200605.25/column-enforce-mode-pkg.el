;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "column-enforce-mode" "1.0.4.0.20200605.25"
  "Highlight text that extends beyond a  column."
  ()
  :url "www.github.com/jordonbiondo/column-enforce-mode"
  :commit "14a7622f2268890e33536ccd29510024d51ee96f"
  :revdesc "14a7622f2268")
