;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20261119.346"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "92d57daeb2e90ab0f5dbf19245e6a4ea8424a83c"
  :revdesc "92d57daeb2e9")
