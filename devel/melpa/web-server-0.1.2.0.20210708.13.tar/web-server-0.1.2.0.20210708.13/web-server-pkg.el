;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "web-server" "0.1.2.0.20210708.13"
  "Emacs Web Server."
  '((emacs  "24.1")
    (cl-lib "0.6"))
  :url "https://github.com/eschulte/emacs-web-server"
  :commit "6357a1c2d1718778503f7ee0909585094117525b"
  :revdesc "6357a1c2d171"
  :keywords '("http" "server" "network")
  :authors '(("Eric Schulte" . "schulte.eric@gmail.com"))
  :maintainers '(("Eric Schulte" . "schulte.eric@gmail.com")))
