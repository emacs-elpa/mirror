;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumber-jump" "0.5.4.0.20241028.14"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "28.1")
    (s     "1.11.0")
    (dash  "2.9.0"))
  :url "https://github.com/zenspider/dumber-jump"
  :commit "37ca96bd065ac6869549e17dec98940edfc59f5a"
  :revdesc "37ca96bd065a"
  :keywords '("tools"))
