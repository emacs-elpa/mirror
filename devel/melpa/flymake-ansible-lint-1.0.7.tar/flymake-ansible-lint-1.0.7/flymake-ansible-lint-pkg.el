;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ansible-lint" "1.0.7"
  "A Flymake backend for ansible-lint."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/flymake-ansible-lint.el"
  :commit "bfb8148d9a1aece141d18eef484e7c0c8db79855"
  :revdesc "1.0.7-0-gbfb8148d9a1a"
  :keywords '("tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
