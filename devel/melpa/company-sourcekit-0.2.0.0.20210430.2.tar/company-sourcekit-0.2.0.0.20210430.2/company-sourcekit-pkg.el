;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-sourcekit" "0.2.0.0.20210430.2"
  "Company-mode completion backend for SourceKit."
  '((emacs     "24.3")
    (company   "0.8.12")
    (dash      "2.18.0")
    (sourcekit "0.2.0"))
  :url "https://github.com/nathankot/company-sourcekit"
  :commit "a1860ad4dd3a542acd2fa0dfac2a388cbdf4af0c"
  :revdesc "a1860ad4dd3a"
  :keywords '("abbrev")
  :authors '(("Nathan Kot" . "nk@nathankot.com"))
  :maintainers '(("Nathan Kot" . "nk@nathankot.com")))
