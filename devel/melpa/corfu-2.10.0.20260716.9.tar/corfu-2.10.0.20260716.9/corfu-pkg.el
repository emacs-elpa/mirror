;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.10.0.20260716.9"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "6c2f57eba77f0734fc7d32d365aa0fab5e0cb8a2"
  :revdesc "2.10-9-g6c2f57eba77f"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
