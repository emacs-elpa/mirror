;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.9.0"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "d52625ddc88ea6cfa29540dbecfe97aadf3c76fa"
  :revdesc "d52625ddc88e"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
