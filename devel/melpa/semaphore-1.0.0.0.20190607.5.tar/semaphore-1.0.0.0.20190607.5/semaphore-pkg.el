;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "semaphore" "1.0.0.0.20190607.5"
  "Semaphore based on condition variables."
  '((emacs "26"))
  :url "https://github.com/webnf/semaphore.el"
  :commit "ec4c485c8e4cff63805ecc25523a031a6c2ad7cd"
  :revdesc "ec4c485c8e4c"
  :keywords '("processes" "unix")
  :authors '(("Herwig Hochleitner" . "herwig@bendlas.net"))
  :maintainers '(("Herwig Hochleitner" . "herwig@bendlas.net")))
