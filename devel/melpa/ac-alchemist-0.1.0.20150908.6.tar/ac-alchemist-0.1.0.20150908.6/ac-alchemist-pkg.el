;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-alchemist" "0.1.0.20150908.6"
  "Auto-complete source for alchemist."
  '((auto-complete "1.5.0")
    (alchemist     "1.5.0")
    (cl-lib        "0.5"))
  :url "https://github.com/syohex/emacs-ac-alchemist"
  :commit "b1891c3d41aed83f61d78a609ea97be5cc2758d9"
  :revdesc "b1891c3d41ae"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
