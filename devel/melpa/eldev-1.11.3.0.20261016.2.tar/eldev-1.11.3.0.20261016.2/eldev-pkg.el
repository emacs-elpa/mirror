;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "1.11.3.0.20261016.2"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "f771fd1722937f9e575f2a3634207b7d4e0dc353"
  :revdesc "f771fd172293"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
