;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.49.0.0.20260804.4"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "dbd8878d64dc98be9b29ffba46d2417f77b8fddf"
  :revdesc "dbd8878d64dc"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
