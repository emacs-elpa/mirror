;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firestarter" "0.2.5.0.20210508.8"
  "Execute (shell) commands on save."
  '((emacs "24.1"))
  :url "https://depp.brause.cc/firestarter"
  :commit "76070c9074aa363350abe6ad06143e90b3e12ab1"
  :revdesc "76070c9074aa"
  :keywords '("convenience")
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
