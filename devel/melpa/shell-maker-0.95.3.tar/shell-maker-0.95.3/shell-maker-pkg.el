;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.95.3"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "6ed92d410ab52f656d8c79a7bd9a912ebcf5b1a1"
  :revdesc "6ed92d410ab5")
