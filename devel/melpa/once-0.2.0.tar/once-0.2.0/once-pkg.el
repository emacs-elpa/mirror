;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "once" "0.2.0"
  "Add-hook and eval-after-load, but only once."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/once"
  :commit "8bb03796ca7801bbd24dcc36f55a5a9d640326d4"
  :revdesc "0.2.0-0-g8bb03796ca78"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
