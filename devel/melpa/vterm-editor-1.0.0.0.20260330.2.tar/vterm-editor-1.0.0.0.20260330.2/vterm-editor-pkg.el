;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vterm-editor" "1.0.0.0.20260330.2"
  "Edit text in a buffer and send it to vterm."
  '((emacs "25.1")
    (vterm "0.0.1"))
  :url "https://git.andros.dev/andros/vterm-editor.el"
  :commit "239782cdf2411aed27a4f053c30e05c90047351b"
  :revdesc "239782cdf241"
  :keywords '("terminals" "convenience")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
