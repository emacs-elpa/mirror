;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-chat" "0.10.0"
  "Emacs client for Lisp Chat."
  '((emacs     "27.1")
    (websocket "1.12"))
  :url "https://github.com/ryukinix/lisp-chat"
  :commit "e54265d278af3de1ca6bc895e7b0ebde82c5b5fc"
  :revdesc "e54265d278af"
  :keywords '("comm" "chat" "lisp")
  :authors '(("Manoel V. Machado" . "(manoel_vilela@engineer.com)"))
  :maintainers '(("Manoel V. Machado" . "(manoel_vilela@engineer.com)")))
