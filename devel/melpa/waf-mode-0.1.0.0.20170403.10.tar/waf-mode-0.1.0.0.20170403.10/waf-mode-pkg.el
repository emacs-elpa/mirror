;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "waf-mode" "0.1.0.0.20170403.10"
  "Waf integration for Emacs."
  ()
  :url "https://bitbucket.org/dvalchuk/waf-mode"
  :commit "91c761336aa137b85b88b53b3f0cc60786d70800"
  :revdesc "91c761336aa1"
  :authors '(("Denys Valchuk" . "dvalchuk@gmail.com"))
  :maintainers '(("Denys Valchuk" . "dvalchuk@gmail.com")))
