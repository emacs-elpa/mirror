;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "memoize" "1.1.0.20200103.7"
  "Memoization functions."
  ()
  :url "https://github.com/skeeto/emacs-memoize"
  :commit "51b075935ca7070f62fae1d69fe0ff7d8fa56fdd"
  :revdesc "1.1-7-g51b075935ca7"
  :authors '(("Christopher Wellons" . "mosquitopsu@gmail.com"))
  :maintainers '(("Christopher Wellons" . "mosquitopsu@gmail.com")))
