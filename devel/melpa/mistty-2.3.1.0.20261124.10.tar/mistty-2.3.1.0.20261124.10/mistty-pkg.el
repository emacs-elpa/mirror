;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "2.3.1.0.20261124.10"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "b109d8c9c4db482d888756630fcb3a5427b2f414"
  :revdesc "b109d8c9c4db"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
