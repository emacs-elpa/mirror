;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lolcode-mode" "0.2.0.20111002.1"
  "Major mode for editing LOLCODE."
  ()
  :url "https://github.com/bodil/lolcode-mode"
  :commit "280a47e0bf02ee3abc7c5b6b14345056f41981f9"
  :revdesc "280a47e0bf02"
  :keywords '("lolcode" "major" "mode")
  :authors '(("Bodil Stokke" . "lolcode@bodil.tv"))
  :maintainers '(("Bodil Stokke" . "lolcode@bodil.tv")))
