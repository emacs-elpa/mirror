;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "4.2.1.0.20261102.3"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "2a8df8a9c9c8507955c4351ceca29f671842d87a"
  :revdesc "v4.2.1-3-g2a8df8a9c9c8"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
