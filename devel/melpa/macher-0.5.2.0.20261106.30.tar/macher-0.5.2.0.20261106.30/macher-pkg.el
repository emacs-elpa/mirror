;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "0.5.2.0.20261106.30"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "b4a86f0d514fea8b460022181cbc2405a3ae9eb3"
  :revdesc "b4a86f0d514f"
  :keywords '("convenience" "gptel" "llm")
  :authors '(("Kevin Montag" . "https://github.com/kmontag"))
  :maintainers '(("Kevin Montag" . "https://github.com/kmontag")))
