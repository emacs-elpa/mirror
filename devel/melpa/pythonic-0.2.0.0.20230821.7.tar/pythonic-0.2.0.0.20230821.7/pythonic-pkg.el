;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pythonic" "0.2.0.0.20230821.7"
  "Utility functions for writing pythonic emacs package."
  '((emacs "25.1")
    (s     "1.9")
    (f     "0.17.2"))
  :url "https://github.com/proofit404/pythonic"
  :commit "f6e0bec552319341f260a5c4740288799c2b3a5b"
  :revdesc "f6e0bec55231"
  :keywords '("convenience" "pythonic")
  :authors '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers '(("Artem Malyshev" . "proofit404@gmail.com")))
