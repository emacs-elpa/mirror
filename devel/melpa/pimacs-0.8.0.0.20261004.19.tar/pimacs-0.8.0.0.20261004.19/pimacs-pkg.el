;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.8.0.0.20261004.19"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "5e94d80b30cecb597759b37656992989516727e4"
  :revdesc "5e94d80b30ce"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
