;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "standard-dirs" "2.0.0"
  "Platform-specific paths for config, cache, and other data."
  '((emacs "26.1")
    (f     "0.20.0")
    (s     "1.7.0"))
  :url "https://github.com/lafrenierejm/standard-dirs.el"
  :commit "e37b7e1c714c7798cd8e3a6569e4d71b96718a60"
  :revdesc "e37b7e1c714c"
  :keywords '("files")
  :authors '(("Joseph M LaFreniere" . "joseph@lafreniere.xyz"))
  :maintainers '(("Joseph M LaFreniere" . "joseph@lafreniere.xyz")))
