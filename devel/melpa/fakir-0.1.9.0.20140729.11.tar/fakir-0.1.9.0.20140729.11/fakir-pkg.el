;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fakir" "0.1.9.0.20140729.11"
  "Fakeing bits of Emacs."
  '((noflet "0.0.8")
    (dash   "1.3.2")
    (kv     "0.0.19"))
  :url "https://github.com/nicferrier/emacs-fakir"
  :commit "1fca406ad7de80fece6319ff75d4230b648534b0"
  :revdesc "1fca406ad7de"
  :keywords '("lisp" "tools")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
