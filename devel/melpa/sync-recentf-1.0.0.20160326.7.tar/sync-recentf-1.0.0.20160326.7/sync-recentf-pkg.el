;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sync-recentf" "1.0.0.20160326.7"
  "Synchronize the recent files list between Emacs instances."
  ()
  :url "https://github.com/ffevotte/sync-recentf"
  :commit "0052561d5c5b5c2684faedc3eead776aec06c3ed"
  :revdesc "0052561d5c5b"
  :keywords '("recentf")
  :authors '(("François Févotte" . "fevotte@gmail.com"))
  :maintainers '(("François Févotte" . "fevotte@gmail.com")))
