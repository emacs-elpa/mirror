;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chapel-mode" "0.0.1.0.20210513.64"
  "A major mode for the Chapel programming language."
  '((emacs "25.1")
    (hydra "0.15.0"))
  :url "https://github.com/damon-kwok/chapel-mode"
  :commit "39fd24bb7cf44808200354ac0496be4fc4fddd9a"
  :revdesc "39fd24bb7cf4"
  :keywords '("chapel" "chpl" "programming" "languages")
  :authors '(("Damon Kwok" . "damon-kwok@outlook.com"))
  :maintainers '(("Damon Kwok" . "damon-kwok@outlook.com")))
