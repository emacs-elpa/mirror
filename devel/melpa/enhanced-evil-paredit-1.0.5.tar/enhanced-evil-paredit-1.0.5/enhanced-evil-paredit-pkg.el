;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "1.0.5"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "2209fceae2acab381facb1865ac41b28c2938f10"
  :revdesc "1.0.5-0-g2209fceae2ac"
  :keywords '("convenience"))
