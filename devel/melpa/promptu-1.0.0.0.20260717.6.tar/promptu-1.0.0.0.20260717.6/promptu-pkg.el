;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "1.0.0.0.20260717.6"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "685e3c99c1ec74e293b6426f40babb56b65383f1"
  :revdesc "v1.0.0-6-g685e3c99c1ec"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
