;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-json" "0.3.0.0.20260628.49"
  "JSON export backend for Org mode."
  '((emacs "26.1")
    (org   "9")
    (s     "1.12"))
  :url "https://github.com/jlumpe/ox-json"
  :commit "1f4df1ca955449a1a79c6e4f33beb479a726639d"
  :revdesc "1f4df1ca9554"
  :keywords '("outlines")
  :authors '(("Jared Lumpe" . "jared@jaredlumpe.com"))
  :maintainers '(("Jared Lumpe" . "jared@jaredlumpe.com")))
