;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "libmpdel" "2.1.0"
  "Communication with an MPD server."
  '((emacs "25.1"))
  :url "https://github.com/mpdel/libmpdel"
  :commit "f2cb01c8d004b5fbfa937579e899035a47d2a5f2"
  :revdesc "v2.1.0-0-gf2cb01c8d004"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
