;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dmacro" "2.0.0.20241027.66"
  "Repeated detection and execution of key operation."
  '((emacs  "24.1")
    (cl-lib "0.6"))
  :url "https://github.com/emacs-jp/dmacro"
  :commit "cb3ce0e1d6ce868baf47cb9225c8daae4b610dab"
  :revdesc "cb3ce0e1d6ce"
  :keywords '("convenience")
  :authors '(("Toshiyuki Masui" . "masui@ptiecan.com"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
