;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.95.1"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "9b769dc078f1dec9588e50838d278d236ba17a3b"
  :revdesc "9b769dc078f1")
