;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cybercafe-theme" "0.3.3.0.20231122.3"
  "Cybercafe color theme."
  '((emacs "24.1"))
  :url "https://github.com/gboncoffee/cybercafe-emacs-theme"
  :commit "c241228914c9bd070733b1e97ea11a5cb6331e86"
  :revdesc "c241228914c9"
  :keywords '("faces")
  :authors '((nil . "GabrieldeBritogabrielgbrito@icloud.com"))
  :maintainers '((nil . "GabrieldeBritogabrielgbrito@icloud.com")))
