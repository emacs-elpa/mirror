;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-god-toggle" "1.3.0"
  "Toggle Evil and God Mode."
  '((emacs    "28.1")
    (evil     "1.0.8")
    (god-mode "2.12.0"))
  :url "https://github.com/jam1015/evil-god-toggle"
  :commit "d6f8d098b9f9e0046df5afd35ced5bc5ed5a0ea0"
  :revdesc "v1.3.0-0-gd6f8d098b9f9"
  :keywords '("convenience" "emulation" "evil" "god-mode")
  :authors '(("Jordan Mandel" . "jordan.mandel@live.com"))
  :maintainers '(("Jordan Mandel" . "jordan.mandel@live.com")))
