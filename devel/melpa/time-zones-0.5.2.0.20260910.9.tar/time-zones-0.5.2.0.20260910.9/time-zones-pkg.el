;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-zones" "0.5.2.0.20260910.9"
  "Time zone lookups."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/time-zones"
  :commit "dc6c438031f5c279bf1bbf39c053f22807460bbf"
  :revdesc "dc6c438031f5")
