;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.960.0.20260915.6"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "9fd89a5a35600247f7fc7dc67d815d8523c89c22"
  :revdesc "9fd89a5a3560"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
