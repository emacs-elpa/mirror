;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "id-manager" "0.0.0.20170320.29"
  "Id-password management."
  ()
  :url "https://github.com/kiwanami/emacs-id-manager"
  :commit "14ebc35db298aac4dedc8aa188bc46bacab81f3b"
  :revdesc "14ebc35db298"
  :keywords '("password" "convenience")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net"))
  :maintainers '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net")))
