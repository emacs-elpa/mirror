;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shexc-ts-mode" "3.0.0.20260726.52"
  "Tree-sitter major mode for ShExC."
  '((emacs     "29.1")
    (transient "0.5.0")
    (compat    "29.1.4.4"))
  :url "https://github.com/ericprud/shexc-mode-for-emacs"
  :commit "815011eb9abf9a42d6bb681d41d21640530a6c70"
  :revdesc "v3.0-52-g815011eb9abf"
  :keywords '("languages")
  :authors '(("Eric Prud'hommeaux" . "eric@w3.org"))
  :maintainers '(("Eric Prud'hommeaux" . "eric@w3.org")))
