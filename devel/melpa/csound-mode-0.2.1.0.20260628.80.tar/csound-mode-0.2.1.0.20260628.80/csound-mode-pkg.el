;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "csound-mode" "0.2.1.0.20260628.80"
  "A major mode for interacting and coding Csound."
  '((emacs     "27.1")
    (shut-up   "0.3.2")
    (multi     "2.0.1")
    (dash      "2.16.0")
    (highlight "0"))
  :url "https://github.com/hlolli/csound-mode"
  :commit "d4bb370233acddc2624d405d2a6a8de8c8c56d30"
  :revdesc "d4bb370233ac"
  :authors '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers '(("Hlöðver Sigurðsson" . "hlolli@gmail.com")))
