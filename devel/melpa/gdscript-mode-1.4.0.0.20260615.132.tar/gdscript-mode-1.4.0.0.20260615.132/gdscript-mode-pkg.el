;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "1.4.0.0.20260615.132"
  "Major mode for Godot's GDScript language."
  '((emacs "29.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "6bfea8c477cda3f300b84248b5f56c9d241e8029"
  :revdesc "6bfea8c477cd"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
