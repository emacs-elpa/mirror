;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scala-ts-mode" "0.0.1.0.20261013.61"
  "An tree-sitter based major-mode for Scala."
  '((emacs "29.1"))
  :url "https://github.com/KaranAhlawat/scala-ts-mode"
  :commit "a1f25865a3c2772b91f5bf95457411b45244ea1e"
  :revdesc "a1f25865a3c2"
  :keywords '("emacs" "scala" "languages" "tree-sitter" "scala-ts-mode")
  :authors '(("Karan Ahlawat" . "ahlawatkaran12@gmail.com"))
  :maintainers '(("Karan Ahlawat" . "ahlawatkaran12@gmail.com")))
