;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-tcl" "0.4.0.20180327.7"
  "A flycheck checker for Tcl using tclchecker."
  '((emacs    "24.4")
    (flycheck "0.22"))
  :url "https://github.com/nwidger/flycheck-tcl"
  :commit "7ca23f4673e178b9f5dcc8a82b86cf05b15d7236"
  :revdesc "7ca23f4673e1"
  :authors '(("Niels Widger" . "niels.widger@gmail.com"))
  :maintainers '(("Niels Widger" . "niels.widger@gmail.com")))
