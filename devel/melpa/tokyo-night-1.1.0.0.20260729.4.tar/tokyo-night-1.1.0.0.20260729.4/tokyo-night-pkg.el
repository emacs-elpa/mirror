;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "1.1.0.0.20260729.4"
  "Tokyo Night color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "e8e33fc282ccbeebe01f883fc0cd55ab9897321a"
  :revdesc "e8e33fc282cc"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
