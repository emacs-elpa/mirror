;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shrink-whitespace" "0.0.4"
  "Whitespace removal DWIM key."
  ()
  :url "https://gitlab.com/jcpetkovich/shrink-whitespace.el"
  :commit "0407b89c142bd17e65edb666f35e2c6755bd0867"
  :revdesc "0407b89c142b"
  :keywords '("convenience")
  :authors '(("Jean-Christophe Petkovich" . "jcpetkovich@gmail.com"))
  :maintainers '(("Jean-Christophe Petkovich" . "jcpetkovich@gmail.com")))
