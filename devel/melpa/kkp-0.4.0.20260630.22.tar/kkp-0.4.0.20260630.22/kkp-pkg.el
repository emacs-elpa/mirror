;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "0.4.0.20260630.22"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benotn/kkp"
  :commit "16e509a13c6321a0ffa0ab583fa903d995f34e34"
  :revdesc "16e509a13c63"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
