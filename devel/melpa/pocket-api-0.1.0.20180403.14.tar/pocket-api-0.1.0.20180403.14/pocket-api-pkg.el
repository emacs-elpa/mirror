;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pocket-api" "0.1.0.20180403.14"
  "Another pocket api."
  '((emacs   "24.4")
    (request "0.2"))
  :url "https://github.com/lujun9972/pocket-api.el"
  :commit "3eb9430b9db90bc02e736e433eb86389f7655189"
  :revdesc "3eb9430b9db9"
  :keywords '("convenience" "pocket")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
