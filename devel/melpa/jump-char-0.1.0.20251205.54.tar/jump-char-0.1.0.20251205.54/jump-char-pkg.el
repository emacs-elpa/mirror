;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jump-char" "0.1.0.20251205.54"
  "Navigation by char."
  ()
  :url "https://github.com/lewang/jump-char"
  :commit "6d7e7b090c4c5af77626f45e64e0677f356fce5b"
  :revdesc "6d7e7b090c4c")
