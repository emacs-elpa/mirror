;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "afterglow" "0.2.1.0.20240312.3"
  "Temporary Highlighting after Function Calls."
  '((emacs "26.1"))
  :url "https://github.com/ernstvanderlinden/emacs-afterglow"
  :commit "d90fcf4e5c8ac6f5bae2eb01dea32558b2b18fba"
  :revdesc "v0.2.1-3-gd90fcf4e5c8a"
  :keywords '("highlight" "line" "convenience" "evil")
  :authors '(("Ernest M. van der Linden" . "hello@ernestoz.com"))
  :maintainers '(("Ernest M. van der Linden" . "hello@ernestoz.com")))
