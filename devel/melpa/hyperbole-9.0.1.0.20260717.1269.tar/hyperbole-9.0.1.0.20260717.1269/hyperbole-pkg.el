;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.0.1.0.20260717.1269"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "5a935fed4e0f44674d2499e5058a43ebf9162e09"
  :revdesc "5a935fed4e0f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
