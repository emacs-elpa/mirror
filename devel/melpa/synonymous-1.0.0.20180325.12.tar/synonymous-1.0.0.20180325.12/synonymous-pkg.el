;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "synonymous" "1.0.0.20180325.12"
  "A thesaurus at your fingertips."
  '((emacs   "24")
    (cl-lib  "0.5")
    (request "0.2.0"))
  :url "https://github.com/toroidal-code/synonymous.el"
  :commit "2cb9a674d84fddf3f1b00c9d6b13a853576acb87"
  :revdesc "2cb9a674d84f"
  :keywords '("utility")
  :authors '(("Katherine Whitlock" . "toroidalcode@gmail.com")
             ("authored by Manuel Serrano" . "Manuel.Serrano@inria.fr"))
  :maintainers '(("Katherine Whitlock" . "toroidalcode@gmail.com")
                 ("authored by Manuel Serrano" . "Manuel.Serrano@inria.fr")))
