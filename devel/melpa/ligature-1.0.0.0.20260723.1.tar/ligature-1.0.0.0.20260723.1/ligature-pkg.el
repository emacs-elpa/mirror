;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ligature" "1.0.0.0.20260723.1"
  "Display typographical ligatures in major modes."
  '((emacs "28"))
  :url "https://www.github.com/mickeynp/ligature.el"
  :commit "b68eb47c5a29b74c8769e05eae6f5ee6a667f8b3"
  :revdesc "v1.0.0-1-gb68eb47c5a29"
  :keywords '("tools" "faces")
  :authors '(("Mickey Petersen" . "mickey@masteringemacs.org"))
  :maintainers '(("Mickey Petersen" . "mickey@masteringemacs.org")))
