;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php" "2.8.1.0.20260921.11"
  "Auto Completion source for PHP."
  '((ac-php-core   "2.0")
    (auto-complete "1.4.0")
    (yasnippet     "0.8.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "ab7f0275e0dd73dfe66c6cad271b9282f6e8a276"
  :revdesc "v2.8.1-11-gab7f0275e0dd"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
