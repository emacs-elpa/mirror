;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-spotlight" "0.1.0.0.20260612.7"
  "Consult interface to macOS mdfind (Spotlight)."
  '((emacs   "28.1")
    (consult "2.0"))
  :url "https://github.com/guibor/consult-spotlight"
  :commit "0a8a60e26fcbf15414c0f56f4c8b4a504c5c9c11"
  :revdesc "0a8a60e26fcb"
  :keywords '("matching" "files" "convenience")
  :authors '(("MDF" . "sguibor@gmail.com"))
  :maintainers '(("MDF" . "sguibor@gmail.com")))
