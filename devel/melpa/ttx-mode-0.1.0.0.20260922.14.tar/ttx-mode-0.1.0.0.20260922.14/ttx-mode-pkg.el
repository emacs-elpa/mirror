;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ttx-mode" "0.1.0.0.20260922.14"
  "TrueType/OpenType font viewer using ttx."
  '((emacs "30.0"))
  :url "https://github.com/wmedrano/ttx-mode"
  :commit "62e53f57656aed47aa4ef000cb565cf8e31abc8a"
  :revdesc "62e53f57656a"
  :keywords '("tools" "fonts")
  :authors '(("Will Medrano" . "will@wmedrano.dev"))
  :maintainers '(("Will Medrano" . "will@wmedrano.dev")))
