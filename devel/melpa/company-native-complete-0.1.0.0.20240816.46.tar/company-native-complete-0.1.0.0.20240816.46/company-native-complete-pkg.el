;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-native-complete" "0.1.0.0.20240816.46"
  "Company completion using native-complete."
  '((emacs           "26.1")
    (company         "0.9.0")
    (native-complete "0.1.0"))
  :url "https://github.com/CeleritasCelery/emacs-native-shell-complete"
  :commit "452c8d429f51434f5d53bd9920b7c2d06bf559d9"
  :revdesc "452c8d429f51"
  :authors '(("Troy Hinckley" . "troy.hinckley@gmail.com"))
  :maintainers '(("Troy Hinckley" . "troy.hinckley@gmail.com")))
