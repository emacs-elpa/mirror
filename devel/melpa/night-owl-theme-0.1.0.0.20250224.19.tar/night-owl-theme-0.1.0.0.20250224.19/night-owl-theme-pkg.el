;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "night-owl-theme" "0.1.0.0.20250224.19"
  "A color theme for the night owls out there."
  '((emacs "24"))
  :url "https://github.com/aaronjensen/night-owl-theme"
  :commit "13d9966ffda746231eef0dc905b50303309f115e"
  :revdesc "v0.1.0-19-g13d9966ffda7"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
