;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260614.1640"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "24c74ba1594d95578c7b753d21d20fc0d17c1ab0"
  :revdesc "24c74ba1594d"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
