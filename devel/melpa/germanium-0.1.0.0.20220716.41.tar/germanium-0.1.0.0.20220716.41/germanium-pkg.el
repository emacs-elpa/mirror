;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "germanium" "0.1.0.0.20220716.41"
  "Generate image from source code using germanium."
  '((emacs "26.1"))
  :url "https://github.com/matsuyoshi30/germanium-el"
  :commit "7292aa6870cf8b0acb34a8750da32b44d83cd65c"
  :revdesc "7292aa6870cf"
  :keywords '("convenience"))
