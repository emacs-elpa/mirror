;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "1.0.1.0.20260716.1"
  "Spaced repetition in plain text."
  '((emacs     "30.2")
    (transient "0.12.0"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "72b3db068a3b7a5e0a3f02d5f24434bec984225f"
  :revdesc "72b3db068a3b"
  :keywords '("hypermedia" "srs" "memory")
  :authors '(("Duncan Britt" . "duncanbritt.com"))
  :maintainers '(("Duncan Britt" . "duncanbritt.com")))
