;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "context-clues" "0.3.0.0.20260719.3"
  "Easily copy context like the current file name and path."
  '((emacs     "28.1")
    (transient "0.3.0"))
  :url "https://github.com/mrcnski/context-clues"
  :commit "51fa7a434a234d64c70054dd8d99ca4792bb7ee1"
  :revdesc "51fa7a434a23"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
