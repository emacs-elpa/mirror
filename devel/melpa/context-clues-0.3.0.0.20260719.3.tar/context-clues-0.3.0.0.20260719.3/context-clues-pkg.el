;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "context-clues" "0.3.0.0.20260719.3"
  "Easily copy context like the current file name and path."
  '((emacs     "28.1")
    (transient "0.3.0"))
  :url "https://github.com/mrcnski/context-clues"
  :commit "1d873e6fe4c1651e3d47df7fde5932f88dfa2879"
  :revdesc "1d873e6fe4c1"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
