;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-docstring-toggle" "1.1.0.0.20251123.2"
  "Toggle Lisp docstring visibility."
  '((emacs "29.1"))
  :url "https://github.com/gggion/lisp-docstring-toggle"
  :commit "3379f337efe01699b40ca8cfb9ca41c166d933ad"
  :revdesc "3379f337efe0"
  :keywords '("lisp" "docs" "editing"))
