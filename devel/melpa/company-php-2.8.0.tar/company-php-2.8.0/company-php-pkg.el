;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-php" "2.8.0"
  "A company back-end for PHP."
  '((cl-lib      "0.5")
    (ac-php-core "2.0")
    (company     "0.9"))
  :url "https://github.com/xcwen/ac-php"
  :commit "a2a89494fd2e53111a81227d2e35290e0825c3fb"
  :revdesc "v2.8.0-0-ga2a89494fd2e"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
