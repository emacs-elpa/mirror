;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "catppuccin-theme" "0.1.0.0.20260406.228"
  "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs."
  '((emacs "27.1"))
  :url "https://github.com/catppuccin/emacs"
  :commit "7435adc7f81eaf3b1b254fd2156ff3abd7a171c4"
  :revdesc "V0.1.0-228-g7435adc7f81e"
  :maintainers '(("Jeremy Baxter" . "jeremy@baxters.nz")))
