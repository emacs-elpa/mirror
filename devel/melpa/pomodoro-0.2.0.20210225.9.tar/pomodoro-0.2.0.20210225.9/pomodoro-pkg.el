;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pomodoro" "0.2.0.20210225.9"
  "A timer for the Pomodoro Technique."
  ()
  :url "https://github.com/baudtack/pomodoro.el"
  :commit "ed888b24d0b89a5dec6f5278b1064c530c827321"
  :revdesc "ed888b24d0b8"
  :authors '(("David Kerschner" . "dkerschner@gmail.com"))
  :maintainers '(("David Kerschner" . "dkerschner@gmail.com")))
