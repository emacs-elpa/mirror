;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-flyspell" "0.1.3.0.20170309.1"
  "Jump to and correct spelling errors using `ace-jump-mode' and flyspell."
  '((avy "0.4.0"))
  :url "https://github.com/cute-jumper/ace-flyspell"
  :commit "538d4f8508d305262ba0228dfe7c819fb65b53c9"
  :revdesc "538d4f8508d3"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
