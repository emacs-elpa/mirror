;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plsense" "0.4.7.0.20151104.1"
  "Provide interface for PlSense that is a development tool for Perl."
  '((auto-complete "1.4.0")
    (log4e         "0.2.0")
    (yaxception    "0.2.0"))
  :url "https://github.com/aki2o/emacs-plsense"
  :commit "d50f9dccc98f42bdb42f1d1c8142246e03879218"
  :revdesc "d50f9dccc98f"
  :keywords '("perl" "completion")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
