;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "0.1.4.0.20261103.6"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "30.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "6b58a54339fb6fc1e8913ca465dc9f2d00ec5f52"
  :revdesc "6b58a54339fb"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
