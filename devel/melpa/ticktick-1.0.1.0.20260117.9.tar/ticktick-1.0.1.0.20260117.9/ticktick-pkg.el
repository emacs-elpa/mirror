;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ticktick" "1.0.1.0.20260117.9"
  "Sync Org Mode tasks with TickTick."
  '((emacs        "27.1")
    (request      "0.3.0")
    (simple-httpd "1.5.0"))
  :url "https://github.com/polhuang/ticktick.el"
  :commit "b9b6319464bd63c43c5edab1d72e73eea4234093"
  :revdesc "v1.0.1-9-gb9b6319464bd"
  :keywords '("tools" "ticktick" "org" "tasks" "todo"))
