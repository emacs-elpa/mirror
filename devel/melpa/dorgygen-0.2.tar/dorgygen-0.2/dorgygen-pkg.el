;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dorgygen" "0.2"
  "Source code documentation in org-mode."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/dorgygen"
  :commit "84815fda133c15fe967c6f132e146992827de1c9"
  :revdesc "84815fda133c"
  :keywords '("tools" "wp"))
