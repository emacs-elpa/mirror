;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "2.8.0.20260729.11"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "ab922067c58ef88ae69d1c288c35202c5fef2c55"
  :revdesc "2.8-11-gab922067c58e"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
