;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "1.5.0.20260927.8"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "48ae8129ad11135a8905701b9ae7dfa9086cd53a"
  :revdesc "v1.5-8-g48ae8129ad11"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
