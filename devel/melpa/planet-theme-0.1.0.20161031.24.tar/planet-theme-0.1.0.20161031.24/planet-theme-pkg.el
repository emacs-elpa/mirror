;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "planet-theme" "0.1.0.20161031.24"
  "A dark theme inspired by Gmail's 'Planets' theme of yore."
  '((emacs "24"))
  :url "https://github.com/cmack/emacs-planet-theme"
  :commit "b0a310ff36565fe22224c407cf59569986698a32"
  :revdesc "b0a310ff3656"
  :keywords '("themes")
  :authors '(("Charlie McMackin" . "charlie.mac@gmail.com"))
  :maintainers '(("Charlie McMackin" . "charlie.mac@gmail.com")))
