;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-ts-mode" "0.1.5.0.20260701.8"
  "Major mode for Nix expressions, powered by tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nix-community/nix-ts-mode"
  :commit "dcc3948afb8fa56060e63da294e78ede199c1d5d"
  :revdesc "dcc3948afb8f"
  :keywords '("nix" "languages" "tree-sitter")
  :maintainers '(("Remi Gelinas" . "mail@remigelin.as")))
