;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-modern" "1.15.0.20261116.4"
  "Modern looks for Org."
  '((emacs  "29.1")
    (org    "9.6")
    (compat "31"))
  :url "https://github.com/minad/org-modern"
  :commit "5cf5879b0c46218cacbfbd68ac78aa84d1a3abf2"
  :revdesc "1.15-4-g5cf5879b0c46"
  :keywords '("outlines" "hypermedia" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
