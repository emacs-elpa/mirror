;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mqtt-mode" "0.1.0"
  "Client for interaction with MQTT servers."
  '((emacs "25")
    (dash  "2.12.0"))
  :url "https://github.com/andrmuel/mqtt-mode"
  :commit "613e70e9b9940e635e779994b5c83f86eb62c8e6"
  :revdesc "613e70e9b994"
  :keywords '("tools")
  :authors '(("Andreas Müller" . "code@0x7.ch"))
  :maintainers '(("Andreas Müller" . "code@0x7.ch")))
