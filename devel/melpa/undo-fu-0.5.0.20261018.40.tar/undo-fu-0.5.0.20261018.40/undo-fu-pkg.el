;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-fu" "0.5.0.20261018.40"
  "Undo helper with redo."
  '((emacs "25.1"))
  :url "https://codeberg.org/ideasman42/emacs-undo-fu"
  :commit "cf9a342972237d8a25fb7ba9418ec659a4273115"
  :revdesc "cf9a34297223"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
