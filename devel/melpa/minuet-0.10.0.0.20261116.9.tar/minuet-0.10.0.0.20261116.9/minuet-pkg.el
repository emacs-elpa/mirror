;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "0.10.0.0.20261116.9"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "7b9822d97972fd4a936a8ea3826ee8d2f215f5b2"
  :revdesc "7b9822d97972"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
