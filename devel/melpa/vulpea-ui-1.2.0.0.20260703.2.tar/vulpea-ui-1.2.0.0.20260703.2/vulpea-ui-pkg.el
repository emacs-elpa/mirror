;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "1.2.0.0.20260703.2"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.5.0")
    (vui    "1.3.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "e3ccfc6febc827eecc9018ade24299710926b87a"
  :revdesc "v1.2.0-2-ge3ccfc6febc8"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
