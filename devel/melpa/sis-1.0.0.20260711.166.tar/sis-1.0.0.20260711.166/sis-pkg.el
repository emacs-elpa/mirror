;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "1.0.0.20260711.166"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "7ca3e115f159f22ddb4bcea85a22246ee03c422c"
  :revdesc "7ca3e115f159"
  :keywords '("convenience"))
