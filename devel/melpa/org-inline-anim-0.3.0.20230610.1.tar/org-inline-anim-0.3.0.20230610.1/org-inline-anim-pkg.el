;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-inline-anim" "0.3.0.20230610.1"
  "Inline playback of animated GIF/PNG for Org."
  '((emacs "25.3")
    (org   "9.4"))
  :url "https://github.com/shg/org-inline-anim.el"
  :commit "488fed644748b578dffe7e3847970ec25dcfd24d"
  :revdesc "488fed644748"
  :keywords '("org" "outlines" "hypermedia" "multimedia"))
