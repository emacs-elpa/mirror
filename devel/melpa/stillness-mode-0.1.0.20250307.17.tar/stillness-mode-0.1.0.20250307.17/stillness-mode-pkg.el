;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stillness-mode" "0.1.0.20250307.17"
  "Prevent windows from jumping on minibuffer activation."
  '((emacs "26.1")
    (dash  "2.18.0"))
  :url "https://github.com/neeasade/stillness-mode.el"
  :commit "05029febdb451941ed218e6ddbef5294776e31d4"
  :revdesc "05029febdb45"
  :keywords '("convenience"))
