;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbdb" "3.2.0.20231122.40"
  "Big Brother DataBase."
  '((emacs  "24")
    (cl-lib "0.5"))
  :commit "53e8ba04c47b3542db75b68f9663941daf2e6ca4"
  :revdesc "v3.2-40-g53e8ba04c47b"
  :maintainers '(("Roland Winkler" . "winkler@gnu.org")))
