;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.10.0.20260720.18"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "44b926838376626c661e2ddbe9082a0ef097928c"
  :revdesc "2.10-18-g44b926838376"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
