;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-treescope" "0.6"
  "Time scoping sparse trees within org."
  '((emacs  "24.3")
    (org    "9.2.3")
    (org-ql "0.5-pre")
    (dash   "2.17.0"))
  :url "https://github.com/mtekman/org-treescope.el"
  :commit "a7c386ff134c71fd4f1f042e320751f077d57ddb"
  :revdesc "a7c386ff134c"
  :keywords '("outlines"))
