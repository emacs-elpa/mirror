;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-extra-font-lock" "0.0.6"
  "Highlight bound variables and quoted exprs."
  ()
  :url "https://github.com/Lindydancer/lisp-extra-font-lock"
  :commit "4605eccbe1a7fcbd3cacf5b71249435413b4db4f"
  :revdesc "4605eccbe1a7"
  :keywords '("languages" "faces"))
