;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js2-highlight-vars" "0.1.0.0.20170418.8"
  "Highlight occurrences of the variable under cursor."
  '((emacs    "24.4")
    (js2-mode "20150908"))
  :url "http://mihai.bazon.net/projects/editing-javascript-with-emacs-js2-mode/js2-highlight-vars-mode"
  :commit "e3bb177e50f76b272e8073a94d4f46be6512a163"
  :revdesc "v0.1.0-8-ge3bb177e50f7"
  :authors '(("Mihai Bazon" . "mihai.bazon@gmail.com"))
  :maintainers '(("Mihai Bazon" . "mihai.bazon@gmail.com")))
