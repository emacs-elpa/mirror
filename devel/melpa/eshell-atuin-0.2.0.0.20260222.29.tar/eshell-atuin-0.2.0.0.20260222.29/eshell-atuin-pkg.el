;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-atuin" "0.2.0.0.20260222.29"
  "Integrate eshell with atuin, a shell history tool."
  '((emacs  "27.1")
    (compat "29.1.4.1"))
  :url "https://github.com/SqrtMinusOne/eshell-atuin"
  :commit "142536a01a9d6d92d802e41474c290e0ca655deb"
  :revdesc "142536a01a9d"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
