;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smilefjes" "0.0.1.0.20240826.16"
  "View Norwegian Food Safety Authority restaurant ratings."
  '((emacs   "24.4")
    (request "0.3.2")
    (ht      "2.3")
    (dash    "2.19.1")
    (helm    "3.8.6"))
  :url "https://github.com/themkat/smilefjes.el"
  :commit "c7e4ebb06215e67e8bdd8299b4cc7405fc861f5b"
  :revdesc "c7e4ebb06215")
