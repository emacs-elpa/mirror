;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.13"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "6477aac54fa1ea4865b23d7562e48b83a082a1e4"
  :revdesc "2.13-0-g6477aac54fa1"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
