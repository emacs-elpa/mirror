;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tern" "0.24.3.0.20260514.6"
  "Tern-powered JavaScript integration."
  '((json   "1.2")
    (cl-lib "0.5")
    (emacs  "24"))
  :url "http://ternjs.github.io/"
  :commit "fab80daebd798b233a9a40d5a8b99359ace63b5e"
  :revdesc "fab80daebd79")
