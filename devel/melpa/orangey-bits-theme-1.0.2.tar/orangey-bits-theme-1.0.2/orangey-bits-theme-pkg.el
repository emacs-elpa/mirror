;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orangey-bits-theme" "1.0.2"
  "A Theme with smashing orangey bits."
  '((autothemer "0.2")
    (emacs      "27.1"))
  :url "https://github.com/emacsfodder/emacs-theme-orangey-bits"
  :commit "533856d399cb4098300bcaf4a2d20920395746f8"
  :revdesc "533856d399cb"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
