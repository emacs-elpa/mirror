;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keypress-multi-event" "1.0.0.20250313.3"
  "Perform different actions for the same keypress."
  '((emacs "24.3"))
  :url "https://www.github.com/Boruch-Baum/emacs-keypress-multi-event"
  :commit "8c31b75f6ef4d81d5625e91a4130e204bfd02dd3"
  :revdesc "8c31b75f6ef4"
  :keywords '("abbrev" "convenience" "wp" "keyboard")
  :authors '(("Boruch Baum" . "boruch_baum@gmx.com"))
  :maintainers '(("Boruch Baum" . "boruch_baum@gmx.com")))
