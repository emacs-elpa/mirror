;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-go" "2013.3.14.0.20150714.3"
  "A flymake handler for go-mode files."
  ()
  :url "https://github.com/robert-zaremba/flymake-go"
  :commit "ae83761aa908c1a50ff34af04f00dcc46bca2ce9"
  :revdesc "ae83761aa908"
  :keywords '("go" "flymake")
  :authors '(("Michael Fellinger" . "michael@iron.io")
             ("Robert Zaremba" . "robert.marek.zaremba@wp.eu"))
  :maintainers '(("Michael Fellinger" . "michael@iron.io")
                 ("Robert Zaremba" . "robert.marek.zaremba@wp.eu")))
