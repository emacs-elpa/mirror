;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-seq" "1.0.1.0.20260915.4"
  "Map pairs of sequentially pressed keys to commands."
  '((key-chord "0.6"))
  :url "https://github.com/vlevit/key-seq.el"
  :commit "f16103e00caa0fe250c64f690a19b662e011012f"
  :revdesc "f16103e00caa"
  :keywords '("convenience" "keyboard" "keybindings")
  :authors '(("Vyacheslav Levit" . "dev@vlevit.org"))
  :maintainers '(("Vyacheslav Levit" . "dev@vlevit.org")))
