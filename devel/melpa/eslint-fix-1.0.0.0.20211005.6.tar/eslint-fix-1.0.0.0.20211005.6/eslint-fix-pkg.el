;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eslint-fix" "1.0.0.0.20211005.6"
  "Fix JavaScript files using ESLint."
  ()
  :url "https://github.com/codesuki/eslint-fix"
  :commit "636bf8d8797bdd58f1b543c9d3f4910e3ce879ab"
  :revdesc "1.0.0-6-g636bf8d8797b"
  :keywords '("tools" "javascript" "eslint" "lint" "formatting" "style")
  :authors '(("Neri Marschik" . "marschik_neri@cyberagent.co.jp"))
  :maintainers '(("Neri Marschik" . "marschik_neri@cyberagent.co.jp")))
