;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paredit" "26.0.20241103.17"
  "Minor mode for editing parentheses."
  ()
  :url "https://paredit.org"
  :commit "89e75b4cb21f525a6f4cabcd12f1bd4204e682ab"
  :revdesc "v26-17-g89e75b4cb21f"
  :keywords '("lisp")
  :authors '(("Taylor R. Campbell" . "campbell@paredit.org"))
  :maintainers '(("Taylor R. Campbell" . "campbell@paredit.org")))
