;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-command-redo" "0.1.0.20260706.4"
  "Repeat commands with automatic undo."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-with-command-redo"
  :commit "2996eef7ff22046c71c1ea294fc06391a9d4e25c"
  :revdesc "2996eef7ff22"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
