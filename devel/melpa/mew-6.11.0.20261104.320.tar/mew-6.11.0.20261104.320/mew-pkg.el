;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20261104.320"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "8b0c60eb5e80dca5126d6b6913db883b8c3eeec3"
  :revdesc "8b0c60eb5e80")
