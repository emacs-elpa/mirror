;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "load-bash-alias" "0.0.3.0.20240103.24"
  "Convert bash aliases into eshell ones."
  '((emacs "24.1")
    (seq   "2.16"))
  :url "https://github.com/daviderestivo/load-bash-alias"
  :commit "7e7b6773f99e6aafe819596388a3a7fd09dd91a9"
  :revdesc "7e7b6773f99e"
  :keywords '("emacs" "bash" "eshell" "alias")
  :authors '(("Davide Restivo" . "davide.restivo@yahoo.it"))
  :maintainers '(("Davide Restivo" . "davide.restivo@yahoo.it")))
