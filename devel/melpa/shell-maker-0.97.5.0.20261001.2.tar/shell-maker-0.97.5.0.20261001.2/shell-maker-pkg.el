;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.97.5.0.20261001.2"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "dcc05a8cf24eb62f2f611fd2d009a161fada5f6e"
  :revdesc "dcc05a8cf24e")
