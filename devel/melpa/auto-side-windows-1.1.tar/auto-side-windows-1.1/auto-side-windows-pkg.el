;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-side-windows" "1.1"
  "Simplified buffer management for side windows."
  '((emacs "30.1"))
  :url "https://github.com/MArpogaus/auto-side-windows"
  :commit "fb63e3a279c79dc5bc0953903e15840a6f8cf146"
  :revdesc "v1.1-0-gfb63e3a279c7"
  :keywords '("convenience" "windows" "buffers")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
