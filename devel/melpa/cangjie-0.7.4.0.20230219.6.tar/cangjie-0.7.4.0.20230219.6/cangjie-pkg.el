;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cangjie" "0.7.4.0.20230219.6"
  "Retrieve cangjie code for han characters."
  '((emacs "24.4")
    (s     "1.12.0")
    (dash  "2.14.1")
    (f     "0.2.0"))
  :url "https://github.com/kisaragi-hiu/cangjie.el"
  :commit "d6882e15f47fdde37e9f739dde604d77d25f11db"
  :revdesc "d6882e15f47f"
  :keywords '("convenience" "writing")
  :authors '(("Kisaragi Hiu" . "mail@kisaragi-hiu.com"))
  :maintainers '(("Kisaragi Hiu" . "mail@kisaragi-hiu.com")))
