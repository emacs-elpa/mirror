;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-stan" "10.2.0.0.20211129.31"
  "A company-mode completion backend for stan."
  '((emacs     "24.3")
    (company   "0.9.10")
    (stan-mode "10.3.0"))
  :url "https://github.com/stan-dev/stan-mode/tree/master/company-stan"
  :commit "150bbbe5fd3ad2b5a3dbfba9d291e66eeea1a581"
  :revdesc "150bbbe5fd3a"
  :keywords '("languages")
  :authors '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu"))
  :maintainers '(("Kazuki Yoshida" . "kazukiyoshida@mail.harvard.edu")))
