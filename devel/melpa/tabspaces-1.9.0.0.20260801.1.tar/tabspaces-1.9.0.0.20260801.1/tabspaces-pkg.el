;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "1.9.0.0.20260801.1"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://codeberg.org/mclear-tools/tabspaces"
  :commit "358790847e4e0791eb5db6870215fe2415f3300a"
  :revdesc "358790847e4e"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
