;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kagi" "0.6.0.20240811.5"
  "Kagi API integration."
  '((emacs         "29.1")
    (markdown-mode "2.6")
    (shell-maker   "0.46.1"))
  :url "https://codeberg.org/bram85/kagi.el"
  :commit "013749218495e2c1bf2bb203c6b61976963817b5"
  :revdesc "0.6-5-g013749218495"
  :keywords '("terminals" "wp")
  :authors '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers '(("Bram Schoenmakers" . "me@bramschoenmakers.nl")))
