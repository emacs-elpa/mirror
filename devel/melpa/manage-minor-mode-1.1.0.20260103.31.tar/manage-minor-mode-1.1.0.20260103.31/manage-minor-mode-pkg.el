;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "manage-minor-mode" "1.1.0.20260103.31"
  "Manage your minor-modes easily."
  '((emacs "24.3"))
  :url "https://github.com/ShingoFukuyama/manage-minor-mode"
  :commit "78ca421b501aa1f6b72a4ecdb9a1fe102055beed"
  :revdesc "78ca421b501a"
  :keywords '("tools" "minor-mode" "manage" "emacs")
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
