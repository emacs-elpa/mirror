;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "merlin" "5.9"
  "Mode for Merlin, an assistant for OCaml."
  '((emacs "25.1"))
  :url "https://github.com/ocaml/merlin"
  :commit "55fbf4bf27429a1b1e4a32295a9cdd54d470b534"
  :revdesc "v5.9-0-g55fbf4bf2742"
  :keywords '("ocaml" "languages")
  :authors '(("Frédéric Bour" . "frederic.bourlakaban.net"))
  :maintainers '(("Frédéric Bour" . "frederic.bourlakaban.net")))
