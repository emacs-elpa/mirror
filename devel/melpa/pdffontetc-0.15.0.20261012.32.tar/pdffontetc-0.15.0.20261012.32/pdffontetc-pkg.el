;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdffontetc" "0.15.0.20261012.32"
  "Display `pdffont' and other PDF information."
  '((emacs     "24.4")
    (pdf-tools "1.2.0"))
  :url "https://github.com/emacsomancer/pdffontetc"
  :commit "dd7cc5409892dfccecfcb2a43144bce63a220be5"
  :revdesc "dd7cc5409892"
  :keywords '("files" "multimedia")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
