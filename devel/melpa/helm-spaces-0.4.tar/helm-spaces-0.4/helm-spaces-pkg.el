;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-spaces" "0.4"
  "Helm sources for spaces."
  '((helm-core "2.2")
    (spaces    "0.1.0"))
  :url "https://github.com/yasuyk/helm-spaces"
  :commit "877e2b5178926308d6a7c2a37477bb12c33a96d4"
  :revdesc "877e2b517892"
  :keywords '("helm" "frames" "convenience")
  :authors '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
