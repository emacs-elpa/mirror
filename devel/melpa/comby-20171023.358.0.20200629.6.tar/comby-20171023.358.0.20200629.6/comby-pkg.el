;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comby" "20171023.358.0.20200629.6"
  "Emacs comby integration."
  '((emacs "25.1"))
  :url "https://github.com/s-kostyaev/comby.el"
  :commit "928b8b8959a2556aba5526f2a25801341eb59dc3"
  :revdesc "928b8b8959a2"
  :keywords '("languages")
  :authors '(("Sergey Kostyaev" . "feo.me@ya.ru"))
  :maintainers '(("Sergey Kostyaev" . "feo.me@ya.ru")))
