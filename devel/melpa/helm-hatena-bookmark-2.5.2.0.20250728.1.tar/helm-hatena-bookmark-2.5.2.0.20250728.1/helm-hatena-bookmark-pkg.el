;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-hatena-bookmark" "2.5.2.0.20250728.1"
  "Helm interface for Hatena::Bookmark."
  '((emacs "24")
    (helm  "2.8.2"))
  :url "https://github.com/masutaka/emacs-helm-hatena-bookmark"
  :commit "9692659fefcb4e1a6519a0072a8bf6d766419f6b"
  :revdesc "2.5.2-1-g9692659fefcb"
  :authors '(("Takashi Masuda" . "masutaka.net@gmail.com"))
  :maintainers '(("Takashi Masuda" . "masutaka.net@gmail.com")))
