;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "0.4.0.20261109.17"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "f3fd12df6bf5211087aa57d698be235e7b95ef08"
  :revdesc "f3fd12df6bf5"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
