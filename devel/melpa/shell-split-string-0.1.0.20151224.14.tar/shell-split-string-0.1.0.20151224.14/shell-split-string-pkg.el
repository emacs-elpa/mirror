;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-split-string" "0.1.0.20151224.14"
  "Split strings using shell-like syntax."
  ()
  :url "https://github.com/10sr/shell-split-string-el"
  :commit "19f6f999c33cc66a4c91bacdcc3697c25d97bf5a"
  :revdesc "19f6f999c33c"
  :keywords '("utility" "library" "shell" "string")
  :authors '(("10sr" . "8.slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8.slashes+el[at]gmail[dot]com")))
