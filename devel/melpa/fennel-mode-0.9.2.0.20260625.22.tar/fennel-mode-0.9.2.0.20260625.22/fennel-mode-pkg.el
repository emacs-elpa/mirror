;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fennel-mode" "0.9.2.0.20260625.22"
  "A major-mode for editing Fennel code."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~technomancy/fennel-mode"
  :commit "0a672d41be405570209e8fafca738162b4ac7111"
  :revdesc "0.9.2-22-g0a672d41be40"
  :keywords '("languages" "tools"))
