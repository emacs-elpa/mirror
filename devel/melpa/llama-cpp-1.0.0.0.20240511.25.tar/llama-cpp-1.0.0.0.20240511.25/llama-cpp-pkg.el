;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llama-cpp" "1.0.0.0.20240511.25"
  "A client for llama-cpp server."
  '((emacs "27.1")
    (dash  "2.19.1"))
  :url "https://github.com/kurnevsky/llama.el"
  :commit "5cea3698aa63921b21888f126cae4f3ebc1baa39"
  :revdesc "5cea3698aa63"
  :keywords '("tools")
  :authors '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com")))
