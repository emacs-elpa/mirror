;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "w32-browser" "235.0.20170101.4"
  "Run Windows application associated with a file."
  ()
  :url "http://www.emacswiki.org/w32-browser.el"
  :commit "e5c60eafd8f8d3546a0fa295ad5af2414d36b4e6"
  :revdesc "e5c60eafd8f8"
  :keywords '("mouse" "dired" "w32" "explorer")
  :maintainers '(("Drew Adams (concat \"drew.adams\" \"oracle\" \".com\"" . "\"@\" ")))
