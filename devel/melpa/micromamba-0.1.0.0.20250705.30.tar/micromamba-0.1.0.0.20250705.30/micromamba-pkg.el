;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "micromamba" "0.1.0.0.20250705.30"
  "A library for working with micromamba environments."
  '((emacs    "27.1")
    (pythonic "0.1.0"))
  :url "https://github.com/SqrtMinusOne/micromamba.el"
  :commit "f0cc31ea2e3d64e1055a8c63700f373a389dc4c0"
  :revdesc "f0cc31ea2e3d"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
