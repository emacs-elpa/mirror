;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3.0.20260810.37"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "816e1571ed530b41fcef102cd6d9974c4343eb7d"
  :revdesc "816e1571ed53"
  :keywords '("build tools" "languages"))
