;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "network-watch" "1.0.0.20171123.17"
  "Support for intermittent network connectivity."
  '((emacs "24.3"))
  :url "https://github.com/jamiguet/network-watch"
  :commit "d80b38dbec79f813c3949a8df8fb5f58d48b60ee"
  :revdesc "d80b38dbec79"
  :keywords '("unix" "tools" "hardware" "lisp")
  :authors '(("Juan Amiguet Vercher" . "jamiguet@gmail.com"))
  :maintainers '(("Juan Amiguet Vercher" . "jamiguet@gmail.com")))
