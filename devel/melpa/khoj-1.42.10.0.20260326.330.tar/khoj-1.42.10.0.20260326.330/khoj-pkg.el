;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "khoj" "1.42.10.0.20260326.330"
  "Your Second Brain."
  '((emacs     "27.1")
    (transient "0.3.0")
    (dash      "2.19.1"))
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs"
  :commit "9258f57dceab19d52a1a0bdac54eb38576c29187"
  :revdesc "9258f57dceab"
  :keywords '("search" "chat" "ai" "org-mode" "outlines" "markdown" "pdf" "image")
  :authors '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
             ("Saba Imran" . "saba@khoj.dev"))
  :maintainers '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
                 ("Saba Imran" . "saba@khoj.dev")))
