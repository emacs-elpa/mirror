;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "2.3.1.0.20261126.14"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "4a3aaba3c98f7cf08e643de0253c7b82a7592f23"
  :revdesc "4a3aaba3c98f"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
