;;; mistty-eterm.el --- Use term.el to create the terminal -*- lexical-binding: t -*-

;; This program is free software: you can redistribute it and/or
;; modify it under the terms of the GNU General Public License as
;; published by the Free Software Foundation; either version 3 of the
;; License, or (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
;; General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see
;; `http://www.gnu.org/licenses/'.

;;; Commentary:
;;
;; This file implements generic methods defined in mistty-term.el
;; on top of mistty-alacritty.el The resulting terminal is an alacritty
;; terminal (TERM=eterm).

(require 'cl-lib)
(require 'term)
;;; Code:

(defvar term-width) ; defined in term.el
(defvar term-height) ; defined in term.el
(defvar term-home-marker) ; defined in term.el

(require 'mistty-custom)
(require 'mistty-term)
(require 'mistty-prompt)
(require 'mistty-accum)
(require 'mistty-scrolline)
(require 'mistty-sync)
(require 'mistty-util)
(eval-when-compile
  (require 'mistty-accum-macros))

(autoload 'mistty-osc7 "mistty-osc7")
(autoload 'mistty-osc-query-color "mistty-osc-colors")
(autoload 'ansi-osc-window-title-handler "ansi-osc")
(autoload 'ansi-osc-hyperlink-handler "ansi-osc")

(define-obsolete-variable-alias
  'mistty-fullscreen-map 'mistty-fullscreen-mode-map "1.5.1snapshot")
(define-obsolete-variable-alias
  'mistty-term-mode-map 'mistty-fullscreen-mode-map "2.3")

(defvar mistty--eterm-key-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "<escape>") "\e")
    (define-key map (kbd "<tab>") "\t")
    (define-key map (kbd "<return>") "\C-m")
    (define-key map (kbd "<backspace>") "\C-?")
    (define-key map (kbd "<delete>") "\C-d")

    ;; The following is a reversed copy of xterm-function-map from
    ;; term/xterm. Simulating xterm keys is generally convenient, as
    ;; most command-line tools support xterm.
    (define-key map (kbd "<down>") "\eOB")
    (define-key map (kbd "<end>") "\eOF")
    (define-key map (kbd "<f10>") "\e[21~")
    (define-key map (kbd "<f11>") "\e[23~")
    (define-key map (kbd "<f12>") "\e[24~")
    (define-key map (kbd "<f1>") "\eOP")
    (define-key map (kbd "<f2>") "\eOQ")
    (define-key map (kbd "<f3>") "\eOR")
    (define-key map (kbd "<f4>") "\eOS")
    (define-key map (kbd "<f5>") "\e[15~")
    (define-key map (kbd "<f6>") "\e[17~")
    (define-key map (kbd "<f7>") "\e[18~")
    (define-key map (kbd "<f8>") "\e[19~")
    (define-key map (kbd "<f9>") "\e[20~")
    (define-key map (kbd "<home>") "\e[1~")
    (define-key map (kbd "<insert>") "\e[2~")
    (define-key map (kbd "<kp-0>") "\eOp")
    (define-key map (kbd "<kp-1>") "\eOq")
    (define-key map (kbd "<kp-2>") "\eOr")
    (define-key map (kbd "<kp-3>") "\eOs")
    (define-key map (kbd "<kp-4>") "\eOt")
    (define-key map (kbd "<kp-5>") "\eOu")
    (define-key map (kbd "<kp-6>") "\eOv")
    (define-key map (kbd "<kp-7>") "\eOw")
    (define-key map (kbd "<kp-8>") "\eOx")
    (define-key map (kbd "<kp-9>") "\eOy")
    (define-key map (kbd "<kp-add>") "\eOk")
    (define-key map (kbd "<kp-divide>") "\eOo")
    (define-key map (kbd "<kp-equal>") "\eOX")
    (define-key map (kbd "<kp-multiply>") "\eOj")
    (define-key map (kbd "<kp-separator>") "\eOl")
    (define-key map (kbd "<kp-subtract>") "\eOm")
    (define-key map (kbd "<left>") "\eOD")
    (define-key map (kbd "<menu>") "\e[29~")
    (define-key map (kbd "<next>") "\e[6~")
    (define-key map (kbd "<prior>") "\e[5~")
    (define-key map (kbd "<right>") "\eOC")
    (define-key map (kbd "<select>") "\e[4~")
    (define-key map (kbd "<up>") "\eOA")
    (define-key map (kbd "C-!") "\e[33;6u")
    (define-key map (kbd "C-#") "\e[35;6u")
    (define-key map (kbd "C-$") "\e[36;6u")
    (define-key map (kbd "C-%") "\e[37;6u")
    (define-key map (kbd "C-&") "\e[38;6u")
    (define-key map (kbd "C-'") "\e[39;5u")
    (define-key map (kbd "C-(") "\e[40;6u")
    (define-key map (kbd "C-)") "\e[41;6u")
    (define-key map (kbd "C-*") "\e[42;6u")
    (define-key map (kbd "C-+") "\e[43;6u")
    (define-key map (kbd "C-,") "\e[44;5u")
    (define-key map (kbd "C--") "\e[45;5u")
    (define-key map (kbd "C-.") "\e[46;5u")
    (define-key map (kbd "C-/") "\e[47;5u")
    (define-key map (kbd "C-0") "\e[48;5u")
    (define-key map (kbd "C-1") "\e[49;5u")
    (define-key map (kbd "C-9") "\e[57;5u")
    (define-key map (kbd "C-:") "\e[58;6u")
    (define-key map (kbd "C-;") "\e[59;5u")
    (define-key map (kbd "C-<") "\e[60;6u")
    (define-key map (kbd "C-<delete>") "\e[3;5~")
    (define-key map (kbd "C-<down>") "\e[1;5B")
    (define-key map (kbd "C-<end>") "\e[1;5F")
    (define-key map (kbd "C-<f10>") "\e[21;5~")
    (define-key map (kbd "C-<f11>") "\e[23;5~")
    (define-key map (kbd "C-<f12>") "\e[24;5~")
    (define-key map (kbd "C-<f1>") "\eO5P")
    (define-key map (kbd "C-<f2>") "\eO5Q")
    (define-key map (kbd "C-<f3>") "\eO5R")
    (define-key map (kbd "C-<f4>") "\eO5S")
    (define-key map (kbd "C-<f5>") "\e[15;5~")
    (define-key map (kbd "C-<f6>") "\e[17;5~")
    (define-key map (kbd "C-<f7>") "\e[18;5~")
    (define-key map (kbd "C-<f8>") "\e[19;5~")
    (define-key map (kbd "C-<f9>") "\e[20;5~")
    (define-key map (kbd "C-<home>") "\e[1;5H")
    (define-key map (kbd "C-<insert>") "\e[2;5~")
    (define-key map (kbd "C-<left>") "\e[1;5D")
    (define-key map (kbd "C-<next>") "\e[6;5~")
    (define-key map (kbd "C-<prior>") "\e[5;5~")
    (define-key map (kbd "C-<return>") "\e[13;5u")
    (define-key map (kbd "C-<right>") "\e[1;5C")
    (define-key map (kbd "C-<tab>") "\e[9;5u")
    (define-key map (kbd "C-<up>") "\e[1;5A")
    (define-key map (kbd "C-=") "\e[61;5u")
    (define-key map (kbd "C->") "\e[62;6u")
    (define-key map (kbd "C-?") "\e[63;6u")
    (define-key map (kbd "C-M-!") "\e[33;8u")
    (define-key map (kbd "C-M-#") "\e[35;8u")
    (define-key map (kbd "C-M-$") "\e[36;8u")
    (define-key map (kbd "C-M-%") "\e[37;8u")
    (define-key map (kbd "C-M-&") "\e[38;8u")
    (define-key map (kbd "C-M-'") "\e[39;7u")
    (define-key map (kbd "C-M-(") "\e[40;8u")
    (define-key map (kbd "C-M-)") "\e[41;8u")
    (define-key map (kbd "C-M-*") "\e[42;8u")
    (define-key map (kbd "C-M-+") "\e[43;8u")
    (define-key map (kbd "C-M-,") "\e[44;7u")
    (define-key map (kbd "C-M--") "\e[45;7u")
    (define-key map (kbd "C-M-.") "\e[46;7u")
    (define-key map (kbd "C-M-/") "\e[47;7u")
    (define-key map (kbd "C-M-0") "\e[48;7u")
    (define-key map (kbd "C-M-1") "\e[49;7u")
    (define-key map (kbd "C-M-2") "\e[50;7u")
    (define-key map (kbd "C-M-3") "\e[51;7u")
    (define-key map (kbd "C-M-4") "\e[52;7u")
    (define-key map (kbd "C-M-5") "\e[53;7u")
    (define-key map (kbd "C-M-6") "\e[54;7u")
    (define-key map (kbd "C-M-7") "\e[55;7u")
    (define-key map (kbd "C-M-8") "\e[56;7u")
    (define-key map (kbd "C-M-9") "\e[57;7u")
    (define-key map (kbd "C-M-:") "\e[58;8u")
    (define-key map (kbd "C-M-;") "\e[59;7u")
    (define-key map (kbd "C-M-<") "\e[60;8u")
    (define-key map (kbd "C-M-<delete>") "\e[3;7~")
    (define-key map (kbd "C-M-<down>") "\e[1;7B")
    (define-key map (kbd "C-M-<end>") "\e[1;7F")
    (define-key map (kbd "C-M-<home>") "\e[1;7H")
    (define-key map (kbd "C-M-<insert>") "\e[2;7~")
    (define-key map (kbd "C-M-<left>") "\e[1;7D")
    (define-key map (kbd "C-M-<next>") "\e[6;7~")
    (define-key map (kbd "C-M-<prior>") "\e[5;7~")
    (define-key map (kbd "C-M-<return>") "\e[13;7u")
    (define-key map (kbd "C-M-<right>") "\e[1;7C")
    (define-key map (kbd "C-M-<tab>") "\e[9;7u")
    (define-key map (kbd "C-M-<up>") "\e[1;7A")
    (define-key map (kbd "C-M-=") "\e[61;7u")
    (define-key map (kbd "C-M->") "\e[62;8u")
    (define-key map (kbd "C-M-?") "\e[63;8u")
    (define-key map (kbd "C-M-S-<delete>") "\e[3;8~")
    (define-key map (kbd "C-M-S-<down>") "\e[1;8B")
    (define-key map (kbd "C-M-S-<end>") "\e[1;8F")
    (define-key map (kbd "C-M-S-<home>") "\e[1;8H")
    (define-key map (kbd "C-M-S-<insert>") "\e[2;8~")
    (define-key map (kbd "C-M-S-<kp-0>") "\eO8p")
    (define-key map (kbd "C-M-S-<kp-1>") "\eO8q")
    (define-key map (kbd "C-M-S-<kp-2>") "\eO8r")
    (define-key map (kbd "C-M-S-<kp-3>") "\eO8s")
    (define-key map (kbd "C-M-S-<kp-4>") "\eO8t")
    (define-key map (kbd "C-M-S-<kp-5>") "\eO8u")
    (define-key map (kbd "C-M-S-<kp-6>") "\eO8v")
    (define-key map (kbd "C-M-S-<kp-7>") "\eO8w")
    (define-key map (kbd "C-M-S-<kp-8>") "\eO8x")
    (define-key map (kbd "C-M-S-<kp-9>") "\eO8y")
    (define-key map (kbd "C-M-S-<kp-add>") "\eO8k")
    (define-key map (kbd "C-M-S-<kp-divide>") "\eO8o")
    (define-key map (kbd "C-M-S-<kp-multiply>") "\eO8j")
    (define-key map (kbd "C-M-S-<kp-separator>") "\eO8l")
    (define-key map (kbd "C-M-S-<kp-subtract>") "\eO8m")
    (define-key map (kbd "C-M-S-<left>") "\e[1;8D")
    (define-key map (kbd "C-M-S-<next>") "\e[6;8~")
    (define-key map (kbd "C-M-S-<prior>") "\e[5;8~")
    (define-key map (kbd "C-M-S-<right>") "\e[1;8C")
    (define-key map (kbd "C-M-S-<up>") "\e[1;8A")
    (define-key map (kbd "C-M-SPC") "\e[32;7u")
    (define-key map (kbd "C-M-\"") "\e[34;8u")
    (define-key map (kbd "C-M-\\") "\e[92;7u")
    (define-key map (kbd "C-S-<delete>") "\e[3;6~")
    (define-key map (kbd "C-S-<down>") "\e[1;6B")
    (define-key map (kbd "C-S-<end>") "\e[1;6F")
    (define-key map (kbd "C-S-<f10>") "\e[21;6~")
    (define-key map (kbd "C-S-<f11>") "\e[23;6~")
    (define-key map (kbd "C-S-<f12>") "\e[24;6~")
    (define-key map (kbd "C-S-<f1>") "\eO6P")
    (define-key map (kbd "C-S-<f2>") "\eO6Q")
    (define-key map (kbd "C-S-<f3>") "\eO6R")
    (define-key map (kbd "C-S-<f4>") "\eO6S")
    (define-key map (kbd "C-S-<f5>") "\e[15;6~")
    (define-key map (kbd "C-S-<f6>") "\e[17;6~")
    (define-key map (kbd "C-S-<f7>") "\e[18;6~")
    (define-key map (kbd "C-S-<f8>") "\e[19;6~")
    (define-key map (kbd "C-S-<f9>") "\e[20;6~")
    (define-key map (kbd "C-S-<home>") "\e[1;6H")
    (define-key map (kbd "C-S-<insert>") "\e[2;6~")
    (define-key map (kbd "C-S-<kp-0>") "\eO6p")
    (define-key map (kbd "C-S-<kp-1>") "\eO6q")
    (define-key map (kbd "C-S-<kp-2>") "\eO6r")
    (define-key map (kbd "C-S-<kp-3>") "\eO6s")
    (define-key map (kbd "C-S-<kp-4>") "\eO6t")
    (define-key map (kbd "C-S-<kp-5>") "\eO6u")
    (define-key map (kbd "C-S-<kp-6>") "\eO6v")
    (define-key map (kbd "C-S-<kp-7>") "\eO6w")
    (define-key map (kbd "C-S-<kp-8>") "\eO6x")
    (define-key map (kbd "C-S-<kp-9>") "\eO6y")
    (define-key map (kbd "C-S-<kp-add>") "\eO6k")
    (define-key map (kbd "C-S-<kp-divide>") "\eO6o")
    (define-key map (kbd "C-S-<kp-multiply>") "\eO6j")
    (define-key map (kbd "C-S-<kp-separator>") "\eO6l")
    (define-key map (kbd "C-S-<kp-subtract>") "\eO6m")
    (define-key map (kbd "C-S-<left>") "\e[1;6D")
    (define-key map (kbd "C-S-<next>") "\e[6;6~")
    (define-key map (kbd "C-S-<prior>") "\e[5;6~")
    (define-key map (kbd "C-S-<return>") "\e[13;6u")
    (define-key map (kbd "C-S-<right>") "\e[1;6C")
    (define-key map (kbd "C-S-<tab>") "\e[9;6u")
    (define-key map (kbd "C-S-<up>") "\e[1;6A")
    (define-key map (kbd "C-\"") "\e[34;6u")
    (define-key map (kbd "C-\\") "\e[92;5u")
    (define-key map (kbd "M-<delete>") "\e[3;3~")
    (define-key map (kbd "M-<down>") "\e[1;3B")
    (define-key map (kbd "M-<end>") "\e[1;3F")
    (define-key map (kbd "M-<f10>") "\e[21;3~")
    (define-key map (kbd "M-<f11>") "\e[23;3~")
    (define-key map (kbd "M-<f12>") "\e[24;3~")
    (define-key map (kbd "M-<f1>") "\eO3P")
    (define-key map (kbd "M-<f2>") "\eO3Q")
    (define-key map (kbd "M-<f3>") "\eO3R")
    (define-key map (kbd "M-<f4>") "\eO3S")
    (define-key map (kbd "M-<f5>") "\e[15;3~")
    (define-key map (kbd "M-<f6>") "\e[17;3~")
    (define-key map (kbd "M-<f7>") "\e[18;3~")
    (define-key map (kbd "M-<f8>") "\e[19;3~")
    (define-key map (kbd "M-<f9>") "\e[20;3~")
    (define-key map (kbd "M-<home>") "\e[1;3H")
    (define-key map (kbd "M-<insert>") "\e[2;3~")
    (define-key map (kbd "M-<left>") "\e[1;3D")
    (define-key map (kbd "M-<next>") "\e[6;3~")
    (define-key map (kbd "M-<prior>") "\e[5;3~")
    (define-key map (kbd "M-<right>") "\e[1;3C")
    (define-key map (kbd "M-<up>") "\e[1;3A")
    (define-key map (kbd "M-S-<delete>") "\e[3;4~")
    (define-key map (kbd "M-S-<down>") "\e[1;4B")
    (define-key map (kbd "M-S-<end>") "\e[1;4F")
    (define-key map (kbd "M-S-<f10>") "\e[21;4~")
    (define-key map (kbd "M-S-<f11>") "\e[23;4~")
    (define-key map (kbd "M-S-<f12>") "\e[24;4~")
    (define-key map (kbd "M-S-<f1>") "\eO4P")
    (define-key map (kbd "M-S-<f2>") "\eO4Q")
    (define-key map (kbd "M-S-<f3>") "\eO4R")
    (define-key map (kbd "M-S-<f4>") "\eO4S")
    (define-key map (kbd "M-S-<f5>") "\e[15;4~")
    (define-key map (kbd "M-S-<f6>") "\e[17;4~")
    (define-key map (kbd "M-S-<f7>") "\e[18;4~")
    (define-key map (kbd "M-S-<f8>") "\e[19;4~")
    (define-key map (kbd "M-S-<f9>") "\e[20;4~")
    (define-key map (kbd "M-S-<home>") "\e[1;4H")
    (define-key map (kbd "M-S-<insert>") "\e[2;4~")
    (define-key map (kbd "M-S-<kp-0>") "\eO4p")
    (define-key map (kbd "M-S-<kp-1>") "\eO4q")
    (define-key map (kbd "M-S-<kp-2>") "\eO4r")
    (define-key map (kbd "M-S-<kp-3>") "\eO4s")
    (define-key map (kbd "M-S-<kp-4>") "\eO4t")
    (define-key map (kbd "M-S-<kp-5>") "\eO4u")
    (define-key map (kbd "M-S-<kp-6>") "\eO4v")
    (define-key map (kbd "M-S-<kp-7>") "\eO4w")
    (define-key map (kbd "M-S-<kp-8>") "\eO4x")
    (define-key map (kbd "M-S-<kp-9>") "\eO4y")
    (define-key map (kbd "M-S-<kp-add>") "\eO4k")
    (define-key map (kbd "M-S-<kp-divide>") "\eO4o")
    (define-key map (kbd "M-S-<kp-multiply>") "\eO4j")
    (define-key map (kbd "M-S-<kp-separator>") "\eO4l")
    (define-key map (kbd "M-S-<kp-subtract>") "\eO4m")
    (define-key map (kbd "M-S-<left>") "\e[1;4D")
    (define-key map (kbd "M-S-<next>") "\e[6;4~")
    (define-key map (kbd "M-S-<prior>") "\e[5;4~")
    (define-key map (kbd "M-S-<right>") "\e[1;4C")
    (define-key map (kbd "M-S-<up>") "\e[1;4A")
    (define-key map (kbd "S-<delete>") "\e[3;2~")
    (define-key map (kbd "S-<down>") "\e[1;2B")
    (define-key map (kbd "S-<end>") "\e[1;2F")
    (define-key map (kbd "S-<f10>") "\e[21;2~")
    (define-key map (kbd "S-<f11>") "\e[23;2~")
    (define-key map (kbd "S-<f12>") "\e[24;2~")
    (define-key map (kbd "S-<f1>") "\e[1;2P")
    (define-key map (kbd "S-<f2>") "\e[1;2Q")
    (define-key map (kbd "S-<f3>") "\e[1;2R")
    (define-key map (kbd "S-<f4>") "\e[1;2S")
    (define-key map (kbd "S-<f5>") "\e[15;2~")
    (define-key map (kbd "S-<f6>") "\e[17;2~")
    (define-key map (kbd "S-<f7>") "\e[18;2~")
    (define-key map (kbd "S-<f8>") "\e[19;2~")
    (define-key map (kbd "S-<f9>") "\e[20;2~")
    (define-key map (kbd "S-<home>") "\e[1;2H")
    (define-key map (kbd "S-<insert>") "\e[2;2~")
    (define-key map (kbd "S-<kp-0>") "\eO2p")
    (define-key map (kbd "S-<kp-1>") "\eO2q")
    (define-key map (kbd "S-<kp-2>") "\eO2r")
    (define-key map (kbd "S-<kp-3>") "\eO2s")
    (define-key map (kbd "S-<kp-4>") "\eO2t")
    (define-key map (kbd "S-<kp-5>") "\eO2u")
    (define-key map (kbd "S-<kp-6>") "\eO2v")
    (define-key map (kbd "S-<kp-7>") "\eO2w")
    (define-key map (kbd "S-<kp-8>") "\eO2x")
    (define-key map (kbd "S-<kp-9>") "\eO2y")
    (define-key map (kbd "S-<kp-add>") "\eO2k")
    (define-key map (kbd "S-<kp-divide>") "\eO2o")
    (define-key map (kbd "S-<kp-multiply>") "\eO2j")
    (define-key map (kbd "S-<kp-separator>") "\eO2l")
    (define-key map (kbd "S-<kp-subtract>") "\eO2m")
    (define-key map (kbd "S-<left>") "\e[1;2D")
    (define-key map (kbd "S-<next>") "\e[6;2~")
    (define-key map (kbd "S-<prior>") "\e[5;2~")
    (define-key map (kbd "S-<return>") "\e[13;2u")
    (define-key map (kbd "S-<right>") "\e[1;2C")
    (define-key map (kbd "S-<tab>") "\e[9;2u")
    (define-key map (kbd "S-<up>") "\e[1;2A")

    map)
"Maps keys to the corresponding sequence to send to the terminal.

This map is used by `mistty-send-key' to convert the key it
receives into something the commands attached to the terminal
might understand.

Note that `mistty-translation-keymap' is applied before this map, to
standardize around the symbol-based representation for ESC, RET or
<backtab>, so this map doesn't need to worry about historical
or alternative representations.

The default value of this map was created by applying
`mistty-reverse-input-decode-map', defined in
mistty-reverse-input-decode-map.el to `xterm-function-map'.")

(defvar mistty-shadowed-term-mode-hook nil
  "Special variable under which hooks found it `term-mode-hook' are stored.

This is allows running `term-mode-hook' or not, from
`mistty-term-mode-hook'.")

(defvar-local mistty--term-properties-to-add-alist nil
  "An alist of id to text properties to add to the term buffer.

This variable associates arbitrary symbols to property lists. It
is set by `mistty-register-text-properties' and read whenever
text is written to the terminal.

This variable is available in the work buffer.")


(defvar-local mistty--term-changed nil
  "Non-nil if the terminal was changed since last postprocess.

This is used to decide whether and on what region of the buffer
to call `mistty--term-postprocess'.")

(defvar-local mistty--eterm nil
  "Instance of `mistty--term-eterm' for the current term-mode buffer.")

(cl-defstruct (mistty--term-eterm
               (:constructor mistty--make-term-eterm)
               (:copier nil))
  ;; shell process
  proc

  ;; term-mode buffer associated with the process
  buf

  ;; a prompt--cell instance used to share prompts between the work and the term buffer.
  prompt-cell

  ;; non-nil if a change was detected above the sync mark
  change-before-scrolline

  ;; non-nil while in fullscreen mode
  fs

  ;; list of events collected since the last sync, in reverse order
  events)

;; Functions may signal this error if the function cannot return the
;; requested value because the buffer containing that value has been
;; killed.
;;
;; Note that this is different from the process being dead, as most
;; methods should still work with a dead process.
(define-error 'mistty--term-eterm-killed "Terminal has been killed")

(defmacro mistty--term-with-eterm-buffer (term &rest body)
  "Execute BODY with TERM's buffer active.

Raise `mistty--term-eterm-killed' if the buffer is not available
anymore.

This is subtly different from `mistty--with-live-buffer', which will
silently skip BODY."
  (declare (indent 1))
  (let ((tempvar (make-symbol "buf")))
    `(let ((,tempvar (mistty--term-eterm-buf ,term)))
       (if (buffer-live-p ,tempvar)
           (with-current-buffer ,tempvar
             ,@body)
         (signal 'mistty--term-eterm-killed nil)))))

(defun mistty--term-eterm-reset (term)
  "Reset internal state for TERM."
  (setf (mistty--term-eterm-fs term) nil)
  (setf (mistty--term-eterm-change-before-scrolline term) nil)
  (setf (mistty--term-eterm-events term) nil))

(cl-defmethod mistty--create-term
  ((_type (eql 'eterm)) name command
   &key width height
   prompt-cell
   enter-fullscreen
   leave-fullscreen
   after-clear-screen
   after-reset
   clear-scrollback
   sync-scrolline
   show-cursor
   request-report-mouse
   report-focus)
  "Create an eterm-based terminal called NAME.

COMMAND is run in the terminal and its size is set to WIDTH x HEIGHT,
defaulting to 80 x 24.

PROMPT-CELL specifies a mistty--prompt-cell struct used to track
prompts.

ENTER-FULLSCREEN and LEAVE-FULLSCREEN handle fullscreen transitions.
AFTER-CLEAR-SCREEN is called after the screen is cleared.
AFTER-RESET is called after the terminal was reset
CLEAR-SCROLLBACK clears scrollback in the work buffer
SYNC-SCROLLINE returns the current sync scrolline.
SHOW-CURSOR shows (non-nil argument) or hides (nil argument) the cursor
REQUEST-REPORT-MOUSE controls mouse reporting.
REPORT-FOCUS control whether focus changes should be reported."
  (ignore request-report-mouse)
  (let ((term-buffer (generate-new-buffer name 'inhibit-buffer-hooks)))
    (with-current-buffer term-buffer
      (let* ((mistty-shadowed-term-mode-hook term-mode-hook)
             (term-mode-hook mistty-term-mode-hook))
        (term-mode))
      (font-lock-mode -1)
      (jit-lock-mode nil)
      (setq-local term-char-mode-buffer-read-only t)
      (setq-local term-char-mode-point-at-process-mark t)
      (setq-local term-buffer-maximum-size 0)
      (setq-local term-set-terminal-size t)
      (setq-local term-width width)
      (setq-local term-height height)
      (setq-local term-command-function #'mistty--term-command-hook)
      (setq-local scroll-margin 0)

      ;; This makes sure the obsolete option
      ;; term-suppress-hard-newline is not set, as MisTTY relies on
      ;; term.el inserting fake newlines marked with term-line-wrap.
      (with-suppressed-warnings ((obsolete term-suppress-hard-newline))
        (setq term-suppress-hard-newline nil))

      (mistty-term--exec (car command) (cdr command))
      (let* ((proc (get-buffer-process term-buffer))
             (term (mistty--make-term-eterm
                    :buf term-buffer
                    :proc proc
                    :prompt-cell prompt-cell))
             (accum (mistty--make-accumulator
                     #'mistty--emulate-terminal)))
        (setq-local mistty--eterm term)

        (process-put proc 'adjust-window-size-function #'ignore)
        (process-put proc 'mistty-term term)
        (set-process-window-size proc height width)
        (set-process-filter proc accum)
        (term-char-mode)
        (add-hook 'after-change-functions #'mistty--after-change-on-term nil t)

        (mistty--term-postprocess-changed accum term)
        (mistty--add-bracketed-paste-prompt-detection accum term)
        (mistty--add-prompt_sp-detection accum term)

        (mistty--add-da1 accum)
        (mistty--add-skip-unsupported accum)
        (mistty--add-osc-detection accum)
        (unless enter-fullscreen (error ":enter-fullscreen required"))
        (mistty--accum-add-processor
         accum
         '(seq CSI (or "47" "?47" "?1047" "?1049") ?h)
         (lambda (ctx _str)
           (unless (mistty--term-eterm-fs term)
             (mistty--accum-ctx-flush ctx)
             (funcall enter-fullscreen)
             (setf (mistty--term-eterm-fs term) t))
           (mistty--accum-ctx-push-down ctx "\e[47h")))

        (unless leave-fullscreen (error ":leave-fullscreen required"))
        (let ((end (copy-marker (point-max))))
          (mistty--accum-add-processor
           accum
           '(seq CSI (or "47" "?47" "?1047" "?1049") ?l)
           (lambda (ctx _str)
             (mistty--accum-ctx-push-down ctx "\e[47l")
             (when (mistty--term-eterm-fs term)
               (mistty--accum-ctx-flush ctx)
               ;; When handling CSI 47 h, term.el sometimes add a newline
               ;; that is not removed after handling CSI 47 l. This
               ;; manifests as extra newlines, especially visible when
               ;; launching recent versions of fish. This code works around
               ;; the problem by deleting anything after the position that
               ;; was end-of-buffer just before CSI 47 h was handled.
               (mistty--with-live-buffer (mistty--term-eterm-buf term)
                 (when (and end
                            (< end (point-max))
                            (eq ?\n (char-after end)))
                   (let ((inhibit-read-only t))
                     (delete-region end (point-max)))
                   (move-marker end nil))
                 (setq end nil))
               (setf (mistty--term-eterm-fs term) nil)
               (funcall leave-fullscreen)))))

        (unless clear-scrollback (error ":clear-scrollback required"))
        (mistty--accum-add-processor
         accum
         ;; CSI H CSI J is the exact sequence sent by 'clear'. We're going to
         ;; handle it like 2J and clear the screen.
         '(or (seq CSI ?2 ?J)
              (seq CSI ?H CSI ?J))
         (lambda (ctx str)
           (if (mistty--term-eterm-fs term)
               (mistty--accum-ctx-push-down ctx str)

             (let ((goto-home (equal str "\e[H\e[J")))
               (mistty--accum-ctx-flush ctx)
               (if (when-let* ((p (mistty--get-prompt prompt-cell)))
                     (and
                      (mistty--prompt-realized p)
                      (equal
                       (mistty--prompt-start p)
                       (mistty--with-live-buffer (mistty--term-eterm-buf term)
                         mistty--scrolline-home-num))))
                   (progn
                     (mistty-log "CLEAR PROMPT (%S)" str)
                     (mistty--accum-ctx-push-down
                      ctx (if goto-home "\e[H\e[0J" "\e[1J\e[0J")))
                 (mistty-log "CLEAR SCREEN (%S)" str)
                 (mistty--accum-ctx-push-down
                  ctx (if goto-home "\e[H\e[2J" "\e[2J"))
                 (mistty--accum-ctx-flush ctx)
                 (mistty--term-eterm-clear-scrollback term clear-scrollback)
                 (when after-clear-screen
                   (funcall after-clear-screen)))))))

        (mistty--accum-add-processor
         accum '(seq CSI ?3 ?J) ;; Clear scrollback
         (lambda (ctx _)
           (mistty--accum-ctx-flush ctx)
           (mistty--term-eterm-clear-scrollback term clear-scrollback)))

        (mistty--accum-add-processor
         accum '(seq ESC ?c) ;; Reset (incl. clear scrollback)
         (lambda (ctx str)
           (mistty--accum-ctx-push-down ctx str)
           (mistty--accum-ctx-flush ctx)
           (mistty-log "RESET")
           (mistty--term-eterm-reset term)
           (mistty--with-live-buffer (mistty--term-eterm-buf term)
             (setq mistty-bracketed-paste nil))
           (mistty--term-eterm-clear-scrollback term clear-scrollback)
           (funcall after-reset)))

        (mistty--accum-add-around-process-filter
         accum
         (lambda (func)
           (if (mistty--term-eterm-fs term)
               (funcall func)

             (cl-letf ((inhibit-modification-hooks nil) ;; run mistty--after-change-on-term
                       ((symbol-function 'term-delete-chars)
                        (lambda (count)
                          (let ((save-point (point)))
                            (move-to-column (+ (term-current-column) count) t)
                            (delete-region save-point (point)))))
                       ((symbol-function 'move-to-column)
                        (let ((orig (symbol-function 'move-to-column)))
                          (lambda (&rest args)
                            (apply #'mistty--around-move-to-column orig args)))))
               (funcall func)))))

        ;; Detect changes made to the terminal above the sync scrolline, which
        ;; means that the sync scrolline needs to be updated.
        (mistty--accum-add-around-process-filter
         accum
         (lambda (func)
           (if (mistty--term-eterm-fs term)
               (funcall func)

             (let ((limit (funcall sync-scrolline)))
               (if (or (null limit) (<= limit 0))
                   (funcall func)
               (when (mistty--detect-change-before-scrolline
                      func (mistty--term-eterm-buf term) limit)
                 (mistty-log "DETECTED BUFFER CHANGE, above %s" limit)
                 (setf (mistty--term-eterm-change-before-scrolline term) t)))))))

        (unless show-cursor (error ":show-cursor required"))
        (mistty--accum-add-processor
         accum
         '(seq CSI "?25h")
         (lambda (_ _)
           (mistty-log "Show cursor")
           (funcall show-cursor t)))
        (mistty--accum-add-processor
         accum
         '(seq CSI "?25l")
         (lambda (_ _)
           (mistty-log "Hide cursor")
           (funcall show-cursor nil)))

        (unless report-focus (error ":report-focus required"))
        (mistty--accum-add-processor
         accum
         '(seq CSI "?1004h")
         (lambda (_ _)
           (mistty-log "Report Focus ON")
           (funcall report-focus t)))
        (mistty--accum-add-processor
         accum
         '(seq CSI "?1004l")
         (lambda (_ _)
           (mistty-log "Report Focus OFF")
           (funcall report-focus nil)))

        term))))

(cl-defmethod mistty--term-handle-process-death ((term mistty--term-eterm) msg)
  "Deal with the process of TERM having died with message MSG."
  (term-sentinel (mistty--term-eterm-proc term) msg))

(cl-defmethod mistty--term-delete ((term mistty--term-eterm))
  "Delete process and cleanup resources for TERM.

The process and/or its associated buffer might have already been killed
when this function is called."
  (when (process-live-p (mistty--term-eterm-proc term))
    (delete-process (mistty--term-eterm-proc term)))
  (when (buffer-live-p (mistty--term-eterm-buf term))
    (kill-buffer (mistty--term-eterm-buf term))))

(cl-defmethod mistty--term-update-options ((term mistty--term-eterm) &rest plist)
  "Set TERM options for the current terminal.

PLIST specifies the options to set. Possible keys:

- :allow-clearing-scrollback boolean

Any other option is ignored."
  (when-let* ((member (plist-member plist :allow-clearing-scrollback)))
    (mistty--with-live-buffer (mistty--term-eterm-buf term)
      (let ((val (cadr member)))
        (mistty-log "OPTION :allow-clearing-scrollback %s" val)
        (setq-local mistty-allow-clearing-scrollback val)))))

(cl-defmethod mistty--term-proc ((term mistty--term-eterm))
  "Return TERM's process."
  (mistty--term-eterm-proc term))

(cl-defmethod mistty--term-scrolline-at-screen-top ((term mistty--term-eterm))
  "Return the scrolline displayed in the first line of TERM's terminal."
  (mistty--term-with-eterm-buffer term
    (mistty--scrolline-at term-home-marker)))

(cl-defmethod mistty--term-lines ((term mistty--term-eterm))
  "Return TERM's height."
  (mistty--term-with-eterm-buffer term
    term-height))

(cl-defmethod mistty--term-columns ((term mistty--term-eterm))
  "Return TERM's width."
  (mistty--term-with-eterm-buffer term
    term-width))

(cl-defmethod mistty--term-resize ((term mistty--term-eterm) width height)
  "Resize TERM's terminal to WIDTH x HEIGHT."
  (set-process-window-size (mistty--term-eterm-proc term) height width)
  (mistty--with-live-buffer (mistty--term-eterm-buf term)
    (term-reset-size height width)))

(cl-defmethod mistty--term-sync
  ((term mistty--term-eterm) dest-buffer sync-pos sync-scrolline keep-markers
   cursor-marker)
  "Update DEST-BUFFER to match the terminal TERM.

The buffer from SYNC-POS to EOB is rewritten to match TERM's content below
SYNC-SCROLLINE.  If KEEP-MARKERS is non-nil, keep markers and overlays.
CURSOR-MARKER is updated to the cursor position."
  (let ((events (nreverse (mistty--term-eterm-events term))))
    (setf (mistty--term-eterm-events term) nil)
    (if (not (buffer-live-p (mistty--term-eterm-buf term)))
        (mistty--with-live-buffer dest-buffer
          (save-excursion
            (goto-char (point-max))
            (unless (looking-back "Terminal killed\\.\n?" nil)
              (insert "\n\nTerminal killed.\n"))))

      ;; Terminal live
      (with-current-buffer (mistty--term-eterm-buf term)
        (let ((home-marker term-home-marker)
              (home-scrolline (mistty--scrolline-at term-home-marker))
              (proc (mistty--term-eterm-proc term))
              (source-buffer (current-buffer)))
          ;; Detect shenanigans and update sync-pos and sync-scrolline accordingly
          (cond
           ((< sync-scrolline home-scrolline)
            (pcase-setq
             `(,sync-pos . ,sync-scrolline)
             (mistty--catchup home-marker home-scrolline dest-buffer sync-pos sync-scrolline)))
           ((mistty--term-eterm-change-before-scrolline term)
            (mistty-log "Detected terminal change above sync mark, at scrolline %s"
                        mistty--scrolline-home-num)
            (pcase-setq
             `(,sync-pos . ,sync-scrolline)
             (mistty--realign-buffers
              source-buffer home-scrolline dest-buffer sync-pos sync-scrolline))))

          (setf (mistty--term-eterm-change-before-scrolline term) nil)

          (let ((source-sync-pos (or (mistty--find-scrolline sync-scrolline)
                                     (mistty--find-scrolline home-scrolline)))
                (column-count term-width))
            (if keep-markers
                (mistty--sync-buffers source-buffer source-sync-pos dest-buffer sync-pos)
              (mistty--copy-buffers source-buffer source-sync-pos dest-buffer sync-pos))

            (mistty--with-live-buffer dest-buffer
              (set-marker cursor-marker
                          (+ sync-pos
                             (- (process-mark proc) source-sync-pos)))
              (mistty--copy-buffer-local-variables '(mistty-bracketed-paste) source-buffer)
              (mistty--copy-buffer-local-variables
               mistty-variables-to-copy source-buffer)
              (mistty--set-term-line-wrap-yank-handler sync-pos (point-max) column-count)
              (mistty--mark-empty-line-at-eob sync-pos)
              (when (mistty--term-eterm-fs term)
                (put-text-property sync-pos (point-max) 'read-only t))))

          (when (and (>= sync-pos home-marker)
                     (> home-marker 1000))
            (mistty--truncate-buffer home-marker)))))

    (list sync-pos sync-scrolline events)))

(cl-defmethod mistty--term-sync-backstage ((term mistty--term-eterm) sync-scrolline cursor)
  "Render TERM into the current buffer from SYNC-SCROLLINE.

The entire current buffer is rewritten to match the content of the
terminal starting at SYNC-SCROLLINE in a way that keeps marker positions
as much as possible.

The marker CURSOR is set at the cursor position, as long as the cursor is at or
below SYNC-SCROLLINE, otherwise the cursor is moved to the beginning of
the buffer after sync."
  (mistty--term-sync
   term (current-buffer) (point-min) sync-scrolline
   'keep-markers cursor)
  (goto-char cursor))

(cl-defmethod mistty--term-detect-dead-spaces-after-insert
  ((term mistty--term-eterm) content scrolline pos-in-line)
  "Mark dead trailing spaces left in TERM after inserting CONTENT.

When inserting a newline in an existing line, the terminal often just
overwrites the existing characters with space instead of re-creating the
line properly. The result are spaces that should be skipped.

SCROLLINE is the scrolline at which CONTENT was inserted in the terminal
buffer and POS-IN-LINE is the character position within that scrolline where it
was inserted."
  (mistty--with-live-buffer (mistty--term-eterm-buf term)
    (let ((beg (+ (mistty--find-scrolline scrolline)
                  pos-in-line))
          (lines (split-string content "\n")))
      (when (length> lines 1)
        (let ((first-line (car lines)))
          (let ((real-trailing-ws 0))
            (while (string-suffix-p " " first-line)
              (cl-incf real-trailing-ws)
              (setq first-line (substring first-line 0 -1)))
            (save-excursion
              (goto-char beg)
              (let ((eol (pos-eol)))
                (goto-char eol)
                (skip-chars-backward " " beg)
                (dotimes (_ real-trailing-ws)
                  (when (eq ?\  (char-after (point)))
                    (goto-char (1+ (point)))))
                (let ((inhibit-read-only t)
                      (inhibit-modification-hooks t))
                  (when (> eol (point))
                    (mistty-log "@%s [%s-%s) %s dead spaces, %s real"
                                (point) (pos-bol) eol (- eol (point)) real-trailing-ws)
                    (put-text-property (point) eol 'mistty-skip 'dead)))))))))))

(cl-defmethod mistty--term-translate-key ((_term mistty--term-eterm) key &optional n)
  "Generate the key byte sequence for TERM.

KEY is an Emacs key event and N the number of repetition for that event.

The function returns the byte sequence appropriate for sending that key
to the terminal."
  (mistty--translate-key-default key (or n 1) mistty--eterm-key-map))

(cl-defmethod mistty--term-list-special-keys ((_type (eql 'eterm)))
  "List the basic type of special event types (special keys)."
  (mistty--list-basic-types-from-map mistty--eterm-key-map))

(defun mistty--term-postprocess-changed (accum term)
  "Set \\='mistty-skip on the regions changed since last call.

This function registers a post processor on ACCUM that works with the
given TERM."
  (mistty--accum-add-post-processor
   accum
   (lambda ()
     (unless (mistty--term-eterm-fs term)
       (mistty--with-live-buffer (mistty--term-eterm-buf term)
         (when (and mistty--term-changed (< mistty--term-changed (point-min)))
           (setq mistty--term-changed (point-min)))
         (when (and mistty--term-changed (>= mistty--term-changed (point-max)))
           (setq mistty--term-changed nil))
         (when-let* ((change-start
                      (when mistty--term-changed
                        (text-property-any
                         mistty--term-changed (point-max) 'mistty-updated t))))
           (mistty--term-postprocess change-start term-width)
           (remove-text-properties
            change-start (point-max) '(mistty-updated t))
           (setq mistty--term-changed nil)))))))

(defun mistty--add-skip-unsupported (accum)
  "Skip some unsupported terminal sequences that confuse term.el.

This function adds processors to ACCUM to skip Application
Keypad (DECPAM) / Normal Keypad (DECPNM) Issued by Fish 4+ but just
ecoed by term.el."
  (mistty--accum-add-processor
   accum
   '(seq ESC (char "=>")) #'ignore))


(defun mistty--add-da1 (accum)
  "Configur ACCUM to handle DA1 Primary Device Detection code.

This implementation detects and answers primary device detection
requests from the application attached to the terminal. This is
here mostly to keep fish 4.1 and later happy."
  (mistty--accum-add-processor
   accum
   '(seq CSI (or "0c" "c"))
   (lambda (_ _)
     (process-send-string (get-buffer-process (current-buffer))
                          "\e[?64;1;18;21;22c"))))

(defun mistty-call-term-mode-hook ()
  "Call the functions registered to `term-mode-hook'.

Remove this hook from `mistty-term-mode-hook' to allow the terminal
modes started by MisTTY to have a completely separate setup from normal
terminal modes. See the documentation of `mistty-term-mode-hook' for
details."
  (run-hooks 'mistty-shadowed-term-mode-hook))

(defun mistty--after-change-on-term (beg end _old-length)
  "Function registered to `after-change-functions' by `mistty--create-term'.

BEG and END define the region that was modified."
  (mistty--changed beg end))

(defun mistty--changed (beg end)
  "Mark text between BEG and END as changed, forcing postprocess."
  (setq mistty--term-changed (if mistty--term-changed
                                 (min mistty--term-changed beg)
                               beg))
  (let ((beg (mistty--bol beg))
        (end (mistty--eol end)))
    (when (> end beg)
      (put-text-property beg end 'mistty-updated t))))

(defun mistty--around-move-to-column (orig-fun &rest args)
  "Add property \\='mistty-clear t to spaces added when just moving.

ORIG-FUN is the original `move-to-column' function and ARGS are its
arguments."
  (let ((initial-end (line-end-position)))
    (apply orig-fun args)
    (when (> (point) initial-end)
      (put-text-property
       initial-end (point) 'mistty-clear t))))


(defun mistty--emulate-terminal (proc str)
  "Handle process output as a terminal would.

This function accepts output from PROC included into STR and forwards
them to `term-emulate-terminal' with some modified functions, fix some
issues.

It also logs everything it receives to the function `mistty-log'.

This is meant as a drop-in replacement for `term-emulate-terminal' in
all situations, even when no work buffer is available."
  (cl-letf* ((inhibit-read-only t) ;; allow modifications in char mode
             ;; Using term-buffer-vertical-motion causes strange
             ;; issues; avoid it. Additionally, it's not actually
             ;; necessary since term.el adds newlines instead of
             ;; relying on Emacs wrapping lines. Mistty makes sure of
             ;; that by forcing term-suppress-hard-newline off.
             ((symbol-function 'term-buffer-vertical-motion)
              (lambda (count)
                (let ((start-point (point))
                      (res (forward-line count)))
                  ;; Convert forward-line return value (lines left to
                  ;; go through) to vertical-motion's (lines gone
                  ;; through) with a workaround for forward-line
                  ;; special handling of the last line.
                  (setq res (- count res))
                  (when (and (> count 0)
                             (= (point) (point-max))
                             (> (point) start-point)
                             (not (eq ?\n (char-before (point-max)))))
                    (cl-decf res))
                  res)))
             ((symbol-function 'term--handle-colors-list)
              (let ((real-handle-colors-list (symbol-function 'term--handle-colors-list)))
                (lambda (parameters)
                  (funcall real-handle-colors-list parameters)
                  (setq term-current-face
                        (mistty--clear-term-face-value term-current-face)))))

             ;; Save screen content in scrollback before clearing it.
             ((symbol-function 'term-erase-in-display)
              (let ((realfunc (symbol-function 'term-erase-in-display)))
                (lambda (arg)
                  (cond
                   ((equal 3 arg)) ;; clear scrollback; handled in work buffer
                   ((and
                     (not (term-using-alternate-sub-buffer))
                     (or (equal 2 arg)))
                    (term-handle-deferred-scroll)
                    (term-goto (1- term-height) 0)
                    (let ((lines (save-excursion
                                   (goto-char (point-max))
                                   (skip-chars-backward "[:blank:]\n\r")
                                   (when (> (point) term-home-marker)
                                     (mistty--count-lines term-home-marker (point))))))
                      (when lines
                        (mistty-log "[term] CLEAR SCREEN (kept %s lines)" lines)
                        (term-down (+ 1 lines))))
                    (term-goto-home)
                    (funcall realfunc 0))

                   (t
                    (funcall realfunc arg))))))

             ;; Save screen content in scrollback before a reset
             ((symbol-function 'term-reset-terminal)
              (lambda ()
                  (term-erase-in-display 2)
                  (term-ansi-reset)
                  (setq term-insert-mode nil))))
    (mistty-log "RECV %S" str)
    (term-emulate-terminal proc str)

    (mistty--with-live-buffer (process-buffer proc)
      (mistty--adjust-scrolline-base)

      ;; term-emulate-terminal sometimes ends up with the process mark
      ;; coming before the home marker or the point not at the process
      ;; mark. This is a workaround.
      (move-marker
       (process-mark proc)
       (max (process-mark proc) term-home-marker))
      (goto-char (process-mark proc)))))

(defun mistty--adjust-scrolline-base ()
  "Move the scrolline base to `term-home-marker'.

Call this before deleting any region before `term-home-marker'."
  (when (markerp term-home-marker)
    (mistty--update-scrolline
     term-home-marker (mistty--scrolline-at term-home-marker))))


(defun mistty-term--exec (program args)
  "Execute PROGRAM with ARGS in the terminal buffer.

Must be called from the term buffer."
  (let ((buffer (current-buffer))
        (name (buffer-name))
        ;; Bash versions older than 4.4 only turn on directory
        ;; tracking if the env variable EMACS is set and contains
        ;; "term". To deal with that, term.el detects whether a
        ;; version of bash older than 4.4 is installed and if it is,
        ;; set this variable to 43. This logic doesn't work well on
        ;; remote hosts. MisTTY disables that and replaces it with
        ;; mistty-set-EMACS.
        (term--bash-needs-EMACS-status 0)
        (process-environment
         (if (with-connection-local-variables mistty-set-EMACS)
             (cons (format "EMACS=%s (term:%s)"
                           emacs-version term-protocol-version)
                   process-environment)
           process-environment)))

    (cl-letf*
        ;; On MacOS, the length of the termcap entry, heavily
        ;; escaped by TRAMP, plus the other env variables is enough
        ;; to hit the 1024 byte limit of the tty cache used in
        ;; canonical mode (on Linux, it is 4095, so there's no
        ;; problem.) Adding a newline to the termcap entry avoids
        ;; hitting that limit while remaining valid. An alternative
        ;; would be to have TRAMP disable canonical mode with stty
        ;; -icanon before sending out the command.
        ((term-termcap-format (concat term-termcap-format "\n"))

         ;; term.el calls start-process, which doesn't support starting
         ;; processes with TRAMP. The following intercepts replace
         ;; start-process with start-file process, which does support
         ;; TRAMP.
         (real-start-process (symbol-function 'start-process))
         (called nil)
         ((symbol-function 'start-process)
          (lambda (name buffer program &rest program-args)
            (if called
                (apply real-start-process name buffer program program-args)
              (setq called t)
              (when-let* ((stty-command (nth 1 program-args)))
                (setq program-args (cl-copy-list program-args))
                (when (string-match "stty.*?sane" stty-command)
                  (setf (nth 1 program-args)
                        (concat (match-string 0 stty-command)
                                " erase ^?"
                                (substring stty-command (match-end 0))))))
              (let* ((process-environment
                      (append
                       (with-connection-local-variables mistty-process-env)
                       ;; TERMINFO references a local file. This is
                       ;; not useful on a remote host, so let's
                       ;; remove it. A description of the terminal is
                       ;; available in TERMCAP.
                       (if (file-remote-p default-directory)
                           (delq nil
                                 (mapcar (lambda (var)
                                           (if (string-prefix-p "TERMINFO=" var)
                                               nil
                                             var))
                                         process-environment))
                         process-environment)))
                     (proc (apply #'start-file-process name buffer program program-args)))

                ;; start-file-process doesn't always respect
                ;; coding-system-for-read set by term.el. Force it.
                (set-process-coding-system proc 'binary (cdr (process-coding-system proc)))
                proc)))))
      (term-exec buffer name program nil args))))


(defun mistty--term-command-hook (string)
  "TRAMP-aware alternative to the hook variable `term-command-hook'.

This function is meant to be bound to `term-command-function' to
catch Emacs-specific control sequences \\032...\\n. The STRING
argument includes everything between \\032 and \\n.

When `default-directory' is remote, this function interprets paths
sent by the terminal as being local to the TRAMP connection. The
result is that it sends remote paths to `cd'.

This works well with Bash which, by default, sends out directory paths
with every prompt if the env variable INSIDE_EMACS is set."
  (if (= (aref string 0) ?/)
      (let ((path (substring string 1)))
        (unless (file-remote-p path)
          (when-let* ((prefix (file-remote-p default-directory)))
            (setq path (concat prefix path))))
        ;; Not using cd here, to avoid a remote connection being made to
        ;; check the path.
        (setq path (file-name-as-directory path))
        (setq path (expand-file-name path))
        (setq default-directory path))

    ;; unknown or unsupported Emacs-specific control sequence.
    (term-command-hook string)))

(defun mistty--add-osc-detection (accum)
  "Handle OSC code in ACCUM.

Known OSC codes are passed down to handlers registered in
`mistty-osc-handlers'."
  (mistty--accum-add-processor-lambda accum
      (ctx '(seq OSC (let code Ps) ?\; (let text Pt) ST))
   (when-let* ((handler (cdr (assoc-string code mistty-osc-handlers))))
     (mistty--accum-ctx-flush ctx)
     (let ((inhibit-modification-hooks t)
           (inhibit-read-only t))
       (funcall handler code
                (decode-coding-string text locale-coding-system t))))))

(defun mistty--term-postprocess (region-start window-width)
  "Set mistty-skip and yank handlers between REGION-START and REGION-END.

WINDOW-WIDTH is used to detect right prompts.

This sets properties from the \\='mistty-clear properties,
detecting regions looking at a complete line."
  (save-excursion
    (let ((inhibit-read-only t)
          (inhibit-modification-hooks t))
      (goto-char region-start)
      (goto-char (pos-bol))
      (setq region-start (point))
      (remove-text-properties
       region-start (point-max)
       '(mistty-skip nil yank-handler nil mistty-updated nil))
      (goto-char region-start)
      (while
          (progn
            (let ((bol (pos-bol))
                  (eol (pos-eol)))
              (when (> eol bol)
                (unless (mistty--detect-right-prompt bol eol window-width)
                  (let ((end (mistty--detect-indent bol eol)))
                    (mistty--detect-trailing-spaces end eol)))))

            ;; process next line?
            (forward-line 1)
            (< (point) (point-max)))))))

(defun mistty--detect-right-prompt (bol eol window-width)
  "Detect right prompt and return its left position or nil.

BOL and EOL define the region to look in. WINDOW-WIDTH must be the width
of the terminal, usually `mistty-alacritty-columns'."
  (let ((pos (1- eol)) in-prompt)
    (when (and (< (abs (- window-width (mistty--column-count))) 3)
               (setq in-prompt (text-property-not-all (max bol (- eol 3)) eol 'mistty-clear t)))
      (when-let* ((rightmost-nonclear (previous-single-property-change in-prompt 'mistty-clear nil bol)))
        (when (and (eq (char-before rightmost-nonclear) ?\ )
                   (> rightmost-nonclear bol))
          (setq pos (1- rightmost-nonclear))
          (while (and (>= pos bol)
                      (eq (char-after pos) ?\ )
                      (get-text-property pos 'mistty-clear))
            (cl-decf pos))
          (cl-incf pos)
          (add-text-properties
           pos eol '(mistty-skip right-prompt
                                 yank-handler (nil "" nil nil)))

          pos)))))

(defun mistty--detect-continue-prompt (bol)
  "Detect continue prompt and return its right position or nil.

BOL define the start of the region to look in."
  (catch 'mistty-return
    (save-excursion
      (goto-char bol)
      (dolist (prompt mistty-multi-line-continue-prompts)
        (when (looking-at prompt)
          (let ((end (match-end 0)))
            (when (> end bol)
              (add-text-properties
               bol end
               '(mistty-skip continue-prompt yank-handler (nil "" nil nil)))
              (throw 'mistty-return end))))))))

(defun mistty--detect-indent (bol eol)
  "Detect line indentation and return its right position or nil.

BOL and EOL define the region to look in."
  (let ((pos bol))
    (while (and (eq (char-after pos) ?\ )
                (get-text-property pos 'mistty-clear))
      (cl-incf pos))
    (when (> pos bol)
      (when (= pos eol)
        (setq pos (min pos (+ bol (mistty--previous-line-indent)))))
      (put-text-property bol pos 'mistty-skip 'indent))

    pos))

(defun mistty--detect-trailing-spaces (bol eol)
  "Detect trailing spaces the left position or nil.

BOL and EOL define the region to look in."
  (let ((pos (1- eol)))
    (while (and (>= pos bol)
                (eq (char-after pos) ?\ )
                (get-text-property pos 'mistty-clear))
      (cl-decf pos))
    (cl-incf pos)

    (when (< pos eol)
      (add-text-properties
       pos eol
       `(mistty-skip trailing yank-handler (nil "" nil nil))))

    pos))

(defun mistty--previous-line-indent ()
  "Return the indentation of the previous line.

This requires the text property mistty-skip to have been set on
the previous line."
  (or
   (save-excursion
     (when (= 0 (forward-line -1))
       (let* ((bol (pos-bol))
              (eol (pos-eol))
              (pos bol))
         (while (and (< pos eol)
                     (eq 'indent (get-text-property pos 'mistty-skip)))
           (cl-incf pos))
         (- pos bol))))
   0))

(defun mistty--set-term-line-wrap-yank-handler (beg end column-count)
  "Set yank handler on fake newlines between BEG and END.

Only the newlines at COLUMN-COUNT are actually modified."
  (save-excursion
    (goto-char beg)
    (while (and (< (point) end)
                (search-forward "\n" end 'noerror))
      (when (and
             (get-text-property (match-beginning 0) 'term-line-wrap)
             (zerop (% (save-excursion
                         (goto-char (match-beginning 0))
                         (current-column))
                       column-count)))
        (add-text-properties
         (1- (point)) (point) '(yank-handler (nil "" nil nil)))))))

(defun mistty--mark-empty-line-at-eob (beg)
  "Mark empty lines at EOB with mistty-skip empty-line-at-eob.

When using eterm, this must be done on the work buffer after refreshing
and not on the term buffer, because newlines tend to stick around in the
term buffer and could end up having a confusing text property.

Start searching after BEG."
  (let ((pos (point-max)))
    (while (and (> pos beg)
                (eq ?\n (char-before pos)))
      (cl-decf pos))
    (when (< pos (point-max))
      (add-text-properties pos (point-max)
                           '(mistty-skip empty-lines-at-eob yank-handler (nil "" nil nil))))))


(defun mistty--add-prompt_sp-detection (accum term)
  "Setup ACCUM for detection of prompt_sp hack for TERM.

Detected prompts can be found in `mistty-prompt'."
  ;; Detect prompt-sp as many spaces followed by CR at the end of a
  ;; line.
  ;;
  ;; Not using " \r" as regexp for the processor as it would mean
  ;; waiting after a space in case a \r eventually comes. This isn't
  ;; an escape sequence.
  (mistty--accum-add-processor
   accum
   'CR
   (lambda (ctx _)
     (when (not (mistty--term-eterm-fs term))
       ;; If we received at least 8 spaces before the \r (enough to fill
       ;; the look-back buffer) flush and look at the state of the
       ;; buffer just before the \r is taken into account.
       (when (string= "        " (mistty--accum-ctx-look-back ctx))
         (mistty--accum-ctx-flush ctx)
         (when (or (and (= (1- (mistty--term-columns term))
                           (term-current-column))
                        (eq ?\  (char-before (point))))
                   (and (get-text-property (pos-eol 0) 'term-line-wrap)
                        (string-match "^ *$" (buffer-substring (pos-bol) (pos-eol)))))
           (let* ((pos (pos-bol))
                  (scrolline (mistty--scrolline-at pos)))
             (when (get-text-property (pos-eol 0) 'term-line-wrap)
               (let* ((eol (pos-eol 0))
                      (pos eol)
                      (inhibit-read-only t)
                      (inhibit-modification-hooks t))
                 (remove-text-properties eol (1+ eol) '(term-line-wrap nil))
                 (while (eq ?\  (char-before pos))
                   (cl-decf pos))
                 (when (> eol pos)
                   (add-text-properties pos eol '(mistty-blank t))))
               (cl-incf scrolline))
             (mistty--register-prompt 'prompt_sp scrolline)))))
     (mistty--accum-ctx-push-down ctx "\r"))))

(defun mistty--add-bracketed-paste-prompt-detection (accum term)
  "Setup ACCUM for bracketed-paste prompt detection for TERM.

Detected prompts can be found in `mistty-prompt'."
  ;; Enable bracketed paste
  (mistty--accum-add-processor
   accum
   '(seq CSI "?2004h")
   (lambda (ctx str)
     (when (not (mistty--term-eterm-fs term))
       (mistty--accum-ctx-flush ctx)
       (unless mistty-bracketed-paste
         (let* ((inhibit-read-only t)
                (inhibit-modification-hooks t)
                (start-pos (pos-bol))
                (scrolline (mistty--scrolline-at-point)))
           (mistty--register-prompt 'bracketed-paste scrolline)
           (when (> (pos-eol) start-pos)
             (mistty--changed start-pos (pos-eol))))
         (setq mistty-bracketed-paste t)))
     (mistty--accum-ctx-push-down ctx str)))

  ;; Disable bracketed paste
  (mistty--accum-add-processor
   accum
   '(seq CSI "?2004l")
   (lambda (ctx str)
     (when (not (mistty--term-eterm-fs term))
       (mistty--accum-ctx-flush ctx)
       (when mistty-bracketed-paste
         (when-let* ((end (if (eq ?\n (char-before (point)))
                              (mistty--scrolline-at-point)
                            (1+ (mistty--scrolline-at-point)))))
           (mistty--end-prompt 'bracketed-paste end))
         (setq mistty-bracketed-paste nil)))
     (mistty--accum-ctx-push-down ctx str))))


(cl-defun mistty--register-prompt (source start &key end text user-input-start)
  "Create and register a new prompt or merge it with the current one.

This function also logs the new or updated prompt.

SOURCE is the prompt source.
START is the scrolline of the prompt start position.
END is nil or the scrolline of the prompt end position.
TEXT is the prompt text.
USER-INPUT-START is (cons scrolline pos) of the start of user input.

Return the new prompt or the modified p prompt. In either case,
this is the same as what's returned by `mistty--prompt' after this call."
  (let* ((cell (mistty--term-eterm-prompt-cell mistty--eterm))
         (p (mistty--get-prompt cell))
         (other (mistty--make-prompt
                 :source source
                 :start start
                 :end end
                 :text text
                 :user-input-start user-input-start))
         (overlap (and p (mistty--prompt-overlaps p other))))
    (if overlap
        (mistty--prompt-merge-from p other)

      ;; Register the new prompt
      (setq p other)
      (mistty--set-prompt cell p))
    (mistty-log "%s %s prompt #%s [%s-%s]%s%s"
                (if overlap "Updated" "Detected")
                (mistty--prompt-source p)
                (mistty--prompt-input-id p)
                (mistty--prompt-start p)
                (or (mistty--prompt-end p) "")
                (if-let* ((text (mistty--prompt-text p)))
                  (format " :text %S" text) "")
                (if-let* ((s (mistty--prompt-user-input-start p)))
                  (format " :user-input-start %S" s) ""))))


(defun mistty--end-prompt (source end)
  "End the current prompt if it comes from SOURCE at END."
  (when-let* ((cell (mistty--term-eterm-prompt-cell mistty--eterm))
              (p (mistty--get-prompt cell)))
    (when (and (eq source (mistty--prompt-source p))
               (null (mistty--prompt-end p))
               (> end (mistty--prompt-start p)))
      (mistty-log "Closed %s prompt #%s [%s-%s]"
                  (mistty--prompt-source p)
                  (mistty--prompt-input-id p)
                  (mistty--prompt-start p)
                  end)
      (setf (mistty--prompt-end p) end))))

(cl-defun mistty--update-prompt (source &key user-input-start)
  "Update the current prompt if it comes from SOURCE.

USER-INPUT-START is the start position of user input."
  (ignore source)
  (when-let* ((cell (mistty--term-eterm-prompt-cell mistty--eterm))
              (p (mistty--get-prompt cell)))
    (when user-input-start
      (mistty-log "Updated %s prompt #%s :user-input-start %S"
                  (mistty--prompt-source p)
                  (mistty--prompt-input-id p)
                  user-input-start)
      (setf (mistty--prompt-user-input-start p) user-input-start))))

(defun mistty--prompt-source< (a b)
  "Compare prompt sources A and B.

Comparison goes from the most trusted (lowest number) to the least
trusted (highest number).

Return non-nil if A < B."
  (cl-labels ((priority (source)
                (pcase source
                  ('osc133 0)
                  ('bracketed-paste 1)
                  ('prompt_sp 2)
                  ('regexp 3)
                  (_ 10))))
    (< (priority a) (priority b))))


(defun mistty--prompt-merge-from (p other)
  "Update P with values from OTHER.

P input-id slot is not modified."

  ;; Select the most trusted source
  (when (mistty--prompt-source<
         (mistty--prompt-source other) (mistty--prompt-source p))
    (setf (mistty--prompt-source p) (mistty--prompt-source other)))

  ;; Expand start and end to cover the union of both ranges.
  ;;
  ;; Expand the end when going from regexp (1 line) to other,
  ;; open-ended prompt type. Expand prompt start when merging
  ;; 'prompt_sp and and 'bracketed paste on Zsh, where bracketed
  ;; past is called on the last line of a multi-line prompt.
  (setf (mistty--prompt-start p)
        (min (mistty--prompt-start other)
             (mistty--prompt-start p)))
  (cond
   ((and (mistty--prompt-end other) (mistty--prompt-end p))
    (setf (mistty--prompt-end p)
          (max (mistty--prompt-end other)
               (mistty--prompt-end p))))
   ((null (mistty--prompt-end other))
    (setf (mistty--prompt-end p) nil)))

  ;; Text is a restriction only valid on 'regexp that captures
  ;; the very first prompt text seen. Mostly only clear it.
  (unless (and (eq 'regexp (mistty--prompt-source p))
               (mistty--prompt-text other)
               (mistty--prompt-text p))
    (setf (mistty--prompt-text p) nil))

  ;; User-input-start is provided explicitly. Always use the
  ;; latest value.
  (when-let* ((s (mistty--prompt-user-input-start other)))
    (setf (mistty--prompt-user-input-start p) s)))

(defun mistty-osc133 (_ osc-seq)
  "Handle OSC 133 codes.

OSC-SEQ contains the subcode followed optionally by a semi-colon and
arguments (ignored).

MisTTY supports code A-D:

 - A marks the start of a new command.
 - B marks the end of the prompt and the start of user input.
 - C marks the start of command output.
 - D marks the end of the command.

Everything else is ignored."
  (when (and (length> osc-seq 0))
    (let ((command-char (aref osc-seq 0))
          (cell (mistty--term-eterm-prompt-cell mistty--eterm)))
      (mistty-log "OSC 133 %s" osc-seq)
      (pcase command-char
        (?A ;; start a new command
         ;; Overwrite any other prompt source.
         (mistty--register-prompt 'osc133 (mistty--scrolline-at-point)))

        (?B ;; end of prompt/start of user input
         (when-let* ((prompt (mistty--get-prompt cell)))
           (setf (mistty--prompt-user-input-start prompt)
                 (cons (mistty--scrolline-at-point)
                       (- (point) (pos-bol))))))

        (?C ;; start of command output
         (when-let* ((prompt (mistty--get-prompt cell)))
           (when (eq 'osc133 (mistty--prompt-source prompt))
             (mistty-log "Closed %s prompt #%s [%s-]"
                         (mistty--prompt-source prompt)
                         (mistty--prompt-input-id prompt)
                         (mistty--prompt-start prompt))
             (setf (mistty--prompt-end prompt) (mistty--scrolline-at-point)))))

        (?D ;; end of command (possible anytime after ?A)
         (unless (mistty--term-eterm-fs mistty--eterm)
           (let ((status (when (string-match "\\`D;\\([0-9]+\\)\\(?:;\\|\\'\\)" osc-seq)
                           (string-to-number (match-string 1 osc-seq)))))
             (push (list 'command-finished status (mistty--scrolline-at-point))
                   (mistty--term-eterm-events mistty--eterm))))
         (when-let* ((prompt (mistty--get-prompt cell)))
           (when (and (eq 'osc133 (mistty--prompt-source prompt))
                      (null (mistty--prompt-end prompt)))
             (mistty-log "Aborted %s prompt #%s [%s-]"
                         (mistty--prompt-source prompt)
                         (mistty--prompt-input-id prompt)
                         (mistty--prompt-start prompt))
             (setf (mistty--prompt-end prompt) (mistty--scrolline-at-point)))))))))

(defun mistty--term-eterm-clear-scrollback (term func)
  "Clear scrollback, if allowed.

This function clears scrollback still stored in TERM's process buffer
and then call FUNC to clear scrollback stored in the work buffer."
  (mistty--with-live-buffer (mistty--term-eterm-buf term)
    (mistty-log "=== CLEAR SCROLLBACK (eterm) %s" mistty-allow-clearing-scrollback)
    (when mistty-allow-clearing-scrollback
      (mistty-log "CLEAR SCROLLBACK (eterm)")
      (when (> term-home-marker (point-min))
        (let ((inhibit-read-only t)
              (inhibit-modification-hooks t))
          (delete-region (point-min) term-home-marker)))
      (funcall func))))

(defun mistty--truncate-buffer (home-marker)
  "Truncate the buffer before HOME-MARKER.

Truncate the buffer at a BOL, leaving at least 200 chars, for
`mistty--realign-buffers'."
  (save-excursion
    (goto-char (- home-marker 200))
    (goto-char (pos-bol))
    (unless (bobp)
      (mistty-log "[term] truncate %s chars of scrollback, leaving %s."
                  (- (point) (point-min))
                  (- home-marker (point)))
      (let ((inhibit-read-only t)
            (inhibit-modification-hooks t))
        (delete-region (point-min) (point))))))

(defun mistty--copy-buffers
    (source-buffer source-pos dest-buffer dest-pos)
  "Copy SOURCE-BUFFER from SOURCE-POS to eob to DEST-BUFFER at DEST-POS.

This function attempts to keep the point where it is if it is before
DEST-POS, otherwise, it moves it to the same position as in
SOURCE-BUFFER."
  (mistty--with-live-buffer dest-buffer
    (save-restriction
      (widen)
      (let ((old-point (when (< (point) dest-pos (point-max))
                         (point))))
        (goto-char dest-pos)
        (delete-region dest-pos (point-max))
        (insert-buffer-substring source-buffer source-pos)
        (if old-point
            ;; old-point was before dest-pos. Restore it.
            (goto-char old-point)
          ;; copy point position from source buffer, if possible
          (goto-char (+ dest-pos
                        (max 0 (with-current-buffer source-buffer
                                 (- (point) source-pos))))))))))

(defun mistty--copy-buffer-local-variables (variables source-buffer)
  "Copy the buffer-local values of VARIABLES between buffers.

Copies values from SOURCE-BUFFER to the current buffer."
  (dolist (var variables)
    (when (buffer-local-boundp var source-buffer)
      (make-local-variable var)
      (set var (buffer-local-value var source-buffer)))))

(defun mistty--clear-term-face-value (value)
  "Clean a font-lock-face VALUE generated by term.el.
n
This just removes the default background and foreground, as set
on the term face."
  (pcase value
    (`((:foreground ,fg :background ,bg . ,more-props) . ,rest)
     (let ((props more-props))
       (unless (equal fg (face-foreground 'term nil 'default))
         (setq props (plist-put props :foreground fg)))
       (unless (equal bg (face-background 'term nil 'default))
         (setq props (plist-put props :background bg)))
       (append (list props) rest '(term))))
    (_ value)))

(defun mistty--detect-change-before-scrolline (func term-buffer scrolline)
  "Return non-nil if FUNC modifies TERM-BUFFER above SCROLLINE.

FUNC is called in the caller's environment. It is supposed to modify
TERM-BUFFER.

Return non-nil if changes were detected."
  (let ((old-sync-position (mistty--with-live-buffer term-buffer
                             (mistty--find-scrolline scrolline))))
    ;; Reminder: call func with no buffer set, to avoid strange
    ;; breakages when the term buffer is killed.
    (funcall func)
    (mistty--with-live-buffer term-buffer
      (when-let* ((new-sync-position (mistty--with-live-buffer term-buffer
                                       (mistty--find-scrolline scrolline))))
        (/= old-sync-position new-sync-position)))))

(defun mistty--catchup
    (home-marker home-scrolline dest-buffer sync-pos sync-scrolline)
  "Catch up scrollback lines.

This function copies lines before HOME-MARKER, with scrolline
HOME-SCROLLINE, to DEST-BUFFER, at SYNC-POS. The line copies are those
between SYNC-SCROLLINE and HOME-SCROLLINE.

Returns new sync position and scrolline (cons SYNC-POS SYNC-SCROLLINE)."
  (cl-assert (< sync-scrolline home-scrolline))
  (mistty-log "Detected rapid scroll (sync @%s, home now @%s). Catching up."
              sync-scrolline home-scrolline)
  (let* ((source-buffer (current-buffer))
         (catchup-lines (- home-scrolline sync-scrolline))
         (catchup-start (save-excursion
                          (goto-char home-marker)
                          (pos-bol (1+ (- catchup-lines)))))
         (catchup-end (marker-position home-marker)))
    (mistty-log "Catchup [%s-%s] %s lines" catchup-start catchup-end catchup-lines)
    (cons (mistty--with-live-buffer dest-buffer
            (save-excursion
              (goto-char sync-pos)
              (let ((inhibit-modification-hooks t)
                    (inhibit-read-only t))
                (insert-buffer-substring
                 source-buffer catchup-start catchup-end))
              (point)))
          home-scrolline)))

(defun mistty--realign-buffers
    (source-buffer home-scrolline dest-buffer sync-pos sync-scrolline)
  "Reset sync position and scrolline after an unexpected change.

This function is called when something changed about the current sync
position, either because the position was set too low or because the
screen was overwritten by the currently running command. It does its
best to find align the two buffers while avoiding duplicated lines as
much as possible.

SOURCE-BUFFER is the terminal buffer, HOME-SCROLLINE the scrolline that
correspond to the top of the screen on the terminal.

DEST-BUFFER is the destination buffer to terminal data to at SYNC-POS,
which correspond to SYNC-SCROLLINE. The lines above SYNC-POS in
DEST-BUFFER may be annotated with \\='mistty-scrolline to specify the
scrolline the original data corresponds to; this function uses this
information to align the two buffers.

Return (cons SYNC-POS SYNC-SCROLLINE) with the new proposed values of
the sync position in DEST-BUFFER and the corresponding scrolline."
  (mistty--with-live-buffer dest-buffer
    (pcase-let* ((`(,pos . ,actual) (mistty--find-marked-scrolline home-scrolline)))
      (cond
       ;; Found exact scrolline, align there or below if rows match
       ((and pos actual (= actual home-scrolline))
        (pcase-setq `(,sync-pos . ,sync-scrolline)
                    (mistty--skip-identical-rows
                     pos home-scrolline source-buffer))
        (mistty-log "REALIGN scrolline %s to pos %s; terminal [%s-]"
                    sync-scrolline sync-pos home-scrolline))

       ;; Found scrolline < goal, align at line after
       ((and pos actual)
          (mistty-log "REALIGN APPROXIMATE scrolline %s to pos %s; terminal [%s-]"
                      home-scrolline pos home-scrolline)
          (setq sync-pos pos
                sync-scrolline home-scrolline))

       ;; Couldn't find beginning. It might have been deleted. Sync
       ;; whole buffer.
       (t
        (mistty-log "REALIGN FALLBACK scrolline %s to point-min %s"
                    home-scrolline (point-min))
        (setq sync-pos (point-min)
              sync-scrolline home-scrolline))))

    (cons sync-pos sync-scrolline)))

(defun mistty--skip-identical-rows (pos scrolline source-buffer)
  "Skip rows from POS that are the same on SOURCE-BUFFER.

Return a (CONS new-pos new-scrolline), possibly modified values for POS
and SCROLLINE."
  (save-excursion
    (while
        (when (equal scrolline (get-text-property pos 'mistty-scrolline))
          (when-let* ((end-row (next-single-property-change pos 'mistty-scrolline)))
            (when (string= (string-trim (buffer-substring-no-properties pos end-row)
                                        "" "\n")
                           (mistty--with-live-buffer source-buffer
                             (save-excursion
                               (goto-char (mistty--find-scrolline scrolline))
                               (mistty--unwrapped-scrolline-text))))
              (setq pos end-row))))
      (goto-char pos)
      (cl-incf scrolline)))

  `(,pos . ,scrolline))

(provide 'mistty-eterm)

;;; mistty-eterm.el ends here
