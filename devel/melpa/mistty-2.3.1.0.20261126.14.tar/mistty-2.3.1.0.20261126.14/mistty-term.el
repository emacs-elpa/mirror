;;; mistty-term.el --- Generic methods for terminal access -*- lexical-binding: t -*-

;; This program is free software: you can redistribute it and/or
;; modify it under the terms of the GNU General Public License as
;; published by the Free Software Foundation; either version 3 of the
;; License, or (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
;; General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see
;; `http://www.gnu.org/licenses/'.

;;; Commentary:
;;
;; This file defines generic methods called by mistty to communicate
;; with the selected terminal type (builtin or mod).

(require 'cl-lib)

;;; Code:

(cl-defgeneric mistty--create-term
    (type name command
          &key width height
          enter-fullscreen
          leave-fullscreen
          after-reset
          after-clear-screen
          clear-scrollback
          sync-scrolline
          show-cursor
          request-report-mouse
          report-focus)
  "Create a new term buffer of the given TYPE with name NAME.

The buffer runs COMMAND, a list containing the program to run and its
arguments.

LOCAL-MAP specifies a local map to be used as the char-mode map.

WIDTH and HEIGHT are the initial dimension of the terminal
reported to the remote process.

This function returns an instance of the generic terminal type, which
allows getting hold of the buffer and process.

ENTER-FULLSCREEN is to be called when entering fullscreen mode.

LEAVE-FULLSCREEN is to be called when leaving fullscreen mode.

AFTER-RESET is to be called after a reset.

AFTER-CLEAR-SCREEN is to be called after the screen has been cleared.

CLEAR-SCROLLBACK is to be called after the screen has been cleared.

SYNC-SCROLLINE is a function that returns the current sync scrolline.

SHOW-CURSOR is passed a boolean to show (non-nil) or hide (nil) the
cursor.

REQUEST-REPORT-MOUSE is a function that the terminal can use to request
which mouse events should be reported `mistty--term-translate-mouse'. It
takes one argument that is either nil (deactivated), \\='click (press
and release events), \\='drag (press, release, and mouse movement with
pointer down), \\='motion (all mouse events).

REPORT-FOCUS is passed a boolean to ask for focus events to be
reported (non-nil) or not (nil).")

(cl-defgeneric mistty--term-handle-process-death (term msg)
  "Handle process death for TERM, with message MSG.

The MSG is forwarded from the one passed to the process sentinel.")

(cl-defgeneric mistty--term-delete (term)
  "Delete process and cleanup resources for TERM.

The process and/or its associated buffer might have already been killed
when this function is called.")

(cl-defgeneric mistty--term-update-options (term &rest plist)
  "Set TERM options.

PLIST specifies the options to set. Possible keys:

- :osc52 nil|\\='only-copy|\\='only-paste|\\='copy-paste
- :allow-clearing-scrollback boolean

Not all terminal support all options. Unsupported or unknown options are
ignored."

  (ignore term plist))

(cl-defgeneric mistty--term-proc (term)
  "Return the TERM's process.")

(cl-defgeneric mistty--term-scrolline-at-screen-top (term)
  "Return the scrolline for he start of TERM's terminal.")

(cl-defgeneric mistty--term-lines (term)
  "Return the height of TERM's terminal, in lines.")

(cl-defgeneric mistty--term-columns (term)
  "Return the width of TERM's terminal, in columns.")

(cl-defgeneric mistty--term-resize (term width height)
  "Set the terminal size for TERM to WIDTH x HEIGHT.")

(cl-defgeneric mistty--term-sync
    (term dest-buffer sync-pos sync-scrolline keep-markers cursor-marker)
  "Update the content of DEST-BUFFER to match the terminal TERM.

The buffer from SYNC-POS to EOB is rewritten to match the content of the
terminal below SYNC-SCROLLINE.

If KEEP-MARKERS is nil, the function may complete rewrite and discard
the content of the buffer within that range. If KEEP-MARKERS is non-nil,
the function needs to do its best to keep markers and overlays and move
them as appropriate.

The function return a (list SYNC-POS SYNC-SCROLLINE EVENTS) containing
new proposed values for future calls. It may propose to increase the
sync scrolline, in cases where SYNC-SCROLLINE is above the top of the
terminal screen, or to decrease it, in cases where changes were detected
above SYNC-SCROLLINE.

EVENTS is a list of events to be handled by the caller:
 - (command-finished exit-status scrolline) OSC 133 reported the given
   command status

Note that in the latter case, the function may modify DEST-BUFFER above
SYNC-POS and the new proposed value may be above the initial value.

DEST-BUFFER can change from one call to the next. If DEST-BUFFER is the
same as in the last call, the function may assume that changes
previously made are still in place to optimize its operations.

CURSOR-MARKER must be a marker. It will be updated with the position of
the cursor on DEST-BUFFER.")

(cl-defgeneric mistty--term-sync-backstage (term sync-scrolline cursor)
  "Render TERM into the current buffer from SYNC-SCROLLINE.

The entire buffer content is rewritten to match the content of the
terminal starting at SYNC-SCROLLINE in a way that keeps marker positions
as much as possible.

The marker CURSOR is set at the cursor position, as long as the cursor
is at or below SYNC-SCROLLINE, otherwise the cursor is moved to the
beginning of the buffer after sync.")

(cl-defgeneric mistty--term-detect-dead-spaces-after-insert (term content scrolline pos-in-line)
  "Mark dead trailing spaces left in TERM after inserting CONTENT.

When inserting a newline in an existing line, the terminal often just
overwrites the existing characters with space instead of re-creating the
line properly. The result are spaces that should be skipped.

SCROLLINE is the scrolline at which CONTENT was inserted in the terminal
buffer and POS-IN-LINE is the character position within that scrolline where it
was inserted.")

(cl-defgeneric mistty--term-translate-key (term key &optional n)
  "Generate the key byte sequence for TERM.

KEY is an Emacs key event and N the number of repetition for that event.

The function returns the byte sequence appropriate for sending that key
to the terminal.")

(cl-defgeneric mistty--term-list-special-keys (type)
  "List special keys (symbols) supported on input for terminal TYPE.

These are the keys `mistty--term-translate-key' should be able to
translate.

The returned value is a list of symbol; basic types for the special keys
as returned by `event-basic-type'.")

(cl-defgeneric mistty--term-translate-mouse (_term _action _button _mods _start-posn _move-posn _sync-pos)
  "Translate a mouse event for TERM into an escape sequence or nil.

ACTION is \\='press \\='release or \\='motion

BUTTON is the number of the pressed button or nil.

MODS are the event modifiers, as reported by `event-modifiers'.

START-POSN is the start position reported by the event.

If MOVE-POSN is non-nil, it is the position of the mouse moved after EV
happened. This is used to report drag events.

SYNC-POS is the buffer position at which the terminal is synced. It's
only guaranteed to correspond to the terminal screen top in fullscreen
mode."
  nil)

(cl-defgeneric mistty--term-click-on (term target sync-pos)
  "Generate a click for TERM on buffer position TARGET.

TARGET is a position in the terminal zone of current buffer, which
starts at SYNC-POS. Scrollines must be set correctly on the buffer.

SYNC-POS is the position in the current buffer at which the terminal is
synced. It's only guaranteed to correspond to the terminal screen top in
fullscreen mode."
  (ignore term target sync-pos)

  nil)

(cl-defgeneric mistty--term-start-regexp-prompt (_term _start)
  "Start a regexp prompt for TERM at START and make it current."
  nil)

(cl-defgeneric mistty--term-end-regexp-prompt (_term)
  "End the current regexp prompt for TERM, if any."
  nil)

(cl-defgeneric mistty--term-mouse-reporting (_term)
  "Return the current mouse reporting level.

Returns nil, \\='click, \\='drag or \\='motion.

Changes to this value are reported to the callback request-report-mouse
passed to `mistty--create-term`."
  nil)

(provide 'mistty-term)

;;; mistty-term.el ends here

