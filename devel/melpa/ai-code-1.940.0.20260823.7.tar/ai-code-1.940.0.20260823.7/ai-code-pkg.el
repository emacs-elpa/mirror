;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.940.0.20260823.7"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "18a0d8498d17a790215f0ce1ccfe6edaecf49b9e"
  :revdesc "18a0d8498d17"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
