;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neon-mode" "1.3.0.0.20241220.3"
  "Simple major mode for editing neon files."
  '((emacs "24.1"))
  :url "https://github.com/Fuco1/neon-mode"
  :commit "23b12659d72a9520850bca72fe64bb7b06fc7b6b"
  :revdesc "23b12659d72a"
  :keywords '("conf")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
