;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "svg-tag-mode" "0.3.2.0.20241021.37"
  "Replace keywords with SVG tags."
  '((emacs   "27.1")
    (svg-lib "0.2"))
  :url "https://github.com/rougier/svg-tag-mode"
  :commit "13e888b8bd9a0664d060149a44a751b2113331b6"
  :revdesc "13e888b8bd9a"
  :keywords '("convenience")
  :authors '(("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr"))
  :maintainers '(("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr")))
