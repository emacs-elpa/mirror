;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empos" "0.1.0.20151011.20"
  "Locate bibtex citations from within emacs."
  ()
  :url "https://github.com/dimalik/empos/"
  :commit "7b99ad30e56937adb7e6349777e5a2045597d564"
  :revdesc "7b99ad30e569"
  :keywords '("citations" "reference" "bibtex" "reftex")
  :authors '(("Dimitris Alikaniotis" . "da352[at]cam.ac.uk"))
  :maintainers '(("Dimitris Alikaniotis" . "da352[at]cam.ac.uk")))
