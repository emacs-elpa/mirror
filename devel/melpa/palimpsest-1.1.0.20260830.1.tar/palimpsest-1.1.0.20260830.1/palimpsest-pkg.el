;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "palimpsest" "1.1.0.20260830.1"
  "Various deletion strategies when editing."
  ()
  :url "https://github.com/danielsz/Palimpsest"
  :commit "cebdd5a37f6e0802eced9b902543d7f2dd10285d"
  :revdesc "cebdd5a37f6e"
  :authors '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com"))
  :maintainers '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com")))
