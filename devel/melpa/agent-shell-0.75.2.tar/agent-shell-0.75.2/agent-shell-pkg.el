;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.75.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.14.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d027d8de2b74019ae83e36b1edcd0b968295ac31"
  :revdesc "d027d8de2b74")
