;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "0.5.2.0.20261104.25"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "c4ff04453eddbfa429d2fddb1376f119d141f605"
  :revdesc "c4ff04453edd"
  :keywords '("convenience" "gptel" "llm")
  :authors '(("Kevin Montag" . "https://github.com/kmontag"))
  :maintainers '(("Kevin Montag" . "https://github.com/kmontag")))
