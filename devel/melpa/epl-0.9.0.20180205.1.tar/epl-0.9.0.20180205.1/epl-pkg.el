;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epl" "0.9.0.20180205.1"
  "Emacs Package Library."
  '((cl-lib "0.3"))
  :url "https://github.com/cask/epl"
  :commit "78ab7a85c08222cd15582a298a364774e3282ce6"
  :revdesc "0.9-1-g78ab7a85c082"
  :keywords '("convenience")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")
                 ("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
