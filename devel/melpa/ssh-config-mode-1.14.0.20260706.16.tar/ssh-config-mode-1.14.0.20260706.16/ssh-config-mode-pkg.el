;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ssh-config-mode" "1.14.0.20260706.16"
  "Mode for fontification of ~/.ssh/config."
  '((emacs "24.3"))
  :url "https://github.com/peterhoeg/ssh-config-mode-el"
  :commit "a171e48c3cef777556961323d4dd6172a94be0f1"
  :revdesc "a171e48c3cef"
  :keywords '("comm" "files")
  :authors '(("Harley Gorrell" . "harley@panix.com"))
  :maintainers '(("Peter Hoeg" . "peter@hoeg.com")))
