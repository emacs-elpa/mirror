;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.2.0.0.20260704.7"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "5b303eaf1344c29ea9968f1e4ebba5517319f756"
  :revdesc "v0.2.0-7-g5b303eaf1344"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
