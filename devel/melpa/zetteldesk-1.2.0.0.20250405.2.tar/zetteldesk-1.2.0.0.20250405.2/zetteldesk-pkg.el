;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zetteldesk" "1.2.0.0.20250405.2"
  "A revision and outlining tool for org-roam."
  '((emacs    "27.1")
    (org-roam "2.0"))
  :url "https://github.com/Vidianos-Giannitsis/zetteldesk.el"
  :commit "0196835c5d6df65d46a4f642b716e6901ad0f4c1"
  :revdesc "0196835c5d6d"
  :authors '(("Vidianos Giannitsis" . "vidianosgiannitsis@gmail.com"))
  :maintainers '(("Vidianos Giannitsis" . "vidianosgiannitsis@gmail.com")))
