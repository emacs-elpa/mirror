;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.10.0.0.20261112.2"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "dabef58467cb32685c8bf8f62d6c5f4357f41c0b"
  :revdesc "dabef58467cb"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
