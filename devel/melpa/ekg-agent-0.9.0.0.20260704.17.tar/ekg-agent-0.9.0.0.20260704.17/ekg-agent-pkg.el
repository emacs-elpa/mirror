;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "0.9.0.0.20260704.17"
  "Agentic actions for ekg."
  '((emacs "28.1")
    (ekg   "0.8.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "370f4bce464acd3930ae5181833854983bb40072"
  :revdesc "370f4bce464a"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
