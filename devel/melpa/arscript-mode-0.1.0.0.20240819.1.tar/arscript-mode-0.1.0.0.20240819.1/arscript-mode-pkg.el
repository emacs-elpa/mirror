;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arscript-mode" "0.1.0.0.20240819.1"
  "Major mode for editing arscript files."
  '((emacs "25.1"))
  :url "https://github.com/captainflasmr/arscript-mode"
  :commit "797e1d0ef1312e8ff846abd0c6853358041f7691"
  :revdesc "797e1d0ef131"
  :keywords '("convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
