;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chyla-dark-theme" "0.1.0.20240824.12"
  "Chyla.org - dark green color theme."
  '((emacs "24.1"))
  :url "https://github.com/chyla/ChylaDarkThemeForEmacs"
  :commit "274ff01146e265f773478b16a59483b638b986f8"
  :revdesc "274ff01146e2"
  :authors '(("Adam Chyła https://chyla.org/" . "adam@chyla.org"))
  :maintainers '(("Adam Chyła https://chyla.org/" . "adam@chyla.org")))
