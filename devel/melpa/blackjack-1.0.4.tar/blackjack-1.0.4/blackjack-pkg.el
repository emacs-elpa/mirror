;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blackjack" "1.0.4"
  "The game of Blackjack."
  '((emacs "26.2"))
  :url "https://github.com/gdonald/blackjack-el"
  :commit "3930d197d1f8f37de0dbb6c9875ef5279e16cdfa"
  :revdesc "3930d197d1f8"
  :keywords '("card" "game" "games" "blackjack" "21")
  :authors '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers '(("Greg Donald" . "gdonald@gmail.com")))
