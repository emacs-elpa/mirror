;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-cask" "0.4.0.20240205.8"
  "Cask support in Flycheck."
  '((emacs    "24.3")
    (flycheck "0.14")
    (dash     "2.4.0"))
  :url "https://github.com/flycheck/flycheck-cask"
  :commit "0eeec5197e9d31bfcfc39380b262d65259a87d91"
  :revdesc "0.4-8-g0eeec5197e9d"
  :keywords '("tools" "convenience")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
