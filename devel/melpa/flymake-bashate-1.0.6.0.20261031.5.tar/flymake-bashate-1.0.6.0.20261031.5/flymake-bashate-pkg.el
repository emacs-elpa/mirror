;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-bashate" "1.0.6.0.20261031.5"
  "A Flymake backend for bashate, a Bash scripts style checker."
  '((flymake-quickdef "1.0.0")
    (emacs            "27.1"))
  :url "https://github.com/jamescherti/flymake-bashate.el"
  :commit "6d455c9de979bcccef50443c5facf10f7aa92d14"
  :revdesc "1.0.6-5-g6d455c9de979"
  :keywords '("tools" "languages")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
