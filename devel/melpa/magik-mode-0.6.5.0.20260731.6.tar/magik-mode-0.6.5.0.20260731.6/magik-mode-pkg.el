;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "0.6.5.0.20260731.6"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "6b03728ad53e30dd686aa710bba7c4be211ab348"
  :revdesc "6b03728ad53e"
  :keywords '("languages"))
