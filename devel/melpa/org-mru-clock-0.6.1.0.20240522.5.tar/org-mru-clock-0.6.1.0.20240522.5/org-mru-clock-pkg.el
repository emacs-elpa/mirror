;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mru-clock" "0.6.1.0.20240522.5"
  "Clock in/out of tasks with completion and persistent history."
  '((emacs "26.1"))
  :url "https://github.com/unhammer/org-mru-clock"
  :commit "198beb2089ea5e457dd13e8ac64d775eeff8fd89"
  :revdesc "v0.6.1-5-g198beb2089ea"
  :keywords '("convenience" "calendar")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
