;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-buf-lint" "0.0.1.0.20250408.5"
  "Flycheck checker for protobuf with buf.build."
  '((emacs    "26.1")
    (flycheck "0.22")
    (s        "1.12.0"))
  :url "https://github.com/shuxiao9058/flycheck-buf-lint"
  :commit "0cf5eec5cf647e3156bc13be67927fa37c167902"
  :revdesc "0cf5eec5cf64"
  :keywords '("convenience" "tools" "buf" "protobuf")
  :authors '(("Aaron Ji" . "shuxiao9058@gmail.com"))
  :maintainers '(("Aaron Ji" . "shuxiao9058@gmail.com")))
