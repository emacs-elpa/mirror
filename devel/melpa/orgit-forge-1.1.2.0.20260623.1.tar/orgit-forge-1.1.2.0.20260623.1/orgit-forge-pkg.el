;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit-forge" "1.1.2.0.20260623.1"
  "Org links to Forge issue buffers."
  '((emacs    "29.1")
    (compat   "30.1")
    (cond-let "0.2")
    (forge    "0.6")
    (magit    "4.5")
    (org      "9.8")
    (orgit    "2.1"))
  :url "https://github.com/magit/orgit-forge"
  :commit "1e325a23ccc707373c13aee91c15a0bc0d1d6f41"
  :revdesc "v1.1.2-1-g1e325a23ccc7"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev")))
