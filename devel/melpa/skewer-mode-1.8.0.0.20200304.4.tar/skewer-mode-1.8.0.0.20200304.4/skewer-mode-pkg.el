;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "skewer-mode" "1.8.0.0.20200304.4"
  "Live browser JavaScript, CSS, and HTML interaction."
  ()
  :url "https://github.com/skeeto/skewer-mode"
  :commit "e5bed351939c92a1f788f78398583c2f83f1bb3c"
  :revdesc "1.8.0-4-ge5bed351939c"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
