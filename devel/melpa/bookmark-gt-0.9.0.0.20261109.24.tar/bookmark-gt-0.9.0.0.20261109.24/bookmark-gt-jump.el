;;; bookmark-gt-jump.el --- Jump reader (marginalia, orderless)  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Daniel M. German <dmg@turingmachine.org>

;; Author: Daniel M. German <dmg@turingmachine.org>
;; Maintainer: Daniel M. German <dmg@turingmachine.org>
;; Assisted-by: Claude:claude-opus-4-7
;; Keywords: convenience, matching, hypermedia
;; URL: https://github.com/dmgerman/bookmark-gt

;; SPDX-License-Identifier: GPL-3.0-or-later
;;
;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; `bookmark-gt-jump' — a jump reader built on `completing-read', so
;; it works with any completion interface (vertico, icomplete, the
;; default *Completions* buffer).  When marginalia is loaded,
;; candidates get an annotation column (tags, type, path).  When
;; orderless is loaded, the reader accepts three narrowing
;; particles:
;;
;;   @TYPE    — narrow to bookmarks of TYPE (url, eww, file, ...).
;;   +GROUP   — narrow to bookmarks in GROUP (web, file, doc, ...).
;;   ;TAG     — narrow to bookmarks carrying TAG.
;;
;; The dispatcher is active only for the length of one reader call;
;; other completion commands are unaffected.  Type and
;; group names come from `bookmark-gt-handler-alist' and
;; `bookmark-gt-group-alist' when the candidates are built, so a
;; user-registered type or group can be selected without further
;; configuration.
;;
;; The reader also supports a mid-read tag filter: `M-t' in the
;; minibuffer reads a tag and re-runs the read with the filter
;; active.  Multiple `M-t' calls compose; `M-d' pops the last
;; filter; abort clears them.

;;; Code:

(require 'bookmark)
(require 'seq)
(require 'cl-lib)
(require 'mule-util)
(require 'bookmark-gt-core)
(require 'bookmark-gt-tags)
(require 'bookmark-gt-handlers)

;; Optional soft-deps.  Each is loaded if present; every use site
;; below guards with `featurep' / `fboundp' so bookmark-gt works
;; without them installed.
(require 'marginalia nil t)
(require 'orderless nil t)

;; Compiler-visible declarations for the soft-dep functions we call.

(defvar orderless-style-dispatchers)
(defvar marginalia-annotators)
(defvar marginalia-separator)
(defvar marginalia-field-width)

;;;; Customization

(defcustom bookmark-gt-jump-name-max-width 58
  "Width at which the jump reader truncates a bookmark name.
Caps the candidate column so that a long name does not push the
annotation columns off the right edge of the window.
This matters most for names bookmark-gt does not choose itself —
browser tabs stored by `bookmark-gt-browser-tabs-mode' carry the
page title, which is often long enough to fill the window on its
own."
  :type 'integer
  :group 'bookmark-gt)

(defcustom bookmark-gt-jump-location-max-width 100
  "Maximum width of the location field in the jump annotation.

The location field takes the horizontal space the candidate, tag
and type columns leave free, so it widens on a wide frame and
narrows on a small one.  This value bounds that width.

A bound is useful because a wide location is not always an
informative one: a bookmark whose location holds machine state
rather than a destination — a window configuration serialized
into a URL, for instance — runs to hundreds of characters and
would otherwise occupy every free column.

An integer is a column count.  A float is a fraction of
`marginalia-field-width'.  nil applies no bound beyond the space
that is free."
  :type '(choice (const :tag "All free space" nil)
                 (integer :tag "Columns")
                 (float :tag "Fraction of `marginalia-field-width'"))
  :group 'bookmark-gt)

(defconst bookmark-gt-jump--location-min-width 20
  "Width the location field keeps when no space is free.
Below this the field carries too little of a path or URL to
identify it, so the annotation runs past the window edge instead.")

(defcustom bookmark-gt-jump-default-sort 'mru
  "Default sort order for `bookmark-gt-jump' and its variants.
Consulted when the entry point's `:SORT-BY' keyword is not
supplied.  Valid values match `bookmark-gt-jump--sort-records':

  `mru'     Sort by `last-visited' descending — recently
            visited records appear first.
  `visits'  Sort by `visits' descending.
  nil       Leave the candidate pool in its original order."
  :type '(choice (const :tag "Most recently used" mru)
                 (const :tag "Most visited"       visits)
                 (const :tag "Pool order"         nil))
  :group 'bookmark-gt)

(defvar bookmark-gt-jump-before-read-hook nil
  "Hook run once inside the jump readers before the reader displays.
Runs at the top of `bookmark-gt-jump', `bookmark-gt-jump-other-window',
and `bookmark-gt-jump-tagged', immediately before the candidate pool
is computed — but only when the entry point is going to prompt the
user (i.e. `:BOOKMARK' was not supplied).  Not run again on tag-filter
restart within a single call.

Called with no arguments.  Contributors typically refresh a pool
that grows stale between reads.  `bookmark-gt-browser-tabs-mode'
registers `bookmark-gt-browser-tabs-refresh' here so live browser
tabs are current whenever the jump reader opens.  Third parties
may add their own refreshers (auto-update sweep, remote-tab
poll, etc.) — each is called synchronously in the order added.")

(defcustom bookmark-gt-jump-candidate-format-function
  #'bookmark-gt-jump-candidate-default
  "Function that builds one candidate string for the jump reader.

Called with one argument, the bookmark RECORD (a `(NAME . DATA)'
cons from `bookmark-alist').  Must return a propertized string
whose text properties carry:

  `bookmark-gt-name'       — the bare bookmark name (string).
  `bookmark-gt-record'     — the record itself.
  `bookmark-gt-particles'  — optional space-separated
                             `@Type +Group ;tag ;tag' tokens for
                             the orderless particle dispatcher.

Customize this to control the visible row layout (e.g. add
DOMAIN / KIND / TITLE columns).  See
`bookmark-gt-jump-candidate-default' for the default
implementation and the token contract."
  :type 'function
  :group 'bookmark-gt)

;;;; Candidate construction

(defun bookmark-gt-jump--truncate-name (name)
  "Return NAME truncated to `bookmark-gt-jump-name-max-width'."
  (truncate-string-to-width name bookmark-gt-jump-name-max-width nil nil t))

(defun bookmark-gt-jump--tag-tokens (tags)
  "Return TAGS rendered as space-separated `;tag' tokens."
  (mapconcat (lambda (tag) (concat ";" tag)) tags " "))

(defun bookmark-gt-jump--type-token (record)
  "Return the `@TypeName' particle string for RECORD, or nil if unknown."
  (let ((name (bookmark-gt-handler-name record)))
    (and name (not (string= name "Unknown"))
         (concat "@" name))))

(defun bookmark-gt-jump--group-token (record)
  "Return the `+GroupName' particle string for RECORD's group."
  (concat "+" (bookmark-gt-group-name (bookmark-gt-handler-group record))))

(defun bookmark-gt-jump-candidate-default (record)
  "Default candidate formatter for RECORD in `bookmark-gt-jump'.
Returns a propertized string with:
  `bookmark-gt-name'      — the raw record name.
  `bookmark-gt-record'    — the record itself.
  `bookmark-gt-particles' — the `@Type +Group ;tag' tokens for the
                             orderless dispatcher."
  (let* ((name (bookmark-gt-display-name-of record))
         (visible (bookmark-gt-jump--truncate-name name))
         (tags (bookmark-gt-tags-of record))
         (type-token (bookmark-gt-jump--type-token record))
         (group-token (bookmark-gt-jump--group-token record))
         (tag-tokens (and tags (bookmark-gt-jump--tag-tokens tags)))
         (particles (string-join (delq nil (list type-token group-token
                                                 tag-tokens))
                                 " ")))
    (propertize visible
                'bookmark-gt-name name
                'bookmark-gt-record record
                'bookmark-gt-particles
                (and (not (string-empty-p particles)) particles))))

(defun bookmark-gt-jump--candidate-name (candidate)
  "Return the raw bookmark name stored on CANDIDATE, or CANDIDATE itself."
  (or (get-text-property 0 'bookmark-gt-name candidate)
      candidate))

(defun bookmark-gt-jump--candidate-record (candidate records)
  "Return the record CANDIDATE stands for, from RECORDS.
Prefers the `bookmark-gt-record' text property, which CANDIDATE
carries when it is a member of the reader's candidate list.
Otherwise falls back to matching CANDIDATE's name against
RECORDS.

The fallback resolves to the first record of that name when
several share one; making candidate strings unique is what
removes that residual ambiguity."
  (or (get-text-property 0 'bookmark-gt-record candidate)
      (let ((name (bookmark-gt-jump--candidate-name candidate)))
        (seq-find (lambda (r)
                    (equal (substring-no-properties
                            (bookmark-name-from-full-record r))
                           (substring-no-properties name)))
                  records))))

;;;; Orderless dispatchers

(defun bookmark-gt-jump--particle-matcher (prefix-char component)
  "Return an orderless predicate matching the `bookmark-gt-particles' property.
Matches candidates whose particles string contains the
concatenation of PREFIX-CHAR and COMPONENT (case-adjusted).
Candidates without the property are dropped."
  (let* ((needle (concat (string prefix-char) component))
         (case-fold completion-ignore-case)
         (folded (if case-fold (downcase needle) needle)))
    (lambda (str)
      (when-let* ((particles (get-text-property 0 'bookmark-gt-particles str)))
        (string-search folded
                       (if case-fold (downcase particles) particles))))))

(defun bookmark-gt-jump-type-dispatch (component)
  "Orderless matcher for `@'-prefixed COMPONENT."
  (bookmark-gt-jump--particle-matcher ?@ component))

(defun bookmark-gt-jump-group-dispatch (component)
  "Orderless matcher for `+'-prefixed COMPONENT."
  (bookmark-gt-jump--particle-matcher ?+ component))

(defun bookmark-gt-jump-tag-dispatch (component)
  "Orderless matcher for `;'-prefixed COMPONENT."
  (bookmark-gt-jump--particle-matcher ?\; component))

(defun bookmark-gt-jump--orderless-dispatcher (component _index _total)
  "Style dispatcher for `bookmark-gt-jump'.
Routes `@'-prefixed COMPONENT to `bookmark-gt-jump-type-dispatch',
`+'-prefixed COMPONENT to `bookmark-gt-jump-group-dispatch', and
`;'-prefixed COMPONENT to `bookmark-gt-jump-tag-dispatch'.
Returns nil for any other component so orderless applies its
default dispatchers and matching styles."
  (when (> (length component) 1)
    (pcase (aref component 0)
      (?@  (cons #'bookmark-gt-jump-type-dispatch  (substring component 1)))
      (?+  (cons #'bookmark-gt-jump-group-dispatch (substring component 1)))
      (?\; (cons #'bookmark-gt-jump-tag-dispatch   (substring component 1))))))

;;;; Marginalia annotator

(defun bookmark-gt-jump--tags-column-width ()
  "Return the max width of any `;tag ;tag ...' segment in `bookmark-alist'."
  (apply #'max 0
         (mapcar (lambda (entry)
                   (let ((tags (bookmark-gt-tags-of entry)))
                     (if tags
                         (length (bookmark-gt-jump--tag-tokens tags))
                       0)))
                 bookmark-alist)))

(defun bookmark-gt-jump--type-column-width ()
  "Return the max width of any handler `:name' in `bookmark-gt-handler-alist'."
  (apply #'max 0
         (mapcar (lambda (entry) (length (plist-get (cdr entry) :name)))
                 bookmark-gt-handler-alist)))

(defun bookmark-gt-jump--record-path (record)
  "Return the display path for RECORD (filename, URL, or `location').
Uses the bookmark+-compat helpers so a placeholder filename or a
`location'-only URL both render correctly."
  (or (bookmark-gt-filename-of record)
      (bookmark-gt-url-of record)
      ""))

;;;; Location field width
;;
;; Marginalia sizes annotation fields against `marginalia-field-width',
;; which it rebinds per annotation pass to (min (/ window-width 2) 80).
;; That value does not depend on how wide the candidates are, so on
;; a wide frame the annotation ends well before the right edge of
;; the window.
;;
;; Here every visible name is truncated by
;; `bookmark-gt-jump--truncate-name', and the reader holds the whole
;; candidate list before the read opens.  So the reader computes the
;; column where the annotation starts, and the annotator starts the
;; annotation there with a `space :align-to' display property and
;; sizes the location field from the columns left in the window.
;; The widths are column counts, which `bookmark-gt-jump--field'
;; applies directly.  Marginalia's private alignment mechanism is
;; not used, so `marginalia-align' does not apply to these rows.

(defconst bookmark-gt-jump--name-column-step 10
  "The annotation column is rounded up to a multiple of this value.
Rounding keeps the column the same while the widest name changes
by a few characters.")

(defvar bookmark-gt-jump--name-column nil
  "Column at which this read's annotations begin, or nil.
Bound by `bookmark-gt-jump--read-once' for the duration of one
read, so every row of a pass computes the same layout and a
cached annotation cannot disagree with a freshly computed one.
Nil outside a bookmark-gt read — the annotator is registered for
the whole `bookmark' completion category, so `bookmark-jump' and
other packages reach it too.")

(defun bookmark-gt-jump--window-width ()
  "Return the width of the narrowest window displaying the minibuffer.
A minibuffer shown in its own window (`vertico-buffer') is
measured by that window rather than by the frame."
  (let* ((win (active-minibuffer-window))
         (windows (and win (get-buffer-window-list (window-buffer win) nil t))))
    (if windows
        (apply #'min (mapcar #'window-width windows))
      (frame-width))))

(defun bookmark-gt-jump--align-column ()
  "Return the column at which the annotation begins.
During a read this is `bookmark-gt-jump--name-column'.  Outside
a read, where the candidates are unknown, assume a name of the
full `bookmark-gt-jump-name-max-width'."
  (or bookmark-gt-jump--name-column
      (bookmark-gt-jump--column-for bookmark-gt-jump-name-max-width)))

(defun bookmark-gt-jump--column-for (width)
  "Return the annotation column for candidates at most WIDTH wide.
The smallest multiple of `bookmark-gt-jump--name-column-step'
greater than WIDTH, so at least one column separates the widest
candidate from the annotation."
  (* (1+ (floor width bookmark-gt-jump--name-column-step))
     bookmark-gt-jump--name-column-step))

(defun bookmark-gt-jump--location-width (used)
  "Return the column budget for the location field.
USED is the width the tag and type fields occupy in this row.
The result is at least `bookmark-gt-jump--location-min-width' and
at most `bookmark-gt-jump-location-max-width'."
  (let* ((separators (* 3 (string-width marginalia-separator)))
         (free (- (bookmark-gt-jump--window-width)
                  (bookmark-gt-jump--align-column)
                  used separators 1))
         (width (max bookmark-gt-jump--location-min-width free))
         (bound bookmark-gt-jump-location-max-width))
    (cond
     ((null bound) width)
     ((floatp bound) (min width (round (* bound marginalia-field-width))))
     (t (min width bound)))))

(defun bookmark-gt-jump--field (string width face)
  "Return STRING fitted to WIDTH columns and displayed in FACE.
A STRING shorter than the absolute value of WIDTH is padded with
spaces; a longer one is cut and ends in the string that function
`truncate-string-ellipsis' returns.
A negative WIDTH keeps the end of STRING instead of its start.
Only the first line of STRING is used.  When STRING is cut, the
result carries the full STRING as its `help-echo'."
  (let* ((line (car (split-string string "\n")))
         (ellipsis (truncate-string-ellipsis))
         (field (if (< width 0)
                    (reverse (truncate-string-to-width
                              (reverse line) (- width) 0 ?\s ellipsis))
                  (truncate-string-to-width line width 0 ?\s ellipsis))))
    (unless (string-prefix-p string field)
      (put-text-property 0 (length field) 'help-echo string field))
    (put-text-property 0 (length field) 'face face field)
    field))

(defun bookmark-gt-jump-annotate (candidate)
  "Marginalia annotator for a bookmark CANDIDATE.
Returns a three-field annotation: tags, type, location.  The tag
and type fields are truncated to the widest value each can hold;
the location field takes the space those leave free, bounded by
`bookmark-gt-jump-location-max-width'."
  (when (featurep 'marginalia)
    ;; Annotate from the record the candidate carries, not from a
    ;; lookup by name: the visible string may differ from the
    ;; stored name, and a name shared by two records would resolve
    ;; to the first, annotating both rows with one record's data.
    (when-let* ((record (or (get-text-property 0 'bookmark-gt-record candidate)
                            (assoc (bookmark-gt-jump--candidate-name candidate)
                                   bookmark-alist))))
      (let* ((tags (bookmark-gt-tags-of record))
             (tag-seg (if tags (bookmark-gt-jump--tag-tokens tags) ""))
             (tag-w (bookmark-gt-jump--tags-column-width))
             (type (bookmark-gt-handler-name record))
             (type-w (bookmark-gt-jump--type-column-width))
             (filename (bookmark-gt-filename-of record))
             (path (bookmark-gt-jump--record-path record))
             (file-p (stringp filename))
             ;; What this row's tag and type fields render to, which
             ;; is what they subtract from the free space.
             (used (+ (min (string-width tag-seg) tag-w)
                      (min (string-width type) type-w)))
             ;; Negative keeps the end of the string, so a file
             ;; bookmark shows its filename rather than the leading
             ;; directories; positive keeps the start, so a URL shows
             ;; its host.
             (location-w (bookmark-gt-jump--location-width used)))
        (concat
         (propertize " " 'display
                     `(space :align-to (+ left ,(bookmark-gt-jump--align-column))))
         marginalia-separator
         (bookmark-gt-jump--field tag-seg tag-w 'completions-annotations)
         marginalia-separator
         (bookmark-gt-jump--field type type-w 'marginalia-type)
         marginalia-separator
         (bookmark-gt-jump--field path
                                  (if file-p (- location-w) location-w)
                                  'marginalia-file-name))))))

;;;; Marginalia install / uninstall

(defun bookmark-gt-jump--install-marginalia ()
  "Register `bookmark-gt-jump-annotate' as a bookmark-category annotator.
No-op when marginalia is not loaded.  Idempotent, so it is safe to
call from every jump read as well as from `bookmark-gt-mode' on."
  (when (featurep 'marginalia)
    (let ((entry (assq 'bookmark marginalia-annotators)))
      (if entry
          (unless (memq 'bookmark-gt-jump-annotate entry)
            (setcdr entry (cons #'bookmark-gt-jump-annotate (cdr entry))))
        (push '(bookmark bookmark-gt-jump-annotate builtin none)
              marginalia-annotators)))))

(defun bookmark-gt-jump--uninstall-marginalia ()
  "Remove `bookmark-gt-jump-annotate' from the bookmark annotators.
When our entry was the only annotator in the list, drop the whole
`(bookmark ...)' form so marginalia falls back to its built-in
default.  No-op when marginalia is not loaded."
  (when (featurep 'marginalia)
    (let ((entry (assq 'bookmark marginalia-annotators)))
      (when entry
        (setcdr entry (delq 'bookmark-gt-jump-annotate (cdr entry)))
        (when (null (cdr entry))
          (setq marginalia-annotators
                (assq-delete-all 'bookmark marginalia-annotators)))))))

;;;; Mid-read tag filter machinery
;;
;; A jump call is one or more reads composed by a restart
;; loop.  Between reads the caller checks the closure-captured
;; `active-filters' state; if a filter command set the restart
;; flag, the next iteration includes the new filter in the
;; candidate list.  Filter commands throw a quit to abort the
;; current read cleanly.

(defvar bookmark-gt-jump--active-filters nil
  "During a jump read, list of active tag-filter strings.
Bound around the reader; outside a read, always nil.")

(defvar bookmark-gt-jump--restart-p nil
  "During a jump read, set non-nil by a filter command to restart the read.")

(defun bookmark-gt-jump-add-tag-filter ()
  "Add a tag filter to the ongoing `bookmark-gt-jump' read and restart it."
  (interactive)
  (let ((tag (completing-read "Tag filter: "
                              (bookmark-gt-tags-list) nil t)))
    (setq bookmark-gt-jump--active-filters
          (cons tag bookmark-gt-jump--active-filters)
          bookmark-gt-jump--restart-p t))
  (abort-recursive-edit))

(defun bookmark-gt-jump-pop-tag-filter ()
  "Remove the most recent tag filter from the ongoing read and restart."
  (interactive)
  (when bookmark-gt-jump--active-filters
    (setq bookmark-gt-jump--active-filters
          (cdr bookmark-gt-jump--active-filters)
          bookmark-gt-jump--restart-p t)
    (abort-recursive-edit)))

(defun bookmark-gt-jump-clear-tag-filters ()
  "Clear every active tag filter and restart the read."
  (interactive)
  (setq bookmark-gt-jump--active-filters nil
        bookmark-gt-jump--restart-p t)
  (abort-recursive-edit))

(defvar-keymap bookmark-gt-jump-minibuffer-map
  :doc "Additions to the minibuffer keymap during `bookmark-gt-jump'."
  "M-t" #'bookmark-gt-jump-add-tag-filter
  "M-d" #'bookmark-gt-jump-pop-tag-filter
  "M-D" #'bookmark-gt-jump-clear-tag-filters)

(defun bookmark-gt-jump--filter-alist (records)
  "Return RECORDS filtered by `bookmark-gt-jump--active-filters' (AND)."
  (seq-filter
   (lambda (record)
     (seq-every-p (lambda (tag) (bookmark-gt-has-tag-p record tag))
                  bookmark-gt-jump--active-filters))
   records))

(defun bookmark-gt-jump--prompt (base)
  "Return BASE decorated with any active filter chips."
  (if (null bookmark-gt-jump--active-filters)
      base
    (format "%s [%s]"
            base
            (mapconcat (lambda (tag) (concat ";" tag))
                       (reverse bookmark-gt-jump--active-filters) " "))))

;;;; Reader

(defun bookmark-gt-jump--completion-table (candidates)
  "Return a completion table over CANDIDATES for the jump reader.
Its metadata gives category `bookmark', so marginalia and embark
treat the candidates as bookmarks, annotates them with
`bookmark-gt-jump-annotate', and keeps CANDIDATES in the order
given."
  (lambda (string predicate action)
    (if (eq action 'metadata)
        `(metadata (category . bookmark)
                   (annotation-function
                    . ,(lambda (cand)
                         (or (bookmark-gt-jump-annotate cand) "")))
                   (display-sort-function . identity)
                   (cycle-sort-function . identity))
      (complete-with-action action candidates string predicate))))

(defun bookmark-gt-jump--install-keymap ()
  "Add `bookmark-gt-jump-minibuffer-map' to the current minibuffer.
The map is composed over the minibuffer's local map, so its keys
take precedence over those of the completion map in use."
  (use-local-map (make-composed-keymap bookmark-gt-jump-minibuffer-map
                                       (current-local-map))))

(defun bookmark-gt-jump--read-candidate (prompt candidates)
  "Read a member of CANDIDATES under PROMPT with `completing-read'.
Returns the member of CANDIDATES that was selected, which carries
the text properties of the candidate, or the string read when it
is not a member."
  (let ((selected
         (minibuffer-with-setup-hook #'bookmark-gt-jump--install-keymap
           (completing-read (bookmark-gt-jump--prompt prompt)
                            (bookmark-gt-jump--completion-table candidates)
                            nil t nil 'bookmark-history))))
    (or (car (member selected candidates)) selected)))

(defvar bookmark-gt-jump--pool nil
  "Dynamic override for the candidate pool during `bookmark-gt-jump--read'.
When non-nil, `--read-once' iterates this alist instead of the
full `bookmark-alist'.  Bound by the entry points so the elisp
caller can restrict what the reader sees via
`:bookmarks-list' / `:bookmarks-filter'.")

(defvar bookmark-gt-jump--sort-by nil
  "Dynamic sort order during `bookmark-gt-jump--read'.
Values: `mru' (by `last-visited' descending), `visits' (by
`visits' descending), or nil (leave records in the pool's
order).  Bound by the entry points via the `:sort-by' keyword.")

(defvar bookmark-gt-jump--preselect nil
  "Dynamic preselect index during `bookmark-gt-jump--read'.
When a positive integer, the reader positions the cursor on the
N-th candidate by installing a one-shot `minibuffer-setup-hook'
that calls `vertico-next' with N after a small delay.  No-op
when `vertico-mode' is off.  Bound by the entry points via the
`:preselect' keyword.")

(defun bookmark-gt-jump--sort-records (records)
  "Return RECORDS sorted per `bookmark-gt-jump--sort-by'.
The original list is not mutated."
  (pcase bookmark-gt-jump--sort-by
    ('mru
     (sort (copy-sequence records)
           (lambda (a b)
             (time-less-p
              (or (bookmark-prop-get b 'last-visited) '(0 0))
              (or (bookmark-prop-get a 'last-visited) '(0 0))))))
    ('visits
     (sort (copy-sequence records)
           (lambda (a b)
             (> (or (bookmark-prop-get a 'visits) 0)
                (or (bookmark-prop-get b 'visits) 0)))))
    (_ records)))

(declare-function vertico-next "ext:vertico")
(defvar vertico-mode)

(defun bookmark-gt-jump--preselect-advance ()
  "Advance vertico's cursor `bookmark-gt-jump--preselect' rows down.
Called from a small-delay timer inside the minibuffer.  No-op when
`vertico-mode' is off — completion frameworks other than vertico
have no equivalent primitive we can call from here.  After moving,
runs the minibuffer's `post-command-hook', which is where vertico
redisplays its candidate list after a command."
  (let ((n bookmark-gt-jump--preselect))
    (when (and (integerp n) (> n 0)
               (bound-and-true-p vertico-mode)
               (active-minibuffer-window))
      (with-selected-window (active-minibuffer-window)
        (vertico-next n)
        (run-hooks 'post-command-hook)))))

(defun bookmark-gt-jump--preselect-arm ()
  "Install a one-shot `minibuffer-setup-hook' that advances by preselect."
  (let ((setup-fn nil))
    (setq setup-fn
          (lambda ()
            (remove-hook 'minibuffer-setup-hook setup-fn)
            (run-at-time 0 nil #'bookmark-gt-jump--preselect-advance)))
    (add-hook 'minibuffer-setup-hook setup-fn t)))

(defun bookmark-gt-jump--read-once (prompt)
  "One iteration of the jump reader under PROMPT.
Returns the selected bookmark record, or throws `quit' on abort.
Consults `bookmark-gt-jump--pool' when non-nil, otherwise
scans `bookmark-alist'."
  (let* ((source (or bookmark-gt-jump--pool bookmark-alist))
         (records (bookmark-gt-jump--filter-alist source))
         (records (bookmark-gt-jump--sort-records records))
         (candidates (bookmark-gt-with-name-index
                       (mapcar bookmark-gt-jump-candidate-format-function
                               records)))
         ;; Measure the annotation's starting column once, from this
         ;; read's candidates, rather than per annotated row.
         (bookmark-gt-jump--name-column
          (bookmark-gt-jump--column-for
           (apply #'max 1 (mapcar #'string-width candidates))))
         ;; Scope the orderless dispatcher to this read only.
         (orderless-style-dispatchers
          (if (and (featurep 'orderless)
                   (boundp 'orderless-style-dispatchers))
              (cons #'bookmark-gt-jump--orderless-dispatcher
                    orderless-style-dispatchers)
            (and (boundp 'orderless-style-dispatchers)
                 orderless-style-dispatchers))))
    (bookmark-gt-jump--candidate-record
     (bookmark-gt-jump--read-candidate prompt candidates)
     records)))

(defun bookmark-gt-jump--read (prompt)
  "Read a bookmark record under PROMPT, running the tag-filter restart loop.
Runs `bookmark-gt-jump-before-read-hook' exactly once, before the
first reader iteration, so pool-refresh contributors fire per jump
rather than per tag-filter restart.  Also re-runs
`bookmark-gt-jump--install-marginalia' at the top so a marginalia
that loaded after `bookmark-gt-mode' still gets our annotator —
the mode-on install is a no-op in that case."
  (bookmark-gt-jump--install-marginalia)
  (bookmark-gt-enforce-same-name-policy)
  (bookmark-gt-ensure-ids)
  (run-hooks 'bookmark-gt-jump-before-read-hook)
  (let (result)
    (while (null result)
      (setq bookmark-gt-jump--restart-p nil)
      (condition-case nil
          (setq result (bookmark-gt-jump--read-once prompt))
        (quit
         (unless bookmark-gt-jump--restart-p
           (signal 'quit nil)))))
    result))

(defun bookmark-gt-jump--resolve-pool (bookmarks-list bookmarks-filter group)
  "Return the candidate pool, or nil when nothing narrows it.
BOOKMARKS-LIST defaults to `bookmark-alist'; BOOKMARKS-FILTER
and GROUP compose as an AND when both are supplied."
  (let* ((list (or bookmarks-list bookmark-alist))
         (predicate
          (cond
           ((and bookmarks-filter group)
            (lambda (r)
              (and (funcall bookmarks-filter r)
                   (eq (bookmark-gt-handler-group r) group))))
           (bookmarks-filter bookmarks-filter)
           (group (lambda (r) (eq (bookmark-gt-handler-group r) group)))
           (t nil))))
    (cond
     (predicate      (seq-filter predicate list))
     (bookmarks-list list)
     (t              nil))))

(defmacro bookmark-gt-jump--with-read-state
    (pool sort-by preselect &rest body)
  "Bind the jump reader's dynamic state around BODY.
POOL, SORT-BY, and PRESELECT are let-bound into the respective
`bookmark-gt-jump--pool' / `--sort-by' / `--preselect' dynamic
variables so the reader picks them up.  Also arms the preselect
minibuffer-setup hook when PRESELECT is a positive integer."
  (declare (indent 3) (debug t))
  `(let ((bookmark-gt-jump--pool ,pool)
         (bookmark-gt-jump--sort-by ,sort-by)
         (bookmark-gt-jump--preselect ,preselect)
         (bookmark-gt-jump--active-filters nil)
         (bookmark-gt-jump--restart-p nil))
     (when (and (integerp bookmark-gt-jump--preselect)
                (> bookmark-gt-jump--preselect 0))
       (bookmark-gt-jump--preselect-arm))
     ,@body))

;;;###autoload
(cl-defun bookmark-gt-jump
    (&key bookmark display-function bookmarks-list bookmarks-filter
          group (sort-by bookmark-gt-jump-default-sort) preselect)
  "Jump to BOOKMARK, reading it with `completing-read' when nil.

All arguments are keyword.  Interactively, none are supplied —
the reader prompts for the bookmark.

- :BOOKMARK — bookmark name or record.  When nil, prompt.
- :DISPLAY-FUNCTION — passed to `bookmark-jump' as its optional
  DISPLAY-FUNC (a fn of one argument, a buffer).  Defaults to
  the built-in same-window handler.
- :BOOKMARKS-LIST — alist in the shape of `bookmark-alist' to
  use as the candidate pool.  Defaults to `bookmark-alist'.
  Ignored when :BOOKMARK is supplied.
- :BOOKMARKS-FILTER — predicate on a record; a candidate is kept
  when the predicate returns non-nil.  Ignored when :BOOKMARK
  is supplied.
- :GROUP — group symbol from `bookmark-gt-group-alist' (e.g.
  `web', `file', `doc').  Only records whose
  `bookmark-gt-handler-group' matches survive.  Composes AND
  with :BOOKMARKS-FILTER when both are supplied.  Ignored when
  :BOOKMARK is supplied.
- :SORT-BY — sort order for the candidate pool.  `mru' sorts by
  the record's `last-visited' prop descending; `visits' sorts by
  the `visits' prop descending; nil leaves the pool's original
  order.  Defaults to `bookmark-gt-jump-default-sort' (\\='mru
  out of the box).
- :PRESELECT — positive integer.  When set (and `vertico-mode'
  is on), the reader positions the cursor on the N-th candidate
  via a one-shot `minibuffer-setup-hook'.

Narrowing particles in the minibuffer (requires `orderless'):
  `@TYPE'    — narrow to bookmarks of TYPE.
  `+GROUP'   — narrow to bookmarks in GROUP.
  `;TAG'     — narrow to bookmarks carrying TAG.

Minibuffer keys:
  `M-t'  add a tag filter (restart).
  `M-d'  pop the most recent tag filter.
  `M-D'  clear every active tag filter."
  (interactive)
  (bookmark-maybe-load-default-file)
  (let* ((pool (bookmark-gt-jump--resolve-pool bookmarks-list
                                               bookmarks-filter
                                               group))
         (record (bookmark-gt--resolve
                  (or bookmark
                      (bookmark-gt-jump--with-read-state pool sort-by preselect
                        (bookmark-gt-jump--read "Jump to bookmark: ")))
                  "Jump to bookmark")))
    (bookmark-gt-jump-record record display-function)))

;;;###autoload
(cl-defun bookmark-gt-jump-other-window
    (&key bookmark bookmarks-list bookmarks-filter group
          (sort-by bookmark-gt-jump-default-sort) preselect)
  "Like `bookmark-gt-jump' but display in another window.
:BOOKMARK, :BOOKMARKS-LIST, :BOOKMARKS-FILTER, :GROUP,
:SORT-BY, and :PRESELECT have the same meaning as in
`bookmark-gt-jump'.  :DISPLAY-FUNCTION is not accepted here —
the display function is fixed to another window."
  (interactive)
  (bookmark-maybe-load-default-file)
  (let* ((pool (bookmark-gt-jump--resolve-pool bookmarks-list
                                               bookmarks-filter
                                               group))
         (record (bookmark-gt--resolve
                  (or bookmark
                      (bookmark-gt-jump--with-read-state pool sort-by preselect
                        (bookmark-gt-jump--read "Jump (other window)")))
                  "Jump (other window)")))
    (bookmark-gt-jump-record record #'switch-to-buffer-other-window)))

;;;###autoload
(cl-defun bookmark-gt-jump-tagged
    (&key tag bookmark bookmarks-list bookmarks-filter group
          (sort-by bookmark-gt-jump-default-sort) preselect)
  "Jump to a bookmark, prefiltered by TAG.
:TAG (required, a string) seeds the reader's active tag filter.
:BOOKMARK, :BOOKMARKS-LIST, :BOOKMARKS-FILTER, :GROUP,
:SORT-BY, and :PRESELECT have the same meaning as in
`bookmark-gt-jump'.

Interactively, :TAG is prompted for from the set of known tags."
  (interactive (list :tag (completing-read
                           "Tag: " (bookmark-gt-tags-list) nil t)))
  (unless (stringp tag)
    (user-error "bookmark-gt-jump-tagged: :TAG must be a string"))
  (bookmark-maybe-load-default-file)
  (let* ((pool (bookmark-gt-jump--resolve-pool bookmarks-list
                                               bookmarks-filter
                                               group))
         (record (or bookmark
                     (let ((bookmark-gt-jump--pool pool)
                         (bookmark-gt-jump--sort-by sort-by)
                         (bookmark-gt-jump--preselect preselect)
                         (bookmark-gt-jump--active-filters (list tag))
                         (bookmark-gt-jump--restart-p nil))
                     (when (and (integerp preselect) (> preselect 0))
                       (bookmark-gt-jump--preselect-arm))
                     (bookmark-gt-jump--read (format "Jump [;%s]" tag))))))
    (bookmark-gt-jump-record (bookmark-gt--resolve record "Jump"))))

(provide 'bookmark-gt-jump)


;; Local Variables:
;; package-lint-main-file: "bookmark-gt.el"
;; End:

;;; bookmark-gt-jump.el ends here
