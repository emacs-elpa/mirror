;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bookmark-gt" "0.9.0.0.20261109.24"
  "Records-only bookmark manager."
  '((emacs "30.1"))
  :url "https://github.com/dmgerman/bookmark-gt"
  :commit "8cd47d67b79cbbaae95ae4296e73c06e6fe35823"
  :revdesc "8cd47d67b79c"
  :keywords '("convenience" "matching" "hypermedia")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
