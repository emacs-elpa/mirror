;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "2.5.0.20260916.3"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "379c3e9e75dce8ef0120de454c6afd1b650f36fe"
  :revdesc "2.5-3-g379c3e9e75dc"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
