;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "6.1.0.0.20260612.4"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (markdown-mode  "2.0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "f5674b69135a49aa3d531d148609942e0b09913b"
  :revdesc "v6.1.0-4-gf5674b69135a"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
