;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "0.1.1.0.20260706.18"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "4d7bbad3e9b70fe0755174a79d5b7e59dfb6d3f7"
  :revdesc "4d7bbad3e9b7"
  :keywords '("convenience" "chinese" "input-method" "rime"))
