;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flutter-l10n-flycheck" "0.1.0.0.20240823.80"
  "Flycheck checker for intl_translation."
  '((emacs    "26.1")
    (flycheck "30")
    (flutter  "0.1.0"))
  :url "https://github.com/amake/flutter.el"
  :commit "e71235d400787d977da7ed792709437899c2a03c"
  :revdesc "e71235d40078"
  :keywords '("languages"))
