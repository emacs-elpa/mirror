;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perfect-margin" "0.1.0.20251209.59"
  "Auto center windows, works with line numbers."
  '((emacs "25.1"))
  :url "https://github.com/mpwang/perfect-margin"
  :commit "d38a2ff6b89dde81da03e8f4a83c0cad2baade0e"
  :revdesc "d38a2ff6b89d"
  :keywords '("convenience" "frames")
  :authors '(("Randall Wang" . "randall.wjz@gmail.com"))
  :maintainers '(("Randall Wang" . "randall.wjz@gmail.com")))
