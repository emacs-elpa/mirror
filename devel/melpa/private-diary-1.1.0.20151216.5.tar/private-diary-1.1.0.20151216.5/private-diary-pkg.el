;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "private-diary" "1.1.0.20151216.5"
  "Maintain a private diary in Emacs."
  '((emacs "24.0"))
  :url "https://github.com/cacology/private-diary"
  :commit "5b1aeb22f22447fd35e1c107b6db44a7b27b8a42"
  :revdesc "5b1aeb22f224"
  :keywords '("diary" "encryption")
  :authors '(("James P. Ascher" . "jpa4q@virginia.edu"))
  :maintainers '(("James P. Ascher" . "jpa4q@virginia.edu")))
