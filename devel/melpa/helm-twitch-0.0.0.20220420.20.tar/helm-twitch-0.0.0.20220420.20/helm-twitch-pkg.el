;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-twitch" "0.0.0.20220420.20"
  "Navigate Twitch.tv via `helm'."
  '((dash       "2.11.0")
    (helm       "1.5")
    (emacs      "24")
    (twitch-api "20210809.1641")
    (streamlink "20210811.1429"))
  :url "https://github.com/BenediktBroich/helm-twitch"
  :commit "27fbec24cc250d508cd2f4286da16262752908eb"
  :revdesc "27fbec24cc25"
  :keywords '("helm" "twitch" "games")
  :authors '(("Aaron Jacobs" . "atheriel@gmail.com"))
  :maintainers '(("Aaron Jacobs" . "atheriel@gmail.com")))
