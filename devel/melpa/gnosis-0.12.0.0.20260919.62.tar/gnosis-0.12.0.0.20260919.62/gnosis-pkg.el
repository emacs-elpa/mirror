;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "0.12.0.0.20260919.62"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "31a69f6d8c834a901e5d919baab4e4e981af6d86"
  :revdesc "31a69f6d8c83"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
