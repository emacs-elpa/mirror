;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "line-up-words" "1.0.0.0.20241121.45"
  "Align words in an intelligent way."
  ()
  :url "https://github.com/janestreet/line-up-words"
  :commit "3c1339a3fb3840dfaea50d8cb966c90b19d14925"
  :revdesc "3c1339a3fb38")
