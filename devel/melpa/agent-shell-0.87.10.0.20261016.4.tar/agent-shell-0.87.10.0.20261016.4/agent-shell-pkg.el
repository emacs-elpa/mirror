;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.87.10.0.20261016.4"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "9e3dd48f9aaa8be314c4012a1f9bff69208f2c00"
  :revdesc "9e3dd48f9aaa")
