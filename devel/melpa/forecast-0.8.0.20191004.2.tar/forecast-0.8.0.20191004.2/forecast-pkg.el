;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forecast" "0.8.0.20191004.2"
  "Weather forecasts."
  '((emacs "24.4"))
  :url "https://dev.gkayaalp.com/elisp/index.html#forecast-el"
  :commit "5f3e67448cc98fe2875115163849acae4d9e8526"
  :revdesc "5f3e67448cc9"
  :keywords '("weather" "forecast")
  :authors '(("Göktuğ Kayaalp" . "self@gkayaalp.com"))
  :maintainers '(("Göktuğ Kayaalp" . "self@gkayaalp.com")))
