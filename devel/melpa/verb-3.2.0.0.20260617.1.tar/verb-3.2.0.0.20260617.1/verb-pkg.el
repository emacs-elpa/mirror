;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verb" "3.2.0.0.20260617.1"
  "Organize and send HTTP requests."
  '((emacs "26.3"))
  :url "https://github.com/federicotdn/verb"
  :commit "25a25456bb9ef5090d80105aaa8ad931f336a06e"
  :revdesc "3.2.0-1-g25a25456bb9e"
  :keywords '("tools")
  :authors '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers '(("Federico Tedin" . "federicotedin@gmail.com")))
