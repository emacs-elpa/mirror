;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frame-mode" "0.0.0.0.20230823.16"
  "Use frames instead of windows."
  '((s     "1.9.0")
    (emacs "24.4"))
  :url "https://github.com/IvanMalison/frame-mode"
  :commit "ab5e568a7c7259d31c252c263458bd76490241d0"
  :revdesc "ab5e568a7c72"
  :keywords '("frames")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
