;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-swiftx" "1.0.2.0.20200814.4"
  "Flycheck: Swift backend."
  '((emacs         "26.1")
    (flycheck      "26")
    (xcode-project "1.0"))
  :url "https://github.com/nhojb/flycheck-swiftx"
  :commit "4d0c8ca0540b06fb947a83f1a38a6003a5abe0d4"
  :revdesc "4d0c8ca0540b"
  :keywords '("convenience" "languages" "tools")
  :authors '(("John Buckley" . "john@olivetoast.com"))
  :maintainers '(("John Buckley" . "john@olivetoast.com")))
