;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-demos" "2024.1.16.0.20240128.31"
  "Elisp API Demos."
  '((emacs "26.3"))
  :url "https://github.com/xuchunyang/elisp-demos"
  :commit "1a108d1c5011f9ced58be2ca98bea1fbd4130a2f"
  :revdesc "1a108d1c5011"
  :keywords '("lisp" "docs"))
