;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime-theme" "20141116.0.20170808.5"
  "An Emacs 24 theme based on Slime (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "8e5880ac69e0b6a079103001cc3a90bdb688998f"
  :revdesc "8e5880ac69e0")
