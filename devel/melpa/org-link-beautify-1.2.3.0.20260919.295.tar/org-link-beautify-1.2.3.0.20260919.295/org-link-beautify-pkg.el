;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "1.2.3.0.20260919.295"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "aac88b3921ac98260d47dc29a4b8b32bb555db38"
  :revdesc "aac88b3921ac"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
