;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-php" "2.8.3.0.20261105.2"
  "A company back-end for PHP."
  '((cl-lib      "0.5")
    (ac-php-core "2.0")
    (company     "0.9"))
  :url "https://github.com/xcwen/ac-php"
  :commit "bb0911bd0edfb5fdf6d685dd520510379572c304"
  :revdesc "v2.8.3-2-gbb0911bd0edf"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
