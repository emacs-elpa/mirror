;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-notebook" "1.1.0.20170322.9"
  "Ease the use of org-mode as a notebook."
  '((emacs  "24")
    (org    "8")
    (cl-lib "0.5"))
  :url "https://github.com/Rahi374/org-notebook"
  :commit "d90c4aeca2442161e6dd89de175561af85aace03"
  :revdesc "d90c4aeca244"
  :keywords '("convenience" "tools")
  :authors '(("Paul Elder" . "paul.elder@amanokami.net"))
  :maintainers '(("Paul Elder" . "paul.elder@amanokami.net")))
