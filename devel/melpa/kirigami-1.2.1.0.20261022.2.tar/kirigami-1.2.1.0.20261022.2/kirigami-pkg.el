;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.2.1.0.20261022.2"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "2f7eaae4eea8a0008df4be57918feae228059f25"
  :revdesc "1.2.1-2-g2f7eaae4eea8"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
