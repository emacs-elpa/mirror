;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "md-ts-mode" "0.3.0.0.20260823.5"
  "Major mode for Markdown using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/dnouri/md-ts-mode"
  :commit "13e175beebe3ab2cbfa65186949b990bb26e1fd4"
  :revdesc "v0.3.0-5-g13e175beebe3"
  :keywords '("markdown" "languages" "tree-sitter")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
