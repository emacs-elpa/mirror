;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dircmp" "1.0.20141204.12"
  "Compare and sync directories."
  ()
  :url "https://github.com/matthewlmcclure/dircmp-mode"
  :commit "558ee0b601c2de9d247612085aafe2926f56a09f"
  :revdesc "558ee0b601c2"
  :keywords '("unix" "tools"))
