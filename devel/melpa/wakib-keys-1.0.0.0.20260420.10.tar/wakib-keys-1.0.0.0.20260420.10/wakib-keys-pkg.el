;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wakib-keys" "1.0.0.0.20260420.10"
  "Minor Mode for Modern Keybindings."
  '((emacs "27.1"))
  :url "https://github.com/darkstego/wakib-keys/"
  :commit "39a8cd3c61b4d2b1f93e2de8e56906f4a648959b"
  :revdesc "39a8cd3c61b4"
  :keywords '("convenience" "keybindings" "keys"))
