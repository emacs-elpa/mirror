;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ffmpeg-player" "0.2.1.0.20260101.48"
  "Play video using ffmpeg."
  '((emacs "24.4")
    (s     "1.12.0")
    (f     "0.20.0"))
  :url "https://github.com/jcs-elpa/ffmpeg-player"
  :commit "97205aa6c47875c75d10385f22ea0ef3c8a1a880"
  :revdesc "97205aa6c478"
  :keywords '("multimedia" "video" "ffmpeg" "buffering" "images")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
