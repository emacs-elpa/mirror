;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-who" "1.0.0.20240916.12"
  "A s-expression html DSL library compatible with cl-who."
  '((emacs "25.1"))
  :url "https://github.com/alejandrogallo/el-who"
  :commit "bfefb23742ac3695578d4b748895df5ccbba6b44"
  :revdesc "bfefb23742ac"
  :keywords '("lisp" "hypermedia" "docs" "tools" "html" "web")
  :authors '(("Alejandro Gallo" . "aamsgallo@gmail.com"))
  :maintainers '(("Alejandro Gallo" . "aamsgallo@gmail.com")))
