;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unfill" "0.3.0.20230227.9"
  "Do the opposite of fill-paragraph or fill-region."
  '((emacs "24.1"))
  :url "https://github.com/purcell/unfill"
  :commit "075052ce0b4451d7d3ede013ce5a77e6a7a92360"
  :revdesc "075052ce0b44"
  :keywords '("convenience")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
