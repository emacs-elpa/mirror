;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "0.3.2.0.20260626.34"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "ee8fdeb692d666c12ce068a2b1ee90e9451ac892"
  :revdesc "v0.3.2-34-gee8fdeb692d6"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
