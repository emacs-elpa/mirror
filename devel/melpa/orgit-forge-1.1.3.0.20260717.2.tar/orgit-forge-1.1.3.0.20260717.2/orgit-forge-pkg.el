;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit-forge" "1.1.3.0.20260717.2"
  "Org links to Forge issue buffers."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (forge    "0.6")
    (magit    "4.6")
    (org      "9.8")
    (orgit    "2.2"))
  :url "https://github.com/magit/orgit-forge"
  :commit "f812864aae188bbbc36725c87bd92909ff0dda3a"
  :revdesc "v1.1.3-2-gf812864aae18"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev")))
