;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "2.7.0.20260725.16"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/cape"
  :commit "d3dd033dd261b31cf6f87df35cd83c8a6e31573b"
  :revdesc "2.7-16-gd3dd033dd261"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
