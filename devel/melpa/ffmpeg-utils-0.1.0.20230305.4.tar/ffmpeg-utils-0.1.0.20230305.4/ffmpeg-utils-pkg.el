;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ffmpeg-utils" "0.1.0.20230305.4"
  "FFmpeg command utilities wrappers."
  '((emacs     "25.1")
    (alert     "1.2")
    (transient "0.1.0"))
  :url "https://repo.or.cz/ffmpeg-utils.git"
  :commit "064d61527bc6b6a1d0fb0065f8a7bae3bbd4cefc"
  :revdesc "064d61527bc6"
  :keywords '("multimedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
