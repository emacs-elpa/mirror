;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "monokai-pro-theme" "0.2.0.20250116.5"
  "A simple theme based on the Monokai Pro Sublime color schemes."
  ()
  :url "https://github.com/belak/emacs-monokai-pro-theme"
  :commit "2c886bbeeb354f5f9da7435b2662f6b1511d17e8"
  :revdesc "2c886bbeeb35"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
