;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-mode" "4.4.0"
  "Major-mode for editing CMake sources."
  '((emacs "24.1"))
  :commit "44125a9e977c834f06ac1e5fe8db55355261ef87"
  :revdesc "v4.4.0-0-g44125a9e977c")
