;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haskell-emacs" "4.0.3.0.20240205.6"
  "Write emacs extensions in haskell."
  ()
  :url "https://github.com/knupfer/haskell-emacs"
  :commit "777d5209f70229b53e4a60a09d1b714d233b0a7c"
  :revdesc "777d5209f702"
  :keywords '("haskell" "emacs" "ffi"))
