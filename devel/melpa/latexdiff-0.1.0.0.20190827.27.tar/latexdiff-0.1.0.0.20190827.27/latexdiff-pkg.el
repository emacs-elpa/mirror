;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latexdiff" "0.1.0.0.20190827.27"
  "Latexdiff integration in Emacs."
  '((emacs "24.4"))
  :url "https://github.com/galaunay/latexdiff.el"
  :commit "56d0b240867527d1b43d3ddec14059361929b971"
  :revdesc "56d0b2408675"
  :keywords '("tex" "vc" "tools" "git" "helm")
  :authors '(("Launay Gaby" . "gaby.launay@tutanota.com"))
  :maintainers '(("Launay Gaby" . "gaby.launay@tutanota.com")))
