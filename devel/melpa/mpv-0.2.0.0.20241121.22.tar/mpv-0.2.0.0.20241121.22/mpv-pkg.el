;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpv" "0.2.0.0.20241121.22"
  "Control mpv for easy note-taking."
  '((emacs "25.1"))
  :url "https://github.com/kljohann/mpv.el"
  :commit "62cb8825d525d7c9475dd93d62ba84d419bc4832"
  :revdesc "62cb8825d525"
  :keywords '("tools" "multimedia")
  :authors '(("Johann Klähn" . "johann@jklaehn.de"))
  :maintainers '(("Johann Klähn" . "johann@jklaehn.de")))
