;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kooten-theme" "20140104.1059.0.20161023.15"
  "Dark color theme."
  '((emacs "24.1"))
  :url "https://github.com/kootenpv/emacs-kooten-theme"
  :commit "d10197b4dd7af02cd14aeab2573c273a294798c3"
  :revdesc "d10197b4dd7a"
  :keywords '("themes")
  :authors '(("Pascal van Kooten" . "kootenpv@gmail.com"))
  :maintainers '(("Pascal van Kooten" . "kootenpv@gmail.com")))
