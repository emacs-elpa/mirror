;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-prog-extra" "0.2.0.20260810.56"
  "Customizable highlighting for source-code."
  '((emacs "27.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra"
  :commit "2896595512b4e0fe36f915227bd5db4d158cc658"
  :revdesc "2896595512b4"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
