;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-emms" "0.2.0.20260829.11"
  "Playback multimedia files from Org documents."
  '((emacs "24.4")
    (org   "9.3")
    (emms  "0.0"))
  :url "https://git.sr.ht/~jagrg/org-emms"
  :commit "5f4d71a1654e71b1ad6885ffbadf46b6d271fa57"
  :revdesc "5f4d71a1654e"
  :keywords '("multimedia")
  :authors '(("Jonathan Gregory" . "jagrgatposteodotcom"))
  :maintainers '(("Jonathan Gregory" . "jagrgatposteodotcom")))
