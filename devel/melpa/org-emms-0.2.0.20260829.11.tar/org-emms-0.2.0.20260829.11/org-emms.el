;;; org-emms.el --- Playback multimedia files from Org documents  -*- lexical-binding: t; -*-

;; Copyright (C) 2016-2026 Jonathan Gregory

;; Author: Jonathan Gregory <jagrg at posteo dot com>
;; Package-Version: 0.2.0.20260829.11
;; Package-Revision: 5f4d71a1654e
;; URL: https://git.sr.ht/~jagrg/org-emms
;; Keywords: multimedia
;; Package-Requires: ((emacs "24.4") (org "9.3") (emms "0.0"))

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; This package provides an Org link type for playing multimedia files
;; with EMMS, The Emacs Multimedia System. If the link contains a
;; track position, playback will start at the specified position. For
;; example:
;;
;; [[emms:/path/to/audio.mp3::2:43]]     Starts playback at 2 min 43 sec.
;; [[emms:/path/to/audio.mp3::1:10:45]]  Starts playback at 1 hr 10 min 45 sec.
;; [[emms:/path/to/audio.mp3::49]]       Starts playback at 0 min 49 sec.
;;
;; Available commands include `org-emms-insert-link`,
;; `org-emms-insert-track`, `org-emms-insert-track-position`
;;
;; It is also possible to store an Org link from an EMMS playlist or
;; browser buffer with `org-store-link`, then insert it into an Org
;; buffer with `org-insert-link`.
;;
;; See also: http://orgmode.org/worg/code/elisp/org-player.el

;;; Code:

(require 'ol)
(require 'subr-x)
(require 'emms)
(require 'emms-playing-time)
(require 'emms-source-file)

(defgroup org-emms nil
  "Connection between EMMS and `org-mode'."
  :prefix "org-emms-"
  :group 'multimedia)

(defcustom org-emms-default-directory nil
  "A directory where multimedia files are stored."
  :type 'directory
  :group 'org-emms)

(defcustom org-emms-delay 0
  "Time in seconds between starting playing and seeking to time.
If your org link has a track position, but the EMMS player does
not start playing at that position, most likely the problem is
that it starts seeking before the player starts playing.  If this
is your case, set this variable to 1 or 2 seconds."
  :type 'integer
  :group 'org-emms)

(defcustom org-emms-time-format "%.2h:%.2m:%.2s"
  "Format string for a track position in org links.
This string is passed to `format-seconds' function."
  :type 'string
  :group 'org-emms)

(defun org-emms-time-string-to-seconds (s)
  "Convert timestring S (\"HH:MM:SS\") to a number of seconds.
Hours, minutes and leading zeros are optional."
  (save-match-data
    (if (stringp s)
	    (if (string-match "\\([0-9]+:\\)?\\([0-9]+\\):\\([0-9]+\\)" s)
	        (let ((hh (if (match-beginning 1) (string-to-number (match-string 1 s)) 0))
		          (mm (string-to-number (match-string 2 s)))
		          (ss (string-to-number (match-string 3 s))))
	          (+ (* hh 3600) (* mm 60) ss))
	      (string-to-number s))
      s)))

(defun org-emms--seek-when-current (file seconds)
  "Seek FILE to SECONDS when FILE is still the current track."
  (let* ((track (emms-playlist-current-selected-track))
	     (current-file (and track (emms-track-name track))))
    (when (and current-file
	           (file-equal-p file current-file))
      (emms-seek-to seconds))))

(defun org-emms-play (path _arg)
  "Follow the EMMS Org link specified by PATH.
If PATH contains a track position, start there.  Otherwise, play
from the beginning."
  (let* ((parts (split-string path "::"))
	     (file (expand-file-name (car parts)))
	     (time (org-emms-time-string-to-seconds (cadr parts)))
	     (track (emms-playlist-current-selected-track))
	     (current-file (and track (emms-track-name track)))
	     (current-p (and emms-player-playing-p
			             current-file
			             (file-equal-p file current-file))))
    ;; Do not start a track again (just seek to time) if we want to open
    ;; a link with the currently playing track.
    (unless current-p
      (emms-play-file file))
    (when time
      (if (and (not current-p)
	           (> org-emms-delay 0))
	      (run-at-time org-emms-delay nil
		               #'org-emms--seek-when-current file time)
	    (emms-seek-to time)))))

(org-link-set-parameters
 "emms"
 :follow #'org-emms-play
 :store #'org-emms-store-link)

(defun org-emms--link-string (path &optional position description)
  "Return an Org EMMS link for PATH.
When POSITION is non-nil, append it to the link path.  Use DESCRIPTION
as the Org link description."
  (org-link-make-string
   (concat "emms:"
           path
           (when position
             (concat "::" position)))
   description))

(defun org-emms-make-link ()
  "Return org link for the the current EMMS track.
The return value is a cons cell (link . description)."
  (let ((track (emms-playlist-current-selected-track)))
    (cons (concat "emms:" (emms-track-name track)
                  (and (/= 0 emms-playing-time)
                       (concat "::"
                               (format-seconds org-emms-time-format
                                               emms-playing-time))))
          (emms-info-track-description track))))

(defun org-emms-store-link (&optional _interactive)
  "Store an Org link for the current EMMS track.
_INTERACTIVE is accepted for compatibility with Org's link storage API."
  (when (derived-mode-p 'emms-playlist-mode
                        'emms-browser-mode)
    (let ((link (org-emms-make-link)))
      (org-link-store-props
       :type        "emms"
       :link        (car link)
       :description (cdr link)))))

;;;###autoload
(defun org-emms-insert-link (arg)
  "Insert org link using completion.
Prompt for a file name and link description.  With a prefix ARG, prompt
for a track position."
  (interactive "P")
  (let* ((file (read-file-name "File: " org-emms-default-directory))
         (path (file-relative-name file)))
    (if arg
	    (let ((position (read-string "Track position (hh:mm:ss): ")))
	      (when (string-empty-p position)
	        (user-error "Track position cannot be empty"))
	      (insert (org-emms--link-string path position position)))
      (let ((description (read-string "Description: ")))
	    (insert
	     (org-emms--link-string
	      path
	      nil
	      (unless (string-empty-p description)
	        description)))))))

;;;###autoload
(defun org-emms-insert-track ()
  "Insert current selected track as an org link."
  (interactive)
  (let* ((track (emms-playlist-current-selected-track))
	     (file (emms-track-name track))
	     (title (emms-track-get track 'info-title)))
    (when (derived-mode-p 'org-mode)
      (insert
       (org-emms--link-string file nil title)))))

;;;###autoload
(defun org-emms-insert-track-position ()
  "Insert current track position as an org link."
  (interactive)
  (let* ((track (emms-playlist-current-selected-track))
	     (file (emms-track-name track))
	     (tp (format-seconds org-emms-time-format emms-playing-time)))
    (insert
     (if (derived-mode-p 'org-mode)
	     (org-emms--link-string file tp tp)
       (format "[%s]" tp)))))

(provide 'org-emms)
;;; org-emms.el ends here
