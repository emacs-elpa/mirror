;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-pyright" "0.3.0.0.20260507.13"
  "Python LSP client using Pyright."
  '((emacs    "29.1")
    (lsp-mode "7.0")
    (dash     "2.18.0")
    (ht       "2.0"))
  :url "https://github.com/emacs-lsp/lsp-pyright"
  :commit "187e08caee4e1630a9975f492274c739f325392f"
  :revdesc "187e08caee4e"
  :keywords '("languages" "tools" "lsp"))
