;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "region-cursors" "0.1.0"
  "Display point and active mark using overlays."
  '((emacs "27.1"))
  :url "https://github.com/abidanBrito/region-cursors"
  :commit "a859ce725ad1ae52a97b46761f605eef6dd61918"
  :revdesc "v0.1.0-0-ga859ce725ad1"
  :keywords '("convenience" "editing" "faces")
  :authors '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com"))
  :maintainers '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com")))
