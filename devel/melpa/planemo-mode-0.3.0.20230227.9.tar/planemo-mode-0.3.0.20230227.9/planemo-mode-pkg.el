;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "planemo-mode" "0.3.0.20230227.9"
  "Minor mode for editing Galaxy XML files."
  '((emacs "27.1")
    (dash  "2.17.0"))
  :url "https://gitlab.com/mtekman/planemo-mode.el"
  :commit "537ebe40688ca8f3786aa1e9842265e6f34584d2"
  :revdesc "537ebe40688c"
  :keywords '("outlines"))
