;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cucumber-goto-step" "0.0.1.0.20131210.3"
  "Jump to cucumber step definition."
  '((pcre2el "1.5"))
  :url "http://orthogonal.me"
  :commit "f2713ffb26ebe1b757d1f2ea80e900b55e5895aa"
  :revdesc "f2713ffb26eb"
  :authors '(("Glen Stampoultzis" . "gstamp@gmail.com"))
  :maintainers '(("Glen Stampoultzis" . "gstamp@gmail.com")))
