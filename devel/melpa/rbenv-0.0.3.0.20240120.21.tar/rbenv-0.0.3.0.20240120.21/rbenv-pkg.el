;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rbenv" "0.0.3.0.20240120.21"
  "Emacs integration for rbenv."
  ()
  :url "https://github.com/senny/rbenv.el"
  :commit "588b817d510737b9d6afd6d1ecddd517d96b78e5"
  :revdesc "v0.0.3-21-g588b817d5107"
  :keywords '("ruby" "rbenv")
  :authors '(("Yves Senn" . "yves.senn@gmail.com"))
  :maintainers '(("Yves Senn" . "yves.senn@gmail.com")))
