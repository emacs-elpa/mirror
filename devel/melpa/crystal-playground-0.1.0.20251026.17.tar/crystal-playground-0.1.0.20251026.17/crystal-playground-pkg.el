;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crystal-playground" "0.1.0.20251026.17"
  "Local crystal playground for short code snippets."
  '((emacs        "25")
    (crystal-mode "0.1.2"))
  :url "https://github.com/jasonrobot/crystal-playground"
  :commit "9920cab99b02c6da70dfe1c3325146d062c14288"
  :revdesc "9920cab99b02"
  :keywords '("tools" "crystal"))
