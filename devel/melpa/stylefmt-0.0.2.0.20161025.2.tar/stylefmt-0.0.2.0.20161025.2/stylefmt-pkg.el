;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stylefmt" "0.0.2.0.20161025.2"
  "Stylefmt interface."
  ()
  :url "https://github.com/KeenS/stylefmt.el"
  :commit "7a38f26bf8ff947215f34f0a064c7ca80575ccbc"
  :revdesc "7a38f26bf8ff"
  :keywords '("style" "code" "formatter"))
