;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-lesim" "0.2.0.20230619.3"
  "Org-babel functions for lesim-mode."
  '((emacs      "28.1")
    (org        "9.3")
    (lesim-mode "0.3.3"))
  :url "https://github.com/drghirlanda/ob-lesim"
  :commit "37e15f610783ff12926b5d221cefb4a49b4d54d6"
  :revdesc "37e15f610783"
  :keywords '("languages" "tools")
  :authors '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainers '(("Stefano Ghirlanda" . "drghirlanda@gmail.com")))
