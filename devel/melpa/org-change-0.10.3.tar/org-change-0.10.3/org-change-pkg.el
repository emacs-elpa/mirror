;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "0.10.3"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "5ee789e00157c7cbd88ae8b97f3408f303f1878e"
  :revdesc "5ee789e00157"
  :keywords '("wp" "convenience"))
