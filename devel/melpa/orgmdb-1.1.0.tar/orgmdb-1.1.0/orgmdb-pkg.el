;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgmdb" "1.1.0"
  "An OMDb API client with some convenience functions."
  '((emacs "27.1")
    (dash  "2.11.0")
    (s     "1.12.0")
    (org   "8.0.0"))
  :url "https://github.com/isamert/orgmdb.el"
  :commit "4f24d187e2bf484ef4f68c191324659dca62c2f6"
  :revdesc "4f24d187e2bf"
  :authors '(("Isa Mert Gurbuz" . "isamert@protonmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamert@protonmail.com")))
