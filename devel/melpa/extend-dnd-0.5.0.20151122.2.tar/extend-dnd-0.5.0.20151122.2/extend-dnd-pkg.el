;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "extend-dnd" "0.5.0.20151122.2"
  "R drag and Drop."
  ()
  :url "https://github.com/mlf176f2/extend-dnd"
  :commit "80c966c93b82c9bb5c6225a432557c39144fc602"
  :revdesc "v0.5-2-g80c966c93b82"
  :keywords '("extend" "drag and drop"))
