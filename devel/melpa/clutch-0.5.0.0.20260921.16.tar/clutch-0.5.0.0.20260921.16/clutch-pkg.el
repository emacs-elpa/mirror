;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.0.0.20260921.16"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "fc26edad6fda900649f70232eaa35d478419448e"
  :revdesc "fc26edad6fda"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
