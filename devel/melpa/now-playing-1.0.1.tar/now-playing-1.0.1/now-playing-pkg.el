;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "now-playing" "1.0.1"
  "Interface for the macOS Music app."
  '((emacs     "30.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/now-playing"
  :commit "5b9776a84eb8dfdc3485565b7e15b9138e4aacaf"
  :revdesc "5b9776a84eb8"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
