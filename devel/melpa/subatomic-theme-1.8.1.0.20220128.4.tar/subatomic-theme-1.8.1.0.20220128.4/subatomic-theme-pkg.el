;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "subatomic-theme" "1.8.1.0.20220128.4"
  "Low contrast bluish color theme."
  ()
  :url "https://github.com/cryon/subatomic"
  :commit "9d0ac6aa5272d0285965a48505eb35658c5472b0"
  :revdesc "1.8.1-4-g9d0ac6aa5272"
  :keywords '("color-theme" "blue" "low contrast")
  :authors '(("John Olsson" . "john@cryon.se"))
  :maintainers '(("John Olsson" . "john@cryon.se")))
