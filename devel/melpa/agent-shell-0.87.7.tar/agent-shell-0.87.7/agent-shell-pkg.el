;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.87.7"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "3e4b4ddf8a534ac287916663a246500444da284b"
  :revdesc "3e4b4ddf8a53")
