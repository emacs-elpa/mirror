;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sixcolors-theme" "1.0.0.20251028.11"
  "Just another theme."
  '((emacs "27.1"))
  :url "https://github.com/mastro35/sixcolors-theme"
  :commit "be8db0ca5f7868a9f139056cb8067d24aeffe67e"
  :revdesc "be8db0ca5f78"
  :keywords '("faces" "colors" "apple" "sixcolors" "vintage" "dark")
  :authors '(("Davide Mastromatteo" . "mastro35@gmail.com"))
  :maintainers '(("Davide Mastromatteo" . "mastro35@gmail.com")))
