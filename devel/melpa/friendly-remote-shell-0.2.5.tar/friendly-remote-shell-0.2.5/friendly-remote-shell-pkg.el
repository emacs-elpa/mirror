;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "friendly-remote-shell" "0.2.5"
  "Human-friendly remote interactive shells."
  '((emacs                  "24.1")
    (cl-lib                 "0.6.1")
    (with-shell-interpreter "0.2.5")
    (friendly-tramp-path    "0.1.0")
    (friendly-shell         "0.2.0"))
  :url "https://github.com/p3r7/friendly-shell"
  :commit "5cafa3f6313ce04a47c8996ea1ac6b617d155d46"
  :revdesc "5cafa3f6313c"
  :keywords '("processes" "terminals"))
