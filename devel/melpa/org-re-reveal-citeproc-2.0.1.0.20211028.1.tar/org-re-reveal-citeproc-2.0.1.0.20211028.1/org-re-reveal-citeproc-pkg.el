;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-re-reveal-citeproc" "2.0.1.0.20211028.1"
  "Citations and bibliography for org-re-reveal."
  '((emacs         "25.1")
    (org           "9.5")
    (citeproc      "0.9")
    (org-re-reveal "3.0.0"))
  :url "https://gitlab.com/oer/org-re-reveal-citeproc"
  :commit "faa9ea387917b20bd1499ad90199ff3d417c00c2"
  :revdesc "faa9ea387917"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "bibliography"))
