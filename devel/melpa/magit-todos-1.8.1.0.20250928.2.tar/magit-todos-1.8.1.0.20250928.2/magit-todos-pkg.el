;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-todos" "1.8.1.0.20250928.2"
  "Show source file TODOs in Magit."
  '((emacs     "26.1")
    (async     "1.9.2")
    (dash      "2.13.0")
    (f         "0.17.2")
    (hl-todo   "1.9.0")
    (magit     "2.13.0")
    (pcre2el   "1.8")
    (s         "1.12.0")
    (transient "0.2.0"))
  :url "https://github.com/alphapapa/magit-todos"
  :commit "7294a95580bddf7232f2d205efae312dc24c5f61"
  :revdesc "v1.8.1-2-g7294a95580bd"
  :keywords '("magit" "vc")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
