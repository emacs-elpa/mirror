;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hlint-refactor" "0.0.1.0.20190115.4"
  "Apply HLint suggestions."
  ()
  :url "https://github.com/mpickering/hlint-refactor-mode"
  :commit "c4307f86aad6d02e32e9b30cb6edc115584c791c"
  :revdesc "c4307f86aad6"
  :keywords '("haskell" "refactor"))
