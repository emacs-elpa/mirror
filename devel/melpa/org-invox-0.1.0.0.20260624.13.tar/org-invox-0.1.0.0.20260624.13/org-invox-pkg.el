;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-invox" "0.1.0.0.20260624.13"
  "Invoice management for contractors using Org mode."
  '((emacs "27.1")
    (org   "9.0"))
  :url "https://github.com/a-manumohan/org-invox"
  :commit "0373529a0c922fcca62c7cb604099323bc869f76"
  :revdesc "0373529a0c92"
  :keywords '("outlines" "tools")
  :authors '(("Manu Mohan" . "me@manumohan.net"))
  :maintainers '(("Manu Mohan" . "me@manumohan.net")))
