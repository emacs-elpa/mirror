;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ctune" "0.2.0.20250310.19"
  "Tune out CC Mode Noise Macros."
  '((emacs "26.1"))
  :url "https://github.com/maurooaranda/ctune"
  :commit "7c26d7af3cd0d6cf4f94deb7f2bf3cf8ed8a1f11"
  :revdesc "v0.2-19-g7c26d7af3cd0"
  :keywords '("c" "convenience")
  :authors '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers '(("Mauro Aranda" . "maurooaranda@gmail.com")))
