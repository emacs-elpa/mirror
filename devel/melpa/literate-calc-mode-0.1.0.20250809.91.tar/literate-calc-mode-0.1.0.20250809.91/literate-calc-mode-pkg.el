;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "literate-calc-mode" "0.1.0.20250809.91"
  "Inline results from calc."
  '((emacs "27")
    (dash  "2.19.1")
    (s     "1.12.0"))
  :url "https://github.com/sulami/literate-calc-mode.el"
  :commit "bdfdb6e526cdcf987ecded3bd9032990e5be1236"
  :revdesc "bdfdb6e526cd"
  :keywords '("calc" "languages" "tools"))
