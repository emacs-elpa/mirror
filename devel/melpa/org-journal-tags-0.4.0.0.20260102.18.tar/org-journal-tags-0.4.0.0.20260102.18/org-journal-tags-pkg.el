;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-journal-tags" "0.4.0.0.20260102.18"
  "Tagging and querying system for org-journal."
  '((emacs         "27.1")
    (org-journal   "2.1.2")
    (magit-section "3.3.0")
    (transient     "0.3.7"))
  :url "https://github.com/SqrtMinusOne/org-journal-tags"
  :commit "945347b7a2daae463498f12300b13b583a8792d4"
  :revdesc "945347b7a2da"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
