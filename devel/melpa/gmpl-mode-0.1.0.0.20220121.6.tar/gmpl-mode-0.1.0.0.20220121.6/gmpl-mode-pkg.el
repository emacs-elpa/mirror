;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gmpl-mode" "0.1.0.0.20220121.6"
  "Major mode for editing GMPL(MathProg) files."
  '((emacs "24"))
  :url "https://github.com/cute-jumper/gmpl-mode"
  :commit "97b103eea8b18f7e27b0f0be6cb4809a4156c032"
  :revdesc "97b103eea8b1"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
