;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nameframe-projectile" "0.0.0.20221023.35"
  "Nameframe integration with Projectile."
  '((nameframe  "0.5.0-beta")
    (projectile "0.13.0"))
  :url "https://github.com/john2x/nameframe"
  :commit "06d3400750c6b33ae215b9ac2922ee4dafd6b506"
  :revdesc "06d3400750c6"
  :authors '(("John Del Rosario" . "john2x@gmail.com"))
  :maintainers '(("John Del Rosario" . "john2x@gmail.com")))
