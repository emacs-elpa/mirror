;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "green-phosphor-theme" "1.0.0.0.20150515.1"
  "A light color theme with muted, autumnal colors."
  ()
  :url "https://github.com/aalpern/emacs-color-theme-green-phosphor"
  :commit "5549781559ff5daa85c1d6c635c94524c1c5f644"
  :revdesc "5549781559ff"
  :keywords '("color" "theme")
  :authors '(("Adam Alpern" . "adam.alpern@gmail.com"))
  :maintainers '(("Adam Alpern" . "adam.alpern@gmail.com")))
