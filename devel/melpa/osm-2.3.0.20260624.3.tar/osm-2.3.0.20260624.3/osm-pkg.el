;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "2.3.0.20260624.3"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/osm"
  :commit "41765d63fd6810df8a43e3290e98b11dab93b40f"
  :revdesc "2.3-3-g41765d63fd68"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
