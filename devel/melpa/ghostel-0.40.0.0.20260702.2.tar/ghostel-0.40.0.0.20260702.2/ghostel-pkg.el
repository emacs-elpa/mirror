;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.40.0.0.20260702.2"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "61f11d711157bb5c047d297b0fec7633342abe44"
  :revdesc "61f11d711157"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
