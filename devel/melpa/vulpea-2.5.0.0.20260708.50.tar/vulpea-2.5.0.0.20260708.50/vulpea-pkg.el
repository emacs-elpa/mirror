;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.5.0.0.20260708.50"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "57b931068a0ec6b091f1c6a6fb693b897bdb283d"
  :revdesc "57b931068a0e"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
