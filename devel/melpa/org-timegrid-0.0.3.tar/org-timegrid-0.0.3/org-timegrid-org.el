;;; org-timegrid-org.el --- Org backend for org-timegrid -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Umar Ahmad

;; Author: Umar Ahmad <Gleek@users.noreply.github.com>
;; Assisted-by: Codex:gpt-5.6-sol
;; Maintainer: Umar Ahmad <Gleek@users.noreply.github.com>
;; Keywords: calendar, outlines, convenience
;; URL: https://github.com/Gleek/org-timegrid

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Read timed events from live Org buffers and write edits back to them, as an
;; implementation of the org-timegrid backend protocol.  Timestamps that carry
;; a clock time are included, whether plain or after SCHEDULED or DEADLINE;
;; repeaters are expanded into concrete occurrences here, so the renderer never
;; sees repeater syntax.  Edits leave their buffers modified but unsaved, as
;; Org Agenda commands do.

;;; Code:

(require 'org)
(require 'org-element)
(require 'org-agenda)
(require 'org-datetree)
(require 'org-timegrid-model)
;; The backend value names renderer functions, so the renderer has to be
;; loaded, not autoloaded.  There is no cycle: `org-timegrid.el' never
;; requires Org.
(require 'org-timegrid)
(require 'org-timegrid-calendar)

(defgroup org-timegrid-org nil
  "Org data support for `org-timegrid'."
  :group 'org-timegrid
  :prefix "org-timegrid-org-")

(defcustom org-timegrid-org-files 'agenda
  "Files queried for timed Org ranges.
The symbol `agenda' means use the variable `org-agenda-files'.  A
function value is called without arguments.  A list is used literally.
The capture file is always queried in addition to these files."
  :type '(choice (const :tag "Org agenda files" agenda)
                 (function :tag "File-producing function")
                 (repeat :tag "Explicit files" file)))

(defcustom org-timegrid-org-capture-file
  (expand-file-name "calendar.org" user-emacs-directory)
  "File reserved for calendar-created Org entries.
The date query always includes this file, even when it is not in the variable
`org-agenda-files'.  New entries are inserted into its live buffer and
left unsaved."
  :type 'file)

(defcustom org-timegrid-org-capture-template
  '(:target file :template "* %{title}\n%{time-range}\n%?")
  "Template used for new calendar entries in the capture file.

TARGET controls the insertion position inside the file.  It may be
`file', `datetree', `(headline NAME)', or `(olp NAME ...)'.  Headings in
the template are relative to that target.

TEMPLATE recognizes `%{title}', `%{time-range}', `%{start}', `%{end}',
`%{duration}', `%<FORMAT>' (formatted from the selected start), and `%?'
for the final point."
  :type '(plist :key-type symbol :value-type sexp))

(defcustom org-timegrid-org-show-repeaters t
  "Whether repeating Org timestamps appear on the calendar.
When nil, the calendar omits both the anchor and generated occurrences of
timestamps with an Org repeater."
  :type 'boolean)

(defcustom org-timegrid-org-repeater-history t
  "Interpret a heading's timestamps as successive schedule versions.
Override with TIMEGRID_REPEATER_HISTORY (t or nil), as an inherited heading
property or a file #+PROPERTY.  Plain timestamps end previous repeaters.
This convention applies only to Timegrid, not Org Agenda."
  :type 'boolean)

(defun org-timegrid-org--repeater-history-p ()
  "Return the repeater history setting at the current heading."
  (let ((value (org-entry-get nil "TIMEGRID_REPEATER_HISTORY" 'inherit t)))
    (if value (equal (downcase value) "t")
      org-timegrid-org-repeater-history)))

(defun org-timegrid-org--history-events (events)
  "Annotate EVENTS with schedule cutoffs and edit preparation."
  (when (cl-some (lambda (event)
                   (plist-get (org-timegrid-event-metadata event) :repeater-type))
                 events)
    (let ((ordered (sort (copy-sequence events)
                         (lambda (a b) (< (org-timegrid-event-start a)
                                          (org-timegrid-event-start b))))))
      (cl-loop for tail on ordered
               for event = (car tail)
               for next = (cadr tail)
               for metadata = (org-timegrid-event-metadata event)
               do (setf (plist-get metadata :history) t
                        (plist-get metadata :prepare-edit)
                        #'org-timegrid-org--prepare-history-edit
                        (plist-get metadata :history-until)
                        (and next
                             (if (eq (plist-get metadata :repeater-unit) 'hour)
                                 (org-timegrid-event-start next)
                               (* 1440 (floor (org-timegrid-event-start next) 1440))))
                        (org-timegrid-event-metadata event) metadata))))
  events)

(defun org-timegrid-org--prepare-history-edit (event &optional deleting)
  "Return EVENT's scope, prompting once per editing session."
  (let ((marker (plist-get (org-timegrid-event-source event) :marker)))
    (unless (and (not deleting)
                 (equal marker (plist-get org-timegrid--edit-context :marker))
                 (equal (org-timegrid-event-start event)
                        (plist-get org-timegrid--edit-context :start)))
      (let* ((choices '(("just this" . this) ("this and future" . future)
                        ("all" . all)))
             (scope (if (plist-get (org-timegrid-event-metadata event) :repeater-type)
                        (cdr (assoc (completing-read
                                     (if deleting "Delete repeating block: "
                                       "Change repeating block: ")
                                     choices nil t nil nil "this and future")
                                    choices))
                      'direct)))
        (setq org-timegrid--edit-context
              (list :marker (copy-marker marker)
                    :start (org-timegrid-event-start event) :scope scope))))
    (plist-get org-timegrid--edit-context :scope)))

(defcustom org-timegrid-org-show-done t
  "Whether timestamps belonging to done Org headings appear."
  :type 'boolean)

(defcustom org-timegrid-org-exclude-tags nil
  "Org tags whose headings should not appear on the calendar.
A heading is excluded when it has any tag in this list."
  :type '(repeat string))

(defcustom org-timegrid-org-exclude-todo-states nil
  "TODO keywords whose headings should not appear on the calendar."
  :type '(repeat string))

(defcustom org-timegrid-org-exclude-properties nil
  "Org property values whose headings should not appear on the calendar.
Each entry is (PROPERTY . VALUE).  PROPERTY and VALUE are strings.  A nil
VALUE matches any non-nil value of PROPERTY."
  :type '(alist :key-type (string :tag "Property")
                :value-type (choice (const :tag "Any value" nil)
                                    (string :tag "Value"))))

(defcustom org-timegrid-org-filter-function
  #'org-timegrid-org-default-filter
  "Function deciding whether an eligible Org timestamp appears.
The function receives the headline and timestamp `org-element' objects and
returns non-nil to keep the timestamp.  Timestamp eligibility itself (an
active date, with or without a time) is always enforced before this function
runs.  The default function observes all Org filtering options in this group."
  :type 'function)

(defun org-timegrid-org-default-filter (headline timestamp)
  "Return non-nil when HEADLINE's TIMESTAMP passes the standard filters."
  (let ((todo (org-element-property :todo-keyword headline)))
    (and (or org-timegrid-org-show-done
             (not (member todo org-done-keywords)))
         (or org-timegrid-org-show-repeaters
             (not (org-element-property :repeater-type timestamp)))
         (not (seq-intersection org-timegrid-org-exclude-tags
                                (org-element-property :tags headline)))
         (not (member todo org-timegrid-org-exclude-todo-states))
         (not
          (seq-some
           (lambda (property)
             (let ((actual
                    (save-excursion
                      (goto-char (org-element-property :begin headline))
                      (org-entry-get nil (car property)))))
               (and actual
                    (or (null (cdr property))
                        (equal actual (cdr property))))))
           org-timegrid-org-exclude-properties)))))

(defcustom org-timegrid-org-auto-save nil
  "Whether calendar edits immediately save their affected Org files.
When non-nil, creating, moving, resizing, renaming, copying, deleting,
undoing, and redoing a calendar entry save the source buffer after the
edit succeeds."
  :type 'boolean)

(defcustom org-timegrid-org-tag-color-alist nil
  "Map Org tag strings to calendar colours.
A value is a name in `org-timegrid-colors' or any colour string.  Tags
are checked in the order they appear on the heading, so the first mapped
tag wins and a heading may carry others freely.  An unmapped heading uses
`org-timegrid-default-color'; colour means something on a calendar, so
inventing one per tag would be noise."
  :type '(alist :key-type (string :tag "Org tag")
                :value-type (choice (symbol :tag "Colour name")
                                    (color :tag "Colour"))))

(defcustom org-timegrid-org-color-function
  #'org-timegrid-org-tag-color
  "Function returning the colour for an Org heading, or nil for the default.
It receives the `org-element' headline, so it can colour by TODO state,
priority, property, or file as easily as by tag."
  :type 'function)

(defun org-timegrid-org-tag-color (headline)
  "Return the colour mapped to HEADLINE's first mapped tag, or nil."
  (seq-some (lambda (tag)
              (cdr (assoc tag org-timegrid-org-tag-color-alist)))
            (org-element-property :tags headline)))

(defun org-timegrid-org--capture-target ()
  "Return the file calendar entries are written to, or nil.
Named apart from `org-timegrid-org-capture-file': a function and a user
option sharing one name is legal and confusing, and it also makes a
minor mode indistinguishable from an option to any code that inspects
symbols."
  org-timegrid-org-capture-file)

(defun org-timegrid-org--files ()
  "Return the existing, deduplicated Org files to query."
  (let ((files
         (append
          (cond ((eq org-timegrid-org-files 'agenda)
                 (org-agenda-files))
                ((functionp org-timegrid-org-files)
                 (funcall org-timegrid-org-files))
                ((listp org-timegrid-org-files)
                 org-timegrid-org-files)
                (t nil))
          (and (org-timegrid-org--capture-target)
               (list (org-timegrid-org--capture-target))))))
    (delete-dups
     (cl-loop for file in files
              for expanded = (expand-file-name file)
              when (or (file-readable-p expanded)
                       (find-buffer-visiting expanded))
              collect expanded))))

(defun org-timegrid-org--format-date (absolute-day)
  "Format ABSOLUTE-DAY for an Org timestamp."
  (let* ((date (calendar-gregorian-from-absolute absolute-day))
         (month (nth 0 date))
         (day (nth 1 date))
         (year (nth 2 date)))
    (format "%04d-%02d-%02d %s" year month day
            (calendar-day-name date t))))

(defun org-timegrid-org--format-clock (minute-of-day)
  "Format MINUTE-OF-DAY as a 24-hour Org clock value."
  (format "%02d:%02d" (/ minute-of-day 60) (% minute-of-day 60)))

(defun org-timegrid-org--format-range (start end)
  "Format absolute minute START and END as an active Org range."
  (let* ((start-day (floor start 1440))
         (end-day (floor end 1440))
         (start-clock (% start 1440))
         (end-clock (% end 1440))
         (start-date (org-timegrid-org--format-date start-day))
         (end-date (org-timegrid-org--format-date end-day)))
    (if (= start-day end-day)
        (format "<%s %s-%s>" start-date
                (org-timegrid-org--format-clock start-clock)
                (org-timegrid-org--format-clock end-clock))
      (format "<%s %s>--<%s %s>" start-date
              (org-timegrid-org--format-clock start-clock)
              end-date
              (org-timegrid-org--format-clock end-clock)))))

(defun org-timegrid-org--format-all-day-range (start end)
  "Format half-open absolute minute START and END as an active Org date range."
  (let* ((start-day (floor start 1440))
         (end-day (floor (1- end) 1440))
         (start-date (org-timegrid-org--format-date start-day)))
    (if (= start-day end-day)
        (format "<%s>" start-date)
      (format "<%s>--<%s>" start-date
              (org-timegrid-org--format-date end-day)))))

(defun org-timegrid-org--all-day-range-p (start end)
  "Return non-nil when START and END describe whole exclusive days."
  (and (= (% start 1440) 0)
       (= (% end 1440) 0)
       (>= (- end start) 1440)))

(defun org-timegrid-org--duplicate-entry-string
    (source title start end &optional all-day)
  "Return a top-level copy of SOURCE using TITLE and range START through END.
When ALL-DAY is non-nil, write the range without times."
  (let* ((source-data (org-timegrid-event-source source))
         (marker (plist-get source-data :marker))
         subtree)
    (unless (and (markerp marker) (marker-buffer marker))
      (user-error "The source entry is no longer live"))
    (with-current-buffer (marker-buffer marker)
      (org-with-wide-buffer
       (goto-char marker)
       (org-back-to-heading t)
       (let ((begin (point)))
         (org-end-of-subtree t t)
         (setq subtree (buffer-substring-no-properties begin (point))))))
    (with-temp-buffer
      (org-mode)
      (insert subtree)
      (goto-char (point-min))
      (org-edit-headline title)
      (while (> (or (org-current-level) 1) 1)
        (org-promote-subtree))
      ;; A duplicate gets a fresh range and no identity properties.
      (goto-char (point-min))
      (while (re-search-forward
              "^[ \t]*:\\(?:ID\\|CUSTOM_ID\\):.*\\(?:\n\\|\\'\\)" nil t)
        (replace-match ""))
      (let (ranges)
        (org-element-map (org-element-parse-buffer) 'timestamp
          (lambda (timestamp)
            (push (cons (org-element-property :begin timestamp)
                        (org-element-property :end timestamp))
                  ranges)))
        (dolist (range (sort ranges (lambda (left right)
                                      (> (car left) (car right)))))
          (delete-region (car range) (cdr range))))
      (goto-char (point-min))
      (while (re-search-forward
              "^[ \t]*\\(?:SCHEDULED:\\|DEADLINE:\\|CLOSED:\\|[ \t]\\)+$"
              nil t)
        (replace-match ""))
      ;; Removing the timestamps and planning values leaves their lines
      ;; empty, so drop the blank run between the heading and the body.
      (goto-char (point-min))
      (forward-line 1)
      (while (and (not (eobp)) (looking-at-p "[ \t]*$"))
        (delete-region (point) (min (point-max) (line-beginning-position 2))))
      (goto-char (point-max))
      (unless (bolp) (insert "\n"))
      (insert (if all-day
                  (org-timegrid-org--format-all-day-range start end)
                (org-timegrid-org--format-range start end))
              "\n")
      (buffer-string))))

(defcustom org-timegrid-org-after-create-hook nil
  "Hook run on a heading the calendar has just created.
Point is on the new heading in its own buffer, inside the change group
that inserted it, so a property set here is part of the entry's single
undo step.  This is where a configuration matches whatever its capture
templates do — stamping a CAPTURED property, filing an ID, adding a
default tag."
  :type 'hook)

(defun org-timegrid-org--format-instant (absolute-minute)
  "Format ABSOLUTE-MINUTE as an active Org timestamp."
  (format "<%s %s>"
          (org-timegrid-org--format-date (floor absolute-minute 1440))
          (org-timegrid-org--format-clock (% absolute-minute 1440))))

(defun org-timegrid-org--absolute-time (absolute-minute)
  "Return an Emacs time value for local ABSOLUTE-MINUTE."
  (let* ((date (calendar-gregorian-from-absolute
                (floor absolute-minute 1440)))
         (clock (% absolute-minute 1440)))
    (encode-time 0 (% clock 60) (/ clock 60)
                 (nth 1 date) (nth 0 date) (nth 2 date))))

(defun org-timegrid-org--expand-capture-template
    (title start end &optional all-day)
  "Expand the calendar template for TITLE and range START through END.
When ALL-DAY is non-nil, timestamp substitutions contain dates without
clock times and END is treated as an exclusive midnight bound."
  (let ((text (plist-get org-timegrid-org-capture-template :template))
        (range (if all-day
                   (org-timegrid-org--format-all-day-range start end)
                 (org-timegrid-org--format-range start end)))
        (start-text (if all-day
                        (org-timegrid-org--format-all-day-range
                         start (+ start 1440))
                      (org-timegrid-org--format-instant start)))
        (end-text (if all-day
                      (org-timegrid-org--format-all-day-range
                       (- end 1440) end)
                    (org-timegrid-org--format-instant end))))
    (unless (stringp text)
      (user-error "The timegrid capture template needs a :template string"))
    (dolist (replacement
             `(("%{title}" . ,title)
               ("%{time-range}" . ,range)
               ("%{start}" . ,start-text)
               ("%{end}" . ,end-text)
               ("%{duration}" . ,(number-to-string (- end start)))))
      (setq text (string-replace (car replacement) (cdr replacement) text)))
    (replace-regexp-in-string
     "%<\\([^>\n]+\\)>"
     (lambda (match)
       (format-time-string (substring match 2 -1)
                           (org-timegrid-org--absolute-time start)))
     text t t)))

(defun org-timegrid-org--capture-parent (target start)
  "Move to TARGET for an entry starting at START and return its level."
  (pcase target
    ('file
     (goto-char (point-max))
     0)
    ('datetree
     (org-datetree-find-date-create
      (calendar-gregorian-from-absolute (floor start 1440)))
     (prog1 (org-current-level)
       (org-end-of-subtree t t)))
    (`(headline ,name)
     (goto-char (org-find-olp (list name) t))
     (prog1 (org-current-level)
       (org-end-of-subtree t t)))
    (`(olp . ,path)
     (goto-char (org-find-olp path t))
     (prog1 (org-current-level)
       (org-end-of-subtree t t)))
    (_ (user-error "Unknown timegrid capture target: %S" target))))

(defun org-timegrid-org--relative-template (template parent-level)
  "Make TEMPLATE headings relative to PARENT-LEVEL."
  (if (zerop parent-level)
      template
    (replace-regexp-in-string
     "^\\*+"
     (lambda (stars) (concat (make-string parent-level ?*) stars))
     template)))

(defun org-timegrid-org--insert-capture-template
    (title start end &optional all-day)
  "Insert a new entry for TITLE and range START through END.
When ALL-DAY is non-nil, write the range without times.
Return markers for its beginning and the position selected by `%?'."
  (let* ((target (or (plist-get org-timegrid-org-capture-template :target)
                     'file))
         (cursor-token "<<org-timegrid-final-point>>")
         (template (string-replace
                    "%?" cursor-token
                    (org-timegrid-org--expand-capture-template
                     title start end all-day)))
         (parent-level (org-timegrid-org--capture-parent target start)))
    (unless (or (= (point-min) (point-max)) (bolp))
      (insert "\n"))
    (let ((beginning (point)))
      (insert (org-timegrid-org--relative-template template parent-level))
      (unless (bolp) (insert "\n"))
      (goto-char beginning)
      (if (search-forward cursor-token nil t)
          (replace-match "" t t)
        (goto-char beginning))
      (list (copy-marker beginning) (copy-marker (point))))))

(defun org-timegrid-org--add-range (record start end &optional all-day)
  "Add the range from START to END to the heading identified by RECORD.
RECORD is either a marker selected interactively or an event source
plist retained while cutting a calendar block."
  (let ((marker (if (markerp record)
                    record
                  (plist-get record :marker))))
    (unless (and (markerp marker) (marker-buffer marker))
      (user-error "The selected Org heading is no longer live"))
    (with-current-buffer (marker-buffer marker)
      (org-with-wide-buffer
       (goto-char marker)
       (org-back-to-heading t)
       (undo-boundary)
       (atomic-change-group
         (org-end-of-meta-data t)
         (unless (bolp) (insert "\n"))
         (insert (if all-day
                     (org-timegrid-org--format-all-day-range start end)
                   (org-timegrid-org--format-range start end))
                 "\n"))
       (undo-boundary)
       (org-timegrid-org--note-edit)))))

(defun org-timegrid-org--create-event
    (title start end &optional source target time-kind)
  "Create TITLE from absolute minute START to END in the capture buffer.
When SOURCE is non-nil, duplicate that event.  When TARGET is non-nil,
add the range to that existing heading instead.  TIME-KIND explicitly
distinguishes date-only values from midnight-aligned timed values."
  (let ((all-day (if time-kind
                     (eq time-kind 'all-day)
                   (org-timegrid-org--all-day-range-p start end))))
   (when (and all-day (not (org-timegrid-org--all-day-range-p start end)))
     (user-error "All-day ranges must span whole days"))
   (if target
      (progn
        (org-timegrid-org--add-range target start end all-day)
        (message "Added time block to %s" title))
    (let ((file (org-timegrid-org--capture-target))
          (entry (and source
                      (org-timegrid-org--duplicate-entry-string
                       source title start end all-day))))
      (unless file
        (user-error "Set `org-timegrid-org-capture-file' first"))
      (let ((buffer (find-file-noselect (expand-file-name file))))
        (with-current-buffer buffer
          (unless (derived-mode-p 'org-mode)
            (org-mode))
          (org-with-wide-buffer
           (goto-char (point-max))
           (undo-boundary)
           (atomic-change-group
             (let* ((positions
                     (if entry
                         (progn
                           (unless (or (= (point-min) (point-max)) (bolp))
                             (insert "\n"))
                           (unless (or (= (point-min) (point-max))
                                       (save-excursion
                                         (forward-line -1)
                                         (looking-at-p "[[:space:]]*$")))
                             (insert "\n"))
                           (let ((beginning (copy-marker (point))))
                             (insert entry)
                             (list beginning beginning)))
                       (org-timegrid-org--insert-capture-template
                        title start end all-day)))
                    (beginning (car positions))
                    (final-point (cadr positions)))
               ;; Run the hook inside the change group, with point on the new
               ;; heading, so anything it adds belongs to the same undo step as
               ;; the entry rather than needing a second undo of its own.
               (goto-char beginning)
               (run-hooks 'org-timegrid-org-after-create-hook)
               (goto-char final-point)))
           (undo-boundary))
          (org-timegrid-org--note-edit)
          (message "Added %s" title)))))))

(defun org-timegrid-org--headline-has-active-timestamp-p (headline)
  "Return non-nil when HEADLINE's own section has an active timestamp."
  (when-let* ((section (seq-find
                       (lambda (element)
                         (eq (org-element-type element) 'section))
                       (org-element-contents headline))))
    (catch 'active
      (org-element-map section 'timestamp
        (lambda (timestamp)
          (when (memq (org-element-property :type timestamp)
                      '(active active-range))
            (throw 'active t))))
      nil)))

(defun org-timegrid-org--heading-candidates ()
  "Return headings eligible for adding another calendar range.
This includes unfinished TODO headings and plain headings that already
have an active timestamp in their own section."
  (let (candidates)
    (dolist (file (org-timegrid-org--files))
      (with-current-buffer (find-file-noselect file)
        (org-with-wide-buffer
         (org-element-map (org-element-parse-buffer) 'headline
           (lambda (headline)
             (when (and
                    (not (eq (org-element-property :todo-type headline)
                             'done))
                    (or (org-element-property :todo-keyword headline)
                        (org-timegrid-org--headline-has-active-timestamp-p
                         headline)))
               (let* ((title (org-element-property :raw-value headline))
                      (todo (org-element-property :todo-keyword headline))
                      (tags (org-element-property :tags headline))
                      (marker (copy-marker
                               (org-element-property :begin headline)))
                      (path (save-excursion
                              (goto-char marker)
                              (org-get-outline-path)))
                      (context (string-join
                                (append path
                                        (list (file-name-nondirectory file)))
                                " / "))
                      (tag-text (and tags
                                     (concat ":" (string-join tags ":") ":")))
                      (display
                        (string-join
                         (delq nil
                              (list (and todo
                                         (propertize
                                          todo 'face
                                          (org-get-todo-face todo)))
                                    title
                                    (and tag-text
                                         (propertize tag-text 'face 'org-tag))
                                    (propertize (format "[%s]" context)
                                                'face 'shadow)))
                        "  ")))
                 (push (cons display (cons title marker)) candidates))))))))
    (nreverse candidates)))

(defun org-timegrid-org-read-entry ()
  "Read an eligible Org heading, or a title for a new capture entry."
  (let* ((candidates (org-timegrid-org--heading-candidates))
         (choice (completing-read "Task: " candidates nil nil))
         (match (assoc choice candidates)))
    (if match
        (cdr match)
      (cons choice nil))))

(defvar org-timegrid-org--undo-transactions nil)
(defvar org-timegrid-org--redo-transactions nil)
(defvar org-timegrid-org--transaction-edits nil)
(defvar org-timegrid-org--undo-direction nil
  "Direction of the current undo run: nil for undo and `redo' for redo.")

(defun org-timegrid-org--note-edit ()
  "Record one calendar edit in the current source buffer.
Save immediately outside a transaction; transactions save once at commit."
  (if org-timegrid-org--transaction-edits
      (puthash (current-buffer)
               (1+ (gethash (current-buffer)
                            org-timegrid-org--transaction-edits 0))
               org-timegrid-org--transaction-edits)
    (push (list (cons (current-buffer) 1))
          org-timegrid-org--undo-transactions)
    (setq org-timegrid-org--redo-transactions nil
          org-timegrid-org--undo-direction nil))
  (when (and (null org-timegrid-org--transaction-edits)
             org-timegrid-org-auto-save
             buffer-file-name
             (buffer-modified-p))
    (save-buffer)))

(defun org-timegrid-org--apply-history (transaction redo)
  "Apply TRANSACTION as undo, or as REDO when non-nil."
  (dolist (edit transaction)
    (let ((buffer (car edit)) (count (cdr edit)))
      (unless (buffer-live-p buffer)
        (user-error "A source buffer needed for undo is no longer live"))
      (with-current-buffer buffer
        (when buffer-read-only (user-error "%s is read-only" (buffer-name)))
        ;; A continued run of `undo' calls becomes one redo unit in Emacs.
        (dotimes (index (if redo 1 count))
          (let ((last-command (and (> index 0) (if redo 'undo-redo 'undo)))
                (this-command this-command))
            (if redo (undo-redo) (undo-only))))
        ;; Source buffers do not run their own command loop while the calendar
        ;; drives them.  Establish the boundary that Emacs would normally add
        ;; after an interactive undo command.
        (undo-boundary)
        (when (and org-timegrid-org-auto-save buffer-file-name
                   (buffer-modified-p))
          (save-buffer))))))

(defun org-timegrid-org--transaction (function)
  "Run FUNCTION as one atomic backend transaction."
  (let ((org-timegrid-org--transaction-edits (make-hash-table :test #'eq)))
    (condition-case error-data
        (prog1 (funcall function)
          (let (transaction)
            (maphash (lambda (buffer count)
                       (push (cons buffer count) transaction))
                     org-timegrid-org--transaction-edits)
            (when transaction
              (push transaction org-timegrid-org--undo-transactions)
              (setq org-timegrid-org--redo-transactions nil
                    org-timegrid-org--undo-direction nil)
              (dolist (edit transaction)
                (with-current-buffer (car edit)
                  (when (and org-timegrid-org-auto-save buffer-file-name
                             (buffer-modified-p))
                    (save-buffer)))))))
      ((error quit)
       (let (transaction)
         (maphash (lambda (buffer count) (push (cons buffer count) transaction))
                  org-timegrid-org--transaction-edits)
         (when transaction (org-timegrid-org--apply-history transaction nil)))
       (signal (car error-data) (cdr error-data))))))

(defun org-timegrid-org--undo (continue redo)
  "Undo, or REDO, the calendar's most recent Org edit.
CONTINUE means this call extends an unbroken run of them, so the source
buffer keeps walking back through its own undo history instead of
undoing the previous undo.  Each calendar edit is bracketed by
`undo-boundary', so one press is one edit."
  (let* ((direction
          (cond (redo 'redo)
                (continue org-timegrid-org--undo-direction)
                (org-timegrid-org--redo-transactions 'redo)))
         (from (if direction org-timegrid-org--redo-transactions
                 org-timegrid-org--undo-transactions))
         (transaction (car from)))
    (unless transaction
      (user-error "The calendar has no edit to %s"
                  (if direction "redo" "undo")))
    (org-timegrid-org--apply-history transaction direction)
    (setq org-timegrid-org--undo-direction direction)
    (if direction
        (progn
          (setq org-timegrid-org--redo-transactions (cdr from))
          (push transaction org-timegrid-org--undo-transactions))
      (setq org-timegrid-org--undo-transactions (cdr from))
      (push transaction org-timegrid-org--redo-transactions))))

(defun org-timegrid-org--remove-entry (event)
  "Delete the whole Org heading that owned EVENT.
Its timestamp has already gone by the time this runs, so the marker is
the only identity left to check."
  (let ((marker (plist-get (org-timegrid-event-source event) :marker)))
    (unless (and (markerp marker) (marker-buffer marker))
      (user-error "The Org source marker is no longer live"))
    (with-current-buffer (marker-buffer marker)
      (org-with-wide-buffer
       (when buffer-read-only
         (user-error "The source Org buffer is read-only"))
       (goto-char marker)
       (org-back-to-heading t)
       (undo-boundary)
       (delete-region (point)
                      (save-excursion (org-end-of-subtree t t) (point)))
       (undo-boundary))
      (org-timegrid-org--note-edit))
    (message "Deleted %s" (org-timegrid-event-title event))))

(defun org-timegrid-org--timestamp-at-marker (marker)
  "Return the Org timestamp element at MARKER, or signal an error."
  (unless (and (markerp marker) (marker-buffer marker))
    (user-error "The source timestamp marker is no longer live"))
  (with-current-buffer (marker-buffer marker)
    (save-restriction
      (widen)
      (goto-char marker)
      (let ((element (or (org-element-timestamp-parser)
                         (org-element-context))))
        (unless (eq (org-element-type element) 'timestamp)
          (user-error "The source timestamp changed; refresh the calendar"))
        element))))

(defun org-timegrid-org--put-endpoint
    (timestamp endpoint absolute-minute)
  "Set TIMESTAMP ENDPOINT from ABSOLUTE-MINUTE.
ENDPOINT is the symbol `start' or `end'."
  (let* ((absolute-day (floor absolute-minute 1440))
         (minute-of-day (% absolute-minute 1440))
         (date (calendar-gregorian-from-absolute absolute-day))
         (suffix (symbol-name endpoint)))
    (org-element-put-property
     timestamp (intern (format ":year-%s" suffix)) (nth 2 date))
    (org-element-put-property
     timestamp (intern (format ":month-%s" suffix)) (nth 0 date))
    (org-element-put-property
     timestamp (intern (format ":day-%s" suffix)) (nth 1 date))
    (org-element-put-property
     timestamp (intern (format ":hour-%s" suffix)) (/ minute-of-day 60))
    (org-element-put-property
     timestamp (intern (format ":minute-%s" suffix)) (% minute-of-day 60))))

(defun org-timegrid-org--put-date-endpoint (timestamp endpoint absolute-day)
  "Set date-only TIMESTAMP ENDPOINT from ABSOLUTE-DAY."
  (let* ((date (calendar-gregorian-from-absolute absolute-day))
         (suffix (symbol-name endpoint)))
    (org-element-put-property
     timestamp (intern (format ":year-%s" suffix)) (nth 2 date))
    (org-element-put-property
     timestamp (intern (format ":month-%s" suffix)) (nth 0 date))
    (org-element-put-property
     timestamp (intern (format ":day-%s" suffix)) (nth 1 date))
    (org-element-put-property
     timestamp (intern (format ":hour-%s" suffix)) nil)
    (org-element-put-property
     timestamp (intern (format ":minute-%s" suffix)) nil)))

(defun org-timegrid-org--rewrite-all-day-timestamp (timestamp start end)
  "Return date-only TIMESTAMP rewritten to half-open START through END.
END is exclusive internally; Org's written date-range endpoint is inclusive."
  (let* ((copy (copy-tree timestamp))
         (start-day (floor start 1440))
         (end-day (floor (1- end) 1440))
         (range (> end-day start-day)))
    (org-element-put-property copy :type (if range 'active-range 'active))
    (org-element-put-property copy :range-type (and range 'daterange))
    (org-timegrid-org--put-date-endpoint copy 'start start-day)
    (org-timegrid-org--put-date-endpoint copy 'end end-day)
    (org-element-interpret-data copy)))

(defun org-timegrid-org--rewrite-timestamp
    (timestamp start end)
  "Return TIMESTAMP rewritten to absolute START and END minutes."
  (let ((copy (copy-tree timestamp)))
    (org-element-put-property copy :type 'active-range)
    (org-element-put-property
     copy :range-type
     (if (= (floor start 1440) (floor end 1440))
         'timerange
       'daterange))
    (org-timegrid-org--put-endpoint copy 'start start)
    (org-timegrid-org--put-endpoint copy 'end end)
    (org-element-interpret-data copy)))

(defun org-timegrid-org--validate-event-source (event timestamp)
  "Ensure TIMESTAMP still matches the source represented by EVENT."
  (let ((expected (plist-get (org-timegrid-event-metadata event)
                             :raw-value))
        (actual (org-element-property :raw-value timestamp)))
    (unless (equal expected actual)
      (user-error "The source timestamp changed; refresh the calendar"))))

(defun org-timegrid-org--rename-heading (marker title)
  "Rename the Org heading owning MARKER to TITLE."
  (with-current-buffer (marker-buffer marker)
    (org-with-wide-buffer
     (goto-char marker)
     (org-back-to-heading t)
     (org-edit-headline title))))

(defun org-timegrid-org--update-event-range
    (event start end &optional title time-kind)
  "Update EVENT to START through END, optional TITLE, and TIME-KIND."
  (if (and (plist-get (org-timegrid-event-metadata event) :history)
           (not title))
      (org-timegrid-org--update-history-range event start end time-kind)
    (org-timegrid-org--update-anchor-range event start end title time-kind)))

(defun org-timegrid-org--update-anchor-range
    (event start end &optional title time-kind)
  "Update EVENT's original anchor to START and END."
  (let* ((source (org-timegrid-event-source event))
         (marker (plist-get source :marker))
         (timestamp (org-timegrid-org--timestamp-at-marker marker)))
    (org-timegrid-org--validate-event-source event timestamp)
    (with-current-buffer (marker-buffer marker)
      (org-with-wide-buffer
       (when buffer-read-only
         (user-error "The source Org buffer is read-only"))
       (undo-boundary)
       (atomic-change-group
         (let* ((all-day (org-timegrid-event-all-day event))
                (base-start
                 (if all-day
                     (org-timegrid-org--timestamp-all-day-minutes timestamp nil)
                   (org-timegrid-org--timestamp-minutes timestamp nil)))
                (occurrence-start (org-timegrid-event-start event))
                (new-base-start (+ base-start (- start occurrence-start)))
                (new-base-end (+ new-base-start (- end start)))
                (new-all-day
                 (if time-kind
                     (eq time-kind 'all-day)
                   (and all-day
                        (= (% new-base-start 1440) 0)
                        (= (% new-base-end 1440) 0)
                        (>= (- new-base-end new-base-start) 1440))))
                (replacement
                 (if (and new-all-day
                          (not (org-timegrid-org--all-day-range-p
                                new-base-start new-base-end)))
                     (user-error "All-day ranges must span whole days")
                   (if new-all-day
                     (org-timegrid-org--rewrite-all-day-timestamp
                      timestamp new-base-start new-base-end)
                   (org-timegrid-org--rewrite-timestamp
                    timestamp new-base-start new-base-end)))))
           (goto-char (org-element-property :begin timestamp))
           (delete-region (org-element-property :begin timestamp)
                          (org-element-property :end timestamp))
           (insert replacement))
         (when title
           (org-timegrid-org--rename-heading marker title)))
       (undo-boundary))
      (org-timegrid-org--note-edit)
      ;; Keep validation metadata coherent for another optimistic update.
      (let* ((updated (org-timegrid-org--timestamp-at-marker marker))
             (metadata (copy-sequence (org-timegrid-event-metadata event))))
        (setf (org-timegrid-event-start event) start
              (org-timegrid-event-end event) end
              (org-timegrid-event-all-day event)
              (if time-kind
                  (eq time-kind 'all-day)
                (org-timegrid-org--timestamp-all-day-p updated))
              (plist-get metadata :raw-value)
              (org-element-property :raw-value updated)
              (org-timegrid-event-metadata event) metadata)))
    (message "%s %s" (if title "Renamed" "Retimed")
             (org-timegrid-event-title event))))

(defun org-timegrid-org--history-replacement (timestamp start end all-day
                                                        &optional single cancelled)
  "Rewrite TIMESTAMP to START and END, optionally as a SINGLE occurrence."
  (let ((copy (copy-tree timestamp)))
    (when single
      (dolist (key '(:repeater-type :repeater-value :repeater-unit))
        (org-element-put-property copy key nil)))
    (let ((text (if all-day
                    (org-timegrid-org--rewrite-all-day-timestamp copy start end)
                  (org-timegrid-org--rewrite-timestamp copy start end))))
      (if cancelled
          (concat "CANCELLED: " (subst-char-in-string
                                ?> ?\] (subst-char-in-string ?< ?\[ text)))
        text))))

(defun org-timegrid-org--validate-history-range (event start end all-day scope)
  "Check that EVENT can be edited to START and END with ALL-DAY and SCOPE."
  (when (and (eq (plist-get (org-timegrid-event-metadata event) :repeater-unit) 'hour)
             (not (eq scope 'all)))
    (user-error "Hourly history repeaters currently support only All edits"))
  (when (and (not (eq scope 'all))
             (/= (floor start 1440) (floor (org-timegrid-event-start event) 1440)))
    (user-error "Scoped history edits must stay on the occurrence's date"))
  (when (and all-day (not (org-timegrid-org--all-day-range-p start end)))
    (user-error "All-day ranges must span whole days")))

(defun org-timegrid-org--write-history-range
    (event timestamp start end all-day scope deleting)
  "Rewrite TIMESTAMP for EVENT; return its new (MARKER . KIND).
START, END, ALL-DAY, SCOPE and DELETING describe the edit.  The caller owns
buffer selection, validation and the atomic change group."
  (let* ((metadata (org-timegrid-event-metadata event))
         (source (org-timegrid-event-source event))
         (old-start (org-timegrid-event-start event))
         (base (if (org-timegrid-event-all-day event)
                   (org-timegrid-org--timestamp-all-day-minutes timestamp nil)
                 (org-timegrid-org--timestamp-minutes timestamp nil)))
         (replace (or (memq scope '(all direct)) (= base old-start)))
         (offset (if (eq scope 'all) (- base old-start) 0))
         (value (plist-get metadata :repeater-value))
         (resume (and value (org-timegrid-org--next-repetition
                             old-start value (plist-get metadata :repeater-unit))))
         (until (plist-get metadata :history-until)))
    ;; One-off edits resume only before the next existing break.
    (when (and (eq scope 'this) resume (or (null until) (< resume until)))
      (goto-char (org-element-property :end timestamp))
      (insert "\n" (org-timegrid-org--history-replacement
                     timestamp resume
                     (+ resume (- (org-timegrid-event-end event) old-start))
                     (org-timegrid-event-all-day event))))
    (if replace
        (let ((region (if deleting
                          (org-timegrid-org--timestamp-region
                           timestamp (plist-get source :kind))
                        (cons (org-element-property :begin timestamp)
                              (org-element-property :end timestamp)))))
          (goto-char (car region))
          (delete-region (car region) (cdr region)))
      (goto-char (org-element-property :end timestamp))
      (insert "\n"))
    (let ((marker (copy-marker (point))))
      (insert (org-timegrid-org--history-replacement
               timestamp (+ start offset) (+ end offset)
               all-day (eq scope 'this) deleting))
      (when deleting
        (set-marker marker (+ (marker-position marker) (length "CANCELLED: "))))
      (cons marker (if (or deleting (not replace)) 'timestamp
                     (plist-get source :kind))))))

(defun org-timegrid-org--sync-history-event (event location start end all-day scope)
  "Update EVENT and editing context after writing LOCATION with START and END.
ALL-DAY and SCOPE describe the edit; LOCATION is a (MARKER . KIND) pair."
  (let* ((marker (car location))
         (timestamp (org-timegrid-org--timestamp-at-marker marker))
         (source (org-timegrid-event-source event))
         (metadata (org-timegrid-event-metadata event))
         (id (org-timegrid-org--event-id
              (plist-get source :file) (marker-position marker) (cdr location))))
    (dolist (property '(:raw-value :repeater-type :repeater-value :repeater-unit))
      (setq metadata (plist-put metadata property (org-element-property property timestamp))))
    (setf (plist-get source :marker) marker
          (plist-get source :kind) (cdr location)
          (org-timegrid-event-id event) (if (plist-get metadata :repeater-type) (list id start) id)
          (org-timegrid-event-start event) start
          (org-timegrid-event-end event) end
          (org-timegrid-event-all-day event) all-day
          (org-timegrid-event-metadata event) (plist-put metadata :reload-after-edit t))
    (setq org-timegrid--edit-context
          (list :marker (copy-marker marker) :start start
                :scope (if (eq scope 'this) 'direct scope)))))

(defun org-timegrid-org--update-history-range (event start end time-kind &optional deleting)
  "Edit EVENT's series to START and END with TIME-KIND, or cancel if DELETING."
  (let* ((scope (org-timegrid-org--prepare-history-edit event deleting))
         (marker (plist-get (org-timegrid-event-source event) :marker))
         (timestamp (org-timegrid-org--timestamp-at-marker marker))
         (all-day (if time-kind (eq time-kind 'all-day)
                    (org-timegrid-event-all-day event)))
         location)
    (org-timegrid-org--validate-event-source event timestamp)
    (org-timegrid-org--validate-history-range event start end all-day scope)
    (with-current-buffer (marker-buffer marker)
      (org-with-wide-buffer
       (when buffer-read-only (user-error "The source Org buffer is read-only"))
       (undo-boundary)
       (atomic-change-group
         (setq location (org-timegrid-org--write-history-range
                         event timestamp start end all-day scope deleting)))
       (undo-boundary)
       (org-timegrid-org--note-edit)))
    (org-timegrid-org--sync-history-event event location start end all-day scope)))

(defun org-timegrid-org--timestamp-region (timestamp kind)
  "Return the region to delete for TIMESTAMP of KIND as a cons cell.
The three kinds differ in one respect only: a SCHEDULED or DEADLINE value
takes its keyword with it, because a planning line whose timestamp is
gone plans nothing.  Everything after this point treats them alike."
  (let ((begin (org-element-property :begin timestamp))
        (end (org-element-property :end timestamp)))
    (if (not (memq kind '(scheduled deadline)))
        (cons begin end)
      (save-excursion
        (goto-char begin)
        (let ((label (upcase (symbol-name kind))))
          (unless (and (re-search-backward (concat "\\_<" label ":[ \t]*")
                                           (line-beginning-position) t)
                       (= (match-end 0) begin))
            (user-error "The planning timestamp label changed"))
          (cons (match-beginning 0) end))))))

(defun org-timegrid-org--remove-event (event)
  "Remove EVENT's time from its Org heading, keeping the heading itself."
  (if (plist-get (org-timegrid-event-metadata event) :history)
      (org-timegrid-org--update-history-range
       event (org-timegrid-event-start event) (org-timegrid-event-end event)
       nil t)
    (org-timegrid-org--remove-anchor event)))

(defun org-timegrid-org--remove-anchor (event)
  "Remove EVENT's original timestamp without history semantics."
  (let* ((source (org-timegrid-event-source event))
         (marker (plist-get source :marker))
         (timestamp (org-timegrid-org--timestamp-at-marker marker)))
    (org-timegrid-org--validate-event-source event timestamp)
    (with-current-buffer (marker-buffer marker)
      (org-with-wide-buffer
       (when buffer-read-only
         (user-error "The source Org buffer is read-only"))
       ;; The cut payload retains this marker for paste.  Keep it on its
       ;; heading before deleting the timestamp underneath it, and advance
       ;; it when paste inserts text at the end of the preceding heading.
       (save-excursion
         (goto-char marker)
         (org-back-to-heading t)
         (set-marker marker (point))
         (set-marker-insertion-type marker t))
       (undo-boundary)
       (atomic-change-group
         (let ((region (org-timegrid-org--timestamp-region
                        timestamp (plist-get source :kind))))
           (delete-region (car region) (cdr region))
           (goto-char (car region))
           ;; What is left behind belongs to neither the entry nor the
           ;; calendar: a gap between two values sharing a planning line,
           ;; or an empty line where the value stood alone.
           (when (looking-at "[ \t]\\{2,\\}")
             (replace-match " "))
           (when (save-excursion
                   (beginning-of-line)
                   (looking-at-p "[ \t]*$"))
             (delete-region (line-beginning-position)
                            (min (point-max) (1+ (line-end-position)))))))
       (undo-boundary))
      (org-timegrid-org--note-edit))
    (message "Untimed %s" (org-timegrid-event-title event))))

(defun org-timegrid-org--entry-empty-p (event)
  "Return non-nil when EVENT's heading has no remaining timestamps."
  (let ((marker (plist-get (org-timegrid-event-source event) :marker)))
    (and (markerp marker) (marker-buffer marker)
         (with-current-buffer (marker-buffer marker)
           (org-with-wide-buffer
            (org-element-cache-reset)
            (goto-char marker)
            (org-back-to-heading t)
            (let ((start (point))
                  (end (save-excursion (org-end-of-subtree t t) (point))))
              (not (save-restriction
                     (narrow-to-region start end)
                     (org-element-map (org-element-parse-buffer)
                         'timestamp #'identity nil t)))))))))

(defun org-timegrid-org--entry-key (event)
  "Return a stable identity for EVENT's owning heading."
  (let ((marker (plist-get (org-timegrid-event-source event) :marker)))
    (when (and (markerp marker) (marker-buffer marker))
      (with-current-buffer (marker-buffer marker)
        (org-with-wide-buffer
         (goto-char marker)
         (org-back-to-heading t)
         (cons (current-buffer) (point)))))))

(defun org-timegrid-org--timestamp-timed-p (timestamp)
  "Return non-nil when TIMESTAMP carries a clock start time.
An endpoint is optional.  An entry timed 09:00 with no end is a real
plan, and hiding it made the calendar disagree with the file; it is shown
`org-timegrid-default-duration-minutes' long instead.  Date-only values
still have no place on a time grid."
  (and timestamp
       (memq (org-element-property :type timestamp)
             '(active active-range))
       (integerp (org-element-property :hour-start timestamp))
       (integerp (org-element-property :minute-start timestamp))))

(defun org-timegrid-org--timestamp-all-day-p (timestamp)
  "Return non-nil when TIMESTAMP is an active date without a clock time."
  (and timestamp
       (memq (org-element-property :type timestamp)
             '(active active-range))
       (not (integerp (org-element-property :hour-start timestamp)))))

(defun org-timegrid-org--timestamp-all-day-minutes (timestamp endp)
  "Return the exclusive absolute-minute bounds of date-only TIMESTAMP.
ENDP selects the end rather than the start of a timestamp range.
Org writes an inclusive final date, whereas the renderer uses a half-open
interval.  Thus an Org range through August 27 ends internally at the start
of August 28, without displaying or writing an August 28 occurrence."
  (let* ((suffix (if (and endp (org-element-property :range-type timestamp))
                     "-end"
                   "-start"))
         (year (org-element-property (intern (format ":year%s" suffix)) timestamp))
         (month (org-element-property (intern (format ":month%s" suffix)) timestamp))
         (day (org-element-property (intern (format ":day%s" suffix)) timestamp))
         (absolute (calendar-absolute-from-gregorian (list month day year))))
    (* (+ absolute (if endp 1 0)) 1440)))

(defun org-timegrid-org--timestamp-minutes (timestamp endp)
  "Return TIMESTAMP start or end as an absolute minute.
ENDP selects the endpoint.  A clock-only range whose endpoint is not later
than its start is treated as ending on the following day.  A timestamp
with no end time gets `org-timegrid-default-duration-minutes'."
  ;; A plain timestamp reports its end hour as a copy of its start, so
  ;; `range-type' is the only trustworthy sign that an end was written.
  (if (and endp (not (org-element-property :range-type timestamp)))
      (+ (org-timegrid-org--timestamp-minutes timestamp nil)
         org-timegrid-default-duration-minutes)
    (let* ((suffix (if endp "-end" "-start"))
           (year (or (org-element-property
                      (intern (format ":year%s" suffix)) timestamp)
                     (org-element-property :year-start timestamp)))
           (month (or (org-element-property
                       (intern (format ":month%s" suffix)) timestamp)
                      (org-element-property :month-start timestamp)))
           (day (or (org-element-property
                     (intern (format ":day%s" suffix)) timestamp)
                    (org-element-property :day-start timestamp)))
           (hour (org-element-property
                  (intern (format ":hour%s" suffix)) timestamp))
           (minute (org-element-property
                    (intern (format ":minute%s" suffix)) timestamp))
           (absolute
            (+ (* (calendar-absolute-from-gregorian (list month day year)) 1440)
               (* hour 60) minute)))
      (if endp
          (let ((start
                 (+ (* (calendar-absolute-from-gregorian
                        (list (org-element-property :month-start timestamp)
                              (org-element-property :day-start timestamp)
                              (org-element-property :year-start timestamp)))
                       1440)
                    (* (org-element-property :hour-start timestamp) 60)
                    (org-element-property :minute-start timestamp))))
            (if (<= absolute start) (+ absolute 1440) absolute))
        absolute))))

(defun org-timegrid-org--timestamp-position (headline timestamp)
  "Return TIMESTAMP's source position within HEADLINE."
  (or (org-element-property :begin timestamp)
      (let ((raw (org-element-property :raw-value timestamp)))
        (save-excursion
          (goto-char (org-element-property :begin headline))
          (when (search-forward raw (org-element-property :end headline) t)
            (match-beginning 0))))))

(defun org-timegrid-org--event-id (file position kind)
  "Build a stable-enough identity for FILE POSITION and KIND."
  (list file position kind))

(defun org-timegrid-org--event
    (file headline timestamp kind &optional all-day)
  "Create a calendar event for FILE HEADLINE TIMESTAMP of KIND.
ALL-DAY records that the timestamp has dates but no times."
  (let* ((todo (org-element-property :todo-keyword headline))
         (begin (org-timegrid-org--timestamp-position
                 headline timestamp)))
    (unless begin
      (error "Cannot locate Org timestamp source for %s"
             (org-element-property :raw-value timestamp)))
    (org-timegrid-event-create
     :id (org-timegrid-org--event-id file begin kind)
     :title (or (org-element-property :raw-value headline) "Untitled")
     :start (if all-day
                (org-timegrid-org--timestamp-all-day-minutes timestamp nil)
              (org-timegrid-org--timestamp-minutes timestamp nil))
     :end (if all-day
              (org-timegrid-org--timestamp-all-day-minutes timestamp t)
            (org-timegrid-org--timestamp-minutes timestamp t))
     :all-day all-day
     :tags (org-element-property :tags headline)
     ;; `org-timegrid-org--mark-latest-done' promotes this to `done'
     ;; on whichever of the heading's events is latest.
     :state todo
     :color (funcall org-timegrid-org-color-function headline)
     :source (list :file file :marker (copy-marker begin) :kind kind)
     :metadata
     (list :planning-type kind
           :raw-value (org-element-property :raw-value timestamp)
           :repeater-type (org-element-property :repeater-type timestamp)
           :repeater-value (org-element-property :repeater-value timestamp)
           :repeater-unit (org-element-property :repeater-unit timestamp)))))

(defun org-timegrid-org--add-months (absolute-minute months)
  "Add MONTHS to ABSOLUTE-MINUTE while preserving its wall-clock time."
  (let* ((absolute-day (floor absolute-minute 1440))
         (minute-of-day (% absolute-minute 1440))
         (date (calendar-gregorian-from-absolute absolute-day))
         (month-index (+ (* (nth 2 date) 12) (1- (nth 0 date)) months))
         (year (floor month-index 12))
         (month (1+ (% month-index 12)))
         (day (min (nth 1 date) (calendar-last-day-of-month month year))))
    (+ (* (calendar-absolute-from-gregorian (list month day year)) 1440)
       minute-of-day)))

(defun org-timegrid-org--next-repetition
    (absolute-minute value unit)
  "Advance ABSOLUTE-MINUTE by repeater VALUE and UNIT."
  (pcase unit
    ('hour (+ absolute-minute (* value 60)))
    ('day (+ absolute-minute (* value 1440)))
    ('week (+ absolute-minute (* value 7 1440)))
    ('month (org-timegrid-org--add-months absolute-minute value))
    ('year (org-timegrid-org--add-months absolute-minute (* value 12)))
    (_ (error "Unsupported Org repeater unit: %S" unit))))

(defun org-timegrid-org--expand-event (event query-start query-end)
  "Expand EVENT occurrences intersecting QUERY-START through QUERY-END."
  (let* ((metadata (org-timegrid-event-metadata event))
         (value (plist-get metadata :repeater-value))
         (unit (plist-get metadata :repeater-unit))
         (base-start (org-timegrid-event-start event))
         (duration (- (org-timegrid-event-end event) base-start))
         (until (plist-get metadata :history-until)))
    (when until (setq query-end (min query-end until)))
    (cond
     ((plist-get metadata :cancelled) nil)
     ((not (and (integerp value) (> value 0) unit))
        (and (< base-start query-end)
             (> (+ base-start duration) query-start)
             (list event)))
     (t
      (let ((occurrence-start base-start)
            (iterations 0)
            occurrences)
        (while (and (< occurrence-start query-end)
                    (< iterations 100000))
          (when (> (+ occurrence-start duration) query-start)
            (let ((occurrence (copy-org-timegrid-event event)))
              (setf (org-timegrid-event-id occurrence)
                    (list (org-timegrid-event-id event)
                          occurrence-start)
                    (org-timegrid-event-start occurrence)
                    occurrence-start
                    (org-timegrid-event-end occurrence)
                    (+ occurrence-start duration)
                    (org-timegrid-event-metadata occurrence)
                    (plist-put (copy-sequence metadata)
                               :occurrence-start occurrence-start))
              (push occurrence occurrences)))
          (let ((next (org-timegrid-org--next-repetition
                       occurrence-start value unit)))
            (unless (> next occurrence-start)
              (error "Org repeater did not advance: %S" event))
            (setq occurrence-start next
                  iterations (1+ iterations))))
        (when (= iterations 100000)
          (error "Org repeater expansion exceeded safety limit"))
        (nreverse occurrences))))))

(defun org-timegrid-org--mark-latest-done (events todo)
  "Mark the latest of EVENTS as done when heading keyword TODO is done.
A heading's done state isn't a property of any one timestamp, so
marking every timestamp done erases history: earlier occurrences
already happened and shouldn't change appearance just because the
heading was later marked done or cancelled.  Only the latest timestamp
reflects the current state; the rest keep their plain TODO keyword."
  (when (and events (member todo org-done-keywords))
    (let ((latest (apply #'max (mapcar #'org-timegrid-event-start events))))
      (dolist (event events)
        (when (= (org-timegrid-event-start event) latest)
          (setf (org-timegrid-event-state event) 'done)))))
  events)

(defun org-timegrid-org--buffer-events (&optional file)
  "Extract explicit timed ranges from the current Org buffer.
FILE defaults to the variable `buffer-file-name'."
  (let* ((file (or file buffer-file-name (buffer-name)))
         (tree (org-element-parse-buffer))
         events seen)
    (org-element-map tree 'headline
      (lambda (headline)
        (let ((history (save-excursion
                         (goto-char (org-element-property :begin headline))
                         (org-timegrid-org--repeater-history-p)))
              headline-events)
          (dolist (planning `((scheduled . ,(org-element-property
                                             :scheduled headline))
                              (deadline . ,(org-element-property
                                            :deadline headline))))
            (let ((timestamp (cdr planning)))
              (when (and
                     (or (org-timegrid-org--timestamp-timed-p timestamp)
                         (org-timegrid-org--timestamp-all-day-p timestamp))
                     (funcall org-timegrid-org-filter-function
                              headline timestamp))
                (push (org-element-property :begin timestamp) seen)
                (push (org-timegrid-org--event
                       file headline timestamp (car planning)
                       (org-timegrid-org--timestamp-all-day-p timestamp))
                      headline-events))))
          (when-let* ((section (cl-find-if
                               (lambda (element) (eq (org-element-type element) 'section))
                               (org-element-contents headline))))
            (org-element-map section 'timestamp
              (lambda (timestamp)
                (let ((cancelled
                       (and history
                            (memq (org-element-property :type timestamp)
                                  '(inactive inactive-range))
                            (save-excursion
                              (goto-char (org-element-property :begin timestamp))
                              (looking-back "CANCELLED: [ \t]*" (line-beginning-position))))))
                  (when (or cancelled
                            (and (or (org-timegrid-org--timestamp-timed-p timestamp)
                                     (org-timegrid-org--timestamp-all-day-p timestamp))
                                 (funcall org-timegrid-org-filter-function headline timestamp)
                                 (not (memq (org-element-property :begin timestamp) seen))))
                    (let ((event (org-timegrid-org--event
                                  file headline timestamp 'timestamp
                                  (not (org-element-property :hour-start timestamp)))))
                      (when cancelled
                        (setf (org-timegrid-event-metadata event)
                              (plist-put (org-timegrid-event-metadata event) :cancelled t)))
                      (push event headline-events)))))))
          (when history (org-timegrid-org--history-events headline-events))
          (setq events
                (nconc (org-timegrid-org--mark-latest-done
                        headline-events
                        (org-element-property :todo-keyword headline))
                       events)))))
    (nreverse events)))

(defun org-timegrid-org--list-events (start end)
  "Return Org events intersecting absolute minutes START through END."
  (cl-loop for file in (org-timegrid-org--files)
           append
           (with-current-buffer (find-file-noselect file)
             (org-with-wide-buffer
              (mapcan (lambda (event)
                        (org-timegrid-org--expand-event event start end))
                      (org-timegrid-org--buffer-events file))))))

(defun org-timegrid-org--visit-event (event)
  "Visit the Org heading that owns EVENT."
  (let* ((source (org-timegrid-event-source event))
         (marker (plist-get source :marker)))
    (unless (and (markerp marker) (marker-buffer marker))
      (user-error "The Org source marker is no longer live"))
    (pop-to-buffer-same-window (marker-buffer marker))
    (goto-char marker)
    (org-back-to-heading t)
    (org-fold-show-context)))

(defun org-timegrid-org-selected-marker ()
  "Return the Org heading marker for the selected calendar block.
Signal a user error if no block is selected, its backend is not Org, or
  its source entry is no longer available."
  (let* ((block (org-timegrid--selected-block))
         (event (org-timegrid-block-event block))
         (source (and event (org-timegrid-event-source event)))
         (marker (plist-get source :marker)))
    (unless (and (markerp marker) (marker-buffer marker))
      (user-error "The selected block has no Org source entry"))
    marker))

(defun org-timegrid-org--heading-location (marker)
  "Return MARKER's Org heading as a buffer-position pair."
  (unless (and (markerp marker) (marker-buffer marker))
    (user-error "The selected block has no live Org source entry"))
  (with-current-buffer (marker-buffer marker)
    (org-with-wide-buffer
     (goto-char marker)
     (org-back-to-heading t)
     (cons (current-buffer) (point)))))

(defun org-timegrid-org--run-at (command buffer position &optional heading)
  "Run COMMAND interactively in BUFFER at POSITION, then refresh the calendar.
When HEADING is non-nil, move to the containing Org heading first."
  (unless (commandp command)
    (user-error "%S is not an interactive command" command))
  (let ((calendar (current-buffer)))
    (unwind-protect
        (save-window-excursion
          (with-current-buffer buffer
            (save-restriction
              (widen)
              (goto-char position)
              (when heading (org-back-to-heading t))
              (call-interactively command))))
      (when (buffer-live-p calendar)
        (with-current-buffer calendar
          (org-timegrid--refresh-data))))))

(defun org-timegrid-org--run-selected-command (command)
  "Run Org COMMAND at the selected calendar entry."
  (pcase-let ((`(,buffer . ,position)
               (org-timegrid-org--heading-location
                (org-timegrid-org-selected-marker))))
    (org-timegrid-org--run-at command buffer position t)))

(defun org-timegrid-org--agenda-location (source-marker)
  "Return an Agenda buffer-position pair for SOURCE-MARKER."
  (let ((source (org-timegrid-org--heading-location source-marker)))
    (or
     (catch 'found
       (dolist (buffer (buffer-list))
         (with-current-buffer buffer
           (when (derived-mode-p 'org-agenda-mode)
             (save-excursion
               (goto-char (point-min))
               (while (not (eobp))
                 (let ((marker (or (org-get-at-bol 'org-hd-marker)
                                   (org-get-at-bol 'org-marker))))
                   (when (and (markerp marker)
                              (equal (org-timegrid-org--heading-location marker)
                                     source))
                     (throw 'found (cons buffer (point)))))
                 (forward-line 1)))))))
     (user-error "The selected entry is not present in a live Org Agenda buffer"))))

(defun org-timegrid-org--run-selected-agenda-command (command)
  "Run Agenda COMMAND on the line for the selected calendar entry."
  (pcase-let ((`(,buffer . ,position)
               (org-timegrid-org--agenda-location
                (org-timegrid-org-selected-marker))))
    (org-timegrid-org--run-at command buffer position)))

(defun org-timegrid-org-command (command)
  "Return an interactive wrapper to run Org COMMAND on the selected entry."
  (lambda ()
    (interactive)
    (org-timegrid-org--run-selected-command command)))

(defun org-timegrid-org-agenda-command (command)
  "Return an interactive wrapper to run Agenda COMMAND on the selected entry."
  (lambda ()
    (interactive)
    (org-timegrid-org--run-selected-agenda-command command)))

(defalias 'org-timegrid-org-set-tags
  (org-timegrid-org-command #'org-set-tags-command)
  "Set tags on the selected calendar entry, then refresh the calendar.")

(defalias 'org-timegrid-org-open-at-point
  (org-timegrid-org-command #'org-open-at-point)
  "Open the link at the selected calendar entry's Org heading.")

(defalias 'org-timegrid-org-todo
  (org-timegrid-org-command #'org-todo)
  "Change the selected calendar entry's TODO state, then refresh the calendar.")

(defalias 'org-timegrid-org-clock-in
  (org-timegrid-org-command #'org-clock-in)
  "Clock in to the selected calendar entry, then refresh the calendar.")

(defalias 'org-timegrid-org-clock-out
  (org-timegrid-org-command #'org-clock-out)
  "Clock out from the selected calendar entry, then refresh the calendar.")

(defalias 'org-timegrid-org-priority
  (org-timegrid-org-command #'org-priority)
  "Set the selected calendar entry's priority, then refresh the calendar.")

(defalias 'org-timegrid-org-set-effort
  (org-timegrid-org-command #'org-set-effort)
  "Set the selected calendar entry's effort, then refresh the calendar.")

(defalias 'org-timegrid-org-add-note
  (org-timegrid-org-command #'org-add-note)
  "Add a note to the selected calendar entry, then refresh the calendar.")

(defalias 'org-timegrid-org-refile
  (org-timegrid-org-command #'org-refile)
  "Refile the selected calendar entry, then refresh the calendar.")

(defalias 'org-timegrid-org-archive
  (org-timegrid-org-command #'org-archive-subtree-default)
  "Archive the selected calendar entry, then refresh the calendar.")

(defvar org-timegrid-org-backend
  (org-timegrid-backend-create
   :name "Org"
   :list-function #'org-timegrid-org--list-events
   :create-function #'org-timegrid-org--create-event
   :update-function #'org-timegrid-org--update-event-range
   :delete-function #'org-timegrid-org--remove-event
   :delete-entry-function #'org-timegrid-org--remove-entry
   :undo-function #'org-timegrid-org--undo
   :transaction-function #'org-timegrid-org--transaction
   :entry-empty-function #'org-timegrid-org--entry-empty-p
   :entry-key-function #'org-timegrid-org--entry-key
   :visit-function #'org-timegrid-org--visit-event
   :read-entry-function #'org-timegrid-org-read-entry
   :read-timestamp-function #'org-timegrid-org-read-timestamp)
  "Org backend used by the integrated Week view.")

(defun org-timegrid-org-read-timestamp (absolute-start duration)
  "Read a start, and possibly a duration, through the Org date prompt.
The prompt is prefilled from ABSOLUTE-START so accepting it costs one
key.  A typed time range such as `10:00-11:30' carries the duration, and
that is returned; otherwise the duration is nil and the caller asks for
it.  DURATION is unused because only a typed range can supply one here."
  (ignore duration)
  (let* ((day (floor absolute-start 1440))
         (minute (% absolute-start 1440))
         (date (calendar-gregorian-from-absolute day))
         (default-time (encode-time 0 (% minute 60) (/ minute 60)
                                    (nth 1 date) (nth 0 date) (nth 2 date)))
         (org-end-time-was-given nil)
         (answer (org-timegrid-calendar-read-date
                  org-timegrid-org-backend t nil nil "Time"
                  default-time))
         (parsed (org-parse-time-string answer))
         (clock (+ (* 60 (nth 2 parsed)) (nth 1 parsed)))
         (start (+ (* 1440 (calendar-absolute-from-gregorian
                            (list (nth 4 parsed) (nth 3 parsed) (nth 5 parsed))))
                   clock))
         ;; `org-end-time-was-given' is how `org-schedule' picks up a typed
         ;; range, and it is the only reliable signal that one was given.
         (end (and (stringp org-end-time-was-given)
                   (string-match "\\([0-9]+\\):\\([0-9]+\\)"
                                 org-end-time-was-given)
                   (+ (* 60 (string-to-number
                             (match-string 1 org-end-time-was-given)))
                      (string-to-number
                       (match-string 2 org-end-time-was-given))))))
    (cons start (and end (> end clock) (- end clock)))))

;;;###autoload
(defun org-timegrid-week (&optional absolute-date)
  "Open the Org-backed week containing ABSOLUTE-DATE."
  (interactive)
  (org-timegrid-open org-timegrid-org-backend absolute-date))

(provide 'org-timegrid-org)
;;; org-timegrid-org.el ends here
