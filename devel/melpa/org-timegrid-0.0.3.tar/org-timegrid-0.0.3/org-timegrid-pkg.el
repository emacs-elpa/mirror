;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "0.0.3"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "f54a782eaf9c0ab11acb48394f526942eb6a665b"
  :revdesc "v0.0.3-0-gf54a782eaf9c"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
