;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "0.12.0.0.20261126.8"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "b44290a7176e2aa90c54b0a71fd1016ca9f668f2"
  :revdesc "b44290a7176e"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
