;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linum-off" "0.1.0.20160217.2"
  "Provides an interface for turning line-numbering off."
  ()
  :url "http://www.emacswiki.org/emacs/auto-indent-mode.el "
  :commit "3e37baaad27d27e405f8dfe01d4ab9cd5b591353"
  :revdesc "3e37baaad27d"
  :keywords '("line" "numbering"))
