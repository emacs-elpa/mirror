;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "preview-tab" "0.7.0"
  "Temporary file buffers, like VS Code's preview tab."
  '((emacs "27.1"))
  :url "https://github.com/ismd/preview-tab.el"
  :commit "4b10a95c2cae577ece000b0e777a95ba4887b747"
  :revdesc "4b10a95c2cae"
  :keywords '("convenience" "files")
  :authors '(("Vladimir Kosteley" . "github@ismd.dev"))
  :maintainers '(("Vladimir Kosteley" . "github@ismd.dev")))
