;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatland-black-theme" "20141116.0.20170808.3"
  "An Emacs 24 theme based on Flatland Black (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/flatland-black-theme"
  :commit "348c5d5fe615e6ea13cadc17f046e506e789ce07"
  :revdesc "348c5d5fe615")
