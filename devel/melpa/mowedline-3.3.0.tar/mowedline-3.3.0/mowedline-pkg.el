;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mowedline" "3.3.0"
  "Elisp utilities for using mowedline."
  ()
  :url "https://github.com/retroj/mowedline"
  :commit "c17501b48ded8261d815ab60bf14cddf7040be72"
  :revdesc "3.3.0-0-gc17501b48ded"
  :authors '(("John Foerch" . "jjfoerch@earthlink.net"))
  :maintainers '(("John Foerch" . "jjfoerch@earthlink.net")))
