;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-c-headers" "1.0.0.0.20200816.1"
  "Auto-complete source for C headers."
  '((auto-complete "1.3.1"))
  :url "http://zk-phi.gitub.io/"
  :commit "67e1e86a48c9bed57bc7ce5ce2553ad203f5752e"
  :revdesc "67e1e86a48c9")
