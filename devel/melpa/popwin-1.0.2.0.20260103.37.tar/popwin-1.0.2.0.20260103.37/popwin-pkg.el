;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popwin" "1.0.2.0.20260103.37"
  "Popup Window Manager."
  '((emacs "24.3"))
  :url "https://github.com/emacsorphanage/popwin"
  :commit "f7a39759180fa88f3890c3c5f35379ab086e04fa"
  :revdesc "f7a39759180f"
  :keywords '("convenience")
  :authors '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
