;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "namespaces" "1.2.2"
  "An implementation of namespaces for Elisp, with an emphasis on immutabilty."
  ()
  :url "https://github.com/chrisbarrett/elisp-namespaces"
  :commit "3d02525d9b9a5ae6e7be3adefd880121436e6270"
  :revdesc "3d02525d9b9a")
