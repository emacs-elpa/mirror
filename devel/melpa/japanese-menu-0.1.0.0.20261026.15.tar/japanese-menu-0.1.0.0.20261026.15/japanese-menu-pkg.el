;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "japanese-menu" "0.1.0.0.20261026.15"
  "Japanese menu translation."
  '((emacs "26.1"))
  :url "https://github.com/yt-emacs-ja/emacs-japanese-menu"
  :commit "5790e2a9c88ff0b7165a7cacb3a36e3e0225c921"
  :revdesc "5790e2a9c88f"
  :keywords '("convenience" "japanese" "menu")
  :authors '(("yt-emacs-ja" . "https://github.com/yt-emacs-ja"))
  :maintainers '(("yt-emacs-ja" . "https://github.com/yt-emacs-ja")))
