;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "1.7.1.0.20260831.11"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "55b9c765e7284de03269bdc4404e5bc5a384b042"
  :revdesc "55b9c765e728"
  :keywords '("chinese" "isearch" "matching" "convenience")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
