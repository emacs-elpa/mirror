;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-sitter-indent" "0.3.0.20220411.14"
  "Provide indentation with a Tree-sitter backend."
  '((emacs       "26.1")
    (tree-sitter "0.12.1")
    (seq         "2.20"))
  :url "https://codeberg.org/FelipeLema/tree-sitter-indent.el"
  :commit "4ef246db3e4ff99f672fe5e4b416c890f885c09e"
  :revdesc "4ef246db3e4f"
  :keywords '("convenience" "internal")
  :authors '(("Felipe Lema" . "felipelema@mortemale.org"))
  :maintainers '(("Felipe Lema" . "felipelema@mortemale.org")))
