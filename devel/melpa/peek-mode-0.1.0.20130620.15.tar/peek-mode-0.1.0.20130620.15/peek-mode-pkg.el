;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "peek-mode" "0.1.0.20130620.15"
  "Serve buffers live over HTTP with elnode backend."
  '((elnode "0.9.8.1"))
  :url "https://github.com/erikriverson/peek-mode"
  :commit "55a7dd011375330c7d57322257a5167516702c71"
  :revdesc "55a7dd011375"
  :authors '(("Erik Iverson" . "erik@sigmafield.org"))
  :maintainers '(("Erik Iverson" . "erik@sigmafield.org")))
