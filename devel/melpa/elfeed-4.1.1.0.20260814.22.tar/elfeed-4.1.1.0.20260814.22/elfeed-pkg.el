;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.1.1.0.20260814.22"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "a901e326e52f46e619450a7802cf4903b87d0b7e"
  :revdesc "4.1.1-22-ga901e326e52f"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
