;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soft-charcoal-theme" "0.2.0.20140420.9"
  "Dark charcoal theme with soft colors."
  ()
  :url "https://github.com/mswift42/soft-charcoal-theme"
  :commit "5607ab977fae6638e78b1495e02da8955c9ba19f"
  :revdesc "5607ab977fae")
