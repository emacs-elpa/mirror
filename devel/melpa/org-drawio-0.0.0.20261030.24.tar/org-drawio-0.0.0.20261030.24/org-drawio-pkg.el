;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-drawio" "0.0.0.20261030.24"
  "Convert and include drawio image to orgmode."
  '((org   "9.6.6")
    (emacs "28.1"))
  :url "https://github.com/kimim/org-drawio"
  :commit "95e9c05bfd5189b58be1a62a2377d53397d1643d"
  :revdesc "95e9c05bfd51"
  :keywords '("multimedia" "convenience")
  :authors '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainers '(("Kimi Ma" . "kimi.im@outlook.com")))
