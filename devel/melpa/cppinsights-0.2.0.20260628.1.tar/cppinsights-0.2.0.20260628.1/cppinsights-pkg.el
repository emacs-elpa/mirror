;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cppinsights" "0.2.0.20260628.1"
  "Integration with cppinsights tool."
  '((emacs "28.1"))
  :url "https://github.com/ignity21/cppinsights.el"
  :commit "552d959a7313e746b2a343991bffb9c2271dba47"
  :revdesc "552d959a7313"
  :keywords '("c++" "tools" "cppinsights")
  :authors '(("Chris Chen" . "chrischen@ignity.xyz"))
  :maintainers '(("Chris Chen" . "chrischen@ignity.xyz")))
