;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zenburn-theme" "2.10.0.0.20260723.6"
  "A low contrast color theme for Emacs."
  ()
  :url "https://github.com/bbatsov/zenburn-emacs"
  :commit "703d08cf709526b6a0bde85df059836d795b5628"
  :revdesc "703d08cf7095"
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
