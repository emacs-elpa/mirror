;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-comment" "1.0.0.0.20200812.6"
  "Insert Elisp result as comment in scratch buffer."
  '((emacs "26.1"))
  :url "https://github.com/conao3/scratch-comment.el"
  :commit "cf3e967b4def1308b6ef1cfeedd2cf15ee6e226c"
  :revdesc "cf3e967b4def"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
