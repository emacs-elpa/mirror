;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dracula-theme" "1.8.3.0.20260224.4"
  "Dracula Theme."
  '((emacs "24.3"))
  :url "https://github.com/dracula/emacs"
  :commit "b1a4d87ba1cf880143f4ab2ccd942cf556887fb1"
  :revdesc "v1.8.3-4-gb1a4d87ba1cf"
  :maintainers '(("tienne Deparis" . "etienne@depar.is")))
