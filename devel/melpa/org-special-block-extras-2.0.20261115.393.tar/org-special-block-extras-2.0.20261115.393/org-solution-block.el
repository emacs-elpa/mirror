;;; org-solution-block.el --- Answers folded away, behind a reprimand  -*- lexical-binding: t; -*-

;; Copyright (c) 2021 Musa Al-hassy

;; Author: Musa Al-hassy <alhassy@gmail.com>
;; Package-Requires: ((s "1.13.1") (dash "2.18.1") (emacs "28.2") (org "9.8"))
;; Keywords: org, blocks, convenience
;; URL: https://alhassy.com/org-special-block-extras

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;;; Commentary:

;; A solution block is a details block, holding a box of reprimand, holding the answer in details.
;;
;; Full documentation at https://alhassy.com/org-special-block-extras

;;; Code:

(require 'org-defblock)
(require 'org-box-block)
(require 'org-details-block)
(require 'org-thread-blockcall)

;;;;;; solution
(org-defblock solution
              (&optional (title "Solution")
               &key (reprimand "Did you actually try? Maybe see the ‘hints’ above!") (really "Solution, for real")
               &allow-other-keys :manual "#Boxed-Text" &context raw-contents)
              "Show the answers to a problem, but with a reprimand in case no attempt was made."
              (org-thread-blockcall raw-contents
                                    (details really :title-color "red")
                                    (box reprimand :background-color "blue")
                                    (details title)))

(org-defblock-attribute solution :example "
# The answer hides, folded, beneath a reprimand asking whether the reader really tried.
#+begin_solution
$2 + 2 = 4$, by counting on our fingers.
#+end_solution

# :reprimand and :really reword the inner folds.")

(provide 'org-solution-block)
;;; org-solution-block.el ends here
