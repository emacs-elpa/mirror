;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaomel" "1.0.0.0.20260615.10"
  "A snappy kaomoji picker."
  '((emacs "27.1"))
  :url "https://github.com/gicrisf/kaomel"
  :commit "652b31cc8437d87b65e618af9428229182ea595c"
  :revdesc "652b31cc8437"
  :keywords '("convenience" "extensions" "faces" "tools")
  :authors '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com"))
  :maintainers '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com")))
