;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "2.9.1.0.20260630.223"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "a9611b1e72d943428b6562f4c89f74807be1f9ae"
  :revdesc "a9611b1e72d9"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
