;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2.0.20260819.28"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "4b879cf99feefc6f7b7a22327e9f01e64110d396"
  :revdesc "4b879cf99fee"
  :keywords '("faces" "files" "q"))
