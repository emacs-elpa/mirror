;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multi-run" "1.0.20210108.30"
  "Efficiently manage multiple remote nodes."
  '((emacs         "24")
    (window-layout "1.4"))
  :url "https://www.github.com/sagarjha/multi-run"
  :commit "13d4d923535b5e8482b13ff76185203075fb26a3"
  :revdesc "13d4d923535b"
  :keywords '("multiple shells" "multi-run" "remote nodes"))
