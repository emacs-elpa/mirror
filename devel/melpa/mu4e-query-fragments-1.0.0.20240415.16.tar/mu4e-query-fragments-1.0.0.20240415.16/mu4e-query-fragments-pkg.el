;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-query-fragments" "1.0.0.20240415.16"
  "Mu4e query fragments extension."
  '((emacs "24.4"))
  :url "https://gitlab.com/wavexx/mu4e-query-fragments.el"
  :commit "14b38e4a7b7aae47f3c1bdccb6680f8c38c645bf"
  :revdesc "14b38e4a7b7a"
  :keywords '("mu4e" "mail" "convenience")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
