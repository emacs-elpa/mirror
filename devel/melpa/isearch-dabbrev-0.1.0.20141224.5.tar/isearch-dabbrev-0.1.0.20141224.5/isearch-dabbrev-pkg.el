;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "isearch-dabbrev" "0.1.0.20141224.5"
  "Use dabbrev in isearch."
  '((cl-lib "0.5"))
  :url "https://github.com/Dewdrops/isearch-dabbrev"
  :commit "1efe7abba4923015cbc2462395deaec5446a9cc8"
  :revdesc "1efe7abba492"
  :keywords '("dabbrev" "isearch")
  :authors '(("Dewdrops" . "v_v_4474@126.com"))
  :maintainers '(("Dewdrops" . "v_v_4474@126.com")))
