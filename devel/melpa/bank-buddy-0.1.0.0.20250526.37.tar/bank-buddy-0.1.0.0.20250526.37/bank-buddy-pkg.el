;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bank-buddy" "0.1.0.0.20250526.37"
  "Financial analysis and reporting."
  '((emacs "26.1")
    (async "1.9.4"))
  :url "https://github.com/captainflasmr/bank-buddy"
  :commit "762ad9e24fa2fe38991513b6b5166c0df8fdd689"
  :revdesc "762ad9e24fa2"
  :keywords '("matching")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
