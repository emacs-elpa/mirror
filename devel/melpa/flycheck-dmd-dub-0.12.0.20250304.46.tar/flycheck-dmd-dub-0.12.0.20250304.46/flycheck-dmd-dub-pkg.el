;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-dmd-dub" "0.12.0.20250304.46"
  "Sets flycheck-dmd-include-paths from dub package information."
  '((flycheck "0.24")
    (f        "0.18.2"))
  :url "https://github.com/atilaneves/flycheck-dmd-dub"
  :commit "c1bf54b7eca8951a38ce9f6ae12e07a011f03eb5"
  :revdesc "V0.12-46-gc1bf54b7eca8"
  :keywords '("languages")
  :authors '(("Atila Neves" . "atila.neves@gmail.com"))
  :maintainers '(("Atila Neves" . "atila.neves@gmail.com")))
