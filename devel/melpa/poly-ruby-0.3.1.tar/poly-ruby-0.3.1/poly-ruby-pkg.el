;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-ruby" "0.3.1"
  "Provides poly-ruby-mode."
  '((emacs    "25")
    (polymode "0.1.2"))
  :url "https://github.com/knu/poly-ruby.el"
  :commit "794ebb926ace23e9c1398da934701951432dcea2"
  :revdesc "794ebb926ace"
  :keywords '("languages")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
