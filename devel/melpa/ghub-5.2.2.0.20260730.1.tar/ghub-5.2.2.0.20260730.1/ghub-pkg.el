;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "5.2.2.0.20260730.1"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (treepy   "0.1.3"))
  :url "https://github.com/magit/ghub"
  :commit "4805f300dd2607d1628bd8554cb05ab557e2fab8"
  :revdesc "v5.2.2-1-g4805f300dd26"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
