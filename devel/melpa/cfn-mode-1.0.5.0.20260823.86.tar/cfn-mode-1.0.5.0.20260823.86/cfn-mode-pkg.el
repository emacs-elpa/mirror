;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "1.0.5.0.20260823.86"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "1652cda225eba6180e8b586ec59c3b152e2a4c9b"
  :revdesc "cfn-mode/v1.0.5-86-g1652cda225eb"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
