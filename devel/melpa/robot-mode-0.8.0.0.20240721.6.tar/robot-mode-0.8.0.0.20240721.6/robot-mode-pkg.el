;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "robot-mode" "0.8.0.0.20240721.6"
  "Major-mode for Robot Framework files."
  '((emacs "26.1"))
  :url "https://github.com/kopoli/robot-mode"
  :commit "7c8d7adfa37b7bd15d61cbb78a02e0e1596c453c"
  :revdesc "v0.8.0-6-g7c8d7adfa37b"
  :keywords '("languages" "files")
  :authors '(("Kalle Kankare" . "kalle.kankare@iki.fi"))
  :maintainers '(("Kalle Kankare" . "kalle.kankare@iki.fi")))
