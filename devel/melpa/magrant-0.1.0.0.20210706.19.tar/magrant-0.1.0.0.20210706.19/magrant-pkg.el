;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magrant" "0.1.0.0.20210706.19"
  "Transient Interface to Vagrant."
  '((emacs                  "25.1")
    (dash                   "2.17.0")
    (s                      "1.12.0")
    (tablist                "0.70")
    (transient              "0.2.0")
    (friendly-shell-command "0.2.3"))
  :url "https://github.com/p3r7/magrant"
  :commit "6309c001355126e3ade79493479b517925943d17"
  :revdesc "6309c0013551"
  :keywords '("processes" "terminals"))
