;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-auto-commit-mode" "4.7.0"
  "Emacs Minor mode to automatically commit and push."
  ()
  :url "https://github.com/ryuslash/git-auto-commit-mode"
  :commit "df07899acdb3f9c114b72fdab77107c924b3172c"
  :revdesc "4.7.0-0-gdf07899acdb3"
  :keywords '("vc")
  :authors '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainers '(("Tom Willemse" . "tom@ryuslash.org")))
