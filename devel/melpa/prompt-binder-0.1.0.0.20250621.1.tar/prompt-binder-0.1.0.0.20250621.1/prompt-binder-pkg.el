;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prompt-binder" "0.1.0.0.20250621.1"
  "Bind LLM prompts to key chords and editor context."
  '((emacs "24.3")
    (llm   "0.26.0"))
  :url "https://github.com/tracym"
  :commit "e0e81fba2f1eaf7fa82827fbf32c0cdbf1328d2f"
  :revdesc "e0e81fba2f1e"
  :keywords '("llm" "tools" "prompt"))
