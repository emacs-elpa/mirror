;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "0.3.0.20260701.225"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "134700bc05be6369bf3dff44e10be894be80a654"
  :revdesc "0.3-225-g134700bc05be"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
