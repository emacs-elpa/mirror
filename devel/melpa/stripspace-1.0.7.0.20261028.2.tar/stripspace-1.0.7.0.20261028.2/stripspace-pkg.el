;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "1.0.7.0.20261028.2"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "209006916a163d98d45624bd3e70aa39904cb0f9"
  :revdesc "1.0.7-2-g209006916a16"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
