;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "2.9"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "c9f991d39a1f6c71cafb462114abda40c223a501"
  :revdesc "c9f991d39a1f"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
