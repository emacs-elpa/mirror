;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flx-ido" "0.6.1.0.20260820.33"
  "Flx integration for ido."
  '((emacs  "24.1")
    (flx    "0.1")
    (cl-lib "0.3"))
  :url "https://github.com/lewang/flx"
  :commit "6803eca89d0c4c7871433c993463e66aabf77443"
  :revdesc "6803eca89d0c")
