;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lv" "0.15.0.0.20200507.26"
  "Other echo area."
  ()
  :url "https://github.com/abo-abo/hydra"
  :commit "87873d788891029d9e44fa5458321d6a05849b94"
  :revdesc "87873d788891")
