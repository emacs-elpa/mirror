;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phony" "3.0.0"
  "Define voice commands."
  '((emacs      "29.1")
    (simulacrum "2.0.0"))
  :url "https://github.com/ErikPrantare/phony.el"
  :commit "b2308e779fb398ac93ba61c5898d00843f89dd85"
  :revdesc "b2308e779fb3"
  :keywords '("convenience")
  :authors '(("Erik Präntare" . "erik@prantare.xyz"))
  :maintainers '(("Erik Präntare" . "erik@prantare.xyz")))
