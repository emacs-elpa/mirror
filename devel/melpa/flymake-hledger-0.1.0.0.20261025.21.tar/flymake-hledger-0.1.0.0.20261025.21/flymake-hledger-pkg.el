;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-hledger" "0.1.0.0.20261025.21"
  "Flymake module to check hledger journals."
  '((emacs "28.2"))
  :url "https://github.com/DamienCassou/flymake-hledger"
  :commit "4b0051589126a8f9178da7e271bac597ba1356e4"
  :revdesc "v0.1.0-21-g4b0051589126"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
