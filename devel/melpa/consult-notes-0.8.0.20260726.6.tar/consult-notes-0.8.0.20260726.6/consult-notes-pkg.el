;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-notes" "0.8.0.20260726.6"
  "Manage notes with consult."
  '((emacs   "28.1")
    (consult "1.0")
    (s       "1.12.0")
    (dash    "2.19"))
  :url "https://codeberg.org/mclear-tools/consult-notes"
  :commit "80c0beb618ca2216280b24fd1669683c29cd3d86"
  :revdesc "80c0beb618ca"
  :keywords '("convenience")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
