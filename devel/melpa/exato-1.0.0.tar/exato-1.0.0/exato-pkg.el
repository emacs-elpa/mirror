;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exato" "1.0.0"
  "EXATO: Evil XML/HTML Attributes Text Object."
  '((evil  "1.2.13")
    (emacs "24"))
  :url "https://github.com/ninrod/exato"
  :commit "5e7b5721bf48aa49c6cdb5d41b908ef7d513b2a8"
  :revdesc "5e7b5721bf48"
  :authors '(("Filipe Silva" . "filipe.silva@gmail.com"))
  :maintainers '(("Filipe Silva" . "filipe.silva@gmail.com")))
