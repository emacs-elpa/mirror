;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nixos-options" "0.0.1.0.20160209.29"
  "Interface for browsing and completing NixOS options."
  '((emacs "24"))
  :url "http://www.github.com/travisbhartwell/nix-emacs/"
  :commit "045825c2e1cf0a4fb0a472e72c1dae8f55202cef"
  :revdesc "045825c2e1cf"
  :keywords '("unix")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com")
             ("Travis B. Hartwell" . "nafai@travishartwell.net"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")
                 ("Travis B. Hartwell" . "nafai@travishartwell.net")))
