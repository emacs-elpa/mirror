;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "1.5.0.0.20260619.66"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://www.github.com/DogLooksGood/meow"
  :commit "96648fa6398222e1376422d01f5249afa2a25680"
  :revdesc "96648fa63982"
  :keywords '("convenience" "modal-editing"))
