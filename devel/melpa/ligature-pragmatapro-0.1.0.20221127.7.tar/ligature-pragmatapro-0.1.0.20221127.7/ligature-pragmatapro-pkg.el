;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ligature-pragmatapro" "0.1.0.20221127.7"
  "PragmataPro support for ligature.el."
  '((emacs    "28")
    (ligature "1.0"))
  :url "https://gitlab.com/wavexx/ligature-pragmatapro.el"
  :commit "85f7b15a5cf5f2ee843bc0469e03602a0251c275"
  :revdesc "85f7b15a5cf5"
  :keywords '("faces" "fonts" "ligatures" "programming-ligatures")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
