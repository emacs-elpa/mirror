;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eprolog" "0.3.2"
  "Native Prolog engine implementation."
  '((emacs "27.2"))
  :url "https://github.com/tani/eprolog"
  :commit "6eff9942d3de603109101f3d74e30aac495203f6"
  :revdesc "v0.3.2-0-g6eff9942d3de"
  :keywords '("languages" "prolog" "logic programming"))
