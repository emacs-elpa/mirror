;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-tutor-ja" "0.1.0.20160917.10"
  "Japanese Vimtutor adapted to Evil and wrapped in a major-mode."
  '((evil       "1.0.9")
    (evil-tutor "0.1"))
  :url "https://github.com/kenjimyzk/evil-tutor-ja"
  :commit "06b9ad853a15ce6f2c53c2cf379b9ff358369f2d"
  :revdesc "06b9ad853a15"
  :keywords '("convenience" "editing" "evil" "japanese")
  :authors '(("Kenji Miyazaki" . "kenjizmyzk@gmail.com"))
  :maintainers '(("Kenji Miyazaki" . "kenjizmyzk@gmail.com")))
