;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-math-input" "0.1.0.20260601.21"
  "Insert Unicode math symbols using TeX notation."
  '((emacs "28.1"))
  :url "https://codeberg.org/astoff/unicode-math-input.el"
  :commit "f0ad9e4bf23df653bc68d578e610a2d0431b87df"
  :revdesc "f0ad9e4bf23d")
