;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-msg" "1.1.1.0.20250218.5"
  "Show commit information of current line."
  '((emacs "24.4")
    (popup "0.5.0"))
  :url "https://github.com/redguardtoo/vc-msg"
  :commit "d55a128616a876936f085e5af486924062e57d66"
  :revdesc "d55a128616a8"
  :keywords '("git" "vc" "svn" "hg" "messenger")
  :authors '(("Chen Bin" . "chenbinDOTshATgmailDOTcom"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmailDOTcom")))
