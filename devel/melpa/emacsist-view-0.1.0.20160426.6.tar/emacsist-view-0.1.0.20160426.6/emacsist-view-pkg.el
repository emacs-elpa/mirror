;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsist-view" "0.1.0.20160426.6"
  "Mode for viewing emacsist.com."
  ()
  :url "https://github.com/lujun9972/emacsist-view"
  :commit "f67761259ed779a9bc95c9a4e0474522990c5c6b"
  :revdesc "f67761259ed7"
  :keywords '("convenience" "usability")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
