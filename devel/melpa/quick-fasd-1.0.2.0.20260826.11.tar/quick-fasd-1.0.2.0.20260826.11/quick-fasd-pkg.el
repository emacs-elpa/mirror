;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "1.0.2.0.20260826.11"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "f849c8ae8c2e6166a279dd65e159c59f2b8257ce"
  :revdesc "1.0.2-11-gf849c8ae8c2e"
  :keywords '("convenience" "files" "tools"))
