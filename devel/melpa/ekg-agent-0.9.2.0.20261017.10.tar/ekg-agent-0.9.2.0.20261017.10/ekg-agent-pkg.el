;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "0.9.2.0.20261017.10"
  "Agentic actions for ekg."
  '((emacs "28.1")
    (ekg   "0.10.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "0efa71af9ccdf06d0e4e118c43c2708b5393c150"
  :revdesc "0efa71af9ccd"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
