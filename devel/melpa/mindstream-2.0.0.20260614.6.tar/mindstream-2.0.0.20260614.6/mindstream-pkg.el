;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mindstream" "2.0.0.20260614.6"
  "Start writing, stay focused, don't worry."
  '((emacs "28.1"))
  :url "https://github.com/countvajhula/mindstream"
  :commit "0b7a2889e8de419d90a3eaa137c82febe014fda6"
  :revdesc "v2.0-6-g0b7a2889e8de"
  :keywords '("convenience" "files" "languages" "outlines" "tools" "vc" "wp")
  :authors '(("Siddhartha Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Siddhartha Kasivajhula" . "sid@countvajhula.com")))
