;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-grep" "1.0.0.20200920.3"
  "Search tools using git grep."
  '((projectile "0.10.0"))
  :url "https://github.com/tychoish/git-grep.el"
  :commit "12ff6045e9b6aa42f98abd4ddc44d670268a0849"
  :revdesc "12ff6045e9b6"
  :keywords '("matching" "files" "grep" "search" "using" "git-grep")
  :maintainers '(("tychoish" . "garen@tychoish.com")))
