;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-attr" "1.0.0"
  "Git attributes of buffer file."
  '((emacs "24.3"))
  :url "https://github.com/arnested/emacs-git-attr"
  :commit "3e43a0cf616b00a4bbd3c6b49fd2397f3103796f"
  :revdesc "1.0.0-0-g3e43a0cf616b"
  :keywords '("vc")
  :authors '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainers '(("Arne Jørgensen" . "arne@arnested.dk")))
