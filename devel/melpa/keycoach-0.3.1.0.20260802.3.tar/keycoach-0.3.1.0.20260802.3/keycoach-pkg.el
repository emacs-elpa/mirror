;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keycoach" "0.3.1.0.20260802.3"
  "Remember and learn new keybindings."
  '((emacs "25.1"))
  :url "https://github.com/mrcnski/keycoach"
  :commit "8cdb38ebca3a69e3ea6658325fb252b846cb6da2"
  :revdesc "8cdb38ebca3a"
  :keywords '("help")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
