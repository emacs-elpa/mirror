;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "golint" "0.0.0.20180221.154"
  "Lint for the Go source code."
  ()
  :url "https://github.com/golang/lint"
  :commit "0562613f16a6ec439a4a68e817e69e0f7c405c87"
  :revdesc "0562613f16a6")
