;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chronometrist" "0.10.0.0.20240807.105"
  "Friendly and powerful personal time tracker and analyzer."
  '((emacs "27.1")
    (dash  "2.16.0")
    (seq   "2.20")
    (ts    "0.2"))
  :url "https://codeberg.org/contrapunctus/chronometrist"
  :commit "fdeeba0c0f23cd0ebfa76d5ec2bf4e5e93f87941"
  :revdesc "fdeeba0c0f23"
  :keywords '("calendar")
  :authors '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainers '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de")))
