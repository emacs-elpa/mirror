;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "4.0.7.0.20260729.39"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "e43f14e25fd5d681c8e0a558f7c5fa73fd931915"
  :revdesc "v4.0.7-39-ge43f14e25fd5"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
