;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difftastic" "1.0.0.0.20261007.10"
  "Wrapper for difftastic."
  '((emacs     "28.1")
    (compat    "29.1.4.2")
    (magit     "4.0.0")
    (transient "0.4.0"))
  :url "https://github.com/pkryger/difftastic.el"
  :commit "2af7e5ee04a3da35ca77c53bc85859f61e8a282c"
  :revdesc "v1.0.0-10-g2af7e5ee04a3"
  :keywords '("tools" "diff")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
