;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex-plus" "1.1.0.0.20260918.2"
  "Grammar and spell checking for LaTeX, Markdown, Org and more."
  '((emacs "29.1"))
  :url "https://github.com/ltex-plus/emacs-ltex-plus"
  :commit "ab94bdf86568c75dee22dd4b2af7b19361ad8549"
  :revdesc "v1.1.0-2-gab94bdf86568"
  :keywords '("lsp" "grammar" "spelling" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
