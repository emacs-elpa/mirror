;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-relative-date" "0.3.2"
  "Live relative-date overlays on org timestamps."
  '((emacs "27.1")
    (org   "9.1"))
  :url "https://github.com/RobertPlant/org-relative-date"
  :commit "3ef9c94299145beeb49dc8f869d518e489701a36"
  :revdesc "3ef9c9429914"
  :keywords '("calendar" "org" "convenience")
  :authors '(("Rob Plant" . "rob@robertplant.io"))
  :maintainers '(("Rob Plant" . "rob@robertplant.io")))
