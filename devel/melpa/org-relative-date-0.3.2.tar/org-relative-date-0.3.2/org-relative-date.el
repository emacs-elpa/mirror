;;; org-relative-date.el --- Live relative-date overlays on org timestamps  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Rob Plant

;; Author: Rob Plant <rob@robertplant.io>
;; Assisted-by: Claude:claude-opus-4-8
;; Maintainer: Rob Plant <rob@robertplant.io>
;; Package-Version: 0.3.2
;; Package-Revision: 3ef9c9429914
;; Package-Requires: ((emacs "27.1") (org "9.1"))
;; Keywords: calendar, org, convenience
;; URL: https://github.com/RobertPlant/org-relative-date

;; This file is not part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; `org-relative-date-mode' paints a live "(N days away)" / "(N days ago)"
;; annotation *after* every Org timestamp in the buffer, without modifying the
;; file.  It is the spiritual successor to `time-uuid-mode': rather than
;; replacing text via a `display' property, it appends an `after-string' overlay,
;; so the raw `<2027-01-09 Sat .+6m>' stays visible and editable.
;;
;; Overlays are painted lazily through `jit-lock' (only the visible region is
;; scanned, so large agenda/journal files stay responsive), and a timer
;; repaints them when the date changes so the counts do not go stale.
;;
;; Usage:
;;
;;   (add-hook 'org-mode-hook #'org-relative-date-mode)
;;
;; or turn it on everywhere with `global-org-relative-date-mode'.

;;; Code:

(require 'org)

(defgroup org-relative-date nil
  "Live relative-date overlays on Org timestamps."
  :group 'org
  :prefix "org-relative-date-")

(defun org-relative-date--set-option (symbol value)
  "Set SYMBOL to VALUE, then repaint so open buffers reflect the change.
Paired with `custom-initialize-default' on each option, so this runs only
on a real user change and never during load, when nothing is painted yet."
  (set-default symbol value)
  (org-relative-date--refresh-all))

(defcustom org-relative-date-include-inactive t
  "When non-nil, annotate inactive [timestamps] as well as active <ones>.
Inactive timestamps include CLOSED: markers and logbook entries."
  :type 'boolean
  :initialize #'custom-initialize-default
  :set #'org-relative-date--set-option
  :group 'org-relative-date)

(defcustom org-relative-date-formatter #'org-relative-date-format-days
  "Function mapping a day delta (integer) to the overlay string.
Positive means in the future, negative means in the past, 0 is today.
The returned string is shown verbatim after the timestamp, so include
any desired leading space."
  :type 'function
  :initialize #'custom-initialize-default
  :set #'org-relative-date--set-option
  :group 'org-relative-date)

(defcustom org-relative-date-extra-format nil
  "When non-nil, a `format-time-string' spec appended after the label.
Applied to the timestamp's own date, so it reads fields *of that
timestamp* rather than of today: \" W%V\" appends the ISO week number,
\" (day %j)\" the day of the year.  Include any leading space.

Nil, the default, appends nothing.  This is independent of
`org-relative-date-formatter', so a custom formatter keeps it."
  :type '(choice (const :tag "Nothing" nil)
                 (string :tag "format-time-string spec"))
  :initialize #'custom-initialize-default
  :set #'org-relative-date--set-option
  :group 'org-relative-date)

(defface org-relative-date-face
  '((((background dark))  :foreground "#c5cdd9" :slant italic)
    (((background light)) :foreground "#4c4c4c" :slant italic)
    (t                    :inherit font-lock-comment-face :slant italic))
  "Face for the relative-date overlay text.
Brighter than a plain comment so the annotation is easy to scan, while
staying italic to mark it as non-buffer text.  The foreground adapts to
light and dark backgrounds; override this face to taste."
  :group 'org-relative-date)

(defvar org-relative-date--timer nil
  "Shared timer that repaints overlays when the date changes.")

(defvar org-relative-date--painted-day nil
  "The `org-today' the timer last saw, so it repaints only on a change.")

(defun org-relative-date-format-days (days)
  "Return the default label for DAYS from today (e.g. -1 -> \" yesterday\")."
  (cond ((=  days  0) " today")
        ((=  days  1) " tomorrow")
        ((= days -1) " yesterday")
        ((>  days  0) (format " %dd away" days))
        (t            (format " %dd ago" (- days)))))

(define-obsolete-function-alias 'org-relative-date-default-formatter
  #'org-relative-date-format-days "0.3.2")

(defun org-relative-date--count-days (inside)
  "Return whole-day delta from today for INSIDE, the text between brackets.
INSIDE looks like \"2027-01-09 Sat .+6m\"; only the date head is used.
Uses absolute Gregorian day numbers so the count is immune to DST and
timezone drift."
  (- (org-time-string-to-absolute (car (split-string inside)))
     (org-today)))

(defun org-relative-date--remove-overlays (beg end)
  "Delete this mode's overlays between BEG and END."
  (dolist (overlay (overlays-in beg end))
    (when (overlay-get overlay 'org-relative-date) (delete-overlay overlay))))

(defun org-relative-date--format-label (inside)
  "Return the overlay text for the timestamp whose bracketed text is INSIDE."
  (propertize
   ;; `concat' drops the nil when no extra format is set.
   (concat (funcall org-relative-date-formatter
                    (org-relative-date--count-days inside))
           (and org-relative-date-extra-format
                (format-time-string org-relative-date-extra-format
                                    (org-time-string-to-time inside))))
   'face 'org-relative-date-face))

(defun org-relative-date--annotate-region (beg end)
  "`jit-lock' worker: (re)annotate every timestamp between BEG and END."
  (let ((regexp (if org-relative-date-include-inactive
                    org-ts-regexp-both
                  org-ts-regexp)))
    (save-excursion
      (goto-char beg)
      ;; Pad both ends: `overlays-in' omits empty overlays sitting exactly at
      ;; END (unless END is `point-max'), so an unpadded clear would leave one
      ;; behind and this pass would add a second, duplicating the label.
      (org-relative-date--remove-overlays (line-beginning-position)
                                          (min (point-max) (1+ end)))
      (while (re-search-forward regexp end t)
        ;; read the match before the label: a user formatter is free to run
        ;; its own searches and clobber the match data
        (let* ((inside (match-string 1))
               (stamp-end (match-end 0))
               (label (org-relative-date--format-label inside))
               (overlay (make-overlay stamp-end stamp-end)))
          (overlay-put overlay 'org-relative-date t)
          (overlay-put overlay 'after-string label))))))

(defun org-relative-date--refresh-on-new-day ()
  "Repaint every buffer if the date has changed since the last tick.
Polled rather than scheduled for midnight: a repeating timer counts
seconds, so one set for 00:01 drifts an hour at every DST change.
Polling also follows `org-extend-today-until' and waking from suspend."
  (let ((today (org-today)))
    (unless (eql today org-relative-date--painted-day)
      (setq org-relative-date--painted-day today)
      (org-relative-date--refresh-all))))

(defun org-relative-date--active-anywhere-p ()
  "Return non-nil if any live buffer still has the mode enabled."
  (catch 'found
    (dolist (buffer (buffer-list))
      (when (buffer-local-value 'org-relative-date-mode buffer)
        (throw 'found t)))))

(defun org-relative-date--stop-timer-maybe ()
  "Cancel the shared daily timer once no buffer needs it."
  (when (and org-relative-date--timer
             (not (org-relative-date--active-anywhere-p)))
    (cancel-timer org-relative-date--timer)
    (setq org-relative-date--timer nil)))

(defun org-relative-date--refresh-all ()
  "Re-run overlays in every buffer where the mode is active."
  (dolist (buffer (buffer-list))
    (with-current-buffer buffer
      (when (bound-and-true-p org-relative-date-mode)
        (jit-lock-refontify)))))

;;;###autoload
(define-minor-mode org-relative-date-mode
  "Show a live \"(N days away)\" overlay after every Org timestamp."
  :lighter " RelDate"
  (if org-relative-date-mode
      (progn
        (jit-lock-register #'org-relative-date--annotate-region)
        (unless org-relative-date--timer
          (setq org-relative-date--painted-day (org-today)
                org-relative-date--timer
                (run-at-time 60 60 #'org-relative-date--refresh-on-new-day))))
    (jit-lock-unregister #'org-relative-date--annotate-region)
    ;; Widen first: overlays outside a narrowing (e.g. `org-narrow-to-subtree')
    ;; would otherwise survive with nothing left to clean them up.
    (save-restriction
      (widen)
      (org-relative-date--remove-overlays (point-min) (point-max)))
    (org-relative-date--stop-timer-maybe)))

(defun org-relative-date--turn-on ()
  "Enable `org-relative-date-mode' in Org buffers only.
Buffer-predicate for `global-org-relative-date-mode', which would
otherwise try to switch the mode on in every buffer."
  (when (derived-mode-p 'org-mode)
    (org-relative-date-mode 1)))

;;;###autoload
(define-globalized-minor-mode global-org-relative-date-mode
  org-relative-date-mode org-relative-date--turn-on
  :group 'org-relative-date)

(provide 'org-relative-date)
;;; org-relative-date.el ends here
