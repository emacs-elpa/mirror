;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.7.0.0.20260802.24"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "3246e673deea8590b4e65c1e3b388c81b6e1bd56"
  :revdesc "3246e673deea"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
