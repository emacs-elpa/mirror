;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xml-quotes" "1.3.0.20200301.1"
  "Read quotations from an XML document."
  ()
  :url "https://github.com/ndw/xml-quotes"
  :commit "8fc21e43b45f9a50b24642412f05afcc3a316a1f"
  :revdesc "8fc21e43b45f"
  :keywords '("xml" "quotations")
  :authors '(("Norman Walsh" . "ndw@nwalsh.com"))
  :maintainers '(("Norman Walsh" . "ndw@nwalsh.com")))
