;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-minutes" "0.1.0.20180202.5"
  "Plain text backend for Org for Meeting Minutes."
  '((emacs "24.4"))
  :url "https://github.com/kaushalmodi/ox-minutes"
  :commit "27c29f3fdb9181322ae56f8bace8d95e621230e5"
  :revdesc "27c29f3fdb91"
  :keywords '("org" "exporter" "notes")
  :authors '(("Kaushal Modi" . "kaushal.modi@gmail.com"))
  :maintainers '(("Kaushal Modi" . "kaushal.modi@gmail.com")))
