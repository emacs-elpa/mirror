;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "baff" "1.0.0.20200824.22"
  "Create a byte array from a file."
  '((emacs "24.3")
    (f     "0.20.0"))
  :url "https://github.com/dave-f/baff/"
  :commit "52a8508e2300ee810ce7806cb78a2b294f2630f2"
  :revdesc "52a8508e2300"
  :keywords '("convenience" "usability")
  :authors '(("Dave Footitt" . "dave.footitt@gmail.com"))
  :maintainers '(("Dave Footitt" . "dave.footitt@gmail.com")))
