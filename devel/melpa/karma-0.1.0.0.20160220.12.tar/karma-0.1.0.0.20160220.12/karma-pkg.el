;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "karma" "0.1.0.0.20160220.12"
  "Karma Test Runner Emacs Integration."
  '((pkg-info "0.4")
    (emacs    "24"))
  :url "https://github.com/tonini/karma.el"
  :commit "31d3e7708246183d7ed0686be92bf23140af348c"
  :revdesc "31d3e7708246"
  :keywords '("language" "javascript" "js" "karma" "testing"))
