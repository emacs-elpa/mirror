;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "attrap" "1.2.0.20260304.1"
  "ATtempt To Repair At Point."
  '((dash  "2.12.0")
    (emacs "25.1")
    (f     "0.19.0")
    (s     "1.11.0"))
  :url "https://github.com/jyp/attrap"
  :commit "ad1d9443fcd93e32f2aefadc5af2646701664581"
  :revdesc "ad1d9443fcd9"
  :keywords '("programming" "tools")
  :authors '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com"))
  :maintainers '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com")))
