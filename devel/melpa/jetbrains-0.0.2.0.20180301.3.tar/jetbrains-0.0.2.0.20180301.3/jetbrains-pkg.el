;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jetbrains" "0.0.2.0.20180301.3"
  "JetBrains IDE bridge."
  '((emacs  "24.3")
    (cl-lib "0.5")
    (f      "0.17"))
  :url "https://github.com/emacs-php/jetbrains.el"
  :commit "56f71a17d455581c10d48f6dbb31d9e2126227bf"
  :revdesc "56f71a17d455"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
