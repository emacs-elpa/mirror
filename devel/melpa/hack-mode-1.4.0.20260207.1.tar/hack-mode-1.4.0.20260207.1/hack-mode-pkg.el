;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hack-mode" "1.4.0.20260207.1"
  "Major mode for the Hack programming language."
  '((emacs "25.1")
    (s     "1.11.0"))
  :url "https://github.com/hhvm/hack-mode"
  :commit "0b117e7f259439e7b5d961ec936d8718a727c13a"
  :revdesc "0b117e7f2594"
  :authors '(("John Allen" . "jallen@fb.com")
             ("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("John Allen" . "jallen@fb.com")
                 ("Wilfred Hughes" . "me@wilfred.me.uk")))
