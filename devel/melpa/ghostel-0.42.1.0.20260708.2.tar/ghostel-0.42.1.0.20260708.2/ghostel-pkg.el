;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.42.1.0.20260708.2"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "bc0de0b14cf54898ebceecaf36fc81692526d9d0"
  :revdesc "bc0de0b14cf5"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
