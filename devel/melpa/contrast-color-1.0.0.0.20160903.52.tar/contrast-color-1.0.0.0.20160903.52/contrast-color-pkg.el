;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "contrast-color" "1.0.0.0.20160903.52"
  "Pick best contrast color for you."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/yuutayamada/contrast-color-el"
  :commit "6ff1b807e09ef6a775e4ab1032bb2ea3fc442d9e"
  :revdesc "6ff1b807e09e"
  :keywords '("color" "convenience")
  :authors '(("Yuta Yamada" . "cokesboy[at]gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy[at]gmail.com")))
