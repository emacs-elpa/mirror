;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elysium" "0.0.1.0.20250406.22"
  "Automatically apply LLM-created code-suggestions."
  '((emacs "27.1")
    (gptel "0.9.0"))
  :url "https://github.com/lanceberge/elysium/"
  :commit "049ad3091baf3ce578791187c5e5e4f932c26044"
  :revdesc "049ad3091baf"
  :authors '(("Lance Bergeron" . "bergeron.lance6@gmail.com"))
  :maintainers '(("Lance Bergeron" . "bergeron.lance6@gmail.com")))
