;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "omtose-phellack-themes" "0.2.0.0.20240928.1"
  "Two dark themes, with cold blusish touch."
  '((emacs "24"))
  :url "http:/github.com/franksn/omtose-darker/"
  :commit "b96905deb9b2bef097e0c573100874812c1e9aa8"
  :revdesc "b96905deb9b2")
