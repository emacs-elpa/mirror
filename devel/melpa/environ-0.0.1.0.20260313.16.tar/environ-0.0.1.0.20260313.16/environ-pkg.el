;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "environ" "0.0.1.0.20260313.16"
  "API for environment variables and env files."
  '((emacs "24.1")
    (dash  "2.17.0")
    (f     "0.20.0")
    (s     "1.12.0"))
  :url "https://github.com/cfclrk/environ"
  :commit "697878b084b74401ba8183f5272cd464d3647ee6"
  :revdesc "697878b084b7"
  :keywords '("tools")
  :authors '(("Chris Clark" . "cfclrk@gmail.com"))
  :maintainers '(("Chris Clark" . "cfclrk@gmail.com")))
