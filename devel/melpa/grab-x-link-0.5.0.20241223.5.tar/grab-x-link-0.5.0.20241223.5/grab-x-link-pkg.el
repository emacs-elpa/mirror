;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grab-x-link" "0.5.0.20241223.5"
  "Grab links from X11 apps and insert into Emacs."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/xuchunyang/grab-x-link"
  :commit "4aecb0f360320e0a58b4b142d247b1e628612574"
  :revdesc "4aecb0f36032"
  :keywords '("hyperlink")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
