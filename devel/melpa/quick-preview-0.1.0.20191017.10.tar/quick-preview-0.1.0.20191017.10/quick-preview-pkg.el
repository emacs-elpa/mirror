;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-preview" "0.1.0.20191017.10"
  "Quick preview using GNOME sushi, gloobus or quick look."
  ()
  :url "https://github.com/myuhe/quick-preview.el"
  :commit "a312ab5539b9a362da9d305e4da814e17c5721c9"
  :revdesc "a312ab5539b9"
  :keywords '("files" "hypermedia")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
