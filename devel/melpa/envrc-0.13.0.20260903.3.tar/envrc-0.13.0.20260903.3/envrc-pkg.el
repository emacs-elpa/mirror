;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "0.13.0.20260903.3"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "e3a4d98a483c3a7804747334c82290c30a20cd7b"
  :revdesc "e3a4d98a483c"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
