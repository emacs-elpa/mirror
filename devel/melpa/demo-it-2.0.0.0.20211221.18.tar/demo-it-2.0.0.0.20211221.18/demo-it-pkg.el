;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "demo-it" "2.0.0.0.20211221.18"
  "Create demonstrations."
  ()
  :url "https://github.com/howardabrams/demo-it"
  :commit "8ade739bb2605275f1f56128a0a9a8c6b55bab6a"
  :revdesc "8ade739bb260"
  :keywords '("demonstration" "presentation" "test")
  :authors '(("Howard Abrams" . "howard.abrams@gmail.com"))
  :maintainers '(("Howard Abrams" . "howard.abrams@gmail.com")))
