;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hippie-namespace" "0.5.8.0.20140508.2"
  "Special treatment for namespace prefixes in hippie-expand."
  ()
  :url "https://github.com/rolandwalker/hippie-namespace"
  :commit "107d927634032062483e83c6de9b7698b64809d1"
  :revdesc "v0.5.8-2-g107d92763403"
  :keywords '("convenience" "lisp" "tools" "completion")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
