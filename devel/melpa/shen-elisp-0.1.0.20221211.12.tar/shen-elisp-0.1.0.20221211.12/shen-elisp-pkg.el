;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shen-elisp" "0.1.0.20221211.12"
  "An implementation of the Shen programming language."
  ()
  :url "https://github.com/deech/shen-elisp"
  :commit "957ab44654fc7a7cc1b78181d244fa25166f9b09"
  :revdesc "957ab44654fc"
  :authors '(("Aditya Siram" . "aditya.siram@gmail.com"))
  :maintainers '(("Aditya Siram" . "aditya.siram@gmail.com")))
