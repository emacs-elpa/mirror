;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "4.0.7.0.20260808.43"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "a985db48bd3f5d4d365bb547b91bfe2ea5d3e85e"
  :revdesc "v4.0.7-43-ga985db48bd3f"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
