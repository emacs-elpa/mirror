;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-grammalecte" "2.5.0.20260615.18"
  "Integrate Grammalecte with Flycheck."
  '((emacs    "29.1")
    (flycheck "32"))
  :url "https://git.umaneti.net/flycheck-grammalecte/"
  :commit "f822e96ef54cc8d0d9ca64ad489b915bc36f6ac0"
  :revdesc "v2.5-18-gf822e96ef54c"
  :keywords '("i18n" "text")
  :authors '(("Guilhem Doulcier" . "guilhem.doulcier@espci.fr")
             ("tienne Pflieger" . "etienne@pflieger.bzh")))
