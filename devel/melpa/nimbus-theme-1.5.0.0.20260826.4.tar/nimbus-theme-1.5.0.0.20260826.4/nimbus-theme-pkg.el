;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nimbus-theme" "1.5.0.0.20260826.4"
  "Nimbus dark theme."
  '((emacs "27.1"))
  :url "https://github.com/mrcnski/nimbus-theme"
  :commit "dc7c6923b1ab589456c14a12bfa49c0791330d66"
  :revdesc "dc7c6923b1ab"
  :keywords '("faces")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
