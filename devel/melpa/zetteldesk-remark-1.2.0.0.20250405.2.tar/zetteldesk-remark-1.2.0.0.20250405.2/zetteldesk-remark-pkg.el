;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zetteldesk-remark" "1.2.0.0.20250405.2"
  "Org-Remark integration for zetteldesk.el."
  '((zetteldesk "1.0")
    (org-remark "1.0")
    (emacs      "27.2"))
  :url "https://github.com/Vidianos-Giannitsis/zetteldesk-remark.el"
  :commit "0196835c5d6df65d46a4f642b716e6901ad0f4c1"
  :revdesc "0196835c5d6d"
  :authors '(("Vidianos Giannitsis" . "vidianosgiannitsis@gmail.com"))
  :maintainers '(("Vidianos Giannitsis" . "vidianosgiannitsis@gmail.com")))
