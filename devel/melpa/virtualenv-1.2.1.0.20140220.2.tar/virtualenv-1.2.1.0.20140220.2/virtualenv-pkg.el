;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "virtualenv" "1.2.1.0.20140220.2"
  "Virtualenv for Python."
  ()
  :url "https://github.com/aculich/virtualenv.el"
  :commit "cc82856b6316d5e78073de717f0d5d1a4ee35fa6"
  :revdesc "cc82856b6316"
  :keywords '("python" "virtualenv")
  :authors '(("Aaron Culich" . "aculich@gmail.com"))
  :maintainers '(("Aaron Culich" . "aculich@gmail.com")))
