;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browse-kill-ring" "2.1.0.0.20260503.3"
  "Interactively insert items from kill-ring."
  ()
  :url "https://github.com/browse-kill-ring/browse-kill-ring"
  :commit "39d65a830b93530c9bd68a7dc14353cbffd1d01f"
  :revdesc "39d65a830b93"
  :keywords '("convenience")
  :authors '(("Colin Walters" . "walters@verbum.org"))
  :maintainers '(("browse-kill-ring" . "browse-kill-ring@tonotdo.com")))
