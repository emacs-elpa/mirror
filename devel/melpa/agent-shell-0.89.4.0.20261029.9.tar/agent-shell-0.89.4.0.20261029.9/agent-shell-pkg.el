;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.89.4.0.20261029.9"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "14be85a5dfa9933c3a2970a83b24daea5c2b1a74"
  :revdesc "14be85a5dfa9")
