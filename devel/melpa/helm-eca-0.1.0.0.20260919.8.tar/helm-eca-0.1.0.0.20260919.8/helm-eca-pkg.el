;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-eca" "0.1.0.0.20260919.8"
  "Helm UI for ECA chats/workspaces."
  '((emacs "28.1")
    (eca   "0.8.1")
    (helm  "3.9.0"))
  :url "https://github.com/PalaceChan/helm-eca"
  :commit "1709548d481319563c101a8177b02ccb8697ea48"
  :revdesc "1709548d4813"
  :keywords '("tools" "convenience")
  :authors '(("PalaceChan" . "PalaceChan@users.noreply.github.com"))
  :maintainers '(("PalaceChan" . "PalaceChan@users.noreply.github.com")))
