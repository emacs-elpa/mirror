;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sticky-shell" "1.0.1.0.20240928.42"
  "Minor mode to keep track of previous prompt in your shell."
  '((emacs "25.1"))
  :url "https://github.com/andyjda/sticky-shell"
  :commit "2aec19f60539faf21f567e89701a8e28492eccd1"
  :revdesc "2aec19f60539"
  :keywords '("processes" "terminals" "tools")
  :authors '(("Andrew De Angelis" . "bobodeangelis@gmail.com"))
  :maintainers '(("Andrew De Angelis" . "bobodeangelis@gmail.com")))
