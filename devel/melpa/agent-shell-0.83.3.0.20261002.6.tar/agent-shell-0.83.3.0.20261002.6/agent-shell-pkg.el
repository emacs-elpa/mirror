;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.83.3.0.20261002.6"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6c91b1fd3d0eaf6c41aadd23e111e37ff737d6b4"
  :revdesc "6c91b1fd3d0e")
