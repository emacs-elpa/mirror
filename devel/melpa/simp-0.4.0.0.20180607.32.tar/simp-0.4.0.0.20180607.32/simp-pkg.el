;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simp" "0.4.0.0.20180607.32"
  "Simple project definition, chiefly for file finding, and grepping."
  ()
  :url "https://github.com/re5et/simp"
  :commit "d4d4b8547055347828bedccbeffdb4fd2d5a5d34"
  :revdesc "d4d4b8547055"
  :keywords '("project" "grep" "find"))
