;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shexc-ts-mode" "20260614.909"
  "Tree-sitter major mode for ShExC."
  '((emacs "29.1"))
  :url "https://github.com/ericprud/shexc-mode-for-emacs"
  :commit "219734ccf6135252b80cab50edf226821914a4c7"
  :revdesc "219734ccf613"
  :keywords '("languages")
  :authors '(("Eric Prud'hommeaux" . "eric@w3.org"))
  :maintainers '(("Eric Prud'hommeaux" . "eric@w3.org")))
