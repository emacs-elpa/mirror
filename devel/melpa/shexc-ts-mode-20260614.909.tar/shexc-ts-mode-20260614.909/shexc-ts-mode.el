;;; shexc-ts-mode.el --- Tree-sitter major mode for ShExC -*- lexical-binding: t; -*-

;; Author: Eric Prud'hommeaux <eric@w3.org>
;; Assisted-by: Claude:claude-sonnet-4-6
;; Package-Version: 20260614.909
;; Package-Revision: 219734ccf613
;; Package-Requires: ((emacs "29.1"))
;; Keywords: languages
;; URL: https://github.com/ericprud/shexc-mode-for-emacs
;; SPDX-License-Identifier: MIT

;;; Commentary:

;; This mode is a tree-sitter based companion to `shexc-mode' (see
;; shexc-mode.el), built on the grammar at
;; https://github.com/ericprud/tree-sitter-shexc
;;
;; It provides:
;; - syntax highlighting (`treesit-font-lock-rules')
;; - structure-aware indentation (`treesit-simple-indent-rules')
;; - line/block commenting (M-; via `comment-dwim')
;; - imenu index of shape declarations
;; - "jump to shape definition" / "find references to shape" via `xref'
;;   (`M-.'/`M-,'/`M-?'), resolving `@<#Shape>', `EXTENDS @<#Shape>',
;;   `&<#Shape>' and `start = @<#Shape>' references to their
;;   `shape_expr_decl'.
;;
;; For documentation on ShExC, see:
;; https://shex.io/shex-semantics/#shexc

;;; Setup:
;;
;; (require 'shexc-ts-mode)
;;
;; ;; tell Emacs where to find the compiled grammar (built with
;; ;; `tree-sitter build -o ~/.emacs.d/tree-sitter/libtree-sitter-shexc.dylib /path/to/tree-sitter-shexc')
;; (add-to-list 'treesit-extra-load-path (expand-file-name "~/.emacs.d/tree-sitter/"))
;;
;; (add-to-list 'auto-mode-alist '("\\.shexc?\\'" . shexc-ts-mode))

;;; Code:

(require 'treesit)
(require 'xref)
(require 'cl-lib)
(require 'pcase)
(require 'hideshow)
(require 'flymake)
(require 'transient)

(declare-function treesit-parser-create "treesit.c")
(declare-function treesit-node-type "treesit.c")
(declare-function treesit-node-text "treesit.c")
(declare-function treesit-node-start "treesit.c")
(declare-function treesit-node-parent "treesit.c")
(declare-function treesit-node-child-by-field-name "treesit.c")
(declare-function treesit-search-forward "treesit.c")

;; defined by `define-derived-mode' below; forward-declared so the
;; feature menu (which closes over it) can refer to it.
(defvar shexc-ts-mode-map)

;; defined by the optional, separate `shex-manifest-browser' package;
;; forward-declared so `shexc-ts-mode-menu' can offer it when present
;; (guarded at both compile and run time by
;; `shexc-ts-mode--manifest-browser-loaded-p').
(defvar shex-manifest-browser-highlight-extended-predicates)

(defgroup shexc-ts nil
  "Major mode for editing ShExC documents with tree-sitter."
  :group 'languages)

(defcustom shexc-ts-mode-indent-offset 2
  "Number of columns for each indentation step in `shexc-ts-mode'."
  :type 'integer
  :safe 'integerp
  :group 'shexc-ts)

;;; Prefix maps
;;
;; A "prefix map" associates short prefixes (as in `PREFIX ex: <...>')
;; with the IRIs they conventionally abbreviate, along with metadata
;; on where that association is authoritatively published.
;; `shexc-ts-mode-insert-prefix' and the "Undefined prefix" flymake
;; diagnostic (`shexc-ts-mode--flymake-undefined-prefixes') consult the
;; active map (`shexc-ts-mode-prefix-map') to propose a `PREFIX'
;; declaration for an undeclared prefix.

(defconst shexc-ts-mode--prefix-map-rdfa
  '(:source "https://www.w3.org/2011/rdfa-context/rdfa-1.1"
    :description
    "W3C RDFa Core 1.1 Initial Context: the default vocabulary prefixes \
recognized by RDFa processors, combining the W3C's own vocabularies \
with other widely-used ones (Dublin Core, FOAF, schema.org, etc.)."
    :prefixes
    (("as" . "https://www.w3.org/ns/activitystreams#")
     ("cc" . "http://creativecommons.org/ns#")
     ("csvw" . "http://www.w3.org/ns/csvw#")
     ("ctag" . "http://commontag.org/ns#")
     ("dc" . "http://purl.org/dc/terms/")
     ("dc11" . "http://purl.org/dc/elements/1.1/")
     ("dcat" . "http://www.w3.org/ns/dcat#")
     ("dcterms" . "http://purl.org/dc/terms/")
     ("dqv" . "http://www.w3.org/ns/dqv#")
     ("duv" . "https://www.w3.org/ns/duv#")
     ("foaf" . "http://xmlns.com/foaf/0.1/")
     ("gr" . "http://purl.org/goodrelations/v1#")
     ("grddl" . "http://www.w3.org/2003/g/data-view#")
     ("ical" . "http://www.w3.org/2002/12/cal/icaltzd#")
     ("jsonld" . "http://www.w3.org/ns/json-ld#")
     ("ldp" . "http://www.w3.org/ns/ldp#")
     ("ma" . "http://www.w3.org/ns/ma-ont#")
     ("oa" . "http://www.w3.org/ns/oa#")
     ("odrl" . "http://www.w3.org/ns/odrl/2/")
     ("og" . "http://ogp.me/ns#")
     ("org" . "http://www.w3.org/ns/org#")
     ("owl" . "http://www.w3.org/2002/07/owl#")
     ("prov" . "http://www.w3.org/ns/prov#")
     ("qb" . "http://purl.org/linked-data/cube#")
     ("rdf" . "http://www.w3.org/1999/02/22-rdf-syntax-ns#")
     ("rdfa" . "http://www.w3.org/ns/rdfa#")
     ("rdfs" . "http://www.w3.org/2000/01/rdf-schema#")
     ("rev" . "http://purl.org/stuff/rev#")
     ("rif" . "http://www.w3.org/2007/rif#")
     ("rr" . "http://www.w3.org/ns/r2rml#")
     ("schema" . "http://schema.org/")
     ("sd" . "http://www.w3.org/ns/sparql-service-description#")
     ("sioc" . "http://rdfs.org/sioc/ns#")
     ("skos" . "http://www.w3.org/2004/02/skos/core#")
     ("skosxl" . "http://www.w3.org/2008/05/skos-xl#")
     ("sosa" . "http://www.w3.org/ns/sosa/")
     ("ssn" . "http://www.w3.org/ns/ssn/")
     ("time" . "http://www.w3.org/2006/time#")
     ("v" . "http://rdf.data-vocabulary.org/#")
     ("vcard" . "http://www.w3.org/2006/vcard/ns#")
     ("void" . "http://rdfs.org/ns/void#")
     ("wdr" . "http://www.w3.org/2007/05/powder#")
     ("wdrs" . "http://www.w3.org/2007/05/powder-s#")
     ("xhv" . "http://www.w3.org/1999/xhtml/vocab#")
     ("xml" . "http://www.w3.org/XML/1998/namespace")
     ("xsd" . "http://www.w3.org/2001/XMLSchema#")))
  "Prefix map transcribed from the W3C RDFa Core 1.1 Initial Context.
See its `:source' for the authoritative, machine-readable (JSON-LD)
list this was transcribed from.")

(defconst shexc-ts-mode--prefix-map-wikidata
  '(:source
    "https://www.mediawiki.org/wiki/Wikibase/Indexing/RDF_Dump_Format"
    :description
    "Wikidata has no single canonical prefix-list page; this combines \
the RDF-dump namespace prefixes documented at its `:source' URL with \
the PREFIX block conventionally used at the top of Wikidata \
EntitySchemas, e.g. https://www.wikidata.org/wiki/EntitySchema:E10."
    :prefixes
    (("bd" . "http://www.bigdata.com/rdf#")
     ("geo" . "http://www.opengis.net/ont/geosparql#")
     ("owl" . "http://www.w3.org/2002/07/owl#")
     ("p" . "http://www.wikidata.org/prop/")
     ("pq" . "http://www.wikidata.org/prop/qualifier/")
     ("pqn" . "http://www.wikidata.org/prop/qualifier/value-normalized/")
     ("pqv" . "http://www.wikidata.org/prop/qualifier/value/")
     ("pr" . "http://www.wikidata.org/prop/reference/")
     ("prn" . "http://www.wikidata.org/prop/reference/value-normalized/")
     ("prov" . "http://www.w3.org/ns/prov#")
     ("prv" . "http://www.wikidata.org/prop/reference/value/")
     ("ps" . "http://www.wikidata.org/prop/statement/")
     ("psn" . "http://www.wikidata.org/prop/statement/value-normalized/")
     ("psv" . "http://www.wikidata.org/prop/statement/value/")
     ("rdf" . "http://www.w3.org/1999/02/22-rdf-syntax-ns#")
     ("rdfs" . "http://www.w3.org/2000/01/rdf-schema#")
     ("schema" . "http://schema.org/")
     ("skos" . "http://www.w3.org/2004/02/skos/core#")
     ("wd" . "http://www.wikidata.org/entity/")
     ("wdata" . "https://www.wikidata.org/wiki/Special:EntityData/")
     ("wdno" . "http://www.wikidata.org/prop/novalue/")
     ("wdref" . "http://www.wikidata.org/reference/")
     ("wds" . "http://www.wikidata.org/entity/statement/")
     ("wdt" . "http://www.wikidata.org/prop/direct/")
     ("wdtn" . "http://www.wikidata.org/prop/direct-normalized/")
     ("wdv" . "http://www.wikidata.org/value/")
     ("wikibase" . "http://wikiba.se/ontology#")
     ("xsd" . "http://www.w3.org/2001/XMLSchema#")))
  "Prefix map for Wikidata's RDF/EntitySchema namespaces.
See `:description' for the (two) sources this was compiled from.")

(defcustom shexc-ts-mode-prefix-maps
  `(("rdfa" . ,shexc-ts-mode--prefix-map-rdfa)
    ("wikidata" . ,shexc-ts-mode--prefix-map-wikidata))
  "Alist of named prefix maps, for `shexc-ts-mode-prefix-map' to select.

Each element is (NAME . PLIST), where NAME is a string (matched
against `shexc-ts-mode-prefix-map') and PLIST has the keys:

  `:source'      URL where the map is authoritatively published, or nil.
  `:description' Free-form text on the map's provenance/contents.
  `:prefixes'    Alist of (PREFIX . IRI) strings, e.g.
                 (\"rdf\" . \"http://www.w3.org/1999/02/22-rdf-syntax-ns#\").

Add your own by appending more (NAME . PLIST) elements, e.g. in your
init file:

  (with-eval-after-load \\='shexc-ts-mode
    (push \\='(\"my-project\"
            :source \"https://example.org/my-prefixes\"
            :description \"Prefixes used across my-project's schemas.\"
            :prefixes ((\"ex\" . \"http://example.org/ns#\")))
          shexc-ts-mode-prefix-maps))"
  :type 'sexp
  :group 'shexc-ts)

(defcustom shexc-ts-mode-prefix-map "rdfa"
  "Name of the active entry in `shexc-ts-mode-prefix-maps'.

`shexc-ts-mode-insert-prefix' and the \"Undefined prefix\" flymake
diagnostic (`shexc-ts-mode--flymake-undefined-prefixes') look up
undeclared prefixes here.  Set this as a file- or directory-local
variable to use a different map in specific buffers, e.g.
\"wikidata\" when editing Wikidata EntitySchemas."
  :type 'string
  :safe #'stringp
  :group 'shexc-ts)

;;; Syntax table

(defvar shexc-ts-mode--syntax-table nil
  "Syntax table for `shexc-ts-mode'.")
;; Use `setq' (not just `defvar') so that `load-file'/`eval-buffer'
;; always rebuilds the table -- `defvar' is a no-op when the variable
;; is already bound.
(setq shexc-ts-mode--syntax-table
  (let ((table (make-syntax-table)))
    ;; block comments: "/* ... */" (style a -- pairs with / and *)
    ;; line comments:  "# ..."    (style b -- pairs with # and \n)
    ;; Two-style setup like C-mode: forward-comment/syntax-ppss handle
    ;; both styles; a style-b `#' inside a style-a `/* */' comment is
    ;; not treated as a comment-start, and vice-versa.
    (modify-syntax-entry ?/ ". 14" table)  ; 1=1st of /**/, 4=2nd of **/
    (modify-syntax-entry ?* ". 23" table)  ; 2=2nd of /**/, 3=1st of **/
    (modify-syntax-entry ?# "< b" table)
    (modify-syntax-entry ?\n "> b" table)
    ;; "." is part of a symbol (e.g. the wildcard shape `.' and PN_LOCAL)
    (modify-syntax-entry ?. "_" table)
    ;; punctuation that shouldn't be picked up by `thing-at-point' 'symbol
    ;; (? + | ^ stay as punctuation; * is already ". 23" above)
    (modify-syntax-entry ?+ "." table)
    (modify-syntax-entry ?? "." table)
    (modify-syntax-entry ?| "." table)
    (modify-syntax-entry ?^ "." table)
    table))

;; `#' both starts a line comment ("# ...") *and* routinely appears
;; inside `irireference's, e.g. the fragment separators in `<#Shape>'
;; or `<http://example.org/onto#Class>' -- ShExC shape labels are
;; conventionally local fragment IRIs like `<#Shape>'. The syntax
;; table can't tell those two roles apart (it would need to mark every
;; `#' as a comment starter, including the ones inside IRIs), which
;; otherwise makes the syntax engine believe a `{'/`}' following
;; `<#Shape>' on the same line is "inside a comment" -- breaking
;; `forward-list'/`up-list'/`backward-up-list' (`C-M-n'/`C-M-u' etc.)
;; and any other syntax-table-based scanning.  `treesit-node-at' can
;; tell them apart directly from the parsed tree (a real comment is a
;; `comment' node; an in-IRI `#' is just part of an `irireference'),
;; so use a `syntax-propertize-function' to neutralize the latter.
(defun shexc-ts-mode--syntax-propertize (beg end)
  "Neutralize non-comment `#' characters between BEG and END.

Give `#' characters that are not `#'-comment starters (e.g. the
fragment separator in `<#Shape>' IRI references) a neutral
`syntax-table' property, so that `forward-list'/`up-list' and
other syntax-based scanning don't mistake them for the start of
a line comment that swallows the rest of that line -- including
any `{'/`}' on it.

A `#' is considered to be inside an IRI (and therefore not a
comment starter) when scanning backward to the beginning of the
line finds an unmatched `<' before any `>'."
  (goto-char beg)
  (while (re-search-forward "#" end t)
    (let ((pos (match-beginning 0)))
      (when (save-excursion
              (let ((bol (line-beginning-position)))
                (and (re-search-backward "<" bol t)
                     (not (re-search-forward ">" pos t)))))
        (with-silent-modifications
          (put-text-property pos (1+ pos)
                             'syntax-table (string-to-syntax "_")))))))

;;; Comments
;;
;; ShExC has both `#'-prefixed line comments and C-style `/* ... */'
;; block comments (the grammar folds both into one `comment' node, so
;; font-lock already handles both -- see the `comment' feature above).
;; `comment-start'/`comment-end' can only describe one style at a
;; time, so -- mirroring `c-ts-mode-toggle-comment-style' -- we let
;; `M-;' default to line comments and provide a command to switch to
;; block comments for languages/regions where they read better (e.g.
;; commenting out a multi-line chunk of a schema).

(defun shexc-ts-mode-comment-dwim (arg)
  "Comment or uncomment the current line or region.
See `comment-dwim' for the meaning of ARG."
  (interactive "*P")
  (require 'newcomment)
  (let ((deactivate-mark nil))
    (comment-dwim arg)))

(defun shexc-ts-mode-toggle-comment-style (&optional arg)
  "Toggle the comment style between line (`#') and block (`/* */').
Optional numeric ARG, if supplied, switches to block comment
style when positive, to line comment style when negative, and
just toggles it when zero or omitted.  This only affects newly
inserted comments (via `comment-dwim'/`comment-region'/`M-;').

Note that `uncomment-region' looks for the *current* style's
delimiters first: in line-comment style it will not recognize
\(and so cannot strip) a pre-existing `/* ... */' comment, while
in block-comment style it can still strip a pre-existing `#'
comment (because `comment-start-skip' always matches both
styles, and a bare `#' has nothing further to match once its
prefix is removed).  Toggle to the matching style first if you
need to remove a comment written in the other style."
  (interactive "P")
  (let ((prevstate-line (string= comment-start "# ")))
    (when (or (not arg)
              (zerop (setq arg (prefix-numeric-value arg)))
              (xor (> 0 arg) prevstate-line))
      (if prevstate-line
          (progn
            (setq-local comment-start "/* "
                        comment-end   " */")
            ;; Block-comment style: wrap the whole region in one pair
            ;; (`/* ' at the start, ` */' at the end) rather than
            ;; bracketing each line individually.  `comment-style
            ;; 'multi-line' + empty `comment-continue' achieves this.
            (setq-local comment-style    'multi-line
                        comment-continue ""))
        (setq-local comment-start "# "
                    comment-end   "")
        ;; Line-comment style: back to one delimiter per line.
        (setq-local comment-style    'plain
                    comment-continue nil))
        ;; `comment-use-syntax' is normally derived once (from
        ;; `comment-start' and the syntax table) and cached
        ;; buffer-locally; force it to be re-derived for the new
        ;; style, or `comment-region'/`uncomment-region' may keep
        ;; using stale syntax-based scanning that doesn't recognize
        ;; the style we just switched to (our syntax table only
        ;; marks `#'/`\n', not `/'/`*', as comment delimiters).
        (setq-local comment-use-syntax 'undecided)
      (message "ShExC comment style: %s"
               (if prevstate-line "block (/* ... */)" "line (#)")))))

;;; Font-lock

(defvar shexc-ts-mode--keywords
  '("kw_a" "kw_abstract" "kw_and" "kw_base" "kw_bnode" "kw_closed"
    "kw_extends" "kw_external" "kw_extra" "kw_fractiondigits" "kw_import"
    "kw_iri" "kw_length" "kw_literal" "kw_maxexclusive" "kw_maxinclusive"
    "kw_maxlength" "kw_minexclusive" "kw_mininclusive" "kw_minlength"
    "kw_nonliteral" "kw_not" "kw_or" "kw_prefix" "kw_restricts" "kw_start"
    "kw_totaldigits")
  "ShExC keyword node types (excluding ones aliased from punctuation).")

(defun shexc-ts-mode--keyword-alternatives ()
  "Build the `[(kw_a) (kw_and) ...]' alternation for the keyword query."
  (apply #'vector (mapcar (lambda (kw) (list (intern kw)))
                          shexc-ts-mode--keywords)))

(defvar shexc-ts-mode--font-lock-settings
  (treesit-font-lock-rules
   :language 'shexc
   :feature 'comment
   '((comment) @font-lock-comment-face)

   :language 'shexc
   :feature 'string
   '([(string) (lang_string) (langtag)] @font-lock-string-face)

   :language 'shexc
   :feature 'keyword
   `([,@(shexc-ts-mode--keyword-alternatives) (shape_any)] @font-lock-keyword-face)

   :language 'shexc
   :feature 'definition
   ;; NOTE: `group_triple_expr's `$<label>' is matched without an `id:'
   ;; field constraint -- tree-sitter's query compiler rejects `id:' on
   ;; `group_triple_expr' with a "Structure error" even though the field
   ;; is present on real parse-tree nodes (the field is assigned inside
   ;; the hidden `_unary_triple_expr' rule it's inlined from, and isn't
   ;; registered in the language's static field table). Matching the
   ;; bare child type works and is unambiguous: a `triple_expr_label'
   ;; appearing directly under `group_triple_expr' can only be its `$id',
   ;; never the `&label' of a nested `include' (which is one level deeper).
   :override t
   '((shape_expr_decl label: (shape_expr_label) @font-lock-function-name-face)
     (group_triple_expr (triple_expr_label) @font-lock-function-name-face)
     (include label: (triple_expr_label) @font-lock-function-name-face))

   :language 'shexc
   :feature 'reference
   :override t
   '((shape_ref label: (shape_expr_label) @font-lock-variable-name-face))

   ;; A bare IRI/prefixed-name directly inside a `node_constraint' can only
   ;; be its `datatype' (NodeKind/value-set/numeric-facet constraints never
   ;; carry one as a direct child) -- no need to climb to the `datatype:'
   ;; field on the enclosing `(inline_)shape_atom'.
   :language 'shexc
   :feature 'type
   :override t
   '((prefix_decl name: (_) @font-lock-type-face)
     (node_constraint [(irireference) (prefixed_name)] @font-lock-type-face))

   :language 'shexc
   :feature 'property
   :override t
   '((triple_constraint predicate: (predicate) @font-lock-property-name-face)
     (annotation predicate: (_) @font-lock-property-name-face))

   :language 'shexc
   :feature 'constant
   '([(boolean_literal) (kw_true) (kw_false)
      (irireference) (prefixed_name) (blank_node)] @font-lock-constant-face)

   :language 'shexc
   :feature 'number
   '([(integer) (decimal) (double)] @font-lock-number-face)

   :language 'shexc
   :feature 'preprocessor
   :override t
   '((code_decl name: (_) @font-lock-preprocessor-face)
     (code) @font-lock-preprocessor-face)

   :language 'shexc
   :feature 'bracket
   '((["{" "}" "[" "]" "(" ")"]) @font-lock-bracket-face)

   :language 'shexc
   :feature 'operator
   '((["." "|" "&" "@" "^" "~" "-" "="]) @font-lock-operator-face
     ([(card_star) (card_plus) (card_opt) (kw_inverse)]) @font-lock-operator-face)

   :language 'shexc
   :feature 'delimiter
   '((["," ";"]) @font-lock-delimiter-face))
  "Tree-sitter font-lock settings for `shexc-ts-mode'.")

(defvar shexc-ts-mode--font-lock-feature-list
  '((comment definition)
    (keyword string)
    (constant number preprocessor property reference type)
    (bracket delimiter operator))
  "`treesit-font-lock-feature-list' for `shexc-ts-mode'.

Levels 1-3 (the default `treesit-font-lock-level') cover everything
but raw punctuation; level 4 additionally highlights brackets,
separators and operators.")

;;; Indentation

(defvar shexc-ts-mode--indent-rules
  `((shexc
     ;; closing delimiters line up with the line that opened the block
     ((node-is "}") parent-bol 0)
     ((node-is ")") parent-bol 0)
     ((node-is "]") parent-bol 0)

     ;; OR/AND continuations ("} OR {", "} AND {") line up with the
     ;; opening brace of their sibling, not indented further
     ((parent-is "shape_or") parent-bol 0)
     ((parent-is "shape_and") parent-bol 0)
     ((parent-is "shape_not") parent-bol 0)
     ((parent-is "inline_shape_or") parent-bol 0)
     ((parent-is "inline_shape_and") parent-bol 0)
     ((parent-is "inline_shape_not") parent-bol 0)

     ;; contents of {...}, (...), [...] indent one step from the line
     ;; that opened the block
     ((parent-is "inline_shape_definition") parent-bol shexc-ts-mode-indent-offset)
     ((parent-is "bracketed_triple_expr") parent-bol shexc-ts-mode-indent-offset)
     ((parent-is "value_set") parent-bol shexc-ts-mode-indent-offset)
     ((parent-is "one_of") parent-bol shexc-ts-mode-indent-offset)
     ((parent-is "shape_expr_decl") parent-bol shexc-ts-mode-indent-offset)

     ;; `group_triple_expr' is a flattening wrapper: it always starts at
     ;; the same position as its first `element', so its elements align
     ;; with it rather than stepping in further (the enclosing block --
     ;; `inline_shape_definition'/`bracketed_triple_expr'/`one_of' --
     ;; already applied the one indentation step for this level)
     ((parent-is "group_triple_expr") parent-bol 0)

     ;; top-level declarations start at column 0
     ((parent-is "shex_doc") column-0 0)

     (catch-all parent-bol 0)))
  "`treesit-simple-indent-rules' for `shexc-ts-mode'.")

;;; Imenu

(defun shexc-ts-mode--imenu-name (node)
  "Return the label text of shape declaration NODE for imenu."
  (let ((label (treesit-node-child-by-field-name node "label")))
    (treesit-node-text (or label node) t)))

(defvar shexc-ts-mode--imenu-settings
  `(("Shape" "\\`shape_expr_decl\\'" nil shexc-ts-mode--imenu-name))
  "`treesit-simple-imenu-settings' for `shexc-ts-mode'.")

;;; Following references (xref)

(defun shexc-ts-mode--label-node-at (pos)
  "Return the smallest `shape_expr_label' node enclosing POS, if any.
This matches both shape declarations (`<#S> { ... }') and shape
references (`@<#S>', `EXTENDS @<#S>', `&<#S>', `start = @<#S>')."
  (let ((node (treesit-node-at pos)))
    (treesit-parent-until
     node
     (lambda (n) (string= (treesit-node-type n) "shape_expr_label"))
     t)))

(defun shexc-ts-mode--label-at-point ()
  "Return the shape-label text at point, or nil."
  (let ((node (shexc-ts-mode--label-node-at (point))))
    (and node (treesit-node-text node t))))

(defun shexc-ts-mode--query-labels (pattern)
  "Return all `shape_expr_label' nodes captured as @label by PATTERN."
  (treesit-query-capture (treesit-buffer-root-node) pattern nil nil t))

(defun shexc-ts-mode--label-line-summary (node)
  "Return a trimmed one-line summary of the source line containing NODE."
  (save-excursion
    (goto-char (treesit-node-start node))
    (string-trim (buffer-substring-no-properties
                  (line-beginning-position) (line-end-position)))))

(defun shexc-ts-mode--xref-make (node)
  "Build an `xref-item' pointing at the shape label NODE."
  (xref-make (shexc-ts-mode--label-line-summary node)
             (xref-make-buffer-location (current-buffer) (treesit-node-start node))))

(defun shexc-ts-mode--matching-xrefs (nodes identifier)
  "Build `xref-item's for the nodes in NODES whose text equals IDENTIFIER."
  (delq nil
        (mapcar (lambda (node)
                  (when (string= (treesit-node-text node t) identifier)
                    (shexc-ts-mode--xref-make node)))
                nodes)))

(defun shexc-ts-mode--all-labels ()
  "Return all shape-label nodes in the buffer (declarations and references)."
  (append
   (shexc-ts-mode--query-labels
    '((shape_expr_decl label: (shape_expr_label) @label)))
   (shexc-ts-mode--query-labels
    '((shape_ref label: (shape_expr_label) @label)))))

(defun shexc-ts-mode--xref-backend ()
  "Return the xref backend symbol for `shexc-ts-mode'."
  'shexc-ts-mode)

(cl-defmethod xref-backend-identifier-at-point ((_backend (eql shexc-ts-mode)))
  "Return the shape label at point, for xref."
  (shexc-ts-mode--label-at-point))

(cl-defmethod xref-backend-identifier-completion-table ((_backend (eql shexc-ts-mode)))
  "Return all shape labels in the buffer, for xref completion."
  (delete-dups (mapcar (lambda (n) (treesit-node-text n t))
                       (shexc-ts-mode--all-labels))))

(cl-defmethod xref-backend-definitions ((_backend (eql shexc-ts-mode)) identifier)
  "Return the `shape_expr_decl' xref defining IDENTIFIER."
  (shexc-ts-mode--matching-xrefs
   (shexc-ts-mode--query-labels
    '((shape_expr_decl label: (shape_expr_label) @label)))
   identifier))

(cl-defmethod xref-backend-references ((_backend (eql shexc-ts-mode)) identifier)
  "Return the `shape_ref' xrefs referencing IDENTIFIER."
  (shexc-ts-mode--matching-xrefs
   (shexc-ts-mode--query-labels
    '((shape_ref label: (shape_expr_label) @label)))
   identifier))

;;; Navigation: structural defun-nav, smart sexp, breadcrumb
;;
;; `treesit-thing-settings' tells `treesit-major-mode-setup' to wire up:
;; - `beginning-of-defun'/`end-of-defun' (`C-M-a'/`C-M-e') to jump
;;   between `shape_expr_decl's -- one "defun" per ShapeDecl.
;; - `forward-sexp'/`backward-sexp' (`C-M-f'/`C-M-b', and anything
;;   built on them, e.g. `transpose-sexps'/`C-M-t', `kill-sexp') to
;;   treat each "branch" of a shape expression -- an EXTENDS clause,
;;   an AND/OR operand, a NOT-negated shape, a `{ ... }' shape body, a
;;   OneOf/EachOf triple-expression group, or a single triple
;;   constraint -- as one sexp.

(defun shexc-ts-mode--ancestor-of-type (node types &optional include-node)
  "Return the closest ancestor of NODE whose type is a member of TYPES.
If INCLUDE-NODE is non-nil, NODE itself is considered first."
  (treesit-parent-until
   node
   (lambda (n) (member (treesit-node-type n) types))
   include-node))

(defconst shexc-ts-mode--sexp-node-types
  '(;; shape declarations and references
    "shape_expr_decl" "shape_ref"
    ;; EXTENDS clauses
    "extension"
    ;; AND / OR / NOT combinations, and their `{ ... }'-body forms
    "shape_or" "inline_shape_or"
    "shape_and" "inline_shape_and"
    "shape_not" "inline_shape_not"
    "shape_atom" "inline_shape_atom"
    "shape_definition" "inline_shape_definition"
    ;; NodeConstraints
    "node_constraint" "value_set"
    ;; triple expressions: OneOf disjuncts, EachOf groups, bracketed
    ;; sub-expressions, and individual triple constraints
    "one_of" "group_triple_expr" "bracketed_triple_expr"
    "triple_constraint" "include")
  "Node types treated as a single `sexp' unit in `shexc-ts-mode'.

Each of these corresponds to a \"branch\" of a ShExC shape
expression or triple expression, so that sexp-based navigation
and editing commands move over a whole branch at a time.")

(defun shexc-ts-mode--current-defun-name ()
  "Return a breadcrumb describing the shape construct at point.

The breadcrumb has the form `<Shape> > predicate > predicate...',
where `<Shape>' is the label of the enclosing `shape_expr_decl' and
each `predicate' is the predicate of an enclosing `triple_constraint'
\(outermost first\), as when a `triple_constraint's value is itself a
`{ ... }' shape containing further `triple_constraint's.  Return nil
outside of any `shape_expr_decl'.

Used as `add-log-current-defun-function', which powers
`which-function-mode' and `add-log-current-defun'."
  (let ((node (treesit-node-at (point)))
        (label nil)
        (predicates nil))
    (while node
      (let ((type (treesit-node-type node)))
        (cond
         ((string= type "triple_constraint")
          (when-let* ((pred (treesit-node-child-by-field-name node "predicate")))
            (push (treesit-node-text pred t) predicates)))
         ((string= type "shape_expr_decl")
          (when-let* ((lbl (treesit-node-child-by-field-name node "label")))
            (setq label (treesit-node-text lbl t))))))
      (setq node (treesit-node-parent node)))
    (when label
      (mapconcat #'identity (cons label predicates) " > "))))

;;; Extended-shape highlighting (API for shex-manifest-browser)
;;
;; Terminology used throughout this section:
;;
;; - `shapeLabel' / `predicate' -- the ShapeDecl label, and the
;;   predicates of its shapeExpression, of the *focal*
;;   `shape_expr_decl', i.e. the one containing point.
;; - `reachable-shapeLabel' / `reachable-predicate' -- the label, and
;;   the predicates, of any *other* shape transitively reachable from
;;   the focal shape's shapeExpression via a sole shape reference
;;   (e.g. `<Contact1> @<Contact>'), AND, OR, NOT, or EXTENDS.  E.g. in
;;   `<S> { <p1> . } AND @<S2>' / `<S2> { <p2> . }', `<S2>' is a
;;   `reachable-shapeLabel' and `<p2>' a `reachable-predicate'.
;; - `not-'/`optional-' prefix on a `reachable-*' term -- the shape is
;;   reachable only inside a NOT (`not-reachable-*'), or via only some
;;   branch(es) of an OR (`optional-reachable-*').  Reachable via AND,
;;   EXTENDS, or as a sole reference gets neither prefix; see
;;   `shexc-ts-mode--strength-required'/`-negated'/`-optional' below.
;; - `extended-' prefix on any `reachable-*' term (with or without the
;;   above) -- the path from the focal shape to it passes through an
;;   EXTENDS edge somewhere along the way.  E.g. if `<Person> EXTENDS
;;   @<Tools>' and `<Tools> { ex:tool @<TBoss> }', then with point in
;;   `<Person>': `<Tools>' and `<TBoss>' are both
;;   `extended-reachable-shapeLabel's (the path to `<TBoss>' passes
;;   through the EXTENDS edge to `<Tools>'), and `ex:tool' is an
;;   `extended-reachable-predicate'.
;;
;; `shexc-ts-mode-highlight-reachable-shapes' highlights the focal
;; shape's own `shapeLabel' and `predicate's, plus every
;; `reachable-shapeLabel' and `reachable-predicate' -- with
;; cycle/duplicate detection.  Each `reachable-*' is classified by the
;; *strength* of its strongest reaching path:
;;
;; - `shexc-ts-mode--strength-required' -- a `reachable-*' with
;;   neither a `not-' nor `optional-' prefix (reachable via EXTENDS,
;;   an AND-conjunct, or as a sole shape reference): every node
;;   conforming to the focal shape also conforms to this one.  Also
;;   the strength of the focal shape's own `predicate's.
;; - `shexc-ts-mode--strength-negated' -- a `not-reachable-*':
;;   conformance to the focal shape requires *not* conforming to this
;;   one.
;; - `shexc-ts-mode--strength-optional' -- an `optional-reachable-*':
;;   conformance to the focal shape *may* entail conformance to this
;;   one, depending on which OR-branch holds.
;;
;; "Required" preempts "negated"/"optional": if a shape is reachable
;; via both a required path and a weaker one, it is highlighted as
;; required.  Likewise, if every branch of an OR reaches the same
;; target shape, that target is not downgraded to "optional" by the
;; OR -- see `shexc-ts-mode--merge-or-branches'.
;;
;; Separately, whether *any* reaching path passes through an EXTENDS
;; edge -- i.e. whether the `extended-' prefix applies -- is tracked
;; alongside the strength; at equal strength, a non-`extended-' path
;; preempts an `extended-' one.  Each combination of role (`shapeLabel'
;; /`predicate' vs `reachable-*'), strength
;; (required/negated/optional), and `extended-'-ness has its own face,
;; built from a role color (`highlight' for labels,
;; `font-lock-warning-face' for predicates), a strength decoration
;; (none/`:strike-through'/`:slant italic' for
;; required/negated/optional), and an access decoration (`:box' for
;; `extended-'); see `shexc-ts-mode--pick-label-face' and
;; `shexc-ts-mode--pick-predicate-face'.  The focal shape's own `shapeLabel'
;; and `predicate's are always at `shexc-ts-mode--strength-required'
;; and never `extended-'.

(defface shexc-ts-mode-label-face
  '((t :inherit highlight))
  "Face for a required, non-extended reachable shapeLabel.

A `shapeLabel' or `reachable-shapeLabel' at
`shexc-ts-mode--strength-required' that is not `extended-' --
reachable via an AND-conjunct or as a sole shape reference, with
neither a `not-' nor `optional-' prefix, and without passing through
an EXTENDS edge.  Also the face of the focal shape's own `shapeLabel'."
  :group 'shexc-ts)

(defface shexc-ts-mode-optional-label-face
  '((t :inherit highlight :slant italic))
  "Face for an optional, non-extended reachable shapeLabel.

An `optional-reachable-shapeLabel' that is not `extended-' --
reachable via one branch of an OR but not every branch, and without
passing through an EXTENDS edge (see
`shexc-ts-mode--strength-optional')."
  :group 'shexc-ts)

(defface shexc-ts-mode-negated-label-face
  '((t :inherit highlight :strike-through t))
  "Face for a negated, non-extended reachable shapeLabel.

A `not-reachable-shapeLabel' that is not `extended-' -- reachable only
inside a NOT, and without passing through an EXTENDS edge (see
`shexc-ts-mode--strength-negated')."
  :group 'shexc-ts)

(defface shexc-ts-mode-extended-label-face
  '((t :inherit highlight :box t))
  "Face for a required, extended reachable shapeLabel.

An `extended-reachable-shapeLabel' at
`shexc-ts-mode--strength-required' -- as `shexc-ts-mode-label-face',
but some reaching path passes through an EXTENDS edge."
  :group 'shexc-ts)

(defface shexc-ts-mode-extended-optional-label-face
  '((t :inherit highlight :slant italic :box t))
  "Face for an optional, extended reachable shapeLabel.

An `extended-optional-reachable-shapeLabel' -- as
`shexc-ts-mode-optional-label-face', but some reaching path passes
through an EXTENDS edge."
  :group 'shexc-ts)

(defface shexc-ts-mode-extended-negated-label-face
  '((t :inherit highlight :strike-through t :box t))
  "Face for a negated, extended reachable shapeLabel.

An `extended-not-reachable-shapeLabel' -- as
`shexc-ts-mode-negated-label-face', but some reaching path passes
through an EXTENDS edge."
  :group 'shexc-ts)

(defface shexc-ts-mode-predicate-face
  '((t :inherit font-lock-warning-face))
  "Face for a required, non-extended reachable predicate.

A `predicate' or `reachable-predicate' at
`shexc-ts-mode--strength-required' that is not `extended-' --
reachable via an AND-conjunct or as a sole shape reference, with
neither a `not-' nor `optional-' prefix, and without passing through
an EXTENDS edge (a `predicate' of the focal shape itself is always at
this strength and never `extended-')."
  :group 'shexc-ts)

(defface shexc-ts-mode-optional-predicate-face
  '((t :inherit font-lock-warning-face :slant italic))
  "Face for an optional, non-extended reachable predicate.

An `optional-reachable-predicate' that is not `extended-' --
reachable via one branch of an OR but not every branch, and without
passing through an EXTENDS edge (see
`shexc-ts-mode--strength-optional')."
  :group 'shexc-ts)

(defface shexc-ts-mode-negated-predicate-face
  '((t :inherit font-lock-warning-face :strike-through t))
  "Face for a negated, non-extended reachable predicate.

A `not-reachable-predicate' that is not `extended-' -- reachable only
inside a NOT, and without passing through an EXTENDS edge (see
`shexc-ts-mode--strength-negated')."
  :group 'shexc-ts)

(defface shexc-ts-mode-extended-predicate-face
  '((t :inherit font-lock-warning-face :box t))
  "Face for a required, extended reachable predicate.

An `extended-reachable-predicate' at
`shexc-ts-mode--strength-required' -- as
`shexc-ts-mode-predicate-face', but some reaching path passes through
an EXTENDS edge."
  :group 'shexc-ts)

(defface shexc-ts-mode-extended-optional-predicate-face
  '((t :inherit font-lock-warning-face :slant italic :box t))
  "Face for an optional, extended reachable predicate.

An `extended-optional-reachable-predicate' -- as
`shexc-ts-mode-optional-predicate-face', but some reaching path passes
through an EXTENDS edge."
  :group 'shexc-ts)

(defface shexc-ts-mode-extended-negated-predicate-face
  '((t :inherit font-lock-warning-face :strike-through t :box t))
  "Face for a negated, extended reachable predicate.

An `extended-not-reachable-predicate' -- as
`shexc-ts-mode-negated-predicate-face', but some reaching path passes
through an EXTENDS edge."
  :group 'shexc-ts)

(defcustom shexc-ts-mode-highlight-reachable-include-current t
  "Whether to highlight the focal shape's own `shapeLabel'.
When non-nil, `shexc-ts-mode-highlight-reachable-mode' highlights it
using `shexc-ts-mode-label-face'.  See
`shexc-ts-mode-highlight-reachable-shapes'."
  :type 'boolean
  :group 'shexc-ts)

(defcustom shexc-ts-mode-highlight-reachable-include-current-predicates t
  "Whether to highlight the focal shape's own `predicate's.
When non-nil, `shexc-ts-mode-highlight-reachable-mode' highlights them
using `shexc-ts-mode-predicate-face'.  See
`shexc-ts-mode-highlight-reachable-shapes'."
  :type 'boolean
  :group 'shexc-ts)

(defcustom shexc-ts-mode-highlight-reachable-include-non-extended t
  "Whether to highlight non-`extended-' `reachable-shapeLabel's.
Those are shapes reached from the focal shape via AND, OR, NOT, or a
sole reference, without any reaching path passing through an EXTENDS
edge.  When nil, such shapes (and their predicates) are excluded
entirely, as if those references were not followed; a shape also
reachable via an EXTENDS path is still shown, via its `extended-'
classification.  See `shexc-ts-mode-highlight-reachable-shapes'."
  :type 'boolean
  :group 'shexc-ts)

(defcustom shexc-ts-mode-highlight-reachable-include-non-extended-predicates t
  "Whether to also highlight non-`extended-' `reachable-predicate's.
When non-nil, `shexc-ts-mode-highlight-reachable-mode' also highlights
`predicate's and non-`extended-' `reachable-predicate's, not just
`shapeLabel' and non-`extended-' `reachable-shapeLabel's.  Only
relevant when
`shexc-ts-mode-highlight-reachable-include-non-extended' is also
non-nil.  See `shexc-ts-mode-highlight-reachable-shapes'."
  :type 'boolean
  :group 'shexc-ts)

(defcustom shexc-ts-mode-highlight-reachable-include-extended t
  "Whether to highlight shapes/predicates reachable only via EXTENDS.
When non-nil, `shexc-ts-mode-highlight-reachable-mode' also highlights
`extended-reachable-shapeLabel's and `extended-reachable-predicate's,
those reachable from the focal shape only via an EXTENDS edge.  When
nil, such shapes (and their predicates) are excluded entirely, as if
EXTENDS edges were not followed; a shape reachable via both an EXTENDS
and a non-EXTENDS path is still shown, via its non-EXTENDS
classification.  See `shexc-ts-mode-highlight-reachable-shapes'."
  :type 'boolean
  :group 'shexc-ts)

(defcustom shexc-ts-mode-highlight-reachable-include-extended-predicates t
  "Whether to highlight `extended-reachable-predicate's.
Of `extended-reachable-shapeLabel's.  Only relevant when
`shexc-ts-mode-highlight-reachable-include-extended' is also non-nil.
See `shexc-ts-mode-highlight-reachable-shapes'."
  :type 'boolean
  :group 'shexc-ts)

(defvar-local shexc-ts-mode--reachable-overlays nil
  "Overlays placed by `shexc-ts-mode-highlight-reachable-shapes'.")

(defun shexc-ts-mode-clear-reachable-overlays ()
  "Remove all overlays added by `shexc-ts-mode-highlight-reachable-shapes'."
  (interactive)
  (mapc #'delete-overlay shexc-ts-mode--reachable-overlays)
  (setq shexc-ts-mode--reachable-overlays nil))

(defun shexc-ts-mode--decl-at (pos)
  "Return the `shape_expr_decl' node containing POS, or nil if none.
`treesit-node-at' falls back to the nearest preceding node when POS is
past the end of the buffer's last node -- e.g. in trailing whitespace,
or in a blank line between two declarations -- so the candidate decl's
span must still be checked against POS."
  (when-let* ((decl (treesit-parent-until
                      (treesit-node-at pos)
                      (lambda (n) (string= (treesit-node-type n) "shape_expr_decl"))
                      t)))
    (and (<= (treesit-node-start decl) pos (treesit-node-end decl))
         decl)))

(defconst shexc-ts-mode--strength-optional 0
  "Reference strength of an optional-reachable shapeLabel/predicate.

An `optional-reachable-shapeLabel' (or `-predicate') is reachable only
via one branch of an OR (and not via every branch), so the focal
shape's conformance only *may* entail conformance to it.")

(defconst shexc-ts-mode--strength-negated 1
  "Reference strength of a not-reachable shapeLabel/predicate.

A `not-reachable-shapeLabel' (or `-predicate') is reachable only inside
a NOT, so the focal shape's conformance entails *non*-conformance to
it.")

(defconst shexc-ts-mode--strength-required 2
  "Reference strength of a `reachable-shapeLabel' (or `-predicate')
with neither a `not-' nor `optional-' prefix: reachable via EXTENDS,
an AND-conjunct, or as a sole shape reference, so the focal shape's
conformance always entails conformance to it.  Also the strength of
the focal shape's own `predicate's.")

(defun shexc-ts-mode--pick-label-face (strength extended)
  "Return the face for a `shapeLabel'/`reachable-shapeLabel', strength STRENGTH.
With the `extended-' prefix iff EXTENDED is non-nil."
  (cond ((>= strength shexc-ts-mode--strength-required)
         (if extended 'shexc-ts-mode-extended-label-face
           'shexc-ts-mode-label-face))
        ((= strength shexc-ts-mode--strength-negated)
         (if extended 'shexc-ts-mode-extended-negated-label-face
           'shexc-ts-mode-negated-label-face))
        (t
         (if extended 'shexc-ts-mode-extended-optional-label-face
           'shexc-ts-mode-optional-label-face))))

(defun shexc-ts-mode--pick-predicate-face (strength extended)
  "Return the face for a `predicate'/`reachable-predicate' of reference STRENGTH.
With the `extended-' prefix iff EXTENDED is non-nil.  A `predicate' of
the focal shape is always at `shexc-ts-mode--strength-required' and
never EXTENDED."
  (cond ((>= strength shexc-ts-mode--strength-required)
         (if extended 'shexc-ts-mode-extended-predicate-face
           'shexc-ts-mode-predicate-face))
        ((= strength shexc-ts-mode--strength-negated)
         (if extended 'shexc-ts-mode-extended-negated-predicate-face
           'shexc-ts-mode-negated-predicate-face))
        (t
         (if extended 'shexc-ts-mode-extended-optional-predicate-face
           'shexc-ts-mode-optional-predicate-face))))

(defun shexc-ts-mode--decl-for-label-text (label-text)
  "Return the `shape_expr_decl' node whose label text equals LABEL-TEXT."
  (cl-some (lambda (label-node)
              (when (string= (treesit-node-text label-node t) label-text)
                (treesit-node-parent label-node)))
            (shexc-ts-mode--query-labels
             '((shape_expr_decl label: (shape_expr_label) @label)))))

(defun shexc-ts-mode--decl-predicate-nodes (decl)
  "Return all `predicate' nodes that are descendants of DECL."
  (treesit-query-capture
   (treesit-buffer-root-node)
   '((triple_constraint predicate: (predicate) @pred))
   (treesit-node-start decl) (treesit-node-end decl)
   t))

(defun shexc-ts-mode--direct-extensions (def-node)
  "Return the direct `extension' children of DEF-NODE.
DEF-NODE is a `shape_definition' or `inline_shape_definition' node.
Unwraps the former's single `inline_shape_definition' child first."
  (when (string= (treesit-node-type def-node) "shape_definition")
    (setq def-node (treesit-node-child def-node 0)))
  (let (result)
    (dotimes (i (treesit-node-child-count def-node))
      (let ((child (treesit-node-child def-node i)))
        (when (string= (treesit-node-type child) "extension")
          (push child result))))
    (nreverse result)))

(defun shexc-ts-mode--strongest-per-label (refs)
  "Collapse REFS to one entry per LABEL-TEXT, keeping the strongest STRENGTH.
REFS is a list of (LABEL-TEXT . (STRENGTH . EXTENDED)).  At equal
STRENGTH, a non-EXTENDED entry preempts an EXTENDED one."
  (let (result)
    (dolist (ref refs)
      (let* ((label (car ref))
             (strength (car (cdr ref)))
             (extended (cdr (cdr ref)))
             (existing (assoc label result)))
        (if existing
            (let ((cur (cdr existing)))
              (when (or (> strength (car cur))
                        (and (= strength (car cur)) (cdr cur) (not extended)))
                (setcdr existing (cons strength extended))))
          (push (cons label (cons strength extended)) result))))
    result))

(defun shexc-ts-mode--merge-or-branches (left right strength)
  "Merge OR-branch results LEFT and RIGHT into the OR's contribution at STRENGTH.
LEFT and RIGHT are each a `shexc-ts-mode--collect-shape-refs' result
computed at branch-root strength
`shexc-ts-mode--strength-required'.  Each entry is (LABEL-TEXT .
\(STRENGTH . EXTENDED)).

A `reachable-shapeLabel' reachable through *both* branches keeps the
weaker of its two per-branch strengths (no OR-downgrade, since every
branch entails it, so it is not made `optional-'), and is `extended-'
only if *both* branches' paths to it are `extended-'; a
`reachable-shapeLabel' reachable through only one branch is downgraded
to `shexc-ts-mode--strength-optional' (`optional-reachable-shapeLabel')
and keeps that branch's `extended-'-ness as-is.  Either way the
strength is then capped at STRENGTH, since the OR itself may be
reached via a NOT or via another OR-branch."
  (let ((left-map (shexc-ts-mode--strongest-per-label left))
        (right-map (shexc-ts-mode--strongest-per-label right))
        result)
    (dolist (entry left-map)
      (let ((rentry (assoc (car entry) right-map)))
        (if rentry
            (push (cons (car entry)
                         (cons (min strength (car (cdr entry)) (car (cdr rentry)))
                               (and (cdr (cdr entry)) (cdr (cdr rentry)))))
                  result)
          (push (cons (car entry)
                       (cons (min strength shexc-ts-mode--strength-optional)
                             (cdr (cdr entry))))
                result))))
    (dolist (entry right-map)
      (unless (assoc (car entry) left-map)
        (push (cons (car entry)
                     (cons (min strength shexc-ts-mode--strength-optional)
                           (cdr (cdr entry))))
              result)))
    (nreverse result)))

(defun shexc-ts-mode--collect-shape-refs (node strength extended)
  "Collect (LABEL-TEXT . (STRENGTH . EXTENDED)) entries reachable from NODE.
Each entry is for one `reachable-shapeLabel' (`@<Label>' reference or
EXTENDS target) directly or transitively reachable from NODE, a
`shape_or'/`shape_and'/`shape_not'/`shape_atom' or one of their
`inline_*' counterparts.
STRENGTH determines whether the caller should
treat that `reachable-shapeLabel' as plain
\(`shexc-ts-mode--strength-required'), `not-reachable-'
\(`-strength-negated'), or `optional-reachable-' (`-strength-optional');
EXTENDED determines whether it is `extended-reachable-' (the path from
the traversal's root passed through an EXTENDS edge -- this is sticky:
once t, it stays t for the rest of the path).  Both are the
classification of the path from the traversal's root down to NODE,
adjusted by OR/AND/NOT/EXTENDS along the way -- see
`shexc-ts-mode--merge-or-branches'.  Triple expressions inside
`{ ... }' are not descended into, so `reachable-predicate's are not
collected here (see `shexc-ts-mode--make-predicate-overlays')."
  (pcase (treesit-node-type node)
    ((or "shape_or" "inline_shape_or")
     (let ((left (shexc-ts-mode--collect-shape-refs
                   (treesit-node-child-by-field-name node "left")
                   shexc-ts-mode--strength-required extended))
           (right (shexc-ts-mode--collect-shape-refs
                   (treesit-node-child-by-field-name node "right")
                   shexc-ts-mode--strength-required extended)))
       (shexc-ts-mode--merge-or-branches left right strength)))
    ((or "shape_and" "inline_shape_and")
     (append (shexc-ts-mode--collect-shape-refs
              (treesit-node-child-by-field-name node "left") strength extended)
             (shexc-ts-mode--collect-shape-refs
              (treesit-node-child-by-field-name node "right") strength extended)))
    ((or "shape_not" "inline_shape_not")
     (shexc-ts-mode--collect-shape-refs
      (treesit-node-child-by-field-name node "shape_expr")
      (min strength shexc-ts-mode--strength-negated) extended))
    ((or "shape_atom" "inline_shape_atom")
     (let ((inner (treesit-node-child-by-field-name node "shape_expr")))
       (when inner
         (cond
          ((string= (treesit-node-type inner) "shape_ref")
           (list (cons (treesit-node-text
                        (treesit-node-child-by-field-name inner "label") t)
                       (cons strength extended))))
          ((member (treesit-node-type inner)
                   '("shape_definition" "inline_shape_definition"))
           (mapcan (lambda (ext)
                     (shexc-ts-mode--collect-shape-refs
                      (treesit-node-child-by-field-name ext "shape_expr")
                      strength t))
                   (shexc-ts-mode--direct-extensions inner)))
          (t
           ;; a parenthesized sub-expression: `( ... )' wraps its
           ;; contents in another shape_or/shape_and/shape_not/shape_atom
           ;; (or `inline_*' variant), which the cases above handle
           (shexc-ts-mode--collect-shape-refs inner strength extended))))))
    (_ nil)))

(defun shexc-ts-mode--make-predicate-overlays (decl strength extended)
  "Overlay each predicate in DECL with the face for STRENGTH and EXTENDED.
Push the new overlays onto `shexc-ts-mode--reachable-overlays', and
return them.  Each predicate is a `predicate' if DECL is the focal
shape, or a `reachable-predicate' otherwise."
  (let (overlays)
    (dolist (pred-node (shexc-ts-mode--decl-predicate-nodes decl))
      (let ((ov (make-overlay (treesit-node-start pred-node)
                              (treesit-node-end pred-node))))
        (overlay-put ov 'face (shexc-ts-mode--pick-predicate-face strength extended))
        (push ov shexc-ts-mode--reachable-overlays)
        (push ov overlays)))
    overlays))

(defun shexc-ts-mode-highlight-reachable-shapes (pos &optional include-predicates)
  "Highlight `shapeLabel's reachable from the `shape_expr_decl' at POS.
If `shexc-ts-mode-highlight-reachable-include-current' is non-nil,
places an overlay on the focal shape's own ShapeDecl label using
`shexc-ts-mode-label-face'.  Places an overlay on the ShapeDecl label of
each shape transitively reachable from it via a sole shape reference
\(e.g. `<Contact1> @<Contact>'), AND, OR, NOT, or EXTENDS -- with
cycle/duplicate detection -- using the label face matching that
`reachable-shapeLabel''s plain/`not-'/`optional-' classification,
combined with whether any path reaching it passes through an EXTENDS
edge (`extended-'); see `shexc-ts-mode--collect-shape-refs',
`shexc-ts-mode--merge-or-branches', and `shexc-ts-mode--pick-label-face' for
exactly how that is computed.
When INCLUDE-PREDICATES is non-nil, also overlays, subject to the
options below:
- every `predicate' directly in the `shape_expr_decl' at POS, always
  at `shexc-ts-mode-predicate-face' (a `predicate' is always
  at `shexc-ts-mode--strength-required' and never `extended-'); and
- every `reachable-predicate' inside each reachable shape, with the
  predicate face matching that shape's classification above.
If `shexc-ts-mode-highlight-reachable-include-non-extended' is nil,
non-`extended-' `reachable-shapeLabel's (and their predicates) are
excluded entirely, as if those references were not followed; a shape
also reachable via an EXTENDS path is still shown, via its `extended-'
classification.  If `shexc-ts-mode-highlight-reachable-include-extended'
is nil, `extended-reachable-shapeLabel's (and their predicates) are
excluded entirely, as if EXTENDS edges were not followed; a shape
reachable via both an EXTENDS and a non-EXTENDS path is still shown, via
its non-EXTENDS classification.
`shexc-ts-mode-highlight-reachable-include-current-predicates',
`-include-non-extended-predicates', and `-include-extended-predicates'
independently control, when INCLUDE-PREDICATES is non-nil, whether the
focal shape's `predicate's, non-`extended-' `reachable-predicate's, and
`extended-reachable-predicate's (respectively) are highlighted, without
affecting whether the corresponding `shapeLabel's themselves are shown.
Clears any overlays from a previous call first, and overlays nothing
if POS is not inside any `shape_expr_decl'.
Returns the list of label texts of the `reachable-shapeLabel's actually
highlighted (not including the focal shape's own label), in the order
they were first discovered (breadth-first)."
  (shexc-ts-mode-clear-reachable-overlays)
  (let* ((decl (shexc-ts-mode--decl-at pos))
         (best (make-hash-table :test 'equal))
         (label-overlays (make-hash-table :test 'equal))
         (predicate-overlays (make-hash-table :test 'equal))
         (queue (and decl (list (list decl shexc-ts-mode--strength-required nil))))
         result)
    (when decl
      (let ((label-node (treesit-node-child-by-field-name decl "label")))
        (when label-node
          (when shexc-ts-mode-highlight-reachable-include-current
            (let ((ov (make-overlay (treesit-node-start label-node)
                                    (treesit-node-end label-node))))
              (overlay-put ov 'face (shexc-ts-mode--pick-label-face
                                     shexc-ts-mode--strength-required nil))
              (push ov shexc-ts-mode--reachable-overlays)))
          ;; seed `best' so a cycle back to the focal shape doesn't
          ;; place a second, possibly different-faced overlay on its
          ;; own label
          (puthash (treesit-node-text label-node t)
                   (cons shexc-ts-mode--strength-required nil)
                   best)))
      (when (and include-predicates
                 shexc-ts-mode-highlight-reachable-include-current-predicates)
        (shexc-ts-mode--make-predicate-overlays
         decl shexc-ts-mode--strength-required nil)))
    (while queue
      (pcase-let* ((`(,cur-decl ,cur-strength ,cur-extended) (pop queue))
                   (refs (shexc-ts-mode--collect-shape-refs
                          (treesit-node-child-by-field-name cur-decl "shape_expr")
                          cur-strength cur-extended)))
        (dolist (ref (shexc-ts-mode--strongest-per-label refs))
          (let* ((label-text (car ref))
                 (ref-strength (car (cdr ref)))
                 (ref-extended (cdr (cdr ref)))
                 (prev (gethash label-text best))
                 (prev-strength (car prev))
                 (prev-extended (cdr prev)))
            (when (and (if ref-extended
                           shexc-ts-mode-highlight-reachable-include-extended
                         shexc-ts-mode-highlight-reachable-include-non-extended)
                       (or (not prev)
                           (> ref-strength prev-strength)
                           (and (= ref-strength prev-strength)
                                prev-extended (not ref-extended))))
              (puthash label-text (cons ref-strength ref-extended) best)
              (unless prev (push label-text result))
              (let ((ext-decl (shexc-ts-mode--decl-for-label-text label-text)))
                (when ext-decl
                  (let ((ov (gethash label-text label-overlays))
                        (label-node (treesit-node-child-by-field-name ext-decl "label")))
                    (if ov
                        (overlay-put ov 'face (shexc-ts-mode--pick-label-face
                                               ref-strength ref-extended))
                      (when label-node
                        (setq ov (make-overlay (treesit-node-start label-node)
                                               (treesit-node-end label-node)))
                        (overlay-put ov 'face (shexc-ts-mode--pick-label-face
                                               ref-strength ref-extended))
                        (push ov shexc-ts-mode--reachable-overlays)
                        (puthash label-text ov label-overlays))))
                  (when (and include-predicates
                             (if ref-extended
                                 shexc-ts-mode-highlight-reachable-include-extended-predicates
                               shexc-ts-mode-highlight-reachable-include-non-extended-predicates))
                    (let ((pred-ovs (gethash label-text predicate-overlays)))
                      (if pred-ovs
                          (dolist (ov pred-ovs)
                            (overlay-put ov 'face (shexc-ts-mode--pick-predicate-face
                                                   ref-strength ref-extended)))
                        (puthash label-text
                                 (shexc-ts-mode--make-predicate-overlays
                                  ext-decl ref-strength ref-extended)
                                 predicate-overlays))))
                  (push (list ext-decl ref-strength ref-extended) queue))))))))
    (nreverse result)))

(defvar-local shexc-ts-mode--highlight-reachable-last-decl-start nil
  "Start position of the last-highlighted `shape_expr_decl', or `none'.
Set by `shexc-ts-mode--highlight-reachable-update'.  The symbol
`none' means the last update found point outside any
`shape_expr_decl' and cleared the overlays.  Used to avoid
recomputing the highlight on every command when point hasn't left the
current shape.")

(defun shexc-ts-mode--highlight-reachable-update ()
  "Update the `reachable-shapeLabel'/`reachable-predicate' overlays for point.
Only recomputes if the `shape_expr_decl' at point has changed since
the last update.  Clears the overlays when point is outside any
`shape_expr_decl'.  Intended for `post-command-hook' via
`shexc-ts-mode-highlight-reachable-mode'."
  (let* ((decl (shexc-ts-mode--decl-at (point)))
         (key (if decl (treesit-node-start decl) 'none)))
    (unless (eq key shexc-ts-mode--highlight-reachable-last-decl-start)
      (setq shexc-ts-mode--highlight-reachable-last-decl-start key)
      (if decl
          (shexc-ts-mode-highlight-reachable-shapes (point) t)
        (shexc-ts-mode-clear-reachable-overlays)))))

;;;###autoload
(define-minor-mode shexc-ts-mode-highlight-reachable-mode
  "Toggle live highlighting of shapes reachable from the shape at point.

While enabled, the focal shape's own `shapeLabel'/`predicate's and the
`reachable-shapeLabel's/`reachable-predicate's of the `shape_expr_decl'
containing point, as found by `shexc-ts-mode-highlight-reachable-shapes',
are highlighted, updating automatically as point moves between shapes
and clearing when point leaves all `shape_expr_decl's.  Which of those
are included is controlled independently by
`shexc-ts-mode-highlight-reachable-include-current',
`-include-non-extended', `-include-extended', and their
`-predicates' counterparts (see `shexc-ts-mode-menu'); toggling those
options does not disable this mode, so turning this mode off and back
on (e.g. with \\[shexc-ts-mode-highlight-reachable-mode]) restores the same selection.

This is the standalone, manifest-free counterpart to the highlighting
`shex-manifest-browser-mode' drives from `sht:shape'; the two can be
used independently or together."
  :lighter " ExtH"
  (if shexc-ts-mode-highlight-reachable-mode
      (progn
        (add-hook 'post-command-hook #'shexc-ts-mode--highlight-reachable-update nil t)
        (shexc-ts-mode--highlight-reachable-update))
    (remove-hook 'post-command-hook #'shexc-ts-mode--highlight-reachable-update t)
    (setq shexc-ts-mode--highlight-reachable-last-decl-start nil)
    (shexc-ts-mode-clear-reachable-overlays)))

(defun shexc-ts-mode--refresh-highlight-reachable ()
  "Recompute the `shexc-ts-mode-highlight-reachable-mode' overlays at point.
Does nothing if that mode is not currently enabled."
  (when shexc-ts-mode-highlight-reachable-mode
    (if (shexc-ts-mode--decl-at (point))
        (shexc-ts-mode-highlight-reachable-shapes (point) t)
      (shexc-ts-mode-clear-reachable-overlays))))

;;;###autoload
(defun shexc-ts-mode-toggle-highlight-reachable-current ()
  "Toggle `shexc-ts-mode-highlight-reachable-include-current'.

That option controls whether `shexc-ts-mode-highlight-reachable-mode'
highlights the focal shape's own `shapeLabel'.  If
`shexc-ts-mode-highlight-reachable-mode' is currently enabled, its
overlays are refreshed immediately to reflect the new setting."
  (interactive)
  (setq shexc-ts-mode-highlight-reachable-include-current
        (not shexc-ts-mode-highlight-reachable-include-current))
  (shexc-ts-mode--refresh-highlight-reachable)
  (message "shexc-ts-mode-highlight-reachable-include-current: %s"
           shexc-ts-mode-highlight-reachable-include-current))

;;;###autoload
(defun shexc-ts-mode-toggle-highlight-reachable-current-predicates ()
  "Toggle `shexc-ts-mode-highlight-reachable-include-current-predicates'.

That option controls whether `shexc-ts-mode-highlight-reachable-mode'
highlights the focal shape's own `predicate's.  If
`shexc-ts-mode-highlight-reachable-mode' is currently enabled, its
overlays are refreshed immediately to reflect the new setting."
  (interactive)
  (setq shexc-ts-mode-highlight-reachable-include-current-predicates
        (not shexc-ts-mode-highlight-reachable-include-current-predicates))
  (shexc-ts-mode--refresh-highlight-reachable)
  (message "shexc-ts-mode-highlight-reachable-include-current-predicates: %s"
           shexc-ts-mode-highlight-reachable-include-current-predicates))

;;;###autoload
(defun shexc-ts-mode-toggle-highlight-reachable-non-extended ()
  "Toggle `shexc-ts-mode-highlight-reachable-include-non-extended'.

That option controls whether `shexc-ts-mode-highlight-reachable-mode'
highlights `reachable-shapeLabel's that are not `extended-' and their
`reachable-predicate's.  If `shexc-ts-mode-highlight-reachable-mode' is
currently enabled, its overlays are refreshed immediately to reflect
the new setting."
  (interactive)
  (setq shexc-ts-mode-highlight-reachable-include-non-extended
        (not shexc-ts-mode-highlight-reachable-include-non-extended))
  (shexc-ts-mode--refresh-highlight-reachable)
  (message "shexc-ts-mode-highlight-reachable-include-non-extended: %s"
           shexc-ts-mode-highlight-reachable-include-non-extended))

;;;###autoload
(defun shexc-ts-mode-toggle-highlight-reachable-non-extended-predicates ()
  "Toggle `shexc-ts-mode-highlight-reachable-include-non-extended-predicates'.

That option controls whether `shexc-ts-mode-highlight-reachable-mode'
also highlights `predicate's and non-`extended-' `reachable-predicate's,
not just `shapeLabel' and non-`extended-' `reachable-shapeLabel's.  If
`shexc-ts-mode-highlight-reachable-mode' is currently enabled, its
overlays are refreshed immediately to reflect the new setting."
  (interactive)
  (setq shexc-ts-mode-highlight-reachable-include-non-extended-predicates
        (not shexc-ts-mode-highlight-reachable-include-non-extended-predicates))
  (shexc-ts-mode--refresh-highlight-reachable)
  (message "shexc-ts-mode-highlight-reachable-include-non-extended-predicates: %s"
           shexc-ts-mode-highlight-reachable-include-non-extended-predicates))

;;;###autoload
(defun shexc-ts-mode-toggle-highlight-reachable-extended ()
  "Toggle `shexc-ts-mode-highlight-reachable-include-extended'.

That option controls whether `shexc-ts-mode-highlight-reachable-mode'
also highlights `extended-reachable-shapeLabel's and
`extended-reachable-predicate's -- those reachable from the focal shape
only via an EXTENDS edge.  If `shexc-ts-mode-highlight-reachable-mode' is
currently enabled, its overlays are refreshed immediately to reflect
the new setting."
  (interactive)
  (setq shexc-ts-mode-highlight-reachable-include-extended
        (not shexc-ts-mode-highlight-reachable-include-extended))
  (shexc-ts-mode--refresh-highlight-reachable)
  (message "shexc-ts-mode-highlight-reachable-include-extended: %s"
           shexc-ts-mode-highlight-reachable-include-extended))

;;;###autoload
(defun shexc-ts-mode-toggle-highlight-reachable-extended-predicates ()
  "Toggle `shexc-ts-mode-highlight-reachable-include-extended-predicates'.

That option controls whether `shexc-ts-mode-highlight-reachable-mode'
highlights the `extended-reachable-predicate's of
`extended-reachable-shapeLabel's, when
`shexc-ts-mode-highlight-reachable-include-extended' is also non-nil.
If `shexc-ts-mode-highlight-reachable-mode' is currently enabled, its
overlays are refreshed immediately to reflect the new setting."
  (interactive)
  (setq shexc-ts-mode-highlight-reachable-include-extended-predicates
        (not shexc-ts-mode-highlight-reachable-include-extended-predicates))
  (shexc-ts-mode--refresh-highlight-reachable)
  (message "shexc-ts-mode-highlight-reachable-include-extended-predicates: %s"
           shexc-ts-mode-highlight-reachable-include-extended-predicates))

;;; Structural editing: unwrapping/wrapping `<predicate> { ... }' shapes
;;
;; These mirror the "splice"/"unwrap" and "wrap" operations familiar
;; from `paredit'/`combobulate', specialized to ShExC's
;; `<predicate> { ... }' nested-shape construct -- e.g. turning
;;
;;   <#foo> {
;;     <p1> {
;;       <p11> @<#bar> ;
;;       <p12> @<#bar>
;;     }
;;   }
;;
;; into
;;
;;   <#foo> {
;;     <p11> @<#bar> ;
;;     <p12> @<#bar>
;;   }
;;
;; and back.

(defun shexc-ts-mode--plain-inline-shape-definition (value-expr)
  "Return VALUE-EXPR's `inline_shape_definition' if it is simply a `{ ... }' shape.
VALUE-EXPR is an `inline_shape_expression'.  \"Simply a `{ ... }'
shape\" means an `inline_shape_definition' with no NodeConstraint and
no AND/OR/NOT combination; otherwise returns nil."
  (when (and value-expr
             (string= (treesit-node-type value-expr) "inline_shape_expression"))
    (let ((atom (treesit-node-child value-expr 0 t)))
      (when (and atom (string= (treesit-node-type atom) "inline_shape_atom")
                 (not (treesit-node-child-by-field-name atom "constraint")))
        (let ((shape-expr (treesit-node-child-by-field-name atom "shape_expr")))
          (and shape-expr
               (string= (treesit-node-type shape-expr) "inline_shape_definition")
               shape-expr))))))

(defun shexc-ts-mode--shape-wrapper-at (pos)
  "Return (TRIPLE-CONSTRAINT . INLINE-SHAPE-DEFINITION) for POS, or nil.
For the nearest `<predicate> { ... }' construct enclosing POS, or nil
if there is none.  Tries both POS and POS-1 as starting points: a
wrapper's closing brace coincides with the end of several
ancestor nodes at once, so which node `treesit-node-at' returns
right after `}' depends on which side of that shared boundary it
resolves to."
  (catch 'found
    (dolist (start (delete-dups (delq nil (list (treesit-node-at pos)
                                                 (and (> pos (point-min))
                                                      (treesit-node-at (1- pos)))))))
      (let ((node start))
        (while node
          (when (string= (treesit-node-type node) "triple_constraint")
            (let ((shape-def (shexc-ts-mode--plain-inline-shape-definition
                              (treesit-node-child-by-field-name node "value_expr"))))
              (when shape-def
                (throw 'found (cons node shape-def)))))
          (setq node (treesit-node-parent node)))))
    nil))

(defun shexc-ts-mode-unwrap-shape ()
  "Remove the `<predicate> { ... }' wrapper enclosing point.
Keeps its triple expressions, re-indenting them in place \(the
structural-editing \"splice\"/\"unwrap\"/\"raise\" operation, e.g.
`paredit-splice-sexp', specialized to ShExC's nested-shape
construct).
For example, with point inside

    <#foo> {
      <p1> {
        <p11> @<#bar> ;
        <p12> @<#bar>
      }
    }

this produces

    <#foo> {
      <p11> @<#bar> ;
      <p12> @<#bar>
    }

This only handles the simple case where the nested shape is the
predicate's entire value -- no NodeConstraint, no AND/OR/NOT
combination; anything else is reported with a `user-error'.
Note that any cardinality (`*'/`+'/`?') or annotations on the
removed triple constraint are discarded along with its
predicate."
  (interactive)
  (let ((found (shexc-ts-mode--shape-wrapper-at (point))))
    (unless found
      (user-error "No simple `<predicate> { ... }' shape to unwrap here"))
    (pcase-let* ((`(,triple-constraint . ,shape-def) found)
                 (beg (treesit-node-start triple-constraint))
                 (end (treesit-node-end triple-constraint))
                 (expression (treesit-node-child-by-field-name shape-def "expression"))
                 (inner (if expression (treesit-node-text expression t) "")))
      (delete-region beg end)
      (goto-char beg)
      (insert inner)
      (indent-region beg (point)))))

(defun shexc-ts-mode-wrap-in-shape ()
  "Wrap the triple expression(s) at point, or in the active region.
In a new `PREDICATE { ... }' shape that you are prompted for,
re-indenting the result \(the inverse \"wrap\" operation, e.g.
`paredit-wrap-round'/`embrace-add', specialized to inject a ShExC
predicate along with the braces).
For example, selecting

    <#foo> {
      <p11> @<#bar> ;
      <p12> @<#bar>
    }

and supplying `<p1>' as the predicate produces

    <#foo> {
      <p1> {
        <p11> @<#bar> ;
        <p12> @<#bar>
      }
    }

With no active region, it wraps just the single triple
expression element at point."
  (interactive)
  (pcase-let* ((`(,beg . ,end) (if (use-region-p)
                                   (cons (region-beginning) (region-end))
                                 (cons (point) (1+ (point)))))
               (probe (or (treesit-node-on beg end) (treesit-node-at beg)))
               (group (treesit-parent-until
                       probe
                       (lambda (n) (string= (treesit-node-type n) "group_triple_expr"))
                       t)))
    (unless group
      (user-error "No triple expression to wrap here"))
    (let ((elements (seq-filter
                     (lambda (c)
                       (and (equal (treesit-node-field-name c) "element")
                            (< (treesit-node-start c) end)
                            (> (treesit-node-end c) beg)))
                     (treesit-node-children group))))
      (unless elements
        (user-error "No triple expression to wrap here"))
      (let* ((new-beg (treesit-node-start (car elements)))
             (new-end (treesit-node-end (car (last elements))))
             (inner (buffer-substring-no-properties new-beg new-end))
             (predicate (string-trim
                         (read-string "Wrap in shape with predicate (e.g. <p1> or ex:p1): "))))
        (when (string-empty-p predicate)
          (user-error "A predicate is required"))
        (delete-region new-beg new-end)
        (goto-char new-beg)
        (insert predicate " {\n" inner "\n}")
        (indent-region new-beg (point))))))

;;; Folding (hideshow)

(defun shexc-ts-mode--def-open-brace (def)
  "Return the position of the `{' that opens shape-body node DEF.

DEF is a `shape_definition' or `inline_shape_definition'.  Its `{'
may be preceded by modifiers such as `CLOSED'/`EXTRA ...', so it is
located by scanning DEF's children rather than assuming it is the
first one."
  (cl-loop for i below (treesit-node-child-count def)
           for child = (treesit-node-child def i)
           when (string= (treesit-node-type child) "{")
           return (treesit-node-start child)))

(defun shexc-ts-mode--first-brace-in (node)
  "Return the position of the first `{' token in NODE's subtree, or nil.

A plain depth-first walk over all children (including anonymous
ones, like `{' itself) -- `treesit-search-subtree' does not visit
anonymous nodes via a function PREDICATE."
  (cl-block found
    (cl-labels ((walk (n)
                  (if (string= (treesit-node-type n) "{")
                      (cl-return-from found (treesit-node-start n))
                    (dotimes (i (treesit-node-child-count n))
                      (walk (treesit-node-child n i))))))
      (walk node)
      nil)))

(defun shexc-ts-mode--shape-body-brace-at (pos)
  "Return the position of the `{' of the shape body to fold at POS, or nil.
This is the `{' of the `{ ... }' shape body that
`shexc-ts-mode-toggle-fold' should act on.

If POS is inside a `shape_definition'/`inline_shape_definition', that
is the body in question.  Otherwise, if POS is elsewhere in an
enclosing `shape_expr_decl' -- e.g. on a `<#Shape> EXTENDS
@<#Other>' header line, before its `{ ... }' body -- fall back to
that declaration's first `{ ... }'."
  (if-let* ((def (shexc-ts-mode--ancestor-of-type
                   (treesit-node-at pos)
                   '("shape_definition" "inline_shape_definition")
                   t)))
      (shexc-ts-mode--def-open-brace def)
    (when-let* ((decl (shexc-ts-mode--decl-at pos)))
      (shexc-ts-mode--first-brace-in decl))))

;;;###autoload
(defun shexc-ts-mode-toggle-fold ()
  "Fold or unfold the `{ ... }' shape body at or around point.

Enables `hs-minor-mode' if it is not already on, then toggles hiding
of the nearest enclosing `{ ... }' (a `shape_definition' or
`inline_shape_definition')."
  (interactive)
  (unless (bound-and-true-p hs-minor-mode)
    (hs-minor-mode 1))
  (if-let* ((brace (shexc-ts-mode--shape-body-brace-at (point))))
      (save-excursion
        (goto-char brace)
        (hs-toggle-hiding))
    (user-error "No `{ ... }' shape body at point")))

(add-to-list 'hs-special-modes-alist
              '(shexc-ts-mode "{" "}" "#\\|/\\*" nil nil))

;;; Renaming shape labels

;;;###autoload
(defun shexc-ts-mode-rename-shape (new-label)
  "Rename the shape label at point to NEW-LABEL everywhere in the buffer.

Renames the `shape_expr_label' at point -- whether on the
`shape_expr_decl' that declares it (`<#Old> { ... }') or on any
`shape_ref' to it (`@<#Old>', `EXTENDS @<#Old>', `&<#Old>',
`start = @<#Old>') -- and every other occurrence of the same label,
including the declaration."
  (interactive
   (let ((old (shexc-ts-mode--label-at-point)))
     (unless old
       (user-error "No shape label at point"))
     (list (read-string (format "Rename %s to: " old) old))))
  (let ((old (shexc-ts-mode--label-at-point)))
    (unless old
      (user-error "No shape label at point"))
    (when (string= old new-label)
      (user-error "New label is the same as the old one"))
    (when (cl-some (lambda (n) (string= (treesit-node-text n t) new-label))
                    (shexc-ts-mode--all-labels))
      (user-error "Label %s is already in use" new-label))
    (let ((ranges
           (sort
            (mapcar (lambda (n) (cons (treesit-node-start n) (treesit-node-end n)))
                    (seq-filter (lambda (n) (string= (treesit-node-text n t) old))
                                 (shexc-ts-mode--all-labels)))
            (lambda (a b) (> (car a) (car b))))))
      (unless ranges
        (user-error "No occurrences of %s found" old))
      (dolist (range ranges)
        (goto-char (car range))
        (delete-region (car range) (cdr range))
        (insert new-label))
      (message "Renamed %d occurrence%s of %s to %s"
               (length ranges) (if (= (length ranges) 1) "" "s") old new-label))))

;;; Flymake: undefined shape references/prefixes, syntax errors,
;;; duplicate predicates

(defun shexc-ts-mode--prefix-name (text)
  "Return the part of prefixed-name TEXT before its `:'.
E.g. \"ex\" for both `ex:p1' and `ex:', and \"\" for `:p1'."
  (substring text 0 (string-search ":" text)))

;;;; Prefix maps: lookup and insertion

(defun shexc-ts-mode--prefix-map-lookup (prefix)
  "Return the IRI for PREFIX in the active `shexc-ts-mode-prefix-map'.
Return nil if PREFIX is empty, `shexc-ts-mode-prefix-map' has no entry
in `shexc-ts-mode-prefix-maps', or that map has no entry for PREFIX."
  (unless (string-empty-p prefix)
    (let ((map (cdr (assoc shexc-ts-mode-prefix-map shexc-ts-mode-prefix-maps))))
      (cdr (assoc prefix (plist-get map :prefixes))))))

(defun shexc-ts-mode--prefixed-name-at (pos)
  "Return the `prefixed_name' node at POS, or nil if none."
  (treesit-parent-until
   (treesit-node-at pos)
   (lambda (n) (string= (treesit-node-type n) "prefixed_name"))
   t))

(defun shexc-ts-mode--insert-prefix-decl (prefix iri)
  "Insert the line `PREFIX PREFIX: <IRI>' into the current buffer.
It is placed immediately after the buffer's last
`base_decl'/`prefix_decl'/`import_decl', or at `point-min' if the
buffer has none of those."
  (let ((directives (treesit-query-capture
                      (treesit-buffer-root-node)
                      '([(base_decl) (prefix_decl) (import_decl)] @d)
                      nil nil t)))
    (if directives
        (progn
          (goto-char (apply #'max (mapcar #'treesit-node-end directives)))
          (end-of-line)
          (if (eobp)
              (insert "\n")
            (forward-char 1)))
      (goto-char (point-min)))
    (insert (format "PREFIX %s: <%s>\n" prefix iri))))

;;;###autoload
(defun shexc-ts-mode-insert-prefix ()
  "Insert a `PREFIX' declaration for the prefixed name at point.

Looks up the prefix of the `prefixed_name' at point (e.g. \"ex\" in
`ex:Foo') in the active `shexc-ts-mode-prefix-map' and, if found there,
inserts `PREFIX ex: <IRI>' via `shexc-ts-mode--insert-prefix-decl'.

Signals a `user-error' if point is not on a prefixed name, or its
prefix has no entry in the active map -- in the latter case, either
add the prefix to `shexc-ts-mode-prefix-maps' or declare it directly
with `PREFIX ex: <...>'."
  (interactive)
  (let ((node (shexc-ts-mode--prefixed-name-at (point))))
    (unless node
      (user-error "No prefixed name at point"))
    (let* ((prefix (shexc-ts-mode--prefix-name (treesit-node-text node t)))
           (iri (shexc-ts-mode--prefix-map-lookup prefix)))
      (unless iri
        (user-error "Prefix `%s:' is not in the %s prefix map"
                     prefix shexc-ts-mode-prefix-map))
      (save-excursion (shexc-ts-mode--insert-prefix-decl prefix iri))
      (message "Inserted `PREFIX %s: <%s>'" prefix iri))))

;;;###autoload
(defun shexc-ts-mode-set-prefix-map (name)
  "Set the buffer-local active prefix map to NAME, for this buffer only.

NAME must be a key of `shexc-ts-mode-prefix-maps' (e.g. \"rdfa\" or
\"wikidata\"); `shexc-ts-mode-insert-prefix' and the \"Undefined
prefix\" flymake diagnostic then look up prefixes in that map.

This setting is buffer-local and does not persist when the buffer is
reopened -- to make a choice persistent, set
`shexc-ts-mode-prefix-map' as a file- or directory-local variable
instead."
  (interactive
   (list (completing-read "Prefix map: "
                           (mapcar #'car shexc-ts-mode-prefix-maps)
                           nil t shexc-ts-mode-prefix-map)))
  (setq-local shexc-ts-mode-prefix-map name)
  (message "Active prefix map: %s" name))

(defun shexc-ts-mode--flymake-undefined-prefixes ()
  "Return `:error' diagnostics for `prefixed_name's with an undeclared prefix.
I.e. a `prefixed_name' (`ex:p1', `ex:', `x:Foo', a value-set IRI, a
datatype, ...) whose prefix has no matching `PREFIX' declaration.

When the prefix has an entry in the active `shexc-ts-mode-prefix-map',
the diagnostic message names the IRI that `shexc-ts-mode-insert-prefix'
would declare for it."
  (let ((declared
         (mapcar (lambda (n) (shexc-ts-mode--prefix-name (treesit-node-text n t)))
                 (treesit-query-capture
                  (treesit-buffer-root-node)
                  '((prefix_decl name: (pname_ns) @name)) nil nil t))))
    (delq nil
          (mapcar
           (lambda (n)
             (let* ((text (treesit-node-text n t))
                    (prefix (shexc-ts-mode--prefix-name text)))
               (unless (member prefix declared)
                 (let ((iri (shexc-ts-mode--prefix-map-lookup prefix)))
                   (flymake-make-diagnostic
                    (current-buffer)
                    (treesit-node-start n) (treesit-node-end n)
                    :error
                    (if iri
                        (format "Undefined prefix %s: `M-x shexc-ts-mode-insert-prefix' \
adds `PREFIX %s: <%s>' from the %s prefix map"
                                prefix prefix iri shexc-ts-mode-prefix-map)
                      (format "Undefined prefix %s:" prefix)))))))
           (treesit-query-capture
            (treesit-buffer-root-node) '((prefixed_name) @n) nil nil t)))))

(defun shexc-ts-mode--flymake-syntax-errors ()
  "Return `:error' diagnostics for tree-sitter ERROR nodes.
I.e. text the parser could not make sense of, e.g. the `p3' in
`ex: p3 . ;' \(a valid `ex:' prefixed name with empty local part,
followed by an unexpected token\)."
  (let (seen diagnostics)
    (dolist (n (treesit-query-capture
                 (treesit-buffer-root-node) '((ERROR) @e) nil nil t))
      (let ((range (cons (treesit-node-start n) (treesit-node-end n))))
        (unless (member range seen)
          (push range seen)
          (push (flymake-make-diagnostic
                 (current-buffer) (car range) (cdr range)
                 :error "Syntax error")
                diagnostics))))
    diagnostics))

(defun shexc-ts-mode--flymake-undefined-shapes ()
  "Return `:error' diagnostics for undefined shape references.
I.e. shape references with no matching `shape_expr_decl', e.g.
`@<#Typo>' or `EXTENDS @<#Typo>'."
  (let ((decl-labels
         (mapcar (lambda (n) (treesit-node-text n t))
                 (shexc-ts-mode--query-labels
                  '((shape_expr_decl label: (shape_expr_label) @label))))))
    (delq nil
          (mapcar
           (lambda (ref)
             (let ((text (treesit-node-text ref t)))
               (unless (member text decl-labels)
                 (flymake-make-diagnostic
                  (current-buffer)
                  (treesit-node-start ref) (treesit-node-end ref)
                  :error
                  (format "Undefined shape %s" text)))))
           (shexc-ts-mode--query-labels
            '((shape_ref label: (shape_expr_label) @label)))))))

(defun shexc-ts-mode--flymake-duplicate-predicates ()
  "Return `:note' diagnostics for predicates repeated in a disjunct group.
I.e. predicates that occur more than once as direct elements of the
same EachOf/OneOf-disjunct group \(`group_triple_expr'\).

Repeated predicates are not an error -- ShEx allows them, e.g. with
different cardinalities or value constraints -- but they are often a
sign of a typo or a missing `|'/cardinality, so they are flagged here
as `:note's for orientation, one per duplicated `triple_constraint'."
  (let (diagnostics)
    (dolist (group (treesit-query-capture
                     (treesit-buffer-root-node)
                     '((group_triple_expr) @g) nil nil t))
      (let ((by-predicate (make-hash-table :test #'equal)))
        (dolist (element (treesit-node-children group))
          (when (and (equal (treesit-node-field-name element) "element")
                     (string= (treesit-node-type element) "triple_constraint"))
            (when-let* ((pred (treesit-node-child-by-field-name element "predicate")))
              (push element (gethash (treesit-node-text pred t) by-predicate)))))
        (maphash
         (lambda (predicate-text elements)
           (when (cdr elements)
             (dolist (element elements)
               (let ((pred (treesit-node-child-by-field-name element "predicate")))
                 (push (flymake-make-diagnostic
                        (current-buffer)
                        (treesit-node-start pred) (treesit-node-end pred)
                        :note
                        (format "Predicate %s appears %d times in this group"
                                predicate-text (length elements)))
                       diagnostics)))))
         by-predicate)))
    diagnostics))

;;;###autoload
(defun shexc-ts-mode-flymake (report-fn &rest _args)
  "Flymake backend for `shexc-ts-mode'.

Reports `:error' diagnostics for shape references with no matching
declaration (see `shexc-ts-mode--flymake-undefined-shapes'),
prefixed names with no matching `PREFIX' declaration (see
`shexc-ts-mode--flymake-undefined-prefixes'), and text the parser
could not make sense of (see `shexc-ts-mode--flymake-syntax-errors');
and `:note' diagnostics for predicates repeated within the same
EachOf/OneOf-disjunct group (see
`shexc-ts-mode--flymake-duplicate-predicates').

REPORT-FN is Flymake's callback; see `flymake-diagnostic-functions'."
  (funcall report-fn
           (append (shexc-ts-mode--flymake-undefined-shapes)
                   (shexc-ts-mode--flymake-undefined-prefixes)
                   (shexc-ts-mode--flymake-syntax-errors)
                   (shexc-ts-mode--flymake-duplicate-predicates))))

;;; shex-manifest-browser integration

(defun shexc-ts-mode--manifest-browser-loaded-p ()
  "Return non-nil if the optional `shex-manifest-browser' package is loaded.
I.e. if `shexc-ts-mode-menu' should offer its settings."
  (boundp 'shex-manifest-browser-highlight-extended-predicates))

;;;###autoload
(defun shexc-ts-mode-toggle-manifest-browser-predicates ()
  "Toggle `shex-manifest-browser-highlight-extended-predicates'.

That option controls whether `shex-manifest-browser' also highlights
the predicates of extended shapes (not just their ShapeDecl labels)
when it highlights a manifest entry's schema.  The new value takes
effect the next time `shex-manifest-browser' highlights an entry."
  (interactive)
  (unless (shexc-ts-mode--manifest-browser-loaded-p)
    (user-error "Package `shex-manifest-browser' is not loaded"))
  (setq shex-manifest-browser-highlight-extended-predicates
        (not shex-manifest-browser-highlight-extended-predicates))
  (message "shex-manifest-browser-highlight-extended-predicates: %s"
           shex-manifest-browser-highlight-extended-predicates))

;;; Feature menu (transient)

(defun shexc-ts-mode--menu-desc (label command)
  "Return LABEL annotated with COMMAND's key binding in `shexc-ts-mode-map'.
For use as a `transient' suffix description."
  (let ((key (where-is-internal command shexc-ts-mode-map t)))
    (if key
        (format "%-36s %s" label (key-description key))
      label)))

(transient-define-prefix shexc-ts-mode-menu ()
  "Feature menu for `shexc-ts-mode', showing live keybindings."
  [["Navigate"
    (:info "C-c C-l          Toggle highlight-reachable-mode on/off")
    ("h" shexc-ts-mode-toggle-highlight-reachable-current
     :description
     (lambda ()
       (format "Highlight current shape (under cursor) [%s]"
               (if shexc-ts-mode-highlight-reachable-include-current "X" " "))))
    ("H" shexc-ts-mode-toggle-highlight-reachable-current-predicates
     :description
     (lambda ()
       (format "Highlight predicates of current shape [%s]"
               (if shexc-ts-mode-highlight-reachable-include-current-predicates "X" " "))))
    ("e" shexc-ts-mode-toggle-highlight-reachable-non-extended
     :description
     (lambda ()
       (format "Highlight shapes reachable from current shape [%s]"
               (if shexc-ts-mode-highlight-reachable-include-non-extended "X" " "))))
    ("E" shexc-ts-mode-toggle-highlight-reachable-non-extended-predicates
     :description
     (lambda ()
       (format "Highlight predicates of reachable shapes [%s]"
               (if shexc-ts-mode-highlight-reachable-include-non-extended-predicates "X" " "))))
    ("x" shexc-ts-mode-toggle-highlight-reachable-extended
     :description
     (lambda ()
       (format "Highlight shapes extended by current shape [%s]"
               (if shexc-ts-mode-highlight-reachable-include-extended "X" " "))))
    ("X" shexc-ts-mode-toggle-highlight-reachable-extended-predicates
     :description
     (lambda ()
       (format "Highlight predicates of extended shapes [%s]"
               (if shexc-ts-mode-highlight-reachable-include-extended-predicates "X" " "))))
    ("f" shexc-ts-mode-toggle-fold
     :description
     (lambda () (shexc-ts-mode--menu-desc
                 "Fold/unfold shape body at point"
                 'shexc-ts-mode-toggle-fold)))
    (:info "C-M-a / C-M-e    Previous/next shape declaration")
    (:info "C-M-f / C-M-b    Forward/backward over a shape branch")
    (:info "M-. / M-, / M-?  Go to / pop back from / find refs to shape")]
   ["Edit"
    ("u" shexc-ts-mode-unwrap-shape
     :description
     (lambda () (shexc-ts-mode--menu-desc
                 "Unwrap `<predicate> { ... }' shape"
                 'shexc-ts-mode-unwrap-shape)))
    ("w" shexc-ts-mode-wrap-in-shape
     :description
     (lambda () (shexc-ts-mode--menu-desc
                 "Wrap region in `<predicate> { ... }'"
                 'shexc-ts-mode-wrap-in-shape)))
    ("r" shexc-ts-mode-rename-shape
     :description
     (lambda () (shexc-ts-mode--menu-desc
                 "Rename shape label everywhere"
                 'shexc-ts-mode-rename-shape)))
    ("k" shexc-ts-mode-toggle-comment-style
     :description
     (lambda () (shexc-ts-mode--menu-desc
                 "Toggle `#' / `/* */' comment style"
                 'shexc-ts-mode-toggle-comment-style)))
    ("P" shexc-ts-mode-insert-prefix
     :description
     (lambda ()
       (shexc-ts-mode--menu-desc
        (format "Insert `PREFIX' for prefix at point (%s map)"
                shexc-ts-mode-prefix-map)
        'shexc-ts-mode-insert-prefix)))
    ("M" shexc-ts-mode-set-prefix-map
     :description
     (lambda ()
       (shexc-ts-mode--menu-desc
        (format "Switch active prefix map (currently %s)"
                shexc-ts-mode-prefix-map)
        'shexc-ts-mode-set-prefix-map)))]
   ["Manifest browser"
    :if shexc-ts-mode--manifest-browser-loaded-p
    ("p" shexc-ts-mode-toggle-manifest-browser-predicates
     :description
     (lambda ()
       (format "Also highlight extended shapes' predicates [%s]"
               (if shex-manifest-browser-highlight-extended-predicates
                   "X" " "))))]])

;;; Major mode

;;;###autoload
(define-derived-mode shexc-ts-mode prog-mode "ShEx[ts]"
  "Major mode for editing ShExC documents, powered by tree-sitter.

\\{shexc-ts-mode-map}"
  :syntax-table shexc-ts-mode--syntax-table
  (unless (treesit-ready-p 'shexc)
    (error "Tree-sitter grammar for `shexc' is not available -- \
see the Setup section in shexc-ts-mode.el"))

  (treesit-parser-create 'shexc)

  ;; disambiguate `#' as comment-starter vs. in-IRI fragment separator
  ;; (see `shexc-ts-mode--syntax-propertize')
  (setq-local syntax-propertize-function #'shexc-ts-mode--syntax-propertize)

  ;; comments: "# ..." (default) or "/* ... */" (see
  ;; `shexc-ts-mode-toggle-comment-style', bound to `C-c C-k' as in
  ;; `c-ts-mode'). The skip regexps recognize *both* styles so that
  ;; `comment-dwim'/`uncomment-region' can find and remove existing
  ;; comments regardless of which style is currently active.
  (setq-local comment-start "# ")
  (setq-local comment-end "")
  (setq-local comment-start-skip (rx (or (+ "#") (seq "/" (+ "*")))
                                     (* (syntax whitespace))))
  (setq-local comment-end-skip
              (rx (* (syntax whitespace))
                  (group (or (syntax comment-end)
                             (seq (+ "*") "/")))))
  (setq-local comment-multi-line t)
  (define-key shexc-ts-mode-map [remap comment-dwim] #'shexc-ts-mode-comment-dwim)
  (define-key shexc-ts-mode-map (kbd "C-c C-k") #'shexc-ts-mode-toggle-comment-style)

  ;; structural editing: unwrap/wrap/rename `<predicate> { ... }' shapes
  (define-key shexc-ts-mode-map (kbd "C-c C-u") #'shexc-ts-mode-unwrap-shape)
  (define-key shexc-ts-mode-map (kbd "C-c C-w") #'shexc-ts-mode-wrap-in-shape)
  (define-key shexc-ts-mode-map (kbd "C-c C-r") #'shexc-ts-mode-rename-shape)

  ;; insert a `PREFIX' declaration for the prefix at point, looked up
  ;; in the active `shexc-ts-mode-prefix-map'
  (define-key shexc-ts-mode-map (kbd "C-c C-p") #'shexc-ts-mode-insert-prefix)

  ;; live "germane shapes" highlighting, following point
  (define-key shexc-ts-mode-map (kbd "C-c C-l") #'shexc-ts-mode-highlight-reachable-mode)

  ;; folding `{ ... }' shape bodies
  (define-key shexc-ts-mode-map (kbd "C-c C-f") #'shexc-ts-mode-toggle-fold)
  (hs-minor-mode 1)

  ;; Magit-style feature menu
  (define-key shexc-ts-mode-map (kbd "C-c C-c") #'shexc-ts-mode-menu)

  ;; indentation
  (setq-local treesit-simple-indent-rules shexc-ts-mode--indent-rules)
  (setq-local indent-tabs-mode nil)
  (setq-local electric-indent-chars
              (append '(?\{ ?\} ?\[ ?\] ?\( ?\)) electric-indent-chars))

  ;; font-lock
  (setq-local treesit-font-lock-settings shexc-ts-mode--font-lock-settings)
  (setq-local treesit-font-lock-feature-list shexc-ts-mode--font-lock-feature-list)

  ;; imenu
  (setq-local treesit-simple-imenu-settings shexc-ts-mode--imenu-settings)

  ;; navigation: structural defun-nav (`C-M-a'/`C-M-e') over
  ;; `shape_expr_decl's, and smart sexp (`C-M-f'/`C-M-b', `C-M-t',
  ;; `kill-sexp', etc.) over shape-expression/triple-expression
  ;; branches -- see `shexc-ts-mode--sexp-node-types'.
  (setq-local treesit-thing-settings
              `((shexc
                 (defun "\\`shape_expr_decl\\'")
                 (sexp ,(concat "\\`"
                                 (regexp-opt shexc-ts-mode--sexp-node-types)
                                 "\\'")))))

  ;; breadcrumb: `add-log-current-defun'/`which-function-mode' show
  ;; "<Shape> > predicate > ..." for point's position
  (setq-local add-log-current-defun-function #'shexc-ts-mode--current-defun-name)

  ;; following shape references
  (add-hook 'xref-backend-functions #'shexc-ts-mode--xref-backend nil t)

  ;; diagnostics: undefined shape references and duplicate predicates
  (add-hook 'flymake-diagnostic-functions #'shexc-ts-mode-flymake nil t)
  (flymake-mode 1)

  (treesit-major-mode-setup))

;; Prefer the tree-sitter mode for .shex(c) files when its grammar is
;; available; `shexc-mode' remains the fallback otherwise.  `require'
;; `treesit' first since this form runs from the autoloads file, before
;; `treesit-ready-p' would otherwise be defined.
;;;###autoload
(progn
  (require 'treesit)
  (when (treesit-ready-p 'shexc t)
    (add-to-list 'auto-mode-alist '("\\.shexc?\\'" . shexc-ts-mode))))

(provide 'shexc-ts-mode)

;;; shexc-ts-mode.el ends here
