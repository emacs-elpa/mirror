;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-autotag" "0.1.2"
  "Easy auto-tagging for elfeed."
  '((emacs           "27.1")
    (elfeed          "3.4.1")
    (elfeed-protocol "0.8.0")
    (org             "8.2.7")
    (dash            "2.10.0")
    (s               "1.9.0"))
  :url "https://github.com/paulelms/elfeed-autotag"
  :commit "bc62c37fb79b720ff8b6d67f04f2268841306dcd"
  :revdesc "bc62c37fb79b"
  :keywords '("news")
  :authors '(("Paul Elms" . "https://paul.elms.pro"))
  :maintainers '(("Paul Elms" . "paul@elms.pro")))
