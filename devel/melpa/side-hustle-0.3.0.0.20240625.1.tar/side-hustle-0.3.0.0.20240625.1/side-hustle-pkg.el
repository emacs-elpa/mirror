;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "side-hustle" "0.3.0.0.20240625.1"
  "Hustle through Imenu in a side window."
  '((emacs "24.4")
    (seq   "2.20"))
  :url "https://github.com/rnkn/side-hustle"
  :commit "94450b58cec1b809afe08d0754a6662839efbc9d"
  :revdesc "94450b58cec1"
  :keywords '("convenience")
  :authors '(("Paul W. Rankin" . "rnkn@rnkn.xyz"))
  :maintainers '(("Paul W. Rankin" . "rnkn@rnkn.xyz")))
