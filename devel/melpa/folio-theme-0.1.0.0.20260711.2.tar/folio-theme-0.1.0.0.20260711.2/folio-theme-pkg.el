;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "folio-theme" "0.1.0.0.20260711.2"
  "Warm paper-like theme built on Modus and Ef."
  '((emacs        "28.1")
    (modus-themes "5.0.0")
    (ef-themes    "2.0.0"))
  :url "https://github.com/kn66/folio-theme.el"
  :commit "758ca1f9674d685747d0846160e76bb6cb677a2d"
  :revdesc "0.1.0-2-g758ca1f9674d"
  :keywords '("faces"))
