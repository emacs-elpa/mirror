;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess" "25.1.0.0.20260723.58"
  "Emacs Speaks Statistics."
  '((emacs "25.1"))
  :url "https://ess.r-project.org/"
  :commit "c3960e09f37550d300437c46ca03fb28975378a1"
  :revdesc "v25.01.0-58-gc3960e09f375"
  :authors '(("David Smith" . "dsmith@stats.adelaide.edu.au")
             ("A.J. Rossini" . "blindglobe@gmail.com")
             ("Richard M. Heiberger" . "rmh@temple.edu")
             ("Kurt Hornik" . "Kurt.Hornik@R-project.org")
             ("Martin Maechler" . "maechler@stat.math.ethz.ch")
             ("Rodney A. Sparapani" . "rsparapa@mcw.edu")
             ("Stephen Eglen" . "stephen@gnu.org")
             ("Sebastian P. Luque" . "spluque@gmail.com")
             ("Henning Redestig" . "henning.red@googlemail.com")
             ("Vitalie Spinu" . "spinuvit@gmail.com")
             ("Lionel Henry" . "lionel.hry@gmail.com")
             ("J. Alexander Branham" . "alex.branham@gmail.com"))
  :maintainers '(("ESS Core Team" . "ESS-core@r-project.org")))
