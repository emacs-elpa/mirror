;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "1.2.1.0.20260710.6"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "fc469061a294a2a9888736d9b9c4ff9b9e6971ce"
  :revdesc "1.2.1-6-gfc469061a294"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
