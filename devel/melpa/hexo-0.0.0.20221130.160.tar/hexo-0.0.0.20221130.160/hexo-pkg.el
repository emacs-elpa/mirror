;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hexo" "0.0.0.20221130.160"
  "Major mode & tools for Hexo."
  '((emacs "24.3"))
  :url "https://github.com/kuanyui/hexo.el"
  :commit "709c069ec0f9ffd8bc2f8fff18a66d80bc205f6d"
  :revdesc "709c069ec0f9"
  :keywords '("tools" "hexo")
  :authors '(("Ono Hiroko" . "azazabc123@gmail.com"))
  :maintainers '(("Ono Hiroko" . "azazabc123@gmail.com")))
