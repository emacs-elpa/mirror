;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "2.1.2.0.20260906.4"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "8047ceebe9cc18e2fb3daa2e0ac15669851c480f"
  :revdesc "8047ceebe9cc"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
