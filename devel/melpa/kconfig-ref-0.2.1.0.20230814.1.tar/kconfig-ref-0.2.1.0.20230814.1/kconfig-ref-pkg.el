;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kconfig-ref" "0.2.1.0.20230814.1"
  "A simple package for looking up kconfig symbol quickly."
  '((emacs      "24.4")
    (projectile "2.7.0")
    (emacsql    "0"))
  :url "https://github.com/seokbeomkim/kconfig-ref"
  :commit "a3f602032cd3b9a7167505bd8ad0f156ae34c0b8"
  :revdesc "a3f602032cd3"
  :keywords '("tools" "kconfig" "linux" "kernel")
  :authors '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainers '(("Jason Kim" . "sukbeom.kim@gmail.com")))
