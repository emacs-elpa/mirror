;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "expenses" "0.2.0.0.20230903.18"
  "Record and view expenses."
  '((emacs "28.1")
    (dash  "2.19.1")
    (ht    "2.3"))
  :url "https://github.com/md-arif-shaikh/expenses"
  :commit "1c89ed3969fef7d733a0f52084cfe07d33200104"
  :revdesc "1c89ed3969fe"
  :keywords '("expense tracking" "convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
