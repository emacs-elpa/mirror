;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-uuid-mode" "0.0.3"
  "Minor mode for previewing time uuids as an overlay."
  '((emacs "27.1"))
  :url "https://github.com/RobertPlant/time-uuid-mode"
  :commit "54f7fc6093163b88042fa7dbaa33f32a35709290"
  :revdesc "54f7fc609316"
  :keywords '("extensions" "convenience" "data" "tools")
  :authors '(("Robert Plant" . "rob@robertplant.io"))
  :maintainers '(("Robert Plant" . "rob@robertplant.io")))
