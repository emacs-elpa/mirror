;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "0.1.0.0.20260929.7"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "fb7a22f6dd61ab81be9b992716c27ac590cb5920"
  :revdesc "v0.1.0-7-gfb7a22f6dd61"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
