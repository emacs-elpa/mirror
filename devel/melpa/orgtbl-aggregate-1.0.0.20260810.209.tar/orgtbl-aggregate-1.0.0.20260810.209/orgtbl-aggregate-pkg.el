;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "1.0.0.20260810.209"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "cc777562bf11a597252cc43b8d1c9fec2baa7288"
  :revdesc "cc777562bf11"
  :keywords '("data" "extensions"))
