;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "2.7.0.0.20260809.1"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (md-ts-mode          "0.3.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "a7b533fb8ab5a5e2fabb6c925ad2d7385456c1bd"
  :revdesc "v2.7.0-1-ga7b533fb8ab5"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
