;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pkgbuild-mode" "0.14.0.20261011.74"
  "Interface to the Arch Linux package manager."
  '((emacs "26.1"))
  :url "https://github.com/juergenhoetzel/pkgbuild-mode"
  :commit "e0f326bb240dc3e2253eff96d29a445512bacaaf"
  :revdesc "e0f326bb240d"
  :keywords '("languages")
  :authors '(("Juergen Hoetzel" . "juergen@hoetzel.info"))
  :maintainers '(("Juergen Hoetzel" . "juergen@hoetzel.info")))
