;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.0.0.20260624.14"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "2330740b43cd68063499a8e71b9b07e66dc74082"
  :revdesc "2330740b43cd"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
