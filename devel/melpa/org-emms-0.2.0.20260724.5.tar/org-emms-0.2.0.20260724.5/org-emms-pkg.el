;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-emms" "0.2.0.20260724.5"
  "Playback multimedia files from Org documents."
  '((emacs "24.1")
    (org   "9.3")
    (emms  "0.0"))
  :url "https://git.sr.ht/~jagrg/org-emms"
  :commit "6f25e8b185ba5df4b06b2cbc48cc644c2b7eed78"
  :revdesc "6f25e8b185ba"
  :keywords '("multimedia")
  :authors '(("Jonathan Gregory" . "jgrgatautisticidotorg"))
  :maintainers '(("Jonathan Gregory" . "jgrgatautisticidotorg")))
