;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-notes" "0.9"
  "Manage notes with consult."
  '((emacs   "28.1")
    (consult "1.0"))
  :url "https://codeberg.org/mclear-tools/consult-notes"
  :commit "4a9b7e2990fa9c9be0df482c2342d24bf9ddc32a"
  :revdesc "0.9-0-g4a9b7e2990fa"
  :keywords '("convenience")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
