;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-tutor-sc" "2.2.0.20240326.4"
  "Simplified Chinese tutor for Evil."
  '((evil       "1.0.9")
    (evil-tutor "0.1"))
  :url "https://github.com/clsty/evil-tutor-sc"
  :commit "9520aae3e10480a942c35ae83f7215086fee9412"
  :revdesc "9520aae3e104"
  :keywords '("convenience" "editing" "evil" "chinese")
  :authors '(("clsty" . "celestial.y@outlook.com"))
  :maintainers '(("clsty" . "celestial.y@outlook.com")))
