;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-random-todo" "0.5.3.0.20190214.1"
  "Show a random TODO (with alert) every so often."
  '((emacs "24.3")
    (alert "1.3"))
  :url "https://github.com/unhammer/org-random-todo"
  :commit "4f7677af740e8f3f7cfaf630ae2e594a125af760"
  :revdesc "0.5.3-1-g4f7677af740e"
  :keywords '("org" "todo" "notification" "calendar")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
