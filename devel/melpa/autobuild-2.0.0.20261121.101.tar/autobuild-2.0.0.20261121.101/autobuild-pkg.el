;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autobuild" "2.0.0.20261121.101"
  "Define and execute build rules and compilation pipelines."
  '((emacs "26.1"))
  :url "https://github.com/erjoalgo/autobuild"
  :commit "f764799a706cc4dcbf09e581296a3a494b18da81"
  :revdesc "v2.0-101-gf764799a706c"
  :keywords '("compile" "build" "pipeline" "autobuild" "extensions" "processes" "tools")
  :maintainers '(("concat \"erjoalgo\" \"@\" \"gmail\" \".com\"" . "")))
