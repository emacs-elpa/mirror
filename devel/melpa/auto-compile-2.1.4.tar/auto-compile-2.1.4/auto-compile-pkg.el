;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-compile" "2.1.4"
  "Automatically compile Emacs Lisp libraries."
  '((emacs "28.1"))
  :url "https://github.com/emacscollective/auto-compile"
  :commit "4db3a0e497feecc8b3dbeeefacdf363ae60a6392"
  :revdesc "v2.1.4-0-g4db3a0e497fe"
  :keywords '("compile" "convenience" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev")))
