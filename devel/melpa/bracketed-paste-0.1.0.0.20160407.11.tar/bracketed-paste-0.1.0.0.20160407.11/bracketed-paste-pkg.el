;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bracketed-paste" "0.1.0.0.20160407.11"
  "Bracketed paste mode support within emacs -nw."
  '((emacs "24.3"))
  :url "https://github.com/hchbaw/bracketed-paste.el"
  :commit "843ce3bbb63d560face889e13a57a2f7543957d5"
  :revdesc "843ce3bbb63d"
  :keywords '("terminals")
  :authors '(("Takeshi Banse" . "takebi@laafc.net"))
  :maintainers '(("Takeshi Banse" . "takebi@laafc.net")))
