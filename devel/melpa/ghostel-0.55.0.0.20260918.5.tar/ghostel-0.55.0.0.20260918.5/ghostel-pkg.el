;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.55.0.0.20260918.5"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "67f43b3e83c15eface911389a291b08fb8311475"
  :revdesc "67f43b3e83c1"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
