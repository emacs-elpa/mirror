;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wsd-mode" "0.5.0.0.20191031.12"
  "Emacs major-mode for www.websequencediagrams.com."
  ()
  :url "https://github.com/josteink/wsd-mode"
  :commit "44aac55afb57cb540559aa1015f9ad2d770dd5c8"
  :revdesc "44aac55afb57"
  :keywords '("wsd" "diagrams" "design" "process" "modelling" "uml")
  :authors '(("Jostein Kjønigsen" . "jostein@gmail.com"))
  :maintainers '(("Jostein Kjønigsen" . "jostein@gmail.com")))
