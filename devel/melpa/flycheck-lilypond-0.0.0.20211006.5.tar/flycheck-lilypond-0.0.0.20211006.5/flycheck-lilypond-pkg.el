;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-lilypond" "0.0.0.20211006.5"
  "LilyPond support in Flycheck."
  '((emacs    "24.3")
    (flycheck "0.22"))
  :url "https://github.com/hinrik/flycheck-lilypond"
  :commit "78f8c16cd67f9f6d3f1806e1fd403222723ba400"
  :revdesc "78f8c16cd67f"
  :keywords '("tools" "convenience")
  :authors '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com"))
  :maintainers '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com")))
