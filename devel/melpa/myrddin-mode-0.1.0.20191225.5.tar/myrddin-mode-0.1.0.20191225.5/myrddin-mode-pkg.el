;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "myrddin-mode" "0.1.0.20191225.5"
  "Major mode for editing Myrddin source files."
  '((emacs "24.3"))
  :url "https://git.sr.ht/~jakob/myrddin-mode"
  :commit "51c0a2cb9dfc9526cd47e71313f5a745c99cadcc"
  :revdesc "v0.1-5-g51c0a2cb9dfc"
  :keywords '("languages")
  :authors '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org"))
  :maintainers '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org")))
