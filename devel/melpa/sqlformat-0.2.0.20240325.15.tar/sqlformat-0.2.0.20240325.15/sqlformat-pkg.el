;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sqlformat" "0.2.0.20240325.15"
  "Reformat SQL using sqlformat or pgformatter."
  '((emacs       "24.3")
    (reformatter "0.3"))
  :url "https://github.com/purcell/sqlformat"
  :commit "f1c8f864f11f4af65551de445dcf65543be0583b"
  :revdesc "f1c8f864f11f"
  :keywords '("languages")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
