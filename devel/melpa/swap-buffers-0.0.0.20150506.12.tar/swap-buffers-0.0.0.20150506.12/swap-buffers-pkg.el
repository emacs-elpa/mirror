;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swap-buffers" "0.0.0.20150506.12"
  "The quickest way to swap buffers between windows. Based on switch-window package."
  ()
  :url "https://github.com/ekazakov/swap-buffers"
  :commit "46ab31359b70d935add6c6e9533443116dc51103"
  :revdesc "46ab31359b70"
  :keywords '("window" "swap" "buffer" "exchange")
  :authors '(("Evgeniy Kazakov" . "evgeniy.kazakov@gmail.com"))
  :maintainers '(("Evgeniy Kazakov" . "evgeniy.kazakov@gmail.com")))
