;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-autofmt" "0.1.0.20260810.410"
  "Emacs lisp auto-format."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt"
  :commit "dab25d90afd70d5adacac37d52ada160a25c5062"
  :revdesc "dab25d90afd7"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
