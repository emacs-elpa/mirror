;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scopeline" "0.1.0.20250120.40"
  "Show scope info of blocks in buffer at end of scope."
  '((emacs "29.1"))
  :url "https://github.com/meain/scopeline.el"
  :commit "5f2cd5aad329190ee3dc56d8003fc957dd65f211"
  :revdesc "5f2cd5aad329"
  :keywords '("scope" "context" "tree-sitter" "convenience"))
