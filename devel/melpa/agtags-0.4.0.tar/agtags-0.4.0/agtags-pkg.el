;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agtags" "0.4.0"
  "A frontend to GNU Global."
  '((emacs "25"))
  :url "https://github.com/vietor/agtags"
  :commit "afb45864557fe08570ee26b7bc7bf9197a6a7538"
  :revdesc "afb45864557f"
  :keywords '("tools" "convenience")
  :authors '(("Vietor Liu" . "vietor.liu@gmail.com"))
  :maintainers '(("Vietor Liu" . "vietor.liu@gmail.com")))
