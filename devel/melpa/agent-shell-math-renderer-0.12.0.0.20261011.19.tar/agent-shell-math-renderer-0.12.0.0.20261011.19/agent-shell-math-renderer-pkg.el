;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.12.0.0.20261011.19"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.66.1")
    (latex-to-svg-backend "0.14.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "4e89bd75539c42310042bd299f849bcdfde9c572"
  :revdesc "v0.12.0-19-g4e89bd75539c"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
