;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "1.9.2.0.20261013.2"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "fe0adc238f3ddd92422013a3cc39af2733924208"
  :revdesc "v1.9.2-2-gfe0adc238f3d"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
