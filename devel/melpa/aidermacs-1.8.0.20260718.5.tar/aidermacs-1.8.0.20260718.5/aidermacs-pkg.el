;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "1.8.0.20260718.5"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "6b805bdaa11c754e5bbfee7a3cc39fbae835b39b"
  :revdesc "6b805bdaa11c"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
