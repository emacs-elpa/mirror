;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-irony" "1.1.1"
  "Company-mode completion back-end for irony-mode."
  '((emacs   "24.1")
    (company "0.8.0")
    (irony   "1.1.0")
    (cl-lib  "0.5"))
  :url "https://github.com/Sarcasm/company-irony/"
  :commit "9ca8f35ef268c0b0cffd49efa687685b373f09fe"
  :revdesc "v1.1.1-0-g9ca8f35ef268"
  :keywords '("convenience")
  :authors '(("Guillaume Papin" . "guillaume.papin@epitech.eu"))
  :maintainers '(("Guillaume Papin" . "guillaume.papin@epitech.eu")))
