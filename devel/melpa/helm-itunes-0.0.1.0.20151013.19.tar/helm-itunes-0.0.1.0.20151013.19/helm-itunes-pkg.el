;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-itunes" "0.0.1.0.20151013.19"
  "Play local iTunes and Spotify tracks."
  '((helm "1.6.1"))
  :url "https://github.com/daschwa/helm-itunes"
  :commit "966de755a5aadbe02311a6cef77bd4790e84c263"
  :revdesc "966de755a5aa"
  :authors '(("Adam Schwartz" . "adam@adamschwartz.io"))
  :maintainers '(("Adam Schwartz" . "adam@adamschwartz.io")))
