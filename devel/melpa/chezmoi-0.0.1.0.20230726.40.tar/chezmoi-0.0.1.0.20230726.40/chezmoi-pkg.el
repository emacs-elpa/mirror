;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chezmoi" "0.0.1.0.20230726.40"
  "A package for interacting with chezmoi."
  '((emacs "26.1"))
  :url "http://www.github.com/tuh8888/chezmoi.el"
  :commit "1389782f8c0780c7e66f8e77b10345ba1f4eabae"
  :revdesc "1389782f8c07"
  :keywords '("vc"))
