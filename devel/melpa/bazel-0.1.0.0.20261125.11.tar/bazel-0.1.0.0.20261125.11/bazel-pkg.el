;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.1.0.0.20261125.11"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "da396d291a02a498a0e8acbc88de42083d509965"
  :revdesc "da396d291a02"
  :keywords '("build tools" "languages"))
