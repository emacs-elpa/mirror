;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-deno" "3.0.0.0.20260213.2"
  "Babel Functions for Javascript/TypeScript with Deno."
  '((emacs "29.1"))
  :url "https://github.com/isamert/ob-deno"
  :commit "77beef624ff21a3ee0b69b61265b427205b8031e"
  :revdesc "77beef624ff2"
  :keywords '("literate programming" "reproducible research" "javascript" "typescript" "tools" "deno"))
