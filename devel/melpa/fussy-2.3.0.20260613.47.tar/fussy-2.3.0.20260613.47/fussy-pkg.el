;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "2.3.0.20260613.47"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "78730ceefb23ee6314803f54eaf73cb044055f47"
  :revdesc "78730ceefb23"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
