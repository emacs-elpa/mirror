;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.1.5.0.20260826.11"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "11ff03c676b439b2267d65ddfe1e897232451b02"
  :revdesc "1.1.5-11-g11ff03c676b4"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
