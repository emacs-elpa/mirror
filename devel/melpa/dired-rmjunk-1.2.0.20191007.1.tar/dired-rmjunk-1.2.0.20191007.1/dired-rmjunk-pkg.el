;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-rmjunk" "1.2.0.20191007.1"
  "A home directory cleanup utility for Dired."
  ()
  :url "https://git.sr.ht/~jakob/dired-rmjunk"
  :commit "0e890a41fa680a45b4b4aad2c28f9d6dca999cee"
  :revdesc "v1.2-1-g0e890a41fa68"
  :keywords '("files" "matching")
  :authors '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org"))
  :maintainers '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org")))
