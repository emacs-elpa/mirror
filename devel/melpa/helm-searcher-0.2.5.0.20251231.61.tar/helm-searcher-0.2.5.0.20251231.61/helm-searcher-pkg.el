;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-searcher" "0.2.5.0.20251231.61"
  "Helm interface to use searcher."
  '((emacs    "25.1")
    (helm     "2.0")
    (searcher "0.1.8"))
  :url "https://github.com/emacs-helm/helm-searcher"
  :commit "f81955c7197cdaaf96e4b643f1946d54912d6b8a"
  :revdesc "f81955c7197c"
  :keywords '("convenience" "replace" "grep" "ag" "rg")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
