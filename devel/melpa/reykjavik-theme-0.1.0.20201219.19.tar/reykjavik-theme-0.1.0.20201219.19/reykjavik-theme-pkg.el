;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reykjavik-theme" "0.1.0.20201219.19"
  "Theme with a dark background."
  '((emacs "24"))
  :url "https://github.com/mswift42/reykjavik-theme"
  :commit "f6d8e83946633603234cd1dac725e17447f40bce"
  :revdesc "f6d8e8394663")
