;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lingva" "0.2.0.20250208.20"
  "Access Google Translate without tracking via lingva.ml."
  '((emacs "25.1"))
  :url "https://codeberg.org/martianh/lingva.el"
  :commit "de11bdbd90c73106ce272e60ac030d2a9a2d5f5b"
  :revdesc "de11bdbd90c7"
  :keywords '("convenience" "translation" "wp" "text")
  :authors '(("marty hiatt" . "mousebot@disroot.org"))
  :maintainers '(("marty hiatt" . "mousebot@disroot.org")))
