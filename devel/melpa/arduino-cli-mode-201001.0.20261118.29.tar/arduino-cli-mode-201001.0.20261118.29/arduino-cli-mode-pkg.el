;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arduino-cli-mode" "201001.0.20261118.29"
  "Arduino-CLI command wrapper."
  '((emacs "25.1"))
  :url "https://github.com/motform/arduino-cli-mode"
  :commit "f7216a5c025e0ef7e1a1f4e7be880deddc9c93ae"
  :revdesc "f7216a5c025e"
  :keywords '("processes" "tools"))
