;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3.0.20261118.148"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "d1f3898d60fdddcc42581d1b4c3e1068580f065f"
  :revdesc "d1f3898d60fd"
  :keywords '("build tools" "languages"))
