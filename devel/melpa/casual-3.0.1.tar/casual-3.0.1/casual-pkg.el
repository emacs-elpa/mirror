;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "3.0.1"
  "Transient user interfaces for various modes."
  '((emacs     "30.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "4360a3f8bd8dc775bd1c41a0fb26f2397785ad7f"
  :revdesc "4360a3f8bd8d"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
