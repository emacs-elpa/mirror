;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org2blog" "1.1.19"
  "Blog from Org mode to WordPress."
  '((emacs          "30.2")
    (htmlize        "1.59")
    (hydra          "0.15.0")
    (xml-rpc        "1.6.15")
    (writegood-mode "2.2.0")
    (metaweblog     "1.1.19"))
  :url "https://github.com/org2blog/org2blog"
  :commit "c3abdd9a518554d62ff2ba3ffd1fd18f37a24e24"
  :revdesc "v1.1.19-0-gc3abdd9a5185"
  :keywords '("comm" "convenience" "outlines" "wp")
  :authors '(("Puneeth Chaganti" . "punchagan+org2blog@gmail.com"))
  :maintainers '(("Grant Rettke" . "grant@wisdomandwonder.com")))
