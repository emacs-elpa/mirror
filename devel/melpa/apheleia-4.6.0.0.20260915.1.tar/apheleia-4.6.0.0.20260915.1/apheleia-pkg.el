;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "4.6.0.0.20260915.1"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "71b732239d69e48a7f31bbd65a88cfa3734a3959"
  :revdesc "71b732239d69"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
