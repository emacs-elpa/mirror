;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "0.1.0.0.20261115.16"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "730b6910ac5a394a08466c854f41ebfb89dc0327"
  :revdesc "v0.1.0-16-g730b6910ac5a"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
