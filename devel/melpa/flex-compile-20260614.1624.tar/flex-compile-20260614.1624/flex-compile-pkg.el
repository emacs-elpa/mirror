;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-compile" "20260614.1624"
  "Run, evaluate and compile across many languages."
  '((emacs         "26.1")
    (dash          "2.17.0")
    (buffer-manage "1.1"))
  :url "https://github.com/plandes/flex-compile"
  :commit "c2e3e1243e04c387e07db6bee52566f7aa534c89"
  :revdesc "c2e3e1243e04"
  :keywords '("compilation" "integration" "processes"))
