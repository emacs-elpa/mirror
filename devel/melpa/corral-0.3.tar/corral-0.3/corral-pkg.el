;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corral" "0.3"
  "Quickly surround text with delimiters."
  ()
  :url "https://github.com/nivekuil/corral"
  :commit "e7ab6aa118e46b93d4933d1364bc273f57cd6911"
  :revdesc "e7ab6aa118e4"
  :authors '(("Kevin Liu" . "mail@nivekuil.com"))
  :maintainers '(("Kevin Liu" . "mail@nivekuil.com")))
