;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-auto-commit" "0.1.0.20210216.12"
  "Auto-committing feature for your repository."
  ()
  :url "https://github.com/thisirs/vc-auto-commit.git"
  :commit "56f478016a541b395092a9d3cdc0da84a37b30a1"
  :revdesc "56f478016a54"
  :keywords '("vc" "convenience")
  :authors '(("Sylvain Rousseau" . "thisirsatgmaildotcom"))
  :maintainers '(("Sylvain Rousseau" . "thisirsatgmaildotcom")))
