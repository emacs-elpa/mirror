;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-auto-readme" "1.0.1.0.20250726.1"
  "Auto-display README file in Dired buffers."
  '((emacs         "29.1")
    (markdown-mode "2.5"))
  :url "https://github.com/amno1/dired-auto-readme"
  :commit "d1cced1a5cf26ff50a8c1585b6e6813a3ddb8395"
  :revdesc "d1cced1a5cf2"
  :keywords '("tools" "convenience"))
