;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ref-prettify" "0.2.0.20220507.9"
  "Prettify org-ref citation links."
  '((emacs             "24.3")
    (org-ref           "3.0")
    (bibtex-completion "1.0.0"))
  :url "https://github.com/alezost/org-ref-prettify.el"
  :commit "0ec3b6e398ee117c8b8a787a0422b95d9e95f7bb"
  :revdesc "0ec3b6e398ee"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com")
             ("Vitus Schäfftlein" . "vitusschaefftlein@live.de"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")
                 ("Vitus Schäfftlein" . "vitusschaefftlein@live.de")))
