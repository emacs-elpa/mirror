;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar" "1.4.0.0.20260921.35"
  "Citation-related commands for org, latex, markdown."
  '((emacs    "29.1")
    (parsebib "4.2")
    (org      "9.5")
    (citeproc "0.9"))
  :url "https://github.com/emacs-citar/citar"
  :commit "a8be76d04f4343776afef77154bf6bda4a696b5f"
  :revdesc "v1.4.0-35-ga8be76d04f43"
  :authors '(("Bruce D'Arcus" . "https://github.com/bdarcus"))
  :maintainers '(("Bruce D'Arcus" . "https://github.com/bdarcus")))
