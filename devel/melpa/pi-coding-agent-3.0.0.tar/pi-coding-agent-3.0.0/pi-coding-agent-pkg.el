;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "3.0.0"
  "Deprecated aliases for piem."
  '((emacs "29.1"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "128cad878db839f732a41442f9d52f160c27a197"
  :revdesc "v3.0.0-0-g128cad878db8")
