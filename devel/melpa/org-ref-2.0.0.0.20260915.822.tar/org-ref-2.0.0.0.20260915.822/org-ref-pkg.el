;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ref" "2.0.0.0.20260915.822"
  "Citations, cross-references and bibliographies in org-mode."
  '((org               "9.4")
    (htmlize           "0")
    (transient         "0")
    (avy               "0")
    (parsebib          "0")
    (bibtex-completion "0")
    (citeproc          "0")
    (ox-pandoc         "0")
    (request           "0"))
  :url "https://github.com/jkitchin/org-ref"
  :commit "734b232df60fe0f1eb5567825c57c203bff8c217"
  :revdesc "v2.0.0-822-g734b232df60f"
  :keywords '("org-mode" "cite" "ref" "label")
  :authors '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainers '(("John Kitchin" . "jkitchin@andrew.cmu.edu")))
