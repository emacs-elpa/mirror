;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "1.2.5.0.20260730.13"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "bd25830791dfc072b61733b9d7f126e777f9e443"
  :revdesc "1.2.5-13-gbd25830791df"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
