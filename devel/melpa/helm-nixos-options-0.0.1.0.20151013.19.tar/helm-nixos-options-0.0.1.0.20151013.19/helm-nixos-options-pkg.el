;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-nixos-options" "0.0.1.0.20151013.19"
  "Helm Interface for nixos-options."
  '((nixos-options "0.0.1")
    (helm          "1.5.6"))
  :url "http://www.github.com/travisbhartwell/nix-emacs/"
  :commit "f7709bb007ebafb4d6b32778c7764e2c44e0420d"
  :revdesc "f7709bb007eb"
  :keywords '("unix")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com")
             ("Travis B. Hartwell" . "nafai@travishartwell.net"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")
                 ("Travis B. Hartwell" . "nafai@travishartwell.net")))
