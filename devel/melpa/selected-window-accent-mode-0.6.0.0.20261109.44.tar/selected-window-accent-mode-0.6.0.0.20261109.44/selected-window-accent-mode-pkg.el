;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-accent-mode" "0.6.0.0.20261109.44"
  "Accent Selected Window."
  '((emacs "29.1"))
  :url "https://github.com/captainflasmr/selected-window-accent-mode"
  :commit "aba05f98db93427a1434de0f78ab3430c1c535e1"
  :revdesc "aba05f98db93"
  :keywords '("convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
