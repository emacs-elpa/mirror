;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "roseline-theme" "1.0.0.20250305.19"
  "Roseline theme."
  '((emacs "24.1"))
  :url "https://github.com/madara123pain/unique-emacs-theme-pack"
  :commit "43afeb68b3ba0394f8cc925ebb90e9a6620b4b28"
  :revdesc "43afeb68b3ba"
  :keywords '("faces" "theme" "custom")
  :authors '(("Omer Arif" . "omerarifkhan.official123@gmail.com"))
  :maintainers '(("Omer Arif" . "omerarifkhan.official123@gmail.com")))
