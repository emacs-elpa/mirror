;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-sort-mtime" "0.5"
  "Sort Ido's file list by modification time."
  ()
  :url "https://github.com/pkkm/ido-sort-mtime"
  :commit "f638ff0c922af862f5211779f2311a27fde428eb"
  :revdesc "f638ff0c922a"
  :keywords '("convenience" "files"))
