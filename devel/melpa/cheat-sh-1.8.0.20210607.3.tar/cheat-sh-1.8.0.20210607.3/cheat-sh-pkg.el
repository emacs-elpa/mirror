;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cheat-sh" "1.8.0.20210607.3"
  "Interact with cheat.sh."
  '((emacs "25.1"))
  :url "https://github.com/davep/cheat-sh.el"
  :commit "33bae22feae8d3375739c6bdef08d0dcdf47ee42"
  :revdesc "33bae22feae8"
  :keywords '("docs" "help")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
