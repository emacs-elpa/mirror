;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jwt" "0.2.0.0.20260514.4"
  "Interact with JSON Web Tokens."
  '((emacs "29.1"))
  :url "https://github.com/joshbax189/jwt-el"
  :commit "83bcef37c311645a07c0263007c5b962ca3dab15"
  :revdesc "83bcef37c311"
  :keywords '("tools" "convenience"))
