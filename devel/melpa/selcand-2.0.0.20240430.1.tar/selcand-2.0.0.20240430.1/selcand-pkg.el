;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selcand" "2.0.0.20240430.1"
  "Select a candidate from a tree of hint characters."
  '((emacs "25.1"))
  :url "https://github.com/erjoalgo/selcand"
  :commit "6baa1771eacbcfe7ec854362bed17baea865424e"
  :revdesc "v2.0-1-g6baa1771eacb"
  :keywords '("lisp" "completing-read" "prompt" "combinations" "vimium")
  :maintainers '(("concat \"erjoalgo\" \"@\" \"gmail\" \".com\"" . "")))
