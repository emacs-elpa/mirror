;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyspell-lazy" "0.6.10.0.20210308.14"
  "Improve flyspell responsiveness using idle timers."
  ()
  :url "https://github.com/rolandwalker/flyspell-lazy"
  :commit "0fc5996bcee20b46cbd227ae948d343c3bef7339"
  :revdesc "v0.6.10-14-g0fc5996bcee2"
  :keywords '("spelling")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
