;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-journal" "1.1.1"
  "Daily note interface for vulpea."
  '((emacs     "29.1")
    (vulpea    "2.5.0")
    (vulpea-ui "1.1.0")
    (vui       "1.3.0")
    (dash      "2.20.0"))
  :url "https://github.com/d12frosted/vulpea-journal"
  :commit "4f6b195faec8f468047efe76a74fbd60a495c32a"
  :revdesc "v1.1.1-0-g4f6b195faec8"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
