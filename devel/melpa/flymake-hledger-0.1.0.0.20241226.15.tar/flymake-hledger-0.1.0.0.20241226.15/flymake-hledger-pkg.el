;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-hledger" "0.1.0.0.20241226.15"
  "Flymake module to check hledger journals."
  '((emacs "28.2"))
  :url "https://github.com/DamienCassou/flymake-hledger"
  :commit "3dd9d58ccd8e4c22c14553ebfac0ca1be3efebc5"
  :revdesc "v0.1.0-15-g3dd9d58ccd8e"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
