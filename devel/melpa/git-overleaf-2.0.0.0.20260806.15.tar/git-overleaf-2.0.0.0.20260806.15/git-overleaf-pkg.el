;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-overleaf" "2.0.0.0.20260806.15"
  "Clone, push, and pull full Overleaf projects with Git."
  '((emacs         "29.4")
    (websocket     "1.15")
    (webdriver     "0.1")
    (magit-section "4.5"))
  :url "https://github.com/Jamie-Cui/git-overleaf"
  :commit "d1cafbd967981e6323d81e63d871247c8da8d62a"
  :revdesc "d1cafbd96798"
  :keywords '("hypermedia" "tex" "tools")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
