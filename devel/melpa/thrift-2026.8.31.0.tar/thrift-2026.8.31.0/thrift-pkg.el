;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.8.31.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "3de249c884d36c370efddae76ba131063888fb0f"
  :revdesc "3de249c884d3"
  :keywords '("languages"))
