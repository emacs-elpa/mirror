;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vc-darcs" "20170409.1521.0.20230319.12"
  "A VC backend for darcs."
  '((emacs "24"))
  :url "https://github.com/velkyel/vc-darcs"
  :commit "097e03f119b4fedb0186fd45d730a1c5acac10dc"
  :revdesc "097e03f119b4"
  :keywords '("vc")
  :authors '(("Jorgen Schaefer" . "forcer@forcix.cx")
             ("Juliusz Chroboczek" . "jch@pps.univ-paris-diderot.fr"))
  :maintainers '(("Libor apák" . "capak@inputwish.com")))
