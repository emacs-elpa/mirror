;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "posframe" "1.5.3.0.20261012.2"
  "Pop a posframe (just a frame) at point."
  '((emacs "26.1"))
  :url "https://github.com/tumashu/posframe"
  :commit "4d950682960966119b34c52d2251ad840c951e32"
  :revdesc "4d9506829609"
  :keywords '("convenience" "tooltip")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
