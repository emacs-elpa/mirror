;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-notmuch" "2.1.5.0.20261117.1"
  "Links to notmuch messages."
  '((emacs   "29.1")
    (compat  "31.1")
    (notmuch "0.39")
    (org     "9.8"))
  :url "https://github.com/tarsius/ol-notmuch"
  :commit "95b2900606ed7a93cff7ec1a91895ed0eabfbec9"
  :revdesc "v2.1.5-1-g95b2900606ed"
  :keywords '("hypermedia" "mail")
  :authors '(("Matthieu Lemerre" . "racin@free.fr"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ol-notmuch@jonas.bernoulli.dev")))
