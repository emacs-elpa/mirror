;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swiper" "0.15.1.0.20260101.20"
  "Isearch with an overview.  Oh, man!."
  '((emacs "24.5")
    (ivy   "0.15.1"))
  :url "https://github.com/abo-abo/swiper"
  :commit "d489b4f0d48fd215119261d92de103c5b5580895"
  :revdesc "0.15.1-20-gd489b4f0d48f"
  :keywords '("matching")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
