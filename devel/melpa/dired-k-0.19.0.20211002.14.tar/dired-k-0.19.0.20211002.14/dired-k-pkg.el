;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-k" "0.19.0.20211002.14"
  "Highlight dired by size, date, git status."
  '((emacs "24.3"))
  :url "https://github.com/emacsorphanage/dired-k"
  :commit "b9507bac79fc8c030abbec389267262bc671f58b"
  :revdesc "b9507bac79fc"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com")))
