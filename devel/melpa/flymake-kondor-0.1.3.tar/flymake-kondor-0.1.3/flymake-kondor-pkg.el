;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-kondor" "0.1.3"
  "Linter with clj-kondo."
  '((emacs "26.1"))
  :url "https://github.com/turbo-cafe/flymake-kondor"
  :commit "784e57f36812a37e323409b90b935ef3c6920a22"
  :revdesc "0.1.3-0-g784e57f36812")
