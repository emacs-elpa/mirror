;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elsqlite" "0.4.0"
  "SQLite browser."
  '((emacs "29.1"))
  :url "https://github.com/dusanx/elsqlite"
  :commit "394904b1cd80ceb665ae4e832043331c1b587b8d"
  :revdesc "v0.4.0-0-g394904b1cd80"
  :keywords '("tools" "databases" "sqlite")
  :authors '(("Dusan Popovic" . "dpx@binaryapparatus.com"))
  :maintainers '(("Dusan Popovic" . "dpx@binaryapparatus.com")))
