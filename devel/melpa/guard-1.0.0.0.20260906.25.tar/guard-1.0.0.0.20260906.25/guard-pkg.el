;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guard" "1.0.0.0.20260906.25"
  "Custom modular init framework."
  '((emacs "29.1"))
  :url "https://github.com/Dspil/guard.el"
  :commit "6a6015f01872fd31a4365da7bbc83b2156258b08"
  :revdesc "6a6015f01872"
  :keywords '("convenience" "initialization" "profiles" "tools")
  :authors '(("Dionisis Spiliopoulos" . "dennisspiliopoylos@gmail.com"))
  :maintainers '(("Dionisis Spiliopoulos" . "dennisspiliopoylos@gmail.com")))
