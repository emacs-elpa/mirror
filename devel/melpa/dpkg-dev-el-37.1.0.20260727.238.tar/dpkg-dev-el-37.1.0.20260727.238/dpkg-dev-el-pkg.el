;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dpkg-dev-el" "37.1.0.20260727.238"
  "Startup file for the elpa-dpkg-dev-el package."
  '((emacs     "27.1")
    (debian-el "37.0"))
  :commit "11a92e9ecaaf68deff5cf4e7f5b3867318d10693"
  :revdesc "37.1-238-g11a92e9ecaaf"
  :authors '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainers '(("Peter S Galbraith" . "psg@debian.org")))
