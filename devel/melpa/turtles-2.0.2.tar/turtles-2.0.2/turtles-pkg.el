;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "turtles" "2.0.2"
  "Screen-grabbing test utility."
  '((emacs  "26.1")
    (compat "30.0.1.0"))
  :url "https://github.com/szermatt/turtles"
  :commit "4da375c5dede7e4854302a7d02e3ff77a30d20c2"
  :revdesc "4da375c5dede"
  :keywords '("testing" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
