;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-guru" "1.6.0.0.20260529.24"
  "Integration of the Go 'guru' analysis tool into Emacs."
  '((go-mode "1.3.1")
    (cl-lib  "0.5"))
  :url "https://github.com/dominikh/go-mode.el"
  :commit "3a71d28ab47df685e54ca6046a7a3dd3e28b682c"
  :revdesc "v1.6.0-24-g3a71d28ab47d"
  :keywords '("tools"))
