;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transwin" "0.1.4.0.20260101.29"
  "Make window/frame transparent."
  '((emacs "24.3"))
  :url "https://github.com/jcs-elpa/transwin"
  :commit "fb78576162d0446fc5765d180aba98b0730b1f37"
  :revdesc "fb78576162d0"
  :keywords '("frames" "window" "transparent")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
