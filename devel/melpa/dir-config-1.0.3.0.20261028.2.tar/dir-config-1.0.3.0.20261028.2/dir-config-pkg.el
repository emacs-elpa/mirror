;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-config" "1.0.3.0.20261028.2"
  "Find and evaluate .dir-config.el (dir-locals alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/dir-config.el"
  :commit "803126f03c13e1cbb3a269cfd1fcca60a6471aaf"
  :revdesc "1.0.3-2-g803126f03c13"
  :keywords '("convenience" "files" "lisp")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
