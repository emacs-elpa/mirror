;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eide" "2.3.4.0.20260723.13"
  "IDE features made available out of the box."
  '((emacs "26.1"))
  :url "https://forge.tedomum.net/hjuvi/eide"
  :commit "74448bb8c2e3674c3b9d332b250cd27a34850b67"
  :revdesc "2.3.4-13-g74448bb8c2e3"
  :authors '(("Cédric Marie" . "hjuvi@tedomum.fr"))
  :maintainers '(("Cédric Marie" . "hjuvi@tedomum.fr")))
