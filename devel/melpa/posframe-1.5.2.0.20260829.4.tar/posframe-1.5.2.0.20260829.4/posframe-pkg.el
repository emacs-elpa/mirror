;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "posframe" "1.5.2.0.20260829.4"
  "Pop a posframe (just a frame) at point."
  '((emacs "26.1"))
  :url "https://github.com/tumashu/posframe"
  :commit "6f89c0acd29306cb2cd023418d18134cfc507800"
  :revdesc "6f89c0acd293"
  :keywords '("convenience" "tooltip")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
