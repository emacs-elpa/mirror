;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "howdoi" "0.4.3.0.20150204.6"
  "Instant coding answers via Emacs."
  ()
  :url "https://github.com/atykhonov/emacs-howdoi/"
  :commit "5fbf7069ee160c597a328e5ce5fb32920e1ca88f"
  :revdesc "5fbf7069ee16"
  :keywords '("howdoi" "convenience")
  :authors '(("Andrey Tykhonov" . "atykhonovatgmail.com"))
  :maintainers '(("Andrey Tykhonov" . "atykhonov@gmail.com")))
