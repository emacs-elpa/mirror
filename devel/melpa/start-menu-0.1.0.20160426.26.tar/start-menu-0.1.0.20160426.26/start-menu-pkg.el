;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "start-menu" "0.1.0.20160426.26"
  "Start-menu for executing external program like in windows."
  '((cl-lib        "0.5")
    (config-parser "0.1"))
  :url "https://github.com/lujun9972/el-start-menu"
  :commit "f7d33fed7ad2dc61156f1c1cff9e1805366fbd69"
  :revdesc "f7d33fed7ad2"
  :keywords '("convenience" "menu")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
