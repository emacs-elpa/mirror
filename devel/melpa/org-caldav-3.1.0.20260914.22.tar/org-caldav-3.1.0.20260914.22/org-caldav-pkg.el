;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-caldav" "3.1.0.20260914.22"
  "Sync org files with external calendar through CalDAV."
  '((emacs "26.3")
    (org   "9.1"))
  :url "https://github.com/dengste/org-caldav/"
  :commit "30906b8c6eb213c540ba2d014cefdb5451f2a1f3"
  :revdesc "30906b8c6eb2"
  :keywords '("calendar" "caldav")
  :authors '(("David Engster" . "deng@randomsample.de"))
  :maintainers '(("David Engster" . "deng@randomsample.de")))
