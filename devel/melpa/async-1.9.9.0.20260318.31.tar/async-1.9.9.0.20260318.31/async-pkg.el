;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async" "1.9.9.0.20260318.31"
  "Asynchronous processing in Emacs."
  '((emacs "24.4"))
  :url "https://github.com/jwiegley/emacs-async"
  :commit "5faab28916603bb324d9faba057021ce028ca847"
  :revdesc "v1.9.9-31-g5faab2891660"
  :keywords '("async")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
