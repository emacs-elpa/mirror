;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pager" "0.0.0.20151202.3"
  "Windows-scroll commands."
  ()
  :url "https://github.com/emacsorphanage/pager"
  :commit "5c791ed23f1136e04040d6f4bc9b4ca5b6dc919f"
  :revdesc "5c791ed23f11"
  :authors '((nil . "MikaelSjödin--mic@docs.uu.se"))
  :maintainers '((nil . "MikaelSjödin--mic@docs.uu.se")))
