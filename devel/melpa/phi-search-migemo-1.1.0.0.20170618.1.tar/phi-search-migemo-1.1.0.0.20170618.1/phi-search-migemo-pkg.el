;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-search-migemo" "1.1.0.0.20170618.1"
  "Migemo extension for phi-search."
  '((phi-search "2.2.0")
    (migemo     "1.9.1"))
  :url "http://hins11.yu-yake.com/"
  :commit "723b584d386639d59298d872ad7a035d3f8008b0"
  :revdesc "723b584d3866")
