;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term+key-intercept" "0.1.0.20140211.3"
  "Term+ intercept key mapping."
  '((term+         "0.1")
    (key-intercept "0.1"))
  :url "https://github.com/tarao/term+-el"
  :commit "fd0771fd66b8c7a909aaac972194485c79ba48c4"
  :revdesc "fd0771fd66b8"
  :keywords '("terminal" "emulation")
  :authors '(("INA Lintaro" . "tarao.gnnatgmail.com"))
  :maintainers '(("INA Lintaro" . "tarao.gnnatgmail.com")))
