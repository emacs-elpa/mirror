;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwin" "0.2.0.0.20251208.2"
  "Navigate and arrange desktop windows."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/lsth/dwin"
  :commit "cbef68f873f02af3e40173c31013e01876a21b71"
  :revdesc "v0.2.0-2-gcbef68f873f0"
  :keywords '("frames" "processes" "convenience")
  :authors '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de"))
  :maintainers '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de")))
