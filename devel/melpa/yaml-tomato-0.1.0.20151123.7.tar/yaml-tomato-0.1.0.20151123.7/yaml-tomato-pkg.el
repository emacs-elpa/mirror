;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yaml-tomato" "0.1.0.20151123.7"
  "Copy or show the yaml path currently under cursor."
  '((s "1.9"))
  :url "https://github.com/RadekMolenda/yaml-tomato"
  :commit "1272c502fac6ce6b0f8b7f8a9beb353f0b35e13c"
  :revdesc "1272c502fac6"
  :keywords '("yaml"))
