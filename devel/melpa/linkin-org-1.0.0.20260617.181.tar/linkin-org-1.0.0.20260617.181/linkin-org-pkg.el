;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linkin-org" "1.0.0.20260617.181"
  "A workflow with fast, reliable links."
  '((emacs "30.1"))
  :url "https://github.com/Judafa/linkin-org"
  :commit "51d7c2c2689c0cfd48f91986d36ffdabea57369f"
  :revdesc "51d7c2c2689c"
  :authors '(("Julien Dallot" . "judafa@protonmail.com"))
  :maintainers '(("Julien Dallot" . "judafa@protonmail.com")))
