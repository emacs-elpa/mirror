;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swoop" "1.0.0.20200618.9"
  "Peculiar buffer navigation."
  '((emacs   "24.3")
    (ht      "2.0")
    (pcre2el "1.5")
    (async   "1.1"))
  :url "https://github.com/ShingoFukuyama/emacs-swoop"
  :commit "828ae0f17f3beaea50ee66d06c500f4847ccc7dd"
  :revdesc "828ae0f17f3b"
  :keywords '("tools" "swoop" "inner" "buffer" "search" "navigation"))
