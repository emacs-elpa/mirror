;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "2.10"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "f776ca306801f3b4d26a458d5109ea586d52e716"
  :revdesc "2.10-0-gf776ca306801"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
