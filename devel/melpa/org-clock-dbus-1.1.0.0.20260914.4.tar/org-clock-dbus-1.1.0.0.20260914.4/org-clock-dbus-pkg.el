;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-dbus" "1.1.0.0.20260914.4"
  "Monitor org-clock from D-Bus."
  '((emacs "28.1")
    (org   "9.6.0"))
  :url "https://github.com/pjones/org-clock-dbus"
  :commit "cebbbc67b19db762df9c4d799404dd0f688444da"
  :revdesc "v1.1.0-4-gcebbbc67b19d"
  :keywords '("comm" "outlines" "unix")
  :authors '(("Peter J. Jones" . "pjones@devalot.com"))
  :maintainers '(("Peter J. Jones" . "pjones@devalot.com")))
