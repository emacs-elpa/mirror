;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-search" "20160630.0.20250611.16"
  "Another incremental search & replace, compatible with \"multiple-cursors\"."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "2caee8a353608eb41a41e794e7999a5950dbfee3"
  :revdesc "2caee8a35360")
