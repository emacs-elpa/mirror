;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.8.1.0.20260816.17"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "2d662c0740df0692a95baa3ca15400d75f82da64"
  :revdesc "2d662c0740df"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
