;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jami-bot" "0.0.2.0.20240203.4"
  "An extendable chat bot for the private messenger GNU Jami."
  '((emacs "27.1"))
  :url "https://gitlab.com/hperrey/jami-bot"
  :commit "c2ad37e2ada14b5551a83211cc4692b39be4e5fb"
  :revdesc "c2ad37e2ada1"
  :keywords '("comm" "jami" "messenger" "chat bot" "dbus")
  :authors '(("Hanno Perrey" . "hanno@hoowl.se"))
  :maintainers '(("Hanno Perrey" . "hanno@hoowl.se")))
