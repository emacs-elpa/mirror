;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "config-general-mode" "0.3.0.20251217.1"
  "Config::General config file mode."
  ()
  :url "https://codeberg.org/scip/config-general-mode"
  :commit "f92cc6d9b3f3cc49e58cea2b10ad3c2e8aced813"
  :revdesc "f92cc6d9b3f3"
  :keywords '("files")
  :authors '(("T.v.Dein" . "tlinden@cpan.org"))
  :maintainers '(("T.v.Dein" . "tlinden@cpan.org")))
