;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inspire" "0.0.1.0.20230514.4"
  "An interface for inspirehep.net."
  '((emacs "27.1"))
  :url "https://github.com/Simon-Lin/inspire.el"
  :commit "825bbd4e19046b0e61aa27a0f88b1daeaaebf1d0"
  :revdesc "825bbd4e1904"
  :keywords '("extensions" "tex")
  :authors '(("Simon Lin" . "n.sibetz@gmail.com"))
  :maintainers '(("Simon Lin" . "n.sibetz@gmail.com")))
