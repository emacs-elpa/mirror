;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "use-package-x" "0.0.1.0.20260525.5"
  "Additional keywords for use-package."
  '((emacs       "30.1")
    (compat      "31")
    (use-package "2.4"))
  :url "https://github.com/DevelopmentCool2449/use-package-x"
  :commit "45ed391f1d6816b1fff0a3104c6c0d94d9bebd64"
  :revdesc "45ed391f1d68"
  :keywords '("convenience" "extensions")
  :authors '(("Elias G. Perez" . "eg642616@gmail.com"))
  :maintainers '(("Elias G. Perez" . "eg642616@gmail.com")))
