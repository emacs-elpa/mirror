;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "1.0.6"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "c3114857fd1db0f570f6776ae63d9fa2e29472c8"
  :revdesc "1.0.6-0-gc3114857fd1d"
  :keywords '("tools" "processes" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
