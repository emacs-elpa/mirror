;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.4.0.0.20260815.1"
  "Emacs Client for Pi."
  '((emacs         "29.1")
    (compat        "31.0")
    (markdown-mode "2.8")
    (timeout       "2.1.7")
    (pcre2el       "1.12")
    (spinner       "1.7")
    (transient     "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "5ada3b27e8a157162fd348a5647ea21efd70d6d5"
  :revdesc "5ada3b27e8a1"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
