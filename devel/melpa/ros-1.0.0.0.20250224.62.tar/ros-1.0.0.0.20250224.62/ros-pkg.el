;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ros" "1.0.0.0.20250224.62"
  "Package to write code for ROS systems."
  '((emacs                  "27.1")
    (s                      "0")
    (with-shell-interpreter "0")
    (kv                     "0")
    (cl-lib                 "0")
    (transient              "0")
    (hydra                  "0")
    (grep                   "0")
    (string-inflection      "0"))
  :url "https://github.com/DerBeutlin/ros.el"
  :commit "2108aed4d075652c342e537fab120392f4703d74"
  :revdesc "2108aed4d075"
  :keywords '("convenience" "tools")
  :authors '(("Max Beutelspacher" . "https://github.com/mtb"))
  :maintainers '(("Max Beutelspacher" . "max@beutelspacher.eu")))
