;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-pomodoro" "2.1.0.0.20261106.36"
  "Pomodoro implementation for org-mode."
  '((alert  "0.5.10")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/lolownia/org-pomodoro"
  :commit "a283a0fca138b2dc9bd59f69b6f1f105d8bf006b"
  :revdesc "a283a0fca138"
  :authors '(("Arthur Leonard Andersen" . "leoc.git@gmail.com")
             ("Marcin Koziej" . "marcinatlolowniadotorg"))
  :maintainers '(("Arthur Leonard Andersen" . "leoc.git@gmail.com")
                 ("Marcin Koziej" . "marcinatlolowniadotorg")))
