;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metaweblog" "1.1.19"
  "An XML-RPC MetaWeblog and WordPress API client."
  '((emacs   "30.2")
    (xml-rpc "1.6.15"))
  :url "https://github.com/org2blog/org2blog"
  :commit "c3abdd9a518554d62ff2ba3ffd1fd18f37a24e24"
  :revdesc "v1.1.19-0-gc3abdd9a5185"
  :keywords '("comm")
  :authors '(("Puneeth Chaganti" . "punchagan+org2blog@gmail.com"))
  :maintainers '(("Grant Rettke" . "grant@wisdomandwonder.com")))
