;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "temporary-persistent" "0.1.0.20260916.28"
  "Keep temp notes buffers persistent."
  '((emacs "24.3")
    (names "20151201.0")
    (dash  "2.12.1")
    (s     "1.10.0"))
  :url "https://github.com/kostafey/temporary-persistent"
  :commit "f4bfecdf5ed99109da02e6c707882a08f50eefbc"
  :revdesc "f4bfecdf5ed9"
  :keywords '("temp" "buffers" "notes")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
