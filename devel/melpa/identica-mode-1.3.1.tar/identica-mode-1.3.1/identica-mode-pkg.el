;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "identica-mode" "1.3.1"
  "Major mode API client for status.net open microblogging."
  ()
  :url "http://blog.gabrielsaldana.org/identica-mode-for-emacs/"
  :commit "cf9183ee11ac922e85c7c908f04e2d00b03111b3"
  :revdesc "v1.3.1-0-gcf9183ee11ac"
  :keywords '("identica" "web")
  :authors '(("Gabriel Saldana" . "gsaldana@gmail.com"))
  :maintainers '(("Gabriel Saldana" . "gsaldana@gmail.com")))
