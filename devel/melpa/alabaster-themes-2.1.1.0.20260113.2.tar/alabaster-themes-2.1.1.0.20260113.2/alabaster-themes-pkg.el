;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alabaster-themes" "2.1.1.0.20260113.2"
  "Alabaster themes collection."
  '((emacs "28.1"))
  :url "https://github.com/vedang/alabaster-themes"
  :commit "2d3dcfc6ac8988d23f8065a580f7dcf4ff607e56"
  :revdesc "2d3dcfc6ac89"
  :keywords '("faces" "theme" "minimal")
  :authors '(("Nikita Prokopov" . "@tonsky"))
  :maintainers '(("Vedang Manerikar" . "@vedang")))
