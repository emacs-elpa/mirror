;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idris-mode" "1.0.0.20260506.366"
  "Major mode for editing Idris code."
  '((emacs     "24")
    (prop-menu "0.1")
    (cl-lib    "0.5"))
  :url "https://github.com/idris-hackers/idris-mode"
  :commit "22cc1bf237428b24de5f4f228db747e93a4ae619"
  :revdesc "22cc1bf23742"
  :keywords '("languages"))
