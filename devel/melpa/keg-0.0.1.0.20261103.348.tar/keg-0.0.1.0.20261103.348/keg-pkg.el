;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keg" "0.0.1.0.20261103.348"
  "Modern Elisp package development system."
  '((emacs "24.1"))
  :url "https://github.com/conao3/keg.el"
  :commit "452c6109621ec1cbd2a98ed0eacd4a74f4fffe3e"
  :revdesc "452c6109621e"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
