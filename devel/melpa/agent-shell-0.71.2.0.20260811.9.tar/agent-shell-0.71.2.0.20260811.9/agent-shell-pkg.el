;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.71.2.0.20260811.9"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a0f67725eb93434c27bb3875879eca3e719d69d1"
  :revdesc "a0f67725eb93")
