;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-at-point" "1.1.0.20191013.1"
  "Edit(copy,cut..) current things(word,symbol..) under cursor."
  ()
  :url "https://github.com/enoson/edit-at-point.el"
  :commit "28c85a65c9c61f2aff50bc5e93f61cde26a5d9c0"
  :revdesc "28c85a65c9c6"
  :authors '((nil . "e.enoson@gmail.com"))
  :maintainers '((nil . "e.enoson@gmail.com")))
