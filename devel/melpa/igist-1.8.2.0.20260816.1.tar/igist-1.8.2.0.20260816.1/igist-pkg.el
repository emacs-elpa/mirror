;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "igist" "1.8.2.0.20260816.1"
  "List, create, update and delete GitHub gists."
  '((emacs     "29.1")
    (ghub      "4.2.2")
    (transient "0.8.5"))
  :url "https://github.com/KarimAziev/igist"
  :commit "2c19cf33044cda8408e15bca48771c13c09d71a1"
  :revdesc "2c19cf33044c"
  :keywords '("tools")
  :authors '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers '(("Karim Aziiev" . "karim.aziiev@gmail.com")))
