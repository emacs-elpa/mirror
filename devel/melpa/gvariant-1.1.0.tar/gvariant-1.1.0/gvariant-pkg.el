;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gvariant" "1.1.0"
  "GVariant (GLib) helpers."
  '((emacs  "24")
    (parsec "0.1.4"))
  :url "https://github.com/wbolster/emacs-gvariant"
  :commit "b49a9c6623773be20e59eada9f8eab33210cc89b"
  :revdesc "1.1.0-0-gb49a9c662377"
  :keywords '("languages")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
