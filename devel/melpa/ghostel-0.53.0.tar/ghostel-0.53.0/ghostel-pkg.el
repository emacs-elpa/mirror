;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.53.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "2bea18f3b52bf97d8222fea706da6fabdfc2cbb8"
  :revdesc "2bea18f3b52b"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
