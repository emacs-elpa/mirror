;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-mmark" "0.1.0.0.20260802.30"
  "Flycheck checker for the MMark markdown processor."
  '((emacs    "24.4")
    (flycheck "0.29"))
  :url "https://github.com/mmark-md/flycheck-mmark"
  :commit "e58e36bf4def70e8aa2928b76fa757dd63d869f7"
  :revdesc "e58e36bf4def"
  :keywords '("convenience" "text")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
