;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clean-kill-ring" "2.6.0.20260724.3"
  "Keep the kill ring clean."
  '((emacs "24.4"))
  :url "https://github.com/NicholasBHubbard/clean-kill-ring.el"
  :commit "dc5d622a23dfcf6c00634fd74ae37fd3bdc36f2e"
  :revdesc "dc5d622a23df"
  :keywords '("kill-ring" "convenience")
  :authors '(("Nicholas Hubbard" . "nicholashubbard@posteo.net"))
  :maintainers '(("Nicholas Hubbard" . "nicholashubbard@posteo.net")))
