;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "6.3.0.0.20261105.3"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "8678b0294cf516c8ce6a5cc47448f51d91daddc6"
  :revdesc "v6.3.0-3-g8678b0294cf5"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
