;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-re-reveal-ref" "1.0.0.0.20211029.8"
  "Citations and bibliography for org-re-reveal."
  '((emacs         "25.1")
    (org-ref       "1.1.1")
    (org-re-reveal "0.9.3"))
  :url "https://gitlab.com/oer/org-re-reveal-ref"
  :commit "ea9661864d5fbef87b12b78f516c13a40c683f24"
  :revdesc "ea9661864d5f"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "bibliography"))
