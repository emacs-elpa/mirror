;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-read-only" "0.0.1.0.20260521.17"
  "Automatically make the buffer to read-only."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/zonuexe/auto-read-only.el"
  :commit "206d4559762fe6ef9e91de8f9dc43e1e41c0f42c"
  :revdesc "206d4559762f"
  :keywords '("files" "convenience")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
