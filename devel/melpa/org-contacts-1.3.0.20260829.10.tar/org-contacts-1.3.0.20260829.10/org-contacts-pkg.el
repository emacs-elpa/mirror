;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "1.3.0.20260829.10"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "886d78099e4cf5ed620379b81097134fea4b8e83"
  :revdesc "886d78099e4c"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
