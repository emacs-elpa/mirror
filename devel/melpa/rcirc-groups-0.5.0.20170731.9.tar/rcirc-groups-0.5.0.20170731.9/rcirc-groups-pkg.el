;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rcirc-groups" "0.5.0.20170731.9"
  "An emacs buffer in rcirc-groups major mode."
  ()
  :url "http://tapoueh.org/emacs/rcirc-groups.html"
  :commit "b68ece9d219b909244d4e3c0d8bf6a746d6fead7"
  :revdesc "b68ece9d219b"
  :keywords '("comm" "convenience")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
