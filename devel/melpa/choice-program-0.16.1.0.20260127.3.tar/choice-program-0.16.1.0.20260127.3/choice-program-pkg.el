;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "choice-program" "0.16.1.0.20260127.3"
  "Parameter based program."
  '((emacs "27.1")
    (dash  "2.19.1"))
  :url "https://github.com/plandes/choice-program"
  :commit "9c027a54a97390ee4863d663be19b1a2aaa70c7b"
  :revdesc "v0.16.1-3-g9c027a54a973"
  :keywords '("execution" "processes" "unix" "lisp"))
