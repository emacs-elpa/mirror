;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "1.3.0.20260628.1"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "7df905c77f590278d301679db354a3d7662407c9"
  :revdesc "v1.3-1-g7df905c77f59"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
