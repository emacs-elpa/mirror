;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nice-org-html" "1.2.0.20260919.58"
  "Prettier org-to-html export."
  '((emacs   "25.1")
    (s       "1.13.0")
    (dash    "2.19.1")
    (htmlize "1.58")
    (uuidgen "1.0"))
  :url "https://github.com/ewantown/nice-org-html"
  :commit "3da4b8ee2b4076ac35372ff80e13d9af4e77fd13"
  :revdesc "3da4b8ee2b40"
  :keywords '("org" "org-export" "html" "css" "js" "tools")
  :authors '(("Ewan Townshend" . "ewan@etown.dev"))
  :maintainers '(("Ewan Townshend" . "ewan@etown.dev")))
