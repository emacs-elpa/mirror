;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch" "0.40.0.20260314.23"
  "Run notmuch within emacs."
  ()
  :url "https://notmuchmail.org"
  :commit "094744b3f6f5c6831b6555d1fe75709abf1d1279"
  :revdesc "0.40-23-g094744b3f6f5"
  :authors '(("Carl Worth" . "cworth@cworth.org"))
  :maintainers '(("Carl Worth" . "cworth@cworth.org")))
