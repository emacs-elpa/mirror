;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-ripgrep" "0.4.0.0.20221013.21"
  "Run ripgrep with Projectile."
  '((ripgrep    "0.3.0")
    (projectile "0.14.0"))
  :url "https://github.com/nlamirault/ripgrep.el"
  :commit "b6bd5beb0c11348f1afd9486cbb451d0d2e3c45a"
  :revdesc "b6bd5beb0c11"
  :keywords '("ripgrep" "projectile")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
