;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sleek-modeline" "1.1.0.0.20261122.34"
  "Minimal and elegant modeline."
  '((emacs "30.1"))
  :url "https://github.com/abidanBrito/sleek-modeline"
  :commit "c3936663b72c90a8397293feb4d4d57762eea707"
  :revdesc "v1.1.0-34-gc3936663b72c"
  :keywords '("mode-line" "faces")
  :authors '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com"))
  :maintainers '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com")))
