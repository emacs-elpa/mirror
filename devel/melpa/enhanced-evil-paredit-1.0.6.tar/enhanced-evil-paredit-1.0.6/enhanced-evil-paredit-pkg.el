;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "1.0.6"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "d29efcecbf9d3401001509b98b7031eba55aa68e"
  :revdesc "1.0.6-0-gd29efcecbf9d"
  :keywords '("convenience" "lisp"))
