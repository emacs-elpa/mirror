;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "splunk-mode" "1.1.0.0.20241002.4"
  "Major Mode for editing Splunk SPL source code."
  '((emacs "27.1"))
  :url "https://github.com/jakewilliami/splunk-mode/"
  :commit "bc0ad3ed26e2f6d46c430a3f1ab86c93c4483403"
  :revdesc "1.1.0-4-gbc0ad3ed26e2"
  :keywords '("languages" "splunk" "mode" "query")
  :authors '(("Jake Ireland" . "jakewilliami@icloud.com"))
  :maintainers '(("Jake Ireland" . "jakewilliami@icloud.com")))
