;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hamburger-menu" "1.0.6"
  "Mode line hamburger menu."
  '((emacs "28.1"))
  :url "https://gitlab.com/iain/hamburger-menu-mode"
  :commit "06bc9d6872007a31226d7410d497a0acd98b272b"
  :revdesc "v1.0.6-0-g06bc9d687200"
  :keywords '("hamburger" "menu"))
