;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "default-font-presets" "0.1.0.20260505.41"
  "Support selecting fonts from a list of presets."
  '((emacs "26.1"))
  :url "https://codeberg.org/ideasman42/emacs-default-font-presets"
  :commit "43e778da6ef468e187743f009e14270875bc312e"
  :revdesc "43e778da6ef4"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
