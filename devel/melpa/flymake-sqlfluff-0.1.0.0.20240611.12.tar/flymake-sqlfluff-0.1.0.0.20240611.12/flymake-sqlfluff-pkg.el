;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-sqlfluff" "0.1.0.0.20240611.12"
  "A flymake plugin for SQL files using sqlfluff."
  '((emacs "27.1"))
  :url "https://github.com/erickgnavar/flymake-sqlfluff"
  :commit "0a836d7a919723ae5897fce01c3c7d651a30e8c6"
  :revdesc "0a836d7a9197"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
