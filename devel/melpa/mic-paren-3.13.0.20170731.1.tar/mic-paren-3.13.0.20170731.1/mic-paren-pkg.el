;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mic-paren" "3.13.0.20170731.1"
  "Advanced highlighting of matching parentheses."
  ()
  :url "https://github.com/emacsattic/mic-paren"
  :commit "d0410c7d805c9aaf51a1bcefaaef092bed5824c4"
  :revdesc "d0410c7d805c"
  :keywords '("languages" "faces" "parenthesis" "matching")
  :authors '(("Mikael Sjödin" . "(mic@docs.uu.se)")
             ("Klaus Berndl" . "berndl@sdm.de")
             ("Jonathan Kotta" . "jpkotta@gmail.com")))
