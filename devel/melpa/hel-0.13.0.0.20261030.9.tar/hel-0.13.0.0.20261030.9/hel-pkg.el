;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hel" "0.13.0.0.20261030.9"
  "Helix Emulation Layer."
  '((emacs        "29.1")
    (dash         "2.19.1")
    (avy          "0.5.0")
    (pcre2el      "1.12")
    (ultra-scroll "0.6"))
  :url "https://github.com/helheim-emacs/hel"
  :commit "4b5c72b54d6b62050dad3edf1a29cbd267569fec"
  :revdesc "4b5c72b54d6b"
  :authors '(("Yuriy Artemyev" . "anuvyklack@gmail.com"))
  :maintainers '(("Yuriy Artemyev" . "anuvyklack@gmail.com")))
