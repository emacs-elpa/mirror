;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "0.9.0.20260626.83"
  "MCP server for Org-mode."
  '((emacs          "28.2")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "0b8c48617bb5472e6506877964995fae021b61c6"
  :revdesc "0b8c48617bb5"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
