;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-commit-mark" "0.1.0.0.20260511.37"
  "Support marking commits as read."
  '((emacs "29.1")
    (magit "3.3.0"))
  :url "https://codeberg.org/ideasman42/emacs-magit-commit-mark"
  :commit "9712db3fd09fe493d2ac5644b40e9cd451877180"
  :revdesc "9712db3fd09f"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
