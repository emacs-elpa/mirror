;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-notmuch" "1.0.0.20181203.9"
  "Search emails in Notmuch asynchronously with Ivy."
  '((emacs   "24")
    (ivy     "0.10.0")
    (notmuch "0.21")
    (s       "1.12.0"))
  :url "https://github.com/fuxialexander/counsel-notmuch"
  :commit "a4a1562935e4180c42524c51609d1283e9be0688"
  :revdesc "a4a1562935e4"
  :keywords '("mail")
  :authors '(("Alexander Fu Xi" . "fuxialexander@gmail.com"))
  :maintainers '(("Alexander Fu Xi" . "fuxialexander@gmail.com")))
