;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "2.9.1"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "3fccf0c0384f32108758323f1691f6dda3c164c9"
  :revdesc "2.9.1-0-g3fccf0c0384f"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
