;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "2.3.0.0.20260721.47"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "4adadb44f76e11dd2805aaf4e6656b52c5f97902"
  :revdesc "4adadb44f76e"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
