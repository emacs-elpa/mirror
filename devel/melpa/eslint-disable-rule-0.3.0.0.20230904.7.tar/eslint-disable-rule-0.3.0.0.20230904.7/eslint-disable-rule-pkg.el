;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eslint-disable-rule" "0.3.0.0.20230904.7"
  "Commands to add JS comments disabling eslint rules."
  '((emacs "27.2"))
  :url "https://github.com/DamienCassou/eslint-disable-rule"
  :commit "54771405e09e2cf5cb8f47aab2818e77d3046f53"
  :revdesc "54771405e09e"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
