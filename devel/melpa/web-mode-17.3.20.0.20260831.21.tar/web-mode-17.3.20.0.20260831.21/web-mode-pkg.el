;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "web-mode" "17.3.20.0.20260831.21"
  "Major mode for editing web templates."
  '((emacs "24.3.1"))
  :url "https://web-mode.org"
  :commit "ce24723eb900c455b488d224910519bd36af580a"
  :revdesc "ce24723eb900"
  :keywords '("languages")
  :maintainers '(("François-Xavier Bois" . "fxbois@gmail.com")))
