;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-super-agenda" "1.3.0.20250421.21"
  "Supercharge your agenda."
  '((emacs  "26.1")
    (compat "29.1.4.1")
    (s      "1.10.0")
    (dash   "2.13")
    (org    "9.0")
    (ht     "2.2")
    (ts     "0.2"))
  :url "https://github.com/alphapapa/org-super-agenda"
  :commit "fb20ad9c8a9705aa05d40751682beae2d094e0fe"
  :revdesc "v1.3-21-gfb20ad9c8a97"
  :keywords '("hypermedia" "outlines" "org" "agenda")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
