;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soccer" "1.6.2.0.20231108.3"
  "Fixtures, results, table etc for soccer."
  '((emacs "26.1")
    (dash  "2.19.1"))
  :url "https://github.com/md-arif-shaikh/soccer"
  :commit "96dd98a34238c8019d48507071df5d2b199360cd"
  :revdesc "96dd98a34238"
  :keywords '("games" "soccer" "football")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
