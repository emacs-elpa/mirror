;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gtk-pomodoro-indicator" "0.1.0.0.20191007.12"
  "A pomodoro indicator for the GTK tray."
  ()
  :url "https://github.com/abo-abo/gtk-pomodoro-indicator"
  :commit "cb026a595de8a9244b16e06876f10c60dce18676"
  :revdesc "cb026a595de8"
  :keywords '("convenience" "pomodoro")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
