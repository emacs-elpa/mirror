;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-etags" "2.0.5.0.20260513.1"
  "Fast and complete Ctags solution using ivy."
  '((emacs   "28.1")
    (counsel "0.15.1"))
  :url "https://github.com/redguardtoo/counsel-etags"
  :commit "d9ed92310da368d8d037e151b8dcbb7ada55d42c"
  :revdesc "d9ed92310da3"
  :keywords '("tools" "convenience"))
