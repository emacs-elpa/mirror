;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultra-scroll" "0.6.2.0.20260616.3"
  "Fast and smooth scrolling."
  '((emacs "29.1"))
  :url "https://github.com/jdtsmith/ultra-scroll"
  :commit "5be267d2d92c230b4347e0769f584c71aec53589"
  :revdesc "5be267d2d92c"
  :keywords '("convenience"))
