;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "0.6.1.0.20260730.2"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "c7d2cb68cff163f58895515cc781bb6f9414868a"
  :revdesc "c7d2cb68cff1"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
