;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "find-file-in-repository" "1.2.0.20210301.34"
  "Quickly find files in a git, mercurial or other repository."
  ()
  :url "https://github.com/hoffstaetter/find-file-in-repository"
  :commit "10f5bd919ce35691addc5ce0d281597a46813a79"
  :revdesc "10f5bd919ce3"
  :keywords '("files" "convenience" "repository" "project" "source control")
  :authors '(("Samuel Hoffstaetter" . "samuel@hoffstaetter.com"))
  :maintainers '(("Samuel Hoffstaetter" . "samuel@hoffstaetter.com")))
