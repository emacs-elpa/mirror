;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "2.2.0"
  "Support for Org links to Magit buffers."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.6")
    (org      "9.8"))
  :url "https://github.com/magit/orgit"
  :commit "7c4827cd04953166f71eaec151ad1c50872fc680"
  :revdesc "v2.2.0-0-g7c4827cd0495"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
