;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rescript-mode" "0.1.0.0.20260505.108"
  "A major mode for editing ReScript."
  '((emacs "26.1"))
  :url "https://github.com/jjlee/rescript-mode"
  :commit "d0ff73d8e6c9653f0baf7edbcd7e585a24dedf8d"
  :revdesc "d0ff73d8e6c9"
  :keywords '("languages" "rescript")
  :authors '(("Karl Landstrom" . "karl.landstrom@brgeight.se")
             ("Daniel Colascione" . "dancol@dancol.org")
             ("John Lee" . "jjl@pobox.com"))
  :maintainers '(("John Lee" . "jjl@pobox.com")))
