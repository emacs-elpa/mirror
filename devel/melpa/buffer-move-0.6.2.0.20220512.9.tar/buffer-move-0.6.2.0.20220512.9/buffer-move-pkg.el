;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-move" "0.6.2.0.20220512.9"
  "Easily swap buffers."
  '((emacs "24.1"))
  :url "https://github.com/lukhas/buffer-move/"
  :commit "e7800b3ab1bd76ee475ef35507ec51ecd5a3f065"
  :revdesc "e7800b3ab1bd"
  :keywords '("convenience")
  :authors '(("Lucas Bonnet" . "lucas@rincevent.net")
             ("Mathis Hofer" . "mathis@fsfe.org")
             ("Geyslan G. Bem" . "geyslan@gmail.com"))
  :maintainers '(("Lucas Bonnet" . "lucas@rincevent.net")
                 ("Mathis Hofer" . "mathis@fsfe.org")
                 ("Geyslan G. Bem" . "geyslan@gmail.com")))
