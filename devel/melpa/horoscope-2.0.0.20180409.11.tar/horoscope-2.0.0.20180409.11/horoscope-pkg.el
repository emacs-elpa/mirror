;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "horoscope" "2.0.0.20180409.11"
  "Generate horoscopes."
  '((emacs "24"))
  :url "https://github.com/mschuldt/horoscope.el"
  :commit "f4c683e991adce0a8f9023f15050f306f9b9a9ed"
  :revdesc "f4c683e991ad"
  :keywords '("extensions" "games")
  :authors '(("Bob Manson" . "manson@cygnus.com"))
  :maintainers '(("Noah Friedman" . "friedman@prep.ai.mit.edu")))
