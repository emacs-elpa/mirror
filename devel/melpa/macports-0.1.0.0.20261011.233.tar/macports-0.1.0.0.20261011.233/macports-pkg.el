;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macports" "0.1.0.0.20261011.233"
  "A porcelain for MacPorts."
  '((emacs     "28.1")
    (transient "0.1.0"))
  :url "https://github.com/amake/macports.el"
  :commit "fb49f0c5bb35bf7bd3370ab46c6ab83136fd3297"
  :revdesc "fb49f0c5bb35"
  :keywords '("convenience"))
