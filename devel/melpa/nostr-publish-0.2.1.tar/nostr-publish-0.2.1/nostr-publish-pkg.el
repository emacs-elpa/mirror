;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nostr-publish" "0.2.1"
  "Publish Markdown to Nostr."
  '((emacs "27.1"))
  :url "https://github.com/941design/emacs-nostr-publish"
  :commit "f39220f2aaff5fc39e4268d6449a1a402a69cafa"
  :revdesc "f39220f2aaff"
  :keywords '("comm" "text")
  :authors '(("Markus Rother" . "mail@markusrother.de"))
  :maintainers '(("Markus Rother" . "mail@markusrother.de")))
