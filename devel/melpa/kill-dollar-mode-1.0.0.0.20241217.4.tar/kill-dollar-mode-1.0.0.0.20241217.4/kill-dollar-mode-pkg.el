;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kill-dollar-mode" "1.0.0.0.20241217.4"
  "Remove leading $ from shell-script-like text."
  '((emacs "27.1"))
  :url "https://github.com/sandinmyjoints/kill-dollar-mode"
  :commit "e51c076f93605c5a651b549731ccfc85a2564aca"
  :revdesc "1.0.0-4-ge51c076f9360"
  :keywords '("convenience" "tools"))
