;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-projectile" "0.7.0.20230821.5"
  "Consult integration for projectile."
  '((emacs      "25.1")
    (consult    "0.12")
    (projectile "2.5.0"))
  :url "https://gitlab.com/OlMon/consult-projectile"
  :commit "400439c56d17bca7888f7d143d8a11f84900a406"
  :revdesc "400439c56d17"
  :keywords '("convenience"))
