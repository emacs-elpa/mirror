;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xquery-mode" "0.1.0.0.20170214.293"
  "A simple mode for editing xquery programs."
  '((cl-lib "0.5"))
  :url "https://github.com/xquery-mode/xquery-mode"
  :commit "19e6f9553ce05380843582b879712de00679e4ab"
  :revdesc "19e6f9553ce0")
