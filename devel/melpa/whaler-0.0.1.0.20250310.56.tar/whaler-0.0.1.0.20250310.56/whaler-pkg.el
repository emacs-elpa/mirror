;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whaler" "0.0.1.0.20250310.56"
  "Minimalistic and customizable project manager."
  '((emacs "25.1")
    (f     "0.20.0")
    (dash  "2.19.1"))
  :url "https://github.com/salorak/whaler.el"
  :commit "9237c4c01b33dd3a6609372def616ae548fd49fc"
  :revdesc "9237c4c01b33"
  :keywords '("tools")
  :authors '(("Hector Salorak Alarcon" . "salorack@protonmail.com"))
  :maintainers '(("Hector Salorak Alarcon" . "salorack@protonmail.com")))
