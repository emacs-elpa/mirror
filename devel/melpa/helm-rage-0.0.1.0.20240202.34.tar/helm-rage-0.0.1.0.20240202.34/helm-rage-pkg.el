;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-rage" "0.0.1.0.20240202.34"
  "Helm command for rage characters."
  '((helm  "1.9.8")
    (emacs "24.4")
    (dash  "2.13.0")
    (s     "1.11.0"))
  :url "https://github.com/bomgar/helm-rage"
  :commit "5b5316b92fd2b5319f7296c7ccaa93d471935076"
  :revdesc "5b5316b92fd2"
  :keywords '("helm" "rage" "meme"))
