;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "www-synonyms" "0.0.5.0.20170128.2"
  "Insert synonym for a word."
  '((request "0.2.0")
    (cl-lib  "0.5"))
  :url "https://github.com/spebern/www-synonyms"
  :commit "7e37ea35064ff31c9945f0198a653647d408c936"
  :revdesc "7e37ea35064f"
  :keywords '("lisp")
  :authors '(("Bernhard Specht" . "bernhard@specht.net"))
  :maintainers '(("Bernhard Specht" . "bernhard@specht.net")))
