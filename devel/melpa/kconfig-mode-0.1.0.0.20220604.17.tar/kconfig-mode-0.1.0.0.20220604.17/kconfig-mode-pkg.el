;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kconfig-mode" "0.1.0.0.20220604.17"
  "Major mode for editing Kconfig files."
  '((emacs "24.3"))
  :url "https://github.com/delaanthonio/kconfig-mode"
  :commit "cd87b71c8c1739d026645ece0bbd20055a7a2d4a"
  :revdesc "cd87b71c8c17"
  :keywords '("kconfig" "languages" "linux" "kernel")
  :authors '(("Dela Anthonio" . "dell.anthonio@gmail.com"))
  :maintainers '(("Dela Anthonio" . "dell.anthonio@gmail.com")))
