;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.2.4.0.20260719.75"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "f64414e20c58a6b92255fd3f634785b0855ea8f5"
  :revdesc "f64414e20c58"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
