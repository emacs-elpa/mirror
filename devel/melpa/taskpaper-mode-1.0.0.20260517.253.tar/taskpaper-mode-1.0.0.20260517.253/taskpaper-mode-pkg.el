;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskpaper-mode" "1.0.0.20260517.253"
  "Major mode for TaskPaper files."
  '((emacs "25.1"))
  :url "https://github.com/saf-dmitry/taskpaper-mode"
  :commit "93a3c5fc3dde0c32f7a3b2ad313cb00d5660c5df"
  :revdesc "93a3c5fc3dde"
  :keywords '("outlines" "notetaking" "task management" "productivity" "taskpaper")
  :authors '(("Dmitry Safronov" . "saf.dmitry@gmail.com"))
  :maintainers '(("Dmitry Safronov" . "saf.dmitry@gmail.com")))
