;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ditz-mode" "0.3.0.20150729.3"
  "Emacs interface to Ditz issue tracking system."
  ()
  :commit "56668844acd91c3d15a08ba406dbb1ba0c2fe9b4"
  :revdesc "0.3-3-m56668844acd9"
  :keywords '("tools")
  :authors '(("Glenn Hutchings" . "zondo42@gmail.com"))
  :maintainers '(("Glenn Hutchings" . "zondo42@gmail.com")))
