;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "2.0.2.0.20260828.2"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "fe1fdfbd3b0dd6b696f286f7ed64993cfef6cc9d"
  :revdesc "v2.0.2-2-gfe1fdfbd3b0d"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
