;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-cider-history" "0.0.1.0.20150719.1"
  "Helm interface for cider history."
  '((helm  "1.4.0")
    (cider "0.9.0"))
  :url "https://github.com/Kungi/helm-cider-history"
  :commit "c391fcb2e162a02001605a0b9449783575a831fd"
  :revdesc "c391fcb2e162"
  :keywords '("convenience")
  :authors '(("Andreas Klein" . "git@kungi.org"))
  :maintainers '(("Andreas Klein" . "git@kungi.org")))
