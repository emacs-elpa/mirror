;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-zones" "0.5.3"
  "Time zone lookups."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/time-zones"
  :commit "6fe85710c9dd4b87c613a345e5c0191ecb6ec386"
  :revdesc "6fe85710c9dd")
