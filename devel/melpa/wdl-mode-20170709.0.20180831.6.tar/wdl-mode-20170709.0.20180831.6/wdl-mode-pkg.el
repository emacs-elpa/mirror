;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wdl-mode" "20170709.0.20180831.6"
  "WDL (Workflow Definition Language) major mode."
  ()
  :url "https://github.com/zhanxw/wdl-mode"
  :commit "cef86e5afc136ae5ad9324cd6e6d6f860b889bcf"
  :revdesc "cef86e5afc13"
  :keywords '("languages")
  :authors '(("Xiaowei Zhan" . "zhanxw@gmail.com"))
  :maintainers '(("Xiaowei Zhan" . "zhanxw@gmail.com")))
