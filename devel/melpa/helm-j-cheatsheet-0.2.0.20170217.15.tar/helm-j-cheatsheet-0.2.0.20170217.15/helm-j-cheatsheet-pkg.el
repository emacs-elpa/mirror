;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-j-cheatsheet" "0.2.0.20170217.15"
  "Quick J reference for Emacs."
  '((helm "1.5.3"))
  :url "https://github.com/abo-abo/helm-j-cheatsheet"
  :commit "6c47e7162b9ba2de4b41221d01180146973d860b"
  :revdesc "6c47e7162b9b"
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
