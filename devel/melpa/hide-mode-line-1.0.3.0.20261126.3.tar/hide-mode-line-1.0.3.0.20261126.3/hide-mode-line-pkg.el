;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hide-mode-line" "1.0.3.0.20261126.3"
  "Minor mode that hides/masks your modeline."
  '((emacs "24.4"))
  :url "https://github.com/hlissner/emacs-hide-mode-line"
  :commit "2325a2caf51b0978569add201b3e84815b5b7973"
  :revdesc "v1.0.3-3-g2325a2caf51b"
  :keywords '("frames" "mode-line")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
