;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fm-bookmarks" "0.1.0.20170104.12"
  "Use file manager bookmarks (eg Dolphin, Nautilus, PCManFM) in Dired."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/kuanyui/fm-bookmarks.el"
  :commit "11dacfd16a926bfecba96a94c6b13e162c7717f7"
  :revdesc "11dacfd16a92"
  :keywords '("files" "convenience")
  :authors '(("Ono Hiroko" . "azazabc123@gmail.com"))
  :maintainers '(("Ono Hiroko" . "azazabc123@gmail.com")))
