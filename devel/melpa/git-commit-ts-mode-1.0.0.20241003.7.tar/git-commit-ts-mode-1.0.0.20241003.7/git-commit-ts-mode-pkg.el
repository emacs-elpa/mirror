;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-commit-ts-mode" "1.0.0.20241003.7"
  "Tree-sitter support for Git commit messages."
  '((emacs "29.1"))
  :url "https://github.com/danilshvalov/git-commit-ts-mode"
  :commit "6eb42a3c08c5c6a1a610d433b93590b88a71f63e"
  :revdesc "6eb42a3c08c5"
  :keywords '("tree-sitter" "git" "faces")
  :authors '(("Daniil Shvalov" . "daniil.shvalov@gmail.com"))
  :maintainers '(("Daniil Shvalov" . "daniil.shvalov@gmail.com")))
