;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.7.0.0.20260802.1"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "f701e192a9ba1f1ec5d98388fff44cf22fc77dc1"
  :revdesc "f701e192a9ba"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
