;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-explore" "4.0.0.20260718.50"
  "Explore and visualise Denote files."
  '((emacs         "29.1")
    (denote        "4.2")
    (dash          "2.19.1")
    (denote-regexp "20250415.2202"))
  :url "https://github.com/pprevos/denote-explore/"
  :commit "ee5fea4143350ab9cfaa4d089caa55bcf9cfb383"
  :revdesc "ee5fea414335"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
