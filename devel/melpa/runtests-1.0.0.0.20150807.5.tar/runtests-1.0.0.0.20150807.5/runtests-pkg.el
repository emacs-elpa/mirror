;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "runtests" "1.0.0.0.20150807.5"
  "Run unit tests from Emacs."
  ()
  :url "https://github.com/sunesimonsen/emacs-runtests"
  :commit "ed90249f24cc48290018df48b9b9b7172440be3e"
  :revdesc "ed90249f24cc"
  :keywords '("test")
  :authors '(("Sune Simonsen" . "sune@we-knowhow.dk"))
  :maintainers '(("Sune Simonsen" . "sune@we-knowhow.dk")))
