;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaesar-pbkdf2" "0.9.1.0.20230626.17"
  "PBKDF2 extension for kaesar.el."
  '((emacs "25.1"))
  :url "https://github.com/mhayashi1120/Emacs-kaesar"
  :commit "740eaea4d2510b78d30cceabf4be2c3daca66cf7"
  :revdesc "740eaea4d251"
  :keywords '("data")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
