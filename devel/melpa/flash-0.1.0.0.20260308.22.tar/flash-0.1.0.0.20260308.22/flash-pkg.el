;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flash" "0.1.0.0.20260308.22"
  "Flash-style navigation."
  '((emacs "27.1"))
  :url "https://github.com/Prgebish/flash"
  :commit "42fbc5883fd802df97cae842c403deba4c433d45"
  :revdesc "42fbc5883fd8"
  :keywords '("convenience" "navigation")
  :authors '(("Vadim Pavlov" . "https://github.com/Prgebish"))
  :maintainers '(("Vadim Pavlov" . "https://github.com/Prgebish")))
