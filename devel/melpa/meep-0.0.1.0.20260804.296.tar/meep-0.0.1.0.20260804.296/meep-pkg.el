;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "0.0.1.0.20260804.296"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "bf25b5a749ff1edf77bcebc82ec7365e55fd1e60"
  :revdesc "bf25b5a749ff"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
