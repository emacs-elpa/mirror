;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "binky" "2.2.0.0.20260719.1"
  "Jump between points like a rabbit."
  '((emacs "29.1")
    (dash  "2.19.1"))
  :url "https://github.com/eki3z/binky.el"
  :commit "e24c4691d231f4b0f649e155d2c93cd83d3dc073"
  :revdesc "e24c4691d231"
  :keywords '("convenience")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
