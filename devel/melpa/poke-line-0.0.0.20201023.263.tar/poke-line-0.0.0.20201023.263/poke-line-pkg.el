;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poke-line" "0.0.0.20201023.263"
  "Minor mode to show position in a buffer using a Pokemon."
  '((emacs "24.3"))
  :url "https://github.com/RyanMillerC/poke-line/"
  :commit "8d484dbaa1215d902fbd1e3c9163b39a43ec532a"
  :revdesc "8d484dbaa121"
  :keywords '("pokemon" "fun" "mode-line" "mouse")
  :authors '(("Ryan Miller" . "ryan@devopsmachine.com"))
  :maintainers '(("Ryan Miller" . "ryan@devopsmachine.com")))
