;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "5.3.0.0.20260722.27"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "7d53a6959c92b40e3f819b134f7db93ec9a31352"
  :revdesc "7d53a6959c92"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
