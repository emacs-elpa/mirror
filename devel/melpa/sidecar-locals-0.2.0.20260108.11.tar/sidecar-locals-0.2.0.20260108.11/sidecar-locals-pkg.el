;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sidecar-locals" "0.2.0.20260108.11"
  "A flexible alternative to built-in dir-locals."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-sidecar-locals"
  :commit "0c969ab64bee11cce0917474eaf693418810712a"
  :revdesc "0c969ab64bee"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
