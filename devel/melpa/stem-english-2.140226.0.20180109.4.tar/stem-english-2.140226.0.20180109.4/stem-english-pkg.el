;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stem-english" "2.140226.0.20180109.4"
  "- routines for stemming English word."
  '((emacs "24.3"))
  :url "https://github.com/kawabata/stem-english"
  :commit "c9fc4c6ed6bf82382e479dae80912f4ae17d31f4"
  :revdesc "c9fc4c6ed6bf"
  :keywords '("text")
  :authors '(("Tsuchiya Masatoshi" . "tsuchiya@pine.kuee.kyoto-u.ac.jp"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
