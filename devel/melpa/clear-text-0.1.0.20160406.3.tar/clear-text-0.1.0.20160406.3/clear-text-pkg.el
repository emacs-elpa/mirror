;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clear-text" "0.1.0.20160406.3"
  "Make you use clear text."
  ()
  :url "https://github.com/xuchunyang/clear-text.el"
  :commit "b50669b6077d6948f72cb3c649281d206e0c2f2b"
  :revdesc "b50669b6077d"
  :keywords '("convenience")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
