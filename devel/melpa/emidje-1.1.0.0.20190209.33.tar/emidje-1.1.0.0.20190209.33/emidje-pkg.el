;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emidje" "1.1.0.0.20190209.33"
  "Test runner and report viewer for Midje."
  '((emacs       "25")
    (cider       "0.17.0")
    (seq         "2.16")
    (magit-popup "2.4.0"))
  :url "https://github.com/nubank/emidje"
  :commit "7e92f053964d925c97dc8cca8d4d70a3030021db"
  :revdesc "7e92f053964d"
  :keywords '("tools")
  :authors '(("Alan Ghelardi" . "alan.ghelardi@nubank.com.br"))
  :maintainers '(("Alan Ghelardi" . "alan.ghelardi@nubank.com.br")))
