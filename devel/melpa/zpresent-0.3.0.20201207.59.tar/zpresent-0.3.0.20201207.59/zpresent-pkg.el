;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zpresent" "0.3.0.20201207.59"
  "Simple presentation mode based on org files."
  '((emacs      "25.1")
    (org-parser "0.4")
    (dash       "2.12.0")
    (request    "0.3.0"))
  :url "https://hg.sr.ht/~zck/zpresent"
  :commit "341d1a4a91a8acff5be6b81f95695e17c79c5309"
  :revdesc "341d1a4a91a8"
  :keywords '("comm"))
