;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "titlecase" "0.4.1.0.20260622.11"
  "Title-case phrases."
  '((emacs "25.1"))
  :url "https://codeberg.org/acdw/titlecase.el"
  :commit "eb75d7539243832761e8e75782252fd7a489fb37"
  :revdesc "eb75d7539243"
  :authors '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainers '(("Case Duckworth" . "acdw@acdw.net")))
