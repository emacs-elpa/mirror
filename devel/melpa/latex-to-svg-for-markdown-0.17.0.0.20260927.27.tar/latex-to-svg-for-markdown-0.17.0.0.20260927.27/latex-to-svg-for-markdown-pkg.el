;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-markdown" "0.17.0.0.20260927.27"
  "Preview Markdown LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.11.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "bdbbc648cbcbf9fefb2bc238a1aebbc9fb8c8ffa"
  :revdesc "v0.17.0-27-gbdbbc648cbcb"
  :keywords '("tex" "markdown" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
