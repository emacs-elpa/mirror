;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sunshine" "0.1.0.20200306.20"
  "Provide weather and forecast information."
  '((cl-lib "0.5"))
  :url "https://github.com/aaronbieber/sunshine.el"
  :commit "88256223539edcfe57017778a997a474c9c022f6"
  :revdesc "88256223539e"
  :keywords '("tools" "weather")
  :authors '(("Aaron Bieber" . "aaron@aaronbieber.com"))
  :maintainers '(("Aaron Bieber" . "aaron@aaronbieber.com")))
