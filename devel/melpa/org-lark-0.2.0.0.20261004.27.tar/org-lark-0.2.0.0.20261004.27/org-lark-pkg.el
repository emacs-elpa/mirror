;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-lark" "0.2.0.0.20261004.27"
  "Export Lark docs to Org."
  '((emacs "27.1"))
  :url "https://github.com/bbw9n/org-lark"
  :commit "3ae8836da75607c4c5f4a6404977e06d78bf8b43"
  :revdesc "3ae8836da756"
  :keywords '("outlines" "hypermedia" "tools")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
