;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "batppuccin" "1.0.0.0.20260520.14"
  "Batppuccin (Catppuccin) color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/batppuccin-emacs"
  :commit "16a6f902cd2d9e25019b4c17a7ee41025f99b93d"
  :revdesc "16a6f902cd2d"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
