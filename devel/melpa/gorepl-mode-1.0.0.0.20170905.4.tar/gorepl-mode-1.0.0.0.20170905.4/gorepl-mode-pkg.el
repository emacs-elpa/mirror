;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gorepl-mode" "1.0.0.0.20170905.4"
  "Go REPL Interactive Development in top of Gore."
  '((emacs "24")
    (s     "1.11.0")
    (f     "0.19.0")
    (hydra "0.13.0"))
  :url "http://www.github.com/manute/gorepl-mode"
  :commit "bbd27f6a0a77f484e2a3f082d70dc69da63ae52a"
  :revdesc "bbd27f6a0a77"
  :keywords '("languages" "go" "golang" "gorepl")
  :authors '(("Manuel Alonso" . "manuteali@gmail.com"))
  :maintainers '(("Manuel Alonso" . "manuteali@gmail.com")))
