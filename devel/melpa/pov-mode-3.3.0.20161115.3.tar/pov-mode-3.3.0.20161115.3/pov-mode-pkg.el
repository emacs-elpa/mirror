;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pov-mode" "3.3.0.20161115.3"
  "Major mode for Povray scene files."
  ()
  :url "https://github.com/melmothx/pov-mode"
  :commit "9fc1db3aab7c27155674dd1a87ec62606035d074"
  :revdesc "9fc1db3aab7c"
  :keywords '("pov" "povray")
  :authors '(("Peter Boettcher" . "pwb@andrew.cmu.edu"))
  :maintainers '(("Marco Pessotto" . "melmothx@gmail.com")))
