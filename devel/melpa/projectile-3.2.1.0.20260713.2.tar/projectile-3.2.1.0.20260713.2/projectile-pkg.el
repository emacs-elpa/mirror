;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.2.1.0.20260713.2"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "cd674bb9cf979473d6d900911f3e3888b2eb3313"
  :revdesc "cd674bb9cf97"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
