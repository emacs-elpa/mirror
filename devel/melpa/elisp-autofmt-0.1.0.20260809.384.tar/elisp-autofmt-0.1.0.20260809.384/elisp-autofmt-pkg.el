;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-autofmt" "0.1.0.20260809.384"
  "Emacs lisp auto-format."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt"
  :commit "67a078fcd4199879189d602d8068f9d4c5d72616"
  :revdesc "67a078fcd419"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
