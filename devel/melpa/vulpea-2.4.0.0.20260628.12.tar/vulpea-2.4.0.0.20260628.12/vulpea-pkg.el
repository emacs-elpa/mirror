;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.4.0.0.20260628.12"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "b66c53ca0462adfc3e81909c01b5ca1be2cf5c67"
  :revdesc "v2.4.0-12-gb66c53ca0462"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
