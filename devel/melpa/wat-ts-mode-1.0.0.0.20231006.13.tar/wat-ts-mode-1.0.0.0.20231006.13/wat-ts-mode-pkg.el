;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wat-ts-mode" "1.0.0.0.20231006.13"
  "Major modes for webassembly text formats using tree sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/wat-ts-mode"
  :commit "d2bbd7dbb57482dc0407574d61b2dcad31b96204"
  :revdesc "d2bbd7dbb574"
  :keywords '("wasm" "wat" "wast" "languages" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
