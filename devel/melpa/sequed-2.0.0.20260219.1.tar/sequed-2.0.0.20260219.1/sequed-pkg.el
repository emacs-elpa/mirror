;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sequed" "2.0.0.20260219.1"
  "Major mode for FASTA and phylip/bpp DNA alignments."
  '((emacs "25.2"))
  :url "https://github.com/brannala/sequed"
  :commit "0156c71a163b7d55b2a8b198eab0be3de9dc229d"
  :revdesc "0156c71a163b"
  :authors '(("Bruce Rannala" . "brannala@ucdavis.edu"))
  :maintainers '(("Bruce Rannala" . "brannala@ucdavis.edu")))
