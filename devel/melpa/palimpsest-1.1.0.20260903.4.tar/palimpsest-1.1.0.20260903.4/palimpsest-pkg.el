;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "palimpsest" "1.1.0.20260903.4"
  "Various deletion strategies when editing."
  ()
  :url "https://github.com/danielsz/Palimpsest"
  :commit "9417fa2f84ee524b56b5883fff5653c05d1b99db"
  :revdesc "9417fa2f84ee"
  :authors '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com"))
  :maintainers '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com")))
