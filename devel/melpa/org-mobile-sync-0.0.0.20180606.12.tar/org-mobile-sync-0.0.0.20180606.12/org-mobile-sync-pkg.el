;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mobile-sync" "0.0.0.20180606.12"
  "Automatically sync org-mobile on changes."
  '((emacs "24.3.50")
    (org   "8.0"))
  :url "https://framagit.org/steckerhalter/org-mobile-sync"
  :commit "06764b943a528827df1e2acc6bc7806cc2c1351f"
  :revdesc "06764b943a52"
  :keywords '("org-mode" "org" "mobile" "sync" "todo"))
