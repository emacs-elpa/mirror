;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "0.8.3.0.20260726.389"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "6c82622dbd98ac8ea024f56490607151d9bd1032"
  :revdesc "6c82622dbd98"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
