;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gerrit" "0.4.0.20250825.23"
  "Magit plugin for Gerrit Code Review."
  '((emacs     "25.1")
    (magit     "2.90.1")
    (transient "0.3.0"))
  :url "https://github.com/emacsorphanage/magit-gerrit"
  :commit "d95d6d3febf7f9c04a4abefa3640610aae626683"
  :revdesc "v0.4-23-gd95d6d3febf7"
  :authors '(("Brian Fransioli" . "assem@terranpro.org"))
  :maintainers '(("Brian Fransioli" . "assem@terranpro.org")))
