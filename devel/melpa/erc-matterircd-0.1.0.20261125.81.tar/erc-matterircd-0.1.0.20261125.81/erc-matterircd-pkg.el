;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-matterircd" "0.1.0.20261125.81"
  "Integrate matterircd with ERC."
  '((emacs "27.1"))
  :url "https://github.com/alexmurray/erc-matterircd"
  :commit "f53e3e94b6f187d7c7f3c6ff35f149e30d52b0f9"
  :revdesc "f53e3e94b6f1"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
