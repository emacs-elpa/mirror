;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf" "4.1.0.0.20261028.217"
  "Simplify your init.el configuration, extended use-package."
  '((emacs "24.1"))
  :url "https://github.com/conao3/leaf.el"
  :commit "cf5f068664e89e4f57e2716184b37655ee4f564e"
  :revdesc "cf5f068664e8"
  :keywords '("lisp" "settings")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
