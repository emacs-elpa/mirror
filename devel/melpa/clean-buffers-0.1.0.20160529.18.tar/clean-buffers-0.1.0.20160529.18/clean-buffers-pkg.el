;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clean-buffers" "0.1.0.20160529.18"
  "Clean useless buffers."
  '((cl-lib "0.5"))
  :url "https://github.com/lujun9972/clean-buffers"
  :commit "1be6c54e3095761b6b64bf749faae3dfce94e72a"
  :revdesc "1be6c54e3095"
  :keywords '("convenience" "usability" "buffers")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
