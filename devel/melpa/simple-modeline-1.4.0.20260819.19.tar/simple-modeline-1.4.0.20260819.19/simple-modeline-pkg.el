;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-modeline" "1.4.0.20260819.19"
  "A simple mode-line configuration for Emacs."
  '((emacs "26.1"))
  :url "https://github.com/gexplorer/simple-modeline"
  :commit "db5a5f4f90ac4c383cfcbd938c1ea64cb1ec653f"
  :revdesc "db5a5f4f90ac"
  :keywords '("mode-line" "faces")
  :authors '(("Eder Elorriaga" . "gexplorer8@gmail.com"))
  :maintainers '(("Eder Elorriaga" . "gexplorer8@gmail.com")))
