;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.5.3.0.20260821.6"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "2524a7be022618134652e0b25184757843f3812a"
  :revdesc "v4.5.3-6-g2524a7be0226"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
