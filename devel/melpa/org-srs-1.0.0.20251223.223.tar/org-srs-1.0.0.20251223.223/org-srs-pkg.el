;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "1.0.0.20251223.223"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "c0aff45392b1f836fd943467cc266cef50899a44"
  :revdesc "c0aff45392b1"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
