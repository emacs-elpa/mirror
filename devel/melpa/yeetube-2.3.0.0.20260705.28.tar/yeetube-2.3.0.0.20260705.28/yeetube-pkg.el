;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "2.3.0.0.20260705.28"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "4bbb5c37b77811b69b2d4483bdb7042247c587a1"
  :revdesc "4bbb5c37b778"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
