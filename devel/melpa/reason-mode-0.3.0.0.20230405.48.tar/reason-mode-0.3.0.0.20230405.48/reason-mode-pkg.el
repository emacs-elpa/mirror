;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reason-mode" "0.3.0.0.20230405.48"
  "A major mode for editing ReasonML."
  '((emacs "24.3"))
  :url "https://github.com/reasonml-editor/reason-mode"
  :commit "d657ff75572a8ea7eda6fe22ada3a2ebf5bc6119"
  :revdesc "0.3.0-48-gd657ff75572a"
  :keywords '("languages" "ocaml"))
