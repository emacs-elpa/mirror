;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "1.0.43.0.20260402.143"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.5"))
  :url "https://github.com/joaotavora/sly"
  :commit "759c0ff8741ced8793257f2b7ed95a23e13e1407"
  :revdesc "759c0ff8741c"
  :keywords '("languages" "lisp" "sly"))
