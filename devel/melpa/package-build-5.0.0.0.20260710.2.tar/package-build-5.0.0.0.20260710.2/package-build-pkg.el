;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "5.0.0.0.20260710.2"
  "Curate an Emacs Lisp package archive."
  '((emacs  "26.1")
    (compat "31.0"))
  :url "https://github.com/melpa/package-build"
  :commit "d31dec67631f14ef8be3ad6438e172a07298082b"
  :revdesc "v5.0.0-2-gd31dec67631f"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
