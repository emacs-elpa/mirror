;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "0.13.0.0.20260921.4"
  "Linked notes and spaced repetition."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.4.4"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "497149ab7ab88c2acbd398803b15c3f9b9ab910a"
  :revdesc "497149ab7ab8"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
