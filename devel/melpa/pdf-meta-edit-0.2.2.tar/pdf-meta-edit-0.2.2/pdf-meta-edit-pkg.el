;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdf-meta-edit" "0.2.2"
  "Edit PDF metadata via pdftk."
  '((emacs  "24.3")
    (compat "29.1"))
  :url "https://github.com/krisbalintona/pdf-meta-edit"
  :commit "18d8b9156f15f77ed3f79152b221551c703b680c"
  :revdesc "18d8b9156f15"
  :keywords '("files" "data")
  :authors '(("Kristoffer Balintona" . "krisbalintona@gmail.com"))
  :maintainers '(("Kristoffer Balintona" . "krisbalintona@gmail.com")))
