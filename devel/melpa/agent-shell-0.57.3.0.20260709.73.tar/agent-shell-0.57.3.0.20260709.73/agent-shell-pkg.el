;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.57.3.0.20260709.73"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "3c8bd0b995c398625b8088a37f46939c0976e3d7"
  :revdesc "3c8bd0b995c3")
