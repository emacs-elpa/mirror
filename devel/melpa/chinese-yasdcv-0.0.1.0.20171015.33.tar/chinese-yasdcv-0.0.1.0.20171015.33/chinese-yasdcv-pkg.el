;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chinese-yasdcv" "0.0.1.0.20171015.33"
  "Yet another StarDict frontend."
  '((cl-lib "0.5")
    (pyim   "1.6.0"))
  :url "https://github.com/tumashu/chinese-yasdcv"
  :commit "5ab830daf1273d5a5cddcb94b56a9737f12d996f"
  :revdesc "5ab830daf127"
  :keywords '("convenience" "chinese" "dictionary")
  :authors '(("Feng Shu" . "tumashu@gmail.com"))
  :maintainers '(("Feng Shu" . "tumashu@gmail.com")))
