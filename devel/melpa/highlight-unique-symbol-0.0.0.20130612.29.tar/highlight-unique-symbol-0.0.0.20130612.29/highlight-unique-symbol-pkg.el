;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-unique-symbol" "0.0.0.20130612.29"
  "Highlight symbols which not appear in the repository."
  '((deferred "0.3.2"))
  :url "https://github.com/hitode909/emacs-highlight-unique-symbol"
  :commit "d760015b4a5ce31d6da5a30890b599a8e1312be5"
  :revdesc "d760015b4a5c"
  :authors '(("hitode909" . "hitode909@gmail.com"))
  :maintainers '(("hitode909" . "hitode909@gmail.com")))
