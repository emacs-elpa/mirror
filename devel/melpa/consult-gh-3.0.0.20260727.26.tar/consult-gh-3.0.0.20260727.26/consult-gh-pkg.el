;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh" "3.0.0.20260727.26"
  "Consulting GitHub Client."
  '((emacs         "29.4")
    (consult       "2.0")
    (markdown-mode "2.6")
    (ox-gfm        "1.0")
    (yaml          "1.2.0"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "fca05ab7598717a9aee91a54b7e49d2a175f2e98"
  :revdesc "fca05ab75987"
  :keywords '("convenience" "matching" "tools" "vc"))
