;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stickyfunc-enhance" "0.1.0.20150429.9"
  "An enhancement to stock `semantic-stickyfunc-mode'."
  '((emacs "24.3"))
  :url "https://github.com/tuhdo/semantic-stickyfunc-enhance"
  :commit "13bdba51fcd83ccbc3267959d23afc94d458dcb0"
  :revdesc "13bdba51fcd8"
  :keywords '("c" "languages" "tools")
  :authors '(("Do Hoang" . "tuhdo1710@gmail.com")))
