;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xref-rst" "0.1.0.20260528.30"
  "Lookup reStructuredText symbols."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-xref-rst"
  :commit "e54656eff9138d71c5d9ad7717675575b9f2b636"
  :revdesc "e54656eff913"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
