;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-clippy" "1.1.0"
  "Flymake backend for Clippy."
  '((emacs "27"))
  :url "https://github.com/mak-kirkland/flymake-clippy"
  :commit "38aeda6a8f4090b00f3c7fdb5188f80e04c556de"
  :revdesc "38aeda6a8f40"
  :keywords '("languages" "tools")
  :authors '(("Michael Kirkland" . "mak.kirkland@proton.me"))
  :maintainers '(("Michael Kirkland" . "mak.kirkland@proton.me")))
