;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-grep" "1.2.3.0.20221004.6"
  "Interactively-editable recursive grep implementation in elisp."
  '((cl-lib "0.1")
    (emacs  "26.1"))
  :url "https://github.com/zk-phi/phi-grep"
  :commit "9f3c42952ad4ad75d24abbdccb041240db4f0557"
  :revdesc "9f3c42952ad4")
