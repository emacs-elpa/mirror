;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buckwalter" "20171126.1.0.20191119.6"
  "Write arabic using Buckwalter transliteration."
  ()
  :url "https://github.com/joehakimrahme/buckwalter-arabic"
  :commit "1ef6f210f38c0686bc5b445b9704190f168f30ea"
  :revdesc "1ef6f210f38c"
  :keywords '("arabic" "transliteration" "i18n")
  :authors '(("Joe HAKIM RAHME" . "joehakimrahme@gmail.com"))
  :maintainers '(("Joe HAKIM RAHME" . "joehakimrahme@gmail.com")))
