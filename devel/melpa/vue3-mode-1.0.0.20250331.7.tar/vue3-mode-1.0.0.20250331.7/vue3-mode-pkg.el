;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vue3-mode" "1.0.0.20250331.7"
  "Syntax highlighting for modern Vue.js 3."
  '((emacs         "29.1")
    (polymode      "0.2.2")
    (vue-html-mode "0.2"))
  :url "https://github.com/vsalvino/vue3-mode"
  :commit "a1ad84c0cc5ea100dd11aeae9b52669918830730"
  :revdesc "a1ad84c0cc5e"
  :keywords '("languages" "vue")
  :authors '(("Vince Salvino" . "mvsalvino@gmail.com"))
  :maintainers '(("Vince Salvino" . "mvsalvino@gmail.com")))
