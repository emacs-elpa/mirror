;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-spotlight" "0.2.0.0.20260828.1"
  "Consult interface to macOS mdfind (Spotlight)."
  '((emacs   "28.1")
    (consult "2.0"))
  :url "https://github.com/guibor/consult-spotlight"
  :commit "3dbb491df1f18b3f7dd3ac34d766f2addbb20a32"
  :revdesc "3dbb491df1f1"
  :keywords '("matching" "files" "convenience")
  :authors '(("MDF" . "sguibor@gmail.com"))
  :maintainers '(("MDF" . "sguibor@gmail.com")))
