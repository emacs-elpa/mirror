;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darkman" "1.1.0.0.20260414.40"
  "Seamless integration with Darkman."
  '((emacs "28.1"))
  :url "https://darkman.grtcdr.tn"
  :commit "ee99dfcdc1f48330d0fbb565f8db7664eee34643"
  :revdesc "1.1.0-40-gee99dfcdc1f4"
  :keywords '("convenience")
  :authors '(("Taha Aziz Ben Ali" . "ba.tahaaziz@gmail.com"))
  :maintainers '(("Taha Aziz Ben Ali" . "ba.tahaaziz@gmail.com")))
