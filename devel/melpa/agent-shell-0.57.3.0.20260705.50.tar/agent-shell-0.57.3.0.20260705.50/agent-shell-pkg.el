;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.57.3.0.20260705.50"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c195435af22e7e690ed045180cc4655b4a66961b"
  :revdesc "c195435af22e")
