;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.4.0.20261003.11"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "9c21ff355ba14972aa72e4695498a591546659dd"
  :revdesc "9c21ff355ba1"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
