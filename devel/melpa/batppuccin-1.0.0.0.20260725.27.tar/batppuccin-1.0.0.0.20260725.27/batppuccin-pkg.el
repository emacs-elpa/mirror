;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "batppuccin" "1.0.0.0.20260725.27"
  "Batppuccin (Catppuccin) color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/batppuccin-emacs"
  :commit "58377838fbc8c367148c6ab72b84b0c31451fb5f"
  :revdesc "58377838fbc8"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
