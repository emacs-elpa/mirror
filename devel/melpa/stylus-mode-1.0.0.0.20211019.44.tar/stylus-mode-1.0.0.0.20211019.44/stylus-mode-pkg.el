;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stylus-mode" "1.0.0.0.20211019.44"
  "Major mode for editing .styl files."
  ()
  :url "https://github.com/brianc/jade-mode"
  :commit "1ad7c51f3c6a6ae64550d9510c5e4e8470014375"
  :revdesc "v1.0.0-44-g1ad7c51f3c6a"
  :keywords '("languages"))
