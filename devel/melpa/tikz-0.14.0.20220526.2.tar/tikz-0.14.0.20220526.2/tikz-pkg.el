;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tikz" "0.14.0.20220526.2"
  "A minor mode to edit TikZ pictures."
  '((emacs "24.1"))
  :url "https://github.com/emiliotorres/tikz"
  :commit "4b205afc5c88f050639135d1d57f1276db323842"
  :revdesc "4b205afc5c88"
  :keywords '("tex")
  :authors '(("Emilio Torres-Manzanera" . "torres@uniovi.es"))
  :maintainers '(("Emilio Torres-Manzanera" . "torres@uniovi.es")))
