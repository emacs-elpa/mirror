;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "versuri" "1.0.0.20211104.31"
  "The lyrics package."
  '((emacs    "26.1")
    (dash     "2.16.0")
    (request  "0.3.0")
    (anaphora "1.0.4")
    (esxml    "0.1.0")
    (s        "1.12.0")
    (esqlite  "0.3.1"))
  :url "https://github.com/mihaiolteanu/versuri/"
  :commit "c8ea562304194f3379ed8f9c6a785ce8ee72898e"
  :revdesc "c8ea56230419"
  :keywords '("multimedia")
  :authors '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainers '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm")))
