;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reddigg" "0.7.0.0.20260817.4"
  "A reader for redditt."
  '((emacs   "26.3")
    (promise "1.1")
    (ht      "2.3")
    (org     "9.2"))
  :url "https://github.com/thanhvg/emacs-reddigg"
  :commit "307b95026da1cb2450d153e0b77eb26d0d5a0980"
  :revdesc "307b95026da1"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
