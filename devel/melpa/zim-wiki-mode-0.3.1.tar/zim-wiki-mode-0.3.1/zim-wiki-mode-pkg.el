;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zim-wiki-mode" "0.3.1"
  "Zim Desktop Wiki edit mode."
  '((emacs           "25.1")
    (dokuwiki-mode   "0.1.1")
    (helm-projectile "0.14.0")
    (link-hint       "0.1")
    (pretty-hydra    "0.2.2"))
  :url "https://github.com/WillForan/zim-wiki-mode"
  :commit "d376b456b275975946e03a393ce16b122962195d"
  :revdesc "d376b456b275"
  :keywords '("outlines")
  :authors '(("Will Foran" . "willforan+zim-wiki-mode@gmail.com"))
  :maintainers '(("Will Foran" . "willforan+zim-wiki-mode@gmail.com")))
