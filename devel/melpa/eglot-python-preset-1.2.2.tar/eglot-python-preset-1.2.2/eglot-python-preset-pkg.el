;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-python-preset" "1.2.2"
  "Eglot preset for Python."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-python-preset"
  :commit "8705fa523e2b92850d399aff0180856f3e63f875"
  :revdesc "8705fa523e2b"
  :keywords '("python" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
