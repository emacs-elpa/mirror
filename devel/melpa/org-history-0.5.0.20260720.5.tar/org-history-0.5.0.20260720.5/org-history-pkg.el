;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-history" "0.5.0.20260720.5"
  "Show Dates for Org headers from vcs + auto-commit."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-org-history"
  :commit "8a24e4c85c3cce0c91e6aaf37748abccd0cea3ba"
  :revdesc "8a24e4c85c3c"
  :keywords '("org" "outline" "vc")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
