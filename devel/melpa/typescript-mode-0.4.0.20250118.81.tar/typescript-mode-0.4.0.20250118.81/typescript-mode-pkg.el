;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typescript-mode" "0.4.0.20250118.81"
  "Major mode for editing typescript."
  '((emacs "24.3"))
  :url "https://github.com/ananthakumaran/typescript.el"
  :commit "481df3ad2cdf569d8e6697679669ff6206fbd2f9"
  :revdesc "481df3ad2cdf"
  :keywords '("typescript" "languages"))
