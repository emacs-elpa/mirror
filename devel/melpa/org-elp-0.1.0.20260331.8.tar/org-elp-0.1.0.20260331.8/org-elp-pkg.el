;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-elp" "0.1.0.20260331.8"
  "Preview latex equations in org mode while editing."
  '((emacs    "27.1")
    (posframe "1.4.0"))
  :url "https://github.com/guanyilun/org-elp"
  :commit "ff2570307654a13f5818ddc110423ed51436449c"
  :revdesc "ff2570307654"
  :keywords '("lisp" "tex" "org"))
