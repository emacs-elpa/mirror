;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "window-jump" "0.1.0.0.20170809.12"
  "Move left/right/up/down through your windows."
  ()
  :url "https://github.com/chumpage/chumpy-windows"
  :commit "6bdb51e9a346907d60a9625f6180bddd06be6674"
  :revdesc "6bdb51e9a346"
  :keywords '("frames" "convenience"))
