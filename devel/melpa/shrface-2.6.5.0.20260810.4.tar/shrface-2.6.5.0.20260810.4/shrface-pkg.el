;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shrface" "2.6.5.0.20260810.4"
  "Extend shr/eww with org features and analysis capability."
  '((emacs              "25.1")
    (org                "9.0")
    (language-detection "0.1.0"))
  :url "https://github.com/chenyanming/shrface"
  :commit "6dad83387dcdd7b018c34c9ec6799926e54e66ec"
  :revdesc "6dad83387dcd"
  :keywords '("faces")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
