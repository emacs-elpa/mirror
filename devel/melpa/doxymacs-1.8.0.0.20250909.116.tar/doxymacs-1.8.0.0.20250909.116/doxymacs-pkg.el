;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doxymacs" "1.8.0.0.20250909.116"
  "Emacs integration with Doxygen."
  '((emacs  "24.4")
    (compat "28.1"))
  :url "https://pniedzielski.github.io/doxymacs/"
  :commit "869b378b724e4bf4b7e4976e2b8a549d744fc1d2"
  :revdesc "v1.8.0-116-g869b378b724e"
  :keywords '("c" "convenience" "tools")
  :authors '(("Patrick M. Niedzielski" . "patrick@pniedzielski.net")
             ("Ryan T. Sammartino" . "ryan.sammartino@gmail.com")
             ("Kris Verbeeck" . "kris.verbeeck@advalvas.be"))
  :maintainers '(("Patrick M. Niedzielski" . "patrick@pniedzielski.net")))
