;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "0blayout" "1.0.2.0.20190703.5"
  "Layout grouping with ease."
  ()
  :url "https://github.com/etu/0blayout"
  :commit "fd9a8f353dbd45b4628b5f84b8d8c2525ebf571d"
  :revdesc "1.0.2-5-gfd9a8f353dbd"
  :keywords '("convenience" "window-management"))
