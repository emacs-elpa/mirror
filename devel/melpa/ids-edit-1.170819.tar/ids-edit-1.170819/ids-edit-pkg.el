;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ids-edit" "1.170819"
  "IDS (Ideographic Description Sequence) editing tool."
  '((emacs "24.3"))
  :url "https://github.com/kawabata/ids-edit"
  :commit "8562a6cbfb3f2d44bc6f62ab15081a80f8fee502"
  :revdesc "8562a6cbfb3f"
  :keywords '("i18n" "wp")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
