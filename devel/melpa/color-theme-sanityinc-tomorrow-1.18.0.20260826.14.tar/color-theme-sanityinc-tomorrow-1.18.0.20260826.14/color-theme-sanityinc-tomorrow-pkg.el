;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-sanityinc-tomorrow" "1.18.0.20260826.14"
  "A version of Chris Kempson's \"tomorrow\" themes."
  '((emacs "24.1"))
  :url "https://github.com/purcell/color-theme-sanityinc-tomorrow"
  :commit "e3a94c399c0c490aa3be7b05c28952c520b65786"
  :revdesc "e3a94c399c0c"
  :keywords '("faces" "themes")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
