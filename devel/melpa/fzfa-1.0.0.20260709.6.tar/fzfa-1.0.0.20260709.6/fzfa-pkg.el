;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0.0.20260709.6"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.1"))
  :url "https://github.com/jojojames/fzfa"
  :commit "674166d5664a6191e84092026bf542a4a960b1f6"
  :revdesc "674166d5664a"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
