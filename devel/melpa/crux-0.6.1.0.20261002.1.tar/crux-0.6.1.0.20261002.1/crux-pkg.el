;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crux" "0.6.1.0.20261002.1"
  "A Collection of Ridiculously Useful eXtensions."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/crux"
  :commit "e769fe4a40813c8b1d1d869acbfee2323d2ed182"
  :revdesc "e769fe4a4081"
  :keywords '("convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
