;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "1.2.1.0.20260722.8"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "fa7905817ac6437b96a654dd6fe3278817ed803b"
  :revdesc "1.2.1-8-gfa7905817ac6"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
