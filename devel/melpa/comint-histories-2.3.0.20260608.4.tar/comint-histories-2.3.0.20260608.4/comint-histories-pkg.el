;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comint-histories" "2.3.0.20260608.4"
  "Many comint histories."
  '((emacs "29.1")
    (f     "0.21.0"))
  :url "https://github.com/NicholasBHubbard/comint-histories"
  :commit "e13c5ac7f812bc6f7da57c4640600b97356bd02b"
  :revdesc "e13c5ac7f812"
  :keywords '("convenience" "processes" "terminals")
  :authors '(("Nicholas Hubbard" . "nicholashubbard@posteo.net"))
  :maintainers '(("Nicholas Hubbard" . "nicholashubbard@posteo.net")))
