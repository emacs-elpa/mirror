;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-jami-bot" "0.0.4.0.20240203.2"
  "Capture GNU Jami messages as notes and todos in Org mode."
  '((emacs    "28.1")
    (jami-bot "0.0.4"))
  :url "https://gitlab.com/hperrey/org-jami-bot"
  :commit "020b03f299dad438f65d7bcbf93553b273fd7c33"
  :revdesc "020b03f299da"
  :keywords '("comm" "outlines" "org-capture" "jami")
  :authors '(("Hanno Perrey" . "hanno@hoowl.se"))
  :maintainers '(("Hanno Perrey" . "hanno@hoowl.se")))
