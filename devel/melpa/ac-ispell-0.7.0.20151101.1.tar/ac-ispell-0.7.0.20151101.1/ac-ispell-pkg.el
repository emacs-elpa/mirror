;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-ispell" "0.7.0.20151101.1"
  "Ispell completion source for auto-complete."
  '((auto-complete "1.4")
    (cl-lib        "0.5"))
  :url "https://github.com/syohex/emacs-ac-ispell"
  :commit "7e054793fe77f5fa1ced59d97da9c31df9807c48"
  :revdesc "7e054793fe77"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
