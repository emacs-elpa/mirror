;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pollen-mode" "1.0.0.20220904.17"
  "Major mode for editing pollen files."
  '((emacs  "24.3")
    (cl-lib "0.5"))
  :url "https://github.com/lijunsong/pollen-mode"
  :commit "19174fab69ce4d2ae903ef2c3da44054e8b84268"
  :revdesc "19174fab69ce"
  :keywords '("languages" "pollen" "pollenpub")
  :authors '(("Junsong Li" . "ljs.darkfishATGMAIL")))
