;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-languagetool" "0.5.0.0.20260818.6"
  "Flycheck support for LanguageTool."
  '((emacs    "27.1")
    (flycheck "39.0.0.20260813"))
  :url "https://github.com/emacs-languagetool/flycheck-languagetool"
  :commit "42c0757d1365f4a98a1eefc621eee69456de8815"
  :revdesc "42c0757d1365"
  :keywords '("convenience" "grammar" "check")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com")
             ("Peter Oliver" . "git@mavit.org.uk"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Peter Oliver" . "git@mavit.org.uk")))
