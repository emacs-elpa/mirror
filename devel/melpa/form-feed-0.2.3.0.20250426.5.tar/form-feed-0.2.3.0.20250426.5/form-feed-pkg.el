;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "form-feed" "0.2.3.0.20250426.5"
  "Display ^L glyphs as horizontal lines."
  '((emacs "25.1"))
  :url "https://depp.brause.cc/form-feed"
  :commit "6258fe6390a7bf264a6f02813502bf83a645d872"
  :revdesc "6258fe6390a7"
  :keywords '("faces")
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
