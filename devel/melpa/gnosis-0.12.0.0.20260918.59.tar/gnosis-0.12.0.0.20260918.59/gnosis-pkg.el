;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "0.12.0.0.20260918.59"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "78f5c62be6b6d1a9fa34f42b6a2f121c58471c7b"
  :revdesc "78f5c62be6b6"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
