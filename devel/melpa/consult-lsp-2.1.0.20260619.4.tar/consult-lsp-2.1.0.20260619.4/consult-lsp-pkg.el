;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-lsp" "2.1.0.20260619.4"
  "LSP-mode Consult integration."
  '((emacs    "27.1")
    (lsp-mode "5.0")
    (consult  "1.9")
    (f        "0.20.0"))
  :url "https://github.com/gagbo/consult-lsp"
  :commit "f41a3946987a3880068f95f3725bbb7b0d4b0b22"
  :revdesc "f41a3946987a"
  :keywords '("tools" "completion" "lsp"))
