;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbyac" "0.0.20150128.0.20180206.23"
  "Type a little Bit, and Bang! You Are Completed."
  '((browse-kill-ring "1.3")
    (cl-lib           "0.5"))
  :url "https://github.com/baohaojun/bbyac"
  :commit "9f0de9cad13801891ffb590dc09f51ff9a7cb225"
  :revdesc "9f0de9cad138"
  :keywords '("abbrev")
  :authors '(("Bao Haojun" . "baohaojun@gmail.com"))
  :maintainers '(("Bao Haojun" . "baohaojun@gmail.com")))
