;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-projectile" "1.6.0.0.20260708.1"
  "Helm integration for Projectile."
  '((emacs      "28.1")
    (helm       "3.0")
    (projectile "3.1.0"))
  :url "https://github.com/bbatsov/helm-projectile"
  :commit "a672a1f398374f82325faf2580d73341608c710a"
  :revdesc "a672a1f39837"
  :keywords '("project" "convenience"))
