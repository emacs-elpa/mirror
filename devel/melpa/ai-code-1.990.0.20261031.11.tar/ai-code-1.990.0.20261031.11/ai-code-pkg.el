;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.990.0.20261031.11"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "936bcf9e0097398bb09130cd9ac565a094c8d3a9"
  :revdesc "936bcf9e0097"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
