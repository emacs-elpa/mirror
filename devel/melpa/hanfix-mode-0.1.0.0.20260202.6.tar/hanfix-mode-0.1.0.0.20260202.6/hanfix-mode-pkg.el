;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hanfix-mode" "0.1.0.0.20260202.6"
  "Korean grammar checker."
  '((emacs "30.2"))
  :url "https://github.com/ntalbs/hanfix-mode"
  :commit "41f3a942cf7531dcb003932138e00e9ab4fa8214"
  :revdesc "41f3a942cf75"
  :keywords '("convenience" "wp")
  :authors '(("ntalbs" . "ntalbsen@gmail.com"))
  :maintainers '(("ntalbs" . "ntalbsen@gmail.com")))
