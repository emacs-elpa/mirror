;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crystal-point" "1.0.0.0.20250915.1"
  "Dynamic cursor color matching face at point."
  '((emacs "24.4"))
  :url "https://github.com/laluxx/crystal-point"
  :commit "bd7b9aca2f6153dd7d4bf3c74e4d138c77dcc748"
  :revdesc "bd7b9aca2f61"
  :keywords '("convenience" "cursor" "faces"))
