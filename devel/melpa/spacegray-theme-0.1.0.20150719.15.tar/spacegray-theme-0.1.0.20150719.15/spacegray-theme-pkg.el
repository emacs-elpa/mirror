;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spacegray-theme" "0.1.0.20150719.15"
  "A Hyperminimal UI Theme."
  '((emacs "24.1"))
  :url "https://github.com/bruce/emacs-spacegray-theme"
  :commit "7f70ee36297e5ccf9bc90b1f81472024f5a7a749"
  :revdesc "7f70ee36297e"
  :keywords '("themes")
  :authors '(("Bruce Williams" . "brwcodes@gmail.com"))
  :maintainers '(("Bruce Williams" . "brwcodes@gmail.com")))
