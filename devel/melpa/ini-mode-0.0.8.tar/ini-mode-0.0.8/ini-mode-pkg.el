;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ini-mode" "0.0.8"
  "Major mode for Windows-style ini files."
  '((emacs "24.1"))
  :url "https://github.com/Lindydancer/ini-mode"
  :commit "d99a27548a650b8ad531634419ae55f7b4dbe2fa"
  :revdesc "d99a27548a65"
  :keywords '("languages" "faces"))
