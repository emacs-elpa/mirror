;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nyan-mode" "1.1.3.0.20220408.8"
  "Nyan Cat shows position in current buffer in mode-line."
  '((emacs "24.1"))
  :url "https://github.com/TeMPOraL/nyan-mode/"
  :commit "09904af23adb839c6a9c1175349a1fb67f5b4370"
  :revdesc "v1.1.3-8-g09904af23adb"
  :keywords '("convenience" "games" "mouse" "multimedia")
  :authors '(("Jacek TeMPOraL Zlydach" . "temporal.pl@gmail.com"))
  :maintainers '(("Jacek TeMPOraL Zlydach" . "temporal.pl@gmail.com")))
