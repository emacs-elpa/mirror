;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haxe-mode" "0.3.3.0.20260103.44"
  "Major mode for editing Haxe files."
  ()
  :url "https://github.com/emacsorphanage/haxe-mode"
  :commit "6ffa81f6d1fa81b7b9ae2e68d22b0d4c872cf59d"
  :revdesc "6ffa81f6d1fa"
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
