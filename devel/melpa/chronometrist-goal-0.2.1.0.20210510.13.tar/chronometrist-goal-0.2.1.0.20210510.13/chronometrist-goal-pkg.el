;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chronometrist-goal" "0.2.1.0.20210510.13"
  "Adds support for time goals to Chronometrist."
  '((emacs         "25.1")
    (alert         "1.2")
    (chronometrist "0.7.0"))
  :url "https://tildegit.org/contrapunctus/chronometrist-goal"
  :commit "6cb939d160f5d5966d7853aa23f3ed7c7ef9df44"
  :revdesc "6cb939d160f5"
  :keywords '("calendar")
  :authors '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainers '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr")))
