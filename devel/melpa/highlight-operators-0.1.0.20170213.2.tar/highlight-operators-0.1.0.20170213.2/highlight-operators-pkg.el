;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-operators" "0.1.0.20170213.2"
  "A face for operators in programming modes."
  ()
  :url "https://github.com/jpkotta/highlight-operators"
  :commit "7696b43419505d6e3511ad2781f9f1dd3c55ef8c"
  :revdesc "7696b4341950"
  :authors '(("Jonathan Kotta" . "jpkotta@gmail.com"))
  :maintainers '(("Jonathan Kotta" . "jpkotta@gmail.com")))
