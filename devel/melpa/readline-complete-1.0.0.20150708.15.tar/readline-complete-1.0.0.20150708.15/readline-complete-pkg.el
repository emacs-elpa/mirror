;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "readline-complete" "1.0.0.20150708.15"
  "Offers completions in shell mode."
  ()
  :url "https://github.com/monsanto/readline-complete.el"
  :commit "30c020c37b2741160cc37e656e13c85d826a0ebf"
  :revdesc "30c020c37b27"
  :authors '(("Christopher Monsanto" . "chris@monsan.to"))
  :maintainers '(("Christopher Monsanto" . "chris@monsan.to")))
