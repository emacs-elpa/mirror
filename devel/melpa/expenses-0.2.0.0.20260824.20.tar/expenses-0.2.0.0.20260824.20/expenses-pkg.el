;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "expenses" "0.2.0.0.20260824.20"
  "Record and view expenses."
  '((emacs     "28.1")
    (dash      "2.19.1")
    (ht        "2.3")
    (transient "0.3.7"))
  :url "https://github.com/md-arif-shaikh/expenses"
  :commit "38e5b3eb49daa00ec0f8de81bc28651afe105d11"
  :revdesc "38e5b3eb49da"
  :keywords '("expense tracking" "convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
