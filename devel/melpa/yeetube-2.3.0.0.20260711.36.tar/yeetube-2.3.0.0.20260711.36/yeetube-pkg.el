;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "2.3.0.0.20260711.36"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "d2bef269fc1d00ccc88de0932430ae56165f4671"
  :revdesc "d2bef269fc1d"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
