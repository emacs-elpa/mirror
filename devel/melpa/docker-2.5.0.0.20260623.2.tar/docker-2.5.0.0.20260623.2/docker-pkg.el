;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "2.5.0.0.20260623.2"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "2128c0d432f4cc0feef21d1e1c11398a3ee2432b"
  :revdesc "2.5.0-2-g2128c0d432f4"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
