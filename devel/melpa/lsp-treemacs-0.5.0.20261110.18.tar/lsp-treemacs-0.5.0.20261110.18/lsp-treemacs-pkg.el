;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-treemacs" "0.5.0.20261110.18"
  "LSP treemacs."
  '((emacs    "29.1")
    (dash     "2.18.0")
    (f        "0.20.0")
    (ht       "2.0")
    (treemacs "2.5")
    (lsp-mode "6.0"))
  :url "https://github.com/emacs-lsp/lsp-treemacs"
  :commit "a3d1596fdf054b89bdbb12941b2bea6b31bb8686"
  :revdesc "a3d1596fdf05"
  :keywords '("languages"))
