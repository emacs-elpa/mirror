;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-table-comment" "0.2.0"
  "Org table comment modes."
  ()
  :url "https://github.com/mlf176f2/org-table-comment.el"
  :commit "33b9966c33ecbc3e27cca67c2f2cdea04364d74e"
  :revdesc "33b9966c33ec"
  :keywords '("org-mode" "orgtbl")
  :authors '(("Matthew L. Fidler" . "matthewdotfidleratgmail.com")))
