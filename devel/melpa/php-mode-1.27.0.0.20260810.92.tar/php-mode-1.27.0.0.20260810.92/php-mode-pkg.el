;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "1.27.0.0.20260810.92"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "fdcba033490bf974c465f09f1590277772d46eb0"
  :revdesc "fdcba033490b"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
