;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "csound-mode" "0.2.1.0.20260717.93"
  "A major mode for interacting and coding Csound."
  '((emacs "27.1"))
  :url "https://github.com/hlolli/csound-mode"
  :commit "8ec473e4dbd10a86e332f63003392b2e89469e69"
  :revdesc "8ec473e4dbd1"
  :authors '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers '(("Hlöðver Sigurðsson" . "hlolli@gmail.com")))
