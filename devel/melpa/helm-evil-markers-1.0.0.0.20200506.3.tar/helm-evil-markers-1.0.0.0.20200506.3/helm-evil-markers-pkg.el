;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-evil-markers" "1.0.0.0.20200506.3"
  "Show evil markers with helm."
  '((emacs "25.1")
    (helm  "2.0.0")
    (evil  "1.2.10"))
  :url "https://github.com/xueeinstein/helm-evil-markers"
  :commit "0245f0c268e0eaec85df51ab2deba7ac961f6770"
  :revdesc "0245f0c268e0"
  :keywords '("extensions"))
