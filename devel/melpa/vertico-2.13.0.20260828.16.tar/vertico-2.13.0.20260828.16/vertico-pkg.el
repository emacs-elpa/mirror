;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "2.13.0.20260828.16"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "024365aced4d6f316d20e5ce65cf3fd9659d3b4e"
  :revdesc "2.13-16-g024365aced4d"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
