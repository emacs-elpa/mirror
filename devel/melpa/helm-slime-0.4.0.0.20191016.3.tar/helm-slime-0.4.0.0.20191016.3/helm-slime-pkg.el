;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-slime" "0.4.0.0.20191016.3"
  "Helm-sources and some utilities for SLIME."
  '((emacs  "25")
    (helm   "3.2")
    (slime  "2.18")
    (cl-lib "0.5"))
  :url "https://github.com/emacs-helm/helm-slime"
  :commit "7886cc49906a87ebd73be3b71f5dd6b1433a9b7b"
  :revdesc "7886cc49906a"
  :keywords '("convenience" "helm" "slime")
  :authors '(("Takeshi Banse" . "takebi@laafc.net"))
  :maintainers '(("Takeshi Banse" . "takebi@laafc.net")))
