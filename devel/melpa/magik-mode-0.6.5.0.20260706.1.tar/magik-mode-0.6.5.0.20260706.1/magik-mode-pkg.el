;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "0.6.5.0.20260706.1"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "ed8e8dce0e7bb552beda9649790b8ff9a6e1ae3b"
  :revdesc "ed8e8dce0e7b"
  :keywords '("languages"))
