;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.2.1.0.20260718.5"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "a5c1ad7d1b73676327fb62cb055eaab1ae139981"
  :revdesc "a5c1ad7d1b73"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
