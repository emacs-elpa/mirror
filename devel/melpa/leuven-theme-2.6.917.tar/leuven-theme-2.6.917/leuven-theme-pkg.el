;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leuven-theme" "2.6.917"
  "Elegant Emacs color theme for a white background."
  ()
  :url "https://github.com/fniessen/emacs-leuven-theme"
  :commit "2f969a336527abbdce05b19b6c4f6ae0e9641f46"
  :revdesc "v2.6.0917-0-g2f969a336527"
  :keywords '("color" "theme")
  :authors '(("Fabrice Niessen" . ""))
  :maintainers '(("Fabrice Niessen" . "")))
