;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "4.0.7.0.20260618.17"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "558427bf221a61014e25d1be3a29dbebad277973"
  :revdesc "v4.0.7-17-g558427bf221a"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
