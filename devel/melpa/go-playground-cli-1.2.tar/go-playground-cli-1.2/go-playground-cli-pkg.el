;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-playground-cli" "1.2"
  "Go Playground client tool."
  '((emacs     "24")
    (request   "0.2.0")
    (deferred  "0.3.2")
    (names     "20151201.404")
    (s         "1.10.0")
    (f         "0.17.2")
    (let-alist "1.0.4")
    (cl-lib    "0.5"))
  :url "https://github.com/kosh04/go-playground-cli"
  :commit "60beebd98e3930641d41cee0189c579626f223bc"
  :revdesc "60beebd98e39"
  :authors '(("KOBAYASHI Shigeru" . "shigeru.kb@gmail.com"))
  :maintainers '(("KOBAYASHI Shigeru" . "shigeru.kb@gmail.com")))
