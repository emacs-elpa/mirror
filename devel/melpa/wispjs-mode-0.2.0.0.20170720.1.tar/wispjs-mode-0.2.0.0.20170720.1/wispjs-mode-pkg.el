;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wispjs-mode" "0.2.0.0.20170720.1"
  "Major mode for Wisp code."
  '((clojure-mode "0"))
  :url "https://github.com/krisajenkins/wispjs-mode"
  :commit "60f9f5fd9d1556e2d008939f67eb1b1d0f325fa8"
  :revdesc "60f9f5fd9d15"
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
