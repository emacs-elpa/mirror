;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "29.0.3"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "40ea544c97aa8492596f35a88286ea80326510ec"
  :revdesc "OTP-29.0.3-0-g40ea544c97aa"
  :keywords '("erlang" "languages" "processes"))
