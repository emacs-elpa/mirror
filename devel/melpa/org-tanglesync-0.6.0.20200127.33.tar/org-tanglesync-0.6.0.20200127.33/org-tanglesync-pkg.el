;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tanglesync" "0.6.0.20200127.33"
  "Syncing org src blocks with tangled external files."
  '((emacs "24.4"))
  :url "https://github.com/mtekman/org-tanglesync.el"
  :commit "31aa5502d1d4f8b032807949908c016b00556684"
  :revdesc "31aa5502d1d4"
  :keywords '("outlines"))
