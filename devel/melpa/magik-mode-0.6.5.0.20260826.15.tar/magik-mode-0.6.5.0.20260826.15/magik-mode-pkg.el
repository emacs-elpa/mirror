;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "0.6.5.0.20260826.15"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "b972837d59874fe5fbfceeebbfc7031892fc9233"
  :revdesc "b972837d5987"
  :keywords '("languages"))
