;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.39.0.0.20260630.18"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "0f0a9bddb150c431a32742efca4b19a51a59b042"
  :revdesc "0f0a9bddb150"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
