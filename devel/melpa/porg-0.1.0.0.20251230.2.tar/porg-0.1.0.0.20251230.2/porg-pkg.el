;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "porg" "0.1.0.0.20251230.2"
  "Bring org-mode features to any prog mode."
  '((emacs "26.1"))
  :url "https://github.com/laluxx/porg"
  :commit "557fecde1f02fa7ffb13b0dc5da3432171946086"
  :revdesc "557fecde1f02"
  :keywords '("folding" "convenience" "org-mode"))
