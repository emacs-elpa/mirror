;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claude-code" "0.9.2"
  "Run Claude Code sessions."
  '((emacs         "28.1")
    (projectile    "2.5.0")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (markdown-mode "2.5"))
  :url "https://github.com/yuya373/claude-code-emacs"
  :commit "77b3edc129f947859e500a363ce767d0555e57e1"
  :revdesc "77b3edc129f9"
  :keywords '("tools" "convenience"))
