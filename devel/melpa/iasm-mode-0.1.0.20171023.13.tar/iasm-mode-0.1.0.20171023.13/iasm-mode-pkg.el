;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iasm-mode" "0.1.0.20171023.13"
  "Interactive assembly major mode."
  ()
  :url "https://github.com/RAttab/iasm-mode"
  :commit "abbec7f308f9ce97beeb57e459fff35f559b4c18"
  :revdesc "abbec7f308f9"
  :keywords '(":" "tools")
  :authors '(("Rémi Attab" . "remi.attab@gmail.com"))
  :maintainers '(("Rémi Attab" . "remi.attab@gmail.com")))
