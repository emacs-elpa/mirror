;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "most-faces" "0.2.0.20250606.4"
  "A List of Most Available Faces."
  '((emacs "24"))
  :url "https://codeberg.org/mekeor/most-faces"
  :commit "6b97ecab10d0a9e6e9faaecac3af543263fe658a"
  :revdesc "6b97ecab10d0"
  :keywords '("faces")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
