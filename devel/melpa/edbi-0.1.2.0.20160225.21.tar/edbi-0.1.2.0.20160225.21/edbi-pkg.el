;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edbi" "0.1.2.0.20160225.21"
  "Database independent interface for Emacs."
  ()
  :url "https://github.com/kiwanami/emacs-edbi"
  :commit "6f50aaf4bde75255221f2292c7a4ad3fa9d918c0"
  :revdesc "6f50aaf4bde7"
  :keywords '("database" "epc")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net")))
