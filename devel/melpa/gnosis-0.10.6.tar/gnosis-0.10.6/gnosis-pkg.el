;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "0.10.6"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://codeberg.org/thanosapollo/emacs-gnosis"
  :commit "07de9c67536fe3e8c5fef1daf61527f3bcfa46a7"
  :revdesc "07de9c67536f"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
