;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "1.0.5.0.20260809.84"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "b9b3456d42f1a6a9e6046a1cfeab5f569e6d92b9"
  :revdesc "cfn-mode/v1.0.5-84-gb9b3456d42f1"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
