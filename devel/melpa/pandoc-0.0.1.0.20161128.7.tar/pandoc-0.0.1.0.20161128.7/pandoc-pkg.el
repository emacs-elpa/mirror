;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pandoc" "0.0.1.0.20161128.7"
  "Pandoc interface."
  '((emacs "24.4"))
  :url "https://github.com/zonuexe/pandoc.el"
  :commit "198d262d09e30448f1672338b0b5a81cf75e1eaa"
  :revdesc "198d262d09e3"
  :keywords '("hypermedia" "documentation" "markup" "converter")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
