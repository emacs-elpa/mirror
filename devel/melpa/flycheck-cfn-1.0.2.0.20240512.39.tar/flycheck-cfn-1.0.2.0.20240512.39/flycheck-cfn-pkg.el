;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-cfn" "1.0.2.0.20240512.39"
  "Flycheck backend for AWS cloudformation."
  '((emacs    "27.0")
    (flycheck "31"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "b26a95a219aa700256b22fd026cace57bce1701b"
  :revdesc "flycheck-cfn/v1.0.2-39-gb26a95a219aa"
  :keywords '("convenience")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
