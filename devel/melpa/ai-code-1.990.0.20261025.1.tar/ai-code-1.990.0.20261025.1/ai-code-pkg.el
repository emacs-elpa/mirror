;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.990.0.20261025.1"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "90030b5dfd7e556b0a12e4399b09498265685115"
  :revdesc "90030b5dfd7e"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
