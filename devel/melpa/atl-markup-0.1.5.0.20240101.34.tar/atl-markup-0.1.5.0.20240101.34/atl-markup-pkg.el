;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atl-markup" "0.1.5.0.20240101.34"
  "Automatically truncate lines for markup languages."
  '((emacs "24.3"))
  :url "https://github.com/jcs-elpa/atl-markup"
  :commit "b616343ffe17060d521b214b8e90f5da1e880934"
  :revdesc "b616343ffe17"
  :keywords '("convenience" "automatic" "truncate" "visual" "lines")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
