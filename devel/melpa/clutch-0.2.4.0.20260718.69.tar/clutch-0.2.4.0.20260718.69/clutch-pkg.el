;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.2.4.0.20260718.69"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "9467c41b49bd9e98fd0e1b8a87a73a5b906b6cf2"
  :revdesc "9467c41b49bd"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
