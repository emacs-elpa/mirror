;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubernetes-evil" "0.19.0"
  "Kubernetes keybindings for evil-mode."
  '((kubernetes "0.18.0")
    (evil       "1.2.12"))
  :url "https://github.com/kubernetes-el/kubernetes-el"
  :commit "54ad1b11ca6ceff8a7931271d8c694ad2e6ade4c"
  :revdesc "54ad1b11ca6c"
  :authors '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainers '(("Chris Barrett" . "chris+emacs@walrus.cool")))
