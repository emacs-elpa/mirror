;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.900.0.20260813.41"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "cd48cae0bbcd3e054e81959216118b45ffed3ad1"
  :revdesc "cd48cae0bbcd"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
