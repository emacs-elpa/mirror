;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "irony" "1.6.1"
  "C/C++ minor mode powered by libclang."
  '((cl-lib "0.5")
    (json   "1.2"))
  :url "https://github.com/Sarcasm/irony-mode"
  :commit "40e0ce19eb850bdf1f77225f11713cc816250d95"
  :revdesc "v1.6.1-0-g40e0ce19eb85"
  :keywords '("c" "convenience" "tools")
  :authors '(("Guillaume Papin" . "guillaume.papin@epitech.eu"))
  :maintainers '(("Guillaume Papin" . "guillaume.papin@epitech.eu")))
