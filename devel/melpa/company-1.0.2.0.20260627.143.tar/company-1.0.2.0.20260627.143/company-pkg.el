;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "1.0.2.0.20260627.143"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "a8c75c5d3fd7eb50b57a5b6aecc9aca58a3e9fcf"
  :revdesc "a8c75c5d3fd7"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
