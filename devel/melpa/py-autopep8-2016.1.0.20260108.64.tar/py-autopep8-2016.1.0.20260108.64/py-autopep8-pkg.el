;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-autopep8" "2016.1.0.20260108.64"
  "Use autopep8 to beautify a Python buffer."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-py-autopep8"
  :commit "f07d487a6cd63a8c8a44ec8b5e93b762aca97566"
  :revdesc "f07d487a6cd6"
  :keywords '("convenience")
  :authors '(("Friedrich Paetzke" . "f.paetzke@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
