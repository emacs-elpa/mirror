;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "listenbrainz" "0.1.0.20260603.13"
  "ListenBrainz API interface."
  '((emacs   "27.1")
    (request "0.3"))
  :url "https://github.com/zzkt/metabrainz"
  :commit "abd37d9f1c25a021b32eac54e6deff6080a66bca"
  :revdesc "abd37d9f1c25"
  :keywords '("music" "scrobbling" "multimedia")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
