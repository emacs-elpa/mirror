;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "1.0.6"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "8f794001a98057aac7395ef4e2230ebfb6eb40b6"
  :revdesc "1.0.6-0-g8f794001a980"
  :keywords '("languages" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
