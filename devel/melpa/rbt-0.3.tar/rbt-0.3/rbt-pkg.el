;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rbt" "0.3"
  "Integrate reviewboard with emacs."
  '((popup "0.5.3")
    (magit "20160128.1201"))
  :url "https://github.com/joeheyming/rbt.el"
  :commit "32bfba9062a014e375451cf4203c29535b5efc1e"
  :revdesc "32bfba9062a0"
  :keywords '("reviewboard" "rbt")
  :authors '(("Joe Heyming" . "joeheyming@gmail.com"))
  :maintainers '(("Joe Heyming" . "joeheyming@gmail.com")))
