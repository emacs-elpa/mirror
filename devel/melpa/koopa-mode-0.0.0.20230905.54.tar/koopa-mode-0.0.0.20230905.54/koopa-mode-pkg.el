;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "koopa-mode" "0.0.0.20230905.54"
  "A major mode for Microsoft PowerShell."
  '((company "0.9.13")
    (emacs   "27.1"))
  :url "https://github.com/sch0lars/koopa-mode"
  :commit "82c81a641e106f270d45427f6d0139aabbd8523c"
  :revdesc "82c81a641e10"
  :keywords '("powershell" "convenience"))
