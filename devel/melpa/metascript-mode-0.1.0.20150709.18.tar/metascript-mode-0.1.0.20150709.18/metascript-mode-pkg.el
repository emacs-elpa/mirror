;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metascript-mode" "0.1.0.20150709.18"
  "Major mode for the Metascript programming language."
  '((emacs "24.3"))
  :url "https://github.com/metascript/metascript-mode"
  :commit "edb361c7b0e5de231e5334a17b90652fb1df78f9"
  :revdesc "edb361c7b0e5"
  :keywords '("languages" "metascript" "mjs")
  :authors '(("Rodrigo B. de Oliveira" . "rbo@acm.org"))
  :maintainers '(("Rodrigo B. de Oliveira" . "rbo@acm.org")))
