;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "opam-switch-mode" "1.7.0.20230802.2"
  "Select OCaml opam switches via a menu."
  '((emacs "25.1"))
  :url "https://github.com/ProofGeneral/opam-switch-mode"
  :commit "1069e56a662f23ea09d4e05611bdedeb99257012"
  :revdesc "1.7-2-g1069e56a662f"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
