;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "impostman" "0.2.0.0.20260805.31"
  "Import Postman collections."
  '((emacs "27.1"))
  :url "https://github.com/flashcode/impostman"
  :commit "341e44c3586e83412782a8b35cc184693e5fdba7"
  :revdesc "v0.2.0-31-g341e44c3586e"
  :keywords '("tools")
  :authors '(("Sébastien Helleu" . "flashcode@flashtux.org"))
  :maintainers '(("Sébastien Helleu" . "flashcode@flashtux.org")))
