;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "1.0.9"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "a774ac4cba86c93300b14bb7bc4fcb8ca5b817c6"
  :revdesc "1.0.9-0-ga774ac4cba86"
  :keywords '("tools" "convenience" "text"))
