;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "0.3.0.20261003.1"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "7ec1aa6fed6c0a4dc92db94d46773b77d5ad1b97"
  :revdesc "7ec1aa6fed6c"
  :keywords '("comm")
  :authors '(("Fabian Markl" . "fabian@markl.dev"))
  :maintainers '(("Fabian Markl" . "fabian@markl.dev")))
