;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.66.0.0.20261117.2"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "467e0af733561e6dba43098fb71da5d021bd91da"
  :revdesc "467e0af73356"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
