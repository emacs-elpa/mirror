;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-cs-fixer" "2.1.1.0.20250211.4"
  "The php-cs-fixer wrapper."
  '((emacs "24.3"))
  :url "https://github.com/pivaldi/php-cs-fixer"
  :commit "4bf549c1dedad2a2a52257b866bcb180a31f129d"
  :revdesc "4bf549c1deda"
  :keywords '("languages" "php"))
