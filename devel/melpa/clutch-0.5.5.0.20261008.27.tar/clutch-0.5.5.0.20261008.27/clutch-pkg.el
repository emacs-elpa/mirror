;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.5.0.20261008.27"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "26fdc068ef28ce684c316164dcae96f1214f0a42"
  :revdesc "26fdc068ef28"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
