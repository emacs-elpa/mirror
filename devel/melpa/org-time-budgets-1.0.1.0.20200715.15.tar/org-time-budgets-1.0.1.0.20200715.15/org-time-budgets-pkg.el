;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-time-budgets" "1.0.1.0.20200715.15"
  "Define time budgets and display clocked time."
  '((alert  "0.5.10")
    (cl-lib "0.5"))
  :url "https://github.com/leoc/org-time-budgets"
  :commit "1d6bfc323013bbf725167842d9e097fad805de03"
  :revdesc "1d6bfc323013"
  :authors '(("Arthur Leonard Andersen" . "leoc.git@gmail.com"))
  :maintainers '(("Arthur Leonard Andersen" . "leoc.git@gmail.com")))
