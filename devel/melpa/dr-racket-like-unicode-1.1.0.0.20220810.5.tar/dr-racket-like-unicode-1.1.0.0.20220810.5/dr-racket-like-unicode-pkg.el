;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dr-racket-like-unicode" "1.1.0.0.20220810.5"
  "DrRacket-style unicode input."
  '((emacs "24.3"))
  :url "https://github.com/david-christiansen/dr-racket-like-unicode"
  :commit "d09b9be289e91e25c941107be5e8f52e7c8f0065"
  :revdesc "d09b9be289e9"
  :keywords '("i18n" "tools")
  :authors '(("David Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Christiansen" . "david@davidchristiansen.dk")))
