;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hippo-themes" "0.0.0.20250929.15"
  "Hippo color theme."
  '((emacs "24.1"))
  :url "https://github.com/kimim/emacs-hippo-theme"
  :commit "8eb27d6bf632bb466d242334adfbbe9c027dd8c5"
  :revdesc "8eb27d6bf632"
  :keywords '("faces" "local" "color" "theme"))
