;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kixtart-mode" "1.4.4.0.20260831.3"
  "Major mode for editing KiXtart scripts."
  '((emacs "28.1")
    (eldoc "1.14.0"))
  :url "https://git.sr.ht/~mew/kixtart-mode"
  :commit "e534609ca0ffbd3cf1a5c6f464861d75d14b7cda"
  :revdesc "v1.4.4-3-ge534609ca0ff"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
