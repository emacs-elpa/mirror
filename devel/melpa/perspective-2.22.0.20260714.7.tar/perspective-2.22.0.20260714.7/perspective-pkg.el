;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective" "2.22.0.20260714.7"
  "Switch between named \"perspectives\" of the editor."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/nex3/perspective-el"
  :commit "d8bc18cd511136fc1b44f5fe85c7691b0aa89083"
  :revdesc "2.22-7-gd8bc18cd5111"
  :keywords '("workspace" "convenience" "frames")
  :authors '(("Natalie Weizenbaum" . "nex342@gmail.com"))
  :maintainers '(("Natalie Weizenbaum" . "nex342@gmail.com")))
