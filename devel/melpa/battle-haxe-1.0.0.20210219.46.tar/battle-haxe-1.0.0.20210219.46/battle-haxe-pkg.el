;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "battle-haxe" "1.0.0.20210219.46"
  "A Haxe development system, with code completion and more."
  '((emacs   "25")
    (company "0.9.9")
    (helm    "3.0")
    (async   "1.9.3")
    (cl-lib  "0.5")
    (dash    "2.18.0")
    (s       "1.10.0")
    (f       "0.19.0"))
  :url "https://github.com/AlonTzarafi/battle-haxe"
  :commit "2f32c81dcecfc68fd410cb9d2aca303d6e3028c7"
  :revdesc "2f32c81dcecf"
  :keywords '("programming" "languages" "completion")
  :authors '(("Alon Tzarafi" . "alontzarafi@gmail.com"))
  :maintainers '(("Alon Tzarafi" . "alontzarafi@gmail.com")))
