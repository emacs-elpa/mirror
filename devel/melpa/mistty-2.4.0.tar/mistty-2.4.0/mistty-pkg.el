;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "2.4.0"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "812cbbf7ec2aaae432be1dbade22badc808324aa"
  :revdesc "812cbbf7ec2a"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
