;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerdtab" "1.2.3.0.20180811.13"
  "Keyboard-oriented tabs."
  '((emacs "24.5"))
  :url "https://github.com/casouri/nerdtab"
  :commit "601d531fa3748db733fbdff157a0f1cdf8a66416"
  :revdesc "601d531fa374"
  :keywords '("convenience")
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
