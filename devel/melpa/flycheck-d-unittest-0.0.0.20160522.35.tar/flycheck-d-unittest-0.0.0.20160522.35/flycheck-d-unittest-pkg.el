;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-d-unittest" "0.0.0.20160522.35"
  "Add D unittest support to flycheck."
  '((flycheck "0.21-cvs1")
    (dash     "1.4.0"))
  :url "https://github.com/tom-tan/flycheck-d-unittest/"
  :commit "3e614f23cb4a5566fd7988dbcaaf254af81c7718"
  :revdesc "3e614f23cb4a"
  :keywords '("flycheck" "d")
  :authors '(("Tomoya Tanjo" . "ttanjo@gmail.com"))
  :maintainers '(("Tomoya Tanjo" . "ttanjo@gmail.com")))
