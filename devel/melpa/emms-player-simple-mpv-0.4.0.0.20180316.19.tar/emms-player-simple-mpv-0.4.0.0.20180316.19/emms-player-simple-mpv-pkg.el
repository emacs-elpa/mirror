;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms-player-simple-mpv" "0.4.0.0.20180316.19"
  "An extension of emms-player-simple.el for mpv JSON IPC."
  '((emacs  "24")
    (cl-lib "0.5")
    (emms   "4.0"))
  :url "https://github.com/momomo5717/emms-player-simple-mpv"
  :commit "101d120ccdee1c2c213fd2f0423c858b21649c00"
  :revdesc "v0.4.0-19-g101d120ccdee"
  :keywords '("emms" "mpv"))
