;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "1.0.0.20260930.16"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "7f1d0dbb7cb36f0063cb50b7bd79bd697c0c0111"
  :revdesc "7f1d0dbb7cb3"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
