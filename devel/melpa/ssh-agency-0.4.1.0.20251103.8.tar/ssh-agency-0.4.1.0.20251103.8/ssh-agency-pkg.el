;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ssh-agency" "0.4.1.0.20251103.8"
  "Manage ssh-agent from Emacs."
  '((emacs "26.1"))
  :url "https://github.com/magit/ssh-agency"
  :commit "2a6e1784b42b6179da11c6c1077faaa0eb484e0d"
  :revdesc "0.4.1-8-g2a6e1784b42b"
  :authors '(("Noam Postavsky" . "npostavs@user.sourceforge.net"))
  :maintainers '(("Noam Postavsky" . "npostavs@user.sourceforge.net")))
