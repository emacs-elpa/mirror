;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dyncloze" "0.2.0.20210712.3"
  "Language alternatives self-testing."
  '((emacs "25.1")
    (dash  "2.18"))
  :url "https://github.com/ahyatt/emacs-dyncloze"
  :commit "aafc5adc25c7f714b619109bccf92e475d6c84ef"
  :revdesc "aafc5adc25c7"
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
