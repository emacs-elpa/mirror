;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "1.3.0.0.20260906.3"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "7904fd83afcacedfdabe59a99356c92efc9b49f6"
  :revdesc "1.3.0-3-g7904fd83afca"
  :keywords '("convenience" "frames" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
