;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-firefox" "1.3.0.20260818.11"
  "Firefox bookmarks."
  '((helm   "1.5")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/emacs-helm/helm-firefox"
  :commit "d299622ceba33636ed67ef2dc70d5cf3291bea6e"
  :revdesc "v1.3-11-gd299622ceba3")
