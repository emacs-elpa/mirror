;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-search-highlight-persist" "1.8.0.20170523.15"
  "Persistent highlights after search."
  '((highlight "0"))
  :url "https://github.com/naclander/evil-search-highlight-persist"
  :commit "6e04a8c075f5fd62526d222447048faab8bfa187"
  :revdesc "6e04a8c075f5"
  :authors '(("Juanjo Alvarez" . "juanjo@juanjoalvarez.net"))
  :maintainers '(("Juanjo Alvarez" . "juanjo@juanjoalvarez.net")))
