;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "1.1.2.0.20260907.3"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "1643da6b9de4df8ec7990fddaa9124c1ff669858"
  :revdesc "1643da6b9de4"
  :keywords '("outlines" "tools" "convenience" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
