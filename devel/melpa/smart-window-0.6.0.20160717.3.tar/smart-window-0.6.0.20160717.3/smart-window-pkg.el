;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-window" "0.6.0.20160717.3"
  "Vim-like window controlling plugin."
  '((cl-lib "0.5"))
  :url "https://github.com/dryman/smart-window.el"
  :commit "5996461b7cbc5ab4509ac48537916eb29a8e4c16"
  :revdesc "5996461b7cbc"
  :keywords '("window")
  :authors '(("Felix Chern" . "idryman@gmail.com"))
  :maintainers '(("Felix Chern" . "idryman@gmail.com")))
