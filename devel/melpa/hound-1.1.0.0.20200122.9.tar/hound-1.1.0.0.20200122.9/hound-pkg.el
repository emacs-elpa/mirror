;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hound" "1.1.0.0.20200122.9"
  "Display hound search results in a compilation window."
  '((request "0.2.0")
    (cl-lib  "0.5"))
  :url "https://github.com/ryoung786/hound.el"
  :commit "35e2cdc81fcc904b450a7ef3ec00fd25df6a4431"
  :revdesc "v1.1.0-9-g35e2cdc81fcc")
