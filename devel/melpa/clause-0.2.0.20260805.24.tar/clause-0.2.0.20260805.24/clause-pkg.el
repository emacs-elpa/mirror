;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clause" "0.2.0.20260805.24"
  "Functions to move, mark, kill by clause."
  '((emacs         "27.1")
    (mark-thing-at "0.3"))
  :url "https://codeberg.org/martianh/clause.el"
  :commit "7d8e89125f5a0d27f1490eb39bb4443133eaae6c"
  :revdesc "7d8e89125f5a"
  :keywords '("wp" "convenience" "sentences" "text")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
