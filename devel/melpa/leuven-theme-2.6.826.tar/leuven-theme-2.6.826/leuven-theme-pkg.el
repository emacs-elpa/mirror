;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leuven-theme" "2.6.826"
  "Elegant Emacs color theme for a white background."
  ()
  :url "https://github.com/fniessen/emacs-leuven-theme"
  :commit "8cd77776d6574596cf37a39e3546f8d88ab9b240"
  :revdesc "v2.6.0826-0-g8cd77776d657"
  :keywords '("color" "theme")
  :authors '(("Fabrice Niessen" . ""))
  :maintainers '(("Fabrice Niessen" . "")))
