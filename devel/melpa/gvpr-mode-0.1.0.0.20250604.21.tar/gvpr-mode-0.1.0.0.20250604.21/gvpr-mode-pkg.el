;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gvpr-mode" "0.1.0.0.20250604.21"
  "A major mode offering basic syntax coloring for gvpr scripts."
  ()
  :url "https://raw.github.com/rodw/gvpr-lib/master/extra/gvpr-mode.el"
  :commit "db3aac0b51d8f624d94f8b022503b645ae97d926"
  :revdesc "db3aac0b51d8"
  :keywords '("graphviz" "gv" "dot" "gvpr" "graph")
  :authors '(("Rod Waldhoff" . "r.waldhoff@gmail.com"))
  :maintainers '(("Rod Waldhoff" . "r.waldhoff@gmail.com")))
