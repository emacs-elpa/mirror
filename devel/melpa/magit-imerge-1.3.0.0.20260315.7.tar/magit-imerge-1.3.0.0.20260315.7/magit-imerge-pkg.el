;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-imerge" "1.3.0.0.20260315.7"
  "Magit extension for git-imerge."
  '((emacs "26.1")
    (magit "4.0.0"))
  :url "https://github.com/magit/magit-imerge"
  :commit "c7853332260298688f8f13cf8e5fdee932d7acae"
  :revdesc "v1.3.0-7-gc78533322602"
  :keywords '("vc" "tools")
  :authors '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainers '(("Kyle Meyer" . "kyle@kyleam.com")))
