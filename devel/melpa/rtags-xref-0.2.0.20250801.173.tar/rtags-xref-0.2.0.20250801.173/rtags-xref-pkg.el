;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rtags-xref" "0.2.0.20250801.173"
  "RTags backend for xref.el."
  '((emacs "25.1")
    (rtags "2.37"))
  :url "https://github.com/Andersbakken/rtags"
  :commit "62d881dab01ecb9ee6d54b705124ca8dadba726f"
  :revdesc "62d881dab01e")
