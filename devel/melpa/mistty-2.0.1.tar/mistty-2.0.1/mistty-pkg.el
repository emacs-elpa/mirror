;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "2.0.1"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "9a501016cf219b8dd99cc51083992100f889d5b1"
  :revdesc "9a501016cf21"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
