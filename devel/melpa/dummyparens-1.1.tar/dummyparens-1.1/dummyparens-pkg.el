;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dummyparens" "1.1"
  "Parenthesis auto-pairing and wrapping."
  ()
  :url "https://github.com/snosov1/dummyparens"
  :commit "9798ef1d0eaa24e4fe66f8aa6022a8c62714cc89"
  :revdesc "9798ef1d0eaa"
  :keywords '("dummyparens" "auto-pair" "wrapping")
  :authors '(("Sergei Nosov" . "sergei.nosov[at]gmail.com"))
  :maintainers '(("Sergei Nosov" . "sergei.nosov[at]gmail.com")))
