;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "6.2.0.0.20260924.8"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "30ee88712364cd347e6e5880d85acbac275d66ce"
  :revdesc "v6.2.0-8-g30ee88712364"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
