;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "0.9.0.0.20261007.48"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "3ea04302c3cf8608971e528de25680266e50a837"
  :revdesc "3ea04302c3cf"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
