;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phony" "1.0.1"
  "Define voice commands."
  '((emacs      "29.1")
    (simulacrum "1.0.0"))
  :url "https://github.com/ErikPrantare/phony.el"
  :commit "b155ee3686c732cfe02a4bcd5f3e07fdc39dca35"
  :revdesc "b155ee3686c7"
  :keywords '("files"))
