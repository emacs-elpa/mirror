;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "strace-mode" "0.0.2.0.20171116.5"
  "Strace output syntax highlighting."
  ()
  :url "https://github.com/pkmoore/strace-mode"
  :commit "2901baa968d5180ab985ac40ca22cc20914d01f5"
  :revdesc "2901baa968d5"
  :keywords '("languages")
  :authors '(("Preston Moore" . "(prestonkmoore@gmail.com)"))
  :maintainers '(("Preston Moore" . "(prestonkmoore@gmail.com)")))
