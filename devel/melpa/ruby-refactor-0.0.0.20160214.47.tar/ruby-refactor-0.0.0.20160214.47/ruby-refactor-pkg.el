;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-refactor" "0.0.0.20160214.47"
  "A minor mode which presents various Ruby refactoring helpers."
  '((ruby-mode "1.2"))
  :url "https://github.com/ajvargo/ruby-refactor"
  :commit "e6b7125878a08518bffec6942df0c606f748e9ee"
  :revdesc "e6b7125878a0"
  :keywords '("refactor" "ruby")
  :authors '(("Andrew J Vargo" . "ajvargo@gmail.com")
             ("Jeff Morgan" . "jeff.morgan@leandog.com"))
  :maintainers '(("Andrew J Vargo" . "ajvargo@gmail.com")
                 ("Jeff Morgan" . "jeff.morgan@leandog.com")))
