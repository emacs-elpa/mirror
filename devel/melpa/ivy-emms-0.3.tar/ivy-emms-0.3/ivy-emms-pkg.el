;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-emms" "0.3"
  "Ivy interface to emms tracks."
  '((ivy   "0.13.0")
    (emms  "0.0")
    (emacs "24.4"))
  :url "https://github.com/franburstall/ivy-emms"
  :commit "3b1bda7be64ba5555672b6375c205e0f7d831bc0"
  :revdesc "3b1bda7be64b"
  :keywords '("multimedia")
  :authors '(("Fran Burstall" . "fran.burstall@gmail.com"))
  :maintainers '(("Fran Burstall" . "fran.burstall@gmail.com")))
