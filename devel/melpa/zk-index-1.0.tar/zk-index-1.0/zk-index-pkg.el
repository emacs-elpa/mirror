;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-index" "1.0"
  "Index for zk."
  '((emacs "28.1")
    (zk    "0.9"))
  :url "https://github.com/localauthor/zk"
  :commit "ad82465a4a65fba7cff07da419455947507080cc"
  :revdesc "ad82465a4a65"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
