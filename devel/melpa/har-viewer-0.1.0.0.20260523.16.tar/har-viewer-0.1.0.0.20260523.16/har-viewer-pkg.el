;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "har-viewer" "0.1.0.0.20260523.16"
  "Major mode for viewing HTTP Archive (HAR) files."
  '((emacs "26.1"))
  :url "https://github.com/bozoslivehere/har-viewer.el"
  :commit "0b36dd0ef6743e0267e603127a4509737f8b1f0b"
  :revdesc "0b36dd0ef674"
  :keywords '("tools" "http" "network")
  :authors '(("Gregory Newman" . "bozoslivehere@protonmail.com"))
  :maintainers '(("Gregory Newman" . "bozoslivehere@protonmail.com")))
