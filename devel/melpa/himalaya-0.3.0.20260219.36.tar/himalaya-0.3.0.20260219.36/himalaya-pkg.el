;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "himalaya" "0.3.0.20260219.36"
  "Interface for the email client Himalaya CLI."
  '((emacs "27.1"))
  :url "https://github.com/dantecatalfamo/himalaya-emacs"
  :commit "e308694ef60b211bad2a70c46a1566ef0b985f2e"
  :revdesc "v0.3-36-ge308694ef60b"
  :keywords '("mail" "comm")
  :authors '(("soywod" . "clement.douin@posteo.net"))
  :maintainers '(("soywod" . "clement.douin@posteo.net")))
