;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitignore-snippets" "1.0.0.0.20201118.6"
  "Gitignore.io templates for Yasnippet."
  '((emacs     "26")
    (yasnippet "0.8.0"))
  :url "https://github.com/sei40kr/gitignore-snippets"
  :commit "f91b3397526fe09d2e4a1f507a73b06bc7542cf7"
  :revdesc "f91b3397526f"
  :keywords '("tools")
  :authors '(("Seong Yong-ju" . "sei40kr@gmail.com"))
  :maintainers '(("Seong Yong-ju" . "sei40kr@gmail.com")))
