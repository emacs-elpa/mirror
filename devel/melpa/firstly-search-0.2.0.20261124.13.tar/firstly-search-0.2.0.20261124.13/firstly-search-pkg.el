;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "0.2.0.20261124.13"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "c35c32e559b36567c0a6937a6fb4d535c931a0c6"
  :revdesc "c35c32e559b3"
  :keywords '("matching" "convenience")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
