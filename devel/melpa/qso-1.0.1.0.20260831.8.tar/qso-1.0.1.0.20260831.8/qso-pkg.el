;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qso" "1.0.1.0.20260831.8"
  "Amateur radio QSO logging."
  '((emacs "25.1"))
  :url "https://github.com/K6SM/Emacs-QSO-Logger"
  :commit "1e47fae4d60ff51a772f330ff2dc9c0ca058082f"
  :revdesc "1e47fae4d60f"
  :keywords '("lisp"))
