;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evalator" "1.0.0.0.20160213.13"
  "Package for interactive transformation of data with helm."
  '((helm-core "1.9.1"))
  :url "http://www.github.com/seanirby/evalator"
  :commit "f30da4da48c0b3f3cfa1fc1c7cfdb53ffe79df36"
  :revdesc "f30da4da48c0"
  :keywords '("languages" "elisp" "helm")
  :maintainers '(("Sean Irby" . "sean.t.irby@gmail.com")))
