;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.56.0.0.20260930.7"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "8cc917321a8ba5d704c72e3dd6d9d186ece7a692"
  :revdesc "8cc917321a8b"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
