;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crossword" "1.0.0.20210614.1"
  "Download and play crossword puzzles."
  '((emacs "26.1"))
  :url "https://github.com/Boruch-Baum/emacs-crossword"
  :commit "e462de8ef15d1f979207a95b224e68d7feead92f"
  :revdesc "e462de8ef15d"
  :keywords '("games"))
