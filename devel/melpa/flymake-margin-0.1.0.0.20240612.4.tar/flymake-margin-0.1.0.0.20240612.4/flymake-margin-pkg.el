;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-margin" "0.1.0.0.20240612.4"
  "Sets flymake to work with margin instead of fringes."
  '((emacs "29.1"))
  :url "https://github.com/LionyxML/flymake-margin"
  :commit "4e36634789d64c33a9fc0dc5bc2eb4a21c391d96"
  :revdesc "4e36634789d6"
  :keywords '("languages" "maint" "tools"))
