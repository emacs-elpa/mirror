;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chee" "0.3.0.0.20171123.1"
  "Interface to chee using dired and image-dired."
  '((dash "2.12.1")
    (s    "1.10.0")
    (f    "0.18.2"))
  :url "https://github.com/eikek/chee/tree/release/0.3.0/emacs"
  :commit "669ff9ee429f24c3c2d03b83d9cb9aec5f86bb8b"
  :revdesc "release/0.3.0-1-g669ff9ee429f")
