;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "0.1.1.0.20260827.31"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "5af8e3512e9509f09897ca0e9a7a36ebb9ed983c"
  :revdesc "5af8e3512e95"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
