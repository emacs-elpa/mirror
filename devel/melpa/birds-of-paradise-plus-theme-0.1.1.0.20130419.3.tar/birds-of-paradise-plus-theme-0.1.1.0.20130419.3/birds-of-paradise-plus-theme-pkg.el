;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "birds-of-paradise-plus-theme" "0.1.1.0.20130419.3"
  "A brown/orange light-on-dark theme for Emacs 24 (deftheme)."
  ()
  :url "https://github.com/jimeh/birds-of-paradise-plus-theme.el"
  :commit "bb9f9d4ef7f7872a388ec4eee1253069adcadb6f"
  :revdesc "v0.1.1-3-gbb9f9d4ef7f7"
  :keywords '("themes")
  :authors '(("Jim Myhrberg" . "contact@jimeh.me"))
  :maintainers '(("Jim Myhrberg" . "contact@jimeh.me")))
