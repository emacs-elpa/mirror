;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llvm-ts-mode" "0.0.1.0.20231120.1"
  "LLVM major mode using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/llvm-ts-mode"
  :commit "9974601dcddbeffc4ad47598d63d3c1a83bb6fb9"
  :revdesc "9974601dcddb"
  :keywords '("languages" "tree-sitter" "llvm")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
