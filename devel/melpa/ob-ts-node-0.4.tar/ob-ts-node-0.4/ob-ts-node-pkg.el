;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-ts-node" "0.4"
  "Org-Babel support for TypeScript via ts-node."
  '((emacs "25.1")
    (org   "8.0"))
  :url "https://github.com/tmythicator/ob-ts-node"
  :commit "a480e19fc204847c5b4c1808b07856bca68dae1e"
  :revdesc "a480e19fc204"
  :keywords '("languages" "tools"))
