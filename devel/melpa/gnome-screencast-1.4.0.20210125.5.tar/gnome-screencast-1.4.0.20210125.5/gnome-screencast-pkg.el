;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnome-screencast" "1.4.0.20210125.5"
  "Use Gnome screen recording functionality using elisp."
  '((emacs "25"))
  :url "https://github.com/juergenhoetzel/emacs-gnome-screencast"
  :commit "1f4ef60fe9d452320dc02f89e289bac04ef2ad1c"
  :revdesc "1f4ef60fe9d4"
  :keywords '("tools" "multimedia")
  :authors '(("Jürgen Hötzel" . "juergen@hoetzel.info"))
  :maintainers '(("Jürgen Hötzel" . "juergen@hoetzel.info")))
