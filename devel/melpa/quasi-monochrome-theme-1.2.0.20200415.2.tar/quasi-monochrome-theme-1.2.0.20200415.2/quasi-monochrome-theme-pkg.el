;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quasi-monochrome-theme" "1.2.0.20200415.2"
  "High contrast quasi monochrome color theme."
  ()
  :url "https://github.com/lbolla/emacs-quasi-monochrome"
  :commit "b38d71860fdea945e10e8a766ac9dfa1410ade67"
  :revdesc "b38d71860fde"
  :keywords '("color-theme" "monochrome" "high contrast")
  :authors '(("Lorenzo Bolla" . "lbolla@gmail.com"))
  :maintainers '(("Lorenzo Bolla" . "lbolla@gmail.com")))
