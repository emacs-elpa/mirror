;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260524.1144"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "516392b28fc9fb180a728cb83f475cf41231c7d0"
  :revdesc "516392b28fc9")
