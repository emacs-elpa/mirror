;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "10.0.0.0.20261001.45"
  "LSP mode."
  '((emacs         "29.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "082792610f726b156f7b9a5b46bac9a7b20f02b0"
  :revdesc "082792610f72"
  :keywords '("languages"))
