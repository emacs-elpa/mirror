;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pretend-type" "0.1.0.0.20251019.6"
  "Reveal buffer as you pretend to type."
  '((emacs "24.3"))
  :url "https://github.com/haji-ali/pretend-type"
  :commit "1396a0c28986af260a462525ff20a1269cb64eb2"
  :revdesc "1396a0c28986"
  :keywords '("hide" "show" "invisible" "learning" "games")
  :authors '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com")))
