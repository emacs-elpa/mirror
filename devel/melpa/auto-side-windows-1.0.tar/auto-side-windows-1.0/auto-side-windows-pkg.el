;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-side-windows" "1.0"
  "Simplified buffer management for side windows."
  '((emacs "30.1"))
  :url "https://github.com/MArpogaus/auto-side-windows"
  :commit "12f3dd7f447e390069744c2925d4eeb2edcfbe51"
  :revdesc "v1.0-0-g12f3dd7f447e"
  :keywords '("convenience" "windows" "buffers")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
