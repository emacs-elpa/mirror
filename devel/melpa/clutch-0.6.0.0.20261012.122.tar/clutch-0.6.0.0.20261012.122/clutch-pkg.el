;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.6.0.0.20261012.122"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "3809d208d884987cc53a54715b674ebdb5c2254b"
  :revdesc "3809d208d884"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
