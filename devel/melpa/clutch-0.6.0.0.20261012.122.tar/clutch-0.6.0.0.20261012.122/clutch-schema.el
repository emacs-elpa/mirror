;;; clutch-schema.el --- Schema refresh and metadata caches -*- lexical-binding: t; -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;;; Commentary:

;; Schema refresh services, status, and metadata cache state.

;;; Code:

(require 'cl-lib)
(require 'clutch-backend)
(require 'clutch-diagnostics)
(require 'subr-x)

(defcustom clutch-schema-refresh-idle-delay-seconds 0.5
  "Idle delay before automatic schema cache refresh after connect.
A small non-zero delay keeps the first query responsive for native backends
whose schema refresh runs on the foreground connection.  Manual schema
refresh commands still start immediately."
  :type 'number
  :group 'clutch)

(defvar clutch--schema-cache (make-hash-table :test 'eq)
  "Global schema cache keyed by connection object identity.")

(defvar clutch--table-metadata-cache (make-hash-table :test 'eq)
  "Table metadata and load status keyed by connection and table identity.")

(defvar clutch--row-identity-cache (make-hash-table :test 'eq)
  "Resolved row identity candidates keyed by connection object identity.
Each value maps (CATALOG SCHEMA TABLE) to a candidate list, where CATALOG
and SCHEMA are the source table's explicit qualifiers.")

(defvar clutch--column-details-queue-cache (make-hash-table :test 'eq)
  "Per-connection queue of tables waiting for async column-detail fetch.")

(defvar clutch--column-details-active-cache (make-hash-table :test 'eq)
  "Per-connection active async column-detail fetch as (TABLE . TICKET).")

(defvar clutch--metadata-ticket-counter 0
  "Monotonic counter used to reject stale async table metadata callbacks.")

(defvar clutch--help-doc-cache (make-hash-table :test 'eq)
  "Cache for live function docs fetched from the database server.")

(defvar clutch--schema-status-cache (make-hash-table :test 'eq)
  "Schema refresh status cache keyed by connection object identity.")

(defvar clutch--schema-refresh-ticket-counter 0
  "Monotonic counter used to reject stale async schema refreshes.")

(defvar clutch--schema-refresh-tickets (make-hash-table :test 'eq)
  "Latest schema refresh ticket keyed by connection object identity.")

(defvar clutch--schema-cache-updated-hook nil
  "Hook run when a connection's schema cache lifecycle changes.
Functions receive CONN and STATE, where STATE is `invalidated' or `ready'.")

(defvar clutch--metadata-state-changed-hook nil
  "Hook run after metadata state changes for a connection.
Functions receive the connection object as their sole argument.")

(defvar clutch--table-metadata-updated-hook nil
  "Hook run after table-scoped metadata is updated.
Functions receive CONN, TABLE, and KIND.")

(defconst clutch--schema-dependent-cache-symbols
  '(clutch--table-metadata-cache
    clutch--row-identity-cache
    clutch--column-details-queue-cache
    clutch--column-details-active-cache
    clutch--help-doc-cache)
  "Metadata cache variables invalidated when schema cache changes.")

(defvar clutch-connection)
(defvar clutch--oracle-i18n-warning-shown nil
  "Non-nil after showing the Oracle orai18n completion warning once.")
(defvar clutch--completion-metadata-warning-cache (make-hash-table :test 'equal)
  "Completion metadata errors already surfaced in this session.")

(defun clutch--notify-schema-cache-updated (conn state)
  "Notify schema-cache consumers that CONN entered STATE."
  (run-hook-with-args 'clutch--schema-cache-updated-hook conn state))

(defun clutch--notify-metadata-state-changed (conn)
  "Notify metadata consumers that state changed for CONN."
  (run-hook-with-args 'clutch--metadata-state-changed-hook conn))

(defun clutch--metadata-debug-event (conn op phase summary
                                          &optional context elapsed)
  "Record a metadata debug event.
CONN, OP, PHASE, SUMMARY, and CONTEXT describe the event.
ELAPSED, when non-nil, is the operation's duration in seconds."
  (when clutch-debug-mode
    (clutch--remember-debug-event
     :connection conn
     :op op
     :phase phase
     :backend (clutch-db-backend-key conn)
     :summary summary
     :context context
     :elapsed elapsed)))

(defun clutch--table-key (table &optional schema catalog)
  "Return the metadata key of TABLE in SCHEMA and CATALOG.
An unqualified table is keyed by its name, which resolves in the
connection's current namespace, and a qualified one by
\(CATALOG SCHEMA TABLE), as row identities are."
  (if (or schema catalog) (list catalog schema table) table))

(defun clutch--table-key-arguments (key)
  "Return the arguments that name the table of metadata KEY to a method.
They are its name, followed by its schema and catalog when it has them."
  (pcase key
    (`(,catalog ,schema ,table) (list table schema catalog))
    (_ (list key))))

(defun clutch--table-key-name (key)
  "Return the table name of metadata KEY."
  (car (clutch--table-key-arguments key)))

(defun clutch--table-key-label (key)
  "Return metadata KEY as text for messages, such as aux.people."
  (if (consp key) (string-join (delq nil (copy-sequence key)) ".") key))

(defun clutch--table-metadata-async (method conn key callback errback)
  "Start async metadata METHOD for the table of KEY on CONN.
METHOD gets CALLBACK and ERRBACK, then the table's schema and catalog when
KEY has them."
  (pcase-let ((`(,table . ,namespace) (clutch--table-key-arguments key)))
    (apply method conn table callback errback namespace)))

(defun clutch--metadata-debug-table-event (conn op phase table summary
                                                &optional elapsed)
  "Record a metadata debug event for TABLE and OP on CONN.
ELAPSED, when non-nil, is the operation's duration in seconds."
  (clutch--metadata-debug-event conn op phase summary
                                (list :table (clutch--table-key-label table))
                                elapsed))

(defun clutch--oracle-i18n-missing-p (err)
  "Return non-nil when ERR indicates Oracle needs orai18n.jar."
  (string-match-p
   "orai18n\\.jar\\|Non supported character set"
   (error-message-string err)))

(defun clutch--warn-oracle-i18n-once ()
  "Warn once that Oracle completion needs orai18n.jar for this session."
  (unless clutch--oracle-i18n-warning-shown
    (setq clutch--oracle-i18n-warning-shown t)
    (message (concat "Oracle completion needs orai18n.jar for this character set. "
                     "Run M-x clutch-jdbc-install-driver RET oracle "
                     "(or oracle-i18n if you already manage ojdbc manually)."))))

(defun clutch--warn-completion-metadata-error-once (message-text)
  "Warn once that completion metadata is unavailable with MESSAGE-TEXT."
  (unless (gethash message-text clutch--completion-metadata-warning-cache)
    (puthash message-text t clutch--completion-metadata-warning-cache)
    (message "Completion metadata unavailable: %s" message-text)))

(defun clutch--safe-completion-call (thunk)
  "Call THUNK for completion and swallow recoverable metadata errors."
  (condition-case err
      (funcall thunk)
    (clutch-db-error
     (clutch--remember-recoverable-metadata-warning
      clutch-connection "completion" err)
     (if (clutch--oracle-i18n-missing-p err)
         (clutch--warn-oracle-i18n-once)
       (clutch--warn-completion-metadata-error-once
        (clutch-db--error-message err)))
     nil)))

(defun clutch--table-metadata (conn key)
  "Return the metadata plist for KEY on CONN, or nil."
  (let ((cache (gethash conn clutch--table-metadata-cache)))
    (and cache (gethash key cache))))

(defun clutch--set-table-metadata (conn table property value)
  "Set PROPERTY to VALUE in TABLE metadata for CONN."
  (let* ((cache (or (gethash conn clutch--table-metadata-cache)
                    (let ((cache (make-hash-table :test 'equal)))
                      (puthash conn cache clutch--table-metadata-cache)
                      cache)))
         (metadata (plist-put (gethash table cache) property value)))
    (puthash table metadata cache)))

(defun clutch--clear-table-metadata-caches (conn table)
  "Clear table-scoped metadata caches for TABLE on CONN."
  (when-let* ((schema (gethash conn clutch--schema-cache)))
    (unless (eq (gethash table schema 'missing) 'missing)
      (puthash table nil schema)))
  (clutch--forget-row-identities conn table)
  (cl-flet ((of-table-p (key)
              (equal (clutch--table-key-name key) table)))
    (when-let* ((cache (gethash conn clutch--table-metadata-cache)))
      (let (keys)
        (maphash (lambda (key _value)
                   ;; Table comments are keyed by (SCHEMA . TABLE).
                   (when (or (of-table-p key) (equal (cdr-safe key) table))
                     (push key keys)))
                 cache)
        (dolist (key keys)
          (remhash key cache))))
    (when-let* ((queue (gethash conn clutch--column-details-queue-cache)))
      (puthash conn
               (cl-remove-if #'of-table-p queue)
               clutch--column-details-queue-cache))
    (when-let* ((active (gethash conn clutch--column-details-active-cache)))
      (when (of-table-p (car active))
        (remhash conn clutch--column-details-active-cache)))))

(defun clutch--begin-metadata-ticket ()
  "Issue a new table metadata freshness ticket."
  (cl-incf clutch--metadata-ticket-counter))

(defun clutch--clear-schema-dependent-caches (conn)
  "Clear metadata caches derived from the schema cache for CONN."
  (dolist (cache-symbol clutch--schema-dependent-cache-symbols)
    (remhash conn (symbol-value cache-symbol))))

(defun clutch--schema-status-entry (conn)
  "Return schema status plist for CONN, or nil."
  (and conn
       (gethash conn clutch--schema-status-cache)))

(defun clutch--schema-cache-guidance (conn)
  "Return a recovery hint for CONN schema cache state, or nil."
  (when-let* ((entry (clutch--schema-status-entry conn))
              (state (plist-get entry :state)))
    (pcase state
      ('stale
       "Schema cache is stale — press C-c C-s before relying on cached table names or object discovery metadata")
      ('failed
       "Schema refresh failed earlier — press C-c C-s to retry before relying on cached table names or object discovery metadata")
      ('refreshing
       "Schema refresh is in progress — cached table names or object discovery metadata may still be behind")
      (_ nil))))

(defun clutch--warn-schema-cache-state (&optional conn)
  "Show a recovery hint when CONN schema cache is not ready."
  (when-let* ((hint (clutch--schema-cache-guidance (or conn clutch-connection))))
    (message "%s" hint)))

(defun clutch--schema-table-candidates (conn schema prefix)
  "Return ready cached table names matching PREFIX for CONN and SCHEMA."
  (when (and (hash-table-p schema)
             (eq (plist-get (clutch--schema-status-entry conn) :state) 'ready))
    (let ((uprefix (upcase prefix)))
      (cl-loop for table being the hash-keys of schema
               when (and (stringp table)
                         (string-prefix-p uprefix (upcase table)))
               collect table))))

(defun clutch--completion-schema-tables (conn namespace)
  "Return cached table names in NAMESPACE on CONN, starting one fetch if needed."
  (let* ((key (clutch--table-key nil namespace))
         (metadata (clutch--table-metadata conn key))
         (state (plist-get (clutch--metadata-status conn key :tables-status) :state)))
    (unless (or (plist-member metadata :completion-tables)
                (memq state '(loading failed))
                (not (clutch-db-live-p conn))
                (clutch-db-busy-p conn))
      (unless (clutch--start-table-metadata-request
               conn key namespace :tables-status "schema-tables"
               #'clutch-db-schema-tables-async
               (lambda (tables)
                 (clutch--set-table-metadata conn key :completion-tables tables)))
        (clutch--set-metadata-status
         conn key :tables-status 'failed "Scoped table completion is unsupported")))
    (plist-get (clutch--table-metadata conn key) :completion-tables)))

(defun clutch--completion-qualified-columns (conn key)
  "Return cached column names for qualified table KEY on CONN.
Start one asynchronous fetch on a cache miss."
  (let ((metadata (clutch--table-metadata conn key))
        (state (plist-get (clutch--metadata-status conn key :columns-status) :state)))
    (unless (or (plist-member metadata :columns)
                (memq state '(loading failed))
                (not (clutch-db-live-p conn))
                (clutch-db-busy-p conn))
      (unless (clutch--start-table-metadata-request
               conn key key :columns-status "list-columns"
               (lambda (connection table callback errback)
                 (clutch--table-metadata-async
                  #'clutch-db-list-columns-async connection table callback errback))
               (lambda (columns)
                 (clutch--set-table-metadata conn key :columns columns)))
        (clutch--set-metadata-status
         conn key :columns-status 'failed "Scoped column completion is unsupported")))
    (plist-get (clutch--table-metadata conn key) :columns)))

(defun clutch--cached-columns (schema table)
  "Return cached columns for TABLE from SCHEMA, or nil if not loaded."
  (let ((cols (and schema (gethash table schema 'missing))))
    (unless (eq cols 'missing) cols)))

(defun clutch--set-schema-status (conn state &optional table-count error-message)
  "Record schema STATE for CONN and refresh connected UI.
TABLE-COUNT is the number of known tables when STATE is \\='ready.
ERROR-MESSAGE is stored when STATE is \\='failed."
  (when conn
    (puthash conn
             (list :state state
                   :tables table-count
                   :error error-message)
             clutch--schema-status-cache)
    (clutch--notify-metadata-state-changed conn)))

(defun clutch--begin-schema-refresh-ticket (conn)
  "Issue and record a new schema refresh ticket for CONN."
  (let ((ticket (cl-incf clutch--schema-refresh-ticket-counter)))
    (puthash conn ticket clutch--schema-refresh-tickets)
    ticket))

(defun clutch--schema-refresh-ticket-latest-p (conn ticket)
  "Return non-nil when TICKET is the latest refresh ticket for CONN."
  (and conn
       (eql (gethash conn clutch--schema-refresh-tickets)
            ticket)))

(defun clutch--schema-refresh-ticket-current-p (conn ticket)
  "Return non-nil when TICKET is current on a live CONN."
  (and (clutch-db-live-p conn)
       (clutch--schema-refresh-ticket-latest-p conn ticket)))

(defun clutch--metadata-status (conn key status-property)
  "Return STATUS-PROPERTY from metadata KEY on CONN."
  (plist-get (clutch--table-metadata conn key) status-property))

(defun clutch--set-metadata-status (conn key status-property state
                                         &optional error-message ticket)
  "Record STATE under STATUS-PROPERTY for metadata KEY on CONN."
  (clutch--set-table-metadata
   conn key status-property
   (list :state state :error error-message :ticket ticket)))

(defun clutch--clear-metadata-status (conn key status-property)
  "Clear STATUS-PROPERTY from metadata KEY on CONN."
  (when-let* ((cache (gethash conn clutch--table-metadata-cache))
              (metadata (gethash key cache)))
    (setq metadata (cl-loop for (prop value) on metadata by #'cddr
                            unless (eq prop status-property)
                            append (list prop value)))
    (if metadata
        (puthash key metadata cache)
      (remhash key cache))))

(defun clutch--cached-column-details (conn table)
  "Return cached column details for TABLE on CONN, or nil if not loaded."
  (plist-get (clutch--table-metadata conn table) :column-details))

(defun clutch--column-details-cached-p (conn table)
  "Return non-nil when TABLE has cached column details on CONN."
  (plist-member (clutch--table-metadata conn table) :column-details))

(defun clutch--table-comment-key (conn table &optional schema)
  "Return the schema-qualified cache key for TABLE on CONN."
  (cons (or schema (clutch-db-current-schema conn)) table))

(defun clutch--cached-row-identity (conn table schema catalog)
  "Return TABLE's cached row identity candidates on CONN, wrapped in a list.
SCHEMA and CATALOG are the source table's explicit qualifiers, if any.
Return nil when nothing is cached.  The wrapper keeps a cached empty
candidate list distinguishable from a cache miss."
  (when-let* ((cache (gethash conn clutch--row-identity-cache)))
    (let ((candidates (gethash (list catalog schema table) cache 'missing)))
      (unless (eq candidates 'missing)
        (list candidates)))))

(defun clutch--cache-row-identity (conn table schema catalog candidates)
  "Cache CANDIDATES as TABLE's row identity on CONN.
SCHEMA and CATALOG are the source table's explicit qualifiers, if any.  An
unqualified table needs no namespace in the key: whatever can change what
it resolves to also drops the cache, namely schema refresh, reconnect,
schema switching, and any statement that returns no result set."
  (puthash (list catalog schema table) candidates
           (or (gethash conn clutch--row-identity-cache)
               (puthash conn (make-hash-table :test 'equal)
                        clutch--row-identity-cache))))

(defun clutch--forget-row-identities (conn &optional table)
  "Drop CONN's cached row identities, only TABLE's when TABLE is non-nil."
  (if (null table)
      (remhash conn clutch--row-identity-cache)
    (when-let* ((cache (gethash conn clutch--row-identity-cache)))
      (let (keys)
        (maphash (lambda (key _candidates)
                   (when (string-equal-ignore-case (nth 2 key) table)
                     (push key keys)))
                 cache)
        (dolist (key keys)
          (remhash key cache))))))

(defun clutch--cached-table-comment (conn table)
  "Return TABLE's cached comment on CONN, or nil."
  (plist-get
   (clutch--table-metadata conn (clutch--table-comment-key conn table))
   :comment))

(defun clutch--table-comment-cached-p (conn table &optional schema)
  "Return non-nil when TABLE in SCHEMA has a cached comment on CONN."
  (plist-member
   (clutch--table-metadata conn (clutch--table-comment-key conn table schema))
   :comment))

(defun clutch--cached-foreign-keys (conn table)
  "Return cached foreign-key metadata for TABLE on CONN, or nil."
  (plist-get (clutch--table-metadata conn table) :foreign-keys))

(defun clutch--foreign-keys-cached-p (conn table)
  "Return non-nil when TABLE has cached foreign-key metadata on CONN."
  (plist-member (clutch--table-metadata conn table) :foreign-keys))

(defun clutch--foreign-key-column-info (conn table col-names)
  "Return cached foreign-key metadata indexed by COL-NAMES for CONN/TABLE."
  (when (clutch--foreign-keys-cached-p conn table)
    (cl-loop for (col-name . ref-info) in (clutch--cached-foreign-keys conn table)
             for idx = (cl-position col-name col-names :test #'string=)
             when idx collect (cons idx ref-info))))

(defun clutch--cache-table-entry-comments (conn entries)
  "Prime CONN's table-comment cache from ENTRIES with explicit comments."
  (when conn
    (dolist (entry entries)
      (let ((name (plist-get entry :name)))
        (when (and name (plist-member entry :comment))
          (let ((comment (plist-get entry :comment)))
            (clutch--set-table-metadata
             conn (clutch--table-comment-key
                   conn name (plist-get entry :schema))
             :comment
             (if (and (stringp comment) (string-empty-p comment))
                 nil
               comment)))
          (clutch--clear-metadata-status
           conn (clutch--table-comment-key
                 conn name (plist-get entry :schema))
           :comment-status))))))

(defun clutch--column-details-queue (conn)
  "Return the async column-details queue for CONN."
  (gethash conn clutch--column-details-queue-cache))

(defun clutch--set-column-details-queue (conn queue)
  "Store async column-details QUEUE for CONN."
  (puthash conn queue clutch--column-details-queue-cache))

(defun clutch--column-details-active (conn)
  "Return the active async column-details fetch for CONN, or nil."
  (gethash conn clutch--column-details-active-cache))

(defun clutch--set-column-details-active (conn table ticket)
  "Record TABLE/TICKET as the active async column-details fetch for CONN."
  (puthash conn (cons table ticket)
           clutch--column-details-active-cache))

(defun clutch--clear-column-details-active (conn)
  "Clear the active async column-details fetch for CONN."
  (remhash conn clutch--column-details-active-cache))

(defun clutch--finish-stale-column-details-callback (conn table ticket)
  "Release stale TABLE/TICKET work on CONN and resume its details queue."
  (let ((active (clutch--column-details-active conn)))
    (when (or (null active)
              (and (equal (car active) table)
                   (eql (cdr active) ticket)))
      (when active
        (clutch--clear-column-details-active conn))
      (clutch--drain-column-details-async conn))))

(defun clutch--install-schema-cache (conn table-names &optional ticket)
  "Install TABLE-NAMES as the schema cache for CONN.
When TICKET is non-nil, ignore the update unless it is still current."
  (when (and (clutch-db-live-p conn)
             (or (null ticket)
                 (clutch--schema-refresh-ticket-current-p conn ticket)))
    (let ((schema (make-hash-table :test 'equal)))
      (clutch--notify-schema-cache-updated conn 'invalidated)
      (dolist (tbl table-names)
        (puthash tbl nil schema))
      (puthash conn schema clutch--schema-cache)
      (clutch--clear-schema-dependent-caches conn)
      (clutch--set-schema-status conn 'ready (hash-table-count schema))
      (clutch--notify-schema-cache-updated conn 'ready)
      t)))

(defun clutch--clear-connection-metadata-caches (conn)
  "Clear schema-scoped metadata caches for CONN."
  (remhash conn clutch--schema-cache)
  (clutch--clear-schema-dependent-caches conn)
  (remhash conn clutch--schema-status-cache)
  (remhash conn clutch--schema-refresh-tickets)
  (clutch--notify-schema-cache-updated conn 'invalidated))

(defun clutch--remember-schema-refresh-error (conn message)
  "Record schema refresh MESSAGE for CONN."
  (clutch--set-schema-status conn 'failed nil message)
  (clutch--remember-problem-record
   :connection conn
   :problem (list :backend (clutch-db-backend-key conn)
                  :summary (clutch--humanize-db-error message)
                  :diag (list :category "metadata"
                              :op "schema-refresh"
                              :raw-message message)))
  (clutch--metadata-debug-event
   conn "schema-refresh" "error" message))

(defun clutch--refresh-schema-cache-async (conn &optional idle-delay)
  "Refresh schema cache for CONN asynchronously when supported.
Return non-nil when an asynchronous refresh was started.
IDLE-DELAY, when non-nil, is passed to idle metadata backends."
  (let ((ticket (clutch--begin-schema-refresh-ticket conn)))
    (clutch--set-schema-status conn 'refreshing)
    (let ((started
           (clutch-db-refresh-schema-async
            conn
            (lambda (table-names)
              (if (clutch--schema-refresh-ticket-current-p conn ticket)
                  (progn
                    (clutch--metadata-debug-event
                     conn "schema-refresh" "success"
                     (format "Loaded %d tables" (length table-names)))
                    (clutch--install-schema-cache conn table-names ticket))
                (clutch--metadata-debug-event
                 conn "schema-refresh" "stale-drop"
                 "Ignored stale schema refresh result")))
            (lambda (message)
              (if (clutch--schema-refresh-ticket-latest-p conn ticket)
                  (clutch--remember-schema-refresh-error conn message)
                (clutch--metadata-debug-event
                 conn "schema-refresh" "stale-drop"
                 "Ignored stale schema refresh error")))
            idle-delay)))
      (when started
        (clutch--metadata-debug-event
         conn "schema-refresh" "submit"
         "Queued background schema refresh"))
      started)))

(defun clutch--refresh-schema-cache (conn)
  "Refresh schema cache for CONN.
Only loads table names (fast).  Column info is loaded lazily."
  (let ((ticket (clutch--begin-schema-refresh-ticket conn)))
    (clutch--set-schema-status conn 'refreshing)
    (condition-case err
        (let ((table-names (clutch-db-list-tables conn)))
          (prog1
              (clutch--install-schema-cache conn table-names ticket)
            (clutch--metadata-debug-event
             conn "schema-refresh" "success"
             (format "Loaded %d tables" (length table-names)))))
      (clutch-db-error
       (clutch--remember-schema-refresh-error conn (clutch-db--error-message err))
       nil))))

(defun clutch--prime-schema-cache (conn)
  "Kick off the appropriate schema refresh strategy for CONN."
  (if (clutch-db-eager-schema-refresh-p conn)
      (clutch--refresh-schema-cache conn)
    (unless (clutch--refresh-schema-cache-async
             conn clutch-schema-refresh-idle-delay-seconds)
      (clutch--refresh-schema-cache conn))))

(defun clutch--ensure-columns (conn schema table)
  "Ensure column info for TABLE is loaded in SCHEMA for CONN.
Fetches from the backend if not yet cached.  Returns column list."
  (let ((cols (gethash table schema 'missing))
        (status (clutch--metadata-status conn table :columns-status)))
    (unless (eq cols 'missing)
      (or cols
          (unless (memq (plist-get status :state) '(ready failed))
            (condition-case err
                (let ((col-names (clutch-db-list-columns conn table)))
                  (puthash table col-names schema)
                  (clutch--set-metadata-status conn table :columns-status 'ready)
                  col-names)
              (clutch-db-error
               (clutch--set-metadata-status
                conn table :columns-status 'failed (clutch-db--error-message err))
               nil)))))))

(defun clutch--metadata-callback-current-p
    (conn ticket status table op outcome)
  "Return non-nil when a metadata callback is current.
Record a stale OUTCOME for TABLE and OP on CONN otherwise.  TICKET and STATUS
identify the request."
  (if (and (clutch-db-live-p conn)
           (eql (plist-get status :ticket) ticket))
      t
    (clutch--metadata-debug-table-event
     conn op "stale-drop" table
     (format "Ignored stale %s for %s" outcome
             (clutch--table-key-label table)))
    nil))

(defun clutch--start-table-metadata-request
    (conn key table status-property op fetch install &optional report-error)
  "Start one independent async metadata request for TABLE on CONN.
KEY and STATUS-PROPERTY locate its state.  OP labels diagnostics.  FETCH is
called with CONN, TABLE, a success callback, and an error callback.  INSTALL
stores the successful value.  REPORT-ERROR, when non-nil, handles an error
message after its failed state is recorded."
  (let ((ticket (clutch--begin-metadata-ticket)))
    (clutch--set-metadata-status
     conn key status-property 'loading nil ticket)
    (cl-labels
        ((failed (message)
           (when (clutch--metadata-callback-current-p
                  conn ticket
                  (clutch--metadata-status conn key status-property)
                  table op "error")
             (clutch--set-metadata-status
              conn key status-property 'failed message ticket)
             (clutch--metadata-debug-table-event conn op "error" table message)
             (when report-error (funcall report-error message))
             (clutch--notify-metadata-state-changed conn))))
      (let ((started
             (condition-case error-data
                 (funcall
                  fetch conn table
                  (lambda (value)
                    (when (clutch--metadata-callback-current-p
                           conn ticket
                           (clutch--metadata-status conn key status-property)
                           table op "result")
                      (clutch--metadata-debug-table-event
                       conn op "success" table
                       (format "Loaded %s for %s" op
                               (clutch--table-key-label table)))
                      (clutch--clear-metadata-status conn key status-property)
                      (funcall install value)
                      (clutch--notify-metadata-state-changed conn)))
                  #'failed)
               (error
                (failed (error-message-string error-data))
                t))))
        (when started
          (clutch--metadata-debug-table-event
           conn op "submit" table
           (format "Queued background %s for %s" op
                   (clutch--table-key-label table))))
        started))))

(defun clutch--ensure-columns-async (conn schema table)
  "Queue an async column-name fetch for TABLE in SCHEMA on CONN when needed."
  (let ((columns (if schema (gethash table schema 'missing) 'missing))
        (state (plist-get
                (clutch--metadata-status conn table :columns-status)
                :state)))
    (unless (or (eq columns 'missing)
                columns
                (memq state '(queued loading ready failed)))
      (let ((started
             (clutch--start-table-metadata-request
              conn table table :columns-status "list-columns"
              #'clutch-db-list-columns-async
              (lambda (columns)
                (when-let* ((live-schema
                             (gethash conn clutch--schema-cache)))
                  (puthash table columns live-schema)
                  (clutch--set-metadata-status
                   conn table :columns-status 'ready))))))
        (unless started
          (clutch--ensure-columns conn schema table)
          (clutch--notify-metadata-state-changed conn)))
      t)))

(defun clutch--ensure-column-details (conn table &optional strict)
  "Return column details for TABLE on CONN, loading lazily if needed.
Returns a list of plists with :name :type :nullable :primary-key :foreign-key,
or nil on error.  When STRICT is non-nil, signal `clutch-db-error'."
  (let* ((metadata (clutch--table-metadata conn table))
         (cached (if (plist-member metadata :column-details)
                     (plist-get metadata :column-details)
                   'missing))
         (status (clutch--metadata-status
                  conn table :column-details-status)))
    (if (not (eq cached 'missing))
        cached
      (if (eq (plist-get status :state) 'failed)
          (when strict
            (let* ((message (or (plist-get status :error)
                                (format "Failed to load column details for %s"
                                        (clutch--table-key-label table))))
                   (details (clutch-db-error-details conn)))
              (signal 'clutch-db-error
                      (if details
                          (list message (copy-tree details))
                        (list message)))))
        (condition-case err
            (let ((details (apply #'clutch-db-column-details
                                  conn (clutch--table-key-arguments table))))
              (clutch--set-table-metadata conn table :column-details details)
              (clutch--clear-metadata-status
               conn table :column-details-status)
              details)
          (clutch-db-error
           (let* ((message (clutch-db--error-message err))
                  (details (or (nth 2 err)
                               (clutch-db-error-details conn))))
             (clutch--set-metadata-status
              conn table :column-details-status 'failed message)
             (when strict
               (signal 'clutch-db-error
                       (if details
                           (list message (copy-tree details))
                         (list message))))
             nil)))))))

(defun clutch--drain-column-details-async (conn)
  "Start the next queued async column-details fetch for CONN."
  (unless (or (clutch--column-details-active conn)
              (not (clutch-db-live-p conn)))
    (when-let* ((queue (clutch--column-details-queue conn))
                (table (car queue))
                (ticket
                 (plist-get
                  (clutch--metadata-status
                   conn table :column-details-status)
                  :ticket)))
      (clutch--set-column-details-queue conn (cdr queue))
      (clutch--set-column-details-active conn table ticket)
      (clutch--set-metadata-status
       conn table :column-details-status 'loading nil ticket)
      (let ((started
             (clutch--table-metadata-async
              #'clutch-db-column-details-async conn table
              (lambda (details)
                (if (clutch--metadata-callback-current-p
                     conn ticket
                     (clutch--metadata-status
                      conn table :column-details-status)
                     table "column-details" "column-detail result")
                    (progn
                      (clutch--metadata-debug-table-event
                       conn "column-details" "success" table
                       (format "Loaded %d column details for %s"
                               (length details)
                               (clutch--table-key-label table)))
                      (clutch--set-table-metadata
                       conn table :column-details details)
                      (clutch--clear-metadata-status
                       conn table :column-details-status)
                      (clutch--clear-column-details-active conn)
                      (run-hook-with-args
                       'clutch--table-metadata-updated-hook
                       conn table 'column-details)
                      (clutch--notify-metadata-state-changed conn)
                      (clutch--drain-column-details-async conn))
                  (clutch--finish-stale-column-details-callback
                   conn table ticket)))
              (lambda (message)
                (if (clutch--metadata-callback-current-p
                     conn ticket
                     (clutch--metadata-status
                      conn table :column-details-status)
                     table "column-details" "column-detail error")
                    (progn
                      (clutch--set-metadata-status
                       conn table :column-details-status
                       'failed message ticket)
                      (clutch--metadata-debug-table-event
                       conn "column-details" "error" table message)
                      (clutch--clear-column-details-active conn)
                      (clutch--notify-metadata-state-changed conn)
                      (clutch--drain-column-details-async conn))
                  (clutch--finish-stale-column-details-callback
                   conn table ticket))))))
        (when started
          (clutch--metadata-debug-table-event
           conn "column-details" "submit" table
           (format "Queued background column-detail preheat for %s"
                   (clutch--table-key-label table))))
        (unless started
          (clutch--ensure-column-details conn table)
          (clutch--clear-column-details-active conn)
          (when (clutch--column-details-cached-p conn table)
            (run-hook-with-args
             'clutch--table-metadata-updated-hook
             conn table 'column-details))
          (clutch--notify-metadata-state-changed conn)
          (clutch--drain-column-details-async conn))))))

(defun clutch--ensure-column-details-async (conn table)
  "Queue an async column-detail fetch for TABLE on CONN when needed."
  (let ((state (plist-get
                (clutch--metadata-status
                 conn table :column-details-status)
                :state))
        (ticket (clutch--begin-metadata-ticket)))
    (unless (or (clutch--column-details-cached-p conn table)
                (memq state '(queued loading)))
      (clutch--set-metadata-status
       conn table :column-details-status 'queued nil ticket)
      (clutch--set-column-details-queue
       conn
       (append (clutch--column-details-queue conn) (list table)))
      (clutch--drain-column-details-async conn)
      t)))

(defun clutch--ensure-table-comment (conn table &optional schema)
  "Return TABLE's comment in SCHEMA on CONN, loading it when needed.
Returns a string or nil."
  (let* ((key (clutch--table-comment-key conn table schema))
         (metadata (clutch--table-metadata conn key)))
    (if (plist-member metadata :comment)
        (plist-get metadata :comment)
      (condition-case err
          (let ((comment (clutch-db-table-comment conn table schema)))
            (clutch--set-table-metadata conn key :comment comment)
            comment)
        (clutch-db-error
         (clutch--remember-recoverable-metadata-warning
          conn "table comment" err `(:table ,table :schema ,schema))
         nil)))))

(defun clutch--ensure-table-comment-async (conn table)
  "Queue an async table-comment fetch for TABLE on CONN when needed."
  (let* ((schema (clutch-db-current-schema conn))
         (key (clutch--table-comment-key conn table schema))
         (state (plist-get
                 (clutch--metadata-status conn key :comment-status)
                 :state)))
    (unless (or (not table)
                (clutch--table-comment-cached-p conn table schema)
                (memq state '(queued loading failed)))
      (let ((started
             (clutch--start-table-metadata-request
              conn key table :comment-status "table-comment"
              #'clutch-db-table-comment-async
              (lambda (comment)
                (clutch--set-table-metadata conn key :comment comment)))))
        (unless started
          (condition-case err
              (progn
                (clutch--set-table-metadata
                 conn key :comment
                 (clutch-db-table-comment conn table schema))
                (clutch--clear-metadata-status conn key :comment-status))
            (clutch-db-error
             (clutch--set-metadata-status
              conn key :comment-status 'failed (clutch-db--error-message err)
              (plist-get (clutch--metadata-status conn key :comment-status)
                         :ticket))))
          (clutch--notify-metadata-state-changed conn)))
      t)))

(defun clutch--ensure-foreign-keys-async (conn table)
  "Queue an async foreign-key fetch for TABLE on CONN when needed."
  (let ((state (plist-get
                (clutch--metadata-status conn table :foreign-keys-status)
                :state)))
    (unless (or (not table)
                (clutch--foreign-keys-cached-p conn table)
                (memq state '(queued loading failed)))
      (let ((started
             (clutch--start-table-metadata-request
              conn table table :foreign-keys-status "foreign-keys"
              (apply-partially #'clutch--table-metadata-async
                               #'clutch-db-foreign-keys-async)
              (lambda (fks)
                (clutch--set-table-metadata conn table :foreign-keys fks)
                (run-hook-with-args
                 'clutch--table-metadata-updated-hook
                 conn table 'foreign-keys))
              (lambda (message)
                (clutch--remember-recoverable-metadata-warning
                 conn "foreign-key metadata"
                 `(clutch-db-error ,message)
                 `(:table ,(clutch--table-key-label table)))))))
        (unless started
          (clutch--set-table-metadata conn table :foreign-keys nil)
          (clutch--clear-metadata-status conn table :foreign-keys-status)))
      t)))

(defun clutch--format-help-doc (doc)
  "Format a DOC plist (:sig SIG :desc DESC) as a propertized eldoc string."
  (let ((sig  (plist-get doc :sig))
        (desc (plist-get doc :desc)))
    (concat (propertize sig 'face 'font-lock-function-name-face)
            (when (and desc (not (string-empty-p desc)))
              (propertize (concat "  — " desc) 'face 'shadow)))))

(defun clutch--ensure-help-doc (conn sym)
  "Return a backend-provided eldoc string for SYM from CONN, with caching.
Queries the server on first access; subsequent calls read from cache.
Returns nil when SYM is not a known built-in on this server."
  (let* ((cache (or (gethash conn clutch--help-doc-cache)
                    (let ((h (make-hash-table :test 'equal)))
                      (puthash conn h clutch--help-doc-cache)
                      h)))
         (uname (upcase sym))
         (entry (gethash uname cache 'missing)))
    (cond
     ((eq entry 'missing)
      (condition-case err
          (let ((doc (clutch-db-symbol-help conn sym)))
            (puthash uname (or doc 'not-found) cache)
            (when doc (clutch--format-help-doc doc)))
        (clutch-db-error
         (clutch--remember-recoverable-metadata-warning
          conn "symbol help" err `(:symbol ,sym))
         nil)))
     ((eq entry 'not-found) nil)
     (t (clutch--format-help-doc entry)))))

(defun clutch--schema-for-connection (&optional conn)
  "Return the schema hash-table for CONN, or nil.
When CONN is nil, use `clutch-connection'."
  (let ((conn (or conn clutch-connection)))
    (when (clutch-db-live-p conn)
      (gethash conn clutch--schema-cache))))

(provide 'clutch-schema)

;;; clutch-schema.el ends here
