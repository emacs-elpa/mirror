;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-reminder" "0.1.0.20230222.27"
  "Notifications that remind you about clocked-in tasks."
  '((emacs "26.1"))
  :url "https://github.com/inickey/org-clock-reminder"
  :commit "d3bf97113fd519aa08198e2283ba9c236a6df168"
  :revdesc "d3bf97113fd5"
  :keywords '("calendar" "convenience")
  :authors '(("Nikolay Brovko" . "i@nickey.ru"))
  :maintainers '(("Nikolay Brovko" . "i@nickey.ru")))
