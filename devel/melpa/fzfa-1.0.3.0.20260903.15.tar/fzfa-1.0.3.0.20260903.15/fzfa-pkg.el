;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0.3.0.20260903.15"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.7"))
  :url "https://github.com/jojojames/fzfa"
  :commit "caec167393d7162089268a04541a2fd18dd422a4"
  :revdesc "caec167393d7"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
