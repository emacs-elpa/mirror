;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-identifiers-mode" "1.0.0.0.20251227.120"
  "Color identifiers based on their names."
  '((dash  "2.5.0")
    (emacs "24.4"))
  :url "https://github.com/ankurdave/color-identifiers-mode"
  :commit "adcdbbe9c69edeb207f2b066db071057f3f612d6"
  :revdesc "adcdbbe9c69e"
  :keywords '("faces" "languages")
  :authors '(("Ankur Dave" . "ankurdave@gmail.com"))
  :maintainers '(("Ankur Dave" . "ankurdave@gmail.com")))
