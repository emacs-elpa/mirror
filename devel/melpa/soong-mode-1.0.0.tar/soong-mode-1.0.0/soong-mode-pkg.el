;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soong-mode" "1.0.0"
  "Major mode for editing Soong build files."
  '((emacs "27.1"))
  :url "https://github.com/bobrofon/soong-mode"
  :commit "bf3dc1070b368b413958f54fbe9bcc2aaf77b56f"
  :revdesc "bf3dc1070b36"
  :keywords '("languages")
  :authors '(("Sergey Bobrenok" . "bobrofon@gmail.com"))
  :maintainers '(("Sergey Bobrenok" . "bobrofon@gmail.com")))
