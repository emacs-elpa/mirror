;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codesearch" "1.0.20240828.44"
  "Core support for managing codesearch tools."
  '((log4e "0.3.1"))
  :url "https://github.com/abingham/emacs-codesearch"
  :commit "92b4c2557c0bbf7da4d26c413feccb6766e70a9c"
  :revdesc "92b4c2557c0b"
  :keywords '("tools" "development" "search")
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com")
             ("Youngjoo Lee" . "youngker@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")
                 ("Youngjoo Lee" . "youngker@gmail.com")))
