;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-toggle-sudo" "1.0.0.20211216.3"
  "Browse directory with sudo privileges."
  ()
  :url "https://github.com/renard/dired-toggle-sudo"
  :commit "9f86cdf858225b15c20affb97ed105e4109047bf"
  :revdesc "v1.0-3-g9f86cdf85822"
  :keywords '("emacs" "dired")
  :authors '(("Sebastien Gross" . "seb•ɑƬ•chezwam•ɖɵʈ•org"))
  :maintainers '(("Sebastien Gross" . "seb•ɑƬ•chezwam•ɖɵʈ•org")))
