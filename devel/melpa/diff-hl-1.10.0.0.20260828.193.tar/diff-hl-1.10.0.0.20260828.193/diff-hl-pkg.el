;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "1.10.0.0.20260828.193"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "8dca5a562289adc3eabc4f0a15a8c856aa799268"
  :revdesc "8dca5a562289"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
