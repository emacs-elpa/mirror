;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sequences" "0.1.0.0.20170818.5"
  "Ports of some Clojure sequence functions."
  '((emacs "24"))
  :url "https://github.com/timvisher/sequences.el"
  :commit "564ebbd93b0beea4e75acfbf824350e90b5d5738"
  :revdesc "564ebbd93b0b"
  :keywords '("convenience")
  :authors '(("Tim Visher" . "tim.visher@gmail.com"))
  :maintainers '(("Tim Visher" . "tim.visher@gmail.com")))
