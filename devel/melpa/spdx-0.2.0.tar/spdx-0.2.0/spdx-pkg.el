;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "0.2.0"
  "Insert SPDX license and copyright headers."
  '((emacs "29.1"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "f23612d30562c92e399fa744920782cc1f7197b3"
  :revdesc "f23612d30562"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
