;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reformatter" "0.7.0.20241204.34"
  "Define commands which run reformatters on the current buffer."
  '((emacs "24.3"))
  :url "https://github.com/purcell/emacs-reformatter"
  :commit "f2cb59466b1c3f85a8c960f7d4b7b7ead015bedc"
  :revdesc "f2cb59466b1c"
  :keywords '("convenience" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
