;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel" "3.0.0.20260919.64"
  "Control Kubernetes with limited permissions."
  '((transient "0.1.0")
    (emacs     "25.3")
    (dash      "2.12.0")
    (s         "1.2.0")
    (yaml-mode "0.0.14"))
  :url "https://github.com/abrochard/kubel"
  :commit "72e36d45c98e1aef927ea0e056c17ad539efe4ee"
  :revdesc "72e36d45c98e"
  :keywords '("kubernetes" "k8s" "tools" "processes"))
