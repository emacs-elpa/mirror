;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "2.0.2.0.20261021.6"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "c34975bbe74b6489266d7568b3faec98d5a4d238"
  :revdesc "v2.0.2-6-gc34975bbe74b"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
