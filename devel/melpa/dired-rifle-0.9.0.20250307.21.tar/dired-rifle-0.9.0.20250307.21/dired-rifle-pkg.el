;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-rifle" "0.9.0.20250307.21"
  "Call rifle(1) from dired."
  ()
  :url "https://github.com/vifon/dired-rifle.el"
  :commit "4bc28f2892cf586cde0a200e350b17218dc556c4"
  :revdesc "4bc28f2892cf"
  :keywords '("files" "convenience")
  :authors '(("Wojciech Siewierski" . "wojciechdotsiewierskiatonetdotpl"))
  :maintainers '(("Wojciech Siewierski" . "wojciechdotsiewierskiatonetdotpl")))
