;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tco" "0.3.0.20191129.5"
  "Tail-call optimisation for Emacs lisp."
  '((dash  "1.2.0")
    (emacs "24.3"))
  :url "https://github.com/Wilfred/tco.el"
  :commit "d82478d56568f60b3a82fd010b3ca0bab2ef5dc9"
  :revdesc "d82478d56568"
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
