;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "1.1.6.0.20260824.3"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "c9757254a9a27a11a36a889cbe6095d67b78bc65"
  :revdesc "c9757254a9a2"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
