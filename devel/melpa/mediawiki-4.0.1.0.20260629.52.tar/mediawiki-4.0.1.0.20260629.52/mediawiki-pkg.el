;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "4.0.1.0.20260629.52"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "0d62770e02b232efae8cbf1926f63adc01a4c9ef"
  :revdesc "0d62770e02b2"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
