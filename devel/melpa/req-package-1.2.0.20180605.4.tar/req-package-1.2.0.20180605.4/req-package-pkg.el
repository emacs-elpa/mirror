;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "req-package" "1.2.0.20180605.4"
  "A use-package wrapper for package runtime dependencies management."
  '((use-package "1.0")
    (dash        "2.7.0")
    (log4e       "0.2.0")
    (ht          "0"))
  :url "https://github.com/edvorg/req-package"
  :commit "a77da72931914ac5f3f64dc61fe9dc3522b2817e"
  :revdesc "a77da7293191"
  :keywords '("dotemacs" "startup" "speed" "config" "package")
  :authors '(("Edward Knyshov" . "edvorg@gmail.com"))
  :maintainers '(("Edward Knyshov" . "edvorg@gmail.com")))
