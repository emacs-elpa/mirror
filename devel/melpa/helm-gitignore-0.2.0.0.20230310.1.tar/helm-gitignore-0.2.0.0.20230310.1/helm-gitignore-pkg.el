;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-gitignore" "0.2.0.0.20230310.1"
  "Generate .gitignore files with gitignore.io."
  '((git-modes "1.4.0")
    (helm      "1.7.0")
    (request   "0.1.0")
    (cl-lib    "0.5"))
  :url "https://github.com/jupl/helm-gitignore"
  :commit "85c34065e6fceac8fa7287e6ec79ea3d1182d654"
  :revdesc "85c34065e6fc"
  :keywords '("helm" "gitignore" "gitignore.io"))
