;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tr-ime" "0.5.0"
  "Emulator of IME patch for Windows."
  '((emacs   "27.1")
    (w32-ime "0.0.1"))
  :url "https://github.com/trueroad/tr-emacs-ime-module"
  :commit "87f0677220b755f947fe5f373b6a34e1afb82f3c"
  :revdesc "v0.5.0-0-g87f0677220b7"
  :authors '(("Masamichi Hosoda" . "trueroad@trueroad.jp"))
  :maintainers '(("Masamichi Hosoda" . "trueroad@trueroad.jp")))
