;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wren-mode" "0.0.1.0.20221227.1"
  "A major mode for the Wren programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/wren-mode"
  :commit "70b1b89f565679a15c8c9c1a9bda98b0d163e83e"
  :revdesc "70b1b89f5656"
  :keywords '("files" "wren"))
