;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swift-mode" "10.0.0.0.20260827.38"
  "Major-mode for Apple's Swift programming language."
  '((emacs "25.2"))
  :url "https://github.com/swift-emacs/swift-mode"
  :commit "bb4ef3a344a04ec97c8707ad8c5aadc2f446ad02"
  :revdesc "bb4ef3a344a0"
  :keywords '("languages" "swift")
  :authors '(("taku0" . "mxxouy6x3m_github@tatapa.org")
             ("Chris Barrett" . "chris.d.barrett@me.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.com")
             ("Arthur Evstifeev" . "lod@pisem.net"))
  :maintainers '(("taku0" . "mxxouy6x3m_github@tatapa.org")))
