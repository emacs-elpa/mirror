;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "0.1.0.0.20260817.47"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (transient  "0.7.0")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "2187ace87a6bcc04cd61bd5a4f8d76221286682d"
  :revdesc "2187ace87a6b"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
