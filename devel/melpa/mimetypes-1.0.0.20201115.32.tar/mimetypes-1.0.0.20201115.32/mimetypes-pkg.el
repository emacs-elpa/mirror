;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mimetypes" "1.0.0.20201115.32"
  "Guess a file's mimetype by extension."
  '((emacs "25.1"))
  :url "https://github.com/cniles/emacs-mimetypes"
  :commit "1663054ce266ed25e47ec707c19f619d33225903"
  :revdesc "1663054ce266"
  :authors '(("Craig Niles" . "niles.catgmail.com"))
  :maintainers '(("Craig Niles" . "niles.catgmail.com")))
