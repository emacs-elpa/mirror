;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ctftime" "1.0.0.0.20261025.12"
  "CTFtime dashboard."
  '((emacs "27.1"))
  :url "https://github.com/giovanni-iannaccone/ctftime.el"
  :commit "67763c4c45cf5425fb8f28e2219d3e175f3de770"
  :revdesc "67763c4c45cf"
  :keywords '("ctf" "tools" "games")
  :authors '(("Giovanni Francesco Iannaccone" . "iannacconegiovanni444@gmail.com"))
  :maintainers '(("Giovanni Francesco Iannaccone" . "iannacconegiovanni444@gmail.com")))
