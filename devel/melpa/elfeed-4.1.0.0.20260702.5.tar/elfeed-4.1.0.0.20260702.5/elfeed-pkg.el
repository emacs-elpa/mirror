;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.1.0.0.20260702.5"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "149bb4ef375c3461f7ff37620759c33050bfb132"
  :revdesc "4.1.0-5-g149bb4ef375c"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
