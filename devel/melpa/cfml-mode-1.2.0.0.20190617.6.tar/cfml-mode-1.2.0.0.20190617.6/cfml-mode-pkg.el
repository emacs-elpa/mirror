;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfml-mode" "1.2.0.0.20190617.6"
  "Emacs mode for editing CFML files."
  '((emacs "25"))
  :url "https://github.com/am2605/cfml-mode"
  :commit "b06d7cee2af0ed5d55a94f0db80fc1f429a1829a"
  :revdesc "b06d7cee2af0"
  :authors '(("Andrew Myers" . "am2605@gmail.com"))
  :maintainers '(("Andrew Myers" . "am2605@gmail.com")))
