;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hnview" "0.1.0.0.20260718.29"
  "Standalone Hacker News client."
  '((emacs "29.1")
    (llm   "0.30.1")
    (plz   "0.9"))
  :url "https://github.com/luciuschen/hnview"
  :commit "4f7b76c93a5fe5bee763b93740e8e33e634eb1e7"
  :revdesc "4f7b76c93a5f"
  :keywords '("news" "hypermedia" "convenience")
  :authors '(("Lucius Chen" . "https://github.com/LuciusChen"))
  :maintainers '(("Lucius Chen" . "https://github.com/LuciusChen")))
