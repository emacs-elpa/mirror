;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "0.5.2.0.20261002.23"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "66fac138a09f02edc0750218180db65ec3e25b1f"
  :revdesc "66fac138a09f"
  :keywords '("convenience" "gptel" "llm"))
