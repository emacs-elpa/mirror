;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nrepl-sync" "0.3.1"
  "Connect to nrepl port and eval .sync.clj."
  '((cider "0.6"))
  :url "https://github.com/phillord/lein-sync"
  :commit "471a08df87687a3eab61b3b8bf25a2e0962b5d5b"
  :revdesc "0.3.1-0-g471a08df8768"
  :authors '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk"))
  :maintainers '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk")))
