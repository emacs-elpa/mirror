;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.58.1.0.20260711.9"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "156b777832400bc6996839b4dd4d2728cabe5cb9"
  :revdesc "156b77783240")
