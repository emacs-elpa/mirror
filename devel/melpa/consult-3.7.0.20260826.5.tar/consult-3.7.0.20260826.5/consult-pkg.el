;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "3.7.0.20260826.5"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "1aec7822fec2724a2e4978665681992f420c29b5"
  :revdesc "3.7-5-g1aec7822fec2"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
