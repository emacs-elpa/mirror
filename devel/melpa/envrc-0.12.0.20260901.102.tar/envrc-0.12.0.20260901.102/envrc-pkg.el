;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "0.12.0.20260901.102"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "105da4c1520e42310234564e6477fc3b9a9b9d7b"
  :revdesc "105da4c1520e"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
