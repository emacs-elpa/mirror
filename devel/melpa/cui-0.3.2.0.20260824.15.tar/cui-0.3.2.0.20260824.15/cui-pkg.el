;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "0.3.2.0.20260824.15"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "6157934b1901e645f9ec0627b38d7c8a202cbbee"
  :revdesc "6157934b1901"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
