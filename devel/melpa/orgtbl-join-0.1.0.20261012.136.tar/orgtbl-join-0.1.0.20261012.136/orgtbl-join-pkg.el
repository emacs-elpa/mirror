;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "0.1.0.20261012.136"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "2f2b24c484d648a18737dd3240b004728e50fc05"
  :revdesc "2f2b24c484d6"
  :keywords '("data" "extensions"))
