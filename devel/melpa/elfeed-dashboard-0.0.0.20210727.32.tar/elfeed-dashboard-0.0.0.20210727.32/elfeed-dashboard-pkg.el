;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-dashboard" "0.0.0.20210727.32"
  "An extensible frontend for elfeed using org-mode."
  '((emacs  "25.1")
    (elfeed "3.3.0"))
  :url "https://github.com/Manoj321/elfeed-dashboard"
  :commit "b143f8453aed2053e8fc6f05cef6233797408546"
  :revdesc "b143f8453aed"
  :keywords '("convenience")
  :authors '(("Manoj Kumar Manikchand" . "manojm321@protonmail.com"))
  :maintainers '(("Manoj Kumar Manikchand" . "manojm321@protonmail.com")))
