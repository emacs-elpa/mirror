;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mark-tools" "0.3.0.20130614.8"
  "Some simple tools to access the mark-ring in Emacs."
  ()
  :url "https://github.com/stsquad/emacs-mark-tools"
  :commit "a11b61effa90bd0abc876d12573674d36fc17f0c"
  :revdesc "a11b61effa90"
  :authors '(("Alex Bennée" . "alex@bennee.com"))
  :maintainers '(("Alex Bennée" . "alex@bennee.com")))
