;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maruo-macro-mode" "0.0.0.20160616.7"
  "Major mode for editing Hidemaru/Maruo macro script."
  '((emacs "24.3"))
  :url "https://github.com/zonuexe/maruo-macro-mode.el"
  :commit "8fc9a38ad051eafa8eb94038711acc52c5d1d8d5"
  :revdesc "8fc9a38ad051"
  :keywords '("programming" "editor" "macro")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
