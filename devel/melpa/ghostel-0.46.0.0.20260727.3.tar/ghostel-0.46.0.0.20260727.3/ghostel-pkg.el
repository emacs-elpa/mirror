;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.46.0.0.20260727.3"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "787a24701ecf693c27117148c3ab4a74add57fc5"
  :revdesc "787a24701ecf"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
