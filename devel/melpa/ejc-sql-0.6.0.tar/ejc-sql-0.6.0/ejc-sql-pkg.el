;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "0.6.0"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "30.2")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "1ac28c45e60ef69c58965019283623942309ccfd"
  :revdesc "v0.6.0-0-g1ac28c45e60e"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
