;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cpp-auto-include" "0.2.0.0.20210318.1"
  "Insert and delete C++ header files automatically."
  '((cl-lib "0.5"))
  :url "https://github.com/emacsorphanage/cpp-auto-include"
  :commit "0ce829f27d466c083e78b9fe210dcfa61fb417f4"
  :revdesc "v0.2.0-1-g0ce829f27d46"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
