;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-rsi" "2.0.0"
  "Use emacs motion keys in evil, inspired by vim-rsi."
  '((evil "1.0.0"))
  :url "https://github.com/linktohack/evil-rsi"
  :commit "236bf6ed1e2285698db808463e5f2f69f5f5e7c0"
  :revdesc "236bf6ed1e22"
  :keywords '("evil" "rsi" "evil-rsi")
  :authors '(("Quang Linh LE" . "linktohack@gmail.com"))
  :maintainers '(("Quang Linh LE" . "linktohack@gmail.com")))
