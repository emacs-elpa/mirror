;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dkdo" "1.1.0.20131110.1"
  "Do List major mode based on org-mode."
  '((dkmisc "0.50")
    (emacs  "24.1"))
  :url "https://github.com/davidkeegan/dkdo"
  :commit "fd6bb105e8331fafb6385c5238c988c4c5bbe2da"
  :revdesc "fd6bb105e833"
  :keywords '("dolist" "task" "productivity")
  :authors '(("David Keegan" . "dksw@eircom.net"))
  :maintainers '(("David Keegan" . "dksw@eircom.net")))
