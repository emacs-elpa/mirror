;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.4.0.0.20260819.11"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "086aa4e481e44c5fc8fdee2345f05ffb8e2bac12"
  :revdesc "086aa4e481e4"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
