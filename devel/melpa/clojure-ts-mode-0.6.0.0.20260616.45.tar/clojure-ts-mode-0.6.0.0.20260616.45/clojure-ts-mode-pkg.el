;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "0.6.0.0.20260616.45"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "https://github.com/clojure-emacs/clojure-ts-mode"
  :commit "af00860cd85a46d7b95af1e4f966d3ddccdab9b4"
  :revdesc "af00860cd85a"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :authors '(("Danny Freeman" . "danny@dfreeman.email")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
