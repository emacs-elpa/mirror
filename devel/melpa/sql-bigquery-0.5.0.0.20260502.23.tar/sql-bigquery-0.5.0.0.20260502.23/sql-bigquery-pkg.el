;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sql-bigquery" "0.5.0.0.20260502.23"
  "Adds BigQuery support to SQLi mode."
  '((emacs "25.1"))
  :url "https://github.com/regadas/sql-bigquery"
  :commit "1d068f7a7226d7af70d4ffceb86bc5e91826c29e"
  :revdesc "1d068f7a7226"
  :keywords '("languages" "sql" "bigquery")
  :authors '(("Martin Nowak" . "code+sql-bigquery@dawg.eu"))
  :maintainers '(("Filipe Regadas" . "oss@regadas.email")))
