;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noctilux-theme" "0.0.0.20161113.28"
  "Dark theme inspired by LightTable."
  '((emacs "24"))
  :url "https://github.com/sjrmanning/noctilux-theme"
  :commit "a3265a1be7f4d73f44acce6d968ca6f7add1f2ca"
  :revdesc "a3265a1be7f4"
  :authors '(("Simon Manning" . "simon@ecksdee.org"))
  :maintainers '(("Simon Manning" . "simon@ecksdee.org")))
