;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.8.0.0.20261125.124"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "8edcaf38d5fbf5260af020f09c714a22c29a40ce"
  :revdesc "8edcaf38d5fb"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
