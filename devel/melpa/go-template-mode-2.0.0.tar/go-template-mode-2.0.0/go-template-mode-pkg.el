;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-template-mode" "2.0.0"
  "Major mode for Go templates."
  '((emacs "28.1"))
  :url "https://codeberg.org/rch/go-template-mode"
  :commit "c36a779879204269d89b8581a3021387e56bc700"
  :revdesc "c36a77987920"
  :keywords '("languages" "tools")
  :authors '(("Robert Charusta" . "rch-public@posteo.net"))
  :maintainers '(("Robert Charusta" . "rch-public@posteo.net")))
