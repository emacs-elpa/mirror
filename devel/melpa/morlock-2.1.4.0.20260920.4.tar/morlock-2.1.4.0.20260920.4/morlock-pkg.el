;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morlock" "2.1.4.0.20260920.4"
  "More font-lock keywords for elisp."
  '((emacs "29.1"))
  :url "https://github.com/tarsius/morlock"
  :commit "4c2ed33733f93a0492b6e479e70eb1a84dc472fa"
  :revdesc "v2.1.4-4-g4c2ed33733f9"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev")))
