;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-make" "0.1.0.0.20200620.59"
  "Select a Makefile target with helm."
  ()
  :url "https://github.com/abo-abo/helm-make"
  :commit "ebd71e85046d59b37f6a96535e01993b6962c559"
  :revdesc "ebd71e85046d"
  :keywords '("makefile")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
