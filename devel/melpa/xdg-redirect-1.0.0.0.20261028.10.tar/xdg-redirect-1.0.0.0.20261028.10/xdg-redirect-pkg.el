;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xdg-redirect" "1.0.0.0.20261028.10"
  "Redirect Emacs files to XDG directories."
  '((emacs "27.1"))
  :url "https://github.com/francisco-colaco/xdg-redirect"
  :commit "af73eb5dc6f3650c745f9cb3d0291253e57aa604"
  :revdesc "af73eb5dc6f3"
  :keywords '("convenience" "files")
  :authors '(("Francisco Miguel Colaço" . "francisco.colaco@gmail.com"))
  :maintainers '(("Francisco Miguel Colaço" . "francisco.colaco@gmail.com")))
