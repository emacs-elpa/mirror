;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "msgpack" "0.0.0.20200323.42"
  "Read and write MessagePack object."
  '((emacs "25.1"))
  :url "https://github.com/xuchunyang/msgpack.el"
  :commit "e2a0d76d1087bc8178c9f27222cb9b93e2e815ec"
  :revdesc "e2a0d76d1087"
  :keywords '("lisp"))
