;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "1.7.0.20260611.3"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "f004cce95e0f5c5048d38f973b654587ed73abf6"
  :revdesc "f004cce95e0f"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
