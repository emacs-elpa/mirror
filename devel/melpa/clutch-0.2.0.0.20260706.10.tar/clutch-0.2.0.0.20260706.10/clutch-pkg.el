;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.2.0.0.20260706.10"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "357494b049d3acedaa96e12de438b9990cdcbc2c"
  :revdesc "v0.2.0-10-g357494b049d3"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
