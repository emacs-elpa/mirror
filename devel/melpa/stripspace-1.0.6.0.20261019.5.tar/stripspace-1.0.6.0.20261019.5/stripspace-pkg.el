;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "1.0.6.0.20261019.5"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "d0e897fb7b65ed4b6664d48136ff8f4acb30f1e7"
  :revdesc "1.0.6-5-gd0e897fb7b65"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
