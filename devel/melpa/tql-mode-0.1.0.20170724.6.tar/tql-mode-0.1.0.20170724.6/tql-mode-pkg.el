;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tql-mode" "0.1.0.20170724.6"
  "TQL mode."
  '((emacs "24"))
  :url "https://github.com/tiros-dev/tql-mode"
  :commit "488add79eb3fc8ec02aedaa997fe1ed9e5c3e638"
  :revdesc "488add79eb3f"
  :keywords '("languages" "tql")
  :authors '(("Sean McLaughlin" . "seanmcl@gmail.com"))
  :maintainers '(("Sean McLaughlin" . "seanmcl@gmail.com")))
