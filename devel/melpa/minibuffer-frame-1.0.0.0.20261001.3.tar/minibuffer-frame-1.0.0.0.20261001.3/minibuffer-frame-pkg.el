;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minibuffer-frame" "1.0.0.0.20261001.3"
  "Minibuffer in centered child frame."
  '((emacs "28.1"))
  :url "https://github.com/zHaOdANiuu/minibuffer-frame"
  :commit "48d84b60773d194d3f896844f52c6cce7c325971"
  :revdesc "48d84b60773d"
  :keywords '("convenience" "minibuffer" "child-frame")
  :authors '(("zhaodaniu" . "zhaodaniu1@gmail.com"))
  :maintainers '(("zhaodaniu" . "zhaodaniu1@gmail.com")))
