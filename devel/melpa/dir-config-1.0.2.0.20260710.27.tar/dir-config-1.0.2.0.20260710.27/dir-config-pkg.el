;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-config" "1.0.2.0.20260710.27"
  "Find and evaluate .dir-config.el (dir-locals alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/dir-config.el"
  :commit "5620beabc842f5d63c02c90d28618d5c67fdf94e"
  :revdesc "1.0.2-27-g5620beabc842"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
