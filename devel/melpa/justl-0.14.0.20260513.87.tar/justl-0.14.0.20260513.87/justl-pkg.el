;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "justl" "0.14.0.20260513.87"
  "Major mode for driving just files."
  '((transient  "0.1.0")
    (emacs      "27.1")
    (s          "1.2.0")
    (f          "0.20.0")
    (inheritenv "0.2"))
  :url "https://github.com/psibi/justl.el"
  :commit "2b6e5f8d2d16e7c535553dcb9c496f8bd1bb827e"
  :revdesc "v0.14-87-g2b6e5f8d2d16"
  :keywords '("just" "justfile" "tools" "processes"))
