;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haxe-imports" "0.1.0.0.20170330.10"
  "Code for dealing with Haxe imports."
  '((emacs  "24.4")
    (s      "1.10.0")
    (pcache "0.3.1"))
  :url "http://www.github.com/accidentalrebel/emacs-haxe-imports"
  :commit "a4ab31759bd237e78c055dda73e808a4ee1b5fde"
  :revdesc "a4ab31759bd2"
  :keywords '("haxe")
  :authors '(("Juan Karlo Licudine" . "karlo@accidentalrebel.com"))
  :maintainers '(("Juan Karlo Licudine" . "karlo@accidentalrebel.com")))
