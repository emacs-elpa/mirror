;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "1.6.9.0.20260705.40"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "9e9b97ad9c1b927e462cd012a27351f8d595baa8"
  :revdesc "9e9b97ad9c1b"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
