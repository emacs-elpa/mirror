;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-lobsters" "0.8.0"
  "Helm front-end for lobste.rs."
  '((helm   "1.0")
    (cl-lib "0.5"))
  :url "https://github.com/julienXX/helm-lobste.rs"
  :commit "3a1af0d063ca24fe0187daff12110171b942c7d3"
  :revdesc "0.8.0-0-g3a1af0d063ca"
  :authors '(("Julien BLANCHARD" . "julien@sideburns.eu"))
  :maintainers '(("Julien BLANCHARD" . "julien@sideburns.eu")))
