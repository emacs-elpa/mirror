;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dart-server" "0.1.0.0.20210501.13"
  "Minor mode for editing Dart files."
  '((emacs    "24.5")
    (cl-lib   "0.5")
    (dash     "2.10.0")
    (flycheck "0.23")
    (s        "1.10"))
  :url "https://github.com/bradyt/dart-server"
  :commit "75562baf9a89b7e314bc2f795f6ecdc5d1f2cc8c"
  :revdesc "75562baf9a89"
  :keywords '("languages")
  :authors '(("Brady Trainor" . "mail@bradyt.com"))
  :maintainers '(("Brady Trainor" . "mail@bradyt.com")))
