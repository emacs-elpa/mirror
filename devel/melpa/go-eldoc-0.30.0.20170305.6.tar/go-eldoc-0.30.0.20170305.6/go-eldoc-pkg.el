;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-eldoc" "0.30.0.20170305.6"
  "Eldoc for go-mode."
  '((emacs   "24.3")
    (go-mode "1.0.0"))
  :url "https://github.com/syohex/emacs-go-eldoc"
  :commit "cbbd2ea1e94a36004432a9ac61414cb5a95a39bd"
  :revdesc "cbbd2ea1e94a"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
