;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emoji-recall" "0.1.0.20160723.8"
  "How many emoji can you recall from memory?."
  '((emacs "24"))
  :url "https://github.com/lujun9972/emoji-recall.el"
  :commit "1c12d18e5592eaa2138dd3034012dced277e6d99"
  :revdesc "1c12d18e5592"
  :keywords '("game")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
