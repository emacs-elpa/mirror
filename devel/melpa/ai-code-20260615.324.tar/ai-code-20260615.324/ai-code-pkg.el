;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260615.324"
  "Unified interface for AI coding backends."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "b650a43b594bb4d2658de08684be37dd0b599c7a"
  :revdesc "b650a43b594b"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
