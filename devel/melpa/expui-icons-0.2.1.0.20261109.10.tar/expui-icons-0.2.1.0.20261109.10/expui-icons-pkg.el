;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "expui-icons" "0.2.1.0.20261109.10"
  "Icons from IntelliJ's New UI."
  '((emacs "29.1"))
  :url "https://github.com/wwulfric/expui-icons"
  :commit "7fb14e8e34e8517f43e8ee6a2335af89093dac99"
  :revdesc "v0.2.1-10-g7fb14e8e34e8"
  :keywords '("convenience" "files")
  :authors '(("Lufei Wang" . "wwulfric@gmail.com"))
  :maintainers '(("Lufei Wang" . "wwulfric@gmail.com")))
