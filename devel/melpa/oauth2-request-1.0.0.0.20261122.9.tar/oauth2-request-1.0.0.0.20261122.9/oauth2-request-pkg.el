;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oauth2-request" "1.0.0.0.20261122.9"
  "OAuth2 request package interface."
  '((emacs   "27.1")
    (oauth2  "0.18.4")
    (request "0.3.3"))
  :url "https://github.com/conao3/oauth2-request.el"
  :commit "9b9598534e8ec4264602bc92da15b0adfb01d6e0"
  :revdesc "9b9598534e8e"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
