;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xref-rst" "0.1.0.20261026.35"
  "Lookup reStructuredText symbols."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-xref-rst"
  :commit "41aa52e73d339141eee88b1cb9dfbdaacf7b28c8"
  :revdesc "41aa52e73d33"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
