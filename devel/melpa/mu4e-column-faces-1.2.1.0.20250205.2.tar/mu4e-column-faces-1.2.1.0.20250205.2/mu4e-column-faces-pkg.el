;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-column-faces" "1.2.1.0.20250205.2"
  "Faces for individual mu4e columns."
  '((emacs "25.3"))
  :url "https://github.com/Alexander-Miller/mu4e-column-faces"
  :commit "b3586a9bf61f0cddd8a9f4cb214458f13d37955a"
  :revdesc "b3586a9bf61f"
  :authors '(("Alexander Miller" . "alexanderm@web.de"))
  :maintainers '(("Alexander Miller" . "alexanderm@web.de")))
