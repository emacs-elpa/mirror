;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-rails" "0.1.0.20190512.20"
  "Rails support for Evil Mode."
  '((evil             "1.0")
    (projectile-rails "1.0"))
  :url "https://github.com/antono/evil-rails"
  :commit "b0f1c5de6720714febeb76c4b569b71bb891938c"
  :revdesc "b0f1c5de6720"
  :keywords '("ruby" "rails" "vim" "project" "convenience" "web" "evil" "projectile")
  :authors '(("Antono Vasiljev" . "antono.vasiljev@gmail.com"))
  :maintainers '(("Antono Vasiljev" . "antono.vasiljev@gmail.com")))
