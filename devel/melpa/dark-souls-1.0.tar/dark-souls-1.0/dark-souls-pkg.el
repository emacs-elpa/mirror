;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dark-souls" "1.0"
  "Prepare to die."
  ()
  :url "https://github.com/tomjakubowski/dark-souls.el"
  :commit "2c9437265b52f966b2fb13a410a12f3b1e167cb7"
  :revdesc "2c9437265b52"
  :keywords '("games")
  :authors '(("Tom Jakubowski" . "tom@crystae.net"))
  :maintainers '(("Tom Jakubowski" . "tom@crystae.net")))
