;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solarized-theme" "2.2.0.0.20261101.8"
  "The Solarized color theme."
  '((emacs "24.1"))
  :url "https://github.com/bbatsov/solarized-emacs"
  :commit "a9e645ee32322b3b86ac0ae85f36a993ddcc9510"
  :revdesc "a9e645ee3232"
  :keywords '("convenience" "themes" "solarized")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
