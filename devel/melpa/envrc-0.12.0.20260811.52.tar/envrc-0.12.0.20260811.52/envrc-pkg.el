;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "0.12.0.20260811.52"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1")
    (seq        "2.24"))
  :url "https://github.com/purcell/envrc"
  :commit "e4f9fd79a612c8f81b4ba5b12ee7261fc33568f0"
  :revdesc "e4f9fd79a612"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
