;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-init-viewer" "0.1.0.0.20150303.6"
  "Record viewer for el-init."
  '((emacs    "24")
    (cl-lib   "0.5")
    (ctable   "0.1.2")
    (dash     "2.10.0")
    (anaphora "1.0.0")
    (el-init  "0.1.4"))
  :url "https://github.com/HKey/el-init-viewer"
  :commit "c40417db7808c8b8c9b2f196a69de5da7eee84a2"
  :revdesc "c40417db7808"
  :authors '(("Hiroki YAMAKAWA" . "s06139@gmail.com"))
  :maintainers '(("Hiroki YAMAKAWA" . "s06139@gmail.com")))
