;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bfbuilder" "1.0.1.0.20210228.4"
  "A brainfuck development environment with interactive debugger."
  '((cl-lib "0.3")
    (emacs  "24.4"))
  :url "http://zk-phi.gitub.io/"
  :commit "689f320a9a1326cdeff43b8538e0d739f8519c4b"
  :revdesc "689f320a9a13")
