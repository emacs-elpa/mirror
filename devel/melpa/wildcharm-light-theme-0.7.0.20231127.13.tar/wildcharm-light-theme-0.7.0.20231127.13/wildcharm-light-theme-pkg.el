;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wildcharm-light-theme" "0.7.0.20231127.13"
  "Port of vim-wildcharm (light) colorscheme."
  '((emacs "24.1"))
  :url "https://github.com/habamax/wildcharm-theme"
  :commit "58662e13c179106ea7780e71bd3ef3c1cf74e929"
  :revdesc "58662e13c179"
  :authors '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers '(("Maxim Kim" . "habamax@gmail.com")))
