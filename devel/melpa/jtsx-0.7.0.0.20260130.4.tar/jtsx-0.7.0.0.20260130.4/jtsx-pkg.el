;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jtsx" "0.7.0.0.20260130.4"
  "Extends JSX/TSX built-in support."
  '((emacs "29.1"))
  :url "https://github.com/llemaitre19/jtsx"
  :commit "f33efef5052b0757287abbea2b877cefca663bf2"
  :revdesc "f33efef5052b"
  :keywords '("languages")
  :authors '(("Loïc Lemaître" . "loic.lemaitre@gmail.com"))
  :maintainers '(("Loïc Lemaître" . "loic.lemaitre@gmail.com")))
