;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260524.1200"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.30.2")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "84bd47f9aee37e07e8601261ccbec0dd0767be0b"
  :revdesc "84bd47f9aee3"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
