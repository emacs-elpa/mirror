;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-clojuredocs" "0.1.0.20201129.15"
  "Search for help in clojuredocs.org."
  '((edn   "1.1.2")
    (ivy   "0.12.0")
    (emacs "24.4"))
  :url "https://github.com/wandersoncferreira/ivy-clojuredocs"
  :commit "8b6de19b3578c72d2b88f898e2290d94c04350f9"
  :revdesc "8b6de19b3578"
  :keywords '("matching")
  :authors '(("Wanderson Ferreira" . "iagwanderson@gmail.com"))
  :maintainers '(("Wanderson Ferreira" . "iagwanderson@gmail.com")))
