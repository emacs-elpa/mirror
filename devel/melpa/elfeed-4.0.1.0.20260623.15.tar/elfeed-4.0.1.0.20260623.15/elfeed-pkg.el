;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.0.1.0.20260623.15"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "2c4f03158a3bf410d95c57851de284a1f88537ca"
  :revdesc "4.0.1-15-g2c4f03158a3b"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
