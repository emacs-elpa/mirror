;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitconfig" "1.0.0"
  "Emacs lisp interface to work with git-config variables."
  ()
  :url "https://github.com/tonini/gitconfig.el"
  :commit "6c313a39e20702ddcebc12d146f69db1ce668901"
  :revdesc "6c313a39e207"
  :keywords '("git" "gitconfig" "git-config"))
