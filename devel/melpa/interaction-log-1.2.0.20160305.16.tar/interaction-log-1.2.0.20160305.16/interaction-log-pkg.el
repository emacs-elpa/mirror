;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "interaction-log" "1.2.0.20160305.16"
  "Exhaustive log of interactions with Emacs."
  '((cl-lib "0"))
  :url "https://github.com/michael-heerdegen/interaction-log.el"
  :commit "0f2d773269d1f7b93c9281226719113f5410cbd0"
  :revdesc "0f2d773269d1"
  :keywords '("convenience")
  :authors '(("Michael Heerdegen" . "michael_heerdegen@web.de"))
  :maintainers '(("Michael Heerdegen" . "michael_heerdegen@web.de")))
