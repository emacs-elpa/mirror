;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-visualstar" "0.2.0.0.20260927.8"
  "Starts a * or # search from the visual selection."
  '((emacs "24.4")
    (evil  "0"))
  :url "https://github.com/bling/evil-visualstar"
  :commit "2b804e317700896116e88ae751df4a36ac8c3934"
  :revdesc "2b804e317700"
  :keywords '("evil" "vim" "visualstar")
  :maintainers '(("Bailey Ling" . "bling@live.ca")))
