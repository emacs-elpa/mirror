;;; markdown-ts-appear.el --- Reveal Markdown source at point -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Thysrael

;; Author: Thysrael <thysrael@163.com>
;; Assisted-by: OpenCode:gpt-5.6-sol
;; Maintainer: Thysrael <thysrael@163.com>
;; Package-Version: 0.4.1.0.20261127.9
;; Package-Revision: v0.4.1-9-g2e8fc1c80ba5
;; Package-Requires: ((emacs "31.1"))
;; Keywords: text, convenience
;; URL: https://github.com/Thysrael/markdown-ts-appear

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; `markdown-ts-appear-mode' hides rendered Markdown markup and reveals the
;; smallest semantic element at point, with optional visual decorations.
;;
;; Enable it with:
;;
;;   (add-hook 'markdown-ts-mode-hook #'markdown-ts-appear-mode)

;;; Code:

(require 'markdown-ts-appear-compat)
(require 'color)
(require 'outline)
(require 'seq)
(require 'subr-x)
(require 'markdown-ts-appear-image)
(require 'markdown-ts-appear-math)
(require 'markdown-ts-appear-diagram)

;;; Options and faces

(defgroup markdown-ts-appear nil
  "Reveal rendered Markdown source at point."
  :group 'markdown-ts)

(defcustom markdown-ts-appear-auto-start t
  "Start source tracking when `markdown-ts-appear-mode' is enabled.
Set nil before enabling the mode to let modal editing hooks call
`markdown-ts-appear-start' and `markdown-ts-appear-stop' instead."
  :type 'boolean)

(defcustom markdown-ts-appear-block-reveal 'automatic
  "How wrapped tables and diagram previews enter source editing.
With `automatic', source follows point as usual.  With `explicit', keep
these blocks rendered until RET, an edit, or Evil insert state opens the
source.  Tables use `markdown-ts-appear-table-reveal' to choose a row or
the whole table; diagrams open in full.  Leaving the revealed region or
stopping tracking restores rendering.
Other Markdown elements still follow point."
  :type '(choice (const :tag "Follow point" automatic)
                 (const :tag "Explicit block editing" explicit))
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(defcustom markdown-ts-appear-enable-math-preview nil
  "Whether to enable the selected optional math renderer.
See `markdown-ts-appear-math-renderer'.  An independently enabled math mode
also follows appear's reveal policy.
Re-enable `markdown-ts-appear-mode' after changing this option."
  :type 'boolean)

(defcustom markdown-ts-appear-math-renderer 'auto
  "Renderer enabled for optional math previews.
`auto' prefers MathJax when its package and Node.js are available,
otherwise uses latex-to-svg.
`mathjax' uses the independent MathJax extension and Node.js, without TeX
or latex-to-svg.  `latex-to-svg' uses its Markdown adaptor and its engine
options (LaTeX, RaTeX or texres).  An already enabled math mode is adopted
when appear starts.  Set with Customize or `setopt' to switch active buffers
to the selected renderer."
  :type '(choice (const :tag "Automatic (prefer MathJax)" auto)
                 (const :tag "Independent MathJax" mathjax)
                 (const :tag "latex-to-svg adaptor" latex-to-svg))
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(defcustom markdown-ts-appear-diagram-renderers nil
  "Alist mapping fenced-block language names to SVG rendering functions.
Registering a language enables its previews.  Names are case-insensitive.
Each function receives LANGUAGE, CODE, THEME and CALLBACK.  THEME is
\"dark\" or \"default\".  Call CALLBACK once with SVG text, or nil and an
error message; the callback may run synchronously or asynchronously.
A renderer may return a zero-argument cancellation function.  Late results
from retired jobs are ignored.  Renderers should provide Emacs-compatible
SVG without HTML foreignObject labels or costly shadow filters.
Use `markdown-ts-appear-diagram-mmdc' to render Mermaid with its CLI."
  :type '(alist :key-type string :value-type function)
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(defcustom markdown-ts-appear-diagram-size 'source
  "How to size diagram previews, preserving aspect ratio without enlarging.
The default `source' limits height to the code block's displayed height
and width to `markdown-ts-image-max-width'.
A positive integer limits only the width, in pixels."
  :type '(choice (const :tag "Fit source height" source)
                 (integer :tag "Maximum width in pixels"))
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(defcustom markdown-ts-appear-heading-bullets nil
  "Symbols replacing the leading hashes of rendered ATX headings.
Each entry is a string or character, followed by a space when displayed.
Entries cycle through heading levels one to six.  Nil keeps the normal
heading rendering.  Empty headings and headings being edited keep their
source markers."
  :type '(repeat (choice (string :tag "String") (character :tag "Character")))
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(defcustom markdown-ts-appear-link-icon ""
  "Icon displayed before rendered Markdown links.
An empty string disables the icon."
  :type 'string
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(defcustom markdown-ts-appear-image-icon ""
  "Icon displayed before rendered Markdown images.
An empty string disables the icon."
  :type 'string
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(defcustom markdown-ts-appear-wikilink-icon "◆"
  "Icon displayed before rendered Markdown Wiki links.
An empty string disables the icon."
  :type 'string
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(defcustom markdown-ts-appear-code-fence-style 'connected
  "How rendered fenced code blocks should display their delimiters."
  :type '(choice (const :tag "Raw Markdown" raw)
                 (const :tag "Connected Unicode lines" connected))
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(defcustom markdown-ts-appear-render-callouts t
  "Whether to render callout labels and softly tinted header backgrounds."
  :type 'boolean
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(defcustom markdown-ts-appear-block-quote-marker "▎"
  "Marker replacing each marker of a rendered block quote.
When nil, preserve the original Markdown marker."
  :type '(choice (const :tag "Display raw marker" nil)
                 (string :tag "Marker"))
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(defcustom markdown-ts-appear-table-style 'wrapped
  "How rendered Markdown pipe tables should display.
The `wrapped' style fits cells to the window without changing buffer text."
  :type '(choice (const :tag "Raw Markdown" raw)
                 (const :tag "Unicode delimiters" unicode)
                 (const :tag "Wrapped Unicode table" wrapped))
  :initialize #'custom-initialize-default
  :set #'markdown-ts-appear--set-render-option)

(require 'markdown-ts-appear-table)

(defface markdown-ts-appear-code-fence-marker
  '((t :inherit (markdown-ts-language-keyword markdown-ts-code-block)))
  "Face used for rendered fenced code block markers.")

(defface markdown-ts-appear-label
  '((t :inverse-video t))
  "Face used to invert rendered code language and callout labels.")

(defface markdown-ts-appear-block-quote-marker
  '((t :inherit font-lock-comment-face))
  "Face used for rendered block quote markers.")

(defvar-local markdown-ts-appear-mode nil
  "Non-nil when Markdown TS Appear mode is enabled.")

(defvar-local markdown-ts-appear--region nil
  "Markers delimiting the semantic Markdown source currently visible.")

(defvar-local markdown-ts-appear--explicit-region nil
  "Markers delimiting a block explicitly opened for source editing.")

(defvar-local markdown-ts-appear--last-point nil
  "Buffer position checked by the most recent reveal update.")

(defvar-local markdown-ts-appear--last-tick nil
  "Buffer modification tick checked by the most recent reveal update.")

(defvar-local markdown-ts-appear--last-range-line nil
  "Line beginning whose inline Tree-sitter ranges were last updated.")

(defvar-local markdown-ts-appear--tracking-change-hook nil
  "Functions run when source tracking starts or stops.")

(defvar-local markdown-ts-appear--syntax-change-functions nil
  "Functions notified of changed block syntax, with arguments BEG and END.")

(defvar-local markdown-ts-appear--managed-properties nil
  "Properties added by reveal mode to `font-lock-extra-managed-props'.")

(defvar-local markdown-ts-appear--block-font-lock-settings nil
  "Tree-sitter font-lock settings installed in the current buffer.")

(defvar markdown-ts-appear--tearing-down-buffer-p nil
  "Non-nil while cleanup is running for a buffer being discarded.")

(defvar markdown-ts-appear--quote-font-lock-settings)
(defvar markdown-ts-appear--code-font-lock-settings)

(defvar markdown-ts-appear--callout-backgrounds nil
  "Cached callout backgrounds, keyed by accent face and its current colors.")

(defvar markdown-ts-appear--quote-prefix-query nil
  "Compiled quote marker query.")

(defun markdown-ts-appear--active-p ()
  "Return non-nil when reveal rendering owns this buffer's text."
  (and markdown-ts-appear-mode
       (memq #'markdown-ts-appear--after-change after-change-functions)))

(defun markdown-ts-appear--tracking-p ()
  "Return non-nil while source reveal follows point in this buffer."
  (memq #'markdown-ts-appear--update post-command-hook))

(defun markdown-ts-appear--deactivate-mode ()
  "Clear Markdown TS Appear mode and unregister it locally."
  (setq markdown-ts-appear-mode nil
        local-minor-modes (delq 'markdown-ts-appear-mode local-minor-modes)))

(defun markdown-ts-appear--decorate (beg end string face)
  "Display STRING with FACE instead of text between BEG and END."
  (let ((display (copy-sequence string)))
    (when face
      (add-face-text-property 0 (length display) face t display))
    (with-silent-modifications
      (put-text-property beg end 'display display)
      (put-text-property beg end 'markdown-ts-appear--decoration t))))

(defun markdown-ts-appear--original-prefix (prefix)
  "Return PREFIX without the decoration installed by this mode."
  (if-let* (((stringp prefix))
            ((> (length prefix) 0))
            (original (get-text-property 0 'markdown-ts-appear--prefix prefix)))
      (car original)
    prefix))

(defun markdown-ts-appear--clear-prefixes (beg end)
  "Restore external prefixes between BEG and END before unfontification."
  (with-silent-modifications
    (dolist (property '(line-prefix wrap-prefix))
      (let ((pos beg))
        (while (< pos end)
          (let* ((next (next-single-property-change pos property nil end))
                 (prefix (get-text-property pos property))
                 (original (markdown-ts-appear--original-prefix prefix)))
            (unless (eq prefix original)
              (put-text-property pos next property original))
            (setq pos next)))))))

(defun markdown-ts-appear--decorate-prefix
    (beg end property display &optional base-property)
  "Append DISPLAY to external PROPERTY prefixes between BEG and END.
Use BASE-PROPERTY for the external indentation when non-nil.  Quoted code
uses `line-prefix' so its rendered quote markers replace the raw wrap suffix."
  (let ((pos beg)
        (base-property (or base-property property)))
    (with-silent-modifications
      (while (< pos end)
        (let* ((next (min (next-single-property-change pos property nil end)
                          (next-single-property-change pos base-property nil end)))
               (original (markdown-ts-appear--original-prefix
                          (get-text-property pos property)))
               (base (or (markdown-ts-appear--original-prefix
                          (get-text-property pos base-property))
                         (symbol-value base-property)))
               (prefix (concat (cond ((null base) "")
                                     ((stringp base) base)
                                     (t (propertize " " 'display base)))
                               display)))
          ;; Keep ownership on the installed value: an external replacement
          ;; must not be overwritten with our saved, now stale, prefix.
          (put-text-property 0 (length prefix) 'markdown-ts-appear--prefix
                             (list original) prefix)
          (add-text-properties
           pos next (list property prefix 'markdown-ts-appear--decoration t))
          (setq pos next))))))

(defun markdown-ts-appear--remove-markup-invisibility (beg end)
  "Remove Markdown markup invisibility between BEG and END."
  (let ((pos beg))
    (while (< pos end)
      (let ((next (next-single-property-change pos 'invisible nil end)))
        (when (eq (get-text-property pos 'invisible) markdown-ts-appear--markup-invisibility)
          (remove-text-properties pos next '(invisible nil)))
        (setq pos next)))))

(defun markdown-ts-appear--label (text face)
  "Render TEXT as a padded inverse-video label over FACE."
  (propertize (concat " " text " ")
              'face (list 'markdown-ts-appear-label face)))

(defun markdown-ts-appear--code-block-face (hide-markup)
  "Return the face of code block content, with HIDE-MARKUP as hiding state."
  (if hide-markup
      'markdown-ts-code-block-markup-hidden
    'markdown-ts-code-block))

(defun markdown-ts-appear--code-quote-prefix (source block-face)
  "Render quoted code prefix SOURCE followed by a code block marker.
Append BLOCK-FACE, so the prefix shares the background of the block."
  (let* ((marker (or markdown-ts-appear-block-quote-marker ">"))
         (prefix
          (concat
           (mapconcat
            (lambda (character)
              (if (eq character ?>)
                  (propertize
                   marker 'face '(markdown-ts-appear-block-quote-marker
                                  markdown-ts-appear-code-fence-marker))
                (propertize
                 (string character) 'face 'markdown-ts-appear-code-fence-marker)))
            source)
           (propertize "│ " 'face 'markdown-ts-appear-code-fence-marker))))
    (add-face-text-property 0 (length prefix) block-face t prefix)
    prefix))

;;; Source bounds and point tracking

(defun markdown-ts-appear--node-ancestor (node type)
  "Return NODE or its nearest ancestor whose type is TYPE."
  (treesit-parent-until
   node (lambda (candidate) (equal (treesit-node-type candidate) type)) t))

(defun markdown-ts-appear--direct-children-of-type (node type)
  "Return direct children of NODE whose type is TYPE."
  (treesit-filter-child
   node (lambda (child) (equal (treesit-node-type child) type))))

(defun markdown-ts-appear--first-direct-child-of-type (node type)
  "Return the first direct child of NODE whose type is TYPE."
  (catch 'child
    (dotimes (index (treesit-node-child-count node))
      (let ((child (treesit-node-child node index)))
        (when (equal (treesit-node-type child) type)
          (throw 'child child))))))

(defun markdown-ts-appear--region-visible-p (beg end)
  "Return non-nil when BEG through END overlaps visible Markdown source."
  (when-let* ((region markdown-ts-appear--region)
              (visible-beg (marker-position (car region)))
              (visible-end (marker-position (cdr region))))
    (and (< beg visible-end) (> end visible-beg))))

(defun markdown-ts-appear--node-visible-p (node)
  "Return non-nil when NODE overlaps visible semantic Markdown source."
  (let ((beg (treesit-node-start node)) (end (treesit-node-end node)))
    (or (markdown-ts-appear--region-visible-p beg end)
        (markdown-ts-appear-math--contains-p beg end))))

(defun markdown-ts-appear--literal-block-at (position &optional node)
  "Return the literal Markdown block containing POSITION, if any.
NODE is the block parser node already found at POSITION, when available."
  (when-let* ((block
               (treesit-parent-until
                (or node (treesit-node-at position 'markdown))
                "\\`\\(?:fenced_code_block\\|indented_code_block\\|html_block\\)\\'"
                t))
              ((<= (treesit-node-start block) position))
              ((< position (treesit-node-end block))))
    block))

(defun markdown-ts-appear--wikilink-bounds-for-node (node)
  "Return Wiki link bounds around shortcut link NODE, if any."
  (when-let* ((node)
              ((equal (treesit-node-type node) "shortcut_link"))
              (previous (treesit-node-prev-sibling node))
              (next (treesit-node-next-sibling node))
              ((equal (treesit-node-type previous) "["))
              ((equal (treesit-node-type next) "]"))
              ((= (treesit-node-end previous) (treesit-node-start node)))
              ((= (treesit-node-start next) (treesit-node-end node)))
              ((not (markdown-ts-appear--node-ancestor
                     (treesit-node-parent node) "image"))))
    (cons (treesit-node-start previous) (treesit-node-end next))))

(defun markdown-ts-appear--wikilink-bounds-at (position inline)
  "Return Wiki link bounds at POSITION, starting from INLINE's ancestors."
  ;; The grammar leaves the extra outer brackets outside the shortcut link.
  (let* ((adjacent (pcase (char-after position)
                     (?\[ (1+ position))
                     (?\] (and (> position (point-min)) (1- position)))))
         (nodes (if adjacent
                    (list inline (treesit-node-at adjacent 'markdown-inline))
                  (list inline)))
         bounds)
    (while (and nodes (not bounds))
      (let ((node (pop nodes)))
        (while (and node (not bounds))
          (setq bounds (markdown-ts-appear--wikilink-bounds-for-node node)
                node (treesit-node-parent node)))))
    (when (and bounds
               (<= (car bounds) position)
               (< position (cdr bounds)))
      bounds)))

(defun markdown-ts-appear--restore (&optional defer)
  "Restore hidden markup in the previously revealed region.
When DEFER is non-nil, let redisplay fontify the region after a text edit."
  (when-let* ((region markdown-ts-appear--region))
    (let ((beg (marker-position (car region)))
          (end (marker-position (cdr region))))
      (set-marker (car region) nil)
      (set-marker (cdr region) nil)
      (setq markdown-ts-appear--region nil)
      (when (and beg end (not markdown-ts-appear--tearing-down-buffer-p))
        (without-restriction
          (font-lock-flush beg end)
          (unless defer
            (condition-case nil
                (font-lock-ensure beg end)
              (treesit-parser-deleted nil))))))))

(defun markdown-ts-appear--bounds-at-point (pos &optional block)
  "Return source bounds for the smallest rendered element at POS.
BLOCK is the Markdown node already found at POS, when available."
  (save-excursion
    (goto-char pos)
    (let* ((line-beg (line-beginning-position))
           (line-end (line-end-position))
           (inline (treesit-node-at pos 'markdown-inline))
           (wikilink-bounds (markdown-ts-appear--wikilink-bounds-at pos inline))
           (contains-p
            (lambda (node)
              (let ((beg (treesit-node-start node))
                    (end (treesit-node-end node)))
                (and (<= beg pos)
                     (or (< pos end)
                         (and (= pos end) (> pos beg)
                              (not (eq (char-before pos) ?\n))
                              (or (>= pos (point-max))
                                  (memq (char-after pos)
                                        '(?\s ?\t ?\n ?\r)))))))))
           (inline-node
            (treesit-parent-until
             inline
             (lambda (node)
               (let ((type (treesit-node-type node)))
                 (and
                  (funcall contains-p node)
                  (member type
                          '("emphasis" "strong_emphasis" "strikethrough"
                            "code_span" "inline_link" "full_reference_link"
                            "collapsed_reference_link" "shortcut_link"
                            "image" "uri_autolink" "email_autolink"
                            "entity_reference" "numeric_character_reference"
                            "backslash_escape" "hard_line_break"
                            "latex_block"))
                  (not (and (equal type "shortcut_link")
                            (markdown-ts-appear--node-ancestor
                             (treesit-node-parent node) "image")))
                  (or (not (equal type "latex_block"))
                      (markdown-ts-appear--native-latex-valid-p node)))))
             t)))
      (cond
       (wikilink-bounds)
       (inline-node
        ;; The inline grammar represents `~~text~~' as nested strikethroughs.
        (when (equal (treesit-node-type inline-node) "strikethrough")
          (setq inline-node
                (treesit-parent-while inline-node "\\`strikethrough\\'")))
        (cons (treesit-node-start inline-node)
              (treesit-node-end inline-node)))
       (t
        (let ((structural-node
               (treesit-parent-until
                (or block (treesit-node-at pos 'markdown))
                (lambda (node)
                  (and
                   (funcall contains-p node)
                   (member
                    (treesit-node-type node)
                    '("atx_heading" "setext_heading" "list_item"
                      "task_list_marker_unchecked"
                      "task_list_marker_checked"
                      "pipe_table_header" "pipe_table_row"
                      "pipe_table_delimiter_row" "thematic_break"
                      "link_reference_definition"))))
                t)))
          (pcase (and structural-node (treesit-node-type structural-node))
            ("atx_heading"
             (when-let* ((marker
                          (treesit-node-child structural-node 0 'named)))
               (cons (treesit-node-start marker)
                     (save-excursion
                       (goto-char (treesit-node-end marker))
                       (skip-chars-forward " \t" line-end)
                       (point)))))
            ("setext_heading"
             (when-let* ((underline
                          (treesit-search-subtree
                           structural-node "\\`setext_h[12]_underline\\'")))
               (cons (save-excursion
                       (goto-char (treesit-node-start underline))
                       (skip-chars-backward " \t\n")
                       (point))
                     (treesit-node-end underline))))
            ("list_item"
             (when-let* ((marker
                          (treesit-node-child structural-node 0 'named))
                         ((string-prefix-p
                           "list_marker_" (treesit-node-type marker)))
                         ((= line-beg
                             (save-excursion
                               (goto-char (treesit-node-start marker))
                               (line-beginning-position)))))
               (cons (treesit-node-start marker)
                     (treesit-node-end marker))))
            ((or "task_list_marker_unchecked" "task_list_marker_checked"
                 "pipe_table_header" "pipe_table_row"
                 "pipe_table_delimiter_row" "thematic_break"
                 "link_reference_definition")
             (cons (treesit-node-start structural-node)
                   (treesit-node-end structural-node))))))))))

(defun markdown-ts-appear--markdown-node-at (position)
  "Return the Markdown node at POSITION, including at node boundaries."
  (or (treesit-node-at position 'markdown)
      (and (> position (point-min))
           (treesit-node-at (1- position) 'markdown))))

(defun markdown-ts-appear--fence-bounds-at (position node)
  "Return fenced delimiter bounds at POSITION, starting from NODE."
  (when-let* ((block (markdown-ts-appear--node-ancestor
                      node "fenced_code_block"))
              (delimiters
               (markdown-ts-appear--direct-children-of-type
                block "fenced_code_block_delimiter")))
    (let* ((opening (car delimiters))
           (closing (car (last delimiters)))
           (info (markdown-ts-appear--first-direct-child-of-type
                  block "info_string"))
           (opening-end (if info (treesit-node-end info)
                          (treesit-node-end opening))))
      (cond
       ((and (<= (treesit-node-start opening) position)
             (<= position opening-end))
        (cons (treesit-node-start opening) opening-end))
       ((and (<= (treesit-node-start closing) position)
             (<= position (treesit-node-end closing)))
        (cons (treesit-node-start closing) (treesit-node-end closing)))))))

(defun markdown-ts-appear--quote-marker-bounds-at (position node)
  "Return block quote marker bounds at POSITION, starting from NODE."
  (let ((nodes (delq nil
                     (list node
                           (and (> position (point-min))
                                (treesit-node-at
                                 (1- position) 'markdown)))))
        marker)
    (while (and nodes (not marker))
      (setq marker
            (treesit-parent-until
             (pop nodes)
             (lambda (node)
               (and (member (treesit-node-type node)
                            '("block_quote_marker" "block_continuation"))
                    (<= (treesit-node-start node) position)
                    (<= position (treesit-node-end node))
                    (string-search ">" (treesit-node-text node t))))
             t)))
    (when marker
      (cons (treesit-node-start marker) (treesit-node-end marker)))))

(defun markdown-ts-appear--callout-data (quote)
  "Return (BEG END TYPE) for a callout marker starting block QUOTE."
  (save-match-data
    (when-let* ((opening
                 (markdown-ts-appear--first-direct-child-of-type
                  quote "block_quote_marker"))
                (beg (treesit-node-end opening)))
      (save-excursion
        (goto-char beg)
        (when (re-search-forward
               "\\=\\[!\\([[:alnum:]_-]+\\)\\]\\([+-]\\)?"
               (line-end-position) t)
          (list beg (point) (match-string-no-properties 1)))))))

(defun markdown-ts-appear--callout-bounds-at (position node)
  "Return callout bounds at POSITION, starting from NODE."
  (when-let* ((markdown-ts-appear-render-callouts)
              (quote (markdown-ts-appear--node-ancestor node "block_quote"))
              (data (markdown-ts-appear--callout-data quote))
              (beg (nth 0 data))
              (end (nth 1 data))
              ((<= beg position))
              ((< position end)))
    (cons beg end)))

(defun markdown-ts-appear--callout-link-p (link)
  "Return non-nil when shortcut LINK is a rendered callout marker."
  (when-let* ((markdown-ts-appear-render-callouts)
              ((equal (treesit-node-type link) "shortcut_link"))
              (markdown-node
               (markdown-ts-appear--markdown-node-at
                (treesit-node-start link)))
              (quote
               (markdown-ts-appear--node-ancestor markdown-node "block_quote"))
              (data (markdown-ts-appear--callout-data quote))
              (beg (nth 0 data))
              (end (nth 1 data))
              (label-end
               (if (memq (char-before end) '(?+ ?-)) (1- end) end)))
    (and (= (treesit-node-start link) beg)
         (= (treesit-node-end link) label-end))))

(defun markdown-ts-appear--image-preview-bounds-at (position)
  "Return image source bounds when POSITION follows a native preview anchor."
  ;; Clicking an image in an after-string places point just past its link.
  (when (and markdown-ts-inline-images (> position (point-min)))
    (when-let* ((preview
                 (seq-find (lambda (overlay)
                             (and (overlay-get overlay 'markdown-ts-image)
                                  (= (overlay-end overlay) position)))
                           (overlays-at (1- position))))
                (image (markdown-ts-appear--node-ancestor
                        (treesit-node-at (overlay-start preview) 'markdown-inline)
                        "image")))
      (cons (treesit-node-start image) (treesit-node-end image)))))

(defun markdown-ts-appear--block-at-point (&optional position node)
  "Return source bounds to open at POSITION, defaulting to point.
Tables follow `markdown-ts-appear-table-reveal'; diagrams open in full.
NODE is the Markdown node at POSITION, when already available."
  (let* ((position (or position (point)))
         (node (and (eq markdown-ts-appear-table-style 'wrapped)
                    (or node (markdown-ts-appear--markdown-node-at position))))
         (table (markdown-ts-appear--node-ancestor node "pipe_table")))
    (if table
        (when-let* ((block (if (eq markdown-ts-appear-table-reveal 'table)
                              table
                            ;; Row nodes end before the newline.  At the last
                            ;; row's EOL, NODE can be the table itself.
                            (treesit-node-first-child-for-pos
                             table (max (treesit-node-start table) (1- position)))))
                    (beg (treesit-node-start block))
                    (end (treesit-node-end block)))
          (when (and (<= beg position)
                     (or (< position end)
                         (and (= position end)
                              (not (eq (char-before end) ?\n)))))
            (cons beg end)))
      (when-let* ((markdown-ts-appear-diagram--objects)
                 (source
                   (seq-find
                    (lambda (overlay)
                      (overlay-get overlay 'markdown-ts-appear-diagram--source))
                    (append (overlays-at position)
                            (overlays-at (max (point-min) (1- position)))))))
        (cons (overlay-start source) (overlay-end source))))))

(defun markdown-ts-appear--explicit-editing-p ()
  "Return non-nil while point remains in the explicitly opened block."
  (when-let* ((region markdown-ts-appear--explicit-region))
    (and (<= (car region) (point) (cdr region))
         (or (< (point) (cdr region))
             (not (eq (char-before) ?\n))))))

(defun markdown-ts-appear--set-explicit-region (bounds)
  "Track block BOUNDS with markers, or clear explicit editing when nil."
  (when markdown-ts-appear--explicit-region
    (set-marker (car markdown-ts-appear--explicit-region) nil)
    (set-marker (cdr markdown-ts-appear--explicit-region) nil))
  (setq markdown-ts-appear--explicit-region
        (when bounds (cons (copy-marker (car bounds))
                           (copy-marker (cdr bounds) t)))))

(defun markdown-ts-appear--block-reveal-p ()
  "Return non-nil when the current large block may reveal its source."
  (or (eq markdown-ts-appear-block-reveal 'automatic)
      (markdown-ts-appear--explicit-editing-p)))

(defun markdown-ts-appear-edit-block ()
  "Reveal source at point without changing its text.
Tables follow `markdown-ts-appear-table-reveal'; diagrams open in full."
  (interactive)
  (unless (and (markdown-ts-appear--active-p) (markdown-ts-appear--tracking-p))
    (user-error "Markdown source tracking is not active"))
  (let ((bounds (markdown-ts-appear--block-at-point)))
    (unless bounds (user-error "No wrapped table or diagram at point"))
    (markdown-ts-appear--set-explicit-region bounds)
    (setq markdown-ts-appear--last-point nil)
    (markdown-ts-appear--update)
    (run-hooks 'markdown-ts-appear--tracking-change-hook)))

(defun markdown-ts-appear--edit-block-binding (command)
  "Return COMMAND only while an explicit block preview is under point."
  (when (and (eq markdown-ts-appear-block-reveal 'explicit)
             (markdown-ts-appear--active-p) (markdown-ts-appear--tracking-p)
             (not (markdown-ts-appear--explicit-editing-p))
             (markdown-ts-appear--block-at-point)
             (get-char-property (min (point) (1- (point-max)))
                                'display (selected-window)))
    command))

(defvar markdown-ts-appear-mode-map
  (let ((map (make-sparse-keymap)))
    (dolist (key '("RET" "<return>"))
      (define-key map (kbd key)
                  '(menu-item "Edit block" markdown-ts-appear-edit-block
                              :filter markdown-ts-appear--edit-block-binding)))
    map)
  "Keymap for `markdown-ts-appear-mode'.")

(defun markdown-ts-appear--before-change (beg _end)
  "Open a large block before an edit at BEG while tracking is active."
  (when (and (eq markdown-ts-appear-block-reveal 'explicit)
             (markdown-ts-appear--tracking-p)
             (not (markdown-ts-appear--explicit-editing-p)))
    (when-let* ((bounds (markdown-ts-appear--block-at-point beg)))
      (markdown-ts-appear--set-explicit-region bounds))))

(defun markdown-ts-appear--evil-insert ()
  "Open a large block when entering Evil insert state with tracking active."
  (when (and (eq markdown-ts-appear-block-reveal 'explicit)
             (markdown-ts-appear--tracking-p)
             (not (markdown-ts-appear--explicit-editing-p)))
    (markdown-ts-appear-start)))

(defun markdown-ts-appear--bounds ()
  "Return source bounds for the smallest rendered element at point."
  (if (markdown-ts-appear--explicit-editing-p)
      (cons (marker-position (car markdown-ts-appear--explicit-region))
            (marker-position (cdr markdown-ts-appear--explicit-region)))
    (let* ((pos (point))
           (node (markdown-ts-appear--markdown-node-at pos)))
      (unless (and (eq markdown-ts-appear-block-reveal 'explicit)
                   (markdown-ts-appear--block-at-point pos node))
        (or (markdown-ts-appear-table--reveal-bounds node)
            (unless (markdown-ts-appear-math--span-at pos)
              (or (markdown-ts-appear--fence-bounds-at pos node)
                  (markdown-ts-appear--callout-bounds-at pos node)
                  (markdown-ts-appear--quote-marker-bounds-at pos node)
                  (unless (markdown-ts-appear--literal-block-at pos node)
                    (or (markdown-ts-appear--image-preview-bounds-at pos)
                        (markdown-ts-appear--bounds-at-point pos node))))))))))

(defun markdown-ts-appear--update-inline-ranges ()
  "Update inline Tree-sitter ranges around point when needed."
  (let ((line-beg (line-beginning-position))
        (tick (buffer-chars-modified-tick)))
    (unless (and (equal line-beg markdown-ts-appear--last-range-line)
                 (equal tick markdown-ts-appear--last-tick))
      (treesit-update-ranges
       line-beg (min (point-max) (line-beginning-position 2)))
      (setq markdown-ts-appear--last-range-line line-beg))))

(defun markdown-ts-appear--update ()
  "Reveal source for the rendered Markdown element at point."
  (let ((position (point))
        (tick (buffer-chars-modified-tick)))
    (unless (and (equal position markdown-ts-appear--last-point)
                 (equal tick markdown-ts-appear--last-tick))
      (let* ((edited (and markdown-ts-appear--last-tick
                          (not (equal tick markdown-ts-appear--last-tick))))
             (region markdown-ts-appear--region)
             (old-beg (and region (marker-position (car region))))
             (old-end (and region (marker-position (cdr region)))))
        ;; Inserting a row can extend the markers past the row we opened.
        ;; Resolve from its original start, rather than following point.
        (when-let* ((edited)
                    ((eq markdown-ts-appear-table-reveal 'row))
                    (explicit markdown-ts-appear--explicit-region)
                    (bounds (markdown-ts-appear--block-at-point
                             (marker-position (car explicit)))))
          (set-marker (cdr explicit) (cdr bounds)))
        (when (and markdown-ts-appear--explicit-region
                   (not (markdown-ts-appear--explicit-editing-p)))
          (markdown-ts-appear--set-explicit-region nil))
        (without-restriction
          (markdown-ts-appear--update-inline-ranges)
          (let* ((bounds (markdown-ts-appear--bounds))
                 (beg (car bounds))
                 (end (cdr bounds)))
            (unless (if bounds
                        (and old-beg old-end
                             (= beg old-beg) (= end old-end))
                      (null region))
              ;; An edit already dirtied its block.  A partial synchronous
              ;; refresh here would reintroduce hidden JIT boundaries in it.
              (markdown-ts-appear--restore edited)
              (when bounds
                (setq markdown-ts-appear--region
                      (cons (copy-marker beg) (copy-marker end t)))
                (font-lock-flush beg end)
                (unless edited (font-lock-ensure beg end))))))
        (setq markdown-ts-appear--last-point position
              markdown-ts-appear--last-tick tick)))))

(defun markdown-ts-appear-start ()
  "Start tracking the semantic Markdown element at point."
  (interactive)
  (when (markdown-ts-appear--active-p)
    (setq markdown-ts-appear--last-point nil
          markdown-ts-appear--last-tick nil
          markdown-ts-appear--last-range-line nil)
    (add-hook 'post-command-hook #'markdown-ts-appear--update nil t)
    (when (and (bound-and-true-p evil-local-mode)
               (eq (bound-and-true-p evil-state) 'insert)
               (eq markdown-ts-appear-block-reveal 'explicit))
      (markdown-ts-appear--set-explicit-region (markdown-ts-appear--block-at-point)))
    (markdown-ts-appear--update)
    (run-hooks 'markdown-ts-appear--tracking-change-hook)))

(defun markdown-ts-appear-stop ()
  "Stop tracking point and restore hidden Markdown markup."
  (interactive)
  (remove-hook 'post-command-hook #'markdown-ts-appear--update t)
  (markdown-ts-appear--set-explicit-region nil)
  (setq markdown-ts-appear--last-point nil
        markdown-ts-appear--last-tick nil
        markdown-ts-appear--last-range-line nil)
  (markdown-ts-appear--restore)
  (run-hooks 'markdown-ts-appear--tracking-change-hook))

;;; Fontification and decorations

(defun markdown-ts-appear--decoration-filter-copied-text (text)
  "Remove package decoration properties from copied Markdown TEXT."
  (let ((pos 0)
        (end (length text)))
    (while (< pos end)
      (let ((next (next-single-property-change
                   pos 'markdown-ts-appear--decoration text end)))
        (when (get-text-property pos 'markdown-ts-appear--decoration text)
          (remove-text-properties
           pos next '(display nil line-height nil line-prefix nil wrap-prefix nil
                              markdown-ts-appear--decoration nil)
           text))
        (setq pos next))))
  text)

(defun markdown-ts-appear--install-block-font-lock ()
  "Install block rendering rules in the current buffer."
  (unless markdown-ts-appear--block-font-lock-settings
    (when-let* ((settings
                 (append
                  (and (or markdown-ts-appear-block-quote-marker
                           markdown-ts-appear-render-callouts)
                       markdown-ts-appear--quote-font-lock-settings)
                  (and (eq markdown-ts-appear-code-fence-style 'connected)
                       markdown-ts-appear--code-font-lock-settings)
                  (and (eq markdown-ts-appear-table-style 'unicode)
                       markdown-ts-appear--table-font-lock-settings))))
      (let ((previous-settings treesit-font-lock-settings))
        (treesit-add-font-lock-rules settings)
        (setq markdown-ts-appear--block-font-lock-settings
              (seq-remove
               (lambda (setting) (memq setting previous-settings))
               treesit-font-lock-settings)))))
  (add-to-list 'font-lock-extra-managed-props
               'markdown-ts-appear--decoration)
  (when (or markdown-ts-appear-block-quote-marker
            (eq markdown-ts-appear-code-fence-style 'connected))
    (add-function :before (local 'font-lock-unfontify-region-function)
                  #'markdown-ts-appear--clear-prefixes))
  (unless (memq 'line-height font-lock-extra-managed-props)
    (push 'line-height markdown-ts-appear--managed-properties)
    (add-to-list 'font-lock-extra-managed-props 'line-height))
  (unless (advice-function-member-p
           #'markdown-ts-appear--decoration-filter-copied-text
           filter-buffer-substring-function)
    (add-function :filter-return (local 'filter-buffer-substring-function)
                  #'markdown-ts-appear--decoration-filter-copied-text)))

(defun markdown-ts-appear--remove-block-font-lock ()
  "Remove block rendering rules from the current buffer."
  (when markdown-ts-appear--block-font-lock-settings
    (setq treesit-font-lock-settings
          (seq-remove
           (lambda (setting)
             (memq setting markdown-ts-appear--block-font-lock-settings))
           treesit-font-lock-settings))
    (setq markdown-ts-appear--block-font-lock-settings nil))
  (remove-function (local 'filter-buffer-substring-function)
                   #'markdown-ts-appear--decoration-filter-copied-text))

(defun markdown-ts-appear--atx-marker-visible-p (node)
  "Return non-nil when ATX marker NODE is in an empty or incomplete heading."
  ;; An unfinished heading at buffer end can have its marker under an ERROR
  ;; node.  Keep it visible until there is a heading with text to render.
  (and (string-match-p "\\`atx_h[1-6]_marker\\'" (treesit-node-type node))
       (or (not (equal (treesit-node-type (treesit-node-parent node))
                       "atx_heading"))
           (save-excursion
             (goto-char (treesit-node-start node))
             (looking-at-p "[# \t]+$")))))

(defun markdown-ts-appear--fontify-node
    (function node override start limit &rest rest)
  "Call FUNCTION for NODE without covering visible source."
  (if (not (markdown-ts-appear--active-p))
      (apply function node override start limit rest)
    (let ((markdown-ts-hide-markup
           (and markdown-ts-hide-markup
                (not (or (markdown-ts-appear--node-visible-p node)
                         (markdown-ts-appear--atx-marker-visible-p node))))))
      (apply function node override start limit rest))))

(defun markdown-ts-appear--fontify-heading-marker
    (function node override start limit &rest rest)
  "Call FUNCTION for NODE, decorating rendered ATX heading markers.
OVERRIDE, START, LIMIT and REST are the native fontifier arguments."
  (if (and markdown-ts-appear-heading-bullets
           (markdown-ts-appear--active-p)
           markdown-ts-hide-markup
           (not (markdown-ts-appear--node-visible-p node))
           (not (markdown-ts-appear--atx-marker-visible-p node)))
      (let* ((marker-end (treesit-node-end node))
             (beg (save-excursion
                    (goto-char (treesit-node-start node))
                    (skip-chars-forward " \t" marker-end)
                    (point)))
             (level (- marker-end beg))
             (end (save-excursion
                    (goto-char marker-end)
                    (skip-chars-forward " \t" (line-end-position))
                    (point)))
             (bullet (nth (mod (1- level) (length markdown-ts-appear-heading-bullets))
                          markdown-ts-appear-heading-bullets))
             (markdown-ts-hide-markup nil))
        (apply function node override start limit rest)
        (when (and (<= start beg) (<= end limit))
          (markdown-ts-appear--decorate
           beg end (concat (if (characterp bullet) (char-to-string bullet) bullet) " ")
           (intern (format "markdown-ts-heading-%d" level)))))
    (apply #'markdown-ts-appear--fontify-node function node override start limit rest)))

(defun markdown-ts-appear--fence-start (node)
  "Return the first fence character in NODE, excluding leading indentation."
  (save-excursion
    (goto-char (treesit-node-start node))
    (skip-chars-forward " \t" (treesit-node-end node))
    (point)))

(defun markdown-ts-appear--code-indent (column)
  "Move over whitespace up to COLUMN, returning any tab overshoot as spaces."
  (while (and (< (current-column) column) (memq (char-after) '(?\s ?\t)))
    (forward-char))
  (make-string (max 0 (- (current-column) column)) ?\s))

(defun markdown-ts-appear--fontify-fence (node visible-p start limit)
  "Render fence NODE between START and LIMIT unless VISIBLE-P."
  (when (and (not visible-p)
             (eq markdown-ts-appear-code-fence-style 'connected)
             (<= start (treesit-node-start node))
             (<= (treesit-node-end node) limit))
    (if (= (treesit-node-start node)
           (treesit-node-start
            (markdown-ts-appear--first-direct-child-of-type
             (treesit-node-parent node) "fenced_code_block_delimiter")))
        (let* ((block (treesit-node-parent node))
               (info
                (markdown-ts-appear--first-direct-child-of-type
                 block "info_string"))
               (header-end (if info (treesit-node-end info)
                             (treesit-node-end node))))
          (when (<= header-end limit)
            (markdown-ts-appear--decorate
             (markdown-ts-appear--fence-start node) (treesit-node-end node)
             (if info
                 (concat
                  (propertize "╭─" 'face 'markdown-ts-appear-code-fence-marker)
                  (markdown-ts-appear--label
                   (treesit-node-text info t) 'markdown-ts-appear-code-fence-marker))
               "╭─")
             (unless info 'markdown-ts-appear-code-fence-marker))
            (when (< (treesit-node-end node) header-end)
              (markdown-ts-appear--decorate
               (treesit-node-end node) header-end "" nil))))
      (let ((column (save-excursion
                      (goto-char (markdown-ts-appear--fence-start
                                  (markdown-ts-appear--first-direct-child-of-type
                                   (treesit-node-parent node) "fenced_code_block_delimiter")))
                      (current-column))))
        (save-excursion
          (goto-char (markdown-ts-appear--fence-start node))
          (skip-chars-backward " \t" (line-beginning-position))
          ;; Keep the quote's own separator; only normalize fence indentation.
          (when (and (eq (char-before) ?>) (memq (char-after) '(?\s ?\t)))
            (forward-char))
          (when (<= start (point))
            (markdown-ts-appear--decorate
             (point) (treesit-node-end node)
             (concat (make-string (max 0 (- column (current-column))) ?\s) "╰─")
             'markdown-ts-appear-code-fence-marker)))))))

(defun markdown-ts-appear--quote-prefixes (node start limit)
  "Return structural quote prefixes in NODE intersecting START through LIMIT.
Each prefix is a list of marker bounds in source order.  Bounds include
at most one following space or tab and are not clipped to START or LIMIT."
  (with-memoization markdown-ts-appear--quote-prefix-query
    (treesit-query-compile
     'markdown '([(block_quote_marker) (block_continuation)] @prefix)))
  (save-match-data
    (save-excursion
      (let (prefixes)
        (dolist (prefix (treesit-query-capture
                         node markdown-ts-appear--quote-prefix-query
                         start limit t))
          (goto-char (treesit-node-start prefix))
          (let ((end (treesit-node-end prefix))
                markers)
            (while (search-forward ">" end t)
              (push (cons (1- (point))
                          (if (and (< (point) end)
                                   (memq (char-after) '(?\s ?\t)))
                              (1+ (point))
                            (point)))
                    markers))
            (when markers
              (push (nreverse markers) prefixes))))
        (nreverse prefixes)))))

(defun markdown-ts-appear--fontify-code-block
    (node _override start limit &rest _)
  "Render the content prefix of fenced code block NODE in START through LIMIT."
  (when-let* (((markdown-ts-appear--active-p))
              ((eq markdown-ts-appear-code-fence-style 'connected))
              (content (markdown-ts-appear--first-direct-child-of-type
                        node "code_fence_content")))
    (let* ((delimiters (markdown-ts-appear--direct-children-of-type
                        node "fenced_code_block_delimiter"))
           (column (save-excursion
                     (goto-char (markdown-ts-appear--fence-start (car delimiters)))
                     (current-column)))
           (closing (and (cdr delimiters) (car (last delimiters))))
           (content-beg (treesit-node-start content))
           (body-beg (save-excursion
                       (goto-char content-beg)
                       (line-beginning-position)))
           (body-end (if closing
                         (save-excursion
                           (goto-char (treesit-node-start closing))
                           (line-beginning-position))
                       (treesit-node-end content)))
           (beg (max start body-beg))
           (end (min limit body-end))
           (block-face
            (markdown-ts-appear--code-block-face markdown-ts-hide-markup)))
      (when (< beg end)
        ;; A prefix string does not take the face of the text it precedes,
        ;; so it gets the block face explicitly, as the fence lines do.
        (if (not (markdown-ts-appear--node-ancestor
                  (treesit-node-parent node) "block_quote"))
            (let* ((prefix (concat (make-string column ?\s) "│ "))
                   (face (list 'markdown-ts-appear-code-fence-marker block-face))
                   (display (propertize prefix 'face face)))
              (if (bound-and-true-p markdown-indent-mode)
                  ;; Keep outline indentation before the rail, and source
                  ;; indentation after it, rather than shifting the rail.
                  (save-excursion
                    (goto-char beg)
                    (beginning-of-line)
                    (while (< (point) end)
                      (markdown-ts-appear--decorate-prefix
                       (max beg (point)) (min end (line-beginning-position 2))
                       'wrap-prefix
                       (propertize
                        (concat prefix
                                (make-string (max 0 (- (current-indentation) column)) ?\s))
                        'face face)
                       'line-prefix)
                      (forward-line 1)))
                (markdown-ts-appear--decorate-prefix beg end 'wrap-prefix display))
              (if (zerop column)
                  (markdown-ts-appear--decorate-prefix beg end 'line-prefix display)
                (save-excursion
                  (goto-char beg)
                  (unless (bolp) (forward-line 1))
                  (while (< (point) end)
                    (let* ((line-beg (point))
                           (extra (markdown-ts-appear--code-indent column)))
                      (if (= line-beg (point))
                          (markdown-ts-appear--decorate-prefix
                           line-beg (min end (line-beginning-position 2)) 'line-prefix
                           display)
                        (markdown-ts-appear--decorate
                         line-beg (min end (point)) (concat prefix extra) face)))
                    (forward-line 1)))))
          (let ((wrap-beg (max beg content-beg))
                (wrap-prefix
                 (markdown-ts-appear--code-quote-prefix
                  (concat (buffer-substring-no-properties body-beg content-beg)
                          (make-string (max 0 (- column (save-excursion
                                                        (goto-char content-beg)
                                                        (current-column)))) ?\s))
                  block-face)))
            (when (< wrap-beg end)
              (markdown-ts-appear--decorate-prefix
               wrap-beg end 'wrap-prefix wrap-prefix 'line-prefix)))
          (dolist (prefix (markdown-ts-appear--quote-prefixes node beg end))
            (pcase-let ((`(,marker-beg . ,marker-end) (car (last prefix))))
              (when (and (<= beg marker-beg) (< marker-beg end)
                         (not (markdown-ts-appear--region-visible-p
                               marker-beg (1+ marker-beg))))
                (save-excursion
                  (goto-char marker-end)
                  (let* ((padding (make-string (max 0 (- column (current-column))) ?\s))
                         (extra (markdown-ts-appear--code-indent column)))
                    (markdown-ts-appear--decorate
                     marker-beg (min end (point))
                     (concat (markdown-ts-appear--code-quote-prefix
                              (concat (buffer-substring-no-properties marker-beg marker-end) padding)
                              block-face)
                             extra)
                     nil)))))))))))

(defun markdown-ts-appear--callout-background (accent)
  "Return a faint background face derived from ACCENT and the default face."
  (let* ((foreground (face-foreground accent nil t))
         (background (face-background 'default nil t))
         (colors (cons foreground background))
         (cached (alist-get accent markdown-ts-appear--callout-backgrounds)))
    (unless (equal colors (car cached))
      (setq cached
            (cons colors
                  (when (and (stringp foreground) (stringp background)
                             (color-defined-p foreground)
                             (color-defined-p background))
                    ;; Use only 15% of the accent so the header stays subdued.
                    (list :background
                          (apply #'color-rgb-to-hex
                                 (append
                                  (seq-mapn (lambda (fg bg)
                                              (+ (* 0.15 fg) (* 0.85 bg)))
                                            (color-name-to-rgb foreground)
                                            (color-name-to-rgb background))
                                  '(2)))
                          :extend t))))
      (setf (alist-get accent markdown-ts-appear--callout-backgrounds) cached))
    (cdr cached)))

(defun markdown-ts-appear--fontify-callout (node start limit)
  "Render callout NODE's header background and label within START through LIMIT."
  (when-let* ((markdown-ts-appear-render-callouts)
              (data (markdown-ts-appear--callout-data node))
              (beg (nth 0 data))
              (end (nth 1 data))
              (label-end
               (if (memq (char-before end) '(?+ ?-)) (1- end) end)))
    (let ((accent (pcase (upcase (nth 2 data))
                    ("NOTE" 'link)
                    ("TIP" 'success)
                    ("IMPORTANT" 'font-lock-keyword-face)
                    ("WARNING" 'warning)
                    ("CAUTION" 'error)
                    (_ 'markdown-ts-appear-block-quote-marker))))
      (save-excursion
        (goto-char beg)
        (let ((header-beg (max start (line-beginning-position)))
              (header-end (min limit (point-max) (1+ (line-end-position)))))
          (when-let* (((< header-beg header-end))
                      (face (markdown-ts-appear--callout-background accent)))
            (add-face-text-property header-beg header-end face))))
      (when (and (<= start beg) (<= label-end limit)
                 (not (markdown-ts-appear--region-visible-p beg end)))
        (markdown-ts-appear--decorate
         beg label-end (markdown-ts-appear--label (nth 2 data) accent) nil)))))

(defun markdown-ts-appear--fontify-quote-wrap (node _override start limit &rest _)
  "Repeat quote prefix NODE on wrapped screen lines between START and LIMIT.
Fenced code owns its continuation-prefix rendering."
  (save-excursion
    (goto-char (treesit-node-end node))
    (when (and (markdown-ts-appear--active-p) markdown-ts-appear-block-quote-marker
               (search-backward ">" (treesit-node-start node) t)
               (not (markdown-ts-appear--node-ancestor node "fenced_code_block")))
      (forward-char)
      (when (and (< (point) (treesit-node-end node))
                 (memq (char-after) '(?\s ?\t)))
        (forward-char))
      (let ((prefix-end (point))
            (beg (max start (line-beginning-position)))
            (end (min limit (line-beginning-position 2)))
            parts)
        (goto-char (line-beginning-position))
        (while (< (point) prefix-end)
          (push (if (eq (char-after) ?>)
                    (propertize
                     (if (markdown-ts-appear--region-visible-p (point) (1+ (point)))
                         ">"
                       markdown-ts-appear-block-quote-marker)
                     'face 'markdown-ts-appear-block-quote-marker)
                  ;; Indent list markers rather than repeating their text.
                  (string (if (eq (char-after) ?\t) ?\t ?\s)))
                parts)
          (forward-char))
        (when (< beg end)
          (let ((display (apply #'concat (nreverse parts))))
            (add-face-text-property
             0 (length display) 'markdown-ts-block-quote t display)
            (markdown-ts-appear--decorate-prefix
             beg end 'wrap-prefix display
             ;; These modes already include raw quote syntax in wrap-prefix.
             (when (or (bound-and-true-p visual-wrap-prefix-mode)
                       (bound-and-true-p markdown-indent-mode))
               'line-prefix))))))))

(defun markdown-ts-appear--fontify-quote-marker (node visible-p start limit)
  "Render NODE's quote markers between START and LIMIT unless VISIBLE-P."
  (when (and (not visible-p) markdown-ts-appear-block-quote-marker
             (< (max start (treesit-node-start node))
                (min limit (treesit-node-end node))))
    (dolist (prefix (markdown-ts-appear--quote-prefixes node start limit))
      (dolist (bounds prefix)
        (let ((beg (car bounds)))
          (when (and (<= start beg) (< beg limit)
                     (not (markdown-ts-appear--region-visible-p beg (1+ beg))))
            (markdown-ts-appear--decorate
             beg (1+ beg) markdown-ts-appear-block-quote-marker
             'markdown-ts-appear-block-quote-marker)))))))

(defun markdown-ts-appear--fontify-delimiter
    (function node override start limit &rest rest)
  "Call FUNCTION for NODE, rendering structural delimiters."
  (if (not (markdown-ts-appear--active-p))
      (apply function node override start limit rest)
    (let* ((type (treesit-node-type node))
           (hide-markup-p markdown-ts-hide-markup)
           (visible-p (markdown-ts-appear--node-visible-p node))
           (quote-marker-p
            (and (member type '("block_quote_marker" "block_continuation"))
                 (string-search ">" (treesit-node-text node t))))
           (fence-p (member type '("fenced_code_block_delimiter"
                                   "info_string")))
           (markdown-ts-hide-markup
            (and markdown-ts-hide-markup
                 (not (or quote-marker-p fence-p
                          visible-p)))))
      (apply function node override start limit rest)
      (when (equal type "fenced_code_block_delimiter")
        (let ((face (markdown-ts-appear--code-block-face hide-markup-p)))
          (save-excursion
            (goto-char (treesit-node-start node))
            (let ((beg (max start (line-beginning-position)))
                  (end (min limit (point-max) (1+ (line-end-position)))))
              (when (< beg end)
                (add-face-text-property beg end face t)))))
        (markdown-ts-appear--fontify-fence node visible-p start limit)))))

(defun markdown-ts-appear--fontify-block-quote
    (node _override start limit &rest _)
  "Render block quote NODE between START and LIMIT."
  (when (markdown-ts-appear--active-p)
    (let ((beg (max start (treesit-node-start node)))
          (end (min limit (treesit-node-end node))))
      (when (< beg end)
        (markdown-ts-appear--fontify-callout node beg end)
        (markdown-ts-appear--fontify-quote-marker node nil beg end)))))

(defconst markdown-ts-appear--quote-font-lock-settings
  (treesit-font-lock-rules
   :language 'markdown
   :feature 'paragraph
   :override 'append
   '(((block_quote) @markdown-ts-appear--fontify-block-quote)
     ([(block_quote_marker) (block_continuation)]
      @markdown-ts-appear--fontify-quote-wrap)))
  "Additional Tree-sitter font-lock settings for rendered block quotes.")

(defconst markdown-ts-appear--code-font-lock-settings
  (treesit-font-lock-rules
   :language 'markdown
   :feature 'paragraph
   :override 'append
   '(((fenced_code_block) @markdown-ts-appear--fontify-code-block)))
  "Additional Tree-sitter font-lock settings for rendered code blocks.")

(defun markdown-ts-appear--fontify-visible-markup
    (function node override start limit &rest rest)
  "Call FUNCTION for NODE without covering visible markup."
  (if (not (markdown-ts-appear--active-p))
      (apply function node override start limit rest)
    (let* ((type (treesit-node-type node))
           (markup-node
            (pcase type
              ("atx_heading" (treesit-node-child node 0 'named))
              ("setext_heading"
               (treesit-search-subtree node "\\`setext_h[12]_underline\\'"))
              (_ node)))
           (markdown-ts-hide-markup
            (and markdown-ts-hide-markup
                 (not (and markup-node
                           (or (markdown-ts-appear--node-visible-p markup-node)
                               (markdown-ts-appear--atx-marker-visible-p
                                markup-node)))))))
      (apply function node override start limit rest)
      (when (and markdown-ts-hide-markup
                 (equal type "setext_heading")
                 markup-node
                 (text-property-any
                  (treesit-node-start markup-node) (treesit-node-end markup-node)
                  'line-height 0))
        (with-silent-modifications
          (put-text-property
           (treesit-node-start markup-node) (treesit-node-end markup-node)
           'markdown-ts-appear--decoration t))))))

(defun markdown-ts-appear--icon (type)
  "Return the configured Markdown icon for TYPE, or nil when empty."
  (let ((icon (pcase type
                ('image markdown-ts-appear-image-icon)
                ('wikilink markdown-ts-appear-wikilink-icon)
                (_ markdown-ts-appear-link-icon))))
    (unless (string-empty-p icon)
      (propertize icon 'face 'markdown-ts-link))))

(defun markdown-ts-appear--fontify-link-destination
    (function node override start limit &rest rest)
  "Call FUNCTION for NODE, preserving useful image labels."
  (if (not (markdown-ts-appear--active-p))
      (apply function node override start limit rest)
    (let* ((parent (treesit-node-parent node))
           (image-p (equal (treesit-node-type parent) "image"))
           (beg (and image-p (treesit-node-start parent)))
           (end (and image-p (treesit-node-end parent)))
           (visible-p (markdown-ts-appear--node-visible-p node))
           (markdown-ts-hide-markup
            (and markdown-ts-hide-markup (not visible-p))))
      (apply function node override start limit rest)
      (when image-p
        (dolist (overlay (overlays-in beg end))
          (when (overlay-get overlay 'markdown-ts-appear--image-label)
            (delete-overlay overlay)))
        (when (and markdown-ts-hide-markup
                   (not (outline-invisible-p beg)))
          (let* ((description
                  (treesit-search-subtree parent "\\`image_description\\'"))
                 (url (markdown-ts-appear--native-decode-destination
                       (treesit-node-text node t)))
                 (label (file-name-nondirectory url))
                 (icon (markdown-ts-appear--icon 'image)))
            (with-silent-modifications
              (unless description
                (markdown-ts-appear--remove-markup-invisibility
                 (treesit-node-start node) (treesit-node-end node))
                (markdown-ts-appear--decorate
                 (treesit-node-start node) (treesit-node-end node)
                 (if (string-empty-p label) url label) nil))
              (markdown-ts-appear--native-link-button beg end url))
            (when icon
              (let ((overlay
                     (make-overlay beg (min (1+ beg) end) nil t nil)))
                (overlay-put overlay 'markdown-ts-appear--image-label t)
                (overlay-put overlay 'before-string (concat icon " "))
                (overlay-put overlay 'help-echo url)
                (overlay-put overlay 'mouse-face 'highlight)
                (overlay-put overlay 'evaporate t)))))))))

(defun markdown-ts-appear--fontify-link
    (function node override start limit &rest rest)
  "Call FUNCTION for NODE, prefixing links with an icon."
  (prog1 (apply function node override start limit rest)
    (when (markdown-ts-appear--active-p)
      (let* ((parent (treesit-node-parent node))
             (parent-beg (treesit-node-start parent))
             (parent-end (treesit-node-end parent))
             (beg (treesit-node-start node))
             (end (treesit-node-end node)))
        (cond
         ((or (markdown-ts-appear--callout-link-p parent)
              (markdown-ts-appear-math--contains-p parent-beg parent-end))
          (with-silent-modifications
            (remove-list-of-text-properties
             parent-beg parent-end
             '(action button category follow-link help-echo keymap mouse-face)))
          (dolist (overlay (overlays-in parent-beg parent-end))
            (when (overlay-get overlay 'markdown-ts-appear--link-icon)
              (delete-overlay overlay))))
         ((and (equal (treesit-node-type node) "link_label")
               (treesit-search-subtree parent "\\`link_text\\'"))
          (with-silent-modifications
            (if (and markdown-ts-hide-markup
                     (not (markdown-ts-appear--node-visible-p node)))
                (put-text-property beg end 'invisible markdown-ts-appear--markup-invisibility)
              (markdown-ts-appear--remove-markup-invisibility beg end)))
          nil)
         ((not (markdown-ts-appear--node-ancestor parent "image"))
          (let* ((wikilink-p (markdown-ts-appear--wikilink-bounds-for-node parent))
                 (alias-delimiter
                  (and wikilink-p
                       (markdown-ts-appear--first-direct-child-of-type node "|")))
                 (alias-beg (and alias-delimiter (treesit-node-end alias-delimiter)))
                 (icon-beg (or alias-beg beg))
                 (visible-p
                  (or (markdown-ts-appear--region-visible-p parent-beg beg)
                      (markdown-ts-appear--region-visible-p end parent-end))))
            (when alias-beg
              (with-silent-modifications
                (markdown-ts-appear--native-link-button
                 beg end
                 (buffer-substring-no-properties
                  beg (treesit-node-start alias-delimiter)))))
            (dolist (overlay (overlays-in beg end))
              (when (overlay-get overlay 'markdown-ts-appear--link-icon)
                (delete-overlay overlay)))
            (when (and markdown-ts-hide-markup (not visible-p))
              (when wikilink-p
                (with-silent-modifications
                  (put-text-property (1- parent-beg) parent-beg
                                     'invisible markdown-ts-appear--markup-invisibility)
                  (put-text-property parent-end (1+ parent-end)
                                     'invisible markdown-ts-appear--markup-invisibility)
                  (when alias-beg
                    (let* ((region markdown-ts-appear--region)
                           (visible-beg (and region (marker-position (car region))))
                           (visible-end (and region (marker-position (cdr region)))))
                      (if (and visible-beg visible-end
                               (< visible-beg alias-beg) (> visible-end beg))
                          (let ((reveal-beg (max beg visible-beg))
                                (reveal-end (min alias-beg visible-end)))
                            (when (< beg reveal-beg)
                              (put-text-property beg reveal-beg
                                                 'invisible markdown-ts-appear--markup-invisibility))
                            (when (< reveal-end alias-beg)
                              (put-text-property reveal-end alias-beg
                                                 'invisible markdown-ts-appear--markup-invisibility)))
                        (put-text-property beg alias-beg
                                           'invisible markdown-ts-appear--markup-invisibility))))))
              (when-let* ((icon (markdown-ts-appear--icon
                                 (if wikilink-p 'wikilink 'link))))
                (let ((overlay (make-overlay icon-beg (min (1+ icon-beg) end)
                                             nil t nil)))
                  (overlay-put overlay 'markdown-ts-appear--link-icon t)
                  (overlay-put overlay 'before-string (concat icon " "))
                  (overlay-put overlay 'evaporate t)))))))))))

;;; Buffer lifecycle

(defun markdown-ts-appear--set-render-option (option value)
  "Set OPTION to VALUE and update rendering in active buffers."
  (set-default option value)
  (dolist (buffer (buffer-list))
    (with-current-buffer buffer
      (when (and (markdown-ts-appear--active-p)
                 (not (local-variable-p option)))
        (cond
         ((eq option 'markdown-ts-appear-math-renderer)
          (markdown-ts-appear-math--restart))
         ((eq option 'markdown-ts-appear-diagram-size)
          (markdown-ts-appear-diagram--refresh))
         ((eq option 'markdown-ts-appear-diagram-renderers)
          (markdown-ts-appear-diagram--teardown)
          (when markdown-ts-appear-diagram-renderers
            (markdown-ts-appear-diagram--setup)))
         ((eq option 'markdown-ts-appear-table-zebra-stripe)
          (markdown-ts-appear-table--refresh-stripes))
         ((memq option '(markdown-ts-appear-block-reveal markdown-ts-appear-table-reveal))
          (cond
           ((eq option 'markdown-ts-appear-block-reveal)
            (markdown-ts-appear--set-explicit-region nil))
           ((markdown-ts-appear--explicit-editing-p)
            (markdown-ts-appear--set-explicit-region (markdown-ts-appear--block-at-point))))
          (setq markdown-ts-appear--last-point nil)
          (when (markdown-ts-appear--tracking-p) (markdown-ts-appear--update))
          (markdown-ts-appear-table--post-command))
         (t
          (when (eq option 'markdown-ts-appear-table-style)
            (markdown-ts-appear-table--teardown))
          (without-restriction
            ;; Clear old managed properties before changing the rules.
            (font-lock-unfontify-region (point-min) (point-max))
            (markdown-ts-appear--remove-block-font-lock)
            (markdown-ts-appear--release-managed-properties)
            (markdown-ts-appear--install-block-font-lock)
            (markdown-ts-appear--delete-rendering-overlays)
            (setq markdown-ts-appear--last-point nil)
            (font-lock-flush)
            (when (markdown-ts-appear--tracking-p)
              (markdown-ts-appear--update)))
          (when (eq option 'markdown-ts-appear-table-style)
            (markdown-ts-appear-table--setup))))))))

(defconst markdown-ts-appear--appearance-hooks
  '(enable-theme-functions disable-theme-functions after-setting-font-hook)
  "Global appearance notifications used while appear is active.")

(defun markdown-ts-appear--appearance-change (&rest _)
  "Refresh decorations and previews after a theme or frame-font change."
  (setq markdown-ts-appear--callout-backgrounds nil)
  (markdown-ts-appear-math--appearance-change)
  (dolist (buffer (buffer-list))
    (with-current-buffer buffer
      (when (markdown-ts-appear--active-p)
        (when markdown-ts-appear-render-callouts
          (without-restriction (font-lock-flush)))
        (when (memq #'markdown-ts-appear-diagram--refresh post-command-hook)
          (run-at-time 0 nil #'markdown-ts-appear-diagram--refresh-buffer buffer))))))

;; Folding changes overlays, not text, so renderers need this notification.
;; Obsoleted in 29.1 as a presumed lazy-lock-only hook; no replacement yet.
;; A replacement API is discussed in Emacs bug#81632:
;; https://debbugs.gnu.org/cgi/bugreport.cgi?bug=81632
(defun markdown-ts-appear--add-outline-hook (function &optional depth)
  "Add FUNCTION to this buffer's outline notifications at DEPTH."
  (with-suppressed-warnings ((obsolete outline-view-change-hook))
    (add-hook 'outline-view-change-hook function depth t)))

(defun markdown-ts-appear--remove-outline-hook (function)
  "Remove FUNCTION from the current buffer's outline visibility notifications."
  (with-suppressed-warnings ((obsolete outline-view-change-hook))
    (remove-hook 'outline-view-change-hook function t)))

(defun markdown-ts-appear--window-views (source property windows beg end &rest properties)
  "Return SOURCE's PROPERTY views for WINDOWS, each spanning BEG to END.
Reuse each window's existing view, create missing ones with PROPERTIES and
delete views whose window is no longer listed.  A nil window means all windows."
  (let* ((old (overlay-get source property))
         (views
          (mapcar
           (lambda (window)
             (let ((view (or (seq-find (lambda (view)
                                         (and (overlay-buffer view)
                                              (eq (overlay-get view 'window) window)))
                                       old)
                             (let ((view (make-overlay beg end nil t nil))
                                   (properties properties))
                               (overlay-put view 'window window)
                               (while properties
                                 (overlay-put view (pop properties) (pop properties)))
                               view))))
               (unless (and (= beg (overlay-start view)) (= end (overlay-end view)))
                 (move-overlay view beg end))
               view))
           windows)))
    (dolist (view old)
      (unless (memq view views) (delete-overlay view)))
    (unless (equal views old)
      (overlay-put source property views))
    views))

(defun markdown-ts-appear--delete-rendering-overlays (&optional beg end)
  "Delete package icon overlays between BEG and END, or throughout the buffer."
  (without-restriction
    (dolist (overlay (overlays-in (or beg (point-min)) (or end (point-max))))
      (when (or (overlay-get overlay 'markdown-ts-appear--image-label)
                (overlay-get overlay 'markdown-ts-appear--link-icon))
        (delete-overlay overlay)))))

(defun markdown-ts-appear--invalidate (beg end)
  "Delete icons and refontify text between BEG and END."
  (markdown-ts-appear--delete-rendering-overlays beg end)
  ;; JIT-lock splits work at invisible-property boundaries.  Drop stale markup
  ;; so an edited block is refontified together, not once per hidden delimiter.
  (with-silent-modifications
    (markdown-ts-appear--remove-markup-invisibility beg end))
  (font-lock-flush beg end))

(defun markdown-ts-appear--after-change (beg end _old-length)
  "Invalidate the outermost block around an edit between BEG and END."
  (without-restriction
    (let ((node (treesit-node-at beg 'markdown))
          block)
      (while (and node (not (member (treesit-node-type node) '("section" "document"))))
        (setq block node
              node (treesit-node-parent node)))
      (save-excursion
        (markdown-ts-appear--invalidate
         (min (progn (goto-char beg) (line-beginning-position))
              (if block (treesit-node-start block) beg))
         (max (progn (goto-char end) (line-end-position))
              (if block (treesit-node-end block) end)))))))

(defun markdown-ts-appear--structure-notifier (ranges _parser)
  "Invalidate RANGES whose block structure changed, possibly far from an edit."
  (without-restriction
    (pcase-dolist (`(,beg . ,end) ranges)
      (markdown-ts-appear--invalidate beg end)
      (run-hook-with-args 'markdown-ts-appear--syntax-change-functions beg end))))

(defun markdown-ts-appear--install-buffer-hooks ()
  "Install buffer-local lifecycle and change hooks."
  (add-hook 'before-change-functions #'markdown-ts-appear--before-change nil t)
  (add-hook 'evil-insert-state-entry-hook #'markdown-ts-appear--evil-insert nil t)
  (add-hook 'after-change-functions #'markdown-ts-appear--after-change t t)
  (treesit-parser-add-notifier
   treesit-primary-parser #'markdown-ts-appear--structure-notifier)
  (add-hook 'change-major-mode-hook
            #'markdown-ts-appear--buffer-teardown nil t)
  (add-hook 'kill-buffer-hook
            #'markdown-ts-appear--kill-buffer-teardown nil t)
  (add-hook 'clone-indirect-buffer-hook
            #'markdown-ts-appear--detach-indirect-clone nil t))

(defun markdown-ts-appear--remove-buffer-hooks ()
  "Remove buffer-local lifecycle and change hooks."
  (remove-hook 'before-change-functions #'markdown-ts-appear--before-change t)
  (remove-hook 'evil-insert-state-entry-hook #'markdown-ts-appear--evil-insert t)
  (remove-hook 'after-change-functions #'markdown-ts-appear--after-change t)
  ;; Indirect clones share the base buffer's parser.
  (when (and (treesit-parser-p treesit-primary-parser)
             (eq (treesit-parser-buffer treesit-primary-parser) (current-buffer)))
    (treesit-parser-remove-notifier
     treesit-primary-parser #'markdown-ts-appear--structure-notifier))
  (remove-hook 'change-major-mode-hook
               #'markdown-ts-appear--buffer-teardown t)
  (remove-hook 'kill-buffer-hook
               #'markdown-ts-appear--kill-buffer-teardown t)
  (remove-hook 'clone-indirect-buffer-hook
               #'markdown-ts-appear--detach-indirect-clone t))

(defun markdown-ts-appear--release-managed-properties ()
  "Release font-lock properties managed by the current buffer."
  (remove-function (local 'font-lock-unfontify-region-function)
                   #'markdown-ts-appear--clear-prefixes)
  (dolist (property markdown-ts-appear--managed-properties)
    (setq font-lock-extra-managed-props
          (remove property font-lock-extra-managed-props)))
  (setq markdown-ts-appear--managed-properties nil)
  (setq font-lock-extra-managed-props
        (remove 'markdown-ts-appear--decoration
                font-lock-extra-managed-props)))

(defun markdown-ts-appear--detach-indirect-clone ()
  "Detach active tracking inherited by a new indirect clone.
Indirect buffers are otherwise unsupported and are not synchronized."
  (when (buffer-base-buffer)
    ;; Do not run normal teardown: text properties are shared with the base.
    (setq markdown-ts-appear-mode nil
          markdown-ts-appear--region nil
          markdown-ts-appear--explicit-region nil)
    (markdown-ts-appear-image--detach)
    (markdown-ts-appear-diagram--detach)
    (markdown-ts-appear-table--detach)
    (markdown-ts-appear-math--detach)
    (setq local-minor-modes
          (remove 'markdown-ts-appear-mode local-minor-modes))
    (remove-hook 'post-command-hook #'markdown-ts-appear--update t)
    (markdown-ts-appear--remove-buffer-hooks)
    (markdown-ts-appear--remove-block-font-lock)
    (setq font-lock-extra-managed-props
          (remove 'display
                  font-lock-extra-managed-props))
    (markdown-ts-appear--release-managed-properties)))

(defun markdown-ts-appear--buffer-teardown ()
  "Disable Markdown TS Appear before replacing the current major mode."
  (when (memq #'markdown-ts-appear--after-change after-change-functions)
    (markdown-ts-appear-mode -1)))

(defun markdown-ts-appear--kill-buffer-teardown ()
  "Disable Markdown TS Appear before discarding the current buffer."
  (let ((markdown-ts-appear--tearing-down-buffer-p t))
    (markdown-ts-appear--buffer-teardown)))

(defun markdown-ts-appear--enable-buffer ()
  "Install Markdown TS Appear integration in the current buffer."
  (markdown-ts-appear--install-advice)
  (dolist (hook markdown-ts-appear--appearance-hooks)
    (add-hook hook #'markdown-ts-appear--appearance-change))
  (markdown-ts-appear--install-buffer-hooks)
  (markdown-ts-appear--install-block-font-lock)
  (markdown-ts-appear-image--setup)
  (unless markdown-ts-hide-markup
    (setq markdown-ts-hide-markup t)
    (markdown-ts-appear--native-set-hide-markup t))
  (without-restriction
    (font-lock-flush (point-min) (point-max)))
  (when markdown-ts-appear-auto-start (markdown-ts-appear-start))
  (markdown-ts-appear-table--setup)
  (markdown-ts-appear-math--setup)
  (when markdown-ts-appear-diagram-renderers
    (markdown-ts-appear-diagram--setup)))

(defun markdown-ts-appear--disable-buffer ()
  "Remove Markdown TS Appear integration from the current buffer."
  (markdown-ts-appear--remove-buffer-hooks)
  (markdown-ts-appear-image--teardown)
  (markdown-ts-appear-diagram--teardown)
  (markdown-ts-appear-math--teardown)
  (markdown-ts-appear-table--teardown)
  (markdown-ts-appear-stop)
  (markdown-ts-appear--remove-block-font-lock)
  (markdown-ts-appear--delete-rendering-overlays)
  (without-restriction
    (kill-local-variable 'markdown-ts-hide-markup)
    (markdown-ts-appear--native-set-hide-markup markdown-ts-hide-markup)
    (unless markdown-ts-appear--tearing-down-buffer-p
      (condition-case nil
          (font-lock-ensure (point-min) (point-max))
        (treesit-parser-deleted
         (font-lock-unfontify-region (point-min) (point-max))))))
  (markdown-ts-appear--release-managed-properties)
  (unless (seq-some (lambda (buffer)
                     (with-current-buffer buffer (markdown-ts-appear--active-p)))
                   (buffer-list))
    (markdown-ts-appear--set-advice nil)
    (dolist (hook markdown-ts-appear--appearance-hooks)
      (remove-hook hook #'markdown-ts-appear--appearance-change))))

;;;###autoload
(define-minor-mode markdown-ts-appear-mode
  "Reveal rendered Markdown source at point.
Disabling the mode resets `markdown-ts-hide-markup' to its current default."
  :lighter nil
  :keymap markdown-ts-appear-mode-map
  ;; The mode variable is already set, so inspect the installed hook instead.
  (let ((initialized
         (memq #'markdown-ts-appear--after-change after-change-functions)))
    (if markdown-ts-appear-mode
        (unless initialized
          (unless (derived-mode-p 'markdown-ts-mode)
            (markdown-ts-appear--deactivate-mode)
            (user-error "Markdown TS Appear mode requires markdown-ts-mode"))
          (when (buffer-base-buffer)
            (markdown-ts-appear--deactivate-mode)
            (user-error "Markdown TS Appear does not support indirect buffers"))
          (markdown-ts-appear--enable-buffer))
      (when initialized
        (markdown-ts-appear--disable-buffer)))))

(defun markdown-ts-appear-unload-function ()
  "Remove global integration before unloading Markdown TS Appear."
  (dolist (hook markdown-ts-appear--appearance-hooks)
    (remove-hook hook #'markdown-ts-appear--appearance-change))
  (dolist (buffer (buffer-list))
    (when (buffer-live-p buffer)
      (with-current-buffer buffer
        (markdown-ts-appear--buffer-teardown))))
  (markdown-ts-appear--set-advice nil)
  nil)

(provide 'markdown-ts-appear)

;;; markdown-ts-appear.el ends here
