;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gvariant" "1.0.0.0.20210507.4"
  "GVariant (GLib) helpers."
  '((emacs  "24")
    (parsec "0.1.4"))
  :url "https://github.com/wbolster/emacs-gvariant"
  :commit "f2e87076845800cbaaeed67f175ad4e4a9c01e37"
  :revdesc "1.0.0-4-gf2e870768458"
  :keywords '("languages")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
