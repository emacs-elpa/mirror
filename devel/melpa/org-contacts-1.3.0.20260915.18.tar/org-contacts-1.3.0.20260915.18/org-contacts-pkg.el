;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "1.3.0.20260915.18"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "a9a29e6374eb4e7baa28ef82b8613acd6eac5c6b"
  :revdesc "a9a29e6374eb"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
