;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pubsub" "0.1.0.20260228.13"
  "A basic publish/subscribe system."
  '((emacs "24.1"))
  :url "https://github.com/countvajhula/pubsub"
  :commit "e88732cf6239a2d94fef59b2e32190bf389a576f"
  :revdesc "v0.1-13-ge88732cf6239"
  :authors '(("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
