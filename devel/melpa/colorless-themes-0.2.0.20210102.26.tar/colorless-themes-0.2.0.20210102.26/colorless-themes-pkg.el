;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "colorless-themes" "0.2.0.20210102.26"
  "A macro to generate mostly colorless themes."
  '((emacs "24.1"))
  :url "https://git.sr.ht/~lthms/colorless-themes.el"
  :commit "95fff8b4e313bdd2073454fd5be9420d95dab267"
  :revdesc "0.2-26-g95fff8b4e313"
  :keywords '("faces themes" "faces")
  :authors '(("Thomas Letan" . "contact@thomasletan.fr"))
  :maintainers '(("Thomas Letan" . "contact@thomasletan.fr")))
