;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clj-doc-browse" "0.1.0.0.20260329.8"
  "Browse Clojure library docs from classpath JARs."
  '((emacs         "27.1")
    (cider         "1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/dcj/clj-doc-browse-el"
  :commit "1409c55f8173720d8035e38f19ee0bd16f1c5ecf"
  :revdesc "1409c55f8173"
  :keywords '("clojure" "documentation" "tools")
  :authors '(("Don Jackson" . "dcj@clark-communications.com"))
  :maintainers '(("Don Jackson" . "dcj@clark-communications.com")))
