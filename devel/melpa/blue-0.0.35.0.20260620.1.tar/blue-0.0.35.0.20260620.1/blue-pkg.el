;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "0.0.35.0.20260620.1"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "ca78d0ee1f7ff9e08b46ec2e90b69a8fbd05a9ab"
  :revdesc "ca78d0ee1f7f"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
