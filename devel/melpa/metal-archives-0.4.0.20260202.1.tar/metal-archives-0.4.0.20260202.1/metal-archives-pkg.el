;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metal-archives" "0.4.0.20260202.1"
  "List future releases using Metal-Archives API."
  '((emacs   "26.3")
    (alert   "1.2")
    (ht      "2.3")
    (request "0.2.2"))
  :url "https://github.com/seblemaguer/metal-archives.el"
  :commit "eb1c4d84f04f4afc7a1c2a0f3c4f816f16fa85e6"
  :revdesc "eb1c4d84f04f"
  :keywords '("lisp" "calendar")
  :authors '(("Sébastien Le Maguer" . "lemagues@tcd.ie"))
  :maintainers '(("Sébastien Le Maguer" . "lemagues@tcd.ie")))
