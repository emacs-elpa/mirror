;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "1.7.0"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "6deb9b868c0ffa1e346952de6bf18f51580794a3"
  :revdesc "6deb9b868c0f"
  :keywords '("convenience" "comm" "hypermedia"))
