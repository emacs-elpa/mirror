;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "justl" "0.14.0.20260915.94"
  "Major mode for driving just files."
  '((transient  "0.1.0")
    (emacs      "27.1")
    (s          "1.2.0")
    (f          "0.20.0")
    (inheritenv "0.2"))
  :url "https://github.com/psibi/justl.el"
  :commit "25ce659d99cd0ca3a1696db1a08315aa4d1e7e1c"
  :revdesc "v0.14-94-g25ce659d99cd"
  :keywords '("just" "justfile" "tools" "processes"))
