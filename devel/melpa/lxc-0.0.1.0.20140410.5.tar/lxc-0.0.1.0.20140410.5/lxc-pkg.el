;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lxc" "0.0.1.0.20140410.5"
  "Lxc integration with Emacs."
  ()
  :url "https://github.com/nicferrier/emacs-lxc"
  :commit "88bed56c954d1edd9ff5ce0ced2c02dcf9f71835"
  :revdesc "88bed56c954d"
  :keywords '("processes")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
