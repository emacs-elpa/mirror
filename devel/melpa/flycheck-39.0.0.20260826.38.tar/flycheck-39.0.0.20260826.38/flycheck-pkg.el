;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "39.0.0.20260826.38"
  "On-the-fly syntax checking."
  '((emacs "28.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "e8245aead5bdd462ecf4cc8732a790a9bb5aa2de"
  :revdesc "e8245aead5bd"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
