;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperlist-mode" "0.9.0.20230119.5"
  "A major-mode for viewing Hyperlists."
  '((emacs "24"))
  :url "https://github.com/vifon/hyperlist-mode"
  :commit "480dbf33ca72e7b5fade952aaf0d5a5eb43acb1d"
  :revdesc "480dbf33ca72"
  :keywords '("outlines"))
