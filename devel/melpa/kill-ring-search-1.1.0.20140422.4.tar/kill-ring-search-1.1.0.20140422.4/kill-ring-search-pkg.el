;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kill-ring-search" "1.1.0.20140422.4"
  "Incremental search for the kill ring."
  ()
  :url "http://nschum.de/src/emacs/kill-ring-search/"
  :commit "23535b4a01a1cb1574604e36c49614e84e85c883"
  :revdesc "1.1-4-g23535b4a01a1"
  :keywords '("convenience" "matching")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
