;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frame-purpose" "1.0.0.20211011.23"
  "Purpose-specific frames."
  '((emacs "25.1")
    (dash  "2.18"))
  :url "https://github.com/alphapapa/frame-purpose.el"
  :commit "7d498147445cc0afb87b922a8225d2e163e5ed5a"
  :revdesc "1.0-23-g7d498147445c"
  :keywords '("buffers" "convenience" "frames")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
