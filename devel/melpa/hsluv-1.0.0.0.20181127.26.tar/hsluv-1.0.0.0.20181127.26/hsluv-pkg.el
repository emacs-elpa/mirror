;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hsluv" "1.0.0.0.20181127.26"
  "Hsluv color space conversions."
  '((seq "2.20"))
  :url "https://github.com/hsluv/hsluv-emacs"
  :commit "bc6e27d25b62f5a2f79836a32e8de6125f4d1564"
  :revdesc "bc6e27d25b62"
  :keywords '("color" "hsluv"))
