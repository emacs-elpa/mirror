;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faustine" "0.4.0.20171122.5"
  "Edit, visualize, build and run Faust code."
  '((emacs      "24.3")
    (faust-mode "0.3"))
  :url "https://bitbucket.org/yphil/faustine"
  :commit "07a38963111518f86123802f9d477be0d4689a3f"
  :revdesc "v0.4-5-g07a389631115"
  :keywords '("languages" "faust")
  :authors '(("Yassin Philip" . "xaccrocheur@gmail.com"))
  :maintainers '(("Yassin Philip" . "xaccrocheur@gmail.com")))
