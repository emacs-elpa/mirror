;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xkcd" "1.1.0.20220503.3"
  "View xkcd from Emacs."
  '((json "1.3"))
  :url "https://github.com/vibhavp/emacs-xkcd"
  :commit "80011da2e7def8f65233d4e0d790ca60d287081d"
  :revdesc "80011da2e7de"
  :keywords '("xkcd" "webcomic")
  :authors '(("Vibhav Pant" . "vibhavp@gmail.com"))
  :maintainers '(("Vibhav Pant" . "vibhavp@gmail.com")))
