;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-rainbow-tags" "0.0.0.20250125.27"
  "Colorize org tags automatically."
  '((emacs "28.1"))
  :url "https://github.com/KaratasFurkan/org-rainbow-tags"
  :commit "dfe36047bc9646b621452f3e2e97170e99e2b43f"
  :revdesc "dfe36047bc96"
  :keywords '("faces" "outlines")
  :authors '(("Furkan Karataş" . "furkan.karatas02@gmail.com"))
  :maintainers '(("Furkan Karataş" . "furkan.karatas02@gmail.com")))
