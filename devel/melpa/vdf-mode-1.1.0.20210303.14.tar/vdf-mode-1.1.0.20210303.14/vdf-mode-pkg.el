;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vdf-mode" "1.1.0.20210303.14"
  "Major mode for editing Valve VDF files."
  '((emacs "24.3"))
  :url "https://github.com/plapadoo/vdf-mode"
  :commit "0910d4f847e9c817eb8da5434b3879048ec4ac92"
  :revdesc "0910d4f847e9")
