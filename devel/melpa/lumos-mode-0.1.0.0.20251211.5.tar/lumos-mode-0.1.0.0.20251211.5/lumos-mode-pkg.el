;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lumos-mode" "0.1.0.0.20251211.5"
  "Major mode for LUMOS schema language."
  '((emacs    "26.1")
    (lsp-mode "8.0"))
  :url "https://github.com/getlumos/lumos-mode"
  :commit "0caf9dccb2676f5d4a7080c3ff515ea65c926038"
  :revdesc "0caf9dccb267"
  :keywords '("languages" "solana" "blockchain"))
