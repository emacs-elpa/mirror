;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keg" "0.0.1.0.20261128.356"
  "Modern Elisp package development system."
  '((emacs "24.1"))
  :url "https://github.com/conao3/keg.el"
  :commit "0b5d9f6bc2c38080dc6091bdd607af4af5c0d473"
  :revdesc "0b5d9f6bc2c3"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
