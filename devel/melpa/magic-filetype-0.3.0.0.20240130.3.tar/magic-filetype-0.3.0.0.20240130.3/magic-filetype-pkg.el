;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magic-filetype" "0.3.0.0.20240130.3"
  "Enhance filetype major mode."
  '((emacs "24.3")
    (s     "1.9.0"))
  :url "https://github.com/emacs-php/magic-filetype.el"
  :commit "3979ddbd8066d7390e31bde2b35f997c5f5f4516"
  :revdesc "3979ddbd8066"
  :keywords '("emulations" "vim" "ft" "file" "magic-mode")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
