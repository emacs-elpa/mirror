;;; guava-themes-dracaena-theme.el --- A theme inspired by the dragon tree colors -*- lexical-binding: t; -*-

;; Copyright (C) 2025-2026

;; Author: Geralld Borbón <geralldborbon@gmail.com>
;; Created: Jan 06, 2026
;; Keywords: themes, faces, color
;; URL: http://github.com/bormoge/guava-themes
;; Package-Requires: ((emacs "24.1"))
;; SPDX-License-Identifier: GPL-3.0-or-later

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; A theme inspired by the dragon tree colors.
;;
;;; Code:

(require 'guava-themes)

(deftheme guava-themes-dracaena "A theme inspired by the dragon tree colors.")

(let* (
      (dracaena-class '((class color) (min-colors 257)))
      (dracaena-black                     "#000000")
      (dracaena-white                     "#FFFFFF")

      (dracaena-gray                      "#484e4b")

      (dracaena-light-green               "#78be78")
      (dracaena-green                     "#288c23")

      (dracaena-snakeplant-yellow         "#dcd78c")

      (dracaena-light-orange              "#ffb38f")
      (dracaena-orange                    "#e6825f")
      (dracaena-orange-red                "#f06e6e")
      (dracaena-red                       "#b43c50")
      (dracaena-pink                      "#cd6eaf")

      (dracaena-light-brown               "#a89d92")

      (dracaena-light-blue                "#6496f0")
      (dracaena-blue                      "#2d50d5")
      (dracaena-steel-blue                "#4678d2")
      (dracaena-cyan                      "#00d7d7")
      (dracaena-dark-cyan                 "#008787")

      (dracaena-fg-1                      "#becee6")
      (dracaena-fg-2                      "#8292aa")
      (dracaena-bg-1                      "#343a37")
      (dracaena-highlight                 "#252b28")
      (dracaena-shadow                    "#b3b3b3")
      (dracaena-tooltip                   "#ffffe0")
      (dracaena-region-1                  "#883634")
      (dracaena-region-2                  "#005f55")

      (dracaena-error                     "#FF0000")
      (dracaena-warning                   "#f6be14")
      (dracaena-success                   "#29d925")
      (dracaena-change                    "#2d50d5")

      (dracaena-mode-line                 "#b43c50")
      (dracaena-mode-line-inactive        "#5c625f")
      (dracaena-mode-line-modified        "#D29B7D")
      (dracaena-bell                      "#3CB464")

      (dracaena-tab-1                     dracaena-mode-line)
      (dracaena-tab-2                     dracaena-mode-line-inactive)
      (dracaena-tab-3                     dracaena-gray)

      (dracaena-fl-comment                dracaena-green)
      (dracaena-fl-string                 dracaena-snakeplant-yellow)
      (dracaena-fl-keyword                dracaena-light-green)
      (dracaena-fl-builtin                dracaena-red)
      (dracaena-fl-type                   dracaena-pink)
      (dracaena-fl-function-name          dracaena-light-orange)
      (dracaena-fl-variable-name          dracaena-orange-red)
      (dracaena-fl-constant               dracaena-light-blue)
      (dracaena-fl-warning                dracaena-warning)
      (dracaena-fl-punctuation            dracaena-fg-2)
      (dracaena-fl-negation-char          dracaena-orange)

      (dracaena-diff-added                "#5aa05a")
      (dracaena-diff-removed              "#a05a5a")
      (dracaena-diff-refine-added         "#007800")
      (dracaena-diff-refine-removed       "#780000")
      (dracaena-diff-header               "#5a5a5a")
      (dracaena-diff-file-header          "#3c3c3c")
      (dracaena-diff-context              "#828282")
      (dracaena-smerge-base               "#5A5AA0")

      (dracaena-complementary-a-0         "#46E6A6")
      (dracaena-complementary-a-1         "#E64686")

      (dracaena-tetradic-a-0              dracaena-mode-line-modified)
      (dracaena-tetradic-a-1              "#8AD27D")
      (dracaena-tetradic-a-2              "#c57dd2")
      (dracaena-tetradic-a-3              "#7DB4D2")

      (dracaena-tetradic-b-0              "#BA5ACD")
      (dracaena-tetradic-b-1              "#6DCD5A")
      (dracaena-tetradic-b-2              "#CD805A")
      (dracaena-tetradic-b-3              "#5AA7CD"))

  (custom-theme-set-faces
   'guava-themes-dracaena

   ;; built-in faces
   ;; with unique colors

   ;; default
   `(default ((,dracaena-class (:foreground ,dracaena-fg-1 :background ,dracaena-bg-1))))

   ;; error, warning, success
   `(error ((,dracaena-class (:foreground ,dracaena-error :weight bold))))
   `(warning ((,dracaena-class (:foreground ,dracaena-warning :weight bold))))
   `(success ((,dracaena-class (:foreground ,dracaena-success :weight bold))))

   ;; highlight
   `(highlight ((,dracaena-class (:background ,dracaena-highlight))))

   ;; shadow
   `(shadow ((,dracaena-class (:foreground ,dracaena-shadow))))

   ;; tooltip
   `(tooltip ((,dracaena-class (:weight bold :foreground ,dracaena-black :background ,dracaena-tooltip :inherit variable-pitch))))

   ;; region
   `(region ((,dracaena-class (:background ,dracaena-region-1 :extend t))))
   `(secondary-selection ((,dracaena-class (:background ,dracaena-region-2 :extend t))))

   ;; font-lock
   `(font-lock-comment-face ((,dracaena-class (:foreground ,dracaena-fl-comment :weight medium))))
   `(font-lock-string-face ((,dracaena-class (:foreground ,dracaena-fl-string :weight medium))))
   `(font-lock-keyword-face ((,dracaena-class (:foreground ,dracaena-fl-keyword :weight medium))))
   `(font-lock-builtin-face ((,dracaena-class (:foreground ,dracaena-fl-builtin :weight medium))))
   `(font-lock-type-face ((,dracaena-class (:foreground ,dracaena-fl-type :weight medium))))
   `(font-lock-function-name-face ((,dracaena-class (:foreground ,dracaena-fl-function-name :weight medium))))
   `(font-lock-variable-name-face ((,dracaena-class (:foreground ,dracaena-fl-variable-name :weight medium))))
   `(font-lock-constant-face ((,dracaena-class (:foreground ,dracaena-fl-constant :weight medium))))
   `(font-lock-warning-face ((,dracaena-class (:foreground ,dracaena-fl-warning :weight bold))))
   `(font-lock-punctuation-face ((,dracaena-class (:foreground ,dracaena-fl-punctuation :weight medium))))
   `(font-lock-negation-char-face ((,dracaena-class (:foreground ,dracaena-fl-negation-char :weight medium))))

   ;; built-in faces
   ;; with non-unique colors

   ;; cursor
   `(cursor ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-mode-line))))

   ;; fringe
   `(fringe ((,dracaena-class (:foreground ,dracaena-fl-builtin :background ,dracaena-bg-1))))
   `(diff-hl-change ((,dracaena-class (:foreground ,dracaena-change :background ,dracaena-change))))
   `(diff-hl-insert ((,dracaena-class (:foreground ,dracaena-success :background ,dracaena-success))))
   `(diff-hl-delete ((,dracaena-class (:foreground ,dracaena-error :background ,dracaena-error))))

   ;; line-number
   `(line-number ((,dracaena-class (:foreground ,dracaena-fg-1 :inherit default))))
   `(line-number-current-line ((,dracaena-class (:foreground ,dracaena-mode-line :weight bold :inherit (highlight line-number)))))
   `(line-number-minor-tick ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-2 :inherit line-number))))
   `(line-number-major-tick ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-3 :inherit line-number))))

   ;; mode-line
   `(mode-line ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-mode-line
                                              :box ,(if guava-themes-boxed-mode-line
                                                        '(:line-width -1 :style released-button)
                                                      'unspecified)))))
   `(mode-line-inactive ((,dracaena-class (:background ,dracaena-mode-line-inactive :inherit mode-line))))
   `(mode-line-emphasis ((,dracaena-class (:weight bold))))
   `(mode-line-highlight ((,dracaena-class (:foreground unspecified :background unspecified :box (:line-width 2 :color "grey40" :style released-button)))))
   `(guava-themes-visible-bell ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-bell))))

   ;; minibuffer
   `(minibuffer-prompt ((,dracaena-class (:weight bold :foreground ,dracaena-mode-line))))

   ;; borders
   `(vertical-border ((,dracaena-class (:foreground ,dracaena-mode-line))))

   ;; header-line
   `(header-line ((,dracaena-class (:background ,dracaena-tab-1 :inherit mode-line))))
   `(which-func ((,dracaena-class (:weight bold :foreground ,dracaena-mode-line-modified))))

   ;; tab-bar
   `(tab-bar ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-2 :weight bold :inherit mode-line))))
   `(tab-bar-tab ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-1 :inherit tab-bar))))
   `(tab-bar-tab-inactive ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-2 :inherit tab-bar-tab))))

   ;; tab-line
   `(tab-line ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-2 :weight bold :inherit mode-line))))
   `(tab-line-tab ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-2 :inherit tab-line))))
   `(tab-line-tab-current ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-1 :inherit tab-line-tab))))
   `(tab-line-tab-inactive ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-2 :inherit tab-line-tab))))
   `(tab-line-tab-inactive-alternate ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-3 :inherit tab-line-tab))))
   `(tab-line-tab-modified ((,dracaena-class (:foreground ,dracaena-mode-line-modified :weight bold))))
   `(tab-line-tab-special ((,dracaena-class (:slant italic :weight bold))))
   `(tab-line-highlight ((,dracaena-class (:foreground unspecified :background unspecified :box (:line-width 2 :style released-button)))))

   ;; parentheses
   `(show-paren-match ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-bell))))
   `(show-paren-mismatch ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-error :inherit show-paren-match))))

   ;; trailing whitespaces
   `(trailing-whitespace ((,dracaena-class (:background ,dracaena-error))))

   ;; links
   `(link ((,dracaena-class (:foreground ,dracaena-cyan :underline t :weight bold))))
   `(link-visited ((,dracaena-class (:foreground ,dracaena-dark-cyan :underline t :weight bold))))

   ;; outline
   `(outline-1 ((,dracaena-class (:foreground ,dracaena-light-orange :weight medium))))
   `(outline-2 ((,dracaena-class (:foreground ,dracaena-light-green :weight medium))))
   `(outline-3 ((,dracaena-class (:foreground ,dracaena-pink :weight medium))))
   `(outline-4 ((,dracaena-class (:foreground ,dracaena-light-blue :weight medium))))
   `(outline-5 ((,dracaena-class (:inherit outline-1))))
   `(outline-6 ((,dracaena-class (:inherit outline-2))))
   `(outline-7 ((,dracaena-class (:inherit outline-3))))
   `(outline-8 ((,dracaena-class (:inherit outline-4))))

   ;; homoglyph, escape-glyph, nobreak-space (C-x 8 RET "FORM FEED") (C-x 8 RET "NO-BREAK SPACE")
   `(homoglyph ((,dracaena-class (:foreground ,dracaena-cyan))))
   `(escape-glyph ((,dracaena-class (:inherit homoglyph))))
   `(nobreak-space ((,dracaena-class (:box (:line-width (2 . 2)) :inherit homoglyph))))
   `(nobreak-hyphen ((,dracaena-class (:inherit homoglyph))))

   ;; pulse-highlight-start-face
   ;; M-: (pulse-momentary-highlight-region (point-min) (point-max))
   `(pulse-highlight-start-face ((,dracaena-class (:background ,dracaena-steel-blue))))

   ;; help-key-binding
   `(help-key-binding ((,dracaena-class (:foreground ,dracaena-snakeplant-yellow :background "grey19" :box (:line-width (-1 . -1) :color "grey35") :inherit fixed-pitch))))

   ;; diff
   `(diff-added ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-diff-added :extend t :inherit diff-changed))))
   `(diff-removed ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-diff-removed :extend t :inherit diff-changed))))
   `(diff-refine-added ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-diff-refine-added :inherit diff-refine-changed))))
   `(diff-refine-removed ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-diff-refine-removed :inherit diff-refine-changed))))
   `(diff-header ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-diff-header :extend t))))
   `(diff-file-header ((,dracaena-class (:weight bold :foreground ,dracaena-white :background ,dracaena-diff-file-header :extend t))))
   `(diff-context ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-diff-context :extend t))))

   ;; smerge
   `(smerge-lower ((,dracaena-class (:extend t :inherit diff-added))))
   `(smerge-upper ((,dracaena-class (:extend t :inherit diff-removed))))
   `(smerge-markers ((,dracaena-class (:extend t :inherit diff-context))))
   `(smerge-refined-added ((,dracaena-class (:extend t :inherit diff-refine-added))))
   `(smerge-refined-removed ((,dracaena-class (:extend t :inherit diff-refine-removed))))
   `(smerge-base ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-smerge-base :extend t))))

   ;; completions
   `(completions-common-part ((,dracaena-class (:foreground ,dracaena-warning :weight bold))))
   `(completions-first-difference ((,dracaena-class (:foreground ,dracaena-error :weight bold))))

   ;; org-faces
   `(org-todo ((,dracaena-class (:foreground ,dracaena-error :weight bold))))
   `(org-done ((,dracaena-class (:foreground ,dracaena-success :weight bold))))
   `(org-hide ((,dracaena-class (:foreground ,dracaena-bg-1))))
   `(org-table ((,dracaena-class (:foreground ,dracaena-light-orange))))
   `(org-table-header ((,dracaena-class (:inverse-video t :inherit org-table))))
   `(org-date ((,dracaena-class (:foreground ,dracaena-orange))))
   `(org-date-selected ((,dracaena-class (:foreground unspecified :inverse-video t :inherit org-date))))
   `(org-headline-todo ((,dracaena-class (:foreground ,dracaena-tetradic-b-2))))
   `(org-headline-done ((,dracaena-class (:foreground ,dracaena-tetradic-b-1))))
   `(org-document-title ((,dracaena-class (:inherit font-lock-keyword-face))))
   `(org-document-info-keyword ((,dracaena-class (:inherit shadow))))
   `(org-meta-line ((,dracaena-class (:inherit font-lock-comment-face))))

   ;; window-divider
   `(window-divider ((,dracaena-class (:foreground ,dracaena-tab-3))))
   `(window-divider-first-pixel ((,dracaena-class (:inherit window-divider))))
   `(window-divider-last-pixel ((,dracaena-class (:inherit window-divider))))

   ;; isearch (use "M-x isearch-forward-regexp foo-\([0-9]+\)\([a-z]+\)\([0-9]+\)" to check the group faces)
   `(isearch ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tetradic-b-2))))
   `(isearch-fail ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-error))))
   `(lazy-highlight ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tetradic-b-3))))
   `(isearch-group-1 ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tetradic-b-0))))
   `(isearch-group-2 ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tetradic-b-1))))

   ;; replace (use "M-x occur" to check the match face)
   `(query-replace ((,dracaena-class (:inherit isearch))))
   `(match ((,dracaena-class (:inherit lazy-highlight))))

   ;; re-builder
   `(reb-match-0 ((,dracaena-class (:background ,dracaena-tetradic-b-0 :foreground ,dracaena-white))))
   `(reb-match-1 ((,dracaena-class (:background ,dracaena-tetradic-b-1 :foreground ,dracaena-white))))
   `(reb-match-2 ((,dracaena-class (:background ,dracaena-tetradic-b-2 :foreground ,dracaena-white))))
   `(reb-match-3 ((,dracaena-class (:background ,dracaena-tetradic-b-3 :foreground ,dracaena-white))))

   ;; custom
   ;; (progn (setopt custom-raised-buttons nil) (setq mouse-highlight t))
   `(custom-button ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-mode-line :box (:line-width 2 :style released-button)))))
   `(custom-button-pressed ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-mode-line :box (:line-width 2 :style pressed-button)))))
   `(custom-button-mouse ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-3 :box (:line-width 2 :style released-button)))))
   `(custom-button-unraised ((,dracaena-class (:foreground ,dracaena-mode-line :inherit underline))))
   `(custom-button-pressed-unraised ((,dracaena-class (:foreground ,dracaena-bell :inherit custom-button-unraised))))
   `(custom-comment ((,dracaena-class (:background ,dracaena-tab-3))))
   `(custom-variable-tag ((,dracaena-class (:weight bold :foreground ,dracaena-tab-2))))
   `(custom-group-tag ((,dracaena-class (:height 1.2 :inherit (custom-variable-tag variable-pitch)))))
   `(custom-state ((,dracaena-class (:foreground ,dracaena-fl-keyword))))

   ;; widget
   `(widget-field ((,dracaena-class (:background ,dracaena-tab-3 :box (:line-width (1 . -1) :color "gray46") :extend t))))
   `(widget-single-line-field ((,dracaena-class (:background ,dracaena-tab-3))))

   ;; package
   `(package-status-dependency ((,dracaena-class (:inherit (font-lock-string-face)))))

   ;; icomplete
   `(icomplete-selected-match ((,dracaena-class (:weight bold :foreground ,dracaena-mode-line :inherit (highlight)))))
   `(icomplete-first-match ((,dracaena-class (:weight bold :foreground ,dracaena-mode-line :inherit (highlight)))))

   ;; bookmark
   `(bookmark-face ((,dracaena-class (:foreground ,dracaena-mode-line :distant-foreground unspecified))))
   `(bookmark-menu-bookmark ((,dracaena-class (:weight bold :inherit bookmark-face))))

   ;; flymake
   `(flymake-note ((,dracaena-class (:underline (:style wave :color ,dracaena-success)))))
   `(flymake-warning ((,dracaena-class (:underline (:style wave :color ,dracaena-warning)))))
   `(flymake-error ((,dracaena-class (:underline (:style wave :color ,dracaena-error)))))

   ;; eww
   `(eww-valid-certificate ((,dracaena-class (:weight bold :foreground ,dracaena-success))))
   `(eww-invalid-certificate ((,dracaena-class (:weight bold :foreground ,dracaena-error))))
   ;; Example of eww-form-text: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-text ((,dracaena-class (:foreground ,dracaena-fg-1 :background ,dracaena-tab-3 :box (:line-width 1)))))
   ;; Example of eww-form-file: https://html.com/input-type-file/
   `(eww-form-file ((,dracaena-class (:foreground ,dracaena-fg-1 :background ,dracaena-tab-2 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-select: http://savannah.gnu.org/projects/emacs/
   ;; Example of eww-form-select: https://git.kernel.org/pub/scm/editors/uemacs/uemacs.git/
   `(eww-form-select ((,dracaena-class (:foreground ,dracaena-fg-1 :background ,dracaena-tab-1 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-submit: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-submit ((,dracaena-class (:foreground ,dracaena-fg-1 :background ,dracaena-tab-2 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-checkbox: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-checkbox ((,dracaena-class (:foreground ,dracaena-fg-1 :background ,dracaena-tab-1 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-textarea: https://en.wikipedia.org/w/index.php?title=Main_Page&action=edit
   `(eww-form-textarea ((,dracaena-class (:foreground ,dracaena-fg-1 :background ,dracaena-tab-3 :box (:line-width 1 :color ,dracaena-tab-1)))))


   ;; external packages

   ;; elfeed
   `(elfeed-search-tag-face ((,dracaena-class (:foreground ,dracaena-snakeplant-yellow))))
   `(elfeed-search-date-face ((,dracaena-class (:foreground ,dracaena-light-blue))))
   `(elfeed-search-feed-face ((,dracaena-class (:foreground ,dracaena-orange-red))))
   `(elfeed-search-title-face ((,dracaena-class (:foreground ,dracaena-light-brown))))
   `(elfeed-search-unread-title-face ((,dracaena-class (:weight bold :foreground ,dracaena-light-green))))
   `(elfeed-search-filter-face ((,dracaena-class (:weight bold :foreground ,dracaena-tetradic-a-1))))
   `(elfeed-search-last-update-face ((,dracaena-class (:weight bold :foreground ,dracaena-tetradic-a-1))))
   `(elfeed-search-unread-count-face ((,dracaena-class (:weight bold :foreground ,dracaena-tetradic-a-1))))

   `(elfeed-show-header-face ((,dracaena-class (:inherit elfeed-search-date-face))))
   `(elfeed-show-author-face ((,dracaena-class (:inherit elfeed-search-unread-title-face))))
   `(elfeed-show-title-face ((,dracaena-class (:inherit elfeed-search-unread-title-face))))
   `(elfeed-show-date-face ((,dracaena-class (:inherit elfeed-search-feed-face))))
   `(elfeed-show-feed-face ((,dracaena-class (:inherit elfeed-search-feed-face))))
   `(elfeed-show-tags-face ((,dracaena-class (:inherit elfeed-search-tag-face))))

   `(elfeed-log-info-level-face ((,dracaena-class (:foreground ,dracaena-success))))
   `(elfeed-log-debug-level-face ((,dracaena-class (:foreground ,dracaena-change))))
   `(elfeed-log-warn-level-face ((,dracaena-class (:foreground ,dracaena-warning))))
   `(elfeed-log-error-level-face ((,dracaena-class (:foreground ,dracaena-error))))

   ;; doom-modeline
   ;; doom-modeline-buffer-file-name-style
   `(doom-modeline-project-name ((,dracaena-class (:foreground ,dracaena-tetradic-a-3 :inherit (doom-modeline bold italic)))))
   `(doom-modeline-project-dir ((,dracaena-class (:foreground ,dracaena-tetradic-a-3 :inherit (doom-modeline bold)))))
   `(doom-modeline-project-root-dir ((,dracaena-class (:foreground ,dracaena-tetradic-a-2 :inherit (doom-modeline bold)))))
   `(doom-modeline-project-parent-dir ((,dracaena-class (:foreground ,dracaena-tetradic-a-2 :inherit (doom-modeline bold)))))
   `(doom-modeline-buffer-minor-mode ((,dracaena-class (:foreground ,dracaena-tetradic-a-1 :inherit (doom-modeline)))))
   `(doom-modeline-buffer-modified ((,dracaena-class (:foreground ,dracaena-tetradic-a-0 :inherit (doom-modeline warning bold)))))

   ;; corfu
   `(corfu-default ((,dracaena-class (:foreground ,dracaena-fg-1 :background ,dracaena-bg-1))))
   `(corfu-current ((,dracaena-class (:foreground unspecified :background unspecified :extend t :inherit highlight))))
   `(corfu-bar ((,dracaena-class (:background ,dracaena-shadow))))
   `(corfu-border ((,dracaena-class (:background ,dracaena-shadow))))

   ;; orderless
   `(orderless-match-face-0 ((,dracaena-class (:foreground ,dracaena-tetradic-b-0 :weight bold))))
   `(orderless-match-face-1 ((,dracaena-class (:foreground ,dracaena-tetradic-b-1 :weight bold))))
   `(orderless-match-face-2 ((,dracaena-class (:foreground ,dracaena-tetradic-b-2 :weight bold))))
   `(orderless-match-face-3 ((,dracaena-class (:foreground ,dracaena-tetradic-b-3 :weight bold))))

   ;; prescient (vertico-prescient-enable-filtering, corfu-prescient-enable-filtering)
   `(prescient-primary-highlight ((,dracaena-class (:foreground ,dracaena-complementary-a-0 :weight bold))))
   `(prescient-secondary-highlight ((,dracaena-class (:foreground ,dracaena-complementary-a-1 :underline t :weight bold))))

   ;; envrc
   `(envrc-mode-line-error-face ((,dracaena-class (:inherit error))))
   `(envrc-mode-line-denied-face ((,dracaena-class (:inherit warning))))
   `(envrc-mode-line-on-face ((,dracaena-class (:inherit success))))
   `(envrc-mode-line-none-face ((,dracaena-class (:inherit warning))))
   `(envrc-mode-line-running-face ((,dracaena-class (:inherit warning))))

   ;; devdocs
   `(devdocs-code-block ((,dracaena-class (:weight bold :background ,dracaena-highlight :extend t))))

   ;; pdf-tools
   `(pdf-view-region ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tetradic-b-3 :inherit region))))

   ;; idle-highlight
   `(idle-highlight ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-fl-builtin :inherit region))))

   ;; keycast
   `(keycast-command ((,dracaena-class (:weight bold))))
   `(keycast-key ((,dracaena-class (:foreground ,dracaena-white :background ,dracaena-tab-3 :box (:line-width -3 :style released-button) :inherit fixed-pitch))))

   ;; nerd-icons
   ;; nerd-icons-completion
   `(nerd-icons-completion-dir-face ((,dracaena-class (:foreground unspecified :inherit font-lock-function-name-face))))))

(provide-theme 'guava-themes-dracaena)

;; Local Variables:
;; no-byte-compile: t
;; indent-tabs-mode: nil
;; eval: (when (featurep 'package-lint-flymake) (package-lint-flymake-setup))
;; End:

;;; guava-themes-dracaena-theme.el ends here
