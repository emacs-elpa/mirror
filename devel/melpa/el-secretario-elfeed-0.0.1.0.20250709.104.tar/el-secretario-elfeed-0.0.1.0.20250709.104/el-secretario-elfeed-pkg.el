;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-secretario-elfeed" "0.0.1.0.20250709.104"
  "Add elfeed feeds to el-secretario."
  '((emacs         "27.1")
    (el-secretario "0.0.1")
    (elfeed        "3.4.1"))
  :url "https://git.sr.ht/~zetagon/el-secretario"
  :commit "77bfa47532cfa06ad6d1627dbc61e60996b064e4"
  :revdesc "77bfa47532cf"
  :keywords '("convenience")
  :authors '(("Leo Okawa Ericson" . "https://sr.ht/~zetagon"))
  :maintainers '(("Leo Okawa Ericson" . "git@relevant-information.com")))
