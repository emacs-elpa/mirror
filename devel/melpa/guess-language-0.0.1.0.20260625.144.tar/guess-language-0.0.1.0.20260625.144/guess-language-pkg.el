;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guess-language" "0.0.1.0.20260625.144"
  "Robust automatic language detection."
  '((cl-lib "0.5")
    (emacs  "24"))
  :url "https://github.com/tmalsburg/guess-language.el"
  :commit "f7f74d50b11e090d7543daa0dfbf273820c006c7"
  :revdesc "f7f74d50b11e"
  :keywords '("wp")
  :authors '(("Titus von der Malsburg" . "malsburg@posteo.de"))
  :maintainers '(("Titus von der Malsburg" . "malsburg@posteo.de")))
