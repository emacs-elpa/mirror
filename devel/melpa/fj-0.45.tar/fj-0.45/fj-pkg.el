;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "0.45"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (compat    "31")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "fc8f28f5f62a2f9f88e6215bd38ff409f049b4e6"
  :revdesc "fc8f28f5f62a"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
