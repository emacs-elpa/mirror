;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pixiv-novel-mode" "0.0.3.0.20160220.2"
  "Major mode for pixiv novel."
  ()
  :url "https://github.com/zonuexe/pixiv-novel-mode.el"
  :commit "0d1ca524d92b91f20a7105402a773bc21779b434"
  :revdesc "0d1ca524d92b"
  :keywords '("novel" "pixiv")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
