;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "list-packages-ext" "0.1.0.0.20151115.5"
  "Extras for list-packages."
  '((s               "1.6.0")
    (ht              "1.5.0")
    (persistent-soft "0.8.6"))
  :url "https://github.com/laynor/list-packages-ext"
  :commit "b4dd644e4369c9aa66f5bb8895ea49ebbfd0a27a"
  :revdesc "b4dd644e4369"
  :keywords '("convenience" "tools")
  :authors '(("Alessandro Piras" . "laynor@gmail.com"))
  :maintainers '(("Alessandro Piras" . "laynor@gmail.com")))
