;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient-dwim" "1.0.0.0.20261122.42"
  "Useful preset transient commands."
  '((emacs     "28.1")
    (transient "0.13.8"))
  :url "https://github.com/conao3/transient-dwim.el"
  :commit "015cb4ea4d9f8b25878347408fd70798348be97b"
  :revdesc "015cb4ea4d9f"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
