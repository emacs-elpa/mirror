;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeatable-motion" "0.2.0.20170620.1"
  "Make repeatable versions of motions."
  '((emacs "24"))
  :url "https://github.com/willghatch/emacs-repeatable-motion"
  :commit "77aa35b27c8a76dc8deef87c9f71ef7e6fd289ee"
  :revdesc "77aa35b27c8a"
  :keywords '("motion" "repeatable")
  :authors '(("William Hatch" . "willghatch@gmail.com"))
  :maintainers '(("William Hatch" . "willghatch@gmail.com")))
