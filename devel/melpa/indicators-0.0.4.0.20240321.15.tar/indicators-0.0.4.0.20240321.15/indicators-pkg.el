;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indicators" "0.0.4.0.20240321.15"
  "Display the buffer relative location of line in the fringe."
  '((dash   "2.13.0")
    (cl-lib "0.5.0"))
  :url "https://github.com/Fuco1/indicators.el"
  :commit "9b80c4545fc5c50332b2748c30d492517ae583b5"
  :revdesc "9b80c4545fc5"
  :keywords '("fringe" "frames")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
