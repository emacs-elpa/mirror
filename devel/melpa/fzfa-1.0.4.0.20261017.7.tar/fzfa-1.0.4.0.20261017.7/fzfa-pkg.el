;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0.4.0.20261017.7"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.7"))
  :url "https://github.com/jojojames/fzfa"
  :commit "8afe418c42e42a8f4aff324badc87099e7522497"
  :revdesc "1.0.4-7-g8afe418c42e4"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
