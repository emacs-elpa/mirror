;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "0.13.4.0.20260617.1"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "9d103f338fb9fd4506a0f1651c483209ab838f49"
  :revdesc "v0.13.4-1-g9d103f338fb9"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
