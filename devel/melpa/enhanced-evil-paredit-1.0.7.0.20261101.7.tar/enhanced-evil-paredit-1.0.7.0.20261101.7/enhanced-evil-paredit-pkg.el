;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "1.0.7.0.20261101.7"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "58374ff5b0ed8259cdee5c7747b5db648348b5c7"
  :revdesc "1.0.7-7-g58374ff5b0ed"
  :keywords '("convenience" "lisp"))
