;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "10.0.0.0.20261009.49"
  "LSP mode."
  '((emacs         "29.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "a6c47c7867955fea450f833ba4f38b93411d7ea5"
  :revdesc "a6c47c786795"
  :keywords '("languages"))
