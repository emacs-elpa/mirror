;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphql-ts-mode" "0.1.0.0.20240105.6"
  "Tree-sitter support for GraphQL."
  '((emacs "29.1"))
  :url "https://sr.ht/~joram/graphql-ts-mode/"
  :commit "e933f235408ea195762700fd07c2d828e8f09aac"
  :revdesc "e933f235408e"
  :keywords '("languages" "graphql" "tree-sitter")
  :authors '(("Joram Schrijver" . "i@joram.io"))
  :maintainers '(("Joram Schrijver" . "i@joram.io")))
