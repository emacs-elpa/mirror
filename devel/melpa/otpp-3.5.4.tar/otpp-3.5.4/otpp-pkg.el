;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "3.5.4"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "ef1460cf7cd978554f894325303a46e629ea2633"
  :revdesc "ef1460cf7cd9"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
