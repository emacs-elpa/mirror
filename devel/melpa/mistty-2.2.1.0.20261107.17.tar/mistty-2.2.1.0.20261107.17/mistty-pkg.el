;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "2.2.1.0.20261107.17"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "8c71878159c75eacc9399be3d822d7d4b7c88724"
  :revdesc "8c71878159c7"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
