;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "1.0.7"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "2535c7cda4d196d2c4f6311b27cff88aefabb14f"
  :revdesc "1.0.7-0-g2535c7cda4d1"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
