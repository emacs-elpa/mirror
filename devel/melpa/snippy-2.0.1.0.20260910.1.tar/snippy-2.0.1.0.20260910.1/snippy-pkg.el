;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snippy" "2.0.1.0.20260910.1"
  "Vscode snippet support with Yasnippet."
  '((emacs     "30.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/MiniApollo/snippy"
  :commit "2cacd95fb8d5f6c3c5ae69b2508248bfd92ba64b"
  :revdesc "v2.0.1-1-g2cacd95fb8d5"
  :keywords '("convenience" "emulations")
  :authors '(("Mark Surmann" . "surmannmark@gmail.com"))
  :maintainers '(("Mark Surmann" . "surmannmark@gmail.com")))
