;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unidecode" "0.1.0.20201213.22"
  "Transliterate Unicode to ASCII."
  ()
  :url "https://github.com/sindikat/unidecode"
  :commit "525b51b38f5b0435642005957740fe22ecb2a53c"
  :revdesc "525b51b38f5b"
  :authors '(("sindikat" . "sindikatatmail36dotnet"))
  :maintainers '(("John Mastro" . "john.b.mastro@gmail.com")))
