;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-gometalinter" "0.1.4.0.20180424.9"
  "Flycheck checker for gometalinter."
  '((emacs    "24")
    (flycheck "0.22"))
  :url "https://github.com/favadi/flycheck-gometalinter"
  :commit "422f6e4b77b27fd7370f0c88437ac5072c9d3413"
  :revdesc "v0.1.4-9-g422f6e4b77b2"
  :keywords '("convenience" "tools" "go")
  :authors '(("Diep Pham" . "me@favadi.com"))
  :maintainers '(("Diep Pham" . "me@favadi.com")))
