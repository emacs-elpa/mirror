;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rand-theme" "0.1.0.20151219.9"
  "Random Emacs theme at start-up!."
  '((cl-lib "0.5"))
  :url "https://github.com/gopar/rand-theme"
  :commit "65a00e5c5150f857aa96803b68f50bc8da0215b7"
  :revdesc "65a00e5c5150")
