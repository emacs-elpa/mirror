;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browsel" "0.94"
  "WebSocket bridge to a Chrome/Firefox extension."
  '((emacs     "27.1")
    (websocket "1.13")
    (org       "9.8"))
  :url "https://github.com/dmgerman/browsel"
  :commit "c232fb6acfb6607f9df08153cbb82585636c6f65"
  :revdesc "c232fb6acfb6"
  :keywords '("comm" "tools" "browser" "org")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
