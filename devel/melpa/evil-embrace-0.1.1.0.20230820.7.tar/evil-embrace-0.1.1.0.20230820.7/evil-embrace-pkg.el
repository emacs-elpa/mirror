;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-embrace" "0.1.1.0.20230820.7"
  "Evil integration of embrace.el."
  '((emacs         "24.4")
    (embrace       "0.1.0")
    (evil-surround "0"))
  :url "https://github.com/cute-jumper/evil-embrace.el"
  :commit "3081d37811b6a3dfaaf01d578c7ab7a746c6064d"
  :revdesc "3081d37811b6"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
