;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esh-help" "1.0.1.0.20190905.2"
  "Add some help functions and support for Eshell."
  '((dash "1.4.0"))
  :url "https://github.com/tom-tan/esh-help/"
  :commit "417673ed18a983930a66a6692dbfb288a995cb80"
  :revdesc "v1.0.1-2-g417673ed18a9"
  :keywords '("eshell" "extensions")
  :authors '(("Tomoya Tanjo" . "ttanjo@gmail.com"))
  :maintainers '(("Tomoya Tanjo" . "ttanjo@gmail.com")))
