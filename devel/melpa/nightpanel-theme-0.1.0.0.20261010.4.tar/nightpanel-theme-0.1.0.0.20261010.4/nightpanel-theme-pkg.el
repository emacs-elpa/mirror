;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nightpanel-theme" "0.1.0.0.20261010.4"
  "Saab instrument cluster colorscheme."
  '((emacs "24.1"))
  :url "https://github.com/gregfelice/nightpanel-theme"
  :commit "9835406644e0f6ab99619c86925f3182df4db9f7"
  :revdesc "v0.1.0-4-g9835406644e0"
  :keywords '("faces" "theme")
  :authors '(("Greg Felice" . "gregfelice@gmail.com"))
  :maintainers '(("Greg Felice" . "gregfelice@gmail.com")))
