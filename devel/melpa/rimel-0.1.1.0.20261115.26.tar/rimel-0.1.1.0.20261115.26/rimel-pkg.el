;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "0.1.1.0.20261115.26"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.11"))
  :url "https://github.com/emacs-rime/rimel"
  :commit "fc1c405b9f4756bcf7cef8d115fdc99c7e0a7155"
  :revdesc "fc1c405b9f47"
  :keywords '("convenience" "chinese" "input-method" "rime"))
