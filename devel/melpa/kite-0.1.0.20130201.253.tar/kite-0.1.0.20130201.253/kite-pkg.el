;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kite" "0.1.0.20130201.253"
  "WebKit inspector front-end."
  '((json      "1.2")
    (websocket "0.93.1"))
  :url "https://github.com/jscheid/kite"
  :commit "7ed74d1147a6ddd152d3da65dc30df3517d53144"
  :revdesc "7ed74d1147a6"
  :keywords '("tools")
  :authors '(("Julian Scheid" . "julians37@gmail.com"))
  :maintainers '(("Julian Scheid" . "julians37@gmail.com")))
