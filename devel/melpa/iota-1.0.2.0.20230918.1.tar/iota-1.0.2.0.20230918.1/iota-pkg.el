;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iota" "1.0.2.0.20230918.1"
  "Replace marker with increasing integers."
  ()
  :url "https://git.sr.ht/~mango/iota.el"
  :commit "c065c087567f074bff639eb12fa53018654b8ce2"
  :revdesc "v1.0.2-1-gc065c087567f"
  :keywords '("abbrev" "data" "wp")
  :authors '(("Thomas Voss" . "mail@thomasvoss.com"))
  :maintainers '(("Thomas Voss" . "mail@thomasvoss.com")))
