;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scf-mode" "0.1.0.20151122.7"
  "Shorten file-names in compilation type buffers."
  ()
  :url "https://github.com/lewang/scf-mode"
  :commit "dbfcdcd89034f208d65e181af58e0d73ad09f8b2"
  :revdesc "dbfcdcd89034"
  :keywords '("compilation"))
