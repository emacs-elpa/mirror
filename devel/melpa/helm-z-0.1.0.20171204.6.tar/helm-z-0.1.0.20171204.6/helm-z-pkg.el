;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-z" "0.1.0.20171204.6"
  "Show z directory list with helm.el support."
  '((helm "1.0"))
  :url "https://github.com/yynozk/helm-z"
  :commit "37212220bebea8b9c238cb1bbacd8332b7f26c03"
  :revdesc "37212220bebe"
  :authors '(("yynozk" . "yynozk@gmail.com"))
  :maintainers '(("yynozk" . "yynozk@gmail.com")))
