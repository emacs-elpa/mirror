;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "numbex" "0.5.1"
  "Manage numbered examples."
  '((emacs "26.1"))
  :url "https://github.com/enricoflor/numbex"
  :commit "b64f51388726363fc0d154219e2270c6b9c5ce19"
  :revdesc "b64f51388726"
  :authors '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers '(("Enrico Flor" . "enrico@eflor.net")))
