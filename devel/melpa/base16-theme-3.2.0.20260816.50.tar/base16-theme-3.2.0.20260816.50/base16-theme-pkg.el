;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "3.2.0.20260816.50"
  "A set of base16 themes for your favorite editor."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "17acf7f6efd7a73dadb902d2f5586aec4e32051e"
  :revdesc "17acf7f6efd7"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
