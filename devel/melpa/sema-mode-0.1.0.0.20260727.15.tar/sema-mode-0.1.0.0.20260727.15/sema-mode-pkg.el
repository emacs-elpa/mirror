;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sema-mode" "0.1.0.0.20260727.15"
  "Major mode for editing Sema files."
  '((emacs "25.1"))
  :url "https://github.com/sema-lisp/emacs-sema"
  :commit "c0065adcb866d3d132c9034d89e8fa6a20b06a8f"
  :revdesc "c0065adcb866"
  :keywords '("languages" "lisp")
  :authors '(("Helge Sverre" . "helge.sverre@gmail.com"))
  :maintainers '(("Helge Sverre" . "helge.sverre@gmail.com")))
