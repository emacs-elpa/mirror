;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "0.14.3.0.20260906.2"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "2a59373ddf252c78e8d6b25b094458f67aba9e10"
  :revdesc "2a59373ddf25")
