;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-html-angular" "1.5.0.0.20151225.7"
  "Auto complete angular15 data for `ac-html' and `company-web'."
  '((web-completion-data "0.1"))
  :url "https://github.com/osv/ac-html-bootstrap"
  :commit "6bafe09afe03112ca4183d58461c1a6f6c2b3c67"
  :revdesc "6bafe09afe03"
  :keywords '("html" "auto-complete" "angular")
  :authors '(("Olexandr Sydorchuk" . "olexandr.syd@gmail.com"))
  :maintainers '(("Olexandr Sydorchuk" . "olexandr.syd@gmail.com")))
