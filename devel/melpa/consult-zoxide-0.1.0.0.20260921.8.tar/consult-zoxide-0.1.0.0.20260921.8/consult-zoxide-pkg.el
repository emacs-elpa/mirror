;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-zoxide" "0.1.0.0.20260921.8"
  "Jump to zoxide directories with Consult."
  '((emacs   "29.1")
    (consult "2.0"))
  :url "https://github.com/agzam/consult-zoxide.el"
  :commit "4db0560e217dc478b206dc55d0670566ec341045"
  :revdesc "4db0560e217d"
  :keywords '("convenience" "files" "tools")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
