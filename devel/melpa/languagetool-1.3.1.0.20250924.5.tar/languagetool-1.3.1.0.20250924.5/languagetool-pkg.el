;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "languagetool" "1.3.1.0.20250924.5"
  "LanguageTool integration for grammar and spell check."
  '((emacs "27.1"))
  :url "https://github.com/PillFall/Emacs-LanguageTool.el"
  :commit "fa3c08c369bf53f3311f1f365b54271cf126e4dd"
  :revdesc "v1.3.1-5-gfa3c08c369bf"
  :keywords '("grammar" "text" "docs" "tools" "convenience" "checker")
  :authors '(("Joar Buitrago" . "jebuitragoc@unal.edu.co"))
  :maintainers '(("Joar Buitrago" . "jebuitragoc@unal.edu.co")))
