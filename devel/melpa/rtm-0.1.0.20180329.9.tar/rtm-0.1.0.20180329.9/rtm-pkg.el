;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rtm" "0.1.0.20180329.9"
  "An elisp implementation of the Remember The Milk API."
  '((cl-lib "1.0"))
  :url "https://github.com/pmiddend/emacs-rtm"
  :commit "3e3d09387cb84801343ecca8fb02e82f213e7bbe"
  :revdesc "3e3d09387cb8"
  :keywords '("remember" "the" "milk" "productivity" "todo")
  :authors '(("Friedrich Delgado Friedrichs" . "frie...@nomaden.org"))
  :maintainers '(("Friedrich Delgado Friedrichs" . "frie...@nomaden.org")))
