;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imgbb" "20180518.0.20180609.1"
  "Simple image upload client for imgbb.com."
  '((emacs   "24")
    (request "0.3.0"))
  :url "https://github.com/ecraven/imgbb.el"
  :commit "a524a46263835aa474f908827ebab4e8fa586001"
  :revdesc "a524a4626383"
  :keywords '("extensions")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Peter" . "craven@gmx.net")))
