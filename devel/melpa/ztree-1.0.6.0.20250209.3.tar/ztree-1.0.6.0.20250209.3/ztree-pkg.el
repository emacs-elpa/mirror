;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ztree" "1.0.6.0.20250209.3"
  "Text mode directory tree."
  '((cl-lib "0"))
  :url "https://github.com/fourier/ztree"
  :commit "9905f1be006fe02417fc6598be4990746053bbec"
  :revdesc "9905f1be006f"
  :keywords '("files" "tools")
  :authors '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com"))
  :maintainers '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com")))
