;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete" "1.5.1.0.20251231.127"
  "Auto Completion for GNU Emacs."
  '((emacs "25.1")
    (popup "0.5.8"))
  :url "https://github.com/auto-complete/auto-complete"
  :commit "07f9915e08342410b933145d7934998709753a29"
  :revdesc "v1.5.1-127-g07f9915e0834"
  :keywords '("completion" "convenience")
  :authors '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
