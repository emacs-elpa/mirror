;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "4.2.2"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.0")
    (closql   "2.4")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "63bf2ab384c0f96f344492d151549c5b95b6830f"
  :revdesc "v4.2.2-0-g63bf2ab384c0"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
