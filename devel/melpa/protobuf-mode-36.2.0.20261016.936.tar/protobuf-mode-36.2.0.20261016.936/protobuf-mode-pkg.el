;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "protobuf-mode" "36.2.0.20261016.936"
  "Major mode for editing protocol buffers."
  ()
  :url "https://github.com/protocolbuffers/protobuf"
  :commit "a19cce4fe0e6db8726c025fc3dae1967ea265fd0"
  :revdesc "a19cce4fe0e6"
  :keywords '("google" "protobuf" "languages")
  :authors '(("Alexandre Vassalotti" . "alexandre@peadrop.com"))
  :maintainers '(("Alexandre Vassalotti" . "alexandre@peadrop.com")))
