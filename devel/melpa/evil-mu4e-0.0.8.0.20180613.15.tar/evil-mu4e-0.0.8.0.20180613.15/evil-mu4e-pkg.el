;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-mu4e" "0.0.8.0.20180613.15"
  "Evil-based key bindings for mu4e."
  '((emacs "24.4")
    (evil  "1.2.10"))
  :url "https://github.com/JorisE/evil-mu4e"
  :commit "f4b387ccbd2c49f3bbb5401e93bfcc050ca128ef"
  :revdesc "f4b387ccbd2c"
  :authors '(("Joris Engbers" . "info@jorisengbers.nl"))
  :maintainers '(("Joris Engbers" . "info@jorisengbers.nl")))
