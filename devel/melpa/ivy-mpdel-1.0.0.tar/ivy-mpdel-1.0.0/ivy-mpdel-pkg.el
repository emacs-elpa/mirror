;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-mpdel" "1.0.0"
  "Ivy interface to navigate MPD."
  '((emacs    "25.1")
    (ivy      "0.10.0")
    (libmpdel "1.0.0")
    (mpdel    "1.0.0"))
  :url "https://gitlab.petton.fr/mpdel/ivy-mpdel"
  :commit "a42dcc943914c71975c115195d38c739f25e475c"
  :revdesc "v1.0.0-0-ga42dcc943914"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
