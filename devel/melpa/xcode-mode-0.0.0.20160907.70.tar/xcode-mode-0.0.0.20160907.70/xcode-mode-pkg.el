;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xcode-mode" "0.0.0.20160907.70"
  "A minor mode for emacs to perform Xcode like actions."
  '((emacs            "24.4")
    (s                "1.10.0")
    (dash             "2.11.0")
    (multiple-cursors "1.0.0"))
  :url "https://github.com/nicklanasa/xcode-mode"
  :commit "5b5f0a4f505d44840a4924b24e3ef73b8528d98b"
  :revdesc "5b5f0a4f505d"
  :keywords '("conveniences")
  :authors '(("Nickolas Lanasa" . "nick@nytekproductions.com"))
  :maintainers '(("Nickolas Lanasa" . "nick@nytekproductions.com")))
