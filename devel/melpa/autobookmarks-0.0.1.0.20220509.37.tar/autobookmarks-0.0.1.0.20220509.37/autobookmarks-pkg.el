;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autobookmarks" "0.0.1.0.20220509.37"
  "Save recently visited files and buffers."
  '((dash   "2.10.0")
    (cl-lib "0.5"))
  :url "https://github.com/Fuco1/autobookmarks"
  :commit "8acd6f182181e23257e01c1b5cf90b872507a74d"
  :revdesc "8acd6f182181"
  :keywords '("files")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
