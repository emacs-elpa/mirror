;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tempus" "0.0.2.0.20260601.1"
  "Enhance Org time tracking."
  '((emacs "27.1"))
  :url "https://github.com/rul/org-tempus"
  :commit "b5562ca4e3344dde465b5cbd86275336aeac44df"
  :revdesc "b5562ca4e334"
  :keywords '("calendar")
  :authors '(("Raul Benencia" . "id@rbenencia.name"))
  :maintainers '(("Raul Benencia" . "id@rbenencia.name")))
