;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jq-mode" "0.5.0.0.20260821.19"
  "Edit jq scripts."
  '((emacs "25.1"))
  :url "https://github.com/ljos/jq-mode"
  :commit "558f2af06c34f12c52097f8db746169c28c35484"
  :revdesc "558f2af06c34"
  :authors '(("Bjarte Johansen" . "BjartedotJohansenatgmaildotcom"))
  :maintainers '(("Bjarte Johansen" . "BjartedotJohansenatgmaildotcom")))
