;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redtt" "0.0.1.0.20181121.45"
  "Major mode for editing redtt proofs."
  '((emacs "25.3"))
  :url "https://github.com/RedPRL/redtt"
  :commit "c95d1a0787fb92eb011df690b4bdc1029a611c0b"
  :revdesc "c95d1a0787fb"
  :keywords '("languages")
  :authors '(("Jonathan Sterling" . "jon@jonmsterling.com"))
  :maintainers '(("Jonathan Sterling" . "jon@jonmsterling.com")))
