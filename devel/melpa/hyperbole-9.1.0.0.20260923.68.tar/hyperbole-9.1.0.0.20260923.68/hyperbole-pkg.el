;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.1.0.0.20260923.68"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "fdb4b9df16a09d743995b45385ac37420b6e7673"
  :revdesc "fdb4b9df16a0"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")
                 ("Mats Lidell" . "matsl@gnu.org")))
