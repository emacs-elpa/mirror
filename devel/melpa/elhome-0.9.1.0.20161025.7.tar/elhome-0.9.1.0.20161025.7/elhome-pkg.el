;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elhome" "0.9.1.0.20161025.7"
  "A framework for a \"home\" Emacs configuration."
  '((initsplit "20120630"))
  :url "https://github.com/demyanrogozhin/elhome"
  :commit "e789e806469af3e9705f72298683c21f6c3a516d"
  :revdesc "e789e806469a"
  :keywords '("lisp")
  :authors '(("Dave Abrahams" . "dave@boostpro.com"))
  :maintainers '(("Demyan Rogozhin" . "demyan.rogozhin@gmail.com")))
