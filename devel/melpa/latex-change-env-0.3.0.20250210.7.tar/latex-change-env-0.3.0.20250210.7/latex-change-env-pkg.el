;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-change-env" "0.3.0.20250210.7"
  "Change in and out of LaTeX environments."
  '((emacs  "27.1")
    (auctex "13.1"))
  :url "https://github.com/slotThe/change-env"
  :commit "c39f8fbc6c378e6969bd94a19213f548c88a949c"
  :revdesc "c39f8fbc6c37"
  :keywords '("convenience" "tex")
  :authors '(("Tony Zorman" . "soliditsallgood@mailbox.org"))
  :maintainers '(("Tony Zorman" . "soliditsallgood@mailbox.org")))
