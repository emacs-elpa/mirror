;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lavenderless-theme" "0.2.0.20201222.22"
  "A mostly colorless version of lavender-theme."
  '((colorless-themes "0.2"))
  :url "https://git.sr.ht/~lthms/colorless-themes.el"
  :commit "1b2a507b3b7f9559c944af8fc7531a60b38ae0c3"
  :revdesc "0.2-22-g1b2a507b3b7f"
  :keywords '("faces" "theme")
  :authors '(("Thomas Letan" . "lthms@soap.coffee"))
  :maintainers '(("Thomas Letan" . "lthms@soap.coffee")))
