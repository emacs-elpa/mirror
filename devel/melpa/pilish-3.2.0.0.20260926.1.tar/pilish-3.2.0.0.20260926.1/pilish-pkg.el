;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.2.0.0.20260926.1"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.4.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "e1165f7e24a5adb745aa7f6d04f1f4c401440771"
  :revdesc "v3.2.0-1-ge1165f7e24a5"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
