;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hel" "0.13.0.0.20261102.15"
  "Helix Emulation Layer."
  '((emacs        "29.1")
    (dash         "2.19.1")
    (avy          "0.5.0")
    (pcre2el      "1.12")
    (ultra-scroll "0.6"))
  :url "https://github.com/helheim-emacs/hel"
  :commit "005dbdf7802737a5e064a97de3b45dfd191d6ba2"
  :revdesc "005dbdf78027"
  :authors '(("Yuriy Artemyev" . "anuvyklack@gmail.com"))
  :maintainers '(("Yuriy Artemyev" . "anuvyklack@gmail.com")))
