;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-ansible-lint" "1.0.7.0.20260826.2"
  "A Flymake backend for ansible-lint."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/flymake-ansible-lint.el"
  :commit "1d16cfe3340fd6215f4d39e38ab032d6cd31a45d"
  :revdesc "1.0.7-2-g1d16cfe3340f"
  :keywords '("tools" "languages")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
