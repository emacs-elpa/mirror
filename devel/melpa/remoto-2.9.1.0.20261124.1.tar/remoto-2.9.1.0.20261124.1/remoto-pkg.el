;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "2.9.1.0.20261124.1"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "cd8ec5d083091ad164f8260a6bd05453e5dd73db"
  :revdesc "2.9.1-1-gcd8ec5d08309"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
