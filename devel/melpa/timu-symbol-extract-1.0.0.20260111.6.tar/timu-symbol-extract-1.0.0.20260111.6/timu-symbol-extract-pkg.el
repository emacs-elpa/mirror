;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-symbol-extract" "1.0.0.20260111.6"
  "Extract symbols to org table."
  '((emacs "28.1"))
  :url "https://gitlab.com/aimebertrand/timu-symbol-extract"
  :commit "5f3b778eb7446ca2b366daacb9f1e71f1d89e097"
  :revdesc "5f3b778eb744"
  :keywords '("defaults" "tools" "helper" "elisp")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
