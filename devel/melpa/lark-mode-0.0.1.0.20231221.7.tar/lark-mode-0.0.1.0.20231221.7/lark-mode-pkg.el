;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lark-mode" "0.0.1.0.20231221.7"
  "Major mode for editing Lark parser code."
  '((emacs "24.3"))
  :url "https://github.com/taquangtrung/lark-mode"
  :commit "0a0724b0f64d433d81f90ba8f86e618f8c33522a"
  :revdesc "0a0724b0f64d"
  :keywords '("languages"))
