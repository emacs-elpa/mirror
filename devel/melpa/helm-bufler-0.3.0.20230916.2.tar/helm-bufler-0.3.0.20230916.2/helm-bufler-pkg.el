;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bufler" "0.3.0.20230916.2"
  "Helm source for Bufler."
  '((emacs  "26.3")
    (bufler "0.2-pre")
    (helm   "1.9.4"))
  :url "https://github.com/alphapapa/bufler.el"
  :commit "938b186f09739196fe0e65e8e370f90b47008054"
  :revdesc "v0.3-2-g938b186f0973"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
