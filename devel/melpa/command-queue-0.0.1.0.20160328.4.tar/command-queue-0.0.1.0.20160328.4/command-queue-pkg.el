;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "command-queue" "0.0.1.0.20160328.4"
  "Shell command queue."
  '((emacs "24.3"))
  :url "https://github.com/Yuki-Inoue/command-queue"
  :commit "f327c6f852592229a755ec6de0c62c6aeafd6659"
  :revdesc "f327c6f85259"
  :authors '(("Yuki INOUE" . "inouetakahirokiatgmail.com"))
  :maintainers '(("Yuki INOUE" . "inouetakahirokiatgmail.com")))
