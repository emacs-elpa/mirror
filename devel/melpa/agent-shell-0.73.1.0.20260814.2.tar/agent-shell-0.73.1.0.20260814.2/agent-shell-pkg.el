;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.73.1.0.20260814.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "5afffb8ba9bc89137ce1f6c14b533a5e37c9b9ab"
  :revdesc "5afffb8ba9bc")
