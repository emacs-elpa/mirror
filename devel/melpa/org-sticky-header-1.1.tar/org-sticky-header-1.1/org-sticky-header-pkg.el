;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-sticky-header" "1.1"
  "Show off-screen Org heading at top of window."
  '((emacs "24.4")
    (org   "8.3.5"))
  :url "https://github.com/alphapapa/org-sticky-header"
  :commit "79136b8c54c48547ba8a07a72a9790cb8e23ecbd"
  :revdesc "1.1-0-g79136b8c54c4"
  :keywords '("hypermedia" "outlines" "org")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
