;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-clock-today" "0.0.2.0.20220918.2"
  "Show total clocked time of the current day in the mode line."
  '((emacs "25"))
  :url "https://github.com/mallt/org-clock-today-mode"
  :commit "b73cca120eb64538ab0666892a8b97b6d65b4d6b"
  :revdesc "b73cca120eb6"
  :authors '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com"))
  :maintainers '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com")))
