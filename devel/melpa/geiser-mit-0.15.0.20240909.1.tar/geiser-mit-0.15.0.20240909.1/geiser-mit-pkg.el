;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-mit" "0.15.0.20240909.1"
  "MIT/GNU Scheme's implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.18"))
  :url "https://gitlab.com/emacs-geiser/mit"
  :commit "ddd2ba733e8274d40a26b5d6d2ee11f1bac8abe6"
  :revdesc "ddd2ba733e82"
  :keywords '("languages" "mit" "scheme" "geiser")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
