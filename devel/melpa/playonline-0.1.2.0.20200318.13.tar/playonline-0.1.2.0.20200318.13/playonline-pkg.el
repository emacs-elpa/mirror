;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "playonline" "0.1.2.0.20200318.13"
  "Play code with online playgrounds."
  '((emacs   "24.4")
    (dash    "2.1")
    (request "0.2"))
  :url "https://github.com/twlz0ne/playonline.el"
  :commit "463a94fc01112817d1e6e0209ea85385efcb1329"
  :revdesc "463a94fc0111"
  :keywords '("tools")
  :authors '(("Gong Qijian" . "gongqijian@gmail.com"))
  :maintainers '(("Gong Qijian" . "gongqijian@gmail.com")))
