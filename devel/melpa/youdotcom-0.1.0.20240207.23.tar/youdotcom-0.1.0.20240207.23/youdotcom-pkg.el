;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youdotcom" "0.1.0.20240207.23"
  "You.com search package."
  '((emacs "25.1"))
  :url "https://github.com/SamuelVanie/youdotcom.el"
  :commit "0b835f143e88c3321006a3e48ac5190d071b872c"
  :revdesc "0b835f143e88"
  :keywords '("ai" "tools")
  :authors '(("Samuel Michael Vanié" . "samuelmichaelvanie@gmail.com"))
  :maintainers '(("Samuel Michael Vanié" . "samuelmichaelvanie@gmail.com")))
