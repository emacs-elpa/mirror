;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diary-manager" "2.0.2.0.20220929.20"
  "Simple personal diary."
  '((emacs "25"))
  :url "https://github.com/radian-software/diary-manager"
  :commit "56c739224e5bb845d275bfe3f4e420285de3a929"
  :revdesc "56c739224e5b"
  :keywords '("extensions")
  :authors '(("Radian LLC" . "contact+diary-manager@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+diary-manager@radian.codes")))
