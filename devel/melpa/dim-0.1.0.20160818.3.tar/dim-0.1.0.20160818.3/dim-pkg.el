;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dim" "0.1.0.20160818.3"
  "Change mode-line names of major/minor modes."
  '((emacs "24.4"))
  :url "https://github.com/alezost/dim.el"
  :commit "110624657fec0c8a7b3589108230e6a635302ae0"
  :revdesc "110624657fec"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
