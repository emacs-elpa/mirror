;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fpga" "0.3.0.0.20260714.9"
  "FPGA & ASIC Utils."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/fpga"
  :commit "fede50a1622295fa9ae6369e8a99c85a1e39f4f4"
  :revdesc "fede50a16222"
  :keywords '("tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
