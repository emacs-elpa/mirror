;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "splitjoin" "0.1.0.20150505.7"
  "Transition between multiline and single-line code."
  '((cl-lib "0.5"))
  :url "https://github.com/syohex/emacs-splitjoin"
  :commit "39a77f1c6c7406e79095eb0385667097172a770c"
  :revdesc "39a77f1c6c74"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
