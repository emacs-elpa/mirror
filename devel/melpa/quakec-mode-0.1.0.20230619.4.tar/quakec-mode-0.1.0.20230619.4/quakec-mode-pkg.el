;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quakec-mode" "0.1.0.20230619.4"
  "Major mode for QuakeC."
  '((emacs "27.1"))
  :url "https://github.com/vkazanov/quakec-mode"
  :commit "7b5d13fbdd9dfdc319ee8db1f1e954e00bdfce54"
  :revdesc "7b5d13fbdd9d"
  :keywords '("games" "languages"))
