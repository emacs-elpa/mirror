;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "0.10.0.0.20260826.23"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "518fa18a541facf8ef7a3740bc611b10a00b73aa"
  :revdesc "518fa18a541f"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
