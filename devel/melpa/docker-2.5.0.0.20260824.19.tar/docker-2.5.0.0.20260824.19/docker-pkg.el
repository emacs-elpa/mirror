;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "2.5.0.0.20260824.19"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "e476b1bf73e917aaae43daab763696629d864425"
  :revdesc "2.5.0-19-ge476b1bf73e9"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
