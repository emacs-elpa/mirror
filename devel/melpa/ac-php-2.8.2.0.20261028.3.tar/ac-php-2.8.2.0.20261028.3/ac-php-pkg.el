;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php" "2.8.2.0.20261028.3"
  "Auto Completion source for PHP."
  '((ac-php-core   "2.0")
    (auto-complete "1.4.0")
    (yasnippet     "0.8.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "619cb3c999719cd6ea0e784249811c2660980e79"
  :revdesc "v2.8.2-3-g619cb3c99971"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
