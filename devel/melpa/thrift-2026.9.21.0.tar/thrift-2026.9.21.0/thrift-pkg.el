;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.9.21.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "de5b6be5213fa8ea83808f69ccd42faf98105516"
  :revdesc "de5b6be5213f"
  :keywords '("languages"))
