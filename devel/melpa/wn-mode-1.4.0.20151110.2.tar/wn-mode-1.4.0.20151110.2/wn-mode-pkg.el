;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wn-mode" "1.4.0.20151110.2"
  "Numeric window switching shortcuts."
  '((emacs "24"))
  :url "https://github.com/luismbo/wn-mode"
  :commit "f05c3151523e529af5a0a3fa8c948b61fb369f6e"
  :revdesc "f05c3151523e"
  :keywords '("buffers" "windows" "switching-windows")
  :maintainers '(("Luís Oliveira" . "luismbo@gmail.com")))
