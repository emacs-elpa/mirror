;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-overleaf" "2.0.0.0.20260816.16"
  "Clone, push, and pull full Overleaf projects with Git."
  '((emacs         "29.4")
    (websocket     "1.15")
    (webdriver     "0.1")
    (magit-section "4.5")
    (transient     "0.7.2"))
  :url "https://github.com/Jamie-Cui/git-overleaf"
  :commit "bb0f38d83140a4816e0b7b4728416799311a182c"
  :revdesc "bb0f38d83140"
  :keywords '("hypermedia" "tex" "tools")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
