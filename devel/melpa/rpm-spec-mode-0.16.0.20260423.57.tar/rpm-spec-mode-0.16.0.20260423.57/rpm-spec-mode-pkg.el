;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rpm-spec-mode" "0.16.0.20260423.57"
  "RPM spec mode for Emacs/XEmacs."
  '((emacs  "27.1")
    (compat "29.1.4.5"))
  :url "https://github.com/Thaodan/rpm-spec-mode/"
  :commit "90c1beceff24b9f0e02c5a141efd466d5763f957"
  :revdesc "90c1beceff24"
  :keywords '("unix" "languages" "rpm")
  :authors '((nil . "stig@bjorlykke.org")
             ("Tore Olsen" . "toreo@tihlde.org")
             ("Steve Sanbeg" . "sanbeg@dset.com")
             ("Tim Powers" . "timp@redhat.com")
             ("Trond Eivind Glomsrød" . "teg@redhat.com")
             ("Chmouel Boudjnah" . "chmouel@mandrakesoft.com")
             ("Ville Skyttä" . "ville.skytta@iki.fi")
             ("Adam Spiers" . "elisp@adamspiers.org"))
  :maintainers '(("Björn Bidar" . "bjorn.bidar@thaodan.de")))
