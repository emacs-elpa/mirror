;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nushell-ts-mode" "0.0.1.0.20230911.29"
  "Tree-sitter support for Nushell."
  '((emacs "29.1"))
  :url "https://github.com/herbertjones/nushell-ts-mode"
  :commit "68afe1a8275880995b4d9a122fecf4accca15183"
  :revdesc "68afe1a82758"
  :keywords '("nu" "nushell" "languages" "tree-sitter")
  :authors '(("Herbert Jones" . "jones.herbert@gmail.com"))
  :maintainers '(("Herbert Jones" . "jones.herbert@gmail.com")))
