;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-projectile-helm" "3.1.0.0.20260313.16"
  "Helm functions for org-projectile."
  '((org-projectile "1.0.0")
    (helm           "2.3.1")
    (helm-org       "1.0")
    (emacs          "25"))
  :url "https://github.com/IvanMalison/org-projectile"
  :commit "6a95fb90bcdb7fcdeba9d9421d7c511cea95ef70"
  :revdesc "6a95fb90bcdb"
  :keywords '("org" "projectile" "todo" "helm" "outlines")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
