;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emc" "0.42.0.20251014.13"
  "Invoking a C/C++ (et al.) build toolchain from ELisp."
  '((delight "1.7")
    (emacs   "29.1"))
  :url "https://github.com/marcoxa/emc"
  :commit "f788e164056801059b5821a64909d49472d0e77e"
  :revdesc "f788e1640568"
  :keywords '("extensions" "c" "lisp" "building tools" "development" "deployment.")
  :authors '(("Marco Antoniotti" . "marcoxa[at]gmail.com"))
  :maintainers '(("Marco Antoniotti" . "marcoxa[at]gmail.com")))
