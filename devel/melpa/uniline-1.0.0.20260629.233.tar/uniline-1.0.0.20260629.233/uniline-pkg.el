;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "1.0.0.20260629.233"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "2d58c8cf237dfc0e7408f1e62e2dbfaf0dd9e99e"
  :revdesc "2d58c8cf237d"
  :keywords '("convenience" "text"))
