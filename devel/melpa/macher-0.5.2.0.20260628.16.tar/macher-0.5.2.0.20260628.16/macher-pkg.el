;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "0.5.2.0.20260628.16"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "44950accf782b2ae0a29f48bc85fb4842bc38ab1"
  :revdesc "44950accf782"
  :keywords '("convenience" "gptel" "llm"))
