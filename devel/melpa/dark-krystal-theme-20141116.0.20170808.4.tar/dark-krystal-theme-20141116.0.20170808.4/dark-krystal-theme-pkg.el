;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dark-krystal-theme" "20141116.0.20170808.4"
  "An Emacs 24 theme based on Dark Krystal (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "79084b99665dc9ffb0ec62cc092349a5ecebebbc"
  :revdesc "79084b99665d")
