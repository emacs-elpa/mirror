;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "d2-ts-mode" "0.1.0.0.20260301.8"
  "Tree-sitter support for D2."
  '((emacs "30.1"))
  :url "https://github.com/chaploud/d2-ts-mode"
  :commit "70891b8d49bbc25cc19ad9b21e3b88bda8fd705d"
  :revdesc "70891b8d49bb"
  :keywords '("languages" "d2" "tree-sitter")
  :authors '(("chaploud" . "https://github.com/chaploud"))
  :maintainers '(("chaploud" . "https://github.com/chaploud")))
