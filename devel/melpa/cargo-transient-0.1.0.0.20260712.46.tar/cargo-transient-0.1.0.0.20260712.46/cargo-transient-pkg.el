;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cargo-transient" "0.1.0.0.20260712.46"
  "A transient UI for Cargo, Rust's package manager."
  '((emacs "28.1"))
  :url "https://github.com/peterstuart/cargo-transient"
  :commit "ece657bb0f44f64a273d5334b3423688b7ed9e3e"
  :revdesc "ece657bb0f44"
  :authors '(("Peter Stuart" . "peter@peterstuart.org"))
  :maintainers '(("Peter Stuart" . "peter@peterstuart.org")))
