;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.88.1.0.20261021.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "80887a9f8e51c30536327a532936ecf67a2bc869"
  :revdesc "80887a9f8e51")
