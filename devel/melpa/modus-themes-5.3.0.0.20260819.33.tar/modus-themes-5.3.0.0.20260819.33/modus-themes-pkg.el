;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "5.3.0.0.20260819.33"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "75ad3771352ed4b61a141f8d4d63e1b08a6c5cbc"
  :revdesc "75ad3771352e"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
