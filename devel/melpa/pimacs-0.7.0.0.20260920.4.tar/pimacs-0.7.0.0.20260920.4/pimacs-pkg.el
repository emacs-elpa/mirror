;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.7.0.0.20260920.4"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "d8713d62e45e8bd14ddebaf5ee1f9bb027930de6"
  :revdesc "d8713d62e45e"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
