;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "json-rpc" "0.0.1"
  "JSON-RPC library."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/skeeto/elisp-json-rpc"
  :commit "81a5a520072e20d18aeab2aac4d66c046b031e56"
  :revdesc "0.0.1-0-g81a5a520072e"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
