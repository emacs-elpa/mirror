;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diminish" "0.45.0.20220909.15"
  "Diminished modes are minor modes with no modeline display."
  '((emacs "24.3"))
  :url "https://github.com/myrjola/diminish.el"
  :commit "fbd5d846611bad828e336b25d2e131d1bc06b83d"
  :revdesc "fbd5d846611b"
  :keywords '("extensions" "diminish" "minor" "codeprose")
  :authors '(("Will Mengarini" . "seldon@eskimo.com"))
  :maintainers '(("Martin Yrjölä" . "martin.yrjola@gmail.com")))
