;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.7.0.0.20260804.2"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "7f38461fe14a2143093bebb1c13f75442bc0c4d2"
  :revdesc "7f38461fe14a"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
