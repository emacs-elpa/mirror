;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "0.3.4.0.20260907.46"
  "Minor mode for making Anki cards with Org."
  '((emacs "29.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "defeab61dfff355622779448add1dfe01c13ddaf"
  :revdesc "defeab61dfff")
