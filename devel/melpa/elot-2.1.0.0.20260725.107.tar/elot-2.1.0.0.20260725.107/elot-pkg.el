;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elot" "2.1.0.0.20260725.107"
  "Emacs Literate Ontology Tool (ELOT)."
  '((emacs "30.1"))
  :url "https://github.com/johanwk/elot"
  :commit "80b764970b121b35dee22c9824c45be0e628fd63"
  :revdesc "v2.1.0-107-g80b764970b12"
  :keywords '("languages" "outlines" "tools" "org" "ontology")
  :authors '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com"))
  :maintainers '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com")))
