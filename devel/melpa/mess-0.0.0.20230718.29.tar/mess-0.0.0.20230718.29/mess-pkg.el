;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mess" "0.0.0.20230718.29"
  "Front-end for MAME MESS."
  '((emacs "27.1")
    (mame  "1.0"))
  :url "https://github.com/Iacob/elmame"
  :commit "65392b0d0ded45de789d4deab28a4ce88de24567"
  :revdesc "65392b0d0ded"
  :authors '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers '(("Yong" . "luo.yong.name@gmail.com")))
