;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.48.0.0.20260731.1"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "ebd6466f46e15a28acfc1cdc28ae187090ced830"
  :revdesc "ebd6466f46e1"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
