;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "6.3.0.0.20261023.1"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "d2f532a35e70de4741bc76e2deca115d590a7e57"
  :revdesc "v6.3.0-1-gd2f532a35e70"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
