;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asdf-vm" "0.1.0"
  "ASDF-VM porcelain."
  '((emacs "29.1"))
  :url "https://github.com/zellio/emacs-asdf-vm"
  :commit "f6dbb4b6560cd7e5bb05006e9fc416c5c323b567"
  :revdesc "v0.1.0-0-gf6dbb4b6560c"
  :keywords '("tools" "asdf-vm" "asdf")
  :authors '(("Zachary Elliott" . "contact@zell.io"))
  :maintainers '(("Zachary Elliott" . "contact@zell.io")))
