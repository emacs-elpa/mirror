;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabnine" "0.0.3.0.20250102.8"
  "An unofficial TabNine package with TabNine Chat supported."
  '((emacs        "27.1")
    (dash         "2.16.0")
    (s            "1.12.0")
    (editorconfig "0.9.1")
    (language-id  "0.5.1")
    (transient    "0.4.0"))
  :url "https://github.com/shuxiao9058/tabnine/"
  :commit "7c103aa9e1dd46e8507d341fee42ce30417e69f5"
  :revdesc "7c103aa9e1dd"
  :keywords '("convenience")
  :authors '(("Aaron Ji" . "shuxiao9058@gmail.com")
             ("Tommy Xiang" . "tommyx058@gmail.com")
             ("John Gong" . "gjtzone@hotmail.com"))
  :maintainers '(("Aaron Ji" . "shuxiao9058@gmail.com")
                 ("Tommy Xiang" . "tommyx058@gmail.com")
                 ("John Gong" . "gjtzone@hotmail.com")))
