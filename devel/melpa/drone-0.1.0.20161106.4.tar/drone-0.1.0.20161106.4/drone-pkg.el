;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "drone" "0.1.0.20161106.4"
  "Launch your drone test suite if drone.yml is present."
  ()
  :url "https://github.com/olymk2/emacs-drone"
  :commit "1d4ee037ad3208847a4235426edf0c4a3e7b1899"
  :revdesc "1d4ee037ad32"
  :keywords '("drone" "tests" "ci")
  :authors '(("Oliver Marks" . "oly@digitaloctave.com"))
  :maintainers '(("Oliver Marks" . "oly@digitaloctave.com")))
