;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "2.0.0.20251031.43"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "36846cdca91794cf38fa171d5a3ac291d3ebc060"
  :revdesc "v2.0-43-g36846cdca917"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
