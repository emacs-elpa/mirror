;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prognth" "1.0"
  "Extend prog1 to arbitrary index."
  ()
  :url "https://github.com/Fuco1/prognth"
  :commit "2f1ca4d34b1fd581163e1df122c85418137e8e62"
  :revdesc "2f1ca4d34b1f"
  :keywords '("lisp")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
