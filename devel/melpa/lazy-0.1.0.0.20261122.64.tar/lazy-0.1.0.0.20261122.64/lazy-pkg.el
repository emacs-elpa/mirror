;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lazy" "0.1.0.0.20261122.64"
  "Lazy evaluation library."
  '((emacs "25"))
  :url "https://github.com/conao3/lazy.el"
  :commit "8fd32e13bd04ca8f734e2f9a9c2ed07a60595693"
  :revdesc "8fd32e13bd04"
  :keywords '("lisp" "lazy")
  :authors '(("chuntaro" . "chuntaro@sakura-games.jp"))
  :maintainers '(("conao3" . "conao3@gmail.com")))
