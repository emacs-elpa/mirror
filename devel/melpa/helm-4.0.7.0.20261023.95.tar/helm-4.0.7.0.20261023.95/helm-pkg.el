;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "4.0.7.0.20261023.95"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.8")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "062b8df21022afa18a59ade1ab97af595ef465d8"
  :revdesc "v4.0.7-95-g062b8df21022"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
