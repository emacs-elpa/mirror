;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-actionlint" "0.1.0.0.20240826.9"
  "A Flymake handler for actionlint."
  '((emacs        "24.1")
    (flymake-easy "0.0.0"))
  :url "https://github.com/ROCKTAKEY/flymake-actionlint"
  :commit "c502456fd445794f166d537eccd7b113d2c6fc64"
  :revdesc "v0.1.0-9-gc502456fd445"
  :keywords '("convenience")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
