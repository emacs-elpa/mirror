;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ctrlxo" "1.2"
  "Switch to the most recently used window."
  '((emacs "25.1"))
  :url "https://github.com/muffinmad/emacs-ctrlxo"
  :commit "8ad95a81bd1ece06ebe40e2a83490775db64b419"
  :revdesc "8ad95a81bd1e"
  :keywords '("frames")
  :authors '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com"))
  :maintainers '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com")))
