;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elx" "2.3.4"
  "Extract information from Emacs Lisp libraries."
  '((emacs    "29.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/elx"
  :commit "23caadf0f87879881e26461460fe5f9f7a34244f"
  :revdesc "v2.3.4-0-g23caadf0f878"
  :keywords '("docs" "libraries" "packages")
  :authors '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev")))
