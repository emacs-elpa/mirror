;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gxref" "0.1.0.20170411.4"
  "Xref backend using GNU Global."
  '((emacs "25"))
  :url "https://github.com/dedi/gxref"
  :commit "380b02c3c3c2586c828456716eef6a6392bb043b"
  :revdesc "v0.1-4-g380b02c3c3c2"
  :keywords '("xref" "global" "tools"))
