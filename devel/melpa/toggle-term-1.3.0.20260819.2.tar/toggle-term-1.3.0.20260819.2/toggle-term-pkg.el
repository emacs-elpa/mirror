;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toggle-term" "1.3.0.20260819.2"
  "Quickly toggle persistent term and shell buffers."
  '((emacs "25.1"))
  :url "https://github.com/justinlime/toggle-term.el"
  :commit "6859d9bab523b2f821a59e2d0a59321ad7fed948"
  :revdesc "6859d9bab523"
  :keywords '("frames" "convenience" "terminals"))
