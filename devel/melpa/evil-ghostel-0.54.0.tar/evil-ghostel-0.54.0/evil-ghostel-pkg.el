;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "0.54.0"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "f1b03e52c4c48bd66772317ebedfa374a4083afe"
  :revdesc "f1b03e52c4c4"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
