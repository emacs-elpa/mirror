;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "motion-mode" "0.5.1.0.20140920.13"
  "Major mode for RubyMotion enviroment."
  '((flymake-easy   "0.7")
    (flymake-cursor "1.0.2"))
  :url "https://github.com/ainame/motion-mode"
  :commit "4c94180e3ecea611a61240a0c0cd48f1032c4a55"
  :revdesc "4c94180e3ece")
