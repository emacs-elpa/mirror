;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2.0.20260824.33"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "aea6db7a7ea78fbf0633aa224c0d896162647d58"
  :revdesc "aea6db7a7ea7"
  :keywords '("faces" "files" "q"))
