;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "naga-theme" "0.0.0.20260422.80"
  "Dark color theme with green foreground color."
  ()
  :url "https://github.com/kenranunderscore/emacs-naga-theme"
  :commit "1ffb5930e57ee0a1073b206ff09ea25ef542b6bc"
  :revdesc "1ffb5930e57e"
  :authors '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainers '(("Johannes Maier" . "johannes.maier@mailbox.org")))
