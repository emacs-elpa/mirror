;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tao-theme" "1.1.1.0.20250717.71"
  "Tao of EMACS grayscale color theme."
  '((cl-lib "0.5"))
  :url "https://github.com/11111000000/tao-theme-emacs"
  :commit "33c0d44048afe444e7a8aee30fbc101a00453799"
  :revdesc "33c0d44048af"
  :authors '(("Peter Kosov" . "11111000000@email.com"))
  :maintainers '(("Peter Kosov" . "11111000000@email.com")))
