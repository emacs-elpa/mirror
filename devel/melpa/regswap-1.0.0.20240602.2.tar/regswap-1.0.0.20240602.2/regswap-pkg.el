;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "regswap" "1.0.0.20240602.2"
  "Functionality for swapping two regions."
  '((emacs "24.3"))
  :url "https://github.com/skitov/regswap"
  :commit "65e2319e013c5d59f338edde12b98ef1c737e870"
  :revdesc "65e2319e013c")
