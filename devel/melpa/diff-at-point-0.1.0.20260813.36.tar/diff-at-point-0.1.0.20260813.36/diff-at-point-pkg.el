;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-at-point" "0.1.0.20260813.36"
  "Diff navigation."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-at-point"
  :commit "5cdfc8fdefc9fd041eab364c9cdeb3db12f79469"
  :revdesc "5cdfc8fdefc9"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
