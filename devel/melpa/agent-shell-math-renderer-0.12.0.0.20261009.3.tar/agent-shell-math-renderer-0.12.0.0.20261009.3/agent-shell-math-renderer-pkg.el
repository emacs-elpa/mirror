;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.12.0.0.20261009.3"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.66.1")
    (latex-to-svg-backend "0.12.1"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "233e01a4e7964f7e695efb492bd8cab08c645afd"
  :revdesc "v0.12.0-3-g233e01a4e796"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
