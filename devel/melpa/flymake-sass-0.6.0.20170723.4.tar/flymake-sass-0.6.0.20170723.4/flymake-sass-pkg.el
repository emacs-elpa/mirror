;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-sass" "0.6.0.20170723.4"
  "Flymake handler for sass and scss files."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-sass"
  :commit "2de28148e92deb93bff3d55fe14e7c67ac476056"
  :revdesc "2de28148e92d"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
