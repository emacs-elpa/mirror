;;; guix-geiser.el --- Interacting with Geiser  -*- lexical-binding: t -*-

;; Copyright © 2015, 2018 Alex Kost <alezost@gmail.com>

;; This file is part of Emacs-Guix.

;; Emacs-Guix is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; Emacs-Guix is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with Emacs-Guix.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; This file provides functions to evaluate guile code using Geiser.

;;; Code:

(require 'geiser-mode)
(require 'guix-guile)

(defvar guix-geiser-connection-timeout (* 3 60 1000) ; 3 minutes
  "Time, in milliseconds, to wait for REPL to return a result.
Same as `geiser-connection-timeout' but is used for Guix
commands.  By default, this variable has a significant value,
because some commands (like `guix-store-live-items') may take a
very long time to run.")

(defun guix-geiser-repl ()
  "Return the current Geiser REPL."
  (or geiser-repl--repl
      (geiser-repl--repl/impl 'guile)
      (error "Geiser REPL not found")))

(defun guix-geiser-eval (str &optional repl)
  "Evaluate STR with guile expression using Geiser REPL.
If REPL is nil, use the current Geiser REPL.
Return a list of strings with result values of evaluation."
  (let ((gc-cons-threshold (max gc-cons-threshold 10000000)))
    (with-current-buffer (or repl (guix-geiser-repl))
      (geiser-con--connection-activate (geiser-eval--connection))
      (let ((res (geiser-eval--send/wait
                  `(:eval (:scm ,str))
                  guix-geiser-connection-timeout)))
        (geiser-con--connection-deactivate (geiser-eval--connection))
        (unless res
          (error "\
Sorry, the evaluation is aborted because it has taken too much time.
Try to increase the value of `guix-geiser-connection-timeout'
variable if you have a slow machine, or please report if you
think this command takes unreasonably long time to run."))
        (if (geiser-eval--retort-error res)
            (error "Error in evaluating guile expression: %s"
                   (geiser-eval--retort-output res))
          (cdr (assq 'result res)))))))

(defun guix-geiser-eval-read (str &optional repl)
  "Evaluate STR with guile expression using Geiser REPL.
Return elisp expression of the first result value of evaluation."
  (guix-guile-read-from-string (car (guix-geiser-eval str repl))))

(defun guix-geiser-eval-in-repl (str &optional repl no-history no-display)
  "Switch to Geiser REPL and evaluate STR with guile expression there.
If NO-HISTORY is non-nil, do not save STR in the REPL history.
If NO-DISPLAY is non-nil, do not switch to the REPL buffer."
  (let ((repl (or repl (guix-geiser-repl))))
    (with-current-buffer repl
      (geiser-repl--send str (not no-history)))
    (unless no-display
      (geiser-repl--switch-to-buffer repl))))

(defun guix-geiser-eval-in-repl-synchronously (str &optional repl
                                                   no-history no-display)
  "Evaluate STR in Geiser REPL synchronously, i.e., wait until the
REPL operation will be finished.
See `guix-geiser-eval-in-repl' for the meaning of arguments."
  (let* ((repl (if repl (get-buffer repl) (guix-geiser-repl)))
         (proc (get-buffer-process repl))
         (running? nil)
         (filter (lambda (output)
                   (setq running?
                         (and (get-buffer-process repl)
                              (not (guix-guile-prompt? output))))))
         (comint-output-filter-functions
          (cons filter comint-output-filter-functions)))
    (guix-geiser-eval-in-repl str repl no-history no-display)
    (while running?
      (accept-process-output proc 0.1)
      (unless no-display
        (redisplay t)
        (end-of-buffer)))))

(defun guix-geiser-call (proc &rest args)
  "Call (PROC ARGS ...) synchronously using the current Geiser REPL.
PROC and ARGS should be strings."
  (guix-geiser-eval
   (apply #'guix-guile-make-call-expression proc args)))

(defun guix-geiser-call-in-repl (proc &rest args)
  "Call (PROC ARGS ...) in the current Geiser REPL.
PROC and ARGS should be strings."
  (guix-geiser-eval-in-repl
   (apply #'guix-guile-make-call-expression proc args)))

(provide 'guix-geiser)

;;; guix-geiser.el ends here
