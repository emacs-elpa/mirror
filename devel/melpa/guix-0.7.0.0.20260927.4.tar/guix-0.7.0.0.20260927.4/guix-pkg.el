;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "0.7.0.0.20260927.4"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3"))
  :url "https://codeberg.org/guix/emacs-guix"
  :commit "ee189ece587c6630e0c9c83bf4570f4571d78487"
  :revdesc "v0.7.0-4-gee189ece587c"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
