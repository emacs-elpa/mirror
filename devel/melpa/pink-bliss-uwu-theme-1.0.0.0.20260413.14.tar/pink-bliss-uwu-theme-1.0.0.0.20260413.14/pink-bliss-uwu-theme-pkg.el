;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pink-bliss-uwu-theme" "1.0.0.0.20260413.14"
  "Pink color theme."
  '((emacs "24.1"))
  :url "https://github.com/themkat/pink-bliss-uwu"
  :commit "26e90134adc997c8f6fbf3820fa9198afa6c832b"
  :revdesc "26e90134adc9")
