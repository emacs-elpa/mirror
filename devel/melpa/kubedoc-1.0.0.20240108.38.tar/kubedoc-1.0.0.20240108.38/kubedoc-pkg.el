;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubedoc" "1.0.0.20240108.38"
  "Kubernetes API Documentation."
  '((emacs "27.1"))
  :url "https://github.com/r0bobo/kubedoc.el/"
  :commit "aac02b096c98b83b4eaf129e6d767cf7150a6d43"
  :revdesc "aac02b096c98"
  :keywords '("docs" "help" "k8s" "kubernetes" "tools")
  :authors '(("Dean Lindqvist Todevski" . "https://github.com/r0bobo")))
