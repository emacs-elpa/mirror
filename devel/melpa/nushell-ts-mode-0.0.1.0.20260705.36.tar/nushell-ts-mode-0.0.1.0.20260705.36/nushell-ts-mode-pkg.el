;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nushell-ts-mode" "0.0.1.0.20260705.36"
  "Tree-sitter support for Nushell."
  '((emacs "29.1"))
  :url "https://github.com/herbertjones/nushell-ts-mode"
  :commit "49915cd99d62b7e743bd8cf9023a5819479d166f"
  :revdesc "49915cd99d62"
  :keywords '("nu" "nushell" "languages" "tree-sitter")
  :authors '(("Herbert Jones" . "jones.herbert@gmail.com"))
  :maintainers '(("Herbert Jones" . "jones.herbert@gmail.com")))
