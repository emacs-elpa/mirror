;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-popup-tip" "0.12.2.0.20260810.1"
  "Display Flycheck error messages using popup.el."
  '((flycheck "0.22")
    (popup    "0.5")
    (emacs    "24"))
  :url "https://github.com/flycheck/flycheck-popup-tip/"
  :commit "79a70cf1f3b7b8db4eeb7cec01f6dedc0a38cabb"
  :revdesc "0.12.2-1-g79a70cf1f3b7"
  :keywords '("convenience" "tools" "flycheck" "tooltip")
  :authors '(("Saša Jovanić" . "sasa@simplify.ba"))
  :maintainers '(("Saša Jovanić" . "sasa@simplify.ba")))
