;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-line" "1.6.0.20260904.2"
  "Custom and simple mode line."
  '((emacs "29.1"))
  :url "https://gitlab.com/aimebertrand/timu-line"
  :commit "7fa9af7ae295446572019c403f89852c506624df"
  :revdesc "7fa9af7ae295"
  :keywords '("modeline" "frames" "ui")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
