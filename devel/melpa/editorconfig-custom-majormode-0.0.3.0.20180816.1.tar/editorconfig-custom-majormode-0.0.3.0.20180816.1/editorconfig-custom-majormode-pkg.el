;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "editorconfig-custom-majormode" "0.0.3.0.20180816.1"
  "Decide major-mode and mmm-mode from EditorConfig."
  '((editorconfig "0.6.0"))
  :url "https://github.com/10sr/editorconfig-custom-majormode-el"
  :commit "13ad1c83f847bedd4b3a19f9df7fd925853b19de"
  :revdesc "13ad1c83f847"
  :keywords '("editorconfig" "util")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
