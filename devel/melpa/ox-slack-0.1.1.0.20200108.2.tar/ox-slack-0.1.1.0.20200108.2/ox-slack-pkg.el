;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-slack" "0.1.1.0.20200108.2"
  "Slack Exporter for org-mode."
  '((emacs  "24")
    (org    "9.1.4")
    (ox-gfm "1.0"))
  :url "https://github.com/titaniumbones/ox-slack"
  :commit "c55b003f4ac343d6c6d8ef7cbe01d0d100abac34"
  :revdesc "c55b003f4ac3"
  :keywords '("org" "slack" "outlines"))
