;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatwork" "0.3.0.20240910.1"
  "ChatWork client for Emacs."
  ()
  :url "https://github.com/ataka/chatwork"
  :commit "5abbf07bd6063c922191cc645f5771a943e3043c"
  :revdesc "0.3-1-g5abbf07bd606"
  :keywords '("web")
  :authors '(("Masayuki Ataka" . "masayuki.ataka@gmail.com"))
  :maintainers '(("Masayuki Ataka" . "masayuki.ataka@gmail.com")))
