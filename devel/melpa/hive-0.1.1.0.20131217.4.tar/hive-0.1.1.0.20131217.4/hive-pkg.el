;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hive" "0.1.1.0.20131217.4"
  "Hive SQL mode extension."
  '((sql "3.0"))
  :url "https://github.com/r0man/hive-el"
  :commit "131f2816a0cf4d1fee44198ca305e6e2d1cab750"
  :revdesc "131f2816a0cf"
  :keywords '("sql" "hive")
  :authors '(("Roman Scherer" . "roman@burningswell.com"))
  :maintainers '(("Roman Scherer" . "roman@burningswell.com")))
