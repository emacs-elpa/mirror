;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3.0.20261104.137"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "98d2c65392e6471f8389ddfac4c2a8ff48c75d85"
  :revdesc "98d2c65392e6"
  :keywords '("build tools" "languages"))
