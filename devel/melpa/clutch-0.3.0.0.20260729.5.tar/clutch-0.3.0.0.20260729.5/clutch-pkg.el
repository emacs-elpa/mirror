;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.3.0.0.20260729.5"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "34a9c01ee1efddb4522358005836cca77370a3a3"
  :revdesc "34a9c01ee1ef"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
