;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260525.1323"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "cd023ad61938e11c9874977d921c66c08351e9d3"
  :revdesc "cd023ad61938"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
