;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liquid-types" "0.0.2"
  "Show inferred liquid-types."
  '((flycheck          "0.13")
    (dash              "1.2")
    (emacs             "24.1")
    (popup             "0.5.2")
    (pos-tip           "0.5.0")
    (flycheck-liquidhs "0.0.1")
    (button-lock       "1.0.2"))
  :url "https://github.com/ucsd-progsys/liquid-types.el"
  :commit "cc4bacbbf204ef9cf0756f78dfebee2c6ae14d7b"
  :revdesc "cc4bacbbf204"
  :authors '(("Ranjit Jhala" . "jhala@cs.ucsd.edu"))
  :maintainers '(("Ranjit Jhala" . "jhala@cs.ucsd.edu")))
