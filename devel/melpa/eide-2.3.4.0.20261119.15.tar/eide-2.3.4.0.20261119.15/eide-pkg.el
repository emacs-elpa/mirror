;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eide" "2.3.4.0.20261119.15"
  "IDE features made available out of the box."
  '((emacs "28.2"))
  :url "https://forge.tedomum.net/hjuvi/eide"
  :commit "bfe7e33b8f62c476842ab7a57e9186a816f6209a"
  :revdesc "2.3.4-15-gbfe7e33b8f62"
  :authors '(("Cédric Marie" . "hjuvi@tedomum.fr"))
  :maintainers '(("Cédric Marie" . "hjuvi@tedomum.fr")))
