;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferbin" "0.0.0.20230706.19"
  "Quick mouse access to buffers."
  '((emacs "26.1"))
  :url "https://github.com/blueridge-data/bufferbin"
  :commit "ee4bf49cc69573f690e2e9f36f03c20b322c1730"
  :revdesc "ee4bf49cc695"
  :authors '(("Ryan Walsh" . "blueridge-data@github"))
  :maintainers '(("Ryan Walsh" . "blueridge-data@github")))
