;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popup-edit-menu" "0.0.3.0.20170404.1"
  "A popup context edit menu package."
  '((emacs "24"))
  :url "https://github.com/debugfan/popup-edit-menu"
  :commit "925600a6e29183841199e866cf55e566a6a1b002"
  :revdesc "925600a6e291"
  :keywords '("lisp" "pop-up" "context" "edit" "menu")
  :authors '(("Debugfan Chin" . "debugfanchin@gmail.com"))
  :maintainers '(("Debugfan Chin" . "debugfanchin@gmail.com")))
