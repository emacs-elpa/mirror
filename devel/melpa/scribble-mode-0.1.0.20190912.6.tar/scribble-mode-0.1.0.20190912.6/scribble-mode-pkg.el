;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scribble-mode" "0.1.0.20190912.6"
  "Major mode for editing Scribble documents."
  '((emacs "24"))
  :url "https://github.com/emacs-pe/scribble-mode"
  :commit "5c3ea3cc9bbad585476eee41ea76dc056c2012bb"
  :revdesc "5c3ea3cc9bba"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
