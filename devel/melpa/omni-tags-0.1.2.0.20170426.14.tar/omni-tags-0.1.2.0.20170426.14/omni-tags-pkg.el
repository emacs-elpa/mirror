;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "omni-tags" "0.1.2.0.20170426.14"
  "Highlight and Actions for 'Tags'."
  '((pcre2el "1.7")
    (cl-lib  "0.5"))
  :url "https://github.com/AdrieanKhisbe/omni-tags.el"
  :commit "8f0f6c302fab900b7681e5c039f90850cbbabd33"
  :revdesc "v0.1.2-14-g8f0f6c302fab"
  :keywords '("convenience")
  :authors '(("Adrien Becchis" . "adriean.khisbe@live.fr"))
  :maintainers '(("Adrien Becchis" . "adriean.khisbe@live.fr")))
