;;; youtube-music.el --- YouTube Music client -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Pavel Bibergal

;; Author: Pavel Bibergal <pavel@keewano.com>
;; Assisted-by: Claude:claude-fable-5
;; URL: https://github.com/cyberkm/emacs-youtube-music
;; Package-Version: 0.2.0.0.20260923.3
;; Package-Revision: d13cf01d58f6
;; Package-Requires: ((emacs "29.1"))
;; Keywords: multimedia, youtube, music

;; This file is not part of GNU Emacs.

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; youtube-music.el is a YouTube Music client for Emacs.  Playback is
;; handled by an `mpv' subprocess, controlled over a JSON IPC socket;
;; browsing and search talk to the YouTube Music API directly.
;;
;; The primary entry point is `M-x youtube-music', which pops a status
;; buffer styled after Magit: a Now Playing section, the upcoming
;; queue, and browseable sources.  Press `C-h m' inside the buffer to
;; see every key binding.
;;
;; Features:
;;
;;   - search songs and playlists in one prompt: picking a song
;;     plays that one track, picking a playlist queues it whole,
;;   - browse your library (`M-x youtube-music-library'): liked
;;     songs, saved playlists, and the personalized Home shelves,
;;   - start a radio of similar tracks from any song,
;;   - like / dislike tracks, shuffle, repeat, seek, edit the queue,
;;   - now-playing info in the global mode line, plus MPRIS support
;;     so desktop media controllers (playerctl, waybar, media keys)
;;     see the player,
;;   - one-keypress login: the YouTube Music cookie is pulled from
;;     your browser (Firefox, Chrome, Chromium, Brave, Edge, Safari)
;;     via yt-dlp, stored in a 0600 credentials file, and silently
;;     re-extracted when it expires.
;;
;; OAuth device flow is intentionally not used: Google has been
;; restricting which client_ids may grant the YouTube Music scopes,
;; so the unofficial-OAuth path is currently unreliable.  The cookie
;; flow is robust and is used by `ytmusicapi' and `ytermusic' alike.
;;
;; Required external programs: `mpv' and `yt-dlp'.

;;; Code:

(require 'cl-lib)
(require 'json)
(require 'subr-x)
(require 'transient)
(require 'url)

;;;; Customization

(defgroup youtube-music nil
  "YouTube Music client for Emacs."
  :group 'multimedia
  :prefix "youtube-music-")

(defcustom youtube-music-mpv-program "mpv"
  "Path to the mpv executable."
  :type 'string)

(defcustom youtube-music-mpv-extra-args
  '("--idle=yes"
    "--no-video"
    "--no-input-terminal"
    "--quiet"
    "--msg-level=all=warn"
    "--ytdl-format=bestaudio")
  "Additional arguments passed to mpv on startup.
Diagnostics from mpv land in the ` *youtube-music-mpv*' buffer; open
it with `youtube-music-show-log'."
  :type '(repeat string))

(defcustom youtube-music-mpv-mpris-search-paths
  '("/usr/lib64/mpv/scripts/mpris.so"
    "/usr/lib/mpv/scripts/mpris.so"
    "/usr/lib/*-linux-gnu/mpv/scripts/mpris.so"
    "/usr/lib/mpv-mpris/mpris.so"
    "/usr/local/lib/mpv/scripts/mpris.so")
  "Candidate paths searched for the mpv-mpris plugin.
Entries are treated as glob patterns (see `file-expand-wildcards')
so the Debian/Ubuntu multiarch directory can be covered with a
single wildcard.  The first matching file is loaded via mpv's
`--script' flag, exposing playback state on the MPRIS D-Bus
interface (`playerctl', the waybar mpris module, etc.).

MPRIS is a Linux-only protocol; on macOS no entry will match and
mpv runs without the plugin, which is fine.  Set to nil to opt
out explicitly."
  :type '(repeat file))

(defcustom youtube-music-modeline-format " %P♪ %t"
  "Format string for the mode-line indicator.
Recognised tokens:
  %t — media title
  %p — current position (m:ss)
  %d — total duration (m:ss)
  %P — pause indicator (\"⏸ \" while paused, empty otherwise)"
  :type 'string)

(defcustom youtube-music-seek-step 5
  "Seconds for `youtube-music-seek-forward' / `youtube-music-seek-backward'."
  :type 'integer)

(defcustom youtube-music-progress-bar-width 30
  "Width, in characters, of the now-playing progress bar."
  :type 'integer)

(defcustom youtube-music-search-max-results 5
  "How many search results to show per category initially.
Each truncated category ends with a \"More ...\" entry that
expands it to everything the API returned (about 20 per
category), instantly and without another request."
  :type 'integer)

(defcustom youtube-music-buffer-name "*youtube-music*"
  "Name of the status buffer."
  :type 'string)

;;;; Faces

(defface youtube-music-section-heading
  '((t :inherit font-lock-keyword-face))
  "Face for section headings in the status buffer.")

(defface youtube-music-current-track
  '((t :inherit font-lock-string-face))
  "Face for the now-playing track title.")

(defface youtube-music-queue-current
  '((t :inherit font-lock-string-face))
  "Face for the currently-playing entry inside the Queue section.")

(defface youtube-music-queue-past
  '((t :inherit shadow))
  "Face for already-played entries inside the Queue section.")

(defface youtube-music-thumbs-up
  '((t :inherit success))
  "Face for the thumbs-up indicator on a track.")

(defface youtube-music-thumbs-down
  '((t :inherit error))
  "Face for the thumbs-down indicator on a track.")

(defface youtube-music-auth-ok
  '((t :inherit success))
  "Face for the signed-in status indicator.")

(defface youtube-music-auth-error
  '((t :inherit error))
  "Face for the signed-out status indicator.")

(defface youtube-music-progress-fill
  '((t :inherit font-lock-keyword-face))
  "Face for the filled portion of the progress bar.")

(defface youtube-music-progress-empty
  '((t :inherit shadow))
  "Face for the empty portion of the progress bar.")

(defface youtube-music-help
  '((t :inherit shadow))
  "Face for the in-buffer help line.")

;;;; Internal state

(defvar youtube-music--mpv-process nil
  "The mpv subprocess, or nil.")

(defvar youtube-music--ipc-process nil
  "The network process connected to mpv's IPC socket, or nil.")

(defvar youtube-music--socket-dir nil
  "Cached private directory that holds the mpv IPC socket, or nil.")

(defvar youtube-music--socket-path nil
  "Cached UNIX socket path used for the mpv IPC server.")

(defvar youtube-music--request-counter 0
  "Monotonically increasing counter for IPC request IDs.")

(defvar youtube-music--pending-requests (make-hash-table :test 'eql)
  "Map of pending IPC request IDs to callback functions.")

(defvar youtube-music--ipc-buffer ""
  "Accumulator for partial IPC messages received from mpv.")

(defvar youtube-music--state
  (list :title nil :pause t :time-pos 0 :duration 0 :playlist-pos -1
        :path nil :loop-file "no" :loop-playlist "no")
  "Cached playback state, refreshed by mpv property events.")

(defvar youtube-music--shuffled-p nil
  "Non-nil when we have shuffled the current mpv playlist.
Tracked locally because mpv has no runtime `shuffled' property.")


(defvar youtube-music--mode-line-string ""
  "Pre-formatted mode-line indicator, recomputed on state change.")

(defvar youtube-music--playlist-cache nil
  "Cached playlist contents fetched from mpv.")

(defvar youtube-music--track-meta (make-hash-table :test 'equal)
  "Map of videoId → plist (:title :subtitle) for tracks we queued.
Populated when we hand a track to mpv so the status buffer can
display the proper artist/song instead of mpv's URL filename
before metadata is resolved.")

(defvar youtube-music--liked-set nil
  "Hash-set of videoIds in the user's liked-songs list, or nil.
Nil until populated.  Use `youtube-music-refresh-liked-set' to
fetch (or play your liked songs, which seeds it as a side effect).")

(defvar youtube-music--disliked-set (make-hash-table :test 'equal)
  "Hash-set of videoIds the user disliked in the current session.
We cannot query the server for disliked tracks the way we do for
liked ones, so this is session-local.  Cleared on quit/logout.")

(defvar youtube-music--auth-state 'unknown
  "Server-reported auth state: `logged-in', `logged-out', or `unknown'.
Updated whenever a youtubei response arrives, by inspecting the
`responseContext.serviceTrackingParams.GFEEDBACK.logged_in' field.")

(defvar youtube-music--account-name nil
  "Cached display name for the currently signed-in account, or nil.")

(defvar youtube-music--auto-refresh-attempted nil
  "Non-nil after we've tried silent cookie re-extraction this session.
Reset on manual login / logout.")

;; Forward declaration: the defcustom lives in the Authentication
;; section further down, but the status renderer above needs the
;; symbol declared so byte-compile is happy.
(defvar youtube-music-credentials-file)

;;;; Lifecycle

(defun youtube-music--socket-path ()
  "Return the IPC socket path, computing it once on first use."
  (or youtube-music--socket-path
      (setq youtube-music--socket-path
            (expand-file-name
             "mpv.sock"
             (setq youtube-music--socket-dir
                   (make-temp-file "youtube-music-" 'directory))))))

(defun youtube-music--cleanup-socket ()
  "Remove the private socket directory created for mpv, if any.
Clears the cached paths so a fresh directory is minted next start."
  (when youtube-music--socket-dir
    (ignore-errors (delete-directory youtube-music--socket-dir t)))
  (setq youtube-music--socket-dir nil
        youtube-music--socket-path nil))

(defun youtube-music--mpv-running-p ()
  "Return non-nil when the mpv subprocess is alive."
  (and youtube-music--mpv-process (process-live-p youtube-music--mpv-process)))

(defun youtube-music--ipc-connected-p ()
  "Return non-nil when the IPC connection to mpv is open."
  (and youtube-music--ipc-process (process-live-p youtube-music--ipc-process)))

(defun youtube-music--mpv-sentinel (_proc event)
  "Process sentinel for the mpv subprocess.
EVENT is the `process-status' string supplied by Emacs.  When it
indicates that mpv has exited, reset cached state and clear the
mode-line indicator."
  (when (string-match-p
         "\\(exited\\|finished\\|killed\\|signal\\|deleted\\)" event)
    (setq youtube-music--mpv-process nil
          youtube-music--ipc-process nil
          youtube-music--state (list :title nil :pause t :time-pos 0
                                      :duration 0 :playlist-pos -1 :path nil)
          youtube-music--playlist-cache nil)
    (clrhash youtube-music--track-meta)
    (setq youtube-music--liked-set nil
          youtube-music--shuffled-p nil)
    (clrhash youtube-music--disliked-set)
    (youtube-music--cleanup-socket)
    (youtube-music--refresh-modeline)
    (youtube-music--rerender)))

(defun youtube-music--mpris-script-path ()
  "Return the first existing match for `youtube-music-mpv-mpris-search-paths'.
Each entry is passed through `file-expand-wildcards' so that
distro-specific directories (notably Debian/Ubuntu's multiarch
`/usr/lib/<arch>-linux-gnu/...') can be covered by a glob."
  (cl-loop for pattern in youtube-music-mpv-mpris-search-paths
           for hits = (file-expand-wildcards pattern)
           when hits return (car hits)))

(defun youtube-music--start-mpv ()
  "Spawn the mpv subprocess and wait for the IPC socket to appear."
  (let* ((sock (youtube-music--socket-path))
         (mpris (youtube-music--mpris-script-path)))
    (when (file-exists-p sock) (delete-file sock))
    (setq youtube-music--mpv-process
          (apply #'start-process
                 "youtube-music-mpv"
                 (get-buffer-create " *youtube-music-mpv*")
                 youtube-music-mpv-program
                 (append youtube-music-mpv-extra-args
                         (list (format "--input-ipc-server=%s" sock))
                         (when mpris
                           (list (format "--script=%s" mpris))))))
    (set-process-query-on-exit-flag youtube-music--mpv-process nil)
    (set-process-sentinel youtube-music--mpv-process #'youtube-music--mpv-sentinel)
    (let ((tries 0))
      (while (and (< tries 50) (not (file-exists-p sock)))
        (sleep-for 0.05)
        (cl-incf tries)))
    (unless (file-exists-p sock)
      (error "Mpv did not create IPC socket at %s" sock))
    ;; Restrict the IPC socket to the owning user.
    (set-file-modes sock #o600)))

(defun youtube-music--connect-ipc ()
  "Connect to mpv's IPC socket and start observing properties."
  (setq youtube-music--ipc-buffer "")
  (setq youtube-music--ipc-process
        (make-network-process
         :name "youtube-music-ipc"
         :family 'local
         :service (youtube-music--socket-path)
         :coding 'utf-8
         :filter #'youtube-music--ipc-filter
         :sentinel #'youtube-music--ipc-sentinel))
  (youtube-music--observe-properties))

(defun youtube-music--ensure-mpv ()
  "Start mpv and connect to its IPC socket if either is missing."
  (unless (youtube-music--mpv-running-p) (youtube-music--start-mpv))
  (unless (youtube-music--ipc-connected-p) (youtube-music--connect-ipc)))

;;;; IPC

(defun youtube-music--send (command &optional callback)
  "Send COMMAND (a list of strings/numbers) to mpv.
If CALLBACK is non-nil, it is invoked with the response plist."
  (youtube-music--ensure-mpv)
  (let* ((id (cl-incf youtube-music--request-counter))
         (payload (json-encode `((command . ,(vconcat command))
                                 (request_id . ,id)))))
    (when callback
      (puthash id callback youtube-music--pending-requests))
    (process-send-string youtube-music--ipc-process (concat payload "\n"))
    id))

(defun youtube-music--ipc-filter (_proc data)
  "Parse incoming IPC DATA from mpv and dispatch each line."
  (condition-case nil
      (progn
        (setq youtube-music--ipc-buffer (concat youtube-music--ipc-buffer data))
        (let (line)
          (while (string-match "\n" youtube-music--ipc-buffer)
            (setq line (substring youtube-music--ipc-buffer
                                  0 (match-beginning 0)))
            (setq youtube-music--ipc-buffer
                  (substring youtube-music--ipc-buffer (match-end 0)))
            (unless (string-empty-p line)
              (condition-case err
                  (youtube-music--handle-message
                   (json-parse-string line :object-type 'plist :null-object nil))
                (error (message "Youtube-music: bad IPC payload: %s -- %S"
                                line err)))))))
    (quit nil)))

(defun youtube-music--ipc-sentinel (_proc event)
  "Network process sentinel for the IPC connection.
EVENT is the `process-status' string supplied by Emacs."
  (when (string-match-p
         "\\(closed\\|exited\\|finished\\|connection broken\\|deleted\\)"
         event)
    (setq youtube-music--ipc-process nil)))

(defun youtube-music--handle-message (msg)
  "Dispatch a parsed IPC MSG plist to its callback or event handler."
  (let ((rid (plist-get msg :request_id))
        (event (plist-get msg :event))
        (err (plist-get msg :error)))
    (cond
     (rid
      (let ((cb (gethash rid youtube-music--pending-requests)))
        (cond
         (cb (remhash rid youtube-music--pending-requests)
             (funcall cb msg))
         ((and err (not (equal err "success")))
          (message "youtube-music: mpv error: %s" err)))))
     ((equal event "property-change")
      (youtube-music--apply-property
       (plist-get msg :name)
       (plist-get msg :data)))
     ((equal event "end-file")
      (let ((reason (plist-get msg :reason)))
        (when (member reason '("error" "unknown"))
          (message "youtube-music: playback ended (%s); see `youtube-music-show-log'"
                   reason)))))))

;;;; Property observation

(defconst youtube-music--observed-properties
  '("pause" "media-title" "time-pos" "duration"
    "playlist-pos" "playlist" "path"
    "loop-file" "loop-playlist")
  "List of mpv properties we subscribe to on connect.")

(defun youtube-music--observe-properties ()
  "Subscribe to every entry in `youtube-music--observed-properties'."
  (cl-loop for prop in youtube-music--observed-properties
           for i from 1
           do (youtube-music--send `("observe_property" ,i ,prop))))

(defun youtube-music--apply-property (name data)
  "Update cached state for the mpv property NAME with DATA."
  (pcase name
    ("pause"        (setq youtube-music--state
                          (plist-put youtube-music--state :pause (eq data t))))
    ("media-title"  (setq youtube-music--state
                          (plist-put youtube-music--state :title data)))
    ("time-pos"     (setq youtube-music--state
                          (plist-put youtube-music--state :time-pos (or data 0))))
    ("duration"     (setq youtube-music--state
                          (plist-put youtube-music--state :duration (or data 0))))
    ("playlist-pos" (setq youtube-music--state
                          (plist-put youtube-music--state :playlist-pos (or data -1))))
    ("playlist"     (setq youtube-music--playlist-cache
                          (when (sequencep data) (append data nil))))
    ("path"         (setq youtube-music--state
                          (plist-put youtube-music--state :path data)))
    ("loop-file"     (setq youtube-music--state
                           (plist-put youtube-music--state :loop-file
                                      (if (or (numberp data)
                                              (and (stringp data)
                                                   (member data '("inf" "yes"))))
                                          "inf" "no"))))
    ("loop-playlist" (setq youtube-music--state
                           (plist-put youtube-music--state :loop-playlist
                                      (if (or (numberp data)
                                              (and (stringp data)
                                                   (member data '("inf" "yes"))))
                                          "inf" "no")))))
  (youtube-music--refresh-modeline)
  ;; Time/pause ticks affect only the Now Playing block.  Updating just
  ;; that region (instead of erasing and rebuilding the whole buffer
  ;; every second) keeps transient overlays elsewhere — avy hints,
  ;; isearch highlights — alive between ticks.
  (pcase name
    ((or "time-pos" "duration" "pause" "media-title"
         "loop-file" "loop-playlist")
     (youtube-music--update-now-playing))
    (_ (youtube-music--rerender))))

;;;; Mode line

(defun youtube-music--format-time (seconds)
  "Format SECONDS as a m:ss string for display."
  (if (or (null seconds) (not (numberp seconds))) "0:00"
    (format "%d:%02d" (truncate (/ seconds 60)) (mod (truncate seconds) 60))))

(defun youtube-music--refresh-modeline ()
  "Recompute `youtube-music--mode-line-string' from cached state."
  (setq youtube-music--mode-line-string
        (let ((title (plist-get youtube-music--state :title))
              (pause (plist-get youtube-music--state :pause))
              (pos   (plist-get youtube-music--state :time-pos))
              (dur   (plist-get youtube-music--state :duration)))
          (if (null title) ""
            (let ((s youtube-music-modeline-format))
              (setq s (replace-regexp-in-string "%t" (or title "") s t t))
              (setq s (replace-regexp-in-string "%p" (youtube-music--format-time pos) s t t))
              (setq s (replace-regexp-in-string "%d" (youtube-music--format-time dur) s t t))
              (setq s (replace-regexp-in-string "%P" (if pause "⏸ " "") s t t))
              s))))
  (force-mode-line-update t))

;;;###autoload
(define-minor-mode youtube-music-modeline-mode
  "Show YouTube Music now-playing information in the global mode line."
  :global t
  :lighter ""
  (if youtube-music-modeline-mode
      (unless (member '(:eval youtube-music--mode-line-string) global-mode-string)
        (setq global-mode-string
              (append (or global-mode-string '(""))
                      '((:eval youtube-music--mode-line-string)))))
    (setq global-mode-string
          (delete '(:eval youtube-music--mode-line-string) global-mode-string))))

;;;; Status buffer

(defvar-keymap youtube-music-mode-map
  :doc "Keymap for `youtube-music-mode'."
  "?"   #'youtube-music-dispatch
  "h"   #'youtube-music-dispatch
  "SPC" #'youtube-music-play-pause
  "n"   #'youtube-music-next
  "p"   #'youtube-music-prev
  "x"   #'youtube-music-stop
  "f"   #'youtube-music-seek-forward
  "b"   #'youtube-music-seek-backward
  "g"   #'youtube-music-refresh
  "q"   #'quit-window
  "Q"   #'youtube-music-quit
  "RET" #'youtube-music-play-at-point
  "k"   #'youtube-music-remove-at-point
  "u"   #'youtube-music-play-url
  "e"   #'youtube-music-enqueue-url
  "S"   #'youtube-music-search
  "s"   #'youtube-music-search-enqueue
  "l"   #'youtube-music-library
  "a"   #'youtube-music-auth
  "L"   #'youtube-music-show-log
  "+"   #'youtube-music-like
  "-"   #'youtube-music-dislike
  "z"   #'youtube-music-toggle-shuffle
  "r"   #'youtube-music-cycle-repeat
  "R"   #'youtube-music-radio)

(define-derived-mode youtube-music-mode special-mode "YT-Music"
  "Major mode for the YouTube Music status buffer.
\\{youtube-music-mode-map}"
  (setq-local revert-buffer-function
              (lambda (&rest _) (youtube-music-refresh)))
  (setq-local truncate-lines t))

(defun youtube-music--status-buffer ()
  "Return the status buffer, creating it in `youtube-music-mode' if needed."
  (or (get-buffer youtube-music-buffer-name)
      (with-current-buffer (get-buffer-create youtube-music-buffer-name)
        (youtube-music-mode)
        (current-buffer))))

;;;###autoload
(defun youtube-music ()
  "Pop up the YouTube Music status buffer."
  (interactive)
  (pop-to-buffer (youtube-music--status-buffer))
  (youtube-music-refresh)
  (when (and (null youtube-music--liked-set)
             (youtube-music--logged-in-p))
    (youtube-music-refresh-liked-set)))

(defun youtube-music-refresh ()
  "Refresh the status buffer from cached state, pulling from mpv if running."
  (interactive)
  (when (youtube-music--mpv-running-p)
    (youtube-music--send '("get_property" "playlist") #'youtube-music--on-playlist))
  (youtube-music--rerender))

(defun youtube-music--on-playlist (msg)
  "Cache the playlist returned by mpv (carried in MSG) and re-render."
  (let ((data (plist-get msg :data)))
    (setq youtube-music--playlist-cache
          (when (sequencep data) (append data nil))))
  (youtube-music--rerender))

(defun youtube-music--rerender ()
  "Redraw the status buffer if it exists, preserving point and scroll."
  (when-let* ((buf (get-buffer youtube-music-buffer-name)))
    (with-current-buffer buf
      (let* ((inhibit-read-only t)
             (line (line-number-at-pos))
             (col (current-column))
             ;; Capture window-start per window so the view doesn't
             ;; snap to the top on every property tick.
             (window-states
              (mapcar (lambda (w)
                        (cons w (line-number-at-pos (window-start w))))
                      (get-buffer-window-list buf nil t))))
        (erase-buffer)
        (youtube-music--render-now-playing)
        (youtube-music--render-queue)
        (youtube-music--render-sources)
        (youtube-music--render-status)
        (youtube-music--render-help)
        (goto-char (point-min))
        (forward-line (1- line))
        (move-to-column col)
        (dolist (ws window-states)
          (let ((w (car ws))
                (start-line (cdr ws)))
            (when (window-live-p w)
              (set-window-start
               w
               (save-excursion
                 (goto-char (point-min))
                 (forward-line (1- start-line))
                 (point))
               t))))))))

(defun youtube-music--insert-heading (text)
  "Insert TEXT as a section heading."
  (insert (propertize text 'face 'youtube-music-section-heading) "\n"))

(defun youtube-music--render-progress (pos dur width)
  "Return a propertized progress bar of WIDTH columns for POS/DUR."
  (if (or (not (numberp pos)) (not (numberp dur)) (<= dur 0))
      (propertize (make-string width ?░) 'face 'youtube-music-progress-empty)
    (let ((filled (truncate (* width (/ (float pos) dur)))))
      (concat (propertize (make-string filled ?█)
                          'face 'youtube-music-progress-fill)
              (propertize (make-string (max 0 (- width filled)) ?░)
                          'face 'youtube-music-progress-empty)))))

(defun youtube-music--insert-now-playing-body ()
  "Insert the title/progress lines of the Now Playing section.
The inserted region is tagged with `youtube-music-now-playing' so
that `youtube-music--update-now-playing' can find it later and
refresh it in place without disturbing the rest of the buffer."
  (let* ((mpv-title (plist-get youtube-music--state :title))
         (path  (plist-get youtube-music--state :path))
         (pause (plist-get youtube-music--state :pause))
         (pos   (plist-get youtube-music--state :time-pos))
         (dur   (plist-get youtube-music--state :duration))
         (title (and (or mpv-title path)
                     (youtube-music--display-title-for path mpv-title)))
         (start (point)))
    (if (null title)
        (insert "  (nothing playing)\n")
      (let ((glyph (youtube-music--current-rating-glyph))
            (badges (youtube-music--mode-badges)))
        (insert "  " (if pause "⏸" "▶") " "
                (propertize title 'face 'youtube-music-current-track)
                (if glyph (concat "  " glyph) "")
                badges
                "\n")
        (insert (format "  %s   %s / %s\n"
                        (youtube-music--render-progress
                         pos dur youtube-music-progress-bar-width)
                        (youtube-music--format-time pos)
                        (youtube-music--format-time dur)))))
    (put-text-property start (point) 'youtube-music-now-playing t)))

(defun youtube-music--render-now-playing ()
  "Render the Now Playing section."
  (youtube-music--insert-heading "── Now Playing ──")
  (youtube-music--insert-now-playing-body)
  (insert "\n"))

(defun youtube-music--update-now-playing ()
  "Refresh only the Now Playing block in place.
Falls back to a full rerender if the tagged region is missing
\(e.g. before the first paint)."
  (if-let* ((buf (get-buffer youtube-music-buffer-name)))
      (with-current-buffer buf
        (let ((beg (text-property-any (point-min) (point-max)
                                      'youtube-music-now-playing t)))
          (if (null beg)
              (youtube-music--rerender)
            (let* ((inhibit-read-only t)
                   (end (or (text-property-not-all
                             beg (point-max) 'youtube-music-now-playing t)
                            (point-max))))
              (save-excursion
                (delete-region beg end)
                (goto-char beg)
                (youtube-music--insert-now-playing-body))))))))

(defun youtube-music--render-queue ()
  "Render the queue section.
Shows every track in mpv's playlist; played entries are dimmed,
the currently-playing entry is highlighted with a leading arrow."
  (youtube-music--insert-heading "── Queue ──")
  (let* ((items youtube-music--playlist-cache)
         (cur   (plist-get youtube-music--state :playlist-pos)))
    (if (null items)
        (insert "  (queue empty)\n")
      (cl-loop
       for entry in items
       for i from 0
       do (let* ((filename (plist-get entry :filename))
                 (mpv-title (plist-get entry :title))
                 (title (youtube-music--display-title-for filename mpv-title))
                 (vid     (youtube-music--video-id-from-url filename))
                 (rating  (youtube-music--rating-glyph-for vid))
                 (current (and cur (= i cur)))
                 (past    (and cur (< i cur)))
                 (marker  (if current "▶" " "))
                 (face    (cond (current 'youtube-music-queue-current)
                                (past   'youtube-music-queue-past)
                                (t      'default)))
                 (line    (format " %s %2d  %s%s\n"
                                  marker (1+ i) title
                                  (if rating (concat "  " rating) ""))))
            (insert (propertize line
                                'face face
                                'youtube-music-playlist-index i))))))
  (insert "\n"))

(defun youtube-music--render-sources ()
  "Render the Sources section."
  (youtube-music--insert-heading "── Sources ──")
  (insert "  s  Search (enqueue)    S  Search (replace)\n")
  (insert "  u  Play URL            e  Enqueue URL\n")
  (insert "  l  Library (liked, playlists, home)\n")
  (insert "\n"))

(defun youtube-music--render-status ()
  "Render the auth status section.
Distinguishes three states:
  signed in              → server accepts our cookie,
  cookie expired         → credentials file exists but server rejects,
  not signed in (fresh)  → no credentials saved yet."
  (youtube-music--insert-heading "── Status ──")
  (let ((have-creds (file-exists-p youtube-music-credentials-file)))
    (pcase youtube-music--auth-state
      ('logged-in
       (insert "  "
               (propertize "● signed in" 'face 'youtube-music-auth-ok)
               (if youtube-music--account-name
                   (format " as %s" youtube-music--account-name)
                 "")
               "\n"))
      ('refreshing
       (insert "  ● refreshing cookie from your browser...\n"))
      ('logged-out
       (cond
        (have-creds
         (insert "  "
                 (propertize "⚠ cookie expired" 'face 'youtube-music-auth-error)
                 " — run `a' then `l' to paste a fresh cookie\n"))
        (t
         (insert "  "
                 (propertize "○ not signed in" 'face 'youtube-music-auth-error)
                 " — run `a' then `l' to log in for the first time\n"))))
      (_
       (cond
        (have-creds
         (insert "  ● auth state unknown — run any library command to probe\n"))
        (t
         (insert "  "
                 (propertize "○ not signed in" 'face 'youtube-music-auth-error)
                 " — run `a' then `l' to log in\n"))))))
  (insert "\n"))

(defun youtube-music--render-help ()
  "Render the in-buffer help line."
  (insert (propertize
           "  ? menu   SPC pause  n next  p prev  x stop  f/b seek    g refresh  q bury  Q quit\n"
           'face 'youtube-music-help)))

;;;; Commands acting on the status buffer

;;;###autoload
(defun youtube-music-play-at-point ()
  "Play the playlist entry at point."
  (interactive)
  (let ((idx (get-text-property (point) 'youtube-music-playlist-index)))
    (if idx (youtube-music--send `("playlist-play-index" ,idx))
      (user-error "No track at point"))))

;;;###autoload
(defun youtube-music-remove-at-point ()
  "Remove the playlist entry at point.
On the Now Playing line, stop playback instead."
  (interactive)
  (let ((idx (get-text-property (point) 'youtube-music-playlist-index)))
    (cond
     (idx (youtube-music--send `("playlist-remove" ,idx)))
     ((get-text-property (point) 'youtube-music-now-playing)
      (youtube-music-stop))
     (t (user-error "Nothing to remove at point")))))

;;;; Playback commands

;;;###autoload
(defun youtube-music-play-url (url)
  "Replace the current playlist with URL and start playing it."
  (interactive "sYouTube URL: ")
  (youtube-music--send `("loadfile" ,url "replace")))

;;;###autoload
(defun youtube-music-enqueue-url (url)
  "Append URL to the mpv playlist."
  (interactive "sYouTube URL: ")
  (youtube-music--send `("loadfile" ,url "append-play")))

(defun youtube-music--no-track-p ()
  "Return non-nil when there is no track loaded in mpv."
  (and (null (plist-get youtube-music--state :title))
       (null (plist-get youtube-music--state :path))))

(defun youtube-music--require-track ()
  "Signal a `user-error' if no track is loaded."
  (when (youtube-music--no-track-p)
    (user-error
     "No track loaded — run `M-x youtube-music' and search or pick from your library to start something")))

;;;###autoload
(defun youtube-music-play-pause ()
  "Toggle play / pause."
  (interactive)
  (youtube-music--require-track)
  (youtube-music--send '("cycle" "pause")))

;;;###autoload
(defun youtube-music-play ()
  "Resume playback (un-pause)."
  (interactive)
  (youtube-music--require-track)
  (youtube-music--send '("set" "pause" "no")))

;;;###autoload
(defun youtube-music-stop ()
  "Stop playback by pausing and resetting position to the start.
Leaves the current playlist intact."
  (interactive)
  (youtube-music--require-track)
  (youtube-music--send '("seek" 0 "absolute"))
  (youtube-music--send '("set" "pause" "yes")))

;;;###autoload
(defun youtube-music-toggle-shuffle ()
  "Shuffle (or un-shuffle) the current mpv playlist.
Uses mpv's `playlist-shuffle' / `playlist-unshuffle' commands so
that subsequent `youtube-music-next' calls follow the new order.
The playing track is moved back to the top after shuffling --
mpv shuffles it along with everything else, which would strand a
random prefix of the queue as \"already played\".  Un-shuffling
still restores the original order (mpv sorts by each entry's
original index, which the move does not disturb)."
  (interactive)
  (youtube-music--require-track)
  (cond
   (youtube-music--shuffled-p
    (youtube-music--send '("playlist-unshuffle"))
    (setq youtube-music--shuffled-p nil)
    (message "youtube-music: shuffle off"))
   (t
    (youtube-music--send '("playlist-shuffle"))
    (youtube-music--send
     '("get_property" "playlist-pos")
     (lambda (msg)
       (let ((pos (plist-get msg :data)))
         (when (and (numberp pos) (> pos 0))
           (youtube-music--send `("playlist-move" ,pos 0))))))
    (setq youtube-music--shuffled-p t)
    (message "youtube-music: shuffle on")))
  (youtube-music--rerender))

;;;###autoload
(defun youtube-music-cycle-repeat ()
  "Cycle repeat mode: off → repeat-playlist → repeat-track → off."
  (interactive)
  (youtube-music--require-track)
  (let* ((file (plist-get youtube-music--state :loop-file))
         (pl   (plist-get youtube-music--state :loop-playlist))
         (mode (cond
                ((equal file "inf") 'track)
                ((equal pl   "inf") 'playlist)
                (t 'off))))
    (pcase mode
      ('off
       (youtube-music--send '("set" "loop-playlist" "inf"))
       (youtube-music--send '("set" "loop-file" "no"))
       (message "youtube-music: repeat playlist"))
      ('playlist
       (youtube-music--send '("set" "loop-playlist" "no"))
       (youtube-music--send '("set" "loop-file" "inf"))
       (message "youtube-music: repeat track"))
      ('track
       (youtube-music--send '("set" "loop-file" "no"))
       (youtube-music--send '("set" "loop-playlist" "no"))
       (message "youtube-music: repeat off")))))

(defun youtube-music--mode-badges ()
  "Return propertized status badges for shuffle/repeat, or empty string."
  (let* ((file (plist-get youtube-music--state :loop-file))
         (pl   (plist-get youtube-music--state :loop-playlist))
         badges)
    (when youtube-music--shuffled-p
      (push (youtube-music--glyph 'shuffle) badges))
    (cond
     ((equal file "inf") (push (youtube-music--glyph 'repeat-one) badges))
     ((equal pl   "inf") (push (youtube-music--glyph 'repeat-all) badges)))
    (if badges (concat "  " (string-join (nreverse badges) " ")) "")))

(defun youtube-music--send-or-explain (command explanation)
  "Send COMMAND to mpv; on failure show EXPLANATION instead of the raw error."
  (youtube-music--send
   command
   (lambda (msg)
     (let ((err (plist-get msg :error)))
       (unless (equal err "success")
         (message "youtube-music: %s" explanation))))))

;;;###autoload
(defun youtube-music-next ()
  "Skip to the next track in the playlist."
  (interactive)
  (youtube-music--require-track)
  (let ((pos (plist-get youtube-music--state :playlist-pos))
        (count (length youtube-music--playlist-cache)))
    (if (and (>= pos 0) (> count 0) (>= pos (1- count))
             (not (equal (plist-get youtube-music--state :loop-playlist) "inf")))
        (message "youtube-music: already at the last track")
      (youtube-music--send-or-explain
       '("playlist-next" "weak")
       "cannot skip forward right now (last track, or still loading)"))))

;;;###autoload
(defun youtube-music-prev ()
  "Skip to the previous track in the playlist.
On the first track, restart it instead."
  (interactive)
  (youtube-music--require-track)
  (if (and (eql (plist-get youtube-music--state :playlist-pos) 0)
           (not (equal (plist-get youtube-music--state :loop-playlist) "inf")))
      (youtube-music--send-or-explain
       '("seek" 0 "absolute")
       "already at the first track")
    (youtube-music--send-or-explain
     '("playlist-prev" "weak")
     "cannot skip back right now (first track, or still loading)")))

;;;###autoload
(defun youtube-music-seek-forward ()
  "Seek forward by `youtube-music-seek-step' seconds."
  (interactive)
  (youtube-music--require-track)
  (youtube-music--send `("seek" ,youtube-music-seek-step "relative")))

;;;###autoload
(defun youtube-music-seek-backward ()
  "Seek backward by `youtube-music-seek-step' seconds."
  (interactive)
  (youtube-music--require-track)
  (youtube-music--send `("seek" ,(- youtube-music-seek-step) "relative")))

;;;###autoload
(defun youtube-music-show-log ()
  "Display the buffer containing mpv's stdout/stderr."
  (interactive)
  (let ((buf (get-buffer " *youtube-music-mpv*")))
    (if buf (pop-to-buffer buf)
      (message "youtube-music: no log buffer yet (mpv has not been started)"))))

;;;###autoload
(defun youtube-music-quit ()
  "Quit the player and clear the mode line.
After this, system-level media controllers (`playerctl', waybar
mpris module, etc.) stop seeing a YouTube Music player.  Use
`youtube-music' (or `C-c y') to start it again."
  (interactive)
  (when (youtube-music--ipc-connected-p)
    (ignore-errors (youtube-music--send '("quit")))
    (delete-process youtube-music--ipc-process))
  (when (youtube-music--mpv-running-p)
    (delete-process youtube-music--mpv-process))
  (setq youtube-music--ipc-process nil
        youtube-music--mpv-process nil
        youtube-music--mode-line-string ""
        youtube-music--state (list :title nil :pause t :time-pos 0
                                    :duration 0 :playlist-pos -1 :path nil)
        youtube-music--playlist-cache nil)
  (clrhash youtube-music--track-meta)
  (setq youtube-music--liked-set nil)
  (clrhash youtube-music--disliked-set)
  (youtube-music--cleanup-socket)
  (force-mode-line-update t)
  (when-let* ((win (get-buffer-window youtube-music-buffer-name t)))
    (quit-window nil win)))

;;;; Authentication

(defcustom youtube-music-credentials-file
  (let* ((dir (or (getenv "XDG_CONFIG_HOME") "~/.config"))
         (subdir (expand-file-name "youtube-music" dir)))
    (expand-file-name "credentials.eld" subdir))
  "File path for stored credentials.
Use a `.gpg' suffix to have Emacs encrypt the file via EPA.  The
file is created with mode 0600."
  :type 'file)

(defvar youtube-music--cookie nil
  "Cached Cookie header for music.youtube.com API requests.")

(defvar youtube-music--sapisid nil
  "Cached SAPISID value, extracted from the cookie.")

(defun youtube-music--extract-sapisid (cookie)
  "Pluck the SAPISID value out of COOKIE string, or return nil."
  (when (and cookie (string-match "\\bSAPISID=\\([^;]+\\)" cookie))
    (match-string 1 cookie)))

(defun youtube-music--credentials-load ()
  "Read and return the credentials plist from disk, or nil."
  (when (file-readable-p youtube-music-credentials-file)
    (with-temp-buffer
      (insert-file-contents youtube-music-credentials-file)
      (goto-char (point-min))
      (condition-case nil (read (current-buffer)) (error nil)))))

(defun youtube-music--credentials-save (plist)
  "Save PLIST to `youtube-music-credentials-file' with mode 0600."
  (let ((dir (file-name-directory youtube-music-credentials-file)))
    (unless (file-directory-p dir) (make-directory dir t)))
  (with-temp-file youtube-music-credentials-file
    (let ((print-length nil) (print-level nil))
      (prin1 plist (current-buffer))))
  (set-file-modes youtube-music-credentials-file #o600))

(defun youtube-music--auth-load ()
  "Hydrate `youtube-music--cookie' / `youtube-music--sapisid' from disk."
  (unless youtube-music--cookie
    (when-let* ((creds (youtube-music--credentials-load)))
      (setq youtube-music--cookie (plist-get creds :cookie)
            youtube-music--sapisid (youtube-music--extract-sapisid
                                    youtube-music--cookie)))))

(defvar-keymap youtube-music-login-mode-map
  :doc "Keymap for `youtube-music-login-mode'."
  "C-c C-c" #'youtube-music-login-finish
  "C-c C-k" #'youtube-music-login-cancel)

(define-derived-mode youtube-music-login-mode text-mode "YT-Login"
  "Major mode for pasting the YouTube Music cookie header.")

(defun youtube-music--logged-in-p ()
  "Return non-nil if a usable cookie is loaded or available on disk."
  (youtube-music--auth-load)
  (and youtube-music--cookie t))

;;;###autoload
(defun youtube-music-login-paste ()
  "Open a buffer for pasting the YouTube Music cookie header.
Press \\<youtube-music-login-mode-map>\\[youtube-music-login-finish] to save, \
\\[youtube-music-login-cancel] to cancel."
  (interactive)
  (let ((buf (get-buffer-create "*youtube-music-login*")))
    (with-current-buffer buf
      (youtube-music-login-mode)
      (let ((inhibit-read-only t))
        (erase-buffer)
        (insert
         "Paste your YouTube Music Cookie header below the line, then press\n"
         "C-c C-c to save, or C-c C-k to cancel.\n\n"
         "How to obtain it:\n"
         "  1. Open https://music.youtube.com (signed in) in a browser.\n"
         "  2. Open DevTools (F12) and switch to the Network tab.\n"
         "  3. Refresh the page and click any music.youtube.com request.\n"
         "  4. Copy the entire 'Cookie' request header value.\n"
         "  5. Make sure it contains 'SAPISID=...'.\n"
         "----------------------------------------------------------------\n"))
      (goto-char (point-max)))
    (pop-to-buffer buf)))

(defun youtube-music--apply-cookie (cookie source)
  "Save COOKIE to disk, set in-memory state, kick off auth probe.
SOURCE is a label used in the success message."
  (youtube-music--credentials-save (list :cookie cookie))
  (setq youtube-music--cookie cookie
        youtube-music--sapisid (youtube-music--extract-sapisid cookie)
        youtube-music--account-name nil
        youtube-music--auto-refresh-attempted nil)
  (youtube-music-fetch-account-info)
  (youtube-music--rerender)
  (message "youtube-music: logged in via %s" source))

(defconst youtube-music--cookie-source-browsers
  '("firefox" "chromium" "brave" "chrome" "edge" "safari")
  "Browsers probed for a YouTube cookie via `yt-dlp --cookies-from-browser'.
The order is the probe order; the first browser yielding a usable
cookie wins.  yt-dlp also supports `opera', `vivaldi', and
`whale' — add them locally if you need them.")

;;;###autoload
(defun youtube-music-login ()
  "Log in to YouTube Music.
Probes every browser yt-dlp can read.  If exactly one yields a
usable cookie, uses it.  If several do, prompts you to pick.  If
none, falls back to the manual paste flow."
  (interactive)
  (let* ((hits (and (executable-find "yt-dlp")
                    (progn (message "youtube-music: probing browsers...")
                           (cl-loop for b in youtube-music--cookie-source-browsers
                                    for c = (youtube-music--extract-cookie-via-browser b)
                                    when c collect (cons b c))))))
    (pcase (length hits)
      (0 (youtube-music-login-paste))
      (1 (youtube-music--apply-cookie (cdr (car hits)) (car (car hits))))
      (_ (let* ((choice (completing-read
                         "Multiple browsers signed in — pick one: "
                         (mapcar #'car hits) nil t))
                (cookie (cdr (assoc choice hits))))
           (when cookie (youtube-music--apply-cookie cookie choice)))))))

(defun youtube-music-login-finish ()
  "Save the cookie pasted in the current login buffer."
  (interactive)
  (goto-char (point-min))
  (unless (re-search-forward "^-+\n" nil t)
    (user-error "Login buffer is malformed"))
  (let ((cookie (string-trim
                 (buffer-substring-no-properties (point) (point-max)))))
    (cond
     ((string-empty-p cookie)
      (user-error "Cookie is empty; paste it after the line and try again"))
     ((not (youtube-music--extract-sapisid cookie))
      (user-error "Pasted text has no SAPISID=... entry; copy a fresh cookie"))
     (t
      (youtube-music--credentials-save (list :cookie cookie))
      (setq youtube-music--cookie cookie
            youtube-music--sapisid (youtube-music--extract-sapisid cookie)
            youtube-music--account-name nil)
      (youtube-music-fetch-account-info)
      (youtube-music--rerender)
      (message "youtube-music: logged in (cookie saved to %s)"
               youtube-music-credentials-file)
      (kill-buffer (current-buffer))))))

(defun youtube-music-login-cancel ()
  "Cancel the login and discard the buffer."
  (interactive)
  (kill-buffer (current-buffer)))

;;;; Browser-based login (auto-extract via yt-dlp)

(defconst youtube-music--auth-cookie-names
  '("SAPISID" "__Secure-1PAPISID" "__Secure-3PAPISID"
    "SID"     "__Secure-1PSID"    "__Secure-3PSID"
              "__Secure-1PSIDTS"  "__Secure-3PSIDTS"
    "HSID" "SSID" "APISID"
    "LOGIN_INFO" "VISITOR_INFO1_LIVE" "VISITOR_PRIVACY_METADATA"
    "PREF" "YSC")
  "Cookie names kept when extracting from a browser.
yt-dlp dumps ~170 cookies under youtube.com, which is too large
for the API server to accept (HTTP 413).  We keep only those that
matter for authentication.")

(defun youtube-music--extract-cookie-via-browser (browser)
  "Use yt-dlp to dump cookies from BROWSER; return a Cookie header or nil.
Only the names in `youtube-music--auth-cookie-names' are kept."
  (let ((tmp (make-temp-file "ytmusic-cookies-" nil ".txt")))
    (unwind-protect
        (progn
          (with-temp-file tmp (insert "# Netscape HTTP Cookie File\n"))
          (call-process "yt-dlp" nil nil nil
                        "--cookies-from-browser" browser
                        "--cookies" tmp
                        "--simulate" "--quiet" "--ignore-errors"
                        "--skip-download"
                        "https://music.youtube.com")
          (with-temp-buffer
            (insert-file-contents tmp)
            (goto-char (point-min))
            (let (parts)
              (while (not (eobp))
                (let ((line (buffer-substring-no-properties
                             (line-beginning-position) (line-end-position))))
                  (unless (or (string-empty-p line) (string-prefix-p "#" line))
                    (let ((fields (split-string line "\t")))
                      (when (and (>= (length fields) 7)
                                 (string-match-p "youtube\\.com" (nth 0 fields))
                                 (member (nth 5 fields)
                                         youtube-music--auth-cookie-names))
                        (push (format "%s=%s" (nth 5 fields) (nth 6 fields))
                              parts)))))
                (forward-line 1))
              (let ((cookie (mapconcat #'identity (nreverse parts) "; ")))
                (and (youtube-music--extract-sapisid cookie) cookie)))))
      (when (file-exists-p tmp) (delete-file tmp)))))


;;;###autoload
(defun youtube-music-logout ()
  "Forget the saved YouTube Music credentials.
Deletes `youtube-music-credentials-file' and clears in-memory cookie."
  (interactive)
  (when (file-exists-p youtube-music-credentials-file)
    (delete-file youtube-music-credentials-file))
  (setq youtube-music--cookie nil
        youtube-music--sapisid nil
        youtube-music--auth-state 'logged-out
        youtube-music--account-name nil
        youtube-music--auto-refresh-attempted nil)
  (youtube-music--rerender)
  (message "youtube-music: logged out"))

;;;###autoload
(defun youtube-music-auth-status ()
  "Echo whether the user is currently logged in."
  (interactive)
  (message "youtube-music: %s"
           (if (youtube-music--logged-in-p) "logged in" "logged out")))

;;;###autoload (autoload 'youtube-music-auth "youtube-music" nil t)
(transient-define-prefix youtube-music-auth ()
  "Manage YouTube Music authentication.
The current sign-in state is shown in the Status section of the
`*youtube-music*' buffer."
  ["Authentication"
   ("l" "Login"  youtube-music-login)
   ("o" "Logout" youtube-music-logout)])

;;;; YouTube Music HTTP client

(defcustom youtube-music-client-version "1.20250101.01.00"
  "Client version string sent in the WEB_REMIX context.
Bump this when YouTube changes the wire protocol."
  :type 'string)

(defcustom youtube-music-user-agent
  (concat "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
          "Chrome/120.0.0.0 Safari/537.36")
  "User-Agent string sent with API requests."
  :type 'string)

(defconst youtube-music--api-base "https://music.youtube.com/youtubei/v1"
  "Base URL for the WEB_REMIX internal API.")

(defconst youtube-music--api-origin "https://music.youtube.com"
  "Origin header value for API requests.")

(defconst youtube-music--api-key "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30"
  "Public API key identifying us as the WEB_REMIX (YT Music web) client.
Not a personal credential -- it's the same fixed value every
browser session at music.youtube.com sends, used by the server
to identify the client *application*, not the user.  Auth is
done separately via the SAPISIDHASH header.")

(defun youtube-music--sapisid-hash (sapisid origin)
  "Build the `Authorization: SAPISIDHASH ...' value.
SAPISID is the SAPISID cookie value; ORIGIN is the request origin."
  (let* ((ts (number-to-string (truncate (float-time))))
         (digest (secure-hash 'sha1 (format "%s %s %s" ts sapisid origin))))
    (format "SAPISIDHASH %s_%s" ts digest)))

(defun youtube-music--youtubei-post (endpoint body callback &optional extra-query)
  "POST BODY (an alist) to ENDPOINT under `youtube-music--api-base'.
Calls CALLBACK with the parsed response plist (or nil on error).
EXTRA-QUERY, if non-nil, is appended to the URL query string."
  (youtube-music--auth-load)
  (unless youtube-music--cookie
    (user-error "Not logged in; run `M-x youtube-music-login' first"))
  (let* ((url (concat youtube-music--api-base "/" endpoint
                      "?key=" youtube-music--api-key
                      "&prettyPrint=false&alt=json"
                      (if extra-query (concat "&" extra-query) "")))
         (full-body
          (cons `(context . ((client . ((clientName . "WEB_REMIX")
                                         (clientVersion . ,youtube-music-client-version)
                                         (hl . "en")
                                         (gl . "US")))
                             (user . ,(make-hash-table))))
                body))
         (json-body (json-encode full-body))
         (auth (youtube-music--sapisid-hash
                youtube-music--sapisid
                youtube-music--api-origin))
         (url-request-method "POST")
         ;; Header values must be unibyte: url-http rejects a request
         ;; whose assembled string contains multibyte text, and the
         ;; cookie (read from disk into a multibyte buffer) would
         ;; otherwise flip the concatenated request to multibyte the
         ;; moment the body carries a non-ASCII query.
         (url-request-extra-headers
          (mapcar (lambda (h)
                    (cons (car h) (encode-coding-string (cdr h) 'utf-8)))
                  `(("User-Agent" . ,youtube-music-user-agent)
                    ("Cookie" . ,youtube-music--cookie)
                    ("Authorization" . ,auth)
                    ("X-Origin" . ,youtube-music--api-origin)
                    ("X-Goog-AuthUser" . "0")
                    ("Origin" . ,youtube-music--api-origin)
                    ("Content-Type" . "application/json; charset=UTF-8")
                    ("Accept" . "*/*"))))
         (url-request-data (encode-coding-string json-body 'utf-8)))
    (url-retrieve url
                  (lambda (status)
                    (condition-case nil
                        (let ((response (youtube-music--read-response status)))
                          (youtube-music--observe-auth response)
                          (funcall callback response))
                      (quit nil)))
                  nil t t)))

(defun youtube-music--read-response (status)
  "Extract and parse the JSON body from the current `url-retrieve' buffer.
STATUS is the plist passed by `url-retrieve' to its callback."
  (let ((buf (current-buffer))
        body data)
    (when (plist-get status :error)
      (message "youtube-music: HTTP error: %S" (plist-get status :error)))
    (goto-char (point-min))
    (when (re-search-forward "\r?\n\r?\n" nil t)
      (setq body (buffer-substring-no-properties (point) (point-max))))
    (kill-buffer buf)
    (when (and body (> (length (string-trim body)) 0))
      (condition-case err
          (setq data (json-parse-string body :object-type 'plist :null-object nil))
        (error (message "youtube-music: parse error: %S" err))))
    data))

;;;; API response parsers

(defun youtube-music--get-in (obj path)
  "Walk PATH (a vector of keys/indices) into OBJ; return nil on miss.
Symbol/keyword keys go through `plist-get'; integer keys index vectors."
  (let ((cur obj))
    (cl-loop for key across path
             while cur
             do (setq cur
                      (cond
                       ((and (vectorp cur) (numberp key) (< key (length cur)))
                        (aref cur key))
                       ((listp cur) (plist-get cur key))
                       (t nil))))
    cur))

(defun youtube-music--flex-text (col)
  "Concatenate text from each run in a flex COL of `musicResponsiveListItem'."
  (let ((runs (youtube-music--get-in
               col [:musicResponsiveListItemFlexColumnRenderer :text :runs])))
    (when runs
      (mapconcat (lambda (r) (or (plist-get r :text) "")) runs ""))))

(defun youtube-music--parse-list-item (item)
  "Parse a `musicResponsiveListItemRenderer' ITEM into a result plist.
Returns plist with :title, :subtitle, :video-id, or nil on miss."
  (when-let* ((mrli (plist-get item :musicResponsiveListItemRenderer)))
    (let* ((flex (plist-get mrli :flexColumns))
           (title (when (and flex (> (length flex) 0))
                    (youtube-music--flex-text (aref flex 0))))
           (subtitle (when (and flex (> (length flex) 1))
                       (youtube-music--flex-text (aref flex 1))))
           (video-id
            (or (youtube-music--get-in mrli [:playlistItemData :videoId])
                (and flex (> (length flex) 0)
                     (let ((runs (youtube-music--get-in
                                  (aref flex 0)
                                  [:musicResponsiveListItemFlexColumnRenderer
                                   :text :runs])))
                       (when (and runs (> (length runs) 0))
                         (youtube-music--get-in
                          (aref runs 0)
                          [:navigationEndpoint :watchEndpoint :videoId])))))))
      (when (and title video-id)
        (list :title title :subtitle (or subtitle "") :video-id video-id)))))

(defconst youtube-music--search-page-type-kinds
  '(("MUSIC_PAGE_TYPE_ALBUM"    . album)
    ("MUSIC_PAGE_TYPE_PLAYLIST" . playlist))
  "Map of browseEndpoint pageType values to item kinds.
Kinds we cannot queue directly (artists, profiles, podcast shows)
are deliberately absent; results of those kinds are dropped.")

(defun youtube-music--clean-subtitle (subtitle)
  "Drop the leading category token from a search-result SUBTITLE.
Flat-layout search results prefix it with \"Song • \", \"Video • \",
\"Artist • \", etc.  The category is already conveyed by the
result's group heading (and song vs video makes no difference to
an audio-only player), so it is pure noise here.  Episodes keep
their prefix: landing in an hour-long podcast is worth flagging."
  (if (and subtitle
           (string-match
            "\\`\\(?:Song\\|Video\\|Album\\|Playlist\\|Artist\\|Profile\\) • "
            subtitle))
      (substring subtitle (match-end 0))
    (or subtitle "")))

(defun youtube-music--parse-search-item (item)
  "Parse search-result ITEM into a plist tagged with a :kind.
Albums, playlists, and artists yield (:kind album|playlist|artist
:browse-id ...); anything with a videoId falls back to (:kind song
:video-id ...).  All carry :title and :subtitle.  Returns nil for
shapes we cannot play."
  (when-let* ((mrli (plist-get item :musicResponsiveListItemRenderer)))
    (let* ((browse-id (youtube-music--get-in
                       mrli [:navigationEndpoint :browseEndpoint :browseId]))
           (page-type (youtube-music--get-in
                       mrli [:navigationEndpoint :browseEndpoint
                             :browseEndpointContextSupportedConfigs
                             :browseEndpointContextMusicConfig :pageType]))
           (kind (cdr (assoc page-type youtube-music--search-page-type-kinds))))
      (if (and browse-id kind)
          (let* ((flex (plist-get mrli :flexColumns))
                 (title (when (and flex (> (length flex) 0))
                          (youtube-music--flex-text (aref flex 0))))
                 (subtitle (when (and flex (> (length flex) 1))
                             (youtube-music--flex-text (aref flex 1)))))
            (when title
              (list :title title
                    :subtitle (youtube-music--clean-subtitle subtitle)
                    :kind kind :browse-id browse-id)))
        (when-let* ((song (youtube-music--parse-list-item item)))
          (plist-put song :subtitle
                     (youtube-music--clean-subtitle
                      (plist-get song :subtitle)))
          (append song (list :kind 'song)))))))

(defconst youtube-music--search-songs-params
  "EgWKAQIIAWoMEA4QChADEAQQCRAF"
  "Search params blob restricting results to songs.
Same fixed value the web client sends; not account-specific.")

(defconst youtube-music--search-playlists-params
  "EgeKAQQoAEABagwQDhAKEAMQBBAJEAU%3D"
  "Search params blob restricting results to community playlists.
Community playlists are the user-curated ones -- exactly what a
search like \"<artist> greatest hits\" should surface.  Same fixed
value the web client sends; not account-specific.")

(defun youtube-music--parse-search-items (response)
  "Extract parsed items from a filtered search RESPONSE.
Walks every `musicShelfRenderer' under the first search tab and
returns the concatenated `youtube-music--parse-search-item' plists."
  (let ((sections (youtube-music--get-in
                   response [:contents :tabbedSearchResultsRenderer
                             :tabs 0 :tabRenderer :content
                             :sectionListRenderer :contents])))
    (when sections
      (cl-loop
       for section across sections
       ;; Some layouts wrap the shelf in a one-element
       ;; itemSectionRenderer; unwrap transparently.
       for shelf = (or (plist-get section :musicShelfRenderer)
                       (youtube-music--get-in
                        section [:itemSectionRenderer :contents 0
                                 :musicShelfRenderer]))
       when shelf
       nconc (cl-loop
              for e across (or (plist-get shelf :contents) [])
              for p = (youtube-music--parse-search-item e)
              when p collect p)))))

;;;; Search command

(defvar youtube-music--search-history nil
  "Minibuffer history for search queries.")

(defvar youtube-music--pick-history nil
  "Minibuffer history for result-pick prompts.
Kept separate from `youtube-music--search-history' and from the
global `minibuffer-history' so that recalling history in the
search prompt yields previous queries, never result labels.")

(defun youtube-music--mixed-kinds-p (items)
  "Return non-nil when ITEMS do not all share the same :kind."
  (let ((first (plist-get (car items) :kind)))
    (cl-some (lambda (it) (not (eq (plist-get it :kind) first)))
             (cdr items))))

(defun youtube-music--item-label (item &optional with-kind)
  "Return the completion label for ITEM.
When WITH-KIND is non-nil the item's kind leads the label
\(\"Artist: ...\"), so mixed-kind lists say up front what pressing
RET will do."
  (let* ((title (plist-get item :title))
         (sub (or (plist-get item :subtitle) ""))
         (base (if (string-empty-p sub) title
                 (format "%s — %s" title sub))))
    (if with-kind
        (format "%s: %s"
                (capitalize (symbol-name (plist-get item :kind)))
                base)
      base)))

(defun youtube-music--search-candidates (shelves)
  "Flatten SHELVES into an ordered alist of (LABEL . ITEM).
Labels carry a `youtube-music-group' text property naming their
shelf, which the completion UI turns into group headings.  In
shelves that mix kinds each label leads with its kind.  A shelf
with a :limit smaller than its item count is truncated there and
gets a trailing \"More ...\" entry carrying the full list."
  (let ((seen (make-hash-table :test 'equal))
        cands)
    (cl-flet ((add (label item group)
                (let ((n (gethash label seen 0)))
                  (puthash label (1+ n) seen)
                  (when (> n 0) (setq label (format "%s (%d)" label (1+ n)))))
                (push (cons (propertize label 'youtube-music-group group) item)
                      cands)))
      (dolist (shelf shelves)
        (let* ((group (plist-get shelf :title))
               (items (plist-get shelf :items))
               (limit (plist-get shelf :limit))
               (truncated (and limit (> (length items) limit)))
               (shown (if truncated (take limit items) items))
               (mixed (youtube-music--mixed-kinds-p shown)))
          (dolist (item shown)
            (add (youtube-music--item-label item mixed) item group))
          (when truncated
            (add (format "More %s… (%d more)"
                         (downcase group) (- (length items) limit))
                 (list :kind 'expand :title group :items items)
                 group)))))
    (nreverse cands)))

(defun youtube-music--candidate-group (candidate transform)
  "Return the shelf heading for CANDIDATE, per `group-function'.
When TRANSFORM is non-nil return CANDIDATE itself unchanged."
  (if transform candidate
    (get-text-property 0 'youtube-music-group candidate)))

(defun youtube-music--read-search-item (prompt candidates)
  "Pick one of CANDIDATES (a (LABEL . ITEM) alist) with PROMPT.
Candidates keep the API's relevance order and are grouped by shelf
in UIs that support `group-function' (vertico, the *Completions*
buffer).  Returns the chosen ITEM, or nil."
  (let* ((table (lambda (string pred action)
                  (if (eq action 'metadata)
                      '(metadata
                        (category . youtube-music-search-item)
                        (group-function . youtube-music--candidate-group)
                        (display-sort-function . identity)
                        (cycle-sort-function . identity))
                    (complete-with-action action candidates string pred))))
         (choice (completing-read prompt table nil t nil
                                  'youtube-music--pick-history)))
    (cdr (assoc choice candidates))))

(defun youtube-music--act-on-item (item &optional enqueue)
  "Play ITEM, or append it to the queue when ENQUEUE is non-nil.
ITEM is a plist from the search or home parsers.  Songs load
directly; albums and playlists queue every track via the browse
API."
  (pcase (plist-get item :kind)
    ('song
     (youtube-music--remember-tracks (list item))
     (let ((url (format "https://music.youtube.com/watch?v=%s"
                        (plist-get item :video-id))))
       (if enqueue (youtube-music-enqueue-url url)
         (youtube-music-play-url url))))
    ((or 'album 'browse)
     (youtube-music--play-playlist-by-browse-id
      (plist-get item :browse-id) enqueue))
    ('playlist
     (let ((pid (plist-get item :playlist-id))
           (vid (plist-get item :video-id))
           (bid (plist-get item :browse-id)))
       (cond
        ;; "Liked Music" — yt-dlp can't expand `?list=LM'; route through
        ;; the API path that fetches the VLLM browse page by page.
        ((or (equal pid "LM") (equal bid "VLLM"))
         (youtube-music-liked))
        (bid (youtube-music--play-playlist-by-browse-id bid enqueue))
        (pid
         (let ((url (if vid
                        (format "https://music.youtube.com/watch?v=%s&list=%s"
                                vid pid)
                      (format "https://music.youtube.com/playlist?list=%s"
                              pid))))
           (if enqueue (youtube-music-enqueue-url url)
             (youtube-music-play-url url)))))))
    (_ (user-error "Unsupported item kind"))))

(defun youtube-music--prompt-shelf-items (title items enqueue)
  "Pick one of ITEMS from the shelf TITLE and act on it.
ENQUEUE is passed through to `youtube-music--act-on-item'."
  (let* ((mixed (youtube-music--mixed-kinds-p items))
         (labels (mapcar (lambda (it)
                           (cons (youtube-music--item-label it mixed) it))
                         items))
         (choice (completing-read (format "%s — pick: " title) labels nil t
                                  nil 'youtube-music--pick-history))
         (item (cdr (assoc choice labels))))
    (when item (youtube-music--act-on-item item enqueue))))

(defun youtube-music--search-offer (shelves enqueue)
  "Prompt for one item across SHELVES and act on it.
When ENQUEUE is non-nil the pick is appended to the queue instead
of replacing it.  Picking a \"More ...\" entry re-prompts with
that category expanded to its full list."
  (let* ((cands (youtube-music--search-candidates shelves))
         (item (youtube-music--read-search-item
                (if enqueue "Enqueue: " "Play: ") cands)))
    (cond
     ((null item) nil)
     ((eq (plist-get item :kind) 'expand)
      (youtube-music--search-offer
       (list (list :title (plist-get item :title)
                   :items (plist-get item :items)))
       enqueue))
     (t (youtube-music--act-on-item item enqueue)))))

;;;###autoload
(defun youtube-music-search (query &optional enqueue)
  "Search YouTube Music for QUERY; pick a song or a playlist.
One prompt, two groups: songs and community playlists.  Picking a
song plays that one track; picking a playlist queues the whole
thing.  Each group shows the top `youtube-music-search-max-results'
hits; the \"More ...\" entry expands a group to the full list.
With a prefix argument, ENQUEUE the pick at the end of the
current queue instead of replacing it."
  (interactive (list (read-string "Search YouTube Music: " nil
                                  'youtube-music--search-history)
                     current-prefix-arg))
  (message "youtube-music: searching for %s..." query)
  (let ((pending 2) songs playlists)
    (cl-flet ((step ()
                (when (zerop (cl-decf pending))
                  (if (and (null songs) (null playlists))
                      (message "youtube-music: no results for %s" query)
                    (youtube-music--search-offer
                     (let ((limit youtube-music-search-max-results))
                       (delq nil
                             (list
                              (and songs (list :title "Songs"
                                               :items songs :limit limit))
                              (and playlists (list :title "Playlists"
                                                   :items playlists
                                                   :limit limit)))))
                     enqueue)))))
      (youtube-music--youtubei-post
       "search" `((query . ,query)
                  (params . ,youtube-music--search-songs-params))
       (lambda (response)
         (setq songs (youtube-music--parse-search-items response))
         (step)))
      (youtube-music--youtubei-post
       "search" `((query . ,query)
                  (params . ,youtube-music--search-playlists-params))
       (lambda (response)
         (setq playlists (youtube-music--parse-search-items response))
         (step))))))

;;;###autoload
(defun youtube-music-search-enqueue (query)
  "Search YouTube Music for QUERY and append the chosen pick to the queue.
Playlists are appended whole."
  (interactive (list (read-string "Enqueue from YouTube Music: " nil
                                  'youtube-music--search-history)))
  (youtube-music-search query t))

;;;; Library browse — parsers

(defun youtube-music--browse-section-list (response)
  "Walk RESPONSE down to its sectionListRenderer.contents vector, or nil.
Tries multiple known shapes:
  `singleColumnBrowseResultsRenderer.tabs[0]' (home, search),
  `twoColumnBrowseResultsRenderer.secondaryContents' (album / mix /
  library tracks; the tabs side here is the header, NOT the list),
  `twoColumnBrowseResultsRenderer.tabs[0]' as a final fallback."
  (or (youtube-music--get-in
       response [:contents :singleColumnBrowseResultsRenderer
                 :tabs 0 :tabRenderer :content
                 :sectionListRenderer :contents])
      (youtube-music--get-in
       response [:contents :twoColumnBrowseResultsRenderer
                 :secondaryContents :sectionListRenderer :contents])
      (youtube-music--get-in
       response [:contents :twoColumnBrowseResultsRenderer
                 :tabs 0 :tabRenderer :content
                 :sectionListRenderer :contents])))

(defun youtube-music--parse-track-shelf (response)
  "Extract a list of track plists from a browse RESPONSE.
Handles both `musicPlaylistShelfRenderer' and `musicShelfRenderer'
section content."
  (let ((sections (youtube-music--browse-section-list response))
        results)
    (when sections
      (cl-loop
       for section across sections
       for shelf-contents = (or (youtube-music--get-in
                                 section [:musicPlaylistShelfRenderer :contents])
                                (youtube-music--get-in
                                 section [:musicShelfRenderer :contents]))
       when shelf-contents
       do (cl-loop
           for entry across shelf-contents
           for parsed = (youtube-music--parse-list-item entry)
           when parsed do (push parsed results))))
    (nreverse results)))

(defun youtube-music--trailing-continuation-token (items)
  "Return the token from a `continuationItemRenderer' ending ITEMS, or nil.
Newer playlist responses no longer carry a `continuations' block
on the shelf; instead the last entry of the contents vector is a
`continuationItemRenderer' holding a `continuationCommand' token."
  (when (and (vectorp items) (> (length items) 0))
    (youtube-music--get-in
     (aref items (1- (length items)))
     [:continuationItemRenderer :continuationEndpoint
      :continuationCommand :token])))

(defun youtube-music--shelf-continuation-token (response)
  "Return a continuation token from a browse RESPONSE, or nil.
Looks at `musicPlaylistShelfRenderer' and `musicShelfRenderer'
shelves under the section list, accepting both the legacy
`continuations' block and the trailing `continuationItemRenderer'
shape (see `youtube-music--trailing-continuation-token')."
  (let ((sections (youtube-music--browse-section-list response)))
    (cl-loop
     for section across (or sections [])
     for shelf = (or (plist-get section :musicPlaylistShelfRenderer)
                     (plist-get section :musicShelfRenderer))
     when shelf
     for tok = (or (youtube-music--get-in
                    shelf [:continuations 0 :nextContinuationData :continuation])
                   (youtube-music--trailing-continuation-token
                    (plist-get shelf :contents)))
     when tok return tok)))

(defun youtube-music--parse-track-continuation (response)
  "Parse a continuation RESPONSE returned by a `?continuation=...' POST.
Returns plist (:tracks LIST :next TOKEN-OR-NIL).  Handles the legacy
`continuationContents' shape (library shelves) and the newer
`onResponseReceivedActions' / `appendContinuationItemsAction' shape
\(playlists, including Liked Music), whose next token rides on a
trailing `continuationItemRenderer'."
  (let* ((cc (plist-get response :continuationContents))
         (shelf (or (plist-get cc :musicPlaylistShelfContinuation)
                    (plist-get cc :musicShelfContinuation)))
         (appended
          (unless shelf
            (cl-loop for action across
                     (or (plist-get response :onResponseReceivedActions) [])
                     for items = (youtube-music--get-in
                                  action [:appendContinuationItemsAction
                                          :continuationItems])
                     when items return items)))
         (contents (if shelf (plist-get shelf :contents) appended))
         (next (if shelf
                   (youtube-music--get-in
                    shelf [:continuations 0 :nextContinuationData
                           :continuation])
                 (youtube-music--trailing-continuation-token appended)))
         results)
    (when contents
      (cl-loop for entry across contents
               for parsed = (youtube-music--parse-list-item entry)
               when parsed do (push parsed results)))
    (list :tracks (nreverse results) :next next)))

(defun youtube-music--fetch-all-tracks (endpoint body token tracks-so-far on-done)
  "Recursively follow continuations and gather all tracks.
ENDPOINT and BODY are passed to `youtube-music--youtubei-post'.
TOKEN is the next continuation token, or nil if we are done.
TRACKS-SO-FAR accumulates results; ON-DONE is called once with
the final list."
  (cond
   ((null token) (funcall on-done tracks-so-far))
   (t
    (let ((extra (format "ctoken=%s&continuation=%s&type=next"
                         (url-hexify-string token)
                         (url-hexify-string token))))
      (youtube-music--youtubei-post
       endpoint body
       (lambda (response)
         (let* ((parsed (youtube-music--parse-track-continuation response))
                (more (plist-get parsed :tracks))
                (next (plist-get parsed :next)))
           (youtube-music--fetch-all-tracks
            endpoint body next
            (append tracks-so-far more)
            on-done)))
       extra)))))

(defun youtube-music--parse-playlist-tile (item)
  "Parse a `musicTwoRowItemRenderer' ITEM into (TITLE . BROWSE-ID), or nil."
  (when-let* ((tri (plist-get item :musicTwoRowItemRenderer)))
    (let* ((runs (youtube-music--get-in tri [:title :runs]))
           (title (when (and runs (> (length runs) 0))
                    (plist-get (aref runs 0) :text)))
           (browse-id (youtube-music--get-in
                       tri [:navigationEndpoint :browseEndpoint :browseId])))
      (when (and title browse-id)
        (cons title browse-id)))))

(defun youtube-music--parse-playlist-shelf (response)
  "Parse RESPONSE into a list of (TITLE . BROWSE-ID) library playlists."
  (let ((sections (youtube-music--browse-section-list response))
        results)
    (when sections
      (cl-loop
       for section across sections
       for grid = (plist-get section :gridRenderer)
       when grid
       do (cl-loop
           for entry across (plist-get grid :items)
           for parsed = (youtube-music--parse-playlist-tile entry)
           when parsed do (push parsed results))))
    (nreverse results)))

;;;; Library browse — commands

(defun youtube-music--video-id-from-url (url)
  "Return the videoId from a YouTube/YT-Music URL, or nil.
Handles `watch?v=<id>', `/shorts/<id>', and `youtu.be/<id>' shapes."
  (when (stringp url)
    (cond
     ((string-match "[?&]v=\\([A-Za-z0-9_-]+\\)" url) (match-string 1 url))
     ((string-match "/shorts/\\([A-Za-z0-9_-]+\\)" url) (match-string 1 url))
     ((string-match "youtu\\.be/\\([A-Za-z0-9_-]+\\)" url) (match-string 1 url)))))

(defun youtube-music--remember-tracks (tracks)
  "Cache title/subtitle metadata for TRACKS keyed by videoId."
  (dolist (tr tracks)
    (let ((vid (plist-get tr :video-id)))
      (when vid
        (puthash vid
                 (list :title (plist-get tr :title)
                       :subtitle (plist-get tr :subtitle))
                 youtube-music--track-meta)))))

(defun youtube-music--display-title-for (url-or-path mpv-title)
  "Pick the best display string for a track.
URL-OR-PATH is the queued URL; MPV-TITLE is mpv's `media-title'.
Falls back to URL-OR-PATH if neither yields anything useful."
  (let* ((vid (youtube-music--video-id-from-url url-or-path))
         (meta (and vid (gethash vid youtube-music--track-meta))))
    (cond
     (meta (let ((sub (plist-get meta :subtitle)))
             (if (and sub (> (length sub) 0))
                 (format "%s — %s" (plist-get meta :title) sub)
               (plist-get meta :title))))
     ((and mpv-title (> (length mpv-title) 0)
           (not (equal mpv-title url-or-path)))
      mpv-title)
     (t (or url-or-path "")))))

(defun youtube-music--play-tracks (tracks &optional enqueue)
  "Hand TRACKS (list of result plists) to mpv.
Replaces the current playlist, or appends to it when ENQUEUE is
non-nil."
  (youtube-music--remember-tracks tracks)
  (unless enqueue (setq youtube-music--shuffled-p nil))
  (cl-loop for tr in tracks
           for first = t then nil
           do (youtube-music--send
               `("loadfile"
                 ,(format "https://music.youtube.com/watch?v=%s"
                          (plist-get tr :video-id))
                 ,(cond (enqueue "append-play")
                        (first "replace")
                        (t "append"))))))

(defun youtube-music--play-playlist-by-browse-id (browse-id &optional enqueue)
  "Queue the playlist / mix / album referenced by BROWSE-ID.
Replaces the current queue, or appends when ENQUEUE is non-nil.
Always fetches via the API and queues the resolved tracks
individually -- handing playlist URLs (especially `?list=LM' for
Liked Music) to yt-dlp doesn't reliably expand them."
  (message "youtube-music: loading playlist...")
  (youtube-music--fetch-all-from-browse-id
   browse-id
   (lambda (tracks)
     (cond
      ((eq tracks 'auth-failed) nil)
      ((null tracks) (message "youtube-music: empty or unparseable playlist"))
      (t (youtube-music--play-tracks tracks enqueue)
         (message "youtube-music: %s %d tracks"
                  (if enqueue "appended" "queued") (length tracks)))))))

(defun youtube-music--populate-liked-set (tracks)
  "Replace `youtube-music--liked-set' with the videoIds from TRACKS."
  (setq youtube-music--liked-set (make-hash-table :test 'equal))
  (dolist (tr tracks)
    (when-let* ((vid (plist-get tr :video-id)))
      (puthash vid t youtube-music--liked-set))))

(defun youtube-music--logged-in-flag (response)
  "Return \"0\", \"1\", or nil for RESPONSE's GFEEDBACK.logged_in field."
  (let ((sci (plist-get (plist-get response :responseContext)
                        :serviceTrackingParams)))
    (when (sequencep sci)
      (cl-loop for entry across sci
               when (equal (plist-get entry :service) "GFEEDBACK")
               return (let ((params (plist-get entry :params)))
                        (and (sequencep params)
                             (cl-loop for p across params
                                      when (equal (plist-get p :key)
                                                  "logged_in")
                                      return (plist-get p :value))))))))

(defun youtube-music--observe-auth (response)
  "Update `youtube-music--auth-state' from RESPONSE.
On a transition into `logged-in', clear the auto-refresh one-shot
and kick off a background account-info fetch so the buffer shows
the user's name.  On a transition into `logged-out', try a silent
auto-refresh from the browser before settling on that state."
  (let ((flag (youtube-music--logged-in-flag response)))
    (when flag
      (let* ((prev youtube-music--auth-state)
             (new-state (if (equal flag "1") 'logged-in 'logged-out)))
        (unless (eq prev new-state)
          (setq youtube-music--auth-state new-state)
          (cond
           ((eq new-state 'logged-in)
            (setq youtube-music--auto-refresh-attempted nil)
            (when (null youtube-music--account-name)
              (youtube-music-fetch-account-info)))
           ((eq new-state 'logged-out)
            (setq youtube-music--account-name nil)
            (youtube-music--rerender)
            (youtube-music--maybe-auto-refresh)))
          (youtube-music--rerender)))))
  response)

;;;###autoload
(defun youtube-music-fetch-account-info ()
  "Fetch the user's account display name in the background.
Also conclusively flips `youtube-music--auth-state' based on
whether an account header is returned: getting the name back
proves we're authenticated; not getting it proves we aren't."
  (interactive)
  (youtube-music--youtubei-post
   "account/account_menu" '()
   (lambda (response)
     (let ((name (or (youtube-music--get-in
                      response
                      [:actions 0 :openPopupAction :popup
                       :multiPageMenuRenderer :header
                       :activeAccountHeaderRenderer :accountName :runs 0 :text])
                     (youtube-music--get-in
                      response
                      [:actions 0 :openPopupAction :popup
                       :multiPageMenuRenderer :header
                       :activeAccountHeaderRenderer :accountName :simpleText]))))
       (cond
        (name
         (setq youtube-music--account-name name
               youtube-music--auth-state 'logged-in)
         (youtube-music--rerender))
        (t
         ;; Either the response had no name, or the request failed
         ;; outright (HTTP error / parse error).  Either way, with
         ;; credentials on disk this means they aren't being honoured.
         (setq youtube-music--account-name nil
               youtube-music--auth-state 'logged-out)
         (youtube-music--rerender)
         (youtube-music--maybe-auto-refresh)))))))

(defun youtube-music--maybe-auto-refresh ()
  "Try silent cookie refresh from a browser when eligible.
Eligible means: state is `logged-out', we still have stored
credentials, we haven't tried this session, and yt-dlp is available.
Updates the buffer status to `refreshing' before doing the work so
the user knows something is happening."
  (when (and (eq youtube-music--auth-state 'logged-out)
             youtube-music--cookie
             (not youtube-music--auto-refresh-attempted)
             (executable-find "yt-dlp"))
    (setq youtube-music--auto-refresh-attempted t
          youtube-music--auth-state 'refreshing)
    (youtube-music--rerender)
    ;; Force redisplay so the user sees the status before the
    ;; potentially-blocking yt-dlp probe runs.
    (redisplay t)
    (let ((new-cookie (cl-some #'youtube-music--extract-cookie-via-browser
                               youtube-music--cookie-source-browsers)))
      (cond
       ((and new-cookie (not (equal new-cookie youtube-music--cookie)))
        (youtube-music--credentials-save (list :cookie new-cookie))
        (setq youtube-music--cookie new-cookie
              youtube-music--sapisid (youtube-music--extract-sapisid new-cookie)
              youtube-music--account-name nil)
        (youtube-music-fetch-account-info))
       (t
        (setq youtube-music--auth-state 'logged-out)
        (youtube-music--rerender))))))

(defun youtube-music--sign-in-required-p (response)
  "Return non-nil if RESPONSE was served as anonymous."
  (equal (youtube-music--logged-in-flag response) "0"))

(defun youtube-music--warn-stale-cookie ()
  "Update auth state to logged-out (the buffer reflects the change)."
  (setq youtube-music--auth-state 'logged-out)
  (youtube-music--rerender))

(defun youtube-music--fetch-all-from-browse-id (browse-id on-done)
  "Fetch every track from BROWSE-ID, following continuations.
Calls ON-DONE with the full list once continuations are exhausted.
If the server returns a sign-in-required placeholder, warns the
user and calls ON-DONE with the symbol `auth-failed' so the caller
can suppress its own \"no results\" message."
  (let ((body `((browseId . ,browse-id))))
    (youtube-music--youtubei-post
     "browse" body
     (lambda (response)
       (cond
        ((youtube-music--sign-in-required-p response)
         (youtube-music--warn-stale-cookie)
         (funcall on-done 'auth-failed))
        (t
         (let ((tracks (youtube-music--parse-track-shelf response))
               (token  (youtube-music--shelf-continuation-token response)))
           (youtube-music--fetch-all-tracks
            "browse" body token tracks on-done))))))))

;;;###autoload
(defun youtube-music-debug-browse (browse-id)
  "Fetch BROWSE-ID and dump the response shape to `*youtube-music-debug*'.
Useful for diagnosing parser misses; share the output with the
maintainer when reporting issues."
  (interactive "sBrowse ID: ")
  (youtube-music--youtubei-post
   "browse"
   `((browseId . ,browse-id))
   (lambda (response)
     (let ((buf (get-buffer-create "*youtube-music-debug*")))
       (with-current-buffer buf
         (let ((inhibit-read-only t))
           (erase-buffer)
           (insert (format "=== Browse: %s ===\n\n" browse-id))
           (insert "── top-level keys ──\n")
           (when (consp response)
             (cl-loop for (k _v) on response by #'cddr
                      do (insert (format "  %S\n" k))))
           (insert "\n── contents.* keys ──\n")
           (let ((contents (plist-get response :contents)))
             (cond
              ((not (consp contents))
               (insert (format "  (no contents; got %s)\n"
                               (type-of contents))))
              (t (cl-loop for (k _v) on contents by #'cddr
                          do (insert (format "  %S\n" k)))
                 (let ((tcbr (plist-get contents :twoColumnBrowseResultsRenderer)))
                   (when (consp tcbr)
                     (insert "\n── twoColumnBrowseResultsRenderer.* keys ──\n")
                     (cl-loop for (k _v) on tcbr by #'cddr
                              do (insert (format "  %S\n" k))))))))
           (insert "\n── --browse-section-list returns ──\n")
           (let ((sections (youtube-music--browse-section-list response)))
             (insert (format "  type: %s, length: %s\n"
                             (type-of sections)
                             (if (sequencep sections)
                                 (length sections) "n/a")))
             (when (and sections (sequencep sections) (> (length sections) 0))
               (cl-loop
                for s across sections
                for i from 0
                do (insert (format "\n  Section %d keys:\n" i))
                   (when (consp s)
                     (cl-loop for (k _v) on s by #'cddr
                              do (insert (format "    %S\n" k))))))))
         (goto-char (point-min)))
       (pop-to-buffer buf)))))

(defconst youtube-music--liked-browse-id "VLLM"
  "Browse ID of the \"Liked Music\" playlist (`?list=LM').
Deliberately not `FEmusic_liked_videos': that is the Library >
Songs view, which only lists catalog *songs* and silently drops
every liked video (official music videos, uploads, live takes),
so newly liked tracks appeared to be missing.")

;;;###autoload
(defun youtube-music-refresh-liked-set ()
  "Fetch the user's liked-songs list (paginated) to refresh the liked set.
This is what powers the thumbs-up indicator on tracks."
  (interactive)
  (message "youtube-music: refreshing liked set...")
  (youtube-music--fetch-all-from-browse-id
   youtube-music--liked-browse-id
   (lambda (tracks)
     (cond
      ((eq tracks 'auth-failed) nil)
      ((null tracks) (message "youtube-music: no liked songs"))
      (t (youtube-music--populate-liked-set tracks)
         (youtube-music--rerender)
         (message "youtube-music: refreshed liked set (%d entries)"
                  (length tracks)))))))

;;;###autoload
(defun youtube-music-liked ()
  "Play your YouTube Music liked-songs list (all pages)."
  (interactive)
  (message "youtube-music: fetching liked songs...")
  (youtube-music--fetch-all-from-browse-id
   youtube-music--liked-browse-id
   (lambda (tracks)
     (cond
      ((eq tracks 'auth-failed) nil)
      ((null tracks) (message "youtube-music: no liked songs"))
      (t (youtube-music--populate-liked-set tracks)
         (youtube-music--play-tracks tracks)
         (message "youtube-music: queued %d tracks" (length tracks)))))))

;;;###autoload
(defun youtube-music-library-playlists ()
  "Pick one of your YouTube Music library playlists and play it."
  (interactive)
  (message "youtube-music: fetching your playlists...")
  (youtube-music--youtubei-post
   "browse"
   '((browseId . "FEmusic_liked_playlists"))
   (lambda (response)
     (cond
      ((youtube-music--sign-in-required-p response)
       (youtube-music--warn-stale-cookie))
      (t
       (let ((entries (youtube-music--parse-playlist-shelf response)))
         (cond
          ((null entries) (message "youtube-music: no playlists found"))
          (t (let* ((choice (completing-read "Playlist: " entries nil t nil
                                             'youtube-music--pick-history))
                    (browse-id (cdr (assoc choice entries))))
               (when browse-id
                 (youtube-music--play-playlist-by-browse-id browse-id)))))))))))

;;;###autoload (autoload 'youtube-music-library "youtube-music" nil t)
(transient-define-prefix youtube-music-library ()
  "Browse your YouTube Music library."
  ["Library"
   ("l" "Liked songs"            youtube-music-liked)
   ("p" "Playlists"              youtube-music-library-playlists)
   ("h" "Home / recommendations" youtube-music-home)])

;;;; Home / recommendations browse

(defun youtube-music--parse-home-item (item)
  "Parse a home-shelf ITEM into a plist.
Returns (:title :subtitle :kind :video-id :playlist-id :browse-id),
where KIND is one of `song', `playlist', `browse', or nil if the
shape is unfamiliar."
  (cond
   ((plist-get item :musicTwoRowItemRenderer)
    (let* ((tri (plist-get item :musicTwoRowItemRenderer))
           (title-runs (youtube-music--get-in tri [:title :runs]))
           (sub-runs   (youtube-music--get-in tri [:subtitle :runs]))
           (title (when (and title-runs (> (length title-runs) 0))
                    (plist-get (aref title-runs 0) :text)))
           (subtitle (when sub-runs
                       (mapconcat (lambda (r) (or (plist-get r :text) ""))
                                  sub-runs "")))
           (vid (youtube-music--get-in
                 tri [:navigationEndpoint :watchEndpoint :videoId]))
           (pid (youtube-music--get-in
                 tri [:navigationEndpoint :watchEndpoint :playlistId]))
           (bid (youtube-music--get-in
                 tri [:navigationEndpoint :browseEndpoint :browseId])))
      (when title
        (list :title title
              :subtitle (or subtitle "")
              :kind (cond (pid 'playlist)
                          (vid 'song)
                          (bid 'browse))
              :video-id vid
              :playlist-id pid
              :browse-id bid))))
   ((plist-get item :musicResponsiveListItemRenderer)
    (when-let* ((parsed (youtube-music--parse-list-item item)))
      (list :title (plist-get parsed :title)
            :subtitle (plist-get parsed :subtitle)
            :kind 'song
            :video-id (plist-get parsed :video-id))))))

(defun youtube-music--shelf-title (shelf)
  "Extract a human-readable title from a home SHELF renderer plist."
  (or (youtube-music--get-in
       shelf [:header :musicCarouselShelfBasicHeaderRenderer :title :runs 0 :text])
      (youtube-music--get-in
       shelf [:header :musicImmersiveCarouselShelfBasicHeaderRenderer
               :title :runs 0 :text])
      (youtube-music--get-in shelf [:title :runs 0 :text])
      "Untitled"))

(defun youtube-music--parse-home (response)
  "Parse home RESPONSE into a list of (SHELF-TITLE . ITEMS) cons cells."
  (let ((sections (youtube-music--browse-section-list response))
        results)
    (when sections
      (cl-loop
       for section across sections
       for shelf = (or (plist-get section :musicCarouselShelfRenderer)
                       (plist-get section :musicImmersiveCarouselShelfRenderer)
                       (plist-get section :musicShelfRenderer))
       when shelf
       do (let* ((title (youtube-music--shelf-title shelf))
                 (items (plist-get shelf :contents))
                 (parsed (and items
                              (cl-loop for it across items
                                       for p = (youtube-music--parse-home-item it)
                                       when p collect p))))
            (when parsed (push (cons title parsed) results)))))
    (nreverse results)))

(defun youtube-music--prompt-home (shelves)
  "Run the two-step pick UI on SHELVES (alist of TITLE → ITEMS)."
  (let* ((shelf-title (completing-read "Shelf: " shelves nil t nil
                                       'youtube-music--pick-history))
         (items (cdr (assoc shelf-title shelves))))
    (when items
      (youtube-music--prompt-shelf-items shelf-title items nil))))

;;;###autoload
(defun youtube-music-home ()
  "Browse YouTube Music home shelves (Discover / Replay / etc.).
Pick a shelf, then pick an item to play."
  (interactive)
  (message "youtube-music: fetching home...")
  (youtube-music--youtubei-post
   "browse"
   '((browseId . "FEmusic_home"))
   (lambda (response)
     (cond
      ((youtube-music--sign-in-required-p response)
       (youtube-music--warn-stale-cookie))
      (t (let ((shelves (youtube-music--parse-home response)))
           (if (null shelves)
               (message "youtube-music: no home shelves")
             (youtube-music--prompt-home shelves))))))))

;;;; Like / dislike the current track

(defun youtube-music--current-video-id ()
  "Return the videoId of the track currently loaded in mpv, or nil."
  (let ((path (plist-get youtube-music--state :path)))
    (or (youtube-music--video-id-from-url path)
        (let* ((cur (plist-get youtube-music--state :playlist-pos))
               (items youtube-music--playlist-cache)
               (entry (and cur items (>= cur 0) (< cur (length items))
                           (nth cur items)))
               (filename (and entry (plist-get entry :filename))))
          (and filename (youtube-music--video-id-from-url filename))))))

(defun youtube-music--complain-no-vid (verb)
  "Signal an informative `user-error' for VERB when no videoId is resolvable.
Surfaces the relevant state so we can diagnose what was missing."
  (user-error
   "Cannot %s: no track at point, and no playing track found (path=%S, playlist-pos=%S, queue-len=%d)"
   verb
   (plist-get youtube-music--state :path)
   (plist-get youtube-music--state :playlist-pos)
   (length (or youtube-music--playlist-cache '()))))

(defun youtube-music--video-id-at-point-or-current ()
  "Return the videoId DWIM at point, or for the currently playing track.
If point is on a queue entry, return that entry's videoId.
Otherwise, return whatever is currently playing."
  (or (let ((idx (get-text-property (point) 'youtube-music-playlist-index)))
        (when (and idx youtube-music--playlist-cache
                   (>= idx 0) (< idx (length youtube-music--playlist-cache)))
          (youtube-music--video-id-from-url
           (plist-get (nth idx youtube-music--playlist-cache) :filename))))
      (youtube-music--current-video-id)))

(defun youtube-music--display-title-from-vid (vid)
  "Return the cached \"Title — Subtitle\" for VID, or nil."
  (when-let* ((meta (gethash vid youtube-music--track-meta)))
    (let ((sub (plist-get meta :subtitle)))
      (if (and sub (not (string-empty-p sub)))
          (format "%s — %s" (plist-get meta :title) sub)
        (plist-get meta :title)))))

(defun youtube-music--update-rating-state (vid new-state)
  "Update liked-set and disliked-set for VID moving to NEW-STATE.
NEW-STATE is one of `like', `dislike', `none'."
  (when youtube-music--liked-set
    (if (eq new-state 'like)
        (puthash vid t youtube-music--liked-set)
      (remhash vid youtube-music--liked-set)))
  (if (eq new-state 'dislike)
      (puthash vid t youtube-music--disliked-set)
    (remhash vid youtube-music--disliked-set)))

(defun youtube-music--rate-track (endpoint verb new-state)
  "POST to ENDPOINT for the DWIM videoId; VERB names the action.
ENDPOINT is e.g. \"like/like\".  VERB is shown in user messages.
NEW-STATE is one of `like', `dislike', `none'.  The target is the
track at point in the queue, or the currently playing track."
  (let ((vid (youtube-music--video-id-at-point-or-current)))
    (cond
     ((null vid) (youtube-music--complain-no-vid verb))
     (t
      (youtube-music--youtubei-post
       endpoint
       `((target . ((videoId . ,vid))))
       (lambda (_response)
         (youtube-music--update-rating-state vid new-state)
         (youtube-music--rerender)
         (message "youtube-music: %sd \"%s\""
                  verb
                  (or (youtube-music--display-title-from-vid vid) vid))))))))

;;;###autoload
(defun youtube-music-like ()
  "Thumbs-up the currently playing track."
  (interactive)
  (youtube-music--rate-track "like/like" "like" 'like))

;;;###autoload
(defun youtube-music-dislike ()
  "Thumbs-down the currently playing track."
  (interactive)
  (youtube-music--rate-track "like/dislike" "dislike" 'dislike))

;;;###autoload
(defun youtube-music-unrate ()
  "Clear thumbs-up/down for the currently playing track."
  (interactive)
  (youtube-music--rate-track "like/removelike" "unrate" 'none))

(defconst youtube-music--glyph-table
  '((thumbs-up   . ("👍" . "+"))
    (thumbs-down . ("👎" . "-"))
    (shuffle     . ("🔀" . "↯"))
    (repeat-all  . ("🔁" . "↻"))
    (repeat-one  . ("🔂" . "↺")))
  "Glyph fallback table: (KEY . (EMOJI . FALLBACK)).
The emoji is preferred; the BMP/ASCII fallback is used when the
emoji cannot be displayed in the current fontset.")

(defun youtube-music--glyph (key)
  "Return the best displayable glyph for KEY in `youtube-music--glyph-table'."
  (let* ((pair (cdr (assq key youtube-music--glyph-table)))
         (emoji (car pair))
         (fallback (cdr pair)))
    (if (and emoji (char-displayable-p (aref emoji 0)))
        emoji
      fallback)))

(defun youtube-music--rating-glyph-for (vid)
  "Return a propertized thumbs-up/down glyph for VID, or nil."
  (cond
   ((null vid) nil)
   ((and youtube-music--liked-set
         (gethash vid youtube-music--liked-set))
    (propertize (youtube-music--glyph 'thumbs-up)
                'face 'youtube-music-thumbs-up))
   ((gethash vid youtube-music--disliked-set)
    (propertize (youtube-music--glyph 'thumbs-down)
                'face 'youtube-music-thumbs-down))
   (t nil)))

(defun youtube-music--current-rating-glyph ()
  "Return the rating glyph for the currently-playing track, or nil."
  (youtube-music--rating-glyph-for (youtube-music--current-video-id)))

;;;; Radio (find-similar)

(defun youtube-music--parse-radio-tracks (response)
  "Parse a `youtubei/v1/next' RESPONSE into a list of track plists."
  (let ((items (youtube-music--get-in
                response
                [:contents :singleColumnMusicWatchNextResultsRenderer
                 :tabbedRenderer :watchNextTabbedResultsRenderer
                 :tabs 0 :tabRenderer :content
                 :musicQueueRenderer :content
                 :playlistPanelRenderer :contents]))
        results)
    (when items
      (cl-loop
       for entry across items
       for r = (or (plist-get entry :playlistPanelVideoRenderer)
                   (youtube-music--get-in
                    entry [:playlistPanelVideoWrapperRenderer
                           :primaryRenderer :playlistPanelVideoRenderer]))
       when r
       do (let* ((title (youtube-music--get-in r [:title :runs 0 :text]))
                 (vid   (plist-get r :videoId))
                 (runs  (youtube-music--get-in r [:longBylineText :runs]))
                 (sub   (when (sequencep runs)
                          (mapconcat (lambda (run)
                                       (or (plist-get run :text) ""))
                                     runs ""))))
            (when (and title vid)
              (push (list :title title :subtitle (or sub "")
                          :video-id vid)
                    results)))))
    (nreverse results)))

(defun youtube-music--start-radio (body enqueue)
  "POST BODY to the `next' endpoint and queue the returned radio tracks.
Replaces the current queue, or appends when ENQUEUE is non-nil."
  (message "youtube-music: starting radio...")
  (youtube-music--youtubei-post
   "next" body
   (lambda (response)
     (let ((tracks (youtube-music--parse-radio-tracks response)))
       (cond
        ((null tracks)
         (message "youtube-music: no radio tracks returned"))
        (t
         (youtube-music--play-tracks tracks enqueue)
         (message "youtube-music: radio %s (%d tracks)"
                  (if enqueue "appended" "queued")
                  (length tracks))))))))

;;;###autoload
(defun youtube-music-radio (&optional enqueue)
  "Start a radio of songs similar to the track at point or now playing.
With a prefix argument, ENQUEUE the radio at the end of the
current queue instead of replacing it."
  (interactive "P")
  (let ((vid (youtube-music--video-id-at-point-or-current)))
    (cond
     ((null vid) (youtube-music--complain-no-vid "start radio"))
     (t (youtube-music--start-radio
         `((videoId . ,vid) (playlistId . ,(format "RDAMVM%s" vid)))
         enqueue)))))

;;;; Status-buffer transient menu

;; No autoload; the only entry point is `?' / `h' inside
;; `youtube-music-mode'.
(transient-define-prefix youtube-music-dispatch ()
  "Show available YouTube Music commands.
This transient is invoked from the status buffer via `?' or `h'.
The currently-playing track is shown in the Now Playing section
of the buffer rather than in the menu header."
  ["Browse"
   [("s" "Search (enqueue)" youtube-music-search-enqueue)
    ("S" "Search (replace)" youtube-music-search)
    ("l" "Library"          youtube-music-library)
    ("u" "Play URL"         youtube-music-play-url)
    ("e" "Enqueue URL"      youtube-music-enqueue-url)]
   [("a" "Auth"             youtube-music-auth)
    ("L" "Show mpv log"     youtube-music-show-log)
    ("Q" "Quit player"      youtube-music-quit)]]
  ["Playback"
   [("SPC" "Play / pause"   youtube-music-play-pause   :transient t)
    ("n"   "Next track"     youtube-music-next         :transient t)
    ("p"   "Previous track" youtube-music-prev         :transient t)
    ("x"   "Stop"           youtube-music-stop         :transient t)]
   [("f"   "Seek +5s"       youtube-music-seek-forward  :transient t)
    ("b"   "Seek -5s"       youtube-music-seek-backward :transient t)]
   [("+"   "Like"           youtube-music-like          :transient t)
    ("-"   "Dislike"        youtube-music-dislike       :transient t)
    ("="   "Unrate"         youtube-music-unrate        :transient t)]
   [("z"   "Shuffle"        youtube-music-toggle-shuffle :transient t)
    ("r"   "Repeat (cycle)" youtube-music-cycle-repeat   :transient t)
    ("R"   "Radio (similar)" youtube-music-radio)]]
  ["Buffer"
   :if-derived youtube-music-mode
   [("g"        "       Refresh"                youtube-music-refresh)
    ("q"        "       Bury buffer"            quit-window)
    ("<return>" "Play track at point"           youtube-music-play-at-point)
    ("k"        "       Remove / stop at point" youtube-music-remove-at-point)]
   [("C-h m"    "       Show all key bindings"  describe-mode)]])


(provide 'youtube-music)
;;; youtube-music.el ends here
