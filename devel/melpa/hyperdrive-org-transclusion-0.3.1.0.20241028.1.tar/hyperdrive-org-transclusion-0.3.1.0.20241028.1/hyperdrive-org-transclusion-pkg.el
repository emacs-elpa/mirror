;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperdrive-org-transclusion" "0.3.1.0.20241028.1"
  "Tranclude hyperdrive content."
  '((emacs            "28.1")
    (hyperdrive       "0.4.2")
    (org-transclusion "1.4.0"))
  :url "https://git.sr.ht/~ushin/hyperdrive-org-transclusion"
  :commit "252e2df3fe7a07a122a365a637c47a43b26e179c"
  :revdesc "v0.3.1-1-g252e2df3fe7a"
  :authors '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht")))
