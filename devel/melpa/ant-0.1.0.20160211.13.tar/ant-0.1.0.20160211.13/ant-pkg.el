;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ant" "0.1.0.20160211.13"
  "Helpers for compiling with ant."
  ()
  :url "https://github.com/apg/ant-el"
  :commit "510b5a3f57ee4b2855422d88d359a28922c1ab70"
  :revdesc "510b5a3f57ee"
  :keywords '("compilation" "ant" "java"))
