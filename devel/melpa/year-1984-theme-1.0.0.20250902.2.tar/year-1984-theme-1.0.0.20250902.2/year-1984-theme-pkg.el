;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "year-1984-theme" "1.0.0.20250902.2"
  "A retro-futuristic theme."
  '((emacs "27.1"))
  :url "https://github.com/mastro35/year-1984-theme"
  :commit "d04b9b267085bb3606426dab2e26ea6489b31de3"
  :revdesc "d04b9b267085"
  :keywords '("themes" "faces" "colors" "apple" "beige" "light" "pastel" "vintage")
  :authors '(("Davide Mastromatteo" . "mastro35@gmail.com"))
  :maintainers '(("Davide Mastromatteo" . "mastro35@gmail.com")))
