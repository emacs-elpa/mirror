;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2.0.20260826.34"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "52ab1712b3cbedcfe34deb6023e4efa91a6ea940"
  :revdesc "52ab1712b3cb"
  :keywords '("faces" "files" "q"))
