;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-nimsuggest" "0.8.1.0.20171027.9"
  "Flycheck backend for Nim using nimsuggest."
  '((flycheck "0.23")
    (emacs    "24.3"))
  :url "https://github.com/yuutayamada/flycheck-nimsuggest"
  :commit "dc9a5de1cb3ee05db5794d824610959a1f603bc9"
  :revdesc "dc9a5de1cb3e"
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
