;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "highlight-function-calls" "0.1.0.20240922.8"
  "Highlight function/macro calls."
  '((emacs "24.4"))
  :url "https://github.com/alphapapa/highlight-function-calls"
  :commit "3037e64c740e799ecefd06419cc1ceffca6320b5"
  :revdesc "v0.1-8-g3037e64c740e"
  :keywords '("faces" "highlighting")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
