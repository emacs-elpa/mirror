;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20260824.32"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "97457777e245f94a5a325f938d0e91b5310431fe"
  :revdesc "97457777e245")
