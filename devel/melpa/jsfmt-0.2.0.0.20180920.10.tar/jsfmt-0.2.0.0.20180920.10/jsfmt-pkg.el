;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jsfmt" "0.2.0.0.20180920.10"
  "Interface to jsfmt command for javascript files."
  ()
  :url "https://github.com/brettlangdon/jsfmt.el"
  :commit "ca141a135c7700eaedef92561d334e1fb7dc28a1"
  :revdesc "ca141a135c77"
  :authors '(("Brett Langdon" . "brett@blangdon.com"))
  :maintainers '(("Brett Langdon" . "brett@blangdon.com")))
