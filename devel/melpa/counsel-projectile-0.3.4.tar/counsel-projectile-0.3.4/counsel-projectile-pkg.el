;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-projectile" "0.3.4"
  "Ivy integration for Projectile."
  '((counsel    "0.13.4")
    (projectile "3.3.0"))
  :url "https://github.com/ericdanan/counsel-projectile"
  :commit "713d504a4d9e0e2e0fda97160a85cd27abf63da7"
  :revdesc "0.3.4-0-g713d504a4d9e"
  :keywords '("project" "convenience"))
