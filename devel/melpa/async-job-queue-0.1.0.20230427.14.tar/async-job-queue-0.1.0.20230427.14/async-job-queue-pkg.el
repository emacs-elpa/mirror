;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async-job-queue" "0.1.0.20230427.14"
  "Dispatch queue of async jobs to a fixed number of slots."
  '((async "1.4")
    (emacs "25.1")
    (queue "0.2"))
  :url "https://github.com/owinebar/emacs-async-job-queue"
  :commit "eeafcce7f960305666b2a51aec55cc6333f6af1b"
  :revdesc "eeafcce7f960"
  :keywords '("extensions" "lisp"))
