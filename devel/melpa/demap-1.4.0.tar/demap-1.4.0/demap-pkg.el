;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "demap" "1.4.0"
  "Detachable minimap package."
  '((emacs "25.1"))
  :url "https://gitlab.com/sawyerjgardner/demap.el"
  :commit "c42ec4752544f80ca7c172ff65e705a56089bc96"
  :revdesc "c42ec4752544"
  :keywords '("lisp" "tools" "convenience")
  :authors '(("Sawyer Gardner" . "https://gitlab.com/sawyerjgardner"))
  :maintainers '(("Sawyer Gardner" . "https://gitlab.com/sawyerjgardner")))
