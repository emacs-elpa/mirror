;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "show-font-mode" "0.1.0.20201225.2"
  "Show font at point on mode line."
  '((emacs "25.1"))
  :url "https://github.com/melissaboiko/show-font-mode"
  :commit "c7328b85655688d257b769192d26b9f5c9bbe26d"
  :revdesc "c7328b856556"
  :keywords '("faces" "i18n" "unicode" "fonts" "fontsets")
  :authors '(("Melissa Boiko" . "melissa@namakajiri.net"))
  :maintainers '(("Melissa Boiko" . "melissa@namakajiri.net")))
