;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-whitespace" "0.2.4.0.20140508.4"
  "Teach whitespace-mode about fancy characters."
  '((ucs-utils       "0.7.6")
    (list-utils      "0.4.2")
    (persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/unicode-whitespace"
  :commit "b0cbfe4f9998a2c1eb4cba031efcb785ef518916"
  :revdesc "v0.2.4-4-gb0cbfe4f9998"
  :keywords '("faces" "wp" "interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
