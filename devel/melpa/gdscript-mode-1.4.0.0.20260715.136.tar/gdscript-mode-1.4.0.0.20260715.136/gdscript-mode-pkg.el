;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "1.4.0.0.20260715.136"
  "Major mode for Godot's GDScript language."
  '((emacs "29.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "8b5b5682835857e5db28ad6a208d3d7dd3f6d4bf"
  :revdesc "8b5b56828358"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
