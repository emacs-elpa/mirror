;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bonjourmadame" "0.6.0.20170919.4"
  "Say \"Hello ma'am!\"."
  ()
  :url "https://github.com/pierre-lecocq/bonjourmadame"
  :commit "d3df185fce78aefa689fded8e56a654f0fde4ac0"
  :revdesc "d3df185fce78")
