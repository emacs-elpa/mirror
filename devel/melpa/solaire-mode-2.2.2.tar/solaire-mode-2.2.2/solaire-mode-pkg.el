;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solaire-mode" "2.2.2"
  "Make certain buffers grossly incandescent."
  '((emacs  "27.1")
    (cl-lib "0.5"))
  :url "https://github.com/hlissner/emacs-solaire-mode"
  :commit "ea97e01e1f978d0cde63049c0d66a6fed2c672a6"
  :revdesc "v2.2.2-0-gea97e01e1f97"
  :keywords '("dim" "bright" "window" "buffer" "faces")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
