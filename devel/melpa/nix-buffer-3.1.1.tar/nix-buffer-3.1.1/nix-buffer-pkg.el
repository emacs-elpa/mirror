;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-buffer" "3.1.1"
  "Set up buffer environments with nix."
  '((f     "0.17.3")
    (emacs "24.4"))
  :url "https://github.com/shlevy/nix-buffer/tree/master/"
  :commit "db57cda36e7477bdc7ef5a136357b971b1d4d099"
  :revdesc "db57cda36e74")
