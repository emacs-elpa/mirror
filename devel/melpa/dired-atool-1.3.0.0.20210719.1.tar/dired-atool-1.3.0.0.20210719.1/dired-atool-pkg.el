;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-atool" "1.3.0.0.20210719.1"
  "Pack/unpack files with atool on dired."
  '((emacs "24"))
  :url "https://github.com/HKey/dired-atool"
  :commit "01416fd5961b901c50686c91cb59b3833adc831b"
  :revdesc "01416fd5961b"
  :keywords '("files")
  :authors '(("Hiroki YAMAKAWA" . "s06139@gmail.com"))
  :maintainers '(("Hiroki YAMAKAWA" . "s06139@gmail.com")))
