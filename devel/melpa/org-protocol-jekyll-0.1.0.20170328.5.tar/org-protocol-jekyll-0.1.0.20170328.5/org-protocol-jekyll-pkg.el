;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-protocol-jekyll" "0.1.0.20170328.5"
  "Jekyll's handler for org-protocol."
  '((cl-lib "0.5"))
  :url "https://github.com/vonavi/org-protocol-jekyll"
  :commit "dec064a42d6dfe81dfde7ba59ece5ca103ac6334"
  :revdesc "dec064a42d6d"
  :authors '(("Vladimir S. Ivanov" . "ivvl82@gmail.com"))
  :maintainers '(("Vladimir S. Ivanov" . "ivvl82@gmail.com")))
