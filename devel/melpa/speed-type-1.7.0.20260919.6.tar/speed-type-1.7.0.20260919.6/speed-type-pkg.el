;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "1.7.0.20260919.6"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "4c7bc4876b03af3c57b6963d59c93fb7c60a367e"
  :revdesc "4c7bc4876b03"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
