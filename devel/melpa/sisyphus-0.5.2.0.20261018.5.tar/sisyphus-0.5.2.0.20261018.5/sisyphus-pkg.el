;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "0.5.2.0.20261018.5"
  "Create releases of Emacs packages."
  '((emacs    "31.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.7"))
  :url "https://github.com/magit/sisyphus"
  :commit "56a8547635d7fdf0396a29a8f19a394c4a8e9859"
  :revdesc "v0.5.2-5-g56a8547635d7"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
