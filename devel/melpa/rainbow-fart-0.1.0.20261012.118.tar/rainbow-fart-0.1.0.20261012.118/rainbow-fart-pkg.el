;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rainbow-fart" "0.1.0.20261012.118"
  "Checks the keywords of code to play suitable sounds."
  '((emacs    "25.1")
    (flycheck "32-cvs"))
  :url "https://repo.or.cz/emacs-rainbow-fart.git"
  :commit "07b0fea92ab81c5fe860be77f13d434015484ad6"
  :revdesc "07b0fea92ab8"
  :keywords '("tools")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
