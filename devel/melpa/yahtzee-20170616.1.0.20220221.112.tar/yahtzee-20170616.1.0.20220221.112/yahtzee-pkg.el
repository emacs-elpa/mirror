;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yahtzee" "20170616.1.0.20220221.112"
  "The yahtzee game."
  '((emacs "24.3"))
  :url "https://github.com/drdv/yahtzee"
  :commit "9b42ba4612d3043464414c08a3d60f6ad594566c"
  :revdesc "9b42ba4612d3"
  :keywords '("games")
  :authors '(("Dimitar Dimitrov" . "mail.mitko@gmail.com"))
  :maintainers '(("Dimitar Dimitrov" . "mail.mitko@gmail.com")))
