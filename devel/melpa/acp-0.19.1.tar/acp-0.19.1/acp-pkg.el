;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "0.19.1"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "0b4240f07d4f3476e49b4a352ee854ff9d28e556"
  :revdesc "0b4240f07d4f")
