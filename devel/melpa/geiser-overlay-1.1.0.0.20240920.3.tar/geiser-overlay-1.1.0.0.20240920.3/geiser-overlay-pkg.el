;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-overlay" "1.1.0.0.20240920.3"
  "Overlay Scheme evaluation results."
  '((emacs  "24.4")
    (geiser "0.31"))
  :url "https://github.com/port19x/geiser-overlay"
  :commit "dd02acf804d6d3c0ac4f86ed580316b19a7f5d5c"
  :revdesc "dd02acf804d6"
  :keywords '("lisp" "scheme")
  :authors '(("port19" . "port19@port19.xyz"))
  :maintainers '(("port19" . "port19@port19.xyz")))
