;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-pomodoro" "2.1.0.0.20261122.42"
  "Pomodoro implementation for org-mode."
  '((alert  "0.5.10")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/lolownia/org-pomodoro"
  :commit "1dacdcda7587866417a9b31ab5607b18d6c6f3c4"
  :revdesc "1dacdcda7587"
  :authors '(("Arthur Leonard Andersen" . "leoc.git@gmail.com")
             ("Marcin Koziej" . "marcinatlolowniadotorg"))
  :maintainers '(("Arthur Leonard Andersen" . "leoc.git@gmail.com")
                 ("Marcin Koziej" . "marcinatlolowniadotorg")))
