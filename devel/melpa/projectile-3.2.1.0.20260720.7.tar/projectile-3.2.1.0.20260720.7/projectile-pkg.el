;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.2.1.0.20260720.7"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "a4a91e08d49d280c9c5c2b0820bb04da198d61db"
  :revdesc "a4a91e08d49d"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
