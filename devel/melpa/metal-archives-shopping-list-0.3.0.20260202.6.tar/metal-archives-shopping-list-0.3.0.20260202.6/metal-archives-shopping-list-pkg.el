;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metal-archives-shopping-list" "0.3.0.20260202.6"
  "Add shopping list generation support to metal-archives."
  '((emacs          "26.3")
    (org-ml         "5.8.7")
    (alert          "1.2")
    (ht             "2.3")
    (metal-archives "0.3"))
  :url "https://github.com/seblemaguer/metal-archives.el"
  :commit "eb1c4d84f04f4afc7a1c2a0f3c4f816f16fa85e6"
  :revdesc "eb1c4d84f04f"
  :keywords '("org" "calendar")
  :authors '(("Sébastien Le Maguer" . "lemagues@tcd.ie"))
  :maintainers '(("Sébastien Le Maguer" . "lemagues@tcd.ie")))
