;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "1.10.0.0.20261122.205"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "b0c04cf21a02351958f3b6fe40e0b28b1515b9bb"
  :revdesc "b0c04cf21a02"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
