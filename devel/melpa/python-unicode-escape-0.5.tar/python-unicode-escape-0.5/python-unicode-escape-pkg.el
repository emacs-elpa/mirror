;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-unicode-escape" "0.5"
  "Completion for Python \\N{NAME} escapes."
  '((emacs "27.1"))
  :url "https://github.com/jb3/python-unicode-escape"
  :commit "5ccc09f6bb773d6aa649aa569cf16099c2d85d0a"
  :revdesc "v0.5-0-g5ccc09f6bb77"
  :keywords '("python" "unicode" "completion" "abbrev")
  :authors '(("Joe Banks" . "joe@jb3.dev"))
  :maintainers '(("Joe Banks" . "joe@jb3.dev")))
