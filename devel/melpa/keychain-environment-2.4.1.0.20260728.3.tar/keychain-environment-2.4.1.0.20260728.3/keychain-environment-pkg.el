;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keychain-environment" "2.4.1.0.20260728.3"
  "Load keychain environment variables."
  ()
  :url "https://github.com/tarsius/keychain-environment"
  :commit "199f407f28f8f473790126a1149abba38e4b3164"
  :revdesc "2.4.1-3-g199f407f28f8"
  :keywords '("gnupg" "pgp" "ssh")
  :authors '(("Paul Tipper" . "bluefooatgooglemaildotcom"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
