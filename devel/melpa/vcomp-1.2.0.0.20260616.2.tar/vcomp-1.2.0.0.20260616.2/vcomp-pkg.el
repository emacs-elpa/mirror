;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vcomp" "1.2.0.0.20260616.2"
  "Compare version strings."
  '((emacs "26.1"))
  :url "https://github.com/tarsius/vcomp"
  :commit "7b3f93d1202bd9353ee6401c47fbc3cc0d6d76e3"
  :revdesc "v1.2.0-2-g7b3f93d1202b"
  :keywords '("versions")
  :authors '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
