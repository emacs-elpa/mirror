;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soft-stone-theme" "0.2.0.20140614.11"
  "Emacs 24 theme with a light background."
  '((emacs "24"))
  :url "https://github.com/mswift42/soft-stone-theme"
  :commit "fb475514cfb02cf30ce358a61c48e46614344d48"
  :revdesc "fb475514cfb0")
