;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "showtip" "0.1"
  "Show tip at cursor."
  ()
  :url "https://github.com/emacsorphanage/showtip"
  :commit "930da302809a4257e8d69425455b29e1cc91949b"
  :revdesc "930da302809a"
  :keywords '("help")
  :authors '(("Ye Wenbin" . "wenbinye@gmail.com"))
  :maintainers '(("Ye Wenbin" . "wenbinye@gmail.com")))
