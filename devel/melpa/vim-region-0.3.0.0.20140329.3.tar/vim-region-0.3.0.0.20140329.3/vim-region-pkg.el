;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-region" "0.3.0.0.20140329.3"
  "Select region as vim."
  '((expand-region "20140127"))
  :url "https://github.com/ongaeshi/emacs-vim-region"
  :commit "7c4a99ce3678fee40c83ab88e8ad075d2a935fdf"
  :revdesc "7c4a99ce3678"
  :authors '(("ongaeshi" . "ongaeshi0621@gmail.com"))
  :maintainers '(("ongaeshi" . "ongaeshi0621@gmail.com")))
