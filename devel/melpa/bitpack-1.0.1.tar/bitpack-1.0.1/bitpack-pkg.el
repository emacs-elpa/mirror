;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitpack" "1.0.1"
  "Bit packing functions."
  '((emacs "24.3"))
  :url "https://github.com/skeeto/bitpack"
  :commit "f368f9fdfc500a1dfa21560830076a4faa3207b5"
  :revdesc "f368f9fdfc50"
  :keywords '("c" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
