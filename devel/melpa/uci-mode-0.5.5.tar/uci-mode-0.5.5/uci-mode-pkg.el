;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uci-mode" "0.5.5"
  "Major-mode for chess engine interaction."
  '((emacs "25.1"))
  :url "https://github.com/dwcoates/uci-mode"
  :commit "2cdf4de5af96d56108a0a5716416ef3c8ac7bb7c"
  :revdesc "v0.5.5-0-g2cdf4de5af96"
  :keywords '("data" "games" "chess"))
