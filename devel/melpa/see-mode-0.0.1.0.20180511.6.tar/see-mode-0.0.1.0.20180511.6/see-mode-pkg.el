;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "see-mode" "0.0.1.0.20180511.6"
  "Edit string  in a separate buffer."
  '((emacs              "24.4")
    (language-detection "0.1.0"))
  :url "https://github.com/marcelino-m/see-mode"
  :commit "db9e4324f9dcc14d5125cb6a79d6c9fad5b14626"
  :revdesc "db9e4324f9dc"
  :keywords '("convenience")
  :authors '(("Marcelo Muñoz" . "ma.munoz.araya@gmail.com"))
  :maintainers '(("Marcelo Muñoz" . "ma.munoz.araya@gmail.com")))
