;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modalka" "0.1.5.0.20260321.42"
  "Modal editing your way."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/modalka"
  :commit "2de5bedc764e318b44dda5e9b70a234432245011"
  :revdesc "2de5bedc764e"
  :keywords '("convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
