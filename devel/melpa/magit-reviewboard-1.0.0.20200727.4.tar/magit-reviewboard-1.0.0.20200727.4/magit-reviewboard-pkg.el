;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-reviewboard" "1.0.0.20200727.4"
  "Show open Reviewboard reviews in Magit."
  '((emacs   "25.2")
    (magit   "2.13.0")
    (s       "1.12.0")
    (request "0.3.0"))
  :url "https://github.com/jtamagnan/magit-reviewboard"
  :commit "aceedff88921f1dfef8a6b2fb18fe316fb7223a8"
  :revdesc "aceedff88921"
  :keywords '("magit" "vc")
  :authors '(("Jules Tamagnan" . "jtamagnan@gmail.com"))
  :maintainers '(("Jules Tamagnan" . "jtamagnan@gmail.com")))
