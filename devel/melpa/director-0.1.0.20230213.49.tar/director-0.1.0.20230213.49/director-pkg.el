;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "director" "0.1.0.20230213.49"
  "Simulate user sessions."
  '((emacs "27.1"))
  :url "https://bard.github.io/emacs-director"
  :commit "16afdbbd91b451fab44c68c8f7d0b810f5283f28"
  :revdesc "16afdbbd91b4"
  :keywords '("maint" "tools")
  :authors '(("Massimiliano Mirra" . "hyperstruct@gmail.com"))
  :maintainers '(("Massimiliano Mirra" . "hyperstruct@gmail.com")))
