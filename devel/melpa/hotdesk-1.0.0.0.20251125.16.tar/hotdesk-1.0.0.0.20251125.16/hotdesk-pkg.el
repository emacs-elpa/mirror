;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hotdesk" "1.0.0.0.20251125.16"
  "Multiple buffer lists for projects & workspaces."
  '((emacs "29.3"))
  :url "https://github.com/j-hotlink/hotdesk"
  :commit "8d20f38edb3f7e53ee86bb408e020f4dc35c6c70"
  :revdesc "8d20f38edb3f"
  :keywords '("convenience" "frames" "local")
  :authors '(("Jonathan Doull" . "jonathan@hotlink.technology"))
  :maintainers '(("Jonathan Doull" . "jonathan@hotlink.technology")))
