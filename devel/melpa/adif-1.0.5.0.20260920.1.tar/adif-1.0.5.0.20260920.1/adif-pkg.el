;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adif" "1.0.5.0.20260920.1"
  "Major mode for viewing and editing ADIF log files."
  '((emacs "25.1"))
  :url "https://github.com/K6SM/adif-mode"
  :commit "e692c3e423e1af6c00a1b88f039450d468baea6d"
  :revdesc "e692c3e423e1"
  :keywords '("comm" "hamradio" "adif" "logging"))
