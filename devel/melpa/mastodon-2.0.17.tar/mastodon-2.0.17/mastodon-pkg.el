;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "2.0.17"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "4b30b2d96625e23325ff3727daa30969b6fe2eed"
  :revdesc "4b30b2d96625"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
