;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-react-redux-yasnippets" "0.0.2.0.20200316.21"
  "JavaScript,React,Redux yasnippets."
  '((emacs     "24.3")
    (yasnippet "0.8.0"))
  :url "https://github.com/sooqua/js-react-redux-yasnippets"
  :commit "9f509043f01fa59bff4daf31b2e95d63f8deab4a"
  :revdesc "9f509043f01f"
  :keywords '("convenience" "snippets"))
