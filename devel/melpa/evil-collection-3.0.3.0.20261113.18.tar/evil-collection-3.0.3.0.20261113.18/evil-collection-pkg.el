;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "3.0.3.0.20261113.18"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "e3f70c513585086ad83e245829e1de8f72f2de26"
  :revdesc "3.0.3-18-ge3f70c513585"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
