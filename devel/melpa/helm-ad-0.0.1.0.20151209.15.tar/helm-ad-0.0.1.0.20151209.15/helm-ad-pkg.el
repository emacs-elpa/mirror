;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ad" "0.0.1.0.20151209.15"
  "Helm source for Active Directory."
  '((dash "2.8.0")
    (helm "1.6.2"))
  :url "https://github.com/tnoda/helm-ad"
  :commit "8ac044705d8620ee354a9cfa8cc1b865e83c0d55"
  :revdesc "8ac044705d86"
  :keywords '("comm")
  :authors '(("Takahiro Noda" . "takahiro.noda+github@gmail.com"))
  :maintainers '(("Takahiro Noda" . "takahiro.noda+github@gmail.com")))
