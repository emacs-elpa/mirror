;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "4.0.9.0.20261105.10"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.9")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "f367b157105f7774b0159015081616bf8da287e2"
  :revdesc "v4.0.9-10-gf367b157105f"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
