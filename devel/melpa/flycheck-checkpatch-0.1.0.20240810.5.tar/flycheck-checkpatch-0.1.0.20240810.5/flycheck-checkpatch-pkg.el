;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-checkpatch" "0.1.0.20240810.5"
  "Flycheck support for checkpatch.pl tool."
  '((emacs    "25")
    (flycheck "30"))
  :url "https://github.com/zpp0/flycheck-checkpatch"
  :commit "61710dff2828ff119968161e7118fce2a4a0b67f"
  :revdesc "61710dff2828"
  :authors '(("Alexander Yarygin" . "yarygin.alexander@gmail.com"))
  :maintainers '(("Alexander Yarygin" . "yarygin.alexander@gmail.com")))
