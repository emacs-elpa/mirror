;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.4.0.0.20260630.20"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "2dea9405a576f5dff7e0ef700fec7733a244226b"
  :revdesc "v2.4.0-20-g2dea9405a576"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
