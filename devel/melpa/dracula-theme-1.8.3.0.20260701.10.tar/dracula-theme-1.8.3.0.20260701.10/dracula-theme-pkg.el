;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dracula-theme" "1.8.3.0.20260701.10"
  "Dracula Theme."
  '((emacs "24.3"))
  :url "https://github.com/dracula/emacs"
  :commit "1acd97258258415f6a43c332475fbdcd7ceb9274"
  :revdesc "v1.8.3-10-g1acd97258258"
  :maintainers '(("tienne Deparis" . "etienne@depar.is")))
