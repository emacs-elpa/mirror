;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-shell" "0.8.0.20170723.1"
  "A flymake syntax-checker for shell scripts."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-shell"
  :commit "a16cf453056b9849cc7c912bb127fb0b08fc6dab"
  :revdesc "a16cf453056b"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
