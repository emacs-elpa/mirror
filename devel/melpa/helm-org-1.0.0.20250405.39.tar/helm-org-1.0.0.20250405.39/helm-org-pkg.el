;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-org" "1.0.0.20250405.39"
  "Helm for org headlines and keywords completion."
  '((helm  "4.0.2")
    (emacs "25.1"))
  :url "https://github.com/emacs-helm/helm-org"
  :commit "4744ca7f8b35e17bafce9cb0093deb87a232699d"
  :revdesc "v1.0-39-g4744ca7f8b35"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
