;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soundklaus" "0.1.0.0.20191220.183"
  "Play music on SoundCloud with Emacs via EMMS."
  '((dash     "2.12.1")
    (emacs    "24")
    (emms     "4.0")
    (s        "1.11.0")
    (pkg-info "0.4")
    (cl-lib   "0.5")
    (request  "0.2.0"))
  :url "https://github.com/r0man/soundklaus.el"
  :commit "15ce6e7f24a45e4f202d83cca9fa3bfdd94ca592"
  :revdesc "15ce6e7f24a4"
  :keywords '("soundcloud" "music" "emms")
  :authors '(("r0man" . "roman@burningswell.com"))
  :maintainers '(("r0man" . "roman@burningswell.com")))
