;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lirve" "0.0.0.20240419.58"
  "Learn irregular verbs in English."
  '((emacs "26.1"))
  :url "https://github.com/tanrax/lirve.el"
  :commit "ff3031fa82d854411da40a32c6191d201b4abf09"
  :revdesc "ff3031fa82d8"
  :authors '(("Andros Fenollosa" . "andros@fenollosa.email"))
  :maintainers '(("Andros Fenollosa" . "andros@fenollosa.email")))
