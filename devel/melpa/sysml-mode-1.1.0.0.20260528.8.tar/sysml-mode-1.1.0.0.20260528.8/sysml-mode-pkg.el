;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sysml-mode" "1.1.0.0.20260528.8"
  "Major mode for SysML v2 (Systems Modeling Language)."
  '((emacs "25.1"))
  :url "https://github.com/decisym/sysml-mode"
  :commit "e8ff9eea7f8f5d18e6a74a48411a1b8e39dd0916"
  :revdesc "e8ff9eea7f8f"
  :keywords '("languages" "modeling" "systems engineering")
  :authors '(("Ph.D." . "don@decisym.ai"))
  :maintainers '(("Ph.D." . "don@decisym.ai")))
