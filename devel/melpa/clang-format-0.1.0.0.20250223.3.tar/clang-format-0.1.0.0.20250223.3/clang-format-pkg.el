;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clang-format" "0.1.0.0.20250223.3"
  "Format code using clang-format."
  '((cl-lib "0.3"))
  :url "https://github.com/emacsmirror/clang-format"
  :commit "a099177b5cd5060597d454e4c1ffdc96b92ba985"
  :revdesc "a099177b5cd5"
  :keywords '("tools" "c"))
