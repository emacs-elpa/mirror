;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "2.2.0"
  "Browse GitHub repos without cloning."
  '((emacs "29.1")
    (ghub  "4.0.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "ceaf310e12bdda479694f619264c637f81beb129"
  :revdesc "2.2.0-0-gceaf310e12bd"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
