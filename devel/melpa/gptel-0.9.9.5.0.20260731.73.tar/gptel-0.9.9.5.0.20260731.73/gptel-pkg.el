;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "0.9.9.5.0.20260731.73"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "9cafa41e7172a995e4eeadb5049a8c05bf7c30ba"
  :revdesc "9cafa41e7172"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
