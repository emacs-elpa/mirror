;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "virtual-ring" "0.1.0.20250920.11"
  "Fixed size rings with virtual rotation."
  '((emacs "25.1"))
  :url "https://github.com/countvajhula/virtual-ring"
  :commit "2d53ba23ecdca94801cc88085c7df7346d98e514"
  :revdesc "v0.1-11-g2d53ba23ecdc"
  :authors '(("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
