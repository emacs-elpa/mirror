;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-capf" "0.1"
  "Auto-complete source with completion-at-point."
  '((auto-complete "1.4")
    (cl-lib        "0.5"))
  :url "https://github.com/syohex/emacs-ac-capf"
  :commit "17571dba0a8f98111f2ab758e9bea285b263781b"
  :revdesc "17571dba0a8f"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
