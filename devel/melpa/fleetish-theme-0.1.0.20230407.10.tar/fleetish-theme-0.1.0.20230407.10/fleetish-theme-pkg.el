;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fleetish-theme" "0.1.0.20230407.10"
  "A take on the JetBrains Fleet theme."
  '((emacs "24"))
  :url "https://github.com/nylar/fleetish-emacs-theme"
  :commit "482513562b6691c7f3440b62a31033d22378ed96"
  :revdesc "482513562b66"
  :authors '(("Scott Raine" . "scott@raine.sh"))
  :maintainers '(("Scott Raine" . "scott@raine.sh")))
