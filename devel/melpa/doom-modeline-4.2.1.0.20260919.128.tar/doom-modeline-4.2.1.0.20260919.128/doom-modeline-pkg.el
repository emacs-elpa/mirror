;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "4.2.1.0.20260919.128"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "8185cbb4a01b5a73e308fa88391dcea0554c2c49"
  :revdesc "8185cbb4a01b"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
