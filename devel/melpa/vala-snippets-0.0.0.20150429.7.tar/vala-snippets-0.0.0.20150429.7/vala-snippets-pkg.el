;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vala-snippets" "0.0.0.20150429.7"
  "Yasnippets for Vala."
  '((yasnippet "0.8.0"))
  :url "https://github.com/gopar/vala-snippets"
  :commit "671439501060449bd100b9fffd524a86064fbfbb"
  :revdesc "671439501060")
