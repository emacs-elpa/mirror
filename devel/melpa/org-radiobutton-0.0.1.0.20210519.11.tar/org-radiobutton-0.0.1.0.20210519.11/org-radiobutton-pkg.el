;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-radiobutton" "0.0.1.0.20210519.11"
  "Radiobutton for org-mode lists."
  '((dash  "2.13.0")
    (emacs "24"))
  :url "https://github.com/Fuco1/org-radiobutton"
  :commit "4ba26bbd26102c45c234bc6ce9a8e9c655c6a0a2"
  :revdesc "4ba26bbd2610"
  :keywords '("outlines")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
