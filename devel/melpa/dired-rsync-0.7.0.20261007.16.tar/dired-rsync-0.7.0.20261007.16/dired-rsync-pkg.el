;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-rsync" "0.7.0.20261007.16"
  "Allow rsync from dired buffers."
  '((s     "1.12.0")
    (dash  "2.0.0")
    (emacs "25.1"))
  :url "https://github.com/stsquad/dired-rsync"
  :commit "52833b7f1ee288f23df129cbeae9759bac83f42c"
  :revdesc "52833b7f1ee2"
  :authors '(("Alex Bennée" . "alex@bennee.com"))
  :maintainers '(("Alex Bennée" . "alex@bennee.com")))
