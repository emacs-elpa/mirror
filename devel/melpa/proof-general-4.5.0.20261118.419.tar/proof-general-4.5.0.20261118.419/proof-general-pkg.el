;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "4.5.0.20261118.419"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "f0460033ef60baa04a989f565a79d5f871196df4"
  :revdesc "v4.5-419-gf0460033ef60"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
