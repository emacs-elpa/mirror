;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.1.1.0.20260812.3"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "f35317b73b0c6c9d590b67a989c36b83011be4ab"
  :revdesc "4.1.1-3-gf35317b73b0c"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
