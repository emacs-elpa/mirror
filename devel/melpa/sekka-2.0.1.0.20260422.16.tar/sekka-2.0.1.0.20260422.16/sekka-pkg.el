;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sekka" "2.0.1.0.20260422.16"
  "Pure Elisp Japanese IME inspired by SKK."
  '((emacs "25.1")
    (popup "0.5.2"))
  :url "https://github.com/kiyoka/sekka"
  :commit "78dfe17b2e04b03b6248e39814f84a77b4f6f2b7"
  :revdesc "78dfe17b2e04"
  :keywords '("i18n")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
