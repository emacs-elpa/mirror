;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-journal" "1.0.1.0.20260630.26"
  "Daily note interface for vulpea."
  '((emacs     "29.1")
    (vulpea    "2.0.0")
    (vulpea-ui "1.0.0")
    (dash      "2.20.0"))
  :url "https://github.com/d12frosted/vulpea-journal"
  :commit "c3217b822ce859ba473475b3ed89f17f3134747b"
  :revdesc "v1.0.1-26-gc3217b822ce8"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
