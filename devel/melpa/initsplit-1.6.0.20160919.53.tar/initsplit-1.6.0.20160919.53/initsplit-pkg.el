;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "initsplit" "1.6.0.20160919.53"
  "Code to split customizations into different files."
  ()
  :url "http://www.gci-net.com/users/j/johnw/emacs.html"
  :commit "c941d436eb2b10b01c76a582c5a2b23fb30751aa"
  :revdesc "c941d436eb2b"
  :keywords '("lisp")
  :authors '(("John Wiegley" . "johnw@gnu.org")
             ("Dave Abrahams" . "dave@boostpro.com"))
  :maintainers '(("John Wiegley" . "johnw@gnu.org")
                 ("Dave Abrahams" . "dave@boostpro.com")))
