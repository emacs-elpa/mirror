;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-ada-spark" "1.3.0.0.20221114.8"
  "Babel functions for Ada & SPARK."
  '((emacs "26.1")
    (f     "0.20.0"))
  :url "https://github.com/rocher/ob-ada-spark"
  :commit "92978410ca14aa4e84c229a0920ad40be91c35e1"
  :revdesc "92978410ca14"
  :keywords '("languages" "tools" "outlines"))
