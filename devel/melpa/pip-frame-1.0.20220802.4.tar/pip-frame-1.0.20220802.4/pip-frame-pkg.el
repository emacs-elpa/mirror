;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pip-frame" "1.0.20220802.4"
  "Display and manage a PIP frame."
  '((emacs "25.1"))
  :url "https://git.zamazal.org/pdm/pip-frame"
  :commit "8c396a11f532a1beb594b65e99e594f1e9f1c2c8"
  :revdesc "8c396a11f532"
  :keywords '("frames")
  :authors '(("Milan Zamazal" . "pdm@zamazal.org"))
  :maintainers '(("Milan Zamazal" . "pdm@zamazal.org")))
