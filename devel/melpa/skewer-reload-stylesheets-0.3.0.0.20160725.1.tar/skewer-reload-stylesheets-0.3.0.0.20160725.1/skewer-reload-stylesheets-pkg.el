;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "skewer-reload-stylesheets" "0.3.0.0.20160725.1"
  "Live-edit CSS, SCSS, Less, and friends."
  '((skewer-mode "1.5.3"))
  :url "https://github.com/NateEag/skewer-reload-stylesheets"
  :commit "3207abca9551660407a6b009cb40fb32bbb550da"
  :revdesc "3207abca9551"
  :authors '(("Nate Eagleson" . "nate@nateeag.com"))
  :maintainers '(("Nate Eagleson" . "nate@nateeag.com")))
