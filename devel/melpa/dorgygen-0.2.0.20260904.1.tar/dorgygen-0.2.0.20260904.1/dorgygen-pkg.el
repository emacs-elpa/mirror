;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dorgygen" "0.2.0.20260904.1"
  "Source code documentation in org-mode."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/dorgygen"
  :commit "2548e715405d082090eb9ea39d723e90bb05d0eb"
  :revdesc "2548e715405d"
  :keywords '("tools" "wp"))
