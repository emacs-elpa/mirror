;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "0.8.0.0.20260730.1"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "68381b4a041170bf6ab727806bd59194fd8760f6"
  :revdesc "v0.8.0-1-g68381b4a0411"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
