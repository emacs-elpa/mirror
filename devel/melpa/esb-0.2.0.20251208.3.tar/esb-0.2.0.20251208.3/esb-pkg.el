;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esb" "0.2.0.20251208.3"
  "Emacs Simple Bookmark."
  '((emacs "27.1"))
  :url "https://github.com/0xhenrique/esb"
  :commit "3646ddab71ede860257182a7e772aad476533d39"
  :revdesc "3646ddab71ed"
  :authors '(("Henrique Marques" . "hm2030master@proton.me"))
  :maintainers '(("Henrique Marques" . "hm2030master@proton.me")))
