;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-section" "4.6.0.0.20260709.14"
  "Sections for read-only buffers."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/magit"
  :commit "cf9d129d3612c7a900a82263951310b186860834"
  :revdesc "v4.6.0-14-gcf9d129d3612"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")))
