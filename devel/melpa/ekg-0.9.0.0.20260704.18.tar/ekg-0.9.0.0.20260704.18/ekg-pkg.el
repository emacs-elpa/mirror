;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.0.0.20260704.18"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "ea1e1ada31ec34e1c1894d41779347f48fc9360d"
  :revdesc "ea1e1ada31ec"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
