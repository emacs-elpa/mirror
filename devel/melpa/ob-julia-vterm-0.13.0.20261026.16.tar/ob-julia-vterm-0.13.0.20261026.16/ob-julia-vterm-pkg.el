;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-julia-vterm" "0.13.0.20261026.16"
  "Babel functions for Julia that work with julia-vterm."
  '((emacs       "26.1")
    (julia-vterm "0.26")
    (queue       "0.2"))
  :url "https://github.com/shg/ob-julia-vterm.el"
  :commit "8885bc1dd1751cc85e596e7f2299d6af4a30ad1b"
  :revdesc "8885bc1dd175"
  :keywords '("julia" "org" "outlines" "literate programming" "reproducible research"))
