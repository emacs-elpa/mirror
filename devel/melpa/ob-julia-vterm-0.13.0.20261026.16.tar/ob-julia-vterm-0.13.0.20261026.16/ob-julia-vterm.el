;;; ob-julia-vterm.el --- Babel functions for Julia that work with julia-vterm -*- lexical-binding: t -*-

;; Copyright (C) 2020-2026 Shigeaki Nishina

;; Author: Shigeaki Nishina
;; Maintainer: Shigeaki Nishina
;; Created: October 31, 2020
;; URL: https://github.com/shg/ob-julia-vterm.el
;; Package-Requires: ((emacs "26.1") (julia-vterm "0.26") (queue "0.2"))
;; Package-Version: 0.13.0.20261026.16
;; Package-Revision: 8885bc1dd175
;; Keywords: julia, org, outlines, literate programming, reproducible research

;; This file is not part of GNU Emacs.

;;; License:

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or (at
;; your option) any later version.
;;
;; This program is distributed in the hope that it will be useful, but
;; WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
;; General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see https://www.gnu.org/licenses/.

;;; Commentary:

;; Org-Babel support for Julia source code block using julia-vterm.

;;; Requirements:

;; This package uses julia-vterm to run Julia code.
;;
;; - https://github.com/shg/julia-vterm.el
;;
;; See https://github.com/shg/ob-julia-vterm.el for installation
;; instructions.

;;; Code:

(require 'ob)
(require 'org-id)
(require 'queue)
(require 'filenotify)
(require 'julia-vterm)

(defgroup ob-julia-vterm nil
  "Org-Babel support for Julia using julia-vterm."
  :group 'org-babel)

(defcustom ob-julia-vterm-helper-buffer-wide-repl-keys nil
  "Non-nil means REPL-related helper keys are active throughout Org buffers.
When nil, `C-c C-z' and `C-c C-d' are active only in Julia source
blocks handled by this package.  When non-nil, they are active
throughout Org buffers where `ob-julia-vterm-helper-mode' is enabled."
  :type 'boolean
  :group 'ob-julia-vterm)

(make-variable-buffer-local 'ob-julia-vterm-helper-buffer-wide-repl-keys)

(defun ob-julia-vterm-wrap-body (use-let body)
  "Make Julia code that execute-s BODY and obtains the results, depending on USE-LET."
  (concat
   (if use-let "let\n" "")
   body
   (if use-let "\nend\n" "")))

(defun ob-julia-vterm-make-str-to-run (uuid params src-file out-file stdin)
  "Make Julia code that execute-s the code in SRC-FILE depending on PARAMS.
The results are saved in OUT-FILE.  UUID is a unique id assigned
to the evaluation."
  (format
   (pcase (cdr (assq :result-type params))
     ('output "\
#OB-JULIA-VTERM_BEGIN %s
import Logging; let in_file = %s, out_file = \"%s\"
    open(out_file, \"w\") do io
        logger = Logging.ConsoleLogger(io)
        redirect_stdio(stdin = in_file, stdout = io) do
            try
                include(\"%s\")
                # %s %s
            catch e
                msg = if %s
                    bt = catch_backtrace()
                    i = findfirst(ip -> any(fr.func == Symbol(\"top-level scope\") for fr in StackTraces.lookup(ip)), bt)
                    showerror(logger.stream, e, bt[1:i])
                else
                    showerror(logger.stream, e)
                end
            end
        end
    end
    result = open(io -> println(read(io, String)), out_file)
    if result == nothing
        open(out_file, \"a\") do io
            print(io, \"\n\")
        end
    else
        result
    end
end #OB-JULIA-VTERM_END\n")
     ('value "\
#OB-JULIA-VTERM_BEGIN %s
import Logging; let in_file = %s, out_file = \"%s\"
    open(out_file, \"w\") do io
        logger = Logging.ConsoleLogger(io)
        redirect_stdio(stdin = in_file) do
            try
                result = include(\"%s\")
                if result == \"\"
                    result = \"\n\"
                end
                pp = %s; nolimit = %s
                if pp
                    if nolimit
                        Base.invokelatest(show, io, \"text/plain\", result)
                    else
                        Base.invokelatest(show, IOContext(io, :limit => true), \"text/plain\", result)
                    end
                else
                    if nolimit
                        Base.invokelatest(print, io, result)
                    else
                        Base.invokelatest(print, IOContext(io, :limit => true), result)
                    end
                end
                result
            catch e
                msg = if %s
                    bt = catch_backtrace()
                    i = findfirst(ip -> any(fr.func == Symbol(\"top-level scope\") for fr in StackTraces.lookup(ip)), bt)
                    sprint(showerror, e, bt[1:i])
                else
                    msg = sprint(showerror, e)
                end
                println(logger.stream, msg)
                println(msg)
            end
        end
    end
end #OB-JULIA-VTERM_END\n"))
   (substring uuid 0 8)
   (if stdin (format "\"%s\"" stdin) "nothing")
   out-file src-file
   (if (member "pp" (cdr (assq :result-params params))) "true" "false")
   (if (member "nolimit" (cdr (assq :result-params params))) "true" "false")
   (if (not (member (cdr (assq :debug params)) '(nil "no"))) "true" "false")))

(defun org-babel-execute:julia-vterm (body params)
  "Execute a block of Julia code with Babel.
This function is called by `org-babel-execute-src-block'.
BODY is the contents and PARAMS are header arguments of the code block."
  (let* ((session (ob-julia-vterm-session))
         (use-let (ob-julia-vterm-session-none-p))
	 (var-lines (org-babel-variable-assignments:julia-vterm params))
	 (result-params (cdr (assq :result-params params))))
    (with-current-buffer (julia-vterm-repl-buffer session)
      (add-hook 'julia-vterm-repl-filter-functions #'ob-julia-vterm-output-filter))
    (ob-julia-vterm-evaluate (current-buffer)
			     session
                             use-let
			     (org-babel-expand-body:generic body params var-lines)
			     params)))

(defun org-babel-variable-assignments:julia-vterm (params)
  "Return list of Julia statements assigning variables based on variable-value pairs in PARAMS."
  (mapcar
   (lambda (pair)
     (format "%s = %s" (car pair) (ob-julia-vterm-value-to-julia (cdr pair))))
   (org-babel--get-vars params)))

(defun ob-julia-vterm-escape-string (str)
  "Escape special characters in STR for Julia variable assignments."
  (replace-regexp-in-string "\"" "\\\\\"" str))

(defun ob-julia-vterm-value-to-julia (value)
  "Convert an emacs-lisp VALUE to a string of julia code for the value."
  (cond
   ((listp value) (format "\"%s\"" value))
   ((numberp value) value)
   ((stringp value) (or (org-babel--string-to-number value)
			(concat "\"" (ob-julia-vterm-escape-string value) "\"")))
   ((symbolp value) (ob-julia-vterm-escape-string (symbol-name value)))
   (t value)))

(defun ob-julia-vterm-check-long-line (value)
  "Return t if VALUE is too long for org-babel result."
  (let ((str (prin1-to-string value)))
    (catch 'loop
      (dolist (line (split-string str "\n"))
	(if (> (length line) 12000)
	    (throw 'loop t))))))

(defvar-local ob-julia-vterm-evaluation-queue nil)
(defvar-local ob-julia-vterm-evaluation-watches nil)

(defun ob-julia-vterm-add-evaluation-to-evaluation-queue (session evaluation)
  "Add an EVALUATION of a source block to SESSION's evaluation queue."
  (with-current-buffer (julia-vterm-repl-buffer session)
    (if (not (queue-p ob-julia-vterm-evaluation-queue))
	(setq ob-julia-vterm-evaluation-queue (queue-create)))
    (queue-append ob-julia-vterm-evaluation-queue evaluation)))

(defun ob-julia-vterm-evaluation-completed-callback-func (session)
  "Return a callback function to be called when an evaluation in SESSION is completed."
  (lambda (event)
    (if (eq 'changed (cadr event))
	(with-current-buffer (julia-vterm-repl-buffer session)
	  (if (and (queue-p ob-julia-vterm-evaluation-queue)
		   (> (queue-length ob-julia-vterm-evaluation-queue) 0))
	      (let-alist (queue-first ob-julia-vterm-evaluation-queue)
		(with-current-buffer .buf
		  (save-excursion
		    (goto-char .src-block-begin)
		    (when (and (not (equal .src-block-begin .src-block-end))
			       (or (eq (org-element-type (org-element-context)) 'src-block)
				   (eq (org-element-type (org-element-context)) 'inline-src-block)))
		      (ob-julia-vterm-wait-for-file-change .out-file 10 0.1)
		      (let ((result (with-temp-buffer
				      (insert-file-contents .out-file)
				      (replace-regexp-in-string "\n\\'" "" (buffer-string))))
			    (result-params (cdr (assq :result-params .params))))
			(cond ((and (member "file" result-params)
				    (cdr (assq :file .params)))
			       (org-redisplay-inline-images))
			      ((member "file" result-params)
			       (org-babel-insert-result
				result result-params
				(org-babel-get-src-block-info 'light))
			       (org-redisplay-inline-images))
			      ((not (member "none" result-params))
			       (org-babel-insert-result
				(if (ob-julia-vterm-check-long-line result)
				    "Output suppressed (line too long)"
				  (org-babel-result-cond result-params
				    result
				    (org-babel-reassemble-table
				     result
				     (org-babel-pick-name (cdr (assq :colname-names .params))
							  (cdr (assq :colnames .params)))
				     (org-babel-pick-name (cdr (assq :rowname-names .params))
							  (cdr (assq :rownames .params))))))
				result-params
				(org-babel-get-src-block-info 'light))))))))
		(queue-dequeue ob-julia-vterm-evaluation-queue)
		(file-notify-rm-watch (cdr (assoc .uuid ob-julia-vterm-evaluation-watches)))
		(setq ob-julia-vterm-evaluation-watches
		      (delete (assoc .uuid ob-julia-vterm-evaluation-watches)
			      ob-julia-vterm-evaluation-watches))
		(ob-julia-vterm-process-evaluation-queue .session)))))))

(defvar-local ob-julia-vterm-output-suppress-state nil)

(defun ob-julia-vterm-output-filter (str)
  "Remove the pasted julia code from STR."
  (let ((begin (string-match "#OB-JULIA-VTERM_BEGIN" str))
	(end (string-match "#OB-JULIA-VTERM_END" str))
	(state ob-julia-vterm-output-suppress-state))
    (if begin (setq ob-julia-vterm-output-suppress-state 'suppress))
    (if end (setq ob-julia-vterm-output-suppress-state nil))
    (let* ((str (replace-regexp-in-string
		 "#OB-JULIA-VTERM_BEGIN \\([0-9a-z]*\\)\\(.*?\n\\)*.*" "Executing... \\1\r\n" str))
	   (str (replace-regexp-in-string
		 "\\(.*?\n\\)*.*#OB-JULIA-VTERM_END" "" str)))
      (if (or begin end)
	  str
	(if state "" str)))))

(defun ob-julia-vterm-wait-for-file-change (file sec interval)
  "Wait up to SEC seconds synchronously until FILE becomes non-empty.
The file is checked at INTERVAL second intervals while waiting."
  (let ((c 0))
    (while (and (< c (/ sec interval))
		(= 0 (file-attribute-size (file-attributes file))))
      (sleep-for interval)
      (setq c (1+ c))))
  (sleep-for 0.1))

(defun ob-julia-vterm-process-one-evaluation-sync (session evaluation)
  "Execute the first EVALUATION in SESSION's queue synchronously.
Return the result."
  (with-current-buffer (julia-vterm-repl-buffer session)
    (while (not (eq (julia-vterm-repl-prompt-status) :julia))
      (message "Waiting REPL becomes ready")
      (sleep-for 0.1))
    (let-alist evaluation
      (julia-vterm-paste-string
       (ob-julia-vterm-make-str-to-run .uuid
				       .params
				       .src-file
				       .out-file
				       .stdin)
       .session)
      (ob-julia-vterm-wait-for-file-change .out-file 10 0.1)
      (with-temp-buffer
	(insert-file-contents .out-file)
	(buffer-string)))))

(defun ob-julia-vterm-process-one-evaluation-async (session)
  "Execute the first evaluation in SESSION's queue asynchronously.
Always return nil."
  (with-current-buffer (julia-vterm-repl-buffer session)
    (if (eq (julia-vterm-repl-prompt-status) :julia)
	(let-alist (queue-first ob-julia-vterm-evaluation-queue)
	  (unless (assoc .uuid ob-julia-vterm-evaluation-watches)
	    (let ((desc (file-notify-add-watch .out-file
					       '(change)
					       (ob-julia-vterm-evaluation-completed-callback-func session))))
	      (push (cons .uuid desc) ob-julia-vterm-evaluation-watches))
	    (julia-vterm-paste-string
	     (ob-julia-vterm-make-str-to-run .uuid
					     .params
					     .src-file
					     .out-file
					     .stdin)
	     .session)))
      (if (null ob-julia-vterm-evaluation-watches)
	  (run-at-time 0.1 nil #'ob-julia-vterm-process-evaluation-queue session))))
  nil)

(defun ob-julia-vterm-process-evaluation-queue (session)
  "Process the evaluation queue for SESSION.
If ASYNC is non-nil, the next evaluation will be executed asynchronously."
  (with-current-buffer (julia-vterm-repl-buffer session)
    (if (and (queue-p ob-julia-vterm-evaluation-queue)
	     (not (queue-empty ob-julia-vterm-evaluation-queue)))
	(ob-julia-vterm-process-one-evaluation-async session)
      (message "Queue empty"))))

(defun ob-julia-vterm-evaluate (buf session use-let body params)
  "Evaluate a Julia code block in BUF in a julia-vterm REPL specified with SESSION.
BODY contains the source code to be evaluated, and PARAMS contains header arguments.
With non-nil USE-LET, the code will be executed in a `let' block"
  (let* ((uuid (org-id-uuid))
	 (src-file (org-babel-temp-file "julia-vterm-src-"))
	 (out-file (org-babel-temp-file "julia-vterm-out-"))
	 (result-params (cdr (assq :result-params params)))
	 (stdin (let ((stdin (cdr (assq :stdin params))))
		  (when stdin
		    (let ((tmp (org-babel-temp-file "julia-vterm-stdin-"))
			  (res (org-babel-ref-resolve stdin)))
		      (with-temp-file tmp
			(insert res))
		      tmp))))
	 (async (not (or (bound-and-true-p org-babel-exp-reference-buffer)
			 (eq (org-element-type (org-element-context)) 'babel-call)
			 (member 'org-babel-ref-resolve (mapcar #'cadr (backtrace-frames)))))))
    (with-temp-file src-file (insert (ob-julia-vterm-wrap-body use-let body)))
    (let ((elm (org-element-context))
	  (src-block-begin (make-marker))
	  (src-block-end (make-marker)))
      (set-marker src-block-begin (org-element-property :begin elm))
      (set-marker src-block-end (org-element-property :end elm))
      (let ((evaluation (list (cons 'uuid uuid)
			      (cons 'async async)
			      (cons 'buf buf)
			      (cons 'session session)
			      (cons 'params (copy-tree params))
			      (cons 'src-file src-file)
			      (cons 'out-file out-file)
			      (cons 'stdin stdin)
			      (cons 'src-block-begin src-block-begin)
			      (cons 'src-block-end src-block-end))))
	(if (not async)
	    (ob-julia-vterm-process-one-evaluation-sync session evaluation)
	  (ob-julia-vterm-add-evaluation-to-evaluation-queue session evaluation)
	  (ob-julia-vterm-process-evaluation-queue session)
	  ;; Babel uses this same list to insert the immediate return value.
	  ;; Keep the original file result parameters in the queued evaluation.
	  (when (and (member "file" result-params)
		     (not (cdr (assq :file params))))
	    (setcar (member "file" result-params) "verbatim"))
	  (concat "Executing... " (substring uuid 0 8)))))))

(add-to-list 'org-src-lang-modes '("julia-vterm" . julia))


;;----------------------------------------------------------------------
;; A helper minor mode for Org buffer with julia-vterm source code blocks.

(defun ob-julia-vterm-session-context ()
  "Return contextual information for determining which REPL to interact with.
The returned alist has three keys, block-ses, fellow-ses, and file-ses."
  (let* ((raw (org-element-property :parameters (org-element-at-point)))
	 (session-specified (string-match-p ":session" (or raw "")))
	 (src-block-info (org-babel-get-src-block-info))
	 (lang (car src-block-info))
	 (block-ses (and session-specified
                         (cdr (assoc :session (caddr src-block-info)))))
         (fellow-ses (and (buffer-live-p julia-vterm-fellow-repl-buffer)
                          (julia-vterm-repl-session-name julia-vterm-fellow-repl-buffer)))
         (props (cond
                 ((and (stringp lang)
                       (string= lang "julia-vterm"))
                  (org-entry-get-with-inheritance "header-args:julia-vterm"))
                 ((and (stringp lang)
                       (string= lang "julia")
                       (fboundp 'org-babel-execute:julia)
                       (eq (symbol-function 'org-babel-execute:julia)
                           'org-babel-execute:julia-vterm))
                  (org-entry-get-with-inheritance "header-args:julia"))
                 (t nil)))
         (file-ses (cadr (member ":session" (split-string (or props ""))))))
    (list (cons 'block-ses block-ses)
          (cons 'fellow-ses fellow-ses)
          (cons 'file-ses file-ses))))

(defun ob-julia-vterm-session ()
  "Return the julia-vterm session name based on context."
  (let-alist (ob-julia-vterm-session-context)
    (if (or (null .block-ses)
            (string= .block-ses "none"))
        (or .fellow-ses
            (if (and .file-ses (not (string= .file-ses "none")))
                .file-ses
              "main"))
      .block-ses)))

(defun ob-julia-vterm-session-none-p ()
  "Return whether the block should be executed in let block."
  (let-alist (ob-julia-vterm-session-context)
    (if .block-ses
        (string= .block-ses "none")
      (string= .file-ses "none"))))

(defun ob-julia-vterm-fellow-repl-buffer (&optional session-name)
  "Return the paired REPL buffer for the current src block.
If SESSION-NAME is specified, return the REPL buffer for that session."
  (julia-vterm-repl-buffer (or session-name (ob-julia-vterm-session))))

(defun ob-julia-vterm-switch-to-repl-buffer (&optional arg)
  "Switch to the paired REPL buffer or to the one with a specified session.
With prefix ARG, prompt for session name."
  (interactive "P")
  (let ((session-name (cond ((null arg) nil)
                            (t (julia-vterm-ask-session)))))
    (julia-vterm-switch-to (ob-julia-vterm-fellow-repl-buffer session-name))))

(defun ob-julia-vterm-send-region-or-current-line ()
  "Send the content of the region if the region is active, or the current line."
  (interactive)
  (julia-vterm-send-region-or-current-line))

(defun ob-julia-vterm-helper-handles-julia-p ()
  "Return non-nil if this package handles `julia' source blocks."
  (and (fboundp 'org-babel-execute:julia)
       (eq (indirect-function 'org-babel-execute:julia)
           (indirect-function 'org-babel-execute:julia-vterm))))

(defun ob-julia-vterm-helper-in-julia-src-block-p (&optional inside)
  "Return non-nil if point is in a Julia src block handled by this package.
When INSIDE is non-nil, return t only when point is inside the source block."
  (and (org-in-src-block-p inside)
       (let ((lang (org-element-property :language (org-element-at-point))))
         (or (string= lang "julia-vterm")
             (and (string= lang "julia")
                  (ob-julia-vterm-helper-handles-julia-p))))))

(defun ob-julia-vterm-helper-fellow-session ()
  "Return the session name of the fellow REPL, or nil."
  (and (buffer-live-p julia-vterm-fellow-repl-buffer)
       (julia-vterm-repl-session-name julia-vterm-fellow-repl-buffer)))

(defun ob-julia-vterm-helper-header-args (&optional lang)
  "Return inherited and file-wide header arguments for LANG.
When LANG is nil, return language-independent header arguments."
  (let ((property (if lang (concat "header-args:" lang) "header-args")))
    (or (org-entry-get-with-inheritance property)
        (catch 'value
          (dolist (item (cdr (assoc "PROPERTY"
                                    (org-collect-keywords '("PROPERTY")))))
            (when (string-match
                   (concat "\\`" (regexp-quote property) "[ \t]+\\(.*\\)")
                   item)
              (throw 'value (match-string 1 item))))))))

(defun ob-julia-vterm-helper-header-session (&optional lang)
  "Return inherited header-args session for LANG, or nil.
When LANG is nil, try `julia-vterm' and then `julia' if this package
handles `julia' source blocks.  Language-specific arguments override
language-independent arguments.  Ignore a session value of \"none\"."
  (let* ((langs (cond
                 ((string= lang "julia-vterm") '("julia-vterm"))
                 ((and (string= lang "julia")
                       (ob-julia-vterm-helper-handles-julia-p))
                  '("julia"))
                 ((null lang)
                  (append '("julia-vterm")
                          (and (ob-julia-vterm-helper-handles-julia-p)
                               '("julia"))))))
         (common (org-babel-parse-header-arguments
                  (or (ob-julia-vterm-helper-header-args) "") t))
         (session
          (catch 'session
            (dolist (item langs)
              (let* ((props (ob-julia-vterm-helper-header-args item))
                     (value (cdr (assq :session
                                       (org-babel-merge-params
                                        common
                                        (org-babel-parse-header-arguments
                                         (or props "") t))))))
                (when (and value (not (string= value "none")))
                  (throw 'session value)))))))
    session))

(defun ob-julia-vterm-helper-block-session ()
  "Return the source block's explicit session name, or nil.
Ignore inherited header args and a session value of \"none\"."
  (when (ob-julia-vterm-helper-in-julia-src-block-p)
    (let* ((block (org-element-at-point))
           (headers (cons (org-element-property :parameters block)
                          (org-element-property :header block)))
           (params (apply #'org-babel-merge-params
                          (mapcar (lambda (header)
                                    (org-babel-parse-header-arguments header t))
                                  headers)))
           (session (cdr (assq :session params))))
      (and session (not (string= session "none")) session))))

(defun ob-julia-vterm-helper-repl-session ()
  "Return the session name for helper-mode REPL switching."
  (or (ob-julia-vterm-helper-block-session)
      (ob-julia-vterm-helper-header-session
       (and (ob-julia-vterm-helper-in-julia-src-block-p)
            (org-element-property :language (org-element-at-point))))
      (ob-julia-vterm-helper-fellow-session)
      "main"))

(defun ob-julia-vterm-helper-switch-to-repl-buffer (&optional arg)
  "Switch to the helper-mode REPL buffer.
With prefix ARG, prompt for session name."
  (interactive "P")
  (let ((session-name (cond ((null arg) (ob-julia-vterm-helper-repl-session))
                            (t (julia-vterm-ask-session)))))
    (julia-vterm-switch-to (julia-vterm-repl-buffer session-name))))

(defun ob-julia-vterm-helper-send-cd-to-buffer-directory ()
  "Change the helper-selected REPL's working directory to the Org buffer directory."
  (interactive)
  (let ((julia-vterm-fellow-repl-buffer
         (julia-vterm-repl-buffer (ob-julia-vterm-helper-repl-session))))
    (julia-vterm-send-cd-to-buffer-directory)))

(defun ob-julia-vterm-helper-filter-repl-binding (binding)
  "Return BINDING according to helper-mode REPL key scope."
  (and (or ob-julia-vterm-helper-buffer-wide-repl-keys
           (ob-julia-vterm-helper-in-julia-src-block-p))
       binding))

(defun ob-julia-vterm-helper-repl-conditional-binding (command)
  "Return a conditional key binding for REPL-related helper COMMAND."
  (list 'menu-item "Julia REPL command" command
        :filter #'ob-julia-vterm-helper-filter-repl-binding))

(defun ob-julia-vterm-helper-filter-julia-body-binding (binding)
  "Return BINDING only inside a Julia source block body."
  (and (ob-julia-vterm-helper-in-julia-src-block-p t) binding))

(defun ob-julia-vterm-helper-body-conditional-binding (command)
  "Return a Julia-source-block-body-only key binding for COMMAND."
  (list 'menu-item "Julia source body command" command
        :filter #'ob-julia-vterm-helper-filter-julia-body-binding))

(defun ob-julia-vterm-helper-handle-tab ()
  "Perform latex substitution or indentation in a Julia source block."
  (interactive)
  (when (ob-julia-vterm-helper-in-julia-src-block-p t)
    (save-restriction
      (org-narrow-to-block)
      (call-interactively #'julia-latexsub-or-indent))
    t))

(defun ob-julia-vterm-helper-handle-return ()
  "Run RET as if typing in the Julia source edit buffer."
  (interactive)
  (org-babel-do-key-sequence-in-edit-buffer (kbd "RET")))

(defun ob-julia-vterm-helper-handle-star (n)
  "Insert N literal * characters using `self-insert-command'."
  (interactive "p")
  (self-insert-command n))

(put 'ob-julia-vterm-helper-handle-star 'delete-selection t)
(put 'ob-julia-vterm-helper-handle-star 'flyspell-delayed t)
(put 'ob-julia-vterm-helper-handle-star 'pabbrev-expand-after-command t)

(defvar ob-julia-vterm-helper-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-c C-z")
                (ob-julia-vterm-helper-repl-conditional-binding
                 #'ob-julia-vterm-helper-switch-to-repl-buffer))
    (define-key map (kbd "C-c C-d")
                (ob-julia-vterm-helper-repl-conditional-binding
                 #'ob-julia-vterm-helper-send-cd-to-buffer-directory))
    (define-key map (kbd "C-<return>")
                (ob-julia-vterm-helper-body-conditional-binding
                 #'ob-julia-vterm-send-region-or-current-line))
    (define-key map (kbd "RET")
                (ob-julia-vterm-helper-body-conditional-binding
                 #'ob-julia-vterm-helper-handle-return))
    (define-key map (kbd "*")
                (ob-julia-vterm-helper-body-conditional-binding
                 #'ob-julia-vterm-helper-handle-star))
    map))

;;;###autoload
(define-minor-mode ob-julia-vterm-helper-mode
  "A minor mode for Org buffer with julia-vterm source code blocks."
  :init-value nil
  :lighter " ⁂"
  :keymap ob-julia-vterm-helper-mode-map
  (unless (eq major-mode 'org-mode)
    (user-error "Cannot use `ob-julia-vterm-helper-mode' outside Org mode"))
  (if ob-julia-vterm-helper-mode
      (add-hook 'org-tab-first-hook #'ob-julia-vterm-helper-handle-tab 0 t)
    (remove-hook 'org-tab-first-hook #'ob-julia-vterm-helper-handle-tab t)))

(unless (fboundp 'julia-helper-mode)
  (defalias 'julia-helper-mode 'ob-julia-vterm-helper-mode))


(provide 'ob-julia-vterm)

;;; ob-julia-vterm.el ends here
