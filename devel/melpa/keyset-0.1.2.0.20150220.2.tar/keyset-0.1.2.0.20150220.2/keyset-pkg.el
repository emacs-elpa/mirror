;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keyset" "0.1.2.0.20150220.2"
  "A small library for structuring key bindings."
  '((dash   "2.8.0")
    (cl-lib "0.5"))
  :url "https://github.com/HKey/keyset"
  :commit "c6b375fbe8035fde593d1d96895eb6e3f111d379"
  :revdesc "c6b375fbe803"
  :authors '(("Hiroki YAMAKAWA" . "s06139@gmail.com"))
  :maintainers '(("Hiroki YAMAKAWA" . "s06139@gmail.com")))
