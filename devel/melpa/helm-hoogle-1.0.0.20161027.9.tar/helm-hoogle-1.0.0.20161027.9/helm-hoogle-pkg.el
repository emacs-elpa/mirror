;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-hoogle" "1.0.0.20161027.9"
  "Use helm to navigate query results from Hoogle."
  '((helm  "1.6.2")
    (emacs "24.4"))
  :url "https://github.com/jwiegley/haskell-config"
  :commit "73969a9d46d2121a849a01a9f7ed3636d01f7bbc"
  :revdesc "73969a9d46d2"
  :keywords '("haskell" "programming" "hoogle")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("John Wiegley" . "jwiegley@gmail.com")))
