;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.74.3.0.20260822.3"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d7e152ca13cac10334aa41344314e97d89d592b7"
  :revdesc "d7e152ca13ca")
