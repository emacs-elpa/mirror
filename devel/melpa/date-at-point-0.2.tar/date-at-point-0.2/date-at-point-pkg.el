;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "date-at-point" "0.2"
  "Add `date' to `thing-at-point' function."
  ()
  :url "https://github.com/alezost/date-at-point.el"
  :commit "b7042938e131f23ceec6ae44fe1b3745c9af05b7"
  :revdesc "b7042938e131"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
