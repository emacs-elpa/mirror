;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "0.1.0.0.20260618.108"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "58c6673d4740d98dcd1445c01c6930208341bc2c"
  :revdesc "58c6673d4740"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
