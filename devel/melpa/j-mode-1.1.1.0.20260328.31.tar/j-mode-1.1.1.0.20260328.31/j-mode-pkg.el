;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "j-mode" "1.1.1.0.20260328.31"
  "Major mode for editing J programs."
  ()
  :url "https://github.com/zellio/j-mode"
  :commit "e49ef0692d73b320c281e40d9fa96b2c17073695"
  :revdesc "v1.1.1-31-ge49ef0692d73"
  :keywords '("j" "languages")
  :authors '(("Zachary Elliott" . "ZacharyElliott1@gmail.com"))
  :maintainers '(("Zachary Elliott" . "ZacharyElliott1@gmail.com")))
