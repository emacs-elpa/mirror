;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ptemplate-templates" "0.1.1.0.20210324.14"
  "Official templates."
  '((emacs     "25.1")
    (ptemplate "2.0.0"))
  :url "https://github.com/nbfalcon/ptemplate-templates"
  :commit "3788387973dde3101f9a3f2064572be033c59ad6"
  :revdesc "3788387973dd"
  :authors '(("Nikita Bloshchanevich" . "nikblos@outlook.com"))
  :maintainers '(("Nikita Bloshchanevich" . "nikblos@outlook.com")))
