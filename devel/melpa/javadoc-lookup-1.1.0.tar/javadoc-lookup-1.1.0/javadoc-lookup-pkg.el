;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "javadoc-lookup" "1.1.0"
  "Javadoc Emacs integration with Maven."
  '((cl-lib "0.3"))
  :url "https://github.com/skeeto/javadoc-lookup"
  :commit "507a2dd443d60b537b8f779c1847e2cd0ccd1382"
  :revdesc "1.1.0-0-g507a2dd443d6"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
