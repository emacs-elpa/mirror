;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mermaid-mode" "1.0.0.20260607.51"
  "Major mode for working with mermaid graphs."
  '((emacs "25.3"))
  :url "https://github.com/abrochard/mermaid-mode"
  :commit "804dbcb1452e7496ae0c48e20362da6351227246"
  :revdesc "804dbcb1452e"
  :keywords '("mermaid" "graphs" "tools" "processes"))
