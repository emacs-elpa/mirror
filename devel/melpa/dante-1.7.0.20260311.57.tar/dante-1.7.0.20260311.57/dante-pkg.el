;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dante" "1.7.0.20260311.57"
  "Development mode for Haskell."
  '((dash     "2.12.0")
    (emacs    "27.1")
    (f        "0.19.0")
    (flycheck "0.30")
    (company  "0.9")
    (flymake  "1.0")
    (s        "1.11.0")
    (lcr      "1.5"))
  :url "https://github.com/jyp/dante"
  :commit "eed4b8147a1395a3b674577f032321d391cbf19e"
  :revdesc "eed4b8147a13"
  :keywords '("haskell" "tools")
  :authors '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com"))
  :maintainers '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com")))
