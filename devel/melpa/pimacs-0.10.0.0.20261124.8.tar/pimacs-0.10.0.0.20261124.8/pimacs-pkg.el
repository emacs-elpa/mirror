;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.10.0.0.20261124.8"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "3097662168094c8d7cb63b0dccd19d879b63d56c"
  :revdesc "309766216809"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
