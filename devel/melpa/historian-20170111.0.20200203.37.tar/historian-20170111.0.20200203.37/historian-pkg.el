;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "historian" "20170111.0.20200203.37"
  "Persistently store selected minibuffer candidates."
  '((emacs "24.4"))
  :url "https://github.com/PythonNut/historian.el"
  :commit "ac1bea7d99dd6965c72fabeb72d5fdc38c5380a4"
  :revdesc "ac1bea7d99dd"
  :keywords '("convenience")
  :authors '(("PythonNut" . "pythonnut@pythonnut.com"))
  :maintainers '(("PythonNut" . "pythonnut@pythonnut.com")))
