;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-aspell" "0.1.0.0.20260105.79"
  "Aspell checker for flymake."
  '((emacs "26.1"))
  :url "https://github.com/leotaku/flycheck-aspell"
  :commit "abbac0f6ccd94224f19c70d8545fddfe9c27351f"
  :revdesc "abbac0f6ccd9"
  :keywords '("wp" "flymake" "spell" "aspell")
  :authors '(("Leo Gaskin" . "leo.gaskin@le0.gs"))
  :maintainers '(("Leo Gaskin" . "leo.gaskin@le0.gs")))
