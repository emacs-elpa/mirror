;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-ts-mode" "0.1.5.0.20260423.5"
  "Major mode for Nix expressions, powered by tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nix-community/nix-ts-mode"
  :commit "50916188784786ed201a8edc70a5264eefb525e3"
  :revdesc "509161887847"
  :keywords '("nix" "languages" "tree-sitter")
  :maintainers '(("Remi Gelinas" . "mail@remigelin.as")))
