;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "0.1.0.20261125.57"
  "Advent of Code mode."
  '((emacs "29.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "45d10da83793df1828645846cb1d84a26a71c8ae"
  :revdesc "45d10da83793"
  :keywords '("tools")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
