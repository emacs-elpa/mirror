;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-tex-ts" "0.1.0.0.20251229.25"
  "Tree-sitter based LaTeX text objects for Evil."
  '((emacs "29.1")
    (evil  "1.0"))
  :url "https://github.com/Prgebish/evil-tex-ts"
  :commit "abeb89a410a2f2e2db0a6e632f11a44de7313f09"
  :revdesc "abeb89a410a2"
  :keywords '("tex" "emulation" "vi" "evil" "wp"))
