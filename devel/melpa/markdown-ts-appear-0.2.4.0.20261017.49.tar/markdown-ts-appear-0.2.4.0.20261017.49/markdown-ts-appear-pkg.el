;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-ts-appear" "0.2.4.0.20261017.49"
  "Reveal Markdown source at point."
  '((emacs               "31.1")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/Thysrael/markdown-ts-appear"
  :commit "a11f6e9e5da51da8655a0e1339e1ccd11ae71300"
  :revdesc "v0.2.4-49-ga11f6e9e5da5"
  :keywords '("text" "convenience")
  :authors '(("Thysrael" . "thysrael@163.com"))
  :maintainers '(("Thysrael" . "thysrael@163.com")))
