;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "make-it-so" "0.1.0.0.20190625.92"
  "Transform files with Makefile recipes."
  '((swiper "0.8.0")
    (emacs  "24"))
  :url "https://github.com/abo-abo/make-it-so"
  :commit "b73dfb640588123c9eece230ad72b37604f5c126"
  :revdesc "b73dfb640588"
  :keywords '("make" "dired")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
