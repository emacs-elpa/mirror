;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gitlab-ci-mode-flycheck" "20180605.1.0.20190323.1"
  "Flycheck support for ‘gitlab-ci-mode’."
  '((emacs          "25")
    (flycheck       "31")
    (gitlab-ci-mode "1"))
  :url "https://gitlab.com/joewreschnig/gitlab-ci-mode-flycheck/"
  :commit "eba81cfb7224fd1fa4e4da90d11729cc7ea12f72"
  :revdesc "eba81cfb7224"
  :keywords '("tools" "vc" "convenience"))
