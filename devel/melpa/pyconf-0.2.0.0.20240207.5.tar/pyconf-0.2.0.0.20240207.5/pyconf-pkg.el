;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyconf" "0.2.0.0.20240207.5"
  "Set up python execution configurations like dap-mode ones."
  '((pyvenv     "1.21")
    (emacs      "28.1")
    (transient  "0.3.7")
    (pyenv-mode "0.1.0"))
  :url "https://github.com/andcarnivorous/pyconf"
  :commit "f1587f20463496193625526ba805c3cf084db966"
  :revdesc "f1587f204634"
  :keywords '("processes" "python")
  :authors '(("Andrew Favia" . "drewlinguistics01atgmaildotcom"))
  :maintainers '(("Andrew Favia" . "drewlinguistics01atgmaildotcom")))
