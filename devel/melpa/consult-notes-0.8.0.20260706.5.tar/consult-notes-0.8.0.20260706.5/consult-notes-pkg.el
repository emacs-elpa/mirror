;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-notes" "0.8.0.20260706.5"
  "Manage notes with consult."
  '((emacs   "28.1")
    (consult "1.0")
    (s       "1.12.0")
    (dash    "2.19"))
  :url "https://github.com/mclear-tools/consult-notes"
  :commit "1e095562c5d8245e9f85c043cbaa9aa4dc0b9ded"
  :revdesc "1e095562c5d8"
  :keywords '("convenience")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
