;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marcopolo" "0.3.0.0.20160421.5"
  "Emacs client to the Docker HUB/Registry API."
  '((s        "1.9.0")
    (dash     "2.9.0")
    (pkg-info "0.5.0")
    (request  "0.1.0"))
  :url "https://github.com/nlamirault/marcopolo"
  :commit "85db828f2bb4346a811b3326349b1c6d0aae4601"
  :revdesc "0.3.0-5-g85db828f2bb4"
  :keywords '("docker")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
