;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-escape" "0.2.1"
  "Improve readability of escape characters in regular expressions."
  ()
  :url "https://github.com/cpitclaudel/easy-escape"
  :commit "938497a21e65ba6b3ff8ec90e93a6d0ab18dc9b4"
  :revdesc "938497a21e65"
  :keywords '("convenience" "lisp" "tools")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
