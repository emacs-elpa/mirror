;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "4.5.0.20261106.369"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "80af5c9829168f2229262b63f42cdd12b6797506"
  :revdesc "v4.5-369-g80af5c982916"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
