;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arch-packer" "0.3.0.20170730.1"
  "Arch Linux package management frontend."
  '((emacs "25.1")
    (s     "1.11.0")
    (async "1.9.2")
    (dash  "2.12.0"))
  :url "https://github.com/brotzeitmacher/arch-packer"
  :commit "940e96f7d357c6570b675a0f942181c787f1bfd7"
  :revdesc "940e96f7d357"
  :authors '(("Fritz Stelzer" . "brotzeitmacher@gmail.com"))
  :maintainers '(("Fritz Stelzer" . "brotzeitmacher@gmail.com")))
