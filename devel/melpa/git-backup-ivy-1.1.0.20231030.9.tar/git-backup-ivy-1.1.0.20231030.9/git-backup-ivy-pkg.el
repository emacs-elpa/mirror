;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-backup-ivy" "1.1.0.20231030.9"
  "An ivy interface to git-backup."
  '((ivy        "0.12.0")
    (git-backup "0.0.1")
    (emacs      "25.1"))
  :url "https://github.com/walseb/git-backup-ivy"
  :commit "8c825ac2fef586e2792e980003e5ae0deb908bbc"
  :revdesc "8c825ac2fef5"
  :keywords '("backup" "convenience" "files" "tools" "vc")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
