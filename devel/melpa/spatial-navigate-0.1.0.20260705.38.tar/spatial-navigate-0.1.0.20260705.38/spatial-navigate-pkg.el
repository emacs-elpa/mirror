;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spatial-navigate" "0.1.0.20260705.38"
  "Directional navigation between blank-space blocks."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spatial-navigate"
  :commit "358337ddaef449ad0f1c6b9ab29f99db363ab319"
  :revdesc "358337ddaef4"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
