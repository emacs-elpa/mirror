;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-crypt" "2.1.0.20251128.4"
  "Symmetric Encryption for ERC."
  '((cl-lib "0.5"))
  :url "https://github.com/atomontage/erc-crypt"
  :commit "fc7eb4896310cc274ab7d035a1daf6a2a608a1e1"
  :revdesc "fc7eb4896310"
  :keywords '("comm")
  :authors '(("xristos" . "xristos@sdf.org"))
  :maintainers '(("xristos" . "xristos@sdf.org")))
