;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "name-this-color" "0.3.0"
  "Match RGB codes to names easily and precisely."
  '((emacs  "24")
    (cl-lib "0.5")
    (dash   "2.11.0"))
  :url "https://github.com/knl/name-this-color.el"
  :commit "e37cd1291d5d68d4c8d6386eab9cb9d94fd3bcfa"
  :revdesc "0.3.0-0-ge37cd1291d5d"
  :keywords '("lisp" "color" "hex" "rgb" "shade" "name")
  :authors '(("Nikola Knezevic" . "knl@soba143.net"))
  :maintainers '(("Nikola Knezevic" . "knl@soba143.net")))
