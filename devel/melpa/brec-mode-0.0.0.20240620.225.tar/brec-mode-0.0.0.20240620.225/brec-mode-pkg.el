;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brec-mode" "0.0.0.20240620.225"
  "A major mode for editing Breccian text."
  '((emacs "24.3"))
  :url "http://reluk.ca/project/Breccia/Emacs/"
  :commit "942e042cc22224ec3940d0867c8c08f71e036924"
  :revdesc "942e042cc222"
  :keywords '("outlines" "wp")
  :authors '(("Michael Allan" . "mike@reluk.ca"))
  :maintainers '(("Michael Allan" . "mike@reluk.ca")))
