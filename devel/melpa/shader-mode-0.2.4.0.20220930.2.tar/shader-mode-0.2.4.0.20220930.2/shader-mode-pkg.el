;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shader-mode" "0.2.4.0.20220930.2"
  "Major mode for shader."
  '((emacs "24"))
  :url "https://github.com/midnightSuyama/shader-mode"
  :commit "fe5a1982ba69e4a98b834141a46a1908f132df15"
  :revdesc "fe5a1982ba69"
  :authors '(("midnightSuyama" . "midnightSuyama@gmail.com"))
  :maintainers '(("midnightSuyama" . "midnightSuyama@gmail.com")))
