;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-indent-rigidly" "20140801.1051"
  "Smart rigid indenting."
  ()
  :url "https://github.com/re5et/smart-indent-rigidly"
  :commit "323d1fe4d0b81e598249aad01bc44adb180ece0e"
  :revdesc "323d1fe4d0b8"
  :keywords '("indenting" "coffee-mode" "haml-mode" "sass-mode"))
