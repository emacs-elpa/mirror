;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "webdriver" "0.1.0.20250224.64"
  "WebDriver local end implementation."
  '((emacs "27.1"))
  :url "https://gitlab.com/mauroaranda/emacs-webdriver"
  :commit "dfe26adc9482d50c7c6ca765916443bd74cf548d"
  :revdesc "dfe26adc9482"
  :keywords '("tools")
  :authors '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers '(("Mauro Aranda" . "maurooaranda@gmail.com")))
