;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-haskell" "0.8.0.20260319.119"
  "Flycheck: Automatic Haskell configuration."
  '((emacs        "24.3")
    (flycheck     "0.25")
    (haskell-mode "13.7")
    (dash         "2.4.0")
    (seq          "1.11")
    (let-alist    "1.0.1"))
  :url "https://github.com/flycheck/flycheck-haskell"
  :commit "dca624b528978ca47b387d34d9aca8b6a42bc011"
  :revdesc "0.8-119-gdca624b52897"
  :keywords '("tools" "convenience")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
