;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "1.0.7.0.20261028.2"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "560f31b3f45fb4ee65a69e1e96a9771faef4b922"
  :revdesc "1.0.7-2-g560f31b3f45f"
  :keywords '("convenience" "lisp"))
