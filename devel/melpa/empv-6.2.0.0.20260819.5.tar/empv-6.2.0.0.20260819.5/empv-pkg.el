;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "6.2.0.0.20260819.5"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "a1c76aa8d29b8759fe9363e83043c7571deaaea4"
  :revdesc "v6.2.0-5-ga1c76aa8d29b"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
