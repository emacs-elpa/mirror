;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.99.3.0.20261124.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.3")
    (acp         "0.20.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "55b9bf9c32f471262233943c61628bc560742c54"
  :revdesc "55b9bf9c32f4")
