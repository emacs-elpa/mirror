;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "impostman" "0.2.0.0.20250412.20"
  "Import Postman collections."
  '((emacs "27.1"))
  :url "https://github.com/flashcode/impostman"
  :commit "c1e764b16d32930d157e5bf2d2e6ac4dc3a23b8c"
  :revdesc "v0.2.0-20-gc1e764b16d32"
  :keywords '("tools")
  :authors '(("Sébastien Helleu" . "flashcode@flashtux.org"))
  :maintainers '(("Sébastien Helleu" . "flashcode@flashtux.org")))
