;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-prog-extra" "0.2.0.20260809.32"
  "Customizable highlighting for source-code."
  '((emacs "27.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra"
  :commit "72c35715942ebf2b6d6ff2a7122bbc36b16992f2"
  :revdesc "72c35715942e"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
