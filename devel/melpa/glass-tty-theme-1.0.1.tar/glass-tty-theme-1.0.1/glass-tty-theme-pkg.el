;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "glass-tty-theme" "1.0.1"
  "Reverse video-like theme for the Glass TTY VT220 font."
  '((emacs "24.1"))
  :url "https://github.com/irtnog/glass-tty-theme"
  :commit "59126e888d9a237c6a0461e3712665d543f1320d"
  :revdesc "59126e888d9a"
  :authors '(("Matthew X. Economou" . "xenophon+glass-tty-theme@irtnog.org"))
  :maintainers '(("Matthew X. Economou" . "xenophon+glass-tty-theme@irtnog.org")))
