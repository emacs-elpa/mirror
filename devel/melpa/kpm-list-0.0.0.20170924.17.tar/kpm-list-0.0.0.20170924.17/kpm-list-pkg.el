;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kpm-list" "0.0.0.20170924.17"
  "An emacs buffer list that tries to intelligently group together buffers."
  ()
  :url "https://github.com/KMahoney/kpm-list/"
  :commit "e0f5112e5ce8ec1b603f4428fa51681c68bb28f5"
  :revdesc "e0f5112e5ce8")
