;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "biome" "0.1.0.0.20260607.85"
  "Bountiful Interface to Open Meteo for Emacs."
  '((emacs     "27.1")
    (transient "0.9.2")
    (ct        "0.2")
    (request   "0.3.3")
    (compat    "29.1.4.1"))
  :url "https://github.com/SqrtMinusOne/biome"
  :commit "77a94f3c5210b80b63d5002c4780e542cd98a65f"
  :revdesc "77a94f3c5210"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
