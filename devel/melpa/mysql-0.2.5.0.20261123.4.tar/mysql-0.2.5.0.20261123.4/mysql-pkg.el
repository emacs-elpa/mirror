;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "0.2.5.0.20261123.4"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "fcd9b6e2ecb905fa2bdea7d02db43235cc5ecbfe"
  :revdesc "fcd9b6e2ecb9"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
