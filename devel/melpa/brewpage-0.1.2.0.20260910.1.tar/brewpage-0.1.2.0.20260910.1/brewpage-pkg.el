;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brewpage" "0.1.2.0.20260910.1"
  "Publish buffers/regions to brewpage.app."
  '((emacs "27.1"))
  :url "https://github.com/kochetkov-ma/brewpage-emacs"
  :commit "cc096fe8cefd39fde35189910467b018eddf6b25"
  :revdesc "0.1.2-1-gcc096fe8cefd"
  :keywords '("tools" "convenience")
  :authors '(("Maksim Kochetkov" . "apmatypa88@gmail.com"))
  :maintainers '(("Maksim Kochetkov" . "apmatypa88@gmail.com")))
