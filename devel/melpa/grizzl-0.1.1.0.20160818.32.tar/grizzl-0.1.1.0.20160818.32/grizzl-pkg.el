;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grizzl" "0.1.1.0.20160818.32"
  "Fast fuzzy search index for Emacs."
  '((cl-lib "0.5")
    (emacs  "24.3"))
  :url "https://github.com/grizzl/grizzl"
  :commit "d554d93afa8519ee3a41340ec8aa6b4555065446"
  :revdesc "v0.1.1-32-gd554d93afa85"
  :keywords '("convenience" "usability")
  :authors '(("Chris Corbyn" . "chris@w3style.co.uk"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
