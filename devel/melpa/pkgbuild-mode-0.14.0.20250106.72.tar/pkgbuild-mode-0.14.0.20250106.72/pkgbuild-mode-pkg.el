;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pkgbuild-mode" "0.14.0.20250106.72"
  "Interface to the Arch Linux package manager."
  '((emacs "26.1"))
  :url "https://github.com/juergenhoetzel/pkgbuild-mode"
  :commit "aadf3d1d19c5eb9b52c15c5b73b1a46faac5b7d5"
  :revdesc "aadf3d1d19c5"
  :keywords '("languages")
  :authors '(("Juergen Hoetzel" . "juergen@hoetzel.info"))
  :maintainers '(("Juergen Hoetzel" . "juergen@hoetzel.info")))
