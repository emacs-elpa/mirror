;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "librera-sync" "0.2.0.0.20230902.3"
  "Sync document's position with Librera Reader for Android."
  '((emacs "26.1")
    (f     "0.17")
    (dash  "2.12.0"))
  :url "https://github.com/jumper047/librera-sync"
  :commit "19cf9496d71daac67ce4b0ebcdf7f6ac2c3e689a"
  :revdesc "19cf9496d71d"
  :keywords '("multimedia" "sync")
  :authors '(("Dmitriy Pshonko" . "jumper047@gmail.com"))
  :maintainers '(("Dmitriy Pshonko" . "jumper047@gmail.com")))
