;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dracula-theme" "1.8.3.0.20260907.15"
  "Dracula Theme."
  '((emacs "24.3"))
  :url "https://github.com/dracula/emacs"
  :commit "73ff45fdd8e1de784156b77d124e99cdbbc39104"
  :revdesc "v1.8.3-15-g73ff45fdd8e1"
  :maintainers '(("tienne Deparis" . "etienne@depar.is")))
