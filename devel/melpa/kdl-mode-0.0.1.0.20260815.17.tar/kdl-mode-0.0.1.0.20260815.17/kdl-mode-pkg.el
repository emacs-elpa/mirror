;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kdl-mode" "0.0.1.0.20260815.17"
  "Major mode for editing KDL files."
  '((emacs "29.1"))
  :url "https://github.com/taquangtrung/emacs-kdl-mode"
  :commit "9ddca206e5fba05fc1a16e5dddb1fa375911550e"
  :revdesc "9ddca206e5fb"
  :keywords '("languages"))
