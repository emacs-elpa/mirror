;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speech-tagger" "0.0.0.0.20170728.48"
  "Tag parts of speech using coreNLP."
  '((cl-lib "0.5"))
  :url "https://github.com/cosmicexplorer/speech-tagger"
  :commit "61955b40d4e8b09e66a3e8033e82893f81657c06"
  :revdesc "61955b40d4e8"
  :keywords '("speech" "tag" "nlp" "language" "corenlp" "parsing" "natural")
  :authors '(("Danny McClanahan" . "danieldmcclanahan@gmail.com"))
  :maintainers '(("Danny McClanahan" . "danieldmcclanahan@gmail.com")))
