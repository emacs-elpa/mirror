;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seethru" "0.3.0.20150218.2"
  "Easily change Emacs' transparency."
  '((shadchen "1.4"))
  :url "https://github.com/benaiah/seethru"
  :commit "d87e231f99313bea75b1e69e48c0f32968c82060"
  :revdesc "d87e231f9931"
  :keywords '("lisp" "tools" "alpha" "transparency")
  :authors '(("Benaiah Mischenko" . "benaiah@mischenko.com"))
  :maintainers '(("Benaiah Mischenko" . "benaiah@mischenko.com")))
