;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zoxide" "1.2.3.0.20241003.1"
  "Find file by zoxide."
  '((emacs "25.1"))
  :url "https://gitlab.com/Vonfry/zoxide.el"
  :commit "6de851de46db51253350edd67f329dbc0587b97c"
  :revdesc "1.2.3-1-g6de851de46db"
  :keywords '("converience" "matching")
  :authors '(("Ruoyu Feng" . "emacs@vonfry.name"))
  :maintainers '(("Ruoyu Feng" . "emacs@vonfry.name")))
