;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "list-environment" "0.1.0.20210930.11"
  "A tabulated process environment editor."
  ()
  :url "https://github.com/dgtized/list-environment.el"
  :commit "0a72a5a9c1abc090b25202a0387e3f766994b053"
  :revdesc "0a72a5a9c1ab"
  :keywords '("processes" "unix")
  :authors '(("Charles L.G. Comstock" . "dgtized@gmail.com"))
  :maintainers '(("Charles L.G. Comstock" . "dgtized@gmail.com")))
