;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-quickdef" "1.0.0"
  "Quickly define a new Flymake backend."
  '((emacs "26.1"))
  :url "https://github.com/karlotness/flymake-quickdef"
  :commit "150c5839768a3d32f988f9dc08052978a68f2ad7"
  :revdesc "150c5839768a"
  :keywords '("languages" "tools" "convenience" "lisp"))
