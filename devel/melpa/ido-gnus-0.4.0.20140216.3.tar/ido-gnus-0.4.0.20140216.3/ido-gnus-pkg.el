;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-gnus" "0.4.0.20140216.3"
  "Access gnus groups or servers using ido."
  '((gnus "5.13"))
  :url "https://github.com/vapniks/ido-gnus"
  :commit "f5fe3f6aa8086f675ba216abace9e3d5f2e3a089"
  :revdesc "f5fe3f6aa808"
  :keywords '("comm")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
