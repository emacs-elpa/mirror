;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "2.0.0.20261124.14"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "0d346752515c92b53d879b178dadd6365581d69e"
  :revdesc "0d346752515c"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
