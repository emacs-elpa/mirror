;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minimal-dashboard" "0.1.4.0.20261104.2"
  "A very minimal dashboard plugin."
  '((emacs "27.1"))
  :url "https://github.com/dheerajshenoy/minimal-dashboard.el"
  :commit "4d3e150da29073f7ad81fc9de4ad253c159aae8e"
  :revdesc "4d3e150da290"
  :keywords '("startup" "screen" "tools" "dashboard")
  :authors '(("Dheeraj Vittal Shenoy" . "dheerajshenoy22@gmail.com"))
  :maintainers '(("Dheeraj Vittal Shenoy" . "dheerajshenoy22@gmail.com")))
