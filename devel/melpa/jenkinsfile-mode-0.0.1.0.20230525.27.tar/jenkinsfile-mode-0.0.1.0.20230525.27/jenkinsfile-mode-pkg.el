;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jenkinsfile-mode" "0.0.1.0.20230525.27"
  "Major mode for editing Jenkins declarative pipeline syntax."
  '((emacs       "24")
    (groovy-mode "2.0"))
  :url "https://github.com/john2x/jenkinsfile-mode"
  :commit "568865ee419e0592de0dd0717d6769a66d9df111"
  :revdesc "568865ee419e")
