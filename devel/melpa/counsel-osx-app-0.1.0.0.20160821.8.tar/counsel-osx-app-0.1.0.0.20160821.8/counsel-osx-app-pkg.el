;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-osx-app" "0.1.0.0.20160821.8"
  "Launch osx applications via ivy interface."
  '((ivy   "0.8.0")
    (emacs "24.3"))
  :url "https://github.com/d12frosted/counsel-osx-app"
  :commit "5cc93ec684f837dc31ce20e7625407f2c0445691"
  :revdesc "5cc93ec684f8"
  :authors '(("Boris Buliga" . "d12frosted@gmail.com"))
  :maintainers '(("Boris Buliga" . "d12frosted@gmail.com")))
