;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elmacro" "1.1.1.0.20260922.5"
  "Convert keyboard macros to emacs lisp."
  '((s    "1.11.0")
    (dash "2.13.0"))
  :url "https://github.com/Silex/elmacro"
  :commit "c1966740ad94f2232581d622d09f8d4cfaecd016"
  :revdesc "1.1.1-5-gc1966740ad94"
  :keywords '("macro" "elisp" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
