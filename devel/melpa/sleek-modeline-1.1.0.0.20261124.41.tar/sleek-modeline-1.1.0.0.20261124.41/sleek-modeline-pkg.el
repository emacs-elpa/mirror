;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sleek-modeline" "1.1.0.0.20261124.41"
  "Minimal and elegant modeline."
  '((emacs "30.1"))
  :url "https://github.com/abidanBrito/sleek-modeline"
  :commit "56429fb2a8116de3df2bfb978187422d8d94ce48"
  :revdesc "v1.1.0-41-g56429fb2a811"
  :keywords '("mode-line" "faces")
  :authors '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com"))
  :maintainers '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com")))
