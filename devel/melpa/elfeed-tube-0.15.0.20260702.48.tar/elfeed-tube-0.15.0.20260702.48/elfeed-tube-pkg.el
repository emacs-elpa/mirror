;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-tube" "0.15.0.20260702.48"
  "YouTube integration for Elfeed."
  '((emacs  "27.1")
    (elfeed "3.4.2")
    (aio    "1.0"))
  :url "https://github.com/karthink/elfeed-tube"
  :commit "f653d5b7f27a2eace217d9e6b4f40e0e35ae88cd"
  :revdesc "f653d5b7f27a"
  :keywords '("news" "hypermedia" "convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
