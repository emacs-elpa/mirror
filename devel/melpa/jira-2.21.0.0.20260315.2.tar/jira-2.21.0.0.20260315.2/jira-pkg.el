;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "2.21.0.0.20260315.2"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "1b1a43600ca138f3f8e56481bea6f629a4d877ec"
  :revdesc "1b1a43600ca1"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
