;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linguistic" "0.2.0.20181129.11"
  "A package for basic linguistic analysis."
  ()
  :url "https://github.com/andcarnivorous/linguistic"
  :commit "23e47e98cdb09ee61883669b6d8a11bf6449862c"
  :revdesc "23e47e98cdb0"
  :keywords '("linguistics" "text analysis" "matching")
  :authors '(("Andrew Favia" . "drewlinguistics01atgmaildotcom"))
  :maintainers '(("Andrew Favia" . "drewlinguistics01atgmaildotcom")))
