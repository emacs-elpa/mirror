;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaleidoscope-evil-state-flash" "0.1.0.0.20170728.9"
  "Flash keyboard LEDs when changing Evil state."
  '((evil         "1.2.12")
    (kaleidoscope "0.1.0")
    (s            "1.11.0"))
  :url "https://github.com/algernon/kaleidoscope.el"
  :commit "5b88327350c3d6375ef1d43fb31342eaabd88fdc"
  :revdesc "5b88327350c3")
