;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.8.0.0.20261118.2"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "c39673fff83c17ab5754e3f0dbfdf6d7fc7a7181"
  :revdesc "c39673fff83c"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
