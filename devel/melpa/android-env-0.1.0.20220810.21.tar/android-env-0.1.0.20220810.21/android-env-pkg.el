;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "android-env" "0.1.0.20220810.21"
  "Helper functions for working in android."
  '((emacs "24.3")
    (s     "1.12.0"))
  :url "https://github.com/fernando-jascovich/android-env.el"
  :commit "d2890f1156ed184314adbfcf01cdceb6ea79b10d"
  :revdesc "d2890f1156ed"
  :keywords '("android" "gradle" "java" "tools" "convenience"))
