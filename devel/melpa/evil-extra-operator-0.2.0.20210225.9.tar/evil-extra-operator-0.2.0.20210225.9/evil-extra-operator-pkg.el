;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-extra-operator" "0.2.0.20210225.9"
  "Evil operator for evaluating codes, taking notes, searching via google, etc."
  '((evil "1.0.7"))
  :url "https://github.com/Dewdrops/evil-extra-operator"
  :commit "49c2dae224705f05dcfa03868b9fbbb72f2b5a8d"
  :revdesc "49c2dae22470"
  :keywords '("evil" "plugin")
  :authors '(("Dewdrops" . "v_v_4474@126.com"))
  :maintainers '(("Dewdrops" . "v_v_4474@126.com")))
