;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-chord" "0.8.2"
  "Map pairs of simultaneously pressed keys to commands."
  '((emacs "24"))
  :url "https://github.com/LemonBreezes/key-chord"
  :commit "cb646e815c61f253ad9fdfbe058049dda4e2b32b"
  :revdesc "v0.8.2-0-gcb646e815c61"
  :keywords '("keyboard" "chord" "input")
  :authors '(("David Andersson" . "l.david.anderssonsverige.nu"))
  :maintainers '(("LemonBreezes" . "look@strawberrytea.xyz")))
