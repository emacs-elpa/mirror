;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "countdown-modeline" "1.4.0"
  "Display a color-coded countdown in the modeline."
  '((emacs "27.1"))
  :url "https://github.com/jholland82/countdown-modeline"
  :commit "a07cf0b1d0e71cca21255a599a91c28d7e8ed2d8"
  :revdesc "v1.4.0-0-ga07cf0b1d0e7"
  :keywords '("convenience" "modeline")
  :authors '(("Jeffrey Holland" . "jeff.holland@gmail.com"))
  :maintainers '(("Jeffrey Holland" . "jeff.holland@gmail.com")))
