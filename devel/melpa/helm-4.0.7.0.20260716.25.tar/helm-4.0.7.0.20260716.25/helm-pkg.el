;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "4.0.7.0.20260716.25"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "0046ed9ab32d6fa3e60865e84b27cf62fe386b67"
  :revdesc "v4.0.7-25-g0046ed9ab32d"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
