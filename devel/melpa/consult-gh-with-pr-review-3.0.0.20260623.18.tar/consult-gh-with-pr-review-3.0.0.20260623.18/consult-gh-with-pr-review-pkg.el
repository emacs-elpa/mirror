;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh-with-pr-review" "3.0.0.20260623.18"
  "\"pr-review\" Integration for consult-gh."
  '((emacs      "29.4")
    (consult    "2.0")
    (pr-review  "0.1")
    (consult-gh "3.0"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "a9e9144fd9d0a689d26818eeb8eb108cd4696718"
  :revdesc "a9e9144fd9d0"
  :keywords '("matching" "git" "repositories" "completion"))
