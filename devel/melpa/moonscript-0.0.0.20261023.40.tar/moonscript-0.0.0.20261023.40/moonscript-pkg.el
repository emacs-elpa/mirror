;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moonscript" "0.0.0.20261023.40"
  "Major mode for editing MoonScript code."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/k2052/moonscript-mode"
  :commit "8c27a902b9319022126e14b5c328599fe46574ff"
  :revdesc "8c27a902b931"
  :keywords '("languages" "moonscript" "lua")
  :authors '((nil . "@GriffinSchneider")
             (nil . "@k2052")
             (nil . "@EmacsFodder")))
