;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occult" "1.4.0"
  "Collapse and reveal buffer regions."
  '((emacs "29.1"))
  :url "https://github.com/agzam/occult.el"
  :commit "11f1430b7abd8da22898c99866521fc2c31cbad5"
  :revdesc "1.4.0-0-g11f1430b7abd"
  :keywords '("convenience")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
