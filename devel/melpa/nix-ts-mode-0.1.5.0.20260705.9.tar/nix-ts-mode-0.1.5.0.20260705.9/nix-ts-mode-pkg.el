;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-ts-mode" "0.1.5.0.20260705.9"
  "Major mode for Nix expressions, powered by tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nix-community/nix-ts-mode"
  :commit "3b69aeb8d2403ea52b60a46fa452965b7b37a50e"
  :revdesc "3b69aeb8d240"
  :keywords '("nix" "languages" "tree-sitter")
  :maintainers '(("Remi Gelinas" . "mail@remigelin.as")))
