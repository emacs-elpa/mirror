;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "0.15.0"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.67.1")
    (latex-to-svg-backend "0.15.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "070a0b586eef602f9e397f3633a000bce882ff67"
  :revdesc "v0.15.0-0-g070a0b586eef"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
