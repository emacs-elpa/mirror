;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwim-shell-command" "0.62.2.0.20261022.44"
  "Shell commands with DWIM behaviour."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/dwim-shell-command"
  :commit "b3b2df5ba4538965e8d7f698dd766096ff3e7c2f"
  :revdesc "b3b2df5ba453")
