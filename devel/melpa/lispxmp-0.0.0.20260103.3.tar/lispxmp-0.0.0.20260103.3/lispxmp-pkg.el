;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lispxmp" "0.0.0.20260103.3"
  "Automagic emacs lisp code annotation."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/download/lispxmp.el"
  :commit "af33c88276706633a0c37dddd672b27867a4b543"
  :revdesc "af33c8827670"
  :keywords '("lisp" "convenience")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
