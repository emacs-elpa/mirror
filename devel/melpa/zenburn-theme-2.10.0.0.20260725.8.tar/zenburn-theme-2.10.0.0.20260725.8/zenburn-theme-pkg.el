;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zenburn-theme" "2.10.0.0.20260725.8"
  "A low contrast color theme for Emacs."
  ()
  :url "https://github.com/bbatsov/zenburn-emacs"
  :commit "3797f3ae26b3649c99fc74a09a0bd6a31b40597f"
  :revdesc "3797f3ae26b3"
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
