;;; zenburn-theme.el --- A low contrast color theme for Emacs.  -*- lexical-binding: t -*-

;; Copyright (C) 2011-2026 Bozhidar Batsov

;; Author: Bozhidar Batsov <bozhidar@batsov.com>
;; URL: https://github.com/bbatsov/zenburn-emacs
;; Package-Version: 2.10.0.0.20260725.8
;; Package-Revision: 3797f3ae26b3

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; A port of the popular Vim theme Zenburn for Emacs 24+, built on top
;; of the new built-in theme support in Emacs 24.

;;; Credits:

;; Jani Nurminen created the original theme for vim on which this port
;; is based.

;;; Code:

(deftheme zenburn "The Zenburn color theme.")

(defgroup zenburn-theme nil
  "Zenburn theme."
  :group 'faces
  :prefix "zenburn-"
  :link '(url-link :tag "GitHub" "http://github.com/bbatsov/zenburn-emacs")
  :tag "Zenburn theme")

;;;###autoload
(defcustom zenburn-override-colors-alist '()
  "Place to override default theme colors.

You can override a subset of the theme's default colors by
defining them in this alist."
  :group 'zenburn-theme
  :type '(alist
          :key-type (string :tag "Name")
          :value-type (string :tag " Hex")))

;;;###autoload
(defcustom zenburn-override-semantic-colors-alist '()
  "Place to override default theme semantic colors.

Semantic colors give meaning-based names (like `zenburn-comment'
or `zenburn-error') to entries in the positional palette.  Values
may be either a hex string or the symbol of a palette entry (for
example, `zenburn-yellow').  See `zenburn-default-semantic-colors-alist'
for the list of semantic names that ship with the theme."
  :group 'zenburn-theme
  :type '(alist
          :key-type (string :tag "Name")
          :value-type (choice (string :tag "Hex")
                              (symbol :tag "Palette name")))
  :package-version '(zenburn . "2.10.0"))

(defcustom zenburn-use-variable-pitch nil
  "When non-nil, use variable pitch face for some headings and titles."
  :type 'boolean
  :safe #'booleanp
  :group 'zenburn-theme
  :package-version '(zenburn . "2.10.0"))

(defcustom zenburn-scale-org-headlines nil
  "Whether `org-mode' headlines should be scaled."
  :type 'boolean
  :safe #'booleanp
  :group 'zenburn-theme
  :package-version '(zenburn . "2.10.0"))

(defcustom zenburn-scale-outline-headlines nil
  "Whether `outline-mode' headlines should be scaled."
  :type 'boolean
  :safe #'booleanp
  :group 'zenburn-theme
  :package-version '(zenburn . "2.10.0"))

(defcustom zenburn-height-plus-1 1.1
  "Font size +1."
  :type 'number
  :group 'zenburn-theme
  :package-version '(zenburn . "2.6"))

(defcustom zenburn-height-plus-2 1.15
  "Font size +2."
  :type 'number
  :group 'zenburn-theme
  :package-version '(zenburn . "2.6"))

(defcustom zenburn-height-plus-3 1.2
  "Font size +3."
  :type 'number
  :group 'zenburn-theme
  :package-version '(zenburn . "2.6"))

(defcustom zenburn-height-plus-4 1.3
  "Font size +4."
  :type 'number
  :group 'zenburn-theme
  :package-version '(zenburn . "2.6"))

(defface zenburn-variable-pitch '((t :inherit default))
  "Face used by Zenburn for headings and titles that should optionally
render in a variable-pitch font.  The theme rebinds this to inherit
from `variable-pitch' when `zenburn-use-variable-pitch' is non-nil.
Customize this face directly if you want finer-grained control than
the boolean toggle provides."
  :group 'zenburn-theme)

;;; Color Palette

(defvar zenburn-default-colors-alist
  '(("zenburn-fg-1"     . "#656555")
    ("zenburn-fg-05"    . "#989890")
    ("zenburn-fg"       . "#DCDCCC")
    ("zenburn-fg+1"     . "#FFFFEF")
    ("zenburn-fg+2"     . "#FFFFFD")
    ("zenburn-bg-2"     . "#000000")
    ("zenburn-bg-1"     . "#2B2B2B")
    ("zenburn-bg-08"    . "#303030")
    ("zenburn-bg-05"    . "#383838")
    ("zenburn-bg"       . "#3F3F3F")
    ("zenburn-bg+05"    . "#494949")
    ("zenburn-bg+1"     . "#4F4F4F")
    ("zenburn-bg+2"     . "#5F5F5F")
    ("zenburn-bg+3"     . "#6F6F6F")
    ("zenburn-red-6"    . "#6C3333")
    ("zenburn-red-5"    . "#7C4343")
    ("zenburn-red-4"    . "#8C5353")
    ("zenburn-red-3"    . "#9C6363")
    ("zenburn-red-2"    . "#AC7373")
    ("zenburn-red-1"    . "#BC8383")
    ("zenburn-red"      . "#CC9393")
    ("zenburn-red+1"    . "#DCA3A3")
    ("zenburn-red+2"    . "#ECB3B3")
    ("zenburn-orange"   . "#DFAF8F")
    ("zenburn-yellow-2" . "#D0BF8F")
    ("zenburn-yellow-1" . "#E0CF9F")
    ("zenburn-yellow"   . "#F0DFAF")
    ("zenburn-green-5"  . "#2F4F2F")
    ("zenburn-green-4"  . "#3F5F3F")
    ("zenburn-green-3"  . "#4F6F4F")
    ("zenburn-green-2"  . "#5F7F5F")
    ("zenburn-green-1"  . "#6F8F6F")
    ("zenburn-green"    . "#7F9F7F")
    ("zenburn-green+1"  . "#8FB28F")
    ("zenburn-green+2"  . "#9FC59F")
    ("zenburn-green+3"  . "#AFD8AF")
    ("zenburn-green+4"  . "#BFEBBF")
    ("zenburn-cyan"     . "#93E0E3")
    ("zenburn-blue+3"   . "#BDE0F3")
    ("zenburn-blue+2"   . "#ACE0E3")
    ("zenburn-blue+1"   . "#94BFF3")
    ("zenburn-blue"     . "#8CD0D3")
    ("zenburn-blue-1"   . "#7CB8BB")
    ("zenburn-blue-2"   . "#6CA0A3")
    ("zenburn-blue-3"   . "#5C888B")
    ("zenburn-blue-4"   . "#4C7073")
    ("zenburn-blue-5"   . "#366060")
    ("zenburn-magenta"  . "#DC8CC3"))
  "List of Zenburn colors.
Each element has the form (NAME . HEX).

`+N' suffixes indicate a color is lighter.
`-N' suffixes indicate a color is darker.")

(defvar zenburn-default-semantic-colors-alist
  '(;; Status
    ("zenburn-error"                   . zenburn-red)
    ("zenburn-warning"                 . zenburn-orange)
    ("zenburn-success"                 . zenburn-green)
    ("zenburn-info"                    . zenburn-blue)
    ;; Font lock
    ("zenburn-comment"                 . zenburn-green)
    ("zenburn-comment-delimiter"       . zenburn-green-2)
    ("zenburn-doc"                     . zenburn-green+2)
    ("zenburn-string"                  . zenburn-red)
    ("zenburn-keyword"                 . zenburn-yellow)
    ("zenburn-function-name"           . zenburn-cyan)
    ("zenburn-variable-name"           . zenburn-orange)
    ("zenburn-type"                    . zenburn-blue-1)
    ("zenburn-constant"                . zenburn-green+4)
    ("zenburn-preprocessor"            . zenburn-blue+1)
    ;; Diff
    ("zenburn-diff-added-bg"           . "#335533")
    ("zenburn-diff-added-fg"           . zenburn-green)
    ("zenburn-diff-changed-bg"         . "#555511")
    ("zenburn-diff-changed-fg"         . zenburn-yellow-1)
    ("zenburn-diff-removed-bg"         . "#553333")
    ("zenburn-diff-removed-fg"         . zenburn-red-2)
    ("zenburn-diff-refine-added-bg"    . "#338833")
    ("zenburn-diff-refine-added-fg"    . zenburn-green+4)
    ("zenburn-diff-refine-changed-bg"  . "#888811")
    ("zenburn-diff-refine-changed-fg"  . zenburn-yellow)
    ("zenburn-diff-refine-removed-bg"  . "#883333")
    ("zenburn-diff-refine-removed-fg"  . zenburn-red))
  "Semantic color mappings layered on top of `zenburn-default-colors-alist'.
Each element has the form (NAME . VALUE) where VALUE is either a
hex string or the symbol of an entry in `zenburn-default-colors-alist'.
Symbols are resolved against the positional palette at expansion
time, so user overrides in `zenburn-override-colors-alist' flow
through automatically.")

(defmacro zenburn-with-color-variables (&rest body)
  "`let*' bind all Zenburn palette colors around BODY.

Bindings are introduced in order: positional palette first (from
`zenburn-default-colors-alist' overlaid with
`zenburn-override-colors-alist'), then the semantic palette (from
`zenburn-default-semantic-colors-alist' overlaid with
`zenburn-override-semantic-colors-alist').  Semantic values may
reference positional palette names as symbols, which resolve against
the just-introduced bindings."
  (declare (indent 0))
  `(let* (,@(mapcar (lambda (cons)
                      (list (intern (car cons)) (cdr cons)))
                    (append zenburn-default-colors-alist
                            zenburn-override-colors-alist))
          ,@(mapcar (lambda (cons)
                      (list (intern (car cons)) (cdr cons)))
                    (append zenburn-default-semantic-colors-alist
                            zenburn-override-semantic-colors-alist)))
     ,@body))

;;; Theme Faces
(zenburn-with-color-variables
  (custom-theme-set-faces
   'zenburn

;;;; Built-in packages

;;;;; basic coloring
   '(button ((t (:underline t))))
   `(link ((t (:foreground ,zenburn-yellow :underline t :weight bold))))
   `(link-visited ((t (:foreground ,zenburn-yellow-2 :underline t :weight normal))))
   `(default ((t (:foreground ,zenburn-fg :background ,zenburn-bg))))
   `(cursor ((t (:foreground ,zenburn-fg :background ,zenburn-fg+1))))
   `(widget-field ((t (:foreground ,zenburn-fg :background ,zenburn-bg+3))))
   `(escape-glyph ((t (:foreground ,zenburn-yellow :weight bold))))
   `(fringe ((t (:foreground ,zenburn-fg :background ,zenburn-bg+1))))
   `(header-line ((t (:foreground ,zenburn-yellow
                                  :background ,zenburn-bg-1
                                  :box (:line-width -1 :style released-button)
                                  :extend t))))
   `(header-line-highlight ((t (:inherit header-line :background ,zenburn-bg+1))))
   `(highlight ((t (:background ,zenburn-bg-05))))
   `(error ((t (:foreground ,zenburn-error :weight bold))))
   `(success ((t (:foreground ,zenburn-success :weight bold))))
   `(warning ((t (:foreground ,zenburn-warning :weight bold))))
   `(tooltip ((t (:foreground ,zenburn-fg :background ,zenburn-bg+1))))
   `(read-multiple-choice-face ((t (:foreground ,zenburn-yellow :weight bold))))
   `(zenburn-variable-pitch ((t (:inherit ,(if zenburn-use-variable-pitch 'variable-pitch 'default)))))
;;;;; ansi-colors
   `(ansi-color-black ((t (:foreground ,zenburn-bg
                                       :background ,zenburn-bg-1))))
   `(ansi-color-red ((t (:foreground ,zenburn-red-2
                                     :background ,zenburn-red-4))))
   `(ansi-color-green ((t (:foreground ,zenburn-green
                                       :background ,zenburn-green+2))))
   `(ansi-color-yellow ((t (:foreground ,zenburn-orange
                                        :background ,zenburn-yellow))))
   `(ansi-color-blue ((t (:foreground ,zenburn-blue-1
                                      :background ,zenburn-blue-4))))
   `(ansi-color-magenta ((t (:foreground ,zenburn-magenta
                                         :background ,zenburn-red))))
   `(ansi-color-cyan ((t (:foreground ,zenburn-cyan
                                      :background ,zenburn-blue))))
   `(ansi-color-white ((t (:foreground ,zenburn-fg
                                       :background ,zenburn-fg-1))))
;;;;; compilation
   `(compilation-column-number ((t (:foreground ,zenburn-yellow))))
   `(compilation-error ((t (:foreground ,zenburn-red-1 :weight bold :underline t))))
   `(compilation-info ((t (:foreground ,zenburn-green+4 :underline t))))
   `(compilation-line-number ((t (:foreground ,zenburn-yellow))))
   `(compilation-warning ((t (:inherit warning :underline t))))
   `(compilation-mode-line-exit ((t (:foreground ,zenburn-green+2 :weight bold))))
   `(compilation-mode-line-fail ((t (:inherit error))))
   `(compilation-mode-line-run ((t (:foreground ,zenburn-yellow :weight bold))))
   `(next-error-message ((t (:background ,zenburn-bg+1 :extend t))))
;;;;; completions
   `(completions-annotations ((t (:foreground ,zenburn-fg-1))))
   `(completions-common-part ((t (:foreground ,zenburn-blue))))
   `(completions-first-difference ((t (:foreground ,zenburn-fg+1))))
   `(completions-group-title ((t (:foreground ,zenburn-yellow :weight bold))))
   `(completions-group-separator ((t (:foreground ,zenburn-green :strike-through t))))
   `(completions-highlight ((t (:background ,zenburn-bg+2))))
;;;;; completion-preview (Emacs 30+)
   `(completion-preview ((t (:foreground ,zenburn-fg-1))))
   `(completion-preview-common ((t (:inherit completion-preview :slant italic))))
   `(completion-preview-exact ((t (:inherit completion-preview :weight bold))))
   `(completion-preview-highlight ((t (:inherit completions-highlight))))
;;;;; customize
   `(custom-variable-tag ((t (:foreground ,zenburn-blue :weight bold))))
   `(custom-group-tag ((t (:foreground ,zenburn-blue :weight bold :height 1.2))))
   `(custom-state ((t (:foreground ,zenburn-green+4))))
;;;;; display-fill-column-indicator
   `(fill-column-indicator ((t :foreground ,zenburn-bg-05 :weight semilight)))
;;;;; eldoc
   `(eldoc-highlight-function-argument ((t (:foreground ,zenburn-yellow :weight bold))))
;;;;; eww
   '(eww-invalid-certificate ((t (:inherit error))))
   '(eww-valid-certificate   ((t (:inherit success))))
;;;;; grep
   `(match ((t (:background ,zenburn-bg-1 :foreground ,zenburn-orange :weight bold))))
;;;;; hi-lock
   `(hi-blue    ((t (:background ,zenburn-cyan    :foreground ,zenburn-bg-1))))
   `(hi-green   ((t (:background ,zenburn-green+4 :foreground ,zenburn-bg-1))))
   `(hi-pink    ((t (:background ,zenburn-magenta :foreground ,zenburn-bg-1))))
   `(hi-yellow  ((t (:background ,zenburn-yellow  :foreground ,zenburn-bg-1))))
   `(hi-blue-b  ((t (:foreground ,zenburn-blue    :weight     bold))))
   `(hi-green-b ((t (:foreground ,zenburn-green+2 :weight     bold))))
   `(hi-red-b   ((t (:foreground ,zenburn-red     :weight     bold))))
;;;;; info
   `(Info-quoted ((t (:inherit font-lock-constant-face))))
;;;;; isearch
   `(isearch ((t (:foreground ,zenburn-yellow-2 :weight bold :background ,zenburn-bg+2))))
   `(isearch-fail ((t (:foreground ,zenburn-fg :background ,zenburn-red-4))))
   `(isearch-group-1 ((t (:foreground ,zenburn-fg :background ,zenburn-blue-3))))
   `(isearch-group-2 ((t (:foreground ,zenburn-fg :background ,zenburn-green-2))))
   `(lazy-highlight ((t (:foreground ,zenburn-yellow-2 :weight bold :background ,zenburn-bg-05))))

   `(menu ((t (:foreground ,zenburn-fg :background ,zenburn-bg))))
   `(minibuffer-prompt ((t (:foreground ,zenburn-yellow))))
   `(mode-line
     ((t (:foreground ,zenburn-green+1
                      :background ,zenburn-bg-1
                      :box (:line-width -1 :style released-button)))))
   `(mode-line-active ((t (:inherit mode-line))))
   `(mode-line-buffer-id ((t (:foreground ,zenburn-yellow :weight bold))))
   `(mode-line-inactive
     ((t (:foreground ,zenburn-green-2
                      :background ,zenburn-bg-05
                      :box (:line-width -1 :style released-button)))))
   `(region ((t (:background ,zenburn-bg-1 :extend t))))
   `(secondary-selection ((t (:background ,zenburn-bg+2))))
   `(trailing-whitespace ((t (:background ,zenburn-red))))
   `(vertical-border ((t (:foreground ,zenburn-fg))))
;;;;; font lock
   `(font-lock-builtin-face ((t (:foreground ,zenburn-fg :weight bold))))
   `(font-lock-comment-face ((t (:foreground ,zenburn-comment))))
   `(font-lock-comment-delimiter-face ((t (:foreground ,zenburn-comment-delimiter))))
   `(font-lock-constant-face ((t (:foreground ,zenburn-constant))))
   `(font-lock-doc-face ((t (:foreground ,zenburn-doc))))
   `(font-lock-function-name-face ((t (:foreground ,zenburn-function-name))))
   `(font-lock-keyword-face ((t (:foreground ,zenburn-keyword :weight bold))))
   `(font-lock-negation-char-face ((t (:foreground ,zenburn-keyword :weight bold))))
   `(font-lock-preprocessor-face ((t (:foreground ,zenburn-preprocessor))))
   `(font-lock-regexp-grouping-construct ((t (:foreground ,zenburn-yellow :weight bold))))
   `(font-lock-regexp-grouping-backslash ((t (:foreground ,zenburn-green :weight bold))))
   `(font-lock-string-face ((t (:foreground ,zenburn-string))))
   `(font-lock-type-face ((t (:foreground ,zenburn-type))))
   `(font-lock-variable-name-face ((t (:foreground ,zenburn-variable-name))))
   `(font-lock-warning-face ((t (:foreground ,zenburn-yellow-2 :weight bold))))
;;;;; font lock (Emacs 29+)
   `(font-lock-bracket-face ((t (:foreground ,zenburn-fg))))
   `(font-lock-delimiter-face ((t (:foreground ,zenburn-fg))))
   `(font-lock-escape-face ((t (:foreground ,zenburn-green :weight bold))))
   `(font-lock-function-call-face ((t (:foreground ,zenburn-function-name))))
   `(font-lock-misc-punctuation-face ((t (:foreground ,zenburn-fg))))
   `(font-lock-number-face ((t (:foreground ,zenburn-constant))))
   `(font-lock-operator-face ((t (:foreground ,zenburn-fg))))
   `(font-lock-property-name-face ((t (:foreground ,zenburn-variable-name))))
   `(font-lock-property-use-face ((t (:foreground ,zenburn-variable-name))))
   `(font-lock-variable-use-face ((t (:foreground ,zenburn-variable-name))))

   `(c-annotation-face ((t (:inherit font-lock-constant-face))))
;;;;; line numbers (Emacs 26.1 and above)
   `(line-number ((t (:inherit default :foreground ,zenburn-bg+3 :background ,zenburn-bg-05))))
   `(line-number-current-line ((t (:inherit line-number :foreground ,zenburn-yellow-2))))
   `(line-number-major-tick ((t (:inherit line-number :foreground ,zenburn-yellow-2 :weight bold))))
   `(line-number-minor-tick ((t (:inherit line-number :foreground ,zenburn-bg+05))))
;;;;; man
   '(Man-overstrike ((t (:inherit font-lock-keyword-face))))
   '(Man-underline  ((t (:inherit (font-lock-string-face underline)))))
;;;;; newsticker
   `(newsticker-date-face ((t (:foreground ,zenburn-fg))))
   `(newsticker-default-face ((t (:foreground ,zenburn-fg))))
   `(newsticker-enclosure-face ((t (:foreground ,zenburn-green+3))))
   `(newsticker-extra-face ((t (:foreground ,zenburn-bg+2 :height 0.8))))
   `(newsticker-feed-face ((t (:foreground ,zenburn-fg))))
   `(newsticker-immortal-item-face ((t (:foreground ,zenburn-green))))
   `(newsticker-new-item-face ((t (:foreground ,zenburn-blue))))
   `(newsticker-obsolete-item-face ((t (:foreground ,zenburn-red))))
   `(newsticker-old-item-face ((t (:foreground ,zenburn-bg+3))))
   `(newsticker-statistics-face ((t (:foreground ,zenburn-fg))))
   `(newsticker-treeview-face ((t (:foreground ,zenburn-fg))))
   `(newsticker-treeview-immortal-face ((t (:foreground ,zenburn-green))))
   `(newsticker-treeview-listwindow-face ((t (:foreground ,zenburn-fg))))
   `(newsticker-treeview-new-face ((t (:foreground ,zenburn-blue :weight bold))))
   `(newsticker-treeview-obsolete-face ((t (:foreground ,zenburn-red))))
   `(newsticker-treeview-old-face ((t (:foreground ,zenburn-bg+3))))
   `(newsticker-treeview-selection-face ((t (:background ,zenburn-bg-1 :foreground ,zenburn-yellow))))
;;;;; pulse
   `(pulse-highlight-face ((t (:background ,zenburn-blue-5))))
   `(pulse-highlight-start-face ((t (:background ,zenburn-blue-5))))
;;;;; woman
   '(woman-bold   ((t (:inherit font-lock-keyword-face))))
   '(woman-italic ((t (:inherit (font-lock-string-face italic)))))

;;;; Third-party packages

;;;;; ace-window
   `(aw-background-face
     ((t (:foreground ,zenburn-fg-1 :background ,zenburn-bg :inverse-video nil))))
   `(aw-leading-char-face ((t (:inherit aw-mode-line-face))))
;;;;; adoc-mode
   `(adoc-anchor-face ((t (:foreground ,zenburn-blue+1))))
   `(adoc-attribute-face ((t (:foreground ,zenburn-blue :slant italic))))
   `(adoc-bold-face ((t (:foreground ,zenburn-fg+1 :weight bold))))
   `(adoc-code-face ((t (:foreground ,zenburn-green+1 :background ,zenburn-bg-05 :extend t))))
   `(adoc-command-face ((t (:foreground ,zenburn-yellow))))
   `(adoc-comment-face ((t (:inherit font-lock-comment-face :slant italic))))
   `(adoc-complex-replacement-face ((t (:foreground ,zenburn-magenta))))
   `(adoc-emphasis-face ((t (:foreground ,zenburn-fg :slant italic))))
   `(adoc-gen-face ((t (:foreground ,zenburn-fg))))
   `(adoc-internal-reference-face ((t (:foreground ,zenburn-yellow-2 :underline t))))
   `(adoc-language-info-face ((t (:foreground ,zenburn-fg-1))))
   `(adoc-language-keyword-face ((t (:foreground ,zenburn-yellow))))
   `(adoc-link-title-face ((t (:foreground ,zenburn-green :slant italic))))
   `(adoc-list-face ((t (:foreground ,zenburn-magenta))))
   `(adoc-markup-face ((t (:foreground ,zenburn-fg-1))))
   `(adoc-meta-face ((t (:foreground ,zenburn-fg-1))))
   `(adoc-meta-hide-face ((t (:foreground ,zenburn-bg+2))))
   `(adoc-native-code-face ((t (:background ,zenburn-bg-05 :extend t))))
   `(adoc-passthrough-face ((t (:foreground ,zenburn-fg))))
   `(adoc-preprocessor-face ((t (:foreground ,zenburn-magenta))))
   `(adoc-reference-face ((t (:foreground ,zenburn-yellow :underline t))))
   `(adoc-replacement-face ((t (:foreground ,zenburn-cyan))))
   `(adoc-secondary-text-face ((t (:foreground ,zenburn-yellow-1 :height 0.9))))
   `(adoc-subscript-face ((t (:foreground ,zenburn-fg :height 0.8))))
   `(adoc-superscript-face ((t (:foreground ,zenburn-fg :height 0.8))))
   `(adoc-table-face ((t (:foreground ,zenburn-green+2))))
   `(adoc-title-face ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-orange :weight bold))))
   `(adoc-title-0-face ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-blue :weight bold
                                     ,@(when zenburn-scale-outline-headlines
                                         (list :height zenburn-height-plus-4))))))
   `(adoc-title-1-face ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-orange :weight bold
                                     ,@(when zenburn-scale-outline-headlines
                                         (list :height zenburn-height-plus-3))))))
   `(adoc-title-2-face ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-green+4 :weight bold
                                     ,@(when zenburn-scale-outline-headlines
                                         (list :height zenburn-height-plus-2))))))
   `(adoc-title-3-face ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-blue-1 :weight bold
                                     ,@(when zenburn-scale-outline-headlines
                                         (list :height zenburn-height-plus-1))))))
   `(adoc-title-4-face ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-yellow-2 :weight bold))))
   `(adoc-title-5-face ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-cyan :weight bold))))
   `(adoc-typewriter-face ((t (:foreground ,zenburn-green+1))))
   `(adoc-value-face ((t (:foreground ,zenburn-green))))
   `(adoc-verbatim-face ((t (:background ,zenburn-bg-05 :extend t))))
   `(adoc-warning-face ((t (:foreground ,zenburn-red :weight bold))))
;;;;; asciidoc-mode
   ;; the tree-sitter AsciiDoc mode; inherits the adoc-mode styling where
   ;; the two face sets correspond
   `(asciidoc-document-title-face ((t (:inherit adoc-title-0-face))))
   `(asciidoc-title-1-face ((t (:inherit adoc-title-1-face))))
   `(asciidoc-title-2-face ((t (:inherit adoc-title-2-face))))
   `(asciidoc-title-3-face ((t (:inherit adoc-title-3-face))))
   `(asciidoc-title-4-face ((t (:inherit adoc-title-4-face))))
   `(asciidoc-title-5-face ((t (:inherit adoc-title-5-face))))
   `(asciidoc-markup-face ((t (:inherit adoc-meta-face))))
   `(asciidoc-code-face ((t (:inherit adoc-code-face))))
   `(asciidoc-link-face ((t (:inherit link))))
   `(asciidoc-link-mouse-face ((t (:inherit highlight))))
   `(asciidoc-url-face ((t (:inherit link))))
   `(asciidoc-cross-reference-face ((t (:inherit adoc-internal-reference-face))))
   `(asciidoc-anchor-face ((t (:inherit adoc-anchor-face))))
   `(asciidoc-superscript-face ((t (:inherit adoc-superscript-face))))
   `(asciidoc-subscript-face ((t (:inherit adoc-subscript-face))))
   `(asciidoc-metadata-key-face ((t (:inherit adoc-attribute-face))))
   `(asciidoc-metadata-value-face ((t (:inherit adoc-value-face))))
   `(asciidoc-footnote-marker-face ((t (:foreground ,zenburn-fg-1))))
   `(asciidoc-footnote-text-face ((t (:foreground ,zenburn-fg))))
   `(asciidoc-highlight-face ((t (:foreground ,zenburn-bg :background ,zenburn-yellow))))
   `(asciidoc-strike-through-face ((t (:strike-through t))))
   `(asciidoc-underline-face ((t (:underline t))))
   `(asciidoc-overline-face ((t (:overline t))))
   `(asciidoc-admonition-note-label-face ((t (:foreground ,zenburn-blue+1 :weight bold))))
   `(asciidoc-admonition-note-face ((t (:background ,zenburn-bg+05 :extend t))))
   `(asciidoc-admonition-tip-label-face ((t (:foreground ,zenburn-green+2 :weight bold))))
   `(asciidoc-admonition-tip-face ((t (:background ,zenburn-diff-added-bg :extend t))))
   `(asciidoc-admonition-important-label-face ((t (:foreground ,zenburn-magenta :weight bold))))
   `(asciidoc-admonition-important-face ((t (:background ,zenburn-bg+05 :extend t))))
   `(asciidoc-admonition-caution-label-face ((t (:foreground ,zenburn-yellow :weight bold))))
   `(asciidoc-admonition-caution-face ((t (:background ,zenburn-diff-changed-bg :extend t))))
   `(asciidoc-admonition-warning-label-face ((t (:foreground ,zenburn-red :weight bold))))
   `(asciidoc-admonition-warning-face ((t (:background ,zenburn-diff-removed-bg :extend t))))
;;;;; android mode
   `(android-mode-debug-face ((t (:foreground ,zenburn-green+1))))
   `(android-mode-error-face ((t (:foreground ,zenburn-orange :weight bold))))
   `(android-mode-info-face ((t (:foreground ,zenburn-fg))))
   `(android-mode-verbose-face ((t (:foreground ,zenburn-green))))
   `(android-mode-warning-face ((t (:foreground ,zenburn-yellow))))
;;;;; anzu
   `(anzu-mode-line ((t (:foreground ,zenburn-cyan :weight bold))))
   `(anzu-mode-line-no-match ((t (:foreground ,zenburn-red :weight bold))))
   `(anzu-match-1 ((t (:foreground ,zenburn-bg :background ,zenburn-green))))
   `(anzu-match-2 ((t (:foreground ,zenburn-bg :background ,zenburn-orange))))
   `(anzu-match-3 ((t (:foreground ,zenburn-bg :background ,zenburn-blue))))
   `(anzu-replace-to ((t (:inherit anzu-replace-highlight :foreground ,zenburn-yellow))))
;;;;; auctex
   `(font-latex-bold-face ((t (:inherit bold))))
   `(font-latex-warning-face ((t (:foreground nil :inherit font-lock-warning-face))))
   `(font-latex-sectioning-5-face ((t (:foreground ,zenburn-red :weight bold ))))
   `(font-latex-sedate-face ((t (:foreground ,zenburn-yellow))))
   `(font-latex-italic-face ((t (:foreground ,zenburn-cyan :slant italic))))
   `(font-latex-string-face ((t (:inherit ,font-lock-string-face))))
   `(font-latex-math-face ((t (:foreground ,zenburn-orange))))
   `(font-latex-script-char-face ((t (:foreground ,zenburn-orange))))
;;;;; agda-mode
   `(agda2-highlight-keyword-face ((t (:foreground ,zenburn-yellow :weight bold))))
   `(agda2-highlight-string-face ((t (:foreground ,zenburn-red))))
   `(agda2-highlight-symbol-face ((t (:foreground ,zenburn-orange))))
   `(agda2-highlight-primitive-type-face ((t (:foreground ,zenburn-blue-1))))
   `(agda2-highlight-inductive-constructor-face ((t (:foreground ,zenburn-fg))))
   `(agda2-highlight-coinductive-constructor-face ((t (:foreground ,zenburn-fg))))
   `(agda2-highlight-datatype-face ((t (:foreground ,zenburn-blue))))
   `(agda2-highlight-function-face ((t (:foreground ,zenburn-blue))))
   `(agda2-highlight-module-face ((t (:foreground ,zenburn-blue-1))))
   `(agda2-highlight-error-face ((t (:foreground ,zenburn-bg :background ,zenburn-magenta))))
   `(agda2-highlight-unsolved-meta-face ((t (:foreground ,zenburn-bg :background ,zenburn-magenta))))
   `(agda2-highlight-unsolved-constraint-face ((t (:foreground ,zenburn-bg :background ,zenburn-magenta))))
   `(agda2-highlight-termination-problem-face ((t (:foreground ,zenburn-bg :background ,zenburn-magenta))))
   `(agda2-highlight-incomplete-pattern-face ((t (:foreground ,zenburn-bg :background ,zenburn-magenta))))
   `(agda2-highlight-typechecks-face ((t (:background ,zenburn-red-4))))
;;;;; auto-complete
   `(ac-candidate-face ((t (:background ,zenburn-bg+3 :foreground ,zenburn-bg-2))))
   `(ac-selection-face ((t (:background ,zenburn-blue-4 :foreground ,zenburn-fg))))
   `(popup-tip-face ((t (:background ,zenburn-yellow-2 :foreground ,zenburn-bg-2))))
   `(popup-menu-mouse-face ((t (:background ,zenburn-yellow-2 :foreground ,zenburn-bg-2))))
   `(popup-summary-face ((t (:background ,zenburn-bg+3 :foreground ,zenburn-bg-2))))
   `(popup-scroll-bar-foreground-face ((t (:background ,zenburn-blue-5))))
   `(popup-scroll-bar-background-face ((t (:background ,zenburn-bg-1))))
   `(popup-isearch-match ((t (:background ,zenburn-bg :foreground ,zenburn-fg))))
;;;;; avy
   `(avy-background-face
     ((t (:foreground ,zenburn-fg-1 :background ,zenburn-bg :inverse-video nil))))
   `(avy-lead-face-0
     ((t (:foreground ,zenburn-green+3 :background ,zenburn-bg :inverse-video nil :weight bold))))
   `(avy-lead-face-1
     ((t (:foreground ,zenburn-yellow :background ,zenburn-bg :inverse-video nil :weight bold))))
   `(avy-lead-face-2
     ((t (:foreground ,zenburn-red+1 :background ,zenburn-bg :inverse-video nil :weight bold))))
   `(avy-lead-face
     ((t (:foreground ,zenburn-cyan :background ,zenburn-bg :inverse-video nil :weight bold))))
;;;;; company-mode
   `(company-tooltip ((t (:foreground ,zenburn-fg :background ,zenburn-bg+1))))
   `(company-tooltip-annotation ((t (:foreground ,zenburn-orange :background ,zenburn-bg+1))))
   `(company-tooltip-annotation-selection ((t (:foreground ,zenburn-orange :background ,zenburn-bg-1))))
   `(company-tooltip-selection ((t (:foreground ,zenburn-fg :background ,zenburn-bg-1))))
   `(company-tooltip-mouse ((t (:background ,zenburn-bg-1))))
   `(company-tooltip-common ((t (:foreground ,zenburn-green+2))))
   `(company-tooltip-common-selection ((t (:foreground ,zenburn-green+2))))
   `(company-scrollbar-fg ((t (:background ,zenburn-bg-1))))
   `(company-scrollbar-bg ((t (:background ,zenburn-bg+2))))
   `(company-preview-common ((t (:foreground ,zenburn-green+2 :background ,zenburn-bg-1))))
;;;;; corfu
   `(corfu-default ((t (:foreground ,zenburn-fg :background ,zenburn-bg+1))))
   `(corfu-current ((t (:foreground ,zenburn-fg :background ,zenburn-bg-1))))
   `(corfu-bar ((t (:background ,zenburn-bg-1))))
   `(corfu-border ((t (:background ,zenburn-bg-2))))
   `(corfu-annotations ((t (:foreground ,zenburn-fg-1))))
   `(corfu-deprecated ((t (:foreground ,zenburn-fg-1 :strike-through t))))
   `(corfu-popupinfo ((t (:background ,zenburn-bg-05))))
;;;;; consult
   `(consult-preview-line ((t (:background ,zenburn-bg+1))))
   `(consult-highlight-match ((t (:foreground ,zenburn-yellow :weight bold))))
   `(consult-highlight-mark ((t (:foreground ,zenburn-orange :weight bold))))
   `(consult-preview-match ((t (:inherit consult-highlight-match))))
   `(consult-preview-insertion ((t (:foreground ,zenburn-green+2))))
   `(consult-narrow-indicator ((t (:foreground ,zenburn-magenta :weight bold))))
   `(consult-async-running ((t (:foreground ,zenburn-orange))))
   `(consult-async-finished ((t (:foreground ,zenburn-green+2))))
   `(consult-async-failed ((t (:foreground ,zenburn-red))))
   `(consult-async-split ((t (:foreground ,zenburn-magenta))))
   `(consult-key ((t (:foreground ,zenburn-blue))))
   `(consult-line-number ((t (:foreground ,zenburn-bg+3))))
   `(consult-file ((t (:foreground ,zenburn-blue))))
   `(consult-grep-context ((t (:foreground ,zenburn-fg-1))))
   `(consult-bookmark ((t (:foreground ,zenburn-yellow))))
   `(consult-buffer ((t (:foreground ,zenburn-fg))))
   `(consult-line-number-prefix ((t (:foreground ,zenburn-bg+3))))
   `(consult-line-number-wrapped ((t (:foreground ,zenburn-orange))))
   `(consult-help ((t (:foreground ,zenburn-green))))
;;;;; bm
   `(bm-face ((t (:background ,zenburn-yellow-1 :foreground ,zenburn-bg))))
   `(bm-fringe-face ((t (:background ,zenburn-yellow-1 :foreground ,zenburn-bg))))
   `(bm-fringe-persistent-face ((t (:background ,zenburn-green-2 :foreground ,zenburn-bg))))
   `(bm-persistent-face ((t (:background ,zenburn-green-2 :foreground ,zenburn-bg))))
;;;;; breadcrumb
   `(breadcrumb-face ((t (:foreground ,zenburn-fg-1))))
   `(breadcrumb-imenu-leaf-face ((t (:foreground ,zenburn-blue :weight bold))))
   `(breadcrumb-imenu-crumbs-face ((t (:foreground ,zenburn-fg-1))))
   `(breadcrumb-project-leaf-face ((t (:foreground ,zenburn-fg :weight bold))))
   `(breadcrumb-project-crumbs-face ((t (:foreground ,zenburn-fg-1))))
   `(breadcrumb-project-base-face ((t (:foreground ,zenburn-fg-1 :weight bold))))
   `(breadcrumb-imenu-base-face ((t (:foreground ,zenburn-fg-1 :weight bold))))
;;;;; calfw
   `(cfw:face-annotation ((t (:foreground ,zenburn-red :inherit cfw:face-day-title))))
   `(cfw:face-day-title ((t nil)))
   `(cfw:face-default-content ((t (:foreground ,zenburn-green))))
   `(cfw:face-default-day ((t (:weight bold))))
   `(cfw:face-disable ((t (:foreground ,zenburn-fg-1))))
   `(cfw:face-grid ((t (:inherit shadow))))
   `(cfw:face-header ((t (:inherit font-lock-keyword-face))))
   `(cfw:face-holiday ((t (:inherit cfw:face-sunday))))
   `(cfw:face-periods ((t (:foreground ,zenburn-cyan))))
   `(cfw:face-saturday ((t (:foreground ,zenburn-blue :weight bold))))
   `(cfw:face-select ((t (:background ,zenburn-blue-5))))
   `(cfw:face-sunday ((t (:foreground ,zenburn-red :weight bold))))
   `(cfw:face-title ((t (:height 2.0 :inherit (variable-pitch font-lock-keyword-face)))))
   `(cfw:face-today ((t (:foreground ,zenburn-cyan :weight bold))))
   `(cfw:face-today-title ((t (:inherit highlight bold))))
   `(cfw:face-toolbar ((t (:background ,zenburn-blue-5))))
   `(cfw:face-toolbar-button-off ((t (:underline nil :inherit link))))
   `(cfw:face-toolbar-button-on ((t (:underline nil :inherit link-visited))))
;;;;; centaur-tabs
   `(centaur-tabs-default ((t (:background ,zenburn-bg :foreground ,zenburn-fg :box nil))))
   `(centaur-tabs-selected ((t (:background ,zenburn-bg :foreground ,zenburn-fg+2 :box nil))))
   `(centaur-tabs-unselected ((t (:background ,zenburn-bg-1 :foreground ,zenburn-fg-05 :box nil))))
   `(centaur-tabs-selected-modified ((t (:background ,zenburn-bg :foreground ,zenburn-orange :box nil))))
   `(centaur-tabs-unselected-modified ((t (:background ,zenburn-bg-1 :foreground ,zenburn-orange :box nil))))
   `(centaur-tabs-active-bar-face ((t (:background ,zenburn-yellow :box nil))))
   `(centaur-tabs-modified-marker-selected ((t (:inherit 'centaur-tabs-selected-modified :foreground ,zenburn-yellow :box nil))))
   `(centaur-tabs-modified-marker-unselected ((t (:inherit 'centaur-tabs-unselected-modified :foreground ,zenburn-yellow :box nil))))
;;;;; cider
   `(cider-result-overlay-face ((t (:background unspecified))))
   `(cider-enlightened-face ((t (:box (:color ,zenburn-orange :line-width -1)))))
   `(cider-enlightened-local-face ((t (:weight bold :foreground ,zenburn-green+1))))
   `(cider-deprecated-face ((t (:background ,zenburn-yellow-2))))
   `(cider-instrumented-face ((t (:box (:color ,zenburn-red :line-width -1)))))
   `(cider-traced-face ((t (:box (:color ,zenburn-cyan :line-width -1)))))
   `(cider-test-failure-face ((t (:background ,zenburn-red-4))))
   `(cider-test-error-face ((t (:background ,zenburn-magenta))))
   `(cider-test-success-face ((t (:background ,zenburn-green-2))))
   `(cider-fringe-good-face ((t (:foreground ,zenburn-green+4))))
   `(cider-fringe-bad-face ((t (:foreground ,zenburn-red))))
   `(cider-fringe-stale-face ((t (:foreground ,zenburn-yellow))))
   `(cider-repl-prompt-face ((t (:foreground ,zenburn-yellow))))
   `(cider-repl-input-face ((t (:weight bold))))
   `(cider-repl-result-face ((t (:foreground ,zenburn-green+1))))
   `(cider-repl-stdout-face ((t (:foreground ,zenburn-fg))))
   `(cider-repl-stderr-face ((t (:foreground ,zenburn-red))))
   `(cider-error-highlight-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-red) :inherit unspecified))
      (t (:foreground ,zenburn-red-1 :weight bold :underline t))))
   `(cider-warning-highlight-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-orange) :inherit unspecified))
      (t (:foreground ,zenburn-orange :weight bold :underline t))))
   `(cider-stacktrace-error-class-face ((t (:foreground ,zenburn-red :weight bold))))
   `(cider-stacktrace-error-message-face ((t (:foreground ,zenburn-fg-1 :slant italic))))
   `(cider-stacktrace-face ((t (:foreground ,zenburn-fg))))
   `(cider-stacktrace-fn-face ((t (:inherit font-lock-function-name-face))))
   `(cider-stacktrace-ns-face ((t (:inherit font-lock-comment-face))))
   `(cider-stacktrace-filter-active-face ((t (:foreground ,zenburn-yellow :underline t))))
   `(cider-stacktrace-filter-inactive-face ((t (:foreground ,zenburn-fg-1))))
   `(cider-stacktrace-promoted-button-face ((t (:foreground ,zenburn-red :box (:line-width -1 :color ,zenburn-red)))))
   `(cider-stacktrace-suppressed-button-face ((t (:foreground ,zenburn-fg-1 :box (:line-width -1 :color ,zenburn-fg-1)))))
   `(cider-reader-conditional-face ((t (:foreground ,zenburn-fg-05))))
   `(cider-debug-prompt-face ((t (:foreground ,zenburn-magenta :weight bold))))
   ;; faces for the nREPL message log, matching `nrepl-message-colors'
   `(nrepl-message-1-face ((t (:foreground ,zenburn-red))))
   `(nrepl-message-2-face ((t (:foreground ,zenburn-orange))))
   `(nrepl-message-3-face ((t (:foreground ,zenburn-yellow))))
   `(nrepl-message-4-face ((t (:foreground ,zenburn-green))))
   `(nrepl-message-5-face ((t (:foreground ,zenburn-green+4))))
   `(nrepl-message-6-face ((t (:foreground ,zenburn-cyan))))
   `(nrepl-message-7-face ((t (:foreground ,zenburn-blue+1))))
   `(nrepl-message-8-face ((t (:foreground ,zenburn-magenta))))
;;;;; citar
   `(citar ((t (:foreground ,zenburn-fg))))
   `(citar-highlight ((t (:foreground ,zenburn-yellow :weight bold))))
   `(citar-icon ((t (:foreground ,zenburn-blue))))
;;;;; circe
   `(circe-highlight-nick-face ((t (:foreground ,zenburn-cyan))))
   `(circe-my-message-face ((t (:foreground ,zenburn-fg))))
   `(circe-fool-face ((t (:foreground ,zenburn-red+1))))
   `(circe-topic-diff-removed-face ((t (:foreground ,zenburn-red :weight bold))))
   `(circe-originator-face ((t (:foreground ,zenburn-fg))))
   `(circe-server-face ((t (:foreground ,zenburn-green))))
   `(circe-topic-diff-new-face ((t (:foreground ,zenburn-orange :weight bold))))
   `(circe-prompt-face ((t (:foreground ,zenburn-orange :background ,zenburn-bg :weight bold))))
;;;;; clojure-mode
   `(clojure-keyword-face ((t (:foreground ,zenburn-cyan))))
   `(clojure-character-face ((t (:inherit font-lock-string-face))))
   `(clojure-discard-face ((t (:inherit font-lock-comment-face))))
;;;;; copilot
   `(copilot-overlay-face ((t (:foreground ,zenburn-fg-1 :slant italic))))
;;;;; coq
   `(coq-solve-tactics-face ((t (:foreground nil :inherit font-lock-constant-face))))
;;;;; ctable
   `(ctbl:face-cell-select ((t (:background ,zenburn-blue :foreground ,zenburn-bg))))
   `(ctbl:face-continue-bar ((t (:background ,zenburn-bg-05 :foreground ,zenburn-bg))))
   `(ctbl:face-row-select ((t (:background ,zenburn-cyan :foreground ,zenburn-bg))))
;;;;; debbugs
   `(debbugs-gnu-done ((t (:foreground ,zenburn-fg-1))))
   `(debbugs-gnu-handled ((t (:foreground ,zenburn-green))))
   `(debbugs-gnu-new ((t (:foreground ,zenburn-red))))
   `(debbugs-gnu-pending ((t (:foreground ,zenburn-blue))))
   `(debbugs-gnu-stale ((t (:foreground ,zenburn-orange))))
   `(debbugs-gnu-tagged ((t (:foreground ,zenburn-red))))
;;;;; denote
   `(denote-faces-title ((t (:foreground ,zenburn-fg :weight bold))))
   `(denote-faces-subdirectory ((t (:foreground ,zenburn-blue :weight bold))))
   `(denote-faces-date ((t (:foreground ,zenburn-cyan))))
   `(denote-faces-time ((t (:foreground ,zenburn-cyan))))
   `(denote-faces-time-delimiter ((t (:foreground ,zenburn-fg-1))))
   `(denote-faces-year ((t (:foreground ,zenburn-cyan))))
   `(denote-faces-keywords ((t (:foreground ,zenburn-magenta :weight bold))))
   `(denote-faces-extension ((t (:foreground ,zenburn-fg-1))))
   `(denote-faces-delimiter ((t (:foreground ,zenburn-fg-1))))
   `(denote-faces-signature ((t (:foreground ,zenburn-orange :weight bold))))
   `(denote-faces-link ((t (:inherit link))))
   `(denote-faces-prompt-current-name ((t (:foreground ,zenburn-cyan))))
   `(denote-faces-prompt-new-name ((t (:foreground ,zenburn-green+2))))
   `(denote-faces-prompt-old-name ((t (:foreground ,zenburn-red))))
;;;;; dictionary
   `(dictionary-word-entry-face ((t (:foreground ,zenburn-orange :weight bold))))
   `(dictionary-word-definition-face ((t (:foreground ,zenburn-fg))))
   `(dictionary-reference-face ((t (:inherit link))))
   `(dictionary-button-face ((t (:inherit link))))
;;;;; diff
   ;; Please read (info "(magit)Theming Faces") before changing this.
   `(diff-added          ((t (:background ,zenburn-diff-added-bg          :foreground ,zenburn-diff-added-fg))))
   `(diff-changed        ((t (:background ,zenburn-diff-changed-bg        :foreground ,zenburn-diff-changed-fg))))
   `(diff-removed        ((t (:background ,zenburn-diff-removed-bg        :foreground ,zenburn-diff-removed-fg))))
   `(diff-refine-added   ((t (:background ,zenburn-diff-refine-added-bg   :foreground ,zenburn-diff-refine-added-fg))))
   `(diff-refine-changed ((t (:background ,zenburn-diff-refine-changed-bg :foreground ,zenburn-diff-refine-changed-fg))))
   `(diff-refine-removed ((t (:background ,zenburn-diff-refine-removed-bg :foreground ,zenburn-diff-refine-removed-fg))))
   `(diff-header ((t (:background ,zenburn-bg+2))))
   `(diff-file-header
     ((t (:background ,zenburn-bg+2 :foreground ,zenburn-fg :weight bold))))
;;;;; diff-hl
   `(diff-hl-change ((t (:foreground ,zenburn-blue :background ,zenburn-blue-2))))
   `(diff-hl-delete ((t (:foreground ,zenburn-red+1 :background ,zenburn-red-1))))
   `(diff-hl-insert ((t (:foreground ,zenburn-green+1 :background ,zenburn-green-2))))
;;;;; dired+
   `(diredp-display-msg ((t (:foreground ,zenburn-blue))))
   `(diredp-compressed-file-suffix ((t (:foreground ,zenburn-orange))))
   `(diredp-date-time ((t (:foreground ,zenburn-magenta))))
   `(diredp-deletion ((t (:foreground ,zenburn-yellow))))
   `(diredp-deletion-file-name ((t (:foreground ,zenburn-red))))
   `(diredp-dir-heading ((t (:foreground ,zenburn-blue :background ,zenburn-bg-1))))
   `(diredp-dir-priv ((t (:foreground ,zenburn-cyan))))
   `(diredp-exec-priv ((t (:foreground ,zenburn-red))))
   `(diredp-executable-tag ((t (:foreground ,zenburn-green+1))))
   `(diredp-file-name ((t (:foreground ,zenburn-blue))))
   `(diredp-file-suffix ((t (:foreground ,zenburn-green))))
   `(diredp-flag-mark ((t (:foreground ,zenburn-yellow))))
   `(diredp-flag-mark-line ((t (:foreground ,zenburn-orange))))
   `(diredp-ignored-file-name ((t (:foreground ,zenburn-red))))
   `(diredp-link-priv ((t (:foreground ,zenburn-yellow))))
   `(diredp-mode-line-flagged ((t (:foreground ,zenburn-yellow))))
   `(diredp-mode-line-marked ((t (:foreground ,zenburn-orange))))
   `(diredp-no-priv ((t (:foreground ,zenburn-fg))))
   `(diredp-number ((t (:foreground ,zenburn-green+1))))
   `(diredp-other-priv ((t (:foreground ,zenburn-yellow-1))))
   `(diredp-rare-priv ((t (:foreground ,zenburn-red-1))))
   `(diredp-read-priv ((t (:foreground ,zenburn-green-2))))
   `(diredp-symlink ((t (:foreground ,zenburn-yellow))))
   `(diredp-write-priv ((t (:foreground ,zenburn-magenta))))
;;;;; dired-async
   `(dired-async-failures ((t (:inherit error))))
   `(dired-async-message ((t (:foreground ,zenburn-yellow :weight bold))))
   `(dired-async-mode-message ((t (:foreground ,zenburn-yellow))))
;;;;; diredfl
   `(diredfl-compressed-file-suffix ((t (:foreground ,zenburn-orange))))
   `(diredfl-date-time ((t (:foreground ,zenburn-magenta))))
   `(diredfl-deletion ((t (:foreground ,zenburn-yellow))))
   `(diredfl-deletion-file-name ((t (:foreground ,zenburn-red))))
   `(diredfl-dir-heading ((t (:foreground ,zenburn-blue :background ,zenburn-bg-1))))
   `(diredfl-dir-priv ((t (:foreground ,zenburn-cyan))))
   `(diredfl-exec-priv ((t (:foreground ,zenburn-red))))
   `(diredfl-executable-tag ((t (:foreground ,zenburn-green+1))))
   `(diredfl-file-name ((t (:foreground ,zenburn-blue))))
   `(diredfl-file-suffix ((t (:foreground ,zenburn-green))))
   `(diredfl-flag-mark ((t (:foreground ,zenburn-yellow))))
   `(diredfl-flag-mark-line ((t (:foreground ,zenburn-orange))))
   `(diredfl-ignored-file-name ((t (:foreground ,zenburn-red))))
   `(diredfl-link-priv ((t (:foreground ,zenburn-yellow))))
   `(diredfl-no-priv ((t (:foreground ,zenburn-fg))))
   `(diredfl-number ((t (:foreground ,zenburn-green+1))))
   `(diredfl-other-priv ((t (:foreground ,zenburn-yellow-1))))
   `(diredfl-rare-priv ((t (:foreground ,zenburn-red-1))))
   `(diredfl-read-priv ((t (:foreground ,zenburn-green-1))))
   `(diredfl-symlink ((t (:foreground ,zenburn-yellow))))
   `(diredfl-write-priv ((t (:foreground ,zenburn-magenta))))
;;;;; doom-modeline
   `(doom-modeline ((t (:inherit mode-line))))
   `(doom-modeline-emphasis ((t (:foreground ,zenburn-blue :weight bold))))
   `(doom-modeline-highlight ((t (:foreground ,zenburn-magenta))))
   `(doom-modeline-buffer-path ((t (:foreground ,zenburn-fg-1))))
   `(doom-modeline-buffer-file ((t (:foreground ,zenburn-fg :weight bold))))
   `(doom-modeline-buffer-modified ((t (:foreground ,zenburn-yellow :weight bold))))
   `(doom-modeline-buffer-major-mode ((t (:foreground ,zenburn-blue :weight bold))))
   `(doom-modeline-buffer-minor-mode ((t (:foreground ,zenburn-bg+3))))
   `(doom-modeline-project-parent-dir ((t (:foreground ,zenburn-fg-1))))
   `(doom-modeline-project-dir ((t (:foreground ,zenburn-blue :weight bold))))
   `(doom-modeline-project-root-dir ((t (:foreground ,zenburn-fg))))
   `(doom-modeline-panel ((t (:foreground ,zenburn-bg :background ,zenburn-blue))))
   `(doom-modeline-host ((t (:foreground ,zenburn-magenta :slant italic))))
   `(doom-modeline-input-method ((t (:foreground ,zenburn-orange :weight bold))))
   `(doom-modeline-debug ((t (:foreground ,zenburn-orange))))
   `(doom-modeline-info ((t (:foreground ,zenburn-cyan))))
   `(doom-modeline-warning ((t (:foreground ,zenburn-yellow))))
   `(doom-modeline-urgent ((t (:foreground ,zenburn-red))))
   `(doom-modeline-notification ((t (:foreground ,zenburn-orange))))
   `(doom-modeline-unread-number ((t (:foreground ,zenburn-fg :weight bold))))
   `(doom-modeline-bar ((t (:background ,zenburn-yellow))))
   `(doom-modeline-bar-inactive ((t (:background nil))))
   `(doom-modeline-evil-emacs-state ((t (:foreground ,zenburn-magenta :weight bold))))
   `(doom-modeline-evil-insert-state ((t (:foreground ,zenburn-green :weight bold))))
   `(doom-modeline-evil-motion-state ((t (:foreground ,zenburn-blue :weight bold))))
   `(doom-modeline-evil-normal-state ((t (:foreground ,zenburn-cyan :weight bold))))
   `(doom-modeline-evil-operator-state ((t (:foreground ,zenburn-magenta :weight bold))))
   `(doom-modeline-evil-visual-state ((t (:foreground ,zenburn-yellow :weight bold))))
   `(doom-modeline-evil-replace-state ((t (:foreground ,zenburn-red :weight bold))))
   `(doom-modeline-overwrite ((t (:foreground ,zenburn-red :weight bold))))
   `(doom-modeline-project-name ((t (:foreground ,zenburn-blue :weight bold))))
   `(doom-modeline-workspace-name ((t (:foreground ,zenburn-magenta))))
   `(doom-modeline-persp-name ((t (:foreground ,zenburn-cyan :weight bold))))
   `(doom-modeline-persp-buffer-not-in-persp ((t (:foreground ,zenburn-fg-1 :slant italic))))
   `(doom-modeline-repl-success ((t (:foreground ,zenburn-green+2 :weight bold))))
   `(doom-modeline-repl-warning ((t (:foreground ,zenburn-yellow :weight bold))))
   `(doom-modeline-vcs-default ((t (:foreground ,zenburn-fg-1))))
   `(doom-modeline-lsp-success ((t (:foreground ,zenburn-green+2 :weight bold))))
   `(doom-modeline-lsp-warning ((t (:foreground ,zenburn-yellow :weight bold))))
   `(doom-modeline-lsp-error ((t (:inherit error))))
   `(doom-modeline-lsp-running ((t (:foreground ,zenburn-orange))))
   `(doom-modeline-battery-charging ((t (:foreground ,zenburn-green))))
   `(doom-modeline-battery-full ((t (:foreground ,zenburn-green))))
   `(doom-modeline-battery-normal ((t (:foreground ,zenburn-fg-1))))
   `(doom-modeline-battery-warning ((t (:foreground ,zenburn-yellow :weight bold))))
   `(doom-modeline-battery-critical ((t (:inherit error))))
   `(doom-modeline-battery-error ((t (:inherit error))))
   `(doom-modeline-time ((t (:foreground ,zenburn-bg+3))))
   `(doom-modeline-compilation ((t (:foreground ,zenburn-orange :weight bold))))
;;;;; easy-kill
   `(easy-kill-selection ((t (:background ,zenburn-bg-1 :extend t))))
   `(easy-kill-origin ((t (:foreground ,zenburn-bg :background ,zenburn-red))))
;;;;; eglot
   `(eglot-highlight-symbol-face ((t (:background ,zenburn-bg+2 :weight bold))))
   `(eglot-diagnostic-tag-unnecessary-face ((t (:foreground ,zenburn-green :underline (:style wave :color ,zenburn-bg+3)))))
   `(eglot-diagnostic-tag-deprecated-face ((t (:foreground ,zenburn-green :strike-through ,zenburn-bg+3))))
   `(eglot-inlay-hint-face ((t (:foreground ,zenburn-bg+3 :height 0.9))))
   `(eglot-parameter-hint-face ((t (:inherit eglot-inlay-hint-face))))
   `(eglot-type-hint-face ((t (:inherit eglot-inlay-hint-face))))
   `(eglot-mode-line ((t (:foreground ,zenburn-yellow :weight bold))))
;;;;; ediff
   `(ediff-current-diff-A ((t (:foreground ,zenburn-fg :background ,zenburn-red-4))))
   `(ediff-current-diff-Ancestor ((t (:foreground ,zenburn-fg :background ,zenburn-red-4))))
   `(ediff-current-diff-B ((t (:foreground ,zenburn-fg :background ,zenburn-green-2))))
   `(ediff-current-diff-C ((t (:foreground ,zenburn-fg :background ,zenburn-blue-5))))
   `(ediff-even-diff-A ((t (:background ,zenburn-bg+1))))
   `(ediff-even-diff-Ancestor ((t (:background ,zenburn-bg+1))))
   `(ediff-even-diff-B ((t (:background ,zenburn-bg+1))))
   `(ediff-even-diff-C ((t (:background ,zenburn-bg+1))))
   `(ediff-fine-diff-A ((t (:foreground ,zenburn-fg :background ,zenburn-red-2 :weight bold))))
   `(ediff-fine-diff-Ancestor ((t (:foreground ,zenburn-fg :background ,zenburn-red-2 :weight bold))))
   `(ediff-fine-diff-B ((t (:foreground ,zenburn-fg :background ,zenburn-green :weight bold))))
   `(ediff-fine-diff-C ((t (:foreground ,zenburn-fg :background ,zenburn-blue-3 :weight bold ))))
   `(ediff-odd-diff-A ((t (:background ,zenburn-bg+2))))
   `(ediff-odd-diff-Ancestor ((t (:background ,zenburn-bg+2))))
   `(ediff-odd-diff-B ((t (:background ,zenburn-bg+2))))
   `(ediff-odd-diff-C ((t (:background ,zenburn-bg+2))))
;;;;; elfeed
   `(elfeed-log-error-level-face ((t (:foreground ,zenburn-red))))
   `(elfeed-log-info-level-face ((t (:foreground ,zenburn-blue))))
   `(elfeed-log-warn-level-face ((t (:foreground ,zenburn-yellow))))
   `(elfeed-search-date-face ((t (:foreground ,zenburn-yellow-1 :underline t
                                              :weight bold))))
   `(elfeed-search-tag-face ((t (:foreground ,zenburn-green))))
   `(elfeed-search-feed-face ((t (:foreground ,zenburn-cyan))))
   `(elfeed-search-title-face ((t (:foreground ,zenburn-fg-05))))
   `(elfeed-search-unread-title-face ((t (:foreground ,zenburn-fg :weight bold))))
;;;;; embark
   `(embark-keybinding ((t (:foreground ,zenburn-blue :weight bold))))
   `(embark-keybinding-repeat ((t (:foreground ,zenburn-magenta :weight bold))))
   `(embark-keymap ((t (:foreground ,zenburn-bg+3))))
   `(embark-target ((t (:foreground ,zenburn-orange :weight bold))))
   `(embark-verbose-indicator-documentation ((t (:foreground ,zenburn-green :slant italic))))
   `(embark-verbose-indicator-title ((t (:foreground ,zenburn-fg :weight bold))))
   `(embark-verbose-indicator-shadowed ((t (:foreground ,zenburn-bg+3))))
   `(embark-collect-candidate ((t (:foreground ,zenburn-fg))))
   `(embark-collect-group-title ((t (:foreground ,zenburn-yellow :weight bold))))
   `(embark-collect-group-separator ((t (:foreground ,zenburn-green :strike-through t))))
   `(embark-collect-annotation ((t (:foreground ,zenburn-fg-1))))
   `(embark-selected ((t (:background ,zenburn-bg+1 :weight bold))))
;;;;; emacs-w3m
   `(w3m-anchor ((t (:foreground ,zenburn-yellow :underline t
                                 :weight bold))))
   `(w3m-arrived-anchor ((t (:foreground ,zenburn-yellow-2
                                         :underline t :weight normal))))
   `(w3m-form ((t (:foreground ,zenburn-red-1 :underline t))))
   `(w3m-header-line-location-title ((t (:foreground ,zenburn-yellow
                                                     :underline t :weight bold))))
   '(w3m-history-current-url ((t (:inherit match))))
   `(w3m-lnum ((t (:foreground ,zenburn-green+2 :background ,zenburn-bg))))
   `(w3m-lnum-match ((t (:background ,zenburn-bg-1
                                     :foreground ,zenburn-orange
                                     :weight bold))))
   `(w3m-lnum-minibuffer-prompt ((t (:foreground ,zenburn-yellow))))
;;;;; erc
   `(erc-action-face ((t (:inherit erc-default-face))))
   `(erc-bold-face ((t (:weight bold))))
   `(erc-current-nick-face ((t (:foreground ,zenburn-blue :weight bold))))
   `(erc-dangerous-host-face ((t (:inherit font-lock-warning-face))))
   `(erc-default-face ((t (:foreground ,zenburn-fg))))
   `(erc-direct-msg-face ((t (:inherit erc-default-face))))
   `(erc-error-face ((t (:inherit font-lock-warning-face))))
   `(erc-fool-face ((t (:inherit erc-default-face))))
   `(erc-highlight-face ((t (:background ,zenburn-bg+1))))
   `(erc-input-face ((t (:foreground ,zenburn-yellow))))
   `(erc-keyword-face ((t (:foreground ,zenburn-blue :weight bold))))
   `(erc-nick-default-face ((t (:foreground ,zenburn-yellow :weight bold))))
   `(erc-my-nick-face ((t (:foreground ,zenburn-red :weight bold))))
   `(erc-nick-msg-face ((t (:inherit erc-default-face))))
   `(erc-notice-face ((t (:foreground ,zenburn-green))))
   `(erc-pal-face ((t (:foreground ,zenburn-orange :weight bold))))
   `(erc-prompt-face ((t (:foreground ,zenburn-orange :background ,zenburn-bg :weight bold))))
   `(erc-timestamp-face ((t (:foreground ,zenburn-green+4))))
   `(erc-underline-face ((t (:underline t))))
;;;;; erlang
   `(erlang-font-lock-exported-function-name-face ((t (:inherit font-lock-function-name-face :weight bold))))
   `(erlang-edoc-heading ((t (:foreground ,zenburn-orange :weight bold))))
   `(erlang-edoc-tag ((t (:foreground ,zenburn-fg-1))))
   `(erlang-edoc-macro ((t (:inherit font-lock-preprocessor-face))))
   `(erlang-edoc-verbatim ((t (:foreground ,zenburn-green+1))))
   `(erlang-edoc-todo ((t (:inherit hl-todo))))
;;;;; eros
   `(eros-result-overlay-face ((t (:background unspecified))))
;;;;; ert
   `(ert-test-result-expected ((t (:foreground ,zenburn-green+4 :background ,zenburn-bg))))
   `(ert-test-result-unexpected ((t (:foreground ,zenburn-red :background ,zenburn-bg))))
;;;;; eshell
   `(eshell-prompt ((t (:foreground ,zenburn-yellow :weight bold))))
   `(eshell-ls-archive ((t (:foreground ,zenburn-red-1 :weight bold))))
   `(eshell-ls-backup ((t (:inherit font-lock-comment-face))))
   `(eshell-ls-clutter ((t (:inherit font-lock-comment-face))))
   `(eshell-ls-directory ((t (:foreground ,zenburn-blue+1 :weight bold))))
   `(eshell-ls-executable ((t (:foreground ,zenburn-red+1 :weight bold))))
   `(eshell-ls-unreadable ((t (:foreground ,zenburn-fg))))
   `(eshell-ls-missing ((t (:inherit font-lock-warning-face))))
   `(eshell-ls-product ((t (:inherit font-lock-doc-face))))
   `(eshell-ls-special ((t (:foreground ,zenburn-yellow :weight bold))))
   `(eshell-ls-symlink ((t (:foreground ,zenburn-cyan :weight bold))))
;;;;; flx
   `(flx-highlight-face ((t (:foreground ,zenburn-green+2 :weight bold))))
;;;;; flycheck
   `(flycheck-error
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-red-1) :inherit unspecified))
      (t (:foreground ,zenburn-red-1 :weight bold :underline t))))
   `(flycheck-warning
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-yellow) :inherit unspecified))
      (t (:foreground ,zenburn-yellow :weight bold :underline t))))
   `(flycheck-info
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-cyan) :inherit unspecified))
      (t (:foreground ,zenburn-cyan :weight bold :underline t))))
   `(flycheck-fringe-error ((t (:foreground ,zenburn-red-1 :weight bold))))
   `(flycheck-fringe-warning ((t (:foreground ,zenburn-yellow :weight bold))))
   `(flycheck-fringe-info ((t (:foreground ,zenburn-cyan :weight bold))))
;;;;; flymake
   `(flymake-errline
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-red)
                   :inherit unspecified :foreground unspecified :background unspecified))
      (t (:foreground ,zenburn-red-1 :weight bold :underline t))))
   `(flymake-warnline
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-orange)
                   :inherit unspecified :foreground unspecified :background unspecified))
      (t (:foreground ,zenburn-orange :weight bold :underline t))))
   `(flymake-infoline
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-green)
                   :inherit unspecified :foreground unspecified :background unspecified))
      (t (:foreground ,zenburn-green-2 :weight bold :underline t))))
   `(flymake-error
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-red)
                   :inherit unspecified :foreground unspecified :background unspecified))
      (t (:foreground ,zenburn-red-1 :weight bold :underline t))))
   `(flymake-warning
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-orange)
                   :inherit unspecified :foreground unspecified :background unspecified))
      (t (:foreground ,zenburn-orange :weight bold :underline t))))
   `(flymake-note
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-green)
                   :inherit unspecified :foreground unspecified :background unspecified))
      (t (:foreground ,zenburn-green-2 :weight bold :underline t))))
   `(flymake-end-of-line-diagnostics-face ((t (:height 0.85 :box (:line-width -1 :color ,zenburn-bg+2)))))
   `(flymake-error-echo ((t (:foreground ,zenburn-red-1 :weight bold))))
   `(flymake-warning-echo ((t (:inherit warning))))
   `(flymake-note-echo ((t (:foreground ,zenburn-green-2 :weight bold))))
;;;;; flyspell
   `(flyspell-duplicate
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-orange) :inherit unspecified))
      (t (:foreground ,zenburn-orange :weight bold :underline t))))
   `(flyspell-incorrect
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-red) :inherit unspecified))
      (t (:foreground ,zenburn-red-1 :weight bold :underline t))))
;;;;; forge
   `(forge-dimmed ((t (:foreground ,zenburn-fg-1))))
   `(forge-topic-header-line ((t (:foreground ,zenburn-fg :weight bold))))
   `(forge-topic-slug-open ((t (:foreground ,zenburn-green+2))))
   `(forge-topic-slug-realized ((t (:foreground ,zenburn-bg+3))))
   `(forge-topic-slug-expunged ((t (:foreground ,zenburn-fg-1 :strike-through t))))
   `(forge-topic-slug-saved ((t (:foreground ,zenburn-blue))))
   `(forge-topic-slug-unread ((t (:foreground ,zenburn-fg :weight bold))))
   `(forge-topic-unread ((t (:foreground ,zenburn-fg :weight bold))))
   `(forge-topic-pending ((t (:foreground ,zenburn-yellow))))
   `(forge-topic-done ((t (:foreground ,zenburn-fg-1))))
   `(forge-discussion-open ((t (:foreground ,zenburn-green+2))))
   `(forge-discussion-completed ((t (:foreground ,zenburn-fg-1))))
   `(forge-discussion-expunged ((t (:foreground ,zenburn-fg-1 :strike-through t))))
   `(forge-issue-open ((t (:foreground ,zenburn-green+2))))
   `(forge-issue-completed ((t (:foreground ,zenburn-fg-1))))
   `(forge-issue-expunged ((t (:foreground ,zenburn-fg-1 :strike-through t))))
   `(forge-pullreq-open ((t (:foreground ,zenburn-green+2))))
   `(forge-pullreq-merged ((t (:foreground ,zenburn-magenta))))
   `(forge-pullreq-rejected ((t (:foreground ,zenburn-red))))
   `(forge-pullreq-draft ((t (:foreground ,zenburn-bg+3 :slant italic))))
   `(forge-topic-label ((t (:box (:line-width -1 :color ,zenburn-bg+2)))))
   `(forge-post-author ((t (:foreground ,zenburn-orange :weight bold))))
   `(forge-post-date ((t (:foreground ,zenburn-blue-1))))
   `(forge-suffix-active ((t (:foreground ,zenburn-green+2 :weight bold))))
   `(forge-suffix-active-and-implied ((t (:foreground ,zenburn-green+2))))
   `(forge-suffix-implied ((t (:foreground ,zenburn-bg+3))))
;;;;; full-ack
   `(ack-separator ((t (:foreground ,zenburn-fg))))
   `(ack-file ((t (:foreground ,zenburn-blue))))
   `(ack-line ((t (:foreground ,zenburn-yellow))))
   `(ack-match ((t (:foreground ,zenburn-orange :background ,zenburn-bg-1 :weight bold))))
;;;;; git-annex
   '(git-annex-dired-annexed-available ((t (:inherit success :weight normal))))
   '(git-annex-dired-annexed-unavailable ((t (:inherit error :weight normal))))
;;;;; git-commit
   `(git-commit-comment-action  ((t (:foreground ,zenburn-green+1 :weight bold))))
   `(git-commit-comment-branch  ((t (:foreground ,zenburn-blue+1  :weight bold)))) ; obsolete
   `(git-commit-comment-branch-local  ((t (:foreground ,zenburn-blue+1  :weight bold))))
   `(git-commit-comment-branch-remote ((t (:foreground ,zenburn-green  :weight bold))))
   `(git-commit-comment-heading ((t (:foreground ,zenburn-yellow  :weight bold))))
;;;;; git-gutter
   `(git-gutter:added ((t (:foreground ,zenburn-green :weight bold :inverse-video t))))
   `(git-gutter:deleted ((t (:foreground ,zenburn-red :weight bold :inverse-video t))))
   `(git-gutter:modified ((t (:foreground ,zenburn-magenta :weight bold :inverse-video t))))
   `(git-gutter:unchanged ((t (:foreground ,zenburn-fg :weight bold :inverse-video t))))
;;;;; git-gutter-fr
   `(git-gutter-fr:added ((t (:foreground ,zenburn-green  :weight bold))))
   `(git-gutter-fr:deleted ((t (:foreground ,zenburn-red :weight bold))))
   `(git-gutter-fr:modified ((t (:foreground ,zenburn-magenta :weight bold))))
;;;;; git-rebase
   `(git-rebase-hash ((t (:foreground, zenburn-orange))))
;;;;; git-timemachine
   `(git-timemachine-commit ((t (:foreground ,zenburn-orange :weight bold))))
   `(git-timemachine-minibuffer-author-face ((t (:foreground ,zenburn-orange))))
   `(git-timemachine-minibuffer-detail-face ((t (:foreground ,zenburn-fg-1))))
;;;;; gnus
   `(gnus-group-mail-1 ((t (:weight bold :inherit gnus-group-mail-1-empty))))
   `(gnus-group-mail-1-empty ((t (:inherit gnus-group-news-1-empty))))
   `(gnus-group-mail-2 ((t (:weight bold :inherit gnus-group-mail-2-empty))))
   `(gnus-group-mail-2-empty ((t (:inherit gnus-group-news-2-empty))))
   `(gnus-group-mail-3 ((t (:weight bold :inherit gnus-group-mail-3-empty))))
   `(gnus-group-mail-3-empty ((t (:inherit gnus-group-news-3-empty))))
   `(gnus-group-mail-4 ((t (:weight bold :inherit gnus-group-mail-4-empty))))
   `(gnus-group-mail-4-empty ((t (:inherit gnus-group-news-4-empty))))
   `(gnus-group-mail-5 ((t (:weight bold :inherit gnus-group-mail-5-empty))))
   `(gnus-group-mail-5-empty ((t (:inherit gnus-group-news-5-empty))))
   `(gnus-group-mail-6 ((t (:weight bold :inherit gnus-group-mail-6-empty))))
   `(gnus-group-mail-6-empty ((t (:inherit gnus-group-news-6-empty))))
   `(gnus-group-mail-low ((t (:weight bold :inherit gnus-group-mail-low-empty))))
   `(gnus-group-mail-low-empty ((t (:inherit gnus-group-news-low-empty))))
   `(gnus-group-news-1 ((t (:weight bold :inherit gnus-group-news-1-empty))))
   `(gnus-group-news-2 ((t (:weight bold :inherit gnus-group-news-2-empty))))
   `(gnus-group-news-3 ((t (:weight bold :inherit gnus-group-news-3-empty))))
   `(gnus-group-news-4 ((t (:weight bold :inherit gnus-group-news-4-empty))))
   `(gnus-group-news-5 ((t (:weight bold :inherit gnus-group-news-5-empty))))
   `(gnus-group-news-6 ((t (:weight bold :inherit gnus-group-news-6-empty))))
   `(gnus-group-news-low ((t (:weight bold :inherit gnus-group-news-low-empty))))
   `(gnus-header-content ((t (:inherit message-header-other))))
   `(gnus-header-from ((t (:inherit message-header-to))))
   `(gnus-header-name ((t (:inherit message-header-name))))
   `(gnus-header-newsgroups ((t (:inherit message-header-other))))
   `(gnus-header-subject ((t (:inherit message-header-subject))))
   `(gnus-server-opened ((t (:foreground ,zenburn-green+2 :weight bold))))
   `(gnus-server-denied ((t (:foreground ,zenburn-red+1 :weight bold))))
   `(gnus-server-closed ((t (:foreground ,zenburn-blue :slant italic))))
   `(gnus-server-offline ((t (:foreground ,zenburn-yellow :weight bold))))
   `(gnus-server-agent ((t (:foreground ,zenburn-blue :weight bold))))
   `(gnus-summary-cancelled ((t (:foreground ,zenburn-orange))))
   `(gnus-summary-high-ancient ((t (:foreground ,zenburn-blue))))
   `(gnus-summary-high-read ((t (:foreground ,zenburn-green :weight bold))))
   `(gnus-summary-high-ticked ((t (:foreground ,zenburn-orange :weight bold))))
   `(gnus-summary-high-unread ((t (:foreground ,zenburn-fg :weight bold))))
   `(gnus-summary-low-ancient ((t (:foreground ,zenburn-blue))))
   `(gnus-summary-low-read ((t (:foreground ,zenburn-green))))
   `(gnus-summary-low-ticked ((t (:foreground ,zenburn-orange :weight bold))))
   `(gnus-summary-low-unread ((t (:foreground ,zenburn-fg))))
   `(gnus-summary-normal-ancient ((t (:foreground ,zenburn-blue))))
   `(gnus-summary-normal-read ((t (:foreground ,zenburn-green))))
   `(gnus-summary-normal-ticked ((t (:foreground ,zenburn-orange :weight bold))))
   `(gnus-summary-normal-unread ((t (:foreground ,zenburn-fg))))
   `(gnus-summary-selected ((t (:foreground ,zenburn-yellow :weight bold))))
   `(gnus-cite-1 ((t (:foreground ,zenburn-blue))))
   `(gnus-cite-10 ((t (:foreground ,zenburn-yellow-1))))
   `(gnus-cite-11 ((t (:foreground ,zenburn-yellow))))
   `(gnus-cite-2 ((t (:foreground ,zenburn-blue-1))))
   `(gnus-cite-3 ((t (:foreground ,zenburn-blue-2))))
   `(gnus-cite-4 ((t (:foreground ,zenburn-green+2))))
   `(gnus-cite-5 ((t (:foreground ,zenburn-green+1))))
   `(gnus-cite-6 ((t (:foreground ,zenburn-green))))
   `(gnus-cite-7 ((t (:foreground ,zenburn-red))))
   `(gnus-cite-8 ((t (:foreground ,zenburn-red-1))))
   `(gnus-cite-9 ((t (:foreground ,zenburn-red-2))))
   `(gnus-group-news-1-empty ((t (:foreground ,zenburn-yellow))))
   `(gnus-group-news-2-empty ((t (:foreground ,zenburn-green+3))))
   `(gnus-group-news-3-empty ((t (:foreground ,zenburn-green+1))))
   `(gnus-group-news-4-empty ((t (:foreground ,zenburn-blue-2))))
   `(gnus-group-news-5-empty ((t (:foreground ,zenburn-blue-3))))
   `(gnus-group-news-6-empty ((t (:foreground ,zenburn-bg+2))))
   `(gnus-group-news-low-empty ((t (:foreground ,zenburn-bg+2))))
   `(gnus-signature ((t (:foreground ,zenburn-yellow))))
   `(gnus-x ((t (:background ,zenburn-fg :foreground ,zenburn-bg))))
   `(mm-uu-extract ((t (:background ,zenburn-bg-05 :foreground ,zenburn-green+1))))
;;;;; go-guru
   `(go-guru-hl-identifier-face ((t (:foreground ,zenburn-bg-1 :background ,zenburn-green+1))))
;;;;; gptel
   `(gptel-context-highlight-face ((t (:background ,zenburn-bg+05 :extend t))))
   `(gptel-context-deletion-face ((t (:background ,zenburn-diff-removed-bg :extend t))))
   `(gptel-rewrite-highlight-face ((t (:background ,zenburn-diff-changed-bg :extend t))))
   `(gptel-response-highlight ((t (:background ,zenburn-bg-05 :extend t))))
   `(gptel-response-fringe-highlight ((t (:foreground ,zenburn-blue))))
;;;;; hackernews
   '(hackernews-comment-count ((t (:inherit link-visited :underline nil))))
   '(hackernews-link          ((t (:inherit link         :underline nil))))
;;;;; haskell-mode
   `(haskell-keyword-face ((t (:inherit font-lock-keyword-face))))
   `(haskell-type-face ((t (:inherit font-lock-type-face))))
   `(haskell-constructor-face ((t (:inherit font-lock-type-face))))
   `(haskell-definition-face ((t (:inherit font-lock-function-name-face))))
   `(haskell-operator-face ((t (:foreground ,zenburn-fg))))
   `(haskell-pragma-face ((t (:inherit font-lock-preprocessor-face))))
   `(haskell-quasi-quote-face ((t (:inherit font-lock-string-face))))
   `(haskell-literate-comment-face ((t (:inherit font-lock-comment-face))))
   `(haskell-hole-face ((t (:foreground ,zenburn-yellow :weight bold))))
   `(haskell-error-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-red) :inherit unspecified))
      (t (:foreground ,zenburn-red-1 :weight bold :underline t))))
   `(haskell-warning-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-orange) :inherit unspecified))
      (t (:foreground ,zenburn-orange :weight bold :underline t))))
   `(haskell-interactive-face-prompt ((t (:foreground ,zenburn-yellow :weight bold))))
   `(haskell-interactive-face-prompt-cont ((t (:foreground ,zenburn-yellow-2))))
   `(haskell-interactive-face-compile-error ((t (:foreground ,zenburn-red :weight bold))))
   `(haskell-interactive-face-compile-warning ((t (:foreground ,zenburn-orange :weight bold))))
   `(haskell-interactive-face-result ((t (:foreground ,zenburn-fg))))
   `(haskell-interactive-face-garbage ((t (:foreground ,zenburn-fg-1))))
;;;;; helm
   `(helm-header
     ((t (:foreground ,zenburn-green
                      :background ,zenburn-bg
                      :underline nil
                      :box nil
                      :extend t))))
   `(helm-source-header
     ((t (:foreground ,zenburn-yellow
                      :background ,zenburn-bg-1
                      :underline nil
                      :weight bold
                      :box (:line-width -1 :style released-button)
                      :extend t))))
   `(helm-selection ((t (:background ,zenburn-bg+1 :underline nil))))
   `(helm-selection-line ((t (:background ,zenburn-bg+1))))
   `(helm-visible-mark ((t (:foreground ,zenburn-bg :background ,zenburn-yellow-2))))
   `(helm-candidate-number ((t (:foreground ,zenburn-green+4 :background ,zenburn-bg-1))))
   `(helm-separator ((t (:foreground ,zenburn-red :background ,zenburn-bg))))
   `(helm-time-zone-current ((t (:foreground ,zenburn-green+2 :background ,zenburn-bg))))
   `(helm-time-zone-home ((t (:foreground ,zenburn-red :background ,zenburn-bg))))
   `(helm-bookmark-addressbook ((t (:foreground ,zenburn-orange :background ,zenburn-bg))))
   `(helm-bookmark-directory ((t (:foreground unspecified :background unspecified :inherit helm-ff-directory))))
   `(helm-bookmark-file ((t (:foreground unspecified :background unspecified :inherit helm-ff-file))))
   `(helm-bookmark-gnus ((t (:foreground ,zenburn-magenta :background ,zenburn-bg))))
   `(helm-bookmark-info ((t (:foreground ,zenburn-green+2 :background ,zenburn-bg))))
   `(helm-bookmark-man ((t (:foreground ,zenburn-yellow :background ,zenburn-bg))))
   `(helm-bookmark-w3m ((t (:foreground ,zenburn-magenta :background ,zenburn-bg))))
   `(helm-buffer-not-saved ((t (:foreground ,zenburn-red :background ,zenburn-bg))))
   `(helm-buffer-process ((t (:foreground ,zenburn-cyan :background ,zenburn-bg))))
   `(helm-buffer-saved-out ((t (:foreground ,zenburn-fg :background ,zenburn-bg))))
   `(helm-buffer-size ((t (:foreground ,zenburn-fg-1 :background ,zenburn-bg))))
   `(helm-ff-directory ((t (:foreground ,zenburn-cyan :background ,zenburn-bg :weight bold))))
   `(helm-ff-file ((t (:foreground ,zenburn-fg :background ,zenburn-bg :weight normal))))
   `(helm-ff-file-extension ((t (:foreground ,zenburn-fg :background ,zenburn-bg :weight normal))))
   `(helm-ff-executable ((t (:foreground ,zenburn-green+2 :background ,zenburn-bg :weight normal))))
   `(helm-ff-invalid-symlink ((t (:foreground ,zenburn-red :background ,zenburn-bg :weight bold))))
   `(helm-ff-symlink ((t (:foreground ,zenburn-yellow :background ,zenburn-bg :weight bold))))
   `(helm-ff-prefix ((t (:foreground ,zenburn-bg :background ,zenburn-yellow :weight normal))))
   `(helm-grep-cmd-line ((t (:foreground ,zenburn-cyan :background ,zenburn-bg))))
   `(helm-grep-file ((t (:foreground ,zenburn-fg :background ,zenburn-bg))))
   `(helm-grep-finish ((t (:foreground ,zenburn-green+2 :background ,zenburn-bg))))
   `(helm-grep-lineno ((t (:foreground ,zenburn-fg-1 :background ,zenburn-bg))))
   `(helm-grep-match ((t (:foreground unspecified :background unspecified :inherit helm-match))))
   `(helm-grep-running ((t (:foreground ,zenburn-red :background ,zenburn-bg))))
   `(helm-match ((t (:foreground ,zenburn-orange :background ,zenburn-bg-1 :weight bold))))
   `(helm-moccur-buffer ((t (:foreground ,zenburn-cyan :background ,zenburn-bg))))
   `(helm-mu-contacts-address-face ((t (:foreground ,zenburn-fg-1 :background ,zenburn-bg))))
   `(helm-mu-contacts-name-face ((t (:foreground ,zenburn-fg :background ,zenburn-bg))))
;;;;; helm-lxc
   `(helm-lxc-face-frozen ((t (:foreground ,zenburn-blue :background ,zenburn-bg))))
   `(helm-lxc-face-running ((t (:foreground ,zenburn-green :background ,zenburn-bg))))
   `(helm-lxc-face-stopped ((t (:foreground ,zenburn-red :background ,zenburn-bg))))
;;;;; helm-swoop
   `(helm-swoop-target-line-face ((t (:foreground ,zenburn-fg :background ,zenburn-bg+1))))
   `(helm-swoop-target-word-face ((t (:foreground ,zenburn-yellow :background ,zenburn-bg+2 :weight bold))))
;;;;; helpful
   `(helpful-heading ((t (:foreground ,zenburn-blue :weight bold :height 1.2))))
;;;;; highlight-numbers
   `(highlight-numbers-number ((t (:foreground ,zenburn-blue))))
;;;;; highlight-thing
   `(highlight-thing ((t (:background ,zenburn-bg+2))))
;;;;; hl-line-mode
   `(hl-line ((t (:background ,zenburn-bg-05 :extend t))))
;;;;; hl-sexp
   `(hl-sexp-face ((t (:background ,zenburn-bg+1))))
;;;;; hl-todo
   `(hl-todo ((t (:foreground ,zenburn-magenta :weight bold))))
;;;;; hydra
   `(hydra-face-red ((t (:foreground ,zenburn-red-1 :background ,zenburn-bg))))
   `(hydra-face-amaranth ((t (:foreground ,zenburn-red-3 :background ,zenburn-bg))))
   `(hydra-face-blue ((t (:foreground ,zenburn-blue :background ,zenburn-bg))))
   `(hydra-face-pink ((t (:foreground ,zenburn-magenta :background ,zenburn-bg))))
   `(hydra-face-teal ((t (:foreground ,zenburn-cyan :background ,zenburn-bg))))
;;;;; info+
   `(info-command-ref-item ((t (:background ,zenburn-bg-1 :foreground ,zenburn-orange))))
   `(info-constant-ref-item ((t (:background ,zenburn-bg-1 :foreground ,zenburn-magenta))))
   `(info-double-quoted-name ((t (:inherit font-lock-comment-face))))
   `(info-file ((t (:background ,zenburn-bg-1 :foreground ,zenburn-yellow))))
   `(info-function-ref-item ((t (:background ,zenburn-bg-1 :inherit font-lock-function-name-face))))
   `(info-macro-ref-item ((t (:background ,zenburn-bg-1 :foreground ,zenburn-yellow))))
   `(info-menu ((t (:foreground ,zenburn-yellow))))
   `(info-quoted-name ((t (:inherit font-lock-constant-face))))
   `(info-reference-item ((t (:background ,zenburn-bg-1))))
   `(info-single-quote ((t (:inherit font-lock-keyword-face))))
   `(info-special-form-ref-item ((t (:background ,zenburn-bg-1 :foreground ,zenburn-yellow))))
   `(info-string ((t (:inherit font-lock-string-face))))
   `(info-syntax-class-item ((t (:background ,zenburn-bg-1 :foreground ,zenburn-blue+1))))
   `(info-user-option-ref-item ((t (:background ,zenburn-bg-1 :foreground ,zenburn-red))))
   `(info-variable-ref-item ((t (:background ,zenburn-bg-1 :foreground ,zenburn-orange))))
;;;;; inf-ruby
   ;; keep the default background, like the cider and eros result overlays
   `(inf-ruby-result-overlay-face ((t (:background unspecified))))
;;;;; ivy
   `(ivy-confirm-face ((t (:foreground ,zenburn-green :background ,zenburn-bg))))
   `(ivy-current-match ((t (:foreground ,zenburn-yellow :weight bold :underline t))))
   `(ivy-cursor ((t (:foreground ,zenburn-bg :background ,zenburn-fg))))
   `(ivy-match-required-face ((t (:foreground ,zenburn-red :background ,zenburn-bg))))
   `(ivy-minibuffer-match-face-1 ((t (:background ,zenburn-bg+1))))
   `(ivy-minibuffer-match-face-2 ((t (:background ,zenburn-green-2))))
   `(ivy-minibuffer-match-face-3 ((t (:background ,zenburn-green))))
   `(ivy-minibuffer-match-face-4 ((t (:background ,zenburn-green+1))))
   `(ivy-remote ((t (:foreground ,zenburn-blue :background ,zenburn-bg))))
   `(ivy-subdir ((t (:foreground ,zenburn-yellow :background ,zenburn-bg))))
;;;;; ido-mode
   `(ido-first-match ((t (:foreground ,zenburn-yellow :weight bold))))
   `(ido-only-match ((t (:foreground ,zenburn-orange :weight bold))))
   `(ido-subdir ((t (:foreground ,zenburn-yellow))))
   `(ido-indicator ((t (:foreground ,zenburn-yellow :background ,zenburn-red-4))))
;;;;; iedit-mode
   `(iedit-occurrence ((t (:background ,zenburn-bg+2 :weight bold))))
;;;;; jinx
   `(jinx-misspelled
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-red) :inherit unspecified))
      (t (:foreground ,zenburn-red-1 :weight bold :underline t))))
   `(jinx-highlight ((t (:inherit isearch))))
   `(jinx-save ((t (:foreground ,zenburn-green+2 :weight bold))))
   `(jinx-key ((t (:foreground ,zenburn-blue :weight bold))))
   `(jinx-annotation ((t (:foreground ,zenburn-fg-1))))
;;;;; js2-mode
   `(js2-warning ((t (:underline ,zenburn-orange))))
   `(js2-error ((t (:inherit error))))
   `(js2-jsdoc-tag ((t (:foreground ,zenburn-green-2))))
   `(js2-jsdoc-type ((t (:inherit font-lock-doc-face))))
   `(js2-jsdoc-value ((t (:foreground ,zenburn-green+3))))
   `(js2-function-param ((t (:foreground, zenburn-orange))))
   `(js2-external-variable ((t (:foreground ,zenburn-orange))))
;;;;; additional js2 mode attributes for better syntax highlighting
   `(js2-instance-member ((t (:foreground ,zenburn-green-2))))
   `(js2-jsdoc-html-tag-delimiter ((t (:foreground ,zenburn-orange))))
   `(js2-jsdoc-html-tag-name ((t (:foreground ,zenburn-red-1))))
   `(js2-object-property ((t (:foreground ,zenburn-blue+1))))
   `(js2-magic-paren ((t (:foreground ,zenburn-blue-5))))
   `(js2-private-function-call ((t (:foreground ,zenburn-cyan))))
   `(js2-function-call ((t (:foreground ,zenburn-cyan))))
   `(js2-private-member ((t (:foreground ,zenburn-blue-1))))
   `(js2-keywords ((t (:foreground ,zenburn-magenta))))
;;;;; keycast
   `(keycast-key ((t (:foreground ,zenburn-bg :background ,zenburn-blue :weight bold))))
   `(keycast-command ((t (:weight bold))))
;;;;; ledger-mode
   `(ledger-font-payee-uncleared-face ((t (:foreground ,zenburn-red-1 :weight bold))))
   `(ledger-font-payee-cleared-face ((t (:foreground ,zenburn-fg :weight normal))))
   `(ledger-font-payee-pending-face ((t (:foreground ,zenburn-red :weight normal))))
   `(ledger-font-xact-highlight-face ((t (:background ,zenburn-bg+1))))
   `(ledger-font-auto-xact-face ((t (:foreground ,zenburn-yellow-1 :weight normal))))
   `(ledger-font-periodic-xact-face ((t (:foreground ,zenburn-green :weight normal))))
   `(ledger-font-pending-face ((t (:foreground ,zenburn-orange :weight normal))))
   `(ledger-font-other-face ((t (:foreground ,zenburn-fg))))
   `(ledger-font-posting-date-face ((t (:foreground ,zenburn-orange :weight normal))))
   `(ledger-font-posting-account-face ((t (:foreground ,zenburn-blue-1))))
   `(ledger-font-posting-account-cleared-face ((t (:foreground ,zenburn-fg))))
   `(ledger-font-posting-account-pending-face ((t (:foreground ,zenburn-orange))))
   `(ledger-font-posting-amount-face ((t (:foreground ,zenburn-orange))))
   `(ledger-occur-narrowed-face ((t (:foreground ,zenburn-fg-1 :invisible t))))
   `(ledger-occur-xact-face ((t (:background ,zenburn-bg+1))))
   `(ledger-font-comment-face ((t (:inherit font-lock-comment-face))))
   `(ledger-font-reconciler-uncleared-face ((t (:foreground ,zenburn-red-1 :weight bold))))
   `(ledger-font-reconciler-cleared-face ((t (:foreground ,zenburn-fg :weight normal))))
   `(ledger-font-reconciler-pending-face ((t (:foreground ,zenburn-orange :weight normal))))
   `(ledger-font-report-clickable-face ((t (:foreground ,zenburn-orange :weight normal))))
;;;;; lispy
   `(lispy-command-name-face ((t (:background ,zenburn-bg-05 :inherit font-lock-function-name-face))))
   `(lispy-cursor-face ((t (:foreground ,zenburn-bg :background ,zenburn-fg))))
   `(lispy-face-hint ((t (:inherit highlight :foreground ,zenburn-yellow))))
;;;;; lsp-mode
   `(lsp-face-highlight-textual ((t (:background ,zenburn-bg+2))))
   `(lsp-face-highlight-read ((t (:background ,zenburn-bg+2))))
   `(lsp-face-highlight-write ((t (:background ,zenburn-bg+2 :weight bold))))
;;;;; lsp-ui
   `(lsp-ui-doc-background ((t (:background ,zenburn-bg-05))))
   `(lsp-ui-doc-header ((t (:foreground ,zenburn-fg :background ,zenburn-blue-4 :weight bold))))
   `(lsp-ui-doc-highlight-hover ((t (:background ,zenburn-bg+2))))
   `(lsp-ui-doc-url ((t (:foreground ,zenburn-blue :underline t))))
   `(lsp-ui-peek-peek ((t (:background ,zenburn-bg-05))))
   `(lsp-ui-peek-list ((t (:background ,zenburn-bg-05))))
   `(lsp-ui-peek-filename ((t (:foreground ,zenburn-orange :weight bold))))
   `(lsp-ui-peek-line-number ((t (:foreground ,zenburn-bg+3))))
   `(lsp-ui-peek-highlight ((t (:foreground ,zenburn-magenta :weight bold :box (:line-width -1 :color ,zenburn-magenta)))))
   `(lsp-ui-peek-header ((t (:foreground ,zenburn-fg :background ,zenburn-blue-4 :weight bold))))
   `(lsp-ui-peek-footer ((t (:foreground ,zenburn-fg :background ,zenburn-blue-4))))
   `(lsp-ui-peek-selection ((t (:foreground ,zenburn-fg :background ,zenburn-bg+2 :weight bold))))
   `(lsp-ui-sideline-symbol ((t (:foreground ,zenburn-bg+3 :box (:line-width -1 :color ,zenburn-bg+3)))))
   `(lsp-ui-sideline-current-symbol ((t (:foreground ,zenburn-fg :weight bold :box (:line-width -1 :color ,zenburn-fg)))))
   `(lsp-ui-sideline-code-action ((t (:foreground ,zenburn-yellow))))
   `(lsp-ui-sideline-symbol-info ((t (:foreground ,zenburn-fg-1 :slant italic))))
   `(lsp-ui-sideline-global ((t (:foreground ,zenburn-fg-1))))
;;;;; ruler-mode
   `(ruler-mode-column-number ((t (:inherit ruler-mode-default :foreground ,zenburn-fg))))
   `(ruler-mode-fill-column ((t (:inherit ruler-mode-default :foreground ,zenburn-yellow))))
   `(ruler-mode-goal-column ((t (:inherit ruler-mode-fill-column))))
   `(ruler-mode-comment-column ((t (:inherit ruler-mode-fill-column))))
   `(ruler-mode-tab-stop ((t (:inherit ruler-mode-fill-column))))
   `(ruler-mode-current-column ((t (:foreground ,zenburn-yellow :box t))))
   `(ruler-mode-default ((t (:foreground ,zenburn-green+2 :background ,zenburn-bg))))

;;;;; lui
   `(lui-time-stamp-face ((t (:foreground ,zenburn-blue-1))))
   `(lui-hilight-face ((t (:foreground ,zenburn-green+2 :background ,zenburn-bg))))
   `(lui-button-face ((t (:foreground ,zenburn-blue-1 :underline t))))
;;;;; macrostep
   `(macrostep-gensym-1
     ((t (:foreground ,zenburn-green+2 :background ,zenburn-bg-1))))
   `(macrostep-gensym-2
     ((t (:foreground ,zenburn-red+1 :background ,zenburn-bg-1))))
   `(macrostep-gensym-3
     ((t (:foreground ,zenburn-blue+1 :background ,zenburn-bg-1))))
   `(macrostep-gensym-4
     ((t (:foreground ,zenburn-magenta :background ,zenburn-bg-1))))
   `(macrostep-gensym-5
     ((t (:foreground ,zenburn-yellow :background ,zenburn-bg-1))))
   `(macrostep-expansion-highlight-face
     ((t (:inherit highlight))))
   `(macrostep-macro-face
     ((t (:underline t))))
;;;;; magit
;;;;;; headings and diffs
   ;; Please read (info "(magit)Theming Faces") before changing this.
   `(magit-section-highlight           ((t (:background ,zenburn-bg+05))))
   `(magit-section-heading             ((t (:foreground ,zenburn-yellow :weight bold))))
   `(magit-section-heading-selection   ((t (:foreground ,zenburn-orange :weight bold))))
   `(magit-diff-file-heading           ((t (:weight bold))))
   `(magit-diff-file-heading-highlight ((t (:background ,zenburn-bg+05 :weight bold))))
   `(magit-diff-file-heading-selection ((t (:background ,zenburn-bg+05 :weight bold
                                                        :foreground ,zenburn-orange))))
   `(magit-diff-added                  ((t (:background ,zenburn-green-2))))
   `(magit-diff-added-highlight        ((t (:background ,zenburn-green))))
   `(magit-diff-removed                ((t (:background ,zenburn-red-4))))
   `(magit-diff-removed-highlight      ((t (:background ,zenburn-red-3))))
   `(magit-diff-hunk-heading           ((t (:background ,zenburn-bg+1))))
   `(magit-diff-hunk-heading-highlight ((t (:background ,zenburn-bg+2))))
   `(magit-diff-hunk-heading-selection ((t (:background ,zenburn-bg+2
                                                        :foreground ,zenburn-orange))))
   `(magit-diff-lines-heading          ((t (:background ,zenburn-orange
                                                        :foreground ,zenburn-bg+2))))
   `(magit-diff-context-highlight      ((t (:background ,zenburn-bg+05
                                                        :foreground "grey70"))))
   `(magit-diffstat-added              ((t (:foreground ,zenburn-green+4))))
   `(magit-diffstat-removed            ((t (:foreground ,zenburn-red))))
;;;;;; popup
   `(magit-popup-heading             ((t (:foreground ,zenburn-yellow  :weight bold))))
   `(magit-popup-key                 ((t (:foreground ,zenburn-green-2 :weight bold))))
   `(magit-popup-argument            ((t (:foreground ,zenburn-green   :weight bold))))
   `(magit-popup-disabled-argument   ((t (:foreground ,zenburn-fg-1    :weight normal))))
   `(magit-popup-option-value        ((t (:foreground ,zenburn-blue-2  :weight bold))))
;;;;;; process
   `(magit-process-ok    ((t (:foreground ,zenburn-green  :weight bold))))
   `(magit-process-ng    ((t (:foreground ,zenburn-red    :weight bold))))
;;;;;; log
   `(magit-log-author    ((t (:foreground ,zenburn-orange))))
   `(magit-log-date      ((t (:foreground ,zenburn-fg-1))))
   `(magit-log-graph     ((t (:foreground ,zenburn-fg+1))))
;;;;;; sequence
   `(magit-sequence-pick ((t (:foreground ,zenburn-yellow-2))))
   `(magit-sequence-stop ((t (:foreground ,zenburn-green))))
   `(magit-sequence-part ((t (:foreground ,zenburn-yellow))))
   `(magit-sequence-head ((t (:foreground ,zenburn-blue))))
   `(magit-sequence-drop ((t (:foreground ,zenburn-red))))
   `(magit-sequence-done ((t (:foreground ,zenburn-fg-1))))
   `(magit-sequence-onto ((t (:foreground ,zenburn-fg-1))))
;;;;;; bisect
   `(magit-bisect-good ((t (:foreground ,zenburn-green))))
   `(magit-bisect-skip ((t (:foreground ,zenburn-yellow))))
   `(magit-bisect-bad  ((t (:foreground ,zenburn-red))))
;;;;;; blame
   `(magit-blame-heading ((t (:background ,zenburn-bg-1 :foreground ,zenburn-blue-2))))
   `(magit-blame-hash    ((t (:background ,zenburn-bg-1 :foreground ,zenburn-blue-2))))
   `(magit-blame-name    ((t (:background ,zenburn-bg-1 :foreground ,zenburn-orange))))
   `(magit-blame-date    ((t (:background ,zenburn-bg-1 :foreground ,zenburn-orange))))
   `(magit-blame-summary ((t (:background ,zenburn-bg-1 :foreground ,zenburn-blue-2
                                          :weight bold))))
;;;;;; references etc
   `(magit-dimmed         ((t (:foreground ,zenburn-bg+3))))
   `(magit-hash           ((t (:foreground ,zenburn-bg+3))))
   `(magit-tag            ((t (:foreground ,zenburn-orange :weight bold))))
   `(magit-branch-remote  ((t (:foreground ,zenburn-green  :weight bold))))
   `(magit-branch-local   ((t (:foreground ,zenburn-blue   :weight bold))))
   `(magit-branch-current ((t (:foreground ,zenburn-blue   :weight bold :box t))))
   `(magit-head           ((t (:foreground ,zenburn-blue   :weight bold))))
   `(magit-refname        ((t (:background ,zenburn-bg+2 :foreground ,zenburn-fg :weight bold))))
   `(magit-refname-stash  ((t (:background ,zenburn-bg+2 :foreground ,zenburn-fg :weight bold))))
   `(magit-refname-wip    ((t (:background ,zenburn-bg+2 :foreground ,zenburn-fg :weight bold))))
   `(magit-signature-good      ((t (:foreground ,zenburn-green))))
   `(magit-signature-bad       ((t (:foreground ,zenburn-red))))
   `(magit-signature-untrusted ((t (:foreground ,zenburn-yellow))))
   `(magit-signature-expired   ((t (:foreground ,zenburn-orange))))
   `(magit-signature-revoked   ((t (:foreground ,zenburn-magenta))))
   '(magit-signature-error     ((t (:inherit    magit-signature-bad))))
   `(magit-cherry-unmatched    ((t (:foreground ,zenburn-cyan))))
   `(magit-cherry-equivalent   ((t (:foreground ,zenburn-magenta))))
   `(magit-reflog-commit       ((t (:foreground ,zenburn-green))))
   `(magit-reflog-amend        ((t (:foreground ,zenburn-magenta))))
   `(magit-reflog-merge        ((t (:foreground ,zenburn-green))))
   `(magit-reflog-checkout     ((t (:foreground ,zenburn-blue))))
   `(magit-reflog-reset        ((t (:foreground ,zenburn-red))))
   `(magit-reflog-rebase       ((t (:foreground ,zenburn-magenta))))
   `(magit-reflog-cherry-pick  ((t (:foreground ,zenburn-green))))
   `(magit-reflog-remote       ((t (:foreground ,zenburn-cyan))))
   `(magit-reflog-other        ((t (:foreground ,zenburn-cyan))))
;;;;; marginalia
   `(marginalia-key ((t (:foreground ,zenburn-blue))))
   `(marginalia-type ((t (:foreground ,zenburn-cyan))))
   `(marginalia-char ((t (:foreground ,zenburn-orange))))
   `(marginalia-lighter ((t (:foreground ,zenburn-bg+3))))
   `(marginalia-on ((t (:foreground ,zenburn-green))))
   `(marginalia-off ((t (:foreground ,zenburn-fg-1))))
   `(marginalia-documentation ((t (:foreground ,zenburn-green :slant italic))))
   `(marginalia-value ((t (:foreground ,zenburn-fg-1))))
   `(marginalia-null ((t (:foreground ,zenburn-fg-1))))
   `(marginalia-true ((t (:foreground ,zenburn-green))))
   `(marginalia-function ((t (:foreground ,zenburn-blue))))
   `(marginalia-symbol ((t (:foreground ,zenburn-magenta))))
   `(marginalia-list ((t (:foreground ,zenburn-cyan))))
   `(marginalia-mode ((t (:foreground ,zenburn-blue-1))))
   `(marginalia-date ((t (:foreground ,zenburn-blue-1))))
   `(marginalia-version ((t (:foreground ,zenburn-cyan))))
   `(marginalia-archive ((t (:foreground ,zenburn-magenta))))
   `(marginalia-installed ((t (:foreground ,zenburn-green))))
   `(marginalia-size ((t (:foreground ,zenburn-bg+3))))
   `(marginalia-number ((t (:foreground ,zenburn-orange))))
   `(marginalia-string ((t (:foreground ,zenburn-red))))
   `(marginalia-modified ((t (:foreground ,zenburn-yellow))))
   `(marginalia-file-name ((t (:foreground ,zenburn-fg-1))))
   `(marginalia-file-owner ((t (:foreground ,zenburn-fg-1))))
   `(marginalia-file-priv-no ((t (:foreground ,zenburn-fg-1))))
   `(marginalia-file-priv-dir ((t (:foreground ,zenburn-blue :weight bold))))
   `(marginalia-file-priv-link ((t (:foreground ,zenburn-cyan))))
   `(marginalia-file-priv-read ((t (:foreground ,zenburn-yellow))))
   `(marginalia-file-priv-write ((t (:foreground ,zenburn-red))))
   `(marginalia-file-priv-exec ((t (:foreground ,zenburn-green))))
   `(marginalia-file-priv-other ((t (:foreground ,zenburn-magenta))))
   `(marginalia-file-priv-rare ((t (:foreground ,zenburn-orange))))
;;;;; markup-faces
   `(markup-anchor-face ((t (:foreground ,zenburn-blue+1))))
   `(markup-code-face ((t (:inherit font-lock-constant-face))))
   `(markup-command-face ((t (:foreground ,zenburn-yellow))))
   `(markup-emphasis-face ((t (:inherit bold))))
   `(markup-internal-reference-face ((t (:foreground ,zenburn-yellow-2 :underline t))))
   `(markup-list-face ((t (:foreground ,zenburn-fg+1))))
   `(markup-meta-face ((t (:foreground ,zenburn-yellow))))
   `(markup-meta-hide-face ((t (:foreground ,zenburn-yellow))))
   `(markup-secondary-text-face ((t (:foreground ,zenburn-yellow-1))))
   `(markup-title-0-face ((t (:inherit font-lock-function-name-face :weight bold))))
   `(markup-title-1-face ((t (:inherit font-lock-function-name-face :weight bold))))
   `(markup-title-2-face ((t (:inherit font-lock-function-name-face :weight bold))))
   `(markup-title-3-face ((t (:inherit font-lock-function-name-face :weight bold))))
   `(markup-title-4-face ((t (:inherit font-lock-function-name-face :weight bold))))
   `(markup-typewriter-face ((t (:inherit font-lock-constant-face))))
   `(markup-verbatim-face ((t (:inherit font-lock-constant-face))))
   `(markup-value-face ((t (:foreground ,zenburn-yellow))))
;;;;; message-mode
   `(message-cited-text ((t (:inherit font-lock-comment-face))))
   `(message-header-name ((t (:foreground ,zenburn-green+1))))
   `(message-header-other ((t (:foreground ,zenburn-green))))
   `(message-header-to ((t (:foreground ,zenburn-yellow :weight bold))))
   `(message-header-cc ((t (:foreground ,zenburn-yellow :weight bold))))
   `(message-header-newsgroups ((t (:foreground ,zenburn-yellow :weight bold))))
   `(message-header-subject ((t (:foreground ,zenburn-orange :weight bold))))
   `(message-header-xheader ((t (:foreground ,zenburn-green))))
   `(message-mml ((t (:foreground ,zenburn-yellow :weight bold))))
   `(message-separator ((t (:inherit font-lock-comment-face))))
;;;;; mic-paren
   `(paren-face-match ((t (:foreground ,zenburn-cyan :background ,zenburn-bg :weight bold))))
   `(paren-face-mismatch ((t (:foreground ,zenburn-bg :background ,zenburn-magenta :weight bold))))
   `(paren-face-no-match ((t (:foreground ,zenburn-bg :background ,zenburn-red :weight bold))))
;;;;; mistty
   `(mistty-fringe-face ((t (:foreground ,zenburn-bg+2))))
;;;;; multiple-cursors
   `(mc/cursor-face ((t (:inverse-video nil :background ,zenburn-bg+2 :foreground ,zenburn-fg))))
   `(mc/cursor-bar-face ((t (:background ,zenburn-fg :height 1))))
   `(mc/region-face ((t (:inherit region))))
;;;;; mingus
   `(mingus-directory-face ((t (:foreground ,zenburn-blue))))
   `(mingus-pausing-face ((t (:foreground ,zenburn-magenta))))
   `(mingus-playing-face ((t (:foreground ,zenburn-cyan))))
   `(mingus-playlist-face ((t (:foreground ,zenburn-cyan ))))
   `(mingus-mark-face ((t (:bold t :foreground ,zenburn-magenta))))
   `(mingus-song-file-face ((t (:foreground ,zenburn-yellow))))
   `(mingus-artist-face ((t (:foreground ,zenburn-cyan))))
   `(mingus-album-face ((t (:underline t :foreground ,zenburn-red+1))))
   `(mingus-album-stale-face ((t (:foreground ,zenburn-red+1))))
   `(mingus-stopped-face ((t (:foreground ,zenburn-red))))
;;;;; merlin
   `(merlin-type-face ((t (:inherit highlight))))
   `(merlin-compilation-warning-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-orange)))
      (t
       (:underline ,zenburn-orange))))
   `(merlin-compilation-error-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-red)))
      (t
       (:underline ,zenburn-red))))
;;;;; mu4e
   `(mu4e-cited-1-face ((t (:foreground ,zenburn-blue    :slant italic))))
   `(mu4e-cited-2-face ((t (:foreground ,zenburn-green+2 :slant italic))))
   `(mu4e-cited-3-face ((t (:foreground ,zenburn-blue-2  :slant italic))))
   `(mu4e-cited-4-face ((t (:foreground ,zenburn-green   :slant italic))))
   `(mu4e-cited-5-face ((t (:foreground ,zenburn-blue-4  :slant italic))))
   `(mu4e-cited-6-face ((t (:foreground ,zenburn-green-2 :slant italic))))
   `(mu4e-cited-7-face ((t (:foreground ,zenburn-blue    :slant italic))))
   `(mu4e-replied-face ((t (:foreground ,zenburn-bg+3))))
   `(mu4e-trashed-face ((t (:foreground ,zenburn-bg+3 :strike-through t))))
;;;;; nerd-icons
   `(nerd-icons-red ((t (:foreground ,zenburn-red))))
   `(nerd-icons-lred ((t (:foreground ,zenburn-red+1))))
   `(nerd-icons-dred ((t (:foreground ,zenburn-red-2))))
   `(nerd-icons-green ((t (:foreground ,zenburn-green))))
   `(nerd-icons-lgreen ((t (:foreground ,zenburn-green+2))))
   `(nerd-icons-dgreen ((t (:foreground ,zenburn-green-2))))
   `(nerd-icons-yellow ((t (:foreground ,zenburn-yellow))))
   `(nerd-icons-lyellow ((t (:foreground ,zenburn-yellow-1))))
   `(nerd-icons-dyellow ((t (:foreground ,zenburn-yellow-2))))
   `(nerd-icons-blue ((t (:foreground ,zenburn-blue))))
   `(nerd-icons-lblue ((t (:foreground ,zenburn-blue+1))))
   `(nerd-icons-dblue ((t (:foreground ,zenburn-blue-2))))
   `(nerd-icons-maroon ((t (:foreground ,zenburn-red-3))))
   `(nerd-icons-lmaroon ((t (:foreground ,zenburn-red-2))))
   `(nerd-icons-dmaroon ((t (:foreground ,zenburn-red-4))))
   `(nerd-icons-purple ((t (:foreground ,zenburn-magenta))))
   `(nerd-icons-lpurple ((t (:foreground ,zenburn-magenta))))
   `(nerd-icons-dpurple ((t (:foreground ,zenburn-magenta))))
   `(nerd-icons-orange ((t (:foreground ,zenburn-orange))))
   `(nerd-icons-lorange ((t (:foreground ,zenburn-orange))))
   `(nerd-icons-dorange ((t (:foreground ,zenburn-orange))))
   `(nerd-icons-cyan ((t (:foreground ,zenburn-cyan))))
   `(nerd-icons-lcyan ((t (:foreground ,zenburn-blue+2))))
   `(nerd-icons-dcyan ((t (:foreground ,zenburn-blue-1))))
   `(nerd-icons-pink ((t (:foreground ,zenburn-red+1))))
   `(nerd-icons-lpink ((t (:foreground ,zenburn-red+2))))
   `(nerd-icons-dpink ((t (:foreground ,zenburn-red-1))))
   `(nerd-icons-silver ((t (:foreground ,zenburn-fg-1))))
   `(nerd-icons-lsilver ((t (:foreground ,zenburn-fg))))
   `(nerd-icons-dsilver ((t (:foreground ,zenburn-bg+3))))
;;;;; neotree
   `(neo-banner-face ((t (:foreground ,zenburn-blue+1 :weight bold))))
   `(neo-header-face ((t (:foreground ,zenburn-fg))))
   `(neo-root-dir-face ((t (:foreground ,zenburn-blue+1 :weight bold))))
   `(neo-dir-link-face ((t (:foreground ,zenburn-blue))))
   `(neo-file-link-face ((t (:foreground ,zenburn-fg))))
   `(neo-expand-btn-face ((t (:foreground ,zenburn-blue))))
   `(neo-vc-default-face ((t (:foreground ,zenburn-fg+1))))
   `(neo-vc-user-face ((t (:foreground ,zenburn-red :slant italic))))
   `(neo-vc-up-to-date-face ((t (:foreground ,zenburn-fg))))
   `(neo-vc-edited-face ((t (:foreground ,zenburn-magenta))))
   `(neo-vc-needs-merge-face ((t (:foreground ,zenburn-red+1))))
   `(neo-vc-unlocked-changes-face ((t (:foreground ,zenburn-red :background ,zenburn-blue-5))))
   `(neo-vc-added-face ((t (:foreground ,zenburn-green+1))))
   `(neo-vc-conflict-face ((t (:foreground ,zenburn-red+1))))
   `(neo-vc-missing-face ((t (:foreground ,zenburn-red+1))))
   `(neo-vc-ignored-face ((t (:foreground ,zenburn-fg-1))))
;;;;; notmuch
   `(notmuch-crypto-decryption ((t (:foreground ,zenburn-bg :background ,zenburn-magenta))))
   `(notmuch-crypto-part-header ((t (:foreground ,zenburn-blue+1))))
   `(notmuch-crypto-signature-bad ((t (:foreground ,zenburn-bg :background ,zenburn-red))))
   `(notmuch-crypto-signature-good ((t (:foreground ,zenburn-bg :background ,zenburn-green+1))))
   `(notmuch-crypto-signature-good-key ((t (:foreground ,zenburn-bg :background ,zenburn-orange))))
   `(notmuch-crypto-signature-unknown ((t (:foreground ,zenburn-bg :background ,zenburn-red))))
   `(notmuch-hello-logo-background ((t (:background ,zenburn-bg+2))))
   `(notmuch-message-summary-face ((t (:background ,zenburn-bg-08))))
   `(notmuch-search-flagged-face ((t (:foreground ,zenburn-blue+1))))
   `(notmuch-search-non-matching-authors ((t (:foreground ,zenburn-fg-1))))
   `(notmuch-tag-added ((t (:underline ,zenburn-green+1))))
   `(notmuch-tag-deleted ((t (:strike-through ,zenburn-red))))
   `(notmuch-tag-face ((t (:foreground ,zenburn-green+1))))
   `(notmuch-tag-flagged ((t (:foreground ,zenburn-blue+1))))
   `(notmuch-tag-unread ((t (:foreground ,zenburn-red))))
   `(notmuch-tree-match-author-face ((t (:foreground ,zenburn-green+1))))
   `(notmuch-tree-match-tag-face ((t (:foreground ,zenburn-green+1))))
;;;;; orderless
   `(orderless-match-face-0 ((t (:foreground ,zenburn-green))))
   `(orderless-match-face-1 ((t (:foreground ,zenburn-magenta))))
   `(orderless-match-face-2 ((t (:foreground ,zenburn-blue))))
   `(orderless-match-face-3 ((t (:foreground ,zenburn-orange))))
;;;;; org-mode
   `(org-agenda-date-today
     ((t (:foreground ,zenburn-fg+1 :slant italic :weight bold))) t)
   `(org-agenda-structure
     ((t (:inherit font-lock-comment-face))))
   `(org-archived ((t (:foreground ,zenburn-fg :weight bold))))
   `(org-block ((t (:background ,zenburn-bg+05 :extend t))))
   `(org-checkbox ((t (:background ,zenburn-bg+2 :foreground ,zenburn-fg+1
                                   :box (:line-width 1 :style released-button)))))
   `(org-date ((t (:foreground ,zenburn-blue :underline t))))
   `(org-deadline-announce ((t (:foreground ,zenburn-red-1))))
   `(org-done ((t (:weight bold :foreground ,zenburn-green+3))))
   `(org-formula ((t (:foreground ,zenburn-yellow-2))))
   `(org-headline-done ((t (:foreground ,zenburn-green+3))))
   `(org-hide ((t (:foreground ,zenburn-bg))))
   `(org-level-1 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-orange
                               ,@(when zenburn-scale-org-headlines
                                   (list :height zenburn-height-plus-4))))))
   `(org-level-2 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-green+4
                               ,@(when zenburn-scale-org-headlines
                                   (list :height zenburn-height-plus-3))))))
   `(org-level-3 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-blue-1
                               ,@(when zenburn-scale-org-headlines
                                   (list :height zenburn-height-plus-2))))))
   `(org-level-4 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-yellow-2
                               ,@(when zenburn-scale-org-headlines
                                   (list :height zenburn-height-plus-1))))))
   `(org-level-5 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-cyan))))
   `(org-level-6 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-green+2))))
   `(org-level-7 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-red+2))))
   `(org-level-8 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-magenta))))
   `(org-link ((t (:foreground ,zenburn-yellow-2 :underline t))))
   `(org-quote ((t (:background ,zenburn-bg+05 :extend t))))
   `(org-scheduled ((t (:foreground ,zenburn-green+4))))
   `(org-scheduled-previously ((t (:foreground ,zenburn-red))))
   `(org-scheduled-today ((t (:foreground ,zenburn-blue+1))))
   `(org-sexp-date ((t (:foreground ,zenburn-blue+1 :underline t))))
   `(org-special-keyword ((t (:inherit font-lock-comment-face))))
   `(org-table ((t (:foreground ,zenburn-green+2))))
   `(org-tag ((t (:weight bold))))
   `(org-time-grid ((t (:foreground ,zenburn-orange))))
   `(org-todo ((t (:weight bold :foreground ,zenburn-red))))
   `(org-upcoming-deadline ((t (:inherit font-lock-keyword-face))))
   `(org-warning ((t (:weight bold :foreground ,zenburn-red :underline nil))))
   `(org-column ((t (:background ,zenburn-bg-1))))
   `(org-column-title ((t (:background ,zenburn-bg-1 :underline t :weight bold))))
   `(org-mode-line-clock ((t (:foreground ,zenburn-fg :background ,zenburn-bg-1))))
   `(org-mode-line-clock-overrun ((t (:foreground ,zenburn-bg :background ,zenburn-red-1))))
   `(org-ellipsis ((t (:foreground ,zenburn-yellow-1 :underline t))))
   `(org-footnote ((t (:foreground ,zenburn-cyan :underline t))))
   `(org-document-title ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-blue
                                      :weight bold
                                      ,@(when zenburn-scale-org-headlines
                                          (list :height zenburn-height-plus-4))))))
   `(org-document-info ((t (:foreground ,zenburn-blue))))
   `(org-habit-ready-face ((t :background ,zenburn-green)))
   `(org-habit-alert-face ((t :background ,zenburn-yellow-1 :foreground ,zenburn-bg)))
   `(org-habit-clear-face ((t :background ,zenburn-blue-3)))
   `(org-habit-overdue-face ((t :background ,zenburn-red-3)))
   `(org-habit-clear-future-face ((t :background ,zenburn-blue-4)))
   `(org-habit-ready-future-face ((t :background ,zenburn-green-2)))
   `(org-habit-alert-future-face ((t :background ,zenburn-yellow-2 :foreground ,zenburn-bg)))
   `(org-habit-overdue-future-face ((t :background ,zenburn-red-4)))
;;;;; org-ref
   `(org-ref-ref-face ((t :underline t)))
   `(org-ref-label-face ((t :underline t)))
   `(org-ref-cite-face ((t :underline t)))
   `(org-ref-glossary-face ((t :underline t)))
   `(org-ref-acronym-face ((t :underline t)))
;;;;; outline
   `(outline-1 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-orange
                             ,@(when zenburn-scale-outline-headlines
                                 (list :height zenburn-height-plus-4))))))
   `(outline-2 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-green+4
                             ,@(when zenburn-scale-outline-headlines
                                 (list :height zenburn-height-plus-3))))))
   `(outline-3 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-blue-1
                             ,@(when zenburn-scale-outline-headlines
                                 (list :height zenburn-height-plus-2))))))
   `(outline-4 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-yellow-2
                             ,@(when zenburn-scale-outline-headlines
                                 (list :height zenburn-height-plus-1))))))
   `(outline-5 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-cyan))))
   `(outline-6 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-green+2))))
   `(outline-7 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-red-4))))
   `(outline-8 ((t (:inherit zenburn-variable-pitch :foreground ,zenburn-blue-4))))
;;;;; p4
   `(p4-depot-added-face ((t :inherit diff-added)))
   `(p4-depot-branch-op-face ((t :inherit diff-changed)))
   `(p4-depot-deleted-face ((t :inherit diff-removed)))
   `(p4-depot-unmapped-face ((t :inherit diff-changed)))
   `(p4-diff-change-face ((t :inherit diff-changed)))
   `(p4-diff-del-face ((t :inherit diff-removed)))
   `(p4-diff-file-face ((t :inherit diff-file-header)))
   `(p4-diff-head-face ((t :inherit diff-header)))
   `(p4-diff-ins-face ((t :inherit diff-added)))
;;;;; c/perl
   `(cperl-nonoverridable-face ((t (:foreground ,zenburn-magenta))))
   `(cperl-array-face ((t (:foreground ,zenburn-yellow, :background ,zenburn-bg))))
   `(cperl-hash-face ((t (:foreground ,zenburn-yellow-1, :background ,zenburn-bg))))
;;;;; paren-face
   `(parenthesis ((t (:foreground ,zenburn-fg-1))))
;;;;; perspective
   `(persp-selected-face ((t (:foreground ,zenburn-yellow-2))))
;;;;; powerline
   `(powerline-active1 ((t (:background ,zenburn-bg-05 :inherit mode-line))))
   `(powerline-active2 ((t (:background ,zenburn-bg+2 :inherit mode-line))))
   `(powerline-inactive1 ((t (:background ,zenburn-bg+1 :inherit mode-line-inactive))))
   `(powerline-inactive2 ((t (:background ,zenburn-bg+3 :inherit mode-line-inactive))))
;;;;; proofgeneral
   `(proof-active-area-face ((t (:underline t))))
   `(proof-boring-face ((t (:foreground ,zenburn-fg :background ,zenburn-bg+2))))
   `(proof-command-mouse-highlight-face ((t (:inherit proof-mouse-highlight-face))))
   `(proof-debug-message-face ((t (:inherit proof-boring-face))))
   `(proof-declaration-name-face ((t (:inherit font-lock-keyword-face :foreground nil))))
   `(proof-eager-annotation-face ((t (:foreground ,zenburn-bg :background ,zenburn-orange))))
   `(proof-error-face ((t (:foreground ,zenburn-fg :background ,zenburn-red-4))))
   `(proof-highlight-dependency-face ((t (:foreground ,zenburn-bg :background ,zenburn-yellow-1))))
   `(proof-highlight-dependent-face ((t (:foreground ,zenburn-bg :background ,zenburn-orange))))
   `(proof-locked-face ((t (:background ,zenburn-blue-5))))
   `(proof-mouse-highlight-face ((t (:foreground ,zenburn-bg :background ,zenburn-orange))))
   `(proof-queue-face ((t (:background ,zenburn-red-4))))
   `(proof-region-mouse-highlight-face ((t (:inherit proof-mouse-highlight-face))))
   `(proof-script-highlight-error-face ((t (:background ,zenburn-red-2))))
   `(proof-tacticals-name-face ((t (:inherit font-lock-constant-face :foreground nil :background ,zenburn-bg))))
   `(proof-tactics-name-face ((t (:inherit font-lock-constant-face :foreground nil :background ,zenburn-bg))))
   `(proof-warning-face ((t (:foreground ,zenburn-bg :background ,zenburn-yellow-1))))
;;;;; racket-mode
   `(racket-keyword-argument-face ((t (:inherit font-lock-constant-face))))
   `(racket-selfeval-face ((t (:inherit font-lock-type-face))))
;;;;; rainbow-delimiters
   `(rainbow-delimiters-depth-1-face ((t (:foreground ,zenburn-fg))))
   `(rainbow-delimiters-depth-2-face ((t (:foreground ,zenburn-green+4))))
   `(rainbow-delimiters-depth-3-face ((t (:foreground ,zenburn-yellow-2))))
   `(rainbow-delimiters-depth-4-face ((t (:foreground ,zenburn-cyan))))
   `(rainbow-delimiters-depth-5-face ((t (:foreground ,zenburn-green+2))))
   `(rainbow-delimiters-depth-6-face ((t (:foreground ,zenburn-blue+1))))
   `(rainbow-delimiters-depth-7-face ((t (:foreground ,zenburn-yellow-1))))
   `(rainbow-delimiters-depth-8-face ((t (:foreground ,zenburn-green+1))))
   `(rainbow-delimiters-depth-9-face ((t (:foreground ,zenburn-blue-2))))
   `(rainbow-delimiters-depth-10-face ((t (:foreground ,zenburn-orange))))
   `(rainbow-delimiters-depth-11-face ((t (:foreground ,zenburn-green))))
   `(rainbow-delimiters-depth-12-face ((t (:foreground ,zenburn-blue-5))))
;;;;; rcirc
   `(rcirc-my-nick ((t (:foreground ,zenburn-blue))))
   `(rcirc-other-nick ((t (:foreground ,zenburn-orange))))
   `(rcirc-bright-nick ((t (:foreground ,zenburn-blue+1))))
   `(rcirc-dim-nick ((t (:foreground ,zenburn-blue-2))))
   `(rcirc-server ((t (:foreground ,zenburn-green))))
   `(rcirc-server-prefix ((t (:foreground ,zenburn-green+1))))
   `(rcirc-timestamp ((t (:foreground ,zenburn-green+2))))
   `(rcirc-nick-in-message ((t (:foreground ,zenburn-yellow))))
   `(rcirc-nick-in-message-full-line ((t (:weight bold))))
   `(rcirc-prompt ((t (:foreground ,zenburn-yellow :weight bold))))
   `(rcirc-track-nick ((t (:inverse-video t))))
   `(rcirc-track-keyword ((t (:weight bold))))
   `(rcirc-url ((t (:weight bold))))
   `(rcirc-keyword ((t (:foreground ,zenburn-yellow :weight bold))))
;;;;; re-builder
   `(reb-match-0 ((t (:foreground ,zenburn-bg :background ,zenburn-magenta))))
   `(reb-match-1 ((t (:foreground ,zenburn-bg :background ,zenburn-blue))))
   `(reb-match-2 ((t (:foreground ,zenburn-bg :background ,zenburn-orange))))
   `(reb-match-3 ((t (:foreground ,zenburn-bg :background ,zenburn-red))))
;;;;; realgud
   `(realgud-overlay-arrow1 ((t (:foreground ,zenburn-green))))
   `(realgud-overlay-arrow2 ((t (:foreground ,zenburn-yellow))))
   `(realgud-overlay-arrow3 ((t (:foreground ,zenburn-orange))))
   `(realgud-bp-enabled-face ((t (:inherit error))))
   `(realgud-bp-disabled-face ((t (:inherit secondary-selection))))
   `(realgud-bp-line-enabled-face ((t (:box (:color ,zenburn-red :style nil)))))
   `(realgud-bp-line-disabled-face ((t (:box (:color "grey70" :style nil)))))
   `(realgud-line-number ((t (:foreground ,zenburn-yellow))))
   `(realgud-backtrace-number ((t (:foreground ,zenburn-yellow, :weight bold))))
;;;;; regex-tool
   `(regex-tool-matched-face ((t (:background ,zenburn-blue-4 :weight bold))))
;;;;; rmail
   `(rmail-highlight ((t (:foreground ,zenburn-yellow :weight bold))))
   `(rmail-header-name ((t (:foreground ,zenburn-blue))))
;;;;; rpm-mode
   `(rpm-spec-dir-face ((t (:foreground ,zenburn-green))))
   `(rpm-spec-doc-face ((t (:foreground ,zenburn-green))))
   `(rpm-spec-ghost-face ((t (:foreground ,zenburn-red))))
   `(rpm-spec-macro-face ((t (:foreground ,zenburn-yellow))))
   `(rpm-spec-obsolete-tag-face ((t (:foreground ,zenburn-red))))
   `(rpm-spec-package-face ((t (:foreground ,zenburn-red))))
   `(rpm-spec-section-face ((t (:foreground ,zenburn-yellow))))
   `(rpm-spec-tag-face ((t (:foreground ,zenburn-blue))))
   `(rpm-spec-var-face ((t (:foreground ,zenburn-red))))
;;;;; rst-mode
   `(rst-level-1-face ((t (:foreground ,zenburn-orange))))
   `(rst-level-2-face ((t (:foreground ,zenburn-green+1))))
   `(rst-level-3-face ((t (:foreground ,zenburn-blue-1))))
   `(rst-level-4-face ((t (:foreground ,zenburn-yellow-2))))
   `(rst-level-5-face ((t (:foreground ,zenburn-cyan))))
   `(rst-level-6-face ((t (:foreground ,zenburn-green-2))))
;;;;; selectrum
   `(selectrum-current-candidate ((t (:foreground ,zenburn-yellow :weight bold :underline t))))
   `(selectrum-primary-highlight ((t (:background ,zenburn-green-2))))
   `(selectrum-secondary-highlight ((t (:background ,zenburn-green))))
;;;;; sh-mode
   `(sh-heredoc     ((t (:foreground ,zenburn-yellow :weight bold))))
   `(sh-quoted-exec ((t (:foreground ,zenburn-red))))
;;;;; show-paren
   `(show-paren-mismatch ((t (:foreground ,zenburn-red+1 :background ,zenburn-bg+3 :weight bold))))
   `(show-paren-match ((t (:foreground ,zenburn-fg :background ,zenburn-bg+3 :weight bold))))
;;;;; smart-mode-line
   ;; use (setq sml/theme nil) to enable Zenburn for sml
   `(sml/global ((t (:foreground ,zenburn-fg :weight bold))))
   `(sml/modes ((t (:foreground ,zenburn-yellow :weight bold))))
   `(sml/minor-modes ((t (:foreground ,zenburn-fg-1 :weight bold))))
   `(sml/filename ((t (:foreground ,zenburn-yellow :weight bold))))
   `(sml/line-number ((t (:foreground ,zenburn-blue :weight bold))))
   `(sml/col-number ((t (:foreground ,zenburn-blue+1 :weight bold))))
   `(sml/position-percentage ((t (:foreground ,zenburn-blue-1 :weight bold))))
   `(sml/prefix ((t (:foreground ,zenburn-orange))))
   `(sml/git ((t (:foreground ,zenburn-green+3))))
   `(sml/process ((t (:weight bold))))
   `(sml/sudo ((t  (:foreground ,zenburn-orange :weight bold))))
   `(sml/read-only ((t (:foreground ,zenburn-red-2))))
   `(sml/outside-modified ((t (:foreground ,zenburn-orange))))
   `(sml/modified ((t (:foreground ,zenburn-red))))
   `(sml/vc-edited ((t (:foreground ,zenburn-green+2))))
   `(sml/charging ((t (:foreground ,zenburn-green+4))))
   `(sml/discharging ((t (:foreground ,zenburn-red+1))))
;;;;; smartparens
   `(sp-show-pair-mismatch-face ((t (:foreground ,zenburn-red+1 :background ,zenburn-bg+3 :weight bold))))
   `(sp-show-pair-match-face ((t (:background ,zenburn-bg+3 :weight bold))))
;;;;; smerge
   `(smerge-base ((t (:background "#555511" :extend t))))
   `(smerge-markers ((t (:foreground ,zenburn-fg-1 :background ,zenburn-bg+1 :extend t))))
   `(smerge-upper ((t (:background "#553333" :extend t))))
   `(smerge-lower ((t (:background "#335533" :extend t))))
   `(smerge-refined-added ((t (:foreground ,zenburn-green+4 :background "#338833" :weight bold))))
   `(smerge-refined-removed ((t (:foreground ,zenburn-red :background "#883333" :weight bold))))
   `(smerge-refined-changed ((t (:foreground ,zenburn-yellow :background "#888811" :weight bold))))
;;;;; sml-mode-line
   '(sml-modeline-end-face ((t :inherit default :width condensed)))
;;;;; SLIME
   `(slime-repl-output-face ((t (:foreground ,zenburn-red))))
   `(slime-repl-inputed-output-face ((t (:foreground ,zenburn-green))))
   `(slime-error-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-red)))
      (t
       (:underline ,zenburn-red))))
   `(slime-warning-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-orange)))
      (t
       (:underline ,zenburn-orange))))
   `(slime-style-warning-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-yellow)))
      (t
       (:underline ,zenburn-yellow))))
   `(slime-note-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-green)))
      (t
       (:underline ,zenburn-green))))
   `(slime-highlight-face ((t (:inherit highlight))))
;;;;; SLY
   `(sly-mrepl-output-face ((t (:foreground ,zenburn-red))))
   `(sly-error-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-red)))
      (t
       (:underline ,zenburn-red))))
   `(sly-warning-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-orange)))
      (t
       (:underline ,zenburn-orange))))
   `(sly-style-warning-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-yellow)))
      (t
       (:underline ,zenburn-yellow))))
   `(sly-note-face
     ((((supports :underline (:style wave)))
       (:underline (:style wave :color ,zenburn-green)))
      (t
       (:underline ,zenburn-green))))
   `(sly-stickers-placed-face ((t (:foreground ,zenburn-fg :background ,zenburn-bg+3))))
;;;;; solaire
   `(solaire-default-face ((t (:inherit default :background ,zenburn-bg-08))))
   `(solaire-minibuffer-face ((t (:inherit default :background ,zenburn-bg-08))))
   `(solaire-hl-line-face ((t (:inherit hl-line :background ,zenburn-bg))))
   `(solaire-org-hide-face ((t (:inherit org-hide :background ,zenburn-bg-08))))
;;;;; speedbar
   `(speedbar-button-face ((t (:foreground ,zenburn-green+2))))
   `(speedbar-directory-face ((t (:foreground ,zenburn-cyan))))
   `(speedbar-file-face ((t (:foreground ,zenburn-fg))))
   `(speedbar-highlight-face ((t (:foreground ,zenburn-bg :background ,zenburn-green+2))))
   `(speedbar-selected-face ((t (:foreground ,zenburn-red))))
   `(speedbar-separator-face ((t (:foreground ,zenburn-bg :background ,zenburn-blue-1))))
   `(speedbar-tag-face ((t (:foreground ,zenburn-yellow))))
;;;;; swiper
   `(swiper-line-face ((t (:underline t))))
;;;;; symbol-overlay
   `(symbol-overlay-default-face ((t (:background ,zenburn-bg+2 :foreground ,zenburn-fg))))
   `(symbol-overlay-face-1 ((t (:background ,zenburn-blue-4 :foreground ,zenburn-fg))))
   `(symbol-overlay-face-2 ((t (:background ,zenburn-magenta :foreground ,zenburn-bg))))
   `(symbol-overlay-face-3 ((t (:background ,zenburn-yellow-2 :foreground ,zenburn-bg))))
   `(symbol-overlay-face-4 ((t (:background ,zenburn-orange :foreground ,zenburn-bg))))
   `(symbol-overlay-face-5 ((t (:background ,zenburn-red-3 :foreground ,zenburn-fg))))
   `(symbol-overlay-face-6 ((t (:background ,zenburn-red-1 :foreground ,zenburn-bg))))
   `(symbol-overlay-face-7 ((t (:background ,zenburn-green-2 :foreground ,zenburn-fg))))
   `(symbol-overlay-face-8 ((t (:background ,zenburn-cyan :foreground ,zenburn-bg))))
;;;;; tabbar
   `(tabbar-button ((t (:foreground ,zenburn-fg
                                    :background ,zenburn-bg))))
   `(tabbar-selected ((t (:foreground ,zenburn-fg
                                      :background ,zenburn-bg
                                      :box (:line-width -1 :style pressed-button)))))
   `(tabbar-unselected ((t (:foreground ,zenburn-fg
                                        :background ,zenburn-bg+1
                                        :box (:line-width -1 :style released-button)))))
;;;;; tab-bar
   `(tab-bar ((t (:background ,zenburn-bg+1))))
   `(tab-bar-tab ((t (:foreground ,zenburn-fg
                                  :background ,zenburn-bg
                                  :weight bold
                                  :box (:line-width -1 :style released-button)))))
   `(tab-bar-tab-inactive ((t (:foreground ,zenburn-fg
                                           :background ,zenburn-bg+1
                                           :box (:line-width -1 :style released-button)))))
   `(tab-bar-tab-ungrouped ((t (:foreground ,zenburn-fg-1 :background ,zenburn-bg+1))))
   `(tab-bar-tab-group-current ((t (:foreground ,zenburn-yellow :background ,zenburn-bg :weight bold))))
   `(tab-bar-tab-group-inactive ((t (:foreground ,zenburn-fg-1 :background ,zenburn-bg+1))))
;;;;; tab-line
   `(tab-line ((t (:background ,zenburn-bg+1))))
   `(tab-line-tab ((t (:foreground ,zenburn-fg
                                  :background ,zenburn-bg
                                  :weight bold
                                  :box (:line-width -1 :style released-button)))))
   `(tab-line-tab-inactive ((t (:foreground ,zenburn-fg
                                           :background ,zenburn-bg+1
                                           :box (:line-width -1 :style released-button)))))
   `(tab-line-tab-current ((t (:foreground ,zenburn-fg
                                           :background ,zenburn-bg+1
                                           :box (:line-width -1 :style pressed-button)))))
   `(tab-line-tab-inactive-alternate ((t (:inherit tab-line-tab-inactive :background ,zenburn-bg-05))))
   `(tab-line-tab-modified ((t (:inherit tab-line-tab :foreground ,zenburn-orange))))
   `(tab-line-tab-special ((t (:inherit tab-line-tab :slant italic))))
   `(tab-line-tab-group ((t (:foreground ,zenburn-yellow :weight bold))))
   `(tab-line-highlight ((t (:inherit tab-line-tab :background ,zenburn-bg+2))))
   `(tab-line-close-highlight ((t (:foreground ,zenburn-red))))
;;;;; transient
   `(transient-heading ((t (:foreground ,zenburn-yellow :weight bold))))
   `(transient-argument ((t (:foreground ,zenburn-orange :weight bold))))
   `(transient-inactive-argument ((t (:foreground ,zenburn-fg-1))))
   `(transient-inapt-argument ((t (:foreground ,zenburn-fg-1 :slant italic))))
   `(transient-value ((t (:foreground ,zenburn-cyan :weight bold))))
   `(transient-inactive-value ((t (:foreground ,zenburn-fg-1))))
   `(transient-delimiter ((t (:foreground ,zenburn-bg+3))))
   `(transient-unreachable ((t (:foreground ,zenburn-fg-1))))
   `(transient-inapt-suffix ((t (:foreground ,zenburn-fg-1 :slant italic))))
   `(transient-active-infix ((t (:background ,zenburn-bg+1))))
   `(transient-enabled-suffix ((t (:foreground ,zenburn-green+2 :background "#335533" :weight bold))))
   `(transient-disabled-suffix ((t (:foreground ,zenburn-red :background "#553333" :weight bold))))
   `(transient-higher-level ((t (:underline t))))
   `(transient-key ((t (:foreground ,zenburn-blue))))
   `(transient-key-stay ((t (:foreground ,zenburn-cyan :weight bold))))
   `(transient-key-noop ((t (:foreground ,zenburn-fg-1))))
   `(transient-key-return ((t (:foreground ,zenburn-magenta))))
   `(transient-key-recurse ((t (:foreground ,zenburn-orange))))
   `(transient-key-stack ((t (:foreground ,zenburn-blue :weight bold))))
   `(transient-key-exit ((t (:foreground ,zenburn-red))))
   `(transient-unreachable-key ((t (:foreground ,zenburn-fg-1))))
   `(transient-nonstandard-key ((t (:foreground ,zenburn-yellow :underline t))))
   `(transient-mismatched-key ((t (:foreground ,zenburn-yellow :underline t))))
;;;;; treemacs
   `(treemacs-directory-face ((t (:foreground ,zenburn-blue :weight bold))))
   `(treemacs-directory-collapsed-face ((t (:foreground ,zenburn-blue))))
   `(treemacs-window-background-face ((t (:background ,zenburn-bg-05))))
   `(treemacs-hl-line-face ((t (:background ,zenburn-bg-05 :extend t))))
   `(treemacs-file-face ((t (:foreground ,zenburn-fg))))
   `(treemacs-root-face ((t (:foreground ,zenburn-blue+1 :weight bold :height 1.1))))
   `(treemacs-root-unreadable-face ((t (:foreground ,zenburn-red :weight bold :height 1.1))))
   `(treemacs-root-remote-face ((t (:foreground ,zenburn-magenta :weight bold :height 1.1))))
   `(treemacs-root-remote-unreadable-face ((t (:foreground ,zenburn-red :slant italic :height 1.1))))
   `(treemacs-root-remote-disconnected-face ((t (:foreground ,zenburn-fg-1 :weight bold :height 1.1))))
   `(treemacs-term-node-face ((t (:foreground ,zenburn-fg-1))))
   `(treemacs-git-unmodified-face ((t (:foreground ,zenburn-fg))))
   `(treemacs-git-modified-face ((t (:foreground ,zenburn-yellow))))
   `(treemacs-git-renamed-face ((t (:foreground ,zenburn-green+1))))
   `(treemacs-git-ignored-face ((t (:foreground ,zenburn-fg-1))))
   `(treemacs-git-untracked-face ((t (:foreground ,zenburn-orange))))
   `(treemacs-git-added-face ((t (:foreground ,zenburn-green+1))))
   `(treemacs-git-conflict-face ((t (:foreground ,zenburn-red :weight bold))))
   `(treemacs-tags-face ((t (:foreground ,zenburn-cyan))))
   `(treemacs-help-title-face ((t (:foreground ,zenburn-magenta :weight bold))))
   `(treemacs-help-column-face ((t (:foreground ,zenburn-blue))))
   `(treemacs-on-failure-pulse-face ((t (:background ,zenburn-red-6))))
   `(treemacs-on-success-pulse-face ((t (:background ,zenburn-green-5))))
   `(treemacs-fringe-indicator-face ((t (:foreground ,zenburn-blue))))
   `(treemacs-header-button-face ((t (:foreground ,zenburn-fg :background ,zenburn-bg+1 :box (:line-width -1 :color ,zenburn-bg+3)))))
   `(treemacs-marked-file-face ((t (:foreground ,zenburn-magenta :weight bold))))
   `(treemacs-git-commit-diff-face ((t (:foreground ,zenburn-bg+3))))
   `(treemacs-async-loading-face ((t (:foreground ,zenburn-fg-1 :slant italic))))
;;;;; term
   `(term-color-black ((t (:foreground ,zenburn-bg
                                       :background ,zenburn-bg-1))))
   `(term-color-red ((t (:foreground ,zenburn-red-2
                                     :background ,zenburn-red-4))))
   `(term-color-green ((t (:foreground ,zenburn-green
                                       :background ,zenburn-green+2))))
   `(term-color-yellow ((t (:foreground ,zenburn-orange
                                        :background ,zenburn-yellow))))
   `(term-color-blue ((t (:foreground ,zenburn-blue-1
                                      :background ,zenburn-blue-4))))
   `(term-color-magenta ((t (:foreground ,zenburn-magenta
                                         :background ,zenburn-red))))
   `(term-color-cyan ((t (:foreground ,zenburn-cyan
                                      :background ,zenburn-blue))))
   `(term-color-white ((t (:foreground ,zenburn-fg
                                       :background ,zenburn-fg-1))))
   '(term-default-fg-color ((t (:inherit term-color-white))))
   '(term-default-bg-color ((t (:inherit term-color-black))))
;;;;; undo-tree
   `(undo-tree-visualizer-active-branch-face ((t (:foreground ,zenburn-fg+1 :weight bold))))
   `(undo-tree-visualizer-current-face ((t (:foreground ,zenburn-red-1 :weight bold))))
   `(undo-tree-visualizer-default-face ((t (:foreground ,zenburn-fg))))
   `(undo-tree-visualizer-register-face ((t (:foreground ,zenburn-yellow))))
   `(undo-tree-visualizer-unmodified-face ((t (:foreground ,zenburn-cyan))))
;;;;; vertico
   `(vertico-current ((t (:foreground ,zenburn-yellow :weight bold :underline t))))
   `(vertico-multiline ((t (:foreground ,zenburn-green))))
   `(vertico-group-title ((t (:foreground ,zenburn-yellow :weight bold))))
   `(vertico-group-separator ((t (:foreground ,zenburn-green :strike-through t))))
;;;;; visual-regexp
   `(vr/group-0 ((t (:foreground ,zenburn-bg :background ,zenburn-green :weight bold))))
   `(vr/group-1 ((t (:foreground ,zenburn-bg :background ,zenburn-orange :weight bold))))
   `(vr/group-2 ((t (:foreground ,zenburn-bg :background ,zenburn-blue :weight bold))))
   `(vr/match-0 ((t (:inherit isearch))))
   `(vr/match-1 ((t (:foreground ,zenburn-yellow-2 :background ,zenburn-bg-1 :weight bold))))
   `(vr/match-separator-face ((t (:foreground ,zenburn-red :weight bold))))
;;;;; volatile-highlights
   `(vhl/default-face ((t (:background ,zenburn-bg-05))))
;;;;; vundo
   `(vundo-node ((t (:foreground ,zenburn-fg-1))))
   `(vundo-stem ((t (:foreground ,zenburn-bg+3))))
   `(vundo-branch-stem ((t (:foreground ,zenburn-fg-1))))
   `(vundo-highlight ((t (:foreground ,zenburn-red-1 :weight bold))))
   `(vundo-saved ((t (:foreground ,zenburn-green+2))))
   `(vundo-last-saved ((t (:foreground ,zenburn-green+2 :weight bold))))
   `(vundo-diff-highlight ((t (:foreground ,zenburn-orange :weight bold))))
;;;;; web-mode
   `(web-mode-builtin-face ((t (:inherit ,font-lock-builtin-face))))
   `(web-mode-comment-face ((t (:inherit ,font-lock-comment-face))))
   `(web-mode-constant-face ((t (:inherit ,font-lock-constant-face))))
   `(web-mode-css-at-rule-face ((t (:foreground ,zenburn-orange ))))
   `(web-mode-css-prop-face ((t (:foreground ,zenburn-orange))))
   `(web-mode-css-pseudo-class-face ((t (:foreground ,zenburn-green+3 :weight bold))))
   `(web-mode-css-rule-face ((t (:foreground ,zenburn-blue))))
   `(web-mode-doctype-face ((t (:inherit ,font-lock-comment-face))))
   `(web-mode-folded-face ((t (:underline t))))
   `(web-mode-function-name-face ((t (:foreground ,zenburn-blue))))
   `(web-mode-html-attr-name-face ((t (:foreground ,zenburn-orange))))
   `(web-mode-html-attr-value-face ((t (:inherit ,font-lock-string-face))))
   `(web-mode-html-tag-face ((t (:foreground ,zenburn-cyan))))
   `(web-mode-keyword-face ((t (:inherit ,font-lock-keyword-face))))
   `(web-mode-preprocessor-face ((t (:inherit ,font-lock-preprocessor-face))))
   `(web-mode-string-face ((t (:inherit ,font-lock-string-face))))
   `(web-mode-type-face ((t (:inherit ,font-lock-type-face))))
   `(web-mode-variable-name-face ((t (:inherit ,font-lock-variable-name-face))))
   `(web-mode-server-background-face ((t (:background ,zenburn-bg))))
   `(web-mode-server-comment-face ((t (:inherit web-mode-comment-face))))
   `(web-mode-server-string-face ((t (:inherit web-mode-string-face))))
   `(web-mode-symbol-face ((t (:inherit font-lock-constant-face))))
   `(web-mode-warning-face ((t (:inherit font-lock-warning-face))))
   `(web-mode-whitespaces-face ((t (:background ,zenburn-red))))
;;;;; whitespace-mode
   `(whitespace-space ((t (:background ,zenburn-bg+1 :foreground ,zenburn-bg+1))))
   `(whitespace-hspace ((t (:background ,zenburn-bg+1 :foreground ,zenburn-bg+1))))
   `(whitespace-tab ((t (:background ,zenburn-red-1))))
   `(whitespace-newline ((t (:foreground ,zenburn-bg+1))))
   `(whitespace-trailing ((t (:background ,zenburn-red))))
   `(whitespace-line ((t (:background ,zenburn-bg :foreground ,zenburn-magenta))))
   `(whitespace-space-before-tab ((t (:background ,zenburn-orange :foreground ,zenburn-orange))))
   `(whitespace-indentation ((t (:background ,zenburn-yellow :foreground ,zenburn-red))))
   `(whitespace-empty ((t (:background ,zenburn-yellow))))
   `(whitespace-space-after-tab ((t (:background ,zenburn-yellow :foreground ,zenburn-red))))
;;;;; wanderlust
   `(wl-highlight-folder-few-face ((t (:foreground ,zenburn-red-2))))
   `(wl-highlight-folder-many-face ((t (:foreground ,zenburn-red-1))))
   `(wl-highlight-folder-path-face ((t (:foreground ,zenburn-orange))))
   `(wl-highlight-folder-unread-face ((t (:foreground ,zenburn-blue))))
   `(wl-highlight-folder-zero-face ((t (:foreground ,zenburn-fg))))
   `(wl-highlight-folder-unknown-face ((t (:foreground ,zenburn-blue))))
   `(wl-highlight-message-citation-header ((t (:foreground ,zenburn-red-1))))
   `(wl-highlight-message-cited-text-1 ((t (:foreground ,zenburn-red))))
   `(wl-highlight-message-cited-text-2 ((t (:foreground ,zenburn-green+2))))
   `(wl-highlight-message-cited-text-3 ((t (:foreground ,zenburn-blue))))
   `(wl-highlight-message-cited-text-4 ((t (:foreground ,zenburn-blue+1))))
   `(wl-highlight-message-header-contents-face ((t (:foreground ,zenburn-green))))
   `(wl-highlight-message-headers-face ((t (:foreground ,zenburn-red+1))))
   `(wl-highlight-message-important-header-contents ((t (:foreground ,zenburn-green+2))))
   `(wl-highlight-message-header-contents ((t (:foreground ,zenburn-green+1))))
   `(wl-highlight-message-important-header-contents2 ((t (:foreground ,zenburn-green+2))))
   `(wl-highlight-message-signature ((t (:foreground ,zenburn-green))))
   `(wl-highlight-message-unimportant-header-contents ((t (:foreground ,zenburn-fg))))
   `(wl-highlight-summary-answered-face ((t (:foreground ,zenburn-blue))))
   `(wl-highlight-summary-disposed-face ((t (:foreground ,zenburn-fg
                                                         :slant italic))))
   `(wl-highlight-summary-new-face ((t (:foreground ,zenburn-blue))))
   `(wl-highlight-summary-normal-face ((t (:foreground ,zenburn-fg))))
   `(wl-highlight-summary-thread-top-face ((t (:foreground ,zenburn-yellow))))
   `(wl-highlight-thread-indent-face ((t (:foreground ,zenburn-magenta))))
   `(wl-highlight-summary-refiled-face ((t (:foreground ,zenburn-fg))))
   `(wl-highlight-summary-displaying-face ((t (:underline t :weight bold))))
;;;;; which-func-mode
   `(which-func ((t (:foreground ,zenburn-green+4))))
;;;;; which-key
   `(which-key-key-face ((t (:foreground ,zenburn-blue :weight bold))))
   `(which-key-separator-face ((t (:foreground ,zenburn-green))))
   `(which-key-note-face ((t (:foreground ,zenburn-fg-1))))
   `(which-key-command-description-face ((t (:foreground ,zenburn-fg))))
   `(which-key-local-map-description-face ((t (:foreground ,zenburn-cyan))))
   `(which-key-highlighted-command-face ((t (:foreground ,zenburn-orange :weight bold))))
   `(which-key-group-description-face ((t (:foreground ,zenburn-magenta))))
   `(which-key-special-key-face ((t (:foreground ,zenburn-red+1 :weight bold))))
   `(which-key-docstring-face ((t (:foreground ,zenburn-green :slant italic))))
;;;;; window-tool-bar-mode
   `(window-tool-bar-button ((t (:foreground ,zenburn-fg
                                 :background ,zenburn-bg
                                 :box (:line-width -1 :style released-button)))))
   `(window-tool-bar-button-hover ((t (:foreground ,zenburn-fg
                                       :background ,zenburn-bg+1
                                       :box (:line-width -1 :style released-button)))))
   `(window-tool-bar-button-disabled ((t (:foreground ,zenburn-fg
                                          :background ,zenburn-bg+3
                                          :box (:line-width -1 :style released-button)))))
;;;;; wgrep
   `(wgrep-face ((t (:foreground ,zenburn-green :background ,zenburn-green-5))))
   `(wgrep-delete-face ((t (:foreground ,zenburn-red :background ,zenburn-red-6))))
   `(wgrep-done-face ((t (:foreground ,zenburn-blue))))
   `(wgrep-file-face ((t (:foreground ,zenburn-fg-1))))
   `(wgrep-reject-face ((t (:foreground ,zenburn-red :weight bold))))
;;;;; xcscope
   `(cscope-file-face ((t (:foreground ,zenburn-yellow :weight bold))))
   `(cscope-function-face ((t (:foreground ,zenburn-cyan :weight bold))))
   `(cscope-line-number-face ((t (:foreground ,zenburn-red :weight bold))))
   `(cscope-mouse-face ((t (:foreground ,zenburn-bg :background ,zenburn-blue+1))))
   `(cscope-separator-face ((t (:foreground ,zenburn-red :weight bold
                                            :underline t :overline t))))
;;;;; yascroll
   `(yascroll:thumb-text-area ((t (:background ,zenburn-bg-1))))
   `(yascroll:thumb-fringe ((t (:background ,zenburn-bg-1 :foreground ,zenburn-bg-1))))
   ))

;;; Theme Variables
(zenburn-with-color-variables
  (custom-theme-set-variables
   'zenburn
;;;;; ansi-color
   `(ansi-color-names-vector [,zenburn-bg ,zenburn-red ,zenburn-green ,zenburn-yellow
                                          ,zenburn-blue ,zenburn-magenta ,zenburn-cyan ,zenburn-fg])
;;;;; nrepl-client
   `(nrepl-message-colors
     '(,zenburn-red ,zenburn-orange ,zenburn-yellow ,zenburn-green ,zenburn-green+4
       ,zenburn-cyan ,zenburn-blue+1 ,zenburn-magenta))
;;;;; pdf-tools
   `(pdf-view-midnight-colors '(,zenburn-fg . ,zenburn-bg-05))
;;;;; vc-annotate
   `(vc-annotate-color-map
     '(( 20. . ,zenburn-red-1)
       ( 40. . ,zenburn-red)
       ( 60. . ,zenburn-orange)
       ( 80. . ,zenburn-yellow-2)
       (100. . ,zenburn-yellow-1)
       (120. . ,zenburn-yellow)
       (140. . ,zenburn-green-2)
       (160. . ,zenburn-green)
       (180. . ,zenburn-green+1)
       (200. . ,zenburn-green+2)
       (220. . ,zenburn-green+3)
       (240. . ,zenburn-green+4)
       (260. . ,zenburn-cyan)
       (280. . ,zenburn-blue-2)
       (300. . ,zenburn-blue-1)
       (320. . ,zenburn-blue)
       (340. . ,zenburn-blue+1)
       (360. . ,zenburn-magenta)))
   `(vc-annotate-very-old-color ,zenburn-magenta)
   `(vc-annotate-background ,zenburn-bg-1)
   ))

;;; Rainbow Support

(declare-function rainbow-mode 'rainbow-mode)
(declare-function rainbow-colorize-by-assoc 'rainbow-mode)

(defcustom zenburn-add-font-lock-keywords nil
  "Whether to add font-lock keywords for zenburn color names.

In buffers visiting library `zenburn-theme.el' the zenburn
specific keywords are always added, provided that library has
been loaded (because that is where the code that does it is
defined).  If you visit this file and only enable the theme,
then you have to turn `rainbow-mode' off and on again for the
zenburn-specific font-lock keywords to be used.

In all other Emacs-Lisp buffers this variable controls whether
this should be done.  This requires library `rainbow-mode'."
  :type 'boolean
  :group 'zenburn-theme)

(defvar zenburn-colors-font-lock-keywords nil)

(defun zenburn--rainbow-turn-on ()
  "Maybe also add font-lock keywords for zenburn colors."
  (when (and (derived-mode-p 'emacs-lisp-mode)
             (or zenburn-add-font-lock-keywords
                 (and (buffer-file-name)
                      (equal (file-name-nondirectory (buffer-file-name))
                             "zenburn-theme.el"))))
    (unless zenburn-colors-font-lock-keywords
      (setq zenburn-colors-font-lock-keywords
            `((,(regexp-opt (mapcar 'car zenburn-default-colors-alist) 'words)
               (0 (rainbow-colorize-by-assoc zenburn-default-colors-alist))))))
    (font-lock-add-keywords nil zenburn-colors-font-lock-keywords 'end)))

(defun zenburn--rainbow-turn-off ()
  "Also remove font-lock keywords for zenburn colors."
  (font-lock-remove-keywords nil zenburn-colors-font-lock-keywords))

(when (fboundp 'advice-add)
  (advice-add 'rainbow-turn-on :after  #'zenburn--rainbow-turn-on)
  (advice-add 'rainbow-turn-off :after #'zenburn--rainbow-turn-off))

;;; Footer

;;;###autoload
(and load-file-name
     (boundp 'custom-theme-load-path)
     (add-to-list 'custom-theme-load-path
                  (file-name-as-directory
                   (file-name-directory load-file-name))))

(provide-theme 'zenburn)

;; Local Variables:
;; no-byte-compile: t
;; indent-tabs-mode: nil
;; eval: (when (require 'rainbow-mode nil t) (rainbow-mode 1))
;; End:
;;; zenburn-theme.el ends here
