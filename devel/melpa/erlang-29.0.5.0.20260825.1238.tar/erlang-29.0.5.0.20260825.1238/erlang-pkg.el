;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "29.0.5.0.20260825.1238"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "9b155fcc2bc05efa1bc8aa05db540852151c5a11"
  :revdesc "OTP-29.0.5-1238-g9b155fcc2bc0"
  :keywords '("erlang" "languages" "processes"))
