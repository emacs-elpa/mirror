;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-tube" "0.15.0.20260522.46"
  "YouTube integration for Elfeed."
  '((emacs  "27.1")
    (elfeed "3.4.2")
    (aio    "1.0"))
  :url "https://github.com/karthink/elfeed-tube"
  :commit "ae763194ad36942ccdbd9d59a40926a33bffd89b"
  :revdesc "ae763194ad36"
  :keywords '("news" "hypermedia" "convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
