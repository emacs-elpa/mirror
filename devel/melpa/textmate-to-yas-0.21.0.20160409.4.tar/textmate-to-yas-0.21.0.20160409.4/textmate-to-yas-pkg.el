;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "textmate-to-yas" "0.21.0.20160409.4"
  "Import Textmate macros into yasnippet syntax."
  ()
  :url "https://github.com/mlf176f2/textmate-to-yas.el/"
  :commit "be3a768b7ac4c2e24b9d4aa6e9ac1d916cdc5a73"
  :revdesc "v0.21-4-gbe3a768b7ac4"
  :keywords '("yasnippet" "textmate"))
