;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arduino-mode" "1.3.1"
  "Major mode for editing Arduino code."
  '((emacs   "25.1")
    (spinner "1.7.3"))
  :url "https://repo.or.cz/arduino-mode.git"
  :commit "b2ffd8441851659cb1cc844156073967729585e5"
  :revdesc "b2ffd8441851"
  :keywords '("languages" "arduino")
  :authors '(("Christopher Grim" . "christopher.grim@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
