;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-picklink" "0.1.0.0.20210210.34"
  "Pick a headline link from org-agenda."
  '((emacs "24.4"))
  :url "https://github.com/tumashu/org-picklink"
  :commit "bfdc22b436482752be41c5d6f6f37dca76b1c7c3"
  :revdesc "bfdc22b43648"
  :keywords '("convenience")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
