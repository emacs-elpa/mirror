;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "howm" "1.5.6.0.20260726.3"
  "Wiki-like note-taking tool."
  '((cl-lib "0.5"))
  :url "https://kaorahi.github.io/howm/"
  :commit "0765a0ad0b9bac80cc739ee869fb986ed705a056"
  :revdesc "0765a0ad0b9b"
  :authors '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com"))
  :maintainers '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com")))
