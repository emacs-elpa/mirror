;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.970.0.20261003.11"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "2402d4cb00448fee11674aa8c9ac81312a6a09ec"
  :revdesc "2402d4cb0044"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
