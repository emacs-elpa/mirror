;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epic" "0.2.0.20170210.5"
  "Evernote Picker for Cocoa Emacs."
  '((htmlize "1.47"))
  :url "https://github.com/yoshinari-nomura/epic"
  :commit "a41826c330eb0ea061d58a08cc861b0c4ac8ec4e"
  :revdesc "a41826c330eb"
  :keywords '("evernote" "applescript")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
