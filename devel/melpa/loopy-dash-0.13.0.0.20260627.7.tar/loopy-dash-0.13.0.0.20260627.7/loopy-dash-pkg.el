;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy-dash" "0.13.0.0.20260627.7"
  "Dash destructuring for `loopy'."
  '((emacs "28.1")
    (loopy "0.13.0")
    (dash  "2.20"))
  :url "https://codeberg.org/okamsn/loopy-dash"
  :commit "d7630105c7188a6e7bc23e66e0c1efb56e005d21"
  :revdesc "d7630105c718"
  :keywords '("extensions"))
