;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-robe" "0.2"
  "Completing read function for robe."
  '((helm "1.7.7"))
  :url "https://github.com/syohex/emacs-helm-robe"
  :commit "7348d0bc0251b51979554ea678b970fd01c0efe9"
  :revdesc "7348d0bc0251"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
