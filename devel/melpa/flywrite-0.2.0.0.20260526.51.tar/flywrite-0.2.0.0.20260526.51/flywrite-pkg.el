;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flywrite" "0.2.0.0.20260526.51"
  "Inline writing suggestions via LLM."
  '((emacs "29.1"))
  :url "https://github.com/awdeorio/flywrite"
  :commit "e9d11b17fdb4a2d986354a5b942952dea9876a6b"
  :revdesc "e9d11b17fdb4"
  :keywords '("text" "wp")
  :authors '(("Andrew DeOrio" . "awdeorio@umich.edu"))
  :maintainers '(("Andrew DeOrio" . "awdeorio@umich.edu")))
