;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pushover" "1.2.0.20170818.7"
  "Pushover API Access."
  '((cl-lib "0.5"))
  :url "https://github.com/swflint/pushover.el"
  :commit "bbe3ac8df3c532a72da4552615af960b8a577588"
  :revdesc "bbe3ac8df3c5"
  :keywords '("notifications")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
