;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qso" "1.0.1.0.20260906.9"
  "Amateur radio QSO logging."
  '((emacs "25.1"))
  :url "https://github.com/K6SM/Emacs-QSO-Logger"
  :commit "3dfaba1062de00b939a45a88e95158272b928bf0"
  :revdesc "3dfaba1062de"
  :keywords '("comm" "hamradio" "adif" "logging"))
