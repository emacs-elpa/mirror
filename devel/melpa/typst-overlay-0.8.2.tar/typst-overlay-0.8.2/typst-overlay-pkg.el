;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typst-overlay" "0.8.2"
  "Overlay Typst equations."
  '((emacs "29.1"))
  :url "https://github.com/hesampakdaman/typst-overlay"
  :commit "4eaa2cb2d18e1eef184e5902e28b09f64101cf72"
  :revdesc "4eaa2cb2d18e"
  :keywords '("tools")
  :authors '(("Hesam Pakdaman" . "https://github.com/hesampakdaman"))
  :maintainers '(("Hesam Pakdaman" . "https://github.com/hesampakdaman")))
