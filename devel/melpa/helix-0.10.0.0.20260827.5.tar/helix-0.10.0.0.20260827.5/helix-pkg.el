;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "0.10.0.0.20260827.5"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "52441ed6ac2a347e4459d7f946a2b22b298e05e8"
  :revdesc "52441ed6ac2a"
  :keywords '("convenience"))
