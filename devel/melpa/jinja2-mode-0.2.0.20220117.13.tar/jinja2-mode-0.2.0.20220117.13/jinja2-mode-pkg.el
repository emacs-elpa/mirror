;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinja2-mode" "0.2.0.20220117.13"
  "A major mode for jinja2."
  ()
  :url "https://github.com/paradoxxxzero/jinja2-mode"
  :commit "03e5430a7efe1d163a16beaf3c82c5fd2c2caee1"
  :revdesc "03e5430a7efe")
