;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-perspeen" "0.1.2.0.20170228.3"
  "Helm interface for perspeen."
  '((perspeen "0.1.0")
    (helm     "2.5.0"))
  :url "https://github.com/jimo1001/helm-perspeen"
  :commit "7fe2922d85608bfa9e18269fc44181428b8849ff"
  :revdesc "7fe2922d8560"
  :keywords '("projects" "lisp"))
