;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-smart-equals" "0.3.1.0.20210411.1"
  "Flexible, context-sensitive assignment key for R/S."
  '((emacs "25.1")
    (ess   "18.10"))
  :url "https://github.com/genovese/ess-smart-equals"
  :commit "fea9eea4b59c3e9559b379508e3500076ca99ef1"
  :revdesc "v0.3.1-1-gfea9eea4b59c"
  :keywords '("r" "s" "ess" "convenience")
  :authors '(("Christopher R. Genovese" . "genovese@cmu.edu"))
  :maintainers '(("Christopher R. Genovese" . "genovese@cmu.edu")))
