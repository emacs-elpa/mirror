;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prosjekt" "0.2.0.20151127.111"
  "A software project tool for emacs."
  '((dash "2.8.0"))
  :url "https://github.com/abingham/prosjekt"
  :commit "a864a8be5842223043702395f311e3350c28e9db"
  :revdesc "a864a8be5842"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
