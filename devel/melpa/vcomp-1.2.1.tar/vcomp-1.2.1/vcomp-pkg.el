;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vcomp" "1.2.1"
  "Compare version strings."
  '((emacs "26.1"))
  :url "https://github.com/tarsius/vcomp"
  :commit "ba2d07505dc29e3128ea915bb252969b82d2af08"
  :revdesc "v1.2.1-0-gba2d07505dc2"
  :keywords '("versions")
  :authors '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
