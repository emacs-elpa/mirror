;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-prescient" "6.3.3.0.20260906.1"
  "Prescient.el + Ivy."
  '((emacs     "26.1")
    (prescient "6.1.0")
    (ivy       "0.11.0"))
  :url "https://github.com/raxod502/prescient.el"
  :commit "ae52777d6b6b856b54c85441c7a713949f1720de"
  :revdesc "ae52777d6b6b"
  :keywords '("extensions")
  :authors '(("Radian LLC" . "contact+prescient@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+prescient@radian.codes")))
