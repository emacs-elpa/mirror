;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "1.2.5.0.20260701.7"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "11bf6a6a77b340416eb07f40d0eb7858f1fa5d5b"
  :revdesc "1.2.5-7-g11bf6a6a77b3"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
