;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tab-group" "0.1.0.20140306.1"
  "Grouped tabs and their tabbar."
  ()
  :url "https://github.com/tarao/tab-group-el"
  :commit "5a290ec2608e4100fb188fd60ecb77affcc3465b"
  :revdesc "5a290ec2608e"
  :keywords '("convenience" "tabs")
  :authors '(("INA Lintaro" . "tarao.gnnatgmail.com"))
  :maintainers '(("INA Lintaro" . "tarao.gnnatgmail.com")))
