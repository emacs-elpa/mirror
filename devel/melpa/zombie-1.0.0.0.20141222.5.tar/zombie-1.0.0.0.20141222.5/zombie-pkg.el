;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zombie" "1.0.0.0.20141222.5"
  "Major mode for editing ZOMBIE programs."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "ff8cd1b4cdbb4b0b9b8fd1ec8f6fb93eba249345"
  :revdesc "ff8cd1b4cdbb")
