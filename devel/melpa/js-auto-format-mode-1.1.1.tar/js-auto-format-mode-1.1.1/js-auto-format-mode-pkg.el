;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-auto-format-mode" "1.1.1"
  "Minor mode for auto-formatting JavaScript code."
  '((emacs "24"))
  :url "https://github.com/ybiquitous/js-auto-format-mode"
  :commit "29d245b4d126a5fc5153a4d8f17396be4165b4a6"
  :revdesc "1.1.1-0-g29d245b4d126"
  :keywords '("languages")
  :authors '(("Masafumi Koba" . "ybiquitous@gmail.com"))
  :maintainers '(("Masafumi Koba" . "ybiquitous@gmail.com")))
