;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "1.2.5.0.20260715.11"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "a722fad8a087b7036657dc22015d0fffbd63d893"
  :revdesc "1.2.5-11-ga722fad8a087"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
