;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-section" "4.5.0.0.20260514.245"
  "Sections for read-only buffers."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "0.2")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/magit"
  :commit "be5a3b0e9f7a64bcb222ba546a18e6b09922e0a9"
  :revdesc "v4.5.0-245-gbe5a3b0e9f7a"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")))
