;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iceberg-theme" "1.0.0.0.20261122.17"
  "Well-designed, eye-friendly, dark blue color scheme."
  '((emacs           "28.1")
    (solarized-theme "2.1.0"))
  :url "https://github.com/conao3/iceberg-theme.el"
  :commit "f7c5830984687d139bd9824f12bda3b2811ed927"
  :revdesc "f7c583098468"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
