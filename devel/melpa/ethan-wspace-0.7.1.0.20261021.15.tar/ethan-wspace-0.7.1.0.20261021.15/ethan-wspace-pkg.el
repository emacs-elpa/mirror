;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ethan-wspace" "0.7.1.0.20261021.15"
  "Whitespace customizations for emacs."
  ()
  :url "https://github.com/glasserc/ethan-wspace"
  :commit "9e34a9d6c5dada2b67552b60f9f2eaa7465589f4"
  :revdesc "9e34a9d6c5da"
  :keywords '("whitespace" "tab" "newline" "trailing" "clean")
  :authors '(("Ethan Glasser-Camp" . "ethan@betacantrips.com"))
  :maintainers '(("Ethan Glasser-Camp" . "ethan@betacantrips.com")))
