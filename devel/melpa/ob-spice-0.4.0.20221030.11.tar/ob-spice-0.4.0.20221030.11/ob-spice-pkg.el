;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-spice" "0.4.0.20221030.11"
  "Org-babel functions for spice evaluation."
  '((spice-mode "0.0.1")
    (org        "8"))
  :url "https://repo.or.cz/ob-spice.git"
  :commit "4d3ab60c2012aba2a5bd96a4d42dfeea0be6edac"
  :revdesc "4d3ab60c2012"
  :maintainers '(("stardiviner" . "(numbchild@gmail.com)")))
