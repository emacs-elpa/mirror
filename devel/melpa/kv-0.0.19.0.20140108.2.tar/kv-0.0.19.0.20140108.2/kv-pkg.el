;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kv" "0.0.19.0.20140108.2"
  "Key/value data structure functions."
  ()
  :url "https://github.com/nicferrier/emacs-kv"
  :commit "721148475bce38a70e0b678ba8aa923652e8900e"
  :revdesc "721148475bce"
  :keywords '("lisp")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
