;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective-project-bridge" "0.1.0.20231024.5"
  "Integration of perspective.el + project.el."
  '((emacs       "27.1")
    (perspective "2.18"))
  :url "https://github.com/arunkmv/perspective-project-bridge"
  :commit "7b65b08a0151b8279fc3ae75f0016cb8d5eadb53"
  :revdesc "7b65b08a0151"
  :keywords '("perspective" "project" "convenience" "frames")
  :authors '(("Arunkumar Vaidyanathan" . "arunkumarmv1997@gmail.com"))
  :maintainers '(("Arunkumar Vaidyanathan" . "arunkumarmv1997@gmail.com")))
