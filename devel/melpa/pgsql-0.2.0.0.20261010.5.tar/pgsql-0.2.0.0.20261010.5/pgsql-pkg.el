;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "0.2.0.0.20261010.5"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "aabac885a0d848c9819b2ebe24096bff3be3415d"
  :revdesc "v0.2.0-5-gaabac885a0d8"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
