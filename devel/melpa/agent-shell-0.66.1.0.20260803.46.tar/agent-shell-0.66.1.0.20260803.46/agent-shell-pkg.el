;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.66.1.0.20260803.46"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "5339d7fb7b7d3b97991ffa48a3c7ff8054a8ec38"
  :revdesc "5339d7fb7b7d")
