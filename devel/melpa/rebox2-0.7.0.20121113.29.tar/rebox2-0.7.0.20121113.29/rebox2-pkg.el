;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rebox2" "0.7.0.20121113.29"
  "Handling of comment boxes in various styles."
  ()
  :url "https://github.com/lewang/rebox2"
  :commit "00634eca420cc48657b81e40e599ff8548083985"
  :revdesc "00634eca420c")
