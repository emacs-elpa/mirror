;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "select-themes" "0.1.4"
  "Color theme selection with completing-read."
  ()
  :url "https://github.com/jasonm23/emacs-select-themes"
  :commit "236f54287519a3ea6dd7b3992d053e4f4ff5d0fe"
  :revdesc "236f54287519"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
