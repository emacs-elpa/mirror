;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-projectile" "1.7.0"
  "Helm integration for Projectile."
  '((emacs      "28.1")
    (helm       "3.0")
    (projectile "3.1.0"))
  :url "https://github.com/bbatsov/helm-projectile"
  :commit "150ab7b669f7d3000718b73fa857dfe0ad641a97"
  :revdesc "150ab7b669f7"
  :keywords '("project" "convenience"))
