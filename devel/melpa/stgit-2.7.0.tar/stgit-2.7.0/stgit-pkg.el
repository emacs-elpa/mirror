;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stgit" "2.7.0"
  "Major mode for StGit interaction."
  ()
  :url "http://stacked-git.github.io"
  :commit "b284e3826e0314693e2f61039b9167ce1b2d7e1d"
  :revdesc "v2.7.0-0-gb284e3826e03"
  :authors '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainers '(("David Kågedal" . "davidk@lysator.liu.se")))
