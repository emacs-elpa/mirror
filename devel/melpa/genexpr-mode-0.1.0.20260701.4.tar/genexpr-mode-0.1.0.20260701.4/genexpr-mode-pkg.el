;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "genexpr-mode" "0.1.0.20260701.4"
  "Major mode for editing GenExpr files."
  '((emacs "27.1"))
  :url "https://github.com/larme/genexpr-mode"
  :commit "b5007dbd80b9468b7b206927791171218f2f5da1"
  :revdesc "b5007dbd80b9"
  :keywords '("languages" "dsp")
  :authors '(("Zhao Shenyang" . "dev@zsy.im"))
  :maintainers '(("Zhao Shenyang" . "dev@zsy.im")))
