;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browsel" "0.93.0.20260629.5"
  "WebSocket bridge to a Chrome/Firefox extension."
  '((emacs     "27.1")
    (websocket "1.13")
    (org       "9.8"))
  :url "https://github.com/dmgerman/browsel"
  :commit "805a4162762c3a1e60ebb791007c788bde0d0be0"
  :revdesc "805a4162762c"
  :keywords '("comm" "tools" "browser" "org")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
