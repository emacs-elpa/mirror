;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-assistant" "1.5.0.20230623.9"
  "Org babel extension for Chat Assistant APIs."
  '((emacs    "28.1")
    (uuidgen  "1.2")
    (deferred "0.5.1")
    (s        "1.12.0")
    (dash     "2.19.1")
    (ht       "0.9"))
  :url "https://github.com/tyler-dodge/org-assistant"
  :commit "d036f82072e22a7fc985e94853deaf65c41d5967"
  :revdesc "d036f82072e2"
  :keywords '("convenience")
  :authors '(("Tyler Dodge" . "(tyler@tdodge.consulting)"))
  :maintainers '(("Tyler Dodge" . "(tyler@tdodge.consulting)")))
