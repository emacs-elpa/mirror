;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-video-thumbnail" "0.1.0.0.20261123.27"
  "Display video thumbnails from dired."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/dired-video-thumbnail"
  :commit "4f58108139412206a88833da4539afcf6f15eada"
  :revdesc "4f5810813941"
  :keywords '("multimedia" "files" "dired"))
