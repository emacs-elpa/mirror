;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frameshot" "1.2.2"
  "Take screenshots of a frame."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/frameshot"
  :commit "6e1f45af13ebaf6ff6f13207c74ed4c5fb8e10c9"
  :revdesc "v1.2.2-0-g6e1f45af13eb"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev")))
