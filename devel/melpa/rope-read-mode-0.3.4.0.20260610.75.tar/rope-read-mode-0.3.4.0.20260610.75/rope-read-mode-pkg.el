;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rope-read-mode" "0.3.4.0.20260610.75"
  "Rearrange lines to read text smoothly."
  '((emacs "24"))
  :url "https://gitlab.com/marcowahl/rope-read-mode"
  :commit "4270080eafa5fe5ce1d1a7ecc7ac4143a7d62a22"
  :revdesc "0.3.4-75-g4270080eafa5"
  :keywords '("reading" "convenience" "chill")
  :authors '(("Marco Wahl" . "marcowahlsoft@gmail.com"))
  :maintainers '(("Marco Wahl" . "marcowahlsoft@gmail.com")))
