;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "turing-machine" "0.2.0.0.20260530.3"
  "Single-tape Turing machine simulator."
  '((emacs "24.4"))
  :url "https://sr.ht/~dieggsy/turing-machine"
  :commit "165f868d5b47b93ca00bc73b0055cdcd7696449d"
  :revdesc "165f868d5b47"
  :keywords '("turing" "machine" "simulation")
  :authors '(("Diego A. Mundo" . "diegoamundo@gmail.com"))
  :maintainers '(("Diego A. Mundo" . "diegoamundo@gmail.com")))
