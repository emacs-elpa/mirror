;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-last-change" "1.2.1.0.20261023.6"
  "Move point through buffer-undo-list positions."
  '((emacs "24.3"))
  :url "https://github.com/camdez/goto-last-change.el"
  :commit "51a058bdd2a1d12fc28909da5bb3a1b7c344976f"
  :revdesc "v1.2.1-6-g51a058bdd2a1"
  :keywords '("convenience")
  :authors '(("Kevin Rodgers" . "ihs_4664@yahoo.com"))
  :maintainers '(("Kevin Rodgers" . "ihs_4664@yahoo.com")))
