;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdffontetc" "0.15.0.20261012.31"
  "Display `pdffont' and other PDF information."
  '((emacs     "24.4")
    (pdf-tools "1.2.0"))
  :url "https://github.com/emacsomancer/pdffontetc"
  :commit "253fb3b9c68f0bbfb8ee4eb77161bc0bdb5d5d18"
  :revdesc "253fb3b9c68f"
  :keywords '("files" "multimedia")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
