;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epx" "0.4.1"
  "Manage and run project-specific shell commands."
  '((emacs "29.1"))
  :url "https://git.sr.ht/~alex-iam/epx"
  :commit "ef8cfb41bf2064c56a61cc0cf96c51f9cc008675"
  :revdesc "ef8cfb41bf20"
  :keywords '("project" "shell" "tools")
  :authors '(("Oleksandr Korzh" . "alex@korzh.me"))
  :maintainers '(("Oleksandr Korzh" . "alex@korzh.me")))
