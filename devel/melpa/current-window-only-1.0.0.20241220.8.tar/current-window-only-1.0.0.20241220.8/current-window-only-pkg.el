;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "current-window-only" "1.0.0.20241220.8"
  "Open things only in the current window."
  '((emacs "25.1"))
  :url "https://github.com/FrostyX/current-window-only"
  :commit "1e9c6fb55a4292c62818035f2bdc159512ac089f"
  :revdesc "1e9c6fb55a42"
  :keywords '("frames")
  :authors '(("Jakub Kadlčík" . "frostyx@email.cz"))
  :maintainers '(("Jakub Kadlčík" . "frostyx@email.cz")))
