;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "malyon" "20161204.0.20161208.12"
  "Mode to execute Z-code files version 3, 5, 8."
  '((cl-lib "0.5"))
  :url "https://github.com/speedenator/malyon"
  :commit "0d9882650720b4a791556f5e2d917388965d6fc0"
  :revdesc "0d9882650720"
  :keywords '("games" "emulations")
  :authors '(("Peter Ilberg" . "peter.ilberg@gmail.com")
             ("Christopher Madsen" . "cjm@cjmweb.net")
             ("Erik Selberg" . "erik@selberg.org"))
  :maintainers '(("Christopher Madsen" . "cjm@cjmweb.net")
                 ("Erik Selberg" . "erik@selberg.org")))
