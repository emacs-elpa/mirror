;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "0.53.0.20261119.99"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (compat    "31")
    (fedi      "0.6")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "f055794b6b9211da154ec02249c0d141558494a7"
  :revdesc "f055794b6b92"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
