;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.14.0.20260828.9"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "5654428d249c727e0a66f58108b7fdac10fdcbfc"
  :revdesc "2.14-9-g5654428d249c"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
