;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "0.4.2"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "26.3")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "e6204de0ca58972c37786533a42d153cb4af3583"
  :revdesc "v0.4.2-0-ge6204de0ca58"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
