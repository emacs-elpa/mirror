;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-exwm" "0.0.2.0.20210215.1"
  "Helm for EXWM buffers."
  '((emacs "25.2")
    (helm  "2.8.5")
    (exwm  "0.15"))
  :url "https://github.com/emacs-helm/helm-exwm"
  :commit "5b35a42ff10fbcbf673268987df700ea6b6288e8"
  :revdesc "5b35a42ff10f"
  :keywords '("helm" "exwm")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
