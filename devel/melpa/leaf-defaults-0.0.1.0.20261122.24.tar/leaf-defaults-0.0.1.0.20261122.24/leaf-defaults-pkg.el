;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leaf-defaults" "0.0.1.0.20261122.24"
  "Awesome leaf config collections."
  '((emacs         "26.1")
    (leaf          "4.5.5")
    (leaf-keywords "2.0.8"))
  :url "https://github.com/conao3/leaf-defaults.el"
  :commit "d670b1dc2ec9d22b670858439e1db1dab2d4da4e"
  :revdesc "d670b1dc2ec9"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
