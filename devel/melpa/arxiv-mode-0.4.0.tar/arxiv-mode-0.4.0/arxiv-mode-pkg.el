;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arxiv-mode" "0.4.0"
  "Read and search for articles on arXiv.org."
  '((emacs "27.1")
    (hydra "0"))
  :url "https://github.com/fizban007/arxiv-mode"
  :commit "f629ec64f8bbac0cadb472c6741f8f33d49e9160"
  :revdesc "f629ec64f8bb"
  :keywords '("bib" "convenience" "hypermedia")
  :authors '(("Alex Chen" . "fizban007@gmail.com")
             ("Simon Lin" . "n.sibetz@gmail.com"))
  :maintainers '(("Alex Chen" . "fizban007@gmail.com")
                 ("Simon Lin" . "n.sibetz@gmail.com")))
