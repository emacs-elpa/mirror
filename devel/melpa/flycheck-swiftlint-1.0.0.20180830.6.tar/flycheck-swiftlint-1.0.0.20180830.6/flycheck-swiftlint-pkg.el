;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-swiftlint" "1.0.0.20180830.6"
  "Flycheck extension for Swiftlint."
  '((emacs    "25.1")
    (flycheck "0.25"))
  :url "https://github.com/jojojames/flycheck-swiftlint"
  :commit "65101873c4c9f8e7eac9471188b161eeddda1555"
  :revdesc "65101873c4c9"
  :keywords '("languages" "swiftlint" "swift" "emacs")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
