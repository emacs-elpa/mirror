;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stillness-mode" "0.1.0.20260824.28"
  "Prevent windows from jumping on minibuffer activation."
  '((emacs "26.1")
    (dash  "2.18.0"))
  :url "https://github.com/neeasade/stillness-mode.el"
  :commit "2f8682a4358ba778021feaa6afc36d249d2316eb"
  :revdesc "2f8682a4358b"
  :keywords '("convenience"))
