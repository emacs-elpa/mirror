;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aggressive-fill-paragraph" "0.0.1.0.20240213.63"
  "A mode to automatically keep paragraphs filled."
  '((dash "2.10.0"))
  :url "https://github.com/davidshepherd7/aggressive-fill-paragraph-mode"
  :commit "60e4eb5c57d4408e811d12c6b6491b8c89dfa695"
  :revdesc "60e4eb5c57d4"
  :keywords '("fill-paragraph" "automatic" "comments")
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
