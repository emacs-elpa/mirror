;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.6.0.0.20260720.8"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "cc1fdc014e9421a9c3d96929af7eb6c5149b2281"
  :revdesc "cc1fdc014e94"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
