;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "turtles" "2.0.1.0.20250315.2"
  "Screen-grabbing test utility."
  '((emacs  "26.1")
    (compat "30.0.1.0"))
  :url "https://github.com/szermatt/turtles"
  :commit "7dca66a67173c63b27d5c6d8aa3e0248fd7f8b83"
  :revdesc "7dca66a67173"
  :keywords '("testing" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
