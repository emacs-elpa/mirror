;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wallpreview" "2.0.0"
  "Set wallpapers with image-dired."
  '((emacs "24.4"))
  :url "https://github.com/nryotaro/wallpreview"
  :commit "6eae0549afdfe725b453ca4fb0878c728735892d"
  :revdesc "6eae0549afdf")
