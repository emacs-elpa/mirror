;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-rouge-theme" "2.0.0.20260122.1"
  "Color theme inspired by the Rouge Theme for VSCode."
  '((emacs "27.1"))
  :url "https://gitlab.com/aimebertrand/timu-rouge-theme"
  :commit "a46e960a8f5aa078ec055bc1b819be52182fda0f"
  :revdesc "a46e960a8f5a"
  :keywords '("faces" "themes")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
