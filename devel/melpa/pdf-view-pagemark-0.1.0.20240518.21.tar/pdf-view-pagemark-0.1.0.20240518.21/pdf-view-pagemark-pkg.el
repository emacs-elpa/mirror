;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdf-view-pagemark" "0.1.0.20240518.21"
  "Add indicator in pdfview mode to show the page remaining."
  '((pdf-tools "0.90")
    (posframe  "1.4.2")
    (emacs     "26.0"))
  :url "https://github.com/kimim/pdf-view-pagemark"
  :commit "a746cf8b86d030ebfc61bb2ff10c0e16b5d195c6"
  :revdesc "a746cf8b86d0"
  :keywords '("multimedia" "convenience")
  :authors '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainers '(("Kimi Ma" . "kimi.im@outlook.com")))
