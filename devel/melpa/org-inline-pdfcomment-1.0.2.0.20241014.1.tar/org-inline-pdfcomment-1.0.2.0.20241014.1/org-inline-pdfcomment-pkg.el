;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-inline-pdfcomment" "1.0.2.0.20241014.1"
  "Export Support for Inline Tasks as PDF Comments."
  '((emacs "24.4"))
  :url "https://git.sr.ht/~swflint/org-inline-pdfcomment"
  :commit "a0af513b24deffcee14c27641477fef65b228696"
  :revdesc "v1.0.2-1-ga0af513b24de"
  :keywords '("docs" "text")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
