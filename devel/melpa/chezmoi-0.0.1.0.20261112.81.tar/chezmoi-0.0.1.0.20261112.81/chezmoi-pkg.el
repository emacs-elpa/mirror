;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chezmoi" "0.0.1.0.20261112.81"
  "A package for interacting with chezmoi."
  '((emacs "27.1"))
  :url "http://www.github.com/tuh8888/chezmoi.el"
  :commit "a7382020a929274e07b5318af9ba7dd8d64300b7"
  :revdesc "a7382020a929"
  :keywords '("vc"))
