;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.4.2.0.20261102.4"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.5.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "6cdd752b697755373f683f62fcabc4ac5b125d44"
  :revdesc "v3.4.2-4-g6cdd752b6977"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
