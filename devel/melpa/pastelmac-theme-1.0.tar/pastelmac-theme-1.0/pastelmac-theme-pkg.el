;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pastelmac-theme" "1.0"
  "A soothing theme with a pastel color palette."
  '((emacs "24.1"))
  :url "https://github.com/bmastenbrook/pastelmac-theme-el"
  :commit "bead21741e3f46f6506e8aef4469d4240a819389"
  :revdesc "bead21741e3f"
  :keywords '("themes")
  :authors '(("Brian Mastenbrook" . "brian@mastenbrook.net"))
  :maintainers '(("Brian Mastenbrook" . "brian@mastenbrook.net")))
