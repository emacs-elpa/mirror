;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bf-mode" "0.0.1.0.20130403.3"
  "Browse file persistently on dired."
  ()
  :url "https://github.com/emacs-jp/bf-mode"
  :commit "7cc4d09aed64d9db6be95646f5f5067de68f8895"
  :revdesc "7cc4d09aed64"
  :keywords '("convenience")
  :maintainers '(("myuhe" . "yuhei.maeda_at_gmail.com")))
