;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atom-one-dark-theme" "0.4.0.0.20260821.118"
  "Atom One Dark color theme."
  ()
  :url "https://github.com/jonathanchu/atom-one-dark-theme"
  :commit "9901e806b37ec92f9b7095cf00303d675ba8534c"
  :revdesc "0.4.0-118-g9901e806b37e"
  :keywords '("faces")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
