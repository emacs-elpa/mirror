;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ewal" "0.2.1.0.20200305.1"
  "A pywal-based theme generator."
  '((emacs "25.1"))
  :url "https://gitlab.com/jjzmajic/ewal"
  :commit "4ecc355dae9c7d648cd2874e01a15dfa02b9350d"
  :revdesc "4ecc355dae9c"
  :keywords '("faces"))
