;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-parser" "0.4.0.20200417.5"
  "Parse org files into structured datatypes."
  '((emacs "25.1")
    (dash  "2.12.0")
    (ht    "2.1"))
  :url "https://hg.sr.ht/~zck/org-parser"
  :commit "fd4cb7035ff649378cc968b1ec2c386b5c565706"
  :revdesc "fd4cb7035ff6"
  :keywords '("files" "outlines" "tools"))
