;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "curry-on-theme" "1.0.0.20210322.10"
  "A low contrast color theme."
  '((emacs "24.1"))
  :url "https://github.com/mvarela/Curry-On-Theme"
  :commit "b53a61d443cc75906d9f97e19f19be71f1e19bc4"
  :revdesc "b53a61d443cc"
  :authors '(("Martín Varela" . "(martin@varela.fi)"))
  :maintainers '(("Martín Varela" . "(martin@varela.fi)")))
