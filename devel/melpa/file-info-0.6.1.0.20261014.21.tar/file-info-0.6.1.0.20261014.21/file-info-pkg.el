;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "file-info" "0.6.1.0.20261014.21"
  "Show pretty information about current file."
  '((emacs            "28.1")
    (hydra            "0.15.0")
    (browse-at-remote "0.15.0"))
  :url "https://github.com/artawower/file-info.el"
  :commit "1eb781f5b0c38a947a3c34df2101ced0b75236d7"
  :revdesc "1eb781f5b0c3"
  :authors '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers '(("Artur Yaroshenko" . "artawower@protonmail.com")))
