;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-yasnippet" "0.3.0.0.20230208.39"
  "Quickly create disposable yasnippets."
  '((yasnippet "0.14.0")
    (emacs     "25.1"))
  :url "https://github.com/abo-abo/auto-yasnippet"
  :commit "6a9e406d0d7f9dfd6dff7647f358cb05a0b1637e"
  :revdesc "6a9e406d0d7f"
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com")
             ("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
