;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp-server-lib" "0.3.0.0.20260630.19"
  "Model Context Protocol server library."
  '((emacs "27.1"))
  :url "https://github.com/laurynas-biveinis/mcp-server-lib.el"
  :commit "dec55e6405987250256a81efe92d65bdfa8a140c"
  :revdesc "0.3.0-19-gdec55e640598"
  :keywords '("comm" "tools")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
