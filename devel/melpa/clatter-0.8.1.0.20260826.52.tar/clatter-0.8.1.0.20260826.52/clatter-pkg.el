;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.8.1.0.20260826.52"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "832a21c37a77f72373e37316601fa8532d63a232"
  :revdesc "832a21c37a77"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
