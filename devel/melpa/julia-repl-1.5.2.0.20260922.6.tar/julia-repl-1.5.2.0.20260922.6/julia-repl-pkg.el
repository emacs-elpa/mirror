;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-repl" "1.5.2.0.20260922.6"
  "A minor mode for a Julia REPL."
  '((emacs  "29.1")
    (s      "1.12")
    (compat "31.1"))
  :url "https://github.com/tpapp/julia-repl"
  :commit "7c818163388c732aeaee0b629b4559e5087c00ba"
  :revdesc "7c818163388c"
  :keywords '("languages")
  :authors '(("Tamas Papp" . "tkpapp@gmail.com"))
  :maintainers '(("Tamas Papp" . "tkpapp@gmail.com")))
