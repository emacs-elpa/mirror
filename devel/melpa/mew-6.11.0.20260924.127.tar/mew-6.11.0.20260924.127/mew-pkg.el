;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20260924.127"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "bceed3e808d0b9da3b9aaaf2d8fb8fe0a08302e0"
  :revdesc "bceed3e808d0")
