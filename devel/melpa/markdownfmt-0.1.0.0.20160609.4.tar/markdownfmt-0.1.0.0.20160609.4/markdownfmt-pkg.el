;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdownfmt" "0.1.0.0.20160609.4"
  "Format markdown using markdownfmt."
  '((emacs "24"))
  :url "https://github.com/nlamirault/emacs-markdownfmt"
  :commit "af83cd00fafcaa837ffdb50d1fa2b0ac952f16c0"
  :revdesc "af83cd00fafc"
  :keywords '("markdown")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
