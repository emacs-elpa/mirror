;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "0.8.1.0.20260810.1"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "2c2fef8209def9de6e77ad91bb86fc4f01297617"
  :revdesc "2c2fef8209de"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
