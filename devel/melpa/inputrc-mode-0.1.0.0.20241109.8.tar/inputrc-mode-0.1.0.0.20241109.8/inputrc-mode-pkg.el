;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inputrc-mode" "0.1.0.0.20241109.8"
  "Major mode for readline configuration."
  '((emacs "27.1"))
  :url "https://github.com/nverno/inputrc-mode"
  :commit "2ccf09ae19f3cbb2b8c35dcd54ed333d688fffae"
  :revdesc "2ccf09ae19f3"
  :keywords '("languages" "readline" "config")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
