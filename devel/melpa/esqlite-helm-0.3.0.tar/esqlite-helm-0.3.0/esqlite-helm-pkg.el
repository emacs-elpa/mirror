;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esqlite-helm" "0.3.0"
  "Define helm source for sqlite database."
  '((esqlite "0.2.0")
    (helm    "20131207.845"))
  :url "https://github.com/mhayashi1120/Emacs-esqlite"
  :commit "84d5b16198f30949c544affba751ee0d58a000d9"
  :revdesc "84d5b16198f3"
  :keywords '("data")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
