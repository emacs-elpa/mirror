;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "puni" "0.0.0.20260519.110"
  "Parentheses Universalistic."
  '((emacs "26.1"))
  :url "https://github.com/AmaiKinono/puni"
  :commit "04819e0bad5ed62af9e412ef9715b33bb1edc3ba"
  :revdesc "04819e0bad5e"
  :keywords '("convenience" "lisp" "tools")
  :authors '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainers '(("Hao Wang" . "amaikinono@gmail.com")))
