;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel" "0.15.1.0.20260214.25"
  "Various completion functions using Ivy."
  '((emacs  "24.5")
    (ivy    "0.15.1")
    (swiper "0.15.1"))
  :url "https://github.com/abo-abo/swiper"
  :commit "ee79f68215ae7e2b8a38ba6bf7f82b3fe57dc16c"
  :revdesc "0.15.1-25-gee79f68215ae"
  :keywords '("convenience" "matching" "tools")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
