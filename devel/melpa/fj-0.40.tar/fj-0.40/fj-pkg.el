;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "0.40"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "6b86044174c55820149fb256d12f55ac81ea6805"
  :revdesc "6b86044174c5"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
