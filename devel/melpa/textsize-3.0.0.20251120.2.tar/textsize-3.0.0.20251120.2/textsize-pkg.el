;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "textsize" "3.0.0.20251120.2"
  "Configure frame text size automatically."
  '((emacs "26.1"))
  :url "https://github.com/WJCFerguson/textsize"
  :commit "cfcc4d6a351c43692f408e5f0fd68de2974fcb9f"
  :revdesc "3.0-2-gcfcc4d6a351c"
  :keywords '("convenience")
  :authors '(("James Ferguson" . "james@faff.org"))
  :maintainers '(("James Ferguson" . "james@faff.org")))
