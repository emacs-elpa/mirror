;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elx" "2.3.4.0.20261117.3"
  "Extract information from Emacs Lisp libraries."
  '((emacs    "30.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/elx"
  :commit "feffbfda008d2c9f90e0fbb54df70a5c84d82515"
  :revdesc "v2.3.4-3-gfeffbfda008d"
  :keywords '("docs" "libraries" "packages")
  :authors '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev")))
