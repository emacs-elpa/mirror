;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wgrep-ack" "1.0.0.0.20230207.3"
  "Writable ack-and-a-half buffer."
  '((emacs "25.1")
    (wgrep "3.0.0"))
  :url "https://github.com/mhayashi1120/Emacs-wgrep/raw/master/wgrep-ack.el"
  :commit "edf768732a56840db6879706b64c5773c316d619"
  :revdesc "edf768732a56"
  :keywords '("grep" "edit" "extensions")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
