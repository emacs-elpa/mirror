;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "4.1.1.0.20260805.1"
  "An Atom/RSS feed reader."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "2970e5d1aa2a6f5c4cb607e0b835b91a6bffec4f"
  :revdesc "4.1.1-1-g2970e5d1aa2a"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
