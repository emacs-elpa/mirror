;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "genexpr-mode" "0.1.0.20240930.3"
  "Major mode for editing GenExpr files."
  '((emacs "27.1"))
  :url "https://github.com/larme/genexpr-mode"
  :commit "27d9d4d32aef1799698ddbf75e92cb71d0ce99bf"
  :revdesc "27d9d4d32aef"
  :keywords '("languages" "dsp")
  :authors '(("Zhao Shenyang" . "dev@zsy.im"))
  :maintainers '(("Zhao Shenyang" . "dev@zsy.im")))
