;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "todotxt-mode" "0.0.0.20240802.34"
  "Major mode for editing todo.txt files."
  ()
  :url "https://github.com/avillafiorita/todotxt-mode"
  :commit "ca4310cfcce4d1f3a6670b31412a9b56462e5b5d"
  :revdesc "ca4310cfcce4"
  :keywords '("wp" "files")
  :authors '(("Adolfo Villafiorita" . "adolfo.villafiorita@me.com"))
  :maintainers '(("Adolfo Villafiorita" . "adolfo.villafiorita@me.com")))
