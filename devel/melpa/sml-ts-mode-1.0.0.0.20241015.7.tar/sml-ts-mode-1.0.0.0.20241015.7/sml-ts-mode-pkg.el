;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sml-ts-mode" "1.0.0.0.20241015.7"
  "SML major-mode using tree-sitter."
  '((emacs    "29.1")
    (sml-mode "6.12"))
  :url "https://github.com/nverno/sml-ts-mode"
  :commit "d2dabcc9d8f91eeee7048641e4c80fabb3583194"
  :revdesc "d2dabcc9d8f9"
  :keywords '("sml" "languages" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
