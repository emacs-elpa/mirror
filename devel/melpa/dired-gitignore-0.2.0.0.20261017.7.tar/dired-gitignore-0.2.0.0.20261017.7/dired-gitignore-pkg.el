;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-gitignore" "0.2.0.0.20261017.7"
  "A minor mode to hide gitignored files in a dired buffer."
  '((emacs "26.1"))
  :url "https://github.com/johannes-mueller/dired-gitignore.el"
  :commit "87bf4a1818ec402837c7b51a1267f64f686a2bed"
  :revdesc "87bf4a1818ec"
  :keywords '("dired" "convenience" "git")
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
