;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-markdownlint" "0.1.3"
  "Markdown linter with markdownlint."
  '((emacs "27.1"))
  :url "https://github.com/shaohme/flymake-markdownlint"
  :commit "59e3520668d9394c573e07b7980a2d48d9f6086c"
  :revdesc "59e3520668d9"
  :authors '(("Martin Kjær Jørgensen" . "mkj@gotu.dk"))
  :maintainers '(("Martin Kjær Jørgensen" . "mkj@gotu.dk")))
