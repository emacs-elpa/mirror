;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2.0.20260827.40"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "4b1318c6f47dbc7eac60891a133f85f66737b631"
  :revdesc "4b1318c6f47d"
  :keywords '("faces" "files" "q"))
