;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex-plus" "1.0.1"
  "Grammar and spell checking for LaTeX, Markdown, Org and more."
  '((emacs "29.1"))
  :url "https://github.com/ltex-plus/emacs-ltex-plus"
  :commit "ac5f25389713a653e80433d2fd1ee22d14f4dea5"
  :revdesc "v1.0.1-0-gac5f25389713"
  :keywords '("lsp" "grammar" "spelling" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
