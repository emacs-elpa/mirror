;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-org-multi-wiki" "0.4.0.0.20210228.101"
  "Helm interface to org-multi-wiki."
  '((emacs          "26.1")
    (org            "9.3")
    (org-multi-wiki "0.4")
    (org-ql         "0.5")
    (dash           "2.18")
    (helm-org-ql    "0.5")
    (helm           "3.5"))
  :url "https://github.com/akirak/org-multi-wiki"
  :commit "c85bcaafed749de3efa5e1f4d256e7ac9c5678e2"
  :revdesc "c85bcaafed74"
  :keywords '("org" "outlines")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
