;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-x" "1.0.0.20260619.88"
  "Python.el extras for interactive evaluation."
  '((python  "0.24")
    (folding "0.0")
    (emacs   "24.5")
    (compat  "26.1"))
  :url "https://gitlab.com/wavexx/python-x.el"
  :commit "548a95c42c110cd65b559416e497de20f5c21d92"
  :revdesc "v1.0-88-g548a95c42c11"
  :keywords '("languages" "processes" "python" "eval" "folding")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
