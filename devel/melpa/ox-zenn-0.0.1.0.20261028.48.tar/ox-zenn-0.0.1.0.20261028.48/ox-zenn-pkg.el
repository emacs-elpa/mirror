;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-zenn" "0.0.1.0.20261028.48"
  "Zenn flavored markdown backend for org export engine."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/conao3/ox-zenn.el"
  :commit "21628f8652659e285e629284db5d2959fca934f0"
  :revdesc "21628f865265"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
