;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.4.0.0.20260825.16"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "5d4b70f6f5c12930166c6c0bcf68d80b90c96285"
  :revdesc "v1.4.0-16-g5d4b70f6f5c1"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
