;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.2.0.0.20260627.19"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "07f7a93729c63d63f826bdecb71d702f0e9a0083"
  :revdesc "07f7a93729c6"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
