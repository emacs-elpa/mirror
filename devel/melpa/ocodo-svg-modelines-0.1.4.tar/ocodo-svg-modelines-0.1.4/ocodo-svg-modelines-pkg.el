;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocodo-svg-modelines" "0.1.4"
  "[No description available]."
  '((svg-mode-line-themes "0"))
  :url "https://github.com/ocodo/ocodo-svg-modelines"
  :commit "a6c5b9a7536c7a8fa3bd9d9dafdebc8d99903018"
  :revdesc "a6c5b9a7536c"
  :authors '(("ocodo" . "what.is.ocodo@gmail.com"))
  :maintainers '(("ocodo" . "what.is.ocodo@gmail.com")))
