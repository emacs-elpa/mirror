;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebib" "2.53.1.0.20261016.2"
  "A BibTeX database manager."
  '((parsebib "6.0")
    (emacs    "27.1")
    (compat   "29.1.4.3"))
  :url "http://joostkremers.github.io/ebib/"
  :commit "c9a6c728c6610cd4bbabec5d2ba3a1049f8fdfc8"
  :revdesc "c9a6c728c661"
  :keywords '("text" "bibtex")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
