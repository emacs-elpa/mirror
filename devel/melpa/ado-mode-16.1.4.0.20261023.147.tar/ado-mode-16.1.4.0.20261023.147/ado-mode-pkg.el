;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ado-mode" "16.1.4.0.20261023.147"
  "Major mode for editing Stata-related files."
  '((emacs "25.1"))
  :url "https://github.com/louabill/ado-mode"
  :commit "699a2e0aa0c3d2afcc404b28f0ee267b63b1d115"
  :revdesc "16.1.4-147-g699a2e0aa0c3"
  :keywords '("tools" "languages" "files" "convenience" "stata" "mata" "ado")
  :authors '(("Bill Rising" . "brising@alum.mit.edu"))
  :maintainers '(("Bill Rising" . "brising@alum.mit.edu")))
