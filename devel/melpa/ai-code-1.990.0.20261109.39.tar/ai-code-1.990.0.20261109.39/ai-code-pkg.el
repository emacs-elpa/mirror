;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.990.0.20261109.39"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a6bc8c7477dbedc3f419ebc356573c1413a9fb57"
  :revdesc "a6bc8c7477db"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
