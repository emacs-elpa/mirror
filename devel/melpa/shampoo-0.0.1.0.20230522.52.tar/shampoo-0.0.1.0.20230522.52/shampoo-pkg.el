;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shampoo" "0.0.1.0.20230522.52"
  "A remote Smalltalk development mode."
  '((emacs "24.1"))
  :url "https://revival.sh/shampoo/"
  :commit "4112f3b9282be0ce1f334e148f5c89b03a5df40c"
  :revdesc "4112f3b9282b"
  :keywords '("languages")
  :authors '(("Dmitry Matveev" . "me@dmitrymatveev.co.uk"))
  :maintainers '(("Dmitry Matveev" . "me@dmitrymatveev.co.uk")))
