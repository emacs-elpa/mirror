;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-printf" "1.0.0.0.20250926.18"
  "Minor mode for highlighting \"printf\" format specifiers."
  '((emacs  "24.1")
    (compat "29.1.0.1"))
  :url "https://github.com/8dcc/hl-printf.el"
  :commit "f2f534efaa1788b66a50a8e811c19d48275f26f4"
  :revdesc "f2f534efaa17"
  :keywords '("c" "faces")
  :authors '(("8dcc" . "8dcc.git@gmail.com"))
  :maintainers '(("8dcc" . "8dcc.git@gmail.com")))
