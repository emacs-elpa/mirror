;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-trepan-ni" "1.0.1.0.20210513.13"
  "Realgud front-end to trepan-ni."
  '((load-relative "1.2")
    (realgud       "1.5.0")
    (emacs         "25"))
  :url "https://github.com/realgud/realgud-trepan-ni"
  :commit "0ec088ea343835e24ae73da09bea96bfb02a3130"
  :revdesc "0ec088ea3438"
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
