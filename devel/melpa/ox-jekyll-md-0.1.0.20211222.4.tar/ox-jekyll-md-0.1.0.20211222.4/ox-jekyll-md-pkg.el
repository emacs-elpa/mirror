;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-jekyll-md" "0.1.0.20211222.4"
  "Export Jekyll on Markdown articles using org-mode."
  ()
  :url "https://github.com/gonsie/ox-jekyll-md"
  :commit "26edb3f4575bcb0f1a2aed56237cd89694284449"
  :revdesc "26edb3f4575b"
  :keywords '("org" "jekyll")
  :authors '(("Elsa Gonsiorowski" . "gonsie@me.com"))
  :maintainers '(("Elsa Gonsiorowski" . "gonsie@me.com")))
