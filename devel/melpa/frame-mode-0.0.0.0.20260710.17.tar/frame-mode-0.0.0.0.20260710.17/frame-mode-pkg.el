;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frame-mode" "0.0.0.0.20260710.17"
  "Use frames instead of windows."
  '((s     "1.9.0")
    (emacs "24.4"))
  :url "https://github.com/IvanMalison/frame-mode"
  :commit "462f86b550771743765edcf699041a27ddc3c5c2"
  :revdesc "462f86b55077"
  :keywords '("frames")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
