;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-last-point" "0.1.0.0.20230406.26"
  "Record and jump to the last point in the buffer."
  '((emacs "24.3"))
  :url "https://github.com/manuel-uberti/goto-last-point"
  :commit "2ad8ff095bc34b433803c824ec4f500ff51cd1b2"
  :revdesc "2ad8ff095bc3"
  :keywords '("convenience")
  :authors '(("Manuel Uberti" . "manuel.uberti@inventati.org"))
  :maintainers '(("Manuel Uberti" . "manuel.uberti@inventati.org")))
