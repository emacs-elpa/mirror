;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-org-todos" "0.1.2.0.20180709.6"
  "Add local todo items to the magit status buffer."
  '((magit "2.0.0")
    (emacs "24"))
  :url "https://github.com/danielma/magit-org-todos"
  :commit "9ffa3efb098434d837cab4bacd1601fdfc6fe999"
  :revdesc "9ffa3efb0984"
  :keywords '("org-mode" "magit" "tools"))
