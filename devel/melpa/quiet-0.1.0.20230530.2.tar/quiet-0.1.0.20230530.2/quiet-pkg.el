;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quiet" "0.1.0.20230530.2"
  "Disconnect from the online world for a while."
  ()
  :url "https://github.com/zzkt/quiet"
  :commit "985b56606517971330c08686c49a8d06db763f3c"
  :revdesc "0.1-2-g985b56606517"
  :keywords '("convenience" "quiet" "distraction" "network" "detachment" "offline")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
