;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difftastic" "1.0.0.0.20260408.5"
  "Wrapper for difftastic."
  '((emacs     "28.1")
    (compat    "29.1.4.2")
    (magit     "4.0.0")
    (transient "0.4.0"))
  :url "https://github.com/pkryger/difftastic.el"
  :commit "7db20929cac31687a529943c3d8d5b44fd8d69e2"
  :revdesc "v1.0.0-5-g7db20929cac3"
  :keywords '("tools" "diff")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
