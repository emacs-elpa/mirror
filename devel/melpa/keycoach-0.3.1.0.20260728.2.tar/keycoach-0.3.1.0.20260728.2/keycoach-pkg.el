;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keycoach" "0.3.1.0.20260728.2"
  "Remember and learn new keybindings."
  '((emacs "25.1"))
  :url "https://github.com/mrcnski/keycoach"
  :commit "9a10d6f4678b54c773b8b3744b0d3785af341907"
  :revdesc "9a10d6f4678b"
  :keywords '("help")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
