;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-fuzzy-find" "0.2.0.20171106.6"
  "Find file using Fuzzy Search."
  '((emacs "24.1")
    (helm  "1.7.0"))
  :url "https://github.com/xuchunyang/helm-fuzzy-find"
  :commit "de2abbf7ca13609587325bacd4a1ed4376b5c927"
  :revdesc "de2abbf7ca13"
  :keywords '("helm" "fuzzy" "find" "file")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
