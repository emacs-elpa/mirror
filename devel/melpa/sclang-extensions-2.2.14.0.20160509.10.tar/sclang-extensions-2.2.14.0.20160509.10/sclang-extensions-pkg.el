;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sclang-extensions" "2.2.14.0.20160509.10"
  "Extensions for the SuperCollider Emacs mode."
  '((auto-complete "1.4.0")
    (s             "1.3.1")
    (dash          "1.2.0")
    (emacs         "24.1"))
  :url "https://github.com/chrisbarrett/sclang-extensions"
  :commit "e9cc79732f16fdb582129303110c163dcc0d6da0"
  :revdesc "e9cc79732f16"
  :keywords '("sclang" "supercollider" "languages" "tools")
  :authors '(("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainers '(("Chris Barrett" . "chris.d.barrett@me.com")))
