;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "0.9.0.0.20260626.6"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "3a7a9b75b3bba52cf27764a1d9d467722214fcd2"
  :revdesc "3a7a9b75b3bb"
  :keywords '("convenience"))
