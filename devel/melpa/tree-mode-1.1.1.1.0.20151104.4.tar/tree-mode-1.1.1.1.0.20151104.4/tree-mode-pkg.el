;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-mode" "1.1.1.1.0.20151104.4"
  "A mode to manage tree widgets."
  ()
  :url "https://github.com/emacsorphanage/tree-mode"
  :commit "b06078826d5875d74b0e7b7ac47b0d0917610534"
  :revdesc "b06078826d58"
  :keywords '("help" "convenience" "widget")
  :authors '((nil . "wenbinye@163.com"))
  :maintainers '((nil . "wenbinye@163.com")))
