;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paxedit" "1.1.8.0.20160730.2"
  "Structured, Context Driven LISP Editing and Refactoring."
  '((cl-lib  "0.5")
    (paredit "23"))
  :url "https://github.com/promethial/paxedit"
  :commit "48df0a26285f68cd20ea64368e7bf2a5fbf13135"
  :revdesc "48df0a26285f"
  :keywords '("lisp" "refactoring" "context"))
