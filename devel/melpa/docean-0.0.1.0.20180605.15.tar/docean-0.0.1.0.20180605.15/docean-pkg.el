;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docean" "0.0.1.0.20180605.15"
  "Interact with DigitalOcean from Emacs."
  '((emacs   "24")
    (cl-lib  "0.5")
    (request "0.2.0"))
  :url "https://github.com/emacs-pe/docean.el"
  :commit "bbe2298fd21f7876fc2d5c52a69b931ff59df979"
  :revdesc "bbe2298fd21f"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
