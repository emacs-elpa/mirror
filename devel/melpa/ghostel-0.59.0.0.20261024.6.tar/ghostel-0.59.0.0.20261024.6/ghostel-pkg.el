;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.59.0.0.20261024.6"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "7c55ea50103c0fdd5c406000712d0a3f246e54f1"
  :revdesc "7c55ea50103c"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
