;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clean-kill-ring" "2.6.0.20260306.2"
  "Keep the kill ring clean."
  '((emacs "24.4"))
  :url "https://github.com/NicholasBHubbard/clean-kill-ring.el"
  :commit "23ce71747f7440eff6368ed045133c3ae694b6fb"
  :revdesc "23ce71747f74"
  :keywords '("kill-ring" "convenience")
  :authors '(("Nicholas Hubbard" . "nicholashubbard@posteo.net"))
  :maintainers '(("Nicholas Hubbard" . "nicholashubbard@posteo.net")))
