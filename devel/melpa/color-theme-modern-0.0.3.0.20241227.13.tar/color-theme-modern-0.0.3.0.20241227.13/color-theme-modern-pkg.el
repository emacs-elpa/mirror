;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-modern" "0.0.3.0.20241227.13"
  "Ports of color-theme themes to deftheme."
  '((emacs "24"))
  :url "https://github.com/emacs-jp/replace-colorthemes"
  :commit "99839fe205ff7dd299b15355e98e6b0aeb9cc646"
  :revdesc "99839fe205ff"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
