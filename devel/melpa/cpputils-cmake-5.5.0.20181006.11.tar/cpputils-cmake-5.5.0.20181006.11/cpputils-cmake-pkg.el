;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cpputils-cmake" "5.5.0.20181006.11"
  "Easy realtime C++ syntax check and IntelliSense with CMake."
  ()
  :url "https://github.com/redguardtoo/cpputils-cmake"
  :commit "64b2b05eff5398b4cd522e66efaf14553ab18ff4"
  :revdesc "64b2b05eff53"
  :keywords '("cmake" "intellisense" "flymake" "flycheck")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
