;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hel" "0.13.0"
  "Helix Emulation Layer."
  '((emacs        "29.1")
    (dash         "2.19.1")
    (avy          "0.5.0")
    (pcre2el      "1.12")
    (ultra-scroll "0.6"))
  :url "https://github.com/helheim-emacs/hel"
  :commit "79736ed7891935e8304381727fbe239e64d9c9af"
  :revdesc "79736ed78919"
  :authors '(("Yuriy Artemyev" . "anuvyklack@gmail.com"))
  :maintainers '(("Yuriy Artemyev" . "anuvyklack@gmail.com")))
