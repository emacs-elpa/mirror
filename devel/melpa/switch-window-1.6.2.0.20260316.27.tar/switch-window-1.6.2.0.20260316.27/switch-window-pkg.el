;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "switch-window" "1.6.2.0.20260316.27"
  "A *visual* way to switch window."
  '((emacs "24"))
  :url "https://github.com/dimitri/switch-window"
  :commit "1ccbfa53df499cb31d5ebbe21306cdcc6b06c135"
  :revdesc "1ccbfa53df49"
  :keywords '("convenience")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org")
             ("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")
                 ("Feng Shu" . "tumashu@163.com")))
