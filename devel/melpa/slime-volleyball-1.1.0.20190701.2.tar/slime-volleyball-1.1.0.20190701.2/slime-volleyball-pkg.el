;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime-volleyball" "1.1.0.20190701.2"
  "An SVG Slime Volleyball Game."
  ()
  :url "https://github.com/fitzsim/slime-volleyball"
  :commit "6c135ad18897c3566d4dadfe847061532600ba2e"
  :revdesc "v1.1-2-g6c135ad18897"
  :keywords '("games")
  :authors '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org"))
  :maintainers '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org")))
