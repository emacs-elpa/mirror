;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "biblio" "0.3.0.20250812.3"
  "Browse and import bibliographic references and BibTeX records from CrossRef, arXiv, DBLP, HAL, IEEE Xplore, Dissemin, and doi.org."
  '((emacs       "24.3")
    (biblio-core "0.3"))
  :url "https://github.com/cpitclaudel/biblio.el"
  :commit "bb9d6b4b962fb2a4e965d27888268b66d868766b"
  :revdesc "0.3-3-gbb9d6b4b962f"
  :keywords '("bib" "tex" "convenience" "hypermedia")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
