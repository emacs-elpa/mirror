;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "0.1.0.20261124.43"
  "Advent of Code mode."
  '((emacs "29.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "bcf9898f080c19978db1c6d03ce6def336ab101c"
  :revdesc "bcf9898f080c"
  :keywords '("lisp")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
