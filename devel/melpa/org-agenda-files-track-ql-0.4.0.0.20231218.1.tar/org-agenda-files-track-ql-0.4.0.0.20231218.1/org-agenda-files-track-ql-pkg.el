;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-agenda-files-track-ql" "0.4.0.0.20231218.1"
  "Fine-track `org-agenda-files' to speed-up `org-ql-views'."
  '((emacs  "27.1")
    (org-ql "0.7.3"))
  :url "https://git.sr.ht/~ngraves/org-agenda-files-track"
  :commit "832cffe62c35f32850afb800e9a3b8a20a05ad7b"
  :revdesc "832cffe62c35"
  :keywords '("data" "files" "tools")
  :authors '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainers '(("Nicolas Graves" . "ngraves@ngraves.fr")))
