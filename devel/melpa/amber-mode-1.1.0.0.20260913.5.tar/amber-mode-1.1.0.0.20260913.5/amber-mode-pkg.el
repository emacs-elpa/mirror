;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amber-mode" "1.1.0.0.20260913.5"
  "A major mode for the Amber programming language."
  '((emacs "28.1"))
  :url "https://codeberg.org/GeorgGD/amber-mode"
  :commit "58e1b6068601951881478568297913fd777095d2"
  :revdesc "58e1b6068601"
  :keywords '("amber" "languages")
  :authors '(("Georgios Davakos" . "georgios.davakos@protonmail.com"))
  :maintainers '(("Georgios Davakos" . "georgios.davakos@protonmail.com")))
