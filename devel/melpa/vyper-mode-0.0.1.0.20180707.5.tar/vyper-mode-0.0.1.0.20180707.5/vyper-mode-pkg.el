;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vyper-mode" "0.0.1.0.20180707.5"
  "Major mode for the Vyper programming language."
  '((emacs "24.3"))
  :url "https://github.com/ralexstokes/vyper-mode"
  :commit "323dfddfc38f0b11697e9ebaf04d1b53297e54e5"
  :revdesc "323dfddfc38f"
  :keywords '("languages")
  :authors '(("Alex Stokes" . "r.alex.stokes@gmail.com"))
  :maintainers '(("Alex Stokes" . "r.alex.stokes@gmail.com")))
