;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-text-object-python" "1.0.1.0.20191010.10"
  "Python specific evil text objects."
  '((emacs "25")
    (evil  "1.2.14")
    (dash  "2.16.0"))
  :url "https://github.com/wbolster/evil-text-object-python"
  :commit "39d22fc524f0413763f291267eaab7f4e7984318"
  :revdesc "1.0.1-10-g39d22fc524f0"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Wouter Bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("Wouter Bolsterlee" . "wouter@bolsterl.ee")))
