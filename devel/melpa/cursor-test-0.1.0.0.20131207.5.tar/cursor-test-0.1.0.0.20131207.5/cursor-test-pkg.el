;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cursor-test" "0.1.0.0.20131207.5"
  "Testing library for cursor position in emacs."
  '((emacs "24"))
  :url "https://github.com/ainame/cursor-test.el"
  :commit "e09956e048b88fd2ee8dd90b5678baed8b04d31b"
  :revdesc "e09956e048b8")
