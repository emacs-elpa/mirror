;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "0.4.2.0.20261015.10"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "30.2")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "7d8b050eebe386ace60a4f8b396497abae422374"
  :revdesc "v0.4.2-10-g7d8b050eebe3"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
