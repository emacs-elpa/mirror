;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cppinsights" "0.3"
  "Integration with cppinsights tool."
  '((emacs "28.1"))
  :url "https://github.com/ignity21/cppinsights.el"
  :commit "528a5e61fffc2e0302cead4b8ab4105f9f8a14a2"
  :revdesc "528a5e61fffc"
  :keywords '("c++" "tools" "cppinsights")
  :authors '(("Chris Chen" . "chrischen@ignity.xyz"))
  :maintainers '(("Chris Chen" . "chrischen@ignity.xyz")))
