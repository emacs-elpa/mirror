;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.15.0.20260905.2"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "5869254349a035e16d656eb232a52cf0e163d531"
  :revdesc "2.15-2-g5869254349a0"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
