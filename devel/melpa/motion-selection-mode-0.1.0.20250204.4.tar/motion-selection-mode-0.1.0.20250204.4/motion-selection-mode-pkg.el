;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "motion-selection-mode" "0.1.0.20250204.4"
  "A minor mode to add a text editing grammar."
  '((emacs    "29.3")
    (god-mode "2.18.0"))
  :url "https://github.com/alexispurslane/motion-selection-mode"
  :commit "96b8cbf18beb528f32cabdf77808b8db596f30be"
  :revdesc "96b8cbf18beb"
  :keywords '("tools")
  :authors '(("Alexis Purslane" . "alexispurslane@pm.me"))
  :maintainers '(("Alexis Purslane" . "alexispurslane@pm.me")))
