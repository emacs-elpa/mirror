;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nnhackernews" "0.1.0"
  "Gnus backend for Hacker News."
  '((emacs    "25.2")
    (request  "0.3.3")
    (dash     "2.18.1")
    (anaphora "1.0.4"))
  :url "https://github.com/dickmao/nnhackernews"
  :commit "0cb7ff0a86c9c5b08786b6dc0591adcb25fbe3b3"
  :revdesc "0cb7ff0a86c9"
  :keywords '("news")
  :authors '(("dickmao" . "githubid:dickmao"))
  :maintainers '(("dickmao" . "githubid:dickmao")))
