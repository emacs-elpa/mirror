;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-repl" "1.5.2.0.20260921.3"
  "A minor mode for a Julia REPL."
  '((emacs  "29.1")
    (s      "1.12")
    (compat "31.1"))
  :url "https://github.com/tpapp/julia-repl"
  :commit "a3a0582691f343d5984a34a85263165c2fe44f43"
  :revdesc "a3a0582691f3"
  :keywords '("languages")
  :authors '(("Tamas Papp" . "tkpapp@gmail.com"))
  :maintainers '(("Tamas Papp" . "tkpapp@gmail.com")))
