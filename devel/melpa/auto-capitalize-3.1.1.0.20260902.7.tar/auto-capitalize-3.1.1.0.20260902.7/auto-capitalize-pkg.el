;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-capitalize" "3.1.1.0.20260902.7"
  "Automatic capitalization with batteries included."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/abdulnafe-t/auto-capitalize.el"
  :commit "27822ed7465dde9606b6967e12823abf65e4f36c"
  :revdesc "27822ed7465d"
  :keywords '("text" "wp" "convenience")
  :maintainers '(("Abdulnafé Toulaïmat" . "abdulnafe.toulaimat@gmail.com")))
