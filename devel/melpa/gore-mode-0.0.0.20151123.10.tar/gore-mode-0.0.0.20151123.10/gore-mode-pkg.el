;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gore-mode" "0.0.0.20151123.10"
  "Simple mode for gore, a command-line evaluator for golang."
  '((go-mode "1.0.0"))
  :url "https://github.com/sergey-pashaev/gore-mode"
  :commit "94d7f3e99104e06167967c98fdc201049c433c2d"
  :revdesc "94d7f3e99104"
  :keywords '("go" "repl")
  :authors '(("Sergey Pashaev" . "sergey.pashaev@gmail.com"))
  :maintainers '(("Sergey Pashaev" . "sergey.pashaev@gmail.com")))
