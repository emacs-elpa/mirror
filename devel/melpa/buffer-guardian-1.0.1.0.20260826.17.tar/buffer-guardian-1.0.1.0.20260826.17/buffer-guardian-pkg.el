;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "1.0.1.0.20260826.17"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "283ff5eb4f1a5f714a7c41b5759a62060d143fa6"
  :revdesc "1.0.1-17-g283ff5eb4f1a"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
