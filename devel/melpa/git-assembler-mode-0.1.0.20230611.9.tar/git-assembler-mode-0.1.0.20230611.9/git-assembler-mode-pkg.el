;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-assembler-mode" "0.1.0.20230611.9"
  "Git-assembler major mode."
  '((emacs "24.4"))
  :url "https://gitlab.com/wavexx/git-assembler-mode.el"
  :commit "391f507269f4f243d81ebdc1f5d43388dc54bc2f"
  :revdesc "391f507269f4"
  :keywords '("git" "git-assembler" "languages" "highlight" "syntax")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
