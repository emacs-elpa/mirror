;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-connect" "1.0.0.20250414.5"
  "AnkiConnect API."
  '((emacs "24.3"))
  :url "https://github.com/lujun9972/anki-connect.el"
  :commit "e32e611d54a3819f88c5ff58009df70c9ae01934"
  :revdesc "e32e611d54a3"
  :keywords '("lisp" "anki")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
