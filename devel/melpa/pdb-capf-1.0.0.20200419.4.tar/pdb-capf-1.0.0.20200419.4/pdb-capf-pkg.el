;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdb-capf" "1.0.0.20200419.4"
  "Completion-at-point function for python debugger."
  '((emacs "25.1"))
  :url "https://github.com/muffinmad/emacs-pdb-capf"
  :commit "2f4099aa1330f87df4e9cd526de057ee9b71de6c"
  :revdesc "2f4099aa1330"
  :keywords '("languages" "abbrev" "convenience")
  :authors '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com"))
  :maintainers '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com")))
