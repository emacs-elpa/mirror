;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "4.0.7.0.20260912.53"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "008ed6a3886f6d58dff2ec8cb996da127824c59f"
  :revdesc "v4.0.7-53-g008ed6a3886f"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
