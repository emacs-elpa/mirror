;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leo" "0.2.0.20250109.265"
  "Interface for dict.leo.org."
  '((emacs "28.1")
    (s     "1.12.0")
    (aio   "1.0"))
  :url "https://codeberg.org/martianh/emacs-leo"
  :commit "24020b11de5975f71f4b57efbb9ef874ec0bcd87"
  :revdesc "24020b11de59"
  :keywords '("convenience" "translate" "wp" "dictionary")
  :authors '(("M.T. Enders" . "michaelATmichael-enders.com")
             ("Marty Hiatt" . "martianhiatusATriseup.net"))
  :maintainers '(("M.T. Enders" . "michaelATmichael-enders.com")
                 ("Marty Hiatt" . "martianhiatusATriseup.net")))
