;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "char-menu" "0.1.1.0.20260802.34"
  "Create your own menu for fast insertion of arbitrary symbols."
  '((emacs    "24.3")
    (avy-menu "0.1"))
  :url "https://github.com/mrkkrp/char-menu"
  :commit "106dfd07ceb84f826ae339230c63897f3590cd3d"
  :revdesc "106dfd07ceb8"
  :keywords '("convenience" "editing")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
