;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mise-tasks" "0.1.0.0.20260703.20"
  "Run mise tasks and highlight lockfiles."
  '((emacs "28.1"))
  :url "https://github.com/klochowicz/mise-tasks.el"
  :commit "76c762bd920bf1e2faac631ac990c4e2e798d321"
  :revdesc "76c762bd920b"
  :keywords '("tools" "processes" "mise")
  :authors '(("Mariusz Klochowicz" . "mariusz@klochowicz.com"))
  :maintainers '(("Mariusz Klochowicz" . "mariusz@klochowicz.com")))
