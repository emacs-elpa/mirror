;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "0.9.1.0.20260716.121"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "005fbd8872ca23437e2c5e72f0f9c605bbc7360d"
  :revdesc "005fbd8872ca"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
