;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soccer" "2.0.0.0.20260823.2"
  "Fixtures, results, table etc for soccer."
  '((emacs "29.1"))
  :url "https://github.com/md-arif-shaikh/soccer"
  :commit "55fa7c959cd51fb05fd1a65ce7ba24de8113caad"
  :revdesc "55fa7c959cd5"
  :keywords '("games" "soccer" "football")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
