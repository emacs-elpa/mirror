;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hgignore-mode" "0.1.20150329.0.20220804.11"
  "A major mode for editing hgignore files."
  ()
  :url "https://github.com/omajid/hgignore-mode"
  :commit "c65810347f39904b985187c5e2aaf27b184f3cae"
  :revdesc "c65810347f39"
  :keywords '("convenience" "vc" "hg")
  :authors '(("Omair Majid" . "omair.majid@gmail.com"))
  :maintainers '(("Omair Majid" . "omair.majid@gmail.com")))
