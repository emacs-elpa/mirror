;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "historyf" "0.0.9"
  "File history library like browser."
  ()
  :url "https://github.com/k1LoW/emacs-historyf"
  :commit "64ab6c9d2cd6dec6982622bf675326e011373cd2"
  :revdesc "64ab6c9d2cd6"
  :authors '((nil . "k1low[at]101000lab[dot]org"))
  :maintainers '((nil . "k1low[at]101000lab[dot]org")))
