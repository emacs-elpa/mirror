;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hutch" "0.1.0.0.20260630.16"
  "AI code review for magit."
  '((emacs     "29.1")
    (magit     "4.0")
    (transient "0.7.4")
    (gptel     "0.9.9.3")
    (svg-lib   "0.3"))
  :url "https://github.com/adjaecent/magit-hutch"
  :commit "ee06a06093c66f2c4c5873434aba44b62e11bf76"
  :revdesc "ee06a06093c6"
  :authors '(("Akshay Gupta" . "mail@kitallis.in"))
  :maintainers '(("Akshay Gupta" . "mail@kitallis.in")))
