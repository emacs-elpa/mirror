;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.981.0.20261012.3"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "5f6dd6dbd7a4ee5be5939422bae3461ca9f5e26e"
  :revdesc "5f6dd6dbd7a4"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
