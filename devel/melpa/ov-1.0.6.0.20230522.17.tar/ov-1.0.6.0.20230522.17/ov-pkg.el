;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ov" "1.0.6.0.20230522.17"
  "Overlay library for Emacs Lisp."
  '((emacs "24.3"))
  :url "https://github.com/ShingoFukuyama/ov.el"
  :commit "e2971ad986b6ac441e9849031d34c56c980cf40b"
  :revdesc "e2971ad986b6"
  :keywords '("convenience" "overlay"))
