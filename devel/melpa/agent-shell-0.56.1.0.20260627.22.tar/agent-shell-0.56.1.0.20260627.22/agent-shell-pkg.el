;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.56.1.0.20260627.22"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.1")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "96343cf9a321f707e3007fb9a1543871d07f9937"
  :revdesc "96343cf9a321")
