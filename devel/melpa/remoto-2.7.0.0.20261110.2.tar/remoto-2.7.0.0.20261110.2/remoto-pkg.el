;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "2.7.0.0.20261110.2"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "d8c517cc80ad7878ab3c2e958d8961f752a20810"
  :revdesc "2.7.0-2-gd8c517cc80ad"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
