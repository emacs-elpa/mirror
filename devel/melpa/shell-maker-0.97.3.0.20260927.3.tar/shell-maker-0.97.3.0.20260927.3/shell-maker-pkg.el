;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.97.3.0.20260927.3"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "965671461820006269bef16c6d104d55fb18a691"
  :revdesc "965671461820")
