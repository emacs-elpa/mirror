;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "1.0.7.0.20261108.1"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "199649d8ded160946107ff3099cb2ebaa37e731f"
  :revdesc "1.0.7-1-g199649d8ded1"
  :keywords '("convenience" "files" "tools"))
