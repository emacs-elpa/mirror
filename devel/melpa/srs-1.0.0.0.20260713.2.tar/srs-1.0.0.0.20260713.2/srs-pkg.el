;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "1.0.0.0.20260713.2"
  "Spaced repetition in plain text."
  '((emacs     "30.2")
    (transient "0.12.0"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "57cf956a746c2f948b801514f62a55a97fb3ef22"
  :revdesc "57cf956a746c"
  :keywords '("hypermedia" "srs" "memory")
  :authors '(("Duncan Britt" . "duncanbritt.com"))
  :maintainers '(("Duncan Britt" . "duncanbritt.com")))
