;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "1.6.7.0.20261125.1"
  "Miasma: color theme inspired by the woods."
  ()
  :url "https://github.com/daut/miasma-theme.el"
  :commit "1b3faf9c84e7955e402e508a0c4393b517983778"
  :revdesc "1b3faf9c84e7")
