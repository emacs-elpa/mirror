;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20261119.374"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "2bcb42550076a5343ecf08b8682f36df160c20e4"
  :revdesc "2bcb42550076")
