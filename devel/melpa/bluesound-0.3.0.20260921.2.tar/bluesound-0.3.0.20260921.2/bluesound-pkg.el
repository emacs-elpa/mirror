;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesound" "0.3.0.20260921.2"
  "Play, pause, resume music on a Bluesound player."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~rwv/bluesound-el/"
  :commit "b4dc3538a14b306caae1dcd23a0b7f622618a2b2"
  :revdesc "0.3-2-gb4dc3538a14b"
  :keywords '("convenience" "multimedia"))
