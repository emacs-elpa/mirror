;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "0.3.4.0.20260605.43"
  "Minor mode for making Anki cards with Org."
  '((emacs "29.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "7089c15f3151e0318e3d7d801f6b87eeeb25d226"
  :revdesc "7089c15f3151")
