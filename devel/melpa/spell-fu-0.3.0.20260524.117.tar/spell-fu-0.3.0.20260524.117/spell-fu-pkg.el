;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spell-fu" "0.3.0.20260524.117"
  "Fast & light spelling highlighter."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spell-fu"
  :commit "103c4aaf0d2ec452359e087bed50504e2bdf4661"
  :revdesc "103c4aaf0d2e"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
