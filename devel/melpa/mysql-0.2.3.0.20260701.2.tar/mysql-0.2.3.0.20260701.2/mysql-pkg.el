;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "0.2.3.0.20260701.2"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "9aaf2b00b91d16ebde03e9d6e5b5b2a588651cf3"
  :revdesc "9aaf2b00b91d"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
