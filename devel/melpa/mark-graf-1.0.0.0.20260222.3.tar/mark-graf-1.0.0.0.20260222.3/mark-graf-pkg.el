;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mark-graf" "1.0.0.0.20260222.3"
  "Modern WYSIWYG-style markdown editing."
  '((emacs "30.1"))
  :url "https://github.com/hyperZphere/mark-graf"
  :commit "0e1c502bd577f5b800c8bc04b15ac510d4c4b4a9"
  :revdesc "0e1c502bd577"
  :keywords '("markdown" "wp" "text")
  :authors '(("Marc Ansset" . "info@ansset.com"))
  :maintainers '(("Marc Ansset" . "info@ansset.com")))
