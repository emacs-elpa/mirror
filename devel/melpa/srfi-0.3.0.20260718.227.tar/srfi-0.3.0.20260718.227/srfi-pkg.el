;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "0.3.0.20260718.227"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "e866eef9526cbfa056a6ed5a5c6506ce5bfe5eb2"
  :revdesc "0.3-227-ge866eef9526c"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
