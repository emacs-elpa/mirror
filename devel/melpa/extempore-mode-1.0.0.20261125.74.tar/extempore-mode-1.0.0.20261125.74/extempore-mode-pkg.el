;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "extempore-mode" "1.0.0.20261125.74"
  "Emacs major mode for Extempore source files."
  '((emacs "27.1"))
  :url "https://github.com/extemporelang/extempore-emacs-mode"
  :commit "02edd4b0748dec83ba14ac11c53f8c9ccb1ca3b5"
  :revdesc "02edd4b0748d"
  :keywords '("extempore")
  :authors '(("Ben Swift" . "ben@benswift.me"))
  :maintainers '(("Ben Swift" . "ben@benswift.me")))
