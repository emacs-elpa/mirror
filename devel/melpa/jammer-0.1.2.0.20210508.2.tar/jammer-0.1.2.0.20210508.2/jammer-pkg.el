;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jammer" "0.1.2.0.20210508.2"
  "Punish yourself for using Emacs inefficiently."
  '((emacs "24.1"))
  :url "https://depp.brause.cc/jammer"
  :commit "a780e4c2adb2e85a4daadcefd1a2b189d761872f"
  :revdesc "a780e4c2adb2"
  :keywords '("games")
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
