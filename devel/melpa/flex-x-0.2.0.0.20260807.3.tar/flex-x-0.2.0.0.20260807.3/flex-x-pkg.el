;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-x" "0.2.0.0.20260807.3"
  "Extended flex completion style."
  '((emacs "30.1"))
  :url "https://github.com/kn66/flex-x"
  :commit "905df04dd7abd4135e1c52a1fa209b49065c0080"
  :revdesc "905df04dd7ab"
  :keywords '("convenience" "matching")
  :authors '(("kn66" . "https://github.com/kn66"))
  :maintainers '(("kn66" . "https://github.com/kn66")))
