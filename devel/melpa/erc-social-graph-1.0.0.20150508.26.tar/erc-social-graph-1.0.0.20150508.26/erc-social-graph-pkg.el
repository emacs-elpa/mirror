;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-social-graph" "1.0.0.20150508.26"
  "A social network graph module for ERC."
  ()
  :url "https://github.com/vibhavp/erc-social-graph"
  :commit "e6ef3416a1c5064054bf054d9f0c1c7bf54a9cd0"
  :revdesc "e6ef3416a1c5"
  :keywords '("erc" "graph")
  :authors '(("Vibhav Pant" . "vibhavp@gmail.com"))
  :maintainers '(("Vibhav Pant" . "vibhavp@gmail.com")))
