;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pt" "0.0.3.0.20161226.15"
  "A front-end for pt, The Platinum Searcher."
  ()
  :url "https://github.com/bling/pt.el"
  :commit "6d99b2aaded3ece3db19a20f4b8f1d4abe382622"
  :revdesc "6d99b2aaded3"
  :keywords '("pt" "ack" "ag" "grep" "search"))
