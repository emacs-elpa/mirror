;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.74.2.0.20260821.4"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0306939b918df3e692c18ce5aeb5fa19457d9893"
  :revdesc "0306939b918d")
