;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20261126.383"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "69d965e8585a77adeecac52a073961a8418976e1"
  :revdesc "69d965e8585a")
