;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.11.9.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "8c2736a151f0778c77d778c92cf3b05181d2d069"
  :revdesc "8c2736a151f0"
  :keywords '("languages"))
