;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "saveplace-pdf-view" "1.0.9"
  "Save place in pdf-view buffers."
  '((emacs "29.1"))
  :url "https://github.com/nicolaisingh/saveplace-pdf-view"
  :commit "dc1e0b28a5ed8319a0b6725abaffba7c2fa8c730"
  :revdesc "saveplace-pdf-view-1.0.9-0-gdc1e0b28a5ed"
  :keywords '("files" "convenience")
  :authors '(("Nicolai Singh" . "nicolaisinghatpm.me"))
  :maintainers '(("Nicolai Singh" . "nicolaisinghatpm.me")))
