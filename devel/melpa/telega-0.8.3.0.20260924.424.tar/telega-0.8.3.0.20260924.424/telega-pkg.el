;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "0.8.3.0.20260924.424"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "4721c9322ce0f988aca0058be4e5f9865eaf83f3"
  :revdesc "4721c9322ce0"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
