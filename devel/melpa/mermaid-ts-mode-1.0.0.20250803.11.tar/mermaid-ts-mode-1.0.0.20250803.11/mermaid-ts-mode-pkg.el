;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mermaid-ts-mode" "1.0.0.20250803.11"
  "Major mode for Mermaid."
  '((emacs "29.1"))
  :url "https://github.com/JonathanHope/mermaid-ts-mode"
  :commit "973e442cbed980cf51afc256c90ef133c4d02141"
  :revdesc "973e442cbed9"
  :keywords '("mermaid" "languages")
  :authors '(("Jonathan Hope" . "jhope@theflatfield.net"))
  :maintainers '(("Jonathan Hope" . "jhope@theflatfield.net")))
