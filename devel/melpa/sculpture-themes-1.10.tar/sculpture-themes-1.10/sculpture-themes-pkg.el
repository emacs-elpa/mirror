;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "1.10"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "e5ac2c7b72ee58eb66510937270716d25484ecd6"
  :revdesc "e5ac2c7b72ee"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
