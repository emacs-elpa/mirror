;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elf-mode" "0.1.0"
  "Show symbols in binaries."
  '((emacs "24.3"))
  :url "https://github.com/abo-abo/elf-mode"
  :commit "cd280d683cd3341d8bb31af6db7e3b74a133e6ab"
  :revdesc "cd280d683cd3"
  :keywords '("matching")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
