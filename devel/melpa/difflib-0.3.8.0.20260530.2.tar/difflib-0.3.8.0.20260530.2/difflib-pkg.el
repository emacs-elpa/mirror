;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difflib" "0.3.8.0.20260530.2"
  "Helpers for computing deltas between sequences."
  '((emacs      "24.4")
    (cl-generic "0.3")
    (ht         "2.2")
    (s          "1.12.0"))
  :url "https://sr.ht/~dieggsy/difflib.el"
  :commit "9efb87bcf430600e8beb1a821dc78c1088a081e7"
  :revdesc "9efb87bcf430"
  :keywords '("matching" "tools" "string")
  :authors '(("Diego A. Mundo" . "dieggsy@pm.me"))
  :maintainers '(("Diego A. Mundo" . "dieggsy@pm.me")))
