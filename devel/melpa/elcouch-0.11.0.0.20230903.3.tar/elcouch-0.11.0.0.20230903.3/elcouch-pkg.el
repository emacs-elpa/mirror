;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elcouch" "0.11.0.0.20230903.3"
  "View and manipulate CouchDB databases."
  '((emacs      "25.1")
    (json-mode  "1.0.0")
    (libelcouch "0.11.0")
    (navigel    "0.3.0"))
  :url "https://gitlab.petton.fr/DamienCassou/elcouch"
  :commit "a426e9bee9501284f4e1e84766621ca6b130c79a"
  :revdesc "a426e9bee950"
  :keywords '("data" "tools")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
