;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-locate-file" "0.1.1.0.20260622.1"
  "Locate-based file links for Org mode."
  '((emacs "30.1")
    (org   "9.3"))
  :url "https://github.com/p-snow/ol-locate-file"
  :commit "205256d39485ec25c3cceca027f30fa5332c8855"
  :revdesc "205256d39485"
  :keywords '("hypermedia" "convenience")
  :authors '(("p-snow" . "public@p-snow.org"))
  :maintainers '(("p-snow" . "public@p-snow.org")))
