;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-char-preview" "0.2.0.0.20260204.1"
  "Preview character when executing `goto-char` command."
  '((emacs "24.3"))
  :url "https://github.com/emacs-vs/goto-char-preview"
  :commit "d81c7186dc3c916ba84a5d8ce2f06c652c1186a8"
  :revdesc "d81c7186dc3c"
  :keywords '("convenience" "character" "navigation")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
