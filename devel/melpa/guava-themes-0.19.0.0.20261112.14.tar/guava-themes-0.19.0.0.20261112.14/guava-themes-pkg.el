;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "0.19.0.0.20261112.14"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "6e660861ab8796be5d1ca5b0e60930b863ca2067"
  :revdesc "v0.19.0-14-g6e660861ab87"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
