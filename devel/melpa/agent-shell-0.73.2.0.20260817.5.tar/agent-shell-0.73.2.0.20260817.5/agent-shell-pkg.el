;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.73.2.0.20260817.5"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "71669673d769f6bf37cb6d911e29b76f7cf995b5"
  :revdesc "71669673d769")
