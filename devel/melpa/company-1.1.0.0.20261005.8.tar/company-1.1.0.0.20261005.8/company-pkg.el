;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "1.1.0.0.20261005.8"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "34c263702f3270f562976819c86880f8d832d1cd"
  :revdesc "1.1.0-8-g34c263702f32"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
