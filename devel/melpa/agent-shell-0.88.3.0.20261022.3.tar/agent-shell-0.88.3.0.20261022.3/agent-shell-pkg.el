;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.88.3.0.20261022.3"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0ec099292c713c5a60c3d8c5890a752cefd19fa8"
  :revdesc "0ec099292c71")
