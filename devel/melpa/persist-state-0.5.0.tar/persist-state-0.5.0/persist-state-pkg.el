;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-state" "0.5.0"
  "Regularly persist bookmarks, history, recent files and more."
  '((emacs "28.2"))
  :url "https://codeberg.org/meedstrom/emacs-persist-state"
  :commit "bb8d39612197558a497152339ba927506f18bcb5"
  :revdesc "0.5.0-0-gbb8d39612197"
  :keywords '("convenience")
  :authors '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
