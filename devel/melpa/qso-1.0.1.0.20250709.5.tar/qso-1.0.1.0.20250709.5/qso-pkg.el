;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qso" "1.0.1.0.20250709.5"
  "Amateur radio QSO logging."
  '((emacs "25.1"))
  :url "https://github.com/K6SM/Emacs-QSO-Logger"
  :commit "33d3211748aa7e94f1aa187570beca8b9b2093d8"
  :revdesc "33d3211748aa"
  :keywords '("lisp"))
