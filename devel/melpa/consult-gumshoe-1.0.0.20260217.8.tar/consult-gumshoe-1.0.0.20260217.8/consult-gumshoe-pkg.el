;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gumshoe" "1.0.0.20260217.8"
  "Consult integration for gumshoe."
  '((emacs   "27.1")
    (consult "0.35")
    (gumshoe "4.0"))
  :url "https://github.com/Overdr0ne/gumshoe"
  :commit "da71e889b5e890fecbacaeba0a4977c4657b4351"
  :revdesc "da71e889b5e8"
  :keywords '("tools"))
