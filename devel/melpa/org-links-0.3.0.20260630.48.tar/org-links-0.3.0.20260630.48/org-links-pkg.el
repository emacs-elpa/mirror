;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "0.3.0.20260630.48"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "f99b31c98c929ccb8babb256681baed0bbcdd3dc"
  :revdesc "f99b31c98c92"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
