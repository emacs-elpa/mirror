;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-flex-with-migemo" "0.0.0.0.20190408.12"
  "Use ido with flex and migemo."
  '((flx-ido "0.6.1")
    (migemo  "1.9.1")
    (emacs   "24.4"))
  :url "https://github.com/ROCKTAKEY/ido-flex-with-migemo"
  :commit "aa93aa05947eb6c106bb9523ff3163b8574c4eac"
  :revdesc "aa93aa05947e"
  :keywords '("matching")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
