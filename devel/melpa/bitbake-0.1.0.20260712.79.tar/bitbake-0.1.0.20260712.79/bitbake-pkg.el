;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbake" "0.1.0.20260712.79"
  "Running bitbake from emacs."
  '((emacs    "25")
    (dash     "2.6.0")
    (polymode "20260505.1803")
    (s        "1.10.0"))
  :url "https://github.com/canatella/bitbake-el"
  :commit "f626d37727df0550aa2afd3f1b0ce81f38be18a3"
  :revdesc "f626d37727df"
  :keywords '("convenience"))
