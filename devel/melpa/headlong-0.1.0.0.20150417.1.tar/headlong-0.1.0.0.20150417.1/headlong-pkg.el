;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "headlong" "0.1.0.0.20150417.1"
  "Reckless completion."
  ()
  :url "https://github.com/abo-abo/headlong"
  :commit "f6830f87f236eee88263cb6976125f72422abe72"
  :revdesc "f6830f87f236"
  :keywords '("completion")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
