;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.981.0.20261014.5"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "71c440e5ab1c6cbeb6e008db15bcd7520d079b7f"
  :revdesc "71c440e5ab1c"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
