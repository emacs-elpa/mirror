;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "0.1.0.0.20260911.192"
  "Manage multiple AI coding agents."
  '((emacs         "28.1")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (magit-section "3.3.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "bdd4a98779c4c53254493bf2abc755b911972ea4"
  :revdesc "bdd4a98779c4"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
