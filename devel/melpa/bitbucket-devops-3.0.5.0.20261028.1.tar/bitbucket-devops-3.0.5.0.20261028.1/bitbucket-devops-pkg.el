;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitbucket-devops" "3.0.5.0.20261028.1"
  "Bitbucket Cloud DevOps workflows."
  '((emacs         "29.1")
    (magit         "4.0.0")
    (markdown-mode "2.6")
    (transient     "0.3.0")
    (yaml          "1.2.3"))
  :url "https://github.com/will-abb/bitbucket-devops.el"
  :commit "94941a1202404d2c0846a7bba75cc523d62d7535"
  :revdesc "v3.0.5-1-g94941a120240"
  :keywords '("tools" "vc")
  :authors '(("Will Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("Will Bosch-Bello" . "williamsbosch@gmail.com")))
