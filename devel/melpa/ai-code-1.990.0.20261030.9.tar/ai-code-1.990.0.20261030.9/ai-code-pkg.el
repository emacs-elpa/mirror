;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.990.0.20261030.9"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "5c1361625c4fc877e35bc36bf5c27fbc312a0697"
  :revdesc "5c1361625c4f"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
