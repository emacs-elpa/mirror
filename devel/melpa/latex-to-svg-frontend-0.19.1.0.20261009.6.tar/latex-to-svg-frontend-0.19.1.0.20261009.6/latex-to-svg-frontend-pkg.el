;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "0.19.1.0.20261009.6"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.12.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "61329e6b95810acaf85da8343276f667d8122bb7"
  :revdesc "v0.19.1-6-g61329e6b9581"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
