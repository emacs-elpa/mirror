;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "0.13.1.0.20260803.1"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "7d5c16ebcf2af86aa0f14ad9ae0ce45df4e8c8a5"
  :revdesc "7d5c16ebcf2a")
