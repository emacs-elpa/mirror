;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ewc" "0.4.0.20261104.53"
  "Wayland client in Elisp."
  '((emacs "28.2")
    (lgr   "0.1.0"))
  :url "http://perma-curious.eu/repo-ewx/"
  :commit "466f12c9327c3ed26acb52b68a64be978706e391"
  :revdesc "466f12c9327c"
  :keywords '("unix")
  :authors '(("Michael Bauer" . "michael-bauer@posteo.de"))
  :maintainers '(("Thomas Koch" . "thomas@koch.ro")))
