;;; agent-shell-attention.el --- Mode-line attention tracker for agent-shell  -*- lexical-binding: t; -*-

;; Copyright (C) 2025  Paul D. Nelson

;; Author: Paul D. Nelson <ultrono@gmail.com>
;; Assisted-by: Codex:gpt-6
;; Maintainer: Paul D. Nelson <ultrono@gmail.com>
;; Package-Version: 0.0.3.0.20261012.2
;; Package-Revision: v0.0.3-2-gaaf599121445
;; URL: https://github.com/ultronozm/agent-shell-attention.el
;; Package-Requires: ((emacs "29.1") (agent-shell "0.47.1"))
;; Keywords: convenience

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; `agent-shell-attention-mode' instruments the `agent-shell' prompt
;; flow to keep track of buffers that are waiting for user input.  It
;; displays a clickable `AS:n' indicator in the mode line, provides a
;; command `agent-shell-attention-jump' to visit pending buffers, and
;; can optionally issue notifications via a user-defined function.
;;
;; It also includes a renderer for an `AS:n/m' pending/active indicator.
;; `agent-shell-attention-jump-idle' returns to an idle shell, or offers
;; completion with a prefix argument.  `agent-shell-attention-dashboard'
;; lists all sessions with their status and last activity.
;;
;; Enable with (agent-shell-attention-mode).
;;
;;; Code:

(require 'cl-lib)
(require 'easymenu)
(require 'map)
(require 'seq)
(require 'subr-x)
(require 'tabulated-list)

(declare-function notifications-notify "notifications")
(declare-function agent-shell-subscribe-to "agent-shell")
(declare-function agent-shell-unsubscribe "agent-shell")
(declare-function agent-shell--send-command "agent-shell")
(declare-function dired "dired" (dirname &optional switches))
(declare-function acp-send-request "acp")
(declare-function agent-shell-viewport--buffer "agent-shell-viewport")
(declare-function agent-shell-viewport--shell-buffer "agent-shell-viewport")

(defgroup agent-shell-attention nil
  "Mode-line tally and minibuffer notifications for agent-shell buffers."
  :group 'agent-shell
  :prefix "agent-shell-attention-")

;;; Basic customizations

(defcustom agent-shell-attention-awaiting-stop-reasons '("end_turn")
  "Stop reasons that indicate the agent expects further input.
Each entry should be a string that matches the ACP stopReason field."
  :type '(repeat string))

(defcustom agent-shell-attention-lighter " AS:%d"
  "String shown in the mode line indicator.
The token `%d' is replaced with the number of buffers waiting for
attention.  Set to nil to hide the lighter entirely."
  :type '(choice (const :tag "Hide indicator" nil)
                 string))

(defcustom agent-shell-attention-message-prefix "[agent-shell]"
  "Prefix used for minibuffer notifications."
  :type 'string)

;;; Notifications

(defun agent-shell-attention-notify-default (_buffer title body)
  "Send TITLE/BODY notification via `notifications-notify'."
  (when (require 'notifications nil t)
    (notifications-notify
     :app-name "agent-shell"
     :title title
     :body body)))

(defcustom agent-shell-attention-notify-function nil
  "Function used to emit optional notifications.

When non-nil, it is called with three arguments: BUFFER, TITLE, and
BODY.  Set this to nil to disable notifications entirely.

The helper `agent-shell-attention-notify-default' uses
`notifications-notify'."
  :type '(choice (const :tag "Disable notifications" nil)
                 (const :tag "Use built-in notifications"
                        agent-shell-attention-notify-default)
                 function))

;;; Display-buffer

(defun agent-shell-attention--window-state-has-buffer (state buffer)
  "Return non-nil when window-state STATE shows BUFFER."
  (when (and state (fboundp 'window-state-buffers))
    (condition-case nil
        (let ((buffers (window-state-buffers state)))
          (and buffers
               (or (memq buffer buffers)
                   (member (buffer-name buffer) buffers))))
      (error nil))))

(defun agent-shell-attention--tab-displays-buffer-p (tab buffer)
  "Return non-nil when TAB's window state shows BUFFER."
  (let ((state (alist-get 'ws tab)))
    (and state
         (agent-shell-attention--window-state-has-buffer state buffer))))

(defun agent-shell-attention-display-buffer-across-tabs (buffer _alist)
  "Display BUFFER by reusing an existing window across tabs in this frame.

Return the window that shows BUFFER, or nil to let other display actions
run.  If `tab-bar-mode' is enabled and BUFFER is visible in another tab
of the current frame, switch to that tab and reuse its window."
  (when (and (bound-and-true-p tab-bar-mode)
             (fboundp 'tab-bar-tabs)
             (fboundp 'tab-bar-select-tab))
    (let* ((frame (selected-frame))
           (tabs (condition-case nil
                     (tab-bar-tabs frame)
                   (wrong-number-of-arguments
                    (tab-bar-tabs))
                   (error nil)))
           (current (when (fboundp 'tab-bar--current-tab)
                      (tab-bar--current-tab)))
           (current-index (or (and current
                                   (cl-position current tabs :test #'equal))
                              0))
           (target-index (cl-position-if
                          (lambda (tab)
                            (agent-shell-attention--tab-displays-buffer-p
                             tab buffer))
                          tabs))
           (target-window nil))
      (when (numberp target-index)
        (cond
         ((= target-index current-index)
          (setq target-window (get-buffer-window buffer frame)))
         (t
          (condition-case nil
              (let ((inhibit-redisplay t))
                (tab-bar-select-tab (1+ target-index))
                (setq target-window (get-buffer-window buffer frame)))
            (error
             (setq target-window nil)))))
        (when (window-live-p target-window)
          target-window)))))

(defcustom agent-shell-attention-display-buffer-action
  '((display-buffer-reuse-window
     agent-shell-attention-display-buffer-across-tabs
     display-buffer-same-window))
  "Display action used by `agent-shell-attention-jump'.

This is passed as ACTION to `pop-to-buffer'.  The default prefers an
existing window showing the buffer in the current frame.  If
`tab-bar-mode' is enabled it will also look across tabs in the same
frame."
  :type 'sexp)

(defcustom agent-shell-attention-before-jump-hook nil
  "Hook run before visiting an agent-shell session.
Each function receives the session's live shell buffer, even when
an existing viewport will be displayed.  Use this to activate the
owning workspace before display and pending-state clearing.
This also runs for dashboard visits in another window."
  :type 'hook)

(defvar agent-shell-attention--pending (make-hash-table :test #'eq)
  "Table of `agent-shell-mode' buffers awaiting user input.")

(defvar agent-shell-attention--busy (make-hash-table :test #'eq)
  "Table of `agent-shell-mode' buffers with in-flight requests.
Values are integer reference counts.")

(defvar agent-shell-attention--busy-since (make-hash-table :test #'eq)
  "Table of when each buffer entered busy state.")

(defvar agent-shell-attention--last-event (make-hash-table :test #'eq)
  "Table of last known activity for agent-shell buffers.
Values are plists with keys :status, :summary, and :timestamp.")

(defvar agent-shell-attention--subscriptions (make-hash-table :test #'eq)
  "Table mapping `agent-shell-mode' buffers to event subscription tokens.")

(defvar agent-shell-attention--dashboard-preserve-row nil
  "When non-nil, dashboard refreshes keep the same visual row.")

;;; Mode-line

(defcustom agent-shell-attention-render-function
  #'agent-shell-attention-render-pending
  "Function used to render the attention indicator.
Called with PENDING-COUNT and ACTIVE-COUNT.  Renderers may ignore the
second argument if they only care about pending buffers.

Return a string suitable for `format-mode-line', or nil/empty string
for no indicator."
  :type '(choice (const :tag "Pending only (AS:n)" agent-shell-attention-render-pending)
                 (const :tag "Pending and busy (AS:n/m)" agent-shell-attention-render-active)
                 function))

(defcustom agent-shell-attention-active-lighter " AS:%d/%d"
  "Mode-line template used when showing pending and active counts.

The first `%d' is replaced with the number of pending buffers; the second
`%d' is replaced with the number of buffers that are either pending or
currently busy.

Used by `agent-shell-attention-render-active'."
  :type 'string)

(defcustom agent-shell-attention-show-zeros nil
  "When non-nil, show the indicator even when counts are zero.
Applies to both pending-only and pending+active renderers."
  :type 'boolean)

(defcustom agent-shell-attention-jump-show-groups nil
  "When non-nil, group jump candidates by status when using a prefix argument.

Grouping relies on completion UIs honoring completion metadata
`group-function'.  When nil, candidates are still ordered with pending
buffers first and are annotated with status tags."
  :type 'boolean)

(defcustom agent-shell-attention-dashboard-buffer-name "*Agent Shell Attention*"
  "Buffer name used by `agent-shell-attention-dashboard'."
  :type 'string)

(defcustom agent-shell-attention-dashboard-max-reason-length 80
  "Maximum width of status text in the dashboard."
  :type 'natnum)

(defcustom agent-shell-attention-dashboard-buffer-column-width 30
  "Width of the dashboard \"Buffer\" column."
  :type '(integer 10 200))

(defcustom agent-shell-attention-dashboard-time-format "%Y-%m-%d %H:%M:%S"
  "Time format used in the dashboard \"Last active\" column.

This format string is passed to `format-time-string'."
  :type 'string)

(defcustom agent-shell-attention-dashboard-permission-detail-length 40
  "Maximum number of characters shown from permission detail text.

When set to 0, permission entries in the dashboard status column are
rendered as plain \"Permissions\"."
  :type 'natnum)

(defun agent-shell-attention--mode-line-list (value)
  "Return VALUE as a list suitable for mode-line variables."
  (cond
   ((null value) nil)
   ((listp value) value)
   (t (list value))))

(defun agent-shell-attention--call-renderer (pending-count active-count)
  "Call `agent-shell-attention-render-function' safely.
PENDING-COUNT and ACTIVE-COUNT are passed to the renderer."
  (condition-case err
      (funcall agent-shell-attention-render-function pending-count active-count)
    (error
     (message "agent-shell-attention render error: %s" err)
     "")))

(defvar agent-shell-attention--indicator-counts '(0 . 0)
  "Snapshot of (PENDING-COUNT . ACTIVE-COUNT) for redisplay.")

(defvar agent-shell-attention--indicator-timer nil
  "Timer reconciling indicator counts with live request state.")

(defvar agent-shell-attention--indicator-update-timer nil
  "Timer coalescing indicator updates after state changes.")

(defvar agent-shell-attention--indicator-error-reported nil
  "Non-nil when an indicator update failure has already been reported.")

(defvar agent-shell-attention--reconciled-state-changed nil
  "Non-nil when live-state reconciliation requires a dashboard refresh.
Keep this set until a successful update, including across failed polls.")

(defvar agent-shell-attention-mode)

(defun agent-shell-attention--indicator ()
  "Render the last count snapshot without inspecting other buffers."
  (agent-shell-attention--call-renderer
   (car agent-shell-attention--indicator-counts)
   (cdr agent-shell-attention--indicator-counts)))

(defun agent-shell-attention--update-indicator ()
  "Refresh indicator counts outside redisplay.
Only inspect subscribed agent buffers, not the entire buffer list."
  (when (timerp agent-shell-attention--indicator-update-timer)
    (cancel-timer agent-shell-attention--indicator-update-timer))
  (setq agent-shell-attention--indicator-update-timer nil)
  (when agent-shell-attention-mode
    (let ((previous-counts agent-shell-attention--indicator-counts))
      (condition-case err
          (let* ((pending (length (agent-shell-attention--pending-live-entries)))
                 (active (agent-shell-attention--compute-active-count pending t)))
            ;; Membership can change even when the counts stay the same.
            (when agent-shell-attention--reconciled-state-changed
              (agent-shell-attention--maybe-refresh-dashboard))
            (unless (and (= pending (car previous-counts))
                         (= active (cdr previous-counts)))
              (setq agent-shell-attention--indicator-counts (cons pending active))
              (force-mode-line-update t))
            (setq agent-shell-attention--reconciled-state-changed nil
                  agent-shell-attention--indicator-error-reported nil))
        (error
         (setq agent-shell-attention--indicator-counts previous-counts)
         (unless agent-shell-attention--indicator-error-reported
           (setq agent-shell-attention--indicator-error-reported t)
           (message "agent-shell-attention indicator update failed: %s"
                    (error-message-string err))))))))

(defun agent-shell-attention--schedule-indicator-update ()
  "Coalesce state changes into one indicator update after callbacks finish."
  (when (and agent-shell-attention-mode
             (not agent-shell-attention--indicator-update-timer))
    (setq agent-shell-attention--indicator-update-timer
          (run-at-time 0 nil #'agent-shell-attention--update-indicator))))

(defvar agent-shell-attention-mode-line-construct
  '(:eval (agent-shell-attention--indicator))
  "Mode-line construct for `agent-shell-attention-mode'.")

(put 'agent-shell-attention-mode-line-construct 'risky-local-variable t)

(defvar agent-shell-attention--mode-line
  agent-shell-attention-mode-line-construct
  "Interned mode-line entry reused in `mode-line-misc-info'.")

(defun agent-shell-attention-tab-bar-format ()
  "Return a `tab-bar-format' entry that renders the indicator.
Useful when users want only this indicator in the tab bar instead of
mirroring the entire `global-mode-string'."
  `((global menu-item ,(format-mode-line
                        agent-shell-attention-mode-line-construct)
            ignore)))

(defcustom agent-shell-attention-indicator-location 'mode-line-misc-info
  "Where to install the attention indicator.

When set to `mode-line-misc-info', the indicator lives in
`mode-line-misc-info'.  When set to `global-mode-string', it lives in
`global-mode-string' (which some setups also show in the tab bar via
`tab-bar-format-global')."
  :type '(choice (const :tag "Mode line misc info" mode-line-misc-info)
                 (const :tag "Global mode string" global-mode-string))
  :set (lambda (symbol value)
         (set-default symbol value)
         (when (bound-and-true-p agent-shell-attention-mode)
           (agent-shell-attention--apply-indicator-location)))
  :group 'agent-shell-attention)

(defun agent-shell-attention--apply-indicator-location ()
  "Apply `agent-shell-attention-indicator-location' to the mode line."
  (let ((indicator agent-shell-attention--mode-line))
    (setq mode-line-misc-info
          (agent-shell-attention--mode-line-list mode-line-misc-info))
    (setq global-mode-string
          (agent-shell-attention--mode-line-list global-mode-string))
    (setq-default mode-line-misc-info
                  (agent-shell-attention--mode-line-list
                   (default-value 'mode-line-misc-info)))
    (setq-default global-mode-string
                  (agent-shell-attention--mode-line-list
                   (default-value 'global-mode-string)))
    ;; Remove from both lists first to avoid duplicates.
    (setq mode-line-misc-info (delq indicator mode-line-misc-info))
    (setq global-mode-string (delq indicator global-mode-string))
    (setq-default mode-line-misc-info
                  (delq indicator (default-value 'mode-line-misc-info)))
    (setq-default global-mode-string
                  (delq indicator (default-value 'global-mode-string)))
    (pcase agent-shell-attention-indicator-location
      ('mode-line-misc-info
       (unless (member indicator mode-line-misc-info)
         (setq mode-line-misc-info
               (append mode-line-misc-info (list indicator))))
       (unless (member indicator (default-value 'mode-line-misc-info))
         (setq-default mode-line-misc-info
                       (append (default-value 'mode-line-misc-info)
                               (list indicator)))))
      ('global-mode-string
       (unless (member indicator global-mode-string)
         (setq global-mode-string
               (append global-mode-string (list indicator))))
       (unless (member indicator (default-value 'global-mode-string))
         (setq-default global-mode-string
                       (append (default-value 'global-mode-string)
                               (list indicator))))))
    (force-mode-line-update t)))

;;; Pending buffer bookkeeping

(defun agent-shell-attention--pending-live-entries ()
  "Return alist of live buffers needing attention.
Each entry is of the form (BUFFER . ENTRY), where ENTRY is the value
stored in `agent-shell-attention--pending'.  This call also purges stale
entries for dead buffers."
  (let ((entries nil)
        (stale nil))
    (maphash (lambda (buffer entry)
               (if (buffer-live-p buffer)
                   (push (cons buffer entry) entries)
                 (push buffer stale)))
             agent-shell-attention--pending)
    (dolist (buffer stale)
      (setq agent-shell-attention--reconciled-state-changed t)
      (remhash buffer agent-shell-attention--pending)
      (remhash buffer agent-shell-attention--busy)
      (remhash buffer agent-shell-attention--busy-since)
      (remhash buffer agent-shell-attention--last-event))
    (nreverse entries)))

(defun agent-shell-attention--pending-entry-label (entry)
  "Return the descriptive label stored in ENTRY."
  (cond
   ((plistp entry) (plist-get entry :label))
   ((consp entry) (car entry))
   (t entry)))

(defun agent-shell-attention--pending-entry-timestamp (entry)
  "Return the timestamp stored in ENTRY or 0 if missing."
  (cond
   ((plistp entry) (or (plist-get entry :timestamp) 0.0))
   ((consp entry) (cdr entry))
   (t 0.0)))

(defun agent-shell-attention--pending-entry-request-id (entry)
  "Return the permission request id stored in ENTRY, if any."
  (when (plistp entry)
    (plist-get entry :request-id)))

(defun agent-shell-attention--pending-entry-tool-call-id (entry)
  "Return the permission tool call id stored in ENTRY, if any."
  (when (plistp entry)
    (plist-get entry :tool-call-id)))

(defun agent-shell-attention--busy-live-buffers (&optional subscribed-only)
  "Return a list of live buffers currently marked busy.

This call also purges stale entries for dead buffers.
When SUBSCRIBED-ONLY is non-nil, discover busy buffers using the event
subscriptions rather than scanning every Emacs buffer."
  (let ((buffers nil)
        (seen (make-hash-table :test #'eq)))
    (maphash (lambda (buffer _count)
               (if (buffer-live-p buffer)
                   (progn
                     (unless (agent-shell-attention--buffer-busy-p buffer)
                       (setq agent-shell-attention--reconciled-state-changed t)
                       (remhash buffer agent-shell-attention--busy)
                       (remhash buffer agent-shell-attention--busy-since))
                     (when (agent-shell-attention--buffer-busy-p buffer)
                       (puthash buffer t seen)
                       (push buffer buffers)))
                 (setq agent-shell-attention--reconciled-state-changed t)
                 (remhash buffer agent-shell-attention--busy)
                 (remhash buffer agent-shell-attention--busy-since)
                 (remhash buffer agent-shell-attention--pending)
                 (remhash buffer agent-shell-attention--last-event)))
             agent-shell-attention--busy)
    (dolist (buffer (if subscribed-only
                       (hash-table-keys agent-shell-attention--subscriptions)
                     (agent-shell-attention--live-agent-shell-buffers)))
      (when (and (agent-shell-attention--buffer-busy-p buffer)
                 (not (gethash buffer seen)))
        (unless (gethash buffer agent-shell-attention--busy-since)
          (puthash buffer (float-time) agent-shell-attention--busy-since))
        (puthash buffer 1 agent-shell-attention--busy)
        (setq agent-shell-attention--reconciled-state-changed t)
        (push buffer buffers)))
    (nreverse buffers)))

(defun agent-shell-attention--buffer-busy-p (buffer)
  "Return non-nil when BUFFER has in-flight `agent-shell' requests."
  (when (buffer-live-p buffer)
    (with-current-buffer buffer
      (when (derived-mode-p 'agent-shell-mode)
        (let ((state (and (boundp 'agent-shell--state)
                          agent-shell--state)))
          (and state
               (map-elt state :active-requests)))))))

(defun agent-shell-attention--compute-active-count (pending-count &optional subscribed-only)
  "Return number of unique buffers that are pending or busy.
PENDING-COUNT is the number of buffers awaiting a reply.
Pass SUBSCRIBED-ONLY to `agent-shell-attention--busy-live-buffers'."
  (let ((count pending-count))
    (dolist (buffer (agent-shell-attention--busy-live-buffers subscribed-only))
      (unless (gethash buffer agent-shell-attention--pending)
        (setq count (1+ count))))
    count))

(defun agent-shell-attention--buffer-selected-p (buffer)
  "Return non-nil if BUFFER is currently shown in the selected window.
A viewport buffer belonging to BUFFER counts as BUFFER, so
interacting with a session through its viewport suppresses
notifications the same way the shell buffer itself does."
  (let ((window (selected-window)))
    (and (window-live-p window)
         (or (eq buffer (window-buffer window))
             (and (fboundp 'agent-shell-viewport--shell-buffer)
                  (eq buffer (agent-shell-viewport--shell-buffer
                              (window-buffer window))))))))

(defun agent-shell-attention--frame-focused-p ()
  "Return non-nil if any Emacs frame currently has input focus."
  (seq-some (lambda (frame)
              (and (frame-live-p frame)
                   (frame-focus-state frame)))
            (frame-list)))

(defun agent-shell-attention--should-notify-buffer (buffer)
  "Return non-nil when BUFFER warrants notifications or lighter updates."
  (or (not (agent-shell-attention--buffer-selected-p buffer))
      (not (agent-shell-attention--frame-focused-p))))

(defun agent-shell-attention--awaiting-p (stop-reason)
  "Return non-nil when STOP-REASON should mark a buffer as awaiting input."
  (and stop-reason
       (member stop-reason agent-shell-attention-awaiting-stop-reasons)))

(defun agent-shell-attention--describe-stop (stop-reason)
  "Return human-readable text for STOP-REASON."
  (pcase stop-reason
    ("end_turn" "Finished")
    ("max_tokens" "Max token limit reached")
    ("max_turn_requests" "Exceeded request limit")
    ("refusal" "Refused")
    ("cancelled" "Cancelled")
    ((pred stringp) (format "Stop for unknown reason: %s" stop-reason))
    (_ "Finished")))

(defun agent-shell-attention--extract-message (object)
  "Return a message or error code from OBJECT, if available."
  (cond
   ((stringp object) object)
   ((mapp object)
    (or (map-elt object 'message)
        (map-elt object 'code)))))

(defun agent-shell-attention--sanitize-summary (summary)
  "Return SUMMARY as a compact single-line string."
  (let ((text (if (stringp summary) summary (format "%s" summary))))
    (string-trim (replace-regexp-in-string "[ \t\n\r]+" " " text))))

(defun agent-shell-attention--record-event (buffer status summary &optional timestamp)
  "Remember BUFFER activity with STATUS and SUMMARY.
TIMESTAMP defaults to current time."
  (when (buffer-live-p buffer)
    (let ((entry (list :status status
                       :summary (agent-shell-attention--sanitize-summary summary)
                       :timestamp (or timestamp (float-time)))))
      (puthash buffer entry agent-shell-attention--last-event)
      (with-current-buffer buffer
        (add-hook 'kill-buffer-hook
                  #'agent-shell-attention--on-buffer-killed nil t)))))

(defun agent-shell-attention--maybe-notify (buffer title body)
  "Show notification for BUFFER with TITLE and BODY when configured."
  (when agent-shell-attention-notify-function
    (condition-case err
        (funcall agent-shell-attention-notify-function buffer title body)
      (error
       (message "agent-shell-attention notification error: %s" err)))))

(defun agent-shell-attention--message (buffer text)
  "Display TEXT as a minibuffer notification for BUFFER."
  (when (and (buffer-live-p buffer)
             (agent-shell-attention--should-notify-buffer buffer))
    (let* ((name (buffer-name buffer))
           (title (format "%s agent" name)))
      (message "%s %s: %s" agent-shell-attention-message-prefix name text)
      (agent-shell-attention--maybe-notify buffer title text))))

(defun agent-shell-attention--on-buffer-killed ()
  "Buffer-local hook to keep tracking tables tidy."
  (let ((buffer (current-buffer))
        (dashboard-relevant-p (derived-mode-p 'agent-shell-mode))
        (changed nil))
    (agent-shell-attention--unsubscribe-buffer buffer)
    (when (gethash buffer agent-shell-attention--pending)
      (remhash buffer agent-shell-attention--pending)
      (setq changed t))
    (when (gethash buffer agent-shell-attention--busy)
      (remhash buffer agent-shell-attention--busy)
      (setq changed t))
    (when (gethash buffer agent-shell-attention--busy-since)
      (remhash buffer agent-shell-attention--busy-since)
      (setq changed t))
    (when (gethash buffer agent-shell-attention--last-event)
      (remhash buffer agent-shell-attention--last-event)
      (setq changed t))
    (when (or changed dashboard-relevant-p)
      (agent-shell-attention--schedule-indicator-update)
      (agent-shell-attention--schedule-dashboard-refresh))))

(defun agent-shell-attention--clear-buffer (buffer)
  "Remove BUFFER from the pending table and refresh the mode line."
  (let ((had-pending (gethash buffer agent-shell-attention--pending)))
    (when had-pending
      (remhash buffer agent-shell-attention--pending))
    (when (and had-pending
               (buffer-live-p buffer)
               (not (gethash buffer agent-shell-attention--pending))
               (not (gethash buffer agent-shell-attention--busy))
               (not (gethash buffer agent-shell-attention--last-event)))
      (with-current-buffer buffer
        (remove-hook 'kill-buffer-hook
                     #'agent-shell-attention--on-buffer-killed t)))
    (when had-pending
      (agent-shell-attention--schedule-indicator-update)
      (agent-shell-attention--maybe-refresh-dashboard))))

(defun agent-shell-attention--maybe-clear-current ()
  "Clear the currently selected buffer if it no longer needs attention.
A selected viewport buffer counts as its session's shell buffer."
  (when-let* ((buffer (cond ((derived-mode-p 'agent-shell-mode)
                             (current-buffer))
                            ((fboundp 'agent-shell-viewport--shell-buffer)
                             (agent-shell-viewport--shell-buffer
                              (current-buffer))))))
    ;; Clear as soon as no outstanding permissions remain.
    (unless (agent-shell-attention--permission-pending-p buffer)
      (agent-shell-attention--clear-buffer buffer))))

;;; Navigation UI

(defun agent-shell-attention--entry-label (buffer entry)
  "Return label for BUFFER with ENTRY text."
  (format "%s — %s"
          (buffer-name buffer)
          (agent-shell-attention--pending-entry-label entry)))

(defun agent-shell-attention--entry-older-p (entry-a entry-b)
  "Return non-nil when ENTRY-A is older than ENTRY-B."
  (< (agent-shell-attention--pending-entry-timestamp (cdr entry-a))
     (agent-shell-attention--pending-entry-timestamp (cdr entry-b))))

(defun agent-shell-attention--active-entry-records ()
  "Return ordered candidate records for active agent-shell buffers.

Each record is a list (BUFFER ENTRY STATUS), where STATUS is either
`pending' (awaiting user response), `permission' (permission prompt),
or `busy' (in-flight request)."
  (let* ((pending (copy-sequence (agent-shell-attention--pending-live-entries)))
         (pending-sorted (sort pending #'agent-shell-attention--entry-older-p))
         (busy-only (cl-remove-if
                     (lambda (buffer)
                       (gethash buffer agent-shell-attention--pending))
                     (agent-shell-attention--busy-live-buffers)))
         (busy-sorted (sort busy-only
                            (lambda (a b)
                              (string-lessp (buffer-name a) (buffer-name b)))))
         (records nil))
    (dolist (entry pending-sorted)
      (push (list (car entry)
                  (cdr entry)
                  (if (agent-shell-attention--pending-entry-permission-p (cdr entry))
                      'permission
                    'pending))
            records))
    (dolist (buffer busy-sorted)
      (push (list buffer nil 'busy) records))
    (nreverse records)))

(defun agent-shell-attention--unique-candidates-with-status (records)
  "Return an alist of (DISPLAY . (BUFFER . STATUS)) built from RECORDS.

RECORDS is a list of (BUFFER ENTRY STATUS).  DISPLAY strings are made
unique if multiple entries would otherwise collide."
  (let ((seen (make-hash-table :test #'equal))
        (candidates nil))
    (dolist (record records)
      (pcase-let ((`(,buffer ,entry ,status) record))
        (let* ((label (pcase status
                        ((or 'busy 'idle) (buffer-name buffer))
                        (_ (agent-shell-attention--entry-label buffer entry))))
               (count (gethash label seen 0))
               (unique (if (zerop count)
                           label
                         (format "%s <%d>" label (1+ count)))))
          (puthash label (1+ count) seen)
          (push (cons unique (cons buffer status)) candidates))))
    (nreverse candidates)))

(defun agent-shell-attention--completion-tag (status)
  "Return a visually distinguished completion tag for STATUS."
  (pcase status
    ('pending (propertize "Awaiting" 'face 'success))
    ('permission (propertize "Permissions" 'face 'warning))
    ('busy (propertize "Running" 'face 'shadow))
    ('idle (propertize "Idle" 'face 'shadow))
    (_ (propertize "active" 'face 'shadow))))

(defun agent-shell-attention--completion-annotation (display status-table)
  "Return completion annotation string for DISPLAY using STATUS-TABLE."
  (let ((status (gethash display status-table)))
    (concat " [" (agent-shell-attention--completion-tag status) "]")))

(defun agent-shell-attention--completion-table (candidates)
  "Return completion table for CANDIDATES with ordering and annotations.

CANDIDATES is an alist of (DISPLAY . (BUFFER . STATUS))."
  (let* ((displays (mapcar #'car candidates))
         (order (let ((table (make-hash-table :test #'equal))
                      (index 0))
                  (dolist (display displays)
                    (puthash display index table)
                    (setq index (1+ index)))
                  table))
         (status-table (let ((table (make-hash-table :test #'equal)))
                          (dolist (candidate candidates)
                            (puthash (car candidate) (cddr candidate) table))
                          table))
         (annotation (lambda (display)
                       (agent-shell-attention--completion-annotation display status-table)))
         (affixation (lambda (completions)
                       (mapcar (lambda (completion)
                                 (let* ((display completion))
                                   (list display ""
                                         (agent-shell-attention--completion-annotation
                                          display status-table))))
                               completions)))
         (group (lambda (display transform)
                  (if transform
                      display
                    (pcase (gethash display status-table)
                      ('pending "Awaiting")
                      ('permission "Permissions")
                      ('busy "Running")
                      ('idle "Idle")
                      (_ "Active")))))
         (sorter (lambda (completions)
                   (sort (copy-sequence completions)
                         (lambda (a b)
                           (let* ((ia (gethash a order most-positive-fixnum))
                                  (ib (gethash b order most-positive-fixnum)))
                             (if (/= ia ib)
                                 (< ia ib)
                               (string-lessp a b))))))))
    ;; Keep the completion table usable on Emacs 29.
    (let ((metadata
           (append
            `((category . agent-shell-attention)
              (display-sort-function . ,sorter)
              (annotation-function . ,annotation)
              (affixation-function . ,affixation))
            (when agent-shell-attention-jump-show-groups
              `((group-function . ,group))))))
      (lambda (string predicate action)
        (if (eq action 'metadata)
            (cons 'metadata metadata)
          (complete-with-action action displays string predicate))))))

(defun agent-shell-attention--jump-to-buffer (buffer)
  "Switch to BUFFER, clearing pending state when appropriate.
When `agent-shell-prefer-viewport-interaction' is non-nil and BUFFER
has an existing viewport buffer, switch to the viewport instead."
  (when (buffer-live-p buffer)
    (run-hook-with-args 'agent-shell-attention-before-jump-hook buffer)
    (unless (agent-shell-attention--permission-pending-p buffer)
      (agent-shell-attention--clear-buffer buffer))
    (let ((target (if (and (boundp 'agent-shell-prefer-viewport-interaction)
                           agent-shell-prefer-viewport-interaction
                           (fboundp 'agent-shell-viewport--buffer))
                      (or (agent-shell-viewport--buffer
                           :shell-buffer buffer :existing-only t)
                          buffer)
                    buffer)))
      (pop-to-buffer target agent-shell-attention-display-buffer-action))))

(defun agent-shell-attention--build-menu (entries)
  "Create popup menu for ENTRIES.
ENTRIES is an alist of (BUFFER . ENTRY)."
  (easy-menu-create-menu
   "Agent Shell Attention"
   (mapcar (lambda (entry)
             (vector (agent-shell-attention--entry-label (car entry)
                                                         (cdr entry))
                     `(agent-shell-attention--jump-to-buffer ',(car entry))
                     t))
           entries)))

(defun agent-shell-attention--double-prefix-arg-p (prefix)
  "Return non-nil when PREFIX is a double universal prefix argument."
  (or (equal prefix '(16))
      (and (integerp prefix) (= prefix 16))))

(defun agent-shell-attention--format-timestamp (timestamp)
  "Return TIMESTAMP as a formatted dashboard time string."
  (if (not (numberp timestamp))
      "-"
    (format-time-string agent-shell-attention-dashboard-time-format
                        (seconds-to-time timestamp))))

(defun agent-shell-attention--dashboard-time-column-width ()
  "Return the width to reserve for the dashboard timestamp column."
  (max 12 (length (agent-shell-attention--format-timestamp (float-time)))))

(defun agent-shell-attention--truncate-text (text max-width)
  "Clamp TEXT to MAX-WIDTH characters."
  (let ((clean (agent-shell-attention--sanitize-summary text)))
    (if (or (<= max-width 0)
            (<= (length clean) max-width))
        clean
      (concat (substring clean 0 (max 0 (- max-width 3))) "..."))))

(defun agent-shell-attention--permission-status-text (label)
  "Return dashboard status text for permission LABEL."
  (let* ((detail (string-trim (string-remove-prefix "Permission:" label)))
         (max-detail agent-shell-attention-dashboard-permission-detail-length))
    (if (or (string-empty-p detail)
            (<= max-detail 0))
        "Permissions"
      (format "Permissions: (%s)"
              (agent-shell-attention--truncate-text detail max-detail)))))

(defun agent-shell-attention--pending-status-text (pending-entry)
  "Return dashboard status text for PENDING-ENTRY."
  (let ((label (agent-shell-attention--sanitize-summary
                (agent-shell-attention--pending-entry-label pending-entry))))
    (if (string-prefix-p "Permission:" label)
        (agent-shell-attention--permission-status-text label)
      "Awaiting")))

(defun agent-shell-attention--pending-entry-permission-p (pending-entry)
  "Return non-nil when PENDING-ENTRY represents a permission request."
  (let ((label (agent-shell-attention--sanitize-summary
                (agent-shell-attention--pending-entry-label pending-entry))))
    (string-prefix-p "Permission:" label)))

(defun agent-shell-attention--dashboard-buffer-name (name)
  "Return dashboard-friendly display text for buffer NAME.

Long names are truncated on the left so the most specific suffix remains
visible, then right-aligned by tabulated-list."
  (let* ((raw (or name ""))
         (width (max 4 agent-shell-attention-dashboard-buffer-column-width))
         (len (length raw)))
    (if (<= len width)
        raw
      (concat "…" (substring raw (max 0 (- len (1- width))))))))

(defun agent-shell-attention--live-agent-shell-buffers ()
  "Return all live `agent-shell-mode' buffers."
  (let ((buffers nil))
    (dolist (buffer (buffer-list))
      (when (buffer-live-p buffer)
        (with-current-buffer buffer
          (when (derived-mode-p 'agent-shell-mode)
            (push buffer buffers)))))
    (nreverse buffers)))

(defun agent-shell-attention--dashboard-status-rank (status)
  "Return sort rank for STATUS."
  (pcase status
    ('pending 0)
    ('busy 1)
    (_ 2)))

(defun agent-shell-attention--dashboard-buffer-record (buffer pending-table)
  "Return dashboard plist for BUFFER using PENDING-TABLE."
  (let* ((pending-entry (gethash buffer pending-table))
         (busy-count (gethash buffer agent-shell-attention--busy 0))
         (busy-p (and (integerp busy-count) (> busy-count 0)))
         (event (gethash buffer agent-shell-attention--last-event))
         (event-time (plist-get event :timestamp))
         (status (cond
                  (pending-entry 'pending)
                  (busy-p 'busy)
                  (t 'idle)))
         (activity-time (cond
                         (pending-entry
                          (agent-shell-attention--pending-entry-timestamp pending-entry))
                         (busy-p
                          (or (gethash buffer agent-shell-attention--busy-since)
                              event-time))
                         (t event-time)))
         (status-text (cond
                       (pending-entry
                        (agent-shell-attention--pending-status-text pending-entry))
                       (busy-p
                        "Running")
                       (t
                        "Idle"))))
    (list :buffer buffer
          :name (buffer-name buffer)
          :status status
          :rank (agent-shell-attention--dashboard-status-rank status)
          :activity-time activity-time
          :status-text (agent-shell-attention--truncate-text
                        status-text
                        agent-shell-attention-dashboard-max-reason-length))))

(defun agent-shell-attention--dashboard-record< (a b)
  "Return non-nil when dashboard record A should sort before B."
  (let ((rank-a (plist-get a :rank))
        (rank-b (plist-get b :rank)))
    (cond
     ((/= rank-a rank-b)
      (< rank-a rank-b))
     (t
      (let ((time-a (or (plist-get a :activity-time) 0.0))
            (time-b (or (plist-get b :activity-time) 0.0)))
        (if (/= time-a time-b)
            (> time-a time-b)
          (string-lessp (plist-get a :name) (plist-get b :name))))))))

(defun agent-shell-attention--dashboard-records ()
  "Collect and sort dashboard records for all live agent-shell buffers."
  (let ((pending-table (make-hash-table :test #'eq))
        (records nil))
    (dolist (entry (agent-shell-attention--pending-live-entries))
      (puthash (car entry) (cdr entry) pending-table))
    (agent-shell-attention--busy-live-buffers)
    (dolist (buffer (agent-shell-attention--live-agent-shell-buffers))
      (push (agent-shell-attention--dashboard-buffer-record buffer pending-table)
            records))
    (sort records #'agent-shell-attention--dashboard-record<)))

(defun agent-shell-attention--dashboard-count (records status)
  "Count how many RECORDS currently have STATUS."
  (cl-count status records :key (lambda (record) (plist-get record :status))))

(defun agent-shell-attention--dashboard-header-line (records)
  "Return dashboard header line for RECORDS."
  (format "Awaiting:%d  Running:%d  Idle:%d   RET: visit  o: other window  j: ambient dir  D: kill session  g: refresh"
          (agent-shell-attention--dashboard-count records 'pending)
          (agent-shell-attention--dashboard-count records 'busy)
          (agent-shell-attention--dashboard-count records 'idle)))

(defun agent-shell-attention--dashboard-entries (records)
  "Return tabulated list entries from dashboard RECORDS."
  (mapcar
   (lambda (record)
     (let* ((buffer (plist-get record :buffer))
            (activity-time (plist-get record :activity-time))
            (timestamp (agent-shell-attention--format-timestamp activity-time)))
       (list buffer
             (vector
              (agent-shell-attention--dashboard-buffer-name
               (plist-get record :name))
              timestamp
              (plist-get record :status-text)))))
   records))

(defun agent-shell-attention--dashboard-current-row-index ()
  "Return the zero-based dashboard row index at point, or nil."
  (when (tabulated-list-get-id)
    (count-lines (point-min) (line-beginning-position))))

(defun agent-shell-attention--dashboard-position-state (&optional position)
  "Return dashboard row state at POSITION, or point when POSITION is nil."
  (save-excursion
    (when position
      (goto-char position))
    (when-let* ((id (tabulated-list-get-id)))
      (list :id id
            :row (agent-shell-attention--dashboard-current-row-index)
            :column (current-column)))))

(defun agent-shell-attention--dashboard-entry-present-p (id entries)
  "Return non-nil when ID appears in tabulated list ENTRIES."
  (cl-some (lambda (entry)
             (eq (car entry) id))
           entries))

(defun agent-shell-attention--dashboard-goto-entry-id (id)
  "Move point to dashboard entry ID and return non-nil if found."
  (goto-char (point-min))
  (catch 'found
    (while (not (eobp))
      (when (eq (tabulated-list-get-id) id)
        (throw 'found t))
      (forward-line 1))
    nil))

(defun agent-shell-attention--dashboard-goto-row-index (index column)
  "Move point to dashboard row INDEX and preserve COLUMN when possible."
  (goto-char (point-min))
  (forward-line (max 0 index))
  (while (and (not (bobp))
              (not (tabulated-list-get-id)))
    (forward-line -1))
  (when (tabulated-list-get-id)
    (move-to-column column)))

(defun agent-shell-attention--dashboard-position-for-state (state entries)
  "Return buffer position for dashboard STATE after refresh to ENTRIES."
  (when state
    (let ((id (plist-get state :id))
          (row (plist-get state :row))
          (column (plist-get state :column)))
      (save-excursion
        (cond
         ((and id
               (not agent-shell-attention--dashboard-preserve-row)
               (agent-shell-attention--dashboard-entry-present-p id entries)
               (agent-shell-attention--dashboard-goto-entry-id id))
          (move-to-column column)
          (point))
         ((and row entries)
          (agent-shell-attention--dashboard-goto-row-index
           (min row (1- (length entries)))
           column)
          (when (tabulated-list-get-id)
            (point))))))))

(defun agent-shell-attention--dashboard-visible-window-states (buffer)
  "Return dashboard position state for live windows displaying BUFFER."
  (delq nil
        (mapcar
         (lambda (window)
           (when (window-live-p window)
             (with-current-buffer buffer
               (when-let* ((state (agent-shell-attention--dashboard-position-state
                                   (window-point window))))
                 (plist-put state :window window)))))
         (get-buffer-window-list buffer nil t))))

(defun agent-shell-attention--dashboard-restore-window-points (states entries)
  "Restore dashboard window STATES after refresh to ENTRIES."
  (dolist (state states)
    (when-let* ((window (plist-get state :window))
                (_ (window-live-p window))
                (position (agent-shell-attention--dashboard-position-for-state
                           state entries)))
      (set-window-point window position))))

(defun agent-shell-attention--refresh-dashboard-buffer (buffer)
  "Refresh dashboard BUFFER when it is still live."
  (when (buffer-live-p buffer)
    (let ((window-states
           (agent-shell-attention--dashboard-visible-window-states buffer)))
      (with-current-buffer buffer
        (when (derived-mode-p 'agent-shell-attention-dashboard-mode)
          (agent-shell-attention-dashboard-refresh)
          (agent-shell-attention--dashboard-restore-window-points
           window-states tabulated-list-entries))))))

(defun agent-shell-attention--schedule-dashboard-refresh ()
  "Refresh the dashboard after the current buffer lifecycle change settles."
  (when-let* ((buffer (get-buffer agent-shell-attention-dashboard-buffer-name)))
    (run-at-time 0 nil
                 #'agent-shell-attention--refresh-dashboard-buffer
                 buffer)))

(defun agent-shell-attention--maybe-refresh-dashboard ()
  "Refresh dashboard buffer when it is currently open."
  (when-let* ((buffer (get-buffer agent-shell-attention-dashboard-buffer-name)))
    (agent-shell-attention--refresh-dashboard-buffer buffer)))

(defun agent-shell-attention-dashboard-refresh ()
  "Refresh the agent-shell attention dashboard."
  (interactive)
  (let* ((old-state (agent-shell-attention--dashboard-position-state))
         (records (agent-shell-attention--dashboard-records))
         (entries (agent-shell-attention--dashboard-entries records)))
    (setq header-line-format (agent-shell-attention--dashboard-header-line records))
    (setq tabulated-list-entries entries)
    (tabulated-list-print (not agent-shell-attention--dashboard-preserve-row))
    (when-let* ((position (agent-shell-attention--dashboard-position-for-state
                           old-state entries)))
      (goto-char position))))

(defun agent-shell-attention-dashboard-visit ()
  "Visit agent-shell buffer on current dashboard row."
  (interactive)
  (when-let* ((buffer (agent-shell-attention-dashboard--selected-live-buffer)))
    (let ((agent-shell-attention--dashboard-preserve-row t))
      (agent-shell-attention--jump-to-buffer buffer))))

(defun agent-shell-attention-dashboard-visit-other-window ()
  "Visit agent-shell buffer on current dashboard row in another window."
  (interactive)
  (when-let* ((buffer (agent-shell-attention-dashboard--selected-live-buffer)))
    (let ((agent-shell-attention--dashboard-preserve-row t))
      (run-hook-with-args 'agent-shell-attention-before-jump-hook buffer)
      (unless (agent-shell-attention--permission-pending-p buffer)
        (agent-shell-attention--clear-buffer buffer))
      (switch-to-buffer-other-window buffer))))

(defun agent-shell-attention-dashboard-open-ambient-directory ()
  "Open dashboard row buffer's ambient directory in Dired."
  (interactive)
  (when-let* ((buffer (agent-shell-attention-dashboard--selected-live-buffer)))
    (let ((directory (with-current-buffer buffer default-directory)))
      (dired directory))))

(defun agent-shell-attention-dashboard-kill-session ()
  "Kill the dashboard row's agent-shell session."
  (interactive)
  (when-let* ((buffer (agent-shell-attention-dashboard--selected-live-buffer)))
    (when (yes-or-no-p (format "Kill session for %s? " (buffer-name buffer)))
      (kill-buffer buffer)
      (agent-shell-attention-dashboard-refresh))))

(defun agent-shell-attention-dashboard--selected-live-buffer ()
  "Return live agent-shell buffer on current dashboard row.

If the row is stale, show an explanatory message and refresh."
  (let ((buffer (tabulated-list-get-id)))
    (if (buffer-live-p buffer)
        buffer
      (message "No live agent-shell buffer on this line")
      (agent-shell-attention-dashboard-refresh)
      nil)))

(defvar agent-shell-attention-dashboard-mode-map
  (let ((map (make-sparse-keymap)))
    (set-keymap-parent map tabulated-list-mode-map)
    (define-key map (kbd "RET") #'agent-shell-attention-dashboard-visit)
    (define-key map (kbd "o") #'agent-shell-attention-dashboard-visit-other-window)
    (define-key map (kbd "j") #'agent-shell-attention-dashboard-open-ambient-directory)
    (define-key map (kbd "D") #'agent-shell-attention-dashboard-kill-session)
    map)
  "Keymap used in `agent-shell-attention-dashboard-mode'.")

(define-derived-mode agent-shell-attention-dashboard-mode tabulated-list-mode "ASA Dashboard"
  "Tabulated heads-up display for `agent-shell-attention'."
  (setq tabulated-list-format
        (vector
         `("Buffer" ,agent-shell-attention-dashboard-buffer-column-width t
           :right-align t)
         `("Last active" ,(agent-shell-attention--dashboard-time-column-width) nil)
         '("Status" 0 t)))
  (setq tabulated-list-padding 2)
  (setq tabulated-list-sort-key nil)
  (add-hook 'tabulated-list-revert-hook
            #'agent-shell-attention-dashboard-refresh nil t)
  (tabulated-list-init-header))

;;;###autoload
(defun agent-shell-attention-dashboard ()
  "Open a tabulated status dashboard for live agent-shell buffers."
  (interactive)
  (let ((buffer (get-buffer-create agent-shell-attention-dashboard-buffer-name)))
    (with-current-buffer buffer
      (agent-shell-attention-dashboard-mode)
      (agent-shell-attention-dashboard-refresh))
    (pop-to-buffer buffer)))

;;;###autoload
(defun agent-shell-attention-jump (&optional prompt)
  "Jump to an agent-shell buffer awaiting your response.

With PROMPT (prefix argument), use `completing-read' to select from all
active agent-shell buffers, ordered with pending buffers first and
busy buffers after.

With a double prefix argument (\\[universal-argument] \\[universal-argument]),
open `agent-shell-attention-dashboard'.

Without PROMPT, jump to the oldest pending buffer."
  (interactive "P")
  (cond
   ((agent-shell-attention--double-prefix-arg-p prompt)
    (agent-shell-attention-dashboard))
   (prompt
    (let* ((records (agent-shell-attention--active-entry-records)))
      (if (null records)
          (message "No active agent-shell buffers")
        (let* ((candidates (agent-shell-attention--unique-candidates-with-status records))
               (table (agent-shell-attention--completion-table candidates))
               (choice (completing-read "Agent shell: " table nil t))
               (entry (assoc choice candidates))
               (buffer (and entry (cadr entry))))
          (when (buffer-live-p buffer)
            (agent-shell-attention--jump-to-buffer buffer))))))
   (t
    (let* ((entries (copy-sequence (agent-shell-attention--pending-live-entries)))
           (sorted (sort entries #'agent-shell-attention--entry-older-p)))
      (if (null sorted)
          (message "No agent-shell buffers awaiting replies")
        (agent-shell-attention--jump-to-buffer (caar sorted)))))))

;;;###autoload
(defun agent-shell-attention-jump-idle (&optional prompt)
  "Jump to the most recently visited idle agent-shell buffer.
Use buffer order, so `bury-buffer' puts a shell behind the others.
Exclude buffers with pending replies or in-flight requests.
With PROMPT (prefix argument), choose an idle buffer with completion."
  (interactive "P")
  (let* ((pending (agent-shell-attention--pending-live-entries))
         (buffers (cl-remove-if
                   (lambda (buffer)
                     (or (assq buffer pending)
                         (agent-shell-attention--buffer-busy-p buffer)))
                   (agent-shell-attention--live-agent-shell-buffers))))
    (if (null buffers)
        (message "No idle agent-shell buffers")
      (agent-shell-attention--jump-to-buffer
       (if prompt
           (let* ((records (mapcar (lambda (buffer) (list buffer nil 'idle))
                                   buffers))
                  (candidates (agent-shell-attention--unique-candidates-with-status
                               records))
                  (table (agent-shell-attention--completion-table candidates))
                  (choice (completing-read "Idle agent shell: " table nil t
                                           nil nil (caar candidates))))
             (cadr (assoc choice candidates)))
         (car buffers))))))

(defun agent-shell-attention-open-menu (&optional event)
  "Show pending agent-shell buffers in a popup menu.
EVENT is the mouse event used to trigger the menu."
  (interactive (list last-nonmenu-event))
  (let ((entries (agent-shell-attention--pending-live-entries)))
    (if (null entries)
        (message "No agent-shell buffers awaiting replies")
      (popup-menu (agent-shell-attention--build-menu entries) event))))

(defvar agent-shell-attention--mode-line-map
  (let ((map (make-sparse-keymap)))
    (define-key map [mode-line down-mouse-1] #'agent-shell-attention-open-menu)
    (define-key map [mode-line mouse-1] #'ignore)
    (define-key map [mode-line down-mouse-3] #'agent-shell-attention-open-menu)
    map)
  "Keymap used to make the mode-line indicator clickable.")

(defun agent-shell-attention-render-pending (pending-count _active-count)
  "Render only PENDING-COUNT using `agent-shell-attention-lighter'.

ACTIVE-COUNT is accepted for API compatibility but ignored."
  (if (or (null agent-shell-attention-lighter)
          (and (zerop pending-count)
               (not agent-shell-attention-show-zeros)))
      ""
    (let ((label (format agent-shell-attention-lighter pending-count)))
      (propertize label
                  'mouse-face 'mode-line-highlight
                  'help-echo "mouse-1: list agent-shell buffers awaiting reply"
                  'local-map agent-shell-attention--mode-line-map))))

(defun agent-shell-attention-render-active (pending-count active-count)
  "Render pending PENDING-COUNT plus ACTIVE-COUNT with the active lighter."
  (let* ((active (or active-count pending-count))
         (nonzero (or (> pending-count 0) (> active 0)))
         (show (and agent-shell-attention-active-lighter
                    (or nonzero agent-shell-attention-show-zeros))))
    (when show
      (let ((label (format agent-shell-attention-active-lighter pending-count active)))
        (propertize label
                    'mouse-face 'mode-line-highlight
                    'help-echo "mouse-1: list agent-shell buffers awaiting reply"
                    'local-map agent-shell-attention--mode-line-map)))))

;;; Agent-shell integration

(defun agent-shell-attention--ensure-mode-line-entry ()
  "Ensure our indicator is present in both current and default mode line."
  (agent-shell-attention--apply-indicator-location))

(defun agent-shell-attention--mark-busy (buffer)
  "Mark BUFFER as busy (with an in-flight request)."
  (when (buffer-live-p buffer)
    (let* ((count (gethash buffer agent-shell-attention--busy 0))
           (previous (if (and (integerp count) (> count 0)) count 0))
           (current (1+ previous))
           (now (float-time)))
      (puthash buffer current agent-shell-attention--busy)
      (unless (> previous 0)
        (puthash buffer now agent-shell-attention--busy-since))
      (agent-shell-attention--record-event
       buffer 'busy
       (if (> current 1)
           (format "Running (%d requests)" current)
         "Running")
       now))
    (with-current-buffer buffer
      (add-hook 'kill-buffer-hook
                #'agent-shell-attention--on-buffer-killed nil t))
    (agent-shell-attention--ensure-mode-line-entry)
    (agent-shell-attention--schedule-indicator-update)
    (agent-shell-attention--maybe-refresh-dashboard)))

(defun agent-shell-attention--clear-busy (buffer)
  "Clear one busy mark for BUFFER, removing it when the refcount hits 0."
  (when (gethash buffer agent-shell-attention--busy)
    (let* ((count (gethash buffer agent-shell-attention--busy 0))
           (new-count (1- (if (integerp count) count 1))))
      (if (> new-count 0)
          (puthash buffer new-count agent-shell-attention--busy)
        (remhash buffer agent-shell-attention--busy)
        (remhash buffer agent-shell-attention--busy-since)
        (when (buffer-live-p buffer)
          (with-current-buffer buffer
            (unless (or (gethash buffer agent-shell-attention--pending)
                        (gethash buffer agent-shell-attention--last-event))
              (remove-hook 'kill-buffer-hook
                           #'agent-shell-attention--on-buffer-killed t)))))))
  (agent-shell-attention--schedule-indicator-update)
  (agent-shell-attention--maybe-refresh-dashboard))

(defun agent-shell-attention--tool-call-awaits-permission-p (tool-call)
  "Return non-nil when TOOL-CALL still requires a user decision."
  (when tool-call
    (let ((permission-id (map-elt tool-call :permission-request-id))
          (status (map-elt tool-call :status)))
      (and permission-id
           (or (null status)
               (equal status "pending"))))))

(defun agent-shell-attention--permission-pending-p (buffer)
  "Return non-nil when BUFFER still has outstanding permission prompts."
  (when (buffer-live-p buffer)
    (with-current-buffer buffer
      (when (derived-mode-p 'agent-shell-mode)
        (let ((state (and (boundp 'agent-shell--state)
                          agent-shell--state)))
          (when state
            (let ((tool-calls (map-elt state :tool-calls)))
              (when tool-calls
                (condition-case nil
                    (catch 'pending
                      (map-do (lambda (_tool-call-id tool-call)
                                (when (agent-shell-attention--tool-call-awaits-permission-p tool-call)
                                  (throw 'pending t)))
                              tool-calls)
                      nil)
                  (error nil))))))))))

(cl-defun agent-shell-attention--mark-buffer
    (buffer label &key force request-id tool-call-id)
  "Mark BUFFER as waiting for user input with LABEL description.

When FORCE is non-nil, mark the buffer even if it's currently selected.
REQUEST-ID and TOOL-CALL-ID identify a pending permission request."
  (when (buffer-live-p buffer)
    (let ((should-track (or force
                            (agent-shell-attention--should-notify-buffer buffer))))
      (when should-track
        (let ((now (float-time)))
          (agent-shell-attention--record-event buffer 'pending label now)
          (unless (gethash buffer agent-shell-attention--pending)
            (with-current-buffer buffer
              (add-hook 'kill-buffer-hook
                        #'agent-shell-attention--on-buffer-killed nil t)))
          (puthash buffer
                   (if (or request-id tool-call-id)
                       (list :label label
                             :timestamp now
                             :request-id request-id
                             :tool-call-id tool-call-id)
                     (cons label now))
                   agent-shell-attention--pending))
        (agent-shell-attention--ensure-mode-line-entry)
        (agent-shell-attention--schedule-indicator-update)
        (agent-shell-attention--maybe-refresh-dashboard)))))

(defun agent-shell-attention--handle-success (buffer response)
  "Process successful agent RESPONSE for BUFFER."
  (let* ((stop-reason (or (map-elt response 'stopReason)
                          (map-elt response :stop-reason)))
         (description (agent-shell-attention--describe-stop stop-reason))
         (awaiting (agent-shell-attention--awaiting-p stop-reason)))
    (unless awaiting
      (agent-shell-attention--record-event buffer 'done description)
      (agent-shell-attention--maybe-refresh-dashboard))
    (when (agent-shell-attention--should-notify-buffer buffer)
      (agent-shell-attention--message buffer description))
    (when awaiting
      (agent-shell-attention--mark-buffer buffer description))))

(defun agent-shell-attention--handle-failure (buffer error raw-message)
  "Handle agent failure for BUFFER using ERROR and RAW-MESSAGE."
  (let ((details (or (agent-shell-attention--extract-message error)
                     (agent-shell-attention--extract-message raw-message)
                     "Request failed")))
    (agent-shell-attention--record-event buffer 'failed details)
    (agent-shell-attention--maybe-refresh-dashboard)
    (when (agent-shell-attention--should-notify-buffer buffer)
      (agent-shell-attention--message buffer details))))

(defun agent-shell-attention--permission-label (tool-call)
  "Return descriptive label for permission TOOL-CALL."
  (let ((title (or (map-elt tool-call :title)
                   (map-elt tool-call 'title)
                   "Permission required"))
        (kind (or (map-elt tool-call :kind)
                  (map-elt tool-call 'kind))))
    (concat "Permission: " title
            (if kind (format " (%s)" kind) ""))))

(defun agent-shell-attention--permission-response-matches-p (entry data)
  "Return non-nil when permission response DATA answers pending ENTRY."
  (let ((entry-request-id
         (agent-shell-attention--pending-entry-request-id entry))
        (entry-tool-call-id
         (agent-shell-attention--pending-entry-tool-call-id entry))
        (response-request-id (map-elt data :request-id))
        (response-tool-call-id (map-elt data :tool-call-id)))
    (and (or entry-request-id entry-tool-call-id)
         (if entry-request-id
             (equal entry-request-id response-request-id)
           t)
         (if entry-tool-call-id
             (equal entry-tool-call-id response-tool-call-id)
           t))))

(defun agent-shell-attention--handle-event (buffer event)
  "Handle `agent-shell' EVENT for BUFFER."
  (let ((data (map-elt event :data)))
    (pcase (map-elt event :event)
      ('permission-request
       (let ((label (agent-shell-attention--permission-label
                     (map-elt data :tool-call))))
         (when (agent-shell-attention--should-notify-buffer buffer)
           (agent-shell-attention--message buffer label))
         (agent-shell-attention--mark-buffer
          buffer label :force t
          :request-id (map-elt data :request-id)
          :tool-call-id (map-elt data :tool-call-id))))
      ('permission-response
       (let ((entry (gethash buffer agent-shell-attention--pending)))
         (when (or (agent-shell-attention--permission-response-matches-p
                    entry data)
                   (not (agent-shell-attention--permission-pending-p buffer)))
           (agent-shell-attention--clear-buffer buffer)))
       (force-mode-line-update t)
       (agent-shell-attention--maybe-refresh-dashboard))
      ('turn-complete
       (agent-shell-attention--clear-busy buffer)
       (agent-shell-attention--handle-success buffer data)))))

(defun agent-shell-attention--subscribe-buffer (buffer)
  "Subscribe BUFFER to public `agent-shell' events."
  (when (and (buffer-live-p buffer)
             (with-current-buffer buffer
               (derived-mode-p 'agent-shell-mode))
             (not (gethash buffer agent-shell-attention--subscriptions)))
    (puthash buffer
             (agent-shell-subscribe-to
              :shell-buffer buffer
              :on-event (lambda (event)
                          (when (buffer-live-p buffer)
                            (agent-shell-attention--handle-event buffer event))))
             agent-shell-attention--subscriptions)
    (agent-shell-attention--schedule-indicator-update)
    (with-current-buffer buffer
      (add-hook 'kill-buffer-hook
                #'agent-shell-attention--on-buffer-killed nil t))))

(defun agent-shell-attention--unsubscribe-buffer (buffer)
  "Remove event subscription associated with BUFFER."
  (when-let* ((subscription (gethash buffer agent-shell-attention--subscriptions)))
    (remhash buffer agent-shell-attention--subscriptions)
    (when (buffer-live-p buffer)
      (with-current-buffer buffer
        (when (and (derived-mode-p 'agent-shell-mode)
                   (bound-and-true-p agent-shell--state))
          (agent-shell-unsubscribe :subscription subscription))))))

(defun agent-shell-attention--maybe-subscribe-current-buffer ()
  "Subscribe the current buffer when it is an `agent-shell-mode' buffer."
  (when (derived-mode-p 'agent-shell-mode)
    (agent-shell-attention--subscribe-buffer (current-buffer))))

(defun agent-shell-attention--decorate-request (buffer request-args)
  "Wrap REQUEST-ARGS with our completion hooks for BUFFER."
  (let ((on-success (plist-get request-args :on-success))
        (on-failure (plist-get request-args :on-failure)))
    (setq request-args
          (plist-put request-args :on-success
                     (lambda (response)
                       (agent-shell-attention--clear-busy buffer)
                       (when on-success
                         (funcall on-success response)))))
    (setq request-args
          (plist-put request-args :on-failure
                     (lambda (error raw-message)
                       (agent-shell-attention--clear-busy buffer)
                       (agent-shell-attention--handle-failure
                        buffer error raw-message)
                       (when on-failure
                         (funcall on-failure error raw-message)))))
    request-args))

(defun agent-shell-attention--around-send-command (orig-fn &rest args)
  "Advice around `agent-shell--send-command' ORIG-FN with ARGS.

Intercept completions to track buffers awaiting user input."
  (let* ((shell (plist-get args :shell))
         (buffer (or (and shell (map-elt shell :buffer))
                     (let ((shell-buffer (plist-get args :shell-buffer)))
                       (and (bufferp shell-buffer) shell-buffer)))))
    (if (not (buffer-live-p buffer))
        (apply orig-fn args)
      (agent-shell-attention--clear-buffer buffer)
      (agent-shell-attention--mark-busy buffer)
      (condition-case err
          (cl-letf* ((orig-request (symbol-function #'acp-send-request))
                     ((symbol-function #'acp-send-request)
                      (lambda (&rest request-args)
                        (prog1
                            (apply orig-request
                                   (agent-shell-attention--decorate-request
                                    buffer
                                    request-args))
                          ;; `agent-shell--send-request' marks :active-requests
                          ;; before calling `acp-send-request'.  Refresh once
                          ;; more here so the dashboard can observe the new
                          ;; running state immediately.
                          (agent-shell-attention--maybe-refresh-dashboard)))))
            (apply orig-fn args))
        (error
         (agent-shell-attention--clear-busy buffer)
         (signal (car err) (cdr err)))))))

;;; Minor mode

(defun agent-shell-attention--enable ()
  "Enable hooks and mode-line integration."
  (require 'agent-shell)
  (agent-shell-attention--ensure-mode-line-entry)
  (add-hook 'agent-shell-mode-hook
            #'agent-shell-attention--maybe-subscribe-current-buffer)
  (add-hook 'buffer-list-update-hook
            #'agent-shell-attention--maybe-clear-current)
  (advice-add #'agent-shell--send-command :around
              #'agent-shell-attention--around-send-command)
  (dolist (buffer (buffer-list))
    (with-current-buffer buffer
      (when (derived-mode-p 'agent-shell-mode)
        (agent-shell-attention--subscribe-buffer buffer))))
  ;; Reconcile requests that start or finish outside our command advice.
  ;; Redisplay itself must never scan buffers or switch their local bindings.
  (unless (timerp agent-shell-attention--indicator-timer)
    (setq agent-shell-attention--indicator-timer
          (run-at-time 1 1 #'agent-shell-attention--update-indicator)))
  (agent-shell-attention--update-indicator)
  (force-mode-line-update t))

(defun agent-shell-attention--disable ()
  "Disable hooks and clear all pending/busy markers."
  (dolist (timer (list agent-shell-attention--indicator-timer
                      agent-shell-attention--indicator-update-timer))
    (when (timerp timer)
      (cancel-timer timer)))
  (setq agent-shell-attention--indicator-timer nil
        agent-shell-attention--indicator-update-timer nil
        agent-shell-attention--indicator-error-reported nil
        agent-shell-attention--reconciled-state-changed nil
        agent-shell-attention--indicator-counts '(0 . 0))
  ;; Remove from both possible locations.
  (let ((indicator agent-shell-attention--mode-line))
    (setq mode-line-misc-info
          (agent-shell-attention--mode-line-list mode-line-misc-info))
    (setq global-mode-string
          (agent-shell-attention--mode-line-list global-mode-string))
    (setq-default mode-line-misc-info
                  (agent-shell-attention--mode-line-list
                   (default-value 'mode-line-misc-info)))
    (setq-default global-mode-string
                  (agent-shell-attention--mode-line-list
                   (default-value 'global-mode-string)))
    (setq mode-line-misc-info (delq indicator mode-line-misc-info))
    (setq global-mode-string (delq indicator global-mode-string))
    (setq-default mode-line-misc-info
                  (delq indicator (default-value 'mode-line-misc-info)))
    (setq-default global-mode-string
                  (delq indicator (default-value 'global-mode-string))))
  (remove-hook 'buffer-list-update-hook
               #'agent-shell-attention--maybe-clear-current)
  (remove-hook 'agent-shell-mode-hook
               #'agent-shell-attention--maybe-subscribe-current-buffer)
  (advice-remove #'agent-shell--send-command
                 #'agent-shell-attention--around-send-command)
  (maphash (lambda (buffer _)
             (agent-shell-attention--unsubscribe-buffer buffer))
           agent-shell-attention--subscriptions)
  (maphash (lambda (buffer _)
             (when (buffer-live-p buffer)
               (with-current-buffer buffer
                 (remove-hook 'kill-buffer-hook
                              #'agent-shell-attention--on-buffer-killed t))))
           agent-shell-attention--pending)
  (maphash (lambda (buffer _)
             (when (buffer-live-p buffer)
               (with-current-buffer buffer
                 (remove-hook 'kill-buffer-hook
                              #'agent-shell-attention--on-buffer-killed t))))
           agent-shell-attention--busy)
  (maphash (lambda (buffer _)
             (when (buffer-live-p buffer)
               (with-current-buffer buffer
                 (remove-hook 'kill-buffer-hook
                              #'agent-shell-attention--on-buffer-killed t))))
           agent-shell-attention--last-event)
  (clrhash agent-shell-attention--pending)
  (clrhash agent-shell-attention--busy)
  (clrhash agent-shell-attention--busy-since)
  (clrhash agent-shell-attention--last-event)
  (clrhash agent-shell-attention--subscriptions)
  (force-mode-line-update t)
  (agent-shell-attention--maybe-refresh-dashboard))

(defvar agent-shell-attention-mode-map
  (let ((map (make-sparse-keymap)))
    map)
  "Keymap used while `agent-shell-attention-mode' is active.")

;;;###autoload
(define-minor-mode agent-shell-attention-mode
  "Global notifications for agent-shell buffers.
When enabled, display a tally of agent shells needing user input and
emit minibuffer notifications whenever an agent hands back control."
  :global t
  :lighter nil
  :keymap agent-shell-attention-mode-map
  (if agent-shell-attention-mode
      (agent-shell-attention--enable)
    (agent-shell-attention--disable)))

(provide 'agent-shell-attention)

;;; agent-shell-attention.el ends here
