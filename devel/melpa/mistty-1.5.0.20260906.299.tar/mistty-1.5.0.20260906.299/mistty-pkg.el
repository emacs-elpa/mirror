;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "1.5.0.20260906.299"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "3eb6f168c260b5139fef89b84fa63ca853cb9aef"
  :revdesc "3eb6f168c260"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
