;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-raku" "1.0.2"
  "Provides raku support for org-babel."
  '((emacs "24.1"))
  :url "https://github.com/masukomi/ob-raku"
  :commit "21aa77a0ca70b7bef0ecf7d4d9c5272d71f0210c"
  :revdesc "v1.0.2-0-g21aa77a0ca70"
  :keywords '("literate programming" "reproducible research" "languages"))
