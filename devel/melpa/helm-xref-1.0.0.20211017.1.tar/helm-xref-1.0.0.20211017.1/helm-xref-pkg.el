;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-xref" "1.0.0.20211017.1"
  "Helm interface for xref results."
  '((emacs "25.1")
    (helm  "1.9.4"))
  :url "https://github.com/brotzeit/helm-xref"
  :commit "ea0e4ed8a9baf236e4085cbc7178241f109a53fa"
  :revdesc "ea0e4ed8a9ba"
  :authors '(("Fritz Stelzer" . "brotzeitmacher@gmail.com"))
  :maintainers '(("Fritz Stelzer" . "brotzeitmacher@gmail.com")))
