;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "muban" "0.1.0"
  "Lightweight template expansion tool."
  '((emacs "25"))
  :url "https://github.com/jiahaowork/muban.el"
  :commit "c134c46e60be1fb3e9a08dba3d07346855e0fcc2"
  :revdesc "c134c46e60be"
  :keywords '("abbrev" "tools")
  :authors '(("Jiahao Li" . "jiahaowork@gmail.com"))
  :maintainers '(("Jiahao Li" . "jiahaowork@gmail.com")))
