;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-patch-changelog" "0.1.0.0.20221209.69"
  "Generate a patch according to emacs-mirror/CONTRIBUTE."
  '((emacs "28.1")
    (magit "3.3.0"))
  :url "https://github.com/dickmao/magit-patch-changelog"
  :commit "fd259cf6ce270a21df2f00b1e031193c8595a7a9"
  :revdesc "fd259cf6ce27"
  :keywords '("git" "tools" "vc")
  :authors '(("dickmao" . "githubid:dickmao"))
  :maintainers '(("dickmao" . "githubid:dickmao")))
