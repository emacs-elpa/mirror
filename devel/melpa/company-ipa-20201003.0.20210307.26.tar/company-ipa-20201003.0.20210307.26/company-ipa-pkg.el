;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ipa" "20201003.0.20210307.26"
  "IPA backend for company."
  '((emacs   "24.3")
    (company "0.8.12"))
  :url "https://github.com/mguzmann/company-ipa"
  :commit "8634021cac885f53f3274ef6dcce7eab19321046"
  :revdesc "8634021cac88"
  :keywords '("convenience" "company" "ipa")
  :authors '(("Matías Guzmán Naranjo" . "mguzmann89@gmail.com"))
  :maintainers '(("Matías Guzmán Naranjo" . "mguzmann89@gmail.com")))
