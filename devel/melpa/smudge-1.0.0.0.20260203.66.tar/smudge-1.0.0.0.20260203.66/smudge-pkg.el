;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smudge" "1.0.0.0.20260203.66"
  "Control the Spotify app."
  '((emacs        "27.1")
    (simple-httpd "1.5.1")
    (request      "0.3")
    (oauth2       "0.18"))
  :url "https://github.com/danielfm/smudge"
  :commit "c90db830e84e34ac5724f57eda2f1112a589df5c"
  :revdesc "c90db830e84e"
  :keywords '("multimedia" "music" "spotify" "smudge"))
