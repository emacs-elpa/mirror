;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yoshi-theme" "7.0.0.0.20230801.1"
  "Theme named after my cat."
  ()
  :url "http://projects.ryuslash.org/yoshi-theme/"
  :commit "61e4250ae32744e5434c8faef7d059c7b157f81a"
  :revdesc "7.0.0-1-g61e4250ae327"
  :keywords '("faces")
  :authors '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainers '(("Tom Willemse" . "tom@ryuslash.org")))
