;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wandbox" "0.6.4"
  "Wandbox client."
  '((emacs   "24")
    (request "0.3.0")
    (s       "1.10.0"))
  :url "https://github.com/kosh04/emacs-wandbox"
  :commit "e002fe41f2cd9b4ce2b1dc80b83301176e9117f1"
  :revdesc "e002fe41f2cd"
  :keywords '("tools")
  :authors '(("KOBAYASHI Shigeru" . "shigeru.kb@gmail.com"))
  :maintainers '(("KOBAYASHI Shigeru" . "shigeru.kb@gmail.com")))
