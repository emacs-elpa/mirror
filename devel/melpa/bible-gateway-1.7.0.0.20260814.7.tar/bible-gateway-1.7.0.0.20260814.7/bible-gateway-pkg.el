;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "1.7.0.0.20260814.7"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "ee4e4b1ad727b42315baa392f66e6b3a906c5253"
  :revdesc "ee4e4b1ad727"
  :keywords '("convenience" "comm" "hypermedia"))
