;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-chicken" "0.17.0.20261106.12"
  "Chicken's implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.19"))
  :url "https://gitlab.com/emacs-geiser/chicken"
  :commit "b019678711ef29a06a049ec7f80598c24cc74a51"
  :revdesc "b019678711ef"
  :keywords '("languages" "chicken" "scheme" "geiser"))
