;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-sections" "0.3.0.0.20260120.1"
  "Universal Sidecar Sections for Denote."
  '((universal-sidecar "1.5.0")
    (denote            "2.2.4")
    (emacs             "27.1"))
  :url "https://git.sr.ht/~swflint/denote-sections"
  :commit "dde6836a4663cb3fc23cdce8ea25834720711c8a"
  :revdesc "dde6836a4663"
  :keywords '("convenience" "files" "notes" "hypermedia")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
