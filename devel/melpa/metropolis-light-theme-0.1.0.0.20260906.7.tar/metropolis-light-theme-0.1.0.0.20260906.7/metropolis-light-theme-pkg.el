;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metropolis-light-theme" "0.1.0.0.20260906.7"
  "Light theme based on the Metropolis Beamer palette."
  '((emacs "25.1"))
  :url "https://github.com/bitorhugo/metropolis-light-theme"
  :commit "e55ac1ae7d25ebff77d22cd432e1d1ebaafa1a84"
  :revdesc "e55ac1ae7d25"
  :keywords '("faces" "theme")
  :authors '((nil . "VítorSantosvhsoo@proton.me"))
  :maintainers '((nil . "VítorSantosvhsoo@proton.me")))
