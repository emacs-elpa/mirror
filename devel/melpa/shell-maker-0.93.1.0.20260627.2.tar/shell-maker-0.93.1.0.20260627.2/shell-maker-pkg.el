;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "0.93.1.0.20260627.2"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "55c383ca542efbb79abd9cb3d6bbd3ab0d92f5d9"
  :revdesc "55c383ca542e")
