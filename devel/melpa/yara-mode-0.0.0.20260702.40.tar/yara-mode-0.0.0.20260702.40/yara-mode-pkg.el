;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yara-mode" "0.0.0.20260702.40"
  "Major mode for editing yara rule file."
  '((emacs "24"))
  :url "not distributed yet"
  :commit "2b097f685e2770d2c16e5f59e1434a8dcc38db86"
  :revdesc "2b097f685e27"
  :keywords '("yara")
  :authors '((nil . "binjo.cn@gmail.com"))
  :maintainers '((nil . "binjo.cn@gmail.com")))
