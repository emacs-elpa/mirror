;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-ring" "0.1.0.20250915.2"
  "Structured and configurable repetition."
  '((emacs        "25.1")
    (virtual-ring "0.1")
    (pubsub       "0.1")
    (mantra       "0.1"))
  :url "https://github.com/countvajhula/repeat-ring"
  :commit "04c128149e50827134ecd8e5a5176cd889469175"
  :revdesc "v0.1-2-g04c128149e50"
  :authors '(("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
