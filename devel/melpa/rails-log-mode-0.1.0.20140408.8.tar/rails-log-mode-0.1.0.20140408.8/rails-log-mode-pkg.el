;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rails-log-mode" "0.1.0.20140408.8"
  "Major mode for viewing Rails log files."
  ()
  :url "https://github.com/ananthakumaran/rails-log-mode"
  :commit "ff440003ad7d47cb0ac3300f2a632f4cfd36a446"
  :revdesc "ff440003ad7d"
  :keywords '("rails" "log")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
