;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-w32-launcher" "0.1.6.0.20141223.3"
  "Start Menu entry launcher using Helm."
  '((emacs  "24")
    (helm   "1.6.5")
    (cl-lib "0.5"))
  :url "https://github.com/Fanael/helm-w32-launcher"
  :commit "3e59ad62b89dd21d334af0203d445a83eb25dc5b"
  :revdesc "3e59ad62b89d"
  :authors '(("Fanael Linithien" . "fanael4@gmail.com"))
  :maintainers '(("Fanael Linithien" . "fanael4@gmail.com")))
