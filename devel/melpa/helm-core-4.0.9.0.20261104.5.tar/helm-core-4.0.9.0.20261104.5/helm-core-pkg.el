;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "4.0.9.0.20261104.5"
  "Development files for Helm."
  '((emacs "25.1")
    (async "2.0"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "f4cef9b68dede2574e4b2f31839c4c586ac60bf9"
  :revdesc "v4.0.9-5-gf4cef9b68ded"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
