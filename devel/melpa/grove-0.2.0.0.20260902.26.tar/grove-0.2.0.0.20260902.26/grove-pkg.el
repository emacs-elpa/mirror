;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grove" "0.2.0.0.20260902.26"
  "Obsidian-like Org and Markdown notes."
  '((emacs "29.1"))
  :url "https://github.com/jonathanchu/grove"
  :commit "4511677ba96cc3b424197dd4d4d35dd535583751"
  :revdesc "4511677ba96c"
  :keywords '("notes" "outlines" "tools")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
