;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.41.0.0.20260703.1"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5eea3b6473924dccdc8fafc2c4386022629fa7c2"
  :revdesc "5eea3b647392"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
