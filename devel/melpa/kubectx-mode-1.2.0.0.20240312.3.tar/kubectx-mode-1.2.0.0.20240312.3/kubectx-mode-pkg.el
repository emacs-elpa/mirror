;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubectx-mode" "1.2.0.0.20240312.3"
  "Change kubectl context/namespace and show in mode line."
  '((emacs "24"))
  :url "https://github.com/terjesannum/emacs-kubectx-mode"
  :commit "b177c0fa9f8471d6199df4598afde1e39e83c504"
  :revdesc "b177c0fa9f84"
  :keywords '("tools" "kubernetes")
  :authors '(("Terje Sannum" . "terje@offpiste.org"))
  :maintainers '(("Terje Sannum" . "terje@offpiste.org")))
