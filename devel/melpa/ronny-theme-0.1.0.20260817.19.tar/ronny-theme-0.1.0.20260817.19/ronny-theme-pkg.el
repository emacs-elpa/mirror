;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ronny-theme" "0.1.0.20260817.19"
  "A dark colorscheme inspired by Monokai."
  '((emacs "27"))
  :url "https://github.com/judaew/ronny.el"
  :commit "e1e499b829907cc7d8ccec18b8a9f06be043800b"
  :revdesc "e1e499b82990"
  :authors '(("Vadym-Valdis Yudaiev" . "judaew@outlook.com"))
  :maintainers '(("Vadym-Valdis Yudaiev" . "judaew@outlook.com")))
