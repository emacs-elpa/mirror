;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-lib" "0.1.0.20211206.2"
  "Basic functions for Apple/OSX."
  '((emacs "24.4"))
  :url "https://github.com/raghavgautam/osx-lib"
  :commit "7afdb57edd5725e8a66f841a90fa571a4cbb81e7"
  :revdesc "7afdb57edd57"
  :keywords '("apple" "applescript" "osx" "finder" "emacs" "elisp" "vpn" "speech")
  :authors '(("Raghav Kumar Gautam" . "raghav@apache.org"))
  :maintainers '(("Raghav Kumar Gautam" . "raghav@apache.org")))
