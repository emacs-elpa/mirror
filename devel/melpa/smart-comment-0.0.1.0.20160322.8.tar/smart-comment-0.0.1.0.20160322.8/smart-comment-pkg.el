;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smart-comment" "0.0.1.0.20160322.8"
  "Smarter commenting."
  ()
  :url "https://github.com/paldepind/smart-comment"
  :commit "ad4e0de29115dc010733b9060d3dab02836b15e1"
  :revdesc "ad4e0de29115"
  :keywords '("lisp")
  :authors '(("Simon Friis Vindum" . "simon@vindum.io"))
  :maintainers '(("Simon Friis Vindum" . "simon@vindum.io")))
