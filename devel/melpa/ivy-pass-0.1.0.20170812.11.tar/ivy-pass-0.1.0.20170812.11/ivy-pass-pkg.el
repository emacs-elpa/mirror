;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-pass" "0.1.0.20170812.11"
  "Ivy interface for pass."
  '((emacs          "24")
    (ivy            "0.8.0")
    (password-store "1.6.5"))
  :url "https://github.com/ecraven/ivy-pass/"
  :commit "5b523de1151f2109fdd6a8114d0af12eef83d3c5"
  :revdesc "5b523de1151f"
  :keywords '("pass" "password" "convenience" "data"))
