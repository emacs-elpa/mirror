;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-rsync" "0.7.0.20260716.11"
  "Allow rsync from dired buffers."
  '((s     "1.12.0")
    (dash  "2.0.0")
    (emacs "25.1"))
  :url "https://github.com/stsquad/dired-rsync"
  :commit "eecf700ce70b282040b87ccdb76ff4195bdba919"
  :revdesc "eecf700ce70b"
  :authors '(("Alex Bennée" . "alex@bennee.com"))
  :maintainers '(("Alex Bennée" . "alex@bennee.com")))
