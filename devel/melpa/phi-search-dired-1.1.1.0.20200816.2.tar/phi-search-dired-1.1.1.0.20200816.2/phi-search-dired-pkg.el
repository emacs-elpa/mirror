;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-search-dired" "1.1.1.0.20200816.2"
  "Interactive filtering for dired powered by phi-search."
  '((phi-search "2.2.0"))
  :url "http://hins11.yu-yake.com/"
  :commit "f014a9fb0b6a94af2df0e22f91ef79ce6996afd7"
  :revdesc "f014a9fb0b6a")
