;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-results" "1.0.6.0.20240108.1"
  "Filter ERT test results display."
  '((emacs "24.1"))
  :url "https://github.com/rswgnu/ert-results"
  :commit "32200a195f68c25a013497329d85ae0703ab475d"
  :revdesc "32200a195f68"
  :keywords '("lisp" "maint" "tools")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
