;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "2.32.0.20260730.58"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "957f61d8b8b57c1f463b56620a274eb77a09bc16"
  :revdesc "957f61d8b8b5"
  :keywords '("languages" "lisp" "slime"))
