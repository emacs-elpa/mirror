;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-x" "0.3.1.0.20260728.14"
  "Extra convenience features for project.el."
  '((emacs "28.1"))
  :url "https://github.com/vmargb/project-x"
  :commit "fbea13f33f820c6294927fcff32dbb6a2b5b9849"
  :revdesc "fbea13f33f82"
  :keywords '("project" "convenience" "session" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("vmargb" . "https://github.com/vmargb")))
