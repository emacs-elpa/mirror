;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.5.0.0.20260703.1"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "f4e2ea6beef43a7ca9d2bfd4d70b68d372a3e2a0"
  :revdesc "f4e2ea6beef4"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
