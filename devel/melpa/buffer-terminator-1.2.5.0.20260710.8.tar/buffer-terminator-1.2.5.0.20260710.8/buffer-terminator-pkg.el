;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "1.2.5.0.20260710.8"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "728310cdb8c266153ddd11e04290f8b61d316412"
  :revdesc "1.2.5-8-g728310cdb8c2"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
