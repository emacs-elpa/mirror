;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "1.0.5.0.20260920.89"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "e3691987ec8cfecb87168cb0d6205367a64ec28f"
  :revdesc "cfn-mode/v1.0.5-89-ge3691987ec8c"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
