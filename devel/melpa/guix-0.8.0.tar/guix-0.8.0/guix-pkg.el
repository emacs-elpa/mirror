;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "0.8.0"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3")
    (consult       "3.5"))
  :url "https://codeberg.org/guix/emacs-guix"
  :commit "d00f4ea96306cced45f9536ee200cfc4244f71e9"
  :revdesc "v0.8.0-0-gd00f4ea96306"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
