;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.940.0.20260825.10"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e9d19814be477e5bb27798a0d14ef8b653a6c38d"
  :revdesc "e9d19814be47"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
