;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "filetags" "0.0.1.0.20190706.61"
  "Package to manage filetags in filename."
  '((emacs "24.4"))
  :url "https://github.com/DerBeutlin/filetags.el"
  :commit "71667a819e46eb1f6e30e2fa61321acb7c6ccb3d"
  :revdesc "71667a819e46"
  :keywords '("convenience" "files"))
