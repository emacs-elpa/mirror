;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.7.0.0.20260922.9"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "5b52ee86071a1b751d9228eff8be6bc807049917"
  :revdesc "5b52ee86071a"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
