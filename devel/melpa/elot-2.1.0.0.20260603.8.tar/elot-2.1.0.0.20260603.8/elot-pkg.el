;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elot" "2.1.0.0.20260603.8"
  "Emacs Literate Ontology Tool (ELOT)."
  '((emacs "30.1"))
  :url "https://github.com/johanwk/elot"
  :commit "aa2e0b60307ab1d06622281a9c69411b55a442b3"
  :revdesc "v2.1.0-8-gaa2e0b60307a"
  :keywords '("languages" "outlines" "tools" "org" "ontology")
  :authors '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com"))
  :maintainers '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com")))
