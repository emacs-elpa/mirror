;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.4.0.0.20260902.19"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "d8e76e7ccc784ab0441caab04fcf36aba73f5bdb"
  :revdesc "v1.4.0-19-gd8e76e7ccc78"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
