;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-html5slide" "0.1.0.20221025.5"
  "Export org-mode to HTML5 slide."
  '((org "8.0"))
  :url "https://github.com/coldnew/org-html5slide"
  :commit "4e0d9026c96e1dde22cca7c700669f1f863a9d07"
  :revdesc "4e0d9026c96e"
  :keywords '("html" "presentation")
  :authors '(("coldnew" . "coldnew.tw@gmail.com"))
  :maintainers '(("coldnew" . "coldnew.tw@gmail.com")))
