;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beluga-mode" "0.0.0.20250930.5088"
  "Major mode for Beluga source code."
  '((emacs "24.4"))
  :url "https://github.com/Beluga-lang/Beluga"
  :commit "820615cc4758086eb7641f62340a3ab93a689303"
  :revdesc "820615cc4758"
  :keywords '("languages")
  :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainers '((nil . "beluga-dev@cs.mcgill.ca")))
