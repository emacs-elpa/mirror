;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "2.13.0.20260824.6"
  "An Org-social client."
  '((emacs            "30.1")
    (org              "9.0")
    (request          "0.3.0")
    (seq              "2.20")
    (emojify          "1.2")
    (async-http-queue "0.1"))
  :url "https://git.andros.dev/org-social/org-social.el"
  :commit "f5141de306ce402b3f148dd96b46e7d329d2568b"
  :revdesc "f5141de306ce"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
