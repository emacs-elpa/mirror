;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-icon" "0.5"
  "A minor mode to display a list of associated icons in dired buffers."
  '((emacs "24.3"))
  :url "https://gitlab.com/xuhdev/dired-icon"
  :commit "dbace8d2250f84487d31b39050fcdc260fcde804"
  :revdesc "dbace8d2250f"
  :keywords '("dired" "files")
  :authors '(("Hong Xu" . "hong@topbug.net"))
  :maintainers '(("Hong Xu" . "hong@topbug.net")))
