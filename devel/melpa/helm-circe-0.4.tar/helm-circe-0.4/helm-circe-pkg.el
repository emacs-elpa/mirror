;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-circe" "0.4"
  "Helm circe buffer management."
  '((emacs  "24")
    (helm   "0.0")
    (circe  "0.0")
    (cl-lib "0.5"))
  :url "https://github.com/lesharris/helm-circe"
  :commit "9091651d9fdd8d49d8ff6f9dcf3a2ae416c9f15a"
  :revdesc "v0.4-0-g9091651d9fdd"
  :keywords '("helm" "circe")
  :authors '(("Les Harris" . "les@lesharris.com"))
  :maintainers '(("Les Harris" . "les@lesharris.com")))
