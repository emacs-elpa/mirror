;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "2.13.0.20260828.20"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "a7425c2865d2dbc36d8a12e09695b278b0142637"
  :revdesc "2.13-20-ga7425c2865d2"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
