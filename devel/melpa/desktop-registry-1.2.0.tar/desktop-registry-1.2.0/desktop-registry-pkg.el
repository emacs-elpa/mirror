;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "desktop-registry" "1.2.0"
  "Keep a central registry of desktop files."
  ()
  :url "http://projects.ryuslash.org/desktop-registry/"
  :commit "244c2e7f9f0a1050aa8a47ad0b38f4e4584682dd"
  :revdesc "1.2.0-0-g244c2e7f9f0a"
  :keywords '("convenience")
  :authors '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainers '(("Tom Willemse" . "tom@ryuslash.org")))
