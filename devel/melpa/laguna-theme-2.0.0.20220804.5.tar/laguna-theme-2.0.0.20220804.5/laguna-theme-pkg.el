;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "laguna-theme" "2.0.0.20220804.5"
  "An updated blue-green Laguna Theme."
  ()
  :url "https://github.com/HenryNewcomer/laguna-theme"
  :commit "680ab8c936cb1c249b5a6a07976bcc83ef217e25"
  :revdesc "680ab8c936cb"
  :authors '(("Henry Newcomer" . "a.cliche.email@gmail.com"))
  :maintainers '(("Henry Newcomer" . "a.cliche.email@gmail.com")))
