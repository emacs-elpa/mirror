;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0.0.20260711.32"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.1"))
  :url "https://github.com/jojojames/fzfa"
  :commit "3c1742e56fba99c80f7fc18ac0165a03e030ea84"
  :revdesc "3c1742e56fba"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
