;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "locs-and-refs" "0.20"
  "Define locations and references for files and buffers."
  '((emacs   "27.1")
    (pcre2el "1.11"))
  :url "https://github.com/phf-1/locs-and-refs"
  :commit "5c3f0e04ea6cc4728219dfd716d95c7d044b8030"
  :revdesc "5c3f0e04ea6c"
  :authors '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com"))
  :maintainers '(("Pierre-Henry FRÖHRING" . "contact@phfrohring.com")))
