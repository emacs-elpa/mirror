;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ipe" "1.1.0.20241229.21"
  "Insert, Update and Delete PAIRs using overlays."
  '((emacs "24.4"))
  :url "https://github.com/BriansEmacs/insert-pair-edit.el"
  :commit "5701e598a0d115a4f0261c82320d180e6be3045e"
  :revdesc "5701e598a0d1"
  :keywords '("convenience" "tools")
  :authors '(("Brian Kavanagh" . "brians.emacs@gmail.com"))
  :maintainers '(("Brian Kavanagh" . "brians.emacs@gmail.com")))
