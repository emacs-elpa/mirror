;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "4.2.1.0.20260917.123"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "e37206704d53f467f4994ea7293d3bb34317427e"
  :revdesc "e37206704d53"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
