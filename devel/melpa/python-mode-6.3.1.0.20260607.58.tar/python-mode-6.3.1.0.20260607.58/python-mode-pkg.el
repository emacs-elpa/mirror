;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "6.3.1.0.20260607.58"
  "Edit, debug, develop, run Python programs."
  '((emacs "24"))
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "4e2edae21655cf5d0559b1d7df23057ade20272c"
  :revdesc "6.3.1-58-g4e2edae21655"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
