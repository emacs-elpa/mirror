;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yarn-mode" "1.0.0.20200208.9"
  "Major mode for yarn.lock files."
  '((emacs "24.3"))
  :url "https://github.com/anachronic/yarn-mode"
  :commit "8239d4dc7d8a52fa1e3fa81bd32c904a359fcfc1"
  :revdesc "v1.0-9-g8239d4dc7d8a"
  :keywords '("convenience")
  :authors '(("Nicolás Salas V." . "nikosalas@gmail.com"))
  :maintainers '(("Nicolás Salas V." . "nikosalas@gmail.com")))
