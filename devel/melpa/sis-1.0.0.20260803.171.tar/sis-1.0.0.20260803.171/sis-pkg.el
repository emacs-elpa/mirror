;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "1.0.0.20260803.171"
  "Minimize manual input source (input method) switching."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "a2c9010d3c1cc282ce364dcafcd9b6c4ac45a643"
  :revdesc "a2c9010d3c1c"
  :keywords '("convenience"))
