;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "2.1.1"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "b3c19403378f9b465302274fb6dda71243c4cfce"
  :revdesc "b3c19403378f"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
