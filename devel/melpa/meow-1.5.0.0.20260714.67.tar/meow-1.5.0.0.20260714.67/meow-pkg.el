;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "1.5.0.0.20260714.67"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://www.github.com/DogLooksGood/meow"
  :commit "aa8aec19e70369b547176e625f5b95c4a8565e8e"
  :revdesc "aa8aec19e703"
  :keywords '("convenience" "modal-editing"))
