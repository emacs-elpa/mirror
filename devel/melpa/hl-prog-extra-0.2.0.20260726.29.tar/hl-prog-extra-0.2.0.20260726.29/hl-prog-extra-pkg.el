;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-prog-extra" "0.2.0.20260726.29"
  "Customizable highlighting for source-code."
  '((emacs "26.2"))
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra"
  :commit "c459329bd5f535575d12f386e1c55ca539a26b0b"
  :revdesc "c459329bd5f5"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
