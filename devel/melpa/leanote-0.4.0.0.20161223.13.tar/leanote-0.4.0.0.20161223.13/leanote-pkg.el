;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leanote" "0.4.0.0.20161223.13"
  "A minor mode writing markdown leanote."
  '((emacs     "24.4")
    (cl-lib    "0.5")
    (request   "0.2")
    (let-alist "1.0.3")
    (pcache    "0.4.0")
    (s         "1.10.0")
    (async     "1.9"))
  :url "https://github.com/aborn/leanote-emacs"
  :commit "d499e7b59bb1f1a2fabc0e4c26fb101ed62ebc7b"
  :revdesc "d499e7b59bb1"
  :keywords '("leanote" "note" "markdown")
  :authors '(("Aborn Jiang" . "aborn.jiang@gmail.com"))
  :maintainers '(("Aborn Jiang" . "aborn.jiang@gmail.com")))
