;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "1.0.5.0.20261103.1"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "b43005dc735c65bf0e09805a35e06c43b384ac22"
  :revdesc "1.0.5-1-gb43005dc735c"
  :keywords '("tools" "processes" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
