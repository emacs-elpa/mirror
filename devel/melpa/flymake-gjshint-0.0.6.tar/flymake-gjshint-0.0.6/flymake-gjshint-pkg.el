;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-gjshint" "0.0.6"
  "A flymake handler for javascript using both jshint and gjslint."
  ()
  :url "https://github.com/yasuyk/flymake-gjshint-el"
  :commit "71495ee5303de18293decd57ab9f9abdbaabfa05"
  :revdesc "0.0.6-0-g71495ee5303d"
  :keywords '("flymake" "javascript" "jshint" "gjslint")
  :authors '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
