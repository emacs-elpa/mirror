;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rmsbolt" "0.1.2.0.20250325.86"
  "A compiler output viewer."
  '((emacs "25.1"))
  :url "https://gitlab.com/jgkamat/rmsbolt"
  :commit "05c4795226f859009bc570940139473b6b6f7555"
  :revdesc "05c4795226f8"
  :keywords '("compilation" "tools")
  :authors '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainers '(("Jay Kamat" . "jaygkamat@gmail.com")))
