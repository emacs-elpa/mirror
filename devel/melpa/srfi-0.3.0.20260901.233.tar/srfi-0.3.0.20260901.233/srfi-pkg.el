;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "0.3.0.20260901.233"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "1adee01451c17dca7e4a670d8a426efde8b276c4"
  :revdesc "0.3-233-g1adee01451c1"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
