;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "totd" "0.0.0.20150519.6"
  "Display a random daily emacs command."
  '((s      "1.9.0")
    (cl-lib "0.5"))
  :url "https://gitlab.com/egh/emacs-totd"
  :commit "a715f7f2df416b8a6c827a9493ce7004180a3a4f"
  :revdesc "a715f7f2df41"
  :keywords '("help")
  :authors '(("Erik Hetzner" . "egh@e6h.org"))
  :maintainers '(("Erik Hetzner" . "egh@e6h.org")))
