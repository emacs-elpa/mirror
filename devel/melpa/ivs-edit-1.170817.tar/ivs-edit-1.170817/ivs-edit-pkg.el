;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivs-edit" "1.170817"
  "IVS (Ideographic Variation Sequence) editing tool."
  '((emacs  "24.3")
    (dash   "2.6.0")
    (cl-lib "1.0"))
  :url "https://github.com/kawabata/ivs-edit"
  :commit "5db39c234aa7393b591168a4fd0a9a4cbbca347d"
  :revdesc "5db39c234aa7"
  :keywords '("text")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
