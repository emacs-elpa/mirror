;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-ghcmod" "0.0.0.20150114.5"
  "A flycheck checker for Haskell using ghcmod."
  '((flycheck "0.21-cvs1")
    (dash     "2.0"))
  :url "https://github.com/scturtle/flycheck-ghcmod"
  :commit "6bb7b7d879f05bbae54e99eb04806c877adf3ccc"
  :revdesc "6bb7b7d879f0"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Shen Chao" . "scturtle@gmail.com"))
  :maintainers '(("Shen Chao" . "scturtle@gmail.com")))
