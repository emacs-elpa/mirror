;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "0.3.2.0.20260805.9"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "4d82b4ee9f837d449c6e13852477c261e91dad02"
  :revdesc "4d82b4ee9f83"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
