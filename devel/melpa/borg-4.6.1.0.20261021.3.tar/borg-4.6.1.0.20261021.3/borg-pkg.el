;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.6.1.0.20261021.3"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "52513cfbe79cb8c4e5ef2ef61e9f4aa47ce56a1f"
  :revdesc "v4.6.1-3-g52513cfbe79c"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
