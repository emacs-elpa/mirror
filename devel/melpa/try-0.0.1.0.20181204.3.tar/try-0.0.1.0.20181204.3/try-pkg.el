;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "try" "0.0.1.0.20181204.3"
  "Try out Emacs packages."
  '((emacs "24"))
  :url "https://github.com/larstvei/try"
  :commit "8831ded1784df43a2bd56c25ad3d0650cdb9df1d"
  :revdesc "8831ded1784d"
  :keywords '("packages")
  :authors '(("Lars Tveito" . "larstvei@ifi.uio.no"))
  :maintainers '(("Lars Tveito" . "larstvei@ifi.uio.no")))
