;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-embark" "1.4.0.0.20251027.17"
  "Citar/Embark integration."
  '((emacs  "27.1")
    (embark "0.17")
    (citar  "0.9.7"))
  :url "https://github.com/emacs-citar/citar"
  :commit "a71ec7c3f02e8d4051fb608d9c4918de5a8ba4e6"
  :revdesc "v1.4.0-17-ga71ec7c3f02e"
  :keywords '("bib" "extensions")
  :authors '(("Bruce D'Arcus" . "bdarcus@gmail.com"))
  :maintainers '(("Bruce D'Arcus" . "bdarcus@gmail.com")))
