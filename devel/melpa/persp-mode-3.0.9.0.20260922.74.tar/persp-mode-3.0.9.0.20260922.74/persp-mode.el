;;; persp-mode.el --- windows/buffers sets shared among frames + save/load. -*- lexical-binding: t; -*-

;; Copyright (C) 2012 Constantin Kulikov

;; Author: Constantin Kulikov (Bad_ptr) <zxnotdead@gmail.com>
;; Package-Version: 3.0.9.0.20260922.74
;; Package-Revision: 703f3b5ad502
;; Package-Requires: ((emacs "24.3"))
;; Keywords: perspectives, session, workspace, persistence, windows, buffers, convenience
;; URL: https://github.com/Bad-ptr/persp-mode.el

;;; License:

;; This file is not part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 2, or (at your option)
;; any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program; if not, write to the Free Software
;; Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

;;; Commentary:

;; Based on the perspective.el by Natalie Weizenbaum
;;  (http://github.com/nex3/perspective-el) but the perspectives are shared
;;   among the frames and could be saved/restored from/to a file.
;;
;; Homepage: https://github.com/Bad-ptr/persp-mode.el

;; Installation:

;; From the MELPA: M-x package-install RET persp-mode RET
;; From a file: M-x package-install-file RET 'path to this file' RET
;; Or put this file into your load-path.

;; Configuration:

;; When installed through the package-install:
;; (with-eval-after-load "persp-mode-autoloads"
;;   (setq wg-morph-on nil)
;;   ;; switch off the animation of restoring window configuration
;;   (setq persp-autokill-buffer-on-remove 'kill-weak)
;;   (add-hook 'after-init-hook (lambda () (persp-mode 1))))

;; When installed without generating an autoloads file:
;; (with-eval-after-load "persp-mode"
;;   ;; .. all settings you want here
;;   (add-hook 'after-init-hook (lambda () (persp-mode 1))))
;; (require 'persp-mode)

;; Dependencies:

;; The ability to save/restore window configurations from/to a file
;;  depends on the workgroups.el(https://github.com/tlh/workgroups.el)
;;   for the emacs versions < 24.4

;; Customization:

;; M-x: customize-group RET persp-mode RET

;; You can read more in README.md


;;; Code:



;; Prerequirements:

(defvar persp-mode-version nil)

(when (featurep 'persp-mode)
  (let* ((pkgs (cdr (assq 'persp-mode package-alist)))
         (cv (and pkgs (package-desc-version (car pkgs))))
         (pv (bound-and-true-p persp-mode-version)))
    (when (and (not (bound-and-true-p persp-skip-new-version-install-guard))
               (not (and cv pv (version-list-= cv pv))))
      (when cv
        (let ((tv (condition-case err
                      (version-to-list (package-get-version))
                    (error nil))))
          (when tv
            (dolist (pkgdsc pkgs)
              (unless (version-list-= tv (package-desc-version pkgdsc))
                ;;(when (string= "obsolete" (package-desc-status pkgdsc))
                (ignore-errors
                  (package-delete pkgdsc)))))))
      (error (message "[persp-mode] Warning: New version will be loaded on Emacs restart.")))))

(setq persp-mode-version (eval-when-compile (version-to-list (package-get-version))))

(require 'cl-lib)
(require 'gv)
(require 'easymenu)

(declare-function golden-ratio-mode "ext:golden-ratio")
(declare-function tabbar-buffer-list "ext:tabbar-mode")

(declare-function tramp-dissect-file-name "tramp")
(declare-function tramp-file-name-hop "tramp")
(declare-function tramp-file-name-host "tramp")
(declare-function tramp-file-name-port "tramp")
(declare-function tramp-file-name-localname "tramp")
(declare-function tramp-file-name-method "tramp")
(declare-function tramp-file-name-user "tramp")
(declare-function tramp-tramp-file-p "tramp")

(defvar tramp-prefix-format)
(defvar tramp-postfix-method-format)
(defvar tramp-postfix-user-format)
(defvar tramp-prefix-port-format)
(defvar tramp-postfix-hop-format)
(defvar tramp-postfix-host-format)

(declare-function wg-restore-wconfig "ext:workgroups")
(declare-function wg-make-wconfig "ext:workgroups")
(declare-function wg-awhen "ext:workgroups")
(declare-function wg-abind "ext:workgroups" (alist binds &rest body))

(defvar ido-cur-item)
(defvar ido-exit)
(defvar ido-temp-list)
(defvar ido-text)
(defvar ido-text-init)

(defvar tabbar-buffer-list-function)

(defvar window-restore-killed-buffer-windows)

(defvar persp-mode nil)
(defvar persp-key-map nil)
(defvar persp-nil-persp)




;; Global variables:

(defvar *persp-pretend-switched-off* nil
  "This intended for rebinding in let blocks to temporary pretend
that persp-mode is switched off to minimize effects on Emacs and persp-mode
global state.
But be warned that setting this to `t' along is not sufficient to supress all
side effects.")

;; check if the initial-buffer-choice may be a function (emacs >= 24.4)
(defvar persp-is-ibc-as-f-supported
  (or
   (not (version< emacs-version "24.4"))
   (not
    (null
     (assq 'function
           (cdr (cl-getf (symbol-plist 'initial-buffer-choice) 'custom-type))))))
  "t if the `initial-buffer-choice' as a function is supported in your emacs,
otherwise nil.")

(defvar persp-minor-mode-menu nil
  "Menu for the persp-mode.")

(defvar *persp-hash* nil
  "The hash table that contain perspectives.")

(defvar persp-names-cache (when *persp-hash* (persp-names))
  "List of perspective names.
Used by the `persp-read-persp' and other UI functions, so it can be used
to alter the order of perspective names present to user. To achieve that
you must add functions to `persp-created-functions', `persp-renamed-functions',
`persp-before-kill-functions', `persp-before-switch-functions' and
`persp-after-load-state-functions' or just set the
`persp-names-sort-before-read-function'.
You must update `persp-names-cache' with `persp-update-names-cache'")

(defvar persp-temporarily-display-buffer nil
  "This variable dynamically bound to t inside
the `persp-temporarily-display-buffer'.")

(defvar persp-saved-read-buffer-function read-buffer-function
  "Save the `read-buffer-function' to restore it on deactivation.")

(defvar persp-special-last-buffer nil
  "Special variable to handle the case when new frames are switching
the selected window to a wrong buffer.")

(defvar persp-frame-buffer-predicate nil
  "Current buffer-predicate.")

(defvar persp-frame-buffer-predicate-buffer-list-cache nil
  "Variable to cache the perspective buffer list for buffer-predicate.")

(defvar persp-frame-server-switch-hook nil
  "Current persp-server-switch-hook.")

(defvar persp-disable-buffer-restriction-once nil
  "The flag used for toggling buffer filtering during read-buffer.")

(defvar persp-inhibit-switch-for nil
  "List of frames/windows for which the switching of perspectives is inhibited.")

(defvar persp-read-multiple-exit-minibuffer-function #'exit-minibuffer
  "Function to call to exit minibuffer when reading multiple candidates.")

(defvar persp-buffer-props-hash (when persp-mode
                                  (make-hash-table :test #'eq :size 10))
  "Cache to store buffer properties.")


(defvar persp-backtrace-frame-function
  (if (version< emacs-version "24.4")
      (lambda (nframes &optional base)
        (let ((i (if base
                     (let ((k 8) found bt)
                       (while (and (not found)
                                   (setq bt (cadr (funcall #'backtrace-frame
                                                           (cl-incf k)))))
                         ;; (message "%s:%s" k (backtrace-frame k))
                         (when (eq bt base) (setq found t)))
                       (when found (+ nframes (- k 3))))
                   (+ nframes 6))))
          (when i
            (funcall #'backtrace-frame i))))
    #'backtrace-frame)
  "Backtrace function with base argument.")


(defconst persp-not-persp :nil
  "Something that is not a perspective.")

(unless (fboundp 'condition-case-unless-debug)
  (defalias 'condition-case-unless-debug 'condition-case-no-debug))
(unless (fboundp 'read-multiple-choice)
  (defun read-multiple-choice (prompt choices)
    (let ((choice-chars (mapcar #'car choices)))
      (when choice-chars
        (assq (read-char-choice
               (format "%s(%s): "
                       (substring prompt 0 (string-match ": $" prompt))
                       (mapconcat (lambda (ch)
                                    (format "[%c] - %s" (car ch) (cadr ch)))
                                  choices "; "))
               choice-chars)
              choices)))))
(unless (fboundp 'alist-get)
  (defun alist-get (key alist &optional default remove)
    (ignore remove) ;;Silence byte-compiler.
    (let ((x (assq key alist)))
      (if x (cdr x) default))))



;; Customization variables:

(unless
    (memq 'custom-group (symbol-plist 'session))
  (defgroup session nil
    "Emacs' state(opened files, buffers, windows, etc.)"
    :group 'environment))

(defgroup persp-mode nil
  "Customization of the `persp-mode'."
  :prefix "persp-"
  :group 'session
  :link '(url-link
          :tag "Github page" "https://github.com/Bad-ptr/persp-mode.el"))

(defcustom persp-nil-name "none"
  "Name for the nil perspective."
  :group 'persp-mode
  :type 'string
  :set (lambda (sym val)
         (when val
           (if (and persp-mode (fboundp 'persp--rename))
               (if (persp--rename val (persp-get-by-name persp-nil-name *persp-hash*
                                                         persp-nil-persp))
                   (custom-set-default sym val)
                 (message "[persp-mode] Warning: failed to set persp-nil-name."))
             (custom-set-default sym val)))))

(defvar persp-last-persp-name persp-nil-name
  "The last activated perspective. New frames will be created with
that perspective if `persp-set-last-persp-for-new-frames' is t.")

(defface persp-face-lighter-buffer-not-in-persp
  '((default . (:background "#F00" :foreground "#00F" :weight bold)))
  "Face for the lighter when the current buffer is not in a perspective."
  :group 'persp-mode)
(defface persp-face-lighter-nil-persp
  '((t :inherit bold-italic))
  "Face for the lighter when the current perspective is nil."
  :group 'persp-mode)
(defface persp-face-lighter-default
  '((t :inherit italic))
  "Default face for the lighter.")

(defcustom persp-lighter
  '(:eval (or (frame-parameter (selected-frame) 'persp-lighter)
              " #~"))
  "Defines how the persp-mode show itself in the modeline."
  :group 'persp-mode
  :type 'sexp)

(defcustom persp-save-dir (expand-file-name "persp-confs/" user-emacs-directory)
  "The directory to/from where perspectives saved/loaded by default.
Autosave files are saved and loaded to/from this directory."
  :group 'persp-mode
  :type 'directory)

(defcustom persp-auto-save-fname "persp-auto-save"
  "Name of the file for auto save/load perspectives on the persp-mode
deactivation or the emacs shutdown."
  :group 'persp-mode
  :type 'string)

(defcustom persp-auto-save-persps-to-their-file t
  "If t -- then a perspective will be autosaved to a file specified
in the `persp-file' perspective parameter."
  :group 'persp-mode
  :type 'boolean)

(defcustom persp-auto-save-persps-to-their-file-before-kill nil
  "Whether or not perspectives will be saved before killed."
  :group 'persp-mode
  :type '(choice
          (const :tag "Save perspectives which have `persp-file' parameter"
                 :value persp-file)
          (const :tag "Save all perspectives" :value t)
          (const :tag "Don't save just kill" :value nil)))

(defcustom persp-auto-save-opt 3
  "This variable controls the autosave functionality of the persp-mode:
0 -- do not auto save;
1 -- save on the emacs shutdown and only if the persp-mode active;
2 -- save on the persp-mode deactivation or the emacs shutdown;
3 -- 2 + save on last client frame deleted."
  :group 'persp-mode
  :type '(choice
          (const :tag "Do not save"  :value 0)
          (const :tag "Save on exit" :value 1)
          (const :tag "Save on exit and persp-mode deactivation" :value 2)
          (const :tag "Save on exit, persp-mode deactivation, last frame deletion" :value 3)))

(defcustom persp-auto-save-num-of-backups 3
  "How many autosave file backups to keep."
  :group 'persp-mode
  :type 'integer)

(defcustom persp-auto-resume-time 3.0
  "Delay time in seconds before loading from the autosave file.
If <= 0 -- do not autoresume."
  :group 'persp-mode
  :type 'float)

(defcustom persp-set-last-persp-for-new-frames t
  "If nil new frames will be created with the `nil' perspective,
otherwise with a last activated perspective."
  :group 'persp-mode
  :type 'boolean)

(defcustom persp-reset-windows-on-nil-window-conf t
  "t -- When a perspective without a window configuration is activated
then delete all windows and show the *scratch* buffer;
function -- run that function with optional frame persp new-frame-p arguments;
nil -- do nothing."
  :group 'persp-mode
  :type '(choice
          (const    :tag "Delete all windows" :value t)
          (const    :tag "Do nothing"         :value nil)
          (function :tag "Run function"
                    :value (lambda (&optional frame persp new-frame-p) nil))))


(define-widget 'persp-buffer-list-restriction-choices 'lazy
  "Variants of how the buffer-list can be restricted."
  :offset 4
  :tag "\nControl the persp-buffer-list-restricted behaviour"
  :type '(choice
          (const :tag "List all buffers" :value -1)
          (const :tag "List current perspective buffers" :value 0)
          (const :tag "List buffers that aren't in the perspective" :value 1)
          (const :tag "List buffers which unique to the perspective" :value 2)
          (const :tag "List unique buffers, but show all for the nil perspective"
                 :value 2.5)
          (const :tag "List free buffers" :value 3)
          (const :tag "List free buffers, but show all for the nil perspective"
                 :value 3.5)))

(defcustom *persp-restrict-buffers-to* 0
  "Controls the behaviour of the `persp-buffer-list-restricted' function."
  :group 'persp-mode
  :type '(choice
          persp-buffer-list-restriction-choices
          (function :tag "\nRun function with frame as an argument"
                    :value (lambda (f) (buffer-list f)))))

(defcustom persp-restrict-buffers-to-if-foreign-buffer nil
  "Override the *persp-restrict-buffers-to* if the current buffer is not in the
current perspective. If nil -- do not override."
  :group 'persp-mode
  :type '(choice
          (const :tag "Do not override" :value nil)
          persp-buffer-list-restriction-choices
          (function :tag "\nRun function with frame as an argument"
                    :value (lambda (f) (buffer-list f)))))

(defcustom persp-set-frame-buffer-predicate 'restricted-buffer-list
  "t -- set the frame's buffer-predicate parameter to a function returning `t'
    for buffers in current persp;
nil -- do not set the buffer-predicate;
restricted-buffer-list -- return t for buffers contained in the list returned
  from the persp-buffer-list-restricted called without arguments;
number -- the same meaning as for the `*persp-restrict-buffers-to*';
function -- use that function as buffer-predicate."
  :group 'persp-mode
  :type '(choice
          (const :tag "\nConstrain to current perspective's buffers."
                 :value t)
          (const :tag "\nDo not set frames' buffer-predicate parameter."
                 :value nil)
          (const :tag "\nConstrain with persp-buffer-list-restricted."
                 :value restricted-buffer-list)
          persp-buffer-list-restriction-choices
          (function
           :tag "\nConstrain with a function which take buffer as an argument."
           :value (lambda (b) b)))
  :set
  (lambda (sym val)
    (custom-set-default sym val)
    (if val
        (if persp-mode
            (persp-update-frames-buffer-predicate)
          (if (and (not (daemonp)) (null (cdr (frame-list))))
              (let (th)
                (setq
                 th (lambda ()
                      (run-at-time
                       10 nil (lambda ()
                                (remove-hook 'window-setup-hook th)
                                (persp-update-frames-buffer-predicate)))))
                (add-hook 'window-setup-hook th))
            (add-hook 'persp-mode-hook
                      #'persp-update-frames-buffer-predicate)))
      (persp-update-frames-buffer-predicate t))))

;; TODO: remove this var
(defcustom persp-hook-up-emacs-buffer-completion nil
  "If t -- try to restrict read-buffer function of the current completion system."
  :group 'persp-mode
  :type 'boolean)
(make-obsolete-variable
 'persp-hook-up-emacs-buffer-completion
 "`persp-set-read-buffer-function', `persp-set-ido-hooks', `persp-interactive-completion-function'"
 "persp-mode 2.6")

(defsubst persp-set-read-buffer-function (&optional opt)
  (if opt
      (when (not (eq read-buffer-function #'persp-read-buffer))
        (setq persp-saved-read-buffer-function read-buffer-function)
        (setq read-buffer-function #'persp-read-buffer))
    (when (eq read-buffer-function #'persp-read-buffer)
      (setq read-buffer-function persp-saved-read-buffer-function))))
(defcustom persp-set-read-buffer-function nil
  "If t -- set the read-buffer-function to persp-read-buffer."
  :group 'persp-mode
  :type 'boolean
  :set (lambda (sym val)
         (custom-set-default sym val)
         (when persp-mode
           (persp-set-read-buffer-function val))))

(defsubst persp-set-ido-hooks (&optional opt)
  (if opt
      (progn
        (add-hook 'ido-make-buffer-list-hook #'persp-restrict-ido-buffers)
        (add-hook 'ido-setup-hook            #'persp-ido-setup))
    (remove-hook 'ido-make-buffer-list-hook #'persp-restrict-ido-buffers)
    (remove-hook 'ido-setup-hook            #'persp-ido-setup)))
(defcustom persp-set-ido-hooks nil
  "If t -- set the ido hooks for buffer list restriction."
  :group 'persp-mode
  :type 'boolean
  :set (lambda (sym val)
         (custom-set-default sym val)
         (when persp-mode
           (persp-set-ido-hooks val))))

(defcustom persp-names-sort-before-read-function nil
  "Function(or nil) to sort `persp-names-cache' before prompting a user for a
perspective name(s). The function must take a list of perspective names and
return a sorted list."
  :group 'persp-mode
  :type '(choice
          (const :tag "No sort." :value nil)
          (function :tag "Function" :value #'identity)))

;; TODO: remove this var, just call the completing-read
(defvar persp-interactive-completion-function #'completing-read
  "The function which is used by the persp-mode
to interactivly read user input with completion.")
(make-obsolete-variable
 'persp-interactive-completion-function
 "`completing-read-function'" "persp-mode 2.7")

;; TODO: remove this var
(defcustom persp-interactive-completion-system 'completing-read
  "What completion system to use."
  :group 'persp-mode
  :type '(choice
          (const :tag "ido"             :value ido)
          (const :tag "completing-read" :value completing-read))
  :set (lambda (sym val)
         (if persp-mode
             (persp-update-completion-system val)
           (custom-set-default sym val))))
(make-obsolete-variable
 'persp-interactive-completion-system
 "`persp-set-read-buffer-function', `persp-set-ido-hooks', `persp-interactive-completion-function'"
 "persp-mode 2.6")

(define-obsolete-variable-alias
  'persp-toggle-read-persp-filter-keys 'persp-toggle-read-buffer-filter-keys
  "persp-mode 2.9")
(defvar persp-toggle-read-buffer-filter-keys)
(make-obsolete-variable 'persp-toggle-read-buffer-filter-keys nil "persp-mode 4.0")

(defun persp-update-completion-system (&optional system remove)
  (interactive "i")
  (when (and (not system) (not remove))
    (setq
     system
     (intern
      (funcall persp-interactive-completion-function
               "Set the completion system for persp-mode: "
               '("ido" "completing-read")
               nil t))))
  (if remove
      (progn
        (when (boundp 'persp-interactive-completion-system)
          (when persp-hook-up-emacs-buffer-completion
            (cl-case persp-interactive-completion-system
              (ido (persp-set-ido-hooks))
              (t nil))))
        (setq persp-interactive-completion-function #'completing-read)
        (custom-set-default 'persp-interactive-completion-system
                            'completing-read))
    (persp-update-completion-system nil t)
    (when system
      (custom-set-default 'persp-interactive-completion-system system)
      (when persp-hook-up-emacs-buffer-completion
        (cl-case persp-interactive-completion-system
          (ido
           (persp-set-ido-hooks t)
           (setq persp-interactive-completion-function #'ido-completing-read))
          (t nil))))))

(define-widget 'persp-init-frame-behaviour-choices 'lazy
  "Choices of the init-frame behavoiurs for the persp-mode."
  :offset 4
  :tag "\nControl how frames initialized by persp-mode"
  :type
  '(choice
    (const :tag "Restore window-configuration" :value t)
    (const :tag "Do not restore window-configuration" :value nil)
    (const :tag "Set persp-ignore flag for frame" :value persp-ignore)
    (const :tag "Set persp-ignore-wconf flag for frame"
           :value persp-ignore-wconf)
    (number :tag "Set persp-ignore-wconf for frame to this number"
           :value 2)
    (const :tag "Create a new random auto-perspective for the new frame"
           :value auto-temp)
    (const
     :tag "Create a new perspective for the new frame and prompt for it's name"
     :value prompt)
    (string :tag "Use/create the perspective with a name" :value "pfnf")
    (function :tag "Run this function"
              :value (lambda (frame &optional new-frame-p) nil))))

(defcustom persp-init-frame-behaviour t
  "Control the behaviour of how frames initialized."
  :group 'persp-mode
  :type 'persp-init-frame-behaviour-choices)

(defcustom persp-init-new-frame-behaviour-override -1
  "Override the `persp-init-frame-behaviour` for new frames."
  :group 'persp-mode
  :type '(choice
          (const :tag "Do not override" : value -1)
          persp-init-frame-behaviour-choices))

(defcustom persp-interactive-init-frame-behaviour-override -1
  "Override the `persp-init-frame-behaviour'
when the `make-frame' was called interactively."
  :group 'persp-mode
  :type '(choice
          (const :tag "Do not override" :value -1)
          persp-init-frame-behaviour-choices))

(defcustom persp-emacsclient-init-frame-behaviour-override -1
  "Override the `persp-init-frame-behaviour' variable for frames created using
the emacsclient -[c|t]."
  :group 'persp-mode
  :type '(choice
          (const :tag "Do not override" :value -1)
          persp-init-frame-behaviour-choices))

(defcustom persp-server-switch-behaviour 'only-file-windows-for-client-frame
  "Controls the behaviour of the server-switch-hook."
  :group 'persp-mode
  :type
  '(choice
    (const :tag "Do nothing" :value nil)
    (const :tag "Leave only windows displaing files for edit
(files that was supplied as parameters to emacsclient)"
           :value only-file-windows)
    (const :tag "For the new frame(created by emacsclient -c ...)
leave only windows displaing files for edit"
           :value only-file-windows-for-client-frame)
    (function :tag "Run this function" :value (lambda (frame buflist) nil)))
  :set
  (lambda (sym val)
    (custom-set-default sym val)
    (if persp-mode
        (persp-update-frame-server-switch-hook)
      (add-hook 'persp-mode-hook #'persp-update-frame-server-switch-hook))))

;; TODO: remove this var
(defcustom persp-ignore-wconf-of-frames-created-to-edit-file t
  "If t -- set the persp-ignore-wconf frame parameter
to t for frames that were created by emacsclient with file arguments.
Also delete windows not showing that files
(this is because server-switch-hook runs after after-make-frames);
If function -- run that function."
  :group 'persp-mode
  :type '(choice
          (const    :tag "Ignore window configuration" :value t)
          (const    :tag "Do as usual"  :value nil)
          (function :tag "Run function" :value (lambda () nil))))
(make-obsolete-variable
 'persp-ignore-wconf-of-frames-created-to-edit-file
 "`persp-emacsclient-frame-to-edit-file-behavoiur'" "persp-mode 2.0")

(defcustom persp-filter-frame-functions
  (list (lambda (f)
          (or (not (frame-live-p f))
              (eq 'ignore (frame-parameter f 'persp-ignore))
              (> 50 (frame-width f))
              (> 15 (frame-height f))
              (and (featurep 'posframe)
                   (or (frame-parameter f 'posframe-buffer)
                       (frame-parameter f 'posframe-parent-buffer)
                       (string= "posframe" (frame-parameter f 'title))))
              (persp-is-frame-daemons-frame f))))
  "Skip frame if one of functions returns non nil."
  :group 'persp-mode
  :type '(repeat function))

(defcustom persp-add-buffer-on-find-file t
  "If t -- add a buffer with opened file to current perspective."
  :group 'persp-mode
  :type
  '(choice
    (const :tag "Always add" :value t)
    (const :tag "Newer add" :value nil)
    (const
     :tag "\nAdd if not matching any predicate from `persp-auto-persp-alist'"
     :value if-not-autopersp)
    (const :tag "\nAlways add but do not switch if the buffer matches any \
predicate from `persp-auto-persp-alist'"
           :value add-but-not-switch-if-autopersp)))


(defcustom persp-add-buffer-on-after-change-major-mode nil
  "t -- add the current buffer to the current perspective when
the `after-change-major-mode-hook' fires;
nil -- do not add;
\\='free -- add only _free_ buffers;
function -- run that function with buffer as argument."
  :group 'persp-mode
  :type '(choice
          (const :tag "Always add" :value t)
          (const :tag "Don't add" :value nil)
          (const :tag "\nAdd if the buffer is not already in any other persp"
                 :value free)
          (function :tag "Run this function" :value (lambda (buf) nil)))
  :set
  (lambda (sym val)
    (custom-set-default sym val)
    (when persp-mode
      (if val
          (add-hook 'after-change-major-mode-hook
                    #'persp-after-change-major-mode-h 99)
        (remove-hook 'after-change-major-mode-hook
                     #'persp-after-change-major-mode-h)))))

(defcustom persp-switch-to-added-buffer t
  "If t then after you add a buffer to the current perspective
the currently selected window will be switched to that buffer."
  :group 'persp-mode
  :type 'boolean)

(define-obsolete-variable-alias
  'persp-when-kill-switch-to-buffer-in-perspective
  'persp-when-remove-buffer-switch-to-other-buffer
  "persp-mode 2.9.7")
(defcustom persp-when-remove-buffer-switch-to-other-buffer t
  "If t -- then after a buffer is removed all windows of the current
perspective which showing that buffer will be switched to some previous buffer
in the current perspective."
  :group 'persp-mode
  :type 'boolean)

(defcustom persp-remove-buffers-from-nil-persp-behaviour 'ask-to-rem-from-all
  "What to do when removing a buffer from the nil perspective."
  :group 'persp-mode
  :type '(choice
          (const :tag "Ask to remove from all perspectives" ask-to-rem-from-all)
          (const :tag "Ask only if buffer belongs to a non-weak perspective"
                 ask-if-in-non-weak-persp)
          (const :tag "Don't ask" nil)
          (function :tag "Run this function" (lambda (b-o-ns) b-o-ns))))

(define-widget 'persp-kill-foreign-buffer-behaviour-choices 'lazy
  "What to do when manually killing a buffer that is not in
the current perspective."
  :offset 4
  :tag "\nControl the persp-kill-buffer-query-function behaviour."
  :type
  '(choice
    (const :tag "Ask what to do" :value ask)
    (const :tag "\nDon't ask if a buffer belongs only to weak perspectives"
           :value dont-ask-weak)
    (const :tag "Just kill" :value kill)
    (const :tag "\nDo not suggest foreign buffer to the user(kill buffer)"
           :value nil)
    (function :tag "Run function" :value (lambda () t))))

(define-obsolete-variable-alias 'persp-kill-foreign-buffer-action
  'persp-kill-foreign-buffer-behaviour "persp-mode 2.9.6")
(defcustom persp-kill-foreign-buffer-behaviour 'dont-ask-weak
  "What to do when manually killing a buffer that is not in
the current perspective."
  :group 'persp-mode
  :type 'persp-kill-foreign-buffer-behaviour-choices)

(make-obsolete-variable
 'persp-kill-foreign-indirect-buffer-behaviour-override
 "Don't use this" "persp-mode 2.9.7")

(defcustom persp-autokill-buffer-on-remove nil
  "Kill the buffer if it removed from every(or non weak) perspective."
  :group 'persp-mode
  :type
  '(choice
    (const :tag "Just kill" :value kill) ;; or t
    (const
     :tag "Kill if buffer belongs only to weak perspectives" :value kill-weak)
    (const :tag "Do not kill" :value nil)))

(defcustom persp-autokill-persp-when-removed-last-buffer 'hide-auto
  "Kill the perspective if no buffers left in it."
  :group 'persp-mode
  :type '(choice
          (const :tag "Just kill" :value kill) ;; or t
          (const :tag "Kill auto perspectives" :value kill-auto)
          (const :tag "Hide" :value hide)
          (const :tag "Hide auto perspectives" :value hide-auto)
          (const :tag "Do not kill" :value nil)
          (function :tag "\nRun this function with persp as an argument"
                    :value (lambda (p) p))))

(defcustom persp-use-kill-buffer-advice t
  "Whether to use `kill-buffer' advice to check killed buffers still in persps"
  :group 'persp-mode
  :type 'boolean
  :set (lambda (sym val)
         (custom-set-default sym val)
         (when persp-mode
           (if val
               (when (fboundp 'persp-activate-kill-buffer-advice)
                 (persp-activate-kill-buffer-advice))
             (when (fboundp 'persp-deactivate-kill-buffer-advice)
               (persp-deactivate-kill-buffer-advice))))))

(defcustom persp-use-make-indirect-buffer-advice nil
  "Whether to use `make-indirect-buffer' advice to add buffer to persp"
  :group 'persp-mode
  :type 'boolean
  :set (lambda (sym val)
         (custom-set-default sym val)
         (when persp-mode
           (if val
               (when (fboundp 'persp-activate-make-indirect-buffer-advice)
                 (persp-activate-make-indirect-buffer-advice))
             (when (fboundp 'persp-deactivate-make-indirect-buffer-advice)
               (persp-deactivate-make-indirect-buffer-advice))))))

(defcustom persp-common-buffer-filter-functions
  (list (lambda (b) (or (string-prefix-p " " (buffer-name b))
                   (eq (buffer-local-value 'major-mode b) 'helm-major-mode))))
  "The list of functions wich takes a buffer as an argument. If one of these
functions return a non nil value the buffer considered as \\='filtered out\\='."
  :group 'persp-mode
  :type '(repeat function))

(defcustom persp-buffer-list-restricted-filter-functions nil
  "Additional filters for use inside the `persp-buffer-list-restricted'."
  :group 'persp-mode
  :type '(repeat function))

(defcustom persp-add-buffer-on-after-change-major-mode-filter-functions nil
  "Additional filters to know which buffers we dont want to add to
the current perspective after the `after-change-major-mode-hook' is fired."
  :group 'persp-mode
  :type '(repeat function))

(defcustom persp-filter-save-buffers-functions
  (list (lambda (b) (string-prefix-p "*" (buffer-name b))))
  "Additional filters to not save unneeded buffers."
  :group 'persp-mode
  :type '(repeat function))

(defcustom persp-save-buffer-functions
  (list (lambda (b)
          (when (persp-buffer-filtered-out-p
                 b persp-filter-save-buffers-functions)
            'skip))
        #'persp-indirect-save-buffer
        #'persp-tramp-save-buffer
        #'persp-dired-save-buffer
        #'persp-standard-save-buffer)
  "Convert a buffer to a structure that could be saved to a file.
If a function returns nil -- follow to the next function in the list.
If a function returns \\='skip -- don\\='t save a buffer."
  :group 'persp-mode
  :type '(repeat function))

(defcustom persp-load-buffer-functions
  (list #'persp-buffer-from-savelist)
  "Restore a buffer from a saved structure.
If a function returns nil -- follow to the next function in the list.
If a function returns \\='skip -- don\\='t restore a buffer."
  :group 'persp-mode
  :type '(repeat function))

(defcustom persp-load-buffer-handle-missing-file-functions
  (list (lambda (bsl) (get-buffer-create (cadr bsl))))
  "Takes buffer definition with missing file as input.
If returns buffer -- use that buffer.
If returns nil -- follow to next function.
If returns \\='skip -- don\\='t restore a buffer."
  :group 'persp-mode
  :type '(repeat function))

(define-widget 'persp-load-name-conflict-behaviour-choices 'lazy
  "What to do in case of name conflict during state loading."
  :offset 4
  :tag "\nUsed when loading state from file."
  :type
  '(choice
    (const :tag "Ask user" :value ask)
    (const :tag "Merge" :value merge)
    (const :tag "Rename loaded" :value rename-new)
    (const :tag "Rename existent" :value rename-old)
    (const :tag "Replace" :value overwrite)
    (const :tag "Generate new name" :value autorename)
    (const :tag "Skip loading" :value skip)
    (const :tag "Do default(Merge)" :value nil)
    (function :tag "Run function"
              :value (lambda (name &optional _file phash/buf-params)
                       (if (hash-table-p phash/buf-params)
                           "new-name-for-persp"
                         "new-name-for-buffer")))))

(defcustom persp-load-name-conflict-behaviour nil
  "What to do if perspective with same name already exists
when loading state from file."
  :group 'persp-mode
  :type 'persp-load-name-conflict-behaviour-choices)

(defcustom persp-load-buffer-name-conflict-behaviour nil
  "What to do if buffer with same name already exists
when loading state from file."
  :group 'persp-mode
  :type 'persp-load-name-conflict-behaviour-choices)

(defcustom persp-mode-hook nil
  "The hook that's run after the `persp-mode' has been activated."
  :group 'persp-mode
  :type 'hook)

(defcustom persp-mode-deactivated-hook nil
  "Runs when the persp-mode is deactivated."
  :group 'persp-mode
  :type 'hook)

(defcustom persp-names-cache-changed-functions nil
  "Functions to run after the `persp-names-cache' was changed.
These functions must take two arguments: a list of olds names and
a list of new names."
  :group 'persp-mode
  :type 'hook)

(defcustom persp-buffer-state-changed-functions nil
  "Functions to run after a persp-mode changed something about a buffer.
Arguments: buffer, perspective, event type symbol.
Current events: \\='added, \\='removed."
  :group 'persp-mode
  :type 'hook)

(defcustom persp-created-functions nil
  "Functions to run after a perspective was created.
These functions must accept two arguments -- the created perspective
and the hash in which this perspective will be placed, you can check
if that hash is the same as `*persp-hash*' or another(when you load
a subset of perspectives(with `persp-load-from-file-by-names') they
will be added to a temporary hash)."
  :group 'persp-mode
  :type 'hook)

(defcustom persp-renamed-functions nil
  "Functions to run if a perspective was renamed.
Each must take three arguments: 1) perspective; 2) old name; 3) new name.
These functions only run when renaming a perspective from `*persp-hash*'."
  :group 'persp-mode
  :type 'hook)

(defcustom persp-before-kill-functions nil
  "Functions that runs just before a perspective will be destroyed.
It's single argument is the perspective that will be killed."
  :group 'persp-mode
  :type 'hook)

(defcustom persp-before-switch-functions nil
  "Functions that runs before actually switching to a perspective.
These functions must take two arguments -- a name of a perspective to switch
 (it could be a name of an nonexistent perspective or it could be the same
as current) and a frame or a window for which the switching will take place."
  :group 'persp-mode
  :type 'hook)

(defcustom persp-activated-functions nil
  "Functions that runs after a perspective has been activated.
These functions must take three arguments -- 1) a symbol:
if it eq \\='frame -- then the perspective is activated for a frame,
if it eq \\='window -- then the perspective is activated for a window;
2) a frame-or-window; 3) activated perspective."
  :group 'persp-mode
  :type 'hook)

(defcustom persp-before-deactivate-functions nil
  "Functions that runs before the current perspective has been deactivated
for selected frame or window.
These functions must take three arguments -- 1) a symbol:
if it\\='s \\='frame -- perspective will be deactivated for a frame,
if it\\='s \\='window -- perspective will be deactivated for a window';
2) a frame-or-window, which may be a dead frame; 3) perspective being deactivated."
  :group 'persp-mode
  :type 'hook)

(defcustom persp-before-save-state-to-file-functions nil
  "Functions to run before saving perspectives to a file.
Each function in this list will be called with 3 arguments:
1) a file name to which perspectives will be saved;
2) a hash with perspectives;
3) a bool argument indicating if the persp-file parameter of perspectives
    must be set."
  :group 'persp-mode
  :type 'hook)

(defvar persp-indirect-buffers-to-restore nil
  "List with indirect buffer definitions to restore
after all normal buffers loaded.")

(defcustom persp-after-load-state-functions
  (list (lambda (_file phash persp-names)
          (when persp-indirect-buffers-to-restore
            (dolist (ibp persp-indirect-buffers-to-restore)
              (cl-destructuring-bind
                  (bname fname mode parameters base-name)
                  (buffer-local-value 'persp-indirect-buffer-restore-info ibp)
                (let ((base-buf (persp-get-buffer-or-null base-name)))
                  (if (buffer-live-p base-buf)
                      (let ((ib (persp-buffer-from-savelist
                                 `(def-buffer ,(buffer-name ibp) ,fname ,mode
                                    ,(cons (cons 'indirect base-buf) parameters)))))
                        (unless (buffer-live-p ib)
                          (message "[persp-mode] Error: Failed to restore indirect buffer %S,
with base buffer %S." bname base-name)))
                    (message "[persp-mode] Error: Can not restore indirect buffer %S.
Base buffer %S not found." bname base-name)))))
            (setq persp-indirect-buffers-to-restore nil))
          (when (eq phash *persp-hash*)
            (persp-update-frames-window-confs persp-names)
            (persp-convert-window-confs persp-names 'from-readable))))
  "Functions that runs after perspectives state was loaded.
These functions must take 3 arguments:
1) a file from which the state was loaded;
2) a hash in which loaded perspectives were placed;
3) list of names of perspectives that was loaded."
  :group 'persp-mode
  :type 'hook)

(defcustom persp-use-workgroups (and (version< emacs-version "24.4")
                                     (locate-library "workgroups"))
  "If t -- use the workgroups.el package for saving/restoring
windows configurations."
  :group 'persp-mode
  :type 'boolean
  :set
  (lambda (sym val)
    (custom-set-default sym val)
    ;; require workgroups if we are going to use it
    (when persp-use-workgroups
      ;;(require 'workgroups)
      (unless (fboundp 'wg-make-wconfig)
        (autoload 'wg-make-wconfig "workgroups"
          "Return a new Workgroups window config from `selected-frame'." ))
      (unless (fboundp 'wg-restore-wconfig)
        (autoload 'wg-restore-wconfig "workgroups"
          "Restore WCONFIG in `selected-frame'." )))))

(defcustom persp-restore-window-conf-method t
  "Defines how to restore window configurations for the new frames:
t -- the standard action.
function -- run that function."
  :group 'persp-mode
  :type
  '(choice
    (const :tag "Standard action" :value t)
    (const :tag "Do nothing" :value nil)
    (function :tag "Run function"
              :value (lambda (frame persp new-frame-p) nil))))

(defcustom persp-save-restore-window-conf-filter-functions
  (list (lambda (f p &optional _new-f-p)
          (or
           (null p)
           (> 50 (frame-width f))
           (> 15 (frame-height f))
           (eq 'ignore (frame-parameter f 'persp-ignore))
           (let ((f-piw (frame-parameter f 'persp-ignore-wconf)))
             (if (numberp f-piw)
                 (prog1 (< 0 f-piw)
                   (when (> 1 (cl-decf f-piw))
                     (setq f-piw nil))
                   (set-frame-parameter f 'persp-ignore-wconf f-piw))
               f-piw)))))
  "The list of functions which takes a frame, persp and new-frame-p(optional) as arguments.
If one of these functions return a non nil value then the window configuration
of the persp will not be saved/restored for the frame"
  :group 'persp-mode
  :type '(repeat function))
(make-obsolete-variable 'persp-restore-window-conf-filter-functions
                        'persp-save-restore-window-conf-filter-functions
                        "persp-mode 4.0.0")

(defcustom persp-get-window-for-state-get-put-function
  #'frame-root-window
  "Function to get window for saving/restoring window configuration of a frame."
  :group 'persp-mode
  :type '(choice
          (const :tag "Use frame root window" :value frame-root-window)
          (const :tag "Use frame main window" :value window-main-window)
          (function :tag "Custom function"
                    :value (lambda (&optional frame)
                             (frame-first-window frame)))))

(defcustom persp-toggle-side-windows-around-window-state-get-put
  (if (eq persp-get-window-for-state-get-put-function #'frame-root-window)
      nil '(put nil))
  "Whether persp-mode must save/restore side windows around
`persp-window-state-get' and `persp-window-state-put'.
The value is a list which may contain any combination of symbols
`get', `put' and `nil'.
The `nil' is for the case when you switch to a perspective without
saved window configuration."
  :group 'persp-mode
  :type '(set (const :tag "for get operation" :value get)
              (const :tag "for put operation" :value put)
              (const :tag "The case of `nil' state" :value nil)))

(defcustom persp-before-window-state-get-functions
  (list (lambda (frame win writable)
          (when (memq 'get
                      persp-toggle-side-windows-around-window-state-get-put)
            (persp-hide-side-windows frame))
          (unless (window-live-p win)
            (setq win (funcall
                       persp-get-window-for-state-get-put-function
                       frame)))
          (list frame win writable)))
  "Run functions before `persp-window-state-get-function'.
Return list of arguments.
Return nil to abort."
  :group 'persp-mode
  :type '(repeat function))

(defcustom persp-after-window-state-get-functions
  (list (lambda (wc/ret frame _win _writable)
          (when (memq 'get
                      persp-toggle-side-windows-around-window-state-get-put)
            (persp-restore-side-windows frame))
          (or wc/ret t)))
  "Run functions after `persp-window-state-get-function'.
Return nil to abort."
  :group 'persp-mode
  :type '(repeat function))

(defcustom persp-before-window-state-put-functions
  (list (lambda (wc frame win)
          (when (memq 'put
                      persp-toggle-side-windows-around-window-state-get-put)
            (persp-hide-side-windows frame))
          (persp-delete-other-windows
           frame
           (persp-get-create-window-to-stay-alive-before-config-put frame))
          (unless (window-live-p win)
            (setq win (funcall
                       persp-get-window-for-state-get-put-function
                       frame)))
          (list wc frame win)))
  "Run functions before `persp-window-state-put-function'.
Return list of arguments.
Return nil to abort."
  :group 'persp-mode
  :type '(repeat function))

(defcustom persp-after-window-state-put-functions
  (list (lambda (ret _wc frame _win)
          (when (memq 'put
                      persp-toggle-side-windows-around-window-state-get-put)
            (persp-restore-side-windows frame))
          (or ret t)))
  "Run functions after `persp-window-state-put-function'.
Return nil to abort."
  :group 'persp-mode
  :type '(repeat function))

(defcustom persp-window-state-get-function
  (if persp-use-workgroups
      (lambda (frame &rest _ignore)
        (when frame
          (with-selected-frame frame (wg-make-wconfig))))
    (if (version< emacs-version "24.4")
        (lambda (_frame rwin &rest _ignore)
          (when rwin
            (when (fboundp 'window-state-get)
              (window-state-get rwin))))
      (lambda (_frame rwin &optional writable)
        (when rwin
          (window-state-get rwin writable)))))
  "Function for getting a window configuration of a frame, accept
three arguments:
first -- a frame
second -- a window(like the root window of a frame)
third -- is state must be writable"
  :group 'persp-mode
  :type 'function)

(defcustom persp-window-state-put-function
  (if persp-use-workgroups
      (lambda (pwc &optional frame _rwin)
        (when (or frame (setq frame (selected-frame)))
          (with-selected-frame frame
            (cl-letf (((symbol-function 'wg-switch-to-window-buffer)
                       (lambda (win)
                         "Switch to a buffer determined from WIN's fname and bname.
Return the buffer if it was found, nil otherwise."
                         (defvar _wg-fname)
                         (defvar wg-bname)
                         (defvar wg-it)
                         (defvar wg-default-buffer)
                         (wg-abind
                          win (_wg-fname wg-bname)
                          (cond ((wg-awhen (get-buffer wg-bname)
                                           (persp-switch-to-buffer wg-it)))
                                (t (persp-switch-to-buffer wg-default-buffer)
                                   nil))))))
              (wg-restore-wconfig pwc)))))
    (lambda (pwc &optional frame rwin)
      (when (or rwin (setq rwin (funcall
                                 persp-get-window-for-state-get-put-function
                                 (or frame (selected-frame)))))
        (when (fboundp 'window-state-put)
          (let ((window-restore-killed-buffer-windows t))
            (window-state-put pwc rwin t))))))
  "Function for restoring a window configuration. Accept a window configuration
obtained by the `persp-window-state-get-function' and two optional arguments:
one -- a frame
and another -- window(like root or main window of a frame)."
  :group 'persp-mode
  :type 'function)

(defcustom persp-window-to-stay-alive-filter-functions
  (list
   (lambda (win)
     (or (not (window-live-p win))
         (window-minibuffer-p win)
         (window-parameter win 'window-side)
         (window-parameter win 'persp-window-not-appropriate-to-restore-win-conf))))
  "Return nil if window can be only window before restoring window config."
  :group 'persp-mode
  :type '(repeat function))
(make-obsolete-variable 'persp-get-window-to-put-window-conf-filter-functions
                        'persp-window-to-stay-alive-filter-functions
                        "persp-mode 4.0.0")

(defcustom persp-buffer-list-function (symbol-function 'buffer-list)
  "The function that is used mostly internally by persp-mode functions
to get a list of all buffers."
  :group 'persp-mode
  :type 'function)

(defcustom persp-dont-count-weaks-in-restricted-buffer-list nil
  "if t -- dont count weak perspectives in `persp-buffer-list-restricted'.
For now it makes any effect only if the value of
the `*persp-restrict-buffers-to*' and friends is 2, 2.5, 3 or 3.5."
  :group 'persp-mode
  :type 'boolean)

(defcustom persp-auto-persp-alist nil
  "Alist of auto-persp definitions."
  :group 'persp-mode
  :tag "Auto perspectives"
  :type '(alist :key-type (string :tag "Name")
                :value-type (alist :tag "Parameters"
                                   :key-type (symbol :tag "Keyword"))))

(defcustom persp-switch-wrap t
  "Whether `persp-next' and `persp-prev' should wrap."
  :group 'persp-mode
  :type 'boolean)



;; Key bindings:

(defvar persp-mode-map (make-sparse-keymap "persp-mode")
  "The keymap with a prefix for the persp-mode.")

(define-prefix-command 'persp-key-map nil "persp")

(define-key persp-key-map (kbd "o") `("o-ff persp-mode"    . ,(lambda () (interactive) (persp-mode -1))))
(define-key persp-key-map (kbd "S") '("S-witch(win)"       . persp-window-switch))
(define-key persp-key-map (kbd "L") '("L-oad some persps"  . persp-load-from-file-by-names))
(define-key persp-key-map (kbd "W") '("W-rite some persps" . persp-save-to-file-by-names))
(define-key persp-key-map (kbd "I") '("I-mport winConf"    . persp-import-win-conf))
(define-key persp-key-map (kbd "i") '("i-mport bufs"       . persp-import-buffers))
(define-key persp-key-map (kbd "c") '("c-opy"              . persp-copy))
(define-key persp-key-map (kbd "z") '("save&kill"          . persp-save-and-kill))
(define-key persp-key-map (kbd "C") '("kill"               . persp-kill))
(define-key persp-key-map (kbd "l") '("l-oad persps"       . persp-load-state-from-file))
(define-key persp-key-map (kbd "w") '("w-rite persps"      . persp-save-state-to-file))
(define-key persp-key-map (kbd "r") '("r-ename"            . persp-rename))
(define-key persp-key-map (kbd "p") '("p-revious"          . persp-prev))
(define-key persp-key-map (kbd "n") '("n-ext"              . persp-next))
(define-key persp-key-map (kbd "X") '("remove bufs(reg-X)" . persp-remove-buffers-by-regexp))
(define-key persp-key-map (kbd "x") '("add bufs(reg-x)"    . persp-add-buffers-by-regexp))
(define-key persp-key-map (kbd "t") '("show buf"           . persp-temporarily-display-buffer))
(define-key persp-key-map (kbd "k") '("remove buf"         . persp-remove-buffer))
(define-key persp-key-map (kbd "a") '("a-dd buf"           . persp-add-buffer))
(define-key persp-key-map (kbd "K") '("K-ill buf"          . persp-kill-buffer))
(define-key persp-key-map (kbd "b") '("b-uf show&add"      . persp-switch-to-buffer))
(define-key persp-key-map (kbd "s") '("s-witch(frame)"     . persp-frame-switch))


(defun persp-set-keymap-prefix (prefix)
  (interactive
   (list
    (read-key-sequence
     "Now press a key sequence to be used as the persp-key-map prefix: ")))
  (when prefix
    (setq prefix (kbd prefix))
    (when (boundp 'persp-keymap-prefix)
      (substitute-key-definition 'persp-key-map nil persp-mode-map))
    (define-key persp-mode-map prefix 'persp-key-map)
    (let ((pkm-lc (last persp-key-map)))
      (when (stringp (car pkm-lc))
        (setcar pkm-lc (concat (propertize "[persp]" 'face 'mode-line)
                               (help-key-description prefix nil)
                               " "))))
    (custom-set-default 'persp-keymap-prefix prefix)))

(defcustom persp-keymap-prefix (kbd "C-c p")
  "The prefix for activating the persp-mode keymap."
  :group 'persp-mode
  :type 'key-sequence
  :set (lambda (_sym val) (persp-set-keymap-prefix val)))

(defvar persp-read-multiple-keys)
;; TODO?: remove this function?
(defun persp-set-toggle-read-buffer-filter-keys (keys)
  (interactive
   (list
    (read-key-sequence
     "Now press a key sequence to be used for toggling persp filters during the read-buffer: ")))
  (setcdr (assq 'toggle-persp-buffer-filter persp-read-multiple-keys) keys)
  (custom-set-default 'persp-toggle-read-buffer-filter-keys keys))
(define-obsolete-function-alias
  'persp-set-toggle-read-persp-filter-keys
  'persp-set-toggle-read-buffer-filter-keys
  "persp-mode 2.9")
(make-obsolete 'persp-set-toggle-read-buffer-filter-keys nil "persp-mode 4.0")

(defcustom persp-read-multiple-keys
  `((toggle-persp-buffer-filter . ,(kbd "C-x C-p"))
    (push-item . ,(kbd "C-<return>"))
    (pop-item  . ,(kbd "M-<return>")))
  "Keybindings to use while prompting for multiple items."
  :group 'persp-mode
  :tag "Keys for reading multiple items"
  :options '(toggle-persp-buffer-filter push-item pop-item)
  :type '(alist
          :key-type (choice (const :tag "toggle buffer filtering"
                                   :value toggle-persp-buffer-filter)
                            (const :tag "push" :value push-item)
                            (const :tag "pop" :value pop-item))
          :value-type key-sequence))

;; (defcustom persp-toggle-read-buffer-filter-keys (kbd "C-x C-p")
;;   "Keysequence to toggle the buffer filtering during read-buffer."
;;   :group 'persp-mode
;;   :type 'key-sequence
;;   :set (lambda (sym val) (message "%S is deprecated" sym)))




;; Perspective struct:

(cl-defstruct (perspective
               (:conc-name persp--)
               (:constructor persp--make))
  (name "")
  (buffers nil)
  (window-conf nil)
  ;; reserved parameters: dont-save-to-file, persp-file, not-auto-add-buffers.
  (parameters nil)
  (weak nil)
  (auto nil)
  (hidden nil))

(define-obsolete-function-alias 'make-persp 'persp--make "persp-mode 4.0.0")

(defun persp-p (obj)
  (or (null obj) (perspective-p obj)))

(defun persp-name (p)
  (persp--name (or p persp-nil-persp)))
(defun persp-buffers (p)
  (if p (persp--buffers p) (funcall persp-buffer-list-function)))
(defun persp-window-conf (p)
  (persp--window-conf (or p persp-nil-persp)))
(defun persp-parameters (p)
  (persp--parameters (or p persp-nil-persp)))
(defun persp-weak (p)
  (persp--weak (or p persp-nil-persp)))
(defun persp-auto (p)
  (persp--auto (or p persp-nil-persp)))
(defun persp-hidden (p)
  (persp--hidden (or p persp-nil-persp)))

(gv-define-setter persp-name (newname p)
  `(setf (persp--name (or ,p persp-nil-persp)) ,newname))
(gv-define-setter persp-buffers (bufs p)
  `(setf (persp--buffers (or ,p persp-nil-persp)) ,bufs))
(gv-define-setter persp-window-conf (wc p)
  `(setf (persp--window-conf (or ,p persp-nil-persp)) ,wc))
(gv-define-setter persp-parameters (params p)
  `(setf (persp--parameters (or ,p persp-nil-persp)) ,params))
(gv-define-setter persp-weak (nweak p)
  `(setf (persp--weak (or ,p persp-nil-persp)) ,nweak))
(gv-define-setter persp-auto (nauto p)
  `(setf (persp--auto (or ,p persp-nil-persp)) ,nauto))
(gv-define-setter persp-hidden (nhidden p)
  `(setf (persp--hidden (or ,p persp-nil-persp)) ,nhidden))

(defvar persp-nil-wconf nil
  "Window configuration for the `nil' perspective.")
(make-obsolete-variable
 'persp-nil-wconf "Use (persp-window-conf persp-nil-persp)"
 "persp-mode 3.9.1")

(defvar persp-nil-parameters nil
  "Parameters of the `nil' perspective.")
(make-obsolete-variable
 'persp-nil-parameters "Use (persp-parameters persp-nil-persp)"
 "persp-mode 3.9.1")

(defvar persp-nil-hidden nil
  "Hidden filed for the `nil' perspective.")
(make-obsolete-variable
 'persp-nil-hidden "Use (persp-hidden persp-nil-persp)"
 "persp-mode 3.9.1")

(defvar persp-nil-persp
  (persp--make :name persp-nil-name :weak t)
  "Structure to store properties of nil perspective.")

(defun persp-nil-p (obj)
  (or (null obj) (eq obj persp-nil-persp)))

(cl-defun persp-normalize-persp-arg (obj &optional (phash *persp-hash*)
                                         (default persp-not-persp))
  (cond
   ((perspective-p obj) obj)
   ((null obj) persp-nil-persp)
   ((stringp obj) (persp-get-by-name obj phash default))
   (t default)))

(cl-defmacro persp-normalize-persp-arg* (&optional (p-var 'persp) (ph-var '*persp-hash*)
                                                   (dflt-var 'persp-not-persp))
  `(setq ,p-var (persp-normalize-persp-arg ,p-var ,ph-var ,dflt-var)))

;; TODO: Remove, not used?
(defun persp-buffer-list (&optional frame window)
  (if *persp-pretend-switched-off*
      (buffer-list)
    (let ((persp (persp-get-current frame window)))
      (if (persp-nil-p persp)
          (buffer-list)
        (persp-buffers persp)))))

;; TODO: use keyword arguments add window argument
(cl-defun persp-buffer-list-restricted
    (&optional
     (frame (selected-frame)) (option *persp-restrict-buffers-to*)
     (option-foreign-override persp-restrict-buffers-to-if-foreign-buffer)
     sure-not-killing)
  (unless frame (setq frame (selected-frame)))
  (unless option (setq option 0))
  (let* ((cpersp (persp-get-current frame))
         (curbuf (current-buffer))
         (cb-foreign (not (persp-contain-buffer-p curbuf cpersp))))
    (when (and option-foreign-override cb-foreign)
      (setq option option-foreign-override))
    (cl-typecase option
      (function (funcall option frame))
      (t
       (when (= option 2.5)
         (setq option (if (persp-nil-p cpersp) -1 2)))
       (when (= option 3.5)
         (setq option (if (persp-nil-p cpersp) -1 3)))
       (let ((bl
              (cl-case option
                (-1
                 (funcall persp-buffer-list-function frame))
                (0
                 (if (persp-nil-p cpersp)
                     (funcall persp-buffer-list-function frame)
                   (cl-copy-list (persp-buffers cpersp))))
                (1
                 (let ((ret (if (persp-nil-p cpersp)
                                nil
                              (let ((pbs (cl-copy-list (persp-buffers cpersp))))
                                (cl-delete-if
                                 (lambda (b) (let ((cns (memq b pbs)))
                                          (when cns
                                            (setcar cns (cadr cns))
                                            (setcdr cns (cddr cns))
                                            t)))
                                 (funcall persp-buffer-list-function frame))))))
                   (unless (persp-contain-buffer-p curbuf cpersp)
                     (setq ret (cons curbuf (cl-delete curbuf ret :count 1))))
                   ret))
                (2
                 (let ((ret
                        (cl-delete-if
                         (lambda (b)
                           (persp-buffer-in-other-p*
                            b cpersp
                            persp-dont-count-weaks-in-restricted-buffer-list))
                         (if (persp-nil-p cpersp)
                             (funcall persp-buffer-list-function frame)
                           (cl-copy-list (persp-buffers cpersp))))))
                   ret))
                (3
                 (let ((ret
                        (cl-delete-if
                         (lambda (b)
                           (or
                            (and (not (persp-nil-p cpersp))
                                 (persp-contain-buffer-p b cpersp))
                            (persp-buffer-in-other-p*
                             b cpersp
                             persp-dont-count-weaks-in-restricted-buffer-list)))
                         (funcall persp-buffer-list-function frame))))
                   ret)))))
         (when persp-buffer-list-restricted-filter-functions
           (setq bl
                 (cl-delete-if (lambda (b)
                                 (persp-buffer-filtered-out-p
                                  b persp-buffer-list-restricted-filter-functions))
                               bl)))
         (when (and
                (not sure-not-killing)
                (not (persp-nil-p cpersp))
                (symbolp this-command)
                persp-kill-foreign-buffer-behaviour
                (string-match-p "^.*?kill-buffer.*?$" (symbol-name this-command))
                (not (memq curbuf bl))
                ;; TODO: remove this
                ;; (not (persp-buffer-filtered-out-p curbuf))
                )
           (push curbuf bl))
         bl)))))

(cl-defmacro with-persp-buffer-list
    ((&key
      ;; TODO: _buffer-list-function ?
      (_buffer-list-function persp-buffer-list-function)
      (restriction *persp-restrict-buffers-to*)
      (restriction-foreign-override persp-restrict-buffers-to-if-foreign-buffer)
      sortp cache)
     &rest body)
  (let ((pblf-body `(persp-buffer-list-restricted frame)))
    (when sortp (setq pblf-body `(sort ,pblf-body (with-no-warnings ,sortp))))
    `(let ((*persp-restrict-buffers-to* ,restriction)
           (persp-restrict-buffers-to-if-foreign-buffer
            ,restriction-foreign-override)
           ,@(if cache `(persp-buffer-list-cache) nil))
       (cl-letf (((symbol-function 'buffer-list)
                  (lambda (&optional frame)
                    ,(if cache
                         `(if persp-buffer-list-cache
                              persp-buffer-list-cache
                            (setq persp-buffer-list-cache ,pblf-body))
                       pblf-body))))
         ,@body))))

;;TODO: _multiple, _default-mode ?
(cl-defmacro with-persp-read-buffer ((&key _multiple (_default-mode t)) &rest body)
  `(let ((read-buffer-function #'persp-read-buffer))
     ,@body))

(defmacro with-persp-ido-hooks (&rest body)
  `(let ((ido-make-buffer-list-hook ido-make-buffer-list-hook)
         (ido-setup-hook ido-setup-hook))
     (persp-set-ido-hooks t)
     ,@body))

(define-obsolete-function-alias 'safe-persp-name        'persp-name        "persp-mode 4.0.0" "use persp-name.")
(define-obsolete-function-alias 'safe-persp-buffers     'persp-buffers     "persp-mode 4.0.0" "use persp-buffers.")
(define-obsolete-function-alias 'safe-persp-window-conf 'persp-window-conf "persp-mode 4.0.0" "use persp-window-conf.")
(define-obsolete-function-alias 'safe-persp-parameters  'persp-parameters  "persp-mode 4.0.0" "use persp-parameters.")
(define-obsolete-function-alias 'safe-persp-weak        'persp-weak        "persp-mode 4.0.0" "use persp-weak.")
(define-obsolete-function-alias 'safe-persp-auto        'persp-auto        "persp-mode 4.0.0" "use persp-auto.")
(define-obsolete-function-alias 'safe-persp-hidden      'persp-hidden      "persp-mode 4.0.0" "use persp-hidden.")


(cl-defun persp-modify-parameters (alist &optional (persp (persp-get-current)))
  (cl-loop for (name . value) in alist
           do (persp-set-parameter name value persp)))
(define-obsolete-function-alias 'modify-persp-parameters 'persp-modify-parameters "persp-mode 4.0.0")

(cl-defun persp-set-parameter
    (param-name &optional value (persp (persp-get-current)))
  (let* ((params (persp-parameters persp))
         (old-cons (assq param-name params)))
    (if old-cons
        (setcdr old-cons value)
      (setf (persp-parameters persp)
            (push (cons param-name value) params)))))
(define-obsolete-function-alias 'set-persp-parameter 'persp-set-parameter "persp-mode 4.0.0")

(cl-defun persp-parameter (param-name &optional (persp (persp-get-current)))
  (alist-get param-name (persp-parameters persp)))

(cl-defun persp-delete-parameter (param-name &optional (persp (persp-get-current)))
  (when (and (not (null param-name)) (symbolp param-name))
    (setf (persp-parameters persp)
          (delq (assq param-name (persp-parameters persp))
                (persp-parameters persp)))))
(define-obsolete-function-alias 'delete-persp-parameter 'persp-delete-parameter "persp-mode 4.0.0")

(defun persp--buffer-prop-get-cons (buf key)
  (let ((buf-props (gethash buf persp-buffer-props-hash)))
    (when buf-props
      (assq key buf-props))))

(defun persp--buffer-prop-set (buf key val)
  (let* ((buf-props (gethash buf persp-buffer-props-hash))
         (cons (assq key buf-props)))
    (if cons
        (setf (cdr cons) val)
      (setq cons (cons key val))
      (push cons buf-props)
      (puthash buf buf-props persp-buffer-props-hash))))

(defun persp--buffer-prop-delete (buf key)
  (let* ((buf-props (gethash buf persp-buffer-props-hash))
         (cons (assq key buf-props)))
    (when (and buf-props cons)
      (puthash buf
               (cl-delete cons buf-props :count 1)
               persp-buffer-props-hash))))

(defun persp--buffer-in-persps (buf)
  (cdr (persp--buffer-prop-get-cons buf 'persp-buffer-in-persps)))

(defun persp--buffer-in-persps-set (buf persps)
  (persp--buffer-prop-set buf 'persp-buffer-in-persps persps))

(defun persp--buffer-in-persps-add (buf persp)
  (persp--buffer-in-persps-set
   buf (cons persp (persp--buffer-in-persps buf))))

(defun persp--buffer-in-persps-remove (buf persp)
  (persp--buffer-in-persps-set
   buf (cl-delete persp (persp--buffer-in-persps buf) :count 1)))



;; Used in mode defenition:

(defun persp-mode-restore-and-remove-from-make-frame-hook (&optional frame)
  (if (or *persp-pretend-switched-off* (not (persp-frame-good-p frame)))
      t
    (remove-hook 'after-make-frame-functions
                 #'persp-mode-restore-and-remove-from-make-frame-hook)
    (if (> persp-auto-resume-time 0)
        (run-at-time
         persp-auto-resume-time nil
         (lambda ()
           (remove-hook 'find-file-hook
                        #'persp-special-last-buffer-make-current)
           (when (> persp-auto-resume-time 0)
             (condition-case-unless-debug err
                 (persp-load-state-from-file)
               (error
                (message
                 "[persp-mode] Error: Can not autoresume perspectives -- %S"
                 err)))
             (when (persp-get-buffer-or-null persp-special-last-buffer)
               (persp-switch-to-buffer persp-special-last-buffer)))))
      (remove-hook 'find-file-hook
                   #'persp-special-last-buffer-make-current))))

(defun persp-asave-on-exit (&optional interactive-query opt)
  (when (null opt)
    (setq opt 0))
  (if (> persp-auto-save-opt opt)
      (condition-case-unless-debug err
          (persp-save-state-to-file)
        (error
         (message "[persp-mode] Error: Can not autosave perspectives -- %S"
                  err)
         (when (or noninteractive
                   (progn
                     (when (null (persp-frame-list-without-daemon))
                       (make-frame))
                     (null (persp-frame-list-without-daemon))))
           (setq interactive-query nil))
         (if interactive-query
             (yes-or-no-p
              "persp-mode can not automatically save perspectives, do you want to exit anyway?")
           t)))
    t))
(defun persp-kill-emacs-h ()
  (when (and persp-mode (not *persp-pretend-switched-off*))
    (unless (memq #'persp-mode-restore-and-remove-from-make-frame-hook
                  after-make-frame-functions)
      (persp-asave-on-exit nil))))

(defun persp-kill-emacs-query-function ()
  (if (and persp-mode (not *persp-pretend-switched-off*))
      (unless (memq #'persp-mode-restore-and-remove-from-make-frame-hook
                    after-make-frame-functions)
        (when (persp-asave-on-exit t)
          (remove-hook 'kill-emacs-hook #'persp-kill-emacs-h)
          t))
    t))

(defun persp-special-last-buffer-make-current ()
  (unless *persp-pretend-switched-off*
    (setq persp-special-last-buffer (current-buffer))))



;; Auto persp functions:

(defun persp-auto-persp-parameters (name)
  (cdr (assoc name persp-auto-persp-alist)))
(defun persp--auto-persp-pickup-buffer (a-p-def buffer)
  (let ((action (alist-get :main-action a-p-def)))
    (when (functionp action)
      (funcall action buffer))))
(defun persp-auto-persp-pickup-bufferlist-for (name bufferlist)
  (let ((a-p-def (persp-auto-persp-parameters name)))
    (when a-p-def
      (mapc (apply-partially #'persp--auto-persp-pickup-buffer a-p-def)
            bufferlist))))
(defun persp-auto-persps-pickup-bufferlist (bufferlist)
  (mapc
   (lambda (name) (persp-auto-persp-pickup-bufferlist-for name bufferlist))
   (mapcar #'car persp-auto-persp-alist)))
(defun persp-auto-persp-pickup-buffers-for (name)
  (persp-auto-persp-pickup-bufferlist-for name
                                          (funcall persp-buffer-list-function)))
(defun persp-auto-persps-pickup-buffers ()
  (interactive)
  (persp-auto-persps-pickup-bufferlist (funcall persp-buffer-list-function)))

(defun persp-buffer-match-auto-persp-p (buffer-or-name)
  (let ((buffer (persp-get-buffer-or-null buffer-or-name))
        pred)
    (car-safe
     (cl-find-if (lambda (a-p-def)
                   (and (setq pred (alist-get :generated-predicate a-p-def))
                        (funcall pred buffer)))
                 persp-auto-persp-alist
                 :key #'cdr))))
(defun persp-auto-persps-for-buffer (buffer-or-name)
  (let ((buffer (persp-get-buffer-or-null buffer-or-name)))
    (cl-remove-if (lambda (pred) (funcall pred buffer))
                  persp-auto-persp-alist
                  :key (lambda (a-p-cons)
                         (alist-get :generated-predicate (cdr a-p-cons))))))

(defun persp-auto-persp-activate-hooks (name)
  (let ((hooks
         (alist-get :hooks
                    (persp-auto-persp-parameters name))))
    (mapc (lambda (hook-cons)
            (add-hook (car hook-cons) (cdr hook-cons)))
          hooks)))
(defun persp-auto-persp-deactivate-hooks (name)
  (let ((hooks
         (alist-get :hooks
                    (persp-auto-persp-parameters name))))
    (mapc (lambda (hook-cons)
            (remove-hook (car hook-cons) (cdr hook-cons)))
          hooks)))
(defun persp-auto-persps-activate-hooks ()
  (mapc #'persp-auto-persp-activate-hooks
        (mapcar #'car persp-auto-persp-alist)))
(defun persp-auto-persps-deactivate-hooks ()
  (mapc #'persp-auto-persp-deactivate-hooks
        (mapcar #'car persp-auto-persp-alist)))

(defsubst persp--generate-predicate-loop-any-all
  (items-list condition &rest body)
  (if items-list
      (let (all noquote)
        (setq items-list
              (cl-typecase items-list
                (function (list items-list))
                (list (if (persp-regexp-p items-list) (list items-list) items-list))
                (t (list items-list))))
        (setq noquote (eq :noquote (car items-list)))
        (when noquote (setq items-list (cadr items-list)))
        (when (listp items-list)
          (setq all (eq :all (car items-list)))
          (when all (pop items-list))
          (unless noquote (setq items-list `',items-list)))
        (let* ((cnd `(cl-member-if
                      (lambda (item)
                        (setq cond-result
                              ,(if all
                                   `(not ,condition)
                                 condition)))
                      ,items-list)))
          `(let (cond-result)
             (when ,(if all `(not ,cnd) cnd)
               ,@body))))
    `(let (cond-result)
       ,@body)))
(cl-defun persp--generate-buffer-predicate
    (&key
     buffer-name file-name mode mode-name minor-mode minor-mode-name predicate
     (true-value (if predicate 'cond-result t))
     &allow-other-keys)
  (let ((predicate-body true-value))
    (when predicate
      (setq predicate-body
            (persp--generate-predicate-loop-any-all
             predicate '(apply item buffer rest-args) predicate-body)))
    (when file-name
      (setq predicate-body
            (persp--generate-predicate-loop-any-all
             file-name '(persp-string-match-p item (buffer-file-name buffer))
             predicate-body)))
    (when buffer-name
      (setq predicate-body
            (persp--generate-predicate-loop-any-all
             buffer-name '(persp-string-match-p item (buffer-name buffer))
             predicate-body)))
    (when minor-mode-name
      (setq predicate-body
            (persp--generate-predicate-loop-any-all
             minor-mode-name
             `(let ((regexp item))
                ,(persp--generate-predicate-loop-any-all
                  '(:noquote minor-mode-alist)
                  '(persp-string-match-p regexp (format-mode-line item))
                  t))
             predicate-body)))
    (when minor-mode
      (setq predicate-body
            (persp--generate-predicate-loop-any-all
             minor-mode
             `(cond
               ((symbolp item) (bound-and-true-p item))
               ((persp-regexp-p item) (let ((regexp item))
                                        ,(persp--generate-predicate-loop-any-all
                                          '(:noquote minor-mode-list)
                                          '(and
                                            (bound-and-true-p item)
                                            (persp-string-match-p regexp item))
                                          t)))
               (t nil))
             predicate-body)))

    (when mode-name
      (setq predicate-body
            (persp--generate-predicate-loop-any-all
             mode-name '(persp-string-match-p item (format-mode-line mode-name))
             predicate-body)))
    (when mode
      (setq predicate-body
            (persp--generate-predicate-loop-any-all
             mode '(cond
                    ((symbolp item) (eq item major-mode))
                    ((persp-regexp-p item)
                     (persp-string-match-p item (symbol-name major-mode)))
                    (t nil))
             predicate-body)))
    (eval `(lambda (buffer &rest rest-args)
             (when (buffer-live-p buffer)
               (with-current-buffer buffer ,predicate-body))))))

(defun persp--auto-persp-default-on-match (state)
  (persp-add-buffer (alist-get 'buffer state)
                    (alist-get 'persp state)
                    nil nil)
  state)
(defun persp--auto-persp-default-after-match (state)
  (let ((persp (alist-get 'persp state))
        (noauto (alist-get :noauto state))
        (weak (alist-get :weak state))
        (parameters (alist-get :parameters state)))
    (persp-normalize-persp-arg*)
    (unless (persp-nil-p persp)
      (when (not noauto)
        (setf (persp-auto persp) t))
      (when weak
        (setf (persp-weak persp) t))
      (persp-modify-parameters parameters persp)))
  (let ((persp-name (alist-get 'persp-name state))
        (switch (alist-get :switch state)))
    (persp-unhide persp-name)
    (cl-case switch
      ((nil) nil)
      (window (persp-window-switch persp-name))
      (frame (persp-frame-switch persp-name))
      (t (persp-switch persp-name)))
    (when switch
      (persp-switch-to-buffer (alist-get 'buffer state))))
  state)

;;;###autoload
(cl-defun persp-def-auto-persp
    (name &rest keyargs
          &key buffer-name file-name mode mode-name minor-mode minor-mode-name
          predicate hooks dyn-env get-name get-buffer get-persp
          switch parameters noauto weak user-data
          on-match after-match dont-pick-up-buffers delete)

  (ignore minor-mode minor-mode-name switch parameters noauto weak user-data)

  (if delete
      (let ((ap-cons (assoc name persp-auto-persp-alist)))
        (persp-auto-persp-deactivate-hooks name)
        (setq persp-auto-persp-alist
              (delq ap-cons persp-auto-persp-alist)))

    (let (auto-persp-parameters
          generated-predicate generated-hook
          main-action)

      (cl-loop for (key val) on keyargs by #'cddr
               when (and val (not (or (eq key :dont-pick-up-buffers))))
               do (push
                   (cons key
                         (if (and (functionp val)
                                  (not (or (eq key :mode) (eq key :minor-mode)))
                                  (null (byte-code-function-p val)))
                             val ;;(byte-compile val)
                           val))
                   auto-persp-parameters))

      (unless get-name
        (push (cons :get-name
                    (byte-compile
                     `(lambda (state)
                        (push (cons 'persp-name ,name) state)
                        state)))
              auto-persp-parameters))

      (unless get-persp
        (push (cons :get-persp
                (lambda (state)
                  (let ((name (alist-get 'persp-name state)))
                    (when name
                      (push (cons 'persp (persp-add-new name))
                            state)))
                  state))
              auto-persp-parameters))

      (unless get-buffer
        (push (cons :get-buffer
                (lambda (state)
                  (push (cons 'buffer (current-buffer))
                        state)
                  state))
              auto-persp-parameters))

      (unless on-match
        (push (cons :on-match
                    #'persp--auto-persp-default-on-match)
              auto-persp-parameters))

      (unless after-match
        (push (cons :after-match
                    #'persp--auto-persp-default-after-match)
              auto-persp-parameters))

      (when (or (null hooks) (not (consp hooks)))
        (unless hooks
          (setq hooks
                (when minor-mode
                  (intern (concat (symbol-name minor-mode)
                                  "-hook")))))
        (unless hooks
          (setq hooks
                (cond
                 (mode
                  (intern (concat (symbol-name mode)
                                  "-hook")))
                 (minor-mode
                  (intern (concat (symbol-name minor-mode)
                                  "-hook")))
                 ((or mode-name predicate buffer-name)
                  'after-change-major-mode-hook)
                 (file-name 'find-file-hook)
                 (t 'after-change-major-mode-hook))))

        (when (and hooks (not (consp hooks)))
          (setq hooks (list hooks)))

        (push (cons :hooks hooks) auto-persp-parameters))

      (setq generated-predicate
            (apply #'persp--generate-buffer-predicate
                   (if predicate
                       keyargs
                     (cons :true-value (cons '(car rest-args) keyargs)))))
      (push (cons :generated-predicate generated-predicate)
            auto-persp-parameters)

      (setq main-action
            (eval
             `(lambda (&optional buffer hook hook-args)
                (when (and persp-mode (not *persp-pretend-switched-off*))
                  (let (,@dyn-env)
                    (let* ((state (copy-alist
                                   (persp-auto-persp-parameters ,name))))
                      (push (cons 'hook hook) state)
                      (push (cons 'hook-args hook-args) state)
                      (if buffer
                          (push (cons 'buffer buffer) state)
                        (let ((get-buffer
                               (alist-get :get-buffer state)))
                          (setq state (funcall get-buffer state))))
                      (when
                          (setq state
                                (funcall (alist-get :generated-predicate state)
                                         (alist-get 'buffer state) state))
                        (with-current-buffer (alist-get 'buffer state)
                          (let ((get-name
                                 (alist-get :get-name state)))
                            (setq state (funcall get-name state)))
                          (let ((get-persp
                                 (alist-get :get-persp state)))
                            (setq state (funcall get-persp state)))
                          (let ((on-match (alist-get :on-match state)))
                            (when on-match
                              (setq state (funcall on-match state))
                              (let ((after-match (alist-get :after-match state)))
                                (when after-match
                                  (setq state (funcall after-match state))))))))))))))
      (push (cons :main-action main-action) auto-persp-parameters)

      (when hooks
        (let ((aparams-hooks (assq :hooks auto-persp-parameters)))
          (dolist (hook hooks)
            (setq generated-hook
                  (with-no-warnings
                    (let ((warning-minimum-level :emergency)
                          byte-compile-warnings)
                      (byte-compile
                       `(lambda (&rest hook-args)
                          (funcall (with-no-warnings ',main-action)
                                   nil ',hook hook-args))))))
            (setcdr aparams-hooks (delete hook (cdr aparams-hooks)))
            (push (cons hook generated-hook) (cdr aparams-hooks)))))

      (let ((auto-persp-definition (assoc name persp-auto-persp-alist)))
        (if auto-persp-definition
            (progn
              (persp-auto-persp-deactivate-hooks name)
              (setcdr auto-persp-definition auto-persp-parameters))
          (setq auto-persp-definition (cons name auto-persp-parameters))
          (push auto-persp-definition persp-auto-persp-alist)))

      (persp-auto-persp-activate-hooks name)

      (unless (or dont-pick-up-buffers *persp-pretend-switched-off*)
        (persp-auto-persp-pickup-buffers-for name)))))

;;;###autoload
(define-obsolete-function-alias 'def-auto-persp 'persp-def-auto-persp
  "persp-mode 2.9.6")



;; Custom save/load functions:

;;;###autoload
(cl-defun persp-def-buffer-save/load
    (&rest
     keyargs
     &key buffer-name file-name mode mode-name minor-mode minor-mode-name
     predicate tag-symbol save-vars save-function load-function after-load-function
     mode-restore-function
     append)

  (ignore buffer-name file-name minor-mode minor-mode-name predicate)

  (let ((generated-save-predicate
         (apply #'persp--generate-buffer-predicate keyargs))
        save-body load-fun)
    (when save-vars
      (unless (listp save-vars) (setq save-vars (list save-vars)))
      (when (and (or mode mode-name) (not (memq 'major-mode save-vars)))
        (push 'major-mode save-vars)))
    (unless tag-symbol (setq tag-symbol 'def-buffer-with-vars))

    (setq save-body
          `(let ((vars-list
                  (with-current-buffer buffer
                    (cl-delete-if-not
                     (lambda (lvar)
                       (and
                        ,(persp--generate-predicate-loop-any-all
                          save-vars
                          '(if (persp-regexp-p item)
                               (persp-string-match-p item
                                                     (symbol-name lvar))
                             (eq item lvar))
                          t)
                        (persp-elisp-object-readable-p
                         (symbol-value lvar))))
                     (buffer-local-variables)
                     :key #'car-safe))))
             ,(if save-function
                  `(funcall (with-no-warnings ',save-function)
                            buffer ',tag-symbol vars-list)
                `(list ',tag-symbol (buffer-name buffer) vars-list)))
          save-body `(when (funcall (with-no-warnings ',generated-save-predicate)
                                    buffer)
                       ,save-body))

    (setq load-fun
          `(lambda (savelist)
             (cl-destructuring-bind
                 (buffer-name vars-list &rest _rest) (cdr savelist)
               (let ((buf-file (alist-get 'buffer-file-name vars-list))
                     (buf-mmode (alist-get 'major-mode vars-list)))
                 ,(when mode-restore-function
                    `(push (cons 'persp-load-buffer-mode-restore-function
                                 (with-no-warnings ',mode-restore-function))
                           vars-list))
                 (let ((persp-loaded-buffer
                        (persp-buffer-from-savelist
                         (list 'def-buffer buffer-name buf-file buf-mmode
                               (list (cons 'local-vars vars-list)))))
                       (persp-after-load-function (with-no-warnings
                                                    ',after-load-function))
                       persp-after-load-lambda)
                   (when (and persp-loaded-buffer persp-after-load-function)
                     (setq persp-after-load-lambda
                           (lambda (&rest pall-args)
                             (apply persp-after-load-function
                                    persp-loaded-buffer pall-args)
                             (remove-hook 'persp-after-load-state-functions
                                          persp-after-load-lambda)))
                     (add-hook 'persp-after-load-state-functions
                               persp-after-load-lambda 99))
                   persp-loaded-buffer)))))

    (add-hook 'persp-save-buffer-functions
              (eval `(lambda (buffer) ,save-body)) append)
    (add-hook 'persp-load-buffer-functions
              (eval
               `(lambda (savelist)
                  (when (eq (car savelist) ',tag-symbol)
                    (let ((default-load-fun (with-no-warnings ',load-fun)))
                      ,(if load-function
                           `(funcall (with-no-warnings ',load-function)
                                     savelist default-load-fun
                                     (with-no-warnings ',after-load-function))
                         `(funcall (eval default-load-fun t) savelist))))))
              append)))

;;;###autoload
(define-obsolete-function-alias
  'def-persp-buffer-save/load 'persp-def-buffer-save/load
  "persp-mode 2.9.6")



;; Mode itself:

(defun persp-mode-setup-hooks ()
  (add-hook 'find-file-hook              #'persp-add-or-not-on-find-file)
  (add-hook 'kill-buffer-query-functions #'persp-kill-buffer-query-function 100)
  (add-hook 'kill-buffer-hook            #'persp-kill-buffer-h 99)
  (add-hook 'before-make-frame-hook      #'persp-before-make-frame)
  (add-hook 'after-make-frame-functions  #'persp-init-new-frame)
  (add-hook 'delete-frame-functions      #'persp-delete-frame)
  (add-hook 'kill-emacs-query-functions  #'persp-kill-emacs-query-function)
  (add-hook 'kill-emacs-hook             #'persp-kill-emacs-h)
  (add-hook 'server-switch-hook          #'persp-server-switch)
  (add-hook 'after-change-major-mode-hook #'persp-after-change-major-mode-h 99)
  (if (boundp 'window-state-change-functions)
      (add-hook 'window-state-change-functions #'persp-update-frame-lighter)
    (add-hook 'window-configuration-change-hook #'persp-update-frame-lighter))

  (persp-set-ido-hooks persp-set-ido-hooks)
  (persp-set-read-buffer-function persp-set-read-buffer-function)

  ;; TODO: isn't `persp-interactive-completion-system' deprecated ?
  (persp-update-completion-system persp-interactive-completion-system)

  (persp-auto-persps-activate-hooks)

  (when (fboundp 'tabbar-mode)
    (setq tabbar-buffer-list-function #'persp-buffer-list)))

(defun persp-mode-remove-hooks ()
  (remove-hook 'find-file-hook               #'persp-add-or-not-on-find-file)
  (remove-hook 'kill-buffer-query-functions  #'persp-kill-buffer-query-function)
  (remove-hook 'kill-buffer-hook             #'persp-kill-buffer-h)
  (remove-hook 'before-make-frame-hook       #'persp-before-make-frame)
  (remove-hook 'after-make-frame-functions   #'persp-init-new-frame)
  (remove-hook 'delete-frame-functions       #'persp-delete-frame)
  (remove-hook 'kill-emacs-query-functions   #'persp-kill-emacs-query-function)
  (remove-hook 'kill-emacs-hook              #'persp-kill-emacs-h)
  (remove-hook 'server-switch-hook           #'persp-server-switch)
  (remove-hook 'after-change-major-mode-hook #'persp-after-change-major-mode-h)
  (if (boundp 'window-state-change-functions)
      (remove-hook 'window-state-change-functions #'persp-update-frame-lighter)
    (remove-hook 'window-configuration-change-hook #'persp-update-frame-lighter))

  (persp-set-ido-hooks)
  (persp-set-read-buffer-function)
  (persp-update-frames-buffer-predicate t)
  (persp-update-completion-system nil t)

  (persp-auto-persps-deactivate-hooks)

  (when (fboundp 'tabbar-mode)
    (setq tabbar-buffer-list-function #'tabbar-buffer-list)))

(defun persp-activate-kill-buffer-advice ()
  (advice-add #'kill-buffer :around #'persp-kill-buffer-around-adv))

(defun persp-deactivate-kill-buffer-advice ()
  (advice-remove #'kill-buffer #'persp-kill-buffer-around-adv))

(defun persp-activate-make-indirect-buffer-advice ()
  (advice-add #'make-indirect-buffer :around #'persp-make-indirect-buffer-around-adv))

(defun persp-deactivate-make-indirect-buffer-advice ()
  (advice-remove #'make-indirect-buffer #'persp-make-indirect-buffer-around-adv))


;;;###autoload
(define-minor-mode persp-mode
  "Toggle the persp-mode.
When active, keeps track of multiple \\='perspectives\\=',
named collections of buffers and window configurations.
Here is a keymap of this minor mode:
\\{persp-mode-map}"
  :require    'persp-mode
  :group      'persp-mode
  :keymap     persp-mode-map
  :init-value nil
  :global     t
  :lighter    (:eval persp-lighter)
  (if persp-mode
      (when (or (eq 'persp-force-restart persp-mode) (null *persp-hash*))
        (setq persp-nil-persp (persp--make :name persp-nil-name :weak t))
        (setq persp-special-last-buffer nil)
        (add-hook 'find-file-hook #'persp-special-last-buffer-make-current)

        (setq *persp-hash* (make-hash-table :test #'equal :size 10))
        (setq persp-buffer-props-hash (make-hash-table :test #'eq :size 10))
        (setq persp-names-cache nil)

        (push '(persp . writable) window-persistent-parameters)

        (persp-add-minor-mode-menu)
        (persp-add-new persp-nil-name)

        (persp-mode-setup-hooks)

        (when persp-use-kill-buffer-advice
          (persp-activate-kill-buffer-advice))
        (when persp-use-make-indirect-buffer-advice
          (persp-activate-make-indirect-buffer-advice))

        (condition-case-unless-debug err
            (mapc #'persp-init-frame (persp-frame-list-without-daemon))
          (error
           (message "[persp-mode] Error: Can not initialize frame -- %S"
                    err)))

        (if (or noninteractive
                (and (daemonp)
                     (null (cdr (frame-list)))
                     (eq (selected-frame) terminal-frame)))
            (add-hook 'after-make-frame-functions
                      #'persp-mode-restore-and-remove-from-make-frame-hook
                      99)
          (persp-mode-restore-and-remove-from-make-frame-hook)))

    (run-hooks 'persp-mode-deactivated-hook)
    (if (memq #'persp-mode-restore-and-remove-from-make-frame-hook
              after-make-frame-functions)
        (remove-hook 'after-make-frame-functions
                     #'persp-mode-restore-and-remove-from-make-frame-hook)
      (persp-asave-on-exit t 1))

    (persp-mode-remove-hooks)

    (when persp-use-kill-buffer-advice
      (persp-deactivate-kill-buffer-advice))
    (when persp-use-make-indirect-buffer-advice
      (persp-deactivate-make-indirect-buffer-advice))

    (setq window-persistent-parameters
          (delq (assq 'persp window-persistent-parameters)
                window-persistent-parameters))

    (setq persp-indirect-buffers-to-restore nil)
    ;; TODO: do it properly -- remove buffers, kill perspectives
    (setq *persp-hash* nil)
    (setq persp-buffer-props-hash nil)
    (persp-update-names-cache nil t)))



;; Hooks:

(defun persp--kill-buffer-query-function-foreign-check (persp buf)
  (let ((opt persp-kill-foreign-buffer-behaviour))
    (cond
     ((cl-find opt '(nil kill dont-ask-weak ask))
      (if (cl-case opt
            ((kill nil) t)
            (dont-ask-weak (persp-buffer-free-p buf t))
            (t (persp-buffer-filtered-out-p buf)))
          'kill
        (let ((curwin (selected-window))
              (prompt (format "You are going to kill a buffer(%s) \
which is not in the current(%s) perspective. It will be removed from \
%s perspectives and then killed.\nWhat do you really want to do? "
                              (buffer-name buf)
                              (persp-name persp)
                              (mapcar #'persp-name
                                      (persp--buffer-in-persps buf)))))
          (cl-macrolet
              ((clwin (w)
                      `(run-at-time 1 nil (lambda (ww)
                                            (when (window-live-p ww)
                                              (delete-window ww)))
                                    ,w))
               (swb (b w)
                    `(run-at-time
                      1 nil
                      (lambda (bb ww)
                        (persp-set-another-buffer-for-window bb ww))
                      ,b ,w)))
            (cl-destructuring-bind (char &rest rest)
                (let ((variants
                       (list '(?q "do nothing")
                             '(?k "kill")
                             '(?K "kill and close window")
                             '(?c "close window")
                             '(?s "switch to another buffer")))
                      (cwin (selected-window)))
                  (when (minibuffer-window-active-p cwin)
                    (setq cwin (minibuffer-selected-window)))
                  (unless (eq buf (window-buffer cwin))
                    (setq variants
                          (delq (assq ?K variants)
                                (delq (assq ?c variants)
                                      (delq (assq ?s variants) variants)))))
                  (read-multiple-choice prompt variants))
              (cl-case char
                ((?q ?\C-g ?\C-\[) nil)
                (?k 'kill)
                (?K (clwin curwin) 'kill)
                (?c (clwin curwin) nil)
                (?s (swb buf curwin) nil)
                (t t)))))))
     ((functionp opt) (funcall opt)))))

(defun persp-kill-buffer-query-function ()
  "This must be the last hook in the `kill-buffer-query-functions'.
Otherwise if next function in the list returns nil -- the buffer will not be
killed, but just removed from a perspective(s)."
  (if (and persp-mode (not *persp-pretend-switched-off*))
      (let* ((buffer (current-buffer))
             (buffer-persps (persp--buffer-in-persps buffer)))
        (if buffer-persps
            (let* ((persp (persp-get-current))
                   (foreign-check
                    (if (or (persp-nil-p persp)
                            (not (persp-contain-buffer-p buffer persp)))
                        (persp--kill-buffer-query-function-foreign-check
                         persp buffer)
                      'not-foreign)))
              (cl-case foreign-check
                (kill
                 (let (persp-autokill-buffer-on-remove)
                   (persp--remove-buffer-2 nil buffer))
                 t)
                (not-foreign
                 (if (persp-buffer-in-other-p* buffer persp)
                     (progn (persp--remove-buffer-2 persp buffer)
                            nil)
                   (if (or (not (buffer-live-p buffer))
                           (persp--buffer-in-persps buffer))
                       nil
                     t)
                   t))
                (t
                 nil)))
          t))
    t))

(defun persp-kill-buffer-h ()
  (let ((buffer (current-buffer)))
    (when (and persp-mode (not *persp-pretend-switched-off*)
               (persp--buffer-in-persps buffer))
      (let (persp-autokill-buffer-on-remove
            (persp-when-remove-buffer-switch-to-other-buffer
             (unless persp-set-frame-buffer-predicate
               persp-when-remove-buffer-switch-to-other-buffer)))
        (persp--remove-buffer-2 nil buffer)
        (unless persp-use-kill-buffer-advice
          (remhash buffer persp-buffer-props-hash))))))

(defun persp--remove-dead-buffers (persp &optional bufname)
  (persp-normalize-persp-arg*)
  (unless (persp-nil-p persp)
    (setf (persp-buffers persp)
          (cl-delete-if-not
           (lambda (b)
             (or (buffer-live-p b)
                 (and (message "[persp-mode] Debug: dead buffer %sremoved from %S."
                               (or (and bufname (concat "\"" bufname "\" "))
                                   "")
                               (persp-name persp))
                      (persp--buffer-in-persps-remove b persp)
                      nil)))
           (persp-buffers persp)))))

(defun persp-kill-buffer-around-adv (kb-f &optional buffer-or-name)
  (if (and persp-mode (not *persp-pretend-switched-off*))
      (let* ((buffer (if buffer-or-name
                         (get-buffer buffer-or-name)
                       (current-buffer)))
             (bname (buffer-name buffer))
             (bpersps (persp--buffer-in-persps buffer))
             (kb-ret (funcall kb-f buffer-or-name)))
        (when kb-ret
          (mapc (lambda (p) (persp--remove-dead-buffers p bname)) bpersps)
          (remhash buffer persp-buffer-props-hash))
        kb-ret)
    (funcall kb-f buffer-or-name)))

(defun persp-make-indirect-buffer-around-adv
    (mib-f b-buf name &optional clone inhibit-buffer-hooks)
  (if (and persp-mode (not *persp-pretend-switched-off*))
      (let ((persp (persp-get-current))
            (buf (funcall mib-f b-buf name clone inhibit-buffer-hooks)))
        (when (and (buffer-live-p buf)
                   (not (or (persp-nil-p persp)
                            (persp-parameter 'not-auto-add-buffers persp))))
          (persp-add-buffer buf persp nil))
        buf)
    (funcall mib-f b-buf name clone inhibit-buffer-hooks)))

(defun persp--restore-buffer-on-find-file ()
  (when (buffer-live-p persp-special-last-buffer)
    (set-window-buffer (or (get-buffer-window) (selected-window))
                       persp-special-last-buffer))
  (setq persp-special-last-buffer nil)
  (remove-hook 'window-configuration-change-hook
               #'persp--restore-buffer-on-find-file))
(defun persp-add-or-not-on-find-file ()
  (unless *persp-pretend-switched-off*
    (let ((no-select
           (not (funcall persp-backtrace-frame-function 0 'find-file)))
          (persp (persp-get-current)))
      (and
       (not (persp-nil-p persp))
       (not (persp-parameter 'not-auto-add-buffers persp))
       (cl-case persp-add-buffer-on-find-file
         ((nil) nil)
         (if-not-autopersp
          (let ((ret (not (persp-buffer-match-auto-persp-p (current-buffer)))))
            (unless (or ret no-select)
              (setq persp-special-last-buffer (window-buffer))
              (add-hook 'window-configuration-change-hook
                        #'persp--restore-buffer-on-find-file))
            ret))
         (add-but-not-switch-if-autopersp
          (when (and (not no-select)
                     (persp-buffer-match-auto-persp-p (current-buffer)))
            (setq no-select t)
            (setq persp-special-last-buffer (window-buffer))
            (add-hook 'window-configuration-change-hook
                      #'persp--restore-buffer-on-find-file))
          t)
         (t t))
       (persp-add-buffer
        (current-buffer) persp (not no-select) nil)))))

(defun persp-after-change-major-mode-h ()
  (unless *persp-pretend-switched-off*
    (let ((buf (current-buffer))
          (persp (persp-get-current))
          (opt persp-add-buffer-on-after-change-major-mode))
      (persp-find-and-set-persps-for-buffer buf)
      (when
          (and
           (not (persp-nil-p persp))
           (not (persp-parameter 'not-auto-add-buffers persp))
           (cond
            ((cl-find opt '(nil t free))
             (cl-case opt
               ((nil) nil)
               (free (persp-buffer-free-p buf))
               (t opt)))
            ((functionp opt) (funcall opt buf)))
           (not
            (persp-buffer-filtered-out-p
             buf persp-add-buffer-on-after-change-major-mode-filter-functions)))
        (persp-add-buffer buf persp nil nil)))))

(defun persp-server-switch ()
  (unless *persp-pretend-switched-off*
    (condition-case-unless-debug err
        (let* ((frame (selected-frame))
               (persp-server-switch-hook (frame-parameter
                                          frame 'persp-server-switch-hook)))
          (when persp-server-switch-hook
            (unless (string-match-p "^.*magit.*$" (symbol-name last-command))
              (funcall persp-server-switch-hook frame))
            (set-frame-parameter frame 'persp-server-switch-hook nil)))
      (error
       (message "[persp-mode] Error: error in server-switch-hook -- %S"
                err)))))



;; Misc funcs:

(cl-defun persp-get-by-name
    (name &optional (phash *persp-hash*) (default persp-not-persp))
  (gethash name phash default))

(cl-defun persp-with-name-exists-p (name &optional (phash *persp-hash*))
  (persp-p (persp-get-by-name name phash)))

(cl-defun persp-get-by-name-and-exists (name &optional (phash *persp-hash*))
  (let ((persp (persp-get-by-name name phash)))
    (cons (persp-p persp) persp)))
(define-obsolete-function-alias
  'persp-by-name-and-exists 'persp-get-by-name-and-exists "persp-mode 3.9.0")

(cl-defun persp-gen-random-name (&optional name (phash *persp-hash*))
  (unless name (setq name (number-to-string (random))))
  (cl-macrolet ((namegen () `(format "%s:%s" name (random 9))))
    (cl-do ((nname name (namegen)))
        ((not (persp-with-name-exists-p nname phash))
         nname))))

(let (update-lighter-throttle-timer frames-to-update)
  (defun persp-update-frame-lighter (&optional f)
    (unless f (setq f (selected-frame)))
    (when (persp-frame-good-p f)
      (unless (memq f frames-to-update)
        (push f frames-to-update))
      (if (timerp update-lighter-throttle-timer)
          (progn
            (timer-set-time update-lighter-throttle-timer (time-add nil 1))
            ;; (timer-activate update-lighter-throttle-timer)
            )
        (setq
         update-lighter-throttle-timer
         (run-with-timer
          1 nil
          (lambda ()
            (unwind-protect
                (progn
                  (mapc
                   (lambda (f)
                     (when (frame-live-p f)
                       (let ((lighter
                              (let* ((persp-cons (persp-frame-window-persp-param-assq f))
                                     (persp (cdr persp-cons)))
                                (if persp
                                    (format
                                     (propertize
                                      " #%.5s"
                                      'face
                                      (if (persp-nil-p persp)
                                          'persp-face-lighter-nil-persp
                                        (if (persp-contain-buffer-p (current-buffer) persp)
                                            'persp-face-lighter-default
                                          'persp-face-lighter-buffer-not-in-persp)))
                                     (persp-name persp))
                                  " #~"))))
                         (set-frame-parameter f 'persp-lighter lighter))))
                   frames-to-update)
                  (setq frames-to-update nil))
              (force-mode-line-update)
              (setq update-lighter-throttle-timer nil)))))))))

(defun persp-is-frame-daemons-frame (f)
  (and (fboundp 'daemonp) (daemonp) (eq f terminal-frame)))

(defun persp-frame-good-p (&optional f)
  (not (run-hook-with-args-until-success 'persp-filter-frame-functions
                                         (or f (selected-frame)))))

(defun persp-frame-list-without-daemon ()
  "Return a list of frames without the daemon's frame."
  (filtered-frame-list #'persp-frame-good-p))

(defun persp-set-for-frame (persp &optional frame)
  (set-frame-parameter frame 'persp persp))
(define-obsolete-function-alias 'set-frame-persp 'persp-set-for-frame "persp-mode 4.0.0")

(defun persp-frame-window-persp-param-assq (&optional frame-or-window)
  (let ((paramf (cond ((framep frame-or-window) #'frame-parameters)
                      ((windowp frame-or-window) #'window-parameters)
                      (t nil))))
    (when paramf
      (assq 'persp (funcall paramf frame-or-window)))))

(defun persp-of-frame (&optional frame)
  (frame-parameter frame 'persp))
(define-obsolete-function-alias 'get-frame-persp 'persp-of-frame "persp-mode 4.0.0")

(cl-defun persp-names (&optional (phash *persp-hash*) (reverse t))
  (let (ret)
    (maphash (lambda (k _p)
               (push k ret))
             phash)
    (if reverse
        (nreverse ret)
      ret)))

(defun persp-set-for-window* (persp-name &optional window)
  (when persp-name
    (set-window-parameter window 'persp persp-name)))
(define-obsolete-function-alias 'set-window-persp* 'persp-set-for-window* "persp-mode 4.0.0")

(defun persp-of-window* (&optional window)
  (window-parameter window 'persp))
(define-obsolete-function-alias 'get-window-persp* 'persp-of-window* "persp-mode 4.0.0")

(defun persp-set-for-window (persp &optional window)
  (let ((frame (window-frame window)))
    (if (eq persp (persp-of-frame frame))
        (persp-unset-for-window window)
      (persp-set-for-window* (persp-name persp) window))))
(define-obsolete-function-alias 'set-window-persp 'persp-set-for-window "persp-mode 4.0.0")

(defun persp-set-for-window-p (&optional window)
  (persp-of-window* window))
(define-obsolete-function-alias 'window-persp-set-p 'persp-set-for-window-p "persp-mode 4.0.0")

(defun persp-of-window (&optional window)
  (let ((pn (persp-of-window* window)))
    (when pn
      (cl-destructuring-bind (e . p)
          (persp-get-by-name-and-exists pn)
        (and e p)))))
(define-obsolete-function-alias 'get-window-persp 'persp-of-window "persp-mode 4.0.0")

(defun persp-unset-for-window (&optional window)
  (set-window-parameter window 'persp nil))
(define-obsolete-function-alias 'clear-window-persp 'persp-unset-for-window "persp-mode 4.0.0")

(defun persp-get-current (&optional frame window)
  (unless window (setq window (frame-selected-window frame)))
  (if (persp-set-for-window-p window)
      (persp-of-window window)
    (persp-of-frame frame)))
(define-obsolete-function-alias 'get-current-persp 'persp-get-current "persp-mode 4.0.0")

(defun persp-set-current (persp)
  (if (persp-set-for-window-p)
      (persp-set-for-window persp)
    (persp-set-for-frame persp)))
(define-obsolete-function-alias 'set-current-persp 'persp-set-current "persp-mode 4.0.0")

(defun persp-names-current-frame-fast-ordered ()
  (cl-copy-list persp-names-cache))

;; TODO: remove this
(cl-defsubst persp-names-sorted (&optional (phash *persp-hash*))
  (sort (persp-names phash nil) #'string<))
(make-obsolete 'persp-names-sorted "it will be removed." "persp-mode 2.9.6")

(defun persp-group-by (keyf lst &optional reverse)
  (let (result)
    (mapc (lambda (pd)
            (let* ((key (funcall keyf pd))
                   (kv (assoc key result)))
              (if kv
                  (setcdr kv (cons pd (cdr kv)))
                (push (cons key (list pd)) result))))
          lst)
    (if reverse
        (nreverse
         (mapcar (lambda (gr)
                   (cl-destructuring-bind (key . pd) gr
                     (cons key (nreverse pd))))
                 result))
      result)))

(defun persp-regexp-p (obj)
  (or (stringp obj) (and (consp obj) (stringp (cdr obj)))))
(defun persp-string-match-p (regexp string &optional start)
  (when (and regexp (not (consp regexp)))
    (setq regexp (cons t regexp)))
  (let ((ret (string-match-p (cdr regexp) string start)))
    (if (eq :not (car regexp))
        (not ret)
      ret)))

(cl-defun persp-persps (&optional (phash *persp-hash*) names-regexp reverse)
  (when (and names-regexp (not (consp names-regexp)))
    (setq names-regexp (cons t names-regexp)))
  (let (ret)
    (maphash (lambda (k p)
               (if names-regexp
                   (when (persp-string-match-p names-regexp k)
                     (push p ret))
                 (push p ret)))
             phash)
    (if reverse
        (nreverse ret)
      ret)))

(cl-defun persp-other-not-hidden-persps (&optional persp (phash *persp-hash*))
  (cl-delete-if #'persp-hidden (delq persp (persp-persps phash))))

(cl-defun persp-other-persps-with-buffer-except-nil
    (&optional (buff-or-name (current-buffer)) (persp (persp-get-current))
               (phash *persp-hash*) del-weak)
  (let ((buf (persp-get-buffer-or-null buff-or-name))
        ret)
    (when buf
      (setq ret (cl-delete-if-not
                 (apply-partially #'memq buf)
                 (delq persp
                       (delq persp-nil-persp (persp-persps phash)))
                 :key #'persp-buffers))
      (when del-weak
        (setq ret (cl-delete-if #'persp-weak ret))))
    ret))
(cl-defun persp-other-persps-with-buffer-except-nil*
    (&optional
     (buff-or-name (current-buffer)) (persp (persp-get-current)) del-weak)
  (let ((persps (persp--buffer-in-persps
                 (persp-get-buffer-or-null buff-or-name))))
    (unless (persp-nil-p persp)
      (setq persps (remq persp persps)))
    (when del-weak
      (setq persps (cl-remove-if #'persp-weak persps)))
    persps))

(cl-defun persp-buffer-in-other-p
    (&optional (buff-or-name (current-buffer)) (persp (persp-get-current))
               (phash *persp-hash*) del-weak)
  (persp-other-persps-with-buffer-except-nil buff-or-name persp phash del-weak))
(cl-defun persp-buffer-in-other-p*
    (&optional (buff-or-name (current-buffer)) (persp (persp-get-current)) del-weak)
  (persp-other-persps-with-buffer-except-nil* buff-or-name persp del-weak))


(cl-defun persp-frames-with-persp (&optional (persp (persp-of-frame)))
  (cl-delete-if-not (apply-partially #'eq persp)
                    (persp-frame-list-without-daemon)
                    :key #'persp-of-frame))
(cl-defun persp-frames-and-windows-with-persp (&optional (persp (persp-get-current)))
  (let (frames windows)
    (dolist (frame (persp-frame-list-without-daemon))
      (when (eq persp (persp-of-frame frame))
        (push frame frames))
      (dolist (window (window-list frame 'no-minibuf))
        (when (and (persp-set-for-window-p window)
                   (eq persp (persp-of-window window)))
          (push window windows))))
    (cons frames windows)))


(cl-defun persp-do-buffer-list-by-regexp (&key blist regexp func (rest-args nil rest-args-p)
                                               noask)
  (interactive)

  (unless blist
    (setq blist (eval (read--expression "Buffer list expression: "
                                        "(persp-buffer-list-restricted)"))))

  (unless regexp
    (let ((tmp
           (condition-case-unless-debug _err
               (with-temp-buffer
                 (let* (preview-win
                        (preview-buf (current-buffer))
                        (buffer-names (mapcar #'buffer-name blist))
                        matched-names
                        (string-match-propertize-f
                         (lambda (rex str)
                           (when (condition-case err
                                     (string-match rex str)
                                   (error
                                    (message "Error matching regex: %S" err)
                                    (throw 'old-matched-names matched-names)
                                    nil))
                             (let ((new-str (copy-sequence str)))
                               ;; (add-text-properties 0 (string-width new-str)
                               ;;                      '(face header-line-highlight)
                               ;;                      new-str)
                               (add-text-properties (match-beginning 0) (match-end 0)
                                                    '(face highlight)
                                                    new-str)
                               new-str))))
                        (old-regex "") matched-names-str
                        (separator (copy-sequence ", "))
                        (minibuf-post-command-h
                         (lambda ()
                           (when (and (minibuffer-window-active-p (selected-window))
                                      (window-live-p preview-win))
                             (let ((regex (minibuffer-contents))
                                   (num-of-matched 0))
                               (unless (string= old-regex regex)
                                 (setq old-regex regex
                                       matched-names (catch 'old-matched-names
                                                       (cl-delete-if-not
                                                        #'identity
                                                        (mapcar
                                                         (apply-partially string-match-propertize-f regex)
                                                         buffer-names)))
                                       num-of-matched (length matched-names)
                                       matched-names-str (mapconcat #'identity matched-names separator))
                                 (with-current-buffer preview-buf
                                   (setq-local header-line-format (format "Number of matched buffers: %s"
                                                                          num-of-matched)

                                               mode-line-format header-line-format
                                               fill-column (window-width preview-win))
                                   (erase-buffer)
                                   (insert matched-names-str)
                                   (goto-char (point-min))
                                   (fill-paragraph))))
                             (fit-window-to-buffer preview-win 10 nil nil nil t))))
                        (minibuf-setup-h
                         (lambda ()
                           (with-current-buffer preview-buf
                             (setq-local header-line-format "Number of matched buffers: 0"
                                         mode-line-format header-line-format
                                         line-spacing 0.2))
                           (setq preview-win (split-window-below -10 (window-main-window)))
                           (set-window-buffer preview-win preview-buf)
                           (set-window-dedicated-p preview-win t)
                           ;; (set-window-margins preview-win 0 0)
                           ;; (set-window-fringes preview-win 0 0)
                           (window-preserve-size preview-win nil t)
                           (add-hook 'post-command-hook minibuf-post-command-h))))
                   (add-text-properties 0 (string-width separator)
                                        '(face fringe) separator)
                   (unwind-protect
                       (minibuffer-with-setup-hook minibuf-setup-h
                         (cons (read-regexp "Regexp: ") matched-names))
                     (remove-hook 'post-command-hook minibuf-post-command-h)
                     (when (window-live-p preview-win)
                       (let ((ignore-window-parameters t)
                             (window--sides-inhibit-check t))
                         (delete-window preview-win))))))
             (error
              (read-regexp "Regexp: ")))))
      (if (stringp tmp)
          (setq regexp tmp)
        (if (consp tmp)
            (setq blist (mapcar #'get-buffer (cdr tmp)))
          (setq regexp nil
                blist nil)))))

  (when (stringp regexp)
    (setq blist (cl-remove-if-not
                 (apply-partially #'persp-string-match-p regexp)
                 (mapcar #'get-buffer blist)
                 :key #'buffer-name)))

  (when blist
    (unless func
      (let ((fs (completing-read "What function to apply: " obarray 'functionp t)))
        (when (and fs (not (string= fs "")))
          (setq func (read fs)))))

    (unless rest-args-p
      (setq rest-args (read--expression "Rest arguments: " "nil")))

    (when (and func
               (or noask (y-or-n-p (format "Do %s on these buffers(%s):\n%s?\n"
                                           func (length blist)
                                           (mapconcat #'buffer-name blist ", ")))))
      (mapcar (lambda (b) (apply func b rest-args)) blist))))



;; Perspective funcs:

(defun persp-update-names-cache (new-persp-names &optional force)
  "Update `persp-names-cache' with `NEW-PERSP-NAMES'."
  (unless *persp-pretend-switched-off*
    (unless (or force new-persp-names)
      (setq new-persp-names (list persp-nil-name)))
    (let ((old-persp-names persp-names-cache))
      (cl-psetq persp-names-cache new-persp-names)
      (run-hook-with-args 'persp-names-cache-changed-functions
                          old-persp-names new-persp-names))))

(defun persp-next ()
  "Switch to next perspective (to the right)."
  (interactive)
  (let* ((persp-list (persp-names-current-frame-fast-ordered))
         (persp-list-length (length persp-list))
         (only-perspective? (= persp-list-length 1))
         (pos (cl-position (persp-name (persp-get-current)) persp-list)))
    (cond
     ((null pos) nil)
     (only-perspective? nil)
     ((= pos (1- persp-list-length))
      (if persp-switch-wrap (persp-switch (nth 0 persp-list))))
     (t (persp-switch (nth (1+ pos) persp-list))))))

(defun persp-prev ()
  "Switch to previous perspective (to the left)."
  (interactive)
  (let* ((persp-list (persp-names-current-frame-fast-ordered))
         (persp-list-length (length persp-list))
         (only-perspective? (= persp-list-length 1))
         (pos (cl-position (persp-name (persp-get-current)) persp-list)))
    (cond
     ((null pos) nil)
     (only-perspective? nil)
     ((= pos 0)
      (if persp-switch-wrap
          (persp-switch (nth (1- persp-list-length) persp-list))))
     (t (persp-switch (nth (1- pos) persp-list))))))

(cl-defun persp-add (persp &optional (phash *persp-hash*))
  "Insert `PERSP' to `PHASH'.
If we adding to the `*persp-hash*' add entries to the mode menu.
Return `PERSP'."
  (let ((name (persp-name persp)))
    (puthash name persp phash)
    (when (eq phash *persp-hash*)
      (persp-add-to-menu persp)))
  persp)

(cl-defun persp-remove-by-name (name &optional (phash *persp-hash*))
  "Remove a perspective with name `NAME' from `PHASH'.
Save it's state before removing.
If we removing from the `*persp-hash*' remove also the menu entries.
Switch all frames with that perspective to another one.
Return the removed perspective."
  (interactive "i")
  (unless name
    (setq name (persp-read-persp
                "to remove" nil
                (and (eq phash *persp-hash*)
                     (persp-name (persp-get-current)))
                t t)))
  (let ((persp (persp-get-by-name name phash))
        (persp-to-switch persp-nil-name))
    (when (persp-p persp)
      (persp-save-state persp)
      (if (and (eq phash *persp-hash*) (persp-nil-p persp))
          (message "[persp-mode] Error: Can't remove the 'nil' perspective")
        (when (and (eq phash *persp-hash*) persp)
          (persp-remove-from-menu persp)
          (cl-destructuring-bind (frames . windows)
              (persp-frames-and-windows-with-persp persp)
            (dolist (w windows) (persp-unset-for-window w))
            ;; (setq persp-to-switch (or (car (persp-names phash nil))
            ;;                           persp-nil-name))
            (dolist (f frames)
              (persp-frame-switch persp-to-switch f))))
        (remhash name phash)))
    persp))

(cl-defun persp-add-new (name &optional (phash *persp-hash*) (ret-existent t))
  "Create a new perspective with the given `NAME'. Add it to `PHASH'.
Return the created perspective."
  (interactive "sA name for the new perspective: ")
  (if (and name (not (string= "" name)))
      (cl-destructuring-bind (e . p)
          (persp-get-by-name-and-exists name phash)
        (if e (or (and ret-existent p) persp-not-persp)
          (setq p (if (string= persp-nil-name name)
                      persp-nil-persp
                    (persp--make :name name)))
          (persp-add p phash)
          (run-hook-with-args 'persp-created-functions p phash)
          p))
    (message "[persp-mode] Error: Can't create a perspective with empty name.")
    nil))

(defun persp-find-and-set-persps-for-buffer (&optional buffer-or-name)
  (setq buffer-or-name (if buffer-or-name
                           (persp-get-buffer-or-null buffer-or-name)
                         (current-buffer)))
  (mapc (lambda (p) (persp-add-buffer buffer-or-name p nil nil))
        (persp--buffer-in-persps buffer-or-name))
  (persp--buffer-in-persps-set
   buffer-or-name
   (cl-delete-if-not (apply-partially #'memq buffer-or-name)
                     (delq persp-nil-persp (persp-persps))
                     :key #'persp-buffers)))

(cl-defun persp-contain-buffer-p
    (&optional (buff-or-name (current-buffer)) (persp (persp-get-current)) delweak)
  (if (and delweak (persp-weak persp))
      nil
    (if (persp-nil-p persp)
        t
      (memq (persp-get-buffer-or-null buff-or-name)
            (persp-buffers persp)))))
(cl-defun persp-contain-buffer-p*
    (&optional (buff-or-name (current-buffer)) (persp (persp-get-current)) delweak)
  (if (and delweak (persp-weak persp))
      nil
    (if (persp-nil-p persp)
        t
      (memq persp (persp--buffer-in-persps
                   (persp-get-buffer-or-null buff-or-name))))))

(cl-defun persp-add-buffer
    (&optional buffs-or-names (persp (persp-get-current))
               (switchorno persp-switch-to-added-buffer)
               (called-interactively-p (called-interactively-p 'any)))
  (interactive "i")
  (persp-normalize-persp-arg*)
  (when (and called-interactively-p current-prefix-arg)
    (setq switchorno (not switchorno)))
  (unless buffs-or-names
    (setq buffs-or-names
          (when called-interactively-p
            (let ((*persp-restrict-buffers-to* 1)
                  persp-restrict-buffers-to-if-foreign-buffer)
              (persp-read-buffer (concat
                                  "Add buffers to the perspective"
                                  (and switchorno
                                       " and switch to first added buffer")
                                  ": ")
                                 (current-buffer) t nil t)))))
  (unless (listp buffs-or-names) (setq buffs-or-names (list buffs-or-names)))
  (let (added-buffers)
    (mapc
     (lambda (bon)
       (let ((buffer (persp-get-buffer-or-null bon)))
         (when (and (not (persp-nil-p persp)) buffer)
           (unless (persp-contain-buffer-p buffer persp)
             (push buffer (persp-buffers persp))
             (push buffer added-buffers))
           (unless (persp-contain-buffer-p* buffer persp)
             (persp--buffer-in-persps-add buffer persp)))
         (when (and buffer switchorno (eq persp (persp-get-current)))
           (persp-switch-to-buffer buffer))
         buffer))
     buffs-or-names)
    (persp-update-frame-lighter)
    (mapc (lambda (b)
            (run-hook-with-args 'persp-buffer-state-changed-functions b persp 'added))
          added-buffers)
    added-buffers))

(cl-defun persp-add-buffers-by-regexp (&optional regexp (persp (persp-get-current)))
  (interactive)
  (persp-normalize-persp-arg*)
  (unless (persp-nil-p persp)
    (persp-do-buffer-list-by-regexp
     :regexp regexp :func #'persp-add-buffer :rest-args (list persp nil)
     :blist (persp-buffer-list-restricted (selected-frame) 1))))

(cl-defun persp-temporarily-display-buffer
    (&optional buff-or-name (called-interactively-p (called-interactively-p 'any)))
  (interactive "i")
  (let ((persp-temporarily-display-buffer t))
    (unless buff-or-name
      (setq buff-or-name
            (if called-interactively-p
                (let ((*persp-restrict-buffers-to*
                       (if (and called-interactively-p current-prefix-arg) 0 1))
                      (persp-restrict-buffers-to-if-foreign-buffer
                       (if (= 0 *persp-restrict-buffers-to*) -1 nil)))
                  (persp-read-buffer
                   (if (= 0 *persp-restrict-buffers-to*)
                       "Remove a buffer from the perspective, but still display it: "
                     "Temporarily display a buffer, not adding it to the current perspective: ")
                   nil t))
              (current-buffer))))
    (let ((buffer (persp-get-buffer-or-null buff-or-name)))
      (when buffer
        (let ((persp (persp-get-current)))
          (unless (or (persp-nil-p persp)
                      (persp-contain-buffer-p* buffer persp))
            (let (persp-autokill-buffer-on-remove
                  persp-autokill-persp-when-removed-last-buffer)
              (persp-remove-buffer buffer persp nil nil nil nil))))
        (persp-switch-to-buffer buffer t)))))


(defun persp--buffer-do-auto-action-if-needed (buffer)
  (when (and persp-autokill-buffer-on-remove
             (persp-buffer-free-p
              buffer
              (eq 'kill-weak persp-autokill-buffer-on-remove)))
    (let (persp-autokill-buffer-on-remove)
      (persp-kill-buffer buffer))))

(defun persp--remove-buffer-1 (buffer &optional persp)
  (if (persp-nil-p persp)
      (mapcar (apply-partially #'persp--remove-buffer-1 buffer)
              (persp-other-persps-with-buffer-except-nil buffer persp))
    (progn
      (when persp-when-remove-buffer-switch-to-other-buffer
        (persp-switch-to-prev-buffer buffer persp))
      (persp--buffer-in-persps-remove buffer persp)
      (setf (persp-buffers persp) (delq buffer (persp-buffers persp)))
      (run-hook-with-args 'persp-buffer-state-changed-functions buffer persp 'removed)
      persp)))

(defun persp--remove-buffer-2 (&optional persp buffer-or-name)
  (let ((buffer (if buffer-or-name
                    (persp-get-buffer-or-null buffer-or-name)
                  (current-buffer))))
    (when buffer
      (persp--remove-buffer-1 buffer persp)
      (persp--buffer-do-auto-action-if-needed buffer)
      (persp--do-auto-action-if-needed persp))
    buffer))

(defun persp--remove-buffers-from-nil-p (buffs-or-names)
  (cl-typecase persp-remove-buffers-from-nil-persp-behaviour
    (function
     (funcall persp-remove-buffers-from-nil-persp-behaviour
              buffs-or-names))
    (symbol
     (cl-macrolet
         ((ask () `(yes-or-no-p
                    (format "Remove %s buffers from all perspectives?"
                            buffs-or-names))))
       (cl-case persp-remove-buffers-from-nil-persp-behaviour
         (ask-to-rem-from-all
          (if (cl-find-if-not #'persp-buffer-free-p buffs-or-names)
              (ask) t))
         (ask-if-in-non-weak-persp
          (if (cl-find-if-not
               (lambda (bon)
                 (persp-buffer-free-p bon t))
               buffs-or-names)
              (ask) t))
         (t t))))
    (t t)))

(cl-defun persp-remove-buffer
    (&optional buffs-or-names (persp (persp-get-current))
               (rem-from-nil-opt persp-remove-buffers-from-nil-persp-behaviour)
               (switch persp-when-remove-buffer-switch-to-other-buffer)
               called-from-kill-buffer-hook
               (called-interactively-p (called-interactively-p 'any)))
  "Remove BUFFS-OR-NAMES(which may be a single buffer or a list of buffers)
from the PERSP. On success return removed buffers otherwise nil."
  (interactive "i")
  (persp-normalize-persp-arg*)

  ;; TODO: remove these parameters
  (ignore called-from-kill-buffer-hook rem-from-nil-opt switch)

  (unless (listp buffs-or-names) (setq buffs-or-names (list buffs-or-names)))
  (unless buffs-or-names
    (setq buffs-or-names
          (if called-interactively-p
              (let ((*persp-restrict-buffers-to* 0)
                    persp-restrict-buffers-to-if-foreign-buffer)
                (persp-read-buffer "Remove buffers from the perspective: "
                                   (current-buffer) t nil t))
            (current-buffer))))
  (when (or (not (persp-nil-p persp))
            (persp--remove-buffers-from-nil-p buffs-or-names))
    (let ((persp-autokill-buffer-on-remove
           (if (and called-interactively-p current-prefix-arg)
               (not persp-autokill-buffer-on-remove)
             persp-autokill-buffer-on-remove)))
      (let ((ret (mapcar (apply-partially #'persp--remove-buffer-2 persp)
                         buffs-or-names)))
        (persp-update-frame-lighter)
        ret))))

(defun persp-kill-buffer (&optional buffers-or-names)
  "Kill buffers, read buffer with restriction to current perspective."
  (interactive (list
                (let ((*persp-restrict-buffers-to* 0)
                      persp-restrict-buffers-to-if-foreign-buffer)
                  (if persp-mode
                      (persp-read-buffer
                       "Kill buffers: " (current-buffer) t nil t)
                    (read-buffer "Kill buffer: " (current-buffer) t)))))
  (unless (listp buffers-or-names)
    (setq buffers-or-names (list buffers-or-names)))
  (mapc #'kill-buffer
        (cl-remove-if-not #'persp-get-buffer-or-null buffers-or-names))
  ;; TODO: not needed? -> window-configuration-change-hook
  ;; (persp-update-frame-lighter)
  buffers-or-names)

(defun persp-switch-to-buffer (buffer-or-name
                               &optional norecord force-same-window)

  "Switch to buffer, read buffer with restriction to current perspective."

  (interactive (list
                (let ((*persp-restrict-buffers-to* 0)
                      persp-restrict-buffers-to-if-foreign-buffer)
                  (if persp-mode
                      (let ((dflt (other-buffer (current-buffer))))
                        (unless (memq dflt (persp-buffers
                                            (persp-get-current)))
                          (cl-psetq dflt (current-buffer)))
                        (persp-read-buffer "Switch to buffer: " dflt t))
                    (read-buffer-to-switch "Switch to buffer: ")))))
  (when (and buffer-or-name
             (persp-get-buffer-or-null (get-buffer buffer-or-name)))
    (switch-to-buffer buffer-or-name norecord force-same-window)
    ;; TODO: not needed? -> window-configuration-change-hook
    ;; (persp-update-frame-lighter)
    ))

(cl-defun persp-remove-buffers-by-regexp
    (&optional regexp (persp (persp-get-current)))
  (interactive)
  (persp-normalize-persp-arg*)
  (unless (persp-nil-p persp)
    (persp-do-buffer-list-by-regexp
     :regexp regexp :func #'persp-remove-buffer
     :blist (persp-buffers persp) :rest-args (list persp))))

(cl-defun persp-import-buffers-from (persp-from
                                     &optional (persp-to (persp-get-current)))
  (if (persp-nil-p persp-to)
      (message "[persp-mode] Error: Can't import buffers to the 'nil' perspective, \
cause it already contain all buffers.")
    (mapc (lambda (b) (persp-add-buffer b persp-to nil nil))
          (persp-buffers persp-from))))

(cl-defun persp-import-buffers
    (names
     &optional (persp-to (persp-get-current)) (phash *persp-hash*))
  "Import buffers from perspectives with the given names to another one."
  (interactive "i")
  (persp-normalize-persp-arg* persp-to phash)
  (unless (listp names) (setq names (list names)))
  (unless names
    (setq names (persp-read-persp "to import buffers from" t nil t nil t)))
  (mapc (lambda (persp-from)
          (persp-import-buffers-from persp-from persp-to))
        (mapcar (lambda (pn) (persp-get-by-name pn phash)) names)))

(cl-defun persp-import-win-conf
    (name
     &optional (persp-to (persp-get-current)) (phash *persp-hash*)
     no-update-frames)
  (interactive "i")
  (persp-normalize-persp-arg* persp-to phash)
  (unless name
    (setq name (persp-read-persp
                "to import window configuration from" nil nil t nil t)))
  (let ((persp-from (persp-get-by-name name phash)))
    (unless (or (eq persp-to persp-from)
                (not (persp-p persp-from)))
      (setf (persp-window-conf (or persp-to persp-nil-persp))
            (persp-window-conf persp-from))
      (unless no-update-frames
        (persp-update-frames-window-confs (list (persp-name persp-to)))))))

(cl-defun persp-copy
    (new-name
     &optional switch (called-interactively-p (called-interactively-p 'any)))
  (interactive "i")
  (unless new-name
    (setq new-name
          (read-string "Copy current persp with name: ")))
  (if (member new-name (persp-names))
      (progn
        (message
         "[persp-mode] Error: There is already a perspective with that name %S"
         new-name)
        nil)
    (let* ((new-persp (persp-add-new new-name))
           (current-persp (persp-get-current))
           (new-buffers (when new-persp
                          (if (persp-nil-p current-persp)
                              (persp-buffers current-persp)
                            (cl-copy-list (persp-buffers current-persp))))))
      (when new-persp
        (when (and called-interactively-p current-prefix-arg)
          (setq new-buffers
                (let (choosen-buffers)
                  (cl-delete-if-not
                   (cl-destructuring-bind (char &rest rest)
                       (read-multiple-choice
                        "What buffers to copy? "
                        '((?a "all")
                          (?d "displayed")
                          (?f "free and displayed")
                          (?F "free")
                          (?c "choose")
                          (?n "none")))
                     (cl-case char
                       (?d (lambda (b) (get-buffer-window-list b 'no-minibuf)))
                       (?f (lambda (b) (or (persp-buffer-free-p b t)
                                             (get-buffer-window-list b 'no-minibuf))))
                       (?F (lambda (b) (persp-buffer-free-p b t)))
                       (?c (setq choosen-buffers
                                 (mapcar #'get-buffer
                                         (persp-read-buffer
                                          "" (current-buffer) t nil t 'push)))
                           (lambda (b) (memq b choosen-buffers)))
                       (?n #'not)
                       (?a nil)
                       (t nil)))
                   new-buffers))))
        (persp-save-state current-persp)
        (setf (persp-window-conf new-persp)
              (persp-window-conf current-persp)
              (persp-parameters new-persp)
              (cl-copy-list (persp-parameters current-persp))
              (persp-weak new-persp)
              (if current-persp (persp-weak current-persp) nil))
        (persp-add-buffer new-buffers new-persp nil nil)
        (cl-case switch
          (window (persp-window-switch new-name))
          (frame (persp-frame-switch new-name))
          (no-switch nil)
          (t (persp-switch new-name)))
        new-persp))))

(cl-defun persp-get-buffer
    (&optional (buff-or-name (current-buffer)) (persp (persp-get-current)))
  "Like `get-buffer', but constrained to the perspective's list of buffers.
Return the buffer if it's in the perspective or the first buffer from the
perspective buffers or nil."
  (let ((buffer (persp-get-buffer-or-null buff-or-name)))
    (or (cl-find buffer (persp-buffers persp))
        (cl-first (persp-buffers persp)))))

(defun persp-get-buffer-or-null (buff-or-name)
  "Safely return a buffer or the nil without errors."
  (cl-typecase buff-or-name
    ((or string buffer)
     (let ((buf (get-buffer buff-or-name)))
       (and (buffer-live-p buf)
            buf)))
    (otherwise nil)))

(defun persp-buffer-filtered-out-p (buff-or-name &rest filters)
  (setq filters (if filters
                    (cons
                     persp-common-buffer-filter-functions
                     filters)
                  persp-common-buffer-filter-functions)
        buff-or-name (get-buffer buff-or-name))
  (cl-find-if (lambda (filter)
                (if (functionp filter)
                    (funcall filter buff-or-name)
                  (cl-find-if (lambda (f) (funcall f buff-or-name)) filter)))
              filters))

(defun persp-buffer-free-p (&optional buff-or-name del-weak)
  (unless buff-or-name (setq buff-or-name (current-buffer)))
  (let ((persps (persp--buffer-in-persps
                 (persp-get-buffer-or-null buff-or-name))))
    (if persps
        (if del-weak
            (not
             (cl-find-if-not #'persp-weak persps))
          nil)
      t)))


(cl-defun persp-set-another-buffer-for-window
    (&optional (old-buff-or-name (current-buffer)) (window (selected-window))
               (persp (persp-get-current nil window)))
  (unless (window-minibuffer-p window)
    (let* ((old-buf (persp-get-buffer-or-null old-buff-or-name))
           (new-buf (if persp-set-frame-buffer-predicate
                        (other-buffer old-buf)
                      (cl-find-if (lambda (bc)
                                    (and (bufferp bc) (not (eq bc old-buf))
                                         (persp-contain-buffer-p bc persp)))
                                  (append (mapcar #'car
                                                  (window-prev-buffers window))
                                          (window-next-buffers window))))))
      (set-window-buffer
       window
       (or (and (buffer-live-p new-buf) new-buf)
           (car (persp-buffer-list-restricted (window-frame window) 2.5))
           (car (buffer-list))))
      ;; TODO: not needed? -> window-configuration-change-hook
      ;; (persp-update-frame-lighter (window-frame window))
      )))

(cl-defun persp-switch-to-prev-buffer
    (&optional (old-buff-or-name (current-buffer)) (persp (persp-get-current)))
  "Switch all windows in all frames with a perspective displaying that buffer
to some previous buffer in the perspective.
Return that old buffer."
  (let ((old-buf (persp-get-buffer-or-null old-buff-or-name)))
    (cl-destructuring-bind (frames . windows)
        (persp-frames-and-windows-with-persp persp)
      (dolist (w windows)
        (persp-set-another-buffer-for-window old-buf w))
      (dolist (f frames)
        (dolist (w (get-buffer-window-list old-buf 'no-minibuf f))
          (persp-set-another-buffer-for-window old-buf w))))
    old-buf))

(defun persp-hide (names)
  (interactive "i")
  (unless (listp names) (setq names (list names)))
  (unless names
    (setq names (persp-read-persp
                 "to hide" t (persp-name (persp-get-current)) t)))
  (let ((persp-to-switch (persp-get-current))
        (hidden-persps
         (mapcar (lambda (pn)
                   (let ((persp (persp-get-by-name pn)))
                     (when (perspective-p persp)
                       (setf (persp-hidden persp) t)
                       persp)))
                 names)))
    (when (persp-hidden persp-to-switch)
      (setq persp-to-switch
            (car (persp-other-not-hidden-persps persp-to-switch))))
    (mapc (lambda (p)
            (when (persp-p p)
              (cl-destructuring-bind (frames . windows)
                  (persp-frames-and-windows-with-persp p)
                (dolist (w windows) (persp-unset-for-window w))
                (dolist (f frames)
                  (persp-frame-switch (persp-name persp-to-switch) f)))))
          hidden-persps)))

(defun persp-unhide (names)
  (interactive "i")
  (unless (listp names) (setq names (list names)))
  (unless names
    (let ((hidden-persps
           (mapcar #'persp-name
                   (cl-delete-if-not #'persp-hidden
                                     (persp-persps)))))
      (setq names
            (persp-read-persp
             "to unhide" t (car hidden-persps) t nil nil hidden-persps t))))
  (when names
    (mapc (lambda (pn)
            (let ((persp (persp-get-by-name pn)))
              (when (perspective-p persp)
                (setf (persp-hidden persp) nil))))
          names)))

(cl-defun persp-kill (names &optional dont-kill-buffers
                            (called-interactively-p (called-interactively-p 'any)))
  (interactive "i")
  (when (and called-interactively-p current-prefix-arg)
    (setq dont-kill-buffers (not dont-kill-buffers)))
  (unless (listp names) (setq names (list names)))
  (unless names
    (setq names (persp-read-persp
                 (concat "to kill"
                         (and dont-kill-buffers " not killing buffers"))
                 t (persp-name (persp-get-current)) t)))
  (mapc (lambda (pn)
          (let ((persp (persp-get-by-name pn)))
            (when (persp-p persp)
              (when (or (not called-interactively-p)
                        (not (persp-nil-p persp))
                        (yes-or-no-p
                         "Really kill the 'nil' perspective (It'l kill all buffers)?"))
                (let ((pfile (persp-parameter 'persp-file persp)))
                  (cl-case persp-auto-save-persps-to-their-file-before-kill
                    (persp-file nil)
                    ((nil) (setq pfile nil))
                    (t (unless pfile
                         (setq pfile persp-auto-save-fname))))
                  (when pfile
                    (persp-save-to-file-by-names
                     pfile *persp-hash* (list pn) t nil)))
                (run-hook-with-args 'persp-before-kill-functions persp)
                (let (persp-autokill-persp-when-removed-last-buffer)
                  (if dont-kill-buffers
                      (let (persp-autokill-buffer-on-remove)
                        (mapc (lambda (b)
                                (persp-remove-buffer b persp t t nil nil))
                              (persp-buffers persp)))
                    (mapc (lambda (b)
                            (persp-remove-buffer b persp t t nil nil))
                          (persp-buffers persp))))
                (unless (persp-nil-p persp)
                  (persp-remove-by-name pn))))))
        names))

(defun persp-kill-without-buffers (names)
  (interactive "i")
  (persp-kill names t nil))

(cl-defun persp-save-and-kill
    (names &optional dont-kill-buffers
           (called-interactively-p (called-interactively-p 'any)))
  (interactive "i")
  (when (and called-interactively-p current-prefix-arg)
    (setq dont-kill-buffers (not dont-kill-buffers)))
  (unless (listp names) (setq names (list names)))
  (unless names
    (setq names (persp-read-persp
                 (concat "to save and kill"
                         (and dont-kill-buffers " not killing buffers"))
                 t (persp-name (persp-get-current)) t)))
  (let ((temphash (make-hash-table :test 'equal :size 10)))
    (mapc (lambda (p)
            (persp-add p temphash))
          (mapcar (lambda (pn) (persp-get-by-name pn)) names))
    (persp-save-state-to-file persp-auto-save-fname temphash
                              persp-auto-save-persps-to-their-file
                              'yes 'yes))
  (persp-kill names))

(cl-defun persp--rename (new-name
                         &optional (persp (persp-get-current)) (phash *persp-hash*))
  "Low level renaming job."
  (let ((opersp (persp-get-by-name new-name phash))
        (old-name (persp-name persp)))
    (if (and (not (persp-p opersp)) new-name
             (not (string= old-name new-name)))
        (progn
          (when (eq phash *persp-hash*)
            (persp-remove-from-menu persp)
            (cl-destructuring-bind (_frames . windows)
                (persp-frames-and-windows-with-persp persp)
              (dolist (win windows)
                (when (string= old-name (persp-of-window* win))
                  (persp-set-for-window* win new-name)))))
          (remhash old-name phash)
          (setf (persp-name (or persp persp-nil-persp)) new-name)
          (when (persp-nil-p persp)
            (setq persp-nil-name new-name))
          (puthash new-name persp phash)
          (when (eq phash *persp-hash*)
            (persp-add-to-menu persp)
            (run-hook-with-args
             'persp-renamed-functions persp old-name new-name)
            (when (string= old-name persp-last-persp-name)
              (setq persp-last-persp-name new-name)))
          (mapc #'persp-update-frame-lighter (persp-frames-with-persp persp))
          old-name)
      (message
       "[persp-mode] Error: There is already a perspective with that name: %S."
       new-name)
      nil)))
(cl-defun persp-rename (new-name
                        &optional (persp (persp-get-current)) (phash *persp-hash*))
  "Change the name field of the `PERSP'.
Return old name on success, otherwise nil."
  (interactive "i")
  (persp-normalize-persp-arg* persp phash)
  (if (not (persp-nil-p persp))
      (let ((old-name (persp-name persp)))
        (unless new-name
          (setq new-name
                (read-string
                 (concat "New name for the " old-name " perspective: ") old-name)))
        (persp--rename new-name persp phash))
    (message
     "[persp-mode] Error: You can't rename the `nil' perspective, use \
M-x: customize-variable RET persp-nil-name RET")
    nil))

(cl-defun persp-switch
    (name &optional frame (window (selected-window))
          (called-interactively-p (called-interactively-p 'any)))
  "Switch to the perspective with name `NAME'.
If there is no perspective with that name it will be created.
Return `NAME'."
  (interactive "i")
  (let ((switch-type 'frame))
    (if (or (persp-set-for-window-p window)
            (and called-interactively-p current-prefix-arg))
        (setq switch-type 'window)
      (unless frame (setq frame (window-frame window))))
    (if (eq 'window switch-type)
        (persp-window-switch name window)
      (persp-frame-switch name frame))))
(cl-defun persp-frame-switch (name &optional (frame (selected-frame)))
  (interactive "i")
  (if (persp-frame-good-p frame)
      (progn
        (unless name
          (setq name (persp-read-persp "to switch(in frame)" nil nil nil nil t)))
        (unless (memq frame persp-inhibit-switch-for)
          (run-hook-with-args 'persp-before-switch-functions name frame)
          (let ((persp-inhibit-switch-for (cons frame persp-inhibit-switch-for)))
            (persp-activate (persp-add-new name) frame)))
        name)
    (message "[persp-mode] Error: This frame is ignored by persp-mode!")
    nil))
(cl-defun persp-window-switch (name &optional (window (selected-window)))
  (interactive "i")
  (unless name
    (setq name (persp-read-persp "to switch(in window)" nil nil nil nil t)))
  (unless (memq window persp-inhibit-switch-for)
    (run-hook-with-args 'persp-before-switch-functions name window)
    (let ((persp-inhibit-switch-for (cons window persp-inhibit-switch-for)))
      (persp-activate (persp-add-new name) window)))
  name)

(defun persp-before-make-frame ()
  (unless *persp-pretend-switched-off*
    (let ((persp (persp-get-by-name
                  (or (and persp-set-last-persp-for-new-frames
                           persp-last-persp-name)
                      persp-nil-name))))
      (unless (persp-p persp)
        (when persp-set-last-persp-for-new-frames
          (setq persp-last-persp-name persp-nil-name))
        (setq persp (persp-add-new persp-nil-name)))
      (persp-save-state persp nil t))))

(defun persp--do-auto-action-if-needed (persp)
  (let ((opt persp-autokill-persp-when-removed-last-buffer))
    (when (and (not (persp-nil-p persp)) (persp-auto persp)
               opt (null (persp-buffers persp)))
      (cond
       ((or (eq 'hide opt)
            (and (eq 'hide-auto opt)
                 (persp-auto persp)))
        (persp-hide (persp-name persp)))
       ((or (eq t opt)
            (eq 'kill opt)
            (and
             (eq 'kill-auto opt)
             (persp-auto persp)))
        (persp-kill (persp-name persp) nil nil))
       ((functionp opt)
        (funcall opt persp))))))

(defsubst persp--deactivate (frame-or-window &optional new-persp)
  (let (persp)
    (cl-typecase frame-or-window
      (frame
       (setq persp (persp-of-frame frame-or-window))
       (unless (eq persp new-persp)
         (run-hook-with-args 'persp-before-deactivate-functions
                             'frame frame-or-window persp)
         (persp-frame-save-state
          frame-or-window
          (if persp-set-last-persp-for-new-frames
              (string= (persp-name persp) persp-last-persp-name)
            (persp-nil-p persp)))))
      (window
       (setq persp (persp-of-window frame-or-window))
       (unless (eq persp new-persp)
         (run-hook-with-args 'persp-before-deactivate-functions
                             'window frame-or-window persp))))
    (let ((persp-inhibit-switch-for
           (cons frame-or-window persp-inhibit-switch-for)))
      (persp--do-auto-action-if-needed persp))))

(cl-defun persp-activate
    (persp &optional (frame-or-window (selected-frame)) new-frame-p)
  (when frame-or-window
    (let (old-persp type)
      (cl-typecase frame-or-window
        (frame
         (setq old-persp (persp-of-frame frame-or-window)
               type 'frame))
        (window
         (setq old-persp (persp-of-window frame-or-window)
               type 'window)))
      (when  (or new-frame-p
                 (not (eq old-persp persp)))
        (cl-case type
          (frame
           (when (persp-frame-good-p frame-or-window)
             (unless new-frame-p
               (persp--deactivate frame-or-window persp))
             (setq persp-last-persp-name (persp-name persp))
             (persp-set-for-frame persp frame-or-window)
             (when persp-init-frame-behaviour
               (persp-restore-window-conf frame-or-window persp new-frame-p))
             (persp-update-frame-lighter frame-or-window)
             (run-hook-with-args 'persp-activated-functions 'frame frame-or-window persp)))
          (window
           (persp--deactivate frame-or-window persp)
           (persp-set-for-window persp frame-or-window)
           (let ((cbuf (window-buffer frame-or-window)))
             (unless (persp-contain-buffer-p cbuf persp)
               (persp-set-another-buffer-for-window cbuf frame-or-window persp)))
           (persp-update-frame-lighter (window-frame frame-or-window))
           (run-hook-with-args 'persp-activated-functions 'window frame-or-window persp)))))))

(defun persp-init-new-frame (frame)
  (unless (or *persp-pretend-switched-off* (not (persp-frame-good-p frame)))
    (condition-case-unless-debug err
        (progn
          (persp-init-frame frame t (frame-parameter frame 'client))
          (when (and (> persp-auto-save-opt 2)
                     (let ((fl (persp-frame-list-without-daemon)))
                       (and (= 1 (length fl)) (eq frame (car fl)))))
            (add-hook 'kill-emacs-query-functions #'persp-kill-emacs-query-function)
            (add-hook 'kill-emacs-hook #'persp-kill-emacs-h)))
      (error
       (message "[persp-mode] Error: Can not initialize frame -- %S"
                err)))))
(cl-defun persp-init-frame (frame &optional new-frame-p client)
  (if (persp-frame-good-p frame)
      (let ((persp-init-frame-behaviour
             (cond
              ((and client
                    (not (eql -1 persp-emacsclient-init-frame-behaviour-override)))
               persp-emacsclient-init-frame-behaviour-override)
              ((and (eq this-command 'make-frame)
                    (not (eql -1 persp-interactive-init-frame-behaviour-override)))
               persp-interactive-init-frame-behaviour-override)
              ((and new-frame-p (not (eql -1 persp-init-new-frame-behaviour-override)))
               persp-init-new-frame-behaviour-override)
              (t persp-init-frame-behaviour))))
        (let (persp-name persp)
          (cl-macrolet
              ((set-default-persp
                ()
                `(progn
                   (setq persp-name (or (and persp-set-last-persp-for-new-frames
                                             persp-last-persp-name)
                                        persp-nil-name)
                         persp (persp-get-by-name persp-name))
                   (unless (persp-p persp)
                     (setq persp-name persp-nil-name
                           persp (persp-add-new persp-name))))))
            (cl-typecase persp-init-frame-behaviour
              (function
               (funcall persp-init-frame-behaviour frame new-frame-p))
              (string
               (setq persp-name persp-init-frame-behaviour
                     persp (persp-add-new persp-name)))
              (symbol
               (cl-case persp-init-frame-behaviour
                 (auto-temp (setq persp-name (persp-gen-random-name)
                                  persp (persp-add-new persp-name))
                            (unless (persp-nil-p persp)
                              (setf (persp-auto persp) t)))
                 (prompt (select-frame frame)
                         (setq persp-name
                               (persp-read-persp "to switch" nil nil nil nil t)
                               persp (persp-add-new persp-name)))
                 (persp-ignore (set-frame-parameter frame 'persp-ignore 'ignore)
                               (setq persp-name nil))
                 (t (set-default-persp))))
              (t (set-default-persp))))
          (when persp-name
            (modify-frame-parameters frame `((persp . ,persp-nil-persp)))
            (when persp-set-frame-buffer-predicate
              (persp-set-frame-buffer-predicate frame))
            (persp-set-frame-server-switch-hook frame)
            (when (or (eq persp-init-frame-behaviour 'persp-ignore-wconf)
                      (numberp persp-init-frame-behaviour))
              (set-frame-parameter frame 'persp-ignore-wconf persp-init-frame-behaviour))
            (persp-activate persp frame new-frame-p))))
    (set-frame-parameter frame 'persp-ignore 'ignore)
    (persp-update-frame-lighter frame)))

(defun persp-delete-frame (frame)
  (unless (or *persp-pretend-switched-off* (not (persp-frame-good-p frame)))
    (condition-case-unless-debug err
        (progn
          (persp--deactivate frame persp-not-persp)
          (when (and (> persp-auto-save-opt 2)
                     (let ((fl (persp-frame-list-without-daemon)))
                       (and (= 1 (length fl)) (eq frame (car fl)))))
            (when (persp-asave-on-exit t 2)
              (remove-hook 'kill-emacs-query-functions #'persp-kill-emacs-query-function)
              (remove-hook 'kill-emacs-hook #'persp-kill-emacs-h))))
      (error
       (message "[persp-mode] Error: Can not deactivate frame -- %S"
                err)))))

(cl-defun persp-find-other-frame-with-persp (&optional (persp (persp-of-frame))
                                                       (exframe (selected-frame))
                                                       for-save)
  (let ((flist (delq exframe (persp-frames-with-persp persp))))
    (if for-save
        (cl-find-if-not (lambda (f) (frame-parameter f 'persp-ignore-wconf)) flist)
      (car flist))))
(make-obsolete 'find-other-frame-with-persp 'persp-find-other-frame-with-persp
               "persp-mode 4.0.0")



;; Helper funcs:

(defun persp-add-minor-mode-menu ()
  (easy-menu-define persp-minor-mode-menu
    persp-mode-map
    "The menu for the `persp-mode'."
    '("Perspectives"
      "-")))

(defun persp-remove-from-menu (persp)
  (unless *persp-pretend-switched-off*
    (let ((name (persp-name persp)))
      (persp-update-names-cache (cl-delete name (persp-names-current-frame-fast-ordered) :count 1))
      (unless (persp-nil-p persp)
        (easy-menu-remove-item persp-minor-mode-menu '("kill") name))
      (easy-menu-remove-item persp-minor-mode-menu nil name))))

(defun persp-add-to-menu (persp)
  (unless *persp-pretend-switched-off*
    (let ((name (persp-name persp)))
      (persp-update-names-cache (append persp-names-cache (list name)))
      (easy-menu-add-item persp-minor-mode-menu nil
                          (vector name (lambda () (interactive)
                                         (persp-switch name)) t))
      (unless (persp-nil-p persp)
        (easy-menu-add-item persp-minor-mode-menu '("kill")
                            (vector name (lambda () (interactive)
                                           (persp-kill name)) t))))))

(cl-defun persp-read-persp
    (&optional action multiple default require-match delnil delcur persp-list
               show-hidden (default-mode t))

  "Read perspective name(s)."

  (when persp-names-sort-before-read-function
    (persp-update-names-cache
     (funcall persp-names-sort-before-read-function
              (persp-names-current-frame-fast-ordered))))

  (unless persp-list
    (setq persp-list (persp-names-current-frame-fast-ordered)))

  (when delnil
    (setq persp-list (cl-delete persp-nil-name persp-list :count 1)))
  (when delcur
    (let ((cpersp (persp-get-current)))
      (when cpersp
        (setq persp-list (cl-delete (persp-name cpersp) persp-list :count 1)))))
  (unless show-hidden
    (setq persp-list
          (cl-delete-if #'persp-hidden persp-list :key #'persp-get-by-name)))
  (when (and default (not (member default persp-list)))
    (setq default nil))
  (when (or persp-list (not require-match))
    (let (retlst)
      (cl-macrolet
          ((call-pif
            ()
            `(funcall
              persp-interactive-completion-function
              (concat
               "Perspective name" (and multiple "s") (and action " ") action
               (if default (concat " (default " default ")") "")
               (when retlst
                 (concat "< " (mapconcat #'identity retlst " ") " > "))
               ": ")
              persp-list nil require-match nil nil default)))
        (if multiple
            (let ((done_str "[>done<]") (not-finished default-mode)
                  exit-minibuffer-function mb-local-key-map
                  (push-keys (alist-get 'push-item persp-read-multiple-keys))
                  (pop-keys (alist-get 'pop-item persp-read-multiple-keys))
                  push-keys-backup pop-keys-backup)
              (while (member done_str persp-list)
                (setq done_str (concat ">" done_str)))
              (let ((persp-minibuffer-setup
                     (lambda ()
                       (setq mb-local-key-map (current-local-map))
                       (when (keymapp mb-local-key-map)
                         (unless exit-minibuffer-function
                           (setq exit-minibuffer-function
                                 (or (lookup-key mb-local-key-map (kbd "RET"))
                                     persp-read-multiple-exit-minibuffer-function)))
                         (unless push-keys-backup
                           (setq push-keys-backup
                                 (lookup-key mb-local-key-map push-keys)))
                         (define-key mb-local-key-map push-keys
                           (lambda () (interactive)
                             (setq not-finished 'push)
                             (funcall exit-minibuffer-function)))
                         (unless pop-keys-backup
                           (setq pop-keys-backup
                                 (lookup-key mb-local-key-map pop-keys)))
                         (define-key mb-local-key-map pop-keys
                           (lambda () (interactive)
                             (setq not-finished 'pop)
                             (funcall exit-minibuffer-function))))))
                    cp)
                (unwind-protect
                    (progn
                      (add-hook 'minibuffer-setup-hook persp-minibuffer-setup t)
                      (while not-finished
                        (setq cp (call-pif))
                        (cl-case not-finished
                          (push
                           (when (and cp (member cp persp-list))
                             (if retlst
                                 (when (string= cp done_str)
                                   (setq not-finished nil))
                               (push done_str persp-list))
                             (when not-finished
                               (if (eq 'reverse multiple)
                                   (setq retlst (append retlst (list cp)))
                                 (push cp retlst))
                               (setq persp-list (cl-delete cp persp-list :count 1)
                                     default done_str)))
                           (when not-finished
                             (setq not-finished default-mode)))
                          (pop
                           (let ((last-item (pop retlst)))
                             (unless retlst (setq persp-list (cl-delete done_str persp-list :count 1)
                                                  default nil))
                             (when last-item
                               (push last-item persp-list)))
                           (setq not-finished default-mode))
                          (t
                           (when (and cp (not (string= cp done_str))
                                      (member cp persp-list))
                             (push cp retlst))
                           (setq not-finished nil)))))
                  (remove-hook 'minibuffer-setup-hook persp-minibuffer-setup)
                  (when (keymapp mb-local-key-map)
                    (when (lookup-key mb-local-key-map push-keys)
                      (define-key mb-local-key-map push-keys push-keys-backup))
                    (when (lookup-key mb-local-key-map pop-keys)
                      (define-key mb-local-key-map pop-keys pop-keys-backup)))))
              retlst)
          (call-pif))))))
(define-obsolete-function-alias 'persp-prompt 'persp-read-persp "persp-mode 2.9")

(defsubst persp--set-frame-buffer-predicate-buffer-list-cache (buflist)
  (prog1
      (setq persp-frame-buffer-predicate-buffer-list-cache buflist)
    (unless persp-frame-buffer-predicate-buffer-list-cache
      (setq persp-frame-buffer-predicate-buffer-list-cache :nil))
    (run-at-time
     2 nil (lambda ()
             (setq persp-frame-buffer-predicate-buffer-list-cache nil)))))
(defmacro persp--get-frame-buffer-predicate-buffer-list-cache (buflist)
  `(if persp-frame-buffer-predicate-buffer-list-cache
       (if (eq :nil persp-frame-buffer-predicate-buffer-list-cache)
           nil
         persp-frame-buffer-predicate-buffer-list-cache)
     (persp--set-frame-buffer-predicate-buffer-list-cache ,buflist)))
(defun persp-generate-frame-buffer-predicate (opt)
  (if opt
      (eval
       `(lambda (b)
          (if (string-prefix-p " *temp*" (buffer-name (current-buffer)))
              t
            ,(cl-typecase opt
               (function
                `(funcall (with-no-warnings ',opt) b))
               (number
                `(let ((*persp-restrict-buffers-to* ,opt))
                   (memq
                    b (persp--get-frame-buffer-predicate-buffer-list-cache
                       (let ((ret
                              (persp-buffer-list-restricted
                               (selected-frame) ,opt
                               persp-restrict-buffers-to-if-foreign-buffer t)))
                         (if (persp-get-current)
                             ret
                           (cl-delete-if #'persp-buffer-filtered-out-p ret)))))))
               (symbol
                (cl-case opt
                  ((nil) t)
                  (restricted-buffer-list
                   '(progn
                      (memq
                       b (persp--get-frame-buffer-predicate-buffer-list-cache
                          (let ((ret
                                 (persp-buffer-list-restricted
                                  (selected-frame)
                                  *persp-restrict-buffers-to*
                                  persp-restrict-buffers-to-if-foreign-buffer
                                  t)))
                            (if (persp-get-current)
                                ret
                              (cl-delete-if #'persp-buffer-filtered-out-p ret)))))))
                  (t '(memq
                       b (persp--get-frame-buffer-predicate-buffer-list-cache
                          (let ((ret (persp-buffers (persp-get-current))))
                            (if (persp-get-current)
                                ret
                              (cl-delete-if #'persp-buffer-filtered-out-p ret))))))))
               (t t)))))
    nil))

(defun persp-set-frame-buffer-predicate (frame &optional off)
  (let ((old-pred (frame-parameter frame 'persp-buffer-predicate-old))
        (cur-pred (frame-parameter frame 'buffer-predicate))
        (last-persp-pred
         (frame-parameter frame 'persp-buffer-predicate-generated)))
    (let (new-pred)
      (if off
          (progn
            (set-frame-parameter frame 'persp-buffer-predicate-old nil)
            (set-frame-parameter frame 'persp-buffer-predicate-generated nil)
            (setq new-pred (if (eq cur-pred last-persp-pred) old-pred cur-pred))
            (set-frame-parameter frame 'buffer-predicate new-pred))
        (unless persp-frame-buffer-predicate
          (setq persp-frame-buffer-predicate
                (persp-generate-frame-buffer-predicate
                 persp-set-frame-buffer-predicate)))
        (if persp-frame-buffer-predicate
            (progn
              (set-frame-parameter frame 'persp-buffer-predicate-old
                                   (if (eq cur-pred last-persp-pred)
                                       old-pred (setq old-pred cur-pred)))
              (setq new-pred
                    (cl-case old-pred
                      ((nil) persp-frame-buffer-predicate)
                      (t `(lambda (b)
                            (and
                             (funcall (with-no-warnings
                                        ',persp-frame-buffer-predicate)
                                      b)
                             (funcall (with-no-warnings ',old-pred) b))))))
              (unless (symbolp new-pred)
                (setq new-pred (with-no-warnings
                                 (let ((warning-minimum-level :emergency)
                                       byte-compile-warnings)
                                   (byte-compile new-pred)))))
              (set-frame-parameter
               frame 'persp-buffer-predicate-generated new-pred)
              (set-frame-parameter frame 'buffer-predicate new-pred))
          (persp-set-frame-buffer-predicate frame t))))))

(defun persp-update-frames-buffer-predicate (&optional off)
  (unless off
    (setq persp-frame-buffer-predicate nil)
    (persp-update-frames-buffer-predicate t))
  (mapc (lambda (f) (persp-set-frame-buffer-predicate f off))
        (persp-frame-list-without-daemon)))


(defun persp-generate-frame-server-switch-hook (opt)
  (if opt
      (eval
       `(lambda (frame)
          (let* ((frame-client (frame-parameter frame 'client))
                 (frame-client-bl (when (processp frame-client)
                                    (process-get frame-client 'buffers))))
            ,(cl-case opt
               (only-file-windows
                `(if frame-client
                     (when frame-client-bl
                       (mapc (lambda (w)
                               (unless (memq (window-buffer w)
                                             frame-client-bl)
                                 (delete-window w)))
                             (window-list frame 'no-minibuf)))
                   (let (frame-server-bl)
                     (mapc (lambda (proc)
                             (setq frame-server-bl
                                   (append frame-server-bl
                                           (process-get proc 'buffers))))
                           (server-clients-with 'frame nil))
                     (when frame-server-bl
                       (mapc (lambda (w)
                               (unless (memq (window-buffer w)
                                             frame-server-bl)
                                 (delete-window w)))
                             (window-list frame 'no-minibuf))))))
               (only-file-windows-for-client-frame
                `(when frame-client-bl
                   (mapc (lambda (w)
                           (unless (memq (window-buffer w) frame-client-bl)
                             (delete-window w)))
                         (window-list frame 'no-minibuf))))
               (t (when (functionp opt)
                    `(funcall (with-no-warnings ',opt) frame)))))))
    nil))

(defun persp-set-frame-server-switch-hook (frame)
  (when (frame-parameter frame 'client)
    (set-frame-parameter
     frame 'persp-server-switch-hook persp-frame-server-switch-hook)))

(defun persp-update-frame-server-switch-hook ()
  (setq persp-frame-server-switch-hook
        (persp-generate-frame-server-switch-hook persp-server-switch-behaviour))
  (mapc #'persp-set-frame-server-switch-hook
        (persp-frame-list-without-daemon)))


(defun persp-ido-setup ()
  (unless *persp-pretend-switched-off*
    (when (eq ido-cur-item 'buffer)
      (setq persp-disable-buffer-restriction-once nil))))

(defun persp-restrict-ido-buffers ()
  "Support for the `ido-mode'."
  (unless *persp-pretend-switched-off*
    (let ((buffer-names-sorted
           (if persp-disable-buffer-restriction-once
               (mapcar #'buffer-name (persp-buffer-list-restricted nil -1 nil))
             (mapcar #'buffer-name (persp-buffer-list-restricted))))
          (indices (make-hash-table)))
      (let ((i 0))
        (dolist (elt ido-temp-list)
          (puthash elt i indices)
          (setq i (1+ i))))
      (setq ido-temp-list
            (sort buffer-names-sorted (lambda (a b)
                                        (< (gethash a indices 10000)
                                           (gethash b indices 10000))))))))

(defun persp-ido-toggle-filter ()
  (interactive)
  (setq persp-disable-buffer-restriction-once
        (not persp-disable-buffer-restriction-once)
        ido-text-init ido-text ido-exit 'refresh)
  (exit-minibuffer))
(define-obsolete-function-alias 'ido-toggle-persp-filter 'persp-ido-toggle-filter "persp-mode 4.0.0")


(cl-defun persp-read-buffer
    (prompt &optional default require-match predicate multiple (default-mode t))

  "Read buffers with restriction."

  (if *persp-pretend-switched-off*
      (read-buffer prompt default require-match predicate)

    (setq persp-disable-buffer-restriction-once nil)

    (when default
      (unless (stringp default)
        (if (and (bufferp default) (buffer-live-p default))
            (setq default (buffer-name default))
          (setq default nil))))

    (if prompt
        (setq prompt (car (split-string prompt ": *$" t)))
      (setq prompt "Please provide a buffer name: "))

    (let* ((buffer-names (mapcar #'buffer-name (persp-buffer-list-restricted)))
           cp retlst
           (done_str "[>done<]") (not-finished default-mode)

           (push-keys (alist-get 'push-item persp-read-multiple-keys))
           (pop-keys (alist-get 'pop-item persp-read-multiple-keys))
           push-keys-backup pop-keys-backup
           (toggle-filter-keys
            (alist-get 'toggle-persp-buffer-filter persp-read-multiple-keys))
           toggle-filter-keys-backup

           exit-minibuffer-function mb-local-key-map
           (persp-minibuffer-setup
            (lambda ()
              (setq mb-local-key-map (current-local-map))
              (when (keymapp mb-local-key-map)
                (unless exit-minibuffer-function
                  (setq exit-minibuffer-function
                        (or (lookup-key mb-local-key-map (kbd "RET"))
                            persp-read-multiple-exit-minibuffer-function)))
                (unless toggle-filter-keys-backup
                  (setq toggle-filter-keys-backup
                        (lookup-key mb-local-key-map toggle-filter-keys)))
                (define-key mb-local-key-map toggle-filter-keys
                  (lambda () (interactive)
                    (setq not-finished 'toggle-filter)
                    (funcall exit-minibuffer-function))))))
           (persp-multiple-minibuffer-setup
            (lambda ()
              (when (keymapp mb-local-key-map)
                (unless push-keys-backup
                  (setq push-keys-backup
                        (lookup-key mb-local-key-map push-keys)))
                (define-key mb-local-key-map push-keys
                  (lambda () (interactive)
                    (setq not-finished 'push)
                    (funcall exit-minibuffer-function)))
                (unless pop-keys-backup
                  (setq pop-keys-backup
                        (lookup-key mb-local-key-map pop-keys)))
                (define-key mb-local-key-map pop-keys
                  (lambda () (interactive)
                    (setq not-finished 'pop)
                    (funcall exit-minibuffer-function)))))))

      (while (member done_str buffer-names)
        (setq done_str (concat ">" done_str)))

      (unwind-protect
          (progn
            (when (and default (not (member default buffer-names)))
              (push default buffer-names)
              ;; TODO: remove this
              ;; (setq default nil)
              )
            (when multiple
              (add-hook 'minibuffer-setup-hook persp-multiple-minibuffer-setup))
            (add-hook 'minibuffer-setup-hook persp-minibuffer-setup)
            (while not-finished
              (setq cp
                    (funcall
                     persp-interactive-completion-function
                     (concat prompt
                             (and default (concat "(default " default ")"))
                             (and retlst
                                  (concat
                                   "< " (mapconcat #'identity retlst " ") " >"))
                             (and toggle-filter-keys
                                  (concat
                                   " [`" (help-key-description toggle-filter-keys nil)
                                   "' toggles filter]"))
                             ": ")
                     buffer-names predicate require-match nil nil default))
              (cl-case not-finished
                (push
                 (when (and cp (member cp buffer-names))
                   (if retlst
                       (when (string= cp done_str)
                         (setq not-finished nil))
                     (push done_str buffer-names))
                   (when not-finished
                     (if (eq 'reverse multiple)
                         (setq retlst (append retlst (list cp)))
                       (push cp retlst))
                     (setq buffer-names (cl-delete cp buffer-names :count 1)
                           default done_str)))
                 (when not-finished
                   (setq not-finished default-mode)))
                (pop
                 (let ((last-item (pop retlst)))
                   (unless retlst (setq buffer-names (cl-delete done_str buffer-names :count 1)
                                        default nil))
                   (when last-item
                     (push last-item buffer-names)))
                 (setq not-finished default-mode))
                (toggle-filter
                 (setq persp-disable-buffer-restriction-once
                       (not persp-disable-buffer-restriction-once))
                 (setq buffer-names
                       (cl-delete-if
                        (lambda (bn) (member bn retlst))
                        (mapcar #'buffer-name
                                (if persp-disable-buffer-restriction-once
                                    (funcall persp-buffer-list-function)
                                  (cl-delete-if #'persp-buffer-filtered-out-p
                                                (persp-buffer-list-restricted))))))
                 (setq not-finished default-mode))
                (t
                 (when (and cp (not (string= cp done_str))
                            (member cp buffer-names))
                   (push cp retlst))
                 (setq not-finished nil))))
            (if multiple retlst (car retlst)))
        (remove-hook 'minibuffer-setup-hook persp-multiple-minibuffer-setup)
        (remove-hook 'minibuffer-setup-hook persp-minibuffer-setup)
        (when (keymapp mb-local-key-map)
          (when multiple
            (when (lookup-key mb-local-key-map push-keys)
              (define-key mb-local-key-map push-keys push-keys-backup))
            (when (lookup-key mb-local-key-map pop-keys)
              (define-key mb-local-key-map pop-keys pop-keys-backup)))
          (when (lookup-key mb-local-key-map toggle-filter-keys)
            (define-key mb-local-key-map toggle-filter-keys
              toggle-filter-keys-backup)))
        (setq persp-disable-buffer-restriction-once nil)))))


(defmacro persp-with-nil-persp-hooks (&rest body)
  (let ((hook-list
         (cl-delete-if-not
          (apply-partially #'eq 'hook)
          (cl-mapcar #'car (get 'persp-mode 'custom-group))
          :key (lambda (s) (get s 'custom-type)))))
    `(let (,@(cl-mapcar (lambda (h) (list h nil))
                        hook-list))
       (progn
         ,@body))))

(defmacro persp-with-nil-emacs-window-hooks (&rest body)
  `(let (window-configuration-change-hook
         window-state-change-hook
         window-state-change-functions
         window-buffer-change-functions
         window-size-change-functions)
     ,@body))

(defmacro persp-with-nil-emacs-frame-hooks (&rest body)
  `(let (before-make-frame-hook
         after-make-frame-functions
         delete-frame-functions
         server-after-make-frame-hook
         (after-focus-change-function #'ignore))
     ,@body))

(defmacro persp-with-temp-frame (fvar &rest body)
  (cl-macrolet ((with-nil-frame-hooks
                 (&rest body)
                 ``(let ((*persp-pretend-switched-off* t)
                         ,@,(when (boundp 'server-switch-hook)
                              ''(server-switch-hook server-after-make-frame-hook))
                         ,@,(when ;; (and
                                (boundp 'focus-in-hook)
                              ;; (null (get 'focus-in-hook 'byte-obsolete-variable))
                              ;; )
                              ''(focus-in-hook focus-out-hook)))
                     (persp-with-nil-emacs-frame-hooks
                      (persp-with-nil-emacs-window-hooks
                       ,,@body)))))
    `(let (,fvar)
       ,(with-nil-frame-hooks
         `(progn
            (setq ,fvar
                  (make-frame (list ;; (cons 'window-system initial-window-system)
                               (cons 'visibility nil)
                               (cons 'fullscreen 'maximized)
                               ;; (cons 'z-group 'below)
                               (cons 'no-other-frame t)
                               (cons 'inhibit-double-buffering t)
                               ;; (cons 'shaded t)
                               (cons 'skip-taskbar t)
                               (cons 'no-focus-on-map t)
                               (cons 'no-accept-focus t)
                               ;; (cons 'undecorated t)
                               ;; (cons 'cursor-type nil)
                               (cons 'name "*persp-temp-frame*"))))
            (make-frame-invisible ,fvar t)
            (sit-for 0.01)
            (persp-delete-other-windows
             ,fvar
             (persp-get-create-window-to-stay-alive-before-config-put ,fvar))))
       (unwind-protect
           (progn
             ,@body)
         (when (frame-live-p ,fvar)
           ,(with-nil-frame-hooks
             `(delete-frame ,fvar t)))))))



;; Save/Load funcs:

(defun persp-configure-window-to-restore-window-conf (win)
  (when (window-live-p win)
    (let ((buf (get-scratch-buffer-create)))
      (with-current-buffer buf
        (setq-local window-size-fixed nil))
      (set-window-dedicated-p win nil)
      (set-window-buffer win buf)
      (set-window-parameter win 'no-other-window nil)
      (set-window-fringes win nil)
      (window-preserve-size win)
      (window-preserve-size win t)
      (mapc (lambda (wptn)
              (set-window-parameter win (car wptn) nil))
            (window-parameters win)))
    win))

(defun persp-get-create-window-to-stay-alive-before-config-put (&optional frame win)
  (setq frame (or frame (selected-frame))
        win (or (and (window-live-p win) win)
                (and frame
                     (if (eq (window-frame (selected-window)) frame)
                         (selected-window)
                       (frame-first-window frame)))))
  (when (and win
             (not (run-hook-with-args-until-failure
                   'persp-window-to-stay-alive-filter-functions
                   win)))
    (setq win (cl-loop
               for nwin in (window-list frame 1 (next-window win 1 nil))
               unless (run-hook-with-args-until-failure
                       'persp-window-to-stay-alive-filter-functions
                       nwin)
               return nwin)))
  (unless win
    (setq win
          (let ((split-width-threshold 2)
                (split-height-threshold 2)
                (window-safe-min-height 1)
                (window-safe-min-width 1)
                (window-min-height 1)
                (window-min-width 1)
                (window-resize-pixelwise t))
            (or
             (condition-case-unless-debug _err
                 (split-window (window-main-window frame) nil 'right)
               (error nil))
             (condition-case-unless-debug _err
                 (split-window (window-main-window frame) nil 'below)
               (error nil))))))
  (unless win
    (setq win (frame-first-window frame)))
  (when win
    (persp-configure-window-to-restore-window-conf win))
  win)

(defun persp-hide-side-windows (&optional frame)
  (setq frame (or frame (selected-frame)))
  (let ((window--sides-inhibit-check t)
        state)
    (when (window-with-parameter 'window-side nil frame)
      (set-frame-parameter frame 'persp-side-windows-state
                           (setq state
                                 (window-state-get (frame-root-window frame))))
      (let ((ignore-window-parameters t))
        (delete-other-windows (window-main-window frame)))
      state)))

(defun persp-restore-side-windows (&optional frame)
  (setq frame (or frame (selected-frame)))
  (let ((window--sides-inhibit-check t)
        (state (frame-parameter frame 'persp-side-windows-state)))
    (when state
      (let ((window-combination-resize t)
            (main-state (window-state-get (frame-root-window frame))))
        (window-state-put state (frame-root-window frame) t)
        (window-state-put main-state (window-main-window frame) t))
      (window--sides-reverse-frame frame)
      state)))

(defun persp-delete-other-windows (&optional frame win)
  (setq win (or (and (window-live-p win) win)
                (and frame (frame-first-window frame))
                (selected-window)))
  (when win
    (let ((ignore-window-parameters t)
          (window--sides-inhibit-check t))
      (condition-case-unless-debug err
          (progn (delete-other-windows win)
                 win)
        (error
         (message "[persp-mode] Warning: Can not delete-other-windows -- %S" err)
         nil)))))

(defun persp-window-state-get (&optional frame win writable)
  (setq frame (or frame (selected-frame))
        win (or win (funcall
                     persp-get-window-for-state-get-put-function
                     frame)))
  (let ((args (list frame win writable))
        (hook-i persp-before-window-state-get-functions)
        ret)
    (while (and hook-i (setq args (apply (car hook-i) args)))
      (setq hook-i (cdr hook-i)))
    (when args
      (setq ret (apply persp-window-state-get-function args))
      (setq hook-i persp-after-window-state-get-functions)
      (let ((tmp-ret ret))
        (while (and hook-i
                    (setq tmp-ret (apply (car hook-i) tmp-ret args)))
          (setq hook-i (cdr hook-i)))
        (when tmp-ret
          ret)))))

(defun persp-window-state-put (wc &optional frame win)
  (setq frame (or frame (selected-frame))
        win (or win (funcall
                     persp-get-window-for-state-get-put-function
                     frame)))
  (let ((args (list wc frame win))
        (hook-i persp-before-window-state-put-functions)
        ret)
    (while (and hook-i (setq args (apply (car hook-i) args)))
      (setq hook-i (cdr hook-i)))
    (when args
      ;; (setq wc    (car args)
      ;;       frame (cadr args)
      ;;       win   (caddr args))
      ;; (unless (window-live-p win)
      ;;   (setq win (funcall
      ;;              persp-get-window-for-state-get-put-function
      ;;              frame))
      ;;   (setq args (list wc frame win)))
      (setq ret (let ((ignore-window-parameters t)
                      (window--sides-inhibit-check t))
                  (apply persp-window-state-put-function args)))
      (setq hook-i persp-after-window-state-put-functions)
      (let ((tmp-ret ret))
        (while (and hook-i
                    (setq tmp-ret (apply (car hook-i) tmp-ret args)))
          (setq hook-i (cdr hook-i)))
        (when tmp-ret
          ret)))))

(cl-defun persp-restore-window-conf (&optional (frame (selected-frame))
                                               (persp (persp-of-frame frame))
                                               new-frame-p)
  (when new-frame-p (sit-for 0.01))
  (unless (run-hook-with-args-until-success 'persp-save-restore-window-conf-filter-functions
                                            frame persp new-frame-p)
    (let ((pwc (persp-window-conf persp))
          (split-width-threshold 2)
          (split-height-threshold 2)
          (window-safe-min-height 1)
          (window-safe-min-width 1)
          (window-min-height 1)
          (window-min-width 1)
          (window-resize-pixelwise t)
          (gr-mode (and (boundp 'golden-ratio-mode) golden-ratio-mode)))
      (when gr-mode (golden-ratio-mode -1))
      (unwind-protect
          (cond
           ((functionp persp-restore-window-conf-method)
            (funcall persp-restore-window-conf-method frame persp new-frame-p))
           ((null persp-restore-window-conf-method) nil)
           (t
            (let (win)
              (if pwc
                  (progn
                    (condition-case-unless-debug err
                        (persp-window-state-put pwc frame)
                      (error
                       (message
                        "[persp-mode] Warning: Can not restore the window \
configuration, because of the error -- %S" err)
                       (let* ((cw (frame-selected-window frame))
                              (cwb (window-buffer cw)))
                         (unless (persp-contain-buffer-p cwb persp)
                           (persp-set-another-buffer-for-window
                            cwb cw persp)))))
                    (when (and new-frame-p persp-is-ibc-as-f-supported)
                      (setq initial-buffer-choice
                            (lambda () persp-special-last-buffer))))
                (when persp-reset-windows-on-nil-window-conf
                  (if (functionp persp-reset-windows-on-nil-window-conf)
                      (funcall persp-reset-windows-on-nil-window-conf frame persp new-frame-p)
                    (let ((keep-side-windows
                           (memq nil
                                 persp-toggle-side-windows-around-window-state-get-put)))
                      (when keep-side-windows
                        (persp-hide-side-windows frame))
                      (setq win (persp-delete-other-windows
                                 frame
                                 (persp-get-create-window-to-stay-alive-before-config-put frame)))
                      (when keep-side-windows
                        (persp-restore-side-windows frame)))
                    (when (window-live-p win)
                      (let* ((pbs (persp-buffers persp))
                             (wb (window-buffer win)))
                        (when (and pbs (not (memq wb pbs)))
                          (persp-set-another-buffer-for-window wb win persp))))))))))
        (when gr-mode (golden-ratio-mode 1))))))


;; Save funcs

(cl-defun persp-frame-save-state
    (&optional (frame (selected-frame)) set-persp-special-last-buffer)
  (let ((persp (persp-of-frame frame)))
    (unless (run-hook-with-args-until-success
             'persp-save-restore-window-conf-filter-functions frame persp nil)
      (when set-persp-special-last-buffer
        (persp-special-last-buffer-make-current))
      (setf (persp-window-conf (or persp persp-nil-persp))
            (persp-window-state-get frame)))))

(cl-defun persp-save-state
    (&optional (persp (persp-of-frame)) exfr set-persp-special-last-buffer)
  (let ((frame (selected-frame)))
    (when (eq frame exfr) (setq frame nil))
    (unless (and frame (eq persp (persp-of-frame frame)))
      (setq frame (persp-find-other-frame-with-persp persp exfr t)))
    (when frame (persp-frame-save-state frame set-persp-special-last-buffer))))


(defun persp-make-buffer-narrowing-parameter-cons (buf)
  (when (and (buffer-live-p buf) (with-current-buffer buf
                                   (buffer-narrowed-p)))
    (cons 'narrow (with-current-buffer buf
                    (cons (point-min) (point-max))))))

(defun persp-buffers-to-savelist (persp)
  (cl-delete-if
   #'symbolp
   (let (find-ret)
     (mapcar (lambda (b)
               (setq find-ret nil)
               (ignore
                (cl-find-if (lambda (sl) (when sl (setq find-ret sl)))
                            persp-save-buffer-functions
                            :key (lambda (s-f) (with-current-buffer b
                                            (funcall s-f b)))))
               find-ret)
             (if (persp-nil-p persp)
                 (cl-delete-if-not #'persp-buffer-free-p
                                   (funcall persp-buffer-list-function))
               (persp-buffers persp))))))

(defun persp-elisp-object-readable-p (obj)
  (let (print-length print-level)
    (or (stringp obj)
        (not (string-match-p "#<.*?>" (prin1-to-string obj))))))

(defun persp-window-conf-to-readable-homemade (wc)
  (cl-labels
      ((wc-to-writable
        (it)
        (cond
         ((and it (listp it))
          (cl-destructuring-bind (head . tail) it
            (cond
             ;; ((listp head)
             ;;  (cons (wc-to-writable head)
             ;;        (wc-to-writable tail)))
             ((eq 'parameters head)
              (let ((rw-params
                     (delq nil
                           (mapcar
                            #'(lambda (pc)
                                (when
                                    (and
                                     (eq 'writable
                                         (alist-get (car pc) window-persistent-parameters))
                                     (persp-elisp-object-readable-p (cdr pc)))
                                  pc))
                            tail))))
                (if rw-params
                    `(parameters
                      ,@rw-params)
                  :delete)))
             (t
              (let ((new-head (wc-to-writable head))
                    (new-tail (wc-to-writable tail)))
                (when (eq :delete new-tail)
                  (setq new-tail nil))
                (if (eq :delete new-head)
                    new-tail
                  (cons new-head
                        new-tail)))))))
         ((bufferp it)
          (if (buffer-live-p it)
              (buffer-name it)
            "*Messages*"))
         ((markerp it)
          (marker-position it))
         (t it))))
    (wc-to-writable wc)))

(defun persp-window-conf-to-savelist (persp &optional wccp-or-frame)
  "When wccp-or-frame -- convert window config to writable form for
writing to a file. For convertion it will set window configuration
of selected frame so you must save/restore it if needed."
  (let ((wc (persp-window-conf persp))
        (frame (when wccp-or-frame (if (framep wccp-or-frame)
                                       wccp-or-frame (selected-frame)))))
    (unless (or persp-use-workgroups
                (persp-elisp-object-readable-p wc))
      (when frame
        (condition-case-unless-debug err
            (progn
              (persp-window-state-put wc frame)
              (setq wc (persp-window-state-get frame nil t)))
          (error
           (message "[persp-mode] Error: Can't convert window configuration to \
readable/writable form: %S" err)
           (message "[persp-mode] trying to convert with homemade method")
           (setq wc (persp-window-conf-to-readable-homemade
                     (persp-window-conf persp)))))))
    `(def-wconf ,(if (or persp-use-workgroups
                         (not (version< emacs-version "24.4")))
                     wc
                   nil))))

(defun persp-parameters-to-savelist (persp)
  `(def-params ,(cl-remove-if
                 (lambda (param)
                   (and (not (persp-elisp-object-readable-p param))
                        (message "[persp-mode] Info: The parameter %S \
of the perspective %S can't be saved."
                                 param (persp-name persp))
                        t))
                 (persp-parameters persp))))

(defun persp-to-savelist (persp &optional wccp-or-frame)
  "Also see `persp-window-conf-to-savelist' docstring."
  `(def-persp ,(and (not (persp-nil-p persp)) (persp-name persp))
     ,(persp-buffers-to-savelist persp)
     ,(persp-window-conf-to-savelist persp wccp-or-frame)
     ,(persp-parameters-to-savelist persp)
     ,(persp-weak persp)
     ,(persp-auto persp)
     ,(persp-hidden persp)))

(defun persps-to-savelist (&optional phash names-regexp)
  (unless phash (setq phash *persp-hash*))
  (let ((persplist (cl-delete-if
                    (apply-partially #'persp-parameter 'dont-save-to-file)
                    (if (eq phash *persp-hash*)
                        (if names-regexp
                            (let (p)
                              (nreverse
                               (cl-reduce (lambda (acc pn)
                                            (setq p (if (persp-string-match-p names-regexp pn)
                                                        (persp-get-by-name pn phash)
                                                      persp-not-persp))
                                            (if (persp-p p) (cons p acc) acc))
                                          (persp-names-current-frame-fast-ordered)
                                          :initial-value nil)))
                          (mapcar #'persp-get-by-name
                                  (persp-names-current-frame-fast-ordered)))
                      (persp-persps phash names-regexp t)))))
    (when persplist
      (persp-with-temp-frame
       tmpf
       (persp-with-nil-emacs-window-hooks
        (mapcar (lambda (p) (persp-to-savelist p tmpf)) persplist))))))

(defsubst persp-save-with-backups (fname)
  (when (and (string= fname
                      (concat (expand-file-name persp-save-dir)
                              persp-auto-save-fname))
             (> persp-auto-save-num-of-backups 0))
    (cl-do ((cur persp-auto-save-num-of-backups (1- cur))
         (prev (1- persp-auto-save-num-of-backups) (1- prev)))
        ((> 1 cur) nil)
      (let ((cf (concat fname (number-to-string cur)))
            (pf (concat fname (if (> prev 0)
                                  (number-to-string prev)
                                ""))))
        (when (file-exists-p pf)
          (when (file-exists-p cf)
            (delete-file cf))
          (rename-file pf cf t))))
    (when (file-exists-p fname)
      (rename-file fname (concat fname (number-to-string 1)) t)))
  (write-file fname nil)
  t)

(defun persp-savelist-to-file (savelist fname)
  (when (and savelist (stringp fname))
    (let ((p-save-dir (or (file-name-directory fname)
                          (expand-file-name persp-save-dir)))
          (p-save-file (file-name-nondirectory fname)))
      (when (cond
             ((< (string-width p-save-file) 1)
              (message "[persp-mode] Error: You must provide nonempty filename to save perspectives.")
              nil)
             ((not (and (file-exists-p p-save-dir)
                        (file-directory-p p-save-dir)))
              (message "[persp-mode] Info: Trying to create the `persp-conf-dir'.")
              (make-directory p-save-dir t)
              (if (and (file-exists-p p-save-dir)
                       (file-directory-p p-save-dir))
                  t
                (message "[persp-mode] Error: Can't save perspectives -- \
`persp-save-dir' does not exists or not a directory %S." p-save-dir)
                nil))
             (t t))
        (mapc
         (lambda (pslist)
           (let* ((params-cons (assq 'def-params pslist))
                  (params (cadr params-cons)))
             (setf (cadr params-cons)
                   (cl-delete-if (apply-partially #'eq 'persp-file)
                                 params
                                 :key #'car))))
         savelist)
        (with-temp-buffer
          (buffer-disable-undo)
          (erase-buffer)
          (goto-char (point-min))
          (insert
           ";; -*- mode: emacs-lisp; eval: (progn (pp-buffer) (indent-buffer)) -*-")
          (newline)
          (insert (let (print-length print-level)
                    (pp-to-string savelist)))
          (persp-save-with-backups (concat p-save-dir p-save-file)))))))

(cl-defun persp-save-state-to-file
    (&optional
     (fname persp-auto-save-fname) (phash *persp-hash*)
     (respect-persp-file-parameter persp-auto-save-persps-to-their-file)
     (keep-others-in-non-parametric-file 'no))
  (interactive (list (read-file-name "Save perspectives to a file: "
                                     persp-save-dir "")))

  (mapc #'persp-save-state (persp-persps phash))
  (run-hook-with-args 'persp-before-save-state-to-file-functions
                      fname phash respect-persp-file-parameter)

  (if respect-persp-file-parameter
      (let (persp-auto-save-persps-to-their-file
            persp-before-save-state-to-file-functions) ; ?
        (mapc (lambda (gr)
                (cl-destructuring-bind (pfname . pl) gr
                  (let ((names (mapcar #'persp-name pl)))
                    (persp-save-to-file-by-names
                     (or pfname fname) phash names
                     (if pfname 'yes keep-others-in-non-parametric-file)
                     nil))))
              (persp-group-by
               (apply-partially #'persp-parameter 'persp-file)
               (persp-persps phash nil t) t)))
    (persp-savelist-to-file (persps-to-savelist phash) fname)))

(cl-defun persp-save-to-file-by-names
    (&optional (fname persp-auto-save-fname) (phash *persp-hash*) names
               keep-others (called-interactively-p (called-interactively-p 'any)))
  (interactive ;; (list (read-file-name "Save perspectives to a file: "
   ;;                       persp-save-dir ""))
   )

  (when called-interactively-p
    (unless names
      (setq names (persp-read-persp
                   "to save" 'reverse (persp-name (persp-get-current))
                   t nil nil nil nil 'push)))
    (setq fname (read-file-name
                 (format "Save a subset of perspectives%s to a file: " names)
                 persp-save-dir))
    (unless keep-others
      (setq keep-others
            (if (and (file-exists-p fname)
                     (yes-or-no-p "Keep other perspectives in the file?"))
                'yes 'no))))

  (when (and names fname)
    (let* ((names-regexp (regexp-opt names))
           (savelist (persps-to-savelist phash names-regexp)))
      (when savelist
        (when (or (eq keep-others 'yes) (eq keep-others t))
          (mapc
           (lambda (pslist) (push pslist savelist))
           (persp-savelist-filter-by-names-regexp
            (persp-savelist-from-savefile fname)
            (cons :not names-regexp))))
        (persp-savelist-to-file savelist fname)))))

(defun persp-indirect-save-buffer (b)
  (let ((base (buffer-base-buffer b)))
    (when base
      (let* ((narrowing (persp-make-buffer-narrowing-parameter-cons b))
             (params (list (cons 'indirect (buffer-name base)))))
        (when narrowing
          (push narrowing params))
        `(def-buffer ,(buffer-name b)
           ,(buffer-file-name base)
           ,(buffer-local-value 'major-mode b)
           ,params)))))

(defun persp-dired-save-buffer (b)
  (when (eq 'dired-mode (buffer-local-value 'major-mode b))
    `(def-buffer ,(buffer-name b)
       ,(buffer-local-value 'default-directory b)
       ,(buffer-local-value 'major-mode b)
       ,(let ((narrowing-param
               (persp-make-buffer-narrowing-parameter-cons b)))
          (when narrowing-param
            (list narrowing-param))))))

(defun persp-standard-save-buffer (b)
  `(def-buffer ,(buffer-name b)
     ,(buffer-file-name b)
     ,(buffer-local-value 'major-mode b)
     ,(let ((narrowing-param
             (persp-make-buffer-narrowing-parameter-cons b)))
        (when narrowing-param
          (list narrowing-param)))))

(defun persp-tramp-save-buffer (b)
  (let* ((buf-f-name (buffer-file-name b))
         (persp-tramp-file-name
          (when (and (or (featurep 'tramp) (require 'tramp nil t))
                     (tramp-tramp-file-p buf-f-name))
            (let ((dissected-f-name (tramp-dissect-file-name buf-f-name))
                  tmh)
              (if (tramp-file-name-method dissected-f-name)
                  (when (and
                         (or (featurep 'tramp-sh) (require 'tramp-sh nil t))
                         (fboundp 'tramp-compute-multi-hops)
                         (setq tmh
                               (condition-case-unless-debug _err
                                   (tramp-compute-multi-hops dissected-f-name)
                                 (error nil))))
                    (let ((persp-tramp-file-name tramp-prefix-format))
                      (while tmh
                        (let* ((hop (car tmh))
                               (method   (tramp-file-name-method hop))
                               (user     (tramp-file-name-user hop))
                               (host     (tramp-file-name-host hop))
                               (port     (tramp-file-name-port hop))
                               (filename (tramp-file-name-localname hop)))
                          (setq persp-tramp-file-name
                                (concat
                                 persp-tramp-file-name
                                 method tramp-postfix-method-format
                                 user (when user tramp-postfix-user-format)
                                 host
                                 (when port tramp-prefix-port-format)
                                 port
                                 (if (= (string-width filename) 0)
                                     tramp-postfix-hop-format
                                   (concat
                                    tramp-postfix-host-format filename)))
                                tmh (cdr tmh))))
                      persp-tramp-file-name))
                buf-f-name)))))
    (when persp-tramp-file-name
      `(def-buffer ,(buffer-name b)
         ,persp-tramp-file-name
         ,(buffer-local-value 'major-mode b)
         ,(let ((narrowing-param
                 (persp-make-buffer-narrowing-parameter-cons b)))
            (when narrowing-param
              (list narrowing-param)))))))

;; Load funcs

(defun persp-update-frames-window-confs (&optional persp-names)
  (mapc #'persp-restore-window-conf
        (if persp-names
            (cl-delete-if-not
             (lambda (pn) (member pn persp-names))
             (persp-frame-list-without-daemon)
             :key (lambda (f) (persp-name (persp-of-frame f))))
          (persp-frame-list-without-daemon))))

(defun persp-convert-window-confs (&optional persp-names from/to)
  (when (and persp-names
             (not persp-use-workgroups) (not (version< emacs-version "24.4")))
    (let ((sftr (selected-frame)))
      (persp-with-temp-frame
       tmpf
       (persp-with-nil-emacs-window-hooks
        (mapc (lambda (p)
                (let ((wc (persp-window-conf p)))
                  (when wc
                    (persp-window-state-put wc tmpf)
                    (setf (persp-window-conf (or p persp-nil-persp))
                          (persp-window-state-get tmpf nil
                                                  (eq from/to 'to-readable))))))
              (persp-persps *persp-hash* (regexp-opt persp-names)))))
      (when sftr
        (select-frame sftr)))))

(defmacro persp-car-as-fun-cdr-as-args (lst)
  (let ((kar (gensym "lst-car")))
    `(let* ((,kar (car-safe ,lst))
            (args (cdr-safe ,lst))
            (fun (or (condition-case-unless-debug _err
                         (symbol-function ,kar)
                       (error nil))
                     (symbol-value ,kar))))
       (if (functionp fun)
           (apply fun args)
         (message "[persp-mode] Error: %S is not a function." fun)))))

(defun persp-buffer-from-savelist (savelist)
  (defvar def-buffer)
  (when (eq 'def-buffer (car savelist))
    (let*
        (persp-add-buffer-on-find-file
         (already-loaded-p
          (lambda (bname fname _mode parameters)
            (let ((buf (persp-get-buffer-or-null bname))
                  (base (alist-get 'indirect parameters)))
              (and
               (cond
                ((not (buffer-live-p buf)) nil)
                ((stringp base)
                 (or (and (buffer-local-boundp 'persp-indirect-buffer-restore-info buf)
                          (buffer-local-value 'persp-indirect-buffer-restore-info buf))
                     (let ((bbase (buffer-base-buffer buf)))
                       (and bbase (string= base (buffer-name bbase))))))
                ((bufferp base)
                 (eq base (buffer-base-buffer buf)))
                (t
                 (and fname (buffer-file-name buf)
                      (string= fname (buffer-file-name buf)))))
               buf))))
         (solve-name-conflict
          (lambda (bname fname mode parameters)
            (let ((buf (persp-get-buffer-or-null bname))
                  user-can-input-p conflict-behaviour)
              (cond
               ((and (buffer-live-p buf) persp-load-buffer-name-conflict-behaviour)
                (message "[persp-mode] Info: buffer name(%S) conflict while loading"
                         bname)
                (setq user-can-input-p (persp-frame-list-without-daemon)
                      conflict-behaviour persp-load-buffer-name-conflict-behaviour)
                (when (eq 'ask conflict-behaviour)
                  (setq conflict-behaviour
                        (if user-can-input-p
                            (cl-destructuring-bind (char &rest rest)
                                (read-multiple-choice
                                 "How to solve name conflict: "
                                 '((?e "use existing buffer")
                                   (?n "new name for new buffer")
                                   (?N "New name for old buffer")
                                   (?r "replace")
                                   (?s "skip loading buffer")
                                   (?g "generate new name")))
                              (cl-case char
                                ((?s ?\C-g ?\C-\[) 'skip)
                                (?e 'merge)
                                (?n 'rename-new)
                                (?N 'rename-old)
                                (?r 'overwrite)
                                (?g 'autorename)
                                (t 'autorename)))
                          'autorename)))
                (cl-case conflict-behaviour
                  ((rename-new rename-old autorename)
                   (let ((new-name bname))
                     (while (persp-get-buffer-or-null new-name)
                       (setq new-name
                             (cond
                              ((or (eq 'autorename conflict-behaviour)
                                   (not user-can-input-p))
                               (generate-new-buffer-name new-name))
                              (t
                               (read-string "New name: " new-name)))))
                     (cl-case conflict-behaviour
                       (rename-old
                        (with-current-buffer buf
                          (condition-case err
                              (rename-buffer new-name)
                            (error
                             (message "[persp-mode] Warning: Can not rename buffer(%S) to name(%S): %S"
                                      bname new-name err))))
                        bname)
                       (t new-name))))
                  (overwrite (kill-buffer buf)
                             bname)
                  (merge bname)
                  (skip nil)
                  (t (if (functionp conflict-behaviour)
                         (funcall conflict-behaviour
                                  bname fname (list mode parameters))
                       bname))))
               (t bname)))))
         (restore-file
          (lambda (bname fname)
            (let ((buf (persp-get-buffer-or-null bname)))
              (cond
               ((or (null fname) (and (buffer-live-p buf)
                                      (string= fname (buffer-file-name buf))))
                buf)
               ((file-exists-p fname)
                (find-file-noselect fname))
               (t
                (message
                 "[persp-mode] Warning: The file %S no longer exists."
                 fname)
                (run-hook-with-args-until-success
                 'persp-load-buffer-handle-missing-file-functions
                 savelist))))))
         (restore-props
          (lambda (buf bname _fname mode parameters)
            (when (buffer-live-p buf)
              (cl-macrolet
                  ((restorevars
                    ()
                    `(mapc
                      (lambda (varcons)
                        (cl-destructuring-bind (vname . vvalue) varcons
                          (unless (or (eq vname 'buffer-file-name)
                                      (eq vname 'major-mode))
                            (set (make-local-variable vname) vvalue))))
                      (alist-get 'local-vars parameters))))
                (with-current-buffer buf
                  (unless (string= bname (buffer-name buf))
                    (condition-case err
                        (rename-buffer bname)
                      (error
                       (message "[persp-mode] Warning: Can not rename loaded buffer to name(%S): %S"
                                bname err))))
                  (restorevars)
                  (cond
                   ((and (boundp 'persp-load-buffer-mode-restore-function)
                         (variable-binding-locus 'persp-load-buffer-mode-restore-function)
                         (functionp persp-load-buffer-mode-restore-function))
                    (funcall persp-load-buffer-mode-restore-function mode)
                    (restorevars))
                   ((functionp mode)
                    (when (and (not (eq major-mode mode))
                               (not (eq major-mode 'not-loaded-yet)))
                      (funcall mode)
                      (restorevars))))
                  (let ((nrw-param (alist-get 'narrow parameters)))
                    (when nrw-param
                      (narrow-to-region (car nrw-param) (cdr nrw-param)))))))
            buf))
         (def-buffer
           (lambda (bname fname mode &optional parameters)
             (let ((buf (funcall already-loaded-p bname fname mode parameters))
                   (base (alist-get 'indirect parameters)))
               (unless (or (buffer-live-p buf) (bufferp base))
                 (setq bname (funcall solve-name-conflict
                                      bname fname mode parameters)))
               (cond
                ((buffer-live-p buf) buf)
                ((null bname) nil)
                ((stringp base)
                 (setq buf (generate-new-buffer bname))
                 (with-current-buffer buf
                   (setq-local persp-indirect-buffer-restore-info
                               (list bname fname mode parameters base)))
                 (push buf persp-indirect-buffers-to-restore)
                 buf)
                ((bufferp base)
                 (setq buf (persp-get-buffer-or-null bname))
                 (let ((persps (persp--buffer-in-persps buf)))
                   (dolist (p persps)
                     (persp--buffer-in-persps-remove buf p)
                     (setf (persp-buffers p) (delq buf (persp-buffers p))))
                   (with-current-buffer buf
                     (rename-buffer (generate-new-buffer-name bname) t))
                   (let ((*persp-pretend-switched-off*))
                     (kill-buffer buf))
                   (setq buf (let ((*persp-pretend-switched-off* t))
                               (make-indirect-buffer base bname t)))
                   (when (buffer-live-p buf)
                     (dolist (p persps)
                       (unless (persp-contain-buffer-p buf p)
                         (persp--buffer-in-persps-add buf p)
                         (setf (persp-buffers p) (cons buf (persp-buffers p)))))
                     (funcall restore-props
                              buf bname fname mode parameters)
                     buf)))
                (t
                 (setq buf (or (funcall restore-file bname fname)
                               (get-buffer-create bname)))
                 (funcall restore-props
                          buf bname fname mode parameters)))))))
      (condition-case-unless-debug err
          (persp-car-as-fun-cdr-as-args savelist)
        (error
         (message "[persp-mode] Error details: %S" savelist)
         (message "[persp-mode] Error: persp-buffer-from-savelist failed to restore a buffer -- %S" err)
         nil)))))

(defun persp-buffers-from-savelist-0 (savelist)
  (cl-delete-if-not
   #'persp-get-buffer-or-null
   (let (find-ret)
     (mapcar
      (lambda (saved-buf)
        (setq find-ret nil)
        (ignore
         (cl-find-if
          (lambda (lb) (when lb (setq find-ret lb)))
          persp-load-buffer-functions
          :key (lambda (l-f)
                 (condition-case-unless-debug err
                     (funcall l-f saved-buf)
                   (error
                    (message "[persp-mode] Error details: %S" saved-buf)
                    (message "[persp-mode] Error: Failed to resume buffer using %S load buffer function -- %S" l-f err)
                    nil)))))
        find-ret)
      savelist))))

(defun persp-window-conf-from-savelist-0 (savelist)
  (defvar def-wconf)
  (let ((def-wconf #'identity))
    (persp-car-as-fun-cdr-as-args savelist)))

(defun persp-parameters-from-savelist-0 (savelist)
  (defvar def-params)
  (let ((def-params #'identity))
    (persp-car-as-fun-cdr-as-args savelist)))

(defun persp-from-savelist-0 (savelist phash persp-file)
  (defvar def-persp)
  (let ((def-persp
          (lambda (name dbufs dwc &optional dparams weak auto hidden)
            (let* ((pname (or name persp-nil-name))
                   (persp (persp-get-by-name pname phash)))
              (when (and (perspective-p persp) persp-load-name-conflict-behaviour)
                (let ((user-can-input-p (persp-frame-list-without-daemon))
                      (conflict-behaviour persp-load-name-conflict-behaviour))
                  (message "[persp-mode] Info: Perspective name(%S) conflict while loading from %S"
                           pname persp-file)
                  (when (eq 'ask conflict-behaviour)
                    (setq conflict-behaviour
                          (if user-can-input-p
                              (cl-destructuring-bind (char &rest rest)
                                  (read-multiple-choice
                                   "How to solve name conflict: "
                                   '((?m "merge")
                                     (?r "rename new persp")
                                     (?R "Rename old persp")
                                     (?o "overwrite")
                                     (?s "skip loading persp")
                                     (?g "generate new name")))
                                (cl-case char
                                  ((?s ?\C-g ?\C-\[) 'skip)
                                  (?m 'merge)
                                  (?r 'rename-new)
                                  (?R 'rename-old)
                                  (?o 'overwrite)
                                  (?g 'autorename)
                                  (t 'autorename)))
                            'autorename)))
                  (setq pname
                        (cl-case conflict-behaviour
                          ((rename-new rename-old autorename)
                           (let ((new-name pname))
                             (while (persp-with-name-exists-p new-name)
                               (setq new-name
                                     (cond
                                      ((or (eq 'autorename conflict-behaviour)
                                           (not user-can-input-p))
                                       (persp-gen-random-name new-name phash))
                                      (t
                                       (read-string "New name: " new-name)))))
                             (cl-case conflict-behaviour
                               (rename-old
                                (persp-rename new-name persp phash)
                                pname)
                               (t new-name))))
                          (overwrite
                           (if (and user-can-input-p (eq phash *persp-hash*))
                               (persp-kill pname)
                             (persp-remove-by-name pname phash))
                           pname)
                          (merge pname)
                          (skip nil)
                          (t (if (functionp conflict-behaviour)
                                 (funcall conflict-behaviour pname persp-file phash)
                               pname))))))
              (setq persp (if pname
                              (persp-add-new pname phash)
                            persp-not-persp))
              (when (perspective-p persp)
                (mapc (lambda (b)
                        (persp-add-buffer b persp nil nil))
                      (condition-case-unless-debug err
                          (persp-buffers-from-savelist-0 dbufs)
                        (error
                         (message "[persp-mode] Error details: %S" dbufs)
                         (message "[persp-mode] Error: failed to load buffers for %S perspective from %S file -- %S" pname persp-file err)
                         nil)))
                (let ((loaded-wconf
                       (condition-case-unless-debug err
                           (persp-window-conf-from-savelist-0 dwc)
                         (error
                          (message "[persp-mode] Error details: %S" dwc)
                          (message "[persp-mode] Error: failed to load window configuration for %S perspective from %S file -- %S" pname persp-file err)
                          nil))))
                  (when loaded-wconf
                    (setf (persp-window-conf (or persp persp-nil-persp)) loaded-wconf)))
                (persp-modify-parameters
                 (condition-case-unless-debug err
                     (persp-parameters-from-savelist-0 dparams)
                   (error
                    (message "[persp-mode] Error details: %S" dparams)
                    (message "[persp-mode] Error: Failed to load %S perspective parameters from %S file -- %S" pname persp-file err)
                    nil))
                 persp)
                (unless (persp-nil-p persp)
                  (setf (persp-weak persp) weak
                        (persp-auto persp) auto))

                (setf (persp-hidden (or persp persp-nil-persp)) hidden)

                (when persp-file
                  (persp-set-parameter 'persp-file persp-file persp)))
              pname))))
    (persp-car-as-fun-cdr-as-args savelist)))

(defun persps-from-savelist-0
    (savelist phash persp-file set-persp-file names-regexp)
  (when (and names-regexp (not (consp names-regexp)))
    (setq names-regexp (cons t names-regexp)))
  (when savelist
    (delq nil
          (mapcar (lambda (pd)
                    (condition-case-unless-debug err
                        (persp-from-savelist-0 pd phash (and set-persp-file persp-file))
                      (error
                       (message "[persp-mode] Error details: %S" pd)
                       (message "[persp-mode] Error: Can not load a perspective from %S file -- %S" persp-file err)
                       nil)))
                  (persp-savelist-filter-by-names-regexp
                   savelist names-regexp "0")))))

(defun persp-name-from-savelist-0 (savelist)
  (or (cadr savelist) persp-nil-name))

(defun persp-names-from-savelist-0 (savelist)
  (mapcar #'persp-name-from-savelist-0 savelist))

(defun persps-savelist-version-string (savelist)
  (let* ((version-list (car savelist))
         (version (or (and (eq (car version-list)
                               'def-persp-save-format-version)
                           (cadr version-list))
                      0)))
    (list
     (format "%S" version)
     (if (eql version 0)
         savelist
       (cdr savelist)))))

(defun persp-dispatch-loadf-version (funsym savelist &optional version-str)
  (unless version-str
    (cl-destructuring-bind (ver-str s-list)
        (persps-savelist-version-string savelist)
      (cl-psetq version-str ver-str
                savelist s-list)))
  (let ((funame (intern (concat (symbol-name funsym) "-" version-str))))
    (if (fboundp funame)
        (list funame savelist version-str)
      (message
       "[persp-mode] Warning: Can not find load function for this version: %S."
       version-str)
      (list nil savelist version-str))))

(defun persps-from-savelist
    (savelist phash persp-file set-persp-file names-regexp &optional version-str)
  (cl-destructuring-bind (fun s-list _ver-str)
      (persp-dispatch-loadf-version 'persps-from-savelist savelist version-str)
    (if fun
        (let ((persp-names
               (funcall fun s-list phash persp-file set-persp-file names-regexp)))
          (unless *persp-pretend-switched-off*
            (run-hook-with-args 'persp-after-load-state-functions persp-file phash
                                persp-names))
          persp-names)
      (message
       "[persp-mode] Error: Can not load perspectives from savelist: %S
\tloaded from %S" savelist persp-file)
      nil)))

(defun persp-savelist-filter-by-names-regexp (savelist names-regexp &optional version-str)
  (cl-destructuring-bind (name-fun s-list _ver-str)
      (persp-dispatch-loadf-version 'persp-name-from-savelist savelist version-str)
    (if name-fun
        (if names-regexp
            (cl-delete-if-not
             (apply-partially #'persp-string-match-p names-regexp)
             s-list
             :key name-fun)
          s-list)
      savelist)))

(defun persp-savelist-from-savefile (fname)
  (let ((p-save-file (concat (or (file-name-directory fname)
                                 (expand-file-name persp-save-dir))
                             (file-name-nondirectory fname))))
    (if (and p-save-file (file-exists-p p-save-file))
        (with-temp-buffer
          (buffer-disable-undo)
          (insert-file-contents p-save-file nil nil nil t)
          (goto-char (point-min))
          (read (current-buffer)))
      (message "[persp-mode] Error: No such file -- %S." p-save-file)
      nil)))


(defun persp-list-persp-names-in-file (&optional fname savelist version-str)
  (unless savelist
    (setq savelist (persp-savelist-from-savefile fname)))
  (when savelist
    (cl-destructuring-bind (fun s-list _ver-str)
        (persp-dispatch-loadf-version 'persp-names-from-savelist savelist version-str)
      (if fun
          (funcall fun s-list)
        (message
         "[persp-mode] Error: Can not list perspective names in file %S."
         fname)
        nil))))


(cl-defun persp-load-state-from-file
    (&optional (fname persp-auto-save-fname) (phash *persp-hash*)
               names-regexp set-persp-file savelist)
  (interactive (list (read-file-name "Load perspectives from a file: "
                                     persp-save-dir)))
  (let ((gc-cons-threshold (* 4 gc-cons-threshold)))
   (unless savelist
     (setq savelist (persp-savelist-from-savefile fname)))
   (when savelist
     (persps-from-savelist
      savelist phash fname set-persp-file names-regexp))))

(cl-defun persp-load-from-file-by-names (&optional (fname persp-auto-save-fname)
                                                   (phash *persp-hash*)
                                                   names savelist)
  (interactive
   (list (read-file-name "Load a subset of perspectives from a file: "
                         persp-save-dir)))
  (unless savelist
    (setq savelist (persp-savelist-from-savefile fname)))
  (when (and (not names) savelist)
    (let ((available-names (persp-list-persp-names-in-file fname savelist)))
      (when available-names
        (setq names
              (persp-read-persp
               "to load" 'reverse nil t nil nil available-names t 'push)))))
  (when names
    (let ((names-regexp (regexp-opt names)))
      (persp-load-state-from-file fname phash names-regexp t savelist))))


(provide 'persp-mode)



;; Local Variables:
;; indent-tabs-mode: nil
;; End:

;;; persp-mode.el ends here
