;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-chrome" "1.151223.0.20160719.7"
  "Helm interface for Chrome bookmarks."
  '((helm   "1.5")
    (cl-lib "0.3")
    (emacs  "24"))
  :url "https://github.com/kawabata/helm-chrome"
  :commit "fd630ace4b4b4f33355a973743bbfe0c90ce4830"
  :revdesc "fd630ace4b4b"
  :keywords '("tools")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
