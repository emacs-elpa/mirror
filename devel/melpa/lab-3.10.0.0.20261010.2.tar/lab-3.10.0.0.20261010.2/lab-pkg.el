;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab" "3.10.0.0.20261010.2"
  "An interface for GitLab."
  '((emacs       "27.1")
    (request     "0.3.2")
    (s           "1.10.0")
    (f           "0.20.0")
    (compat      "29.1.4.4")
    (promise     "1.1")
    (async-await "1.1"))
  :url "https://github.com/isamert/lab.el"
  :commit "180148f2b6fe6e52149decf70dadfd5ac51b3c0a"
  :revdesc "v3.10.0-2-g180148f2b6fe"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
