;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "2.5.0.0.20260709.17"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "f32940100035438934d626adb99cfc63036de490"
  :revdesc "2.5.0-17-gf32940100035"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
