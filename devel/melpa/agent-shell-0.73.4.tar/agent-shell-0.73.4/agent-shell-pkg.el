;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.73.4"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "bb4fa12a0cb8ff285a9c9446767bb3324df0477d"
  :revdesc "bb4fa12a0cb8")
