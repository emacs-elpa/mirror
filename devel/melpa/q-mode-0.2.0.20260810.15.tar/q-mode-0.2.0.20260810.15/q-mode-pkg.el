;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2.0.20260810.15"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "d951be62b2625dadd0a398ab6c93512f6d9e4f3c"
  :revdesc "d951be62b262"
  :keywords '("faces" "files" "q"))
