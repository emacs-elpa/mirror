;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gregorio-mode" "1.0.0.20170705.7"
  "Gregorio Mode for .gabc files."
  ()
  :url "https://jsrjenkins.github.io/gregorio-mode/"
  :commit "2b45f91246286abc449cb71f28583403181051c2"
  :revdesc "2b45f9124628"
  :keywords '("gregorio" "chant")
  :authors '(("Fr. John Jenkins" . "jenkins@sspx.ng"))
  :maintainers '(("Fr. John Jenkins" . "jenkins@sspx.ng")))
