;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "2.5.0.20261025.4"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/osm"
  :commit "9616cbbab33a8fcd52c981e5a6ff567f43520826"
  :revdesc "2.5-4-g9616cbbab33a"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
