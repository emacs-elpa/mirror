;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anaphora" "1.0.4.0.20240120.2"
  "Anaphoric macros providing implicit temp variables."
  ()
  :url "https://github.com/rolandwalker/anaphora"
  :commit "a755afa7db7f3fa515f8dd2c0518113be0b027f6"
  :revdesc "v1.0.4-2-ga755afa7db7f"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
