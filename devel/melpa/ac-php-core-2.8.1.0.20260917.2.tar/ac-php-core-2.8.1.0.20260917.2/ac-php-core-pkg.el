;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "2.8.1.0.20260917.2"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "0959afc45f24eec4ace3600609ce939c3ba77410"
  :revdesc "v2.8.1-2-g0959afc45f24"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
