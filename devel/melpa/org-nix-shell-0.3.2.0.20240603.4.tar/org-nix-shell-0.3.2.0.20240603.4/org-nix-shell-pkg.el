;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-nix-shell" "0.3.2.0.20240603.4"
  "Org local nix-shell."
  '((emacs "27.1")
    (org   "9.4"))
  :url "https://github.com/AntonHakansson/"
  :commit "f359d9e1053fadee86dd668f4789ae2e700d8e8a"
  :revdesc "f359d9e1053f"
  :keywords '("processes" "outlines")
  :maintainers '(("Anton Hakansson" . "anton@hakanssn.com")))
