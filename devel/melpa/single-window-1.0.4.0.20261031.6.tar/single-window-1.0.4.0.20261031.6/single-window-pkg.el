;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "single-window" "1.0.4.0.20261031.6"
  "Always open buffers in the current window."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/single-window.el"
  :commit "5875a42420b4a30fece31163dbc25bfea11b868b"
  :revdesc "1.0.4-6-g5875a42420b4"
  :keywords '("convenience" "windows")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
