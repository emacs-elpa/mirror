;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prodigy" "1.0.0.0.20250401.20"
  "Manage external services."
  '((s     "1.8.0")
    (dash  "2.4.0")
    (f     "0.14.0")
    (emacs "27.1"))
  :url "https://github.com/rejeep/prodigy.el"
  :commit "7bd89fdd544209afb28d6abe828728ad62257617"
  :revdesc "7bd89fdd5442"
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
