;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.4.0.0.20260822.15"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "506718e69235a0cc7ab8ada4423c0b8e499621da"
  :revdesc "v1.4.0-15-g506718e69235"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
