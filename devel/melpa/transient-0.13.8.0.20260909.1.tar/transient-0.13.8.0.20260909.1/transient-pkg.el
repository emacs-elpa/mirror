;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "0.13.8.0.20260909.1"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "03c8ccc6aab24021787aada2be12d64cb1f436e8"
  :revdesc "v0.13.8-1-g03c8ccc6aab2"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
