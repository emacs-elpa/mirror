;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "literate-elisp" "0.8.0.20260729.48"
  "Load Emacs Lisp code blocks from Org files."
  '((emacs "30.1"))
  :url "https://github.com/jingtaozf/literate-elisp"
  :commit "9fcfe78b9bf8a7cfc85ef2074f72a49e8ea6d2b7"
  :revdesc "9fcfe78b9bf8"
  :keywords '("lisp" "docs" "extensions" "tools")
  :authors '(("Jingtao Xu" . "jingtaozf@gmail.com"))
  :maintainers '(("Jingtao Xu" . "jingtaozf@gmail.com")))
