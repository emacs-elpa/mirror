;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "0.4.0.20261118.20"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "f193aa9b8c20049ff932059aa383d51340bd1029"
  :revdesc "f193aa9b8c20"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
