;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "2.32.0.20260825.61"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "37530f48dfa52871c632b1783029ab7c7e84bd39"
  :revdesc "37530f48dfa5"
  :keywords '("languages" "lisp" "slime"))
