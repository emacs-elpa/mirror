;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qtcreator-theme" "0.1.0.0.20201215.15"
  "A color theme that mimics Qt Creator IDE."
  '((emacs "24.3"))
  :url "https://github.com/LesleyLai/emacs-qtcreator-theme"
  :commit "515532b05063898459157d2ba5c10ec0d5a4b1bd"
  :revdesc "515532b05063"
  :keywords '("theme" "light" "faces")
  :authors '(("Lesley Lai" . "lesley@lesleylai.info"))
  :maintainers '(("Lesley Lai" . "lesley@lesleylai.info")))
