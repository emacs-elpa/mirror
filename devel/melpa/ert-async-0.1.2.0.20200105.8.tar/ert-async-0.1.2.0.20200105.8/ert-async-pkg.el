;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-async" "0.1.2.0.20200105.8"
  "Async support for ERT."
  '((emacs "24.1"))
  :url "https://github.com/rejeep/ert-async.el"
  :commit "948cf2faa10e085bda3739034ca5ea1912893433"
  :revdesc "948cf2faa10e"
  :keywords '("lisp" "test")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
