;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-import" "1.0.0.20261025.37"
  "Import Javascript files from your current project or dependencies."
  '((emacs      "24.4")
    (f          "0.19.0")
    (projectile "0.14.0")
    (dash       "2.13.0"))
  :url "https://github.com/jakoblind/js-import"
  :commit "068e95edd47fe5838effba0e14631ad7cddff628"
  :revdesc "068e95edd47f"
  :keywords '("tools"))
