;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ticktick" "1.0.1.0.20261102.23"
  "Sync Org Mode tasks with TickTick."
  '((emacs        "27.1")
    (request      "0.3.0")
    (simple-httpd "1.5.0"))
  :url "https://github.com/polhuang/ticktick.el"
  :commit "48973e636ce0bb7ade8eed92e64eec9b0d20fa43"
  :revdesc "v1.0.1-23-g48973e636ce0"
  :keywords '("tools" "ticktick" "org" "tasks" "todo"))
