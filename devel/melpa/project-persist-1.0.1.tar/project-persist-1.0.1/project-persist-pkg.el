;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-persist" "1.0.1"
  "A minor mode to allow loading and saving of project settings."
  ()
  :url "https://github.com/rdallasgray/project-persist"
  :commit "26d9435bef44da2a1b0892eba822f9f487b98eec"
  :revdesc "1.0.1-0-g26d9435bef44"
  :keywords '("project" "persistence"))
