;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.86.0.20260628.10"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "04d9c34ca19602b6accbca5b8ebd20c6ec258e86"
  :revdesc "04d9c34ca196"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
