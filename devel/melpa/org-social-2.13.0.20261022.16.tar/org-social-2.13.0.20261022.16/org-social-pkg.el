;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "2.13.0.20261022.16"
  "An Org-social client."
  '((emacs            "30.1")
    (org              "9.0")
    (request          "0.3.0")
    (seq              "2.20")
    (emojify          "1.2")
    (async-http-queue "0.1"))
  :url "https://git.andros.dev/org-social/org-social.el"
  :commit "6ed804700ff18a048d0cca57a7770d7b1b57c871"
  :revdesc "6ed804700ff1"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
