;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pumpkin-spice-theme" "0.1.0.0.20231011.1"
  "Spice up your day with a delightful pumpkin colored theme."
  '((emacs      "27.1")
    (autothemer "0.2"))
  :url "https://cicadas.surf/cgit/pumpkin-spice-theme.git"
  :commit "8d38276f6b2d16325ca372dd3630653b21e6e7ed"
  :revdesc "8d38276f6b2d"
  :keywords '("faces" "theme" "halloween" "pumpkin")
  :authors '(("Grant Shangreaux" . "shoshin@cicadas.surf"))
  :maintainers '(("Grant Shangreaux" . "shoshin@cicadas.surf")))
