;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devdocs-browser" "20210525.0.20251129.48"
  "Browse devdocs.io documents using EWW."
  '((emacs "27.1"))
  :url "https://github.com/blahgeek/emacs-devdocs-browser"
  :commit "f6c3b96748cb4e6d3022a2cece15d0d0fc437cd6"
  :revdesc "f6c3b96748cb"
  :keywords '("docs" "help" "tools")
  :authors '(("blahgeek" . "i@blahgeek.com"))
  :maintainers '(("blahgeek" . "i@blahgeek.com")))
