;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cyberpunk-2019-theme" "0.0.1.0.20191008.9"
  "A retina-scorching cyberpunk theme."
  '((emacs "24.1"))
  :url "https://github.com/the-frey/cyberpunk-2019"
  :commit "7e40c37210c363b2819fd9bb98a73101d7a3c206"
  :revdesc "7e40c37210c3"
  :keywords '("cyberpunk" "theme" "themes")
  :authors '(("Alex Lynham" . "alex@lynh.am"))
  :maintainers '(("Alex Lynham" . "alex@lynh.am")))
