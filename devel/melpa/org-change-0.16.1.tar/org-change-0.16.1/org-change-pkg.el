;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "0.16.1"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "0ad1a79934627eb40dbde1ff8c3dad9b8e790f16"
  :revdesc "0ad1a7993462"
  :keywords '("wp" "convenience"))
