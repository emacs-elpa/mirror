;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imake" "1.2.9.0.20261115.1"
  "Simple, opinionated make target runner."
  '((emacs      "29.1")
    (compat     "31.1")
    (marginalia "2.13"))
  :url "https://github.com/tarsius/imake"
  :commit "39a4e89a8f29571e3d39410f3ecb729e6cc48c96"
  :revdesc "v1.2.9-1-g39a4e89a8f29"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev")))
