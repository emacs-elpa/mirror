;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-projectile" "0.3.4.0.20260917.8"
  "Ivy integration for Projectile."
  '((counsel    "0.13.4")
    (projectile "3.3.0"))
  :url "https://github.com/ericdanan/counsel-projectile"
  :commit "037747b8d3cfee791eb6a5aa7822fbf6cf52b6d6"
  :revdesc "0.3.4-8-g037747b8d3cf"
  :keywords '("project" "convenience"))
