;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sema-mode" "0.2.0.0.20261009.6"
  "Major mode for editing Sema files."
  '((emacs "25.1"))
  :url "https://github.com/sema-lisp/emacs-sema"
  :commit "1e53b24de03963ad6ee1b293d418b8dd63c627d5"
  :revdesc "v0.2.0-6-g1e53b24de039"
  :keywords '("languages" "lisp")
  :authors '(("Helge Sverre" . "helge.sverre@gmail.com"))
  :maintainers '(("Helge Sverre" . "helge.sverre@gmail.com")))
