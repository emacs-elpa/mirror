;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-rst" "0.2.2.0.20210418.2"
  "Poly-rst-mode polymode."
  '((emacs    "25")
    (polymode "0.2.2"))
  :url "https://github.com/polymode/poly-rst"
  :commit "e71f2ae6a00683cdb8006f953e5db0673043e144"
  :revdesc "e71f2ae6a006"
  :keywords '("languages" "multi-modes"))
