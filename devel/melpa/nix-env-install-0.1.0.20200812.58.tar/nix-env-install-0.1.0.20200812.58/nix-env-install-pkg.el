;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-env-install" "0.1.0.20200812.58"
  "Install packages using nix-env."
  '((emacs "25.1"))
  :url "https://github.com/akirak/nix-env-install"
  :commit "79c34bc117ba1cebeb67fab32c364951d2ec37a0"
  :revdesc "79c34bc117ba"
  :keywords '("processes" "tools")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
