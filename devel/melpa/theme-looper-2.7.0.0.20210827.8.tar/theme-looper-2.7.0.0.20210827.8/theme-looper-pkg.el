;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "theme-looper" "2.7.0.0.20210827.8"
  "A package for switching themes in Emacs interactively."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "http://ismail.teamfluxion.com"
  :commit "e6e8efd740df0b68db89805ba72492818dba61ab"
  :revdesc "e6e8efd740df"
  :keywords '("convenience" "color-themes")
  :authors '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com"))
  :maintainers '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com")))
