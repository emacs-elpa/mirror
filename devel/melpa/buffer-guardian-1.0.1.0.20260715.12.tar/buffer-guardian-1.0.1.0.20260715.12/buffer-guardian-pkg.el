;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "1.0.1.0.20260715.12"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "e56fe46b8588dd851406e5d5264644898730ea20"
  :revdesc "1.0.1-12-ge56fe46b8588"
  :keywords '("maint")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
