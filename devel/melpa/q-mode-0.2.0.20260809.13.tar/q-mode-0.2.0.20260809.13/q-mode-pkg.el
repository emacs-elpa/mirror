;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2.0.20260809.13"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "e1fdff40c3a75f6d3323a5e9a3d8ff4a7ea07673"
  :revdesc "e1fdff40c3a7"
  :keywords '("faces" "files" "q"))
