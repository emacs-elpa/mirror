;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wisp-mode" "1.0.13.0.20260628.8"
  "Tools for wisp: the Whitespace-to-Lisp preprocessor."
  '((emacs "24.4"))
  :url "http://www.draketo.de/english/wisp"
  :commit "69bb231addaf8b1dcab702ab531b2765fc88b211"
  :revdesc "v1.0.13-7-m69bb231addaf"
  :keywords '("languages" "lisp" "scheme")
  :authors '(("Arne Babenhauserheide" . "arne_bab@web.de"))
  :maintainers '(("Arne Babenhauserheide" . "arne_bab@web.de")))
