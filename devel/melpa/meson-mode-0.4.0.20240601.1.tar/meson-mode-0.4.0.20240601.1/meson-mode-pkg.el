;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meson-mode" "0.4.0.20240601.1"
  "Major mode for the Meson build system files."
  '((emacs "26.1"))
  :url "https://github.com/wentasah/meson-mode"
  :commit "0449c649daaa9322e1c439c1540d8c290501d455"
  :revdesc "v0.4-1-g0449c649daaa"
  :keywords '("languages" "tools")
  :authors '(("Michal Sojka" . "sojkam1@fel.cvut.cz"))
  :maintainers '(("Michal Sojka" . "sojkam1@fel.cvut.cz")))
