;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-test-helpers" "1.14.2.0.20230820.184"
  "Unit test helpers for Evil."
  '((evil "1.15.0"))
  :url "https://github.com/emacs-evil/evil"
  :commit "4beec94d14fc4180c41314edff997dbb9c422a23"
  :revdesc "4beec94d14fc"
  :authors '(("Vegard ye" . "vegard_oyeathotmail.com"))
  :maintainers '(("Vegard ye" . "vegard_oyeathotmail.com")))
