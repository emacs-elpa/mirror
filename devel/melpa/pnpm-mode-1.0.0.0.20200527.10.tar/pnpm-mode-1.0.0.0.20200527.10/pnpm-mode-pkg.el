;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pnpm-mode" "1.0.0.0.20200527.10"
  "Minor mode for working with pnpm projects."
  '((emacs "24.1"))
  :url "https://github.com/rajasegar/pnpm-mode"
  :commit "ec66ba36ba6e07883b029569c33fd461d28eed75"
  :revdesc "ec66ba36ba6e"
  :keywords '("convenience" "project" "javascript" "node" "npm" "pnpm")
  :authors '(("Rajasegar Chandran" . "rajasegar.c@gmail.com"))
  :maintainers '(("Rajasegar Chandran" . "rajasegar.c@gmail.com")))
