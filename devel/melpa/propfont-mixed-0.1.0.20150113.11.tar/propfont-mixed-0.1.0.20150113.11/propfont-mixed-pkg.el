;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "propfont-mixed" "0.1.0.20150113.11"
  "Use proportional fonts with space-based indentation."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/ikirill/propfont-mixed"
  :commit "0b461ef4754a469610dba71874a34b6da42176bf"
  :revdesc "0b461ef4754a"
  :keywords '("faces")
  :authors '(("Kirill Ignatiev" . "github.com/ikirill"))
  :maintainers '(("Kirill Ignatiev" . "github.com/ikirill")))
