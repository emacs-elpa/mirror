;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-errcheck" "1.1.2.0.20160723.1"
  "Errcheck integration for go-mode."
  ()
  :url "https://github.com/dominikh/go-errcheck.el"
  :commit "9db21eccecedc2490793f176246094167164af31"
  :revdesc "v1.1.2-1-g9db21ecceced"
  :authors '(("Dominik Honnef" . "dominikh@fork-bomb.org"))
  :maintainers '(("Dominik Honnef" . "dominikh@fork-bomb.org")))
