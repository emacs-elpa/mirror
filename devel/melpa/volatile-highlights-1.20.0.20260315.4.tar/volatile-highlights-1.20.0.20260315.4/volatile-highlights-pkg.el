;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "volatile-highlights" "1.20.0.20260315.4"
  "Transient visual feedback for edits."
  '((emacs "24.4"))
  :url "https://github.com/k-talo/volatile-highlights.el"
  :commit "f68ac37451c1226d6f13c1b299ec7516f74888a1"
  :revdesc "v1.20-4-gf68ac37451c1"
  :keywords '("editing" "emulations" "convenience" "wp")
  :authors '(("K-talo Miyazaki" . "Keitaro.Miyazaki@gmail.com"))
  :maintainers '(("K-talo Miyazaki" . "Keitaro.Miyazaki@gmail.com")))
