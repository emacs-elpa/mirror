;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-leanpub" "0.4.0.20260903.1"
  "Export Org documents to Leanpub book format."
  '((org    "9.1")
    (ox-gfm "1.0")
    (emacs  "26.1")
    (s      "1.12.0"))
  :url "https://gitlab.com/zzamboni/ox-leanpub"
  :commit "3035ac27ed1dfcb8529d4969fa0b4da18a168f9c"
  :revdesc "3035ac27ed1d"
  :keywords '("files" "org" "leanpub")
  :authors '(("Diego Zamboni" . "diego@zzamboni.org"))
  :maintainers '(("Diego Zamboni" . "diego@zzamboni.org")))
