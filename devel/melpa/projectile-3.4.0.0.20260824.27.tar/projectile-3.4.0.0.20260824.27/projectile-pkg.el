;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.4.0.0.20260824.27"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "f60f47f2f72d60201679e8c3b50ad00bae3889dd"
  :revdesc "f60f47f2f72d"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
