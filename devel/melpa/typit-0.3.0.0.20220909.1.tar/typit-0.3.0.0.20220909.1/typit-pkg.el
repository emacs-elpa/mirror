;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typit" "0.3.0.0.20220909.1"
  "Typing game similar to tests on 10 fast fingers."
  '((emacs "24.4")
    (f     "0.18")
    (mmt   "0.1.1"))
  :url "https://github.com/mrkkrp/typit"
  :commit "6ad0d5a106c4a4428fd131653bbe7c0aab4b5f60"
  :revdesc "6ad0d5a106c4"
  :keywords '("games")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
