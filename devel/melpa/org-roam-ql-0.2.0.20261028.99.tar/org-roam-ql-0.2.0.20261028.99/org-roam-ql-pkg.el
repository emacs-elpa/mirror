;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "0.2.0.20261028.99"
  "Interface to query and view results from org-roam."
  '((emacs         "28")
    (org-roam      "2.2.0")
    (s             "1.12.0")
    (magit-section "3.3.0")
    (transient     "0.4")
    (dash          "2.0"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "070816db13e8e532e68833a898633c2b36b471f4"
  :revdesc "070816db13e8")
