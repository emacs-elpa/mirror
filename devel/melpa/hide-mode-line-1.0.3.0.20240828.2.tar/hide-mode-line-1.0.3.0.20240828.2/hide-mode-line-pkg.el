;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hide-mode-line" "1.0.3.0.20240828.2"
  "Minor mode that hides/masks your modeline."
  '((emacs "24.4"))
  :url "https://github.com/hlissner/emacs-hide-mode-line"
  :commit "ddd154f1e04d666cd004bf8212ead8684429350d"
  :revdesc "v1.0.3-2-gddd154f1e04d"
  :keywords '("frames" "mode-line")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
