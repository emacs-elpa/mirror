;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nushell-mode" "0.1.0.0.20260802.39"
  "Major mode for Nushell scripts."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/nushell-mode"
  :commit "79f7fd4b2920e3947e85ba34f4b6538c85388187"
  :revdesc "79f7fd4b2920"
  :keywords '("languages" "unix")
  :authors '(("Azzam S.A" . "vcs@azzamsa.com"))
  :maintainers '(("Azzam S.A" . "vcs@azzamsa.com")))
