;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-cfn" "0.1.0.20240112.15"
  "LSP integration for cfn-lsp-extra."
  '((emacs     "27.0")
    (lsp-mode  "8.0.0")
    (yaml-mode "0.0.15"))
  :url "https://github.com/LaurenceWarne/lsp-cfn.el"
  :commit "2297533003118ebd9db0116b4d3486a987e98ca9"
  :revdesc "229753300311")
