;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "1.0.9.0.20261031.7"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "b9254f46ceb4cb18f65b6f35bf40a4f9deac66fe"
  :revdesc "1.0.9-7-gb9254f46ceb4"
  :keywords '("convenience" "files" "tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
