;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ivy-search" "0.1.6.0.20250305.13"
  "Full text search for org files powered by ivy."
  '((emacs  "25.1")
    (ivy    "0.10.0")
    (org    "0.10.0")
    (beacon "1.3.4"))
  :url "https://github.com/beacoder/org-ivy-search"
  :commit "d09472c5ae5c099bee17fb0e4f3f017ce7ebd031"
  :revdesc "d09472c5ae5c"
  :keywords '("convenience" "tool" "org")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
