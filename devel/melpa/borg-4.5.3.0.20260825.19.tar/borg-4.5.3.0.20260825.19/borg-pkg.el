;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.5.3.0.20260825.19"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "92501666a293f611c56fa3a0dda4f4159295ccb5"
  :revdesc "v4.5.3-19-g92501666a293"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
