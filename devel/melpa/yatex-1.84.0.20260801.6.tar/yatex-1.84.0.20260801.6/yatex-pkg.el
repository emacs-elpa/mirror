;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yatex" "1.84.0.20260801.6"
  "Yet Another tex-mode for emacs //野鳥//."
  ()
  :commit "6a0fea36298fdfdd32e8346eaa252cc358ec807a"
  :revdesc "yatex-1.84-6-m6a0fea36298f")
