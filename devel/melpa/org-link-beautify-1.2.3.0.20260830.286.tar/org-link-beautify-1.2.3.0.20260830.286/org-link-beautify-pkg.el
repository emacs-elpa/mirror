;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "1.2.3.0.20260830.286"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "7c0fb6c9add55270f75c80cd36b79d5ac6f6c6ce"
  :revdesc "7c0fb6c9add5"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
