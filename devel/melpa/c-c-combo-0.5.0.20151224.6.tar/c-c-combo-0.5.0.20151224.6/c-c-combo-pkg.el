;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "c-c-combo" "0.5.0.20151224.6"
  "Make stuff happen when you reach a target wpm."
  ()
  :url "https://www.github.com/CestDiego/c-c-combo.el"
  :commit "a261a833499a7fdc29610863b3aafc74818770ba"
  :revdesc "a261a833499a"
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")))
