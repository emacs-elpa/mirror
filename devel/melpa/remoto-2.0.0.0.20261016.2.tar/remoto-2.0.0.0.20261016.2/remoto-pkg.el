;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "2.0.0.0.20261016.2"
  "Browse GitHub repos without cloning."
  '((emacs "29.1")
    (ghub  "4.0.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "914046738749c0ffd5a2ca18986809b616cac45b"
  :revdesc "2.0.0-2-g914046738749"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
