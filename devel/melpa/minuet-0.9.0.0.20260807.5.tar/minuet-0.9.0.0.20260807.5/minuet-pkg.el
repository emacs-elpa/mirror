;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "0.9.0.0.20260807.5"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "dd3f6191fca5d011f1d1b119058f05ed3086a220"
  :revdesc "v0.9.0-5-gdd3f6191fca5"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
