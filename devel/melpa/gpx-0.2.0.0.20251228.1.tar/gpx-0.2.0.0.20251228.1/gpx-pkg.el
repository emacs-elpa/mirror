;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpx" "0.2.0.0.20251228.1"
  "Major mode for GPX files."
  '((emacs "27.1"))
  :url "https://github.com/mkcms/gpx-mode"
  :commit "d97efb2c2701118f418c22ab1b6518bef0d79517"
  :revdesc "v0.2.0-1-gd97efb2c2701"
  :keywords '("data" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
