;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bookmark-in-project" "0.2.0.20260108.22"
  "Bookmark access within a project."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-bookmark-in-project"
  :commit "bf923ddd3e74fe99e086221e461a5fa7599d0644"
  :revdesc "bf923ddd3e74"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
