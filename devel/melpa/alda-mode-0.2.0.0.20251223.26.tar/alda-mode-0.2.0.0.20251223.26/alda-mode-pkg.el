;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alda-mode" "0.2.0.0.20251223.26"
  "An Alda major mode."
  '((emacs "24.0"))
  :url "https://gitlab.com/jgkamat/alda-mode"
  :commit "bde0e9c5df2810deb48df57f46bb3a1a51d7a8f6"
  :revdesc "0.2.0-26-gbde0e9c5df28"
  :keywords '("alda" "highlight")
  :authors '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainers '(("Jay Kamat" . "jaygkamat@gmail.com")))
