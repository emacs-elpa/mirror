;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kerl" "0.1.0.20150424.3"
  "Emacs integration for kerl."
  ()
  :url "https://github.com/correl/kerl.el/"
  :commit "1732ee26213f021bf040919c45ad276aafcaae14"
  :revdesc "1732ee26213f"
  :keywords '("tools")
  :authors '(("Correl Roush" . "correl@gmail.com"))
  :maintainers '(("Correl Roush" . "correl@gmail.com")))
