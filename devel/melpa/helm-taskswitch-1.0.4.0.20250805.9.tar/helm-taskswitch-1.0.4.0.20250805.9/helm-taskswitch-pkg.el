;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-taskswitch" "1.0.4.0.20250805.9"
  "Use helm to switch windows and buffers."
  '((emacs "24")
    (helm  "3.0"))
  :url "https://github.com/bdc34/helm-taskswitch"
  :commit "11e84316b9db96b19bf1d4038e85bbc26017f302"
  :revdesc "11e84316b9db"
  :keywords '("frames")
  :authors '(("Brian Caruso" . "briancaruso@gmail.com"))
  :maintainers '(("Brian Caruso" . "briancaruso@gmail.com")))
