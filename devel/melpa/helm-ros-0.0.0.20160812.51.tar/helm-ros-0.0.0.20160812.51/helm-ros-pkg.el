;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ros" "0.0.0.20160812.51"
  "Interfaces ROS with helm."
  '((helm        "1.9.9")
    (xterm-color "1.0")
    (cl-lib      "0.5"))
  :url "https://www.github.com/davidlandry93/helm-ros"
  :commit "92b0b215f6a017f0f57f1af15466cc0b2a5a0135"
  :revdesc "92b0b215f6a0"
  :keywords '("helm" "ros")
  :authors '(("David Landry" . "davidlandry93@gmail.com"))
  :maintainers '(("David Landry" . "davidlandry93@gmail.com")))
