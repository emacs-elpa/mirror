;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "2.7.4.0.20260306.1"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "8b21c8f9a47a71102bf4ec08504b044aeab880fe"
  :revdesc "2.7.4-1-g8b21c8f9a47a"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
