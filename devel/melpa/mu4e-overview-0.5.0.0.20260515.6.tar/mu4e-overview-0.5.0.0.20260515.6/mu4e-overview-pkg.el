;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-overview" "0.5.0.0.20260515.6"
  "Show overview of maildir."
  '((emacs "28"))
  :url "https://github.com/mkcms/mu4e-overview"
  :commit "b6dfe3ecc569aa6313ef093c0c49df8a507f19c4"
  :revdesc "0.5.0-6-gb6dfe3ecc569"
  :keywords '("mail" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
