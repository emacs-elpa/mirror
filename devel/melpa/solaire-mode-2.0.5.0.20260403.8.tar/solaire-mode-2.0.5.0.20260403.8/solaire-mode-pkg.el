;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solaire-mode" "2.0.5.0.20260403.8"
  "Make certain buffers grossly incandescent."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/hlissner/emacs-solaire-mode"
  :commit "1bd0134194e48c8fe4089e9d505517935b2b15e3"
  :revdesc "v2.0.5-8-g1bd0134194e4"
  :keywords '("dim" "bright" "window" "buffer" "faces")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
