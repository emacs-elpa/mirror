;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "batppuccin" "1.1.0.0.20260901.5"
  "Batppuccin (Catppuccin) color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/batppuccin-emacs"
  :commit "7c4c3f5e01ba76485d3db7b9e16701efc42c4231"
  :revdesc "7c4c3f5e01ba"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
