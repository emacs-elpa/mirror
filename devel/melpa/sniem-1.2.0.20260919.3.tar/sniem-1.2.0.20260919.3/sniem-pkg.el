;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sniem" "1.2.0.20260919.3"
  "Hands-eased united editing method."
  '((emacs "27.1")
    (s     "2.12.0")
    (dash  "1.12.0"))
  :url "https://github.com/SpringHan/sniem.git"
  :commit "b6def98bdf6af44193f11ffec45c66bbbc6b1a83"
  :revdesc "b6def98bdf6a"
  :keywords '("convenience" "united-editing-method"))
