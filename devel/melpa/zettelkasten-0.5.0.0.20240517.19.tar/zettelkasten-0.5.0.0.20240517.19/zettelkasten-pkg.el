;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zettelkasten" "0.5.0.0.20240517.19"
  "Helper functions to organise notes in a Zettelkasten style."
  '((emacs "25.1")
    (s     "1.10.0"))
  :url "https://github.com/ymherklotz/emacs-zettelkasten"
  :commit "6a33faf7b4231b03d056099a1aff40bbeee6e720"
  :revdesc "6a33faf7b423"
  :keywords '("files" "hypermedia" "notes")
  :authors '(("Yann Herklotz" . "yann@ymhg.org"))
  :maintainers '(("Yann Herklotz" . "yann@ymhg.org")))
