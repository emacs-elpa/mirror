;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.6.1"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "04ca0586896d2ccc2feae28c95b59dba8af31c00"
  :revdesc "v4.6.1-0-g04ca0586896d"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
