;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "3.2.0.20260802.49"
  "A set of base16 themes for your favorite editor."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "53a8b553b364964ffb97c5f84de34f01e4d5b2eb"
  :revdesc "53a8b553b364"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
