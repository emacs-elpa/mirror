;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-transclusion-http" "0.4.0.20240619.1"
  "Transclude over HTTP."
  '((emacs            "28.1")
    (org-transclusion "1.4.0")
    (plz              "0.7.2"))
  :url "https://git.sr.ht/~ushin/org-transclusion-http"
  :commit "65caad0d9b19bf19c815bd7c033ffb907c3ebb12"
  :revdesc "v0.4-1-g65caad0d9b19"
  :authors '(("Joseph Turner" . "firstnameatushin.org"))
  :maintainers '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht")))
