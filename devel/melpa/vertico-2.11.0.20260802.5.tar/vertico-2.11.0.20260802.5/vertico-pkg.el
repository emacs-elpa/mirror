;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "2.11.0.20260802.5"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "5a764752fc70950e562c59a1ed2298d7296db4e8"
  :revdesc "2.11-5-g5a764752fc70"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
