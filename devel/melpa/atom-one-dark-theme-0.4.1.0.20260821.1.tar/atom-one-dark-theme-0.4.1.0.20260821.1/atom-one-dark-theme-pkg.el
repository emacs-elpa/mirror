;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atom-one-dark-theme" "0.4.1.0.20260821.1"
  "Atom One Dark color theme."
  ()
  :url "https://github.com/jonathanchu/atom-one-dark-theme"
  :commit "4317f01ed554cbd60397243fda949800d1fa5ce1"
  :revdesc "0.4.1-1-g4317f01ed554"
  :keywords '("faces")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
