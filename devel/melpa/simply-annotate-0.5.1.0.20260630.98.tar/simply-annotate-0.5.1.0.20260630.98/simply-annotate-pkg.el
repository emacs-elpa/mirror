;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "0.5.1.0.20260630.98"
  "Enhanced annotation system with threading."
  '((emacs     "28.1")
    (transient "0.4"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "330c6b4014dcb42526b7a76affed345b1aba8b89"
  :revdesc "330c6b4014dc"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
