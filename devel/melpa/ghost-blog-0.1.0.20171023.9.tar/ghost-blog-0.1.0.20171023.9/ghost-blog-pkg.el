;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghost-blog" "0.1.0.20171023.9"
  "A package to manage Ghost blog."
  '((markdown-mode "1.0"))
  :url "https://github.com/javaguirre/ghost-blog"
  :commit "71b358643cc9a2db1bf752281ff94aba9b59e4cc"
  :revdesc "71b358643cc9"
  :keywords '("ghost" "blog")
  :authors '(("Javier Aguirre" . "hello@javaguirre.net"))
  :maintainers '(("Javier Aguirre" . "hello@javaguirre.net")))
