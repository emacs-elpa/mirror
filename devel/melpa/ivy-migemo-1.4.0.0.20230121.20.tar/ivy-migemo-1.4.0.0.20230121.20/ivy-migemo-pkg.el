;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-migemo" "1.4.0.0.20230121.20"
  "Use migemo on ivy."
  '((emacs   "24.3")
    (ivy     "0.13.0")
    (migemo  "1.9.2")
    (nadvice "0.3"))
  :url "https://github.com/ROCKTAKEY/ivy-migemo"
  :commit "6022b24e72f073a7b5599f2dea611da3a1282378"
  :revdesc "6022b24e72f0"
  :keywords '("matching")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
