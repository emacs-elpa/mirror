;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-django" "0.1.0.20150822.66"
  "A Jazzy package for managing Django projects."
  ()
  :url "https://github.com/fgallina/python-django.el"
  :commit "fc54ad74f0309670359b939f64d0f1fff68aeac4"
  :revdesc "fc54ad74f030"
  :keywords '("languages")
  :authors '(("Fabián E. Gallina" . "fabian@anue.biz")))
