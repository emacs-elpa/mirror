;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-track-score" "0.0.0.20130328.3"
  "Add score support to tracked channel buffers."
  ()
  :url "http://julien.danjou.info/erc-track-score.html"
  :commit "5b27531ea6b1a4c4b703b270dfa9128cb5bfdaa3"
  :revdesc "5b27531ea6b1"
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")))
