;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prompts" "0.1.0.0.20160916.1"
  "Utilities for working with text prompts."
  '((dash "2.13.0"))
  :url "https://github.com/guiltydolphin/prompts.el"
  :commit "1cd5e732ff2a86b47836eb7252e5b59cd4b6ab26"
  :revdesc "1cd5e732ff2a"
  :keywords '("input" "minibuffer")
  :authors '(("Ben Moon" . "guiltydolphin@gmail.com"))
  :maintainers '(("Ben Moon" . "guiltydolphin@gmail.com")))
