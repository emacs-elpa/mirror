;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ewal-evil-cursors" "0.2.1"
  "`ewal'-colored evil cursor for Emacs and Spacemacs."
  '((emacs "25")
    (ewal  "0.1"))
  :url "https://gitlab.com/jjzmajic/ewal"
  :commit "732a2f4abb480f9f5a3249af822d8eb1e90324e3"
  :revdesc "732a2f4abb48"
  :keywords '("faces"))
