;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "4.5.0.20261109.410"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "e09cd62ada58d5e38986a81101cffe1be28e527d"
  :revdesc "v4.5-410-ge09cd62ada58"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
