;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "silkworm-theme" "0.1.0.20210215.6"
  "Light theme with pleasant, low contrast colors."
  '((emacs "24"))
  :url "https://github.com/mswift42/silkworm-theme"
  :commit "ff80e9294da0fb093e15097ac62153ef4a64a889"
  :revdesc "ff80e9294da0")
