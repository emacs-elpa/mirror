;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dag-draw" "1.1.0"
  "Draw directed graphs using the GKNV algorithm."
  '((emacs "26.1")
    (dash  "2.19.1")
    (ht    "2.3"))
  :url "https://codeberg.org/trevoke/dag-draw.el"
  :commit "c20b3c28781f1d768116a2cc601a4e8d0058e2ba"
  :revdesc "1.1.0-0-gc20b3c28781f"
  :keywords '("tools" "extensions"))
