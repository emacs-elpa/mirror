;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spray" "0.0.2.0.20160304.39"
  "A speed reading mode."
  ()
  :url "https://github.com/ian-kelling/spray"
  :commit "69fe48e7bb079e3011476b9f4eb6ac9ae94d6d9b"
  :revdesc "69fe48e7bb07"
  :keywords '("convenience")
  :authors '(("Ian Kelling" . "ian@iankelling.org"))
  :maintainers '(("Ian Kelling" . "ian@iankelling.org")))
