;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260524.1146"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "628a4e3ef40b1a6e6f39a58a709cfdea3fbbc5e1"
  :revdesc "628a4e3ef40b"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
