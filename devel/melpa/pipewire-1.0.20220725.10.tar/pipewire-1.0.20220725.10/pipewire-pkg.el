;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pipewire" "1.0.20220725.10"
  "PipeWire user interface."
  '((emacs "28.1"))
  :url "https://git.zamazal.org/pdm/pipewire-0"
  :commit "115a8a89a3a0c6a89ebe22df0ef0928a701cb1f0"
  :revdesc "115a8a89a3a0"
  :keywords '("multimedia")
  :authors '(("Milan Zamazal" . "pdm@zamazal.org"))
  :maintainers '(("Milan Zamazal" . "pdm@zamazal.org")))
