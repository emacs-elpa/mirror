;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-indent-plus" "1.0.0.0.20230927.13"
  "Evil textobjects based on indentation."
  '((evil   "0")
    (cl-lib "0.5"))
  :url "https://github.com/TheBB/evil-indent-plus"
  :commit "f392696e4813f1d3a92c7eeed333248914ba6dae"
  :revdesc "f392696e4813"
  :keywords '("convenience" "evil")
  :authors '(("Eivind Fonn" . "evfonn@gmail.com"))
  :maintainers '(("Eivind Fonn" . "evfonn@gmail.com")))
