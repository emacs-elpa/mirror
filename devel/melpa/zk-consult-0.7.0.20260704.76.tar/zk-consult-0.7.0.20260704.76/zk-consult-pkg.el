;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-consult" "0.7.0.20260704.76"
  "Consult integration for zk."
  '((emacs   "27.1")
    (zk      "0.4")
    (consult "0.14"))
  :url "https://github.com/localauthor/zk"
  :commit "dfb3a82c9a84b0282fa79cf4d2bcaeba6ee4ec81"
  :revdesc "dfb3a82c9a84"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
