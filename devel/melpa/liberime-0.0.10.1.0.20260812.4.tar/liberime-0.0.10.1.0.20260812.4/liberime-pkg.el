;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "0.0.10.1.0.20260812.4"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "f805e3bf7ba1e809939a3fe059dd112f8167e849"
  :revdesc "f805e3bf7ba1"
  :keywords '("convenience" "chinese" "input-method" "rime"))
