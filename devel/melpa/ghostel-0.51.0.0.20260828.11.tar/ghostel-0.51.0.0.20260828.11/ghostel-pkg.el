;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.51.0.0.20260828.11"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "7c4cbd9f487b545c3d0452ab749f65eaa3c18b7e"
  :revdesc "7c4cbd9f487b"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
