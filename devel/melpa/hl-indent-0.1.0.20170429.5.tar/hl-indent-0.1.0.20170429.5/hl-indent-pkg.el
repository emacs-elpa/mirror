;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-indent" "0.1.0.20170429.5"
  "Highlight irregular indentation."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/ikirill/hl-indent"
  :commit "bdb2e0177a7c8b29af26998e688b856adc6ded93"
  :revdesc "bdb2e0177a7c"
  :keywords '("convenience" "faces")
  :authors '(("Kirill Ignatiev" . "github.com/ikirill"))
  :maintainers '(("Kirill Ignatiev" . "github.com/ikirill")))
