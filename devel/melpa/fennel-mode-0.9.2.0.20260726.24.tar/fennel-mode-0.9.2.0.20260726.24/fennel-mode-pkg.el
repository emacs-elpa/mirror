;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fennel-mode" "0.9.2.0.20260726.24"
  "A major-mode for editing Fennel code."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~technomancy/fennel-mode"
  :commit "2cf12616455d5b042cca8394f3ceb70b138e3043"
  :revdesc "0.9.2-24-g2cf12616455d"
  :keywords '("languages" "tools"))
