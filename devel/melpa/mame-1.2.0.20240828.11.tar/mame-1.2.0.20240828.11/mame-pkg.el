;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mame" "1.2.0.20240828.11"
  "A MAME front-end."
  '((emacs "27.1"))
  :url "https://github.com/Iacob/elmame"
  :commit "7c727999e03932fc65cabdbe2161efbe06ff1274"
  :revdesc "7c727999e039"
  :authors '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers '(("Yong" . "luo.yong.name@gmail.com")))
