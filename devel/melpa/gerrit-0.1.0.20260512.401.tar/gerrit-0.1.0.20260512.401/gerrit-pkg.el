;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gerrit" "0.1.0.20260512.401"
  "Gerrit client."
  '((emacs "29.1")
    (magit "2.13.1")
    (s     "1.12.0")
    (dash  "0.2.15"))
  :url "https://github.com/twmr/gerrit.el"
  :commit "ccbc70a482305c8f0c88da3a9daead6a16c63ae5"
  :revdesc "ccbc70a48230"
  :keywords '("extensions")
  :authors '(("Thomas Wimmer" . "thomaswimmer@posteo.com"))
  :maintainers '(("Thomas Wimmer" . "thomaswimmer@posteo.com")))
