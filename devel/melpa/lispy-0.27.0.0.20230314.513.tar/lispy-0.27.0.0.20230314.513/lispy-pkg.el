;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lispy" "0.27.0.0.20230314.513"
  "Vi-like Paredit."
  ()
  :url "https://github.com/abo-abo/lispy"
  :commit "fe44efd21573868638ca86fc8313241148fabbe3"
  :revdesc "fe44efd21573"
  :keywords '("lisp")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
