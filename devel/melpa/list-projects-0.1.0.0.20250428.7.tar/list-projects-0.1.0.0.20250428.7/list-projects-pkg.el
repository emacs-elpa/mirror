;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "list-projects" "0.1.0.0.20250428.7"
  "List of known projects."
  '((emacs "28.1"))
  :url "https://github.com/MatthewTromp/list-projects"
  :commit "8f07faf991f201593388fb85fc7c70320755b71a"
  :revdesc "8f07faf991f2"
  :authors '(("Matthew Tromp" . "matthewktromp@gmail.com"))
  :maintainers '(("Matthew Tromp" . "matthewktromp@gmail.com")))
