;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "downplay-mode" "0.1.0.20151125.7"
  "Focus attention on a region of the buffer."
  ()
  :url "https://github.com/tobias/downplay-mode/"
  :commit "4a2c3addc73c8ca3816345c3c11c08af265baedb"
  :revdesc "4a2c3addc73c"
  :authors '(("Toby Crawley" . "toby@tcrawley.org"))
  :maintainers '(("Toby Crawley" . "toby@tcrawley.org")))
