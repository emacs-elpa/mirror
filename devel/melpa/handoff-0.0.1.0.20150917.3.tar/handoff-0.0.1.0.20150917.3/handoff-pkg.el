;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "handoff" "0.0.1.0.20150917.3"
  "Get your hand off that mouse, damn it!."
  ()
  :url "https://github.com/rejeep/handoff.el"
  :commit "75dc7a7e352f38679f65d0ca80ad158798e168bd"
  :revdesc "75dc7a7e352f"
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
