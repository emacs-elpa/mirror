;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lpy" "0.1.0.0.20231026.188"
  "A lispy interface to Python."
  '((emacs "25.1")
    (lispy "0.27.0"))
  :url "https://github.com/abo-abo/lpy"
  :commit "2c086ec162d4456b99a6095c3c335382a8304734"
  :revdesc "2c086ec162d4"
  :keywords '("python" "lisp")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
