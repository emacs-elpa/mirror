;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-caribbean-theme" "1.5.0.20250411.16"
  "Color theme with cyan/coral as a dominant color."
  '((emacs "27.1"))
  :url "https://gitlab.com/aimebertrand/timu-caribbean-theme"
  :commit "ae8fbab1c3fbb14ca797b0207c45d723d7d25b22"
  :revdesc "ae8fbab1c3fb"
  :keywords '("faces" "themes")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
