;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-commentary" "2.2.0.0.20230610.4"
  "Comment stuff out. A port of vim-commentary."
  '((evil "1.0.0"))
  :url "https://github.com/linktohack/evil-commentary"
  :commit "c5945f28ce47644c828aac1f5f6ec335478d17fb"
  :revdesc "c5945f28ce47"
  :keywords '("evil" "comment" "commentary" "evil-commentary")
  :authors '(("Quang Linh LE" . "linktohack@gmail.com"))
  :maintainers '(("Quang Linh LE" . "linktohack@gmail.com")))
