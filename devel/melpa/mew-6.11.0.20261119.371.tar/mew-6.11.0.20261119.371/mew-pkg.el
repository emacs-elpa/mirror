;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20261119.371"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "fe3b15790cb4b018a676462b91a0a0048cc2a480"
  :revdesc "fe3b15790cb4")
