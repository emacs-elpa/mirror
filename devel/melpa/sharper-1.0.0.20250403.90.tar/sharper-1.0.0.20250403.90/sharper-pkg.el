;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sharper" "1.0.0.20250403.90"
  "A dotnet CLI wrapper, using Transient."
  '((emacs     "27.1")
    (transient "0.2.0"))
  :url "https://github.com/sebasmonia/sharper"
  :commit "5049795848609e6508e4c9718a9f97ee481bf36c"
  :revdesc "504979584860"
  :keywords '("maint" "tool")
  :authors '(("Sebastian Monia" . "smonia@outlook.com"))
  :maintainers '(("Sebastian Monia" . "smonia@outlook.com")))
