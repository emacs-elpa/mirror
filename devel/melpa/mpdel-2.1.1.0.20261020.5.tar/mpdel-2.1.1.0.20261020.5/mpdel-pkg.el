;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpdel" "2.1.1.0.20261020.5"
  "Play and control your MPD music."
  '((emacs    "28.0")
    (libmpdel "1.2.0")
    (navigel  "0.7.0"))
  :url "https://github.com/mpdel/mpdel"
  :commit "1c497d3433aa104a69d234aec1317ee988915ef0"
  :revdesc "v2.1.1-5-g1c497d3433aa"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
