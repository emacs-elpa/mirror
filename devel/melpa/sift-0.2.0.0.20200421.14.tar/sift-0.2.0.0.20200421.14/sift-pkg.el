;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sift" "0.2.0.0.20200421.14"
  "Front-end for sift, a fast and powerful grep alternative."
  ()
  :url "https://github.com/nlamirault/sift.el"
  :commit "cdddba2d183146c340915003f1b5d09d13712c22"
  :revdesc "cdddba2d1831"
  :keywords '("sift" "ack" "pt" "ag" "grep" "search")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
