;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-test-mode" "1.0.0.20210205.114"
  "Minor mode for Behaviour and Test Driven."
  '((ruby-mode "1.0")
    (pcre2el   "1.8"))
  :url "https://github.com/ruby-test-mode/ruby-test-mode"
  :commit "d66db4aca6e6a246f65f7195ecfbc7581d35fb7a"
  :revdesc "d66db4aca6e6"
  :keywords '("ruby" "unit" "test" "rspec" "tools")
  :authors '(("Roman Scherer" . "roman.scherer@gmx.de")
             ("Caspar Florian Ebeling" . "florian.ebeling@gmail.com"))
  :maintainers '(("Roman Scherer" . "roman.scherer@burningswell.com")))
