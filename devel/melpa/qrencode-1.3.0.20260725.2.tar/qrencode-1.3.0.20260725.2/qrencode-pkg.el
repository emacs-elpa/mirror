;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "1.3.0.20260725.2"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "d96e458305c07ce845f3ebff573416972d1f8834"
  :revdesc "v1.3-2-gd96e458305c0"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
