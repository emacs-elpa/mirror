;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-latex" "0.21.0.0.20261013.6"
  "Preview LaTeX math as SVG in LaTeX buffers."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.21.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "8b025ab330d16ff5bfee7caa82b18303a09b3cb1"
  :revdesc "v0.21.0-6-g8b025ab330d1"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
