;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-agent-shell" "0.2.0.0.20260727.1"
  "Org-babel backend for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.50.1")
    (org         "9.6"))
  :url "https://github.com/eddof13/ob-agent-shell"
  :commit "012e2d8acf152ee096d95e4b52ef3e82507e93a2"
  :revdesc "v0.2.0-1-g012e2d8acf15"
  :keywords '("tools" "convenience" "outlines")
  :authors '(("Eddie Jesinsky" . "eddie@jesinsky.com"))
  :maintainers '(("Eddie Jesinsky" . "eddie@jesinsky.com")))
