;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-imenu" "0.1.0.0.20181029.5"
  "Enhance imenu for go language."
  '((emacs "24.3"))
  :url "https://github.com/brantou/go-imenu.el"
  :commit "00bb69c1c71453f43ab2d6622a74e3c8e6b454b9"
  :revdesc "00bb69c1c714"
  :keywords '("tools")
  :authors '(("Brantou" . "brantou89@gmail.com"))
  :maintainers '(("Brantou" . "brantou89@gmail.com")))
