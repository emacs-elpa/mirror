;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "editorconfig-domain-specific" "0.1.0.0.20180505.2"
  "Apply brace style and other \"domain-specific\" EditorConfig properties."
  '((cl-lib       "0.5")
    (editorconfig "0.6.0"))
  :url "https://github.com/lassik/editorconfig-emacs-domain-specific"
  :commit "e9824160fb2e466afa755240ee3ab7cc5657fb04"
  :revdesc "e9824160fb2e"
  :keywords '("editorconfig" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
