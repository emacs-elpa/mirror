;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alsamixer" "0.2.1.0.20250106.1"
  "Functions to call out to amixer."
  ()
  :url "https://codeberg.org/rwv/alsamixer-el"
  :commit "5f5a1f26637ca1b2a8ac964fc86a59522e3f778e"
  :revdesc "0.2.1-1-g5f5a1f26637c"
  :keywords '("convenience"))
