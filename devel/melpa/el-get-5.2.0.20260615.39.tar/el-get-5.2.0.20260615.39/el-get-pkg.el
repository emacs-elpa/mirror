;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-get" "5.2.0.20260615.39"
  "Manage the external elisp bits and pieces you depend upon."
  ()
  :url "http://www.emacswiki.org/emacs/el-get"
  :commit "447b7efc9fca29a087f4ec29c5d8ccb580cd1c78"
  :revdesc "5.2-39-g447b7efc9fca"
  :keywords '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
