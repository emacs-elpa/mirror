;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel-evil" "3.0.0.20231224.14"
  "Extension for kubel to provide evil keybindings."
  '((kubel "1.0")
    (evil  "1.0")
    (emacs "25.3"))
  :url "https://github.com/abrochard/kubel"
  :commit "3d2f86fccdf81ab890f5d46dde93f241b718a436"
  :revdesc "3d2f86fccdf8"
  :keywords '("kubernetes" "k8s" "tools" "processes" "evil" "keybindings"))
