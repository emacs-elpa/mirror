;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fedi" "0.4"
  "Helper functions for fediverse clients."
  '((emacs         "28.1")
    (markdown-mode "2.5"))
  :url "https://codeberg.org/martianh/fedi.el"
  :commit "91f28ee199a499b8d6e1b9c7a0f1c15f8a382198"
  :revdesc "91f28ee199a4"
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
