;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "1.0.0.20260818.239"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "a3912b532d4ce6700eac8789216ef6beac218b4d"
  :revdesc "a3912b532d4c"
  :keywords '("convenience" "text"))
