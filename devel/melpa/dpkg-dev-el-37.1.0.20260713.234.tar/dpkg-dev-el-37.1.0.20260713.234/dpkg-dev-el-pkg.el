;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dpkg-dev-el" "37.1.0.20260713.234"
  "Startup file for the elpa-dpkg-dev-el package."
  '((emacs     "27.1")
    (debian-el "37.0"))
  :commit "74ccc3b0a227a2e71b2c69af4da09e28ae944972"
  :revdesc "37.1-234-g74ccc3b0a227"
  :authors '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainers '(("Peter S Galbraith" . "psg@debian.org")))
