;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sbt-mode" "2.0.0.0.20260301.35"
  "Interactive support for sbt projects."
  '((emacs "24.4"))
  :url "https://github.com/hvesalai/emacs-sbt-mode"
  :commit "c353df6aa112c05dde6dc63ccf813c2203cb472b"
  :revdesc "v2.0.0-35-gc353df6aa112"
  :keywords '("languages"))
