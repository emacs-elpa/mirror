;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-make-toc" "0.6"
  "Automatic tables of contents for Org files."
  '((emacs  "26.1")
    (dash   "2.12")
    (s      "1.10.0")
    (org    "9.3")
    (compat "29.1"))
  :url "https://github.com/alphapapa/org-make-toc"
  :commit "5f0f39b11c091a5abf49ddf78a6f740252920f78"
  :revdesc "v0.6-0-g5f0f39b11c09"
  :keywords '("org" "convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
