;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.1.0.0.20260923.9"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.4.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "7ca4ee574d6a2b14032a9769c5c4cada97b97977"
  :revdesc "v3.1.0-9-g7ca4ee574d6a"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
