;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-snippets" "0.1.0.0.20180113.8"
  "Yasnippets for go."
  '((yasnippet "0.8.0"))
  :url "https://github.com/toumorokoshi/go-snippets"
  :commit "d437df148879566ffe7f2e503a3cf2602aa9fb28"
  :revdesc "d437df148879"
  :keywords '("snippets"))
