;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260614.2123"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "743651d4728737cb864635a9de45395a0ee9d9fd"
  :revdesc "743651d47287"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
