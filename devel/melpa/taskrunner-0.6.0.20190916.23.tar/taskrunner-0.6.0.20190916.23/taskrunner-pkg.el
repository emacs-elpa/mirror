;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskrunner" "0.6.0.20190916.23"
  "Retrieve build system/taskrunner tasks."
  '((emacs      "25.1")
    (projectile "2.0.0")
    (async      "1.9.3"))
  :url "https://github.com/emacs-taskrunner/emacs-taskrunner"
  :commit "716323aff410b4d864d137c9ebe4bbb5b8587f5e"
  :revdesc "716323aff410"
  :keywords '("build-system" "taskrunner" "build" "task-runner" "tasks" "convenience")
  :authors '(("Yavor Konstantinov" . "ykonstantinov1ATgmailDOTcom"))
  :maintainers '(("Yavor Konstantinov" . "ykonstantinov1ATgmailDOTcom")))
