;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mbsync" "0.1.2.0.20200128.11"
  "Run mbsync to fetch mails."
  ()
  :url "https://github.com/dimitri/mbsync-el"
  :commit "d3c81da81ce5b154c0d048047a47277338721a70"
  :revdesc "d3c81da81ce5"
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
