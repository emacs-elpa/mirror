;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertica" "0.1.0.0.20131217.5"
  "Vertica SQL mode extension."
  '((sql "3.0"))
  :url "https://github.com/r0man/vertica-el"
  :commit "3c9647b425c5c13c30bf0cba483646af18196588"
  :revdesc "3c9647b425c5"
  :keywords '("sql" "vertica")
  :authors '(("Roman Scherer" . "roman@burningswell.com"))
  :maintainers '(("Roman Scherer" . "roman@burningswell.com")))
