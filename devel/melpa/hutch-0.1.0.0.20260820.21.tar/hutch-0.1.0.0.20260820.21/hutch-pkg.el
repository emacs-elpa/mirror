;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hutch" "0.1.0.0.20260820.21"
  "AI code review for magit."
  '((emacs     "29.1")
    (magit     "4.0")
    (transient "0.7.4")
    (gptel     "0.9.9.3")
    (svg-lib   "0.3"))
  :url "https://github.com/adjaecent/magit-hutch"
  :commit "319e5c55c66968ebce7beeb780c18dc20fdeac6b"
  :revdesc "319e5c55c669"
  :authors '(("Akshay Gupta" . "mail@kitallis.in"))
  :maintainers '(("Akshay Gupta" . "mail@kitallis.in")))
