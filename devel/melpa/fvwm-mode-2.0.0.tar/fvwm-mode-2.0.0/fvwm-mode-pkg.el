;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fvwm-mode" "2.0.0"
  "A major mode for editing Fvwm configuration files."
  ()
  :url "https://github.com/theBlackDragon/fvwm-mode"
  :commit "574c0370f6199c9a1492923bf0d35fdd26738d24"
  :revdesc "v2.0.0-0-g574c0370f619"
  :keywords '("files")
  :authors '(("Bert Geens" . "bert@lair.be"))
  :maintainers '(("Bert Geens" . "bert@lair.be")))
