;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-tools" "0.1.0.20210622.39"
  "Indent, navigate (and more) by blocks of indentation: yaml, python etc."
  '((s         "0")
    (hydra     "0")
    (yafolding "0"))
  :url "https://gitlab.com/emacs-stuff/indent-tools/"
  :commit "c731f05fa3950e2e8580ec61b88abbc705639830"
  :revdesc "c731f05fa395"
  :keywords '("indentation" "movements" "navigation" "kill" "fold" "yaml" "python")
  :authors '(("vindarel" . "vindarel@mailz.org"))
  :maintainers '(("vindarel" . "vindarel@mailz.org")))
