;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lang-refactor-perl" "0.1.4.0.20131122.6"
  "Simple refactorings, primarily for Perl."
  ()
  :url "https://github.com/jplindstrom/emacs-lang-refactor-perl"
  :commit "691bd69639de6b7af357e3b7143563ececd9c497"
  :revdesc "691bd69639de"
  :keywords '("languages" "refactoring" "perl")
  :authors '(("Johan Lindstrom" . "buzzwordninjanot_this_bit@googlemail.com"))
  :maintainers '(("Johan Lindstrom" . "buzzwordninjanot_this_bit@googlemail.com")))
