;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dune" "3.25.0"
  "Integration with the dune build system."
  ()
  :url "https://github.com/ocaml/dune"
  :commit "b845053f93d094f89c2ca933f960d853e3588e52"
  :revdesc "3.25.0-0-gb845053f93d0")
