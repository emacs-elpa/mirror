;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "look-mode" "0.0.0.20250511.58"
  "Quick file viewer for image and text file browsing."
  ()
  :url "https://github.com/petermao/look-mode"
  :commit "6d82a013ede5f9ef5493801c3071bad5f6b283bb"
  :revdesc "6d82a013ede5"
  :authors '(("Peter H. Mao" . "petermao@jpl.nasa.gov"))
  :maintainers '(("Peter H. Mao" . "petermao@jpl.nasa.gov")))
