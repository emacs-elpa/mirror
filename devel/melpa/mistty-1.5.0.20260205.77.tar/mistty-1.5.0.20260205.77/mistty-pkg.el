;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "1.5.0.20260205.77"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "bf0ddd077351001c56a4c754399d7ec025b93bab"
  :revdesc "bf0ddd077351"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
