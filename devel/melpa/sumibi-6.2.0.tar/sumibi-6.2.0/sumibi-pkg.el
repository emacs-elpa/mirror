;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "6.2.0"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (markdown-mode  "2.0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "9b191439bdaa0f6a36ad95429e725d096d564096"
  :revdesc "v6.2.0-0-g9b191439bdaa"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
