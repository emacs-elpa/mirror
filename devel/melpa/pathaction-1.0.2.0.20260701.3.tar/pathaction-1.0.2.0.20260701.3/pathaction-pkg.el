;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "1.0.2.0.20260701.3"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "845a2aec48df0f42010db1ed2c87880b2ddb1f69"
  :revdesc "1.0.2-3-g845a2aec48df"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
