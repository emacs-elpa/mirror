;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.62.1.0.20260720.15"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8a6ea7a22afb6e7aef198a41bba2cc554e96981c"
  :revdesc "8a6ea7a22afb")
