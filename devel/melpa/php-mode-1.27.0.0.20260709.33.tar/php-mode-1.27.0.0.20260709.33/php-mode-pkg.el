;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "1.27.0.0.20260709.33"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "86e788eeeab57e0576fad9ec9ea1fab0c236efb7"
  :revdesc "86e788eeeab5"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
