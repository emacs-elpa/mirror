;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor-view" "0.1.1.0.20230807.9"
  "Open anki-editor notes from Anki."
  '((emacs "29.1"))
  :url "https://gitlab.com/vherrmann/anki-editor-view"
  :commit "6ad8c6be4f44de0c33eab012e507320b732d4800"
  :revdesc "6ad8c6be4f44"
  :authors '(("Valentin Herrmann" . "me@valentin-herrmann.de"))
  :maintainers '(("Valentin Herrmann" . "me@valentin-herrmann.de")))
