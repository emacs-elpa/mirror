;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frame-mode" "0.0.0.0.20260710.18"
  "Use frames instead of windows."
  '((s     "1.9.0")
    (emacs "24.4"))
  :url "https://github.com/IvanMalison/frame-mode"
  :commit "0435d9ed05223904cf389eea881553632e681035"
  :revdesc "0435d9ed0522"
  :keywords '("frames")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
