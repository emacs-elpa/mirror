;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symbol-navigation-hydra" "0.0.7"
  "A symbol-aware, range-aware hydra."
  '((auto-highlight-symbol "1.61")
    (hydra                 "0.15.0")
    (emacs                 "24.4")
    (multiple-cursors      "1.4.0"))
  :url "https://github.com/bgwines/symbol-navigation-hydra"
  :commit "b3b1257e676514d93cd2d71a10a485bf00b5375f"
  :revdesc "b3b1257e6765"
  :keywords '("highlight" "face" "match" "convenience" "hydra" "symbol")
  :authors '(("Brett Wines" . "bgwines@cs.stanford.edu"))
  :maintainers '(("Brett Wines" . "bgwines@cs.stanford.edu")))
