;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "espresso-theme" "1.0.0.20210505.10"
  "Espresso Tutti Colori port for Emacs."
  ()
  :url "https://github.com/dgutov/espresso-theme"
  :commit "580f673729f02aa07070c5300bedf24733d56e74"
  :revdesc "580f673729f0"
  :authors '(("Martin Kühl" . "purl.org/net/mkhl"))
  :maintainers '(("Martin Kühl" . "purl.org/net/mkhl")))
