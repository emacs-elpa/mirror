;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-cmake" "0.2.1.0.20260728.6"
  "A cmake backend for project.el."
  '((emacs "30.1"))
  :url "https://github.com/lucius-martius/project-cmake"
  :commit "9b0d785220e6e2368f6c02fe336911dc18703faa"
  :revdesc "9b0d785220e6"
  :keywords '("tools" "convenience")
  :authors '(("Lucius Martius" . "lucius.martius@mailbox.org"))
  :maintainers '(("Lucius Martius" . "lucius.martius@mailbox.org")))
