;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "1.6.7"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "2df8d0500aa842fbb60109e863a70c705dfe998d"
  :revdesc "2df8d0500aa8"
  :keywords '("convenience" "comm" "hypermedia"))
