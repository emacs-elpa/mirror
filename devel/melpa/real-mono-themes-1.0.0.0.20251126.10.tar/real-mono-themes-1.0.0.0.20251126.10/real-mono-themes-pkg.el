;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "real-mono-themes" "1.0.0.0.20251126.10"
  "Real monochromatic color themes."
  '((emacs "28.1"))
  :url "https://github.com/NestorLiao/real-mono-themes"
  :commit "45d68036bce5c3d95fcfdb4f02fca5fddb70e3db"
  :revdesc "45d68036bce5"
  :keywords '("faces")
  :authors '(("Qingsong Liao" . "llqingsong@qq.com"))
  :maintainers '(("Qingsong Liao" . "llqingsong@qq.com")))
