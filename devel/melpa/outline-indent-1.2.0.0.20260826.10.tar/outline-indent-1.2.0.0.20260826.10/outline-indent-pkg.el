;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "1.2.0.0.20260826.10"
  "Folding text based on indentation (origami alternative)."
  '((emacs    "26.1")
    (kirigami "1.0.5"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "41b5065b5c9a2a0b8a796cab27e60aad00d762f0"
  :revdesc "1.2.0-10-g41b5065b5c9a"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
