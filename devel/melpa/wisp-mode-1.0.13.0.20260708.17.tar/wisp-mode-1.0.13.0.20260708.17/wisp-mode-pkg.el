;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wisp-mode" "1.0.13.0.20260708.17"
  "Tools for wisp: the Whitespace-to-Lisp preprocessor."
  '((emacs "24.4"))
  :url "http://www.draketo.de/english/wisp"
  :commit "71dcfcbdf9a50f3a32012481bd0bf79859b4141c"
  :revdesc "v1.0.13-16-m71dcfcbdf9a5"
  :keywords '("languages" "lisp" "scheme")
  :authors '(("Arne Babenhauserheide" . "arne_bab@web.de"))
  :maintainers '(("Arne Babenhauserheide" . "arne_bab@web.de")))
