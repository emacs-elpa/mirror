;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "1.0.9.0.20261028.2"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "af74958268102cc6ad9c99129be4d05e4de57acb"
  :revdesc "1.0.9-2-gaf7495826810"
  :keywords '("convenience" "files" "tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
