;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "google-c-style" "0.0.0.20220210.455"
  "Google's C/C++ style for c-mode."
  ()
  :url "https://github.com/google/styleguide"
  :commit "af78b49ac4fef8083094d5105f72528ee7d09073"
  :revdesc "af78b49ac4fe"
  :keywords '("c" "tools"))
