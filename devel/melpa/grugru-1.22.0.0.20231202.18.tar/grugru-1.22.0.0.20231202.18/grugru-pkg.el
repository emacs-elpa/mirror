;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grugru" "1.22.0.0.20231202.18"
  "Rotate text at point."
  '((emacs "24.4"))
  :url "https://github.com/ROCKTAKEY/grugru"
  :commit "3f1bc431f4dc919a7b04e519f1c8add9fb2949f3"
  :revdesc "3f1bc431f4dc"
  :keywords '("convenience" "abbrev" "tools")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
