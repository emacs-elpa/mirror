;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-notifications" "0.1.0.20210918.10"
  "Creates notifications for org-mode entries."
  '((emacs     "25.1")
    (org       "9.0")
    (sound-wav "0.02")
    (alert     "1.2")
    (seq       "2.21"))
  :url "https://github.com/doppelc/org-notifications"
  :commit "b8032f8adfbeb328962a5657c6dd173e64cc76e5"
  :revdesc "b8032f8adfbe"
  :keywords '("outlines"))
