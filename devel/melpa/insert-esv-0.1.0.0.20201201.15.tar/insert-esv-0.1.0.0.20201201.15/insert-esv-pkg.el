;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insert-esv" "0.1.0.0.20201201.15"
  "Insert ESV Bible passages."
  '((emacs   "24.3")
    (request "0.3.2"))
  :url "https://github.com/sam030820/insert-esv/"
  :commit "b6b47f1521f221e0c2a215f1f802708e10294422"
  :revdesc "b6b47f1521f2"
  :keywords '("convenience"))
