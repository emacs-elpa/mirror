;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "show-css" "1.1.0.20160210.40"
  "Show the css of the html attribute the cursor is on."
  '((doom "1.3")
    (s    "1.10.0"))
  :url "https://github.com/smmcg/showcss-mode"
  :commit "771daeddd4df7a7c10f66419a837145649bab63b"
  :revdesc "771daeddd4df"
  :keywords '("hypermedia")
  :authors '(("Sheldon McGrandle" . "developer@rednemesis.com"))
  :maintainers '(("Sheldon McGrandle" . "developer@rednemesis.com")))
