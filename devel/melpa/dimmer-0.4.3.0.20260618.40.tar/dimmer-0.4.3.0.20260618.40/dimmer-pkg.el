;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dimmer" "0.4.3.0.20260618.40"
  "Visually highlight the selected buffer."
  '((emacs "27.1"))
  :url "https://github.com/gonewest818/dimmer.el"
  :commit "bbab62f01d45086b9098f6a0ab765282d9c7bc45"
  :revdesc "bbab62f01d45"
  :keywords '("faces" "editing"))
