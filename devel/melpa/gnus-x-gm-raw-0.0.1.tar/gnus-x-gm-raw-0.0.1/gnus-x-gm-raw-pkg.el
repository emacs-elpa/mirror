;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-x-gm-raw" "0.0.1"
  "Search mail of Gmail using X-GM-RAW as web interface."
  '((log4e      "0.2.0")
    (yaxception "0.1"))
  :url "https://github.com/aki2o/gnus-x-gm-raw"
  :commit "978bdfcecc8844465b71641c2e909fcdc66b22be"
  :revdesc "978bdfcecc88"
  :keywords '("gnus")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
