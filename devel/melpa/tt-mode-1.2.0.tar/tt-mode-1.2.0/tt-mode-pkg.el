;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tt-mode" "1.2.0"
  "Major mode for editing Template Toolkit files."
  '((emacs "24.1"))
  :url "https://github.com/davorg/tt-mode"
  :commit "39f907c67d049c3c5d31db0b0b16e84edc323005"
  :revdesc "39f907c67d04"
  :keywords '("languages")
  :authors '(("Dave Cross" . "dave@dave.org.uk"))
  :maintainers '(("Dave Cross" . "dave@dave.org.uk")))
