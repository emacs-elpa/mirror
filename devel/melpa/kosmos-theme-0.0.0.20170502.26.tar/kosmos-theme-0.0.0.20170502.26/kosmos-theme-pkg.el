;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kosmos-theme" "0.0.0.20170502.26"
  "Black and lightgray theme with not so much syntax highlighting."
  '((emacs "24"))
  :url "https://github.com/habamax/kosmos-theme"
  :commit "616456d2376a75dc31190ad65137d179fbad4336"
  :revdesc "616456d2376a"
  :authors '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers '(("Maxim Kim" . "habamax@gmail.com")))
