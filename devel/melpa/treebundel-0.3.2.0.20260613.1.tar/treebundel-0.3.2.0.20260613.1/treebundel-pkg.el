;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treebundel" "0.3.2.0.20260613.1"
  "Bundle related git-worktrees together."
  '((emacs "29.1"))
  :url "https://github.com/purplg/treebundel"
  :commit "9b64c358338e90c02e9aedb4689a3c1a8be29abf"
  :revdesc "9b64c358338e"
  :keywords '("convenience" "vc"))
