;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "friendly-tramp-path" "0.1.0.0.20200502.2"
  "Human-friendly TRAMP path construction."
  '((cl-lib "0.6.1"))
  :url "https://github.com/p3r7/prf-tramp"
  :commit "be572b8953b9e5a3a35c30bb64c2936d3e9802ba"
  :revdesc "be572b8953b9")
