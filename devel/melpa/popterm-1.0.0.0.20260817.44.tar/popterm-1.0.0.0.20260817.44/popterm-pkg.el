;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "1.0.0.0.20260817.44"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "07410f12057c5ec80f2f81a17f5b66d94ecbc6d0"
  :revdesc "07410f12057c"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
