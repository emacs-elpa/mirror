;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.6.0.0.20260722.37"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "7959c8fda61dfaa053e161f201531377f1b920c8"
  :revdesc "7959c8fda61d"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
