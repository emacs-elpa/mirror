;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "etc-sudoers-mode" "1.1.1.0.20260224.1"
  "Edit Sudo security policies."
  '((sudo-edit   "0")
    (with-editor "0"))
  :url "https://gitlab.com/mavit/etc-sudoers-mode/"
  :commit "400b4d4d7281b33896d388e84dec6b7a2c39ea22"
  :revdesc "400b4d4d7281"
  :keywords '("languages")
  :authors '(("Peter Oliver" . "git@mavit.org.uk"))
  :maintainers '(("Peter Oliver" . "git@mavit.org.uk")))
