;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-dall-e-shell" "0.33.1.0.20241112.2"
  "Org babel functions for DALL-E evaluation."
  '((emacs        "27.1")
    (dall-e-shell "0.43.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "1ef7951bf47f63d2d0808c3f475f82eac8c9b219"
  :revdesc "1ef7951bf47f")
