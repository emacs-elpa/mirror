;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "build-helper" "0.1.0.20161009.37"
  "Utilities to help build code."
  '((projectile "0.9.0"))
  :url "https://github.com/afonso360/build-helper"
  :commit "d1962858734253eca791721ccf62d1c4a10719f5"
  :revdesc "d19628587342"
  :keywords '("convenience")
  :authors '(("Afonso Bordado" . "afonsobordado@az8.co"))
  :maintainers '(("Afonso Bordado" . "afonsobordado@az8.co")))
