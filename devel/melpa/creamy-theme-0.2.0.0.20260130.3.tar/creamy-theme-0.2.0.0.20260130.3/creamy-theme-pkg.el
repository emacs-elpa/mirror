;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "creamy-theme" "0.2.0.0.20260130.3"
  "A simple creamy theme."
  '((emacs "24.1"))
  :url "https://github.com/smallwat3r/emacs-creamy-theme"
  :commit "d16902a91c28d616d01bb7bcfd7c6248415f5860"
  :revdesc "d16902a91c28")
