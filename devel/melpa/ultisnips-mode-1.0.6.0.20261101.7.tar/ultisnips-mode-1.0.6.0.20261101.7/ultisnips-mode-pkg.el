;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "1.0.6.0.20261101.7"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "7bc2751e0c70dd784785c97727cdcd9f6e8dc500"
  :revdesc "1.0.6-7-g7bc2751e0c70"
  :keywords '("languages" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
