;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-etags" "0.6.0.20161001.5"
  "Etags/ctags completion source for auto-complete."
  '((auto-complete "1.4"))
  :url "https://github.com/syohex/emacs-ac-etags"
  :commit "7983e631c226fe0fa53af3b2d56bf4eca3d785ce"
  :revdesc "7983e631c226"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
