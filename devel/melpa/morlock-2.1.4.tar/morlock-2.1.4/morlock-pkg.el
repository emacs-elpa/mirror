;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morlock" "2.1.4"
  "More font-lock keywords for elisp."
  '((emacs "29.1"))
  :url "https://github.com/tarsius/morlock"
  :commit "1fd3cc79b1fa1f69386d6b2fa058e2477d35a4e7"
  :revdesc "v2.1.4-0-g1fd3cc79b1fa"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev")))
