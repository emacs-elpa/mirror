;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-battery" "0.2.0.20150101.4"
  "Fancy battery display."
  '((emacs "24.1"))
  :url "https://github.com/lunaryorn/fancy-battery.el"
  :commit "bcc2d7960ba207b5b4db96fe40f7d72670fdbb68"
  :revdesc "0.2-4-gbcc2d7960ba2"
  :keywords '("convenience" "tools" "hardware")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
