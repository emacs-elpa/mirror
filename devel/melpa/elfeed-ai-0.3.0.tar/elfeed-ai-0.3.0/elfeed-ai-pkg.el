;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-ai" "0.3.0"
  "AI-powered article summarization for elfeed."
  '((emacs  "28.1")
    (elfeed "3.4.1")
    (gptel  "0.9.9"))
  :url "https://github.com/danielfleischer/elfeed-ai"
  :commit "10c8f39e3304eca2d6fabb3b06d252d0c0c0bdaa"
  :revdesc "v0.3.0-0-g10c8f39e3304"
  :keywords '("comm" "news" "ai")
  :authors '(("Daniel Fleischer" . "danflscr@gmail.com"))
  :maintainers '(("Daniel Fleischer" . "danflscr@gmail.com")))
