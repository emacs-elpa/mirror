;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soft-morning-theme" "0.2.0.20150918.7"
  "Emacs24 theme with a light background."
  ()
  :url "https://github.com/mswift42/soft-morning-theme"
  :commit "c0f9c70c97ef2be2a093cf839c4bfe27740a111c"
  :revdesc "c0f9c70c97ef")
