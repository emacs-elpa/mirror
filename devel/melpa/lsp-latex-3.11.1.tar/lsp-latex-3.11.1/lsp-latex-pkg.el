;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-latex" "3.11.1"
  "LSP-mode client for LaTeX, on texlab."
  '((emacs    "29.1")
    (lsp-mode "6.0")
    (consult  "0.35"))
  :url "https://github.com/ROCKTAKEY/lsp-latex"
  :commit "e57cf3a2330fd05a906b2b7ad74972ce0642d284"
  :revdesc "v3.11.1-0-ge57cf3a2330f"
  :keywords '("languages" "tex")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
