;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.88.0.20260709.6"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "1745025ee5f4d6382c26ffa8c38bad6b2c9e8e26"
  :revdesc "1745025ee5f4"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
