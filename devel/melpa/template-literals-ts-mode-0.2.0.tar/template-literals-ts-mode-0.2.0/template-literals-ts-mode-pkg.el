;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "template-literals-ts-mode" "0.2.0"
  "Tree-sitter support for HTML/CSS in JS/TS template literals."
  '((emacs "30.1"))
  :url "https://github.com/ispringle/template-literals-ts-mode"
  :commit "cb5d55b4d962efff42d067463bee8cfc0a61a318"
  :revdesc "cb5d55b4d962"
  :keywords '("languages" "javascript" "typescript" "tree-sitter")
  :authors '(("Ian S. Pringle" . "ian@dapringles.org"))
  :maintainers '(("Ian S. Pringle" . "ian@dapringles.org")))
