;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "contextual-menubar" "1.0.0.0.20180205.2"
  "Display the menubar only on a graphical display."
  ()
  :url "https://github.com/aaronjensen/contextual-menubar"
  :commit "f76f55232ac07df76ef9a334a0c527dfab97c40b"
  :revdesc "1.0.0-2-gf76f55232ac0"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
