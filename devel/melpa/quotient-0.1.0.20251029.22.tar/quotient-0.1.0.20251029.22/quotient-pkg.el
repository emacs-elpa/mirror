;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quotient" "0.1.0.20251029.22"
  "A library for generating random quotes using a text corpus."
  '((emacs  "25.1")
    (compat "30.1.0.1"))
  :url "https://github.com/tvirolai/quotient"
  :commit "3bece7b17a4ef7745f8c49c0c21570239f2b4ded"
  :revdesc "3bece7b17a4e"
  :keywords '("lisp")
  :authors '(("Tuomo Virolainen" . "tvirolai@soittakaaparanoid.mail.kapsi.fi"))
  :maintainers '(("Tuomo Virolainen" . "tvirolai@soittakaaparanoid.mail.kapsi.fi")))
