;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pasp-mode" "0.1.0.0.20180404.8"
  "- A major mode for editing Answer Set Programs."
  '((emacs "24.3"))
  :url "https://github.com/santifa/pasp-mode"
  :commit "59385eb0e8ebcfc8c11dd811fb145d4b0fa3cc92"
  :revdesc "59385eb0e8eb"
  :keywords '("asp" "pasp" "answer set programs" "potassco answer set programs" "major mode" "languages")
  :authors '(("Henrik Jürges" . "juerges.henrik@gmail.com"))
  :maintainers '(("Henrik Jürges" . "juerges.henrik@gmail.com")))
