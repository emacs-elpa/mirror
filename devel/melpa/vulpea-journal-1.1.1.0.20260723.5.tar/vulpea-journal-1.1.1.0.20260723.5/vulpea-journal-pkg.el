;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-journal" "1.1.1.0.20260723.5"
  "Daily note interface for vulpea."
  '((emacs     "29.1")
    (vulpea    "2.5.0")
    (vulpea-ui "1.1.0")
    (vui       "1.3.0")
    (dash      "2.20.0"))
  :url "https://github.com/d12frosted/vulpea-journal"
  :commit "ab9858dd1c2cb448736bb312a45dde4525e026e7"
  :revdesc "v1.1.1-5-gab9858dd1c2c"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
