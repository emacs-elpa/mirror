;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.5.3.0.20260824.15"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "40cd0b9f59a431916b4acb3286b67d6240332fd2"
  :revdesc "v4.5.3-15-g40cd0b9f59a4"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
