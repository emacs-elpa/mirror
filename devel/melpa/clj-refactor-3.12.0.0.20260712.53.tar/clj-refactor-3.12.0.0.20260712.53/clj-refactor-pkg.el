;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clj-refactor" "3.12.0.0.20260712.53"
  "A collection of commands for refactoring Clojure code."
  '((emacs        "28.1")
    (yasnippet    "0.6.1")
    (paredit      "24")
    (clojure-mode "5.18.0")
    (cider        "1.11.1")
    (parseedn     "1.2.0")
    (transient    "0.4.1")
    (spinner      "1.7"))
  :url "https://github.com/clojure-emacs/clj-refactor.el"
  :commit "f11383b643a46bb41f657455a55900682e6baf1c"
  :revdesc "v3.12.0-53-gf11383b643a4"
  :keywords '("convenience" "clojure" "cider")
  :authors '(("Magnar Sveen" . "magnars@gmail.com")
             ("Lars Andersen" . "expez@expez.com")
             ("Benedek Fazekas" . "benedek.fazekas@gmail.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")
                 ("Lars Andersen" . "expez@expez.com")
                 ("Benedek Fazekas" . "benedek.fazekas@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
