;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "1.7.7.0.20260904.8"
  "A set of eye pleasing themes."
  '((emacs      "26.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "316bb3119ebbf845504cfc932ff187cdd646f45f"
  :revdesc "316bb3119ebb"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
