;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cd-compile" "0.1.0.20141108.3"
  "Run compile in a specific directory."
  ()
  :url "https://github.com/jamienicol/emacs-cd-compile"
  :commit "10284ccae86afda4a37b09ba90acd1e2efedec9f"
  :revdesc "10284ccae86a"
  :authors '(("Jamie Nicol" . "jamie@thenicols.net"))
  :maintainers '(("Jamie Nicol" . "jamie@thenicols.net")))
