;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-lispops" "0.10.2"
  "Operations for editing lisp evilly."
  '((emacs "26.1")
    (evil  "1.2.10"))
  :url "https://github.com/precompute/evil-lispops"
  :commit "372b52df1a45fcea6c9461e7909cfdbb1db822a9"
  :revdesc "372b52df1a45"
  :authors '(("precompute" . "git@precompute.net"))
  :maintainers '(("precompute" . "git@precompute.net")))
