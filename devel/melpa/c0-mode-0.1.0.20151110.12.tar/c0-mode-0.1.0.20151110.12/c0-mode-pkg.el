;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "c0-mode" "0.1.0.20151110.12"
  "Major mode for editing C0 files."
  ()
  :url "http://c0.typesafety.net/"
  :commit "c214093c36864d6208fcb9e6a72413ed17ed5d60"
  :revdesc "c214093c3686"
  :keywords '("c0" "languages"))
