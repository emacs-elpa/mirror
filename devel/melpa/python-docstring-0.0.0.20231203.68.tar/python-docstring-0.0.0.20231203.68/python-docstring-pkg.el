;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-docstring" "0.0.0.20231203.68"
  "Smart Python docstring formatting."
  ()
  :url "https://github.com/glyph/python-docstring-mode"
  :commit "48e6489ec2db8b4959a9f591910941c2a5f132a3"
  :revdesc "48e6489ec2db")
