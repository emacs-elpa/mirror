;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "schrute" "0.2.2.0.20170521.2"
  "Help you remember there is a better way to do something."
  '((emacs "24.3"))
  :url "https://bitbucket.org/shackra/dwight-k.-schrute"
  :commit "59faa6c4232ae183cea93237301acad8c0763997"
  :revdesc "59faa6c4232a"
  :keywords '("convenience")
  :authors '(("Jorge Araya Navarro" . "elcorreo@deshackra.com"))
  :maintainers '(("Jorge Araya Navarro" . "elcorreo@deshackra.com")))
