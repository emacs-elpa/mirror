;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kotlin-ts-mode" "0.1.0.20260824.58"
  "A mode for editing Kotlin files based on tree-sitter."
  '((emacs "30.1"))
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode"
  :commit "292c9a05ff2243c39a48201b277840b1d25e1ea0"
  :revdesc "292c9a05ff22"
  :authors '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers '(("Alex Figl-Brick" . "alex@alexbrick.me")))
