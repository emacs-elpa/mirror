;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotated-completing-read" "0.1.0.20261121.62"
  "Ergonomic completing-read wrapper/helper."
  '((emacs "29.1"))
  :url "https://github.com/tychoish/annotated-completing-read"
  :commit "356c2dfd697da56078b1b50fb4409d00bc9bb5da"
  :revdesc "356c2dfd697d"
  :keywords '("convenience" "matching")
  :authors '(("sam kleinman" . "garen@tychoish.com"))
  :maintainers '(("sam kleinman" . "garen@tychoish.com")))
