;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "posframe" "1.5.2.0.20260816.2"
  "Pop a posframe (just a frame) at point."
  '((emacs "26.1"))
  :url "https://github.com/tumashu/posframe"
  :commit "ec0ec37c0d6397422a07def499e87591ca037af7"
  :revdesc "ec0ec37c0d63"
  :keywords '("convenience" "tooltip")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
