;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "upbo" "1.0.0.0.20180422.12"
  "Karma Test Runner Integration."
  '((dash  "2.12.0")
    (emacs "24.4"))
  :url "https://github.com/shiren"
  :commit "63514c484e70cd6eeae828f7e58216e1a3429184"
  :revdesc "63514c484e70"
  :keywords '("javascript" "js" "test" "karma"))
