;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-statistics" "0.2.2.0.20250805.6"
  "Sort candidates using completion history."
  '((emacs   "24.3")
    (company "0.8.5"))
  :url "https://github.com/company-mode/company-statistics"
  :commit "120e982f47e01945c044e0762ba376741c41b76c"
  :revdesc "0.2.2-6-g120e982f47e0"
  :keywords '("abbrev" "convenience" "matching")
  :authors '(("Ingo Lohmar" . "i.lohmar@gmail.com"))
  :maintainers '(("Ingo Lohmar" . "i.lohmar@gmail.com")))
