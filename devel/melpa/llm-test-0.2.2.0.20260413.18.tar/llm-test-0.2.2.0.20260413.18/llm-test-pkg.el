;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "0.2.2.0.20260413.18"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "b01444d9a7cffd7273162043921cb47eacc48373"
  :revdesc "b01444d9a7cf"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
