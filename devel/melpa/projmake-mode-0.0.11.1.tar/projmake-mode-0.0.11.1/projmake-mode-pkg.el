;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projmake-mode" "0.0.11.1"
  "Run build system for project."
  '((dash       "20150611.922")
    (indicators "20130217.1405"))
  :url "https://github.com/emacsattic/projmake-mode"
  :commit "99f10611c24e0884f1f24744adcccb3d972326f6"
  :revdesc "99f10611c24e")
