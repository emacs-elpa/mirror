;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "affe" "0.10"
  "Asynchronous Fuzzy Finder for Emacs."
  '((emacs   "29.1")
    (consult "2.8"))
  :url "https://github.com/minad/affe"
  :commit "ccc6e4dc3dc7c87bdd4733d174274f4710f9e99e"
  :revdesc "0.10-0-gccc6e4dc3dc7"
  :keywords '("matching" "files" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
