;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-projectile" "0.3.5.0.20260918.1"
  "Ivy integration for Projectile."
  '((counsel    "0.13.4")
    (projectile "3.3.0"))
  :url "https://github.com/lafrenierejm/counsel-projectile"
  :commit "283352a5bd6d7df9f69974000323123845f894bb"
  :revdesc "0.3.5-1-g283352a5bd6d"
  :keywords '("project" "convenience")
  :maintainers '(("Joseph LaFreniere" . "git@lafreniere.xyz")))
