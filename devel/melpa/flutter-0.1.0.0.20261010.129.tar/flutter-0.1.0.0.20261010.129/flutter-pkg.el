;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flutter" "0.1.0.0.20261010.129"
  "Tools for working with Flutter SDK."
  '((emacs "28.1"))
  :url "https://github.com/amake/flutter.el"
  :commit "b7ca9515ce04c68d5fa580c0b1a1cec5aed7c5a6"
  :revdesc "b7ca9515ce04"
  :keywords '("languages"))
