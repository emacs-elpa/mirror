;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.4.0.0.20260821.13"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "413bfd18996a2ec72dc1b4aa793532953099aa14"
  :revdesc "v1.4.0-13-g413bfd18996a"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
