;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "1.0.1"
  "Client for Lichess.org."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "98aadeaf2ec78345279e2292075deef9b47fbfb3"
  :revdesc "v1.0.1-0-g98aadeaf2ec7"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
