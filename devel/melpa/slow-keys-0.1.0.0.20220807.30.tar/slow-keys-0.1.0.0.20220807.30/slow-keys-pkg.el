;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slow-keys" "0.1.0.0.20220807.30"
  "Slow keys mode to avoid RSI."
  '((emacs "24.1"))
  :url "https://github.com/manuel-uberti/slow-keys"
  :commit "b951ae4bdcea56ced03f227b82b28c3d91d15e61"
  :revdesc "b951ae4bdcea"
  :keywords '("convenience")
  :authors '(("Manuel Uberti" . "manuel.uberti@inventati.org"))
  :maintainers '(("Manuel Uberti" . "manuel.uberti@inventati.org")))
