;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bshell" "1.1.0"
  "Manage and track multiple inferior shells."
  '((emacs         "26.1")
    (dash          "2.19.1")
    (buffer-manage "1.1"))
  :url "https://github.com/plandes/bshell"
  :commit "c13907ac0d2d8eda58c0e35d99179ed8c0e4c25a"
  :revdesc "v1.1.0-0-gc13907ac0d2d"
  :keywords '("unix" "interactive" "shell" "management"))
