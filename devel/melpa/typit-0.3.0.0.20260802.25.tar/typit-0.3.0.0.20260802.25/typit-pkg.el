;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typit" "0.3.0.0.20260802.25"
  "Typing game similar to tests on 10 fast fingers."
  '((emacs "24.4")
    (f     "0.18")
    (mmt   "0.1.1"))
  :url "https://github.com/mrkkrp/typit"
  :commit "82914a7a4c437762f51f366d2f5f0e8dbb6c222c"
  :revdesc "82914a7a4c43"
  :keywords '("games")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
