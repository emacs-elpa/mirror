;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.3.2.0.20261030.2"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "e9974c1cf02e4f52b5a31a54ee37d04cd11cebb9"
  :revdesc "hyperbole-9.3.2-2-ge9974c1cf02e"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")
                 ("Mats Lidell" . "matsl@gnu.org")))
