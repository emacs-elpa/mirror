;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ttx-mode" "0.1.0.0.20260628.11"
  "TrueType/OpenType font viewer using ttx."
  '((emacs "30.0"))
  :url "https://github.com/wmedrano/ttx-mode"
  :commit "58f4d4b2de51cfc47f3320c88fdb679ac8df6758"
  :revdesc "58f4d4b2de51"
  :keywords '("tools" "fonts")
  :authors '(("Will Medrano" . "will@wmedrano.dev"))
  :maintainers '(("Will Medrano" . "will@wmedrano.dev")))
