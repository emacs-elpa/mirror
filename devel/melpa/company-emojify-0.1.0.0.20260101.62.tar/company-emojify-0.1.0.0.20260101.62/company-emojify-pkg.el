;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-emojify" "0.1.0.0.20260101.62"
  "Company completion for Emojify."
  '((emacs   "26.1")
    (company "0.8.0")
    (emojify "1.2.1")
    (ht      "2.0"))
  :url "https://github.com/jcs-elpa/company-emojify"
  :commit "e7dcd46effa607c18cb4bde51a59dc310ceeac1c"
  :revdesc "e7dcd46effa6"
  :keywords '("convenience" "emoji" "company" "emojify")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
