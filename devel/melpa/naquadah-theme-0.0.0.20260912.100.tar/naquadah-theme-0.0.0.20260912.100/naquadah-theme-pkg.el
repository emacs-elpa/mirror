;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "naquadah-theme" "0.0.0.20260912.100"
  "A theme based on Tango color set."
  ()
  :url "https://github.com/jd/naquadah-theme"
  :commit "e46fd3fbc3a982d3c9d94647dd6e491593ce293c"
  :revdesc "e46fd3fbc3a9"
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")))
