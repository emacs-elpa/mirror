;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "2.8.0.20260729.10"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "d6268c346a1da6ddf7b027784199092e490544d6"
  :revdesc "2.8-10-gd6268c346a1d"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
