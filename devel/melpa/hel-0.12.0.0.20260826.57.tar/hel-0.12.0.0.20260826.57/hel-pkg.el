;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hel" "0.12.0.0.20260826.57"
  "Helix Emulation Layer."
  '((emacs        "29.1")
    (dash         "2.19.1")
    (avy          "0.5.0")
    (pcre2el      "1.12")
    (ultra-scroll "0.6"))
  :url "https://github.com/helheim-emacs/hel"
  :commit "28aac5b39cf582b0781bd61e6bce457625392e0e"
  :revdesc "28aac5b39cf5"
  :authors '(("Yuriy Artemyev" . "anuvyklack@gmail.com"))
  :maintainers '(("Yuriy Artemyev" . "anuvyklack@gmail.com")))
