;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "logpad" "1.0.2"
  "Simulate Windows Notepad for logging."
  ()
  :url "https://github.com/dertuxmalwieder/logpad.el"
  :commit "2955c6e3de40bd1e84acb4c16c7690b210f82bec"
  :revdesc "2955c6e3de40"
  :keywords '("files" "outlines" "notepad")
  :authors '(("Sven Knurr" . "git@tuxproject.de"))
  :maintainers '(("Sven Knurr" . "git@tuxproject.de")))
