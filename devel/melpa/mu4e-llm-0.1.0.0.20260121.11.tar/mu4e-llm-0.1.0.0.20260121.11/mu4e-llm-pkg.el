;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-llm" "0.1.0.0.20260121.11"
  "AI-powered email assistance for mu4e."
  '((emacs "28.1")
    (llm   "0.17"))
  :url "https://github.com/sillyfellow/mu4e-llm"
  :commit "290657310d4041c23d627572d6fb780da8ed02f8"
  :revdesc "v0.1.0-11-g290657310d40"
  :keywords '("mail" "convenience")
  :authors '(("Dr. Sandeep Sadanandan" . "sillyfellow@whybenormal.org"))
  :maintainers '(("Dr. Sandeep Sadanandan" . "sillyfellow@whybenormal.org")))
