;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-nginx" "0.1.0.20220210.5"
  "Company-mode keywords support for nginx-mode."
  '((emacs   "24")
    (cl-lib  "0")
    (company "0"))
  :url "https://repo.or.cz/company-nginx.git"
  :commit "8a9f1a5653fe2d9a5042bfb9377d54f37fcc64c8"
  :revdesc "8a9f1a5653fe"
  :keywords '("company" "nginx")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
