;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "huecycle" "1.0.0.0.20241129.12"
  "Idle color animation."
  '((emacs "27.1"))
  :url "https://github.com/pnor/huecycle"
  :commit "60eed50ffe83e2e139c8a675ff8e53cf94c8a1ee"
  :revdesc "60eed50ffe83"
  :keywords '("faces")
  :authors '(("Phillip O'Reggio" . "https://github.com/pnor")))
