;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "0.1.4.0.20260323.4"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "30.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "a6d8140295783b94cc6e5eef25ac8913a2b9b9f2"
  :revdesc "a6d814029578"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
