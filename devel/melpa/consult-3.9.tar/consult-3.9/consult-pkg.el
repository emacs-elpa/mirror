;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "3.9"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "b7558f65374b733b749147b2c299b93d7b939483"
  :revdesc "3.9-0-gb7558f65374b"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
