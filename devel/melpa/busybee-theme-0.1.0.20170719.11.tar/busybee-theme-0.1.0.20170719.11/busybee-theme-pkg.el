;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "busybee-theme" "0.1.0.20170719.11"
  "Port of vim's mustang theme."
  ()
  :url "https://github.com/mswift42/busybee-theme"
  :commit "66b2315b030582d0ebee605cf455d386d8c30fcd"
  :revdesc "66b2315b0305")
