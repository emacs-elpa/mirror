;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "1.13.0.20260609.1"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/tempel"
  :commit "0cfeac15a3c92373d41a743d00a5cb9368eaa006"
  :revdesc "1.13-1-g0cfeac15a3c9"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
