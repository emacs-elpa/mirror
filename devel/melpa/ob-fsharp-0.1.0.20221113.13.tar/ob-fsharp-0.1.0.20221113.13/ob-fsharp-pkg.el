;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-fsharp" "0.1.0.20221113.13"
  "Org-Babel F#."
  '((emacs       "25")
    (fsharp-mode "1.9.8")
    (seq         "2.22"))
  :url "https://github.com/juergenhoetzel/ob-fsharp"
  :commit "a5e893a88d47bd8ea01cf456331ce54910321b47"
  :revdesc "a5e893a88d47"
  :keywords '("literate programming" "reproducible research")
  :authors '(("Jürgen Hötzel" . "juergen@archlinux.org"))
  :maintainers '(("Jürgen Hötzel" . "juergen@archlinux.org")))
