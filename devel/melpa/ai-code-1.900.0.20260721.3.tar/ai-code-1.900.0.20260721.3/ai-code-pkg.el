;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.900.0.20260721.3"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "43d721caf5c26843e185426b0ce41191efc833a1"
  :revdesc "43d721caf5c2"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
