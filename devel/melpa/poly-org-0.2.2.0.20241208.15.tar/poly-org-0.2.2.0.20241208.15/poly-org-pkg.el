;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-org" "0.2.2.0.20241208.15"
  "Polymode for org-mode."
  '((emacs    "25")
    (polymode "0.2.2"))
  :url "https://github.com/polymode/poly-org"
  :commit "90d9ca9f440d3b6c03b185353edd37a100559ec4"
  :revdesc "90d9ca9f440d"
  :keywords '("languages" "multi-modes"))
