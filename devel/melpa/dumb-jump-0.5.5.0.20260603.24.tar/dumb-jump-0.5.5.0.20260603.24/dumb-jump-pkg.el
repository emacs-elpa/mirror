;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "0.5.5.0.20260603.24"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "26.1"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "cf06b4ccdce6a39346c32f05139f9ee8b77ee229"
  :revdesc "cf06b4ccdce6"
  :keywords '("programming"))
