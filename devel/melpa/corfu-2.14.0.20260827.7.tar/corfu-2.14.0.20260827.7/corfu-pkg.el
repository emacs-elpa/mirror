;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.14.0.20260827.7"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "afb932056e8f398ad29e53edb0ff3ea5c0f96eb9"
  :revdesc "2.14-7-gafb932056e8f"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
