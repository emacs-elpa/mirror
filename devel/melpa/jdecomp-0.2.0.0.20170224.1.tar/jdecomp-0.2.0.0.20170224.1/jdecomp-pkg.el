;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jdecomp" "0.2.0.0.20170224.1"
  "Interface to Java decompilers."
  '((emacs "24.5"))
  :url "https://github.com/xiongtx/jdecomp"
  :commit "692866abc83deedce62be8d6040cf24dda7fb7a8"
  :revdesc "692866abc83d"
  :keywords '("decompile" "java" "languages" "tools")
  :authors '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com"))
  :maintainers '(("Tianxiang Xiong" . "tianxiang.xiong@gmail.com")))
