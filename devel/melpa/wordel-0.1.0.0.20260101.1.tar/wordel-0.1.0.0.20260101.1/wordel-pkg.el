;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wordel" "0.1.0.0.20260101.1"
  "An Elisp implementation of \"Wordle\" (aka \"Lingo\")."
  '((emacs "27.1"))
  :url "https://github.com/progfolio/wordel"
  :commit "e31bc8b285984c12efb9a667b080f9b9c570d7d7"
  :revdesc "e31bc8b28598"
  :keywords '("games")
  :authors '(("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com"))
  :maintainers '(("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com")))
