;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "0.10.0.0.20260907.12"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "e9e0eb5f219c379931a03ea7feb3f934ede584ca"
  :revdesc "e9e0eb5f219c"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
