;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macports" "0.1.0.0.20260313.231"
  "A porcelain for MacPorts."
  '((emacs     "28.1")
    (transient "0.1.0"))
  :url "https://github.com/amake/macports.el"
  :commit "6de6616e6aeb762dfd287f72c09efce15e8c26f4"
  :revdesc "6de6616e6aeb"
  :keywords '("convenience"))
