;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "filldent" "1.0.1.0.20220423.4"
  "Fill or indent."
  '((emacs "24.1"))
  :url "https://github.com/duckwork/filldent.el"
  :commit "2f32e0cf5e27c613f962fa41bf3427bbdc04e6c0"
  :revdesc "2f32e0cf5e27"
  :authors '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainers '(("Case Duckworth" . "acdw@acdw.net")))
