;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tmsu" "0.9.0.20260610.117"
  "A basic TMSU interface."
  '((emacs "28.1"))
  :url "https://github.com/vifon/tmsu.el"
  :commit "625d01d87f2820f648816f78b0c5bc220f14488b"
  :revdesc "625d01d87f28"
  :keywords '("files"))
