;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disaster" "1.2.0.20250828.3"
  "Disassemble C, C++ or Fortran code under cursor."
  '((emacs "27"))
  :url "https://github.com/jart/disaster"
  :commit "0299c129d4153e3a794358159737c3ff9d155654"
  :revdesc "0299c129d415"
  :keywords '("tools" "c")
  :authors '(("Justine Tunney" . "jtunney@gmail.com")
             ("Abdelhak Bougouffa" . "abougouffa@fedoraproject.org"))
  :maintainers '(("Abdelhak Bougouffa" . "abougouffa@fedoraproject.org")))
