;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "0.9.0.20260630.88"
  "MCP server for Org-mode."
  '((emacs          "28.2")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "86443dab4e35f60e1762b5427c17a813bda50ba4"
  :revdesc "86443dab4e35"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
