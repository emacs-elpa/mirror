;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "0.6.5"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "95dcd634d9de45851fce911dd0fffc85822a2ecb"
  :revdesc "95dcd634d9de"
  :keywords '("languages"))
