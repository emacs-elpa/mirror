;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xwiki-mode" "0.0.1.0.20211112.24"
  "Major mode for xwiki-formatted text."
  '((emacs "27.1"))
  :url "https://github.com/ackerleytng/xwiki-mode"
  :commit "8b6f2caead8ec804e8d7d37d87eb3b46aa96b6e8"
  :revdesc "8b6f2caead8e"
  :keywords '("languages" "convenience" "tools")
  :authors '(("Ackerley Tng" . "ackerleytng@gmail.com"))
  :maintainers '(("Ackerley Tng" . "ackerleytng@gmail.com")))
