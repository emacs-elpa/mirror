;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "omni-kill" "0.6.0"
  "Kill all the things."
  ()
  :url "https://github.com/AdrieanKhisbe/omni-kill.el"
  :commit "904549c8fd6ac3cf22b5d7111ca8944e179cffea"
  :revdesc "904549c8fd6a"
  :keywords '("convenience" "editing" "tools")
  :authors '(("Adrien Becchis" . "adriean.khisbe@live.fr"))
  :maintainers '(("Adrien Becchis" . "adriean.khisbe@live.fr")))
