;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "salesforce-utils" "1.0"
  "Simple utilities for Salesforce."
  '((cl-lib "0.5"))
  :url "https://github.com/grimnebulin/emacs-salesforce"
  :commit "73328baf0fb94ac0d0de645a8f6d42e5ae27f773"
  :revdesc "73328baf0fb9")
