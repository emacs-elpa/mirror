;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orglink" "1.3.2"
  "Use Org Mode links in other modes."
  '((emacs  "29.1")
    (compat "31.1")
    (llama  "1.0")
    (org    "9.8"))
  :url "https://github.com/tarsius/orglink"
  :commit "5205d2ba94cf00ab4645fa8521d75a74d60cfe2e"
  :revdesc "v1.3.2-0-g5205d2ba94cf"
  :keywords '("hypermedia")
  :authors '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orglink@jonas.bernoulli.dev")))
