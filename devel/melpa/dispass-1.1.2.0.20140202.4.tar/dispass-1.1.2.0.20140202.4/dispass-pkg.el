;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dispass" "1.1.2.0.20140202.4"
  "Emacs wrapper for DisPass."
  '((dash "1.0.0"))
  :url "http://projects.ryuslash.org/dispass.el/"
  :commit "b6e8f89040ebaaf0e7609b04bc27a8979f0ae861"
  :revdesc "1.1.2-4-gb6e8f89040eb"
  :keywords '("processes")
  :authors '(("Tom Willemsen" . "tom@ryuslash.org"))
  :maintainers '(("Tom Willemsen" . "tom@ryuslash.org")))
