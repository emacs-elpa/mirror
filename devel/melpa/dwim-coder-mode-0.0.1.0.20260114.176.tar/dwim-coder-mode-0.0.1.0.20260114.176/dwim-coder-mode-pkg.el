;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwim-coder-mode" "0.0.1.0.20260114.176"
  "DWIM keybindings for C, Python, Rust, and more."
  '((emacs "31"))
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html"
  :commit "bc8b308e5fe82951d3843b5913c6d34c11c07098"
  :revdesc "bc8b308e5fe8"
  :keywords '("convenience" "hacks")
  :authors '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers '(("Mohammed Sadiq" . "sadiq@sadiqpk.org")))
