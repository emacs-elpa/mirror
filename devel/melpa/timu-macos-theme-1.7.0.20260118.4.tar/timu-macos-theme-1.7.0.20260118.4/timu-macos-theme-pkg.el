;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-macos-theme" "1.7.0.20260118.4"
  "Color theme inspired by the macOS UI."
  '((emacs "27.1"))
  :url "https://gitlab.com/aimebertrand/timu-macos-theme"
  :commit "5a1e080b831b18b01a012af661653e5ecdf0fad0"
  :revdesc "5a1e080b831b"
  :keywords '("faces" "themes")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
