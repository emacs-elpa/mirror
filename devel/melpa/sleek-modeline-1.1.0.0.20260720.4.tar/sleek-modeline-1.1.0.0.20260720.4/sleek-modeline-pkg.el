;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sleek-modeline" "1.1.0.0.20260720.4"
  "Minimal and elegant modeline."
  '((emacs "29.1"))
  :url "https://github.com/abidanBrito/sleek-modeline"
  :commit "c32ec1d448c5d673f75d0f7f8297dbc7a881d6fc"
  :revdesc "v1.1.0-4-gc32ec1d448c5"
  :keywords '("mode-line" "faces")
  :authors '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com"))
  :maintainers '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com")))
