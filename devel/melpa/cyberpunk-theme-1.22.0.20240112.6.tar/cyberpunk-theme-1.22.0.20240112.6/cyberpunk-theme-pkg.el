;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cyberpunk-theme" "1.22.0.20240112.6"
  "Cyberpunk Color Theme."
  ()
  :url "https://github.com/n3mo/cyberpunk-theme.el"
  :commit "1fd5350ddfc53c30e6eef82af77c62d7c825df3c"
  :revdesc "1fd5350ddfc5"
  :keywords '("color" "theme" "cyberpunk")
  :authors '(("Nicholas M. Van Horn" . "nvanhorn@protonmail.com"))
  :maintainers '(("Nicholas M. Van Horn" . "nvanhorn@protonmail.com")))
