;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kolon-mode" "0.1.0.20140122.8"
  "Syntax highlighting for Text::Xslate's Kolon syntax."
  ()
  :url "https://github.com/samvtran/kolon-mode"
  :commit "5af0955e280ae991862189ebecd3937c5fc8fb9f"
  :revdesc "5af0955e280a"
  :keywords '("xslate" "perl"))
