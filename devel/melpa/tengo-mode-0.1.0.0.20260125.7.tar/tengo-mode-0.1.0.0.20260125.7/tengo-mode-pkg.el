;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tengo-mode" "0.1.0.0.20260125.7"
  "Major mode for the Tengo programming language."
  '((emacs "24.4"))
  :url "https://github.com/CsBigDataHub/tengo-mode"
  :commit "faafdf361abd19024d02e3890684ab61e6637dc8"
  :revdesc "faafdf361abd"
  :keywords '("languages" "tengo")
  :authors '(("Chetan Koneru" . "hadoopchetan@gmail.com"))
  :maintainers '(("Chetan Koneru" . "hadoopchetan@gmail.com")))
