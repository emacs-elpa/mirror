;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ready-player" "0.33.1.0.20260224.12"
  "Open media files in ready-player major mode."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/ready-player"
  :commit "e7737e59f9bc70872935a46da67eef919b9141c4"
  :revdesc "e7737e59f9bc")
