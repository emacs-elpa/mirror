;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "related" "0.0.1.0.20190327.6"
  "Switch back and forth between similarly named buffers."
  '((cl-lib "0.5"))
  :url "https://github.com/julien-montmartin/related"
  :commit "546c7e811b290470288b617f2c27106bd83ccd33"
  :revdesc "546c7e811b29"
  :keywords '("file" "buffer" "switch" "selection" "matching" "convenience"))
