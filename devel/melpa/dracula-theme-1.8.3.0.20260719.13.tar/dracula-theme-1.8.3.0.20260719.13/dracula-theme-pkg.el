;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dracula-theme" "1.8.3.0.20260719.13"
  "Dracula Theme."
  '((emacs "24.3"))
  :url "https://github.com/dracula/emacs"
  :commit "df2be56b03fcbbafcc211013ff93ba50e34a4397"
  :revdesc "v1.8.3-13-gdf2be56b03fc"
  :maintainers '(("tienne Deparis" . "etienne@depar.is")))
