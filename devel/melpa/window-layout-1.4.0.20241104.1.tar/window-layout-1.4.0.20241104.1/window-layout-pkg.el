;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "window-layout" "1.4.0.20241104.1"
  "Window layout manager."
  ()
  :url "https://github.com/kiwanami/emacs-window-layout"
  :commit "277d0a8247adf13707703574cbbc16ddcff7c5fd"
  :revdesc "277d0a8247ad"
  :keywords '("window" "layout")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net"))
  :maintainers '(("SAKURAI Masashi" . "m.sakuraiatmarkkiwanami.net")))
