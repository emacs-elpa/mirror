;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-proc" "0.0.5.0.20241230.5"
  "Helm interface for managing system processes."
  '((helm   "1.6.0")
    (cl-lib "0.5"))
  :url "https://github.com/markus1189/helm-proc"
  :commit "86265218415c7b26cdc3c25de03d063196ba566a"
  :revdesc "0.0.5-5-g86265218415c"
  :keywords '("helm")
  :authors '(("Markus Hauck" . "markus1189@gmail.com"))
  :maintainers '(("Markus Hauck" . "markus1189@gmail.com")))
