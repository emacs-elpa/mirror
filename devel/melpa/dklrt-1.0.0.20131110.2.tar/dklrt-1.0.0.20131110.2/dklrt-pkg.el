;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dklrt" "1.0.0.20131110.2"
  "Ledger Recurring Transactions."
  '((dkmisc      "0.50")
    (ledger-mode "20130908.1357")
    (emacs       "24.1"))
  :url "https://github.com/davidkeegan/dklrt"
  :commit "4eceed270015b41d24a62a8b71bd239224a63063"
  :revdesc "4eceed270015"
  :keywords '("ledger" "ledger-cli" "recurring" "periodic" "automatic")
  :authors '(("David Keegan" . "dksw@eircom.net"))
  :maintainers '(("David Keegan" . "dksw@eircom.net")))
