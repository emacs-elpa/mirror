;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.2.2.0.20261025.6"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "a435a8f41c33e5824fe3aaf65ad01d0bba5f58e1"
  :revdesc "1.2.2-6-ga435a8f41c33"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
