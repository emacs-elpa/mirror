;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "windwow" "0.1.0.20170816.7"
  "Simple workspace management."
  '((dash   "2.11.0")
    (cl-lib "0.6.1")
    (emacs  "24"))
  :url "github.com/vijumathew/windwow"
  :commit "77bad26f651744b68d31b389389147014d250f23"
  :revdesc "77bad26f6517"
  :keywords '("frames")
  :authors '(("Viju Mathew" . "viju.jm@gmail.com"))
  :maintainers '(("Viju Mathew" . "viju.jm@gmail.com")))
