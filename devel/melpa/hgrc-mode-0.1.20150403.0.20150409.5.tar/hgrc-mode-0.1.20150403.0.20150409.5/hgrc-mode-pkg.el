;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hgrc-mode" "0.1.20150403.0.20150409.5"
  "Major mode for editing hgrc files."
  ()
  :url "https://github.com/omajid/hgrc-mode"
  :commit "314e8320b82cc1ce74b1bd372f296252e7a23090"
  :revdesc "314e8320b82c"
  :keywords '("convenience" "vc" "hg")
  :authors '(("Omair Majid" . "omair.majid@gmail.com"))
  :maintainers '(("Omair Majid" . "omair.majid@gmail.com")))
