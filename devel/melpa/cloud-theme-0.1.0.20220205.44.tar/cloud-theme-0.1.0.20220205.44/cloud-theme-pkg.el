;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cloud-theme" "0.1.0.20220205.44"
  "A light colored theme."
  '((emacs "24"))
  :url "https://github.com/vallyscode/cloud-theme"
  :commit "16ef7fbf0a423b29e3c3a0a2d9525afaf265aaed"
  :revdesc "16ef7fbf0a42"
  :keywords '("color" "theme")
  :authors '(("Valerii Lysenko" . "vallyscode@gmail.com"))
  :maintainers '(("Valerii Lysenko" . "vallyscode@gmail.com")))
