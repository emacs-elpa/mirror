;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-grepint" "1.6.1"
  "Generic helm interface to grep."
  '((helm  "2.9.7")
    (emacs "24.4"))
  :url "https://github.com/kopoli/helm-grepint"
  :commit "9aec98428823b749eb14d2c8512b46b59ca9f8ca"
  :revdesc "1.6.1-0-g9aec98428823"
  :keywords '("grep" "grepping" "searching" "helm" "tools" "convenience")
  :authors '(("Kalle Kankare" . "kalle.kankare@iki.fi"))
  :maintainers '(("Kalle Kankare" . "kalle.kankare@iki.fi")))
