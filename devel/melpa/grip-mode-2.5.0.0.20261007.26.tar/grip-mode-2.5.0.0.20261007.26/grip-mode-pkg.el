;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grip-mode" "2.5.0.0.20261007.26"
  "Instant GitHub-flavored Markdown/Org preview using grip."
  '((emacs "24.4"))
  :url "https://github.com/seagle0128/grip-mode"
  :commit "f249df1f59866f55620afbf0d7dfb07546ac9a32"
  :revdesc "f249df1f5986"
  :keywords '("convenience" "markdown" "preview")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
