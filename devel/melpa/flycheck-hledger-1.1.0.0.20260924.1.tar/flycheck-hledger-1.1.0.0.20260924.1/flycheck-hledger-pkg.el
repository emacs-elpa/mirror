;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-hledger" "1.1.0.0.20260924.1"
  "Flycheck module to check hledger journals."
  '((emacs    "27.1")
    (flycheck "31"))
  :url "https://github.com/DamienCassou/flycheck-hledger/"
  :commit "bae0665f836828e0ced0550e2acf1744d0727561"
  :revdesc "v1.1.0-1-gbae0665f8368"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
