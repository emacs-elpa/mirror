;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-macos-theme" "1.7.0.20261105.9"
  "Color theme inspired by the macOS UI."
  '((emacs "27.1"))
  :url "https://gitlab.com/aimebertrand/timu-macos-theme"
  :commit "dc3adfd413c8178f98e89ee9cca0096456f126b4"
  :revdesc "dc3adfd413c8"
  :keywords '("faces" "themes")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
