;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sourcepawn-mode" "0.2.0.20260318.4"
  "SourcePawn major mode."
  ()
  :url "https://rakeri.net/teamfortress2/sourcepawn-mode"
  :commit "1278cfe7e411385755b796ac7245ace7d0deb26d"
  :revdesc "v0.2-4-g1278cfe7e411"
  :authors '(("Aaron Griffith" . "aargri@gmail.com"))
  :maintainers '(("Aaron Griffith" . "aargri@gmail.com")))
