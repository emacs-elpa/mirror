;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "2.1.0"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "ab458ae007b2886c52ba8e5b4b9421498a82079a"
  :revdesc "v2.1.0-0-gab458ae007b2"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
