;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-notes" "0.4.2.0.20221206.5"
  "Keep handy notes of read Gnus articles with helm and org."
  '((emacs "27.1")
    (bbdb  "3.1")
    (helm  "3.1")
    (hydra "0.13.0")
    (org   "8.3")
    (s     "0.0")
    (lv    "0.0")
    (async "1.9.1"))
  :url "https://github.com/deusmax/gnus-notes"
  :commit "9996b382c5c7b4f944a716baac69b556ef181462"
  :revdesc "v0.4.2-5-g9996b382c5c7"
  :keywords '("convenience" "mail" "bbdb" "gnus" "helm" "org" "hydra")
  :authors '(("Deus Max" . "deusmax@gmx.com"))
  :maintainers '(("Deus Max" . "deusmax@gmx.com")))
