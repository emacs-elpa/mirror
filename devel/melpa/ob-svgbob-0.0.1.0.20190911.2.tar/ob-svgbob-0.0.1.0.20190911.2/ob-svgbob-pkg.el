;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-svgbob" "0.0.1.0.20190911.2"
  "Babel Functions for svgbob."
  '((emacs "24"))
  :url "https://github.com/mgxm/ob-svgbob"
  :commit "5747f96fb4fdb8711546b3313df9412177eb3c1a"
  :revdesc "0.0.1-2-g5747f96fb4fd"
  :keywords '("tools" "files")
  :authors '(("Marcio Giaxa" . "i@mgxm.me"))
  :maintainers '(("Marcio Giaxa" . "i@mgxm.me")))
