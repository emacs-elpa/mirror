;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cursor-flash" "1.0.0.20210722.2"
  "Highlight the cursor on buffer/window-switch."
  '((emacs "24.3"))
  :url "https://github.com/Boruch-Baum/emacs-cursor-flash"
  :commit "6bb54a1e2e1bf9df80926718b1b8b9ee49080484"
  :revdesc "6bb54a1e2e1b"
  :keywords '("convenience" "faces" "maint"))
