;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "0.9.0.0.20261009.88"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "4f70ef9b4f15d38d8a8e6f81ec030c57d4ebc3d3"
  :revdesc "4f70ef9b4f15"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
