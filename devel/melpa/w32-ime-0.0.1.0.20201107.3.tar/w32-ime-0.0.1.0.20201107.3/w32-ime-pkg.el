;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "w32-ime" "0.0.1.0.20201107.3"
  "Windows IME UI/UX controler."
  '((emacs "24.4"))
  :url "https://github.com/trueroad/w32-ime.el"
  :commit "9c62273dce0ba685a591577885b1e216ba832ec1"
  :revdesc "v0.0.1-3-g9c62273dce0b"
  :authors '(("Masamichi Hosoda" . "trueroad@trueroad.jp")
             ("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Masamichi Hosoda" . "trueroad@trueroad.jp")))
