;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prog-fill" "1.0.0"
  "Smartly format lines to use vertical space."
  '((emacs  "25.1")
    (cl-lib "0.6.1"))
  :url "https://github.com/ahungry/prog-fill"
  :commit "3fbf7da6dd826e95c9077d659566ee29814a31d8"
  :revdesc "3fbf7da6dd82"
  :keywords '("ahungry" "convenience" "c" "formatting" "editing")
  :authors '(("Matthew Carter" . "m@ahungry.com"))
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
