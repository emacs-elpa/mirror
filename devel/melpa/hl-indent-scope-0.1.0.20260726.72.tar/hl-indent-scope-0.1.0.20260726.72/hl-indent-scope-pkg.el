;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-indent-scope" "0.1.0.20260726.72"
  "Highlight indentation by scope."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope"
  :commit "5e0e0d293231169b27c96d13cf2ccdf3b4d01353"
  :revdesc "5e0e0d293231"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
