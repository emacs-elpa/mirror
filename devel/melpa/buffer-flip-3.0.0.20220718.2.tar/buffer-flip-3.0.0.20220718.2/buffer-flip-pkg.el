;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-flip" "3.0.0.20220718.2"
  "Cycle through buffers like Alt-Tab in Windows."
  '((cl-lib "0.5"))
  :url "https://github.com/killdash9/buffer-flip.el"
  :commit "dda0cbcd202cdadf322942f9637a11ed92525756"
  :revdesc "dda0cbcd202c"
  :keywords '("convenience")
  :authors '(("Russell Black" . "(killdash9@github)"))
  :maintainers '(("Russell Black" . "(killdash9@github)")))
