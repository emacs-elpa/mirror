;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miniedit" "2.0"
  "Enhanced editing for minibuffer fields."
  ()
  :url "https://github.com/emacsorphanage/miniedit"
  :commit "e12bf659c3eb92dd8a4cb77642dc0865c54667a3"
  :revdesc "2.0-0-ge12bf659c3eb")
