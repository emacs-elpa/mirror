;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab" "3.9.0"
  "An interface for GitLab."
  '((emacs       "27.1")
    (request     "0.3.2")
    (s           "1.10.0")
    (f           "0.20.0")
    (compat      "29.1.4.4")
    (promise     "1.1")
    (async-await "1.1"))
  :url "https://github.com/isamert/lab.el"
  :commit "f072f8c0d674a9f3864e97e8fe6cae3766c98139"
  :revdesc "v3.9.0-0-gf072f8c0d674"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
