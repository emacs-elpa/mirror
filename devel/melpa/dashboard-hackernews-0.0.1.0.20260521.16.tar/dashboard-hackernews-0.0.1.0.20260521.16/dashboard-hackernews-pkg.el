;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dashboard-hackernews" "0.0.1.0.20260521.16"
  "Display Hacker News on dashboard."
  '((emacs     "24")
    (dashboard "1.2.5")
    (request   "0.3.0"))
  :url "https://github.com/hyakt/emacs-dashboard-hackernews"
  :commit "ecc8c1eeca10408ac1fab2ad0e80fccf9c6bc0b2"
  :revdesc "ecc8c1eeca10"
  :authors '(("Hayato KAJIYAMA" . "kaji1216@gmail.com"))
  :maintainers '(("Hayato KAJIYAMA" . "kaji1216@gmail.com")))
