;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "google-maps" "1.0.0.0.20181121.10"
  "Access Google Maps from Emacs."
  '((emacs "24.3"))
  :url "https://julien.danjou.info/projects/emacs-packages#google-maps"
  :commit "2eb16ff609f5a9f8d02c15238a111fbb7db6c146"
  :revdesc "1.0.0-10-g2eb16ff609f5"
  :keywords '("comm")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")))
