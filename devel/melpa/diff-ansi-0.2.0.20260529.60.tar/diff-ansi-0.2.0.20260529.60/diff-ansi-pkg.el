;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-ansi" "0.2.0.20260529.60"
  "Display diffs using alternative diffing tools."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi"
  :commit "1019b341897a2abc944a6bf9914fab344a37e5d5"
  :revdesc "1019b341897a"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
