;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mutant" "1.0.0.20160124.11"
  "An interface for the Mutant testing tool."
  '((emacs "24.4")
    (dash  "2.1.0"))
  :url "https://github.com/p-lambert/mutant.el"
  :commit "aff50603a70a110f4ecd7142963ef719e8c11c06"
  :revdesc "aff50603a70a"
  :keywords '("mutant" "testing"))
