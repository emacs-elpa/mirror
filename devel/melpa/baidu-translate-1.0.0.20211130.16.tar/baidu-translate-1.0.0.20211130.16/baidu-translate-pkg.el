;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "baidu-translate" "1.0.0.20211130.16"
  "A plugin using baidu-translate-api."
  '((unicode-escape "1.1"))
  :url "https://github.com/liShiZhensPi/baidu-translate"
  :commit "16101d5e6ce19bbcc8badf4422a95db457160999"
  :revdesc "16101d5e6ce1"
  :keywords '("docs")
  :authors '((nil . "LiShizhengsu4017@gmail.com"))
  :maintainers '((nil . "LiShizhengsu4017@gmail.com")))
