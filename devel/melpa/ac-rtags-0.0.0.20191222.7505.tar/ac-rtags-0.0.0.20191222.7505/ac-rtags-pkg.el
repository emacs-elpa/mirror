;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-rtags" "0.0.0.20191222.7505"
  "Auto-complete back-end for RTags."
  '((auto-complete "1.4.0")
    (rtags         "2.10"))
  :url "https://github.com/Andersbakken/rtags"
  :commit "595055b5316a7c92ba1d638f324f98842a0f41a5"
  :revdesc "595055b5316a"
  :authors '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
             ("Anders Bakken" . "agbakken@gmail.com"))
  :maintainers '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
                 ("Anders Bakken" . "agbakken@gmail.com")))
