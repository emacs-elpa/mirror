;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-hn" "1.0.0.0.20250716.31"
  "Hacker News search with Consult."
  '((emacs     "29.4")
    (consult   "2.0")
    (ts        "0.3")
    (transient "0.9"))
  :url "https://github.com/agzam/consult-hn"
  :commit "7e02d69296b880dd0cfbdaed45c0365d6daca647"
  :revdesc "7e02d69296b8"
  :keywords '("search" "extensions")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
