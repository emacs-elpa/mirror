;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-mode" "4.4.1"
  "Major-mode for editing CMake sources."
  '((emacs "24.1"))
  :commit "d1cffecacdfd7d6fb0cda0d1e0bf1ba30b967019"
  :revdesc "v4.4.1-0-gd1cffecacdfd")
