;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit-forge" "1.1.5"
  "Org links to Forge issue buffers."
  '((emacs    "29.1")
    (compat   "31.1")
    (cond-let "1.1")
    (forge    "0.6")
    (magit    "4.7")
    (org      "9.8")
    (orgit    "2.2"))
  :url "https://github.com/magit/orgit-forge"
  :commit "8b5fbe9bb7dee123054bf9aa3095607e56e946cd"
  :revdesc "v1.1.5-0-g8b5fbe9bb7de"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev")))
