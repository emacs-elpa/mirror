;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20260907.35"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "0b0419427ecfce373a56e11272b1d2703e445993"
  :revdesc "0b0419427ecf")
