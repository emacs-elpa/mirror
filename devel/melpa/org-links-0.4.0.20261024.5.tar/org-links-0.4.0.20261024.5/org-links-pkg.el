;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "0.4.0.20261024.5"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "89409893936d9126d840172d18da49fbbb62b9d1"
  :revdesc "89409893936d"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
