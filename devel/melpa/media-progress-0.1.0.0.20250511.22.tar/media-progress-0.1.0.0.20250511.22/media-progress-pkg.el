;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "media-progress" "0.1.0.0.20250511.22"
  "Display position where media player stopped."
  '((emacs "28.1"))
  :url "https://github.com/jumper047/media-progress"
  :commit "7055f5830690c9b1330816f899ee05791f35b406"
  :revdesc "7055f5830690"
  :keywords '("files" "convenience")
  :authors '(("Dmitriy Pshonko" . "http://github.com/jumper047"))
  :maintainers '(("Dmitriy Pshonko" . "http://github.com/jumper047")))
