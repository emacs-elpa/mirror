;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "define-scratch" "0.1.0.0.20221220.7"
  "Define new commands to make scratch buffers."
  '((emacs "24.3"))
  :url "https://github.com/lassik/emacs-define-scratch"
  :commit "26cf11f801c2b5df0fbd56d2c4f7ac41b3ccd1c6"
  :revdesc "26cf11f801c2"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
