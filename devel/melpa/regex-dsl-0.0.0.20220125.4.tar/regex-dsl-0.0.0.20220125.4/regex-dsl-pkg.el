;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "regex-dsl" "0.0.0.20220125.4"
  "Lisp syntax for regexps."
  ()
  :url "https://github.com/alk/elisp-regex-dsl"
  :commit "8802555ecdab8b50bb64181798497c10cdb5034b"
  :revdesc "8802555ecdab"
  :authors '(("Aliaksey Kandratsenka" . "alk@tut.by"))
  :maintainers '(("Aliaksey Kandratsenka" . "alk@tut.by")))
