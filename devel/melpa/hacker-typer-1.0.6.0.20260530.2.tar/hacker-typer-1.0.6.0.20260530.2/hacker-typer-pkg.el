;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hacker-typer" "1.0.6.0.20260530.2"
  "Pretend to write code like a pro."
  '((emacs "24"))
  :url "https://sr.ht/~dieggsy/emacs-hacker-typer"
  :commit "3f15d0cfe7636d5b32cbc882f23d5a7b61a86ae7"
  :revdesc "3f15d0cfe763"
  :keywords '("hacker" "typer" "multimedia" "games")
  :authors '(("Diego A. Mundo" . "diegoamundo@gmail.com"))
  :maintainers '(("Diego A. Mundo" . "diegoamundo@gmail.com")))
