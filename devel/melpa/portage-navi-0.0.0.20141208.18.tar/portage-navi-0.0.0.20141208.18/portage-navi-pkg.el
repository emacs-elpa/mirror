;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "portage-navi" "0.0.0.20141208.18"
  "Portage viewer."
  '((concurrent "0.3.1")
    (ctable     "0.1.2"))
  :url "https://github.com/kiwanami/emacs-portage-navi"
  :commit "8016c3e99fe6cef101d479a3d69185796b22ca2f"
  :revdesc "8016c3e99fe6"
  :keywords '("tools" "gentoo")
  :authors '((nil . "m.sakuraiatkiwanami.net"))
  :maintainers '((nil . "m.sakuraiatkiwanami.net")))
