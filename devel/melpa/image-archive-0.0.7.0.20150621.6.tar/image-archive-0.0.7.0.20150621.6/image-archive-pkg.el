;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "image-archive" "0.0.7.0.20150621.6"
  "Image thumbnails in archive file with non-blocking."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/mhayashi1120/Emacs-image-archive"
  :commit "4cf0edabfd6a4da2ffb920ff1e5009a002fc1e53"
  :revdesc "4cf0edabfd6a"
  :keywords '("multimedia")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
