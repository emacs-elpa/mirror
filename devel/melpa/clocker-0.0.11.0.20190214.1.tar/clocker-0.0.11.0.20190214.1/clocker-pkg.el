;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clocker" "0.0.11.0.20190214.1"
  "Note taker and clock-in enforcer."
  '((projectile "0.11.0")
    (dash       "2.10")
    (spaceline  "2.0.1"))
  :url "https://github.com/roman/clocker.el"
  :commit "c4d76968a49287ce3bac0832bb5d5d076054c96f"
  :revdesc "c4d76968a492"
  :keywords '("org")
  :authors '(("Roman Gonzalez" . "romanandreg@gmail.com"))
  :maintainers '(("Roman Gonzalez" . "romanandreg@gmail.com")))
