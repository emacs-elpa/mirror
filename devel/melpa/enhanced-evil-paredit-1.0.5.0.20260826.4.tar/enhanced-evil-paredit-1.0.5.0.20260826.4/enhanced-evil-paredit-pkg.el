;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "1.0.5.0.20260826.4"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "e6149d233313b299f8a05e13b6082fbd35a2c593"
  :revdesc "1.0.5-4-ge6149d233313"
  :keywords '("convenience" "lisp"))
