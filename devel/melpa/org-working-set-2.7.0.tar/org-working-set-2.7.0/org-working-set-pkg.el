;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-working-set" "2.7.0"
  "Manage and visit a small and changing set of org-nodes that you work on."
  '((org   "9.3")
    (dash  "2.12")
    (s     "1.12")
    (emacs "28.0"))
  :url "https://github.com/marcIhm/org-working-set"
  :commit "ab14880f7875381ba574183af9e4eec0b5975b07"
  :revdesc "2.7.0-0-gab14880f7875"
  :authors '(("Marc Ihm" . "marc@ihm.name"))
  :maintainers '(("Marc Ihm" . "marc@ihm.name")))
