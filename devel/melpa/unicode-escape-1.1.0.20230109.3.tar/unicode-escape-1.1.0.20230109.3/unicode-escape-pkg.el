;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-escape" "1.1.0.20230109.3"
  "Escape/Unescape unicode notations."
  '((emacs "24")
    (names "20151201.0")
    (dash  "2.12.1"))
  :url "https://github.com/kosh04/unicode-escape.el"
  :commit "afbb09c774571eefd4e639fc6163280476484363"
  :revdesc "1.1-3-gafbb09c77457"
  :keywords '("i18n" "unicode")
  :authors '(("KOBAYASHI Shigeru" . "shigeru.kb@gmail.com"))
  :maintainers '(("KOBAYASHI Shigeru" . "shigeru.kb@gmail.com")))
