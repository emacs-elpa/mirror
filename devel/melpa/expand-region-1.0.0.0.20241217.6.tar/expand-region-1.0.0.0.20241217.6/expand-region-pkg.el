;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "expand-region" "1.0.0.0.20241217.6"
  "Increase selected region by semantic units."
  '((emacs "24.4"))
  :url "https://github.com/magnars/expand-region.el"
  :commit "351279272330cae6cecea941b0033a8dd8bcc4e8"
  :revdesc "1.0.0-6-g351279272330"
  :keywords '("marking" "region")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
