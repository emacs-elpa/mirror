;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-markdown" "0.25.1"
  "Preview Markdown LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.25.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "527fcac9afd65c4c1bd9692f16250b31fdce7bc0"
  :revdesc "v0.25.1-0-g527fcac9afd6"
  :keywords '("tex" "markdown" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
