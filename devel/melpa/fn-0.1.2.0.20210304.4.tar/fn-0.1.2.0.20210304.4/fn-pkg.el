;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fn" "0.1.2.0.20210304.4"
  "Concise anonymous functions for Emacs Lisp."
  '((emacs  "24")
    (cl-lib "0.5")
    (dash   "2.18.0"))
  :url "https://github.com/troyp/fn.el"
  :commit "98e3fe1b4785e162d9aca978a2db106baa79260f"
  :revdesc "0.1.2-4-g98e3fe1b4785"
  :keywords '("functional"))
