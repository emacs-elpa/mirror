;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "38.3.0.20260805.110"
  "On-the-fly syntax checking."
  '((emacs "28.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "3088cd5464c259f6e8e55cff0ba4cfe6521744fb"
  :revdesc "3088cd5464c2"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
