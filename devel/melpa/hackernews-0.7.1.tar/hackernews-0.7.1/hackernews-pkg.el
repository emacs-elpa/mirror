;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hackernews" "0.7.1"
  "Hacker News Client for Emacs."
  ()
  :url "https://github.com/clarete/hackernews.el"
  :commit "1d3ba5faf47a3907e270ed5aa4099f73dadfdf6c"
  :revdesc "v0.7.1-0-g1d3ba5faf47a"
  :keywords '("comm" "hypermedia" "news")
  :authors '(("Lincoln de Sousa" . "lincoln@clarete.li"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
