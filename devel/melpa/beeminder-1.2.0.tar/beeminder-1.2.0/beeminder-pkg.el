;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "beeminder" "1.2.0"
  "Emacs interface for Beeminder."
  '((emacs "24.3")
    (seq   "2.16")
    (org   "7"))
  :url "http://www.philnewton.net/code/beeminder-el/"
  :commit "161d9c94c594614a01cb08219693d9e000af4f69"
  :revdesc "161d9c94c594"
  :keywords '("tools" "beeminder")
  :authors '(("Phil Newton" . "phil@sodaware.net"))
  :maintainers '(("Phil Newton" . "phil@sodaware.net")))
