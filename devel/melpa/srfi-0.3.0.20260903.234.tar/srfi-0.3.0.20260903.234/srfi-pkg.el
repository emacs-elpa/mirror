;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "0.3.0.20260903.234"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "d34e493510313fb4811ffce373a9a2c9e0bb0923"
  :revdesc "0.3-234-gd34e49351031"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
