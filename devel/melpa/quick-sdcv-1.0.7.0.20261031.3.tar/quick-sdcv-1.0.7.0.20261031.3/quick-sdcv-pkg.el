;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "1.0.7.0.20261031.3"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "9e3bab377bd1f23395405cb7719e1454ca209eed"
  :revdesc "1.0.7-3-g9e3bab377bd1"
  :keywords '("tools" "convenience" "text"))
