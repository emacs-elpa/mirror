;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prog-face-refine" "0.1.0.20260726.7"
  "Refine faces for programming modes."
  '((emacs "28.0"))
  :url "https://codeberg.org/ideasman42/emacs-prog-face-refine"
  :commit "55a142ab1698f5457567666a56cc96ee6bdc4d74"
  :revdesc "55a142ab1698"
  :keywords '("faces" "convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
