;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-aws" "1.0.0.0.20180514.15"
  "Manage AWS EC2 server instances directly from Emacs."
  '((helm   "1.5.3")
    (cl-lib "0.5")
    (s      "1.9.0"))
  :url "https://github.com/istib/helm-aws"
  :commit "b36c744b3f00f458635a91d1f5158fccbb5baef6"
  :revdesc "1.0.0-15-gb36c744b3f00")
