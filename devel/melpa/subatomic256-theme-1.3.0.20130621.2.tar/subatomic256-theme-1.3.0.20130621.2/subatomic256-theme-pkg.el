;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "subatomic256-theme" "1.3.0.20130621.2"
  "Fork of subatomic-theme for terminals."
  ()
  :url "https://github.com/cryon/subatomic256"
  :commit "326177d6f99cd2b1d30df695e67ee3bc441cd96f"
  :revdesc "326177d6f99c"
  :authors '(("John Olsson" . "john@cryon.se"))
  :maintainers '(("John Olsson" . "john@cryon.se")))
