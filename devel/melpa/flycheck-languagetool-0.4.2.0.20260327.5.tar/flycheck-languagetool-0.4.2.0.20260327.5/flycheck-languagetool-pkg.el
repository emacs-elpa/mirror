;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-languagetool" "0.4.2.0.20260327.5"
  "Flycheck support for LanguageTool."
  '((emacs    "27.1")
    (flycheck "0.14"))
  :url "https://github.com/emacs-languagetool/flycheck-languagetool"
  :commit "a53b3e509c63e82680843978694a1099ee3591eb"
  :revdesc "a53b3e509c63"
  :keywords '("convenience" "grammar" "check")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com")
             ("Peter Oliver" . "git@mavit.org.uk"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Peter Oliver" . "git@mavit.org.uk")))
