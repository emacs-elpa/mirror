;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-snippets" "1.0.1.0.20241226.22"
  "Yasnippets for clojure."
  '((yasnippet "0.10.0")
    (cl-lib    "0.5"))
  :url "https://github.com/mpenet/clojure-snippets"
  :commit "1e96ed7215e9da7c003a370eb1f91ed5475e6b0d"
  :revdesc "1e96ed7215e9"
  :keywords '("snippets")
  :authors '(("Max Penet" . "m@qbits.cc"))
  :maintainers '(("Max Penet" . "m@qbits.cc")))
