;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-indentation" "0.1.0.20230625.20"
  "Simplify writing indentation functions, alternative to SMIE."
  '((emacs "24.3")
    (dash  "2.18.0")
    (s     "1.12.0"))
  :url "https://github.com/semenInRussia/simple-indentation.el"
  :commit "b5f97fc14b3f494cfe009938cf5ee9016a83d30e"
  :revdesc "b5f97fc14b3f"
  :authors '(("Semen Khramtsov" . "hrams205@gmail.com"))
  :maintainers '(("Semen Khramtsov" . "hrams205@gmail.com")))
