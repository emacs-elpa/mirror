;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-utils" "0.1.0.0.20140512.10"
  "Buffer-manipulation utility functions."
  ()
  :url "https://github.com/rolandwalker/buffer-utils"
  :commit "32e1f23817b9c6caedb53e5359baad29e99eaa2b"
  :revdesc "v0.1.0-10-g32e1f23817b9"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
