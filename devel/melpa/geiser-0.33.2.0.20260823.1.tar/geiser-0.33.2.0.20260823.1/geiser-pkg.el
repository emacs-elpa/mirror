;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser" "0.33.2.0.20260823.1"
  "GNU Emacs and Scheme talk to each other."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://gitlab.com/emacs-geiser/"
  :commit "584f78b103037e8bc6f4b22a6fae23e09f619d6d"
  :revdesc "584f78b10303"
  :keywords '("languages" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
