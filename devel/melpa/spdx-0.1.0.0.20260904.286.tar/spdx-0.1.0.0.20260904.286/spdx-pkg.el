;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "0.1.0.0.20260904.286"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "d5aab09bfc8db29ef75b1028aa6dfc1344ff4e2d"
  :revdesc "d5aab09bfc8d"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
