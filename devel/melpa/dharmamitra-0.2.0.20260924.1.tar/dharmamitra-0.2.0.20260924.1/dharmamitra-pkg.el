;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dharmamitra" "0.2.0.20260924.1"
  "Sanskrit/Pāli/Tibetan/Chinese analysis via dharmamitra.org."
  '((emacs "26.1"))
  :url "https://github.com/dharmamitra/dharmamitra-emacs"
  :commit "170d91c99a59acb933660b1c0c45cf8e07195f80"
  :revdesc "v0.2-1-g170d91c99a59"
  :keywords '("languages" "tools"))
