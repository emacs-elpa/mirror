;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "1.5.0.20260907.307"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "dcba7b0506f36ba0edeb358a3cf63ca7951f3434"
  :revdesc "dcba7b0506f3"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
