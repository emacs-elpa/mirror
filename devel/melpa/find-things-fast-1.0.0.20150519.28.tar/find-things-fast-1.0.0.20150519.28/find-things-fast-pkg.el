;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "find-things-fast" "1.0.0.20150519.28"
  "Find things fast, leveraging the power of git."
  ()
  :url "https://github.com/eglaysher/find-things-fast"
  :commit "281dcb5a2e2db1013246dcac5111808352a8ea95"
  :revdesc "281dcb5a2e2d"
  :keywords '("project" "convenience"))
