;;; latex-to-svg-for-org.el --- Preview Org LaTeX math as SVG -*- lexical-binding: t -*-

;; Copyright (C) 2026 Andrea Alberti

;; Author: Andrea Alberti <a.alberti82@gmail.com>
;; Maintainer: Andrea Alberti <a.alberti82@gmail.com>
;; Assisted-by: Claude:claude-opus-4-8
;; URL: https://github.com/alberti42/latex-to-svg
;; Package-Version: 0.23.0
;; Package-Revision: v0.23.0-0-g5368c0dad8db
;; Package-Requires: ((emacs "29.1") (latex-to-svg-frontend "0.23.0"))
;; Keywords: tex, org, math, images

;; This package is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 3, or (at your option)
;; any later version.

;; This package is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with GNU Emacs.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; Org adaptor for `latex-to-svg-frontend': a thin layer that tells the shared
;; core which Org regions are code / verbatim / comment (so math inside them is
;; not previewed) and how to unfold a jump target (`org-fold-show-context'),
;; then enables the core.  All the actual work lives in
;; `latex-to-svg-frontend'.
;;
;; Detection uses the core's universal scanner (not `org-element'); the Org
;; block, comment, table formula and fixed-width regions below are excluded
;; from it, as are inline `~code~' /
;; `=verbatim=' spans, so `=\(=' stays literal text.  Disable a delimiter
;; family with the core toggles if a markup character still causes false
;; positives.
;;
;; Usage:
;;
;;   (add-hook 'org-mode-hook #'latex-to-svg-for-org-mode)
;;
;; Per-buffer settings are the core's buffer-local variables; set them in the
;; same hook, e.g. `(setq-local latex-to-svg-frontend-rescale-display 1.25)'.

;;; Code:

(require 'latex-to-svg-frontend)

(defvar org-verbatim-re)
(defvar org-emphasis-alist)

(defconst latex-to-svg-for-org--verbatim-fallback-re
  (concat "\\([-[:space:]('\"{]\\|^\\)"                   ; 1: pre char
          "\\(\\([=~]\\)"                                ; 2: whole, 3: marker
          "\\([^[:space:]]\\|[^[:space:]].*?[^[:space:]]\\)" ; 4: body
          "\\3\\)"
          "\\([-[:space:].,:!?;'\")}]\\|$\\)")            ; 5: post char
  "Fallback for `org-verbatim-re', same group layout (2 = the whole span).
Used when Org has not yet computed its emphasis regexps.")

(defun latex-to-svg-for-org--inline-verbatim-regions (beg end)
  "Return inline `~code~' / `=verbatim=' regions between BEG and END.
Uses Org's own `org-verbatim-re' when available so what we skip is exactly
what Org fontifies as verbatim; group 2 is the span including its markers."
  (let ((re (if (and (boundp 'org-verbatim-re) (stringp org-verbatim-re))
                org-verbatim-re
              latex-to-svg-for-org--verbatim-fallback-re))
        (regions '()))
    (save-excursion
      ;; Start one char early so the pre-char alternative can match the
      ;; character just before BEG (BEG itself is usually a block start).
      (goto-char (max (point-min) (1- beg)))
      (while (re-search-forward re end t)
        (push (cons (match-beginning 2) (match-end 2)) regions)
        (goto-char (match-end 2))))
    regions))

(defun latex-to-svg-for-org--exclusions (beg end)
  "Return Org code / verbatim / comment regions in BEG..END to skip.
Covers `#+begin_src' / `example' / `export' / `comment' blocks, whole
comment lines (`# …'), table formula lines (`#+TBLFM:'), fixed-width
lines (`: …'), and inline `~code~' / `=verbatim=' spans.  This is
the buffer's `latex-to-svg-frontend-exclude-function'."
  (let ((regions '())
        (case-fold-search t))
    (save-excursion
      (save-restriction
        (widen)
        ;; #+begin_… … #+end_… blocks (src / example / export / comment).
        (goto-char (point-min))
        ;; The closing `#+end_…' search is deliberately unbounded (a block
        ;; straddling END must be excluded whole), so it can leave point past
        ;; END -- guard the loop, or the next bounded search signals
        ;; "Invalid search bound (wrong side of point)".
        (while (and (<= (point) end)
                    (re-search-forward
                     "^[ \t]*#\\+begin_\\(src\\|example\\|export\\|comment\\)\\_>"
                     end t))
          (let ((b (match-beginning 0))
                (kind (match-string 1)))
            (when (re-search-forward
                   (format "^[ \t]*#\\+end_%s\\_>.*$" (regexp-quote kind)) nil t)
              (push (cons b (match-end 0)) regions))))
        ;; Whole comment lines: `# …' or a bare `#'.
        (goto-char (point-min))
        (while (re-search-forward "^[ \t]*#\\(?: .*\\)?$" end t)
          (push (cons (match-beginning 0) (match-end 0)) regions))
        ;; Table formulas, which refer to columns as `$1', `$2' ...
        (goto-char (point-min))
        (while (re-search-forward "^[ \t]*#\\+tblfm:.*$" end t)
          (push (cons (match-beginning 0) (match-end 0)) regions))
        ;; Fixed-width lines (literal examples): `: …' or a bare `:'.
        (goto-char (point-min))
        (while (re-search-forward "^[ \t]*:\\(?: .*\\)?$" end t)
          (push (cons (match-beginning 0) (match-end 0)) regions))
        ;; Inline `~code~' / `=verbatim='.
        (setq regions
              (nconc (latex-to-svg-for-org--inline-verbatim-regions beg end)
                     regions))))
    regions))

(defun latex-to-svg-for-org-preview-disabled ()
  "Say that Org's LaTeX preview is off while `latex-to-svg-for-org-mode' is on.
The mode remaps `org-latex-preview' to this command, whatever key runs
it: Org's preview would draw its own images over this package's, with no
numbering, no reveal on cursor and a separate cache.  To use Org's
preview, turn `latex-to-svg-for-org-mode' off."
  (interactive)
  (message "Org's LaTeX preview is off while `latex-to-svg-for-org-mode' \
is on; turn that mode off to use it"))

(defvar latex-to-svg-for-org-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map [remap org-latex-preview]
                #'latex-to-svg-for-org-preview-disabled)
    map)
  "Keymap for `latex-to-svg-for-org-mode'.
It only remaps `org-latex-preview' (see
`latex-to-svg-for-org-preview-disabled'), and is active only in Org
buffers where the mode is on.")

(defvar org-startup-with-latex-preview)

(defconst latex-to-svg-for-org--startup-url
  "https://github.com/alberti42/latex-to-svg/blob/main/docs/latex-to-svg-for-org.md#opening-a-file-with-startup-latexpreview-fails"
  "The Troubleshooting section about Org's preview as a file opens.")

(defconst latex-to-svg-for-org--preview-mode-url
  "https://github.com/alberti42/latex-to-svg/blob/main/docs/latex-to-svg-for-org.md#org-latex-preview-mode-previews-the-math-too"
  "The Troubleshooting section about `org-latex-preview-mode'.")

(defun latex-to-svg-for-org--warn-org-preview ()
  "Warn when Org's own LaTeX preview ran when this buffer opened.
Org runs its preview while `org-mode' sets up the buffer, before
`org-mode-hook' turns `latex-to-svg-for-org-mode' on, when
`org-startup-with-latex-preview' is non-nil: set buffer-locally by
the file's `#+startup: latexpreview', or globally in the user's
config.  Its images cover the same math as this package's.  The
mode does not stop Org's preview; the warning says which setting
to change, and links to the adaptor's Troubleshooting section."
  (when-let* ((message
               (cond
                ((local-variable-p 'org-startup-with-latex-preview)
                 (when org-startup-with-latex-preview
                   "Org's own LaTeX preview typeset every equation in this \
file as it opened, because the file has `#+startup: latexpreview'.  Its \
images cover this package's previews.  To stop it, delete `latexpreview' \
from the `#+startup' line, or have Org ignore that word in every file: the \
section linked below gives the lines for your config.  Then open the file \
again, to remove Org's images."))
                ((bound-and-true-p org-startup-with-latex-preview)
                 "Org's own LaTeX preview typeset every equation in this \
file as it opened, because `org-startup-with-latex-preview' is t in your \
config.  Its images cover this package's previews.  To stop it, set that \
option to nil, then open the file again, to remove Org's images."))))
    (latex-to-svg-frontend--warn-other-preview
     'latex-to-svg-for-org message latex-to-svg-for-org--startup-url)))

(defvar latex-to-svg-for-org-mode)

(defun latex-to-svg-for-org--warn-org-latex-preview-mode ()
  "Warn when `org-latex-preview-mode' and this mode are both on.
Org's mode previews the math as it is typed, and its images cover
the same math as this package's.  The mode runs this when it turns
on, and from `org-latex-preview-mode-hook' when Org's mode turns on
after it, so it warns each time one of the two turns on while the
other is on (see `latex-to-svg-frontend--warn-other-modes').  The
mode does not turn Org's mode off."
  (when latex-to-svg-for-org-mode
    (latex-to-svg-frontend--warn-other-modes
     'latex-to-svg-for-org '(org-latex-preview-mode)
     latex-to-svg-for-org--preview-mode-url)))

(defun latex-to-svg-for-org--emphasis-faces ()
  "Return the faces of Org's emphasis markers, from `org-emphasis-alist'.
The value of `latex-to-svg-frontend-emphasis-faces' in Org buffers:
`bold', `italic', `underline', `org-verbatim', `org-code' and
`(:strike-through t)' by default, and the faces a user put there."
  (delete-dups (mapcar #'cadr (bound-and-true-p org-emphasis-alist))))

;;;###autoload
(define-minor-mode latex-to-svg-for-org-mode
  "Preview Org LaTeX math as SVG images (a `latex-to-svg-frontend' adaptor).

Installs the Org code/comment exclusions and `org-fold-show-context' as
the jump-reveal, then turns on `latex-to-svg-frontend-mode', which does
the rendering.  Enable it from `org-mode-hook'.  While it is on,
`org-latex-preview' only says that it is off (see
`latex-to-svg-for-org-preview-disabled').  When Org's own preview ran
as the buffer opened, the mode warns (see
`latex-to-svg-for-org--warn-org-preview'), and so it does when
`org-latex-preview-mode' is on in the buffer (see
`latex-to-svg-for-org--warn-org-latex-preview-mode')."
  :lighter nil
  :keymap latex-to-svg-for-org-mode-map
  (if latex-to-svg-for-org-mode
      (if (derived-mode-p 'org-mode)
          (progn
            (setq-local latex-to-svg-frontend-exclude-function
                        #'latex-to-svg-for-org--exclusions)
            (setq-local latex-to-svg-frontend-reveal-function
                        (lambda ()
                          (when (fboundp 'org-fold-show-context)
                            (org-fold-show-context 'link-search))))
            (setq-local latex-to-svg-frontend-emphasis-faces
                        (latex-to-svg-for-org--emphasis-faces))
            (latex-to-svg-for-org--warn-org-preview)
            (latex-to-svg-for-org--warn-org-latex-preview-mode)
            (add-hook 'org-latex-preview-mode-hook
                      #'latex-to-svg-for-org--warn-org-latex-preview-mode nil t)
            (latex-to-svg-frontend-mode 1))
        (setq latex-to-svg-for-org-mode nil)
        (user-error "`latex-to-svg-for-org-mode' only works in Org buffers"))
    (latex-to-svg-frontend-mode -1)
    (remove-hook 'org-latex-preview-mode-hook
                 #'latex-to-svg-for-org--warn-org-latex-preview-mode t)
    (kill-local-variable 'latex-to-svg-frontend-exclude-function)
    (kill-local-variable 'latex-to-svg-frontend-reveal-function)
    (kill-local-variable 'latex-to-svg-frontend-emphasis-faces)))

(provide 'latex-to-svg-for-org)

;;; latex-to-svg-for-org.el ends here
