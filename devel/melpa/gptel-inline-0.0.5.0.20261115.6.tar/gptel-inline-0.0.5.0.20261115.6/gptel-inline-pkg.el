;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-inline" "0.0.5.0.20261115.6"
  "Persistent gptel session that follows you around."
  '((emacs  "30.1")
    (compat "30.1.0.0")
    (gptel  "0.9.9.5"))
  :url "https://github.com/karthink/gptel-inline"
  :commit "0dfebee2708c5ab05da514904beaf6687679bf89"
  :revdesc "0dfebee2708c"
  :keywords '("comm")
  :authors '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com")))
