;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weblio" "0.4.1"
  "Look up Japanese words on Weblio.jp."
  '((request "0.3.3")
    (emacs   "25.1"))
  :url "https://github.com/pzel/weblio"
  :commit "86adae50e51a74149d9805c0446edf10a7f5c3f7"
  :revdesc "86adae50e51a"
  :keywords '("langauges" "i18n"))
