;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "api-credit" "1.0.1.0.20260907.1"
  "AI API balance in the modeline."
  '((emacs "25.1"))
  :url "https://github.com/OverbearingPearl/api-credit"
  :commit "5cad5f508c768fecb7e79ad41642fc3cf3cd7eb9"
  :revdesc "5cad5f508c76"
  :keywords '("comm" "convenience")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
