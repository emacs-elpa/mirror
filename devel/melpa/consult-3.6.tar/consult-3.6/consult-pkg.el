;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "3.6"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "9bb68cf3941eb618fff18bd7626164951c70eb8a"
  :revdesc "3.6-0-g9bb68cf3941e"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
