;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bliss-theme" "20141116.0.20170808.4"
  "An Emacs 24 theme based on Bliss (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "c3cf6d8a666ab26909b7da158f9e94df71a5fbbf"
  :revdesc "c3cf6d8a666a")
