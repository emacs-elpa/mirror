;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.89.0.20260718.21"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "2c494430ce9e64eaf4d3eac7bd584c7b789a1975"
  :revdesc "2c494430ce9e"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
