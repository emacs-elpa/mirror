;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-transient" "1.2.2.0.20260925.1"
  "Command dispatchers for Notmuch."
  '((emacs     "29.1")
    (compat    "31.0")
    (notmuch   "0.39")
    (transient "0.13"))
  :url "https://github.com/tarsius/notmuch-transient"
  :commit "4c731df125d66e0d1d9854c75a474d1aa2914f00"
  :revdesc "v1.2.2-1-g4c731df125d6"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev")))
