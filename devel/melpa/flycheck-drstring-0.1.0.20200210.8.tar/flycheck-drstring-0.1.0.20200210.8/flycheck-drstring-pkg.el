;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-drstring" "0.1.0.20200210.8"
  "Doc linting for Swift using DrString."
  '((emacs      "25.1")
    (flycheck   "0.25")
    (swift-mode "8.0"))
  :url "https://github.com/danielmartin/flycheck-drstring"
  :commit "d8d5a560e792a6657ef5ac69934c74f1ed51372d"
  :revdesc "d8d5a560e792"
  :keywords '("tools" "flycheck")
  :authors '(("Daniel Martín" . "mardani29@yahoo.es"))
  :maintainers '(("Daniel Martín" . "mardani29@yahoo.es")))
