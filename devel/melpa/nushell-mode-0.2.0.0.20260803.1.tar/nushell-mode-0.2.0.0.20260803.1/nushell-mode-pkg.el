;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nushell-mode" "0.2.0.0.20260803.1"
  "Major mode for Nushell scripts."
  '((emacs "24.4"))
  :url "https://github.com/mrkkrp/nushell-mode"
  :commit "1fbc56d406c4ec9ad699e19735203a1478c31e49"
  :revdesc "1fbc56d406c4"
  :keywords '("languages" "unix")
  :authors '(("Azzam S.A" . "vcs@azzamsa.com"))
  :maintainers '(("Azzam S.A" . "vcs@azzamsa.com")))
