;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "h5dump-mode" "0.1.0.0.20221128.6"
  "Major mode for navigating h5dump output."
  '((emacs "25.1"))
  :url "https://github.com/berquist/h5dump-mode"
  :commit "3c9e4608112da91db76bf316417023bed0422ef3"
  :revdesc "3c9e4608112d"
  :keywords '("languages" "hdf5"))
