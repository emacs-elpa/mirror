;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leadkey" "0.2.0.0.20260624.1"
  "Translate leader keys to key sequences."
  '((emacs "30.1"))
  :url "https://github.com/jixiuf/emacs-leadkey"
  :commit "3a0befd5a8937f8effe07da001cf8d3c765fc2ce"
  :revdesc "3a0befd5a893"
  :keywords '("convenience")
  :authors '(("jixiuf" . "https://github.com/jixiuf"))
  :maintainers '(("jixiuf" . "https://github.com/jixiuf")))
