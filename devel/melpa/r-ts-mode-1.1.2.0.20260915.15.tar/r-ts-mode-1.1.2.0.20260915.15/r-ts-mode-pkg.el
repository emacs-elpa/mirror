;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "r-ts-mode" "1.1.2.0.20260915.15"
  "R treesitter mode."
  '((emacs "30.1"))
  :url "https://codeberg.org/R-for-emacs/r-ts-mode"
  :commit "f5e4f6395a09a4d20a7dd41b5d8606ba56e39057"
  :revdesc "f5e4f6395a09"
  :authors '(("Manuel Teodoro" . "ttm@teoten.me"))
  :maintainers '(("Manuel Teodoro" . "ttm@teoten.me")))
