;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "expenses" "0.2.0.0.20261016.25"
  "Record and view expenses."
  '((emacs     "28.1")
    (dash      "2.19.1")
    (ht        "2.3")
    (transient "0.3.7"))
  :url "https://github.com/md-arif-shaikh/expenses"
  :commit "716024ef83753df0723e9b20d574e368d01476fb"
  :revdesc "716024ef8375"
  :keywords '("expense tracking" "convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
