;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iosevka-theme" "0.2.0.20250919.3"
  "Theme using various stylistic sets of Iosevka font."
  '((emacs "28.1"))
  :url "https://codeberg.org/mekeor/iosevka-theme"
  :commit "bef8c3ec7979937cfdde3054ce5fed2146bc3f87"
  :revdesc "bef8c3ec7979"
  :keywords '("faces" "theme")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
