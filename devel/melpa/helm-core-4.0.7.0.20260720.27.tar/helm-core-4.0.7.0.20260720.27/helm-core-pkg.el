;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "4.0.7.0.20260720.27"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "ab09703effe69217b97a2097ff3b8742bb39c6a3"
  :revdesc "v4.0.7-27-gab09703effe6"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
