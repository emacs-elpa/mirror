;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-ts-appear" "0.2.4.0.20261013.16"
  "Reveal Markdown source at point."
  '((emacs               "31.1")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/Thysrael/markdown-ts-appear"
  :commit "5af4ad99b0c1bc26b4f6b16acff4638ca252cfb4"
  :revdesc "v0.2.4-16-g5af4ad99b0c1"
  :keywords '("text" "convenience")
  :authors '(("Thysrael" . "thysrael@163.com"))
  :maintainers '(("Thysrael" . "thysrael@163.com")))
