;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar" "1.4.0.0.20260328.27"
  "Citation-related commands for org, latex, markdown."
  '((emacs    "27.1")
    (parsebib "4.2")
    (org      "9.5")
    (citeproc "0.9")
    (compat   "30"))
  :url "https://github.com/emacs-citar/citar"
  :commit "58df8b9b8af8a2636b28ed5c6005eddef7f579f7"
  :revdesc "v1.4.0-27-g58df8b9b8af8"
  :authors '(("Bruce D'Arcus" . "https://github.com/bdarcus"))
  :maintainers '(("Bruce D'Arcus" . "https://github.com/bdarcus")))
