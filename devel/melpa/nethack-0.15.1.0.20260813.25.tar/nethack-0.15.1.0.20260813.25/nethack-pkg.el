;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "0.15.1.0.20260813.25"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "1c8475d3d3061c71705b8cfb696c40a38ff745ae"
  :revdesc "1c8475d3d306"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
