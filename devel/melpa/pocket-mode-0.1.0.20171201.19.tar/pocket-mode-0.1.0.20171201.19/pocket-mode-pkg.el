;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pocket-mode" "0.1.0.20171201.19"
  "Manage your pocket."
  '((emacs      "24.4")
    (pocket-api "0.1"))
  :url "https://github.com/lujun9972/pocket-mode"
  :commit "229de7d35b7e5605797591c46aa8200d7efc363c"
  :revdesc "229de7d35b7e"
  :keywords '("convenience" "pocket")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
