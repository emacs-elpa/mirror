;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ample-theme" "0.3.0.0.20260611.50"
  "Calm Dark Theme for Emacs."
  ()
  :url "https://github.com/jordonbiondo/ample-theme"
  :commit "6952b29a588c854084ca1360bed16c9bc2d48e37"
  :revdesc "6952b29a588c"
  :keywords '("theme" "dark")
  :authors '(("Jordon Biondo" . "jordonbiondo@gmail.com"))
  :maintainers '(("Jordon Biondo" . "jordonbiondo@gmail.com")))
