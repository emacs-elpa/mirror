;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rtags" "2.44.135.0.20260504.10"
  "A front-end for rtags."
  '((emacs "24.3"))
  :url "https://github.com/Andersbakken/rtags"
  :commit "2d9049adfef58961d0a710f93a8af387eb84dd01"
  :revdesc "2d9049adfef5"
  :authors '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
             ("Anders Bakken" . "agbakken@gmail.com"))
  :maintainers '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
                 ("Anders Bakken" . "agbakken@gmail.com")))
