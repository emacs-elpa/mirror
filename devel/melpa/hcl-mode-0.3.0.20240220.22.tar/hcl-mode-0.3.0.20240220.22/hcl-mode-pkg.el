;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hcl-mode" "0.3.0.20240220.22"
  "Major mode for Hashicorp."
  '((emacs "24.3"))
  :url "https://github.com/purcell/emacs-hcl-mode"
  :commit "b2a03a446c1fe324ff494c28b9321486fa6fc672"
  :revdesc "b2a03a446c1f"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
