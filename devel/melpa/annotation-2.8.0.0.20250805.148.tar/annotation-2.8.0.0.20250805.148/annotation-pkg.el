;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotation" "2.8.0.0.20250805.148"
  "Functions for annotating text with faces and help bubbles."
  ()
  :url "https://github.com/agda/agda"
  :commit "213db6e50bb89c1b0b2832eab4c6caafb137eb6d"
  :revdesc "213db6e50bb8")
