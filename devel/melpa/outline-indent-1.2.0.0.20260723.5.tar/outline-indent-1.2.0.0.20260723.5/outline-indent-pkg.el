;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "1.2.0.0.20260723.5"
  "Folding text based on indentation (origami alternative)."
  '((emacs    "26.1")
    (kirigami "1.0.5"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "983d1143fcf574dd3e47dda8832c8c78ffdac1c5"
  :revdesc "1.2.0-5-g983d1143fcf5"
  :keywords '("outlines")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
