;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "1.5.0.20260704.4"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/dicom"
  :commit "50bfab3a34e502d6bac8ab12854cb33c8aff343c"
  :revdesc "1.5-4-g50bfab3a34e5"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
