;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projekt" "0.1.0.20150324.3"
  "Some kind of staging for CVS."
  '((emacs "24"))
  :url "https://github.com/tekai/projekt"
  :commit "a65e554e5d8b0def08c5d06f3fe34fec40bebd83"
  :revdesc "a65e554e5d8b"
  :authors '(("Engelke Eschner" . "tekai@gmx.li"))
  :maintainers '(("Engelke Eschner" . "tekai@gmx.li")))
