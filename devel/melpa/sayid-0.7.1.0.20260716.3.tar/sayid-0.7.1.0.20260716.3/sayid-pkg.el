;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "0.7.1.0.20260716.3"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "2.0"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "241fa2dc15ac6655ee214f226b885e4eb4d06be8"
  :revdesc "v0.7.1-3-g241fa2dc15ac"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
