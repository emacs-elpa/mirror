;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "0.6.1.0.20260711.5"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3"))
  :url "https://codeberg.org/guix/emacs-guix"
  :commit "90db5c1951886737aa26cc8be8e7ac717182dfef"
  :revdesc "v0.6.1-5-g90db5c195188"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
