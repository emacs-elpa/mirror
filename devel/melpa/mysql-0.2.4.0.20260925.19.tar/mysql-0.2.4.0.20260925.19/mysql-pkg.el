;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "0.2.4.0.20260925.19"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "0f8f3c0fff6d9016c9c04ab6094d9354cca82c2c"
  :revdesc "0f8f3c0fff6d"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
