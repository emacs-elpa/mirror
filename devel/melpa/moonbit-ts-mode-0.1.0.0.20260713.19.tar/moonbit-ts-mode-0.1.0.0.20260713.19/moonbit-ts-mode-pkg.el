;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moonbit-ts-mode" "0.1.0.0.20260713.19"
  "MoonBit tree-sitter major mode."
  '((emacs "30.1"))
  :url "https://github.com/moonbit-community/moonbit-ts-mode"
  :commit "f8ae31f506571614afea2fcd03532d872afd917b"
  :revdesc "f8ae31f50657"
  :keywords '("languages" "tree-sitter"))
