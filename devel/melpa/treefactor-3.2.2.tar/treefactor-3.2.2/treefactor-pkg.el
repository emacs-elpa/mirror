;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treefactor" "3.2.2"
  "Restructure your messy Org documents."
  '((emacs "26.1")
    (dash  "2.16.0")
    (f     "0.20.0")
    (org   "9.2.6")
    (avy   "0.5.0"))
  :url "https://github.com/cyberthal/treefactor"
  :commit "75357757022a4399ab772ff0d92065bd114dabe9"
  :revdesc "75357757022a"
  :keywords '("outlines" "files" "convenience")
  :authors '(("Leo Littlebook" . "Leo.Littlebook@gmail.com"))
  :maintainers '(("Leo Littlebook" . "Leo.Littlebook@gmail.com")))
