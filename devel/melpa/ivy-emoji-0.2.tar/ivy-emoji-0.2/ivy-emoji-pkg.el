;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-emoji" "0.2"
  "Insert emojis with ivy."
  '((emacs "26.1")
    (ivy   "0.13.0"))
  :url "https://github.com/sbozzolo/ivy-emoji.git"
  :commit "45894a1f8f8c67b142e1dd1113f47d703dea0b59"
  :revdesc "45894a1f8f8c"
  :keywords '("emoji" "ivy" "convenience")
  :authors '(("Gabriele Bozzola" . "sbozzolator@gmail.com"))
  :maintainers '(("Gabriele Bozzola" . "sbozzolator@gmail.com")))
