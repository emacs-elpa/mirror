;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bilibili" "1.0.0"
  "Watch videos of BiliBili (哔哩哔哩) in org mode."
  '((emacs "29.1")
    (org   "9.0")
    (mpvi  "1.3")
    (pdd   "0.2"))
  :url "https://github.com/lorniu/bilibili.el"
  :commit "f650983c9c29ea5fe4574dac3b3fd2a62ae49520"
  :revdesc "f650983c9c29"
  :keywords '("multimedia" "application")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
