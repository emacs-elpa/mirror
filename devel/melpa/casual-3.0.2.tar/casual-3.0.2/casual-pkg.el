;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "3.0.2"
  "Transient user interfaces for various modes."
  '((emacs     "30.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "60259e256e34d4f6ae64ef950c740cacbe8b4d37"
  :revdesc "60259e256e34"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
