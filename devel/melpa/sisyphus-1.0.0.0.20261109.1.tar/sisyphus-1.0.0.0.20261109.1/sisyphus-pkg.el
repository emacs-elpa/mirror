;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "1.0.0.0.20261109.1"
  "Create releases of Emacs packages."
  '((emacs    "31.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.7"))
  :url "https://github.com/magit/sisyphus"
  :commit "a878b54943bac1f179c2aa588e99a7f8f4dad37c"
  :revdesc "v1.0.0-1-ga878b54943ba"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
