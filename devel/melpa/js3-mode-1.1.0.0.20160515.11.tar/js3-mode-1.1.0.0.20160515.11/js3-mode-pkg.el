;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js3-mode" "1.1.0.0.20160515.11"
  "An improved JavaScript editing mode."
  ()
  :url "https://github.com/tamzinblake/js3-mode"
  :commit "7fceb21ec56aac7af4b189bb0c0d0cf620327f5a"
  :revdesc "v1.1.0-11-g7fceb21ec56a"
  :keywords '("javascript" "languages")
  :authors '(("Thom Blake" . "(webmaster@thomblake.com)"))
  :maintainers '(("Thom Blake" . "(webmaster@thomblake.com)")))
