;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-sagemath" "0.4.0.20191106.16"
  "Org-babel functions for SageMath evaluation."
  '((sage-shell-mode "0.0.8")
    (s               "1.8.0")
    (emacs           "24"))
  :url "https://github.com/stakemori/ob-sagemath"
  :commit "79645bce0c25a650bae61e550434bed836995dce"
  :revdesc "79645bce0c25"
  :keywords '("sagemath" "org-babel")
  :authors '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainers '(("Sho Takemori" . "stakemorii@gmail.com")))
