;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perject" "3.2.0.20250115.36"
  "Session-persistent project management."
  '((emacs     "27.1")
    (dash      "2.10")
    (transient "0.3.7"))
  :url "https://github.com/overideal/perject"
  :commit "28fad17c048685d89c815b6bf6e69c3102ee3712"
  :revdesc "28fad17c0486")
