;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eping" "0.1.1.0.20201027.6"
  "Ping websites to check internet connectivity."
  '((emacs "25.1"))
  :url "https://github.com/sean-hut/eping"
  :commit "004496ee06c0b8ead4a4f49e17109e8eb32eb49d"
  :revdesc "004496ee06c0"
  :keywords '("comm" "processes" "terminals" "unix")
  :authors '(("Sean Hutchings" . "seanhut@yandex.com"))
  :maintainers '(("Sean Hutchings" . "seanhut@yandex.com")))
