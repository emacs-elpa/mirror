;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-pause" "0.1.0.20160426.12"
  "Run processes which will be paused when Emacs is idle."
  '((emacs "24.4"))
  :url "https://github.com/lujun9972/auto-pause"
  :commit "a4d778de774ca3895542cb559a953e0d98657338"
  :revdesc "a4d778de774c"
  :keywords '("convenience" "menu")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
