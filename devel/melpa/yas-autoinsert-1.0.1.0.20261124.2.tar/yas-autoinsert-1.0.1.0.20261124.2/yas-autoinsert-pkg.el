;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yas-autoinsert" "1.0.1.0.20261124.2"
  "Autoinsert trigger for YASnippet."
  '((emacs     "25.1")
    (yasnippet "0.8.1"))
  :url "https://gitlab.com/rchastel1/emacs/yas-autoinsert"
  :commit "67725680fc1a6a1527400cce861a5d3b092d6d56"
  :revdesc "v1.0.1-2-g67725680fc1a"
  :keywords '("editing" "files" "convenience")
  :authors '(("Wieland Hoffmann" . "themineo+yatemplate@gmail.com")
             ("Piknik" . "https://github.com/piknik")
             ("Romain Châtel" . "rchastel@protonmail.com"))
  :maintainers '(("Romain Châtel" . "rchastel@protonmail.com")))
