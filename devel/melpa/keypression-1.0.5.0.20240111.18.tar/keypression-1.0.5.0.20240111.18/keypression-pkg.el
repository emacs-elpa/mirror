;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keypression" "1.0.5.0.20240111.18"
  "Keystroke visualizer."
  '((emacs "26.3"))
  :url "https://github.com/chuntaro/emacs-keypression"
  :commit "e85e3fd9ce216a370be221cf9de1503777ef0088"
  :revdesc "e85e3fd9ce21"
  :keywords '("key" "screencast" "tools")
  :authors '(("chuntaro" . "chuntaro@sakura-games.jp"))
  :maintainers '(("chuntaro" . "chuntaro@sakura-games.jp")))
