;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpactor" "0.1.0.0.20261007.260"
  "Interface to Phpactor."
  '((emacs       "28.1")
    (php-runtime "0.2")
    (composer    "0.2.0")
    (async       "1.9.3"))
  :url "https://github.com/emacs-php/phpactor.el"
  :commit "00c74783c152bb568d4bda76ce8438c03fdf97fa"
  :revdesc "00c74783c152"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me")
             ("Mikael Kermorgant" . "mikael@kgtech.fi"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")
                 ("Mikael Kermorgant" . "mikael@kgtech.fi")))
