;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shut-up" "0.3.3.0.20261029.10"
  "Shut up would you!."
  '((emacs "25.3"))
  :url "https://github.com/rejeep/shut-up.el"
  :commit "2f015df0b678c4eac90a561c65d8f31f6d7b73d1"
  :revdesc "2f015df0b678"
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
