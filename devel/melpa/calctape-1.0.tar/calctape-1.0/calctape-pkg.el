;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calctape" "1.0"
  "Adding-machine, tape calculator, column sum-mer."
  '((emacs "29.1"))
  :url "https://github.com/Boruch-Baum/emacs-calctape"
  :commit "783be1a28ea24e63f7438210aedc9e750439c925"
  :revdesc "783be1a28ea2"
  :keywords '("convenience" "data")
  :authors '(("Boruch Baum" . "boruch_baum@gmx.com"))
  :maintainers '(("Boruch Baum" . "boruch_baum@gmx.com")))
