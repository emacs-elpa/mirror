;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f90-ts-mode" "0.4.0.0.20260918.34"
  "Tree-sitter based Fortran 90 mode."
  '((emacs "29.1"))
  :url "https://github.com/mscfd/emacs-f90-ts-mode"
  :commit "e6195edbb42203cb2a0e10b3cf997a5f1198ff79"
  :revdesc "v0.4.0-34-ge6195edbb422"
  :keywords '("languages" "treesitter" "fortran")
  :authors '(("Martin Stein" . "mscfd@gmx.net"))
  :maintainers '(("Martin Stein" . "mscfd@gmx.net")))
