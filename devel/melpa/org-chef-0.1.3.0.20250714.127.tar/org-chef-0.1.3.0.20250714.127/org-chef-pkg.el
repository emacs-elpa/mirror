;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-chef" "0.1.3.0.20250714.127"
  "Cookbook and recipe management with org-mode."
  '((org   "0")
    (emacs "24.3"))
  :url "https://github.com/Chobbes/org-chef"
  :commit "9f749324f7e8c51a2da8516820268c83e825c6c7"
  :revdesc "9f749324f7e8"
  :keywords '("convenience" "abbrev" "outlines" "org" "food" "recipes" "cooking")
  :authors '(("Calvin Beck" . "hobbes@ualberta.ca"))
  :maintainers '(("Calvin Beck" . "hobbes@ualberta.ca")))
