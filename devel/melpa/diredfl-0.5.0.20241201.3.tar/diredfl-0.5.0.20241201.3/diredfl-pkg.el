;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredfl" "0.5.0.20241201.3"
  "Extra font lock rules for a more colourful dired."
  '((emacs "24"))
  :url "https://github.com/purcell/diredfl"
  :commit "fe72d2e42ee18bf6228bba9d7086de4098f18a70"
  :revdesc "fe72d2e42ee1"
  :keywords '("faces")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
