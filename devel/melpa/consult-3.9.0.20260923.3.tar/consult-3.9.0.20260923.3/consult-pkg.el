;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "3.9.0.20260923.3"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "24eed02c31e80df16aed5f741b77b66e270de6eb"
  :revdesc "3.9-3-g24eed02c31e8"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
