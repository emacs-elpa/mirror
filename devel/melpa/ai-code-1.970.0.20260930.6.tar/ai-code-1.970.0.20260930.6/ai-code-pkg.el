;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.970.0.20260930.6"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "254916b1868d0a4d6822e9934edcf7dada842ea2"
  :revdesc "254916b1868d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
