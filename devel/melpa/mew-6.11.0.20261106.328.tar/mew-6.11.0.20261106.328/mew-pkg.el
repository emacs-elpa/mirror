;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20261106.328"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "92dd698f73d8b855fbe540f5dc12a262af260208"
  :revdesc "92dd698f73d8")
