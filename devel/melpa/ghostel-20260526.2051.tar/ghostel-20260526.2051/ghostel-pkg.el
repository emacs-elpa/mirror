;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260526.2051"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "58a7f8ad43edc6249bacb0592cb28d83aa2ed37a"
  :revdesc "58a7f8ad43ed"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
