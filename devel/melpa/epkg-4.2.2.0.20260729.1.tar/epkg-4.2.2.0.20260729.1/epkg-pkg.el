;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "4.2.2.0.20260729.1"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.0")
    (closql   "2.4")
    (cond-let "1.1")
    (emacsql  "4.4")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "abb96029632bf9e8faafa3bf12c0bfa27aea0d40"
  :revdesc "v4.2.2-1-gabb96029632b"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
