;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-try-hard" "0.1.0.20200417.8"
  "Get all completions from company backends."
  '((emacs   "24.3")
    (company "0.8.0")
    (dash    "2.0"))
  :url "https://github.com/Wilfred/company-try-hard"
  :commit "2b41136b5ed6e02032d99bcdb0599ecf00394fa5"
  :revdesc "2b41136b5ed6"
  :keywords '("matching")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
