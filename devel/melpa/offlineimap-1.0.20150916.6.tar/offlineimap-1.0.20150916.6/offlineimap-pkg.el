;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "offlineimap" "1.0.20150916.6"
  "Run OfflineIMAP from Emacs."
  ()
  :url "http://julien.danjou.info/offlineimap-el.html"
  :commit "cc3e067e6237a1eb7b21c575a41683b1febb47f1"
  :revdesc "v1-6-gcc3e067e6237"
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("Julien Danjou" . "julien@danjou.info")))
