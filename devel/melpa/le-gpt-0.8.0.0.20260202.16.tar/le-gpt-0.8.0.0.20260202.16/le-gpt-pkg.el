;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "le-gpt" "0.8.0.0.20260202.16"
  "Emacs on steroids with GPT."
  '((emacs         "28.1")
    (markdown-mode "2.6"))
  :url "https://github.com/AnselmC/le-gpt.el"
  :commit "dd5e0cdec646adb3fb638d837e6d8fb61a2602f1"
  :revdesc "dd5e0cdec646"
  :keywords '("openai" "anthropic" "deepseek" "gpt" "claude" "language" "copilot" "convenience" "tools" "llm")
  :authors '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainers '(("Anselm Coogan" . "anselm.coogan@gmail.com")))
