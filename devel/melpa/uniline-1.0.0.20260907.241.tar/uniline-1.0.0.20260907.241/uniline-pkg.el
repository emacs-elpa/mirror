;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "1.0.0.20260907.241"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "de69977255b9074d5d01eb291eb0bfd92575fea2"
  :revdesc "de69977255b9"
  :keywords '("convenience" "text"))
