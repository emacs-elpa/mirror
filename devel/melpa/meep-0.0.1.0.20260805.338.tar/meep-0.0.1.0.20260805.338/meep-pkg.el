;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "0.0.1.0.20260805.338"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "6611204fbbd1ed7ae9f9ad7cd17db2d199a8ac80"
  :revdesc "6611204fbbd1"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
