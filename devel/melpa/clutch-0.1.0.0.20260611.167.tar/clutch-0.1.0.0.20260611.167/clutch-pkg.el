;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.1.0.0.20260611.167"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.2")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "40a6f93e14a6742dbad59e383236e3be6ec0e9e5"
  :revdesc "40a6f93e14a6"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
