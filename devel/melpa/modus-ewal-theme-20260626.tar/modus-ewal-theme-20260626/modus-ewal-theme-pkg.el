;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-ewal-theme" "20260626"
  "Modus theme that uses pywal colors powered by ewal."
  '((emacs        "25.1")
    (modus-themes "5.2.0")
    (ewal         "0.2.1"))
  :url "https://github.com/deadendpl/modus-ewal-theme"
  :commit "47d6e60920ec92217e899a8f174f37c8f6640ed6"
  :revdesc "47d6e60920ec"
  :keywords '("faces" "theme")
  :authors '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me"))
  :maintainers '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me")))
