;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gs-mode" "0.1.0.20151202.3"
  "Major mode for editing GrADS script files."
  ()
  :url "https://github.com/yyr/emacs-grads"
  :commit "1a13051db21b999c7682a015b33a03096ff9d891"
  :revdesc "1a13051db21b"
  :keywords '("grads" "script" "major-mode")
  :authors '(("Joe Wielgosz" . "joew@cola.iges.org"))
  :maintainers '(("Joe Wielgosz" . "joew@cola.iges.org")))
