;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thanks" "1.0.0.20250907.14"
  "Say thanks to the authors of all your installed packages."
  '((emacs "25.1")
    (gh    "1.0.1"))
  :url "https://github.com/FrostyX/thanks"
  :commit "7dcc186ea754695694f1ce7159ab8b6a2d663f3c"
  :revdesc "7dcc186ea754"
  :keywords '("tools")
  :authors '(("Jakub Kadlčík" . "frostyx@email.cz"))
  :maintainers '(("Jakub Kadlčík" . "frostyx@email.cz")))
