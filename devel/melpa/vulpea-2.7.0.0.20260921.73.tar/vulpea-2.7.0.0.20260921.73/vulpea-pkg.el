;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.7.0.0.20260921.73"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "7de5f6fc21b2a3054cc7fa4363a27c123560f0f5"
  :revdesc "7de5f6fc21b2"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
