;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gn-mode" "0.4.1"
  "Major mode for editing GN (generate ninja) files."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/lashtear/gn-mode"
  :commit "fcf8e1e500d953364e97e7ebc5708a2c00fa3cd2"
  :revdesc "fcf8e1e500d9"
  :keywords '("data")
  :authors '(("Emily Backes" . "lucca@accela.net"))
  :maintainers '(("Emily Backes" . "lucca@accela.net")))
