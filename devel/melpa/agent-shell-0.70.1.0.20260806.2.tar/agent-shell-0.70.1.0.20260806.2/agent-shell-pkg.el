;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.70.1.0.20260806.2"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.96.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0d078df3aa2f99f207294629d3f6e8a299497fa4"
  :revdesc "0d078df3aa2f")
