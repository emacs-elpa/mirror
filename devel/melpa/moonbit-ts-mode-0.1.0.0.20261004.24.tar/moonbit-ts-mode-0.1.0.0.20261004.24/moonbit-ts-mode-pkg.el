;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moonbit-ts-mode" "0.1.0.0.20261004.24"
  "MoonBit tree-sitter major mode."
  '((emacs "31.1"))
  :url "https://github.com/moonbit-community/moonbit-ts-mode"
  :commit "783bc2f6034dd34d321a263650df85a46d56d8e9"
  :revdesc "783bc2f6034d"
  :keywords '("languages" "tree-sitter"))
