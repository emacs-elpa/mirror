;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-kanban" "0.6.15"
  "Kanban dynamic block for org-mode."
  '((s    "0")
    (dash "2.17.0"))
  :url "https://github.com/gizmomogwai/org-kanban"
  :commit "bc7864f2140d3ed510ec0ecd60c6d3d8b8589ea4"
  :revdesc "v0.6.15-0-gbc7864f2140d"
  :keywords '("org-mode" "org" "kanban" "tools")
  :authors '(("Christian Köstlin" . "christian.koestlin@gmail.com"))
  :maintainers '(("Christian Köstlin" . "christian.koestlin@gmail.com")))
