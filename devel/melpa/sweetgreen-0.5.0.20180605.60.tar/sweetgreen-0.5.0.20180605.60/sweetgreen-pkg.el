;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sweetgreen" "0.5.0.20180605.60"
  "Order Salads from sweetgreen.com."
  '((dash    "2.12.1")
    (helm    "1.5.6")
    (request "0.2.0")
    (cl-lib  "0.5"))
  :url "https://www.github.com/CestDiego/sweetgreen.el"
  :commit "e933fe466b5ef0e976967e203f88bd7a012469d1"
  :revdesc "e933fe466b5e"
  :keywords '("salad" "food" "sweetgreen" "request")
  :authors '(("Diego Berrocal" . "cestdiego@gmail.com"))
  :maintainers '(("Diego Berrocal" . "cestdiego@gmail.com")))
