;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-hn" "1.1.0"
  "Hacker News search with Consult."
  '((emacs     "29.4")
    (consult   "2.0")
    (ts        "0.3")
    (transient "0.9"))
  :url "https://github.com/agzam/consult-hn"
  :commit "adbb48802a2b000df2340dc0a1b51396c0b0c0c3"
  :revdesc "v1.1.0-0-gadbb48802a2b"
  :keywords '("search" "extensions")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
