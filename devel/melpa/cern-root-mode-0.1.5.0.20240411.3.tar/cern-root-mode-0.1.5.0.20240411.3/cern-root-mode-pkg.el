;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cern-root-mode" "0.1.5.0.20240411.3"
  "Major-mode for running C++ code with ROOT."
  '((emacs "26.1"))
  :url "https://github.com/jaypmorgan/cern-root-mode"
  :commit "d769530ddfbe57cc3c319b430c8a37c72c8ce52c"
  :revdesc "d769530ddfbe"
  :keywords '("languages" "tools")
  :authors '(("Jay Morgan" . "jay@morganwastaken.com"))
  :maintainers '(("Jay Morgan" . "jay@morganwastaken.com")))
