;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multitran" "0.4.16.0.20240206.4"
  "Interface to multitran."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/zevlg/multitran.el"
  :commit "680f31d15b78876daf484bd926e5c172ab061595"
  :revdesc "680f31d15b78"
  :keywords '("dictionary" "hypermedia")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
