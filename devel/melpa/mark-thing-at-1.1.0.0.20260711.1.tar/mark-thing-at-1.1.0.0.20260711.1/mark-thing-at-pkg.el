;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mark-thing-at" "1.1.0.0.20260711.1"
  "Mark a pattern at the current point."
  '((emacs          "26")
    (choice-program "0.14"))
  :url "https://github.com/plandes/mark-thing-at"
  :commit "7829d89ba7da560adb4236fd26fc6ed5813b7173"
  :revdesc "v1.1.0-1-g7829d89ba7da"
  :keywords '("mark" "point" "lisp"))
