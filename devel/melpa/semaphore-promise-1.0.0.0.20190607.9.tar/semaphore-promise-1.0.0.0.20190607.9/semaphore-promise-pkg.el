;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "semaphore-promise" "1.0.0.0.20190607.9"
  "Semaphore integration with promise."
  '((emacs     "26")
    (semaphore "1")
    (promise   "1"))
  :url "https://github.com/webnf/semaphore.el"
  :commit "9cdfef91cc0293371af549ad41027aa5b73f30a4"
  :revdesc "9cdfef91cc02"
  :keywords '("processes" "unix")
  :authors '(("Herwig Hochleitner" . "herwig@bendlas.net"))
  :maintainers '(("Herwig Hochleitner" . "herwig@bendlas.net")))
