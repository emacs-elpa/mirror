;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morganey-mode" "0.0.1.0.20170118.18"
  "Major mode for editing Morganey files."
  '((emacs "24.4"))
  :url "https://github.com/morganey-lang/morganey-mode"
  :commit "7e33f1be486f58dfcf02adcbf82ccac47f69bd9b"
  :revdesc "7e33f1be486f"
  :authors '(("Alexey Kutepov" . "reximkut@gmail.com"))
  :maintainers '(("Alexey Kutepov" . "reximkut@gmail.com")))
