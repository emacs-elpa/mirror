;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zombie-trellys-mode" "0.2.1"
  "A minor mode for interaction with Zombie Trellys."
  '((emacs        "24")
    (cl-lib       "0.5")
    (haskell-mode "1.5"))
  :url "https://github.com/david-christiansen/zombie-trellys-mode"
  :commit "9e99d444a387dd1634cab62ef802683f5bf5d907"
  :revdesc "9e99d444a387"
  :keywords '("languages")
  :authors '(("David Raymond Christiansen" . "david@davidchristiansen.dk"))
  :maintainers '(("David Raymond Christiansen" . "david@davidchristiansen.dk")))
