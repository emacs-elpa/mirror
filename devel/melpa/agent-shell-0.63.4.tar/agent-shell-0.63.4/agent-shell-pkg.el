;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.63.4"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c5bc80bad17aaf9d0cab8a6410b7552ddb0accdd"
  :revdesc "c5bc80bad17a")
