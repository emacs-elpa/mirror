;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sublimity" "20160629.0.20200905.31"
  "Smooth-scrolling, minimap and distraction-free mode."
  '((emacs "26.1"))
  :url "https://github.com/zk-phi/sublimity"
  :commit "8e2ffc4d62194106130014531e7b54fc9b4b9e6c"
  :revdesc "8e2ffc4d6219")
