;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elx" "2.3.3"
  "Extract information from Emacs Lisp libraries."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/elx"
  :commit "99ea4bde756a3ae4a0cae96e9fffe6b13421d25f"
  :revdesc "v2.3.3-0-g99ea4bde756a"
  :keywords '("docs" "libraries" "packages")
  :authors '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev")))
