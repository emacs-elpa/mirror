;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-cfengine3" "0.0.7.0.20260731.4"
  "Org Babel functions for CFEngine 3."
  '((emacs "24.1"))
  :url "https://github.com/nickanderson/ob-cfengine3"
  :commit "3d2576546312193456405af5d1acc446a59d71bc"
  :revdesc "3d2576546312"
  :keywords '("tools" "convenience")
  :authors '(("Nick Anderson" . "nick@cmdln.org"))
  :maintainers '(("Nick Anderson" . "nick@cmdln.org")))
