;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vimscript-ts-mode" "0.0.1.0.20241020.9"
  "Vim-script major mode using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/nverno/vimscript-ts-mode"
  :commit "8ebe7746172caaa88d463c58e0bfe76ec7fc971a"
  :revdesc "8ebe7746172c"
  :keywords '("languages" "vim" "tree-sitter")
  :authors '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers '(("Noah Peart" . "noah.v.peart@gmail.com")))
