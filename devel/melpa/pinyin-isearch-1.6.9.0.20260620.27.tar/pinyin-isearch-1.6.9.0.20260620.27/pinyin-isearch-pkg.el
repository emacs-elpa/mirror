;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "1.6.9.0.20260620.27"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "f15976e9989cfa9e7bd2bf59f2361e0cf62fed8e"
  :revdesc "f15976e9989c"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
