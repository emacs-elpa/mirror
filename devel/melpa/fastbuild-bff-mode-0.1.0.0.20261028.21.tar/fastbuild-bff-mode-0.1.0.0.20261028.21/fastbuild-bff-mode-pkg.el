;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fastbuild-bff-mode" "0.1.0.0.20261028.21"
  "Major mode for FASTBuild BFF files."
  '((emacs "26.1"))
  :url "https://github.com/cyberkm/fastbuild-bff-mode"
  :commit "5fed845e3f8f8ebd7304e4591621d67f3ee2f809"
  :revdesc "5fed845e3f8f"
  :keywords '("languages" "tools" "build")
  :authors '(("Pavel Bibergal" . "cyberkm@gmail.com"))
  :maintainers '(("Pavel Bibergal" . "cyberkm@gmail.com")))
