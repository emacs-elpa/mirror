;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diffpdf" "1.0.0.20210626.6"
  "Transient diffpdf."
  '((emacs     "25.1")
    (transient "0.3.0"))
  :url "https://github.com/ShuguangSun/diffpdf.el"
  :commit "a5b203b549e373cb9b0ef3f00c0010bd34dd644a"
  :revdesc "a5b203b549e3"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
