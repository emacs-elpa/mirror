;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lgr" "0.1.0.0.20261109.32"
  "A fully featured logging framework."
  '((emacs "26.1"))
  :url "https://github.com/Fuco1/emacs-lgr"
  :commit "d65485c6b86ef371cd0da5442ebc8ec309927841"
  :revdesc "d65485c6b86e"
  :keywords '("tools")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
