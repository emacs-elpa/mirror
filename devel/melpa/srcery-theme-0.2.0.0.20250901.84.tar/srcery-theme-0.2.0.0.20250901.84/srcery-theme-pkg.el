;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srcery-theme" "0.2.0.0.20250901.84"
  "Dark color theme."
  '((emacs "24"))
  :url "https://github.com/srcery-colors/srcery-emacs"
  :commit "eee86865bb7baa8f015ab57a42d9c12e51b8b6fb"
  :revdesc "eee86865bb7b"
  :keywords '("faces"))
