;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gscholar-bibtex" "0.3.3.0.20190130.4"
  "Retrieve BibTeX from Google Scholar and other online sources(ACM, IEEE, DBLP)."
  ()
  :url "https://github.com/cute-jumper/gscholar-bibtex"
  :commit "3b651e3de116860eb1f1aef9b547a561784871fe"
  :revdesc "3b651e3de116"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
