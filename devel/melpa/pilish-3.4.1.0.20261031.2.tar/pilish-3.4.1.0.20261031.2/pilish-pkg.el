;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.4.1.0.20261031.2"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.5.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "a38fbdadecb57684011fea18f022c364d9a9a325"
  :revdesc "v3.4.1-2-ga38fbdadecb5"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
