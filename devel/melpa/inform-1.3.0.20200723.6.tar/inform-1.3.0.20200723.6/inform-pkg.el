;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inform" "1.3.0.20200723.6"
  "Link symbols in Info buffers to their help documentation."
  '((emacs "25.1"))
  :url "https://github.com/dieter-wilhelm/inform"
  :commit "8ff0a19a9f40cfa8283da8ed73de94c35a327423"
  :revdesc "1.3-6-g8ff0a19a9f40"
  :keywords '("help" "docs" "convenience")
  :authors '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de")))
