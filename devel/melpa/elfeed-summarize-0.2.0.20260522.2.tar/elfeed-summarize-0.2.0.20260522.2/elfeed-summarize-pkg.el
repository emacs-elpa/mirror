;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-summarize" "0.2.0.20260522.2"
  "Add LLM-powered inline summaries to elfeed."
  '((emacs  "28.1")
    (elfeed "3.4.1")
    (llm    "0.28.4"))
  :url "https://github.com/fritzgrabo/elfeed-summarize"
  :commit "9b2fbc469d31e1f965ff1953e483adabbdf4495d"
  :revdesc "9b2fbc469d31"
  :keywords '("comm")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
