;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "puppet-ts-mode" "0.3.0"
  "Major mode for Puppet using Tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/smoeding/puppet-ts-mode"
  :commit "f287c44f357604ec7fbf2f3ab0196dcd47056593"
  :revdesc "f287c44f3576"
  :keywords '("languages")
  :authors '(("Stefan Möding" . "stm@kill-9.net"))
  :maintainers '(("Stefan Möding" . "stm@kill-9.net")))
