;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kawacode" "0.1.0.0.20260307.25"
  "Kawa Code collaboration package."
  '((emacs "27.1"))
  :url "https://github.com/codeawareness/kawa.emacs"
  :commit "2aa16e40aaf044c27a7c79dfd5a3fe6656875979"
  :revdesc "v0.1.0-25-g2aa16e40aaf0"
  :keywords '("tools" "convenience" "vc")
  :authors '(("Mark Vasile" . "mark@codeawareness.com"))
  :maintainers '(("Mark Vasile" . "mark@codeawareness.com")))
