;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp-server-lib" "0.3.0.0.20260613.8"
  "Model Context Protocol server library."
  '((emacs "27.1"))
  :url "https://github.com/laurynas-biveinis/mcp-server-lib.el"
  :commit "6a33350e768af0029af224a14b526ab6246d29b4"
  :revdesc "0.3.0-8-g6a33350e768a"
  :keywords '("comm" "tools")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
