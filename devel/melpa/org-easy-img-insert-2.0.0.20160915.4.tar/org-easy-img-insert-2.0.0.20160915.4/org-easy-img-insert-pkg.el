;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-easy-img-insert" "2.0.0.20160915.4"
  "An easier way to add images from the web in org mode."
  '((emacs "24.4"))
  :url "https://github.com/tashrifsanil/org-easy-img-insert"
  :commit "3efb4d70e5a39bfbf7ee4c4033cc61afa89430dd"
  :revdesc "3efb4d70e5a3"
  :keywords '("convenience" "hypermedia" "files")
  :authors '(("Tashrif Sanil" . "tashrifsanil@kloke-source.com"))
  :maintainers '(("Tashrif Sanil" . "tashrifsanil@kloke-source.com")))
