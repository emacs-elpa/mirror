;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.2.1.0.20260724.32"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "1393c9b40b4c6d620e7d303c07f728f14e101a52"
  :revdesc "1393c9b40b4c"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
