;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "4.5.0.20261106.390"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "7922429acd7b46e237873f26533a20f67490ad3f"
  :revdesc "v4.5-390-g7922429acd7b"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
