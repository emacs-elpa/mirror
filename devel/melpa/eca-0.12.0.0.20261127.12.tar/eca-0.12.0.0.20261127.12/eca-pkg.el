;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "0.12.0.0.20261127.12"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "07dc7ee246372f9508605312fdbcde5edd0b4b0d"
  :revdesc "07dc7ee24637"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
