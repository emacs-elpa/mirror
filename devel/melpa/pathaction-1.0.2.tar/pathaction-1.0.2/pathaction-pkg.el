;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "1.0.2"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "19dc91a8da6574dc7f80b263cc3a909be1c300e4"
  :revdesc "1.0.2-0-g19dc91a8da65"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
