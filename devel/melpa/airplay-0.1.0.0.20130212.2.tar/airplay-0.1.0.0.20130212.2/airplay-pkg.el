;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "airplay" "0.1.0.0.20130212.2"
  "Airplay bindings to Emacs."
  '((request      "20130110.2144")
    (simple-httpd "1.4.1")
    (deferred     "0.3.1"))
  :url "https://github.com/gongo/airplay-el"
  :commit "46fad71d293a3e18551cf464fe6c6208a7a32d9d"
  :revdesc "46fad71d293a"
  :keywords '("appletv" "airplay")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
