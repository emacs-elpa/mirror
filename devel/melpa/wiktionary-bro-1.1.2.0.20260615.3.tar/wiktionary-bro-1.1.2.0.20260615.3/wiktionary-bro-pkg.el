;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wiktionary-bro" "1.1.2.0.20260615.3"
  "Lookup Wiktionary entries."
  '((emacs   "30.1")
    (request "0.3.3"))
  :url "https://github.com/agzam/wiktionary-bro.el"
  :commit "bf53a1b3ce71ecf13d3b8a7aa0ba3a66bcf3f2a1"
  :revdesc "bf53a1b3ce71"
  :keywords '("convenience" "multimedia")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
