;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ninetyfive" "0.1.0.0.20260213.50"
  "NinetyFive."
  '((emacs     "26.1")
    (websocket "1.12")
    (async     "1.9.7"))
  :url "https://github.com/numerataz/ninetyfive.el"
  :commit "f2af587f97168e3544e770e74690cf0d7877c250"
  :revdesc "f2af587f9716"
  :keywords '("convenience" "productivity"))
