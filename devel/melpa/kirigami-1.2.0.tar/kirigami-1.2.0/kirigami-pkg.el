;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "1.2.0"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "64af455922935d83b5c77d2b8aec5ab11b246962"
  :revdesc "1.2.0-0-g64af45592293"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
