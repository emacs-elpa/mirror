;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jazz-theme" "1.0.0.20230814.85"
  "A warm color theme for Emacs 24+."
  ()
  :url "https://github.com/donderom/jazz-theme"
  :commit "b936b392e3ea3b6968530e3d5e5fccb9c454b5f8"
  :revdesc "b936b392e3ea"
  :authors '(("Roman Parykin" . "donderom@ymail.com"))
  :maintainers '(("Roman Parykin" . "donderom@ymail.com")))
