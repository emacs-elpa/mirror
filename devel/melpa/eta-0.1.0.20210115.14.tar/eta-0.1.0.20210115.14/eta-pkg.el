;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eta" "0.1.0.20210115.14"
  "Standard and multi dispatch key bind."
  '((emacs "25.1")
    (ht    "2.2")
    (dash  "2.17"))
  :url "https://www.github.com/zcaudate/eta"
  :commit "651f96c46eeb7ff8a0f0efcfacad5b4d25bfaa4b"
  :revdesc "651f96c46eeb"
  :keywords '("convenience" "usability"))
