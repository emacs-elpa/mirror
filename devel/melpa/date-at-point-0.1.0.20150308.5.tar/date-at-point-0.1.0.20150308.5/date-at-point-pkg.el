;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "date-at-point" "0.1.0.20150308.5"
  "Add `date' to `thing-at-point' function."
  ()
  :url "https://github.com/alezost/date-at-point.el"
  :commit "258c0268cc4357640c2af78774ba9667beff28ee"
  :revdesc "258c0268cc43"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
