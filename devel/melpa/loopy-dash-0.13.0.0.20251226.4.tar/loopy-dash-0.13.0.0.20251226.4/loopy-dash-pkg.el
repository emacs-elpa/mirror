;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy-dash" "0.13.0.0.20251226.4"
  "Dash destructuring for `loopy'."
  '((emacs "28.1")
    (loopy "0.13.0")
    (dash  "2.20"))
  :url "https://github.com/okamsn/loopy-dash"
  :commit "d60c4f49a640541e415e5471ad26c2d8e6886888"
  :revdesc "d60c4f49a640"
  :keywords '("extensions"))
