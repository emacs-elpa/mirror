;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "1.11.4.0.20261017.1"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "5f739885621b4b9f5f58302e02bdff86123eefc5"
  :revdesc "5f739885621b"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
