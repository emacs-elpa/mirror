;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wedge-ws" "0.2.0"
  "Wedge whitespace between columns in text."
  ()
  :url "https://github.com/aes/wedge-ws"
  :commit "4669115f02d9c6fee067cc5369bb38c0f9db88b2"
  :revdesc "4669115f02d9"
  :keywords '("formatting" "indentation")
  :authors '(("Anders Eurenius" . "aes@spotify.com"))
  :maintainers '(("Anders Eurenius" . "aes@spotify.com")))
