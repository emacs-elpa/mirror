;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yankpad" "1.6.0.20261122.97"
  "Paste snippets from an org-mode file."
  '((emacs "25.1"))
  :url "https://github.com/Kungsgeten/yankpad"
  :commit "d10c6260ee1d246832e36d5a9734df48ba8be648"
  :revdesc "d10c6260ee1d"
  :keywords '("abbrev" "convenience"))
