;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-treeview" "1.4.0.0.20260926.6"
  "A directory tree browser and simple file manager."
  '((emacs    "29.1")
    (treeview "1.4.0"))
  :url "https://github.com/tilmanrassy/emacs-dir-treeview"
  :commit "15c8b15e6e3f97f467d3e8b65313cb0795bb18ff"
  :revdesc "v1.4.0-6-g15c8b15e6e3f"
  :keywords '("tools" "convenience" "files")
  :authors '(("Tilman Rassy" . "tilman.rassy@googlemail.com"))
  :maintainers '(("Tilman Rassy" . "tilman.rassy@googlemail.com")))
