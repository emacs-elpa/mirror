;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yuck-mode" "1.0.1.0.20230113.14"
  "Major mode for the yuck configuration language."
  '((emacs "25.1"))
  :url "https://github.com/mmcjimsey26/yuck-mode"
  :commit "e084416fa3e7f91bb429edbf7ff1585aa5674367"
  :revdesc "e084416fa3e7"
  :keywords '("languages" "yuck" "eww" "widgets"))
