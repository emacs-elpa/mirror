;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "paperless" "1.3.2"
  "A major mode for sorting and filing PDF documents."
  '((emacs  "29.1")
    (f      "0.11.0")
    (s      "1.10.0")
    (cl-lib "0.7.1"))
  :url "https://github.com/atgreen/paperless"
  :commit "ef2e7ef5aeaffa997794f5d6e27be6631ba05d34"
  :revdesc "ef2e7ef5aeaf"
  :keywords '("pdf" "convenience")
  :authors '(("Anthony Green" . "green@moxielogic.com"))
  :maintainers '(("Anthony Green" . "green@moxielogic.com")))
