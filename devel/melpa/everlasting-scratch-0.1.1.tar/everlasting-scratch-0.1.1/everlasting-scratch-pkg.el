;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "everlasting-scratch" "0.1.1"
  "The *scratch* that lasts forever."
  '((emacs "26.1"))
  :url "https://github.com/beacoder/everlasting-scratch"
  :commit "4180fd04183a24de44a920cc02ac5a3bbf23643f"
  :revdesc "4180fd04183a"
  :keywords '("convenience" "tool")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
