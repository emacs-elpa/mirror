;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "github-browse-file" "0.5.0.0.20160205.3"
  "View the file you're editing on GitHub."
  '((cl-lib "0.5"))
  :url "https://github.com/osener/github-browse-file"
  :commit "177667b8dac640f3dabacc4395e09451c5e88c53"
  :revdesc "177667b8dac6"
  :keywords '("convenience" "vc" "git" "github")
  :authors '(("Ozan Sener" . "ozan@ozansener.com"))
  :maintainers '(("Ozan Sener" . "ozan@ozansener.com")))
