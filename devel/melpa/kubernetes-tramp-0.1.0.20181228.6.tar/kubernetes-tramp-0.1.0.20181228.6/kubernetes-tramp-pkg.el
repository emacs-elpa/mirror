;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubernetes-tramp" "0.1.0.20181228.6"
  "TRAMP integration for kubernetes containers."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/gruggiero/kubernetes-tramp"
  :commit "8713571b66940f8f3f496b55baa23cdf1df7a869"
  :revdesc "8713571b6694"
  :keywords '("kubernetes" "convenience")
  :authors '(("Giovanni Ruggiero" . "giovanni.ruggiero+github@gmail.com"))
  :maintainers '(("Giovanni Ruggiero" . "giovanni.ruggiero+github@gmail.com")))
