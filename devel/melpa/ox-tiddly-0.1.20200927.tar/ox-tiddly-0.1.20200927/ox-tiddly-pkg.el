;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-tiddly" "0.1.20200927"
  "Org TiddlyWiki exporter."
  '((org   "8")
    (emacs "24.4"))
  :url "https://github.com/dfeich/org8-wikiexporters"
  :commit "3377d8732aa916e736ce5822c7a9a4fbdc894e37"
  :revdesc "3377d8732aa9"
  :keywords '("org")
  :authors '(("Derek Feichtinger" . "derek.feichtinger@psi.ch"))
  :maintainers '(("Derek Feichtinger" . "derek.feichtinger@psi.ch")))
