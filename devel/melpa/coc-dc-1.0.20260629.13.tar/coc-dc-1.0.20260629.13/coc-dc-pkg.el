;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coc-dc" "1.0.20260629.13"
  "A Clash of Clans damage calculator."
  '((emacs "27.2")
    (hydra "0.14.0"))
  :url "https://github.com/S0mbr3/coc-damage-calculator"
  :commit "c5bb252b1ed39c17796ef2b4dcaf66e1202cbd89"
  :revdesc "c5bb252b1ed3"
  :keywords '("games")
  :authors '(("S0mbr3" . "0xf2f@proton.me"))
  :maintainers '(("S0mbr3" . "0xf2f@proton.me")))
