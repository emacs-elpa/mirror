;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "1.0.0.20260628.225"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "e6e5fbfcb8beb520141edac647ccb76af9b71df6"
  :revdesc "e6e5fbfcb8be"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
