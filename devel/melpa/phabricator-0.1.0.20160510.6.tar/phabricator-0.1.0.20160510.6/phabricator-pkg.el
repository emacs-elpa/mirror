;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phabricator" "0.1.0.20160510.6"
  "Phabricator/Arcanist helpers for Emacs."
  '((emacs      "24.4")
    (dash       "1.0")
    (projectile "0.13.0")
    (s          "1.10.0")
    (f          "0.17.2"))
  :url "https://github.com/ajtulloch/phabricator.el"
  :commit "d09d6f059aea92d3b11c68664a5e80c901182ab8"
  :revdesc "d09d6f059aea"
  :keywords '("phabricator" "arcanist" "diffusion"))
