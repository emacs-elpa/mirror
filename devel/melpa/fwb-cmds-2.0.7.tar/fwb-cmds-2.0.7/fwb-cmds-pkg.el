;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fwb-cmds" "2.0.7"
  "Misc frame, window and buffer commands."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/tarsius/fwb-cmds"
  :commit "ceaef86755e00bf2bdbe6873897c9ec3cae14d3f"
  :revdesc "v2.0.7-0-gceaef86755e0"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.fwb-cmds@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.fwb-cmds@jonas.bernoulli.dev")))
