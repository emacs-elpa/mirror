;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nix-modeline" "1.1.0"
  "Info about in-progress Nix evaluations on your modeline."
  '((emacs "25.1"))
  :url "https://github.com/ocelot-project/nix-modeline"
  :commit "9a6116a11bdacf649f2c50ae1f2f4b12c03bed70"
  :revdesc "9a6116a11bda"
  :keywords '("processes" "unix" "tools")
  :authors '(("Jordan Mulcahey" . "snhjordy@gmail.com"))
  :maintainers '(("Jordan Mulcahey" . "snhjordy@gmail.com")))
