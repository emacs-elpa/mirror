;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "twilight-theme" "1.0.0"
  "Twilight theme for GNU Emacs 24 (deftheme)."
  ()
  :url "https://github.com/developernotes/twilight-theme"
  :commit "77c4741cb3dcf16e53d06d6c2ffdc660c40afb5b"
  :revdesc "77c4741cb3dc"
  :authors '(("Nick Parker" . "nickp@developernotes.com"))
  :maintainers '(("Nick Parker" . "nickp@developernotes.com")))
