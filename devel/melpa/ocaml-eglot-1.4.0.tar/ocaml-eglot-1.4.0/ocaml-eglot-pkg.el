;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocaml-eglot" "1.4.0"
  "An OCaml companion for Eglot."
  '((emacs "29.1"))
  :url "https://github.com/tarides/ocaml-eglot"
  :commit "d7bf5ea2cdc945d950e6474f9baeabcd473a3fde"
  :revdesc "d7bf5ea2cdc9"
  :keywords '("ocaml" "languages")
  :authors '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com"))
  :maintainers '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com")))
