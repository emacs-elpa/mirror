;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql-ql" "0.2.0.20260322.90"
  "Intgrating org-roam and org-ql."
  '((emacs       "28")
    (org-roam-ql "0.1")
    (org-ql      "0.8.2")
    (org-roam    "2.2.0")
    (s           "1.12.0")
    (transient   "0.4"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "b6b6a25029503c27c2d4e4e0ca17a0ab82611470"
  :revdesc "b6b6a2502950")
