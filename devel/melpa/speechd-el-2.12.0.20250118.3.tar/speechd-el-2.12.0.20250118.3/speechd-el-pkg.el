;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speechd-el" "2.12.0.20250118.3"
  "Info file for package managers."
  ()
  :url "https://github.com/brailcom/speechd-el"
  :commit "0e509d392c7f82ca2451a59b97d551382136d2d5"
  :revdesc "0e509d392c7f"
  :authors '(("Milan Zamazal" . "pdm@zamazal.org"))
  :maintainers '(("Milan Zamazal" . "pdm@zamazal.org")))
