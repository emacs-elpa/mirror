;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "equake" "0.991111.0.20260102.15"
  "Drop-down console for (e)shell & terminal emulation."
  '((emacs "27.1")
    (dash  "2.14.1"))
  :url "https://github.com/emacsomancer/equake"
  :commit "4469dd9eb1519f4d699d43d6cdb3a59488021fe8"
  :revdesc "4469dd9eb151"
  :keywords '("convenience" "frames" "terminals" "tools" "window-system")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
