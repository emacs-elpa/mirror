;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.3.0.20261002.1"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "75f895b51cbe74400f446805a320741d2f35c307"
  :revdesc "75f895b51cbe"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
