;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wfnames" "1.2.0.20260105.3"
  "Edit filenames."
  '((emacs "24.4"))
  :url "https://github.com/thierryvolpiatto/wfnames"
  :commit "6ea49841ab76f44c0164b9f4722da2f9d46228da"
  :revdesc "v1.2-3-g6ea49841ab76"
  :keywords '("wfnames" "convenience" "files" "editing" "helm")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
