;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3.0.20261106.141"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "90e379dcea04eae527a4b7ff088551bdb1929eb6"
  :revdesc "90e379dcea04"
  :keywords '("build tools" "languages"))
