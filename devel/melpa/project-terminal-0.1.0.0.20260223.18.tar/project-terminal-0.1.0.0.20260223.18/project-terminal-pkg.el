;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-terminal" "0.1.0.0.20260223.18"
  "Per-project terminal management."
  '((emacs "28.1"))
  :url "https://github.com/cowboyd/project-terminal.el"
  :commit "79a4cb4fe4bd30c4088f634a108ef24b54769943"
  :revdesc "79a4cb4fe4bd"
  :keywords '("terminals" "projects" "convenience")
  :authors '(("Charles Lowell" . "cowboyd@frontside.com"))
  :maintainers '(("Charles Lowell" . "cowboyd@frontside.com")))
