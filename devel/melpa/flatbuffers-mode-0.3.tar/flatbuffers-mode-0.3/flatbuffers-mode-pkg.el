;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatbuffers-mode" "0.3"
  "Major mode for editing flatbuffers."
  '((emacs "24.3"))
  :url "https://github.com/Asalle/flatbuffers-mode"
  :commit "8e7783db45a64c9456130fd0c108ac12d45a7789"
  :revdesc "8e7783db45a6"
  :keywords '("flatbuffers" "languages")
  :authors '(("Asal Mirzaieva" . "asalle.kim@gmail.com"))
  :maintainers '(("Asal Mirzaieva" . "asalle.kim@gmail.com")))
