;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pet" "4.0.0.0.20251217.23"
  "Executable and virtualenv tracker for python-mode."
  '((emacs "27.1")
    (f     "0.6.0")
    (map   "3.3.1")
    (seq   "2.24"))
  :url "https://github.com/wyuenho/emacs-pet/"
  :commit "222f1da892462d7bea5c7a7bbcb6b5a5f4cb2158"
  :revdesc "222f1da89246"
  :keywords '("tools")
  :authors '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
