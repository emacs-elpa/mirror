;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-dart" "2.0.0"
  "Evaluate Dart source blocks in org-mode."
  '((emacs "24.4"))
  :url "http://github.org/mzimmerm/ob-dart"
  :commit "f6d5664d5cc8b15e002f6899f8adedcb10ced5f1"
  :revdesc "f6d5664d5cc8"
  :keywords '("languages"))
