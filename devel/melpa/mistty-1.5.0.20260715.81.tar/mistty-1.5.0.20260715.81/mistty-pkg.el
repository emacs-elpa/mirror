;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "1.5.0.20260715.81"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "879abed83287ab79b6d3dbdab7df2bf3fc68769a"
  :revdesc "879abed83287"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
