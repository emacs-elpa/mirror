;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sourcekit" "0.2.0.0.20210430.2"
  "Library to interact with sourcekittendaemon."
  '((emacs   "24.3")
    (dash    "2.18.0")
    (request "0.2.0"))
  :url "https://github.com/nathankot/company-sourcekit"
  :commit "a1860ad4dd3a542acd2fa0dfac2a388cbdf4af0c"
  :revdesc "a1860ad4dd3a"
  :keywords '("tools" "processes")
  :authors '(("Nathan Kot" . "nk@nathankot.com"))
  :maintainers '(("Nathan Kot" . "nk@nathankot.com")))
