;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sdlang-mode" "0.1.0.0.20161201.6"
  "Major mode for Simple Declarative Language files."
  '((emacs "24.3"))
  :url "https://github.com/CyberShadow/sdlang-mode"
  :commit "d42a6eedefeb44919fbacf58d302b6df18f05bbc"
  :revdesc "d42a6eedefeb"
  :keywords '("languages"))
