;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "0.2.0.20260917.52"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "9928f507d2759fd6dacc04e4daa255356834bca1"
  :revdesc "9928f507d275"
  :keywords '("faces" "files" "q"))
