;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emoji-fontset" "0.1.1"
  "Set font face for Emoji."
  ()
  :url "https://github.com/zonuexe/emoji-fontset.el"
  :commit "e460c9a08e48ec4103e38a7a04acae20880149a9"
  :revdesc "e460c9a08e48"
  :keywords '("emoji" "font" "config")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
