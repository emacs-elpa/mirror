;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-gfm" "1.0.0.20231215.7"
  "Github Flavored Markdown Back-End for Org Export Engine."
  ()
  :url "https://github.com/larstvei/ox-gfm"
  :commit "4f774f13d34b3db9ea4ddb0b1edc070b1526ccbb"
  :revdesc "4f774f13d34b"
  :keywords '("org" "wp" "markdown" "github"))
