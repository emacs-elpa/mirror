;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ron-mode" "1.0.20200830.7"
  "Rusty Object Notation mode."
  '((emacs "24.5.1"))
  :url "https://chiselapp.com/user/Hutzdog/repository/ron-mode/home"
  :commit "c5e0454b9916d6b73adc15dab8abbb0b0a68ea22"
  :revdesc "c5e0454b9916"
  :keywords '("languages")
  :authors '(("Daniel Hutzley" . "endergeryt@gmail.com"))
  :maintainers '(("Daniel Hutzley" . "endergeryt@gmail.com")))
