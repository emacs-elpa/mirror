;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "3.4.0.0.20260829.44"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "57b2ea3a093d67df5476bbf1f4e47798303b5974"
  :revdesc "57b2ea3a093d"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
