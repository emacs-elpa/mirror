;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leuven-theme" "2.6.812.0.20260824.1"
  "Elegant Emacs color theme for a white background."
  ()
  :url "https://github.com/fniessen/emacs-leuven-theme"
  :commit "c6cce6185125fa5e2172c29d59aa76e8325537ea"
  :revdesc "v2.6.0812-1-gc6cce6185125"
  :keywords '("color" "theme")
  :authors '(("Fabrice Niessen" . ""))
  :maintainers '(("Fabrice Niessen" . "")))
