;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "1.2.5.0.20260826.16"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "6b6b648127c3d3ac4b7e6ce0a701ddbb8325151c"
  :revdesc "1.2.5-16-g6b6b648127c3"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
