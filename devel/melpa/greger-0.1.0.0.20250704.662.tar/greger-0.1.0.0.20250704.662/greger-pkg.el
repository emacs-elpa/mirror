;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greger" "0.1.0.0.20250704.662"
  "Agentic coding environment with tool use, using Claude."
  '((emacs "29.1"))
  :url "https://github.com/andreasjansson/greger.el"
  :commit "b9591c30193cc764b23f1741fbb43159f85e945b"
  :revdesc "b9591c30193c"
  :keywords '("agent" "agentic" "ai" "chat" "language-models" "tools")
  :authors '(("Andreas Jansson" . "andreas@jansson.me.uk"))
  :maintainers '(("Andreas Jansson" . "andreas@jansson.me.uk")))
