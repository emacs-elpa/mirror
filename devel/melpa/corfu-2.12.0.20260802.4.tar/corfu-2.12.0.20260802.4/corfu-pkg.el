;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "2.12.0.20260802.4"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "4b440fb30ff2fff4291af676b59da7ab22130a45"
  :revdesc "2.12-4-g4b440fb30ff2"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
