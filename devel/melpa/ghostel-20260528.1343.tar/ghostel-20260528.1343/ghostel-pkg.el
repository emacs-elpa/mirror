;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260528.1343"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "393b74f7a36895c3551267cc165bc42be4a492db"
  :revdesc "393b74f7a368"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
