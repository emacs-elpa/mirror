;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doct" "3.2.0"
  "DOCT: Declarative Org capture templates."
  '((emacs "25.1"))
  :url "https://github.com/progfolio/doct"
  :commit "5cab660dab653ad88c07b0493360252f6ed1d898"
  :revdesc "5cab660dab65"
  :keywords '("org" "convenience")
  :authors '(("Nicholas Vollmer" . "progfolio@protonmail.com"))
  :maintainers '(("Nicholas Vollmer" . "progfolio@protonmail.com")))
