;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browser-gt" "0.94.0.20260821.21"
  "WebSocket bridge to a Chrome/Firefox extension."
  '((emacs     "30.1")
    (websocket "1.13")
    (org       "9.8"))
  :url "https://github.com/dmgerman/browser-gt"
  :commit "6117e1f4b70540a8f6986f6e647eedbd72e818e7"
  :revdesc "6117e1f4b705"
  :keywords '("comm" "tools" "browser" "org")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
