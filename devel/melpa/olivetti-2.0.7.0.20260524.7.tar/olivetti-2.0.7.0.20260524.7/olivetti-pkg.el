;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "olivetti" "2.0.7.0.20260524.7"
  "Minor mode to automatically balance window margins."
  '((emacs "24.4"))
  :url "https://github.com/rnkn/olivetti"
  :commit "d2ccae56b442d9c5b06dd2481057abbd7eb82551"
  :revdesc "v2.0.7-7-gd2ccae56b442"
  :keywords '("wp" "text")
  :authors '(("Paul W. Rankin" . "rnkn@rnkn.xyz"))
  :maintainers '(("Paul W. Rankin" . "rnkn@rnkn.xyz")))
