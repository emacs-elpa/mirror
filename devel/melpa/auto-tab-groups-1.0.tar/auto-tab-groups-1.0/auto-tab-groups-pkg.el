;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-tab-groups" "1.0"
  "Simple auto tab group creator for specified commands."
  '((emacs "29.1"))
  :url "https://github.com/MArpogaus/auto-tab-groups"
  :commit "bff1b91cefe31cf488f29cff2ab1b2095e52e3ce"
  :revdesc "v1.0-0-gbff1b91cefe3"
  :keywords '("convenience" "tabs")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
