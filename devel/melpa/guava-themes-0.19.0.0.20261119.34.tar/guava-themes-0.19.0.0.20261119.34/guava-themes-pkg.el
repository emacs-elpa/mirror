;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "0.19.0.0.20261119.34"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "a75e9e34ea43cce7036b6dbcc75d0d118ef4bd71"
  :revdesc "v0.19.0-34-ga75e9e34ea43"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
