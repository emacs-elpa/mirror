;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatland-theme" "0.1.2.0.20171113.13"
  "A simple theme for Emacs based on the Flatland theme for Sublime Text."
  ()
  :url "https://github.com/gregchapple/flatland-emacs"
  :commit "a98a6f19ad4dff0fa3fad1ea487b7d0ef634a19a"
  :revdesc "a98a6f19ad4d"
  :authors '(("Greg Chapple" . "info@gregchapple.com"))
  :maintainers '(("Greg Chapple" . "info@gregchapple.com")))
