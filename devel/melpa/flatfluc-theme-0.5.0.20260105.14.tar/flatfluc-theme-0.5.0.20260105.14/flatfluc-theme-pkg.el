;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatfluc-theme" "0.5.0.20260105.14"
  "Custom merge of flucui and flatui themes."
  '((emacs "26.1"))
  :url "https://github.com/seblemaguer/flatfluc-theme"
  :commit "483f25a8d5c332851f0b216bee58e33e95632769"
  :revdesc "483f25a8d5c3"
  :keywords '("lisp")
  :authors '(("Sébastien Le Maguer" . "lemagues@tcd.ie"))
  :maintainers '(("Sébastien Le Maguer" . "lemagues@tcd.ie")))
