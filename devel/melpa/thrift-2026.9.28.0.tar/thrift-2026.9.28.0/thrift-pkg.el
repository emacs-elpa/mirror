;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.9.28.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "a32e117aa420392a893249d0732055e4f8e3a917"
  :revdesc "a32e117aa420"
  :keywords '("languages"))
