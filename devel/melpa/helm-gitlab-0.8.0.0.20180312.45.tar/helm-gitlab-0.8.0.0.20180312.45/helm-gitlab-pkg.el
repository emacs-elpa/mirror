;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-gitlab" "0.8.0.0.20180312.45"
  "Helm interface to Gitlab."
  '((s      "1.9.0")
    (dash   "2.9.0")
    (helm   "1.0")
    (gitlab "0.8.0"))
  :url "https://github.com/nlamirault/emacs-gitlab"
  :commit "68318aca3206d50701039c9aae39734ca29a49f9"
  :revdesc "68318aca3206"
  :keywords '("gitlab" "helm")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
