;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calendar-norway" "0.9.5.0.20220211.2"
  "Norwegian calendar."
  ()
  :url "https://github.com/unhammer/calendar-norway.el"
  :commit "0db0ea63365f4ff5f7d18fb8335fa88af194a2cc"
  :revdesc "0.9.5-2-g0db0ea63365f"
  :keywords '("calendar" "norwegian" "localization")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
