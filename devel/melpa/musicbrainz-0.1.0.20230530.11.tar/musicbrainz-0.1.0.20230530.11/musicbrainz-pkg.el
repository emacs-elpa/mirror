;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "musicbrainz" "0.1.0.20230530.11"
  "MusicBrainz API interface."
  '((emacs   "28.1")
    (request "0.3"))
  :url "https://github.com/zzkt/metabrainz"
  :commit "986690a515e67526598eaa4200bd383f03a007bd"
  :revdesc "986690a515e6"
  :keywords '("music" "scrobbling" "multimedia")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
