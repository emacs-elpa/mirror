;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mixed-pitch" "1.1.1.0.20210304.4"
  "Use a variable pitch, keeping fixed pitch where it's sensible."
  '((emacs "24.3"))
  :url "https://gitlab.com/jabranham/mixed-pitch"
  :commit "519e05f74825abf04b7d2e0e38ec040d013a125a"
  :revdesc "519e05f74825"
  :authors '(("J. Alexander Branham" . "branham@utexas.edu"))
  :maintainers '(("J. Alexander Branham" . "branham@utexas.edu")))
