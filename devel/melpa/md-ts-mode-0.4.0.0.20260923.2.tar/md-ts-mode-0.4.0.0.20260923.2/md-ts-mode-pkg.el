;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "md-ts-mode" "0.4.0.0.20260923.2"
  "Major mode for Markdown using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/dnouri/md-ts-mode"
  :commit "c6f0bc5cb505ac82802ef588a6a9bc085c823c2f"
  :revdesc "v0.4.0-2-gc6f0bc5cb505"
  :keywords '("markdown" "languages" "tree-sitter")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
