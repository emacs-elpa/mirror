;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lirve" "1.3.0"
  "Learn irregular verbs in English."
  '((emacs "26.1"))
  :url "https://github.com/tanrax/lirve.el"
  :commit "287f5995e026787f2930e6892874f78c421203f0"
  :revdesc "287f5995e026"
  :authors '(("Andros Fenollosa" . "andros@fenollosa.email"))
  :maintainers '(("Andros Fenollosa" . "andros@fenollosa.email")))
