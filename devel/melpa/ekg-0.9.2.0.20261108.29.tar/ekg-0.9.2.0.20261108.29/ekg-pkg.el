;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "0.9.2.0.20261108.29"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "29.1")
    (llm     "0.30.0")
    (vui     "20261030.946"))
  :url "https://github.com/ahyatt/ekg"
  :commit "7a0bc6c3fb33950aed588a3983b5ad7ba4a7fbe8"
  :revdesc "7a0bc6c3fb33"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
