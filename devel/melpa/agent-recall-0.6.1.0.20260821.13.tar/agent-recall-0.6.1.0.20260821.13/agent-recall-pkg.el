;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "0.6.1.0.20260821.13"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "8c9cfc200a5c08bffd6d9415f2719382cf481640"
  :revdesc "8c9cfc200a5c"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
