;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php" "2.8.0"
  "Auto Completion source for PHP."
  '((ac-php-core   "2.0")
    (auto-complete "1.4.0")
    (yasnippet     "0.8.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "a2a89494fd2e53111a81227d2e35290e0825c3fb"
  :revdesc "v2.8.0-0-ga2a89494fd2e"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
