;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inline-crypt" "0.1.4.0.20170824.2"
  "Simple inline encryption via openssl."
  ()
  :url "https://github.com/Sodel-the-Vociferous/inline-crypt-el"
  :commit "af4981c613bfd355d5ef34da1995a8384f167fd9"
  :revdesc "af4981c613bf"
  :keywords '("crypt")
  :authors '(("Daniel Ralston" . "Wubbulous@gmail.com"))
  :maintainers '(("Daniel Ralston" . "Wubbulous@gmail.com")))
