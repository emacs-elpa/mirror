;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent-harness" "0.3.3.0.20260909.72"
  "Autonomous coding-agent harness for gptel-agent."
  '((emacs       "29.1")
    (compat      "30.1.0.0")
    (gptel       "0.9.9")
    (gptel-agent "0.0.1"))
  :url "https://github.com/beacoder/gptel-agent-harness"
  :commit "a808a1ca67057d88e769d56a50100744037cb534"
  :revdesc "a808a1ca6705"
  :keywords '("programming" "convenience" "ai" "agent")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
