;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "2.0.1.0.20260918.4"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "37fd8765e112f3125f2500a1e08328066dd56b19"
  :revdesc "37fd8765e112"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
