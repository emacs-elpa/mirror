;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smeargle" "0.3.0.20200323.3"
  "Highlighting region by last updated time."
  '((emacs "24.3"))
  :url "https://github.com/emacsorphanage/smeargle"
  :commit "1c5c1e1d66aa96b818fbfcdf9fbec84e509b87be"
  :revdesc "1c5c1e1d66aa"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com")))
