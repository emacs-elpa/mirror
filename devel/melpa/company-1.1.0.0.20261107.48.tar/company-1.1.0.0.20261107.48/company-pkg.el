;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "1.1.0.0.20261107.48"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "7c50b45870fa4e95d60c28e2ea9281c0295a486c"
  :revdesc "1.1.0-48-g7c50b45870fa"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
