;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chordpro-mode" "2.7.0.0.20260711.1"
  "Major mode for ChordPro lead sheet file format."
  '((emacs  "29.1")
    (compat "29.1.4.1"))
  :url "https://git.sr.ht/~breatheoutbreathein/chordpro-mode.el/"
  :commit "9d7b242b06453aaaa3fb3d1cca438ebcd478979b"
  :revdesc "2.7.0-1-g9d7b242b0645"
  :keywords '("convenience")
  :authors '(("Howard Ding" . "hading2@gmail.com"))
  :maintainers '(("Howard Ding" . "hading2@gmail.com")))
