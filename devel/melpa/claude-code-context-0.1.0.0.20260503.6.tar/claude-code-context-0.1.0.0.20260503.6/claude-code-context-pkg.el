;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claude-code-context" "0.1.0.0.20260503.6"
  "Share buffer context with Claude Code."
  '((emacs "27.1"))
  :url "https://github.com/lukehoersten/claude-code-context"
  :commit "1e9062b0bc5e0d4f3f9f98a349b6ed9c775360ca"
  :revdesc "1e9062b0bc5e"
  :keywords '("tools" "ai" "convenience")
  :authors '(("Luke Hoersten" . "Luke@Hoersten.org"))
  :maintainers '(("Luke Hoersten" . "Luke@Hoersten.org")))
