;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "haskell-tab-indent" "0.3"
  "Tab-based indentation for haskell-mode."
  ()
  :url "https://spwhitton.name/tech/code/haskell-tab-indent/"
  :commit "1127f46eca40a48be9cd2380df2cfc5f0b694e63"
  :revdesc "0.3-0-g1127f46eca40"
  :keywords '("indentation" "haskell")
  :authors '(("Sean Whitton" . "spwhitton@spwhitton.name"))
  :maintainers '(("Sean Whitton" . "spwhitton@spwhitton.name")))
