;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.3.0.20260819.57"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "997bca9b96ad9287619e485af8b860f7f1b016fa"
  :revdesc "997bca9b96ad"
  :keywords '("build tools" "languages"))
