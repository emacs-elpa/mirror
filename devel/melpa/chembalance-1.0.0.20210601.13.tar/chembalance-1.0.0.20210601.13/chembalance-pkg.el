;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chembalance" "1.0.0.20210601.13"
  "Balance chemical equations."
  '((emacs "24.4"))
  :url "https://github.com/sergiruiztrepat/chembalance"
  :commit "ae36c823ca151f1dc6144ec96b2f5e98181c0dbb"
  :revdesc "ae36c823ca15"
  :keywords '("convenience" "chemistry"))
