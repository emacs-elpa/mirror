;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devops" "0.1.0.0.20261018.33"
  "Infrastructure as an org file."
  '((emacs "30.1"))
  :url "https://github.com/kpassapk/devops.el"
  :commit "d5125c96dbd83accb39ae8f68ee0926ae1c09698"
  :revdesc "d5125c96dbd8"
  :keywords '("tools" "processes" "outlines")
  :authors '(("Kyle S Passarelli" . "kyle.passarelli@gmail.com"))
  :maintainers '(("Kyle S Passarelli" . "kyle.passarelli@gmail.com")))
