;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "2.9.1.0.20260902.5"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.3.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "be3ca87badb5438535897d85232e59f9edec385b"
  :revdesc "v2.9.1-5-gbe3ca87badb5"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
