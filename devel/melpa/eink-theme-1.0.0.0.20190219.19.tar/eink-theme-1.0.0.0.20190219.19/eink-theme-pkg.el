;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eink-theme" "1.0.0.0.20190219.19"
  "E Ink color theme."
  ()
  :url "https://github.com/maio/eink-emacs"
  :commit "326b07523dcb076d6209cdbc7fdbb73df296dbdb"
  :revdesc "326b07523dcb"
  :authors '(("Marian Schubert" . "marian.schubert@gmail.com"))
  :maintainers '(("Marian Schubert" . "marian.schubert@gmail.com")))
