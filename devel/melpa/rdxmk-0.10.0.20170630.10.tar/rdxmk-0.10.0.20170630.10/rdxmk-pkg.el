;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rdxmk" "0.10.0.20170630.10"
  "A small set of tools for redox developments."
  ()
  :url "https://github.com/jsalzbergedu/rdxmk"
  :commit "e78749fb29738365ffa4d863ffabeb969ebb0bcf"
  :revdesc "e78749fb2973"
  :keywords '("redox" "convenience" "tools")
  :authors '(("Jacob Salzberg" . "jsalzbergedu@yahoo.com"))
  :maintainers '(("Jacob Salzberg" . "jsalzbergedu@yahoo.com")))
