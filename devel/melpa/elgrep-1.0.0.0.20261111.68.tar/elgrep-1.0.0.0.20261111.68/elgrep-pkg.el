;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elgrep" "1.0.0.0.20261111.68"
  "Searching files for regular expressions."
  '((emacs "26.2")
    (async "1.5"))
  :url "https://github.com/TobiasZawada/elgrep"
  :commit "2af18694dd8862a364d35c404a9697c333517507"
  :revdesc "2af18694dd88"
  :keywords '("tools" "matching" "files" "unix")
  :authors '(("Tobias Zawada" . "i@tn-home.de"))
  :maintainers '(("Tobias Zawada" . "i@tn-home.de")))
