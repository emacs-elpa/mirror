;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess-r-insert-obj" "1.0.0.20220610.13"
  "Insert objects in ESS-R."
  '((emacs "26.1")
    (ess   "18.10.1"))
  :url "https://github.com/ShuguangSun/ess-r-insert-obj"
  :commit "2ded9c23d0af2a7f6c0e02f9ea4af0e5b3cb7fb4"
  :revdesc "2ded9c23d0af"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
