;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "1.0.0.20261028.247"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "91e8ac05d8983029a45b58fc2e405bfb947f7f12"
  :revdesc "91e8ac05d898"
  :keywords '("convenience" "text"))
