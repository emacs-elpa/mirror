;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slothbar" "0.30.2.0.20260913.1"
  "Emacs X window manager status bar."
  '((all-the-icons "5.0.0")
    (backlight     "1.4")
    (compat        "29.1")
    (dash          "2.1.0")
    (f             "0.20.0")
    (fontsloth     "0.19.1")
    (log4e         "0.3.3")
    (nerd-icons    "0.1.0")
    (s             "1.12.0")
    (volume        "1.0")
    (xelb          "0.18")
    (emacs         "28.1"))
  :url "https://codeberg.org/agnes-li/slothbar"
  :commit "5b1b7f5c45e5e468754c6e676e97223529cd4575"
  :revdesc "v0.30.2-1-g5b1b7f5c45e5"
  :keywords '("frames" "hardware")
  :authors '(("Jo Gay" . "jo.gay@mailfence.com")
             ("Agnes Li" . "agnes.li@mailfence.com"))
  :maintainers '(("Jo Gay" . "jo.gay@mailfence.com")
                 ("Agnes Li" . "agnes.li@mailfence.com")))
