;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liblouis" "0.2.0.20220426.2"
  "Mode for editing liblouis braille translation tables."
  '((emacs "26.1"))
  :url "https://github.com/liblouis/liblouis-mode"
  :commit "a341a0c434cdbe7f46956c8db13203c3fc941a34"
  :revdesc "v0.2-2-ga341a0c434cd"
  :keywords '("languages")
  :authors '(("Christian Egli" . "christian.egli@sbs.ch"))
  :maintainers '(("Christian Egli" . "christian.egli@sbs.ch")))
