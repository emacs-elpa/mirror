;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "0.1.0.0.20261029.201"
  "Manage multiple AI coding agents."
  '((emacs         "28.1")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (magit-section "3.3.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "3227814626b40f39475c3f2c391c58134a812676"
  :revdesc "3227814626b4"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
