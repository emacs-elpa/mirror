;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popup-switcher" "0.2.14.0.20210402.20"
  "Switch to other buffers and files via popup."
  '((cl-lib "0.3")
    (popup  "0.5.3")
    (dash   "2.10.0"))
  :url "https://github.com/kostafey/popup-switcher"
  :commit "94e01b9ea7970e86ed0f2fbeaa8cd320b60ae821"
  :revdesc "94e01b9ea797"
  :keywords '("popup" "switch" "buffers" "functions")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
