;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotated-completing-read" "0.1.0.20261016.59"
  "Ergonomic completing-read wrapper/helper."
  '((emacs "29.1"))
  :url "https://github.com/tychoish/annotated-completing-read"
  :commit "c0cd30d201d75e45912f811799ee45e41ef808c7"
  :revdesc "c0cd30d201d7"
  :keywords '("convenience" "matching")
  :authors '(("sam kleinman" . "garen@tychoish.com"))
  :maintainers '(("sam kleinman" . "garen@tychoish.com")))
