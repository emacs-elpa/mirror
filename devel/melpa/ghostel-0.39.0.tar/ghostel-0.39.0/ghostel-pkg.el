;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.39.0"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "92bfcc57dc85f254ce95dcb51dbdd2411fea5f02"
  :revdesc "92bfcc57dc85"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
