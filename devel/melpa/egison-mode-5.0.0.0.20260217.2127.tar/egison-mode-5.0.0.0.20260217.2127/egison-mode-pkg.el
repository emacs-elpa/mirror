;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "egison-mode" "5.0.0.0.20260217.2127"
  "Egison editing mode."
  ()
  :url "https://github.com/egisatoshi/egison/blob/master/emacs/egison-mode.el"
  :commit "448dc7ee9db1e2778261f295715fcb64496ba19e"
  :revdesc "448dc7ee9db1"
  :authors '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainers '(("Satoshi Egi" . "egisatoshi@gmail.com")))
