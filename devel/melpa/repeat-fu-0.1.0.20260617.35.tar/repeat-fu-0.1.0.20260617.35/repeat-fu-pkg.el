;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "0.1.0.20260617.35"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "4d30d92a1fc3b5f0207866685de16cb78b83337c"
  :revdesc "4d30d92a1fc3"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
