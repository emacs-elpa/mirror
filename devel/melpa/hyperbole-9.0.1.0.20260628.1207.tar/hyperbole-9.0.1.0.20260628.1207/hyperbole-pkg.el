;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.0.1.0.20260628.1207"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "4124a0a192503aeffe3806ffa6f59e5bc22eea3d"
  :revdesc "4124a0a19250"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
