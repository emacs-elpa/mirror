;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-crystal" "0.1.0.0.20180119.2"
  "Run a Inferior-Crystal process in a buffer."
  '((emacs        "24.3")
    (crystal-mode "0.1.0"))
  :url "https://github.com/brantou/inf-crystal.el"
  :commit "dd5c85e621976ea09b602182a15396e3b510ec63"
  :revdesc "dd5c85e62197"
  :keywords '("languages" "crystal")
  :authors '(("Brantou" . "brantou89@gmail.com"))
  :maintainers '(("Brantou" . "brantou89@gmail.com")))
