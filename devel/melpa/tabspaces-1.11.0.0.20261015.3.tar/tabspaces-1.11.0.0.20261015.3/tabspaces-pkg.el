;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "1.11.0.0.20261015.3"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://codeberg.org/mclear-tools/tabspaces"
  :commit "d45bf0db847ed7de47b85dee61926506e3c1995a"
  :revdesc "d45bf0db847e"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
