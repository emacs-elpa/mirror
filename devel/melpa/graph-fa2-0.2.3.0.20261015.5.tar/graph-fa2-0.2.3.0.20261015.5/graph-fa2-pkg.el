;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graph-fa2" "0.2.3.0.20261015.5"
  "ForceAtlas2 pure-elisp background-cached engine."
  '((emacs "27.1"))
  :url "https://github.com/elij/graph-fa2"
  :commit "32040244072200f3a70faad142b98bb88738b1ba"
  :revdesc "320402440722"
  :keywords '("multimedia" "graphs" "visualization")
  :authors '(("Elijah Charles" . "https://github.com/elij"))
  :maintainers '(("Elijah Charles" . "https://github.com/elij")))
