;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-pry" "1.0.0.0.20201011.5"
  "Realgud front-end to the Ruby pry debugger."
  '((realgud       "1.4.5")
    (load-relative "1.2")
    (cl-lib        "0.5")
    (emacs         "25"))
  :url "https://github.com/rocky/realgud-pry"
  :commit "264ca6811b0bef5de4decc54acfeacf0bce2f51f"
  :revdesc "264ca6811b0b")
