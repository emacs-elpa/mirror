;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "0.50.0"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.42.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "5143313e07ba8a6b095f85154e6345f87479d63e"
  :revdesc "5143313e07ba"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
