;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buttercup" "1.41"
  "Behavior-Driven Emacs Lisp Testing."
  '((emacs "24.4"))
  :url "https://github.com/jorgenschaefer/emacs-buttercup"
  :commit "3bcf6cf0e164d558072a484f467169a0e77bd791"
  :revdesc "v1.41-0-g3bcf6cf0e164"
  :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainers '(("Ola Nilsson" . "ola.nilsson@gmail.com")))
