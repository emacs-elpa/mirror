;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "1.1.5.0.20260826.5"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "c2653f3bb2d102ae62901fb42da1507bdf60cff5"
  :revdesc "1.1.5-5-gc2653f3bb2d1"
  :keywords '("convenience" "frames")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
