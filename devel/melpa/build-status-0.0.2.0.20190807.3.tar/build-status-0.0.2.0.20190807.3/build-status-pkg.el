;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "build-status" "0.0.2.0.20190807.3"
  "Mode line build status indicator."
  '((cl-lib "0.5"))
  :url "https://github.com/sshaw/build-status"
  :commit "1a1d2473aa62f2fdda47d8bfeb9fe352d2579b48"
  :revdesc "1a1d2473aa62"
  :keywords '("mode-line" "ci" "circleci" "travis-ci")
  :authors '(("Skye Shaw" . "skye.shaw@gmail.com"))
  :maintainers '(("Skye Shaw" . "skye.shaw@gmail.com")))
