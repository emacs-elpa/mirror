;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "countdown" "0.0.0.20190626.19"
  "Countdown using big LCD-like digits."
  '((emacs  "25.1")
    (stream "2.2.4"))
  :url "https://github.com/xuchunyang/countdown.el"
  :commit "139dea91fc818d65944aca5f16c9626abbdfbf04"
  :revdesc "139dea91fc81"
  :keywords '("tools")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
