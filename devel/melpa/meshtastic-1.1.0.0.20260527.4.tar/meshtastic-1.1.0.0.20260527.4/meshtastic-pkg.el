;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meshtastic" "1.1.0.0.20260527.4"
  "Chat client for Meshtastic LoRa devices via serial."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/meshtastic.el"
  :commit "5ad027669b3e652f704857e3d7e373095d1c09d1"
  :revdesc "5ad027669b3e"
  :keywords '("comm")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
