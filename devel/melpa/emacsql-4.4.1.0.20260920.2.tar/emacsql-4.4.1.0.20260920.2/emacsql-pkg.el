;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsql" "4.4.1.0.20260920.2"
  "High-level SQL database front-end."
  '((emacs "28.1"))
  :url "https://github.com/magit/emacsql"
  :commit "f3e2f688d1fe809163b68e2504d445d3a5c1d522"
  :revdesc "v4.4.1-2-gf3e2f688d1fe"
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.emacsql@jonas.bernoulli.dev")))
