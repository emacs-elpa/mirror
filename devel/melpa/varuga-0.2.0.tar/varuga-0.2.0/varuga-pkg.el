;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "varuga" "0.2.0"
  "Send ical calendar invites by email."
  '((emacs "27.1"))
  :url "https://git.systemreboot.net/varuga"
  :commit "f055e8572b2e4d7a700392b8a71bacbfdc8e442a"
  :revdesc "0.2.0-0-gf055e8572b2e"
  :authors '(("Arun Isaac" . "arunisaac@systemreboot.net"))
  :maintainers '(("Arun Isaac" . "arunisaac@systemreboot.net")))
