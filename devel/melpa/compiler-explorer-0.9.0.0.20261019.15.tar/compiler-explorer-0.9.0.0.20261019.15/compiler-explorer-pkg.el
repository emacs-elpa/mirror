;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compiler-explorer" "0.9.0.0.20261019.15"
  "Compiler explorer client (godbolt.org)."
  '((emacs "29.1")
    (plz   "0.9")
    (eldoc "1.15.0")
    (map   "3.3.1")
    (seq   "2.23"))
  :url "https://github.com/mkcms/compiler-explorer.el"
  :commit "5455b3757a837a3c87c20001c580e0187dbfffbd"
  :revdesc "v0.9.0-15-g5455b3757a83"
  :keywords '("c" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
