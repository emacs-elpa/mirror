;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inhibit-mouse" "1.0.4.0.20260629.4"
  "Deactivate mouse input (alternative to disable-mouse)."
  '((emacs "24.1"))
  :url "https://github.com/jamescherti/inhibit-mouse.el"
  :commit "affabbd3c07ea4b739cf9dc79633681588803e0a"
  :revdesc "1.0.4-4-gaffabbd3c07e"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
