;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-combo" "1.6.0.20230323.8"
  "Map key sequence to commands."
  ()
  :url "https://github.com/uk-ar/key-combo"
  :commit "16fb73522d53547ef38f3710aff7c0b01005d576"
  :revdesc "16fb73522d53"
  :keywords '("keyboard" "input")
  :authors '(("Yuuki Arisawa" . "yuuki.ari@gmail.com"))
  :maintainers '(("Vitalie Spinu" . "spinuvit@gmail.com")))
