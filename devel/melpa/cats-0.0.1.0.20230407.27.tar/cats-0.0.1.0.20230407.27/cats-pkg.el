;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cats" "0.0.1.0.20230407.27"
  "Monads for Elisp."
  '((emacs "26.1"))
  :url "https://github.com/Fuco1/emacs-cats"
  :commit "7fc70db0eeb2c33ffba5c13c4cdc0f31c7b95537"
  :revdesc "7fc70db0eeb2"
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
