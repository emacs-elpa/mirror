;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "racket-mode" "1.0.20260726.246"
  "Racket editing, REPL, and more."
  '((emacs  "25.1")
    (compat "30.0.2.0"))
  :url "https://www.racket-mode.com/"
  :commit "f92a33dcc3b604f53ef23a538e26e1f25c4fea47"
  :revdesc "f92a33dcc3b6"
  :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")))
