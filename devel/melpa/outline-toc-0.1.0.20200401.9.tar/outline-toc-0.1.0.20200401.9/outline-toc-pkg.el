;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-toc" "0.1.0.20200401.9"
  "Sidebar showing a \"table of contents\"."
  ()
  :url "https://github.com/abingham/outline-toc.el"
  :commit "81d373633b40628cc3a6b6fb534fd7730076bcdb"
  :revdesc "81d373633b40"
  :keywords '("convenience" "outlines")
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
