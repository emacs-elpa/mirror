;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-html" "0.31.0.20151005.37"
  "Auto complete source for html tags and attributes."
  '((auto-complete "1.4")
    (s             "1.9")
    (f             "0.17")
    (dash          "2.10"))
  :url "https://github.com/cheunghy/ac-html"
  :commit "3de94a46d8cb93e8e62a1b6bdebbde4d65dc7cc2"
  :revdesc "3de94a46d8cb"
  :keywords '("html" "auto-complete" "slim" "haml" "jade")
  :authors '(("Zhang Kai Yu" . "yeannylam@gmail.com"))
  :maintainers '(("Zhang Kai Yu" . "yeannylam@gmail.com")))
