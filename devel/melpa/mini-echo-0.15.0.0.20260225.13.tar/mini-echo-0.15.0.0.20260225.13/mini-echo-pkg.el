;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mini-echo" "0.15.0.0.20260225.13"
  "Echo buffer status in minibuffer window."
  '((emacs          "29.1")
    (hide-mode-line "1.0.3"))
  :url "https://github.com/eki3z/mini-echo.el"
  :commit "d5e5ab763184d0eac2b3dc72e1aac4a7b2e6762f"
  :revdesc "d5e5ab763184"
  :keywords '("frames")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
