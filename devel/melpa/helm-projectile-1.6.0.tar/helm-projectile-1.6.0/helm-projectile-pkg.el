;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-projectile" "1.6.0"
  "Helm integration for Projectile."
  '((emacs      "27.1")
    (helm       "3.0")
    (projectile "2.9"))
  :url "https://github.com/bbatsov/helm-projectile"
  :commit "aebebed88a2de239d21f08d823719d794df92871"
  :revdesc "aebebed88a2d"
  :keywords '("project" "convenience"))
