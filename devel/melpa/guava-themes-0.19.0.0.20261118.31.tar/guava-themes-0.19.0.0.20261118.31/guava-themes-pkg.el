;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "0.19.0.0.20261118.31"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "1bb902369888beb05d8530a3853164e993048381"
  :revdesc "v0.19.0-31-g1bb902369888"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
