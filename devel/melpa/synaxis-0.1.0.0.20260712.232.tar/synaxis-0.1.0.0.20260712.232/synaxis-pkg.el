;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "synaxis" "0.1.0.0.20260712.232"
  "Feed reader with SQLite storage."
  '((emacs        "29.1")
    (keymap-popup "0.2.1"))
  :url "https://git.thanosapollo.org/synaxis"
  :commit "4a4b98050f74391beb45fe60bae874408f559573"
  :revdesc "4a4b98050f74"
  :keywords '("news" "hypermedia" "rss" "atom")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
