;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "0.5.2"
  "Create releases of Emacs packages."
  '((emacs    "30.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.7"))
  :url "https://github.com/magit/sisyphus"
  :commit "39f54bf415dcdb93f9c1ddc153470468eb198c29"
  :revdesc "v0.5.2-0-g39f54bf415dc"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
