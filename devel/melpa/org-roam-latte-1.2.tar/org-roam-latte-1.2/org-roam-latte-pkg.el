;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-latte" "1.2"
  "Auto-highlight unlinked Org-roam references."
  '((emacs       "27.1")
    (org-roam    "2.0")
    (inflections "1.1"))
  :url "https://github.com/yad-tahir/org-roam-latte"
  :commit "89b979be06195a435ab8dd8762c09221f96a5fd5"
  :revdesc "89b979be0619"
  :keywords '("hypermedia" "outlines" "org-roam" "convenience")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
