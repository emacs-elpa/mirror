;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "2.0.20261013.214"
  "30 new custom blocks & 34 link types for Org-mode."
  '((s        "1.13.1")
    (dash     "2.18.1")
    (emacs    "27.1")
    (org      "9.1")
    (lf       "26.10.1")
    (dad-joke "1.4")
    (seq      "2.0")
    (lolcat   "0"))
  :url "https://alhassy.github.io/org-special-block-extras"
  :commit "bf4c16418145761f821089b057ee9ebcfebceffc"
  :revdesc "bf4c16418145"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
