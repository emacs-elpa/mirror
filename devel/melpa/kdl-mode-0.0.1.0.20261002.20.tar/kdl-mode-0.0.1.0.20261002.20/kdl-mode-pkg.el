;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kdl-mode" "0.0.1.0.20261002.20"
  "Major mode for editing KDL files."
  '((emacs "29.1"))
  :url "https://github.com/taquangtrung/emacs-kdl-mode"
  :commit "e966ed4b53f8a72b88a016e61bcadec42f317e39"
  :revdesc "e966ed4b53f8"
  :keywords '("languages"))
