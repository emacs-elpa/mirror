;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bbdb" "1.1.0.20260719.48"
  "Helm interface for bbdb."
  '((emacs "26.1")
    (helm  "1.5")
    (bbdb  "3.1.2"))
  :url "https://github.com/emacs-helm/helm-bbdb"
  :commit "3eb99e36ed18ca2809594d165664af77a02d2bd0"
  :revdesc "v1.1-48-g3eb99e36ed18")
