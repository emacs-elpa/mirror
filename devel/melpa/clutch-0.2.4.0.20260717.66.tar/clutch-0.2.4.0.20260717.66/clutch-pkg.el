;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.2.4.0.20260717.66"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "227f6bb710c8f3c9ac34ef36daa12f14cbd10b53"
  :revdesc "227f6bb710c8"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
