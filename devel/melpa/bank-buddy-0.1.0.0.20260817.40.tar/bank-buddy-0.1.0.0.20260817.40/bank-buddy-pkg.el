;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bank-buddy" "0.1.0.0.20260817.40"
  "Financial analysis and reporting."
  '((emacs "26.1")
    (async "1.9.4"))
  :url "https://github.com/captainflasmr/bank-buddy"
  :commit "7b1567e85f5dfa40120a109b0dd15e885500fdfe"
  :revdesc "7b1567e85f5d"
  :keywords '("matching")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
