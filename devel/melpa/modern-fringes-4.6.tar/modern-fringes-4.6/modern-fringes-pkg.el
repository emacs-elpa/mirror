;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modern-fringes" "4.6"
  "Modern fringe bitmaps."
  ()
  :url "https://github.com/specialbomb/emacs-modern-fringes"
  :commit "1fa5e3ce022089558c853f7830f72b7201e66a78"
  :revdesc "1fa5e3ce0220"
  :keywords '("themes" "fringes" "convenience")
  :authors '(("Quen Jankosky" . "quen.jankosky@gmail.com"))
  :maintainers '(("Quen Jankosky" . "quen.jankosky@gmail.com")))
