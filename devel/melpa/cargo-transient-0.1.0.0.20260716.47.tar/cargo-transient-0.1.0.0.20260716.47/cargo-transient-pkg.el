;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cargo-transient" "0.1.0.0.20260716.47"
  "A transient UI for Cargo, Rust's package manager."
  '((emacs "28.1"))
  :url "https://github.com/peterstuart/cargo-transient"
  :commit "1ee9c93418cb31c8f12e6ec8916fb1604a7e6100"
  :revdesc "1ee9c93418cb"
  :authors '(("Peter Stuart" . "peter@peterstuart.org"))
  :maintainers '(("Peter Stuart" . "peter@peterstuart.org")))
