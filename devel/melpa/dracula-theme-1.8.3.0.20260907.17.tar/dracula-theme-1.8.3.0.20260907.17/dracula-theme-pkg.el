;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dracula-theme" "1.8.3.0.20260907.17"
  "Dracula Theme."
  '((emacs "24.3"))
  :url "https://github.com/dracula/emacs"
  :commit "538b8d20c667ac4b0c43ed1a5ef50760fb4ad754"
  :revdesc "v1.8.3-17-g538b8d20c667"
  :maintainers '(("tienne Deparis" . "etienne@depar.is")))
