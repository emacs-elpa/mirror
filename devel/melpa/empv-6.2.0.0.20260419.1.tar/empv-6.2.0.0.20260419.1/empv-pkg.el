;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "6.2.0.0.20260419.1"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "7f8af0b41a83c36acf7fe826839c02ecbffa33fc"
  :revdesc "v6.2.0-1-g7f8af0b41a83"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
