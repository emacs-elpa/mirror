;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cff" "1.0.1.0.20250209.8"
  "Search of the C/C++ file header by the source and vice versa."
  '((cl-lib "0.5")
    (emacs  "24"))
  :url "https://codeberg.org/fourier/cff"
  :commit "ebb2c9c24cae43283221219e95dac0ab43925a0f"
  :revdesc "ebb2c9c24cae"
  :keywords '("find-file")
  :authors '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com"))
  :maintainers '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com")))
