;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wacspace" "0.4.2.0.20260427.8"
  "The WACky WorkSPACE manager for emACS."
  '((emacs "24")
    (dash  "1.2.0"))
  :url "https://github.com/shosti/wacspace.el"
  :commit "28b1fb7a124febb8dbf47aaae8d7dd8c185eea7d"
  :revdesc "28b1fb7a124f"
  :keywords '("workspace")
  :authors '(("Emanuel Evans" . "emanuel.evans@gmail.com"))
  :maintainers '(("Emanuel Evans" . "emanuel.evans@gmail.com")))
