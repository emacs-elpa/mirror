;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "2.32.0.20260717.56"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "79b0b75f71aac249f00b17d95aa63ae3ff97ef75"
  :revdesc "79b0b75f71aa"
  :keywords '("languages" "lisp" "slime"))
