;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "0.13.8.0.20261001.13"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "3ad7c35404028cf4b0a34b8eece303e94ed7449a"
  :revdesc "v0.13.8-13-g3ad7c3540402"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
