;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dune" "3.25.0.0.20261123.772"
  "Integration with the dune build system."
  ()
  :url "https://github.com/ocaml/dune"
  :commit "002a58170ee03b1adde695fb07d345ce12a5bcf4"
  :revdesc "3.25.0-772-g002a58170ee0")
