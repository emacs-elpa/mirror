;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nimbus-theme" "1.6.0.0.20260903.1"
  "Nimbus dark theme."
  '((emacs "27.1"))
  :url "https://github.com/mrcnski/nimbus-theme"
  :commit "55ace6746bf3950c930bf5cfc67f2a082c5435ba"
  :revdesc "55ace6746bf3"
  :keywords '("faces")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
