;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-minor-faces" "1.2.4.0.20260925.1"
  "Highlight only section headings."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1"))
  :url "https://github.com/tarsius/outline-minor-faces"
  :commit "0b32cefa85307b61028412355c436093926e6cf5"
  :revdesc "v1.2.4-1-g0b32cefa8530"
  :keywords '("faces" "outlines")
  :authors '(("Jonas Bernoulli" . "emacs.outline-minor-faces@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.outline-minor-faces@jonas.bernoulli.dev")))
