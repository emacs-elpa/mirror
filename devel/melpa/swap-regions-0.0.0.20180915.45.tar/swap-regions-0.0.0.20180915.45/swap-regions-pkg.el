;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swap-regions" "0.0.0.20180915.45"
  "Swap text in two regions."
  '((emacs "24.3"))
  :url "https://github.com/xuchunyang/swap-regions.el"
  :commit "f4fd9880cf690e003fcde88dcf2b46adbbbb03cd"
  :revdesc "f4fd9880cf69"
  :keywords '("convenience")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
