;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "1.8.0.20260719.7"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "c548c5cf0d4a427a9c59d6e384ac1d96c285adbe"
  :revdesc "c548c5cf0d4a"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
