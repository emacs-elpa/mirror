;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blox" "0.3.0.0.20220521.2"
  "Interaction with Roblox tooling."
  '((emacs "25.1"))
  :url "https://github.com/kennethloeffler/blox"
  :commit "9ebebb65fb38b5570ba8dfbb5ec835633c06b67d"
  :revdesc "9ebebb65fb38"
  :keywords '("roblox" "rojo" "tools")
  :authors '(("Kenneth Loeffler" . "kenloef@gmail.com"))
  :maintainers '(("Kenneth Loeffler" . "kenloef@gmail.com")))
