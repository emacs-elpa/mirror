;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magent" "0.1.0.0.20260912.88"
  "AI coding agent."
  '((emacs       "29.1")
    (gptel       "0.9.8")
    (yaml        "1.0.0")
    (compat      "30.1.0.0")
    (acp         "0.13.1")
    (agent-shell "0.66.1"))
  :url "https://github.com/jamie-cui/magent"
  :commit "9805f3a7201d2acca1e525a27ec92d121c0a35ce"
  :revdesc "9805f3a7201d"
  :keywords '("tools" "ai" "copilot")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
