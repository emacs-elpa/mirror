;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dut-mode" "1.0.0.20170729.3"
  "Major mode for the Dut programming language."
  '((emacs "24"))
  :url "https://github.com/dut-lang/dut-mode"
  :commit "9235c7acaa6690942e9de8b7acd1e4be0c859dc1"
  :revdesc "9235c7acaa66"
  :keywords '("languages" "gut"))
