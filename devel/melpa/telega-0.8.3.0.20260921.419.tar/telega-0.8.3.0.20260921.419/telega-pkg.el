;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "0.8.3.0.20260921.419"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "901d99f12d46a3eec7333fea1e09fe54c635f327"
  :revdesc "901d99f12d46"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
