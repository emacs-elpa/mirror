;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "snoopy" "0.2.0"
  "Minor mode for number row unshifted character insertion."
  '((emacs  "24")
    (cl-lib "0.6"))
  :url "https://github.com/anmonteiro/snoopy-mode"
  :commit "ec4123bdebfe0bb7bf4feaac2dc02b59caffe386"
  :revdesc "ec4123bdebfe"
  :keywords '("lisp")
  :authors '(("António Nuno Monteiro" . "anmonteiro@gmail.com"))
  :maintainers '(("António Nuno Monteiro" . "anmonteiro@gmail.com")))
