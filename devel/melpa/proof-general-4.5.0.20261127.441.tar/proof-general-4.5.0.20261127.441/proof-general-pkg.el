;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "4.5.0.20261127.441"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "f15e4bf82c596268949f0da16530f031edcefa0e"
  :revdesc "v4.5-441-gf15e4bf82c59"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
