;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-gradle" "1.0.0.20190315.30"
  "Flycheck extension for Gradle."
  '((emacs    "25.1")
    (flycheck "0.25"))
  :url "https://github.com/jojojames/flycheck-gradle"
  :commit "1ca08bbc343362a923cbdc2010f66e41655e92ab"
  :revdesc "1ca08bbc3433"
  :keywords '("languages" "gradle")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
