;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keycast" "1.4.8.0.20260925.2"
  "Show current command and its binding."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1"))
  :url "https://github.com/tarsius/keycast"
  :commit "e70b9231b5a3083f0cb335d474e9872c59689aa1"
  :revdesc "v1.4.8-2-ge70b9231b5a3"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev")))
