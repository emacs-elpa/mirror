;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gptcommit" "0.1.0.0.20260530.62"
  "Git commit with help of gpt."
  '((emacs "29.1")
    (dash  "2.13.0")
    (magit "2.90.1")
    (llm   "0.16.1"))
  :url "https://github.com/douo/magit-gptcommit"
  :commit "b3ac0bfad8b06b6930dc4e35e3adefb4b6646193"
  :revdesc "b3ac0bfad8b0"
  :authors '(("Tiou Lims" . "dourokinga@gmail.com"))
  :maintainers '(("Tiou Lims" . "dourokinga@gmail.com")))
