;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jastadd-ast-mode" "0.2.0.20260209.4"
  "Major mode for editing JastAdd AST files."
  '((emacs "25"))
  :url "https://github.com/rudi/jastadd-ast-mode"
  :commit "b495089cd15876d5ac83289c5768d67dce3c28cd"
  :revdesc "b495089cd158"
  :keywords '("languages")
  :authors '(("Rudi Schlatte" . "rudi@constantly.at"))
  :maintainers '(("Rudi Schlatte" . "rudi@constantly.at")))
