;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timesheet" "0.5.0"
  "Timesheet management add-on for org-mode."
  '((s   "1")
    (org "9"))
  :url "https://github.com/tmarble/timesheet.el"
  :commit "511751b239c84d7619ec1c61d7f108b732b64442"
  :revdesc "511751b239c8"
  :keywords '("org" "timesheet"))
