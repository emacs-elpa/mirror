;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "impostman" "0.2.0.0.20260714.28"
  "Import Postman collections."
  '((emacs "27.1"))
  :url "https://github.com/flashcode/impostman"
  :commit "afaeefd8db6e72cd3022821db5aa5e1b521549b3"
  :revdesc "v0.2.0-28-gafaeefd8db6e"
  :keywords '("tools")
  :authors '(("Sébastien Helleu" . "flashcode@flashtux.org"))
  :maintainers '(("Sébastien Helleu" . "flashcode@flashtux.org")))
