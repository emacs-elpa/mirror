;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iflipb" "1.6.0.20220612.1"
  "Interactively flip between recently visited buffers."
  ()
  :url "https://github.com/jrosdahl/iflipb"
  :commit "9ec1888335107bd314e8f40b3e113d525fed8083"
  :revdesc "1.6-1-g9ec188833510"
  :authors '(("Joel Rosdahl" . "joel@rosdahl.net"))
  :maintainers '(("Joel Rosdahl" . "joel@rosdahl.net")))
