;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unicode-troll-stopper" "1.0.0.20190209.12"
  "Minor mode for Highlighting Unicode homoglyphs."
  ()
  :url "https://github.com/camsaul/emacs-unicode-troll-stopper"
  :commit "5e8be35a7bf6382384a701663f7438ee27e4b67c"
  :revdesc "5e8be35a7bf6"
  :keywords '("unicode")
  :authors '(("Cam Saül" . "cammsaul@gmail.com"))
  :maintainers '(("Cam Saül" . "cammsaul@gmail.com")))
