;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-cite-overlay-sidecar" "1.1.1"
  "Show Sidecar for overlaid org-cite citations."
  '((emacs                      "28.1")
    (citeproc                   "0.9.4")
    (org-cite-overlay           "0.1.0")
    (universal-sidecar          "1.5.0")
    (universal-sidecar-citeproc "1.0.0"))
  :url "https://git.sr.ht/~swflint/org-cite-overlay"
  :commit "452f467f044866b169314d6b691e22f95c94e2b5"
  :revdesc "452f467f0448"
  :keywords '("bib")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
