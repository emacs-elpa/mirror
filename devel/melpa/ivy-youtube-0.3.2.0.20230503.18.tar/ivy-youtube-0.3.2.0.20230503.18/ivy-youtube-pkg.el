;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-youtube" "0.3.2.0.20230503.18"
  "Query YouTube and play videos in your browser."
  '((request "0.2.0")
    (ivy     "0.8.0")
    (cl-lib  "0.5"))
  :url "https://github.com/squiter/ivy-youtube"
  :commit "e7a7cc860e967500857e5fd85d8e397c6d752ee1"
  :revdesc "e7a7cc860e96"
  :keywords '("youtube" "multimedia" "mpv" "vlc"))
