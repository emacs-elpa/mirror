;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marginalia" "2.12.0.20260831.1"
  "Enrich existing commands with completion annotations."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/marginalia"
  :commit "d76d7e36185ab552240c14fb08f7abcbf9a2910c"
  :revdesc "2.12-1-gd76d7e36185a"
  :keywords '("docs" "help" "matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
