;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clang-format+" "1.0.0.0.20190824.14"
  "Minor mode for automatic clang-format application."
  '((emacs        "25.1")
    (clang-format "20180406.1514"))
  :url "https://github.com/SavchenkoValeriy/emacs-clang-format-plus"
  :commit "ddd4bfe1a13c2fd494ce339a320a51124c1d2f68"
  :revdesc "ddd4bfe1a13c"
  :keywords '("c" "c++" "clang-format")
  :authors '(("Valeriy Savchenko" . "sinmipt@gmail.com"))
  :maintainers '(("Valeriy Savchenko" . "sinmipt@gmail.com")))
