;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "synaxis" "0.1.0.0.20260804.241"
  "Feed reader with SQLite storage."
  '((emacs        "29.1")
    (keymap-popup "0.2.1"))
  :url "https://git.thanosapollo.org/synaxis"
  :commit "262669b3bfafe9b8695a97a726f32b05e88bf00a"
  :revdesc "262669b3bfaf"
  :keywords '("news" "hypermedia" "rss" "atom")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
