;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-auto-beautify" "0.0.4"
  "Auto format you js/jsx file."
  '((web-beautify "0.3.1")
    (web-mode     "14.0.27"))
  :url "https://github.com/Qquanwei/auto-beautify.el"
  :commit "6bc9fef474197ca1722cb1e9051b270f80cdd7cc"
  :revdesc "6bc9fef47419"
  :authors '((nil . "quanwei9958@126.com"))
  :maintainers '((nil . "quanwei9958@126.com")))
