// SPDX-License-Identifier: MIT
#include "fzf-private.h"
#include "fzf-simd-prefilter.h"

#include <string.h>
#include <ctype.h>
#include <stdlib.h>

// UTF8PROC integration for Unicode support
#include "utf8proc-2.10.0/utf8proc.h"
#include "utf8_char_index.h"
#include "fzf-normalize.inc"

static FZF_THREAD_LOCAL bool fzf_allocation_failure;
FZF_THREAD_LOCAL bool fzf_simd_prefilter_allowed = true;

void fzf_clear_allocation_failure(void) {
  fzf_allocation_failure = false;
}

bool fzf_allocation_failed(void) {
  return fzf_allocation_failure;
}

static void fzf_mark_allocation_failure(void) {
  fzf_allocation_failure = true;
}

// TODO(conni2461): UNICODE HEADER
#define UNICODE_MAXASCII 0x7f

/* Pattern parsing runs on the Emacs thread and on persistent scoring threads.
   strtok stores its cursor in process-global state, so concurrent parses can
   make one thread read another thread's freed pattern buffer.  Use the native
   reentrant tokenizer on each supported platform. */
static char *fzf_strtok_r(char *str, const char *delim, char **state) {
#ifdef _WIN32
  return strtok_s(str, delim, state);
#else
  return strtok_r(str, delim, state);
#endif
}

#define SFREE(x)                                                               \
  if (x) {                                                                     \
    free(x);                                                                   \
  }

/* Helpers */
#define free_alloc(obj)                                                        \
  if ((obj).allocated) {                                                       \
    free((obj).data);                                                          \
  }

#define gen_simple_slice(name, type)                                           \
  typedef struct {                                                             \
    type *data;                                                                \
    size_t size;                                                               \
  } name##_slice_t;                                                            \
  static name##_slice_t slice_##name(type *input, size_t from, size_t to) {    \
    return (name##_slice_t){.data = input + from, .size = to - from};          \
  }

#define gen_slice(name, type)                                                  \
  gen_simple_slice(name, type);                                                \
  static name##_slice_t slice_##name##_right(type *input, size_t to) {         \
    return slice_##name(input, 0, to);                                         \
  }

gen_slice(i16, int16_t);
gen_simple_slice(i32, int32_t);
gen_slice(str, const char);
#undef gen_slice
#undef gen_simple_slice

/* TODO(conni2461): additional types (utf8) */
typedef int32_t char_class;
typedef char byte;

typedef enum {
  ScoreMatch = 16,
  ScoreGapStart = -3,
  ScoreGapExtention = -1,
  BonusBoundary = ScoreMatch / 2,
  BonusNonWord = ScoreMatch / 2,
  BonusCamel123 = BonusBoundary + ScoreGapExtention,
  BonusConsecutive = -(ScoreGapStart + ScoreGapExtention),
  BonusFirstCharMultiplier = 2,
} score_t;

typedef enum {
  CharWhite = 0,
  CharNonWord,
  CharDelimiter,
  CharLower,
  CharUpper,
  CharLetter,
  CharNumber
} char_types;

typedef struct {
  int16_t boundary_white;
  int16_t boundary_delimiter;
  char_class initial_class;
  bool path_delimiters_only;
} score_scheme_config_t;

static const score_scheme_config_t score_scheme_configs[] = {
    [FZF_SCORE_SCHEME_DEFAULT] =
        {BonusBoundary + 2, BonusBoundary + 1, CharWhite, false},
    [FZF_SCORE_SCHEME_PATH] =
        {BonusBoundary, BonusBoundary + 1, CharDelimiter, true},
    [FZF_SCORE_SCHEME_HISTORY] =
        {BonusBoundary, BonusBoundary, CharWhite, false},
};

static const score_scheme_config_t *score_scheme_config(
    const fzf_slab_t *slab) {
  fzf_score_scheme_t scheme = slab ? slab->score_scheme
                                    : FZF_SCORE_SCHEME_DEFAULT;
  if ((unsigned int)scheme > FZF_SCORE_SCHEME_HISTORY)
    scheme = FZF_SCORE_SCHEME_DEFAULT;
  return &score_scheme_configs[scheme];
}

static int32_t index_byte(fzf_string_t *string, char b) {
  if (string->size == 0) return -1;
  if (string->data[0] == b) return 0;
  const char *match = memchr(
      string->data + 1, (unsigned char)b, string->size - 1);
  return match ? (int32_t)(match - string->data) : -1;
}

static bool fzf_unicode_is_space(utf8proc_int32_t cp) {
  if ((cp >= 0x09 && cp <= 0x0d) || cp == 0x85)
    return true;
  utf8proc_category_t category = utf8proc_category(cp);
  return category == UTF8PROC_CATEGORY_ZS ||
         category == UTF8PROC_CATEGORY_ZL ||
         category == UTF8PROC_CATEGORY_ZP;
}

/* Return a byte count.  The anchored algorithms use byte slices even on the
   UTF-8 path, so counting raw `isspace' bytes is both locale-dependent and
   unsafe: in a UTF-8 locale a continuation byte such as 0xa0 can be classified
   as whitespace and split a CJK codepoint. */
static size_t leading_whitespaces(fzf_string_t *str) {
  size_t pos = 0;
  while (pos < str->size) {
    utf8proc_int32_t cp;
    utf8proc_ssize_t width = utf8_iterate_lossy(
        (const utf8proc_uint8_t *)str->data + pos,
        (utf8proc_ssize_t)(str->size - pos), &cp);
    if (!fzf_unicode_is_space(cp)) break;
    pos += (size_t)width;
  }
  return pos;
}

static size_t trailing_whitespaces(fzf_string_t *str) {
  size_t pos = 0;
  size_t trailing = 0;
  /* A string ending in an ASCII non-space (paths, identifiers -- the
     common case for every `$'-anchored term) has no trailing whitespace;
     answer without the full forward decode. */
  if (str->size > 0) {
    unsigned char last = (unsigned char)str->data[str->size - 1];
    if (last < 0x80 && !((last >= 0x09 && last <= 0x0d) || last == 0x20))
      return 0;
  }
  while (pos < str->size) {
    utf8proc_int32_t cp;
    utf8proc_ssize_t width = utf8_iterate_lossy(
        (const utf8proc_uint8_t *)str->data + pos,
        (utf8proc_ssize_t)(str->size - pos), &cp);
    if (fzf_unicode_is_space(cp))
      trailing += (size_t)width;
    else
      trailing = 0;
    pos += (size_t)width;
  }
  return trailing;
}

static void copy_runes(fzf_string_t *src, fzf_i32_t *destination) {
  for (size_t i = 0; i < src->size; i++) {
    destination->data[i] = (int32_t)src->data[i];
  }
}

static void copy_into_i16(i16_slice_t *src, fzf_i16_t *dest) {
  for (size_t i = 0; i < src->size; i++) {
    dest->data[i] = src->data[i];
  }
}

// char* helpers
static char *trim_whitespace_left(char *str, size_t *len) {
  for (size_t i = 0; i < *len; i++) {
    if (str[0] == ' ') {
      (*len)--;
      str++;
    } else {
      break;
    }
  }
  return str;
}

static bool has_prefix(const char *str, const char *prefix, size_t prefix_len) {
  return strncmp(prefix, str, prefix_len) == 0;
}

static bool has_suffix(const char *str, size_t len, const char *suffix,
                       size_t suffix_len) {
  return len >= suffix_len &&
         strncmp(slice_str(str, len - suffix_len, len).data, suffix,
                 suffix_len) == 0;
}

static char *str_replace_char(char *str, char find, char replace) {
  char *current_pos = strchr(str, find);
  while (current_pos) {
    *current_pos = replace;
    current_pos = strchr(current_pos, find);
  }
  return str;
}

static char *str_replace(char *orig, char *rep, char *with) {
  if (!orig || !rep || !with) {
    return NULL;
  }

  char *result;
  char *ins;
  char *tmp;

  size_t len_rep = strlen(rep);
  size_t len_front = 0;
  size_t len_orig = strlen(orig);
  size_t len_with = strlen(with);
  size_t count = 0;

  if (len_rep == 0) {
    return NULL;
  }

  ins = orig;
  for (; (tmp = strstr(ins, rep)); ++count) {
    ins = tmp + len_rep;
  }

  size_t result_len = len_orig;
  if (len_with >= len_rep) {
    size_t growth = len_with - len_rep;
    if (growth && count > (SIZE_MAX - result_len - 1) / growth) {
      return NULL;
    }
    result_len += growth * count;
  } else {
    size_t shrink = len_rep - len_with;
    if (count > result_len / shrink) {
      return NULL;
    }
    result_len -= shrink * count;
  }

  tmp = result = (char *)malloc(result_len + 1);
  if (!result) {
    return NULL;
  }

  while (count--) {
    ins = strstr(orig, rep);
    len_front = (size_t)(ins - orig);
    tmp = strncpy(tmp, orig, len_front) + len_front;
    tmp = strcpy(tmp, with) + len_with;
    orig += len_front + len_rep;
    len_orig -= len_front + len_rep;
  }
  strncpy(tmp, orig, len_orig);
  tmp[len_orig] = 0;
  return result;
}

static char *str_duplicate(const char *str, size_t size) {
  if (size == SIZE_MAX) return NULL;
  char *copy = malloc(size + 1);
  if (!copy) return NULL;
  memcpy(copy, str, size);
  copy[size] = '\0';
  return copy;
}

// UTF-8 aware lowercase conversion
static char *str_tolower(const char *str, size_t size) {
  // Check if string is pure ASCII for fast path
  if (is_ascii_utf8proc(str, size)) {
    // Fast ASCII path
    if (size == SIZE_MAX) return NULL;
    char *lower_str = (char *)malloc(size + 1);
    if (!lower_str) return NULL;
    for (size_t i = 0; i < size; i++) {
      lower_str[i] = (char)tolower((uint8_t)str[i]);
    }
    lower_str[size] = '\0';
    return lower_str;
  }
  
  // UTF-8 path: need to handle multibyte characters
  // Allocate worst case (each char could expand to 4 bytes)
  if (size > (SIZE_MAX - 1) / 4) return NULL;
  char *lower_str = (char *)malloc(size * 4 + 1);
  if (!lower_str) return NULL;
  size_t out_pos = 0;
  size_t in_pos = 0;
  
  while (in_pos < size) {
    utf8proc_int32_t codepoint;
    utf8proc_ssize_t bytes = utf8proc_iterate(
      (const utf8proc_uint8_t*)(str + in_pos),
      size - in_pos, &codepoint);
    
    if (bytes <= 0) {
      // Invalid UTF-8, copy byte as-is
      lower_str[out_pos++] = str[in_pos++];
      continue;
    }
    
    // Apply case folding
    utf8proc_int32_t folded = utf8proc_case_fold(codepoint);
    
    // Encode back to UTF-8
    utf8proc_ssize_t out_bytes = utf8proc_encode_char(
      folded, (utf8proc_uint8_t*)(lower_str + out_pos));
    
    if (out_bytes > 0) {
      out_pos += out_bytes;
    } else {
      // Encoding failed, copy original
      memcpy(lower_str + out_pos, str + in_pos, bytes);
      out_pos += bytes;
    }
    
    in_pos += bytes;
  }
  
  lower_str[out_pos] = '\0';
  
  // Resize to actual size
  char *result = (char *)realloc(lower_str, out_pos + 1);
  return result ? result : lower_str;
}

static int16_t max16(int16_t a, int16_t b) {
  return (a > b) ? a : b;
}

static size_t min64u(size_t a, size_t b) {
  return (a < b) ? a : b;
}

fzf_position_t *fzf_pos_array(size_t len) {
  if (len > SIZE_MAX / sizeof(uint32_t)) {
    fzf_mark_allocation_failure();
    return NULL;
  }
  fzf_position_t *pos = (fzf_position_t *)malloc(sizeof(fzf_position_t));
  if (!pos) {
    fzf_mark_allocation_failure();
    return NULL;
  }
  pos->size = 0;
  pos->cap = len;
  if (len > 0) {
    pos->data = (uint32_t *)malloc(len * sizeof(uint32_t));
    if (!pos->data) {
      free(pos);
      fzf_mark_allocation_failure();
      return NULL;
    }
  } else {
    pos->data = NULL;
  }
  return pos;
}

static bool resize_pos(fzf_position_t *pos, size_t add_len, size_t comp) {
  if (!pos) {
    return true;
  }
  if (comp > SIZE_MAX - pos->size) {
    fzf_mark_allocation_failure();
    return false;
  }
  size_t needed = pos->size + comp;
  if (needed <= pos->cap) return true;

  size_t growth = add_len > 0 ? add_len : 1;
  size_t new_cap = pos->cap;
  if (growth > SIZE_MAX - new_cap)
    new_cap = needed;
  else
    new_cap += growth;
  if (new_cap < needed) new_cap = needed;
  if (new_cap > SIZE_MAX / sizeof(uint32_t)) {
    fzf_mark_allocation_failure();
    return false;
  }
  uint32_t *new_data =
      (uint32_t *)realloc(pos->data, sizeof(uint32_t) * new_cap);
  if (!new_data) {
    fzf_mark_allocation_failure();
    return false;
  }
  pos->data = new_data;
  pos->cap = new_cap;
  return true;
}

static bool unsafe_append_pos(fzf_position_t *pos, size_t value) {
  if (!resize_pos(pos, pos->cap, 1)) return false;
  pos->data[pos->size] = value;
  pos->size++;
  return true;
}

static bool append_pos(fzf_position_t *pos, size_t value) {
  return !pos || unsafe_append_pos(pos, value);
}

static bool insert_range(fzf_position_t *pos, size_t start, size_t end) {
  if (!pos) {
    return true;
  }

  if (end <= start) return true;

  if (!resize_pos(pos, end - start, end - start)) return false;
  for (size_t k = start; k < end; k++) {
    pos->data[pos->size] = k;
    pos->size++;
  }
  return true;
}

static fzf_i16_t alloc16(size_t *offset, fzf_slab_t *slab, size_t size) {
  if (slab != NULL && *offset <= slab->I16.cap &&
      size <= slab->I16.cap - *offset) {
    i16_slice_t slice = slice_i16(slab->I16.data, *offset, (*offset) + size);
    *offset = *offset + size;
    return (fzf_i16_t){.data = slice.data,
                       .size = slice.size,
                       .cap = slice.size,
                       .allocated = false};
  }
  if (size > SIZE_MAX / sizeof(int16_t)) {
    fzf_mark_allocation_failure();
    return (fzf_i16_t){0};
  }
  int16_t *data = (int16_t *)malloc(size * sizeof(int16_t));
  if (size > 0 && !data) {
    fzf_mark_allocation_failure();
    return (fzf_i16_t){0};
  }
  memset(data, 0, size * sizeof(int16_t));
  return (fzf_i16_t){
      .data = data, .size = size, .cap = size, .allocated = true};
}

static fzf_i32_t alloc32(size_t *offset, fzf_slab_t *slab, size_t size) {
  if (slab != NULL && *offset <= slab->I32.cap &&
      size <= slab->I32.cap - *offset) {
    i32_slice_t slice = slice_i32(slab->I32.data, *offset, (*offset) + size);
    *offset = *offset + size;
    return (fzf_i32_t){.data = slice.data,
                       .size = slice.size,
                       .cap = slice.size,
                       .allocated = false};
  }
  if (size > SIZE_MAX / sizeof(int32_t)) {
    fzf_mark_allocation_failure();
    return (fzf_i32_t){0};
  }
  int32_t *data = (int32_t *)malloc(size * sizeof(int32_t));
  if (size > 0 && !data) {
    fzf_mark_allocation_failure();
    return (fzf_i32_t){0};
  }
  memset(data, 0, size * sizeof(int32_t));
  return (fzf_i32_t){
      .data = data, .size = size, .cap = size, .allocated = true};
}

static bool score_scheme_delimiter(const score_scheme_config_t *config,
                                   utf8proc_int32_t codepoint) {
  if (codepoint == '/') return true;
  /* Pinned fzf adds the host path separator alongside '/' only when they
     differ.  The test override exercises this Windows branch on POSIX without
     defining _WIN32 and changing unrelated libc compatibility paths. */
#if defined(_WIN32) || defined(FZF_TEST_WINDOWS_PATH_SCORING)
  if (config->path_delimiters_only && codepoint == '\\') return true;
#endif
  return !config->path_delimiters_only &&
         (codepoint == ',' || codepoint == ':' || codepoint == ';' ||
          codepoint == '|');
}

static char_class char_class_of_ascii(char ch,
                                      const score_scheme_config_t *config) {
  unsigned char byte = (unsigned char)ch;
  if (ch >= 'a' && ch <= 'z') {
    return CharLower;
  }
  if (ch >= 'A' && ch <= 'Z') {
    return CharUpper;
  }
  if (ch >= '0' && ch <= '9') {
    return CharNumber;
  }
  if ((byte >= 0x09 && byte <= 0x0d) || byte == 0x20) {
    return CharWhite;
  }
  if (score_scheme_delimiter(config, byte)) {
    return CharDelimiter;
  }
  return CharNonWord;
}

// static char_class char_class_of_non_ascii(char ch) {
//   return 0;
// }

static char_class char_class_of(char ch,
                                const score_scheme_config_t *config) {
  return char_class_of_ascii(ch, config);
  // if (ch <= 0x7f) {
  //   return char_class_of_ascii(ch);
  // }
  // return char_class_of_non_ascii(ch);
}

static bool char_class_is_word(char_class class) {
  return class == CharLower || class == CharUpper || class == CharLetter ||
         class == CharNumber;
}

static int16_t bonus_for(const score_scheme_config_t *config,
                         char_class prev_class, char_class class) {
  if (class >= CharNonWord) {
    if (prev_class == CharWhite) {
      return config->boundary_white;
    }
    if (prev_class == CharDelimiter) {
      return config->boundary_delimiter;
    }
    if (prev_class == CharNonWord) {
      return BonusBoundary;
    }
  }
  if ((prev_class == CharLower && class == CharUpper) ||
      (prev_class != CharNumber && class == CharNumber)) {
    return BonusCamel123;
  }
  if (class == CharNonWord || class == CharDelimiter) {
    return BonusNonWord;
  }
  if (class == CharWhite) return config->boundary_white;
  return 0;
}

static int16_t bonus_at(fzf_string_t *input, size_t idx,
                        const score_scheme_config_t *config) {
  if (idx == 0) {
    return config->boundary_white;
  }
  return bonus_for(config, char_class_of(input->data[idx - 1], config),
                   char_class_of(input->data[idx], config));
}

static utf8proc_int32_t fzf_normalize_codepoint(utf8proc_int32_t codepoint) {
  if (codepoint < 0x00c0) return codepoint;
  switch ((uint32_t)codepoint >> 8) {
#define FZF_NORMALIZED_SOURCE_PAGE(page) case page:
      FZF_NORMALIZED_SOURCE_PAGES
#undef FZF_NORMALIZED_SOURCE_PAGE
#undef FZF_NORMALIZED_SOURCE_PAGES
      break;
    default:
      return codepoint;
  }
  size_t lo = 0;
  size_t hi = sizeof fzf_normalized_runes / sizeof fzf_normalized_runes[0];
  while (lo < hi) {
    size_t mid = lo + (hi - lo) / 2;
    utf8proc_int32_t source = fzf_normalized_runes[mid].source;
    if (source < codepoint)
      lo = mid + 1;
    else
      hi = mid;
  }
  if (lo < sizeof fzf_normalized_runes / sizeof fzf_normalized_runes[0] &&
      fzf_normalized_runes[lo].source == codepoint)
    return fzf_normalized_runes[lo].target;
  return codepoint;
}

static char normalize_rune(char r) {
  return (char)fzf_normalize_codepoint((uint8_t)r);
}

/* fzf normalizes candidate text only when the lowercased query is already in
   normalized form.  A query that contains a foldable rune stays literal.
   This preserves the directional contract: "e" matches "é", but "é" does
   not match "e" or "ê". */
static bool pattern_can_normalize(const char *pattern, size_t byte_len) {
  size_t offset = 0;
  while (offset < byte_len) {
    utf8proc_int32_t codepoint;
    utf8proc_ssize_t width = utf8_iterate_lossy(
        (const utf8proc_uint8_t *)pattern + offset,
        (utf8proc_ssize_t)(byte_len - offset), &codepoint);
    if (fzf_normalize_codepoint(codepoint) != codepoint) return false;
    offset += (size_t)width;
  }
  return true;
}

static int32_t try_skip(fzf_string_t *input, bool case_sensitive, byte b,
                        int32_t from) {
  str_slice_t slice = slice_str(input->data, (size_t)from, input->size);
  fzf_string_t byte_array = {.data = slice.data, .size = slice.size};
  int32_t idx = index_byte(&byte_array, b);
  if (idx == 0) {
    return from;
  }

  if (!case_sensitive && b >= 'a' && b <= 'z') {
    if (idx > 0) {
      str_slice_t tmp = slice_str_right(byte_array.data, (size_t)idx);
      byte_array.data = tmp.data;
      byte_array.size = tmp.size;
    }
    int32_t uidx = index_byte(&byte_array, b - (byte)32);
    if (uidx >= 0) {
      idx = uidx;
    }
  }
  if (idx < 0) {
    return -1;
  }

  return from + idx;
}

static bool is_ascii(const char *runes, size_t size) {
  // TODO(conni2461): future use
  /* for (size_t i = 0; i < size; i++) { */
  /*   if (runes[i] >= 256) { */
  /*     return false; */
  /*   } */
  /* } */
  return true;
}

static int32_t ascii_fuzzy_index(
    fzf_string_t *input, fzf_string_t *pattern,
    const fzf_ascii_query_plan_t *plan, bool case_sensitive) {
  if (!is_ascii(pattern->data, pattern->size)) {
    return -1;
  }

#if FZF_HAVE_SIMD_PREFILTER
  if (plan && plan->pattern_size == pattern->size &&
      plan->case_sensitive == case_sensitive &&
      pattern->size >= FZF_SIMD_FUZZY_MIN_PATTERN &&
      input->size >= FZF_SIMD_FUZZY_MIN_TEXT) {
    const char *first = fzf_ascii_plan_find_byte(
        input->data, input->size, &plan->bytes[0], case_sensitive);
    if (!first) return -1;
    size_t first_index = (size_t)(first - input->data);
    if (!fzf_ascii_plan_ordered_after_first(
            input->data, input->size, plan, first_index))
      return -1;
    return first_index > 0 ? (int32_t)(first_index - 1) : 0;
  }
#else
  (void)plan;
#endif

  int32_t first_idx = 0;
  int32_t idx = 0;
  for (size_t pidx = 0; pidx < pattern->size; pidx++) {
    idx = try_skip(input, case_sensitive, pattern->data[pidx], idx);
    if (idx < 0) {
      return -1;
    }
    if (pidx == 0 && idx > 0) {
      first_idx = idx - 1;
    }
    idx++;
  }

  return first_idx;
}

/* UTF-8 utility functions using utf8proc */

bool is_ascii_utf8proc(const char *text, size_t len) {
  const unsigned char *ptr = (const unsigned char *)text;

  /* fzf_has_match uses this check for every filter-only candidate.  Inspect
     eight bytes at a time so Unicode correctness does not add a byte-at-a-time
     pre-pass to the overwhelmingly ASCII completion corpus.  memcpy keeps the
     load valid for unaligned strings. */
  while (len >= sizeof(uint64_t)) {
    uint64_t word;
    memcpy(&word, ptr, sizeof(word));
    if (word & UINT64_C(0x8080808080808080)) return false;
    ptr += sizeof(word);
    len -= sizeof(word);
  }
  while (len-- > 0)
    if (*ptr++ & 0x80) return false;
  return true;
}

static char_class char_class_of_codepoint(
    utf8proc_int32_t codepoint, const score_scheme_config_t *config) {
  const utf8proc_property_t *prop = utf8proc_get_property(codepoint);
  
  switch (prop->category) {
    case UTF8PROC_CATEGORY_LL: // Lowercase letter
      return CharLower;
    case UTF8PROC_CATEGORY_LU: // Uppercase letter  
    case UTF8PROC_CATEGORY_LT: // Titlecase letter
      return CharUpper;
    case UTF8PROC_CATEGORY_LO: // Other letter
    case UTF8PROC_CATEGORY_LM: // Modifier letter
      return CharLetter;
    case UTF8PROC_CATEGORY_ND: // Decimal digit number
    case UTF8PROC_CATEGORY_NL: // Letter number
    case UTF8PROC_CATEGORY_NO: // Other number
      return CharNumber;
    default:
      if (fzf_unicode_is_space(codepoint)) return CharWhite;
      if (score_scheme_delimiter(config, codepoint)) return CharDelimiter;
      return CharNonWord;
  }
}

int32_t char_class_of_utf8proc(utf8proc_int32_t codepoint) {
  return char_class_of_codepoint(codepoint,
                                 &score_scheme_configs[FZF_SCORE_SCHEME_DEFAULT]);
}

utf8proc_int32_t utf8proc_case_fold(utf8proc_int32_t codepoint) {
  return utf8proc_tolower(codepoint);
}

/* FuzzyMatchV2 follows fzf's unicode.IsUpper guard when it lowercases
   candidate runes.  This is intentionally narrower than Unicode ToLower:
   titlecase letters and cased numbers can have lowercase mappings without
   belonging to the Lu category. */
static utf8proc_int32_t v2_case_fold_candidate(
    utf8proc_int32_t codepoint) {
  return utf8proc_category(codepoint) == UTF8PROC_CATEGORY_LU
             ? utf8proc_case_fold(codepoint)
             : codepoint;
}

/* Find the first byte of a fuzzy UTF-8 subsequence without narrowing an
   input offset.  Apply the same case-fold and pinned normalization map as
   the scorer when NORMALIZE is true.  The public compatibility wrapper below
   still returns an int32_t, while internal callers can safely prefilter
   size_t-bounded input. */
static bool utf8_fuzzy_index_size(fzf_string_t *input, const char *pattern,
                                  size_t pattern_len, bool case_sensitive,
                                  bool normalize,
                                  bool v2_candidate_case,
                                  size_t *first_idx_out,
                                  size_t *input_char_count_out) {
  *first_idx_out = 0;
  if (input_char_count_out) *input_char_count_out = 0;
  // Handle empty pattern
  if (pattern_len == 0) {
    if (input_char_count_out)
      *input_char_count_out = utf8_strlen(input->data, input->size);
    return true;
  }

  // Unified implementation for both ASCII and UTF-8
  // This avoids the broken ascii_fuzzy_index function
  const char *input_ptr = input->data;
  const char *pattern_ptr = pattern;
  
  size_t input_pos = 0;
  size_t pattern_pos = 0;
  size_t first_idx = 0;
  size_t input_char_count = 0;
  
  // Process each pattern character
  while (pattern_pos < pattern_len && input_pos < input->size) {
    utf8proc_int32_t pattern_cp, input_cp;
    
    // Decode pattern character (handles both ASCII and UTF-8)
    utf8proc_ssize_t pattern_bytes = utf8_iterate_lossy(
      (const utf8proc_uint8_t*)(pattern_ptr + pattern_pos),
      pattern_len - pattern_pos, &pattern_cp);
    
    if (!case_sensitive) {
      pattern_cp = utf8proc_case_fold(pattern_cp);
    }
    if (normalize) {
      pattern_cp = fzf_normalize_codepoint(pattern_cp);
    }
    
    // Search for this pattern character starting from current position
    bool found = false;
    size_t search_pos = input_pos;
    
    while (search_pos < input->size) {
      utf8proc_ssize_t input_bytes = utf8_iterate_lossy(
        (const utf8proc_uint8_t*)(input_ptr + search_pos),
        input->size - search_pos, &input_cp);
      input_char_count++;
      
      utf8proc_int32_t input_cp_cmp = input_cp;
      if (!case_sensitive) {
        input_cp_cmp = v2_candidate_case
                           ? v2_case_fold_candidate(input_cp)
                           : utf8proc_case_fold(input_cp);
      }
      if (normalize) {
        input_cp_cmp = fzf_normalize_codepoint(input_cp_cmp);
      }
      
      if (input_cp_cmp == pattern_cp) {
        // Found the character
        if (pattern_pos == 0) {
          // Store the byte position where the first match starts
          first_idx = search_pos;
        }
        found = true;
        input_pos = search_pos + input_bytes;
        break;
      }

      search_pos += input_bytes;
      input_pos = search_pos;
    }

    if (!found) {
      if (input_char_count_out) *input_char_count_out = input_char_count;
      return false; // Pattern character not found
    }
    
    pattern_pos += pattern_bytes;
  }

  /* Fuzzy v2 needs the full character count to size its DP arrays.  Finish
     that mandatory count here so a successful prefilter can reuse this decode
     instead of making the char-map builder decode the candidate again. */
  if (input_char_count_out) {
    while (input_pos < input->size) {
      utf8proc_int32_t input_cp;
      utf8proc_ssize_t input_bytes = utf8_iterate_lossy(
          (const utf8proc_uint8_t *)(input_ptr + input_pos),
          input->size - input_pos, &input_cp);
      input_pos += (size_t)input_bytes;
      input_char_count++;
    }
    *input_char_count_out = input_char_count;
  }

  if (pattern_pos < pattern_len) return false;
  *first_idx_out = first_idx;
  return true;
}

int32_t utf8_fuzzy_index(fzf_string_t *input, const char *pattern,
                         size_t pattern_len, bool case_sensitive) {
  size_t first_idx = 0;
  if (!utf8_fuzzy_index_size(input, pattern, pattern_len, case_sensitive,
                             false, false, &first_idx, NULL) ||
      first_idx > INT32_MAX)
    return -1;
  return (int32_t)first_idx;
}

/* UTF-8 helper functions */

// UTF-8 aware character comparison
static bool utf8_char_equal(utf8proc_int32_t cp1, utf8proc_int32_t cp2,
                           bool case_sensitive, bool normalize) {
  if (!case_sensitive) {
    cp1 = utf8proc_case_fold(cp1);
    cp2 = utf8proc_case_fold(cp2);
  }
  if (normalize) {
    cp1 = fzf_normalize_codepoint(cp1);
    cp2 = fzf_normalize_codepoint(cp2);
  }
  return cp1 == cp2;
}

/* Return the byte offset of the UTF-8 character immediately before POS.
   Callers validate the sequence with utf8proc_iterate after finding the
   boundary, so malformed input remains a safe non-match. */
static size_t utf8_previous_char_start(const char *data, size_t pos) {
  if (pos == 0) return 0;
  pos--;
  while (pos > 0 && ((uint8_t)data[pos] & 0xc0) == 0x80) pos--;
  return pos;
}

/* Backward counterpart of `utf8_iterate_lossy': the byte offset and
   codepoint of the unit a forward lossy pass decodes immediately before
   POS (POS > 0).  When the bytes between the previous lead-byte
   boundary and POS are not one valid sequence, the previous unit is the
   single (invalid) byte at POS-1, mirroring the forward policy. */
static size_t utf8_lossy_previous_char(const char *data, size_t pos,
                                       utf8proc_int32_t *cp) {
  size_t start = utf8_previous_char_start(data, pos);
  utf8proc_ssize_t bytes = utf8proc_iterate(
      (const utf8proc_uint8_t *)(data + start),
      (utf8proc_ssize_t)(pos - start), cp);
  if (bytes != (utf8proc_ssize_t)(pos - start) || bytes <= 0 || *cp < 0) {
    *cp = 0xDC00 + (utf8proc_int32_t)(uint8_t)data[pos - 1];
    return pos - 1;
  }
  return start;
}

// UTF-8 aware bonus calculation
static int32_t calculate_score(bool case_sensitive, bool normalize,
                               fzf_string_t *text, fzf_string_t *pattern,
                               size_t sidx, size_t eidx, fzf_position_t *pos,
                               fzf_slab_t *slab) {
  const size_t M = pattern->size;
  const score_scheme_config_t *config = score_scheme_config(slab);

  size_t pidx = 0;
  int32_t score = 0;
  int32_t consecutive = 0;
  bool in_gap = false;
  int16_t first_bonus = 0;

  if (!resize_pos(pos, M, M)) return 0;
  int32_t prev_class = config->initial_class;
  if (sidx > 0) {
    prev_class = char_class_of(text->data[sidx - 1], config);
  }
  for (size_t idx = sidx; idx < eidx; idx++) {
    char c = text->data[idx];
    int32_t class = char_class_of(c, config);
    if (!case_sensitive) {
      /* TODO(conni2461): He does some unicode stuff here, investigate */
      c = (char)tolower((uint8_t)c);
    }
    if (normalize) {
      c = normalize_rune(c);
    }
    if (c == pattern->data[pidx]) {
      if (!append_pos(pos, idx)) return 0;
      score += ScoreMatch;
      int16_t bonus = bonus_for(config, prev_class, class);
      if (consecutive == 0) {
        first_bonus = bonus;
      } else {
        if (bonus >= BonusBoundary && bonus > first_bonus) {
          first_bonus = bonus;
        }
        bonus = max16(max16(bonus, first_bonus), BonusConsecutive);
      }
      if (pidx == 0) {
        score += (int32_t)(bonus * BonusFirstCharMultiplier);
      } else {
        score += (int32_t)bonus;
      }
      in_gap = false;
      consecutive++;
      pidx++;
    } else {
      if (in_gap) {
        score += ScoreGapExtention;
      } else {
        score += ScoreGapStart;
      }
      in_gap = true;
      consecutive = 0;
      first_bonus = 0;
    }
    prev_class = class;
  }
  return score;
}

// UTF-8 aware calculate_score
static int32_t calculate_score_utf8(bool case_sensitive, bool normalize,
                                    fzf_string_t *text, fzf_string_t *pattern,
                                    size_t start, size_t end,
                                    fzf_position_t *pos, fzf_slab_t *slab) {
  size_t pidx = 0;
  size_t text_pos = start;
  int32_t score = 0;
  int32_t consecutive = 0;
  int16_t first_bonus = 0;
  bool in_gap = false;

  const size_t M = pattern->size;
  const size_t N = text->size;
  const score_scheme_config_t *config = score_scheme_config(slab);

  // Determine prev_class: the character class of the character before 'start'
  int32_t prev_class = config->initial_class;
  if (start > 0) {
    // Walk forward from 0 to find the codepoint just before start
    size_t scan = 0;
    utf8proc_int32_t prev_cp = 0;
    while (scan < start) {
      utf8proc_int32_t cp;
      utf8proc_ssize_t b = utf8_iterate_lossy(
        (const utf8proc_uint8_t*)(text->data + scan),
        N - scan, &cp);
      prev_cp = cp;
      scan += b;
    }
    prev_class = char_class_of_codepoint(prev_cp, config);
  }

  size_t pat_byte_pos = 0; // tracks current byte offset into pattern

  while (text_pos < end) {
    utf8proc_int32_t text_cp;

    utf8proc_ssize_t text_bytes = utf8_iterate_lossy(
      (const utf8proc_uint8_t*)(text->data + text_pos),
      end - text_pos, &text_cp);

    int32_t class = char_class_of_codepoint(text_cp, config);
    int16_t bonus = bonus_for(config, prev_class, class);

    // Check if we still have pattern characters to match
    if (pat_byte_pos < M) {
      utf8proc_int32_t pattern_cp;
      utf8proc_ssize_t pattern_bytes = utf8_iterate_lossy(
        (const utf8proc_uint8_t*)(pattern->data + pat_byte_pos),
        M - pat_byte_pos, &pattern_cp);

      if (utf8_char_equal(text_cp, pattern_cp, case_sensitive, normalize)) {
        if (!append_pos(pos, text_pos)) return 0;
        score += ScoreMatch;

        if (consecutive == 0) {
          first_bonus = bonus;
        } else {
          if (bonus >= BonusBoundary && bonus > first_bonus) {
            first_bonus = bonus;
          }
          bonus = max16(max16(bonus, first_bonus), BonusConsecutive);
        }

        if (pidx == 0) {
          score += (int32_t)(bonus * BonusFirstCharMultiplier);
        } else {
          score += (int32_t)bonus;
        }
        in_gap = false;
        consecutive++;
        pidx++;
        pat_byte_pos += pattern_bytes;
      } else {
        if (in_gap) {
          score += ScoreGapExtention;
        } else {
          score += ScoreGapStart;
        }
        in_gap = true;
        consecutive = 0;
        first_bonus = 0;
      }
    }

    text_pos += text_bytes;
    prev_class = class;
  }

  return score;
}

static fzf_result_t fzf_fuzzy_match_v1_impl(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab,
    const fzf_ascii_query_plan_t *plan) {
  const size_t M = pattern->size;
  const size_t N = text->size;
  if (M == 0) {
    return (fzf_result_t){0, 0, 0};
  }
  if (ascii_fuzzy_index(text, pattern, plan, case_sensitive) < 0) {
    return (fzf_result_t){-1, -1, 0};
  }

  size_t pidx = 0;
  size_t sidx = 0;
  size_t eidx = 0;
  bool started = false;
  /* Select the scan direction once.  SIZE_MAX is -1 modulo size_t, so each
     hot loop can advance its valid index without a direction branch. */
  size_t scan_delta = forward ? 1 : SIZE_MAX;
  size_t text_index = forward ? 0 : N - 1;
  size_t pattern_index = forward ? 0 : M - 1;
  for (size_t step = 0; step < N; step++) {
    char c = text->data[text_index];
    /* TODO(conni2461): Common pattern maybe a macro would be good here */
    if (!case_sensitive) {
      /* TODO(conni2461): He does some unicode stuff here, investigate */
      c = (char)tolower((uint8_t)c);
    }
    if (normalize) {
      c = normalize_rune(c);
    }
    if (c == pattern->data[pattern_index]) {
      if (!started) {
        sidx = step;
        started = true;
      }
      pidx++;
      if (pidx == M) {
        eidx = step + 1;
        break;
      }
      pattern_index += scan_delta;
    }
    text_index += scan_delta;
  }
  if (started && eidx > 0) {
    size_t remaining = M;
    size_t tighten_delta = forward ? SIZE_MAX : 1;
    text_index = forward ? eidx - 1 : N - eidx;
    pattern_index = forward ? M - 1 : 0;
    for (size_t step = eidx; step-- > sidx;) {
      char c = text->data[text_index];
      if (!case_sensitive) {
        /* TODO(conni2461): He does some unicode stuff here, investigate */
        c = (char)tolower((uint8_t)c);
      }
      if (normalize) {
        c = normalize_rune(c);
      }
      if (c == pattern->data[pattern_index]) {
        remaining--;
        if (remaining == 0) {
          sidx = step;
          break;
        }
        pattern_index += tighten_delta;
      }
      text_index += tighten_delta;
    }

    size_t start = forward ? sidx : N - eidx;
    size_t end = forward ? eidx : N - sidx;
    int32_t score = calculate_score(case_sensitive, normalize, text, pattern,
                                    start, end, pos, slab);
    return (fzf_result_t){(int32_t)start, (int32_t)end, score};
  }
  return (fzf_result_t){-1, -1, 0};
}

fzf_result_t fzf_fuzzy_match_v1_with_direction(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_fuzzy_match_v1_impl(case_sensitive, normalize, forward, text,
                                 pattern, pos, slab, NULL);
}

fzf_result_t fzf_fuzzy_match_v1(bool case_sensitive, bool normalize,
                                fzf_string_t *text, fzf_string_t *pattern,
                                fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_fuzzy_match_v1_impl(case_sensitive, normalize, true, text,
                                 pattern, pos, slab, NULL);
}

static fzf_result_t fzf_fuzzy_match_v2_impl(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab,
    const fzf_ascii_query_plan_t *plan) {
  const size_t M = pattern->size;
  const size_t N = text->size;
  const score_scheme_config_t *config = score_scheme_config(slab);
  if (M == 0) {
    return (fzf_result_t){0, 0, 0};
  }
  if (slab != NULL &&
      (N != 0 && M > SIZE_MAX / N ? true : N * M > slab->I16.cap)) {
    return fzf_fuzzy_match_v1_impl(case_sensitive, normalize, forward, text,
                                   pattern, pos, slab, plan);
  }

  size_t idx;
  {
    int32_t tmp_idx;
    /* Keep the common one-byte incremental query in this hot caller.  The
       compiler can inline try_skip here without expanding every multi-byte
       ascii_fuzzy_index call site. */
    if (M == 1 && N == 1) {
      char pattern_byte = pattern->data[0];
      char text_byte = text->data[0];
      bool exact = text_byte == pattern_byte;
      bool folded = !case_sensitive && pattern_byte >= 'a' &&
                    pattern_byte <= 'z' &&
                    text_byte == pattern_byte - (char)32;
      tmp_idx = exact || folded ? 0 : -1;
    } else if (M == 1) {
      tmp_idx = try_skip(text, case_sensitive, pattern->data[0], 0);
      if (tmp_idx > 0) tmp_idx--;
    } else {
      tmp_idx = ascii_fuzzy_index(text, pattern, plan, case_sensitive);
    }
    if (tmp_idx < 0) {
      return (fzf_result_t){-1, -1, 0};
    }
    idx = (size_t)tmp_idx;
  }

  size_t offset16 = 0;
  size_t offset32 = 0;

  fzf_i16_t h0 = alloc16(&offset16, slab, N);
  fzf_i16_t c0 = alloc16(&offset16, slab, N);
  // Bonus point for each positions
  fzf_i16_t bo = alloc16(&offset16, slab, N);
  // The first occurrence of each character in the pattern
  fzf_i32_t f = alloc32(&offset32, slab, M);
  // Rune array
  fzf_i32_t t = alloc32(&offset32, slab, N);
  if (fzf_allocation_failed()) {
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    return (fzf_result_t){-1, -1, 0};
  }
  copy_runes(text, &t); // input.CopyRunes(T)

  // Phase 2. Calculate bonus for each point
  int16_t max_score = 0;
  size_t max_score_pos = 0;

  size_t pidx = 0;
  size_t last_idx = 0;

  char pchar0 = pattern->data[0];
  char pchar = pattern->data[0];
  int16_t prev_h0 = 0;
  int32_t prev_class = config->initial_class;
  bool in_gap = false;

  i32_slice_t t_sub = slice_i32(t.data, idx, t.size); // T[idx:];
  i16_slice_t h0_sub =
      slice_i16_right(slice_i16(h0.data, idx, h0.size).data, t_sub.size);
  i16_slice_t c0_sub =
      slice_i16_right(slice_i16(c0.data, idx, c0.size).data, t_sub.size);
  i16_slice_t b_sub =
      slice_i16_right(slice_i16(bo.data, idx, bo.size).data, t_sub.size);

  for (size_t off = 0; off < t_sub.size; off++) {
    char_class class;
    char c = (char)t_sub.data[off];
    class = char_class_of_ascii(c, config);
    if (!case_sensitive && class == CharUpper) {
      /* TODO(conni2461): unicode support */
      c = (char)tolower((uint8_t)c);
    }
    if (normalize) {
      c = normalize_rune(c);
    }

    t_sub.data[off] = (uint8_t)c;
    int16_t bonus = bonus_for(config, prev_class, class);
    b_sub.data[off] = bonus;
    prev_class = class;
    if (c == pchar) {
      if (pidx < M) {
        f.data[pidx] = (int32_t)(idx + off);
        pidx++;
        pchar = pattern->data[min64u(pidx, M - 1)];
      }
      last_idx = idx + off;
    }

    if (c == pchar0) {
      int16_t score = ScoreMatch + bonus * BonusFirstCharMultiplier;
      h0_sub.data[off] = score;
      c0_sub.data[off] = 1;
      if (M == 1 && (forward ? score > max_score : score >= max_score)) {
        max_score = score;
        max_score_pos = idx + off;
        if (forward && bonus >= BonusBoundary) {
          break;
        }
      }
      in_gap = false;
    } else {
      if (in_gap) {
        h0_sub.data[off] = max16(prev_h0 + ScoreGapExtention, 0);
      } else {
        h0_sub.data[off] = max16(prev_h0 + ScoreGapStart, 0);
      }
      c0_sub.data[off] = 0;
      in_gap = true;
    }
    prev_h0 = h0_sub.data[off];
  }
  if (pidx != M) {
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    return (fzf_result_t){-1, -1, 0};
  }
  if (M == 1) {
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    fzf_result_t res = {(int32_t)max_score_pos, (int32_t)max_score_pos + 1,
                        max_score};
    append_pos(pos, max_score_pos);
    return res;
  }

  size_t f0 = (size_t)f.data[0];
  size_t width = last_idx - f0 + 1;
  if (M != 0 && width > SIZE_MAX / M) {
    fzf_mark_allocation_failure();
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    return (fzf_result_t){-1, -1, 0};
  }
  size_t matrix_size = width * M;
  fzf_i16_t h = alloc16(&offset16, slab, matrix_size);
  if (fzf_allocation_failed()) {
    free_alloc(h);
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    return (fzf_result_t){-1, -1, 0};
  }
  {
    i16_slice_t h0_tmp_slice = slice_i16(h0.data, f0, last_idx + 1);
    copy_into_i16(&h0_tmp_slice, &h);
  }

  fzf_i16_t c = alloc16(&offset16, slab, matrix_size);
  if (fzf_allocation_failed()) {
    free_alloc(c);
    free_alloc(h);
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    return (fzf_result_t){-1, -1, 0};
  }
  {
    i16_slice_t c0_tmp_slice = slice_i16(c0.data, f0, last_idx + 1);
    copy_into_i16(&c0_tmp_slice, &c);
  }

  i32_slice_t f_sub = slice_i32(f.data, 1, f.size);
  str_slice_t p_sub =
      slice_str_right(slice_str(pattern->data, 1, M).data, f_sub.size);
  for (size_t off = 0; off < f_sub.size; off++) {
    size_t foff = (size_t)f_sub.data[off];
    pchar = p_sub.data[off];
    pidx = off + 1;
    size_t row = pidx * width;
    in_gap = false;
    t_sub = slice_i32(t.data, foff, last_idx + 1);
    b_sub = slice_i16_right(slice_i16(bo.data, foff, bo.size).data, t_sub.size);
    i16_slice_t c_sub = slice_i16_right(
        slice_i16(c.data, row + foff - f0, c.size).data, t_sub.size);
    i16_slice_t c_diag = slice_i16_right(
        slice_i16(c.data, row + foff - f0 - 1 - width, c.size).data,
        t_sub.size);
    i16_slice_t h_sub = slice_i16_right(
        slice_i16(h.data, row + foff - f0, h.size).data, t_sub.size);
    i16_slice_t h_diag = slice_i16_right(
        slice_i16(h.data, row + foff - f0 - 1 - width, h.size).data,
        t_sub.size);
    i16_slice_t h_left = slice_i16_right(
        slice_i16(h.data, row + foff - f0 - 1, h.size).data, t_sub.size);
    h_left.data[0] = 0;
    for (size_t j = 0; j < t_sub.size; j++) {
      char ch = (char)t_sub.data[j];
      size_t col = j + foff;
      int16_t s1 = 0;
      int16_t s2 = 0;
      int16_t consecutive = 0;

      if (in_gap) {
        s2 = h_left.data[j] + ScoreGapExtention;
      } else {
        s2 = h_left.data[j] + ScoreGapStart;
      }

      if (pchar == ch) {
        s1 = h_diag.data[j] + ScoreMatch;
        int16_t b = b_sub.data[j];
        consecutive = c_diag.data[j] + 1;
        if (consecutive > 1) {
          int16_t first_bonus =
              bo.data[col - ((size_t)consecutive) + 1];
          if (b >= BonusBoundary && b > first_bonus)
            consecutive = 1;
          else
            b = max16(b, max16(BonusConsecutive, first_bonus));
        }
        if (s1 + b < s2) {
          s1 += b_sub.data[j];
          consecutive = 0;
        } else {
          s1 += b;
        }
      }
      c_sub.data[j] = consecutive;
      in_gap = s1 < s2;
      int16_t score = max16(max16(s1, s2), 0);
      if (pidx == M - 1 &&
          (forward ? score > max_score : score >= max_score)) {
        max_score = score;
        max_score_pos = col;
      }
      h_sub.data[j] = score;
    }
  }

  resize_pos(pos, M, M);
  size_t j = max_score_pos;
  if (pos) {
    size_t i = M - 1;
    bool prefer_match = true;
    for (;;) {
      size_t ii = i * width;
      size_t j0 = j - f0;
      int16_t s = h.data[ii + j0];

      int16_t s1 = 0;
      int16_t s2 = 0;
      if (i > 0 && j >= f.data[i]) {
        s1 = h.data[ii - width + j0 - 1];
      }
      if (j > f.data[i]) {
        s2 = h.data[ii + j0 - 1];
      }

      size_t row = i;
      if (s > s1 && (s > s2 || (s == s2 && prefer_match))) {
        unsafe_append_pos(pos, j);
        if (i == 0) {
          break;
        }
        i--;
      }
      prefer_match = c.data[ii + j0] > 1 ||
                     (row + 1 < M && j < last_idx &&
                      j + 1 >= (size_t)f.data[row + 1] &&
                      c.data[ii + width + j0 + 1] > 0);
      j--;
    }
  }

  free_alloc(h);
  free_alloc(c);
  free_alloc(t);
  free_alloc(f);
  free_alloc(bo);
  free_alloc(c0);
  free_alloc(h0);
  return (fzf_result_t){(int32_t)j, (int32_t)max_score_pos + 1,
                        (int32_t)max_score};
}

fzf_result_t fzf_fuzzy_match_v2_with_direction(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_fuzzy_match_v2_impl(case_sensitive, normalize, forward, text,
                                 pattern, pos, slab, NULL);
}

fzf_result_t fzf_fuzzy_match_v2(bool case_sensitive, bool normalize,
                                fzf_string_t *text, fzf_string_t *pattern,
                                fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_fuzzy_match_v2_impl(case_sensitive, normalize, true, text,
                                 pattern, pos, slab, NULL);
}

static fzf_result_t fzf_exact_match_impl(
    bool case_sensitive, bool normalize, bool forward, bool boundary_check,
    fzf_string_t *text, fzf_string_t *pattern, fzf_position_t *pos,
    fzf_slab_t *slab, bool parsed_plan_available) {
  const size_t M = pattern->size;
  const size_t N = text->size;
  const score_scheme_config_t *config = score_scheme_config(slab);

  if (M == 0) {
    return (fzf_result_t){0, 0, 0};
  }
  if (N < M) {
    return (fzf_result_t){-1, -1, 0};
  }
  /* Keep the legacy ordered-byte rejection in front of the literal scan.
     It makes a missing query byte a single memchr-class check and avoids
     scanning every SIMD chunk for seed-free misses. */
  if (ascii_fuzzy_index(text, pattern, NULL, case_sensitive) < 0)
    return (fzf_result_t){-1, -1, 0};
  const fzf_ascii_query_plan_t *plan = NULL;
  if (parsed_plan_available && M >= 2 && M <= FZF_SIMD_MAX_PATTERN &&
      N - M + 1 >= FZF_SIMD_LITERAL_MIN_STARTS &&
      fzf_get_simd_prefilter_allowed())
    plan = fzf_ascii_query_plan_from_parsed(pattern);
  int32_t best_pos = -1;
  int16_t best_bonus = -1;
  bool best_has_boundary_bonus = false;
  bool used_plan = false;
#if FZF_HAVE_SIMD_PREFILTER
  /* PLAN is supplied only for byte-classified ASCII candidates.  Unicode
     normalization is therefore the identity operation for this input. */
  if (plan && plan->pattern_size == M &&
      plan->case_sensitive == case_sensitive) {
    used_plan = true;
    size_t from = 0;
    while (from <= N - M) {
      size_t start = fzf_ascii_plan_find_exact(text->data, N, plan, from);
      if (start == SIZE_MAX) break;
      size_t idx = start + M - 1;
      int16_t bonus = bonus_at(text, start, config);
      bool boundary_match =
          !boundary_check ||
          ((start == 0 ||
            !char_class_is_word(
                char_class_of(text->data[start - 1], config))) &&
           (idx + 1 == N ||
            !char_class_is_word(
                char_class_of(text->data[idx + 1], config))));
      if (boundary_match) {
        bool replace = bonus > best_bonus;
        if (!forward) {
          replace = bonus >= BonusBoundary ||
                    (!best_has_boundary_bonus && bonus >= best_bonus);
        }
        if (replace) {
          best_pos = (int32_t)idx;
          best_bonus = bonus;
        }
        if (bonus >= BonusBoundary) best_has_boundary_bonus = true;
      }
      if (boundary_match && forward && bonus >= BonusBoundary) break;
      if (start == N - M) break;
      from = start + 1;
    }
  }
#else
  (void)plan;
#endif

  if (!used_plan) {
    size_t pidx = 0;
    int16_t bonus = 0;
    for (size_t idx = 0; idx < N; idx++) {
      char c = text->data[idx];
      if (!case_sensitive) {
        /* TODO(conni2461): He does some unicode stuff here, investigate */
        c = (char)tolower((uint8_t)c);
      }
      if (normalize) c = normalize_rune(c);
      if (c == pattern->data[pidx]) {
        if (pidx == 0) bonus = bonus_at(text, idx, config);
        pidx++;
        if (pidx == M) {
          size_t start = idx - M + 1;
          bool boundary_match =
              !boundary_check ||
              ((start == 0 ||
                !char_class_is_word(
                    char_class_of(text->data[start - 1], config))) &&
               (idx + 1 == N ||
                !char_class_is_word(
                    char_class_of(text->data[idx + 1], config))));
          if (boundary_match) {
            bool replace = bonus > best_bonus;
            if (!forward) {
              replace = bonus >= BonusBoundary ||
                        (!best_has_boundary_bonus && bonus >= best_bonus);
            }
            if (replace) {
              best_pos = (int32_t)idx;
              best_bonus = bonus;
            }
            if (bonus >= BonusBoundary) best_has_boundary_bonus = true;
          }
          if (boundary_match && forward && bonus >= BonusBoundary) break;
          idx -= pidx - 1;
          pidx = 0;
          bonus = 0;
        }
      } else {
        idx -= pidx;
        pidx = 0;
        bonus = 0;
      }
    }
  }
  if (best_pos >= 0) {
    size_t bp = (size_t)best_pos;
    size_t sidx = bp - M + 1;
    size_t eidx = bp + 1;
    int32_t score;
    if (boundary_check) {
      score = (int32_t)best_bonus + ScoreMatch * (int32_t)M +
              config->boundary_white * ((int32_t)M + 1);
      int32_t deduct = (int32_t)best_bonus - BonusBoundary + 1;
      if (sidx > 0 && text->data[sidx - 1] == '_') {
        score -= deduct + 1;
        deduct = 1;
      }
      if (eidx < N && text->data[eidx] == '_') score -= deduct;
    } else {
      score = calculate_score(case_sensitive, normalize, text, pattern,
                              sidx, eidx, NULL, slab);
    }
    insert_range(pos, sidx, eidx);
    return (fzf_result_t){(int32_t)sidx, (int32_t)eidx, score};
  }
  return (fzf_result_t){-1, -1, 0};
}

fzf_result_t fzf_exact_match_naive_with_direction(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_exact_match_impl(case_sensitive, normalize, forward, false, text,
                              pattern, pos, slab, false);
}

fzf_result_t fzf_exact_match_boundary_with_direction(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_exact_match_impl(case_sensitive, normalize, forward, true, text,
                              pattern, pos, slab, false);
}

fzf_result_t fzf_exact_match_naive(bool case_sensitive, bool normalize,
                                   fzf_string_t *text, fzf_string_t *pattern,
                                   fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_exact_match_impl(case_sensitive, normalize, true, false, text,
                              pattern, pos, slab, false);
}

fzf_result_t fzf_exact_match_boundary(
    bool case_sensitive, bool normalize, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_exact_match_impl(case_sensitive, normalize, true, true, text,
                              pattern, pos, slab, false);
}

fzf_result_t fzf_prefix_match(bool case_sensitive, bool normalize,
                              fzf_string_t *text, fzf_string_t *pattern,
                              fzf_position_t *pos, fzf_slab_t *slab) {
  const size_t M = pattern->size;
  if (M == 0) {
    return (fzf_result_t){0, 0, 0};
  }
  size_t trimmed_len = 0;
  /* TODO(conni2461): i feel this is wrong */
  if (!fzf_unicode_is_space((uint8_t)pattern->data[0])) {
    trimmed_len = leading_whitespaces(text);
  }
  if (text->size - trimmed_len < M) {
    return (fzf_result_t){-1, -1, 0};
  }
  for (size_t i = 0; i < M; i++) {
    char c = text->data[trimmed_len + i];
    if (!case_sensitive) {
      c = (char)tolower((uint8_t)c);
    }
    if (normalize) {
      c = normalize_rune(c);
    }
    if (c != pattern->data[i]) {
      return (fzf_result_t){-1, -1, 0};
    }
  }
  size_t start = trimmed_len;
  size_t end = trimmed_len + M;
  int32_t score = calculate_score(case_sensitive, normalize, text, pattern,
                                  start, end, NULL, slab);
  insert_range(pos, start, end);
  return (fzf_result_t){(int32_t)start, (int32_t)end, score};
}

fzf_result_t fzf_suffix_match(bool case_sensitive, bool normalize,
                              fzf_string_t *text, fzf_string_t *pattern,
                              fzf_position_t *pos, fzf_slab_t *slab) {
  size_t trimmed_len = text->size;
  const size_t M = pattern->size;
  /* TODO(conni2461): i think this is wrong */
  if (M == 0 || !fzf_unicode_is_space((uint8_t)pattern->data[M - 1])) {
    trimmed_len -= trailing_whitespaces(text);
  }
  if (M == 0) {
    return (fzf_result_t){(int32_t)trimmed_len, (int32_t)trimmed_len, 0};
  }
  /* `trimmed_len' and `M' are unsigned, so the original `size_t diff =
     trimmed_len - M; if (diff < 0)' guard was dead and underflowed when the
     candidate was shorter than the suffix pattern, indexing far out of
     bounds below.  Compare before subtracting. (The _utf8 variant already
     guards with `trimmed_len < M'.) */
  if (trimmed_len < M) {
    return (fzf_result_t){-1, -1, 0};
  }
  size_t diff = trimmed_len - M;

  for (size_t idx = 0; idx < M; idx++) {
    char c = text->data[idx + diff];
    if (!case_sensitive) {
      c = (char)tolower((uint8_t)c);
    }
    if (normalize) {
      c = normalize_rune(c);
    }
    if (c != pattern->data[idx]) {
      return (fzf_result_t){-1, -1, 0};
    }
  }
  size_t start = trimmed_len - M;
  size_t end = trimmed_len;
  int32_t score = calculate_score(case_sensitive, normalize, text, pattern,
                                  start, end, NULL, slab);
  insert_range(pos, start, end);
  return (fzf_result_t){(int32_t)start, (int32_t)end, score};
}

fzf_result_t fzf_equal_match(bool case_sensitive, bool normalize,
                             fzf_string_t *text, fzf_string_t *pattern,
                             fzf_position_t *pos, fzf_slab_t *slab) {
  const size_t M = pattern->size;
  const score_scheme_config_t *config = score_scheme_config(slab);
  if (M == 0) {
    return (fzf_result_t){-1, -1, 0};
  }

  size_t trimmed_len = 0;
  if (!fzf_unicode_is_space((uint8_t)pattern->data[0])) {
    trimmed_len = leading_whitespaces(text);
  }
  size_t trimmed_end_len = 0;
  if (!fzf_unicode_is_space((uint8_t)pattern->data[M - 1])) {
    trimmed_end_len = trailing_whitespaces(text);
  }
  size_t content_len = trimmed_len + trimmed_end_len >= text->size
                         ? 0
                         : text->size - trimmed_len - trimmed_end_len;

  if (content_len != M) {
    return (fzf_result_t){-1, -1, 0};
  }

  bool match = true;
  if (normalize) {
    // TODO(conni2461): to rune
    for (size_t idx = 0; idx < M; idx++) {
      char pchar = pattern->data[idx];
      char c = text->data[trimmed_len + idx];
      if (!case_sensitive) {
        c = (char)tolower((uint8_t)c);
      }
      if (normalize_rune(c) != normalize_rune(pchar)) {
        match = false;
        break;
      }
    }
  } else {
    // TODO(conni2461): to rune
    for (size_t idx = 0; idx < M; idx++) {
      char pchar = pattern->data[idx];
      char c = text->data[trimmed_len + idx];
      if (!case_sensitive) {
        c = (char)tolower((uint8_t)c);
      }
      if (c != pchar) {
        match = false;
        break;
      }
    }
  }
  if (match) {
    insert_range(pos, trimmed_len, trimmed_len + M);
    return (fzf_result_t){(int32_t)trimmed_len,
                          ((int32_t)trimmed_len + (int32_t)M),
                          (ScoreMatch + config->boundary_white) * (int32_t)M +
                              (BonusFirstCharMultiplier - 1) *
                                  config->boundary_white};
  }
  return (fzf_result_t){-1, -1, 0};
}

/* UTF-8 aware matching algorithms */

static fzf_result_t fzf_exact_match_utf8_impl(
    bool case_sensitive, bool normalize, bool forward, bool boundary_check,
    fzf_string_t *text, fzf_string_t *pattern, fzf_position_t *pos,
    fzf_slab_t *slab) {
  const size_t M = pattern->size;
  const size_t N = text->size;
  const score_scheme_config_t *config = score_scheme_config(slab);

  if (M == 0) {
    return (fzf_result_t){0, 0, 0};
  }
  if (utf8_strlen(text->data, N) < utf8_strlen(pattern->data, M)) {
    return (fzf_result_t){-1, -1, 0};
  }
  if (!normalize &&
      utf8_fuzzy_index(text, pattern->data, M, case_sensitive) < 0) {
    return (fzf_result_t){-1, -1, 0};
  }
  
  // Build byte-to-char mapping for position conversion
  utf8_char_map_t *char_map = utf8_build_char_map(
      text->data, N, slab ? &slab->UTF8 : NULL);
  if (!char_map) {
    fzf_mark_allocation_failure();
    return (fzf_result_t){-1, -1, 0};
  }

  // Count with the same lossy decoder used by the matching loop.  A raw byte
  // is one unit on both sides, so completion cannot be declared early.
  size_t pattern_cp_count = utf8_strlen(pattern->data, M);

  // UTF-8 exact matching
  size_t text_pos = 0;
  size_t pattern_pos = 0;
  size_t pidx = 0;
  int32_t best_pos = -1;
  int16_t bonus = 0;
  int16_t best_bonus = -1;
  bool best_has_boundary_bonus = false;
  size_t match_start_byte = 0;
  size_t match_start_first_char_bytes = 0;

  while (text_pos < N) {
    utf8proc_int32_t text_cp, pattern_cp;

    // Decode text character
    utf8proc_ssize_t text_bytes = utf8_iterate_lossy(
      (const utf8proc_uint8_t*)(text->data + text_pos),
      N - text_pos, &text_cp);

    // Decode pattern character
    utf8proc_ssize_t pattern_bytes = utf8_iterate_lossy(
      (const utf8proc_uint8_t*)(pattern->data + pattern_pos),
      M - pattern_pos, &pattern_cp);

    if (utf8_char_equal(text_cp, pattern_cp, case_sensitive, normalize)) {
      if (pidx == 0) {
        match_start_byte = text_pos;
        match_start_first_char_bytes = (size_t)text_bytes;
        // Use UTF-8 aware bonus for the match start
        int32_t cur_class = char_class_of_codepoint(text_cp, config);
        if (text_pos == 0) {
          bonus = config->boundary_white;
        } else {
          utf8proc_int32_t prev_cp;
          utf8_lossy_previous_char(text->data, text_pos, &prev_cp);
          int32_t prev_class = char_class_of_codepoint(prev_cp, config);
          bonus = bonus_for(config, prev_class, cur_class);
        }
      }
      pidx++;
      pattern_pos += pattern_bytes;
      text_pos += text_bytes;

      if (pidx == pattern_cp_count) { // All pattern characters matched
        bool boundary_match = true;
        if (boundary_check) {
          if (match_start_byte > 0) {
            utf8proc_int32_t prev_cp;
            utf8_lossy_previous_char(text->data, match_start_byte, &prev_cp);
            boundary_match = !char_class_is_word(
                char_class_of_codepoint(prev_cp, config));
          }
          if (boundary_match && text_pos < N) {
            utf8proc_int32_t next_cp;
            utf8_iterate_lossy(
                (const utf8proc_uint8_t *)(text->data + text_pos),
                N - text_pos, &next_cp);
            boundary_match = !char_class_is_word(
                char_class_of_codepoint(next_cp, config));
          }
        }
        if (boundary_match) {
          bool replace = bonus > best_bonus;
          if (!forward) {
            replace = bonus >= BonusBoundary ||
                      (!best_has_boundary_bonus && bonus >= best_bonus);
          }
          if (replace) {
            best_pos = (int32_t)match_start_byte;
            best_bonus = bonus;
          }
          if (bonus >= BonusBoundary) best_has_boundary_bonus = true;
        }
        if (boundary_match && forward && bonus >= BonusBoundary) {
          break;
        }
        // Reset for next potential match — advance by first matched char's byte length
        text_pos = match_start_byte + match_start_first_char_bytes;
        pattern_pos = 0;
        pidx = 0;
        bonus = 0;
        continue;
      }
    } else {
      if (pidx > 0) {
        // Reset pattern matching — advance by first matched char's byte length
        text_pos = match_start_byte + match_start_first_char_bytes;
        pattern_pos = 0;
        pidx = 0;
        bonus = 0;
        continue;
      }
      text_pos += text_bytes;
    }
  }
  
  if (best_pos >= 0) {
    size_t sidx = (size_t)best_pos;

    // Walk through pattern characters from sidx to find the actual end byte position
    size_t eidx = sidx;
    pattern_pos = 0;
    while (pattern_pos < M && eidx < N) {
      utf8proc_int32_t text_cp_tmp, pattern_cp_tmp;

      utf8proc_ssize_t tb = utf8_iterate_lossy(
        (const utf8proc_uint8_t*)(text->data + eidx),
        N - eidx, &text_cp_tmp);
      utf8proc_ssize_t pb = utf8_iterate_lossy(
        (const utf8proc_uint8_t*)(pattern->data + pattern_pos),
        M - pattern_pos, &pattern_cp_tmp);

      eidx += tb;
      pattern_pos += pb;
    }

    int32_t score;
    if (boundary_check) {
      score = (int32_t)best_bonus +
              ScoreMatch * (int32_t)pattern_cp_count +
              config->boundary_white * ((int32_t)pattern_cp_count + 1);
      int32_t deduct = (int32_t)best_bonus - BonusBoundary + 1;
      if (sidx > 0 && text->data[sidx - 1] == '_') {
        score -= deduct + 1;
        deduct = 1;
      }
      if (eidx < N && text->data[eidx] == '_') score -= deduct;
    } else {
      score = calculate_score_utf8(case_sensitive, normalize, text, pattern,
                                   sidx, eidx, NULL, slab);
    }

    // Convert byte positions to character positions
    size_t char_start = utf8_byte_to_char(char_map, sidx);
    size_t char_end = utf8_byte_to_char(char_map, eidx);

    insert_range(pos, char_start, char_end);

    utf8_free_char_map(char_map);
    return (fzf_result_t){(int32_t)char_start, (int32_t)char_end, score};
  }
  utf8_free_char_map(char_map);
  return (fzf_result_t){-1, -1, 0};
}

fzf_result_t fzf_exact_match_utf8_with_direction(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_exact_match_utf8_impl(case_sensitive, normalize, forward, false,
                                   text, pattern, pos, slab);
}

fzf_result_t fzf_exact_match_boundary_utf8_with_direction(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_exact_match_utf8_impl(case_sensitive, normalize, forward, true,
                                   text, pattern, pos, slab);
}

fzf_result_t fzf_exact_match_utf8(bool case_sensitive, bool normalize,
                                  fzf_string_t *text, fzf_string_t *pattern,
                                  fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_exact_match_utf8_impl(case_sensitive, normalize, true, false,
                                   text, pattern, pos, slab);
}

fzf_result_t fzf_exact_match_boundary_utf8(
    bool case_sensitive, bool normalize, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_exact_match_utf8_impl(case_sensitive, normalize, true, true, text,
                                   pattern, pos, slab);
}

fzf_result_t fzf_prefix_match_utf8(bool case_sensitive, bool normalize,
                                   fzf_string_t *text, fzf_string_t *pattern,
                                   fzf_position_t *pos, fzf_slab_t *slab) {
  const size_t M = pattern->size;
  if (M == 0) {
    return (fzf_result_t){0, 0, 0};
  }

  // Build byte-to-char mapping for position conversion
  utf8_char_map_t *char_map = utf8_build_char_map(
      text->data, text->size, slab ? &slab->UTF8 : NULL);
  if (!char_map) {
    fzf_mark_allocation_failure();
    return (fzf_result_t){-1, -1, 0};
  }

  // Skip leading whitespace if pattern doesn't start with whitespace
  size_t trimmed_start = 0;
  if (M > 0) {
    utf8proc_int32_t first_pattern_cp;
    utf8proc_iterate((const utf8proc_uint8_t*)pattern->data, M, &first_pattern_cp);
    if (!fzf_unicode_is_space(first_pattern_cp)) {
      trimmed_start = leading_whitespaces(text);
    }
  }
  
  if (utf8_strlen(text->data + trimmed_start,
                  text->size - trimmed_start) <
      utf8_strlen(pattern->data, M)) {
    utf8_free_char_map(char_map);
    return (fzf_result_t){-1, -1, 0};
  }

  // Match UTF-8 characters at the beginning
  size_t text_pos = trimmed_start;
  size_t pattern_pos = 0;
  
  while (pattern_pos < M && text_pos < text->size) {
    utf8proc_int32_t text_cp, pattern_cp;
    
    utf8proc_ssize_t text_bytes = utf8_iterate_lossy(
      (const utf8proc_uint8_t*)(text->data + text_pos),
      text->size - text_pos, &text_cp);
    utf8proc_ssize_t pattern_bytes = utf8_iterate_lossy(
      (const utf8proc_uint8_t*)(pattern->data + pattern_pos),
      M - pattern_pos, &pattern_cp);

    if (!utf8_char_equal(text_cp, pattern_cp, case_sensitive, normalize)) {
      utf8_free_char_map(char_map);
      return (fzf_result_t){-1, -1, 0};
    }
    
    text_pos += text_bytes;
    pattern_pos += pattern_bytes;
  }
  
  if (pattern_pos < M) {
    utf8_free_char_map(char_map);
    return (fzf_result_t){-1, -1, 0};
  }
  
  size_t start = trimmed_start;
  size_t end = text_pos;
  int32_t score = calculate_score_utf8(case_sensitive, normalize, text,
                                       pattern, start, end, NULL, slab);

  // Convert byte positions to character positions
  size_t char_start = utf8_byte_to_char(char_map, start);
  size_t char_end = utf8_byte_to_char(char_map, end);

  // Insert character positions instead of byte positions
  insert_range(pos, char_start, char_end);

  utf8_free_char_map(char_map);
  return (fzf_result_t){(int32_t)char_start, (int32_t)char_end, score};
}

fzf_result_t fzf_suffix_match_utf8(bool case_sensitive, bool normalize,
                                   fzf_string_t *text, fzf_string_t *pattern,
                                   fzf_position_t *pos, fzf_slab_t *slab) {
  const size_t M = pattern->size;
  size_t trimmed_len = text->size;
  
  // Build byte-to-char mapping for position conversion
  utf8_char_map_t *char_map = utf8_build_char_map(
      text->data, text->size, slab ? &slab->UTF8 : NULL);
  if (!char_map) {
    fzf_mark_allocation_failure();
    return (fzf_result_t){-1, -1, 0};
  }
  
  // Skip trailing whitespace if pattern is empty or doesn't end with whitespace
  if (M == 0) {
    trimmed_len -= trailing_whitespaces(text);
  } else {
    utf8proc_int32_t last_pattern_cp = 0;
    // Forward scan to find the last codepoint in the pattern
    size_t scan_pos = 0;
    while (scan_pos < M) {
      utf8proc_int32_t cp;
      utf8proc_ssize_t bytes = utf8_iterate_lossy(
        (const utf8proc_uint8_t*)(pattern->data + scan_pos),
        M - scan_pos, &cp);
      last_pattern_cp = cp;
      scan_pos += bytes;
    }

    if (!fzf_unicode_is_space(last_pattern_cp)) {
      trimmed_len -= trailing_whitespaces(text);
    }
  }
  
  if (M == 0) {
    size_t char_len = utf8_byte_to_char(char_map, trimmed_len);
    utf8_free_char_map(char_map);
    return (fzf_result_t){(int32_t)char_len, (int32_t)char_len, 0};
  }
  
  /* Compare from the end in decoded units.  Byte lengths are not a valid
     feasibility test because Unicode lowercasing can expand or shrink the
     encoded pattern while preserving its character count. */
  size_t text_pos = trimmed_len;
  size_t pattern_pos = M;
  while (pattern_pos > 0) {
    if (text_pos == 0) {
      utf8_free_char_map(char_map);
      return (fzf_result_t){-1, -1, 0};
    }
    utf8proc_int32_t text_cp, pattern_cp;
    size_t text_start =
        utf8_lossy_previous_char(text->data, text_pos, &text_cp);
    size_t pattern_start =
        utf8_lossy_previous_char(pattern->data, pattern_pos, &pattern_cp);
    if (!utf8_char_equal(text_cp, pattern_cp, case_sensitive, normalize)) {
      utf8_free_char_map(char_map);
      return (fzf_result_t){-1, -1, 0};
    }
    text_pos = text_start;
    pattern_pos = pattern_start;
  }

  size_t start = text_pos;
  size_t end = trimmed_len;
  int32_t score = calculate_score_utf8(case_sensitive, normalize, text,
                                       pattern, start, end, NULL, slab);

  // Convert byte positions to character positions
  size_t char_start = utf8_byte_to_char(char_map, start);
  size_t char_end = utf8_byte_to_char(char_map, end);

  // Insert character positions instead of byte positions
  insert_range(pos, char_start, char_end);

  utf8_free_char_map(char_map);
  return (fzf_result_t){(int32_t)char_start, (int32_t)char_end, score};
}

fzf_result_t fzf_equal_match_utf8(bool case_sensitive, bool normalize,
                                  fzf_string_t *text, fzf_string_t *pattern,
                                  fzf_position_t *pos, fzf_slab_t *slab) {
  const size_t M = pattern->size;
  const score_scheme_config_t *config = score_scheme_config(slab);
  if (M == 0) {
    return (fzf_result_t){-1, -1, 0};
  }

  // Build byte-to-char mapping for position conversion
  utf8_char_map_t *char_map = utf8_build_char_map(
      text->data, text->size, slab ? &slab->UTF8 : NULL);
  if (!char_map) {
    fzf_mark_allocation_failure();
    return (fzf_result_t){-1, -1, 0};
  }

  utf8proc_int32_t first_pattern_cp = 0;
  (void)utf8_iterate_lossy(
      (const utf8proc_uint8_t *)pattern->data, M, &first_pattern_cp);
  utf8proc_int32_t last_pattern_cp = first_pattern_cp;
  for (size_t pattern_pos = 0; pattern_pos < M;) {
    utf8proc_int32_t cp;
    utf8proc_ssize_t width = utf8_iterate_lossy(
        (const utf8proc_uint8_t *)pattern->data + pattern_pos,
        (utf8proc_ssize_t)(M - pattern_pos), &cp);
    last_pattern_cp = cp;
    pattern_pos += (size_t)width;
  }

  size_t trimmed_start = 0;
  if (!fzf_unicode_is_space(first_pattern_cp)) {
    trimmed_start = leading_whitespaces(text);
  }
  size_t trimmed_end_len = 0;
  if (!fzf_unicode_is_space(last_pattern_cp)) {
    trimmed_end_len = trailing_whitespaces(text);
  }
  /* Leading and trailing whitespace regions overlap when the candidate is
     entirely whitespace.  Clamp that case to an empty content slice instead
     of underflowing size_t and asking utf8_strlen to scan arbitrary memory. */
  size_t content_byte_len = trimmed_start + trimmed_end_len >= text->size
                              ? 0
                              : text->size - trimmed_start - trimmed_end_len;

  // Count codepoints in text content and pattern for accurate comparison
  size_t text_cp_count = utf8_strlen(text->data + trimmed_start, content_byte_len);
  size_t pattern_cp_count = utf8_strlen(pattern->data, M);

  if (text_cp_count != pattern_cp_count) {
    utf8_free_char_map(char_map);
    return (fzf_result_t){-1, -1, 0};
  }

  // Character-by-character comparison
  size_t text_pos = trimmed_start;
  size_t pattern_pos = 0;
  size_t char_count = 0;
  
  size_t content_end = trimmed_start + content_byte_len;
  while (pattern_pos < M && text_pos < content_end) {
    utf8proc_int32_t text_cp, pattern_cp;

    utf8proc_ssize_t text_bytes = utf8_iterate_lossy(
      (const utf8proc_uint8_t*)(text->data + text_pos),
      content_end - text_pos, &text_cp);
    utf8proc_ssize_t pattern_bytes = utf8_iterate_lossy(
      (const utf8proc_uint8_t*)(pattern->data + pattern_pos),
      M - pattern_pos, &pattern_cp);

    if (!utf8_char_equal(text_cp, pattern_cp, case_sensitive, normalize)) {
      utf8_free_char_map(char_map);
      return (fzf_result_t){-1, -1, 0};
    }

    text_pos += text_bytes;
    pattern_pos += pattern_bytes;
    char_count++;
  }

  // Ensure we consumed all of both strings
  if (pattern_pos != M || text_pos != content_end) {
    utf8_free_char_map(char_map);
    return (fzf_result_t){-1, -1, 0};
  }

  // Convert byte positions to character positions
  size_t char_start = utf8_byte_to_char(char_map, trimmed_start);
  size_t char_end = utf8_byte_to_char(char_map, content_end);
  
  // Insert character positions instead of byte positions
  insert_range(pos, char_start, char_end);
  
  utf8_free_char_map(char_map);
  return (fzf_result_t){(int32_t)char_start,
                        (int32_t)char_end,
                        (ScoreMatch + config->boundary_white) *
                                (int32_t)char_count +
                            (BonusFirstCharMultiplier - 1) *
                                config->boundary_white};
}

static fzf_result_t fzf_fuzzy_match_v1_utf8_impl(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  const size_t M = pattern->size;
  const size_t N = text->size;

  if (M == 0) {
    return (fzf_result_t){0, 0, 0};
  }

  if (!normalize &&
      utf8_fuzzy_index(text, pattern->data, M, case_sensitive) < 0) {
    return (fzf_result_t){-1, -1, 0};
  }

  utf8_char_map_t *char_map = utf8_build_char_map(
      text->data, N, slab ? &slab->UTF8 : NULL);
  if (!char_map) {
    fzf_mark_allocation_failure();
    return (fzf_result_t){-1, -1, 0};
  }

  size_t start = 0;
  size_t end = 0;
  bool matched = false;
  if (forward) {
    size_t text_pos = 0;
    size_t pattern_pos = 0;
    bool started = false;
    while (text_pos < N && pattern_pos < M) {
      utf8proc_int32_t text_cp, pattern_cp;
      utf8proc_ssize_t text_bytes = utf8_iterate_lossy(
          (const utf8proc_uint8_t *)text->data + text_pos, N - text_pos,
          &text_cp);
      utf8proc_ssize_t pattern_bytes = utf8_iterate_lossy(
          (const utf8proc_uint8_t *)pattern->data + pattern_pos,
          M - pattern_pos, &pattern_cp);
      if (utf8_char_equal(text_cp, pattern_cp, case_sensitive, normalize)) {
        if (!started) {
          start = text_pos;
          started = true;
        }
        pattern_pos += (size_t)pattern_bytes;
        if (pattern_pos == M) {
          end = text_pos + (size_t)text_bytes;
          matched = true;
          break;
        }
      }
      text_pos += (size_t)text_bytes;
    }
    if (matched) {
      size_t pattern_pos = M;
      size_t text_pos = end;
      while (text_pos > start && pattern_pos > 0) {
        utf8proc_int32_t text_cp, pattern_cp;
        size_t previous_text =
            utf8_lossy_previous_char(text->data, text_pos, &text_cp);
        size_t previous_pattern =
            utf8_lossy_previous_char(pattern->data, pattern_pos, &pattern_cp);
        text_pos = previous_text;
        if (utf8_char_equal(text_cp, pattern_cp, case_sensitive, normalize)) {
          pattern_pos = previous_pattern;
          if (pattern_pos == 0) start = text_pos;
        }
      }
    }
  } else {
    size_t text_pos = N;
    size_t pattern_pos = M;
    bool started = false;
    while (text_pos > 0 && pattern_pos > 0) {
      utf8proc_int32_t text_cp, pattern_cp;
      size_t previous_text =
          utf8_lossy_previous_char(text->data, text_pos, &text_cp);
      size_t previous_pattern =
          utf8_lossy_previous_char(pattern->data, pattern_pos, &pattern_cp);
      if (utf8_char_equal(text_cp, pattern_cp, case_sensitive, normalize)) {
        if (!started) {
          end = text_pos;
          started = true;
        }
        pattern_pos = previous_pattern;
        if (pattern_pos == 0) {
          start = previous_text;
          matched = true;
          break;
        }
      }
      text_pos = previous_text;
    }
    if (matched) {
      size_t text_pos = start;
      size_t pattern_pos = 0;
      while (text_pos < end && pattern_pos < M) {
        utf8proc_int32_t text_cp, pattern_cp;
        utf8proc_ssize_t text_bytes = utf8_iterate_lossy(
            (const utf8proc_uint8_t *)text->data + text_pos, end - text_pos,
            &text_cp);
        utf8proc_ssize_t pattern_bytes = utf8_iterate_lossy(
            (const utf8proc_uint8_t *)pattern->data + pattern_pos,
            M - pattern_pos, &pattern_cp);
        if (utf8_char_equal(text_cp, pattern_cp, case_sensitive, normalize)) {
          pattern_pos += (size_t)pattern_bytes;
          if (pattern_pos == M) {
            end = text_pos + (size_t)text_bytes;
            break;
          }
        }
        text_pos += (size_t)text_bytes;
      }
    }
  }

  if (!matched) {
    utf8_free_char_map(char_map);
    return (fzf_result_t){-1, -1, 0};
  }
  int32_t score = calculate_score_utf8(case_sensitive, normalize, text,
                                       pattern, start, end, pos, slab);
  size_t char_start = utf8_byte_to_char(char_map, start);
  size_t char_end = utf8_byte_to_char(char_map, end);
  if (pos) {
    for (size_t i = 0; i < pos->size; i++)
      pos->data[i] = utf8_byte_to_char(char_map, pos->data[i]);
  }
  utf8_free_char_map(char_map);
  return (fzf_result_t){(int32_t)char_start, (int32_t)char_end, score};
}

fzf_result_t fzf_fuzzy_match_v1_utf8_with_direction(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_fuzzy_match_v1_utf8_impl(case_sensitive, normalize, forward,
                                      text, pattern, pos, slab);
}

fzf_result_t fzf_fuzzy_match_v1_utf8(
    bool case_sensitive, bool normalize, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_fuzzy_match_v1_utf8_impl(case_sensitive, normalize, true, text,
                                      pattern, pos, slab);
}

static fzf_result_t fzf_fuzzy_match_v2_utf8_impl(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  const size_t M = pattern->size;
  const size_t N = text->size;
  const score_scheme_config_t *config = score_scheme_config(slab);

  if (M == 0) {
    return (fzf_result_t){0, 0, 0};
  }

  bool cached_pattern_cps = !normalize && pattern->codepoints != NULL &&
      pattern->codepoints_case_folded == !case_sensitive;
  const size_t Mc = cached_pattern_cps
                      ? pattern->codepoint_count
                      : utf8_strlen(pattern->data, M);

  if (Mc == 0) {
    return (fzf_result_t){0, 0, 0};
  }

  /* Reject non-matches before building the byte-to-character table.  The
     table decodes the whole candidate twice and writes one slot per byte;
     none of that state is observed when the subsequence prefilter fails. */
  size_t tmp_idx = 0;
  size_t candidate_char_count = 0;
  if (!utf8_fuzzy_index_size(text, pattern->data, M, case_sensitive,
                             normalize, true, &tmp_idx,
                             &candidate_char_count)) {
    return (fzf_result_t){-1, -1, 0};
  }

  /* The prefilter already counted the candidate with the same lossy decoder
     used by both matchers.  Decide whether v2 fits before constructing its
     byte-to-character table; v1 builds the table it needs itself. */
  bool v2_size_overflows = candidate_char_count != 0 &&
                           Mc > SIZE_MAX / candidate_char_count;
  if (slab != NULL &&
      (v2_size_overflows ||
       candidate_char_count * Mc > slab->I16.cap)) {
    return fzf_fuzzy_match_v1_utf8_impl(case_sensitive, normalize, forward,
                                        text, pattern, pos, slab);
  }

  // Build byte-to-char mapping for character position tracking
  utf8_char_map_t *char_map = utf8_build_char_map_counted(
      text->data, N, candidate_char_count, slab ? &slab->UTF8 : NULL);
  if (!char_map) {
    fzf_mark_allocation_failure();
    return (fzf_result_t){-1, -1, 0};
  }

  const size_t Nc = char_map->char_count;

  // Start one character before the first match, just as ascii_fuzzy_index
  // does for the byte matcher.  Phase 2 needs that character to establish
  // the real boundary/camel bonus at the first match; starting directly at
  // the match incorrectly treats every non-initial UTF-8 match as a word
  // boundary.
  size_t match_idx = utf8_byte_to_char(char_map, tmp_idx);
  size_t idx = match_idx > 0 ? match_idx - 1 : 0;

  // Pre-decode pattern codepoints (case-folded if needed)
  if (Mc > SIZE_MAX / sizeof(utf8proc_int32_t)) {
    fzf_mark_allocation_failure();
    utf8_free_char_map(char_map);
    return (fzf_result_t){-1, -1, 0};
  }
  utf8proc_int32_t *owned_pattern_cps = NULL;
  const utf8proc_int32_t *pattern_cps = pattern->codepoints;
  if (!cached_pattern_cps) {
    owned_pattern_cps = malloc(Mc * sizeof *owned_pattern_cps);
    if (!owned_pattern_cps) {
      fzf_mark_allocation_failure();
      utf8_free_char_map(char_map);
      return (fzf_result_t){-1, -1, 0};
    }
    pattern_cps = owned_pattern_cps;
    size_t p_pos = 0;
    for (size_t i = 0; i < Mc; i++) {
      utf8proc_ssize_t bytes = utf8_iterate_lossy(
          (const utf8proc_uint8_t *)(pattern->data + p_pos), M - p_pos,
          &owned_pattern_cps[i]);
      if (!case_sensitive) {
        owned_pattern_cps[i] = utf8proc_case_fold(owned_pattern_cps[i]);
      }
      if (normalize) {
        owned_pattern_cps[i] =
            fzf_normalize_codepoint(owned_pattern_cps[i]);
      }
      p_pos += bytes;
    }
  }

  size_t offset16 = 0;
  size_t offset32 = 0;

  // Allocate arrays sized by character counts
  fzf_i16_t h0 = alloc16(&offset16, slab, Nc);
  fzf_i16_t c0 = alloc16(&offset16, slab, Nc);
  fzf_i16_t bo = alloc16(&offset16, slab, Nc);
  fzf_i32_t f = alloc32(&offset32, slab, Mc);
  fzf_i32_t t = alloc32(&offset32, slab, Nc);
  if (fzf_allocation_failed()) {
    free(owned_pattern_cps);
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    utf8_free_char_map(char_map);
    return (fzf_result_t){-1, -1, 0};
  }

  // Decode all text codepoints into t[]
  {
    size_t byte_pos = 0;
    for (size_t i = 0; i < Nc; i++) {
      utf8proc_int32_t cp;
      utf8proc_ssize_t bytes = utf8_iterate_lossy(
          (const utf8proc_uint8_t *)(text->data + byte_pos), N - byte_pos,
          &cp);
      t.data[i] = cp;
      byte_pos += bytes;
    }
  }

  // Phase 2: Forward scan - calculate bonus and build h0, c0, bo, f
  int16_t max_score = 0;
  size_t max_score_pos = 0;

  size_t pidx = 0;
  size_t last_idx = 0;

  utf8proc_int32_t pchar0 = pattern_cps[0];
  utf8proc_int32_t pchar = pattern_cps[0];
  int16_t prev_h0 = 0;
  int32_t prev_class = config->initial_class;
  bool in_gap = false;

  i32_slice_t t_sub = slice_i32(t.data, idx, t.size);
  i16_slice_t h0_sub =
      slice_i16_right(slice_i16(h0.data, idx, h0.size).data, t_sub.size);
  i16_slice_t c0_sub =
      slice_i16_right(slice_i16(c0.data, idx, c0.size).data, t_sub.size);
  i16_slice_t b_sub =
      slice_i16_right(slice_i16(bo.data, idx, bo.size).data, t_sub.size);

  for (size_t off = 0; off < t_sub.size; off++) {
    utf8proc_int32_t cp = t_sub.data[off];
    char_class class = char_class_of_codepoint(cp, config);

    utf8proc_int32_t c = cp;
    if (!case_sensitive) {
      c = v2_case_fold_candidate(cp);
    }
    if (normalize) {
      c = fzf_normalize_codepoint(c);
    }

    t_sub.data[off] = c;
    int16_t bonus = bonus_for(config, prev_class, class);
    b_sub.data[off] = bonus;
    prev_class = class;

    if (c == pchar) {
      if (pidx < Mc) {
        f.data[pidx] = (int32_t)(idx + off);
        pidx++;
        pchar = pattern_cps[min64u(pidx, Mc - 1)];
      }
      last_idx = idx + off;
    }

    if (c == pchar0) {
      int16_t score = ScoreMatch + bonus * BonusFirstCharMultiplier;
      h0_sub.data[off] = score;
      c0_sub.data[off] = 1;
      if (Mc == 1 && (forward ? score > max_score : score >= max_score)) {
        max_score = score;
        max_score_pos = idx + off;
        if (forward && bonus >= BonusBoundary) {
          break;
        }
      }
      in_gap = false;
    } else {
      if (in_gap) {
        h0_sub.data[off] = max16(prev_h0 + ScoreGapExtention, 0);
      } else {
        h0_sub.data[off] = max16(prev_h0 + ScoreGapStart, 0);
      }
      c0_sub.data[off] = 0;
      in_gap = true;
    }
    prev_h0 = h0_sub.data[off];
  }

  if (pidx != Mc) {
    free(owned_pattern_cps);
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    utf8_free_char_map(char_map);
    return (fzf_result_t){-1, -1, 0};
  }

  if (Mc == 1) {
    free(owned_pattern_cps);
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    utf8_free_char_map(char_map);
    fzf_result_t res = {(int32_t)max_score_pos, (int32_t)max_score_pos + 1,
                        max_score};
    append_pos(pos, max_score_pos);
    return res;
  }

  // Phase 3: DP matrix
  size_t f0 = (size_t)f.data[0];
  size_t width = last_idx - f0 + 1;
  if (Mc != 0 && width > SIZE_MAX / Mc) {
    fzf_mark_allocation_failure();
    free(owned_pattern_cps);
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    utf8_free_char_map(char_map);
    return (fzf_result_t){-1, -1, 0};
  }
  size_t matrix_size = width * Mc;
  fzf_i16_t h = alloc16(&offset16, slab, matrix_size);
  if (fzf_allocation_failed()) {
    free(owned_pattern_cps);
    free_alloc(h);
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    utf8_free_char_map(char_map);
    return (fzf_result_t){-1, -1, 0};
  }
  {
    i16_slice_t h0_tmp_slice = slice_i16(h0.data, f0, last_idx + 1);
    copy_into_i16(&h0_tmp_slice, &h);
  }

  fzf_i16_t c = alloc16(&offset16, slab, matrix_size);
  if (fzf_allocation_failed()) {
    free(owned_pattern_cps);
    free_alloc(c);
    free_alloc(h);
    free_alloc(t);
    free_alloc(f);
    free_alloc(bo);
    free_alloc(c0);
    free_alloc(h0);
    utf8_free_char_map(char_map);
    return (fzf_result_t){-1, -1, 0};
  }
  {
    i16_slice_t c0_tmp_slice = slice_i16(c0.data, f0, last_idx + 1);
    copy_into_i16(&c0_tmp_slice, &c);
  }

  i32_slice_t f_sub = slice_i32(f.data, 1, f.size);
  for (size_t off = 0; off < f_sub.size; off++) {
    size_t foff = (size_t)f_sub.data[off];
    pchar = pattern_cps[off + 1];
    pidx = off + 1;
    size_t row = pidx * width;
    in_gap = false;
    t_sub = slice_i32(t.data, foff, last_idx + 1);
    b_sub =
        slice_i16_right(slice_i16(bo.data, foff, bo.size).data, t_sub.size);
    i16_slice_t c_sub = slice_i16_right(
        slice_i16(c.data, row + foff - f0, c.size).data, t_sub.size);
    i16_slice_t c_diag = slice_i16_right(
        slice_i16(c.data, row + foff - f0 - 1 - width, c.size).data,
        t_sub.size);
    i16_slice_t h_sub = slice_i16_right(
        slice_i16(h.data, row + foff - f0, h.size).data, t_sub.size);
    i16_slice_t h_diag = slice_i16_right(
        slice_i16(h.data, row + foff - f0 - 1 - width, h.size).data,
        t_sub.size);
    i16_slice_t h_left = slice_i16_right(
        slice_i16(h.data, row + foff - f0 - 1, h.size).data, t_sub.size);
    h_left.data[0] = 0;

    for (size_t j = 0; j < t_sub.size; j++) {
      utf8proc_int32_t ch = t_sub.data[j];
      size_t col = j + foff;
      int16_t s1 = 0;
      int16_t s2 = 0;
      int16_t consecutive = 0;

      if (in_gap) {
        s2 = h_left.data[j] + ScoreGapExtention;
      } else {
        s2 = h_left.data[j] + ScoreGapStart;
      }

      if (pchar == ch) {
        s1 = h_diag.data[j] + ScoreMatch;
        int16_t b = b_sub.data[j];
        consecutive = c_diag.data[j] + 1;
        if (consecutive > 1) {
          int16_t first_bonus =
              bo.data[col - ((size_t)consecutive) + 1];
          if (b >= BonusBoundary && b > first_bonus)
            consecutive = 1;
          else
            b = max16(b, max16(BonusConsecutive, first_bonus));
        }
        if (s1 + b < s2) {
          s1 += b_sub.data[j];
          consecutive = 0;
        } else {
          s1 += b;
        }
      }
      c_sub.data[j] = consecutive;
      in_gap = s1 < s2;
      int16_t score = max16(max16(s1, s2), 0);
      if (pidx == Mc - 1 &&
          (forward ? score > max_score : score >= max_score)) {
        max_score = score;
        max_score_pos = col;
      }
      h_sub.data[j] = score;
    }
  }

  // Phase 4: Backtrace
  resize_pos(pos, Mc, Mc);
  size_t j = max_score_pos;
  if (pos) {
    size_t i = Mc - 1;
    bool prefer_match = true;
    for (;;) {
      size_t ii = i * width;
      size_t j0 = j - f0;
      int16_t s = h.data[ii + j0];

      int16_t s1 = 0;
      int16_t s2 = 0;
      if (i > 0 && j >= (size_t)f.data[i]) {
        s1 = h.data[ii - width + j0 - 1];
      }
      if (j > (size_t)f.data[i]) {
        s2 = h.data[ii + j0 - 1];
      }

      size_t row = i;
      if (s > s1 && (s > s2 || (s == s2 && prefer_match))) {
        unsafe_append_pos(pos, j);
        if (i == 0) {
          break;
        }
        i--;
      }
      prefer_match = c.data[ii + j0] > 1 ||
                     (row + 1 < Mc && j < last_idx &&
                      j + 1 >= (size_t)f.data[row + 1] &&
                      c.data[ii + width + j0 + 1] > 0);
      j--;
    }
  }

  // Cleanup
  free(owned_pattern_cps);
  free_alloc(h);
  free_alloc(c);
  free_alloc(t);
  free_alloc(f);
  free_alloc(bo);
  free_alloc(c0);
  free_alloc(h0);
  utf8_free_char_map(char_map);

  return (fzf_result_t){(int32_t)j, (int32_t)max_score_pos + 1,
                        (int32_t)max_score};
}

fzf_result_t fzf_fuzzy_match_v2_utf8_with_direction(
    bool case_sensitive, bool normalize, bool forward, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_fuzzy_match_v2_utf8_impl(case_sensitive, normalize, forward,
                                      text, pattern, pos, slab);
}

fzf_result_t fzf_fuzzy_match_v2_utf8(
    bool case_sensitive, bool normalize, fzf_string_t *text,
    fzf_string_t *pattern, fzf_position_t *pos, fzf_slab_t *slab) {
  return fzf_fuzzy_match_v2_utf8_impl(case_sensitive, normalize, true, text,
                                      pattern, pos, slab);
}

static bool append_set(fzf_term_set_t *set, fzf_term_t value) {
  if (set->size == SIZE_MAX) return false;
  size_t needed = set->size + 1;
  if (needed > set->cap) {
    size_t new_cap = set->cap ? set->cap : 1;
    while (new_cap < needed) {
      if (new_cap > SIZE_MAX / 2) {
        new_cap = needed;
        break;
      }
      new_cap *= 2;
    }
    if (new_cap > SIZE_MAX / sizeof *set->ptr) return false;
    fzf_term_t *new_ptr = realloc(
        set->ptr, new_cap * sizeof *set->ptr);
    if (!new_ptr) return false;
    set->ptr = new_ptr;
    set->cap = new_cap;
  }
  set->ptr[set->size] = value;
  set->size++;
  return true;
}

static bool append_pattern(fzf_pattern_t *pattern, fzf_term_set_t *value) {
  if (pattern->size == SIZE_MAX) return false;
  size_t needed = pattern->size + 1;
  if (needed > pattern->cap) {
    size_t new_cap = pattern->cap ? pattern->cap : 1;
    while (new_cap < needed) {
      if (new_cap > SIZE_MAX / 2) {
        new_cap = needed;
        break;
      }
      new_cap *= 2;
    }
    if (new_cap > SIZE_MAX / sizeof *pattern->ptr) return false;
    fzf_term_set_t **new_ptr = realloc(
        pattern->ptr, new_cap * sizeof *pattern->ptr);
    if (!new_ptr) return false;
    pattern->ptr = new_ptr;
    pattern->cap = new_cap;
  }
  pattern->ptr[pattern->size] = value;
  pattern->size++;
  return true;
}

static fzf_string_t *make_pattern_text(const char *data, size_t size,
                                       bool case_sensitive) {
  size_t count = utf8_strlen(data, size);
  size_t plan_pattern_size =
      is_ascii_utf8proc(data, size) && size >= 2 &&
              size <= FZF_SIMD_MAX_PATTERN
          ? size
          : 0;
  size_t plan_size = fzf_ascii_query_plan_size(plan_pattern_size);
#if FZF_HAVE_SIMD_PREFILTER
  if (plan_size == 0) return NULL;
#endif
  if (count > (SIZE_MAX - sizeof(fzf_string_t)) /
                  sizeof(utf8proc_int32_t))
    return NULL;
  size_t codepoint_bytes = count * sizeof(utf8proc_int32_t);
  size_t plan_offset = sizeof(fzf_string_t) + codepoint_bytes;
#if FZF_HAVE_SIMD_PREFILTER
  size_t alignment = FZF_SIMD_PLAN_ALIGNMENT;
  size_t remainder = plan_offset % alignment;
  if (remainder != 0) {
    size_t padding = alignment - remainder;
    if (padding > SIZE_MAX - plan_offset) return NULL;
    plan_offset += padding;
  }
#endif
  if (plan_size > SIZE_MAX - plan_offset) return NULL;
  fzf_string_t *text = malloc(plan_offset + plan_size);
  if (!text) return NULL;
  utf8proc_int32_t *codepoints = (utf8proc_int32_t *)(text + 1);
#if FZF_HAVE_SIMD_PREFILTER
  fzf_ascii_query_plan_t *plan =
      (fzf_ascii_query_plan_t *)((unsigned char *)text + plan_offset);
  fzf_ascii_query_plan_init(plan, data, plan_pattern_size, case_sensitive);
#endif
  *text = (fzf_string_t){
      .data = data,
      .size = size,
      .codepoints = codepoints,
      .codepoint_count = count,
      .codepoints_case_folded = !case_sensitive,
  };
  size_t byte_pos = 0;
  for (size_t i = 0; i < count; i++) {
    utf8proc_ssize_t width = utf8_iterate_lossy(
        (const utf8proc_uint8_t *)data + byte_pos,
        (utf8proc_ssize_t)(size - byte_pos), &codepoints[i]);
    if (!case_sensitive) codepoints[i] = utf8proc_case_fold(codepoints[i]);
    byte_pos += (size_t)width;
  }
  return text;
}

static void free_term_set(fzf_term_set_t *set) {
  if (!set) return;
  for (size_t i = 0; i < set->size; i++) {
    free(set->ptr[i].ptr);
    free(set->ptr[i].text);
  }
  free(set->ptr);
  free(set);
}

// Helper function to get the UTF-8 version of an algorithm
static fzf_algo_t get_utf8_algo(fzf_algo_t ascii_algo) {
  if (ascii_algo == fzf_fuzzy_match_v2) return fzf_fuzzy_match_v2_utf8;
  if (ascii_algo == fzf_fuzzy_match_v1) return fzf_fuzzy_match_v1_utf8;
  if (ascii_algo == fzf_exact_match_naive) return fzf_exact_match_utf8;
  if (ascii_algo == fzf_exact_match_boundary)
    return fzf_exact_match_boundary_utf8;
  if (ascii_algo == fzf_prefix_match) return fzf_prefix_match_utf8;
  if (ascii_algo == fzf_suffix_match) return fzf_suffix_match_utf8;
  if (ascii_algo == fzf_equal_match) return fzf_equal_match_utf8;
  return ascii_algo; // fallback
}

static inline const fzf_ascii_query_plan_t *fzf_fuzzy_query_plan(
    const fzf_string_t *input, const fzf_string_t *pattern) {
  if (pattern->size < FZF_SIMD_FUZZY_MIN_PATTERN ||
      pattern->size > FZF_SIMD_MAX_PATTERN ||
      input->size < FZF_SIMD_FUZZY_MIN_TEXT ||
      !fzf_get_simd_prefilter_allowed())
    return NULL;
  return fzf_ascii_query_plan_from_parsed(pattern);
}

static inline fzf_result_t call_alg_for_input(
    fzf_term_t *term, bool normalize, fzf_string_t *input,
    bool input_is_ascii, bool forward, fzf_position_t *pos,
    fzf_slab_t *slab) {
  (void)normalize;
  fzf_algo_t algo = term->fn;
  if (!input_is_ascii) {
    /* Get UTF-8 version of the algorithm */
    algo = get_utf8_algo(algo);
  }
  fzf_string_t *pattern = (fzf_string_t *)term->text;
  if (algo == fzf_fuzzy_match_v1) {
    const fzf_ascii_query_plan_t *plan =
        fzf_fuzzy_query_plan(input, pattern);
    return fzf_fuzzy_match_v1_impl(
        term->case_sensitive, term->normalize, forward, input, pattern, pos,
        slab, plan);
  }
  if (algo == fzf_fuzzy_match_v2) {
    const fzf_ascii_query_plan_t *plan =
        fzf_fuzzy_query_plan(input, pattern);
    return fzf_fuzzy_match_v2_impl(
        term->case_sensitive, term->normalize, forward, input, pattern, pos,
        slab, plan);
  }
  if (algo == fzf_exact_match_naive) {
    return fzf_exact_match_impl(
        term->case_sensitive, term->normalize, forward, false, input, pattern,
        pos, slab, true);
  }
  if (algo == fzf_exact_match_boundary) {
    return fzf_exact_match_impl(
        term->case_sensitive, term->normalize, forward, true, input, pattern,
        pos, slab, true);
  }
  if (algo == fzf_fuzzy_match_v1_utf8)
    return fzf_fuzzy_match_v1_utf8_with_direction(
        term->case_sensitive, term->normalize, forward, input, pattern, pos,
        slab);
  if (algo == fzf_fuzzy_match_v2_utf8)
    return fzf_fuzzy_match_v2_utf8_with_direction(
        term->case_sensitive, term->normalize, forward, input, pattern, pos,
        slab);
  if (algo == fzf_exact_match_utf8)
    return fzf_exact_match_utf8_with_direction(
        term->case_sensitive, term->normalize, forward, input, pattern, pos,
        slab);
  if (algo == fzf_exact_match_boundary_utf8)
    return fzf_exact_match_boundary_utf8_with_direction(
        term->case_sensitive, term->normalize, forward, input, pattern, pos,
        slab);
  return algo(term->case_sensitive, term->normalize, input, pattern, pos,
              slab);
}

#define CALL_ALG(term, normalize, input, input_is_ascii, forward, pos, slab) \
  call_alg_for_input(term, normalize, &(input), input_is_ascii, forward, pos, \
                     slab)

// TODO(conni2461): REFACTOR
/* assumption (maybe i change that later)
 * - always v2 alg
 * - bool extended always true (thats the whole point of this isn't it)
 */
fzf_pattern_t *fzf_parse_pattern_with_direction(
    fzf_case_types case_mode, bool normalize, char *pattern, bool fuzzy,
    bool forward) {
  if (!pattern) return NULL;
  fzf_pattern_t *pat_obj = calloc(1, sizeof *pat_obj);
  if (!pat_obj) return NULL;
  pat_obj->forward = forward;
  char *pattern_copy = NULL;
  fzf_term_set_t *set = NULL;

  size_t pat_len = strlen(pattern);
  if (pat_len == 0) {
    return pat_obj;
  }
  pattern = trim_whitespace_left(pattern, &pat_len);
  while (has_suffix(pattern, pat_len, " ", 1) &&
         !has_suffix(pattern, pat_len, "\\ ", 2)) {
    pattern[pat_len - 1] = 0;
    pat_len--;
  }

  pattern_copy = str_replace(pattern, "\\ ", "\t");
  if (!pattern_copy) goto parse_failure;
  const char *delim = " ";
  char *token_state = NULL;
  char *ptr = fzf_strtok_r(pattern_copy, delim, &token_state);

  set = calloc(1, sizeof *set);
  if (!set) goto parse_failure;

  bool switch_set = false;
  bool after_bar = false;
  while (ptr != NULL) {
    fzf_algo_t fn = fzf_fuzzy_match_v2;
    bool inv = false;

    size_t len = strlen(ptr);
    str_replace_char(ptr, '\t', ' ');
    char *text = str_duplicate(ptr, len);
    if (!text) goto parse_failure;

    char *og_str = text;
    char *lower_text = str_tolower(text, len);
    if (!lower_text) {
      free(og_str);
      goto parse_failure;
    }
    size_t lower_len = strlen(lower_text);
    bool normalize_term =
        normalize && pattern_can_normalize(lower_text, lower_len);
    bool case_sensitive =
        case_mode == CaseRespect ||
        (case_mode == CaseSmart && strcmp(text, lower_text) != 0);
    if (!case_sensitive) {
      SFREE(text);
      text = lower_text;
      og_str = lower_text;
      /* Unicode lowercasing can change the encoded byte length (for example,
         U+212A KELVIN SIGN is three UTF-8 bytes but lowercases to one-byte
         ASCII "k").  Every parser check below, and fzf_string_t.size, uses
         LEN as a byte count, so retain the transformed length rather than the
         source token's length. */
      len = lower_len;
    } else {
      SFREE(lower_text);
    }
    
    // Check if pattern contains UTF-8 characters
    bool is_utf8 = !is_ascii_utf8proc(text, len);
    
    if (!fuzzy) {
      fn = is_utf8 ? fzf_exact_match_utf8 : fzf_exact_match_naive;
    } else {
      fn = is_utf8 ? fzf_fuzzy_match_v2_utf8 : fzf_fuzzy_match_v2;
    }
    if (set->size > 0 && !after_bar && strcmp(text, "|") == 0) {
      switch_set = false;
      after_bar = true;
      ptr = fzf_strtok_r(NULL, delim, &token_state);
      SFREE(og_str);
      continue;
    }
    after_bar = false;
    if (has_prefix(text, "!", 1)) {
      inv = true;
      fn = is_utf8 ? fzf_exact_match_utf8 : fzf_exact_match_naive;
      text++;
      len--;
    }

    if (strcmp(text, "$") != 0 && has_suffix(text, len, "$", 1)) {
      fn = is_utf8 ? fzf_suffix_match_utf8 : fzf_suffix_match;
      text[len - 1] = 0;
      len--;
    }

    if (len > 2 && has_prefix(text, "'", 1) &&
        has_suffix(text, len, "'", 1)) {
      fn = is_utf8 ? fzf_exact_match_boundary_utf8
                   : fzf_exact_match_boundary;
      text[len - 1] = 0;
      text++;
      len -= 2;
    } else if (has_prefix(text, "'", 1)) {
      if (fuzzy && !inv) {
        fn = is_utf8 ? fzf_exact_match_utf8 : fzf_exact_match_naive;
        text++;
        len--;
      } else {
        fn = is_utf8 ? fzf_fuzzy_match_v2_utf8 : fzf_fuzzy_match_v2;
        text++;
        len--;
      }
    } else if (has_prefix(text, "^", 1)) {
      if (fn == (is_utf8 ? fzf_suffix_match_utf8 : fzf_suffix_match)) {
        fn = is_utf8 ? fzf_equal_match_utf8 : fzf_equal_match;
      } else {
        fn = is_utf8 ? fzf_prefix_match_utf8 : fzf_prefix_match;
      }
      text++;
      len--;
    }

    if (len > 0) {
      if (switch_set) {
        if (!append_pattern(pat_obj, set)) {
          free(og_str);
          goto parse_failure;
        }
        set = NULL;
        set = calloc(1, sizeof *set);
        if (!set) {
          free(og_str);
          goto parse_failure;
        }
      }
      fzf_string_t *text_ptr = make_pattern_text(text, len, case_sensitive);
      if (!text_ptr) {
        free(og_str);
        goto parse_failure;
      }
      if (!append_set(set, (fzf_term_t){.fn = fn,
                                        .inv = inv,
                                        .ptr = og_str,
                                        .text = text_ptr,
                                        .case_sensitive = case_sensitive,
                                        .normalize = normalize_term})) {
        free(text_ptr);
        free(og_str);
        goto parse_failure;
      }
      switch_set = true;
    } else {
      SFREE(og_str);
    }

    ptr = fzf_strtok_r(NULL, delim, &token_state);
  }
  if (set->size > 0) {
    if (!append_pattern(pat_obj, set)) goto parse_failure;
    set = NULL;
  } else {
    free_term_set(set);
    set = NULL;
  }
  bool only = true;
  bool has_positive_term = false;
  for (size_t i = 0; i < pat_obj->size; i++) {
    fzf_term_set_t *term_set = pat_obj->ptr[i];
    if (term_set->size > 1) only = false;
    for (size_t j = 0; j < term_set->size; j++) {
      if (!term_set->ptr[j].inv) {
        only = false;
        has_positive_term = true;
      }
    }
  }
  pat_obj->only_inv = only;
  pat_obj->has_positive_term = has_positive_term;
  SFREE(pattern_copy);
  return pat_obj;

parse_failure:
  free_term_set(set);
  free(pattern_copy);
  fzf_free_pattern(pat_obj);
  return NULL;
}

fzf_pattern_t *fzf_parse_pattern(fzf_case_types case_mode, bool normalize,
                                 char *pattern, bool fuzzy) {
  return fzf_parse_pattern_with_direction(
      case_mode, normalize, pattern, fuzzy, true);
}

void fzf_free_pattern(fzf_pattern_t *pattern) {
  if (!pattern) return;
  if (pattern->ptr) {
    for (size_t i = 0; i < pattern->size; i++) {
      free_term_set(pattern->ptr[i]);
    }
    free(pattern->ptr);
  }
  SFREE(pattern);
}

int32_t fzf_get_score(const char *text, fzf_pattern_t *pattern,
                      fzf_slab_t *slab) {
  fzf_clear_allocation_failure();
  // If the pattern is an empty string then pattern->ptr will be NULL and we
  // basically don't want to filter. Return 1 for telescope
  if (pattern->ptr == NULL) {
    return 1;
  }

  fzf_string_t input = {.data = text, .size = strlen(text)};
  bool input_is_ascii = is_ascii_utf8proc(input.data, input.size);
#include "fzf-score-input.inc"
}

int32_t fzf_get_score_bytes(const char *text, size_t text_len,
                            fzf_pattern_t *pattern, fzf_slab_t *slab) {
  fzf_clear_allocation_failure();
  if (pattern->ptr == NULL) return 1;

  fzf_string_t input = {.data = text, .size = text_len};
  bool input_is_ascii = is_ascii_utf8proc(text, text_len);
#include "fzf-score-input.inc"
}

int32_t fzf_get_score_bytes_preclassified(
    const char *text, size_t text_len, bool input_is_ascii,
    fzf_pattern_t *pattern, fzf_slab_t *slab) {
  fzf_clear_allocation_failure();
  if (pattern->ptr == NULL) return 1;

  fzf_string_t input = {.data = text, .size = text_len};
#include "fzf-score-input.inc"
}

static void fzf_score_bounds_add(fzf_score_bounds_t *bounds,
                                 fzf_result_t result) {
  if (!bounds) return;
  bounds->raw_score += result.score;
  if (result.start < 0 || result.end <= result.start) return;
  if (!bounds->valid) {
    bounds->min_begin = result.start;
    bounds->min_end = result.end;
    bounds->max_end = result.end;
    bounds->valid = true;
    return;
  }
  if (result.start < bounds->min_begin) bounds->min_begin = result.start;
  if (result.end < bounds->min_end) bounds->min_end = result.end;
  if (result.end > bounds->max_end) bounds->max_end = result.end;
}

int32_t fzf_get_score_with_bounds(const char *text,
                                  fzf_pattern_t *pattern,
                                  fzf_slab_t *slab,
                                  fzf_score_bounds_t *bounds) {
  size_t text_len = strlen(text);
  return fzf_get_score_with_bounds_bytes_preclassified(
      text, text_len, is_ascii_utf8proc(text, text_len), pattern, slab,
      bounds);
}

int32_t fzf_get_score_with_bounds_bytes_preclassified(
    const char *text, size_t text_len, bool input_is_ascii,
    fzf_pattern_t *pattern, fzf_slab_t *slab,
    fzf_score_bounds_t *bounds) {
  fzf_clear_allocation_failure();
  if (bounds) *bounds = (fzf_score_bounds_t){0};
  if (pattern->ptr == NULL) return 1;

  fzf_string_t input = {.data = text, .size = text_len};
  fzf_score_bounds_t staged_bounds = {0};
#define FZF_SCORE_RECORD_BOUNDS(result) \
  fzf_score_bounds_add(&staged_bounds, (result))
#define FZF_SCORE_COMMIT_BOUNDS() do { \
  if (bounds) *bounds = staged_bounds; \
} while (0)
#include "fzf-score-input.inc"
#undef FZF_SCORE_COMMIT_BOUNDS
#undef FZF_SCORE_RECORD_BOUNDS
}

static int32_t score_positions_for_input(const char *text,
                                         fzf_pattern_t *pattern,
                                         fzf_slab_t *slab,
                                         fzf_position_t **positions,
                                         bool compute_score) {
  *positions = NULL;
  // If the pattern is an empty string then pattern->ptr will be NULL and we
  // basically don't want to filter. Return 1 for telescope and no positions.
  if (pattern->ptr == NULL) {
    return 1;
  }

  fzf_string_t input = {.data = text, .size = strlen(text)};
  bool input_is_ascii = is_ascii_utf8proc(input.data, input.size);
  /* Keep the wrapper on the stack until a match is known.  Simple misses then
     retain the score-only fast path and allocate no position storage. */
  fzf_position_t position_data = {0};
  fzf_position_t *all_pos = &position_data;
  int32_t total_score = 0;
  for (size_t i = 0; i < pattern->size; i++) {
    fzf_term_set_t *term_set = pattern->ptr[i];
    int32_t current_score = 0;
    bool matched = false;
    for (size_t j = 0; j < term_set->size; j++) {
      fzf_term_t *term = &term_set->ptr[j];
      if (term->inv) {
        // If we have an inverse term we need to check if we have a match, but
        // we are not interested in the positions (for highlights) so to speed
        // this up we can pass in NULL here and don't calculate the positions
        fzf_result_t res = CALL_ALG(
            term, false, input, input_is_ascii, pattern->forward, NULL, slab);
        if (fzf_allocation_failed()) {
          free(position_data.data);
          return 0;
        }
        if (res.start < 0) {
          if (compute_score) current_score = 0;
          matched = true;
        }
        continue;
      }
      fzf_result_t res = CALL_ALG(
          term, false, input, input_is_ascii, pattern->forward, all_pos, slab);
      if (fzf_allocation_failed()) {
        free(position_data.data);
        return 0;
      }
      if (res.start >= 0) {
        /* Match fzf_get_score's public no-match sentinel handling when a v1
           fallback produces a valid match with a non-positive raw score. */
        if (compute_score)
          current_score = res.score > 0 ? res.score : 1;
        matched = true;
        break;
      }
    }
    if (!matched) {
      free(position_data.data);
      return 0;
    }
    /* fzf_get_positions historically did not total term scores.  Keep its
       path free of signed-overflow behavior for exceptionally large parsed
       patterns; only the combined scoring API needs the aggregate. */
    if (compute_score) total_score += current_score;
  }
  fzf_position_t *owned = fzf_pos_array(0);
  if (!owned) {
    free(position_data.data);
    return 0;
  }
  *owned = position_data;
  *positions = owned;
  return compute_score && total_score > 0 ? total_score : 1;
}

static bool score_positions_one_pass_safe(const fzf_pattern_t *pattern) {
  return pattern && pattern->size == 1 && pattern->ptr[0] &&
         pattern->ptr[0]->size == 1 && !pattern->ptr[0]->ptr[0].inv;
}

int32_t fzf_get_score_positions(const char *text, fzf_pattern_t *pattern,
                                fzf_slab_t *slab,
                                fzf_position_t **positions) {
  if (!positions) return fzf_get_score(text, pattern, slab);
  fzf_clear_allocation_failure();
  *positions = NULL;
  if (pattern->ptr == NULL) return 1;
  /* Compound patterns can do position work for an early term before a later
     term rejects the candidate.  Preserve score-first behavior for those
     patterns; the common single positive term uses one matcher traversal. */
  if (!score_positions_one_pass_safe(pattern)) {
    int32_t score = fzf_get_score(text, pattern, slab);
    if (score <= 0 || fzf_allocation_failed()) return score;
    fzf_position_t *found = fzf_get_positions(text, pattern, slab);
    if (fzf_allocation_failed()) {
      fzf_free_positions(found);
      return 0;
    }
    *positions = found;
    return score;
  }
  return score_positions_for_input(text, pattern, slab, positions, true);
}

fzf_position_t *fzf_get_positions(const char *text, fzf_pattern_t *pattern,
                                  fzf_slab_t *slab) {
  fzf_clear_allocation_failure();
  fzf_position_t *positions = NULL;
  (void)score_positions_for_input(text, pattern, slab, &positions, false);
  return positions;
}

void fzf_free_positions(fzf_position_t *pos) {
  if (pos) {
    SFREE(pos->data);
    free(pos);
  }
}

fzf_slab_t *fzf_make_slab(fzf_slab_config_t config) {
  if (config.size_16 > SIZE_MAX / sizeof(int16_t) ||
      config.size_32 > SIZE_MAX / sizeof(int32_t))
    return NULL;

  fzf_slab_t *slab = (fzf_slab_t *)calloc(1, sizeof(fzf_slab_t));
  if (!slab)
    return NULL;

  if (config.size_16 > 0) {
    slab->I16.data =
        (int16_t *)calloc(config.size_16, sizeof(*slab->I16.data));
    if (!slab->I16.data)
      goto fail;
  }
  slab->I16.cap = config.size_16;
  slab->I16.size = 0;
  slab->I16.allocated = true;

  if (config.size_32 > 0) {
    slab->I32.data =
        (int32_t *)calloc(config.size_32, sizeof(*slab->I32.data));
    if (!slab->I32.data)
      goto fail;
  }
  slab->I32.cap = config.size_32;
  slab->I32.size = 0;
  slab->I32.allocated = true;

  return slab;

fail:
  fzf_free_slab(slab);
  return NULL;
}

fzf_slab_t *fzf_make_default_slab(void) {
  return fzf_make_slab((fzf_slab_config_t){(size_t)100 * 1024, 2048});
}

bool fzf_slab_set_score_scheme(fzf_slab_t *slab,
                               fzf_score_scheme_t score_scheme) {
  if (!slab || (unsigned int)score_scheme > FZF_SCORE_SCHEME_HISTORY)
    return false;
  slab->score_scheme = score_scheme;
  return true;
}

void fzf_free_slab(fzf_slab_t *slab) {
  if (slab) {
    free(slab->I16.data);
    free(slab->I32.data);
    free(slab->UTF8.map.byte_to_char);
    free(slab);
  }
}
