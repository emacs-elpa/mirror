;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "password-store" "1.7.4.0.20250618.14"
  "Password store (pass) support."
  '((emacs       "26.1")
    (with-editor "2.5.11"))
  :url "https://www.passwordstore.org/"
  :commit "3ca13cd8882cae4083c1c478858adbf2e82dd037"
  :revdesc "1.7.4-14-g3ca13cd8882c"
  :keywords '("tools" "pass" "password" "password-store" "gpg")
  :authors '(("Svend Sorensen" . "svend@svends.net"))
  :maintainers '(("Tino Calancha" . "tino.calancha@gmail.com")))
