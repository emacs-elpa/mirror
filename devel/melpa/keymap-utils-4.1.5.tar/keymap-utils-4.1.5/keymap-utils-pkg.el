;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keymap-utils" "4.1.5"
  "Keymap utilities."
  '((emacs  "28.1")
    (compat "31.1")
    (llama  "1.0"))
  :url "https://github.com/tarsius/keymap-utils"
  :commit "1a4e751222e356957ad31ec5ff94fa99dc8f6997"
  :revdesc "v4.1.5-0-g1a4e751222e3"
  :keywords '("convenience" "extensions")
  :authors '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keymap-utils@jonas.bernoulli.dev")))
