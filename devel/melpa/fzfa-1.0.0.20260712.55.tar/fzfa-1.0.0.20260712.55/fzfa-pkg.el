;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0.0.20260712.55"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.1"))
  :url "https://github.com/jojojames/fzfa"
  :commit "ba74b4e33bcb464a52fd46faf0f0c9cccfbfcdc4"
  :revdesc "ba74b4e33bcb"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
