;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "0.8.3.0.20260916.405"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "bf4b3659d6c02ac6a558f58e852de01923b3951f"
  :revdesc "bf4b3659d6c0"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
