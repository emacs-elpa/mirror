;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "encrypt-region" "1.0.0.20220802.13"
  "Encrypts and decrypts regions."
  '((emacs "26.1"))
  :url "https://github.com/cgshep/encrypt-region"
  :commit "8ff5704bc6f4c57f935a8b7680129e599bbe474f"
  :revdesc "v1.0-13-g8ff5704bc6f4"
  :keywords '("tools" "convenience")
  :authors '(("Carlton Shepherd" . "carlton@linux.com"))
  :maintainers '(("Carlton Shepherd" . "carlton@linux.com")))
