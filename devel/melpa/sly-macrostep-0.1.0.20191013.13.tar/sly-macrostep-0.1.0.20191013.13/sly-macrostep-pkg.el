;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly-macrostep" "0.1.0.20191013.13"
  "Fancy macro-expansion via macrostep.el."
  '((sly       "1.0.0-beta2")
    (macrostep "0.9"))
  :url "https://github.com/capitaomorte/sly-macrostep"
  :commit "be2d24545092d164be1a91031d8881afd29c9ec0"
  :revdesc "be2d24545092"
  :keywords '("languages" "lisp" "sly")
  :authors '(("Luís Oliveira" . "luismbo@gmail.com")
             ("Jon Oddie" . "j.j.oddie@gmail.com")
             ("João Távora" . "joaotavora@gmail.com"))
  :maintainers '(("Luís Oliveira" . "luismbo@gmail.com")
                 ("Jon Oddie" . "j.j.oddie@gmail.com")
                 ("João Távora" . "joaotavora@gmail.com")))
