;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh-embark" "3.1"
  "Embark Actions for consult-gh."
  '((emacs          "29.4")
    (consult        "2.0")
    (consult-gh     "3.1")
    (embark-consult "1.1")
    (which-key      "3.6.0"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "c8707e86d36ea4ec38e177ca8fa0313a5374a0a9"
  :revdesc "c8707e86d36e"
  :keywords '("matching" "git" "repositories" "forges" "completion"))
