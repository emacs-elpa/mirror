;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "0.5.1.0.20261103.101"
  "Enhanced annotation system with threading."
  '((emacs     "28.1")
    (transient "0.4"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "0cddfef672d2a0b7633be34671fca30e38b298d3"
  :revdesc "0cddfef672d2"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
