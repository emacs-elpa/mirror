;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "1.3.1.0.20261031.18"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "f4b8c21eea95e0cd6312683c0ac96b82c9105f80"
  :revdesc "1.3.1-18-gf4b8c21eea95"
  :keywords '("convenience" "frames" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
