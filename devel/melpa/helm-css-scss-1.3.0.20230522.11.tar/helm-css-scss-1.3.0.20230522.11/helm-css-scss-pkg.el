;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-css-scss" "1.3.0.20230522.11"
  "CSS/SCSS/LESS Selectors with helm interface."
  '((emacs "24.3")
    (helm  "1.0"))
  :url "https://github.com/ShingoFukuyama/helm-css-scss"
  :commit "2169d83d8fdc661241df208cb3235112735d936e"
  :revdesc "2169d83d8fdc"
  :keywords '("convenience" "scss" "css" "less" "selector" "helm"))
