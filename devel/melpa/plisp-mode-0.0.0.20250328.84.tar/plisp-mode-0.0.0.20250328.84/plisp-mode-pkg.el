;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "plisp-mode" "0.0.0.20250328.84"
  "Major mode for PicoLisp programming."
  ()
  :url "https://github.com/flexibeast/plisp-mode"
  :commit "062c333343e64427dd70a2739ab9225fd23e550a"
  :revdesc "062c333343e6"
  :keywords '("picolisp" "lisp" "programming")
  :authors '(("Alexis Guillermo R. Palavecine" . "grpala@gmail.com")
             ("Thorsten Jolitz" . "tjolitz@gmail.com")
             ("Alexis" . "flexibeast@gmail.com"))
  :maintainers '(("Alexis" . "flexibeast@gmail.com")))
