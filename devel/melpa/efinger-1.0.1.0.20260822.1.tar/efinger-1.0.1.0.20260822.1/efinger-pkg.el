;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "efinger" "1.0.1.0.20260822.1"
  "Finger client and .plan feed reader."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/efinger.el"
  :commit "175b0d027da97a64819dc8b7056a148ac1b23ea1"
  :revdesc "175b0d027da9"
  :keywords '("comm")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
