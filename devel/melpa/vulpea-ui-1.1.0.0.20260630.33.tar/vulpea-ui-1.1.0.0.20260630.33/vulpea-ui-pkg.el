;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "1.1.0.0.20260630.33"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.4.0")
    (vui    "1.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "96e0bb8e8f467d26c44f58033cfb615d2144e28c"
  :revdesc "v1.1.0-33-g96e0bb8e8f46"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
