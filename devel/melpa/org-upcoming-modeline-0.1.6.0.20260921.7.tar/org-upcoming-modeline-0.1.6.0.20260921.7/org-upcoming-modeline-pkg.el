;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-upcoming-modeline" "0.1.6.0.20260921.7"
  "Show next org event in mode line."
  '((emacs  "26.1")
    (ts     "0.2")
    (org-ql "0.6"))
  :url "https://github.com/unhammer/org-upcoming-modeline"
  :commit "d4b52d40e9d6fd252094a856d24e2a2334a6dd47"
  :revdesc "v0.1.6-7-gd4b52d40e9d6"
  :keywords '("convenience" "calendar")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
