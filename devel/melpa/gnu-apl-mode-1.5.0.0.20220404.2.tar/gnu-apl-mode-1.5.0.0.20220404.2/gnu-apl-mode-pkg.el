;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnu-apl-mode" "1.5.0.0.20220404.2"
  "Emacs mode for GNU APL."
  ()
  :url "http://www.gnu.org/software/apl/"
  :commit "c8695b0d55b5167263a843252ffd21a589018427"
  :revdesc "c8695b0d55b5"
  :keywords '("languages")
  :authors '(("Elias Mårtenson" . "lokedhs@gmail.com"))
  :maintainers '(("Elias Mårtenson" . "lokedhs@gmail.com")))
