;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "major-mode-hydra" "0.2.2.0.20231003.18"
  "Major mode keybindings managed by Hydra."
  '((dash         "2.18.0")
    (pretty-hydra "0.2.2")
    (emacs        "25"))
  :url "https://github.com/jerrypnz/major-mode-hydra.el"
  :commit "d0a5dadee97c3752fcdef113cf2ba1923972a480"
  :revdesc "0.2.2-18-gd0a5dadee97c"
  :authors '(("Jerry Peng" . "pr2jerry@gmail.com"))
  :maintainers '(("Jerry Peng" . "pr2jerry@gmail.com")))
