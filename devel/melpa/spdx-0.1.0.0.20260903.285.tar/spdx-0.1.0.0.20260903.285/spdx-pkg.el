;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "0.1.0.0.20260903.285"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "a7a39e931c639c75bed4e5e6d07fc7848938bb9c"
  :revdesc "a7a39e931c63"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
