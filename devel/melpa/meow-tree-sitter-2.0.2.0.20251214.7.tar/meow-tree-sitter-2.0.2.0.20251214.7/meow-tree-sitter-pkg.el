;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow-tree-sitter" "2.0.2.0.20251214.7"
  "Tree-sitter powered motions for Meow."
  '((emacs "29.1")
    (meow  "1.2.0"))
  :url "https://github.com/skissue/meow-tree-sitter"
  :commit "f050dc0867b7a37efc2c6432b33305a0f14b1029"
  :revdesc "f050dc0867b7"
  :keywords '("convenience" "files" "languages" "tools")
  :authors '(("Ad" . "me@skissue.xyz"))
  :maintainers '(("Ad" . "me@skissue.xyz")))
