;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vtm" "1.0.0.0.20200921.4"
  "Manages vterm buffers with configuration files."
  ()
  :url "https://github.com/laishulu/emacs-vterm-manager"
  :commit "d770fd8cff7c24688199392ad93c01485c6a9569"
  :revdesc "d770fd8cff7c"
  :keywords '("convenience"))
