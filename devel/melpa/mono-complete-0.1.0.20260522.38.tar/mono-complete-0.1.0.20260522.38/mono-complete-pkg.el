;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mono-complete" "0.1.0.20260522.38"
  "Completion suggestions with multiple back-ends."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-mono-complete"
  :commit "7d3d5656269f290a8ebec772d877d95cc815939b"
  :revdesc "7d3d5656269f"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
