;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "1.3.0.20260905.13"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "bc21e333851a92ce77c9f00b86c2f7a8795891a1"
  :revdesc "bc21e333851a"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
