;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-zettelkasten" "0.7.0.0.20240716.21"
  "A Zettelkasten mode leveraging Org."
  '((emacs "25.1")
    (org   "9.3"))
  :url "https://sr.ht/~ymherklotz/org-zettelkasten"
  :commit "b6ee54071f9653fb95a33491e2c0152efc3c61c8"
  :revdesc "b6ee54071f96"
  :keywords '("files" "hypermedia" "org" "notes")
  :authors '(("Yann Herklotz" . "git@yannherklotz.com"))
  :maintainers '(("Yann Herklotz" . "git@yannherklotz.com")))
