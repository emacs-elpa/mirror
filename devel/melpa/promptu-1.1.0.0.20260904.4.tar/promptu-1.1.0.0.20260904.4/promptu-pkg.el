;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "1.1.0.0.20260904.4"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "3d1c6c70e84bfdb1633029f04354473f9d947929"
  :revdesc "v1.1.0-4-g3d1c6c70e84b"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
