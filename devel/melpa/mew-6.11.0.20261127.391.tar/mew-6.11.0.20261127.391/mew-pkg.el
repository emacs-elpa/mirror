;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20261127.391"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "162d063613533f3bf64c6ab4c312e0dd921046cb"
  :revdesc "162d06361353")
