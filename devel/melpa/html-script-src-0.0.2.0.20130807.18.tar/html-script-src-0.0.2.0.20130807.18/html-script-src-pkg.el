;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "html-script-src" "0.0.2.0.20130807.18"
  "Insert <script src=\"..\"> for popular JavaScript libraries."
  ()
  :url "https://github.com/rejeep/html-script-src"
  :commit "ed5e686ab604c81222c7e50b27c5d874c5687db7"
  :revdesc "ed5e686ab604"
  :keywords '("tools" "convenience")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
