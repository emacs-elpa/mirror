;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sproto-mode" "0.1.0.20151115.2"
  "Major mode for editing sproto."
  ()
  :url "https://github.com/m2q1n9/sproto-mode"
  :commit "1753277d9f2163fb3bc58b983a9892831cf9874b"
  :revdesc "1753277d9f21"
  :keywords '("sproto"))
