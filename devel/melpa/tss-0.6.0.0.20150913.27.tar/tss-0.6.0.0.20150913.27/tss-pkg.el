;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tss" "0.6.0.0.20150913.27"
  "Provide a interface for auto-complete.el/flymake.el on typescript-mode."
  '((auto-complete "1.4.0")
    (json-mode     "1.1.0")
    (log4e         "0.2.0")
    (yaxception    "0.1"))
  :url "https://github.com/aki2o/emacs-tss"
  :commit "81ac6351a2ae258fd0ebf916dae9bd5a179fefd0"
  :revdesc "81ac6351a2ae"
  :keywords '("typescript" "completion")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
