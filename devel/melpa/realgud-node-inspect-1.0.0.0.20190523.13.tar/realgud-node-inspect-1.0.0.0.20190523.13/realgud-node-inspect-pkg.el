;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-node-inspect" "1.0.0.0.20190523.13"
  "Realgud front-end to newer \"node inspect\"."
  '((realgud       "1.4.5")
    (load-relative "1.2")
    (cl-lib        "0.5")
    (emacs         "24"))
  :url "https://github.com/realgud/realgud-node-inspect"
  :commit "e0f18442d759b8ce4479c01e090975b62270257d"
  :revdesc "e0f18442d759"
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
