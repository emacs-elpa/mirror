;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-msg" "4.0.0.20260507.24"
  "Org mode to send and reply to email in HTML."
  '((emacs   "24.4")
    (htmlize "1.54"))
  :url "https://github.com/jeremy-compostella/org-msg"
  :commit "7b45df759340f3e388e84f497052b7cf3a41698c"
  :revdesc "7b45df759340"
  :keywords '("extensions" "mail")
  :authors '(("Jérémy Compostella" . "jeremy.compostella@gmail.com"))
  :maintainers '(("Jérémy Compostella" . "jeremy.compostella@gmail.com")))
