;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noether" "0.1.0.0.20250320.65"
  "A modeline which plays hide and seek."
  '((posframe "1.4.2")
    (emacs    "29.1"))
  :url "https://devheroes.codes/lxsameer/noether"
  :commit "c7b85569181f351ae03c4f4d3f622549332534cd"
  :revdesc "c7b85569181f"
  :keywords '("frames" "modeline")
  :authors '(("Sameer Rahmani" . "lxsameer@gnu.org"))
  :maintainers '(("Sameer Rahmani" . "lxsameer@gnu.org")))
