;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "holy-books" "1.5"
  "Org-mode links/tooltips/lookups for Quran & Bible."
  '((s     "1.12.0")
    (dash  "2.16.0")
    (emacs "27.1")
    (org   "9.1"))
  :url "https://alhassy.github.io/holy-books/"
  :commit "02c2956d36631d3d8c8b4bacdcf0a5cdd1f3136d"
  :revdesc "02c2956d3663"
  :keywords '("quran" "bible" "links" "tooltips" "convenience" "comm" "hypermedia")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
