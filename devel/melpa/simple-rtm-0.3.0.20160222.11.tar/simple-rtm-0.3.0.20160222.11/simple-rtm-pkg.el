;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-rtm" "0.3.0.20160222.11"
  "Interactive Emacs mode for Remember The Milk."
  '((rtm  "0.1")
    (dash "2.0.0"))
  :url "https://codeberg.org/mbunkus/simple-rtm"
  :commit "37c5feffea7c9b571279b6f549d06cf9c0720273"
  :revdesc "37c5feffea7c"
  :keywords '("remember" "the" "milk" "productivity" "todo")
  :authors '(("Moritz Bunkus" . "morit@bunkus.org"))
  :maintainers '(("Moritz Bunkus" . "morit@bunkus.org")))
