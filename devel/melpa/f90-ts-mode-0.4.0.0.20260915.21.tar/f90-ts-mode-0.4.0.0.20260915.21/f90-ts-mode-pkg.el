;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f90-ts-mode" "0.4.0.0.20260915.21"
  "Tree-sitter based Fortran 90 mode."
  '((emacs "30.1"))
  :url "https://github.com/mscfd/emacs-f90-ts-mode"
  :commit "a3c7c836e825713210b9d4dba55526b85855a011"
  :revdesc "v0.4.0-21-ga3c7c836e825"
  :keywords '("languages" "treesitter" "fortran")
  :authors '(("Martin Stein" . "mscfd@gmx.net"))
  :maintainers '(("Martin Stein" . "mscfd@gmx.net")))
