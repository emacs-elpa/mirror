;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-utils" "1.0.1.0.20250106.7"
  "Extensions for package.el."
  '((restart-emacs "0.1.1"))
  :url "https://github.com/Silex/package-utils"
  :commit "41c7bf2c0174a9a8bd6efc2260fa9805fbb44c5e"
  :revdesc "1.0.1-7-g41c7bf2c0174"
  :keywords '("package" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
