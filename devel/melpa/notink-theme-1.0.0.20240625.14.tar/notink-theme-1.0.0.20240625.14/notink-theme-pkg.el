;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notink-theme" "1.0.0.20240625.14"
  "A custom theme inspired by e-ink displays."
  '((emacs "26.1"))
  :url "https://github.com/MetroWind/notink-theme"
  :commit "d1e84622a491bb570d6a450706833fafaad74f39"
  :revdesc "d1e84622a491"
  :keywords '("faces")
  :authors '(("MetroWind" . "chris.corsair@gmail.com"))
  :maintainers '(("MetroWind" . "chris.corsair@gmail.com")))
