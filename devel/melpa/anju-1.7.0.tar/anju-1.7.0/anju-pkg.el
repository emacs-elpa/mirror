;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "1.7.0"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "eb3889778f212a69fbe40acbc4d208c0e0c9ee2c"
  :revdesc "eb3889778f21"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
