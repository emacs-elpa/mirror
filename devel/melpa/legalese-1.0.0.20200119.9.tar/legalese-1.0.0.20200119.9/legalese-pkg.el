;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "legalese" "1.0.0.20200119.9"
  "Add legalese to your program files."
  ()
  :url "https://github.com/jorgenschaefer/legalese"
  :commit "e465471d2d5a62d35073d93e0f8d40387a82e302"
  :revdesc "e465471d2d5a"
  :keywords '("convenience")
  :authors '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainers '(("Jorgen Schaefer" . "forcer@forcix.cx")))
