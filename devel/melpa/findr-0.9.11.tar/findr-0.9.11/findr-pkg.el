;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "findr" "0.9.11"
  "Breadth-first file-finding facility for (X)Emacs."
  ()
  :url "https://github.com/emacsorphanage/findr"
  :commit "1ddbc0464bb05dcda392b62666ad17239a2152d3"
  :revdesc "1ddbc0464bb0"
  :keywords '("files")
  :authors '(("David Bakhash" . "cadet@bu.edu"))
  :maintainers '(("David Bakhash" . "cadet@bu.edu")))
