;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-hl-todo" "1.0.0.20230807.10"
  "Display hl-todo keywords in flycheck."
  '((emacs    "25.1")
    (hl-todo  "1.9.0")
    (flycheck "0.14"))
  :url "https://github.com/alvarogonzalezsotillo/flycheck-hl-todo"
  :commit "16b66ea07e9d31950093ef0ff97d42b8e7ebf10f"
  :revdesc "16b66ea07e9d"
  :keywords '("convenience")
  :authors '(("lvaro González Sotillo" . "alvarogonzalezsotillo@gmail.com"))
  :maintainers '(("lvaro González Sotillo" . "alvarogonzalezsotillo@gmail.com")))
