;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sentex" "0.2.0.20260805.22"
  "Regex-based sentence navigation rules."
  '((emacs "27.1"))
  :url "https://codeberg.org/martianh/sentex"
  :commit "f21da7c9451eefd8af587da5d5e8a1e619ded45a"
  :revdesc "f21da7c9451e"
  :keywords '("languages" "convenience" "translation" "sentences" "text" "wp")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
