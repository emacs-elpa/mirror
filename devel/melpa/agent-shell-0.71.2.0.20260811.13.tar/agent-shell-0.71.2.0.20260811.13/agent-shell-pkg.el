;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "0.71.2.0.20260811.13"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "ab620f37dd88089afa559de2b0f189dc8c9566e5"
  :revdesc "ab620f37dd88")
