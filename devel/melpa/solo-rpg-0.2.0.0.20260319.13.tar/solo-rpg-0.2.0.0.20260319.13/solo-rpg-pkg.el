;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solo-rpg" "0.2.0.0.20260319.13"
  "Solo roleplaying games and Lonelog support."
  '((emacs     "27.1")
    (transient "0.3.7"))
  :url "https://github.com/enfors/solo-rpg"
  :commit "a64be1367d1b058d7caddd4dfc96a899c4c89d49"
  :revdesc "a64be1367d1b"
  :keywords '("games")
  :authors '(("Christer Enfors" . "christer.enfors@gmail.com"))
  :maintainers '(("Christer Enfors" . "christer.enfors@gmail.com")))
