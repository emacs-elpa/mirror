;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syncthing" "3.0.2.0.20250612.23"
  "Client for Syncthing."
  '((emacs "27.1"))
  :url "https://github.com/KeyWeeUsr/emacs-syncthing"
  :commit "eac37ecf5458b6d554544b1ddb76e3c6fbe3cb2f"
  :revdesc "3.0.2-23-geac37ecf5458"
  :keywords '("convenience" "syncthing" "sync" "client" "view")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
