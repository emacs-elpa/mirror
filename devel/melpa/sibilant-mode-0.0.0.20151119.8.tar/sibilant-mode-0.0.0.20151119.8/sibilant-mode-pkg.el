;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sibilant-mode" "0.0.0.20151119.8"
  "Support for the Sibilant programming language."
  ()
  :url "http://sibilantjs.info"
  :commit "5baf8c3e80ee0736c7298a2a17fb615ba5ac0d2d"
  :revdesc "5baf8c3e80ee"
  :keywords '("languages")
  :authors '(("Jacob Rothstein" . "hi@jbr.me"))
  :maintainers '(("Jacob Rothstein" . "hi@jbr.me")))
