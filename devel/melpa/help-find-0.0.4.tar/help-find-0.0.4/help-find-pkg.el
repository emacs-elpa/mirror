;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "help-find" "0.0.4"
  "Additional help functions for working with keymaps."
  '((emacs "25.2")
    (dash  "2.12."))
  :url "https://github.com/duncanburke/help-find"
  :commit "ef7266fc480367c12bff64817c875af940d0c9c0"
  :revdesc "ef7266fc4803"
  :keywords '("help")
  :authors '(("Duncan Burke" . "duncankburke@gmail.com"))
  :maintainers '(("Duncan Burke" . "duncankburke@gmail.com")))
