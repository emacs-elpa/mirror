;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cryptol-mode" "0.1.0.0.20190531.25"
  "Cryptol major mode for Emacs."
  ()
  :url "https://github.com/thoughtpolice/cryptol-mode"
  :commit "81ebbde83f7cb75b2dfaefc09de6a1703068c769"
  :revdesc "v0.1.0-25-g81ebbde83f7c"
  :keywords '("cryptol" "cryptography")
  :authors '(("Austin Seipp" . "aseipp[@at]pobox[dot]com"))
  :maintainers '(("Austin Seipp" . "aseipp[@at]pobox[dot]com")))
