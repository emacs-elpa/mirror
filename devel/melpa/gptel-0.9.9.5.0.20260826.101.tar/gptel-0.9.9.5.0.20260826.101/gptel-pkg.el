;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "0.9.9.5.0.20260826.101"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "1f6556d9266c756a142337ccc82acfa5bba713ec"
  :revdesc "1f6556d9266c"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
