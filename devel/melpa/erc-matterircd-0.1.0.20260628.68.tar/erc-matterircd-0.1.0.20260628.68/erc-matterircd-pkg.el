;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-matterircd" "0.1.0.20260628.68"
  "Integrate matterircd with ERC."
  '((emacs "27.1"))
  :url "https://github.com/alexmurray/erc-matterircd"
  :commit "f4c8e3cac924065b2d0e43114459c45fa39cc006"
  :revdesc "f4c8e3cac924"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
