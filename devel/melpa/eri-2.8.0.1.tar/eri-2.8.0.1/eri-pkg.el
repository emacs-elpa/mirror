;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eri" "2.8.0.1"
  "Enhanced relative indentation (eri)."
  ()
  :url "https://github.com/agda/agda"
  :commit "001a4ede95950a55099ee7eaf583288606fb8272"
  :revdesc "v2.8.0.1-0-g001a4ede9595")
