;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "1.0.0.20260702.347"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.1"))
  :url "https://github.com/jojojames/fzfa"
  :commit "def4a2297f5d62624b9325a823ff8665436c3d23"
  :revdesc "def4a2297f5d"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
