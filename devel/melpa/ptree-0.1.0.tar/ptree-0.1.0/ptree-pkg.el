;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ptree" "0.1.0"
  "Property tree data structure."
  '((emacs "25.1"))
  :url "https://github.com/alpha-catharsis/ptree"
  :commit "23cb9093f99b9869606f8d54fa5c45ea35fcc789"
  :revdesc "23cb9093f99b"
  :keywords '("lisp")
  :authors '(("Alpha Catharsis" . "alpha.catharsis@gmail.com"))
  :maintainers '(("Alpha Catharsis" . "alpha.catharsis@gmail.com")))
