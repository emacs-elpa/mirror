;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-propose" "4.0.0.0.20210207.3"
  "Simple and safe undo navigation."
  '((emacs "24.3"))
  :url "https://github.com/jackkamm/undo-propose.el"
  :commit "91a1dfe516d90dab69c368f6669bacb2458ec5e9"
  :revdesc "91a1dfe516d9"
  :keywords '("convenience" "files" "undo" "redo" "history"))
