;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elcute" "1.1.0.20260102.17"
  "Commands for marking and killing lines electrically."
  '((emacs "29.1"))
  :url "https://codeberg.org/vilij/slurpbarf-elcute"
  :commit "5ec0f75a308ab8ae1f29bbb3c18b63514fc83c20"
  :revdesc "5ec0f75a308a"
  :keywords '("convenience" "lisp" "xml"))
