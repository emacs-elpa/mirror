;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-toki" "0.1.0.0.20230705.3"
  "Counsel support for toki pona dictionary lookup."
  '((request "0.3.3")
    (emacs   "25.1")
    (ivy     "0.14.0"))
  :url "https://github.com/emiflake/counsel-toki"
  :commit "545aa4413ba8ce6a92d11d42e910a57a8cb58e2e"
  :revdesc "545aa4413ba8"
  :authors '(("Emily Martins" . "emi@haskell.fyi"))
  :maintainers '(("Emily Martins" . "emi@haskell.fyi")))
