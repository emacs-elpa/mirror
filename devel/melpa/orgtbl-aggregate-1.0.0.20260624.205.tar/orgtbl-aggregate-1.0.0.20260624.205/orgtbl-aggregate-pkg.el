;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "1.0.0.20260624.205"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "84d7721b4bf8c07d121945d9a37890059d8fad1d"
  :revdesc "84d7721b4bf8"
  :keywords '("data" "extensions"))
