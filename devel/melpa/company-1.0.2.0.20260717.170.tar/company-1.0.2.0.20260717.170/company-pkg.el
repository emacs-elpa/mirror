;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "1.0.2.0.20260717.170"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "5bdbde0565592838e965186a122ae20a1c737886"
  :revdesc "5bdbde056559"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
