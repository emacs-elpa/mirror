;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.7.3.0.20261117.58"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "d8b52162cb66faefd3fc500bcfb9590923949f02"
  :revdesc "d8b52162cb66"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
