;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-atoms" "0.2.0.0.20201013.6"
  "Reverse variable lookup using Helm."
  '((emacs "25.1")
    (helm  "2.0"))
  :url "https://github.com/dantecatalfamo/helm-atoms"
  :commit "7e6f91a16f556c96ae1b0d1f965ea56861bb6372"
  :revdesc "7e6f91a16f55"
  :keywords '("help" "lisp" "maint" "helm" "tools" "matching"))
