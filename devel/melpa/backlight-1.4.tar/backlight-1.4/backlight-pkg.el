;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "backlight" "1.4"
  "Backlight brightness adjustment on GNU/Linux."
  '((emacs "24.3"))
  :url "https://github.com/mschuldt/backlight.el"
  :commit "b6826a60440d8bf440618e3cdafb40158de920e6"
  :revdesc "b6826a60440d"
  :keywords '("hardware")
  :authors '(("Michael Schuldt" . "mbschuldt@gmail.com"))
  :maintainers '(("Michael Schuldt" . "mbschuldt@gmail.com")))
