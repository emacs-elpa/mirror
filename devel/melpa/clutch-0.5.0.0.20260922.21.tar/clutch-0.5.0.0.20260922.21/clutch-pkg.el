;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.0.0.20260922.21"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "5af73121be1ccc488189d847dca3a9fcdaf4a9a6"
  :revdesc "5af73121be1c"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
