;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eacl" "2.2.3"
  "Auto-complete lines by grepping project."
  '((emacs "27.1"))
  :url "https://github.com/redguardtoo/eacl"
  :commit "19f0170f3548eb49f5bd92653f321c3b1742b492"
  :revdesc "19f0170f3548"
  :keywords '("abbrev" "convenience" "matching"))
