;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-listcruncher" "1.4"
  "Planning tool - Parse Org mode lists into table."
  '((seq   "2.3")
    (emacs "26.1"))
  :url "https://github.com/dfeich/org-listcruncher"
  :commit "075e0e6d36eb50406a608bc8a2f0dd359ec63938"
  :revdesc "075e0e6d36eb"
  :keywords '("convenience")
  :authors '(("Derek Feichtinger" . "dfeich@gmail.com"))
  :maintainers '(("Derek Feichtinger" . "dfeich@gmail.com")))
