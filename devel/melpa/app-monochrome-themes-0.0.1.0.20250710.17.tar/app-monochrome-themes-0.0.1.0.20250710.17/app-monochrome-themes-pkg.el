;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "app-monochrome-themes" "0.0.1.0.20250710.17"
  "Low contrast monochrome themes."
  '((emacs "26.1"))
  :url "https://github.com/Greybeard-Entertainment/app-monochrome"
  :commit "bd8bfee0b64bf10543f4cefaf40bb5dcd4cf123b"
  :revdesc "bd8bfee0b64b"
  :authors '(("Aleksandr Petrosyan" . "appetrosan3@gmail.com"))
  :maintainers '(("Aleksandr Petrosyan" . "appetrosan3@gmail.com")))
