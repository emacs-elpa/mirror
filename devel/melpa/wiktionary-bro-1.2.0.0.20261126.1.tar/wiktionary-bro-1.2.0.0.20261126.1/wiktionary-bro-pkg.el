;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wiktionary-bro" "1.2.0.0.20261126.1"
  "Lookup Wiktionary entries."
  '((emacs   "29.4")
    (request "0.3.3"))
  :url "https://github.com/agzam/wiktionary-bro.el"
  :commit "09ae926a013b93cf07bad46e5f2a2ad4dd7fc6d0"
  :revdesc "09ae926a013b"
  :keywords '("convenience" "multimedia")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
