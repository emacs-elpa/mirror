;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "0.9"
  "Client for Lichess.org."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "de62be5c1fbbf37fe4cd241feec88814bc78f2c4"
  :revdesc "de62be5c1fbb"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
