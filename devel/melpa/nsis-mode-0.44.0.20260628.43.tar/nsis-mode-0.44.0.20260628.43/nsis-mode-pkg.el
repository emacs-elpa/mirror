;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nsis-mode" "0.44.0.20260628.43"
  "NSIS-mode."
  ()
  :url "https://github.com/mlf176f2/nsis-mode"
  :commit "5ee283dd4da0bf8ca90cc8210da6ad94899d50b9"
  :revdesc "v0.44-43-g5ee283dd4da0"
  :keywords '("nsis"))
