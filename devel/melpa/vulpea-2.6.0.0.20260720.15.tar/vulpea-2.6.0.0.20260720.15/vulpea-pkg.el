;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.6.0.0.20260720.15"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "f7a9e919ffd73109f545796e0b8f78f8bc3d0d1f"
  :revdesc "f7a9e919ffd7"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
