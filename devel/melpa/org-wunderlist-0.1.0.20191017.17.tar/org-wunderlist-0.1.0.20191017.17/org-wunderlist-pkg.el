;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-wunderlist" "0.1.0.20191017.17"
  "Org sync with Wunderlist."
  '((request-deferred "0.2.0")
    (alert            "1.1")
    (emacs            "24")
    (cl-lib           "0.5")
    (org              "8.2.4")
    (s                "1.9.0"))
  :url "https://github.com/myuhe/org-wunderlist.el"
  :commit "1a084bb49be4b5a1066db9cd9b7da2f8efab293f"
  :revdesc "1a084bb49be4"
  :keywords '("convenience")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
