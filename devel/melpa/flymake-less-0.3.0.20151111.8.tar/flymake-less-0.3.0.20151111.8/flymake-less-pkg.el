;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-less" "0.3.0.20151111.8"
  "Flymake handler for LESS stylesheets (lesscss.org)."
  '((less-css-mode "0.15")
    (flymake-easy  "0.1"))
  :url "https://github.com/purcell/flymake-less"
  :commit "32d3c28a9a5c52b82d1741ff9d715013b6498421"
  :revdesc "32d3c28a9a5c"
  :keywords '("languages")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
