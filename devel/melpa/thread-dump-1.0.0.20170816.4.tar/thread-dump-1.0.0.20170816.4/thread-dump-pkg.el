;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thread-dump" "1.0.0.20170816.4"
  "Java thread dump viewer."
  ()
  :url "https://github.com/nd/thread-dump.el"
  :commit "204c9600242756d4b514bb5ff6293e052bf4b49d"
  :revdesc "204c96002427")
