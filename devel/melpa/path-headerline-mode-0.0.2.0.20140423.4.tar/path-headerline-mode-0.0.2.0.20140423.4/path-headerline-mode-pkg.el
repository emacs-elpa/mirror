;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "path-headerline-mode" "0.0.2.0.20140423.4"
  "Displaying file path on headerline."
  ()
  :url "https://github.com/7696122/path-headerline-mode"
  :commit "b5b2725c6a8b1cb592fc242b7dbbd54b4dff2e69"
  :revdesc "b5b2725c6a8b"
  :keywords '("headerline"))
