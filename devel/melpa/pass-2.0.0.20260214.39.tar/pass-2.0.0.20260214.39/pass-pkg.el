;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pass" "2.0.0.20260214.39"
  "Major mode for password-store.el."
  '((emacs              "25.1")
    (password-store     "1.7.4")
    (password-store-otp "0.1.5")
    (f                  "0.17"))
  :url "https://github.com/NicolasPetton/pass"
  :commit "143456809fd2dbece9f241f4361085e1de0b0e75"
  :revdesc "143456809fd2"
  :keywords '("tools" "files")
  :authors '(("Nicolas Petton" . "petton.nicolas@gmail.com")
             ("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Nicolas Petton" . "petton.nicolas@gmail.com")
                 ("Damien Cassou" . "damien@cassou.me")))
