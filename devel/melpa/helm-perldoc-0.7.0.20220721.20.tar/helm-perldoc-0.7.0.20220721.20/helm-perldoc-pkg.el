;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-perldoc" "0.7.0.20220721.20"
  "Perldoc with helm interface."
  '((helm-core "3.6.0")
    (deferred  "0.3.1")
    (emacs     "24.4"))
  :url "https://github.com/syohex/emacs-helm-perldoc"
  :commit "affbf0f7357e5e0b33dab74d7193c91632d59b78"
  :revdesc "affbf0f7357e"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
