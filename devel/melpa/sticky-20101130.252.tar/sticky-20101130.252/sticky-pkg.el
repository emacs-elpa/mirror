;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sticky" "20101130.252"
  "Sticky key for capital letters."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/download/sticky.el"
  :commit "fec4e1af38f17f5cd80eca361d8e8ef8772db366"
  :revdesc "fec4e1af38f1"
  :keywords '("convenience")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
