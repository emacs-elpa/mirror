;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "0.9.0"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "6acca5831d723105af361b742049cbf53d05bdf7"
  :revdesc "6acca5831d72"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
