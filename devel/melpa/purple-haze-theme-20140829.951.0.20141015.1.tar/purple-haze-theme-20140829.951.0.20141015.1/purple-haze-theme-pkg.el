;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "purple-haze-theme" "20140829.951.0.20141015.1"
  "An overtly purple color theme for Emacs24."
  '((emacs "24.0"))
  :url "https://github.com/jasonm23/emacs-purple-haze-theme"
  :commit "3e245cbef7cd09e6b3ee124963e372a04e9a6485"
  :revdesc "3e245cbef7cd"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
