;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "just-ts-mode" "0.1.0.0.20260319.17"
  "Justfile editing mode."
  '((emacs "29.1"))
  :url "https://github.com/leon-barrett/just-ts-mode.el"
  :commit "94f788eccb13cd3ade827af5612ffe3cad5fddf0"
  :revdesc "94f788eccb13"
  :keywords '("files" "languages" "tools" "treesitter")
  :authors '(("Leon Barrett" . "(leon@barrettnexus.com)"))
  :maintainers '(("Leon Barrett" . "(leon@barrettnexus.com)")))
