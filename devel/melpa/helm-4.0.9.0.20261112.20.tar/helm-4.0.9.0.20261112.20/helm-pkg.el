;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "4.0.9.0.20261112.20"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.9")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "9e3877eb5d962dd5004a42876f035930dc88f68f"
  :revdesc "v4.0.9-20-g9e3877eb5d96"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
