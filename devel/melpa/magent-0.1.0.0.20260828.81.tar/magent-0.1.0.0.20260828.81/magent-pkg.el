;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magent" "0.1.0.0.20260828.81"
  "AI coding agent."
  '((emacs       "29.1")
    (gptel       "0.9.8")
    (yaml        "1.0.0")
    (compat      "30.1.0.0")
    (acp         "0.13.1")
    (agent-shell "0.66.1"))
  :url "https://github.com/jamie-cui/magent"
  :commit "0959570cb2ba87854d4cfb650a29937834defac1"
  :revdesc "0959570cb2ba"
  :keywords '("tools" "ai" "copilot")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
