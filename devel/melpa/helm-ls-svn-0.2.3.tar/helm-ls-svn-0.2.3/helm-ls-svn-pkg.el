;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ls-svn" "0.2.3"
  "Helm extension to list svn files."
  '((emacs  "24.1")
    (helm   "1.7.0")
    (cl-lib "0.5"))
  :url "https://svn.macports.org/repository/macports/users/chunyang/helm-ls-svn.el/helm-ls-svn.el"
  :commit "a6043e1187282f649e2cb9f0e722a42daf41294b"
  :revdesc "a6043e118728"
  :keywords '("helm" "svn")
  :authors '(("Chunyang Xu" . "chunyang@macports.org"))
  :maintainers '(("Chunyang Xu" . "chunyang@macports.org")))
