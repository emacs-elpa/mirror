;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "0.3.2.0.20260906.19"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "52849fb8c2be46ad908bfee2a42cc9d79b797704"
  :revdesc "52849fb8c2be"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
