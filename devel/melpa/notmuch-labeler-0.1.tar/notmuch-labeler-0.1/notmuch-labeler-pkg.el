;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-labeler" "0.1"
  "Improve notmuch way of displaying labels."
  '((notmuch "0"))
  :url "https://github.com/DamienCassou/notmuch-labeler"
  :commit "d65d1129555d368243df4770ecc1e7ccb88efc58"
  :revdesc "d65d1129555d"
  :keywords '("emacs" "package" "elisp" "notmuch" "emails")
  :authors '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainers '(("Damien Cassou" . "damien.cassou@gmail.com")))
