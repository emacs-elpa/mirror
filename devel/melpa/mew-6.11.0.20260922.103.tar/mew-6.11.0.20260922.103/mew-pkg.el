;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "6.11.0.20260922.103"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "66261fb2eead0abfbf3d8c435b2f615c8bc7fe4b"
  :revdesc "66261fb2eead")
