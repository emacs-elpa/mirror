;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slirm" "1.0.0.20160201.14"
  "Systematic Literature Review Mode for Emacs."
  '((emacs "24.4."))
  :url "https://github.com/fbie/slirm"
  :commit "9adfbe1fc67580e7d0d90f7e927a25d63a797464"
  :revdesc "9adfbe1fc675"
  :authors '(("Florian Biermann" . "fbie@itu.dk"))
  :maintainers '(("Florian Biermann" . "fbie@itu.dk")))
