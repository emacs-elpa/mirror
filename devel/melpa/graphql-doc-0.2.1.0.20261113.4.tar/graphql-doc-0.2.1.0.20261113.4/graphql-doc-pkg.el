;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphql-doc" "0.2.1.0.20261113.4"
  "GraphQL Documentation Explorer."
  '((emacs   "26.1")
    (request "0.3.2")
    (promise "1.1"))
  :url "https://github.com/ifitzpatrick/graphql-doc.el"
  :commit "e680b911affe819857bbb88cd2e5ae2256296ac3"
  :revdesc "e680b911affe")
