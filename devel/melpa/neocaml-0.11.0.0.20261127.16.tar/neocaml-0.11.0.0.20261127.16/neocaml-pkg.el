;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "0.11.0.0.20261127.16"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "3c130d5be880a55d60b5e3b82a7c14af14847d8f"
  :revdesc "3c130d5be880"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
