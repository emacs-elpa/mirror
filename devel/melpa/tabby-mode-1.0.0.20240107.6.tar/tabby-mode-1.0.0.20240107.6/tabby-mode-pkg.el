;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabby-mode" "1.0.0.20240107.6"
  "Minor mode for the Tabby AI coding assistant."
  '((emacs "25.1"))
  :url "https://github.com/ragnard/tabby-mode"
  :commit "b656727247c5fc78690827fecf232edc1945a331"
  :revdesc "b656727247c5"
  :keywords '("tools" "convenience")
  :authors '(("Ragnar Dahlén" . "r.dahlen@gmail.com"))
  :maintainers '(("Ragnar Dahlén" . "r.dahlen@gmail.com")))
