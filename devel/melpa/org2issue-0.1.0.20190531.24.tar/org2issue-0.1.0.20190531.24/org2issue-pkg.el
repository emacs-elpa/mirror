;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org2issue" "0.1.0.20190531.24"
  "Export org to github issue."
  '((org    "8.0")
    (emacs  "24.4")
    (ox-gfm "0.1")
    (gh     "0.1")
    (s      "20160405.920"))
  :url "https://github.com/lujun9972/org2issue"
  :commit "910b98c858762fd14b11d261626c5e979dde0833"
  :revdesc "910b98c85876"
  :keywords '("convenience" "github" "org")
  :authors '(("DarkSun" . "lujun9972@gmail.com"))
  :maintainers '(("DarkSun" . "lujun9972@gmail.com")))
