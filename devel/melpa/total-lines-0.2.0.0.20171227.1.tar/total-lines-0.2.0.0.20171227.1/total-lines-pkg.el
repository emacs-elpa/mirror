;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "total-lines" "0.2.0.0.20171227.1"
  "Keep track of a buffer's total number of lines."
  '((emacs "24.3"))
  :url "https://github.com/hinrik/total-lines"
  :commit "c762f08d039c8103f71c747e00304f209c2254f4"
  :revdesc "c762f08d039c"
  :keywords '("convenience" "mode-line"))
