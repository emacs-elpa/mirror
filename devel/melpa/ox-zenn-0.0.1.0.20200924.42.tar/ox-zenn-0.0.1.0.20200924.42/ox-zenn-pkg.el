;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-zenn" "0.0.1.0.20200924.42"
  "Zenn flavored markdown backend for org export engine."
  '((emacs "27.1")
    (org   "9.0"))
  :url "https://github.com/conao3/ox-zenn.el"
  :commit "b53bd82116c9f7dbb5b476d2cfcc8ed0f3bc9c78"
  :revdesc "b53bd82116c9"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
