;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selectrum-prescient" "6.3.3.0.20260906.1"
  "Prescient.el + Selectrum."
  '((emacs     "26.1")
    (prescient "6.1.0")
    (selectrum "3.1"))
  :url "https://github.com/raxod502/prescient.el"
  :commit "ae52777d6b6b856b54c85441c7a713949f1720de"
  :revdesc "ae52777d6b6b"
  :keywords '("extensions")
  :authors '(("Radian LLC" . "contact+prescient@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+prescient@radian.codes")))
