;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-clang-async" "0.5"
  "Auto Completion source for clang for GNU Emacs."
  ()
  :url "https://github.com/Golevka/emacs-clang-complete-async"
  :commit "a5114e3477793ccb9420acc5cd6a1cb26be65964"
  :revdesc "v0.5-0-ga5114e347779"
  :keywords '("completion" "convenience")
  :authors '(("Brian Jiang" . "brianjcj@gmail.com")
             ("Taylan Ulrich Bayirli/Kammer" . "taylanbayirli@gmail.com"))
  :maintainers '(("Brian Jiang" . "brianjcj@gmail.com")
                 ("Taylan Ulrich Bayirli/Kammer" . "taylanbayirli@gmail.com")))
