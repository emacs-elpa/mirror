;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "balanced-windows" "1.0.1.0.20260630.1"
  "Keep windows balanced."
  '((emacs "25"))
  :url "https://github.com/wbolster/emacs-balanced-windows"
  :commit "1a2c52770b228624dbaca12c5455dba11f153c65"
  :revdesc "1.0.1-1-g1a2c52770b22"
  :keywords '("convenience")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
