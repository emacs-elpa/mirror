;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-plist" "2.0.0.0.20200212.1"
  "Apple plist file parser."
  '((emacs "25.1"))
  :url "https://github.com/gonewest818/osx-plist"
  :commit "cd86c03a52eab9b1a1496618809155b25b030ba6"
  :revdesc "cd86c03a52ea"
  :keywords '("convenience")
  :authors '(("Theresa O'Connor" . "tess@oconnor.cx"))
  :maintainers '(("Neil Okamoto" . "neil.okamoto+melpa@gmail.com")))
