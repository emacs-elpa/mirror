;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "efzf" "0.1.0.0.20261123.6"
  "Fzf-like command-line selector using completing-read."
  '((emacs "29.1"))
  :url "https://github.com/yoshinari-nomura/efzf"
  :commit "165881fe3da8ac2742f798b872ee908fca723198"
  :revdesc "165881fe3da8"
  :keywords '("convenience" "matching" "terminals")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
