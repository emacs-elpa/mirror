;;; efzf.el --- fzf-like command-line selector using completing-read  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Yoshinari Nomura

;; Author: Yoshinari Nomura <nom@quickhack.net>
;; Maintainer: Yoshinari Nomura <nom@quickhack.net>
;; URL: https://github.com/yoshinari-nomura/efzf
;; Package-Version: 0.1.0.0.20261123.6
;; Package-Revision: 165881fe3da8
;; Package-Requires: ((emacs "29.1"))
;; Keywords: convenience, matching, terminals

;; This file is not part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; efzf brings Emacs' completion UI (Vertico, Orderless, Marginalia,
;; etc.) to the terminal as an fzf-like selector.  The companion shell
;; script `efzf' calls `efzf-run-action' through emacsclient, which
;; shows a full-screen completion UI in the terminal and writes the
;; selected item to a file.
;;
;; When installed as a package, run `M-x efzf-install-scripts' to copy
;; the shell scripts `efzf' and `efzf.zsh' to your shell environment.
;;
;; See README.org for installation and shell integration.

;;; Code:

(defvar vertico-count)
(defvar vertico-resize)
(defvar orderless-smart-case)

(defconst efzf--source-directory
  (file-name-directory (or load-file-name buffer-file-name))
  "Directory containing efzf.el and the bundled shell scripts.")

;;;###autoload
(defun efzf-install-scripts (script-dir zsh-dir)
  "Copy the bundled shell scripts to SCRIPT-DIR and ZSH-DIR.
The `efzf' script is copied to SCRIPT-DIR and made executable;
SCRIPT-DIR should be included in your $PATH.  `efzf.zsh' is
copied to ZSH-DIR; source it from your .zshrc.

Run this command again after upgrading efzf."
  (interactive
   (list (read-directory-name "Install efzf to: " "~/.local/bin/")
         (read-directory-name "Install efzf.zsh to: " "~/.zsh/")))
  (dolist (spec `(("efzf" ,script-dir #o755)
                  ("efzf.zsh" ,zsh-dir #o644)))
    (let* ((src (expand-file-name (nth 0 spec) efzf--source-directory))
           (dir (file-name-as-directory (expand-file-name (nth 1 spec))))
           (dst (expand-file-name (nth 0 spec) dir)))
      (unless (file-exists-p src)
        (user-error "Cannot find %s" src))
      (make-directory dir t)
      (copy-file src dst (if (called-interactively-p 'any) 1 t))
      (set-file-modes dst (nth 2 spec))
      (message "Installed %s" (abbreviate-file-name dst)))))

;;;###autoload
(defun efzf-run-action (target-dir input-file output-file action-func-symbol options)
  "Run ACTION-FUNC-SYMBOL in a full-screen UI for emacsclient.
TARGET-DIR: working directory (set as `default-directory')
INPUT-FILE: file containing the contents of stdin
OUTPUT-FILE: file to write the selection result to
ACTION-FUNC-SYMBOL: action function to call
OPTIONS: plist passed to the action function

If OPTIONS has :ignore-case, the case sensitivity of completion is
bound to its value while ACTION-FUNC-SYMBOL runs."
  (message nil)
  (let ((frame (selected-frame))
        (coding-system-for-write 'utf-8))
    (unwind-protect
        (progn
          (let ((ui-buf (get-buffer-create "*EFZF-UI*")))
            (with-current-buffer ui-buf
              (setq default-directory target-dir)
              (setq mode-line-format nil)
              (setq header-line-format nil)
              (erase-buffer))
            (switch-to-buffer ui-buf)
            (delete-other-windows)
            (redisplay))
          (with-temp-buffer
            (setq default-directory target-dir)
            ;; Load the input file
            (when (file-exists-p input-file)
              (let ((coding-system-for-read 'utf-8))
                (insert-file-contents input-file)))

            (let* ((vertico-count (- (frame-height) 2))
                   (vertico-resize nil)
                   ;; In case a minibuffer is active in another frame
                   (enable-recursive-minibuffers t)
                   (result
                    (if (plist-member options :ignore-case)
                        ;; Orderless ignores `completion-ignore-case'
                        ;; with smart case.
                        (let* ((completion-ignore-case
                                (plist-get options :ignore-case))
                               (read-file-name-completion-ignore-case
                                completion-ignore-case)
                               (orderless-smart-case nil))
                          (funcall action-func-symbol options))
                      (funcall action-func-symbol options))))

              (when (and (stringp result) (not (string= result "")))
                (with-temp-file output-file
                  (insert result))))))
      ;; Clean up
      (when (get-buffer "*EFZF-UI*")
        (kill-buffer "*EFZF-UI*"))

      (run-at-time 0 nil
                   (lambda (f)
                     (when (frame-live-p f)
                       (message nil)
                       (redisplay)
                       (delete-frame f)))
                   frame))))

;;; Actions
;;
;; An action function takes a plist OPTIONS made from the command
;; line options of efzf:
;;
;;   :prompt STRING      -p     prompt string
;;   :query STRING       -q     initial input
;;   :sort BOOL          -s/-S  sort candidates or not (default: nil)
;;
;; :ignore-case BOOL (-i/-I) is handled by `efzf-run-action', so
;; action functions need not care about it.

(defun efzf--non-empty (string)
  "Return STRING if it is a non-empty string, otherwise nil."
  (and (stringp string) (not (string= string "")) string))

(defun efzf-action-pipe (options)
  "Select a line of the current buffer with `completing-read'.
Each line is split at the first NUL character into a candidate and
the value to return; a line without NUL is used for both.  Return
the value of the selected candidate, or nil if cancelled.  If the
same candidate appears more than once, return the value of the
first one.
OPTIONS is a plist described in the Actions section."
  (let* ((lines (efzf--buffer-to-key-value-alist ?\0))
         (prompt (or (plist-get options :prompt) "Filter: "))
         (completion-table
          (if (plist-get options :sort)
              lines
            (lambda (string pred action)
              (if (eq action 'metadata)
                  '(metadata (display-sort-function . identity)
                             (cycle-sort-function . identity))
                (complete-with-action action lines string pred))))))
    (when lines
      (let ((choice (condition-case nil
                        (completing-read prompt completion-table nil t
                                         (plist-get options :query))
                      (quit nil))))
        (cdr (assoc choice lines))))))

(defun efzf-action-file (options)
  "Read a file name and return its absolute path, or nil if cancelled.
OPTIONS is a plist described in the Actions section."
  (let* ((prompt (or (plist-get options :prompt) "Select file: "))
         (file (condition-case nil
                   (read-file-name prompt nil nil nil
                                   (plist-get options :query))
                 (quit nil))))
    (when (efzf--non-empty file)
      (expand-file-name file))))

(defun efzf-action-directory (options)
  "Read a directory name and return its absolute path, or nil if cancelled.
OPTIONS is a plist described in the Actions section."
  (let* ((prompt (or (plist-get options :prompt) "Select directory: "))
         (dir (condition-case nil
                  (read-directory-name prompt nil nil t
                                       (plist-get options :query))
                (quit nil))))
    (when (efzf--non-empty dir)
      (file-name-as-directory (expand-file-name dir)))))

(defun efzf--buffer-to-key-value-alist (delimiter-char &optional key-is-last)
  "Convert each line of the current buffer to a (KEY . VALUE) alist.
DELIMITER-CHAR separates KEY and VALUE.
If KEY-IS-LAST is non-nil, the part after the last delimiter is KEY,
and the part before it is VALUE.
If a line has no delimiter, use the whole line for both KEY and VALUE."
  (save-excursion
    (goto-char (point-min))
    (let (alist)
      (while (not (eobp))
        (let* ((line (buffer-substring-no-properties
                      (line-beginning-position)
                      (line-end-position)))
               (delim (regexp-quote (string delimiter-char)))
               (pos (if key-is-last
                        (and (string-match (concat ".*\\(" delim "\\)") line)
                             (match-beginning 1))
                      (string-match delim line))))
          (push
           (if pos
               (if key-is-last
                   (cons (substring line (1+ pos))
                         (substring line 0 pos))
                 (cons (substring line 0 pos)
                       (substring line (1+ pos))))
             (cons line line))
           alist))
        (forward-line 1))
      (nreverse alist))))

(provide 'efzf)

;;; efzf.el ends here
