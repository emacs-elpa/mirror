;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-vimish-fold" "0.3.0.20200122.3"
  "Integrate vimish-fold with evil."
  '((emacs       "24.4")
    (evil        "1.0.0")
    (vimish-fold "0.2.0"))
  :url "https://github.com/alexmurray/evil-vimish-fold"
  :commit "b6e0e6b91b8cd047e80debef1a536d9d49eef31a"
  :revdesc "b6e0e6b91b8c"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
