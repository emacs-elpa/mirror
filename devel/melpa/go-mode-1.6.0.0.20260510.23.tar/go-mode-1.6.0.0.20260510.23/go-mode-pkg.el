;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-mode" "1.6.0.0.20260510.23"
  "Major mode for the Go programming language."
  '((emacs "26.1"))
  :url "https://github.com/dominikh/go-mode.el"
  :commit "8aaaa9d2574d7862ecbbe1ff369e88fe3796c8be"
  :revdesc "v1.6.0-23-g8aaaa9d2574d"
  :keywords '("languages" "go"))
