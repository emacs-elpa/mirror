;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "0.7.0"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.23"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "9e98dda1748faca10ad74a8d2e58d7e5c219ed9d"
  :revdesc "v0.7.0-0-g9e98dda1748f"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
