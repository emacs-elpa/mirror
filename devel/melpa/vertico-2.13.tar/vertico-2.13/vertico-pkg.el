;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "2.13"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "a6874e3d8c74a9eea77967d702d608ebbd6b27ec"
  :revdesc "2.13-0-ga6874e3d8c74"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
