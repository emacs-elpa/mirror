;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "1.0.0.20260705.206"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "90e2767bd7e7c3fc69a723723cab488fbd976f7e"
  :revdesc "90e2767bd7e7"
  :keywords '("data" "extensions"))
