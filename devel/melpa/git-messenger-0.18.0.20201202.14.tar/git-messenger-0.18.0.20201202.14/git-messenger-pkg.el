;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-messenger" "0.18.0.20201202.14"
  "Popup last commit of current line."
  '((emacs "24.3")
    (popup "0.5.3"))
  :url "https://github.com/emacsorphanage/git-messenger"
  :commit "fb9a049ac3b5fba7369ef1f027b97881f1e377ec"
  :revdesc "fb9a049ac3b5"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com")))
