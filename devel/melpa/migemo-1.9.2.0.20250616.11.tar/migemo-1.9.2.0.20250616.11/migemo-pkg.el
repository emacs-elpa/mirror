;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "migemo" "1.9.2.0.20250616.11"
  "Japanese incremental search through dynamic pattern expansion."
  '((emacs "25"))
  :url "https://github.com/emacs-jp/migemo"
  :commit "c0d84b4092ddade01110ba875559bfd454862ac2"
  :revdesc "c0d84b4092dd"
  :authors '(("Satoru Takabayashi" . "satoru-t@is.aist-nara.ac.jp"))
  :maintainers '(("Satoru Takabayashi" . "satoru-t@is.aist-nara.ac.jp")))
