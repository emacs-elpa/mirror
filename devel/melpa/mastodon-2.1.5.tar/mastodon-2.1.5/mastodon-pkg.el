;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "2.1.5"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (compat  "31")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "156a4e2c76a2cd2c69c4e4fe35800a08afb17bfe"
  :revdesc "156a4e2c76a2"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
