;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-forge-prs" "0.1.0.20260624.5"
  "Generate PR descriptions for forge using gptel."
  '((emacs "28.1")
    (magit "4.0")
    (forge "0.3")
    (gptel "0.9"))
  :url "https://github.com/ArthurHeymans/gptel-forge-prs"
  :commit "0a23a7f3f339bb0110a446a7b358aa68867c7898"
  :revdesc "0a23a7f3f339"
  :keywords '("forge" "vc" "convenience" "llm" "pull-request"))
