;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minions" "1.2.1.0.20260925.1"
  "A minor-mode menu for the mode line."
  '((emacs  "29.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/minions"
  :commit "d683c91b8d20efb2ad799e55faae98c5b23c8077"
  :revdesc "v1.2.1-1-gd683c91b8d20"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.minions@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.minions@jonas.bernoulli.dev")))
