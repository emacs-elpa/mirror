;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-fu" "0.5.0.20261022.53"
  "Undo helper with redo."
  '((emacs "25.1"))
  :url "https://codeberg.org/ideasman42/emacs-undo-fu"
  :commit "2e39b8c2c3a68a7763e5936145dbe4d6060da19c"
  :revdesc "2e39b8c2c3a6"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
