;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "samskritam" "0.2.2"
  "Show samskrit word definitions."
  '((emacs     "28.1")
    (transient "0.3.0"))
  :url "https://github.com/thapakrish/samskritam"
  :commit "30bbd177d2664c5a0d33f17b42c07705b8473b66"
  :revdesc "30bbd177d266"
  :keywords '("samskrit" "sanskrit" "संस्कृत" "dictionary" "devanagari" "convenience" "language")
  :authors '(("Krishna Thapa" . "thapakrish@gmail.com"))
  :maintainers '(("Krishna Thapa" . "thapakrish@gmail.com")))
