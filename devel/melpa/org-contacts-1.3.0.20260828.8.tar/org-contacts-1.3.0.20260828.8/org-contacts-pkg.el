;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "1.3.0.20260828.8"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "dda8ba65f186384169b0025c0696f4a784674e0e"
  :revdesc "dda8ba65f186"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
