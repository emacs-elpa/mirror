;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.44.0.0.20260719.6"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "af41a8b461bbd353bdf07e27c73521aea7311151"
  :revdesc "af41a8b461bb"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
