;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oblivion-theme" "0.1.0.20260108.25"
  "A port of GEdit oblivion theme."
  '((emacs "24.1"))
  :url "https://codeberg.org/ideasman42/emacs-theme-oblivion"
  :commit "2a07e4fad23dbe6844dc565193fb04b033c319d4"
  :revdesc "2a07e4fad23d"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
