;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xbm-life" "0.1.3.0.20210508.9"
  "A XBM version of Conway's Game of Life."
  '((emacs "24.1"))
  :url "https://depp.brause.cc/xbm-life"
  :commit "ec6abb0182068294a379cb49ad5346b1d757457d"
  :revdesc "ec6abb018206"
  :keywords '("games")
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
