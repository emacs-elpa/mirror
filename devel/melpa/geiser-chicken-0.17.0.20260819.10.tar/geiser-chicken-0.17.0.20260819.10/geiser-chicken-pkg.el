;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-chicken" "0.17.0.20260819.10"
  "Chicken's implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.19"))
  :url "https://gitlab.com/emacs-geiser/chicken"
  :commit "ba0c16df8ce21f1722e27e4591656c9b64fafdff"
  :revdesc "ba0c16df8ce2"
  :keywords '("languages" "chicken" "scheme" "geiser"))
