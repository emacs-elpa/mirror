;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tracking" "2.14.0.20250831.7"
  "Buffer modification tracking."
  ()
  :url "https://github.com/emacs-circe/circe/wiki/Tracking"
  :commit "254814886cb4fdeba0ab1a9df33f7cbcdc1900cf"
  :revdesc "v2.14-7-g254814886cb4"
  :authors '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainers '(("Jorgen Schaefer" . "forcer@forcix.cx")))
