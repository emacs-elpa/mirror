;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "5.3.0.0.20260717.26"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "e81c3c6ce3cdeb02266487a6fc1461cb9194c70e"
  :revdesc "e81c3c6ce3cd"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
