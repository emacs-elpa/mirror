;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keyfreq" "1.8.0.20231107.8"
  "Track command frequencies."
  '((cl-lib "0.5"))
  :url "https://github.com/dacap/keyfreq"
  :commit "c6955162307f37c2ac631d9daf118781009f8dda"
  :revdesc "c6955162307f")
