;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "discover-clj-refactor" "0.1.0.20150328.3"
  "Adds discover context menu for clj-refactor."
  '((clj-refactor "0.14.0")
    (discover     "0.3"))
  :url "https://github.com/maio/discover-clj-refactor.el"
  :commit "3fbd5c1162739e606d7cf5d4f5d7426547d99647"
  :revdesc "3fbd5c116273"
  :keywords '("clj-refactor" "discover" "convenience")
  :authors '(("Marian Schubert" . "marian.schubert@gmail.com"))
  :maintainers '(("Marian Schubert" . "marian.schubert@gmail.com")))
