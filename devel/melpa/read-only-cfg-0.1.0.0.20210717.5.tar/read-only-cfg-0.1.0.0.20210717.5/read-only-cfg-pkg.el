;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "read-only-cfg" "0.1.0.0.20210717.5"
  "Make files read-only based on user config."
  '((emacs "24.3"))
  :url "https://github.com/pfchen/read-only-cfg"
  :commit "fa16d6018a5a29f26adf6007b6b76ea1b3c0bfce"
  :revdesc "fa16d6018a5a"
  :keywords '("tools" "convenience")
  :authors '(("pfchen" . "pfchen31@gmail.com"))
  :maintainers '(("pfchen" . "pfchen31@gmail.com")))
