;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "islisp-mode" "0.3.1.0.20220924.3"
  "Major mode for ISLisp programming."
  '((emacs "26.3"))
  :url "https://gitlab.com/sasanidas/islisp-mode"
  :commit "bbf45d02495f9455e91beed01676178dfa5d3561"
  :revdesc "bbf45d02495f"
  :keywords '("islisp" "lisp" "programming")
  :maintainers '(("Fermin Munoz" . "fmfs@posteo.net")))
