;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "goto-chg" "1.7.5.0.20240407.2"
  "Go to last change."
  '((emacs "24.1"))
  :url "https://github.com/emacs-evil/goto-chg"
  :commit "72f556524b88e9d30dc7fc5b0dc32078c166fda7"
  :revdesc "72f556524b88"
  :keywords '("convenience" "matching")
  :authors '(("David Andersson" . "l.david.anderssonsverige.nu"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
