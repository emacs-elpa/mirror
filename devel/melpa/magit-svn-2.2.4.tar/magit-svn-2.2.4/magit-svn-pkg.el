;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-svn" "2.2.4"
  "Git-Svn extension for Magit."
  '((emacs     "27.1")
    (dash      "2.19.1")
    (magit     "4.3.0")
    (transient "0.8.4"))
  :url "https://github.com/emacsorphanage/magit-svn"
  :commit "ca637c648835eddbeb277cc8089d3ffd6f75ae13"
  :revdesc "2.2.4-0-gca637c648835"
  :keywords '("vc" "tools")
  :authors '(("Phil Jackson" . "phil@shellarchive.co.uk"))
  :maintainers '(("Phil Jackson" . "phil@shellarchive.co.uk")))
