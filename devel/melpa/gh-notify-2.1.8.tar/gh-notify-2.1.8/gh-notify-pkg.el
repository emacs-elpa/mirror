;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gh-notify" "2.1.8"
  "A veneer for Magit/Forge GitHub notifications."
  '((emacs "29.1")
    (magit "3.3.0")
    (forge "0.4.0"))
  :url "https://github.com/anticomputer/gh-notify"
  :commit "d606d1390778cb104c28dbc5220e685293e1e687"
  :revdesc "d606d1390778"
  :keywords '("comm")
  :authors '(("Bas Alberts" . "bas@anti.computer")
             ("xristos" . "xristos@sdf.org"))
  :maintainers '(("Bas Alberts" . "bas@anti.computer")))
