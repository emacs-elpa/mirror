;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.3.0.0.20260811.19"
  "Emacs Client for Pi."
  '((emacs         "29.1")
    (compat        "31.0")
    (markdown-mode "2.8")
    (timeout       "2.1.7")
    (pcre2el       "1.12")
    (spinner       "1.7")
    (transient     "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "d0b405cf9ca396b1a15efc390a5aebb72a0e2580"
  :revdesc "d0b405cf9ca3"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
