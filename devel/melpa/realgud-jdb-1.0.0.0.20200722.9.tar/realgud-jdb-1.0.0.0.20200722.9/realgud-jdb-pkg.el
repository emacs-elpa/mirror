;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-jdb" "1.0.0.0.20200722.9"
  "Realgud front-end to Java's jdb debugger\"."
  '((realgud       "1.5.0")
    (load-relative "1.3.1")
    (emacs         "25"))
  :url "https://github.com/realgud/realgud-jdb"
  :commit "1c183b2f8aae0de60942ea01444b896bf182c66a"
  :revdesc "1c183b2f8aae"
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
