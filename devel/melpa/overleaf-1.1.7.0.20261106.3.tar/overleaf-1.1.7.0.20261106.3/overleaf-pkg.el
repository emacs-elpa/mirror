;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "1.1.7.0.20261106.3"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "51e061fb47333e4f4f64b4461c1eebd672a8de63"
  :revdesc "51e061fb4733"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
