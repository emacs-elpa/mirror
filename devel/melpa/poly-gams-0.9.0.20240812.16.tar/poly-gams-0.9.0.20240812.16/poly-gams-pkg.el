;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-gams" "0.9.0.20240812.16"
  "Polymode for GAMS."
  '((emacs     "25")
    (polymode  "0.2.2")
    (gams-mode "6.12"))
  :url "https://github.com/ShiroTakeda/poly-gams"
  :commit "e3abb2a195077750c89146900607894ed6239cb4"
  :revdesc "e3abb2a19507"
  :keywords '("languages" "multi-modes" "gams"))
