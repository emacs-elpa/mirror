;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.44.0.0.20260720.9"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "93f9cb927a80e0a5a01b4940ced563fdd3a6f424"
  :revdesc "93f9cb927a80"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
