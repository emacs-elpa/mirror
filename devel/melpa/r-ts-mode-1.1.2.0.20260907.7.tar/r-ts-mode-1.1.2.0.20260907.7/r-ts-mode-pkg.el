;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "r-ts-mode" "1.1.2.0.20260907.7"
  "R treesitter mode."
  '((emacs "30.1"))
  :url "https://codeberg.org/R-for-emacs/r-ts-mode"
  :commit "327dee7a359b61520e44343a82443ea516191e5b"
  :revdesc "327dee7a359b"
  :authors '(("Manuel Teodoro" . "ttm@teoten.me"))
  :maintainers '(("Manuel Teodoro" . "ttm@teoten.me")))
