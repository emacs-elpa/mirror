;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auth-source-xoauth2" "1.0.0.20220804.16"
  "Integrate auth-source with XOAUTH2."
  '((emacs "26.1"))
  :url "https://github.com/ccrusius/auth-source-xoauth2"
  :commit "99a03f8ce835412943d311b2746e77fcf5a1b500"
  :revdesc "v1.0-16-g99a03f8ce835"
  :authors '(("Cesar Crusius" . "ccrusius@google.com"))
  :maintainers '(("Cesar Crusius" . "ccrusius@google.com")))
