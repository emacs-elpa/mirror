;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-notmuch" "2.1.5"
  "Links to notmuch messages."
  '((emacs   "29.1")
    (compat  "31.1")
    (notmuch "0.39")
    (org     "9.8"))
  :url "https://github.com/tarsius/ol-notmuch"
  :commit "679e2672d920253f08ac1a7a27f812725b3dac22"
  :revdesc "v2.1.5-0-g679e2672d920"
  :keywords '("hypermedia" "mail")
  :authors '(("Matthieu Lemerre" . "racin@free.fr"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ol-notmuch@jonas.bernoulli.dev")))
