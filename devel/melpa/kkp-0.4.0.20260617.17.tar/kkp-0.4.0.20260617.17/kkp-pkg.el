;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "0.4.0.20260617.17"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benotn/kkp"
  :commit "0b77ce2fb9eefbb07ffa906f8fe2df14450a9cfc"
  :revdesc "0b77ce2fb9ee"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
