;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eyuml" "0.1.0.0.20141028.12"
  "Write textual uml diagram from emacs using yuml.me."
  '((request "0.2.0")
    (s       "1.8.0"))
  :url "https://github.com/antham/eyuml"
  :commit "2f259c201c6cc63ee608f75cd85c1ae27f9d2532"
  :revdesc "2f259c201c6c"
  :keywords '("uml")
  :authors '(("Anthony HAMON" . "hamon.anth@gmail.com"))
  :maintainers '(("Anthony HAMON" . "hamon.anth@gmail.com")))
