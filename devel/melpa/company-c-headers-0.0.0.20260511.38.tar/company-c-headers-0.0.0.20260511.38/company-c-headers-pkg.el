;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-c-headers" "0.0.0.20260511.38"
  "Company mode backend for C/C++ header files."
  '((emacs   "24.1")
    (company "0.8"))
  :url "https://github.com/randomphrase/company-c-headers"
  :commit "986cef8c7aae821ae65b193ea15e7f4a7097821c"
  :revdesc "986cef8c7aae"
  :keywords '("development" "company")
  :authors '(("Alastair Rankine" . "alastair@girtby.net"))
  :maintainers '(("Alastair Rankine" . "alastair@girtby.net")))
