;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alect-themes" "0.11.0.20260928.15"
  "Configurable light, dark and black themes."
  '((emacs "25.0"))
  :url "https://github.com/alezost/alect-themes"
  :commit "c1730e30bb96c578fc984ce533d2253fd83517b2"
  :revdesc "c1730e30bb96"
  :keywords '("color" "theme")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
