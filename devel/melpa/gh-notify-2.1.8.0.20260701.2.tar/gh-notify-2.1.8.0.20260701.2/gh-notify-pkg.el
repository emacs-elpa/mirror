;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gh-notify" "2.1.8.0.20260701.2"
  "A veneer for Magit/Forge GitHub notifications."
  '((emacs "29.1")
    (magit "3.3.0")
    (forge "0.4.0"))
  :url "https://github.com/anticomputer/gh-notify"
  :commit "efecbc0ea7a1b77a48fb395ce3d5a54271974608"
  :revdesc "efecbc0ea7a1"
  :keywords '("comm")
  :authors '(("Bas Alberts" . "bas@anti.computer")
             ("xristos" . "xristos@sdf.org"))
  :maintainers '(("Bas Alberts" . "bas@anti.computer")))
