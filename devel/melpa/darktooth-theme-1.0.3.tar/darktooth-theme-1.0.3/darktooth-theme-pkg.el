;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darktooth-theme" "1.0.3"
  "From the darkness... it watches."
  '((emacs      "27.1")
    (autothemer "0.2"))
  :url "https://github.com/emacsfodder/emacs-theme-darktooth"
  :commit "998639b2ce629dbdc0901ed560371f82de7af490"
  :revdesc "998639b2ce62"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
