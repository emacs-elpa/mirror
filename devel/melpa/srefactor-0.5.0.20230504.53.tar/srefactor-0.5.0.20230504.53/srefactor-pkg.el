;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srefactor" "0.5.0.20230504.53"
  "A refactoring tool based on Semantic parser framework."
  '((emacs "24.4"))
  :url "https://github.com/tuhdo/semantic-refactor"
  :commit "95c70a94b5aad4c85b35569e2f2325047791153a"
  :revdesc "95c70a94b5aa"
  :keywords '("c" "languages" "tools")
  :authors '(("Do Hoang" . "tuhdo1710@gmail.com")))
