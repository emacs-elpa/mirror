;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "1.2.4"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "bba36c41d5b21a80927583dc6eb83d080d0caad1"
  :revdesc "1.2.4-0-gbba36c41d5b2"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
