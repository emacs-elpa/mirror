;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-modern" "1.14"
  "Modern looks for Org."
  '((emacs  "29.1")
    (org    "9.6")
    (compat "31"))
  :url "https://github.com/minad/org-modern"
  :commit "4855ade77ab17de7587c37bde12a0afeab342783"
  :revdesc "1.14-0-g4855ade77ab1"
  :keywords '("outlines" "hypermedia" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
