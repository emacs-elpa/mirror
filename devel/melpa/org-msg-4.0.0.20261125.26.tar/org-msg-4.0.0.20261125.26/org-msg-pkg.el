;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-msg" "4.0.0.20261125.26"
  "Org mode to send and reply to email in HTML."
  '((emacs   "24.4")
    (htmlize "1.54"))
  :url "https://github.com/jeremy-compostella/org-msg"
  :commit "c274cd4f5ffa24b185687a01b7004b9d6cabec6e"
  :revdesc "c274cd4f5ffa"
  :keywords '("extensions" "mail")
  :authors '(("Jérémy Compostella" . "jeremy.compostella@gmail.com"))
  :maintainers '(("Jérémy Compostella" . "jeremy.compostella@gmail.com")))
