;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "all-ext" "0.5.0.20200315.18"
  "M-x all with helm-swoop/anything/multiple-cursors/line-number."
  '((emacs "24.4")
    (all   "1.0"))
  :url "https://github.com/rubikitch/all-ext"
  :commit "c865c62506af2c9edc7705a7c24dc8b70d5d4de2"
  :revdesc "c865c62506af"
  :keywords '("matching" "all" "search" "replace" "anything" "helm" "helm-swoop" "occur")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
