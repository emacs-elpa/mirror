;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ahg" "1.0.0.0.20261023.136"
  "Alberto's Emacs interface for Mercurial (Hg)."
  ()
  :url "https://bitbucket.org/agriggio/ahg"
  :commit "b55f7e3a066a7117beac00100fd7a11fb348cc00"
  :revdesc "b55f7e3a066a"
  :authors '(("Alberto Griggio" . "agriggio@users.sourceforge.net"))
  :maintainers '(("Alberto Griggio" . "agriggio@users.sourceforge.net")))
