;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sqlite-mode-extras" "0.7.0.20250827.17"
  "Extensions for sqlite-mode."
  '((emacs "29.1"))
  :url "https://github.com/xenodium/sqlite-mode-extras"
  :commit "83881ac1298eb15aaded2d579b59d7d9d25e403b"
  :revdesc "83881ac1298e")
