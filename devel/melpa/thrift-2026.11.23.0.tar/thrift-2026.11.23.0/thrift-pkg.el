;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "2026.11.23.0"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "f376cb35d789217b72e550a1e2c82cdf230e62b8"
  :revdesc "f376cb35d789"
  :keywords '("languages"))
