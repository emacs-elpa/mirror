;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "1.960.0.20260914.5"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "56859707a090cbd01083023287dd2a4bb4c54691"
  :revdesc "56859707a090"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
