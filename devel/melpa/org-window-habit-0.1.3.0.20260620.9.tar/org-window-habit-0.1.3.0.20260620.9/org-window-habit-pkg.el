;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "0.1.3.0.20260620.9"
  "Time window based habits."
  '((emacs "29.1")
    (dash  "2.10.0"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "19a6e070502e2b0d9aa85f12eda48debb44a479b"
  :revdesc "v0.1.3-9-g19a6e070502e"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
