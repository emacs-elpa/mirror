;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "2.8.2.0.20261028.3"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "619cb3c999719cd6ea0e784249811c2660980e79"
  :revdesc "v2.8.2-3-g619cb3c99971"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
