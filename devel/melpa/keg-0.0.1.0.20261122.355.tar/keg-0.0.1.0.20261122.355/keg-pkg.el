;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keg" "0.0.1.0.20261122.355"
  "Modern Elisp package development system."
  '((emacs "24.1"))
  :url "https://github.com/conao3/keg.el"
  :commit "68a9ab9f3300aa3004ab09c82afae8a2d36b909a"
  :revdesc "68a9ab9f3300"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
