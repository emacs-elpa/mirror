;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rust-mode" "1.0.6.0.20260725.48"
  "A major-mode for editing Rust source code."
  '((emacs "25.1"))
  :url "https://github.com/rust-lang/rust-mode"
  :commit "0058837c048cc031ca1a13f598a6a6604777458b"
  :revdesc "1.0.6-48-g0058837c048c"
  :keywords '("languages")
  :authors '(("Mozilla" . "rust-mode@noreply.github.com"))
  :maintainers '(("Mozilla" . "rust-mode@noreply.github.com")))
