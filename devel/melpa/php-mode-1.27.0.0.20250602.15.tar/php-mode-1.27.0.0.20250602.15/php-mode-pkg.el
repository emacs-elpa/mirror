;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "1.27.0.0.20250602.15"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "40b8abed3079771e060dd99a56703520dabf5be4"
  :revdesc "40b8abed3079"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
