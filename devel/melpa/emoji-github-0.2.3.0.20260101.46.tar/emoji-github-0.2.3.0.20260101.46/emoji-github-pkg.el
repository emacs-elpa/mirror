;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emoji-github" "0.2.3.0.20260101.46"
  "Display list of GitHub's emoji.  (cheat sheet)."
  '((emacs   "24.4")
    (emojify "1.0")
    (request "0.3.0"))
  :url "https://github.com/jcs-elpa/emoji-github"
  :commit "439c0471b16bc1d73e7d460e526a1b0fa14116c3"
  :revdesc "439c0471b16b"
  :keywords '("convenience" "list" "github" "emoji" "display")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
