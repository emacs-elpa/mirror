;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "2.7.0.0.20260727.1"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "c5bb04388a17e853f57183cd1cb9e9d37ea22dfd"
  :revdesc "c5bb04388a17"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
