;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pos-tip" "0.3.0.20200516.8"
  "Display Flycheck errors in GUI tooltips."
  '((emacs    "24.1")
    (flycheck "0.22")
    (pos-tip  "0.4.6"))
  :url "https://github.com/flycheck/flycheck-pos-tip"
  :commit "dc57beac0e59669926ad720c7af38b27c3a30467"
  :revdesc "0.3-8-gdc57beac0e59"
  :keywords '("tools" "convenience")
  :authors '(("Akiha Senda" . "senda.akiha@gmail.com")
             ("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Sebastian Wiesner" . "swiesner@lunaryorn.com")))
