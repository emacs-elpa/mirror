;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mandoku" "0.3.0.20180403.277"
  "A tool to access repositories of premodern Chinese texts."
  '((org          "8")
    (github-clone "20150705.1705"))
  :url "http://www.mandoku.org"
  :commit "e3b7678762e9824861b1ce775a94b05b096164f5"
  :revdesc "e3b7678762e9"
  :keywords '("convenience")
  :authors '(("Christian Wittern" . "cwittern@gmail.com"))
  :maintainers '(("Christian Wittern" . "cwittern@gmail.com")))
