;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "0.1.4.0.20261107.17"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "a8b012b7da74a00ee82137c38908911f87d40cc4"
  :revdesc "a8b012b7da74"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
