;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "search-web" "1.1"
  "Post web search queries using `browse-url'."
  ()
  :url "https://github.com/tomoya/search-web.el"
  :commit "c4ae86ac1acfc572b81f3d78764bd9a54034c331"
  :revdesc "c4ae86ac1acf"
  :authors '(("Tomoya Otake" . "tomoya.ton@gmail.com"))
  :maintainers '(("Tomoya Otake" . "tomoya.ton@gmail.com")))
