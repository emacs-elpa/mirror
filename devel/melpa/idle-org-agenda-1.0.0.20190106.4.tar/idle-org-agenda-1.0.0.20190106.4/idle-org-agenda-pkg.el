;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idle-org-agenda" "1.0.0.20190106.4"
  "Shows your agenda when editor is idle."
  ()
  :url "https://github.com/enisozgen/idle-org-agenda"
  :commit "bfdf1b4f4096acdd081b3549d6b838f4ca4f7d0d"
  :revdesc "bfdf1b4f4096"
  :keywords '("org" "org-mode" "org-agenda" "calendar")
  :authors '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainers '(("Enis zgen" . "mail@enisozgen.com")))
