;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zen-mode" "0.8.20200609"
  "A major mode for the Zen programming language."
  '((emacs "24.3"))
  :url "https://github.com/zenlang/zen-mode"
  :commit "c1b1806358f3cce6c04b30699987d82dc7d42559"
  :revdesc "0.8.20200609-0-gc1b1806358f3"
  :keywords '("zen" "languages")
  :authors '(("Andrea Orru" . "andreaorru1991@gmail.com")
             ("Andrew Kelley" . "superjoe30@gmail.com")
             ("kristopher tate" . "kt@connectfree.co.jp")
             ("Yoshitaka Takemoto" . "yt.3b8@connectfree.co.jp"))
  :maintainers '(("Andrea Orru" . "andreaorru1991@gmail.com")
                 ("Andrew Kelley" . "superjoe30@gmail.com")
                 ("kristopher tate" . "kt@connectfree.co.jp")
                 ("Yoshitaka Takemoto" . "yt.3b8@connectfree.co.jp")))
