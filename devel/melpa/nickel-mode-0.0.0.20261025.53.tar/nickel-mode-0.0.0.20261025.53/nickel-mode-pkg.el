;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nickel-mode" "0.0.0.20261025.53"
  "A major mode for editing Nickel source code."
  '((emacs "24.3"))
  :url "https://github.com/nickel-lang/nickel-mode"
  :commit "4e890cc504c38135cf2a61cae327e87c692a092c"
  :revdesc "4e890cc504c3"
  :keywords '("languages" "configuration-language" "configuration" "nickel" "infrastructure")
  :authors '(("The Nickel Team" . "(nickel-lang@tweag.io)"))
  :maintainers '(("The Nickel Team" . "(nickel-lang@tweag.io)")))
