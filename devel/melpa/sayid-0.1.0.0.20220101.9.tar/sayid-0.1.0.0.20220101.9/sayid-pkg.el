;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "0.1.0.0.20220101.9"
  "Sayid nREPL middleware client."
  '((cider "0.21.0"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "879aff586336a0ec4d46c0ed4720fb1de22082bd"
  :revdesc "879aff586336"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
