;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mvn" "0.1.0.20181002.10"
  "Helpers for compiling with maven."
  ()
  :url "https://github.com/apgwoz/mvn-el"
  :commit "ffa40235b7dabb6c6c165f64f32a963cde8031f0"
  :revdesc "ffa40235b7da"
  :keywords '("compilation" "maven" "java")
  :authors '(("Andrew Gwozdziewycz" . "git@apgwoz.com"))
  :maintainers '(("Andrew Gwozdziewycz" . "git@apgwoz.com")))
