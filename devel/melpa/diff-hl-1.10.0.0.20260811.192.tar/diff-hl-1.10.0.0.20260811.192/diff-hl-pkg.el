;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "1.10.0.0.20260811.192"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "6f1df2b83d1140a2938409b35de7f4c9c7b1defd"
  :revdesc "6f1df2b83d11"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
