;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.3.0.0.20260813.10"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "40dfa189d16a713522600f65f6e7b7f5d89393b8"
  :revdesc "40dfa189d16a"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
