;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "align-cljlet" "0.4.0.20160112.11"
  "Space align various Clojure forms."
  '((clojure-mode "1.11.5"))
  :url "https://github.com/gstamp/align-cljlet"
  :commit "ebcf0a912e836579a3a9d386e22c1c4bef7fba17"
  :revdesc "ebcf0a912e83"
  :authors '(("Glen Stampoultzis" . "gstampgmail.com")
             ("Reid D McKenzie" . "https://github.com/arrdem"))
  :maintainers '(("Glen Stampoultzis" . "gstampgmail.com")
                 ("Reid D McKenzie" . "https://github.com/arrdem")))
