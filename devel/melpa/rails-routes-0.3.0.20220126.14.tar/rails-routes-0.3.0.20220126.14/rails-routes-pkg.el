;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rails-routes" "0.3.0.20220126.14"
  "Search for and insert rails routes."
  '((emacs       "27.2")
    (inflections "1.1"))
  :url "https://github.com/otavioschwanck/rails-routes"
  :commit "eab995a9297ca5bd9bd4f4c2737f2fecfc36def0"
  :revdesc "eab995a9297c"
  :keywords '("tools" "languages")
  :authors '(("Otávio Schwanck" . "otavioschwanck@gmail.com"))
  :maintainers '(("Otávio Schwanck" . "otavioschwanck@gmail.com")))
