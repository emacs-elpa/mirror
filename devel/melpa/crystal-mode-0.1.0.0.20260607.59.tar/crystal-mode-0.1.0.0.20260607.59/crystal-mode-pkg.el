;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crystal-mode" "0.1.0.0.20260607.59"
  "Major mode for editing Crystal files."
  '((emacs "24.4"))
  :url "https://github.com/crystal-lang-tools/emacs-crystal-mode"
  :commit "f3b01df0bbe58852d0d7242bf5c0495931bb6fa6"
  :revdesc "f3b01df0bbe5"
  :keywords '("languages" "crystal"))
