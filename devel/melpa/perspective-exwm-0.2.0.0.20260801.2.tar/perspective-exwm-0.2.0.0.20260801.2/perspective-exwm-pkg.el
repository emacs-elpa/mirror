;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective-exwm" "0.2.0.0.20260801.2"
  "Better integration for perspective.el and EXWM."
  '((emacs       "27.1")
    (burly       "0.2-pre")
    (exwm        "0.26")
    (perspective "2.17"))
  :url "https://github.com/SqrtMinusOne/perspective-exwm.el"
  :commit "db1e196d11a701d0aa528444affc60c2516c0e6e"
  :revdesc "db1e196d11a7"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
