;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kixtart-mode" "1.4.3.0.20260324.12"
  "Major mode for editing KiXtart scripts."
  '((emacs "28.1")
    (eldoc "1.14.0"))
  :url "https://git.sr.ht/~mew/kixtart-mode"
  :commit "ddae1136812659e1bb0fb97da7b4b5db786a763d"
  :revdesc "v1.4.3-12-gddae11368126"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
