;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morrowind-theme" "0.1.0.20230912.7"
  "Theme."
  '((emacs "24.1"))
  :url "https://github.com/samuelbanya/morrowind-theme"
  :commit "f197ef02e96fa3b8a38eca25ba750df7b843e564"
  :revdesc "f197ef02e96f")
