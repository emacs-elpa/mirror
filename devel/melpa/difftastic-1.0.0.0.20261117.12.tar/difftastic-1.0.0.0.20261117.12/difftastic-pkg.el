;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difftastic" "1.0.0.0.20261117.12"
  "Wrapper for difftastic."
  '((emacs     "28.1")
    (compat    "29.1.4.2")
    (magit     "4.0.0")
    (transient "0.4.0"))
  :url "https://github.com/pkryger/difftastic.el"
  :commit "6f504f1a2965690ef2f3a514679b8d92f33b07a9"
  :revdesc "v1.0.0-12-g6f504f1a2965"
  :keywords '("tools" "diff")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
