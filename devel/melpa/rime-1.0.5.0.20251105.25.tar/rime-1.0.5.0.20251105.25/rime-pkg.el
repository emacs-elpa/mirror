;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rime" "1.0.5.0.20251105.25"
  "Rime input method."
  '((emacs    "26.3")
    (dash     "2.17.0")
    (cl-lib   "0.6.1")
    (popup    "0.5.3")
    (posframe "0.1.0"))
  :url "https://www.github.com/DogLooksGood/emacs-rime"
  :commit "f927d26e471e7d63de65ffa92897944242f2fd92"
  :revdesc "f927d26e471e"
  :keywords '("convenience" "input-method"))
