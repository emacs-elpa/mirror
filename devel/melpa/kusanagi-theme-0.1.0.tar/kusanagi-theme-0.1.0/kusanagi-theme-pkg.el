;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kusanagi-theme" "0.1.0"
  "Ghost in the Shell inspired dark theme built on Modus."
  '((emacs        "30.1")
    (modus-themes "5.0.0"))
  :url "https://github.com/LionyxML/kusanagi-theme"
  :commit "9bc24e173addb206a583fcd23086d79cd3e6c360"
  :revdesc "9bc24e173add"
  :keywords '("faces" "themes")
  :authors '(("Rahul Martim Juliato" . "rahul.juliato@gmail.com"))
  :maintainers '(("Rahul Martim Juliato" . "rahul.juliato@gmail.com")))
