;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qso" "1.0.1.0.20260930.12"
  "Amateur radio QSO logging."
  '((emacs "25.1")
    (adif  "1.0.7"))
  :url "https://github.com/K6SM/Emacs-QSO-Logger"
  :commit "018a5cab088db58c50656e2704edd94baab8b3e0"
  :revdesc "018a5cab088d"
  :keywords '("comm" "hamradio" "adif" "logging"))
