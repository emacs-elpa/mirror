;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macrostep-geiser" "0.2.0.0.20210717.3"
  "Macrostep for `geiser'."
  '((emacs     "24.4")
    (macrostep "0.9")
    (geiser    "0.12"))
  :url "https://github.com/nbfalcon/macrostep-geiser"
  :commit "f6a2d5bb96ade4f23df557649af87ebd0cc45125"
  :revdesc "f6a2d5bb96ad"
  :keywords '("languages" "scheme"))
