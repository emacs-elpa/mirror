;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "0.0.4.0.20261018.1"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "43c9fd027df9a66375e45cfc86915f201c03470d"
  :revdesc "v0.0.4-1-g43c9fd027df9"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
