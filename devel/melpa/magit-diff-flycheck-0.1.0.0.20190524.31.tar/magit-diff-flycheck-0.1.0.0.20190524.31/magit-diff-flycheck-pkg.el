;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-diff-flycheck" "0.1.0.0.20190524.31"
  "Report errors in diffs."
  '((magit    "2")
    (flycheck "31")
    (seq      "2")
    (emacs    "25.1"))
  :url "https://github.com/ragone/magit-diff-flycheck"
  :commit "ad58efa312d708f25661dfcc2a7f83a833cca328"
  :revdesc "ad58efa312d7"
  :keywords '("convenience" "matching")
  :authors '(("Alex Ragone" . "ragonedk@gmail.com"))
  :maintainers '(("Alex Ragone" . "ragonedk@gmail.com")))
