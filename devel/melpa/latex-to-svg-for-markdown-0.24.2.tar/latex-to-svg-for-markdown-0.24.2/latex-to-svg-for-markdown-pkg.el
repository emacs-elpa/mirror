;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-markdown" "0.24.2"
  "Preview Markdown LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.24.2"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "40eacb69d15f189a93d7529955ef715e5c82b4a9"
  :revdesc "v0.24.2-0-g40eacb69d15f"
  :keywords '("tex" "markdown" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
