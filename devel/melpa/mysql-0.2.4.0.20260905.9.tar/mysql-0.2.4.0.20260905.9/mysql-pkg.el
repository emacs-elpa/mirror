;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "0.2.4.0.20260905.9"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "443aa06a9a6b36de4141b5096e02502812c4a4a8"
  :revdesc "443aa06a9a6b"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
