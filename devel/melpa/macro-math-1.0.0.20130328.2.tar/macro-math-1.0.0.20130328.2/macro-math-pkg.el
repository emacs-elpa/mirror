;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macro-math" "1.0.0.20130328.2"
  "In-buffer mathematical operations."
  ()
  :url "http://nschum.de/src/emacs/macro-math/"
  :commit "216e59371e9ee39c34117ba79b9acd78bb415750"
  :revdesc "1.0-2-g216e59371e9e"
  :keywords '("convenience")
  :authors '(("Nikolaj Schumacher" . "bugs*nschumde"))
  :maintainers '(("Nikolaj Schumacher" . "bugs*nschumde")))
