;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redpen-paragraph" "0.42.0.20160625.1"
  "RedPen interface."
  '((emacs  "24")
    (cl-lib "0.5")
    (json   "1.4"))
  :url "https://github.com/karronoli/redpen-paragraph.el"
  :commit "770ffb34b04bfa0ea8484fa1506e96c530168e13"
  :revdesc "770ffb34b04b"
  :keywords '("document" "proofreading" "help"))
