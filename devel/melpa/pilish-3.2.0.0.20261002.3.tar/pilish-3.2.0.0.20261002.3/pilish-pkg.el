;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.2.0.0.20261002.3"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.4.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "ec016f7173a46de391bb86a167abb75640647588"
  :revdesc "v3.2.0-3-gec016f7173a4"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
