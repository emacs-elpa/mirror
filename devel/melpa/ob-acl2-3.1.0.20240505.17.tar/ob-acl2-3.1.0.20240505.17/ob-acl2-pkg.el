;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-acl2" "3.1.0.20240505.17"
  "Babel Functions for ACL2."
  '((emacs "28")
    (org   "9"))
  :url "https://github.com/tani/ob-acl2"
  :commit "db6b274de3cd16e17b5b525c94bf3ad9cc279970"
  :revdesc "db6b274de3cd"
  :keywords '("tools" "org" "literate programming" "theorem proving" "acl2" "proof assistant system")
  :authors '(("TANIGUCHI Masaya" . "masaya.taniguchi@a.riken.jp"))
  :maintainers '(("TANIGUCHI Masaya" . "masaya.taniguchi@a.riken.jp")))
