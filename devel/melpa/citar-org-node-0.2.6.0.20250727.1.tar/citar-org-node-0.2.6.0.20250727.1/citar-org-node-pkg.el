;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citar-org-node" "0.2.6.0.20250727.1"
  "Citar integration with org-node."
  '((emacs    "26.1")
    (citar    "1.1")
    (org-node "3.0.0")
    (ht       "1.6"))
  :url "https://github.com/krisbalintona/citar-org-node"
  :commit "b6f8e9db9bbff7675299bc3babb62db7e73bdc60"
  :revdesc "b6f8e9db9bbf"
  :keywords '("tools")
  :authors '(("Kristoffer Balintona" . "krisbalintona@gmail.com"))
  :maintainers '(("Kristoffer Balintona" . "krisbalintona@gmail.com")))
