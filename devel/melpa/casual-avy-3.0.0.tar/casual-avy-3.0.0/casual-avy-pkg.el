;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual-avy" "3.0.0"
  "Transient UI for Avy."
  '((emacs  "30.1")
    (avy    "0.5.0")
    (casual "3.0.0"))
  :url "https://github.com/kickingvegas/casual-avy"
  :commit "cfa3168ad1ff05baefc276d683ac9cca6ab68d47"
  :revdesc "cfa3168ad1ff"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
