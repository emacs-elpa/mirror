;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-review" "0.3.0.0.20250826.2"
  "Re:VIEW Back-End for Org Export Engine."
  '((emacs "26.1")
    (org   "9"))
  :url "https://github.com/masfj/ox-review"
  :commit "516bce8fb298e84d813d3c65b9cba200fa72e3b0"
  :revdesc "516bce8fb298"
  :keywords '("outlines" "hypermedia"))
