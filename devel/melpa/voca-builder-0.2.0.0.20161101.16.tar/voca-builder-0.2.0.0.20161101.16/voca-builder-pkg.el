;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "voca-builder" "0.2.0.0.20161101.16"
  "Helps you build up your vocabulary."
  '((popup "0.5.2"))
  :url "https://github.com/yitang/voca-builder"
  :commit "51573beec8cd8308477b0faf453aad93e17f57c5"
  :revdesc "51573beec8cd"
  :keywords '("english" "vocabulary")
  :authors '(("Yi Tang" . "yi.tang.uk@me.com"))
  :maintainers '(("Yi Tang" . "yi.tang.uk@me.com")))
