;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "night-owl-theme" "0.1.0.0.20261007.21"
  "A color theme for the night owls out there."
  '((emacs "24"))
  :url "https://github.com/aaronjensen/night-owl-theme"
  :commit "1b56ab29b322103287d97990108681d389188c65"
  :revdesc "v0.1.0-21-g1b56ab29b322"
  :authors '(("Aaron Jensen" . "aaronjensen@gmail.com"))
  :maintainers '(("Aaron Jensen" . "aaronjensen@gmail.com")))
