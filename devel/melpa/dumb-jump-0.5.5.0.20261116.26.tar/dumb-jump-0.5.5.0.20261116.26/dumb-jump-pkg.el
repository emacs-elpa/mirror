;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "0.5.5.0.20261116.26"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "26.1"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "5fe3d06313b6a2c48902849039ade750735dd251"
  :revdesc "5fe3d06313b6"
  :keywords '("programming"))
