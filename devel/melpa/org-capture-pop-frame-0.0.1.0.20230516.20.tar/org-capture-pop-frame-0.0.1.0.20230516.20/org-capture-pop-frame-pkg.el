;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-capture-pop-frame" "0.0.1.0.20230516.20"
  "Run org-capture in a new pop frame."
  '((emacs "24.4"))
  :url "https://github.com/tumashu/org-capture-pop-frame.git"
  :commit "d88b75cc02fc53716701051dbdd906db0515de8c"
  :revdesc "d88b75cc02fc"
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
