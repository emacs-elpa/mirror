;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "switch-buffer-functions" "0.0.1.0.20200127.11"
  "Hook run when current buffer changed."
  ()
  :url "https://github.com/10sr/switch-buffer-functions-el"
  :commit "40cb0c9e2c84b30e1c5c7458a795cda1bd8ad8fa"
  :revdesc "40cb0c9e2c84"
  :keywords '("hook" "utility")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
