;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-mff" "1.2.0.0.20210603.8"
  "Mouse Follows Focus."
  '((emacs "25.1"))
  :url "https://github.com/ieure/exwm-mff"
  :commit "89206f2e3189f589c27c56bd2b6203e906ee7100"
  :revdesc "89206f2e3189"
  :keywords '("unix")
  :authors '(("Ian Eure" . "public@lowbar.fyi"))
  :maintainers '(("Ian Eure" . "public@lowbar.fyi")))
