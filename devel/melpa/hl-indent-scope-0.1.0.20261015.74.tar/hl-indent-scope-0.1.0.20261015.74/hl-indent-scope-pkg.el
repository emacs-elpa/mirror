;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-indent-scope" "0.1.0.20261015.74"
  "Highlight indentation by scope."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope"
  :commit "944964aaf79c040aa38e662cf2da36839d999774"
  :revdesc "944964aaf79c"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
