;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-mode" "99.0"
  "A major mode for editing OpenSCAD code."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/openscad/emacs-scad-mode"
  :commit "8798dca7e919705bcbc35d4ab5639556827ccb6f"
  :revdesc "99.0-0-g8798dca7e919"
  :keywords '("languages")
  :maintainers '(("Len Trigg" . "lenbok@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
