;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "6.3.1.0.20261026.60"
  "Edit, debug, develop, run Python programs."
  '((emacs "24"))
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "d0302ec21e485f7d7f6d7bb632f3f5eadef4cbad"
  :revdesc "6.3.1-60-gd0302ec21e48"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
