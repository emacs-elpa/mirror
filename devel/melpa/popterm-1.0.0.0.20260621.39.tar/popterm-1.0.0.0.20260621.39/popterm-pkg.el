;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "1.0.0.0.20260621.39"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "24b9f85226dde1e4fc18c5470ed2971a120d4f27"
  :revdesc "24b9f85226dd"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
