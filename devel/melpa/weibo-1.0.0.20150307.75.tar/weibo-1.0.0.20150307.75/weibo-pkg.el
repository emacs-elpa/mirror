;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "weibo" "1.0.0.20150307.75"
  "Weibo client for Emacs."
  '((cl-lib "0.5"))
  :url "https://github.com/austin-----/weibo.emacs"
  :commit "a8abb50b7602fe15fe2bc6400ac29780e956b390"
  :revdesc "v1.0-75-ga8abb50b7602"
  :keywords '("weibo")
  :authors '(("Austin" . "austiny.cn@gmail.com"))
  :maintainers '(("Austin" . "austiny.cn@gmail.com")))
