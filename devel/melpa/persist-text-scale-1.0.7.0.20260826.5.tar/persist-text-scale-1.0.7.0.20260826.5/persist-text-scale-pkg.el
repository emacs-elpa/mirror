;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "1.0.7.0.20260826.5"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "dfedeeee6ef14d1d369b81fd25864dd85726af34"
  :revdesc "1.0.7-5-gdfedeeee6ef1"
  :keywords '("convenience" "faces")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
