;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kill-file-path" "1.0.0.20230306.3"
  "Copy file name into kill ring."
  '((emacs "26"))
  :url "https://github.com/chyla/kill-file-path/kill-file-path.el"
  :commit "5dcbce69cbae17665216a32dd20f27de54c62972"
  :revdesc "5dcbce69cbae"
  :keywords '("files")
  :authors '(("Adam Chyła" . "adam@chyla.org"))
  :maintainers '(("Adam Chyła" . "adam@chyla.org")))
