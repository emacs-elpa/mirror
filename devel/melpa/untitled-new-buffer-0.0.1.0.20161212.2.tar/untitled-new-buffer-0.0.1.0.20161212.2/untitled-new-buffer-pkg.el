;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "untitled-new-buffer" "0.0.1.0.20161212.2"
  "Open untitled new buffer like other text editors."
  '((emacs          "24.4")
    (magic-filetype "0.2.0"))
  :url "https://github.com/zonuexe/untitled-new-buffer.el"
  :commit "e359ae63bc6310e315b7c25157858f9b9796ed3d"
  :revdesc "e359ae63bc63"
  :keywords '("files" "convenience")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
