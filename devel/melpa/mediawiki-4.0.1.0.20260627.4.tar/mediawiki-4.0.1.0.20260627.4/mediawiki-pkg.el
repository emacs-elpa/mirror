;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "4.0.1.0.20260627.4"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "420d18365a62b0b6122c1ee8c3c88ebcb4f035df"
  :revdesc "420d18365a62"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
