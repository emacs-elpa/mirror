;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fz-index" "0.3.2.0.20261012.3"
  "Sublime-style fuzzy file open with a native index."
  '((emacs "28.1"))
  :url "https://github.com/uppet/fz-index"
  :commit "2c41d9de9f92ee1b844b2f7ec1fdcd82f111bb73"
  :revdesc "2c41d9de9f92"
  :keywords '("files" "matching" "convenience")
  :authors '(("Joyer Huang" . "collger@gmail.com"))
  :maintainers '(("Joyer Huang" . "collger@gmail.com")))
