;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-git" "0.0.1.0.20261122.136"
  "Git integration for dired."
  '((emacs         "26.1")
    (async-await   "1.0")
    (async         "1.9.4")
    (all-the-icons "2.2.0")
    (ppp           "1.0.0"))
  :url "https://github.com/conao3/dired-git.el"
  :commit "931f41918ac903d907b40d217a4a99de158fbc95"
  :revdesc "931f41918ac9"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
