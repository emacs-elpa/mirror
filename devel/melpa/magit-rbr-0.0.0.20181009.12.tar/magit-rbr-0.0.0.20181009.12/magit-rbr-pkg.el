;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-rbr" "0.0.0.20181009.12"
  "Support for git rbr in Magit."
  '((magit "2.13.0")
    (emacs "24.3"))
  :url "https://github.com/fanatoly/magit-rbr"
  :commit "029203b3e48537205052a058e964f058cd802c3c"
  :revdesc "029203b3e485"
  :keywords '("git" "magit" "rbr" "tools")
  :authors '(("Anatoly Fayngelerin" . "fanatoly+magitrbr@gmail.com"))
  :maintainers '(("Anatoly Fayngelerin" . "fanatoly+magitrbr@gmail.com")))
