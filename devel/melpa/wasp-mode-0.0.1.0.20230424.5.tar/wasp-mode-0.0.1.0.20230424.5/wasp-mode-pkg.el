;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wasp-mode" "0.0.1.0.20230424.5"
  "A major mode for the Wasp programming language."
  '((emacs "24.3"))
  :url "https://github.com/thechampagne/wasp-mode"
  :commit "76198cdd5f0ece3770c3a586115caea3ea613169"
  :revdesc "76198cdd5f0e"
  :keywords '("files" "wasp"))
