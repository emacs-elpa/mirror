;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-inline-anim" "0.3.0.20261119.5"
  "Inline playback of animated GIF/PNG for Org."
  '((emacs "25.3")
    (org   "9.4"))
  :url "https://github.com/shg/org-inline-anim.el"
  :commit "eee0ce91fe9abfd1c85fcfbd5d388cb29b6db32d"
  :revdesc "eee0ce91fe9a"
  :keywords '("org" "outlines" "hypermedia" "multimedia"))
