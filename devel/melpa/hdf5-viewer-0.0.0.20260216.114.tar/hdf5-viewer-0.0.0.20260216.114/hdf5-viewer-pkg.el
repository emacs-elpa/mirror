;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hdf5-viewer" "0.0.0.20260216.114"
  "Major mode for viewing HDF5 files."
  '((emacs "29.1"))
  :url "https://github.com/hdf5-viewer/hdf5-viewer"
  :commit "620abfea368c85e326108328c846a82fea490b77"
  :revdesc "620abfea368c"
  :keywords '("hdf5" "data")
  :authors '(("Paul Minner" . "minner.paul@gmail.com")
             ("Peter Mao" . "peter.mao@gmail.com"))
  :maintainers '(("Paul Minner" . "minner.paul@gmail.com")
                 ("Peter Mao" . "peter.mao@gmail.com")))
