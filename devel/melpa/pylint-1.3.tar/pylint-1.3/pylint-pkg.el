;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pylint" "1.3"
  "Minor mode for running `pylint'."
  ()
  :url "https://github.com/emacsorphanage/pylint"
  :commit "bddb91610b6b6aa1e7fee96b6be3be69dfe3695e"
  :revdesc "v1.3-0-gbddb91610b6b"
  :keywords '("languages" "python")
  :authors '(("Ian Eure" . "ian.eure@gmail.com"))
  :maintainers '(("Ian Eure" . "ian.eure@gmail.com")))
