;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "0.0.2.0.20260803.5"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazelbuild/emacs-bazel-mode"
  :commit "8c14a11845cf13118f44728fdb48e55dfa202d1f"
  :revdesc "8c14a11845cf"
  :keywords '("build tools" "languages"))
