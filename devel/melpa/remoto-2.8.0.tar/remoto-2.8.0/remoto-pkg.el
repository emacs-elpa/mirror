;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "2.8.0"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "a76159d285967ed6c542b5b93b461933ff4fd202"
  :revdesc "2.8.0-0-ga76159d28596"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
