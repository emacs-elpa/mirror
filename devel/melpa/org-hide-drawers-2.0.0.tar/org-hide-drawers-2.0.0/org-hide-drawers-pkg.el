;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-hide-drawers" "2.0.0"
  "Hide drawers in Org using overlays."
  '((emacs "26.1"))
  :url "https://github.com/krisbalintona/org-hide-drawers.git"
  :commit "15c8fa7fe5b15e09a751699ce780dde7edf7b5bd"
  :revdesc "15c8fa7fe5b1"
  :keywords '("tools" "extensions")
  :authors '(("Kristoffer Balintona" . "krisbalintona@gmail.com"))
  :maintainers '(("Kristoffer Balintona" . "krisbalintona@gmail.com")))
