;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shr-tag-pre-highlight" "2.0.20260829.15"
  "Syntax highlighting code block in HTML."
  '((emacs              "25.1")
    (language-detection "0.1.0"))
  :url "https://github.com/xuchunyang/shr-tag-pre-highlight.el"
  :commit "9f674822afb9ba09ce1ced776af003374d1c5ccf"
  :revdesc "9f674822afb9"
  :keywords '("html")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
