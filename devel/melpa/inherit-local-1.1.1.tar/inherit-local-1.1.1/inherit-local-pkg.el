;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inherit-local" "1.1.1"
  "Inherited buffer-local variables."
  '((emacs "24.3"))
  :url "https://github.com/shlevy/inherit-local/tree-master/"
  :commit "b1f4ff9c41f9d64e4adaf5adcc280b82f084cdc7"
  :revdesc "b1f4ff9c41f9")
