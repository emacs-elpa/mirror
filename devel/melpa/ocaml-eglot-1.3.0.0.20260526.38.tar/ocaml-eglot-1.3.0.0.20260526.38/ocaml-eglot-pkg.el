;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocaml-eglot" "1.3.0.0.20260526.38"
  "An OCaml companion for Eglot."
  '((emacs "29.1"))
  :url "https://github.com/tarides/ocaml-eglot"
  :commit "1edc88567f45dba18f220fc705acd93e652e12ff"
  :revdesc "1edc88567f45"
  :keywords '("ocaml" "languages")
  :authors '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com"))
  :maintainers '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com")))
