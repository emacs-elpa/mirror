;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orca" "0.1.0.0.20250205.44"
  "Org Capture."
  '((emacs    "24.3")
    (zoutline "0.1.0"))
  :url "https://github.com/abo-abo/orca"
  :commit "c6105df2ff6cec9f7d109a4348cc16e62bb0feef"
  :revdesc "c6105df2ff6c"
  :keywords '("org" "convenience")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
