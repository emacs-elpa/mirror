;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-test" "0.1.0.20181018.23"
  "Python testing integration."
  '((emacs "25.1"))
  :url "https://github.com/emacs-pe/python-test.el"
  :commit "f899975b133539e19ba822e4b0bfd1a28572967e"
  :revdesc "f899975b1335"
  :keywords '("convenience" "tools" "processes")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
