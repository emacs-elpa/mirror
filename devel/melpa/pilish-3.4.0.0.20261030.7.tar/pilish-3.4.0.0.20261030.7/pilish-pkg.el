;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "3.4.0.0.20261030.7"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.5.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "53dbba9586c35410bb5069148838b014e4c6f662"
  :revdesc "v3.4.0-7-g53dbba9586c3"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
