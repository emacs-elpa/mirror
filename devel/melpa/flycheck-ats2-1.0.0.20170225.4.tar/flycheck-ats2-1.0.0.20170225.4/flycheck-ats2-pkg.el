;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-ats2" "1.0.0.20170225.4"
  "Flycheck: ATS2 support."
  '((emacs    "24.1")
    (flycheck "0.22"))
  :url "https://github.com/drvink/flycheck-ats2"
  :commit "9f77add8408462af35bdddf87e37a661880255e3"
  :revdesc "9f77add84084"
  :keywords '("convenience" "tools" "languages")
  :authors '(("Mark Laws" . "mdl@60hz.org"))
  :maintainers '(("Mark Laws" . "mdl@60hz.org")))
