;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "1.0.0.20260718.235"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "35983966dc850cec03d37d3d98ff8fddd8f1d099"
  :revdesc "35983966dc85"
  :keywords '("convenience" "text"))
