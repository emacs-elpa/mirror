;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "polymode" "0.2.2.0.20261119.101"
  "Extensible framework for multiple major modes."
  '((emacs "25"))
  :url "https://github.com/polymode/polymode"
  :commit "b313feab15a83e2ab8dfa2be92b3f0481af192ad"
  :revdesc "b313feab15a8"
  :keywords '("languages" "multi-modes" "processes")
  :maintainers '(("Vitalie Spinu" . "spinuvit@gmail.com")))
