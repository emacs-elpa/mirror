;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "0.14"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "0ccdd131fb642323527e67aa9e854c9a82598507"
  :revdesc "0ccdd131fb64"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
