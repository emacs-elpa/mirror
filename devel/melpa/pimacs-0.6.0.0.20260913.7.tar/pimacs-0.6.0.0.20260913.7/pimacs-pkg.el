;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.6.0.0.20260913.7"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "f16c337f34b8d9a7694b79c2c01b045899ace4e6"
  :revdesc "f16c337f34b8"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
