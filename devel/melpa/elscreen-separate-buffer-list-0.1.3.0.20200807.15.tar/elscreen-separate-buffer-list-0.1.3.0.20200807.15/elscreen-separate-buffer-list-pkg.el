;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elscreen-separate-buffer-list" "0.1.3.0.20200807.15"
  "Separate buffer list manager for elscreen."
  '((emacs    "24.4")
    (elscreen "1.4.6"))
  :url "https://github.com/wamei/elscreen-separate-buffer-list"
  :commit "88d8850108947949431425a2d938a09d941454e8"
  :revdesc "88d885010894"
  :keywords '("elscreen")
  :authors '(("wamei" . "wamei.cho@gmail.com"))
  :maintainers '(("wamei" . "wamei.cho@gmail.com")))
