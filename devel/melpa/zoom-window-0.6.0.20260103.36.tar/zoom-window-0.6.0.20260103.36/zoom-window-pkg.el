;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zoom-window" "0.6.0.20260103.36"
  "Zoom window like tmux."
  '((emacs "24.3"))
  :url "https://github.com/syohex/emacs-zoom-window"
  :commit "8a0ae04de53583949a58e0aa8e7f64f03be7c9f8"
  :revdesc "8a0ae04de535"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
