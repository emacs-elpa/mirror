;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elwm" "0.0.2"
  "Minimalistic window manager for emacs."
  '((dash "1.1.0"))
  :url "https://github.com/Fuco1/elwm"
  :commit "c33b183f006ad476c3a44dab316f580f8b369930"
  :revdesc "c33b183f006a"
  :keywords '("docs")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
