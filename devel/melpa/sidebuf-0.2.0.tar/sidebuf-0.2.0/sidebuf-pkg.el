;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sidebuf" "0.2.0"
  "Buffer list sidebar panel."
  '((emacs "27.1"))
  :url "https://github.com/rain-64/sidebuf"
  :commit "9245426b8d8fc63f5bb2b5a28ebb957db4e4ce2c"
  :revdesc "v0.2.0-0-g9245426b8d8f"
  :keywords '("convenience" "buffers")
  :authors '(("rain-64" . "https://github.com/rain-64"))
  :maintainers '(("rain-64" . "https://github.com/rain-64")))
