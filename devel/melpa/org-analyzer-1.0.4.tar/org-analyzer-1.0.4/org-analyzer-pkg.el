;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-analyzer" "1.0.4"
  "Visualizes org-mode time tracking data."
  '((emacs "26"))
  :url "https://github.com/rksm/clj-org-analyzer"
  :commit "19da62aa4dcf1090be8f574f6f2d4c7e116163a8"
  :revdesc "19da62aa4dcf"
  :keywords '("calendar")
  :authors '(("Robert Krahn" . "robert@kra.hn"))
  :maintainers '(("Robert Krahn" . "robert@kra.hn")))
