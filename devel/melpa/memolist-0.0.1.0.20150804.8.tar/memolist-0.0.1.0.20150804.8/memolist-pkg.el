;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "memolist" "0.0.1.0.20150804.8"
  "Memolist.el is Emacs port of memolist.vim."
  '((markdown-mode "22.0")
    (ag            "0.45"))
  :url "https://github.com/mikanfactory/emacs-memolist"
  :commit "60c296e202a71e9dcf1c3936d47b5c4b95c5839f"
  :revdesc "60c296e202a7"
  :keywords '("markdown" "memo")
  :authors '(("mikanfactory" . "k952i4j14x17_at_gmail.com")))
