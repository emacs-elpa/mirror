;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-rust" "0.0.1.0.20220824.20"
  "Org-babel functions for Rust."
  ()
  :url "https://github.com/micanzhang/ob-rust"
  :commit "be059d231fafeb24a658db212a55ccdc55c0c500"
  :revdesc "be059d231faf"
  :keywords '("rust" "languages" "org" "babel"))
