;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-rdb2" "1.0.0.20190520.9"
  "Realgud front-end for interacting with Ruby debugger2."
  '((realgud       "1.4.5")
    (load-relative "1.2")
    (cl-lib        "0.5")
    (emacs         "24"))
  :url "https://github.com/rocky/realgud-ruby-debugger2"
  :commit "3594aa74f7afda3c3251bb2af7fe0e8ec6d621ae"
  :revdesc "3594aa74f7af")
