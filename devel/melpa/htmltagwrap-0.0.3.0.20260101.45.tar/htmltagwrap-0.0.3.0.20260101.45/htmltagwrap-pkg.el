;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "htmltagwrap" "0.0.3.0.20260101.45"
  "Wraps a chunk of HTML code in tags."
  '((emacs "24.4"))
  :url "https://github.com/emacs-vs/htmltagwrap"
  :commit "d5df47cf0a303ddad6b063c69db629d373ce2fd3"
  :revdesc "d5df47cf0a30"
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
