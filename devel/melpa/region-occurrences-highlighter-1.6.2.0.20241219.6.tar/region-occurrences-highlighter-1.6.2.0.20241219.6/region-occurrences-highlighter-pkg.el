;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "region-occurrences-highlighter" "1.6.2.0.20241219.6"
  "Mark occurrences of current region (selection)."
  '((emacs "26.1"))
  :url "https://github.com/alvarogonzalezsotillo/region-occurrences-highlighter"
  :commit "4c2c7a241fd257dd51f2726715cd1be022b3445a"
  :revdesc "4c2c7a241fd2"
  :keywords '("convenience")
  :authors '(("lvaro González Sotillo" . "alvarogonzalezsotillo@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
