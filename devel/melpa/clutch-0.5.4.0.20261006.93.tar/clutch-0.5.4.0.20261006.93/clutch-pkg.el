;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "0.5.4.0.20261006.93"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "ab2965725d00bdffcd4d4600a8c060ac2f8d2250"
  :revdesc "ab2965725d00"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
