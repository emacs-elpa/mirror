;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-wc" "0.0.0.20251023.39"
  "Count words in org mode trees."
  ()
  :url "https://github.com/tesujimath/org-wc"
  :commit "65e2caaeaeea01b4ab3ab3cd964c911297885a0f"
  :revdesc "65e2caaeaeea")
