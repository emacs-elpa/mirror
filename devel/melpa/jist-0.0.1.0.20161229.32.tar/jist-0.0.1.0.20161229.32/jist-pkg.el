;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jist" "0.0.1.0.20161229.32"
  "Gist integration."
  '((emacs     "24.4")
    (dash      "2.12.0")
    (seq       "1.11")
    (let-alist "1.0.4")
    (magit     "2.1.0")
    (request   "0.2.0"))
  :url "https://github.com/emacs-pe/jist.el"
  :commit "ec4b27eb4051f0084cb3b1e4f19fab9e2db77665"
  :revdesc "ec4b27eb4051"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
