;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vscode-dark-plus-theme" "2.1.0.0.20260606.4"
  "Default Visual Studio Code Dark+ theme."
  ()
  :url "https://github.com/ianpan870102/vscode-dark-plus-emacs-theme"
  :commit "c401b44809bfbf5928582efddc19ddda4f271ed4"
  :revdesc "c401b44809bf")
