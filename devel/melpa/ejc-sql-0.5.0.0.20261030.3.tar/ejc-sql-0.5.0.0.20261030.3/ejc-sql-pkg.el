;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "0.5.0.0.20261030.3"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "30.2")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "db54f7c584b6409957d1369635fef2af3103622c"
  :revdesc "v0.5.0-3-gdb54f7c584b6"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
