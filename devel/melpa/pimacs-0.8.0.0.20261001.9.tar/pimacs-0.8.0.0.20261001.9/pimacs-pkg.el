;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "0.8.0.0.20261001.9"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "0fa021b62f3f71b420fa41821960678f10b6e38b"
  :revdesc "0fa021b62f3f"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
