;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "2.15.0.20261126.2"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/vertico"
  :commit "6976caba3c83799e54d3e2647f6dee79f18869b2"
  :revdesc "2.15-2-g6976caba3c83"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
