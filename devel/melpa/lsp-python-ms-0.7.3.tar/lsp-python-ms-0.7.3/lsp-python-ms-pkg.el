;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-python-ms" "0.7.3"
  "The lsp-mode client for Microsoft python-language-server."
  '((emacs    "25.1")
    (lsp-mode "6.1"))
  :url "https://github.com/emacs-lsp/lsp-python-ms"
  :commit "7bda327bec7b219d140c34dab4b1e1fbd41bc516"
  :revdesc "7bda327bec7b"
  :keywords '("languages" "tools"))
