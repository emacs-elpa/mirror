;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gandalf-theme" "0.1.0.20130809.5"
  "Gandalf color theme."
  ()
  :url "https://github.com/ptrv/gandalf-theme-emacs"
  :commit "4e472fc851431458537d458d09c1f5895e338536"
  :revdesc "4e472fc85143"
  :keywords '("color" "theme")
  :authors '(("Peter Vasil" . "mail@petervasil.net"))
  :maintainers '(("Peter Vasil" . "mail@petervasil.net")))
