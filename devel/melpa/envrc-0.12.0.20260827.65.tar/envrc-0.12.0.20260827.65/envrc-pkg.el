;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "0.12.0.20260827.65"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "c1cc16ca6b02dc57c1704806710cbc94f5a5905a"
  :revdesc "c1cc16ca6b02"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
