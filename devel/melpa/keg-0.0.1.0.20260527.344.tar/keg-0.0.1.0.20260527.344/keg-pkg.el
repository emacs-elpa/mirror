;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keg" "0.0.1.0.20260527.344"
  "Modern Elisp package development system."
  '((emacs "24.1"))
  :url "https://github.com/conao3/keg.el"
  :commit "91030f36115ce50c4f812b95b169aeaffdd0e042"
  :revdesc "91030f36115c"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
