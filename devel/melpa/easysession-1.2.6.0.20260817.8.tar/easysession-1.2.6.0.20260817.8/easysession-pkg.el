;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "1.2.6.0.20260817.8"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "334f106659bcfb874a443b814f4cd99f2376aa0a"
  :revdesc "1.2.6-8-g334f106659bc"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
