;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultra-scroll" "0.7.0.20260810.2"
  "Fast and smooth scrolling."
  '((emacs "29.1"))
  :url "https://github.com/jdtsmith/ultra-scroll"
  :commit "0222f429955f5a2a3810f3c84d59ca441aa16eb2"
  :revdesc "0222f429955f"
  :keywords '("convenience"))
