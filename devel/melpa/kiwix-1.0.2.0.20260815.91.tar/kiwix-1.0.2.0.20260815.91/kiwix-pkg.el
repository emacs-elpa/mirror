;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kiwix" "1.0.2.0.20260815.91"
  "Searching offline Wikipedia through Kiwix."
  '((emacs   "25.1")
    (request "0.3.0"))
  :url "https://repo.or.cz/kiwix.el.git"
  :commit "f6becc2abf733b9e631c687c431dabd2097d1fba"
  :revdesc "v1.0.2-91-gf6becc2abf73"
  :keywords '("kiwix" "wikipedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
