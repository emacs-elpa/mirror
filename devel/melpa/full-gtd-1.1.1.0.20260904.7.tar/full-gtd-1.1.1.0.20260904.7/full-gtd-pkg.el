;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "full-gtd" "1.1.1.0.20260904.7"
  "Complete Getting Things Done (GTD) workflow for org-mode."
  '((emacs "29.1")
    (org   "9.3"))
  :url "https://github.com/OverbearingPearl/full-gtd"
  :commit "988c892b95638e3454096f8f5b26816769131612"
  :revdesc "988c892b9563"
  :keywords '("outlines" "tools" "convenience" "org" "todo" "gtd" "calendar")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
