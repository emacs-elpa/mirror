;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "efar" "1.29.0.20230216.25"
  "FAR-like file manager."
  '((emacs "26.1"))
  :url "https://github.com/suntsov/efar"
  :commit "78618a6cd9fe7d46c3728db3589d1fe50f7c1c6b"
  :revdesc "78618a6cd9fe"
  :keywords '("files")
  :authors '(("Vladimir Suntsov" . "vladimir@suntsov.online"))
  :maintainers '((nil . "vladimir@suntsov.online")))
