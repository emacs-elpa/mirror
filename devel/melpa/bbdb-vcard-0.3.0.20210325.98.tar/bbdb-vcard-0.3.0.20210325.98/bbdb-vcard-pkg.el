;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbdb-vcard" "0.3.0.20210325.98"
  "VCard import/export for BBDB."
  '((bbdb "3.0"))
  :url "https://github.com/tohojo/bbdb-vcard"
  :commit "113c66115ce68316e209f51ebce56de8dded3606"
  :revdesc "0.3-98-g113c66115ce6"
  :keywords '("data" "calendar" "mail" "news")
  :authors '(("Bert Burgemeister" . "trebbu@googlemail.com")
             ("Vincent Geddes" . "vincent.geddes@gmail.com"))
  :maintainers '(("Bert Burgemeister" . "trebbu@googlemail.com")
                 ("Vincent Geddes" . "vincent.geddes@gmail.com")))
