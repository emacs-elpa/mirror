;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inlineR" "0.2.0.20191017.7"
  "Insert Tag for inline image of R graphics."
  ()
  :url "https://github.com/myuhe/inlineR.el"
  :commit "bf6450a3540aa3538546d312324c41befd0a4e54"
  :revdesc "bf6450a3540a"
  :keywords '("convenience" "iimage.el" "cacoo.el")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
