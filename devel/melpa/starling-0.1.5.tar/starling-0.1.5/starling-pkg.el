;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "starling" "0.1.5"
  "Starling bank interaction."
  '((emacs "29.1")
    (plz   "0.7.2"))
  :url "https://codeberg.org/draxil/starling-el"
  :commit "9a5f3003d40a9c6bd64b5cf396973c4922006e4d"
  :revdesc "9a5f3003d40a"
  :keywords '("data" "applications" "banking")
  :authors '(("Joe Higton" . "draxil@gmail.com"))
  :maintainers '(("Joe Higton" . "draxil@gmail.com")))
