;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-keypad" "0.1.5.0.20260802.19"
  "Modal command dispatch for evil-mode."
  '((emacs "30.1")
    (evil  "1.0.0"))
  :url "https://github.com/achyudh/evil-keypad"
  :commit "0a9f3873d67ba7b9ab4281bcb6d000ec9a1dbd04"
  :revdesc "0a9f3873d67b"
  :keywords '("convenience" "emulation")
  :authors '(("Achyudh Ram" . "mail@achyudh.me"))
  :maintainers '(("Achyudh Ram" . "mail@achyudh.me")))
