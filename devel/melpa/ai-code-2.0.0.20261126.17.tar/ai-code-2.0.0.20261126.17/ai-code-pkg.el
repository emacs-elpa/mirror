;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "2.0.0.20261126.17"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "3c3ddeefcfb2c0b9e63515ef936d25879cad3449"
  :revdesc "3c3ddeefcfb2"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
