;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "1.2.3.0.20260924.298"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "f1d5f10e07365785f60332aff3c4ddc191ab48a6"
  :revdesc "f1d5f10e0736"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
