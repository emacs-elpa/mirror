;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ls-git" "0.1.0.20250419.42"
  "Consult integration for git."
  '((emacs   "27.1")
    (consult "0.16"))
  :url "https://github.com/rcj/consult-ls-git"
  :commit "85882e4b7af9ad40160d985e42b36b0fd6400ead"
  :revdesc "85882e4b7af9"
  :keywords '("convenience"))
