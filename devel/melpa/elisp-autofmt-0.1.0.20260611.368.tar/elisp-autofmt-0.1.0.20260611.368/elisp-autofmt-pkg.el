;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-autofmt" "0.1.0.20260611.368"
  "Emacs lisp auto-format."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt"
  :commit "fdae9054c55804def507cf7045c8460573d876a9"
  :revdesc "fdae9054c558"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
