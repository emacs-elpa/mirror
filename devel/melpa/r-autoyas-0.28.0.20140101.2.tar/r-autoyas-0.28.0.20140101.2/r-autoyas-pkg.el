;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "r-autoyas" "0.28.0.20140101.2"
  "Provides automatically created yasnippets for R function argument lists."
  '((ess       "0")
    (yasnippet "0.8.0"))
  :url "https://github.com/mlf176f2/r-autoyas.el"
  :commit "d321a7da0ef2e94668d53e0807277da7b70ea678"
  :revdesc "v0.28-2-gd321a7da0ef2"
  :keywords '("r" "yasnippet"))
