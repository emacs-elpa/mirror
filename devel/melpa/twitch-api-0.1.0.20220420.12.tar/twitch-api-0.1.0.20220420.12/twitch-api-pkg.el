;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "twitch-api" "0.1.0.20220420.12"
  "An elisp interface for the Twitch.tv API."
  '((emacs "27.1")
    (dash  "2.19.0"))
  :url "https://github.com/BenediktBroich/twitch-api"
  :commit "181681097d1fc8d7b78928f8a5b38c61d0e20ef5"
  :revdesc "181681097d1f"
  :keywords '("multimedia" "twitch-api"))
