;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ado-mode" "16.1.4.0.20260210.137"
  "Major mode for editing Stata-related files."
  '((emacs "25.1"))
  :url "https://github.com/louabill/ado-mode"
  :commit "371441d27027fd4783a8c828458a5af098babca4"
  :revdesc "16.1.4-137-g371441d27027"
  :keywords '("tools" "languages" "files" "convenience" "stata" "mata" "ado")
  :authors '(("Bill Rising" . "brising@alum.mit.edu"))
  :maintainers '(("Bill Rising" . "brising@alum.mit.edu")))
