;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ropgadget" "1.0.0.0.20230107.2"
  "Display and filter ROP gadgets of a binary."
  '((emacs     "24.4")
    (transient "0.3.6"))
  :url "https://github.com/Dragoncraft89/ropgadget-el"
  :commit "10e9d6f66de1ee805d871c59f4acc078b66747a3"
  :revdesc "10e9d6f66de1"
  :keywords '("tools" "ctf" "pwn" "rop"))
