;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "0.1.0.0.20260418.107"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "bc598413a18baa3ec9ef7e1a0cf0115685d23a22"
  :revdesc "bc598413a18b"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
