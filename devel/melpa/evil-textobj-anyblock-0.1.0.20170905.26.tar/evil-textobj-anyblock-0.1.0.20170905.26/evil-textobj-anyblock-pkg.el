;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-anyblock" "0.1.0.20170905.26"
  "Textobject for the closest user-defined blocks."
  '((cl-lib "0.5")
    (evil   "1.1.0"))
  :url "https://github.com/noctuid/evil-textobj-anyblock"
  :commit "ff00980f0634f95bf2ad9956b615a155ea8743be"
  :revdesc "v0.1-26-gff00980f0634"
  :keywords '("evil")
  :authors '(("Fox Kiester" . "noct@openmailbox.org"))
  :maintainers '(("Fox Kiester" . "noct@openmailbox.org")))
