;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fnm" "0.1.0.0.20260717.6"
  "Manage Node versions using fnm."
  '((emacs "24.1")
    (s     "1.8.0")
    (dash  "2.18.0")
    (f     "0.14.0"))
  :url "https://github.com/nhojb/fnm.el"
  :commit "2bb4c5d287a3c2046b42f90db2cc8e889ea642d9"
  :revdesc "2bb4c5d287a3"
  :keywords '("tools" "node" "fnm" "nvm")
  :authors '(("John Buckley" . "nhoj.buckley@gmail.com"))
  :maintainers '(("John Buckley" . "nhoj.buckley@gmail.com")))
