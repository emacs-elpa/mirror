;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "amd-mode" "2.8.0.20180111.4"
  "Minor mode for handling JavaScript AMD module requirements."
  '((emacs        "25")
    (projectile   "20161008.47")
    (s            "1.9.0")
    (f            "0.16.2")
    (seq          "2.16")
    (makey        "0.3")
    (js2-mode     "20140114")
    (js2-refactor "0.6.1"))
  :url "https://github.com/NicolasPetton/amd-mode.el"
  :commit "01fd19e0d635ccaf8e812364d8720733f2e84126"
  :revdesc "2.8-4-g01fd19e0d635"
  :keywords '("javascript" "amd" "projectile")
  :authors '(("Nicolas Petton" . "petton.nicolas@gmail.com"))
  :maintainers '(("Nicolas Petton" . "petton.nicolas@gmail.com")))
