;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "0.6.1.0.20260310.1"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3"))
  :url "https://codeberg.org/guix/emacs-guix"
  :commit "43151aa6902c7122e919d3ed688fd484ec004feb"
  :revdesc "v0.6.1-1-g43151aa6902c"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
