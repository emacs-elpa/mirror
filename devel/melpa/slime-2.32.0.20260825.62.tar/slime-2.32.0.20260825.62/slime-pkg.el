;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "2.32.0.20260825.62"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "06e46196ad7d972c10559291d8a82f8beb735463"
  :revdesc "06e46196ad7d"
  :keywords '("languages" "lisp" "slime"))
