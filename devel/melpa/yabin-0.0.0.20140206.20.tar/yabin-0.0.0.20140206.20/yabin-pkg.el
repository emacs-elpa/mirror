;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yabin" "0.0.0.20140206.20"
  "Yet Another Bignum package (A thin wrapper of calc.el)."
  ()
  :url "https://github.com/d5884/yabin"
  :commit "db8c404507560ef9147fcce2b94cd706fbfa03b5"
  :revdesc "db8c40450756"
  :keywords '("data")
  :authors '(("Daisuke Kobayashi" . "d5884jp@gmail.com"))
  :maintainers '(("Daisuke Kobayashi" . "d5884jp@gmail.com")))
