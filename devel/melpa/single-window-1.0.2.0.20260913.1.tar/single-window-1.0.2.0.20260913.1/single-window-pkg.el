;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "single-window" "1.0.2.0.20260913.1"
  "Always open buffers in the current window."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/single-window.el"
  :commit "fe30d590c3915ac83f897eecbcd34eb4cf3b3f6a"
  :revdesc "1.0.2-1-gfe30d590c391"
  :keywords '("convenience" "windows")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
