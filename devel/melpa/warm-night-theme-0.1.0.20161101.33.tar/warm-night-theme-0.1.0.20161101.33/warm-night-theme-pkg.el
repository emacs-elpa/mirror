;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "warm-night-theme" "0.1.0.20161101.33"
  "Emacs 24 theme with a dark background."
  '((emacs "24"))
  :url "https://github.com/mswift42/warm-night-theme"
  :commit "020f084d23409b5035150508ba6e57c2509edd64"
  :revdesc "020f084d2340")
