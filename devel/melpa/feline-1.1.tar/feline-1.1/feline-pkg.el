;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "feline" "1.1"
  "A modeline with very little."
  '((emacs "28.1"))
  :url "https://opensource.chee.party/chee/feline-mode"
  :commit "8c46b1be9e45a38281aa9ddae79fda3c8e4cb5c5"
  :revdesc "8c46b1be9e45"
  :authors '(("chee" . "emacs@chee.party"))
  :maintainers '(("chee" . "emacs@chee.party")))
