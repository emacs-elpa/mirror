;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "streamlink" "0.1.0.20210811.4"
  "A major mode for streamlink output."
  '((s "1.12.0"))
  :url "https://github.com/BenediktBroich/streamlink"
  :commit "13dff15121ac0276f693696db9b04ae5820058d5"
  :revdesc "13dff15121ac"
  :keywords '("multimedia" "streamlink"))
