;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "5.3.0.0.20260712.15"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "31e8394cb1a563814d341bc4f7fa162a6e0d9169"
  :revdesc "31e8394cb1a5"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
