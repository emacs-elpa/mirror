;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "drill-instructor-AZIK-force" "0.1.0.20151123.2"
  "Support AZIK input."
  ()
  :url "https://github.com/myuhe/drill-instructor-AZIK-force.el"
  :commit "008cea202dc31d7d6fb1e7d8e6334d516403b7a5"
  :revdesc "008cea202dc3"
  :keywords '("convenience")
  :authors '(("Yuhei Maeda" . "yuhei.maeda_at_gmail.com")))
