;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recentf-remove-sudo-tramp-prefix" "0.0.0.0.20220621.17"
  "Normalise recentf history."
  '((emacs "24.4"))
  :url "https://github.com/ncaq/recentf-remove-sudo-tramp-prefix"
  :commit "95ff600058371dd08f615095a55850d2910021bb"
  :revdesc "95ff60005837"
  :authors '(("ncaq" . "ncaq@ncaq.net"))
  :maintainers '(("ncaq" . "ncaq@ncaq.net")))
