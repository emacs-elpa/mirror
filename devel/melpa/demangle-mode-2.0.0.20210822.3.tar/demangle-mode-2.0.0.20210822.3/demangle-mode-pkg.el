;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "demangle-mode" "2.0.0.20210822.3"
  "Automatically demangle C++, D, and Rust symbols."
  '((cl-lib "0.1")
    (emacs  "24.3"))
  :url "https://github.com/liblit/demangle-mode"
  :commit "04f545adab066708d6151f13da65aaf519f8ac4e"
  :revdesc "04f545adab06"
  :keywords '("c" "tools")
  :authors '(("Ben Liblit" . "liblit@acm.org"))
  :maintainers '(("Ben Liblit" . "liblit@acm.org")))
