;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-lens" "0.7.0.0.20220922.3"
  "Show new, deleted or modified files in branch."
  '((emacs "24.4"))
  :url "https://github.com/pidu/git-lens"
  :commit "347832fbdb75a0930aa3eef628ec0069a335f3b7"
  :revdesc "347832fbdb75"
  :keywords '("vc" "convenience")
  :authors '(("Peter Stiernström" . "peter@stiernstrom.se"))
  :maintainers '(("Peter Stiernström" . "peter@stiernstrom.se")))
