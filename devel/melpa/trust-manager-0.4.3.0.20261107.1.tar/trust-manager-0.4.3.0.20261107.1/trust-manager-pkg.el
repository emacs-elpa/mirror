;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trust-manager" "0.4.3.0.20261107.1"
  "Convenient trust management."
  '((emacs "30.1"))
  :url "https://git.sr.ht/~eshel/trust-manager"
  :commit "bd30086bb8518c0b2bcb36f3856917690f58ab05"
  :revdesc "v0.4.3-1-gbd30086bb851"
  :keywords '("security" "trust" "files")
  :authors '(("Eshel Yaron" . "me@eshelyaron.com"))
  :maintainers '(("Eshel Yaron" . "me@eshelyaron.com")))
