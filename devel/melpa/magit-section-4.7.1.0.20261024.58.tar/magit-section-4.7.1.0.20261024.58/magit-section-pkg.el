;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-section" "4.7.1.0.20261024.58"
  "Sections for read-only buffers."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/magit"
  :commit "70e5b635068949a6347e6e93f1758b11f561aba2"
  :revdesc "v4.7.1-58-g70e5b6350689"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")))
