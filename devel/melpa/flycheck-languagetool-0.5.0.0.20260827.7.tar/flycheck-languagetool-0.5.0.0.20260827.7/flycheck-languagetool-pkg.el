;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-languagetool" "0.5.0.0.20260827.7"
  "Flycheck support for LanguageTool."
  '((emacs    "27.1")
    (flycheck "39.0.0.20260813"))
  :url "https://github.com/emacs-languagetool/flycheck-languagetool"
  :commit "11784df62e08178b52bb303df3dc64c87a199e1f"
  :revdesc "11784df62e08"
  :keywords '("convenience" "grammar" "check")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com")
             ("Peter Oliver" . "git@mavit.org.uk"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Peter Oliver" . "git@mavit.org.uk")))
