;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "single-window" "1.0.2"
  "Always open buffers in the current window."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/single-window.el"
  :commit "9b8f12c097ada5c770da827cb16d3ab06f452a0c"
  :revdesc "1.0.2-0-g9b8f12c097ad"
  :keywords '("convenience" "windows"))
