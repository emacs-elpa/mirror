;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatui-dark-theme" "1.0.1"
  "FlatUI dark theme built on the modus-themes engine."
  '((emacs        "29.1")
    (modus-themes "5.0.0"))
  :url "https://github.com/theasp/flatui-dark-theme"
  :commit "72c49292b335872dda1b50ce29e19362be4e8820"
  :revdesc "72c49292b335"
  :keywords '("faces" "theme" "flatui" "modus")
  :authors '(("Andrew Phillips" . "theasp@gmail.com"))
  :maintainers '(("Andrew Phillips" . "theasp@gmail.com")))
