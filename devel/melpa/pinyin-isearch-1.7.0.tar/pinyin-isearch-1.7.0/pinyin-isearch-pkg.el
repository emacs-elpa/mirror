;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "1.7.0"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "b87cf9856660fbcc83d8297ef33c243a3f4ec4f0"
  :revdesc "b87cf9856660"
  :keywords '("chinese" "isearch" "matching" "convenience")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
