;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "0.5.0.0.20260813.1"
  "Create releases of Emacs packages."
  '((emacs    "30.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.7"))
  :url "https://github.com/magit/sisyphus"
  :commit "4c75cbf6c3543322c08c280d2b9b6f37b79f220d"
  :revdesc "v0.5.0-1-g4c75cbf6c354"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
