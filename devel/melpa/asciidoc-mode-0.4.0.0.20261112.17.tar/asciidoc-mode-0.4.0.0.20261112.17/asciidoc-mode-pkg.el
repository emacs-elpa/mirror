;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asciidoc-mode" "0.4.0.0.20261112.17"
  "Major mode for AsciiDoc markup."
  '((emacs "30.1"))
  :url "https://github.com/bbatsov/asciidoc-mode"
  :commit "75631bf0a22c2247ff4bd4f79ac71828167447c9"
  :revdesc "75631bf0a22c"
  :keywords '("text" "asciidoc" "languages" "tree-sitter")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
