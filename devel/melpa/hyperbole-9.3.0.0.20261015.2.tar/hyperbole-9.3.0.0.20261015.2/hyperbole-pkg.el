;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "9.3.0.0.20261015.2"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "555e986434e83feb285d14fdeb770821e077dbcb"
  :revdesc "hyperbole-9.3.0-2-g555e986434e8"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")
                 ("Mats Lidell" . "matsl@gnu.org")))
