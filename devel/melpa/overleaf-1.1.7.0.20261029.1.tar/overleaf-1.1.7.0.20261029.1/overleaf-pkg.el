;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "1.1.7.0.20261029.1"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "0bae5a630c9e14019473057744619ce7e66afc3f"
  :revdesc "0bae5a630c9e"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
