;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smartrep" "1.0.0.0.20240416.9"
  "Support sequential operation which omitted prefix keys."
  ()
  :url "https://github.com/myuhe/smartrep.el"
  :commit "fdf135e3781b286174b5de4d613f12c318d2023c"
  :revdesc "fdf135e3781b"
  :keywords '("convenience")
  :authors '(("myuhe" . "yuhei.maeda_at_gmail.com")))
