;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud-node-debug" "1.0.0.0.20190525.11"
  "Realgud front-end to older \"node debug\"."
  '((realgud       "1.4.5")
    (load-relative "1.2")
    (cl-lib        "0.5")
    (emacs         "25"))
  :url "https://github.com/realgud/realgud-node-debug"
  :commit "72e786359ce9dace1796b0d81a00e9340e9c90ad"
  :revdesc "72e786359ce9"
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
