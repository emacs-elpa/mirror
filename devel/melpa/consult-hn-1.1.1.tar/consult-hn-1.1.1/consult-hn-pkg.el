;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-hn" "1.1.1"
  "Hacker News search with Consult."
  '((emacs     "29.4")
    (consult   "2.0")
    (ts        "0.3")
    (transient "0.9"))
  :url "https://github.com/agzam/consult-hn"
  :commit "9667a1af212f272aca97142d2b3de248584369e6"
  :revdesc "v1.1.1-0-g9667a1af212f"
  :keywords '("search" "extensions")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
