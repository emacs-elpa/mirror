;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truename-cache" "0.3.7.0.20260726.2"
  "Efficiently de-dup file-names."
  '((emacs  "27.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/truename-cache"
  :commit "5de00fbb6df3e3636095dc02d5c726f200213753"
  :revdesc "0.3.7-2-g5de00fbb6df3"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
