;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seriestracker" "1.3.1.0.20250315.3"
  "Series tracker."
  '((dash      "2.12.1")
    (transient "0.3.2")
    (emacs     "27.1"))
  :url "https://www.github.com/MaximeWack/seriesTracker"
  :commit "03e5937abe7911fef6286601cbe54e0a6bc9ec3f"
  :revdesc "03e5937abe79"
  :keywords '("multimedia")
  :authors '(("Maxime Wack" . "contactatmaximewackdotcom"))
  :maintainers '(("Maxime Wack" . "contactatmaximewackdotcom")))
