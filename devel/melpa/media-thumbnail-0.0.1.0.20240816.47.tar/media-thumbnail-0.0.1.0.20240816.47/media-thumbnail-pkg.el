;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "media-thumbnail" "0.0.1.0.20240816.47"
  "Utility package to provide media icons."
  '((emacs "28.1"))
  :url "https://github.com/jojojames/media-thumbnail"
  :commit "190632c1d6cc2ab94031d57e0c24412a4698faf0"
  :revdesc "190632c1d6cc"
  :keywords '("files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
