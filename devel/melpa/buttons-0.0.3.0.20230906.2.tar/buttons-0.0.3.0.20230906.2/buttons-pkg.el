;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buttons" "0.0.3.0.20230906.2"
  "Define and visualize hierarchies of keymaps."
  '((emacs  "24.1")
    (cl-lib "0.3"))
  :url "https://github.com/erjoalgo/emacs-buttons"
  :commit "6fd4a9b3f8b9d2344a316b0fd6576d90f53f5acb"
  :revdesc "0.0.3-2-g6fd4a9b3f8b9"
  :keywords '("lisp" "extensions" "convenience" "tools")
  :maintainers '(("concat \"erjoalgo\" \"@\" \"gmail\" \".com\"" . "")))
