;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "maccalfw" "0.1.0.20251104.105"
  "Calendar view for Mac Calendars."
  '((emacs     "29.1")
    (calfw     "2.0")
    (ical-form "0.2"))
  :url "https://github.com/haji-ali/maccalfw"
  :commit "0a72897c02537948aecc6a65b30c91466c8adaa8"
  :revdesc "0a72897c0253"
  :keywords '("calendar")
  :authors '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
