;;; daselt-eieio.el --- EIEIO data structures for Daselt -*- lexical-binding: t; -*-

;; Copyright (C) 2025  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Keywords: tools
;; URL: https://gitlab.com/nameiwillforget/d-emacs/

;; This file is part of Daselt.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; This file defines EIEIO classes for Daselt's core data structures.
;; These classes replace the ad-hoc list-based data structures with
;; proper object-oriented abstractions.

;; The main classes are:

;; - `daselt-coords' — a keyboard coordinate (layer, row, column)
;; - `daselt-placeval' — a coordinate-value pair
;; - `daselt-layer' — a layer of key bindings (a grid of placevals)
;; - `daselt-layout' — a full keyboard layout (multiple layers)
;; - `daselt-binding' — a single key binding (key spec → value)
;; - `daselt-bindlist' — a list of bindings for a keymap

;;; Code:

(require 'eieio)
(require 'eieio-base)
(require 'cl-lib)
(require 'seq)
(require 'daselt-base)


;;;; Coordinates

(defclass daselt-coords ()
  ((layer :initarg :layer
          :initform 0
          :type (or null integer)
          :documentation "Layer number (0-based).")
   (row :initarg :row
        :initform 0
        :type (or null integer)
        :documentation "Row number.")
   (col :initarg :col
        :initform 0
        :type (or null number)
        :documentation "Column number (can be fractional for midpoints."))
  (:documentation "A keyboard coordinate in Daselt's coordinate system.

A coordinate consists of a layer, row, and column.  The layer
identifies which keyboard layer the key is on (0 = base, 1 =
first shifted layer, etc.).  Row and column locate the key within
the layer's grid."))

(defun daselt-eieio-coords-p (obj)
  "Return non-nil if OBJ is a `daselt-coords' object or a coordinate list."
  (or (and (eieio-object-p obj) (object-of-class-p obj 'daselt-coords))
      (and (listp obj)
           (<= 2 (length obj))
           (cl-every (lambda (x) (or (numberp x) (null x))) obj))))

(cl-defmethod daselt-eieio-coords-to-list ((c daselt-coords))
  "Convert `daselt-coords' object C to a list (LAYER ROW COL)."
  (list (oref c layer) (oref c row) (oref c col)))

(cl-defgeneric daselt-eieio-coords-from-list (lst)
  "Create a `daselt-coords' object from list LST.")

(cl-defmethod daselt-eieio-coords-from-list ((lst list))
  "Create a `daselt-coords' object from list LST."
  (when (and lst (<= 2 (length lst)))
    (daselt-coords :layer (nth 0 lst)
                   :row (nth 1 lst)
                   :col (nth 2 lst))))


;;;; Placeval

(defclass daselt-placeval ()
  ((coords :initarg :coords
           :initform nil
           :documentation "Coordinate list or `daselt-coords' object.")
   (value :initarg :value
          :initform nil
          :documentation "The value bound at these coordinates."))
  (:documentation "A coordinate-value pair, used in layout layers."))

(cl-defmethod daselt-eieio-placeval-to-cons ((pv daselt-placeval))
  "Convert placeval PV to a cons (COORDS . VALUE)."
  (let ((c (oref pv coords)))
    (cons (if (and (eieio-object-p c) (object-of-class-p c 'daselt-coords))
              (daselt-eieio-coords-to-list c)
            c)
          (oref pv value))))

(cl-defgeneric daselt-eieio-placeval-from-cons (cons)
  "Create a `daselt-placeval' from a cons cell CONS.")

(cl-defmethod daselt-eieio-placeval-from-cons ((c cons))
  "Create a `daselt-placeval' from cons cell C."
  (daselt-placeval :coords (car c) :value (cdr c)))


;;;; Layer

(defclass daselt-layer ()
  ((number :initarg :number
           :initform 0
           :type integer
           :documentation "Layer number (0-based).")
   (rows :initarg :rows
         :initform nil
         :type list
         :documentation "List of rows, each row is a list of values (strings or nil)."))
  (:documentation "A layer in a keyboard layout.

A layer consists of a layer number and a grid of values (key
bindings).  Each row is a list of strings or nil, where each
string is the signal produced by pressing that key."))

(cl-defmethod daselt-eieio-layer-get-row ((layer daselt-layer) rownum)
  "Return row ROWNUM from LAYER, or nil if out of bounds."
  (nth rownum (oref layer rows)))

(cl-defmethod daselt-eieio-layer-set-row ((layer daselt-layer) rownum values)
  "Set row ROWNUM in LAYER to VALUES."
  (let ((rows (copy-tree (oref layer rows))))
    (while (<= (length rows) rownum)
      (setq rows (append rows (list nil))))
    (setcar (nthcdr rownum rows) values)
    (oset layer rows rows)))

(cl-defmethod daselt-eieio-layer-get-binding ((layer daselt-layer) row col)
  "Return the binding at ROW, COL in LAYER."
  (let ((rowdata (daselt-eieio-layer-get-row layer row)))
    (and rowdata
         (<= 0 col)
         (< col (length rowdata))
         (nth col rowdata))))


;;;; Layout

(defclass daselt-layout ()
  ((name :initarg :name
         :initform nil
         :type (or null string)
         :documentation "Name of the layout.")
   (layers :initarg :layers
           :initform nil
           :type list
           :documentation "List of `daselt-layer' objects."))
  (:documentation "A keyboard layout consisting of multiple layers."))

(cl-defmethod daselt-eieio-layout-get-layer ((layout daselt-layout) laynum)
  "Return the layer numbered LAYNUM from LAYOUT."
  (seq-find (lambda (layer)
              (= (oref layer number) laynum))
            (oref layout layers)))

(cl-defmethod daselt-eieio-layout-add-layer ((layout daselt-layout) layer)
  "Add LAYER to LAYOUT, replacing any existing layer with the same number."
  (let* ((existing (daselt-eieio-layout-get-layer layout (oref layer number)))
         (layers (if existing
                     (mapcar (lambda (l)
                               (if (= (oref l number) (oref layer number))
                                   layer
                                 l))
                             (oref layout layers))
                   (append (oref layout layers) (list layer)))))
    (oset layout layers layers)
    layout))


;;;; Binding

(defclass daselt-binding ()
  ((prefix :initarg :prefix
           :initform nil
           :type (or null string)
           :documentation "Modifier prefix string (e.g. \"C-M-\").")
   (suffix :initarg :suffix
           :initform nil
           :type (or null string)
           :documentation "Key suffix string (e.g. \"a\", \"<return>\").")
   (coords :initarg :coords
           :initform nil
           :type (or null list daselt-coords)
           :documentation "Coordinates matching this binding's key, or nil if unmatched.")
   (value :initarg :value
          :initform nil
          :documentation "The value bound to this key."))
  (:documentation "A single key binding in Daselt.

A binding associates a key location (described by prefix + suffix
and/or coordinates) with a value (usually a command symbol or
keymap)."))

(defun daselt-eieio-binding-p (obj)
  "Return non-nil if OBJ is a `daselt-binding' object."
  (object-of-class-p obj 'daselt-binding))

(cl-defmethod daselt-eieio-binding-to-cons ((b daselt-binding))
  "Convert binding B to a cons cell (LOCATION . VALUE).

LOCATION is the most specific available form: if coordinates
exist, a prefix-coords cons; otherwise a prefix-suffix cons; or
just a suffix string."
  (let ((prefix (oref b prefix))
        (suffix (oref b suffix))
        (coords (oref b coords))
        (value (oref b value)))
    (cond
     ;; Elaborate form: both prefix-suffix and coords
     ((and prefix suffix coords)
      (cons (cons (cons prefix suffix) coords) value))
     ;; Prefix-coords form
     ((and prefix coords (not suffix))
      (cons (cons prefix coords) value))
     ;; Prefix-suffix form
     ((and prefix suffix (not coords))
      (cons (cons prefix suffix) value))
     ;; Coords-only form
     ((and coords (not prefix) (not suffix))
      (cons coords value))
     ;; Suffix-only form
     ((and suffix (not prefix) (not coords))
      (cons suffix value))
     ;; Fallback
     (t (cons suffix value)))))


;;;; Bindlist

(defclass daselt-bindlist ()
  ((keymap-name :initarg :keymap-name
                :initform nil
                :type (or null symbol string)
                :documentation "Symbol naming the keymap these bindings target.")
   (eval-condition :initarg :eval-condition
                   :initform nil
                   :type (or null symbol string)
                   :documentation "Condition for deferred evaluation (for `with-eval-after-load').")
   (bindings :initarg :bindings
             :initform nil
             :type list
             :documentation "List of `daselt-binding' objects or raw cons cells."))
  (:documentation "A list of key bindings targeting a specific keymap.

A bindlist groups bindings together and optionally specifies which
keymap they should be applied to and under what evaluation
condition."))

(defun daselt-eieio-bindlist-p (obj)
  "Return non-nil if OBJ is a `daselt-bindlist' object."
  (and (eieio-object-p obj) (object-of-class-p obj 'daselt-bindlist)))

(cl-defmethod daselt-eieio-bindlist-add-binding ((bl daselt-bindlist) binding)
  "Add BINDING to bindlist BL."
  (oset bl bindings (append (oref bl bindings) (list binding)))
  bl)

(cl-defmethod daselt-eieio-bindlist-length ((bl daselt-bindlist))
  "Return the number of bindings in BL."
  (length (oref bl bindings)))


;;;; Persistent bindlist (for `.deio' files)
;;
;; A persistent bindlist wraps the raw s-expression form of a
;; `.dbl' file in an EIEIO object so that it can be saved to
;; disk, reloaded, and dispatched on by class.  The whole
;; original s-expression is stored verbatim in the `form' slot so
;; that round-trip conversion with `.dbl' is byte-for-byte
;; lossless; parsed views (head / body) are exposed by methods
;; that delegate to `daselt-bind' once that module is loaded.

(defclass daselt-persistent-bindlist ()
  ((form :initarg :form
         :initform nil
         :documentation "Original bindlist s-expression (e.g. `(map bind bind...)').")
   (source-file :initarg :source-file
                :initform nil
                :type (or null string)
                :documentation "Path of the `.dbl' file this object was derived from."))
  (:documentation "Persistent EIEIO bindlist, the `.deio' counterpart of a `.dbl' file.

The `form' slot holds the original bindlist s-expression
unchanged so that conversion to and from `.dbl' is lossless.
The `head' and `bindings' accessors are available as
`daselt-eieio-persistent-bindlist-head' /
`-bindings' once `daselt-bind' is loaded."))

(defun daselt-eieio-persistent-bindlist-p (obj)
  "Return non-nil if OBJ is a `daselt-persistent-bindlist' object."
  (and (eieio-object-p obj)
       (object-of-class-p obj 'daselt-persistent-bindlist)))

(defun daselt-eieio-persistent-bindlist-from-sexp (sexp &optional source-file)
  "Build a `daselt-persistent-bindlist' from the bindlist s-expression SEXP.

SOURCE-FILE, if given, is stored in the `source-file' slot for
provenance tracking.  The conversion is lossless."
  (declare (ftype (function (t &optional (or null string)) daselt-persistent-bindlist)))
  (daselt-persistent-bindlist :form sexp :source-file source-file))

(cl-defmethod daselt-eieio-object-to-sexp ((obj daselt-persistent-bindlist))
  "Return the original bindlist s-expression stored in OBJ."
  (oref obj form))

(cl-defmethod daselt-eieio-persistent-bindlist-head ((bl daselt-persistent-bindlist))
  "Return the head of BL's bindlist, delegating to `daselt-bind-head'.
Returns nil if `daselt-bind-head' is not yet loaded."
  (let ((form (oref bl form)))
    (and (fboundp 'daselt-bind-head)
         (daselt-bind-head form))))

(defun daselt-eieio-persistent-bindlist-special-p (obj)
  "Return non-nil if OBJ looks like a \"special\" bindlist.

Mirrors the heuristic used by the file-name dispatcher: a
bindlist is special when its `source-file' contains the
substring \"special\"."
  (declare (ftype (function (daselt-persistent-bindlist) boolean)))
  (let ((src (oref obj source-file)))
    (or (and (stringp src) (string-match-p "special" src))
        ;; Fall back to the form's keymap-name for objects built in memory.
        (let ((form (oref obj form)))
          (and (consp form)
               (let ((head (car form)))
                 (and (symbolp head)
                      (string-match-p "special" (symbol-name head)))))))))


;;;; Persistent constantlist (for `.dclo' files)
;;
;; A constantlist is the EIEIO counterpart of a `.dcl' file.  As
;; with bindlists we store the whole s-expression verbatim.

(defclass daselt-persistent-constantlist ()
  ((form :initarg :form
         :initform nil
         :documentation "Original constantlist s-expression (alist with optional head).")
   (source-file :initarg :source-file
                :initform nil
                :type (or null string)
                :documentation "Path of the `.dcl' file this object was derived from."))
  (:documentation "Persistent EIEIO constantlist, the `.dclo' counterpart of a `.dcl' file."))

(defun daselt-eieio-persistent-constantlist-p (obj)
  "Return non-nil if OBJ is a `daselt-persistent-constantlist' object."
  (and (eieio-object-p obj)
       (object-of-class-p obj 'daselt-persistent-constantlist)))

(defun daselt-eieio-persistent-constantlist-from-sexp (sexp &optional source-file)
  "Build a `daselt-persistent-constantlist' from the `.dcl' sexp SEXP.

SOURCE-FILE, if given, is stored in the `source-file' slot for
provenance tracking."
  (declare (ftype (function (t &optional (or null string))
                            daselt-persistent-constantlist)))
  (daselt-persistent-constantlist :form sexp :source-file source-file))

(cl-defmethod daselt-eieio-object-to-sexp ((obj daselt-persistent-constantlist))
  "Return the original constantlist s-expression stored in OBJ."
  (oref obj form))


;;;; Predicate fixups
;;
;; `defclass' automatically defines a `<class>-p' class predicate,
;; and the class `daselt-coords' therefore defines a `daselt-coords-p'
;; that would clobber the list predicate of the same name from
;; `daselt-coords.el' (or vice versa) depending on load order.  This
;; bit us when an old installed Daselt package provided the old
;; `daselt-coords' while the new `daselt-eieio' was loaded over it:
;; afterwards `daselt-coords-p' only accepted objects and plain
;; coordinate lists like (2 3) were rejected ("Expected a
;; daselt-dfk-datum").  Restore the combined meaning here, after
;; all classes, so both load orders agree.

;; The compiler counts the defclass-generated predicate as the
;; first definition; the redefinition here is the point, so use
;; `fset' to avoid the redefinition warning.
(fset 'daselt-coords-p
      (lambda (obj)
        "Return non-nil if OBJ is a `daselt-coords' object or a coordinate list.
A coordinate list is a proper list of numbers."
        (or (and (eieio-object-p obj)
                 (object-of-class-p obj 'daselt-coords))
            (and (proper-list-p obj)
                 (daselt-base-forall-p obj #'numberp)))))


;;;; Object file readers, writers, and dispatch helpers
;;
;; On-disk format of a `.deio' / `.dclo' file:
;;
;;     ;;; <basename>.deio --- EIEIO bindlist object  -*- lexical-binding: t; -*-
;;     ;; Generated from <basename>.dbl by `daselt-eieio-write-object-file'.
;;     (daselt-persistent-bindlist
;;       :form (daselt-mode-map
;;              ((7 -1 -1) . (if daselt-icicles #'beginning-of-line+ ...))
;;              ...)
;;       :source-file "/path/to/original.dbl")
;;
;; A file may contain several top-level object forms; each one is
;; read and processed in turn (mirroring the multi-sexp behaviour
;; of `daselt-dirs-act-on-sexps-in-file').

(defun daselt-eieio-extension-for-class (class)
  "Return the file extension (without dot) for EIEIO object class CLASS."
  (declare (ftype (function (symbol) string)))
  (pcase class
    ('daselt-persistent-bindlist "deio")
    ('daselt-persistent-constantlist "dclo")
    (_ (error "Unknown EIEIO object class: %S" class))))

(defun daselt-eieio-class-for-extension (ext)
  "Return the EIEIO object class symbol for file extension EXT (no dot)."
  (declare (ftype (function (string) symbol)))
  (pcase ext
    ("deio" 'daselt-persistent-bindlist)
    ("dclo" 'daselt-persistent-constantlist)
    (_ (error "Unknown EIEIO file extension: %S" ext))))

(defun daselt-eieio-object-extension-p (filename)
  "Return non-nil if FILENAME has a Daselt EIEIO extension (`.deio' or `.dclo')."
  (declare (ftype (function (string) boolean))
           (pure t))
  (member (file-name-extension filename) '("deio" "dclo")))

(cl-defgeneric daselt-eieio-object-to-sexp (obj)
  "Return the canonical `.dbl'/`.dcl' s-expression for EIEIO object OBJ.")

(defun daselt-eieio-write-object-file (filename object &optional comment-source)
  "Write OBJECT to FILENAME as an EIEIO object file.

OBJECT is a `daselt-persistent-bindlist' or
`daselt-persistent-constantlist'.  The on-disk format is a single
`read'-able form: `(CLASS-SYMBOL :slot value :slot value ...)'.

COMMENT-SOURCE, when non-nil, is the original source path used in
the `generated-from' comment for provenance."
  (declare (ftype (function (string (or daselt-persistent-bindlist
                                        daselt-persistent-constantlist)
                                     &optional (or null string))
                            nil)))
  (let* ((class-sym (eieio-object-class object))
         (kind-string
          (pcase class-sym
            ('daselt-persistent-bindlist "bindlist")
            ('daselt-persistent-constantlist "constantlist")
            (_ "daselt")))
         (header-line
          (format ";;; %s --- EIEIO %s object  -*- lexical-binding: t; -*-"
                  (file-name-nondirectory filename)
                  kind-string))
         (provenance-line
          (if comment-source
              (format ";; Generated from %s by `daselt-eieio-write-object-file'."
                      comment-source)
            ";; Generated by `daselt-eieio-write-object-file'."))
         (form (daselt-eieio--object-to-initargs-form object)))
    (with-temp-file filename
      (insert header-line "\n\n")
      (insert provenance-line "\n")
      (insert ";; Edit the original `.dbl'/`.dcl' file and re-run the\n"
              ";; converter if you need to change this object.\n\n")
      (insert (pp-to-string form) "\n")
      (insert ";;; " (file-name-nondirectory filename) " ends here\n"))
    (daselt-eieio-extension-for-class class-sym)))

(defun daselt-eieio--object-to-initargs-form (object)
  "Build a `(CLASS :slot value ...)' form for OBJECT suitable for `read'."
  (declare (ftype (function ((or daselt-persistent-bindlist
                                 daselt-persistent-constantlist)) cons)))
  (let ((class-sym (eieio-object-class object)))
    (cons class-sym
          (cl-mapcan
           (lambda (slot)
             (list (intern (format ":%s" slot))
                   (slot-value object slot)))
           ;; Hard-coded slot lists for our two persistent classes; this
           ;; is simpler and more portable than walking
           ;; `eieio-class-slots' descriptors across Emacs versions.
           (pcase class-sym
             ('daselt-persistent-bindlist '(form source-file))
             ('daselt-persistent-constantlist '(form source-file))
             (_ (error "Unsupported EIEIO class in writer: %S" class-sym)))))))

(defun daselt-eieio-read-objects-from-file (filename)
  "Read all top-level EIEIO object forms from FILENAME.

Return a list of `daselt-persistent-bindlist' and/or
`daselt-persistent-constantlist' objects, in file order."
  (declare (ftype (function (string) list)))
  (with-current-buffer (find-file-noselect filename)
    (unwind-protect
        (save-excursion
          (goto-char (point-min))
          (let (objects)
            (condition-case nil
                (while t
                  (skip-chars-forward " \t\r\n")
                  ;; Skip leading line / sexp comments.
                  (when (eq (char-after) ?\;)
                    (forward-comment 1))
                  (skip-chars-forward " \t\r\n")
                  (when (eobp) (signal 'end-of-file nil))
                  (let ((form (read (current-buffer))))
                    (push (daselt-eieio--initargs-form-to-object form filename)
                          objects)))
              (end-of-file))
            (nreverse objects)))
      (unless (bound-and-true-p daselt-dirs-keep-read-buffers)
        (kill-buffer (current-buffer))))))

(defun daselt-eieio--initargs-form-to-object (form source-file)
  "Instantiate an EIEIO object from the `read'-able initargs FORM.

SOURCE-FILE is stored on the object for provenance if FORM does
not already specify a `:source-file'."
  (declare (ftype (function (cons (or null string))
                            (or daselt-persistent-bindlist
                                daselt-persistent-constantlist))))
  (unless (and (consp form) (symbolp (car form)))
    (error "Malformed EIEIO object form: %S" form))
  (let* ((class-sym (car form))
         (args (cdr form))
         ;; Make sure source-file is set even on older files.
         (args (if (or (plist-member args :source-file)
                       (not source-file))
                   args
                 (append args (list :source-file source-file)))))
    (apply class-sym args)))


;;;; Daselt Configuration (for caching)

(defclass daselt-config ()
  ((name :initarg :name
         :initform nil
         :type (or null string)
         :documentation "Name for this configuration.")
   (xkb-layout :initarg :xkb-layout
               :initform nil
               :type (or null symbol)
               :documentation "The active xkb layout symbol.")
   (dfk-layout :initarg :dfk-layout
               :initform nil
               :type (or null daselt-layout)
               :documentation "The active dfk layout object.")
   (keyboard-layout-type :initarg :keyboard-layout-type
                         :initform "iso"
                         :type (or null string)
                         :documentation "Keyboard type: \"ansi\" or \"iso\".")
   (outside-mods :initarg :outside-mods
                 :initform nil
                 :type boolean
                 :documentation "Whether modifiers are placed outside the key layout.")
   (translate-keys :initarg :translate-keys
                   :initform t
                   :type boolean
                   :documentation "Whether key translations are active.")
   (bindlists :initarg :bindlists
              :initform nil
              :type list
              :documentation "List of saved bindlist objects.")
   (key-translations :initarg :key-translations
                     :initform nil
                     :type list
                     :documentation "Key translation alist.")
   (boundaries :initarg :boundaries
               :initform nil
               :type list
               :documentation "Layout boundaries for drawing."))
  (:documentation "A complete Daselt configuration, used for caching.

This object captures all the state needed to restore a Daselt
session: the active layouts, keyboard type, translations, and
saved bindlists."))


;;;; Provide
(provide 'daselt-eieio)
;;; daselt-eieio.el ends here
