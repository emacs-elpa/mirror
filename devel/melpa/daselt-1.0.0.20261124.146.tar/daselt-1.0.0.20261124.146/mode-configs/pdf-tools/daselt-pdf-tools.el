;;; daselt-pdf-tools.el -- daselt-commands for pdf-tools  -*- lexical-binding: t; -*-

;; Copyright (C) 2024, 2025  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Package-Requires: ((emacs "29.1"))
;; Version: 1.0
;; Keywords: tools
;; URL: https://gitlab.com/nameiwillforget/d-emacs/daselt-mode/

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;;

;;; Code:

;; Bindlist variables created by applying the `pdf-tools' bindlists.

(declare-function pdf-view-next-line-or-next-page "pdf-view")
(declare-function pdf-view-previous-line-or-previous-page "pdf-view")
(defvar daselt-pdf-history-minor-mode-map-bindlist nil)
(defvar daselt-pdf-isearch-active-mode-map-bindlist nil)


(defun daselt-pdf-view-scroll-chunk-up ()
  "Scroll up a chunk when reading a pdf."
  (interactive)
  (pdf-view-previous-line-or-previous-page 10))

(defun daselt-pdf-view-scroll-chunk-down ()
  "Scroll down a chunk when reading a pdf."
  (interactive)
  (pdf-view-next-line-or-next-page 10))

(defun daselt-pdf-view-apply-bindlists ()
  "Apply `daselt-pdf-history-minor-mode-map-bindlist'."
  (declare (ftype (function () t)))
  (daselt-bind-apply-bindlist daselt-pdf-history-minor-mode-map-bindlist)
  (daselt-bind-apply-bindlist daselt-pdf-isearch-active-mode-map-bindlist))

(provide 'daselt-pdf-tools)
;;; daselt-pdf-tools.el ends here
