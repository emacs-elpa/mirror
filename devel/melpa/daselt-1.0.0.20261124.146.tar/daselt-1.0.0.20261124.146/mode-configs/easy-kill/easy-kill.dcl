((easy-kill-alist
  . (car (daselt-base-act-on-sexps-in-file
          (concat daselt-mode-pkg-configs-directory
                  "easy-kill/easy-kill-special-alist.dbl")
          (lambda ()
            (let ((blist (daselt-base-read-region)))
              (mapcar (lambda (binding)
                        (cons (string-to-char (daselt-bind-string binding))
                              (cdr binding)))
                      blist)))))))
