;;; daselt-dired.el --- Daselt-code for Dired    -*- lexical-binding: t; -*-

;; Copyright (C) 2025  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Keywords: tools

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;;

;;; Code:

(defun daselt-dired-permanently-delete (&optional arg)
  "Permanently delete files with `dired-do-delete'."
  (declare (ftype (function (&optional t) t)))
  (interactive "P")
  (let ((delete-by-moving-to-trash nil))
    (dired-do-delete arg)))

(defun daselt-dired-make-backup ()
  "Back up all marked files or the file under point if none are marked."
  (declare (ftype (function () string)))
  (interactive)
  (let ((files (dired-get-marked-files))
        (file-name (dired-file-name-at-point)))
    (if files
        (mapc #'daselt-backup-file files)
      (daselt-backup-file file-name)))
  (revert-buffer))


(provide 'daselt-dired)
;;; daselt-dired.el ends here

