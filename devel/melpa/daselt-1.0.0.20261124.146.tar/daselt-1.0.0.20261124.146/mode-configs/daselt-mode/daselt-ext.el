;;; daselt-ext.el --- Not required to start daselt-mode, but bound to keys etc.  -*- lexical-binding: t; -*-

;; Copyright (C) 2025  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Package-Requires: ((emacs "29.1"))
;; Version: 1.0
;; Keywords: tools
;; URL: https://gitlab.com/nameiwillforget/d-emacs/daselt-mode/
;; Keywords: tools

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; daselt functions bound to keys and adjecent stuff.

;;; Code:

;;;; Preamble
(require 'cl-lib)
(require 'checkdoc)
(require 'outline)

(declare-function tempo-expand-if-complete "tempo.el")
(declare-function daselt-bind-string "daselt-bind")
(declare-function abv-expand "abv")
(declare-function yas-expand "yasnippet")
(declare-function yas-maybe-expand-abbrev-key-filter "yasnippet")
(declare-function cdlatex--texmathp "cdlatex")
(declare-function vterm-yank "vterm")
(declare-function avy-act--follow-or-open "avy-act")
(declare-function Info-next "info")
(declare-function Info-prev "info")
(declare-function pdf-view-rotate "pdf-view")

;; This is only called if daselt-abbrev-chain is t
(declare-function abbrev-chain-with-syntax-table-and-combining-categories nil)
(defvar daselt-abv)
(defvar daselt-cdlatex)
(defvar daselt-yasnippet)
(defvar cdlatex-mode)
(defvar cdlatex-command-alist-comb)
(defvar daselt-special-read-answer-bindlist)
(defvar daselt-base-definition-types-list)

;;;; Constants
(defconst daselt-backward-command-list
  (remq nil `(sp-kill-hybrid-sexp sp-mark-sexp mark-sexp mark-defun transpose-paragraphs kill-paragraph transpose-sentences delete-char transpose-lines transpose-words transpose-sexps sp-down-sexp down-list transpose-chars other-frame sp-transpose-sexp sp-transpose-hybrid-sexp mark-line daselt-kill-defun delete-all-space delete-horizontal-space sp-up-sexp up-list pdf-view-rotate))
  "List of commands for which backward analogs are created.")

(defconst daselt-new-buffer-command-list
  '(Info-prev Info-next)
  "List of commands for which analogs are created that open a new buffer.")

(defconst daselt-subsentence-command-list
  (remq nil `(backward-sentence forward-sentence backward-kill-sentence kill-sentence ,(if (package-installed-p 'expand-region) 'er/mark-sentence) daselt-backward-transpose-sentences))
  "List of commands for which subsentence analogs are created in.")

(defconst daselt-backup-limit
  100
  "Number of backups `daselt-backup-file' should keep.")

;;;; Customs
(defcustom daselt-mode-tab-bar-status-functions
  '(tab-new tab-bar-new-tab)
  "Functions around which `daselt-mode-keep-tab-bar-status' should be
wrapped.

Only used if `daselt-mode-keep-tab-bar-status' is t."
  :type '(repeat function)
  :group 'daselt-mode)

;;;;; Contexts of contextual commands
(defcustom daselt-C-4-0-2-contexts-list
  '((minibuffer-mode . daselt--minibuffer-C-4-0-2-action)
    (abv-language-table-add-words-batch-mode
     . abv-language-table-add-words-batch-finish)
    (abv-vterm-compose-mode
     . (lambda () (abv-vterm-compose-commit current-prefix-arg)))
    (djvu-script-mode . djvu-view)
    (djvu-image-mode . image-forward-hscroll)
    (special-mode . daselt-follow-in-other-window)
    (LaTeX-mode . (lambda () (latex/forward-environment 1)))
    (vterm-mode . vterm-send-tab)
    (emacs-lisp-mode . sp-next-sexp)
    (org-mode . daselt--org-C-4-0-2-action)
    (gnus-article-mode . gnus-article-show-summary))
  "A list defining actions for `daselt-C-4-0-2' across different modes."
  :type '(repeat (cons symbol sexp))
  :group 'daselt-mode)

(defcustom daselt-C-1-0-2-contexts-list
  '((undo-tree-visualizer-mode . undo-tree-visualize-switch-branch-right)
    (rectangle-mark-mode . (lambda () (rectangle-forward-char 1)))
    (minibuffer-mode . daselt-move-right-or-exit)
    (image-mode . (lambda () (image-forward-hscroll 1)))
    (pdf-view-mode . (lambda () (image-forward-hscroll 1)))
    (vterm-mode . vterm-send-right))
  "Actions for `daselt-C-1-0-2' in different modes."
  :type '(repeat (cons symbol sexp))
  :group 'daselt-mode)

(defcustom daselt-C-1-0--2-contexts-list
  '((undo-tree-visualizer-mode . undo-tree-visualize-switch-branch-left)
    (rectangle-mark-mode . (lambda () (rectangle-backward-char 1)))
    (image-mode . (lambda () (image-backward-hscroll 1)))
    (pdf-view-mode . (lambda () (image-backward-hscroll 1)))
    (vterm-mode . vterm-send-left))
  "Actions for `daselt-C-1-0--2' in different modes."
  :type '(repeat (cons symbol sexp))
  :group 'daselt-mode)

(defcustom daselt-C-1-0--3-contexts-list
  '((undo-tree-visualizer-mode . undo-tree-visualize-undo)
    (vterm-copy-mode . previous-line)
    (vterm-mode . vterm-send-up)
    (minibuffer-mode . previous-line-or-history-element)
    (rectangle-mark-mode . (lambda () (rectangle-previous-line 1)))
    (pdf-view-mode . (lambda () (pdf-view-previous-line-or-previous-page 1)))
    (image-mode . image-previous-line)
    (eshell-hist-mode . eshell-previous-input))
  "Actions for `daselt-C-1-0--3' across different modes."
  :type '(repeat (cons symbol sexp))
  :group 'daselt-mode)

(defcustom daselt-C-1-0-3-contexts-list
  '((undo-tree-visualizer-mode . undo-tree-visualize-redo)
    (vterm-copy-mode . next-line)
    (vterm-mode . vterm-send-down)
    (minibuffer-mode . next-line-or-history-element)
    (rectangle-mark-mode . (lambda () (rectangle-next-line 1)))
    (pdf-view-mode . (lambda () (pdf-view-scroll-up-or-next-page 1)))
    (image-mode . image-next-line)
    (eshell-hist-mode . eshell-next-input))
  "Actions for `daselt-C-1-0-3' across different modes."
  :type '(repeat (cons symbol sexp))
  :group 'daselt-mode)

(defcustom daselt-C-1-0--4-contexts-list
  '((pdf-view-mode . pdf-view-previous-page-command)
    (minibuffer-mode . previous-line-or-history-element)
    (image-mode . image-previous-frame)
    (vterm-copy-mode . scroll-down-command)
    (vterm-mode . vterm-send-prior))
  "Actions for `daselt-C-1-0--4' across different modes."
  :type '(repeat (cons symbol sexp))
  :group 'daselt-mode)

(defcustom daselt-C-1-0-4-contexts-list
  '((pdf-view-mode . pdf-view-next-page-command)
    (minibuffer-mode . next-line-or-history-element)
    (image-mode . image-next-frame)
    (vterm-copy-mode . scroll-up-command)
    (vterm-mode . vterm-send-next))
  "Actions for `daselt-C-1-0-4' across different modes."
  :type '(repeat (cons symbol sexp))
  :group 'daselt-mode)

;;;; Functions
;;;;; Context dispatch
(defun daselt--funcall-first-mode-match (alist &optional default)
  "Invoke the function associated with the first active mode in ALIST.

The mode can be a major or minor mode.  If no match is found, DEFAULT
is called instead."
  (declare (ftype (function ((list (cons symbol function))
                             &optional function)
                            t)))
  (let ((cmd (cl-loop for (mmode . mcmd) in alist
                      if (or (and (boundp mmode)
                                  (memq mmode minor-mode-list)
                                  (symbol-value mmode))
                             (derived-mode-p mmode))
                      return mcmd
                      finally return default)))
    (funcall-interactively cmd)))

(defun daselt--minibuffer-C-4-0-2-action ()
  "Perform the minibuffer action for `daselt-C-4-0-2'.

Run the command the minibuffer's local map binds to the invoking key,
so that maps like `vertico-map' and `minibuffer-local-isearch-map' keep
their binding below `daselt-mode-map'.  Without one, call
`minibuffer-complete-and-exit'."
  (let ((cmd (lookup-key (current-local-map) (this-command-keys-vector))))
    (call-interactively
     (if (commandp cmd) cmd #'minibuffer-complete-and-exit))))

(defun daselt--org-C-4-0-2-action ()
  "Perform the Org mode action for `daselt-C-4-0-2'.

If at a footnote reference, invoke `org-footnote-action'.
If at an item, try `org-open-at-point-functions'; on failure,
use `org-element-lineage' to determine context and open or go to
next item as appropriate.  Otherwise call `org-open-at-point-global'."
  (cond
   ((org-footnote-at-reference-p)
    (org-footnote-action))
   ((org-at-item-p)
    (unless (run-hook-with-args-until-success
             'org-open-at-point-functions)
      (let* ((context
              (org-element-lineage
               (org-element-context)
               '(citation citation-reference clock comment
                          comment-block footnote-definition footnote-reference
                          headline inline-src-block inlinetask keyword link
                          node-property planning src-block timestamp)
               t))
             (type (org-element-type context)))
        (if type
            (org-open-at-point)
          (org-next-item)))))
   (t
    (org-open-at-point-global))))

;;;;; Advice functions
;;;;;; Read functions
(defun daselt--read-answer-key-alist ()
  "Map the default answer characters to their Daselt replacements.

The pairs are taken from `daselt-special-read-answer-bindlist'."
  (mapcar (lambda (bind)
            (cons (cdr bind)
                  (string-to-char (daselt-bind-string bind))))
          daselt-special-read-answer-bindlist))

(defun daselt--translate-read-multiple-choice
    (fun prompt choices &optional help-string show-help long-form original)
  "Unless ORIGINAL is t, replace short-choices in `read-multiple-choice'.

Replacements are specified in `daselt-special-read-answer-bindlist'.
To be wrapped around `read-multiple-choice'."
  (declare (ftype (function (function string list &optional string
                                      boolean boolean boolean)
                            t)))
  (if original
      (funcall fun prompt choices help-string show-help long-form)
    (let* ((keylst (daselt--read-answer-key-alist))
           (newchoices (mapcar (lambda (choice)
                                 (let* ((choicekey (car choice))
                                        (newkey (alist-get choicekey keylst
                                                           choicekey)))
                                   (cons newkey (cdr choice))))
                               choices))
           (choicereturn (funcall fun prompt newchoices
                                  help-string show-help long-form))
           (carret (car choicereturn))
           (transcarret (daselt-base-reverse-alist-get
                         carret keylst carret)))
      (cons transcarret (cdr choicereturn)))))

(defun daselt--translate-read-answer (fun question answers)
  "Replace short answers in `read-answer'-input with Daselt values.

These are specified in `daselt-special-read-answer-bindlist'.  Wraps around
`read-answer'."
  (let* ((keylst (daselt--read-answer-key-alist))
         (newans (mapcar (lambda (answer)
                           (let ((repl (alist-get (cadr answer) keylst)))
                             (list (car answer)
                                   (or repl (cadr answer))
                                   (caddr answer))))
                         answers)))
    (funcall fun question newans)))

(defun daselt--translate-read-char-choice
    (fun prompt chars &optional inhibit-keyboard-quit)
  "Replace characters in `read-char-choice' with Daselt values.

These are specified in `daselt-special-read-answer-bindlist'.
Wraps around `read-char-choice'."
  (declare (ftype (function (function string list &optional boolean) t)))
  (let* ((keylst (daselt--read-answer-key-alist))
         (trans (mapcar (lambda (char)
                          (alist-get char keylst char nil #'=))
                        chars))
         (answer (funcall fun prompt trans inhibit-keyboard-quit)))
    (daselt-base-reverse-alist-get answer keylst answer #'=)))

;;;;;; rx-functions
(defun daselt-mode-read-rx (fun rx &rest args)
  "Read an rx-form RX and pass forward the generated regexp.

To be wrapped around regexp-search and replace forms FUN.

Theoretically, you can put in any Lisp form that evaluates to a
regexp, but the default is `rx'."
  (apply fun (eval rx) args))

;;;;;; Tab-bar
(defun daselt-mode-keep-tab-bar-status (command &optional _dummy)
  "Preserve the tab-bar status while executing COMMAND.

If `tab-bar-mode' is off, it remains off after executing COMMAND."
  (let ((status (if tab-bar-mode 1 0)))
    (tab-bar-mode 1)
    (call-interactively command)
    (tab-bar-mode status)))

;;;;;; Replace hardcoded keybinds
(defun daselt-checkdoc-interactive-loop (start-here showstatus findfunc)
  "`checkdoc-interactive-loop' customized to include Daselt shortcuts.

See the primary command for documentation."
  (let* ((begin (prog1 (point)
                  (unless start-here (goto-char (point-min)))))
         (checkdoc-spellcheck-documentation-flag
          (car (memq checkdoc-spellcheck-documentation-flag
                     '(buffer interactive t))))
         (err-list (let ((err (funcall findfunc nil)))
                     (and err (list err))))
         (cdo nil)
         (returnme nil)
         c
         (nextchar (string-to-char (daselt-coords-binding '(1 0 3))))
         (prevchar (string-to-char (daselt-coords-binding '(1 0 -3))))
         (quitchar (string-to-char (daselt-coords-binding '(1 1 -2))))
         (fixchar  (string-to-char (daselt-coords-binding '(1 0 2))))
         (inschar  (string-to-char (daselt-coords-binding '(1 0 -2))))
         (help-text
          (lambda (err)
            (concat
             "Checkdoc Keyboard Summary:\n"
             (unless (checkdoc-error-unfixable err)
               (concat
                (format "%c    - auto Fix this warning"
                        fixchar)
                " (if available.)\n"
                "         Very complex operations will still query.\n"))
             (format "%c      - Enter recursive Edit."
                     inschar)
             "  Press C-M-c to exit.\n"
             (format "%c - skip to the Next error.\n" nextchar)
             (format "%c - skip to the Previous error.\n" prevchar)
             (format "%c      - Quit checkdoc.\n" quitchar)
             "C-h    - Toggle this help buffer."))))
    (save-window-excursion
      (beginning-of-defun)
      (while err-list
        (goto-char (cdr (car err-list)))
        (setq cdo (if (stringp (car (car err-list)))
                      (save-excursion
                        (make-overlay (point)
                                      (progn (forward-sexp 1) (point))))
                    (make-overlay
                     (checkdoc-error-start (car (car err-list)))
                     (checkdoc-error-end (car (car err-list))))))
        (unwind-protect
            (progn
              (overlay-put cdo 'face 'highlight)
              (sit-for 0)
              (if (and (= (following-char) ?\")
                       (not (pos-visible-in-window-p
                             (save-excursion (forward-sexp 1) (point))
                             (selected-window))))
                  (let ((l (count-lines
                            (point)
                            (save-excursion (forward-sexp 1) (point)))))
                    (if (> l (window-height))
                        (recenter 1)
                      (recenter (/ (- (window-height) l) 2))))
                (recenter))
              (message "%s (C-h,%s%s)"
                       (checkdoc-error-text (car (car err-list)))
                       (if (checkdoc-error-unfixable (car (car err-list)))
                           ""
                         (concat (char-to-string fixchar) ","))
                       (mapconcat #'char-to-string
                                  (list nextchar prevchar
                                        quitchar inschar)
                                  ","))
              (save-excursion
                (goto-char (checkdoc-error-start (car (car err-list))))
                (unless (pos-visible-in-window-p)
                  (recenter (- (window-height) 2)))
                (setq c (read-event)))
              (unless (integerp c) (setq c ??))
              (cond
               ((eq c ?\C-g) (signal 'quit nil))
               ((eq c fixchar)
                (delete-overlay cdo)
                (setq cdo nil)
                (goto-char (cdr (car err-list)))
                (let ((checkdoc-autofix-flag 'automatic-then-never)
                      (fixed nil))
                  (funcall findfunc t)
                  (setq fixed (not (eq checkdoc-autofix-flag
                                       'automatic-then-never)))
                  (if (not fixed)
                      (progn
                        (message "A Fix was not available.")
                        (sit-for 2))
                    (setq err-list (cdr err-list))))
                (beginning-of-defun)
                (let ((ne (funcall findfunc nil)))
                  (if ne
                      (setq err-list (cons ne err-list))
                    (cond ((not err-list)
                           (message "No More Stylistic Errors.")
                           (sit-for 2))
                          (t
                           (message
                            "No Additional style errors.  Continuing...")
                           (sit-for 2))))))
               ((eq c nextchar)
                (let ((ne (funcall findfunc nil)))
                  (if (not ne)
                      (if showstatus
                          (setq returnme err-list
                                err-list nil)
                        (if (not err-list)
                            (message "No More Stylistic Errors.")
                          (message
                           "No Additional style errors.  Continuing..."))
                        (sit-for 2))
                    (setq err-list (cons ne err-list)))))
               ((eq c prevchar)
                (if (/= (length err-list) 1)
                    (progn
                      (setq err-list (cdr err-list))
                      (goto-char (cdr (car err-list)))
                      (beginning-of-defun))
                  (message "No Previous Errors.")
                  (sit-for 2)))
               ((eq c inschar)
                (checkdoc-recursive-edit
                 (checkdoc-error-text (car (car err-list))))
                (delete-overlay cdo)
                (setq err-list (cdr err-list))
                (beginning-of-defun)
                (let ((ne (funcall findfunc nil)))
                  (if (not ne)
                      (if showstatus
                          (setq returnme err-list
                                err-list nil)
                        (message "No More Stylistic Errors.")
                        (sit-for 2))
                    (setq err-list (cons ne err-list)))))
               ((eq c quitchar)
                (setq returnme err-list
                      err-list nil
                      begin (point)))
               (t
                (if (get-buffer-window checkdoc--help-buffer)
                    (progn
                      (delete-window
                       (get-buffer-window checkdoc--help-buffer))
                      (kill-buffer checkdoc--help-buffer))
                  (with-output-to-temp-buffer checkdoc--help-buffer
                    (with-current-buffer standard-output
                      (insert (funcall help-text
                                       (car (car err-list))))))
                  (shrink-window-if-larger-than-buffer
                   (get-buffer-window checkdoc--help-buffer))))))
          (when cdo (delete-overlay cdo)))))
    (goto-char begin)
    (when (get-buffer checkdoc--help-buffer)
      (kill-buffer checkdoc--help-buffer))
    (message "Checkdoc: Done.")
    returnme))

;;;;; Drawing
(defun daselt-keymap-to-cons-list (keymap)
  "Convert the KEYMAP of key bindings into a list of conses.

Each cons cell has a string (converted for `kbd') as its car and the
binding value as its cdr."
  (let (result)
    (map-keymap
     (lambda (key binding)
       (when binding
         (let ((key-string (if (vectorp key)
                               (key-description key)
                             (format "%s" key))))
           (push (cons key-string binding) result))))
     keymap)
    (reverse result)))

;;;; Commands
;;;;; Modifiers
(defun daselt-MetaSuper-next-cmd ()
  "Apply Meta and Super modifiers to the next event."
  (interactive)
  (execute-kbd-macro
   (vector
    (event-apply-modifier
     (event-apply-modifier
      (read-event) 'super 23 "s-")
     'meta 27 "M-"))))

;;;;; General purpose
(defun daselt-rename-file-and-buffer (new-name)
  "Rename the current buffer and its visiting file to NEW-NAME.

Displays a message if the buffer isn't visiting a file or if another
buffer with NEW-NAME already exists."
  (interactive "sNew name: ")
  (let ((name (buffer-name))
        (filename (buffer-file-name)))
    (cond
     ((not filename)
      (message "Buffer '%s' is not visiting a file!" name))
     ((get-buffer new-name)
      (message "A buffer named '%s' already exists!" new-name))
     (t
      (rename-file filename new-name 1)
      (rename-buffer new-name)
      (set-visited-file-name new-name)
      (set-buffer-modified-p nil)))))

(defun daselt-set-test-fun ()
  "Evaluate the current defun and define `daselt-test' as an alias to it."
  (interactive)
  (let ((fun (call-interactively #'eval-defun)))
    (defalias 'daselt-test fun)))

(defun daselt-copy-buffer-name ()
  "Copy the current buffer's name to the kill ring."
  (interactive)
  (let ((buffer-name (buffer-name)))
    (kill-new buffer-name)
    (message "Copied buffer name: %s" buffer-name)))

;;;;; Navigation
(defun daselt-scroll-chunk-up ()
  "Scroll up by a fixed chunk."
  (interactive)
  (scroll-up-command 10))

(defun daselt-scroll-chunk-down ()
  "Scroll down by a fixed chunk."
  (interactive)
  (scroll-down-command 10))

(defun daselt-outline-forward-up-heading (arg &optional invisible-ok)
  "Move forward to a visible heading on a higher level.

Move up ARG levels; if INVISIBLE-OK is non-nil, consider invisible
lines."
  (interactive "p")
  (and (eq this-command 'outline-up-heading)
       (or (eq last-command 'outline-up-heading) (push-mark)))
  (outline-back-to-heading invisible-ok)
  (let ((start-level (funcall outline-level)))
    (when (<= start-level 1)
      (error "Already at top level of the outline"))
    (while (and (> start-level 1) (> arg 0) (not (bobp)))
      (let ((level start-level))
        (while (not (or (< level start-level) (bobp)))
          (if invisible-ok
              (outline-next-heading)
            (outline-next-visible-heading 1))
          (setq level (funcall outline-level)))
        (setq start-level level))
      (setq arg (- arg 1))))
  (if outline-search-function
      (funcall outline-search-function nil nil t t)
    (looking-at outline-regexp)))

(defun daselt-switch-to-messages ()
  "Switch to messages buffer."
  (declare (ftype (function nil t)))
  (interactive)
  (switch-to-buffer "*Messages*"))

(defun daselt-follow-in-other-window ()
  "Follow or open link at point in another window."
  (interactive)
  (let ((new-buffer (clone-buffer))
        (current-point (point)))
    ;; (unless (one-window-p)
    ;;   (other-window 1))
    (switch-to-buffer-other-window new-buffer)
    (goto-char current-point)
    (avy-act--follow-or-open)))

;;;;; Context-specific behavior
(defun daselt-C-1-0-2 ()
  "Contextual command on `C-(1 0 2)'.

Mode-specific contexts can be edited by changing `daselt-C-1-0-2-contexts-list`.
Default behavior is to move cursor one character forward."
  (interactive)
  (daselt--funcall-first-mode-match daselt-C-1-0-2-contexts-list #'forward-char))

(defun daselt-C-1--1-0 ()
  "Like `back-button-local-backward' but interacts better with `daselt-C-4-0-2'."
  (declare (ftype (function nil t)))
  (interactive)
  (cl-letf (((symbol-function 'back-button-push-mark)
             (lambda ()
               (if (eq last-command #'daselt-C-4-0-2)
                   (set-marker (mark-marker) (point) (current-buffer))
                 (push-mark)))))
    (back-button-local-backward)))

(defun daselt-C-1-0--2 ()
  "Contextual command on `C-(1 0 -2)'.

Mode-specific contexts can be edited by changing
`daselt-C-1-0--2-contexts-list`. Default behavior is to move cursor one
character backward."
  (interactive)
  (daselt--funcall-first-mode-match daselt-C-1-0--2-contexts-list #'backward-char))

(defun daselt-C-1-0--3 ()
  "Contextual command on `C-(1 0 -3)'.

Mode-specific contexts can be edited by changing
`daselt-C-1-0--3-contexts-list'. Default behavior is to move cursor one line
up."
  (interactive)
  (daselt--funcall-first-mode-match daselt-C-1-0--3-contexts-list #'previous-line))

(defun daselt-C-1-0-3 ()
  "Contextual command on `C-(1 0 3)'.

Mode-specific contexts can be edited by changing `daselt-C-1-0-3-contexts-list`.
Default behavior is to move cursor line down."
  (interactive)
  (daselt--funcall-first-mode-match daselt-C-1-0-3-contexts-list #'next-line))

(defun daselt-C-1-0--4 ()
  "Contextual command on `C-(1 0 -4)'.

Mode-specific contexts can be edited by changing
`daselt-C-1-0--4-contexts-list`. Default behavior is to move one page up."
  (interactive)
  (daselt--funcall-first-mode-match daselt-C-1-0--4-contexts-list #'scroll-down-command))

(defun daselt-C-1-0-4 ()
  "Contextual command on `C-(1 0 4)'.

Mode-specific contexts can be edited by changing
`daselt-C-1-0-4-contexts-list'.  Default behavior is to move one page
down."
  (interactive)
  (daselt--funcall-first-mode-match
   daselt-C-1-0-4-contexts-list #'scroll-up-command))

(defun daselt--push-global-mark-ring ()
  "Push a copy of the current mark onto the global mark ring."
  (let ((old (nth global-mark-ring-max global-mark-ring))
        (history-delete-duplicates nil))
    (add-to-history
     'global-mark-ring (copy-marker (mark-marker))
     global-mark-ring-max t)
    (when old
      (set-marker old nil))))

(defun daselt--push-mark-ring (marker)
  "Push MARKER onto the local mark ring, trimming if needed."
  (when (mark t)
    (let ((old (nth mark-ring-max mark-ring))
          (history-delete-duplicates nil))
      (add-to-history 'mark-ring marker mark-ring-max t)
      (when old
        (set-marker old nil)))))

(cl-defun daselt-C-4-0-2 ()
  "Expand Yasnippet, Cdlatex, tempo, abbrev, or Corfu if available.

Also, go to the next item or environment, open a footnote, or open
something as needed.

If point changes position, add the previous position to the mark ring.
This is helpful for when you tried to expand something and it didn't
work for some reason.

In math-mode, no abbrevs are expanded."
  (interactive)
  (cl-flet*
      ((yas-maybe-expand ()
         (when (yas-maybe-expand-abbrev-key-filter t)
           (yas-expand)
           (cl-return-from daselt-C-4-0-2)))
       (daselt-cdlatex-maybe-expand ()
         (let ((pos (point)) expr math-mode)
           (backward-word 1)
           (while (eq (following-char) ?$) (forward-char 1))
           (setq expr (buffer-substring-no-properties (point) pos)
                 expr (assoc expr cdlatex-command-alist-comb))
           (if (not expr)
               (goto-char pos)
             (setq math-mode (cdlatex--texmathp))
             (when (or (and (not math-mode) (nth 5 expr))
                       (and math-mode (nth 6 expr)))
               (delete-char (- pos (point)))
               (insert (nth 2 expr))
               (when-let* ((fun (nth 3 expr)))
                 (if (nth 4 expr)
                     (apply fun (nth 4 expr))
                   (funcall fun))))
             (cl-return-from daselt-C-4-0-2))))
       (maybe-expand-abbrev ()
         (let ((pos (point)))
           (when (if daselt-abv
                     (progn (abv-expand) (/= (point) pos))
                   (expand-abbrev))
             (cl-return-from daselt-C-4-0-2)))))
    (when daselt-yasnippet (yas-maybe-expand))
    (when (and daselt-cdlatex cdlatex-mode)
      (daselt-cdlatex-maybe-expand))
    (when (and (fboundp #'tempo-expand-if-complete)
               (tempo-expand-if-complete))
      (cl-return-from daselt-C-4-0-2))
    (unless (and (derived-mode-p 'LaTeX-mode)
                 (texmathp)
                 (save-excursion
                   (if daselt-abv
                       (abbrev-chain-with-syntax-table-and-combining-categories
                        (backward-word))
                     (backward-word))
                   (texmathp)))
      (maybe-expand-abbrev))
    (let ((pos (point))
          (buf (current-buffer))
          (marker (point-marker)))
      (daselt--funcall-first-mode-match
       daselt-C-4-0-2-contexts-list #'org-open-at-point-global)
      ;; If point has moved, save the previous position to the mark ring.
      (unless (and (eq buf (current-buffer))
                   (= pos (point)))
        (daselt--push-mark-ring marker)
        ;; Don't push the global mark ring if the last global mark
        ;; pushed was in this same buffer.
        (unless (and global-mark-ring
                     (eq (marker-buffer (car global-mark-ring))
                         (current-buffer)))
          (daselt--push-global-mark-ring))))))

;;;;; Minibuffer
(defun daselt-move-right-or-exit ()
  "Exit if at the end of the minibuffer, otherwise move char right."
  (interactive)
  (if (eobp)
      (exit-minibuffer)
    (forward-char)))

;;;;; Saving
(defun daselt-abbrev-save ()
  "Save user-defined abbrevs to default abbrev-file."
  (declare (ftype (function nil t)))
  (interactive)
  (write-abbrev-file nil))

(defun daselt-backup-file (file)
  "Backup FILE with timestamp suffix.

Creates directory if needed, removes oldest backups when
`daselt-backup-limit' is exceeded.  The backup directory is in the
same directory as the file."
  (declare (ftype (function (string) t)))
  (let* ((directory (concat file "-backups"))
         (backup-file
          (expand-file-name
           (format "%s-%s"
                   (file-name-nondirectory file)
                   (format-time-string "%Y%m%d-%H%M%S"))
           directory)))
    (unless (file-directory-p directory)
      (make-directory directory t))
    (copy-file file backup-file t)
    (let ((backups (sort (directory-files
                          directory t
                          (concat (regexp-quote (file-name-nondirectory file))
                                  "-[0-9]\\{8\\}-[0-9]\\{6\\}\\'"))
                         #'file-newer-than-file-p)))
      (when (> (length backups) daselt-backup-limit)
        (dolist (old-backup (nthcdr daselt-backup-limit backups))
          (delete-file old-backup))))))

;;;;; Yanking
(defun daselt-yank-or-org-roam-node-insert ()
  "Yank text when mark is inactive; otherwise call `org-roam-node-insert`."
  (interactive)
  (cond ((derived-mode-p 'vterm-mode)
         (vterm-yank))
        ((use-region-p)
         (call-interactively #'org-roam-node-insert))
        (t (yank))))

(defun daselt-kill-append ()
  "Kill the currently marked region and append it to the last kill."
  (interactive)
  (append-next-kill)
  (kill-region (mark) (point)))

(defun daselt-copy-append ()
  "Copy the currently marked region and append it to the last kill."
  (interactive)
  (append-next-kill)
  (kill-ring-save (mark) (point)))
(defun daselt-yank-url ()
  "Yank URL at point from shr buffer."
  (declare (ftype (function nil t)))
  (interactive)
  (let ((url (get-text-property (point) 'shr-url)))
    (if url
        (progn
          (kill-new url)
          (message "Yanked: %s" url))
      (message "No URL at point"))))

;;;;; Killing
(defun daselt-kill-defun (&optional arg)
  "Kill the current defun, marking the active region and killing it.

ARG determines the scope of the kill."
  (interactive "p")
  (mark-defun arg)
  (kill-region (region-beginning) (region-end)))


(defun daselt-backward-kill-line (&optional arg)
  "Kill line backward."
  (declare (ftype (function (&optional integer) t)))
  (interactive "P")
  (let ((arg (or arg 0)))
    (kill-line arg)))

;;;;; Spacing
(defun daselt-just-one-space (&optional n)
  "Like `just-one-space', but also delete newlines around point.
Leaves one space, or N spaces when called with a prefix argument.
This is equivalent to calling `just-one-space' with a negative
argument."
  (interactive "*p")
  (just-one-space (- (abs (or n 1)))))

;;;;; Insertion
(defun daselt-insert-and-return (str)
  "Insert STR and return to the position before insertion."
  (interactive "sString: ")
  (let ((pos (point)))
    (insert str)
    (goto-char pos)))

(defun daselt-insert-space-forward ()
  "Insert a space and return to the original position."
  (interactive)
  (daselt-insert-and-return " "))

(defun daselt-insert-newline-forward ()
  "Insert a newline and return to the original position."
  (interactive)
  (daselt-insert-and-return "\n"))

(defun daselt-mode-insert-lambda-string (&optional arg)
  "Insert string \"lambda\".  With ARG, insert \"λ\" symbol."
  (interactive "P")
  (if arg
      (insert "λ")
    (insert "lambda")))

;;;;; Declaring
(defun daselt-generate-declare-function ()
  "Generate a `declare-function' statement for the function at point."
  (interactive)
  (let ((sym (symbol-at-point)))
    (if (not (and sym (fboundp sym)))
        (message "No function at point.")
      (let* ((function-location
              (find-lisp-object-file-name sym (symbol-function sym)))
             (args (help-function-arglist sym t)))
        (unless function-location
          (message "Cannot find function location."))
        (let ((declare-statement
               (format
                "(declare-function %s \"%s\" %s)"
                sym
                (if function-location
                    (file-name-sans-extension
                     (file-name-nondirectory function-location)))
                (if args
                    (format "%s"
                            (mapcar (lambda (arg)
                                      (if (symbolp arg) arg (car arg)))
                                    args))
                  "nil"))))
          (save-excursion
            (cond
             ((progn (goto-char (point-min))
                     (daselt-base-search-at-line-start
                      "(declare-function" t))
              (beginning-of-line)
              (insert (daselt-base-append-newlines
                       1 declare-statement)))
             ((daselt-base-search-at-line-start "(require" t)
              (while (re-search-forward
                      (rx line-start (* (or ";" " ")) "(require")
                      nil t)
                (end-of-line))
              (insert (daselt-base-prepend-newlines
                       2 declare-statement)))
             ((daselt-base-search-at-line-start ";;;; Preamble")
              (end-of-line)
              (insert (daselt-base-surround-by-newlines
                       1 1 declare-statement)))
             ((daselt-base-search-at-line-start ";;; Code")
              (end-of-line)
              (insert (format "\n;;;; Preamble\n%s"
                              declare-statement))))))))))

(defun daselt-generate-variable-definition ()
  "Generate an unvalued `defvar' statement for the variable at point.

The produced statement will be added to the preamble of the current
file."
  (interactive)
  (let ((sym (symbol-at-point)))
    (if (not sym)
        (message "No symbol under point.")
      (let ((defvar-statement
             (concat "(defvar " (symbol-name sym) ")")))
        (save-excursion
          (cond
           ((progn (goto-char (point-min))
                   (daselt-base-search-at-line-start "(defvar"))
            (beginning-of-line)
            (insert (daselt-base-append-newlines
                     1 defvar-statement)))
           ((daselt-base-search-at-line-start "(declare-function")
            (while (daselt-base-search-at-line-start
                    "(declare-function")
              (end-of-line))
            (insert (daselt-base-prepend-newlines
                     2 defvar-statement)))
           ((daselt-base-search-at-line-start ";;;; Preamble")
            (end-of-line)
            (insert (daselt-base-prepend-newlines
                     1 defvar-statement)))
           ((daselt-base-search-at-line-start ";;; Code")
            (end-of-line)
            (insert (format "\n;;;; Preamble\n%s"
                            defvar-statement)))))))))

;;;;; Recentering
(defun daselt-recenter-top ()
  "Recenter the screen with the current line at the top."
  (interactive)
  (recenter 1))

(defun daselt-recenter-bottom ()
  "Recenter the screen with the current line at the bottom."
  (interactive)
  (recenter -1))

;;;;; Toggling
(defun daselt-toggle-mode-line ()
  "Toggle the visibility of the mode line."
  (interactive)
  (if (equal mode-line-format nil)
      (setq mode-line-format
            (list "%e" 'mode-line-front-space
                  '(:propertize
                    ("" mode-line-mule-info mode-line-client
                     mode-line-modified mode-line-remote)
                    display (min-width (5.0)))
                  'mode-line-frame-identification
                  'mode-line-buffer-identification
                  "   "
                  'mode-line-position
                  '(vc-mode vc-mode)
                  "  "
                  'mode-line-modes
                  'mode-line-misc-info
                  'mode-line-end-spaces))
    (setq mode-line-format nil)))

(defun daselt-toggle-variable (var)
  "Toggle VAR between true and false."
  (interactive "vToggle variable: ")
  (set var (not (symbol-value var))))

;;;;; Search
(defun daselt-do-not-search-invisible ()
  "Set the search to ignore invisible portions of the text."
  (interactive)
  (setq search-invisible nil)
  (message "Invisible text is not searched."))

(defun daselt-search-invisible ()
  "Set the search to include invisible portions of the text."
  (interactive)
  (setq search-invisible t)
  (message "Invisible text is searched."))

(defun daselt-isearch-backward-thing-at-point ()
  "Do incremental search backward for the thing found near point.

Like ordinary incremental search except that the thing found at point
is added to the search string initially.  The thing is defined by
`bounds-of-thing-at-point'.  You can customize the variable
`isearch-forward-thing-at-point' to define a list of symbols to try
to find a thing at point.  For example, when the list contains the
symbol `region' and the region is active, then text from the active
region is added to the search string."
  (interactive)
  (isearch-backward nil 1)
  (let ((bounds (seq-some (lambda (thing)
                            (bounds-of-thing-at-point thing))
                          isearch-forward-thing-at-point)))
    (cond
     (bounds
      (when (use-region-p)
        (deactivate-mark))
      (when (< (car bounds) (point))
        (goto-char (car bounds)))
      (isearch-yank-string
       (buffer-substring-no-properties (car bounds) (cdr bounds))))
     (t
      (setq isearch-error "No thing at point")
      (isearch-push-state)
      (isearch-update)))))
(defun daselt-isearch-backward-symbol (&optional _not-symbol no-recursive-edit)
  "Do incremental search backward for a symbol.

The prefix argument is currently unused.  Like ordinary incremental
search except that your input is treated as a symbol surrounded by
symbol boundary constructs \\_< and \\_>.  See the command
`isearch-backward' for more information.  This command does not
support character folding, and lax space matching has no effect on it."
  (interactive "P\np")
  (isearch-mode nil nil nil (not no-recursive-edit) 'isearch-symbol-regexp))
(defun daselt-isearch-backward-word (&optional not-word no-recursive-edit)
  "Do incremental search backward for a sequence of words.

With a prefix argument, do a regular string search instead.  Like
ordinary incremental search except that your input is treated as a
sequence of words without regard to how the words are separated.  See
the command `isearch-backward' for more information.  This command
does not support character folding, and lax space matching has no
effect on it."
  (interactive "P\np")
  (isearch-mode nil nil nil (not no-recursive-edit) (null not-word)))
(defun daselt-isearch-backward-symbol-at-point (&optional arg)
  "Do incremental search backward for a symbol found near point.

Like ordinary incremental search except that the symbol found at point
is added to the search string initially as a regexp surrounded by
symbol boundary constructs \\_< and \\_>.  See the command
`daselt-isearch-backward-symbol' for more information.  With a
prefix argument ARG, repeat the backward search ARG times."
  (interactive "P")
  (daselt-isearch-backward-symbol nil 1)
  (let ((bounds (find-tag-default-bounds))
        (count (and arg (prefix-numeric-value arg))))
    (cond
     (bounds
      (when (< (car bounds) (point))
        (goto-char (car bounds)))
      (isearch-yank-string
       (buffer-substring-no-properties (car bounds) (cdr bounds)))
      (when count
        (isearch-repeat-backward count)))
     (t
      (setq isearch-error "No symbol at point")
      (isearch-push-state)
      (isearch-update)))))

;;;;; Replace
(defun daselt-replace-listwise (&rest strings)
  "Interactively replace strings listwise within a region or buffer.

Operates on each instance of STRINGS, mapping the nth string to the
\(n-1)th.  For the final string in STRINGS, if it has not appeared
previously, it is removed; otherwise, it cycles the replacements.  A
prefix argument reverses the mappings.

For example, with input strings A, B, C, ...:
  Without prefix: A -> B, B -> C, ..., Y -> Z, Z -> (removed)
  With prefix:    A <- B, B <- C, ..., Y <- Z, Z <- (removed)

Special case: With A, B, A, instances of A are replaced with B, and
vice versa.  The user is prompted to input the strings, which are
collected into STRINGS.

This function uses a placeholder based on `πλαχεηολδερ' to handle
replacements.  This word should not occur in the text being processed.
If it does, change the placeholder.

Operates on the active region if present; otherwise, it operates on
the entire buffer.

Interactively, STRINGS are collected by prompting with a minibuffer
until an empty string is entered.  The function then sequentially
replaces occurrences of each string with a unique placeholder,
followed by a second pass replacing placeholders with the mapped
string values, ensuring reliable in-place text replacement."
  (interactive (let (input inputs)
                 (while (not (string-empty-p
                              (setq input
                                    (completing-read
                                     "Enter strings to cycle (empty to exit): "
                                     nil))))
                   (push input inputs))
                 (nreverse inputs)))
  (let* ((beg (if (use-region-p) (region-beginning) (point-min)))
         (end (if (use-region-p) (region-end) (point-max)))
         ;; Unwrap if called with a list as first argument.
         (strings (if (listp (car strings)) (car strings) strings))
         ;; Reverse if prefix arg is given.
         (strings (if current-prefix-arg (reverse strings) strings))
         (nstrings (length strings)))
    (cl-loop for n from 0 to (1- nstrings)
             for oldstring = (nth n strings)
             for placeholder = (format "πλαχεηολδερ%s" n)
             for lengthdiff = (- (length placeholder) (length oldstring))
             do (goto-char beg)
             do (while (search-forward oldstring end t)
                  (replace-match placeholder case-replace t)
                  (cl-incf end lengthdiff)))
    (cl-loop for n from 0 to (- nstrings 2)
             for newstring = (nth (1+ n) strings)
             for placeholder = (format "πλαχεηολδερ%s" n)
             for lengthdiff = (- (length newstring) (length placeholder))
             do (while (search-forward placeholder end t)
                  (replace-match newstring case-replace t)
                  (cl-incf end lengthdiff))
             do (goto-char beg))
    (while (re-search-forward "πλαχεηολδερ." end t)
      (replace-match "" nil t))))
(defun daselt--exchange-read-args (prompt)
  "Read the arguments of an exchange command, prompting with PROMPT.

Return the list (STRING1 STRING2 DELIMITED), where DELIMITED is the
raw prefix argument."
  (let* ((prompt (concat prompt (if (use-region-p) " in region" "")))
         (string1 (read-string (concat prompt ": ") nil
                               query-replace-from-history-variable))
         (string2 (read-string (format "%s %s with: " prompt string1) nil
                               query-replace-to-history-variable)))
    (list string1 string2 current-prefix-arg)))

(defun daselt--exchange (string1 string2 query delimited)
  "Exchange STRING1 and STRING2 in the active region or the whole buffer.

Both strings are matched in a single pass, so no placeholder is
needed.  If QUERY is non-nil, ask about each match as `query-replace'
does.  If DELIMITED is non-nil, only exchange matches surrounded by word
boundaries.  Matches rejected by `isearch-filter-predicate' are skipped,
so binding it restricts the exchange."
  (when (or (string-empty-p string1) (string-empty-p string2))
    (user-error "Cannot exchange an empty string"))
  (when (string= string1 string2)
    (user-error "Nothing to exchange: the strings are identical"))
  ;; Try the longer string first, so that it wins when the shorter one is
  ;; a prefix of it.
  (let* ((swap (< (length string1) (length string2)))
         (long (if swap string2 string1))
         (short (if swap string1 string2))
         (region (use-region-p))
         (regexp (concat "\\(?:\\(" (regexp-quote long) "\\)\\|"
                         (regexp-quote short) "\\)")))
    ;; Word boundaries go into the regexp: `perform-replace' would apply
    ;; DELIMITED as a word-search transformation of the whole regexp.
    (perform-replace
     (if delimited (concat "\\b" regexp "\\b") regexp)
     (cons (lambda (_data _count) (if (match-beginning 1) short long)) nil)
     query 'literal nil nil nil
     (if region (region-beginning) (point-min))
     (if region (region-end) (point-max))
     nil (and region (region-noncontiguous-p)))))

(defun daselt-exchange (string1 string2 &optional delimited)
  "Exchange STRING1 with STRING2 in the active region or the whole buffer.

Every occurrence of either string is replaced by the other one in a
single pass.  With a prefix argument DELIMITED, only exchange matches
surrounded by word boundaries.  Case is handled as in `replace-string'.
Point does not move."
  (interactive (daselt--exchange-read-args "Exchange"))
  (save-excursion
    (daselt--exchange string1 string2 nil delimited)))

(defun daselt-query-exchange (string1 string2 &optional delimited)
  "Like `daselt-exchange', but ask about each occurrence.

The questions are those of `query-replace'.  DELIMITED is as in
`daselt-exchange'."
  (interactive (daselt--exchange-read-args "Query exchange"))
  (daselt--exchange string1 string2 t delimited))

(defun daselt--backward-replace-read-args (what regexp-flag)
  "Read the arguments of a backward replace command.

WHAT names the kind of replacement (\"string\" or \"regexp\") in the
prompt and REGEXP-FLAG is passed to `query-replace-read-args'.  Return
the list (FROM TO DELIMITED START END REGION-NONCONTIGUOUS-P)."
  (let ((common (query-replace-read-args
                 (concat "Replace backward " what
                         (if (use-region-p) " in region" ""))
                 regexp-flag)))
    (list (car common) (cadr common) (caddr common)
          (use-region-beginning) (use-region-end)
          (use-region-noncontiguous-p))))

(defun daselt-replace-string-backward
    (from-string to-string &optional delimited start end
		 region-noncontiguous-p)
  "Perform backward string replacement from FROM-STRING to TO-STRING.

DELIMITED, START, END, and REGION-NONCONTIGUOUS-P are as in
`replace-string'."
  (declare (interactive-only
            "use `search-forward' and `replace-match' instead.")
           (interactive-args
            (start (use-region-beginning))
            (end (use-region-end))
            (region-noncontiguous-p (use-region-noncontiguous-p))))
  (interactive (daselt--backward-replace-read-args "string" nil))
  (perform-replace from-string to-string nil nil delimited
                   nil nil start end t region-noncontiguous-p))
(defun daselt-replace-regexp-backward
    (regexp to-string &optional delimited start end
	    region-noncontiguous-p)
  "Perform backward regexp replacement from REGEXP to TO-STRING.

DELIMITED, START, END, and REGION-NONCONTIGUOUS-P are as in
`replace-regexp'."
  (declare (interactive-only
            "use `re-search-forward' and `replace-match' instead.")
           (interactive-args
            (start (use-region-beginning))
            (end (use-region-end))
            (region-noncontiguous-p (use-region-noncontiguous-p))))
  (interactive (daselt--backward-replace-read-args "regexp" t))
  (perform-replace regexp to-string nil t delimited
                   nil nil start end t region-noncontiguous-p))
(defun daselt-query-replace-string-backward
    (from-string to-string &optional delimited start end
		 region-noncontiguous-p)
  "Perform backward interactive query replace from FROM-STRING to TO-STRING.

DELIMITED, START, END, and REGION-NONCONTIGUOUS-P are as in
`query-replace-string'."
  (declare (interactive-only
            "use `search-forward' and `replace-match' instead.")
           (interactive-args
            (start (use-region-beginning))
            (end (use-region-end))
            (region-noncontiguous-p (use-region-noncontiguous-p))))
  (interactive (daselt--backward-replace-read-args "string" nil))
  (perform-replace from-string to-string t nil delimited
                   nil nil start end t region-noncontiguous-p))
(defun daselt-query-replace-regexp-backward
    (regexp to-string &optional delimited start end
	    region-noncontiguous-p)
  "Perform backward interactive query replace from REGEXP to TO-STRING.

DELIMITED, START, END, and REGION-NONCONTIGUOUS-P are as in
`query-replace-regexp'."
  (declare (interactive-only
            "use `re-search-forward' and `replace-match' instead.")
           (interactive-args
            (start (use-region-beginning))
            (end (use-region-end))
            (region-noncontiguous-p (use-region-noncontiguous-p))))
  (interactive (daselt--backward-replace-read-args "regexp" t))
  (perform-replace regexp to-string t t delimited
                   nil nil start end t region-noncontiguous-p))

(defun daselt-replace-string-throughout-buffer (from-string to-string)
  "Replace all instances of FROM-STRING with TO-STRING in the buffer."
  (interactive
   (let ((common (query-replace-read-args
                  "Replace string in buffer: " nil)))
     (list (car common) (cadr common))))
  (save-excursion
    (goto-char (point-min))
    (while (search-forward from-string nil t)
      (replace-match to-string nil t))))
(defun daselt-replace-regexp-throughout-buffer (from-regexp replacement)
  "Replace all instances of FROM-REGEXP with REPLACEMENT in the buffer."
  (interactive
   (let ((common (query-replace-read-args
                  "Replace regexp in buffer: " nil)))
     (list (car common) (cadr common))))
  (save-excursion
    (goto-char (point-min))
    (while (re-search-forward from-regexp nil t)
      (replace-match replacement))))

(defun daselt-replace-string-throughout-directory
    (from-string to-string dir &optional filetest dirtest allfiles)
  "Replace FROM-STRING with TO-STRING in files under DIR.

FILETEST can be a regexp string or a predicate function.  If a regexp,
only files whose names match it are processed.  If a function, it is
called with the filename and must return non-nil to process.

DIRTEST is similar for filtering directories to recurse into.

If ALLFILES is non-nil, hidden files and directories are included."
  (interactive "sString: \nsReplacement: \nDDirectory: ")
  (daselt--replace-throughout-directory
   (lambda () (daselt-replace-string-throughout-buffer from-string to-string))
   dir filetest dirtest allfiles))

(defun daselt-replace-regexp-throughout-directory
    (regexp replacement dir &optional filetest dirtest allfiles)
  "Replace REGEXP with REPLACEMENT in files under DIR.

FILETEST can be a regexp string or a predicate function.  If a regexp,
only files whose names match it are processed.  If a function, it is
called with the filename and must return non-nil to process.

DIRTEST is similar for filtering directories to recurse into.

If ALLFILES is non-nil, hidden files and directories are included."
  (interactive "sString: \nsReplacement: \nDDirectory: ")
  (daselt--replace-throughout-directory
   (lambda () (daselt-replace-regexp-throughout-buffer regexp replacement))
   dir filetest dirtest allfiles))

(defun daselt--replace-throughout-directory
    (replace-fun dir filetest dirtest allfiles)
  "Call REPLACE-FUN in a buffer visiting each file under DIR.

FILETEST, DIRTEST and ALLFILES are as in
`daselt-replace-string-throughout-directory'."
  (let* ((buf (current-buffer))
         (filepred (daselt--coerce-to-predicate filetest))
         (action (lambda (fname)
                   (set-buffer (find-file-noselect fname))
                   (funcall replace-fun)))
         (test (lambda (idx flist)
                 (funcall filepred (nth idx flist)))))
    (save-excursion
      (daselt-base-recurse-through-directory
       dir (list (cons action test))
       (daselt--coerce-to-predicate dirtest) nil allfiles)
      (set-buffer buf))))

(defun daselt--coerce-to-predicate (filetest)
  "Coerce FILETEST to a predicate function.

If FILETEST is a string, return a function that matches it as a regexp
against its argument.  If nil, return a function that always returns t.
Otherwise return FILETEST unchanged."
  (cond
   ((null filetest) (lambda (_file) t))
   ((stringp filetest)
    (lambda (fname) (string-match-p filetest fname)))
   (t filetest)))

(defun daselt-replace-list-throughout-directory
    (lst dir fun &optional filetest dirtest allfiles)
  "Replace occurrences of strings or symbols in files throughout DIR.

LST is a list of strings or symbols.  If an element is a cons cell, the
car is the string to be replaced and the cdr is the replacement.
Otherwise, FUN is called on the element to get the replacement.

FILETEST can be a regexp string or predicate function for filtering
files.  DIRTEST can be a regexp string or predicate function for
filtering directories.  If ALLFILES is non-nil, include hidden files.

Returns a list of the replacement strings for each element in LST."
  (cl-flet ((obj-or-name (obj)
              (if (symbolp obj) (symbol-name obj) obj)))
    (mapcar (lambda (obj)
              (let* ((ocnsp (consp obj))
                     (str (if ocnsp
                              (obj-or-name (car obj))
                            (obj-or-name obj)))
                     (repl (if ocnsp (cdr obj) (funcall fun obj))))
                (daselt-replace-string-throughout-directory
                 str repl dir filetest dirtest allfiles)
                repl))
            lst)))

;;;;; Open Emacs
(defun daselt--shell-escaped-buffer-file-name ()
  "Return the current buffer's file name with spaces escaped for a shell."
  (daselt-base--escape-chars-in-str
   (or (buffer-file-name)
       (error "Buffer not visiting a file"))
   (list (rx-to-string '(group " ")))))

(defun daselt-open-file-in-new-emacs (&optional filename)
  "Open FILENAME in a new Emacs instance with --debug-init and --no-desktop.

Defaults to the current buffer's file if FILENAME isn't specified."
  (interactive)
  (shell-command
   (format "emacs --no-desktop --debug-init %s &"
           (or filename (daselt--shell-escaped-buffer-file-name)))))

(defun daselt-open-file-in-new-emacs-no-init (&optional filename)
  "Open FILENAME in a new Emacs instance without loading the init file.

Defaults to the current buffer's file if FILENAME isn't specified."
  (interactive)
  (shell-command
   (format "emacs -q %s &"
           (or filename (daselt--shell-escaped-buffer-file-name)))))

;;;;; Keys
(defun daselt-minor-mode-key-binding (key)
  "Retrieve the list of minor mode keybindings for KEY.

Ignore the override map."
  (interactive "sKey: ")
  (let ((active-maps nil))
    (mapc (lambda (x)
            (when (and (symbolp (car x)) (symbol-value (car x)))
              (push (lookup-key (cdr x) (kbd key)) active-maps)))
          minor-mode-map-alist)
    (make-composed-keymap (nreverse active-maps))))

;;;; Generated commands
(daselt-base-def-by-forms
 ((let ((str-is-top (string= str "top")))
    `(defun ,(intern (concat "daselt-move-to-" str)) ()
       ,(format "Move to the %s of the current window." str)
       (interactive)
       (let ((this-scroll-margin (min (max 0 scroll-margin) (truncate (/ (window-body-height) 4.0)))))
         (move-to-window-line ,(if str-is-top
                                   'this-scroll-margin
                                 '(- -1 this-scroll-margin)))))))
 (str . ("top" "bottom")))

(daselt-base-def-by-forms-by-variables
 (`(defun ,(intern (concat "daselt-backward-"
                           (replace-regexp-in-string
                            "daselt-" "" (symbol-name cmd))))
       (&optional arg)
     ,(daselt-base-fill-string-like-docstring
       (format "A version of %s with a negative argument so it acts backwards.
Generated automatically using `daselt-backward-command-list'." cmd))
     (interactive "p")
     (,cmd (- arg))))
 (cmd . daselt-backward-command-list))

(daselt-base-def-by-forms-by-variables
 (`(defun ,(intern (concat "daselt-in-new-buffer-"
                           (replace-regexp-in-string
                            "daselt-" "" (symbol-name cmd))))
       ()
     ,(format "Run %s in a clone of the current buffer.
The original buffer stays where it was.
Generated automatically using `daselt-new-buffer-command-list'." cmd)
     (interactive)
     (switch-to-buffer (clone-buffer))
     (call-interactively #',cmd)))
 (cmd . daselt-new-buffer-command-list))

;; Create subsentence-analogs of sentence-commands in daselt-subsentence-command-list.
(daselt-base-def-by-forms-by-variables
 ((let ((nullary (= 0 (cdr (func-arity cmd)))))
    `(defun ,(intern (concat "daselt-"
                             (replace-regexp-in-string
                              "daselt-" ""
                              (replace-regexp-in-string
                               "sentence" "subsentence" (symbol-name cmd)))))
         ,(if nullary '() '(arg))
       ,(daselt-base-fill-string-like-docstring
         (format "Execute %s with subsentence-signs as delimiters." (symbol-name cmd)))
       (interactive "p")
       (let ((sentence-end-base "[.?!…‽;:,][]\"'”’)}»›]*"))
         ,(remq nil `(,cmd ,(unless nullary 'arg)))))))
 (cmd . daselt-subsentence-command-list))

;;;; Provide
(provide 'daselt-ext)
;;; daselt-ext.el ends here
