;;; daselt-vterm.el --- Daselt commands for vterm  -*- lexical-binding: t; -*-

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; `daselt-mode-map' lives in `emulation-mode-map-alists', so it
;; shadows `vterm-mode-map' on every key it binds: Daselt's word,
;; line and kill commands then act on the read-only Emacs buffer
;; instead of on the shell's input line.
;;
;; `daselt-vterm-mode' fixes this.  It is enabled in every vterm
;; buffer (see vterm.dhl) and puts two maps above `daselt-mode-map':
;;
;; - `daselt-vterm-mode-map' (bound in vterm.dbl) while the terminal
;;   is live.  Editing keys send the matching readline key to the
;;   shell; buffer-navigation keys enter `vterm-copy-mode' and run
;;   their ordinary Daselt command there.
;; - `vterm-copy-mode-map' while `vterm-copy-mode' is on, so the
;;   copy-mode bindings in vterm.dbl win as well.  The live-terminal
;;   map is switched off in copy mode, so all Daselt navigation works
;;   normally on the scrollback.
;;
;; With `daselt-abv' enabled, `abv-vterm' is loaded so `abv-expand'
;; expands directly in the terminal and `abv-vterm-compose' is
;; available.

;;; Code:

(defvar vterm-copy-mode)
(defvar vterm-copy-mode-map)
(declare-function vterm-send "vterm" (key))
(declare-function vterm-copy-mode "vterm" (&optional arg))

(defvar-keymap daselt-vterm-mode-map
  :doc "Daselt bindings above `daselt-mode-map' in live vterm buffers.")

(defvar daselt-vterm--emulation-alist nil
  "Element of `emulation-mode-map-alists' holding the vterm maps.
Rebuilt by `daselt-vterm--raise-maps'.")

(defun daselt-vterm--raise-maps ()
  "Put the vterm maps in front of `emulation-mode-map-alists'.
`daselt-mode' adds `daselt-mode-map' there when it starts, possibly
after this package was set up, so the order is restored whenever
`daselt-vterm-mode' is turned on."
  (setq daselt-vterm--emulation-alist
        `((daselt-vterm-mode . ,daselt-vterm-mode-map)
          ,@(when (boundp 'vterm-copy-mode-map)
              `((vterm-copy-mode . ,vterm-copy-mode-map)))))
  (setq emulation-mode-map-alists
        (cons 'daselt-vterm--emulation-alist
              (delq 'daselt-vterm--emulation-alist
                    emulation-mode-map-alists))))

(define-minor-mode daselt-vterm-mode
  "Let Daselt keys act on the terminal in this vterm buffer.

See the commentary of daselt-vterm.el.

\\{daselt-vterm-mode-map}"
  :lighter nil
  (when daselt-vterm-mode
    (daselt-vterm--raise-maps)
    (when (bound-and-true-p daselt-abv)
      (require 'abv-vterm nil t))))

(defun daselt-vterm--follow-copy-mode ()
  "Turn `daselt-vterm-mode' off in `vterm-copy-mode' and back on after it."
  (daselt-vterm-mode (if vterm-copy-mode -1 1)))

(defun daselt-vterm-copy-mode-and-repeat ()
  "Enter `vterm-copy-mode' and run what this key does outside the terminal.
Bound to Daselt's buffer-navigation and search keys, so they move
through the scrollback instead of being reset by the next redraw."
  (interactive)
  (vterm-copy-mode 1)
  (let ((cmd (key-binding (this-command-keys-vector) t)))
    (when (commandp cmd)
      (setq this-command cmd)
      (call-interactively cmd))))

(defmacro daselt-vterm--define-senders (&rest specs)
  "Define a command `daselt-vterm-send-KEY' for each (KEY DESCRIPTION) in SPECS."
  `(progn
     ,@(mapcar (lambda (spec)
                 (let ((key (car spec)))
                   `(defun ,(intern (concat "daselt-vterm-send-" key)) ()
                      ,(format "Send %s (%s) to the terminal." key (cadr spec))
                      (interactive)
                      (vterm-send ,key))))
               specs)))

(daselt-vterm--define-senders
 ("C-a" "beginning of line")
 ("C-e" "end of line")
 ("M-b" "backward word")
 ("M-f" "forward word")
 ("M-d" "kill word")
 ("C-k" "kill to end of line")
 ("C-u" "kill to beginning of line")
 ("C-t" "transpose characters")
 ("M-t" "transpose words")
 ("C-c" "interrupt"))

(provide 'daselt-vterm)
;;; daselt-vterm.el ends here
