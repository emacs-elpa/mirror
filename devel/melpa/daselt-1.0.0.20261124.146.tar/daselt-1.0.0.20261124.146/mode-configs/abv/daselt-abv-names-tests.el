;;; daselt-abv-names-tests.el --- Tests for daselt-abv-names  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; Author: Alexander Praehauser <ahprae@protonmail.com>
;; Keywords: abbrev

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Tests for `daselt-abv-names': `daselt-abv--generate-free-key' and
;; the Daselt specializations of `abv--add-name', `abv--add-macro' and
;; `abv--add-formula'.

;;; Code:

(require 'ert)
(require 'cl-lib)
(require 'daselt-abv-tests--setup)
(require 'daselt-abv-names)
(require 'abv-name-table)

;;;; Test stubs for missing abv primitives

;; The original `daselt-abv--generate-free-key' references
;; `abv-name-table--taken-keys', and `abv-add-with' on `abv-table'
;; delegates to an "obarray-generic" `abv-add-with' that isn't
;; actually defined in the current abv codebase.  We provide working
;; definitions of both here so the Daselt name/macro/formula methods
;; can be exercised end-to-end.

(cl-defmethod abv-add-with ((array obarray) name value &key _history-list &allow-other-keys)
  "Add NAME to ARRAY (an obarray) with VALUE as its expansion."
  (let ((sym (intern name array)))
    (set sym value))
  name)


;;;; Helpers

(defun daselt-abv-names-tests--fresh-name-table ()
  "Return a fresh empty `abv-name-table' for tests."
  (make-instance 'abv-name-table :name "test-names"))


;;;; daselt-abv--generate-free-key

(ert-deftest daselt-abv-generate-free-key-finds-single-char ()
  "When the table is empty, the first free key is a single char."
  (let* ((layout daselt-abv--default-layout)
         (tbl (daselt-abv-names-tests--fresh-name-table)))
    (let ((key (daselt-abv--generate-free-key layout tbl)))
      (should (stringp key))
      (should (= 1 (length key))))))

(ert-deftest daselt-abv-generate-free-key-avoids-taken ()
  "`generate-free-key' returns a key that is not already in the obarray."
  (let* ((layout daselt-abv--default-layout)
         (tbl (daselt-abv-names-tests--fresh-name-table))
         ;; Reserve the first 5 single-char keys.
         (chars (delq nil
                      (mapcar (lambda (pv)
                                (and (stringp (cdr pv))
                                     (not (string-empty-p (cdr pv)))
                                     (cdr pv)))
                              (cl-subseq (oref (oref layout placevals) standard-placevals) 0 5)))))
    (dolist (c chars)
      (abv-add-with tbl c "occupied"))
    (let ((key (daselt-abv--generate-free-key layout tbl)))
      (should (stringp key))
      ;; The returned key must not collide with any reserved key.
      (should-not (intern-soft key (oref tbl obarray))))))

(ert-deftest daselt-abv-generate-free-key-is-deterministic ()
  "Two calls on the same fresh table return the same key."
  (let* ((layout daselt-abv--default-layout))
    (let ((k1 (daselt-abv--generate-free-key
               layout (daselt-abv-names-tests--fresh-name-table)))
          (k2 (daselt-abv--generate-free-key
               layout (daselt-abv-names-tests--fresh-name-table))))
      (should (string= k1 k2)))))


;;;; abv--add-name

(ert-deftest daselt-abv-add-name-smoke ()
  "`abv--add-name' returns a string key for the name."
  (let* ((layout daselt-abv--default-layout)
         (tbl (daselt-abv-names-tests--fresh-name-table)))
    (let ((key (abv--add-name "Alexander" tbl layout)))
      (should (stringp key))
      ;; The key must now resolve to "Alexander".
      (should (equal "Alexander"
                     (abv-return-match key tbl))))))


;;;; abv--add-macro

(ert-deftest daselt-ei-add-macro-smoke ()
  "`abv--add-macro' returns a string key for the macro."
  (let* ((layout daselt-abv--default-layout)
         (tbl (daselt-abv-names-tests--fresh-name-table)))
    (let ((key (abv--add-macro "(lambda () \"hi\")" tbl layout)))
      (should (stringp key))
      (should (equal "(lambda () \"hi\")"
                     (abv-return-match key tbl))))))


;;;; abv--add-formula

(ert-deftest daselt-ei-add-formula-smoke ()
  "`abv--add-formula' returns a string key for the formula."
  (let* ((layout daselt-abv--default-layout)
         (tbl (daselt-abv-names-tests--fresh-name-table)))
    (let ((key (abv--add-formula "x^2 + y^2" tbl layout)))
      (should (stringp key))
      (should (equal "x^2 + y^2"
                     (abv-return-match key tbl))))))


;;;; Old method still works

(ert-deftest daselt-abv-add-name-old-smoke ()
  "`abv--add-name--old' returns a string key for the name."
  (let* ((layout daselt-abv--default-layout)
         (tbl (daselt-abv-names-tests--fresh-name-table)))
    (let ((key (abv--add-name--old "Euler" tbl layout)))
      (should (stringp key))
      (should (equal "Euler"
                     (abv-return-match key tbl))))))


(provide 'daselt-abv-names-tests)
;;; daselt-abv-names-tests.el ends here
