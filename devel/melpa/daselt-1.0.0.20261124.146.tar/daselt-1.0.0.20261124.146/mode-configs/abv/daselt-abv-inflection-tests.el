;;; daselt-abv-inflection-tests.el --- Tests for daselt-abv-inflection  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; Author: Alexander Praehauser <ahprae@protonmail.com>
;; Keywords: abbrev

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Tests for `daselt-abv-inflection': pure decode helpers, verb
;; first/second-char info, `abv-layout-inflection-info' specializations,
;; word-type decoding and the conversion-method table.

;;; Code:

(require 'ert)
(require 'cl-lib)
(require 'daselt-abv-tests--setup)
(require 'daselt-abv-inflection)


;;;; Coordinate-component decoders

(ert-deftest daselt-abv-number-from-layer ()
  "`number-from-layer' decodes singular/plural."
  (should (eq 'singular (daselt-abv--number-from-layer 1)))
  (should (eq 'singular (daselt-abv--number-from-layer 4)))
  (should (eq 'singular (daselt-abv--number-from-layer 5)))
  (should (eq 'singular (daselt-abv--number-from-layer 8)))
  (should (eq 'plural (daselt-abv--number-from-layer 2)))
  (should (eq 'plural (daselt-abv--number-from-layer 3)))
  (should (eq 'plural (daselt-abv--number-from-layer 6)))
  (should (eq 'plural (daselt-abv--number-from-layer 7))))

(ert-deftest daselt-abv-negate-from-layer ()
  "`negate-from-layer' decodes negation."
  (should (null (daselt-abv--negate-from-layer 1)))
  (should (null (daselt-abv--negate-from-layer 2)))
  (should (eq t (daselt-abv--negate-from-layer 5)))
  (should (eq t (daselt-abv--negate-from-layer 6)))
  ;; Layers outside known pairs return nil.
  (should (null (daselt-abv--negate-from-layer 3)))
  (should (null (daselt-abv--negate-from-layer 7))))

(ert-deftest daselt-abv-tense-from-col ()
  "`tense-from-col' decodes tense from the column."
  (should (eq 'past-participle (daselt-abv--tense-from-col -3)))
  (should (eq 'past (daselt-abv--tense-from-col -2)))
  (should (eq 'present (daselt-abv--tense-from-col -1)))
  (should (eq 'present (daselt-abv--tense-from-col 0)))
  (should (eq 'present (daselt-abv--tense-from-col 1)))
  (should (eq 'future (daselt-abv--tense-from-col 2)))
  (should (eq 'gerund (daselt-abv--tense-from-col 3)))
  (should (eq 'infinitive (daselt-abv--tense-from-col 4)))
  ;; Unknown columns return nil.
  (should (null (daselt-abv--tense-from-col -5)))
  (should (null (daselt-abv--tense-from-col 10))))

(ert-deftest daselt-abv-person-from-row ()
  "`person-from-row' decodes grammatical person."
  (should (= 1 (daselt-abv--person-from-row -1)))
  (should (= 3 (daselt-abv--person-from-row 0)))
  (should (= 2 (daselt-abv--person-from-row 1)))
  (should (null (daselt-abv--person-from-row 99))))

(ert-deftest daselt-abv-aspect-from-col ()
  "`aspect-from-col' decodes aspect."
  (should (eq 'perfect (daselt-abv--aspect-from-col -3)))
  (should (eq 'progressive (daselt-abv--aspect-from-col -2)))
  (should (eq 'perfect-progressive (daselt-abv--aspect-from-col 2)))
  (should (eq 'simple (daselt-abv--aspect-from-col 3)))
  (should (null (daselt-abv--aspect-from-col 0))))

(ert-deftest daselt-abv-mood-from-row ()
  "`mood-from-row' decodes mood."
  (should (eq 'subjunctive (daselt-abv--mood-from-row -1)))
  (should (eq 'indicative (daselt-abv--mood-from-row 0)))
  (should (eq 'imperative (daselt-abv--mood-from-row 1)))
  (should (null (daselt-abv--mood-from-row 99))))

(ert-deftest daselt-abv-voice-from-layer ()
  "`voice-from-layer' decodes voice (2 = passive)."
  (should (eq 'passive (daselt-abv--voice-from-layer 2)))
  (should (eq 'active (daselt-abv--voice-from-layer 1)))
  (should (eq 'active (daselt-abv--voice-from-layer 5))))

(ert-deftest daselt-abv-case-from-row ()
  "`case-from-row' decodes grammatical case."
  (should (eq 'genitive (daselt-abv--case-from-row -1)))
  (should (eq 'common (daselt-abv--case-from-row 0)))
  (should (eq 'common (daselt-abv--case-from-row 1))))

(ert-deftest daselt-abv-degree-from-row ()
  "`degree-from-row' decodes comparison degree."
  (should (eq 'positive (daselt-abv--degree-from-row -1)))
  (should (eq 'comparative (daselt-abv--degree-from-row 0)))
  (should (eq 'superlative (daselt-abv--degree-from-row 1)))
  (should (null (daselt-abv--degree-from-row 99))))

(ert-deftest daselt-abv-gender-from-col ()
  "`gender-from-col' decodes gender."
  (should (eq 'masculine (daselt-abv--gender-from-col -2)))
  (should (eq 'feminine (daselt-abv--gender-from-col -1)))
  (should (eq 'neuter (daselt-abv--gender-from-col 0)))
  (should (null (daselt-abv--gender-from-col 2))))


;;;; Verb character info

(ert-deftest daselt-abv-verb-first-char-info ()
  "`verb-first-char-info' returns tense/person/number/negate plist."
  (let ((info (daselt-abv--verb-first-char-info '(1 0 -2))))
    (should (eq 'past (plist-get info :tense)))
    (should (= 3 (plist-get info :person)))
    (should (eq 'singular (plist-get info :number)))
    (should (null (plist-get info :negate))))
  (let ((info (daselt-abv--verb-first-char-info '(5 1 2))))
    (should (eq 'future (plist-get info :tense)))
    (should (= 2 (plist-get info :person)))
    (should (eq 'singular (plist-get info :number)))
    (should (eq t (plist-get info :negate)))))

(ert-deftest daselt-abv-verb-second-char-info ()
  "`verb-second-char-info' returns mood/aspect/voice plist."
  (let ((info (daselt-abv--verb-second-char-info '(1 1 3))))
    (should (eq 'imperative (plist-get info :mood)))
    (should (eq 'simple (plist-get info :aspect)))
    (should (eq 'active (plist-get info :voice))))
  (let ((info (daselt-abv--verb-second-char-info '(2 -1 -3))))
    (should (eq 'subjunctive (plist-get info :mood)))
    (should (eq 'perfect (plist-get info :aspect)))
    (should (eq 'passive (plist-get info :voice)))))


(ert-deftest daselt-abv-degree-info ()
  "`degree-info' decodes degree, negate and particle."
  (should (equal '(:degree positive :negate nil :particle nil)
                 (daselt-abv--degree-info '(1 -1 0))))
  (should (equal '(:degree comparative :negate nil :particle t)
                 (daselt-abv--degree-info '(2 0 0))))
  (should (equal '(:degree comparative :negate t :particle nil)
                 (daselt-abv--degree-info '(5 0 0))))
  (should (equal '(:degree superlative :negate t :particle t)
                 (daselt-abv--degree-info '(6 1 0)))))

(ert-deftest daselt-abv-noun-info ()
  "`noun-info' decodes number, case, definiteness and particle."
  (should (equal '(:number singular :case common :definiteness nil
                           :particle nil)
                 (daselt-abv--noun-info '(1 0 0))))
  (should (equal '(:number plural :case genitive :definiteness nil
                           :particle nil)
                 (daselt-abv--noun-info '(2 -1 0))))
  (should (equal '(:number singular :case common :definiteness definite
                           :particle t)
                 (daselt-abv--noun-info '(5 1 0))))
  (should (equal '(:number plural :case common :definiteness indefinite
                           :particle nil)
                 (daselt-abv--noun-info '(3 0 0)))))

(ert-deftest daselt-abv-verb-subject-and-particle ()
  "Verb layers decode subject, negation with subject, and particle."
  (let ((plain (daselt-abv--verb-first-char-info '(1 0 0)))
        (subject (daselt-abv--verb-first-char-info '(4 0 0)))
        (both (daselt-abv--verb-first-char-info '(7 0 0))))
    (should-not (plist-get plain :subject))
    (should (plist-get subject :subject))
    (should-not (plist-get subject :negate))
    (should (eq 'singular (plist-get subject :number)))
    (should (plist-get both :subject))
    (should (plist-get both :negate))
    (should (eq 'plural (plist-get both :number))))
  (let ((info (daselt-abv--verb-second-char-info '(6 0 3))))
    (should (eq 'passive (plist-get info :voice)))
    (should (plist-get info :particle)))
  (should-not (plist-get (daselt-abv--verb-second-char-info '(2 0 3))
                         :particle)))

(ert-deftest daselt-abv-position-affix-layer-pair ()
  "A layer pair's own conversion entry wins over the all-pairs entry."
  (should (= 5 (daselt-abv--pair-lower-layer 6)))
  (should (= 4 (daselt-abv--pair-lower-layer 3)))
  ;; Verb -> verb: pair (5,6) has its own prefixes.
  (should (equal "dis-" (daselt-abv--position-affix-from-coord
                         'verb '(5 -1 -2))))
  (should (equal "co-" (daselt-abv--position-affix-from-coord
                        'verb '(6 0 -2))))
  ;; The other pairs keep the all-pairs entries.
  (should (equal "re-" (daselt-abv--position-affix-from-coord
                        'verb '(4 -1 -2))))
  (should (equal "mis-" (daselt-abv--position-affix-from-coord
                         'verb '(3 0 -2))))
  (should (equal "over-" (daselt-abv--position-affix-from-coord
                          'verb '(2 -1 -2))))
  ;; Pair (8,7) puts up-/down- on the top and bottom rows of the
  ;; lower layer (layer 7 has no keys there).
  (should (equal "up-" (daselt-abv--position-affix-from-coord
                        'verb '(8 -1 -2))))
  (should (equal "down-" (daselt-abv--position-affix-from-coord
                          'verb '(8 1 -2))))
  (should (equal "up-" (daselt-abv--position-affix-from-coord
                        'noun '(8 -1 2))))
  (should (equal "down-" (daselt-abv--position-affix-from-coord
                          'noun '(8 1 2))))
  (should (equal "un-" (daselt-abv--position-affix-from-coord
                        'verb '(8 0 -2))))
  ;; Type pairs without pair entries are unchanged on pair (5,6).
  (should (equal "-ize" (daselt-abv--position-affix-from-coord
                         'noun '(5 -1 -2))))
  ;; Adjective -> adjective has no row-1 entry on pair (5,6): the
  ;; all-pairs entry still applies there.
  (should (equal "un-" (daselt-abv--position-affix-from-coord
                        'adjective '(5 -1 -1))))
  (should (equal "over-" (daselt-abv--position-affix-from-coord
                          'adjective '(5 1 -1)))))

;;;; abv-layout-inflection-info specializations

(ert-deftest daselt-abv-inflection-info-noun-empty-data ()
  "Empty DATA returns nil for noun inflection."
  (let ((layout daselt-abv--default-layout))
    (should (null (abv-layout-inflection-info layout 'noun "" nil)))))

(ert-deftest daselt-abv-inflection-info-adjective-empty-data ()
  "Empty DATA returns nil for adjective inflection."
  (let ((layout daselt-abv--default-layout))
    (should (null (abv-layout-inflection-info layout 'adjective "" nil)))))

(ert-deftest daselt-abv-inflection-info-adverb-empty-data ()
  "Empty DATA returns nil for adverb inflection."
  (let ((layout daselt-abv--default-layout))
    (should (null (abv-layout-inflection-info layout 'adverb "" nil)))))

(ert-deftest daselt-abv-inflection-info-determiner-empty-data ()
  "Empty DATA returns nil for determiner inflection."
  (let ((layout daselt-abv--default-layout))
    (should (null (abv-layout-inflection-info layout 'determiner "" nil)))))

(ert-deftest daselt-abv-inflection-info-verb-empty-data ()
  "Empty DATA returns nil for verb inflection."
  (let ((layout daselt-abv--default-layout))
    (should (null (abv-layout-inflection-info layout 'verb "" nil)))))


;;;; Word-type decoding

(ert-deftest daselt-abv-word-type-from-coord ()
  "`word-type-from-coord' decodes word type from column."
  (should (eq 'pronoun (daselt-abv--word-type-from-coord '(1 0 -3))))
  (should (eq 'verb (daselt-abv--word-type-from-coord '(1 0 -2))))
  (should (eq 'adjective (daselt-abv--word-type-from-coord '(1 0 -1))))
  ;; Column 0 has no word-type.
  (should (null (daselt-abv--word-type-from-coord '(1 0 0))))
  (should (eq 'adverb (daselt-abv--word-type-from-coord '(1 0 1))))
  (should (eq 'noun (daselt-abv--word-type-from-coord '(1 0 2))))
  (should (eq 'determiner (daselt-abv--word-type-from-coord '(1 0 3)))))

(ert-deftest daselt-abv-word-type-from-string-empty ()
  "`abv-layout-word-type-from-string' returns nil for empty string."
  (let ((layout daselt-abv--default-layout))
    (should (null (abv-layout-word-type-from-string layout "" nil)))))


;;;; Conversion-method table

(ert-deftest daselt-abv-conversion-method-table-known-entries ()
  "`daselt-abv--conversion-method-table' has the known source types."
  (let ((keys (mapcar #'car daselt-abv--conversion-method-table)))
    (should (member '(verb . noun) keys))
    (should (member '(noun . verb) keys))
    (should (member '(adjective . noun) keys))
    (should (member '(adjective . adverb) keys))))

(ert-deftest daselt-abv-conversion-method-from-coord-verb-to-noun ()
  "`conversion-method-from-coord' decodes suffixes for verb->noun.

The original implementation used `assq' on a table whose keys are
cons cells; `assq' compares by `eq', which never matched a freshly
consed pair.  It now compares with `equal', so decoding works."
  ;; to-type is noun -> col=2; row=0; higher lower layer 8 -> "-ion".
  (should (equal "-ion"
                 (daselt-abv--conversion-method-from-coord 'verb '(8 0 2)))))

(ert-deftest daselt-abv-conversion-method-from-coord-first-layer-default ()
  "First-layer keys request the word's stored conversion-default.
With CONVERSION-DEFAULT non-nil it is returned verbatim, even a
full word; without one nil is returned, so the expansion consults
the language's regex-matched conversion suffix
\(`abv-language-conversion-suffix-match') and the language's own
conversion before resorting to the key's position affix
\(`daselt-abv--position-affix-from-coord')."
  ;; No stored default: first-layer keys decode no affix.
  (should (null (daselt-abv--conversion-method-from-coord 'verb '(1 0 2))))
  (should (null (daselt-abv--conversion-method-from-coord 'noun '(1 0 -2))))
  ;; Stored default: first-layer keys return it, even a full word.
  (should (equal "ramification"
                 (daselt-abv--conversion-method-from-coord
                  'verb '(1 0 2) "ramification")))
  (should (equal "-ion"
                 (daselt-abv--conversion-method-from-coord
                  'verb '(1 0 2) "-ion")))
  ;; Stored defaults do not override higher-layer explicit affixes.
  (should (equal "-ment"
                 (daselt-abv--conversion-method-from-coord
                  'verb '(8 -1 2) "-ion"))))

(ert-deftest daselt-abv-position-affix-from-coord ()
  "Position affixes decode for every layer, including layer 1.
`daselt-abv--position-affix-from-coord' ignores first-layer
conversion-default semantics; it is the last-resort fallback."
  ;; First-layer keys keep their position affix.
  (should (equal "-ion"
                 (daselt-abv--position-affix-from-coord 'verb '(1 0 2))))
  (should (equal "-ic"
                 (daselt-abv--position-affix-from-coord 'noun '(1 0 -1))))
  ;; Higher layers decode as the conversion method does.
  (should (equal "-ic"
                 (daselt-abv--position-affix-from-coord 'noun '(5 0 -1))))
  (should (equal "-less"
                 (daselt-abv--position-affix-from-coord 'noun '(2 0 -1))))
  ;; No word-type column and unknown from-type: no affix.
  (should (null (daselt-abv--position-affix-from-coord 'verb '(2 0 0))))
  (should (null (daselt-abv--position-affix-from-coord 'gerund '(1 0 2)))))

(ert-deftest daselt-abv-effective-conversion-method-chain ()
  "First-layer triggers resolve default > regex match > language.
The first-layer adjective key \"o\" (row 0, col -1) yields the
word's stored conversion-default when set, else the English
regex-matched suffix (doctor -> -al); without either, nil is
returned so the expansion defers to the language's own
conversion (`abv-syntax-convert-word': dictionary-validated smart
conversion, regex fallback), never to the key's position affix —
a positional guess like -ion must not preempt a validated form
(refine -> refinement, not refinion).  Higher-layer keys keep
their explicit affix."
  (require 'abv-english)
  (skip-unless (and (boundp 'daselt-abv--default-layout)
                    daselt-abv--default-layout))
  (let* ((layout daselt-abv--default-layout)
         (syntax (make-instance 'abv-syntax))
         (language abv-english-default))
    ;; postdoctor: noun, no stored default; its ending matches the
    ;; doctor -> -al regex in `abv-english-conversion-methods'.
    (abv-syntax-put-word syntax "postdoctor" 'noun)
    (should (equal "-al"
                   (abv-syntax--effective-conversion-method
                    syntax "postdoctor" 'adjective layout "o" language)))
    ;; A stored conversion-default wins over the regex match.
    (abv-syntax-add-conversion-default syntax "postdoctor" 'adjective "-ary")
    (should (equal "-ary"
                   (abv-syntax--effective-conversion-method
                    syntax "postdoctor" 'adjective layout "o" language)))
    ;; No regex match and no default: nil — the language's own
    ;; conversion answers, so the key's position affix (-ion)
    ;; must not be returned.
    (abv-syntax-put-word syntax "adopt" 'verb)
    (should (null (abv-syntax--effective-conversion-method
                   syntax "adopt" 'noun layout "t" language)))
    ;; First-layer nominalization defers to the language's answer:
    ;; refine -> refinement (with a usable dictionary via the
    ;; validated smart conversion, without one via the empty-regex
    ;; -ment fallback) — never the mechanical refinion the row-0
    ;; position affix -ion would produce.
    (abv-syntax-put-word syntax "refine" 'verb)
    (should (null (abv-syntax--effective-conversion-method
                   syntax "refine" 'noun layout "t" language)))
    (should (equal "refinement"
                   (abv-syntax-convert-word
                    syntax "refine" 'noun language)))
    ;; Higher-layer keys keep their explicit affix regardless.
    (should (equal "-less"
                   (abv-syntax--effective-conversion-method
                    syntax "postdoctor" 'adjective layout "O" language)))))

(ert-deftest daselt-abv-conversion-method-from-coord-higher-layers ()
  "Higher-layer keys decode the default affixes by row and layer.
Lower higher-layer 5 row 0 -> \"-ic\"; upper higher-layer 2
row 0 -> \"-less\" for noun->adjective."
  (should (equal "-ic"
                 (daselt-abv--conversion-method-from-coord 'noun '(5 0 -1))))
  (should (equal "-less"
                 (daselt-abv--conversion-method-from-coord 'noun '(2 0 -1)))))

(ert-deftest daselt-abv-conversion-method-from-coord-no-to-type ()
  "When coord has no word-type, returns nil."
  (should (null (daselt-abv--conversion-method-from-coord 'verb '(2 0 0)))))

(ert-deftest daselt-abv-conversion-method-from-coord-unknown-from-type ()
  "Unknown from-type returns nil."
  (should (null (daselt-abv--conversion-method-from-coord 'gerund '(1 0 2)))))

(ert-deftest daselt-abv-conversion-method-from-string-empty ()
  "`abv-layout-conversion-method-from-string' returns nil for empty string."
  (let ((layout daselt-abv--default-layout))
    (should (null (abv-layout-conversion-method-from-string
                   layout "" nil 'verb)))))

(ert-deftest daselt-abv-conversion-method-adjective-adverb-defers-to-language ()
  "Adjective->adverb keys decode no affix on any layer.
English adverbialization (-ly with its -y/-ally orthographic
variants and per-word conversion-defaults like good -> well) is
entirely handled by the language layer, so no key position may
override it with an explicit affix (regression: the row-0 keys
decoded \"-wise\", turning quick into quickwise)."
  ;; No position affix on any layer, including the first.
  (should (null (daselt-abv--position-affix-from-coord
                 'adjective '(1 -1 1))))
  (should (null (daselt-abv--position-affix-from-coord
                 'adjective '(1 0 1))))
  (should (null (daselt-abv--position-affix-from-coord
                 'adjective '(4 0 1))))
  ;; Higher layers decode no conversion method either.
  (should (null (daselt-abv--conversion-method-from-coord
                 'adjective '(4 0 1))))
  ;; First-layer keys still return a stored conversion-default.
  (should (equal "well"
                 (daselt-abv--conversion-method-from-coord
                  'adjective '(1 0 1) "well")))
  ;; Noun->adverb keys keep their explicit affixes.
  (should (equal "-ly"
                 (daselt-abv--position-affix-from-coord
                  'noun '(1 -1 1))))
  (should (equal "-wise"
                 (daselt-abv--position-affix-from-coord
                  'noun '(1 0 1)))))

(ert-deftest daselt-abv-adjective-adverb-expansion ()
  "Every adverb-column trigger converts adjectives correctly.
The expansion flow (stored default > language regex match >
language conversion, with the key's position affix only as the
last resort, as in `abv-syntax--effective-conversion-method' and
the distill expansion) must yield the dictionary adverb for every
key of the adverb column, on every layer."
  (require 'abv-english)
  (skip-unless (and (boundp 'daselt-abv--default-layout)
                    daselt-abv--default-layout))
  (let* ((layout daselt-abv--default-layout)
         (syntax (make-instance 'abv-syntax))
         (language abv-english-default)
         (pairs '(("quick" . "quickly")
                  ("happy" . "happily")
                  ("simple" . "simply")
                  ("tragic" . "tragically")
                  ("public" . "publicly")))
         triggers)
    ;; Collect every printable char whose column decodes to 'adverb.
    (dotimes (i 127)
      (let ((coord (daselt-abv--char-coord layout i)))
        (when (and coord (= 1 (daselt-abv--coord-col coord)))
          (push (string i) triggers))))
    (should triggers)
    (dolist (pair pairs)
      (abv-syntax-put-word syntax (car pair) 'adjective)
      (dolist (trigger triggers)
        (let* ((method (abv-syntax--effective-conversion-method
                        syntax (car pair) 'adverb layout trigger language))
               (converted (if method
                              (abv-syntax-convert-word-with-method
                               syntax (car pair) 'adverb language method)
                            (abv-syntax-convert-word
                             syntax (car pair) 'adverb language))))
          (should (equal (cdr pair) converted)))))
    ;; A stored conversion-default wins from every adverb key for a
    ;; word without a language regex match (quick); public's ^public$
    ;; regex match outranks a stored default on higher-layer keys by
    ;; the documented `abv-syntax--effective-conversion-method' order.
    (abv-syntax-put-word syntax "quick" 'adjective)
    (abv-syntax-add-conversion-default syntax "quick" 'adverb "well")
    (dolist (trigger triggers)
      (should (equal "well"
                     (abv-syntax-convert-word-with-method
                      syntax "quick" 'adverb language
                      (abv-syntax--effective-conversion-method
                       syntax "quick" 'adverb layout trigger language)))))))


(provide 'daselt-abv-inflection-tests)
;;; daselt-abv-inflection-tests.el ends here
