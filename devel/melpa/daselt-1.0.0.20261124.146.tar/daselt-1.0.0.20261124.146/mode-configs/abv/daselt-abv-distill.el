;;; daselt-abv-distill.el --- Daselt abv distillation algorithm  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; License: GPL-3+

;;; Commentary:

;; Distillation module for the Daselt abv integration.  Implements
;; the multi-word variation distillation strategy: choosing morph
;; sequence candidates that map to unique typing strings, with
;; single-word and multi-word handling, collision recovery and the
;; embellished-sequence-string fallback used by the distillate
;; registration step.

;;; Code:

(require 'daselt-abv-layout)
(require 'daselt-abv-typing)
(require 'abv-language-table)
(require 'cl-lib)

(require 'abv-sublingual-table)
(require 'abv-emacs-lisp-mode-table)

(declare-function abv-distillate-sequence-unique-p
                  "abv-language-table-distill" (seq table &optional reset))
(declare-function abv-language-table-distillation-choice-sequence
                  "abv-language-table-distill" (seq table &optional words))

(define-inline daselt-abv--same-word-variant-p (seq-a seq-b)
  "Return non-nil when SEQ-A and SEQ-B analyze the same word.
Two sequences count as the same word when they are equal after
dropping morph-separator cells from both: the hyphenated spelling
of a compound (\"sub-sheaf\") and its un-separated variant
(\"subsheaf\") share every other morph, so a distillate registered
for one is not a collision for the other — it is the same entry."
  (inline-letevals (seq-a seq-b)
    (inline-quote
     (let ((a ,seq-a) (b ,seq-b))
       (if (not (and (listp a) (listp b)))
           nil
         (let ((same t))
           (while (and same (or (consp a) (consp b)))
             (while (and (consp a)
                         (eq (cdr (car a)) 'morph-separator))
               (setq a (cdr a)))
             (while (and (consp b)
                         (eq (cdr (car b)) 'morph-separator))
               (setq b (cdr b)))
             (if (and (consp a) (consp b))
                 (progn
                   (unless (equal (car a) (car b))
                     (setq same nil))
                   (setq a (cdr a))
                   (setq b (cdr b)))
               (setq same nil)))
           same))))))
(cl-defun daselt-abv--exit-if-suitable (full-cand+pos table layout &key rep? max?
                                                       )
                                    "Throw found-distillate if FULL-CAND+POS is
                                    unique and suitable.

Evaluates against TABLE and LAYOUT. REP? indicates if the sequence is
representable, and MAX? indicates if a maximal check is required.
A distillate must contain a root or a name cell (whose name-table
key makes it distinctive on its own)."
                                    (and-let* ((lang (oref table language))
              (full-cand (mapcar #'car (sort full-cand+pos :key #'cdr)))
              (cand-str (abv-typed-layout-morph-sequence-string full-cand layout lang))
              (seq-contains-root (cl-some (lambda (morph)
                                            (memq (cdr morph) '(root name)))
                                          full-cand))
             (seq-unique (abv-distillate-sequence-unique-p full-cand table))
             (str-unique-or-maximal
              (or (not rep?)
                  (let ((existing (gethash cand-str (oref (oref table caches)
                                                          reverse-distillate-strings-cache))))
                    (or (not existing)
                        max?))))
             (is-free (and seq-unique str-unique-or-maximal)))
    (throw 'found-distillate full-cand+pos)))



(cl-defun daselt-abv--try-cands
                                            (rseq choice table layout &key context variants continue rep? (first-prefix nil))
                      "Recursively try candidate variations for RSEQ using
                      CHOICE on LAYOUT.

TABLE is the `abv-language-table'. CONTEXT and VARIANTS track the ongoing
combination state. CONTINUE and REP? govern whether the algorithm should stop
after the first unique candidate or exhaust variations. FIRST-PREFIX, when
non-nil, restricts the prefix-run subsets to those containing the first
prefix cell, so the leading prefix morph survives in every candidate
\(package-prefixed symbols keep a recognizable leading prefix). Return a list of valid
morph sequence candidate variants."
                        (let* ((binding-specs
             (mapcar
              (lambda (type)
                (let ((cells-of-type
                       (cl-remove-if-not
                        (lambda (morph-idx)
                          (eq type (cdar morph-idx)))
                        choice)))
                  (when cells-of-type
                    (cons cells-of-type type))))
              '(formal morph-separator infix prefix suffix root name)))
           (formal+pos+type (nth 0 binding-specs))
           (morph-separators+pos+type (nth 1 binding-specs))
           (infixes+pos+type (nth 2 binding-specs))
           (prefixes+pos+type (nth 3 binding-specs))
           (suffixes+pos+type (nth 4 binding-specs))
           (roots+pos+type (nth 5 binding-specs))
           (names+pos+type (nth 6 binding-specs))
           (new-run-bindings
            (remq nil
                  (mapcar
                   (lambda (affixes+pos+type)
                                         (when affixes+pos+type
                       (let* ((binds-of-type (abv-morph-powerlist (car affixes+pos+type)))
                              (binds-of-type
                               (if (and first-prefix
                                        (eq (cdr affixes+pos+type) 'prefix)
                                        (car affixes+pos+type))
                                   ;; Keep only subsets that retain the
                                   ;; leading (earliest-position) prefix
                                   ;; cell; the full run is the last
                                   ;; powerlist entry, so the fallback
                                   ;; branch below always finds one.
                                   (cl-remove-if-not
                                    (lambda (subset)
                                      (memq (car (car affixes+pos+type))
                                            subset))
                                    binds-of-type)
                                 binds-of-type)))
                         (if (memq (cdr affixes+pos+type) '(root name))
                                                                     (remq nil binds-of-type)
                                               binds-of-type))))
                   `(,formal+pos+type ,morph-separators+pos+type
                                      ,infixes+pos+type ,prefixes+pos+type
                                      ,(cons (nreverse
                                              (car suffixes+pos+type))
                                             (cdr suffixes+pos+type))
                                      ,roots+pos+type ,names+pos+type))))
           new-variants)

    (named-let recur ((runlist nil)
                      (run-bindings new-run-bindings)
                      (rep? rep?)
                      (max? (not continue)))

      (if run-bindings
                                                  (let  ((possible-subsets (car run-bindings))
                 (future-variations (cdr run-bindings)))

            (cl-loop for type-subset in possible-subsets
                     do (let ((new-runlist (append runlist type-subset)))
                          (recur new-runlist future-variations rep? nil))
                     finally do (if max?
                                                                            (let ((new-runlist (append runlist (car (last possible-subsets)))))
                                      (recur new-runlist future-variations rep? t)))))

        (let* ((cand-seq runlist)
               (full-cand+pos (and cand-seq (car cand-seq)
                                   (cl-union cand-seq context :test #'equal))))
          (when (and full-cand+pos (not (equal full-cand+pos context)))
            (daselt-abv--exit-if-suitable
             cand-seq table layout :rep? rep? :max? max?)
            (push full-cand+pos new-variants)))))

    (if continue
                                                new-variants
                          (if (abv-rich-morph-sequence-representable? rseq)
                                                  (progn
                                (setf (abv-rich-morph-sequence-representable? rseq)
                  nil)

                                (named-let recur ((runlist nil)
                              (run-bindings new-run-bindings)
                              (rep? nil)
                              (variants variants))

              (if run-bindings
                                                          (let ((possible-subsets (car run-bindings))
                        (future-variations (cdr run-bindings)))

                    (dolist (type-subset possible-subsets)
                      (let ((new-runlist (append runlist type-subset)))
                        (recur new-runlist future-variations rep? variants))))

                  (let* ((cand-seq runlist)
                         (full-cand+pos (cl-union cand-seq context :test #'equal))
                         (variants (push cand-seq variants)))

                    (daselt-abv--exit-if-suitable
                     full-cand+pos table layout
                     :rep? nil)

                    variants))))
        (error
         "Morph-sequence collision in %s, use\n
`abv-edit-morph-sequence-collisions' or similar"
         (or (ignore-errors (oref table name)) table)))))
                      )


(defun daselt-abv--handle-distillate-collision (table layout caches seq
                                                      already-distillate lang)
  "Handle a collision where SEQ is already the distillate of ALREADY-DISTILLATE.

Prompt the user for action. Return non-nil if distillation for SEQ should be
skipped.  In batch mode (see `noninteractive') no prompt is possible: the
collision is accepted (the [a]nyway answer) so unattended
`abv-add-words' batches never block."
  (if noninteractive
      nil
    (let ((choice (read-char-choice
                   (format "Sequence %s is already the distillate of %s. [q]uit, [a]nyway, [r]e-distill other? "
                           seq already-distillate)
                   '(?q ?a ?r)))
          (skip-distillation nil))
    (pcase choice
      (?q (setq skip-distillation t)
          (user-error "Distillation aborted"))
      (?a nil)
      (?r
       (setq skip-distillation nil)
       (let* ((oa (oref table obarray))
              (hoa (and (slot-boundp table 'hidden-obarray) (oref table hidden-obarray)))
              (seq2-sym (cl-some (lambda (oar)
                                   (and (obarrayp oar)
                                        (catch 'found
                                          (mapatoms (lambda (s)
                                                      (when (equal (get s :morph-sequence) already-distillate)
                                                        (throw 'found s)))
                                                    oar))))
                                 (list oa hoa)))
              (word-seq (and seq2-sym (get seq2-sym :word-sequence)))
              (comp-str (and seq2-sym (symbol-value seq2-sym)))
              (key-str (and seq2-sym (symbol-name seq2-sym)))
              (rseq2
               ;; (abv-language-table--find-rich-sequence
               ;;  already-distillate
               ;;  (oref caches table-rich-morph-sequence-cache))
               (make-abv-rich-morph-sequence
                :morph-sequence already-distillate
                 :abstraction (abv-language-sequence-abstraction already-distillate lang :refresh t)
                :representable? t
                :word-sequence word-seq
                :composite-string comp-str
                :key-string key-str)))
          (if rseq2
              (abv-language-table-rebind-sequences table layout (list rseq2) :reset t)
            (message "Could not find rich sequence for %s" already-distillate))

         (remhash already-distillate (oref table distillate))
         (remhash seq (oref caches reverse-distillate-cache)))))
      skip-distillation)))


(defun daselt-abv--find-distillate-candidate (rseq table layout
                                                   lang word-separator-regexp
                                                   sym seq rep? beginning-only directed-only
                                                   &optional first-prefix)
                "Find and return the final distillation candidate for RSEQ.

This function handles both single-word and multi-word morph sequences.
FIRST-PREFIX keeps a word's leading prefix cell in every candidate
\(see `daselt-abv--try-cands')."
                (if (= 1 (length seq))
                                  (mapcar (lambda (morph) (cons morph 0)) seq)
                  (let* ((words (abv-language-table-sequence-words-layout rseq table word-separator-regexp))
           (single-word? (or (not words) (= (length words) 1)))
           (choice (if single-word?
                                                   (abv-language-table-distillation-choice-sequence rseq table (unless single-word? words))))
           (sorted-words (and words (abv-language-table-sort-words words table)))
           (caches (oref table caches))
           (already-distillate (or (gethash (mapcar #'car choice) (oref caches reverse-distillate-cache))))
           skip-distillation)

      (when (and already-distillate
                 (not (daselt-abv--same-word-variant-p
                       seq already-distillate)))
        (setq skip-distillation
              (daselt-abv--handle-distillate-collision
               table layout caches (mapcar #'car choice) already-distillate lang)))

      (unless skip-distillation
        (catch 'found-distillate
          (if single-word?
                                          (daselt-abv--try-cands rseq choice table layout :rep? rep? :first-prefix first-prefix)
                          (let (prior-variants)
              (cl-loop for word-num from 0 to (1- (length sorted-words))
                       do (let* ((word-plist (nth word-num sorted-words))
                                 (word-morph-seq (plist-get word-plist :morphs))
                                 (word-string (plist-get word-plist :string))
                                 (word-beginning (car (plist-get word-plist :morph-positions)))
                                 (rich-word-morph-seq (make-abv-rich-morph-sequence
                                                       :morph-sequence word-morph-seq
                                                       :composite-string word-string
                                                       :word-sequence (list word-plist)))
                                 (word-dist (mapcar (lambda (cns)
                                                                    (cons (car cns) (+ word-beginning (cdr cns))))
                                                    (or (abv-language-table-get-distillate-sequence table word-morph-seq t)
                                                        (and (if (string-match-p
                                                                  (abv-rx-to-string lang (abv-script-combined-separator-rx lang '(ms)))
                                                                  word-string)
                                                                                             (if sym
                                                                                                 (error "Word \"%s\" in word-sequence of symbol \"%s\" contains a word-separator" word-string sym)
                                                                                 (error "Word \"%s\" contains a word-separator" word-string))
                                                                (abv-distill table layout :initial-level nil :sync t :beginning-only beginning-only :directed-only directed-only :re-distill nil :rseqs (list rich-word-morph-seq) :first-prefix first-prefix))
                                                             (abv-language-table-get-distillate-sequence table word-morph-seq t)))))
                                 (firsts-of-others (mapcar (lambda (plist)
                                                                           (cons (car (plist-get plist :morphs))
                                                                   (car (plist-get plist :morph-positions))))
                                                             (cl-subseq sorted-words (1+ word-num)))))
                            (setq choice (append choice word-dist))
                            (setq prior-variants
                                  (if prior-variants
                                                                  (apply #'append
                                             (cl-loop for var in prior-variants
                                                      collect (daselt-abv--try-cands
                                                               rich-word-morph-seq word-dist table layout
                                                               :context (or var firsts-of-others)
                                                               :continue t :rep? rep? :first-prefix first-prefix)))
                                    (daselt-abv--try-cands
                                     rich-word-morph-seq word-dist table layout
                                     :context firsts-of-others :continue t :rep? rep? :first-prefix first-prefix))))
                       finally do (progn
                                                  (setq choice (append choice (remq nil (cl-mapcar (lambda (morph idx)
                                                                                                     (if (eq 'formal (cdr morph))
                                                                                                                       (cons morph idx)))
                                                                                     seq (daselt-base-cardinal (length seq))))))
                                                  (daselt-abv--try-cands rseq choice table layout :rep? rep? :first-prefix first-prefix))))))))))
(cl-defun daselt-abv--distill-helper (table layout &key status-symbol re-distill
                                            beginning-only directed-only rseqs
                                            (initial-level t) no-cache-refresh reset
                                            first-prefix)
      "Helper for `abv-distill' to run in a thread.

This function encapsulates the core logic of the Daselt-specific distillation
algorithm. It processes all sequences in TABLE, generating distillates based on
multi-word variation.

RE-DISTILL, if non-nil, forces re-computation. STATUS-SYMBOL is an optional
progress tracker for `abv-run-in-background'.

If RESET, reset the given RSEQS but don't clear out the previous distillate.

FIRST-PREFIX keeps a word's leading prefix cell in every distillate
candidate \(see `daselt-abv--try-cands')."
      (if initial-level (message "Starting Daselt distillation for table %s..." (oref table name)))

      (when (or re-distill (and reset (not rseqs)))
    (oset table distillate (make-hash-table :test 'equal))
    (setq daselt-abv-undistilled nil))

      (let* ((stats (abv-language-read-statistics table layout))
         (lang (oref table language))
         (script (oref lang script))
         (word-separator-regexp (abv-rx-to-string lang (abv-script-combined-separator-rx script '(ms))))
         (caches (if (and initial-level (not no-cache-refresh))
                             (abv-language-table-set-distillation-caches table layout :statistics stats :rseqs rseqs :re-distill re-distill :reset reset)
                       (oref table caches)))
         (new-rich (if (or (not rseqs)
                           (and initial-level (not no-cache-refresh)))
                               (oref caches new-rich-morph-sequence-cache)
                         rseqs))
         (overall-count (length new-rich))
         (current-count 0)
         distillate
         undistilled?)

    (when status-symbol
      (setf (slot-value status-symbol 'target-count) overall-count)
      (setf (slot-value status-symbol 'current-type) "distilling"))

    ;; 1. Partition sequences into representable and non-representable using the cue-table for 3-letter words.
    (dolist (rseq new-rich)
      (when (and-let* ((abv-rich-morph-sequence-representable? rseq)
                       (comp-str (abv-rich-morph-sequence-composite-string rseq))
                       (seq (abv-rich-morph-sequence-morph-sequence rseq))
                       (long-enough (>= (length comp-str)
                                        abv-language-table-min-word-length))))
        (setf (abv-rich-morph-sequence-representable? rseq) t)))

    ;; 2. Process all sequences in a single, globally sorted pass.
    ;; Processed sequences are removed from the new-rich cache in
    ;; one final pass (equivalent to deleting each after its turn,
    ;; also when an error interrupts the run midway).
    (let ((processed (make-hash-table :test #'eq)))
      (unwind-protect
          (dolist (rseq new-rich)

      (setq undistilled? nil)
      (let ((seq (abv-rich-morph-sequence-morph-sequence rseq)))
        (unless reset
          (setq distillate (abv-language-table-get-distillate-sequence table seq)))

        (or distillate ; If we already have a distillate, we can return immediately.
            (let* ((key (abv-rich-morph-sequence-key-string rseq))
                   (sym (and (stringp key)
                             (intern-soft key (oref table obarray))))
                   (final-candidate nil)
                   (rep? (abv-rich-morph-sequence-representable? rseq))
                    (already-distillate (or (gethash seq (oref caches reverse-distillate-cache))))
                    (skip-distillation nil))

              ;; A reverse-cache hit is only a collision when the
              ;; distillate belongs to a DIFFERENT word: the
              ;; hyphenated and un-separated spellings of one
              ;; compound share their distillate by construction and
              ;; must not prompt.
              (when (and already-distillate
                         (not (daselt-abv--same-word-variant-p
                               seq already-distillate)))
                (setq skip-distillation
                      (daselt-abv--handle-distillate-collision
                       table layout caches seq already-distillate lang)))

              (if skip-distillation
                          (progn
                        (push rseq daselt-abv-undistilled)
                        (setq undistilled? t))

                (setq final-candidate (daselt-abv--find-distillate-candidate
                                       rseq table layout lang word-separator-regexp
                                       sym seq rep? beginning-only directed-only
                                       first-prefix))

                ;; 3. Get positions and register the distillate.
                (if final-candidate
                            (let ((positions (sort (mapcar #'cdr final-candidate))))
                      (abv-language-table-register-distillate
                       table (abv-rich-morph-sequence-morph-sequence rseq) positions layout rep? sym))
                  (push rseq daselt-abv-undistilled)
                  (setq undistilled? t))))))

      (when status-symbol
        (cl-incf (slot-value status-symbol 'current-count)))

      (cl-incf current-count)
      (if initial-level (message (if undistilled? " \"%s\" could not be distilled, %s of %s complete."
                                   "Distilled \"%s\", %s of %s complete.")
                                 (and (abv-rich-morph-sequence-composite-string rseq)
                                      (abv-rich-morph-sequence-composite-string rseq))
                                 current-count overall-count))

      (puthash rseq t processed))
        (oset caches new-rich-morph-sequence-cache
              (cl-delete-if (lambda (x) (gethash x processed))
                            (oref caches new-rich-morph-sequence-cache))))))

      (if initial-level (message "Daselt distillation complete for table %s." (oref table name)))

      (if rseqs
              (abv-language-table-get-distillate-sequence table (car rseqs))
        table))

(cl-defmethod abv-distill ((table abv-sublingual-table) (layout daselt-abv-layout)
                           &rest args &key rseqs &allow-other-keys)
  "Distill TABLE, but never sequences the parent table covers.

Items whose expansion the parent language table already holds must not gain
abbreviations in the sublingual table: the parent abbreviation remains
authoritative for them. When RSEQS is non-nil, every rich sequence covered by
the parent (see `abv-sublingual-table--filter-parent-rseqs') is removed before
the rest reaches `cl-call-next-method'; dropped sequences are reported in the
echo area. A covered sequence is dropped only when the parent (or TABLE
itself) actually supplies a distillate for it: a parent word that was never
distilled cannot donate one, and multi-word composition (see
`daselt-abv--find-distillate-candidate') needs the component's distillate
registered locally to distill the composed sequence at all. Such sequences are
kept in the distillation set — they still never gain an abbreviation of their
own, since binding is guarded by `abv-language-table-rebind-rseqs'. When
nothing remains to distill, distillation is skipped and the distillate of the
first original sequence is returned, looked up via
`abv-language-table-get-distillate-sequence' and thus usually found in the
parent. RSEQS nil (distill the whole table) is passed on unchanged, since
whole-table runs rely on parent words having been removed from the table
beforehand."
  (let ((parent (abv-sublingual-table--parent table)))
    (if (or (null rseqs) (not (abv-language-table-p parent)))
        (apply #'cl-call-next-method table layout args)
      (let* ((split (abv-sublingual-table--filter-parent-rseqs rseqs parent))
             (covered (cdr split))
             (distilled-p
              (lambda (rseq)
                (abv-language-table-get-distillate-sequence
                 table (abv-plain-sequence rseq))))
             (drop (cl-remove-if-not distilled-p covered))
             (keep (append (car split) (cl-remove-if distilled-p covered))))
        (when drop
          (message "Skipping distillation of %d sequence(s) covered by `%s'"
                   (length drop) (oref parent name)))
        (if keep
            (apply #'cl-call-next-method table layout
                   (plist-put (copy-sequence args) :rseqs keep))
          (message "All sequences covered by `%s'; nothing to distill"

                   (oref parent name))
          (abv-language-table-get-distillate-sequence table (car rseqs)))))))

(cl-defmethod abv-distill ((table abv-language-table) (layout daselt-abv-layout)
                           &key (sync t) re-distill (beginning-only t) (directed-only t) rseqs (initial-level t) no-cache-refresh reset first-prefix)
        "Daselt-specific distillation algorithm using multi-word variation.

This method implements the oplax distillation strategy. It processes all
sequences in a stable, length-sorted order.

For multi-word sequences, it varies one word at a time (in importance order),
keeping other words fixed to their `first-choice' morph. Candidates are
generated for the active word using its co-atoms and affix combinations.
Uniqueness is always tested on the full candidate sequence.

Representable sequences must yield unique distillate strings, while
non-representable ones do not, though uniqueness is still preferred.

When SYNC is nil, this operation runs in the background.
FIRST-PREFIX keeps a word's leading prefix cell in every distillate."
        (if sync
                  (daselt-abv--distill-helper table layout :rseqs rseqs :re-distill re-distill :beginning-only beginning-only :directed-only directed-only :initial-level initial-level :no-cache-refresh no-cache-refresh :reset reset :first-prefix first-prefix)
          (let* ((lang (oref table language))
           (lname (and lang (oref lang name)))
           (status-symbol (intern (format "abv-progress-distill-%s-%s-%s"
                                          (oref table name)
                                          (oref layout name)
                                          lname))))
      (eval `(progn
                     (defvar ,status-symbol nil
                       ,(format "Progress status for distilling table %s with layout %s for language %s."
                          (oref table name)
                          (oref layout name)
                          lname))
                     (abv-run-in-background
                               ,status-symbol
                       (daselt-abv--distill-helper ,table ,layout :status-symbol ,status-symbol :beginning-only ,beginning-only :directed-only ,directed-only :reset ,reset :first-prefix ,first-prefix)))))))

;;;; Emacs-Lisp programming tables keep their first prefix

(cl-defmethod abv-distill ((table abv-emacs-lisp-mode-table)
                           (layout daselt-abv-layout)
                           &rest args &key &allow-other-keys)
  "Distill the Emacs-Lisp TABLE keeping the first prefix.
The layout methods of `abv-distill' specialize on layout
subclasses incomparable with the table specializers of
`abv-emacs-lisp-mode-table', so the Daselt layout needs this
explicit specialization to run before the generic one."
  (apply #'cl-call-next-method table layout
         (plist-put (copy-sequence args) :first-prefix t)))

;;;; Search-ring helpers used by the embellished-sequence-string method

;; `my-one-hot' and `daselt-abv--make-search-rings' moved to
;; `daselt-abv-typing.el' (next to their only caller): this module
;; requires that one, not the other way around, so defining them
;; there keeps the ring search working even when only the typing
;; module is loaded.







(provide 'daselt-abv-distill)
;;; daselt-abv-distill.el ends here
