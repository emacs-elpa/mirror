;;; daselt-abv-typing.el --- Daselt abv assignments and typings  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; License: GPL-3+

;;; Commentary:

;; Assignment, typing-graph construction and morph-sequence string
;; rendering for the Daselt abv integration.  Implements
;; `daselt-abv--assign-one', `abv-typed-layout-type-root',
;; `abv-set-typings' specializations, the
;; `abv-typed-layout-morph-sequence-string',
;; `abv-typed-layout-exchange-characters-in-graph' and
;; `abv-typed-layout-morph-typing-string' methods.

;;; Code:

(require 'daselt-abv-layout)
(require 'daselt-abv-ergonomics)
(require 'abv-language-table)
(require 'abv-corpus-language-statistics)
(require 'abv-morph-sort)
(require 'abv-sublingual-table)

(defun daselt-abv--parent-typing-graphs (layout language)
  "Return the typing graphs of LANGUAGE's ancestor languages.
LANGUAGE may be an `abv-sub-language'; every ancestor language
in its `parent-language' chain contributes the graph filed under
the ancestor's name in LAYOUT, closest parent first.  Plain
languages yield nil."
  (when (object-of-class-p language 'abv-sub-language)
    (let ((graphs nil)
          (seen (make-hash-table :test 'eq))
          (cur language))
      (while (and cur (eieio-object-p cur) (not (gethash cur seen)))
        (puthash cur t seen)
        (let* ((pname (abv-sublingual-table--language-parent-name cur))
               (graph (and layout
                           pname
                           (alist-get pname (oref layout typing-graphs)
                                      nil nil #'string=))))
          (when graph (push graph graphs))
          (setq cur (and pname
                         (abv-sublingual-table--parent-language cur)))))
      (nreverse graphs))))

(declare-function daselt-bind--get-unique-layout-match "daselt-bind")

;;;; Assignment

(defun daselt-abv--typing-value-coords (v)
  "Return the coordinate list of an affix typing value V.
Affix typings are single coordinates; rich values wrapping them
are unwrapped via `abv-plain-value'."
  (let ((plain (if (and (fboundp 'abv-rich-value-p)
                        (abv-rich-value-p v))
                   (abv-plain-value v)
                 v)))
    (if (daselt-coords-p plain) (list plain) nil)))

(cl-defmethod abv-set-typings ((placevals list) (stats list)
                               &key separators table reset morphs letter-freq layout
                               taken-tables)
  "Set typings using PLACEVALS and STATS lists.

Assign affixes to the given placevals according to the sorted frequencies in
STATS. MORPHS overrides STATS if provided. If RESET is nil, skip affixes that
are already present in TABLE.

TAKEN-TABLES is a list of typing tables whose values count as
occupied coordinates: affixes typed here never land on a
coordinate already taken in another graph, e.g. the parent
language's."
  (let* ((affixes (or morphs (mapcar #'car stats)))
         (used-coords (make-hash-table :test 'equal))
         (counts (let ((ht (make-hash-table :test 'equal)))
                   (dolist (tt (delq nil (and taken-tables
                                              (ensure-list taken-tables))))
                     (when (hash-table-p tt)
                       (maphash (lambda (_k v)
                                  (dolist (coord (daselt-abv--typing-value-coords v))
                                    (puthash coord 1 ht)))
                                tt)))
                   ht))
         (placevals-without-separators (daselt-abv--filter-placevals-by-separators placevals separators))
         (univ-h (daselt-abv--placevals->coord-hash placevals-without-separators))
         (lower-paired-without-separators (daselt-abv--filter-to-paired placevals-without-separators))
         (paired-h (daselt-abv--placevals->coord-hash lower-paired-without-separators))
         (compl-h (daselt-abv--complement-hash univ-h paired-h))
         (sorted (if stats
                     (daselt-abv--sorted-affixes-by-frequency affixes stats)
                   affixes))
         (letter-base (daselt-abv--collect-letter-bases placevals))
         results)

    (dolist (afx sorted)
      (unless (and (not reset) (gethash afx table))
        (let* ((coord (daselt-abv--assign-one layout afx paired-h counts letter-base nil separators letter-freq)))
          (when (or (null coord) (gethash coord used-coords))
            (setq coord (daselt-abv--assign-one layout afx compl-h counts letter-base t separators letter-freq)))
          (when coord
            (puthash coord t used-coords)
            (puthash afx coord table)
            (push (cons afx coord) results)))))
    results))


(cl-defmethod abv-set-typings ((layout daselt-abv-layout) (stats list)
                               &key parse-data language morphs reset
                               &allow-other-keys)
  "Set incremental typings for LAYOUT using frequency STATS.

LANGUAGE selects the graph. MORPHS is a list of morph conses to type. This
method delegates to `daselt-abv-set-morph-typings' so roots and affixes use the
same audited argument order."
  (unless language
    (user-error "LANGUAGE is required for incremental Daselt typings"))
  (daselt-abv-set-morph-typings
   layout stats language morphs parse-data reset))

(defun daselt-abv-set-morph-typings (layout stats language morphs
                                            &optional parse-data reset)
  "Set Daselt typings for MORPHS using STATS and LANGUAGE.

This helper is the audited incremental interface for callers that want to avoid
rebuilding the complete typing graph. It updates affix tables with type-specific
frequency lists and types roots with `abv-typed-layout-type-root' using the
graph root table, the statistics shared-affix matrix and LANGUAGE. RESET
controls whether existing entries may be replaced.

For a sub-language the typings go into the language's own
graph (created on demand), and the parent language's graph tables
are handed to the affix and root assignment as taken, so new
typings avoid coordinates already used by the parent graph."
  (let* ((graph (abv-typed-layout-language-typing-graph layout language))
         (separators (and parse-data
                          (daselt-abv--parse-data-separators parse-data))))
    (unless graph
      (if (object-of-class-p language 'abv-sub-language)
          (setq graph (abv-sublingual-table--ensure-typing-graph
                       layout language))
        (user-error "No graph found for %s in %s"
                    (oref language name) (oref layout name))))
    (let* ((parent-graphs (daselt-abv--parent-typing-graphs layout language))
           (affix-result nil)
           (root-result nil))
      (let ((daselt-abv--layout-match-cache (make-hash-table :test 'equal)))
        ;; Type every morph under the form the lookup uses later:
        ;; the language abstraction of the morph (falling back to
        ;; its raw form).  Distillates can carry concrete forms
        ;; (e.g. "serve" threaded from "serv") whose abstraction is
        ;; what `abv-typed-layout-morph-typing' queries, so storing
        ;; the raw form would leave the morph untypeable.
        (cl-flet ((typed-form (morph)
                    (or (ignore-errors
                         (abv-language-abstraction morph language))
                        (car morph))))
          (dolist (type '(prefix suffix infix))
            (and-let* ((placevals (slot-value
                                   layout
                                   (intern (concat (symbol-name type)
                                                   "-placevals"))))
                       (table-symbol (intern (concat (symbol-name type)
                                                     "-table")))
                       (typing-table (and (slot-boundp graph table-symbol)
                                          (slot-value graph table-symbol)))
                       (frequency (cond
                                   ((and (eieio-object-p stats)
                                         (object-of-class-p
                                          stats 'abv-corpus-language-statistics))
                                    (slot-value
                                     stats
                                     (intern (concat (symbol-name type)
                                                     "-frequency"))))
                                   ((listp stats) stats)
                                   (t nil)))
                       (typed-morphs
                        (mapcar #'typed-form
                                (cl-remove-if-not
                                 (lambda (morph)
                                   (and (eq (cdr morph) type)
                                        (or reset
                                            (not (abv-language-abstraction
                                                  morph language)))))
                                 morphs)))
                       (taken (or (delq nil
                                         (mapcar (lambda (g)
                                                   (and (slot-boundp g table-symbol)
                                                        (slot-value g table-symbol)))
                                                 parent-graphs))
                                   ;; Languages without parents have no
                                   ;; taken tables: the empty list is a
                                   ;; valid value there, but a nil
                                   ;; binding would make `and-let*'
                                   ;; abort and silently skip the whole
                                   ;; affix assignment (base languages
                                   ;; then die with "No typing could be
                                   ;; assigned").  The nil element is
                                   ;; dropped by the consumer's delq.
                                   '(nil))))
              (push (cons type
                          (abv-set-typings
                           placevals
                           (daselt-abv--normalize-frequencies frequency)
                           :separators separators
                           :table typing-table
                           :morphs typed-morphs
                           :reset reset
                           :layout layout
                           :taken-tables taken))
                    affix-result)))
          (dolist (morph (cl-remove-if-not
                          (lambda (cell) (eq (cdr cell) 'root))
                          morphs))
            (let ((form (typed-form morph)))
              (push (cons form
                          (abv-typed-layout-type-root
                           layout form (oref graph root-table)
                           separators
                           (ignore-errors
                            (oref stats shared-affix-frequencies))
                           language nil
                           :reset reset
                           :taken-tables
                           (delq nil
                                 (mapcar (lambda (g)
                                           (and (slot-boundp g 'root-table)
                                                (oref g root-table)))
                                         parent-graphs))))
                    root-result)))
          (cons (cons 'root (nreverse root-result))
                (nreverse affix-result)))))))

(cl-defmethod abv-set-typings ((layout daselt-abv-layout)
                               (stats abv-corpus-language-statistics)
                               &key parse-data graph (sync t) (reset t)
                               language morphs table &allow-other-keys)
  "Build a morph-sign-graph from STATS and add it to LAYOUT.

PARSE-DATA is an optional `abv-parse-data' instance; if provided, separators
listed in it are excluded from the placevals used for affix assignment.

When MORPHS is non-nil, update only those morphs in the existing graph.
Otherwise perform the full Daselt graph build."
  (if morphs
      (daselt-abv-set-morph-typings
       layout stats (or language (oref stats language))
       morphs parse-data reset)
    (let* ((lang (oref stats language))
           (lname (and lang (oref lang name)))
           (status-symbol (intern (format "abv-progress-set-graph-%s-%s"
                                          (oref layout name)
                                          lname)))
           (new-graph (abv-typing-graph :statistics-file (oref stats file)))
           (old-graph (alist-get (oref (oref stats language) name)
                                 (oref layout typing-graphs)
                                 nil nil #'string=))
           (graph (or graph
                      (if (not old-graph)
                          (progn
                            (object-add-to-list
                             layout 'typing-graphs
                             (cons lname new-graph))
                            new-graph)
                        (if reset
                            (setf (alist-get
                                   lname (oref layout typing-graphs)
                                   nil nil #'string=)
                                  new-graph)
                          (oset old-graph statistics-file stats)
                          old-graph))))
           (parse-data (or parse-data
                           (oref abv-collection-current parse-data))))
      ;; The owning table (for staged one-letter cue words);
      ;; derived from the current collection when not given.
      (let ((table (or table
                       (and (boundp 'abv-collection-current)
                            abv-collection-current
                            (cl-find-if
                             (lambda (tb)
                               (and (slot-exists-p tb 'language)
                                    (slot-boundp tb 'language)
                                    (equal (oref tb language)
                                           (oref stats language))))
                             (oref abv-collection-current tables))))))
        (if sync
            (daselt-abv--set-typings-helper
             layout stats parse-data graph nil reset table)
          (eval `(progn
                   (defvar ,status-symbol nil
                     ,(format "Progress for graph %s and language %s."
                              (oref layout name) lname))
                   (abv-run-in-background
                       ,status-symbol
                     (daselt-abv--set-typings-helper
                      ,layout ,stats ,parse-data
                      ,status-symbol ,graph ,reset ,table)))))))))

(defun daselt-abv--set-typings-helper (layout stats parse-data graph
                                              &optional status-symbol reset
                                              table)
    "Helper for `abv-set-typings' to run in a thread.

This function encapsulates the core logic of building a morph-sign-graph from
STATS for LAYOUT. It promotes frequent short words (two and three letters,
in frequency order) to cues and generates deep structures for other roots.

PARSE-DATA is an optional `abv-parse-data' instance used for separator
information. If EMPTY-CACHE? is non-nil, relevant caches are cleared.
STATUS-SYMBOL is an optional progress tracker used by `abv-run-in-background'."
    (let* ((separators (if parse-data (daselt-abv--parse-data-separators parse-data)))
           (lang (oref stats language))
           (rf (ignore-errors (oref stats root-frequency)))
           (rwf (ignore-errors (oref stats root-word-frequency)))
           (cue-table (oref graph cue-table))
           (root-table (oref graph root-table))
           ;; A3 (usage feedback): blend the live usage counts of
           ;; the owning table's words into the statistics' word
           ;; frequencies, so the ranking seats what the user
           ;; actually types.
           (usage (daselt-abv--usage-counts table))
           (_(and stats
                  (abv-corpus-language--ensure-word-frequency
                   stats (daselt-abv--table-words table))))
           (word-freq (and (slot-boundp stats 'word-frequency)
                           (oref stats word-frequency)))
           (_(when (and usage word-freq)
               (maphash (lambda (w n)
                          (puthash w (+ n (gethash w word-freq 0)) word-freq))
                        usage)))
           ;; A4 (one ranking function): the benefit score of
           ;; `abv-morph--sequence-frequency-score' orders both
           ;; the cue race and the root pass, so graph and
           ;; distillate levels cannot disagree about what is
           ;; frequent.  One-letter words keep their explicit
           ;; log-2 handicap: they also type literally, so their
           ;; cues are worth less ("and" claims the best single
           ;; symbols before "a" does).
           (benefit (lambda (root)
                      (let ((s (or (abv-morph--sequence-frequency-score
                                    `((,root . root)) stats)
                                   0.0)))
                        (if (= 1 (length root)) (- s 2.0) s))))
           (benefits (let ((h (make-hash-table :test 'equal)))
                       (dolist (cell (append (and (listp rwf) rwf)
                                             (and (listp rf) rf)))
                         (let ((r (car cell)))
                           (unless (gethash r h)
                             (puthash r (funcall benefit r) h))))
                       h))
           (ordered-3l (when (and (listp rwf) (> (length rwf) 0))
                         (cl-sort
                          (cl-remove-if-not
                           (lambda (r)
                             (or (and (<= 1 (length r) 3)
                                      (abv-language-word-p lang r))
                                 (save-match-data
                                  (string-match
                                   (rx string-start
                                       (group not-newline
                                              not-newline
                                              not-newline)
                                       "\["
                                       (+ (not "\]"))
                                       "\]?"
                                       string-end)
                                   r))))
                           ;; Racer candidates come from the
                           ;; statistics AND from the owning
                           ;; table's own words: morph-inventory
                           ;; drift can drop words ("for"
                           ;; consolidated into "for[e]?") that
                           ;; the user still types with high
                           ;; counts.
                           (delete-dups
                            (append (mapcar #'car rwf)
                                    (daselt-abv--table-words table))))
                          (lambda (a b)
                            (> (gethash a benefits -1e9)
                               (gethash b benefits -1e9))))))
           ;; C2 (family weights): root-frequency as family weight
           ;; source for the seating bonus.
           (fam-weights (or (and (listp rf)
                                 (abv-layout-alist->hash rf))
                            (make-hash-table :test 'equal)))
           (ordered (when (and (listp rf) (> (length rf) 0))
                      (cl-sort (copy-sequence rf)
                               (lambda (a b)
                                 (> (gethash (car a) benefits -1e9)
                                    (gethash (car b) benefits -1e9)))))))

    (abv-refresh lang)
    (if reset (setq daselt-abv-untyped nil))

    (mapc (lambda (type)
            ;; Mirror the incremental path: hand the placevals
            ;; method the layout's placeval set and the
            ;; type-specific frequency list (slot of STATS for
            ;; corpus statistics, STATS itself for plain lists).
            (and-let* ((placevals (slot-value
                                   layout
                                   (intern (concat (symbol-name type)
                                                   "-placevals"))))
                       (table-symbol (intern (concat (symbol-name type)
                                                     "-table")))
                       (typing-table (and (slot-boundp graph table-symbol)
                                          (slot-value graph table-symbol)))
                       (frequency (cond
                                   ((and (eieio-object-p stats)
                                         (object-of-class-p
                                          stats 'abv-corpus-language-statistics))
                                    (slot-value
                                     stats
                                     (intern (concat (symbol-name type)
                                                     "-frequency"))))
                                   ((listp stats) stats)
                                   (t nil))))
              (abv-set-typings placevals
                               (daselt-abv--normalize-frequencies frequency)
                               :separators separators
                               :table typing-table
                               :reset reset
                               :layout layout)))
          '(prefix suffix infix))

    (when status-symbol
      (setf (slot-value status-symbol 'target-count)
            (length ordered-3l))
      (setf (slot-value status-symbol 'current-type)
            "3-length words"))

    ;; Phase 1: Promote frequent short words (two and three
    ;; letters, benefit-ordered) to cues from
    ;; root-word-frequency.  Staged one-letter words from the
    ;; table's hidden obarray join the race too: they were never
    ;; roots, so root-word-frequency has no entry for them (they
    ;; enter with a zero count and thus claim the LAST single
    ;; symbols, after every counted word).
    (let ((daselt-abv--layout-match-cache (make-hash-table :test 'equal))
          (daselt-abv--family-weights fam-weights)
          (daselt-abv--initial-load nil)
          (budget (length (oref (oref layout placevals) standalone-placevals)))
          (staged-1l
           (and table
                (slot-exists-p table 'hidden-obarray)
                (slot-boundp table 'hidden-obarray)
                (let ((out nil))
                  (mapatoms
                   (lambda (sym)
                     (when (and (boundp sym)
                                (stringp (symbol-value sym))
                                (= 1 (length (symbol-value sym))))
                       (push (symbol-value sym) out)))
                   (oref table hidden-obarray))
                   out)))
          (alpha (daselt-abv--weights-slot
                  (and (slot-exists-p layout 'weights)
                       (slot-boundp layout 'weights)
                       (oref layout weights))
                  'initial-load-weight 0.5)))
      (when staged-1l
        (setq ordered-3l
              (append ordered-3l
                      (cl-remove-if
                       (lambda (w) (member w ordered-3l))
                       staged-1l))))
      ;; Reserve cue slots for the staged one-letter words:
      ;; ordered-3l alone can exceed the standalone budget
      ;; (observed 348 racers for 207 slots), which starved the
      ;; appended entries completely.  Counted words race for the
      ;; reduced budget; the one-letter words claim last,
      ;; unconditionally within the full budget.
      (dolist (r ordered-3l)
        (unless (member r staged-1l)
          (when (< (hash-table-count cue-table)
                   (- budget (length staged-1l)))
            (abv-plain-value
             (abv-typed-layout-type-root
              layout r root-table separators
              (oref stats shared-affix-frequencies)
              lang cue-table))))
        (when status-symbol
          (cl-incf (slot-value status-symbol 'current-count))))
      (dolist (w staged-1l)
        (when (< (hash-table-count cue-table) budget)
          (abv-plain-value
           (abv-typed-layout-type-root
            layout w root-table separators
            (oref stats shared-affix-frequencies)
            lang cue-table))))

      ;; Phase 2: Generate deep structures for all remaining
      ;; roots, benefit-ordered.  With a positive
      ;; initial-load-weight (C1) a second pass re-seats every
      ;; root against the initial-cell load built by the first
      ;; pass, spreading compound initials across cells.
      (when ordered
        (dolist (pass (if (> alpha 0) '(seed spread) '(seed)))
          (when (eq pass 'spread)
            (let ((load (make-hash-table :test 'equal)))
              (maphash (lambda (root v)
                         (let ((cell (car (daselt-abv--typing-value-coords
                                           v))))
                           (when cell
                             (puthash cell
                                      (+ (gethash cell load 0)
                                         (gethash root fam-weights 0))
                                      load))))
                       root-table)
              (setq daselt-abv--initial-load load))
            (clrhash root-table)
            (maphash (lambda (k v) (puthash k v root-table))
                     cue-table))
          (dolist (cell ordered)
            (let ((root (car cell)))
              (unless (gethash root cue-table)
                (abv-typed-layout-type-root
                 layout root root-table separators
                 (oref stats shared-affix-frequencies) lang)))
            (when status-symbol
              (cl-incf (slot-value status-symbol 'current-count))))
        ;; B1 (churn rebalance): re-choose affix symbols against
        ;; the usage-weighted layer families of their hosts.
        (daselt-abv--rebalance-affixes layout graph table))))
    graph))

;;;; Single-coordinate assignment helper

(defun daselt-abv--assign-one (layout affix preferred-hash counts-hash letter-base complementp
                                      &optional separators letter-freq)
  "Choose a coordinate for AFFIX and update COUNTS-HASH.

Search letters from rarest; prefer neighbors around letter bases across layer
order. If none are free, choose by usage then ergonomic. Return coordinate."
  (let* ((letters (daselt-abv--affix-letters affix))
         (letters-sorted (cl-stable-sort (copy-sequence letters) #'<
                                         :key (lambda (L)
                                                (if letter-freq
                                                    (alist-get
                                                     (string-to-char L) letter-freq 0)
                                                  (daselt-abv--letter-rarity L preferred-hash)))))
         (layers (daselt-abv--coord-layers-in-order complementp))
         (chosen-coord nil))
    (cl-loop for L in letters-sorted
             for base = (gethash L letter-base)
             unless (or (cl-member base separators
                                   :test (lambda (coords sep)
                                           (= (string-to-char
                                               (daselt-coords-binding
                                                coords))
                                              sep)))
                        (not (<= (gethash base counts-hash 0) 0)))
             do (setq chosen-coord base) (cl-return)
             when chosen-coord do (cl-return))
    (unless chosen-coord
      ;; B2 (scored neighbors): keep the column-first walk as the
      ;; candidate order (same-finger memorization), but among
      ;; the free candidates pick the best-scored one -- letter
      ;; match first, then ergonomic cost -- instead of the
      ;; literally-first free coordinate.
      (let ((cands nil))
        (cl-loop for L in letters-sorted
                 for base = (gethash L letter-base)
                 when base do
                   (dolist (coord (abv-layout-neighbors layout base :layers layers))
                     (when (and (gethash coord preferred-hash)
                                (<= (gethash coord counts-hash 0) 0)
                                (not (cl-member coord separators
                                                :test (lambda (coords sep)
                                                        (= (string-to-char
                                                            (daselt-coords-binding
                                                             coords))
                                                           sep)))))
                       (push coord cands)))
                 when (> (length cands) 11) do (cl-return))
        (when cands
          (setq chosen-coord
                (car (cl-sort cands #'<
                              :key (lambda (coord)
                                     (let ((binding (daselt-coords-binding coord)))
                                       (+ (if (member (daselt-abv--down binding)
                                                      letters)
                                              0.0 1.0)
                                          (daselt-abv--erg-score coord))))))))))
    (unless chosen-coord
      (let ((free (daselt-abv--free-candidates preferred-hash counts-hash)))
        (setq chosen-coord (if free (car (cl-sort free #'< :key #'daselt-abv--erg-score))
                             (daselt-abv--choose-fallback preferred-hash counts-hash)))))
    (cl-incf (gethash chosen-coord counts-hash 0))
    chosen-coord))

(defun daselt-abv--layer-family (layer)
  "Return the layer-pair family keyword of LAYER.
The Daselt layer pairs are (1 . 2), (4 . 3), (5 . 6), (8 . 7);
families share one hold modifier, so cross-family adjacent keys
churn modifiers (see `daselt-abv--pair-units' layer-switch
penalty)."
  (cond ((memql layer '(1 2)) 'base)
        ((memql layer '(4 3)) 'four)
        ((memql layer '(5 6)) 'five)
        ((memql layer '(8 7)) 'eight)
        (t nil)))

(defun daselt-abv--table-words (table)
  "Collect the word strings of TABLE's visible and hidden obarrays."
  (let ((words nil))
    (dolist (oa (list (and table (slot-boundp table 'obarray)
                           (oref table obarray))
                      (and table (slot-exists-p table 'hidden-obarray)
                           (slot-boundp table 'hidden-obarray)
                           (oref table hidden-obarray))))
      (when (obarrayp oa)
        (mapatoms (lambda (sym)
                    (when (and (boundp sym)
                               (stringp (symbol-value sym))
                               (>= (length (symbol-value sym)) 2))
                      (push (symbol-value sym) words)))
                  oa)))
    words))

(defun daselt-abv--usage-counts (table)
  "Hash expansion string -> usage count over TABLE's obarrays.
A3 (usage feedback): the live counts of what the user actually
types blend into the statistics' word frequencies during graph
generation.  Return nil when TABLE is nil."
  (and table
       (let ((h (make-hash-table :test 'equal)))
         (dolist (oa (list (and (slot-boundp table 'obarray)
                                (oref table obarray))
                           (and (slot-exists-p table 'hidden-obarray)
                                (slot-boundp table 'hidden-obarray)
                                (oref table hidden-obarray))))
           (when (obarrayp oa)
             (mapatoms (lambda (sym)
                         (when (and (boundp sym)
                                    (stringp (symbol-value sym)))
                           (puthash (symbol-value sym)
                                    (+ (or (get sym 'count) 0)
                                       (gethash (symbol-value sym) h 0))
                                    h)))
                       oa)))
         h)))

(defun daselt-abv--rebalance-affixes (layout graph table)
  "Re-choose affix symbols to minimize cross-family layer churn.
B1 (churn rebalance): for every affix of GRAPH's prefix, suffix
and infix tables, collect a usage-weighted histogram of the layer
families appearing in the keys of TABLE entries whose
morph-sequence contains the affix, ignoring signs equal to the
affix's own binding.  The dominant family is the affix's
preferred family; when the current coordinate sits on another
family and a free coordinate of the preferred family exists
\(unused by any graph table), the affix moves there, choosing
among free candidates by letter match first, then ergonomic
score.  Return the number of affixes moved."
  (when (and table (slot-boundp table 'obarray) (obarrayp (oref table obarray)))
    (let* ((sign-coord (let ((h (make-hash-table :test 'equal)))
                         (dolist (pv (oref (oref layout placevals)
                                           standard-placevals))
                           (puthash (cdr pv) (car pv) h))
                         h))
           (occupied (make-hash-table :test 'equal))
           (slots '(prefix-table suffix-table infix-table))
           (affix-coord (make-hash-table :test 'equal)) ; (slot . affix) -> coord
           (hist (make-hash-table :test 'equal))        ; (slot . affix) -> fam -> weight
           (moved 0))
      ;; Occupancy: every coordinate bound in any graph table.
      (dolist (slot slots)
        (let ((tbl (slot-value graph slot)))
          (maphash (lambda (affix v)
                     (let ((c (car (daselt-abv--typing-value-coords v))))
                       (when c
                         (puthash c t occupied)
                         (puthash (cons slot affix) c affix-coord))))
                   tbl)))
      (maphash (lambda (_root v)
                 (let ((c (car (daselt-abv--typing-value-coords v))))
                   (when c (puthash c t occupied))))
               (oref graph root-table))
      ;; Host histograms from the live table.
      (mapatoms
       (lambda (sym)
         (when (and (boundp sym) (stringp (symbol-value sym))
                    (get sym :morph-sequence) (listp (get sym :morph-sequence)))
           (let* ((seq (get sym :morph-sequence))
                  (cnt (1+ (or (get sym 'count) 0)))
                  (key (symbol-name sym)))
             (dolist (cell seq)
               (let ((slot (pcase (cdr cell)
                             ('prefix 'prefix-table)
                             ('suffix 'suffix-table)
                             ('infix 'infix-table)
                             (_ nil))))
                 (when slot
                   (let* ((own (gethash (cons slot (car cell)) affix-coord))
                          (own-sign (and own (daselt-coords-binding own)))
                          (slot-h (or (gethash (cons slot (car cell)) hist)
                                      (let ((h (make-hash-table :test 'eq)))
                                        (puthash (cons slot (car cell)) h hist)
                                        h))))
                     (dolist (ch (append key nil))
                       (let* ((coord (gethash (string ch) sign-coord))
                              (fam (and coord (daselt-abv--layer-family
                                               (nth 0 coord)))))
                         (when (and fam
                                    (not (and own-sign
                                              (string= (string ch) own-sign))))
                           (puthash fam (+ cnt (gethash fam slot-h 0))
                                    slot-h)))))))))))
       (oref table obarray))
      ;; Move affixes onto their dominant family when free cells allow.
      (dolist (slot slots)
        (let ((tbl (slot-value graph slot)))
          (maphash
           (lambda (affix v)
             (let* ((cur (car (daselt-abv--typing-value-coords v)))
                    (slot-h (gethash (cons slot affix) hist))
                    (best-fam
                     (and slot-h
                          (let ((best nil) (best-w -1.0))
                            (maphash (lambda (fam w)
                                       (when (> w best-w)
                                         (setq best-w w)
                                         (setq best fam)))
                                     slot-h)
                            best)))
                    (cur-fam (and cur (daselt-abv--layer-family (nth 0 cur)))))
               (when (and best-fam cur-fam (not (eq best-fam cur-fam)))
                 (let* ((letters (daselt-abv--affix-letters affix))
                        (cands
                         (cl-remove-if-not
                          (lambda (pv)
                            (let ((coord (car pv)))
                              (and (eq (daselt-abv--layer-family (nth 0 coord))
                                       best-fam)
                                   (or (not (gethash coord occupied))
                                       (equal coord cur)))))
                          (oref (oref layout placevals) standard-placevals))))
                   (setq cands
                         (cl-sort cands
                                  (lambda (a b) (< (daselt-abv--affix-cand-key
                                                    letters a)
                                                   (daselt-abv--affix-cand-key
                                                    letters b)))))
                   (when (and cands (not (equal (caar cands) cur)))
                     (puthash cur nil occupied)
                     (puthash (caar cands) t occupied)
                     (puthash affix (caar cands) tbl)
                     (puthash (cons slot affix) (caar cands) affix-coord)
                     (cl-incf moved))))))
           tbl)))
      moved)))

(defun daselt-abv--affix-cand-key (letters pv)
  "Sort key for affix candidate PV: letter match, then ergonomic score."
  (let* ((binding (cdr pv))
         (matched (member (daselt-abv--down binding) letters)))
    (- (if matched 0 1)
       (daselt-abv--erg-score (car pv)))))


;;;; Root typing via ring-search

(defvar daselt-abv--valid-set-cache (make-hash-table :test #'eq :weakness 'key)
  "Membership hashes for `abv-layout-generate-symbol-sequence-cache' results.
Maps a cached xlist object (by identity) to an equal-test hash of
its sequences, so the per-root validity hash over e.g. the 8192
\"rr\" sequences is built once per layout instead of per root.")

(defun daselt-abv--valid-set-for (seqs)
  "Return the membership hash for the cached sequence xlist SEQS."
  (or (gethash seqs daselt-abv--valid-set-cache)
      (let ((h (make-hash-table :test 'equal)))
        (dolist (s seqs h) (puthash s t h))
        (puthash seqs h daselt-abv--valid-set-cache)
        h)))

(cl-defmethod abv-typed-layout-type-root ((layout daselt-abv-layout)
                                          (root string) table
                                          &optional separators shared-matrix
                                          language cue-table &key reset
                                          taken-tables)
        "Compute deep structure for ROOT on LAYOUT using ring expansion.

This method enumerates base candidates, embellishes them, filters by valid
symbol sequences and relative freedom (uniqueness of values) in TABLE and
CUE-TABLE, and selects the best candidate by weighted score.

TAKEN-TABLES is a list of further root tables whose values count
as occupied: candidates landing on a deep structure already taken
there are filtered out, so typings generated for one graph avoid
structures used by another graph (e.g. the parent language's).

The taken reverse index is reused across consecutive calls for the
same TABLE and TAKEN-TABLES and maintained incrementally, so batch
typings pay for its construction only once.

It stores and returns the chosen deep structure as a list of coordinate tuples
\(wrapped in an `abv-rich-value' if appropriate)."
        (let ((exists (gethash root table)))
    (if (and (not reset) exists)
                    exists
            (daselt-abv--with-taken-reverse-index table taken-tables
              (let* ((wobj (or (and (slot-boundp layout 'weights) (oref layout weights))
                        (abv-weights)))
              (wordp (and language (abv-language-word-p language root)))
              (onep (or (< (length root) 3)
                        (and (< (length root) 4) wordp)
                        (save-match-data
                                (and (string-match (rx string-start (group not-newline
                                                                     not-newline
                                                                     not-newline)
                                                 "\["
                                                 (* (not "\]"))
                                                 "\]?"
                                                 string-end)
                                             root)
                               (abv-language-word-p language (match-string 1 root))))))
              (base-seqs (daselt-abv--string-combinations root (if onep 1 2) (if onep 1 2)))
              ;; Mnemonic extension: when every 2-symbol base
              ;; combination is occupied, a 3-symbol combination
              ;; of the root's own letters (e.g. (f,o,r) for
              ;; "form" rendering "for") types better than an
              ;; embellished pair of unrelated symbols (e.g.
              ;; (o,z) rendering "oz" or numbered fallbacks).
              (base3-seqs nil)
              (root-coord-set
               (let ((ht (make-hash-table :test 'equal)))
                 (dolist (pv (oref (oref layout placevals) root-placevals) ht)
                   (puthash (car pv) t ht))))

              ;; Pre-calculate valid sequence set for fast lookup
              (valid-seqs (abv-layout-generate-symbol-sequence-cache layout (if onep "r" "rr")))
              (valid-set (daselt-abv--valid-set-for valid-seqs))
             (embellishment-search-rings
              (if onep
                              '(nil ((t nil nil)) ((nil t nil)) ((nil nil t)))
                      '(nil ((nil nil nil) (t nil nil))
                      ((t nil nil) (nil nil nil))
                      ((nil nil nil) (nil t nil))
                      ((nil t nil) (nil nil nil))
                      ((nil nil nil) (nil nil t))
                      ((nil nil t) (nil nil nil))))))
        (cl-flet ((do-search3 (overcount)
                      ;; Search the 3-symbol mnemonic extensions
                      ;; (nil ring only: they are already base
                      ;; letter combinations, embellishing them is
                      ;; the LAST resort handled by do-search).
                      (unless (or onep base3-seqs)
                        (setq base3-seqs
                              (daselt-abv--string-combinations root 3 3)))
                      ;; Validity by direct coordinate membership in
                      ;; the root placevals: the enumerated "rrr"
                      ;; cache is capped far below the full space
                      ;; and rejects most real letter triples.
                      (when base3-seqs
                        (let* ((valid-cands
                                (cl-loop for c in base3-seqs
                                         when (cl-every
                                               (lambda (elt)
                                                 (gethash (car (cdr elt))
                                                          root-coord-set))
                                               c)
                                         collect c))
                               (free-cands
                                (daselt-abv--filter-candidates
                                 valid-cands separators table cue-table overcount)))
                          (daselt-abv--score-candidates
                           free-cands layout root table wobj shared-matrix))))
                  (do-search (overcount &optional base-only)
                          (or
                      ;; Ring search: score the best candidate of
                      ;; EVERY ring and keep the overall best, so an
                      ;; ergonomic letter-layer variant wins over an
                      ;; awkward (e.g. emoji-layer) one from an
                      ;; earlier ring.
                      (let ((overall nil))
                        (cl-loop for ring in (cond
                                              (base-only
                                               (list (car embellishment-search-rings)))
                                              (overcount
                                               (cdr embellishment-search-rings))
                                              (t embellishment-search-rings))
                                 for embellished = (daselt-abv--embellish base-seqs ring)
                                 ;; Filter by validity (must be in valid-seqs cache)
                                 for valid-cands = (cl-loop for c in embellished
                                                            when (gethash (daselt-abv--seq-placevals c) valid-set)
                                                            collect c)
                                 ;; Filter by separators and freedom
                                 for free-cands = (daselt-abv--filter-candidates valid-cands separators table cue-table overcount)
                                 ;; Score
                                 for best = (daselt-abv--score-candidates free-cands layout root table wobj shared-matrix)
                                 when (and best
                                           (or (null overall)
                                               (> (cdr best) (cdr overall))))
                                 do (setq overall best))
                        overall)
                      ;; Fallback: search all valid sequences in
                      ;; cache (not in base-only passes: their
                      ;; candidates must stay base combinations).
                      (and (not base-only)
                           (let* ((all-free (daselt-abv--filter-candidates valid-seqs separators table cue-table overcount)))
                             (daselt-abv--score-candidates all-free layout root table wobj shared-matrix))))))

          (let* ((best-cand (if cue-table
                                 ;; Cues must stay strictly unique:
                                 ;; keep the original strict-then-
                                 ;; overcount search.
                                 (or (do-search nil) (do-search t))
                               (or (do-search nil t)
                                   (do-search3 nil)
                                   (do-search nil)
                                   (do-search t t)
                                   (do-search3 t)
                                   (do-search t))))
                 (seq (car best-cand))) ; best-cand is (SEQ . SCORE)
            (if seq
                            (let* ((coords (daselt-abv--seq-coords seq)) ; Extract coords
                       (val-to-put (if wordp
                                                   (make-instance 'abv-rich-value
                                                      :plain-value coords
                                                      :property-plist '(:word? t))
                                     coords)))
                  (puthash root val-to-put table)
                  ;; Keep the reverse index in sync so a reused
                  ;; index always matches a fresh rebuild of TABLE:
                  ;; drop ROOT's previous bucket entry (RESET
                  ;; retypings) before adding the new one.
                  (when daselt-abv--root-reverse-index
                    (when (and reset exists)
                      (let* ((old-key (daselt-abv--value-coords exists))
                             (bucket (and old-key
                                           (gethash old-key
                                                    daselt-abv--root-reverse-index))))
                        (when bucket
                          (setq bucket (delete root bucket))
                          (if bucket
                              (puthash old-key bucket
                                       daselt-abv--root-reverse-index)
                            (remhash old-key
                                     daselt-abv--root-reverse-index)))))
                    (let ((coords-key (daselt-abv--value-coords val-to-put)))
                      (puthash coords-key
                               (cons root (gethash coords-key daselt-abv--root-reverse-index nil))
                               daselt-abv--root-reverse-index)))
                  (if cue-table (puthash root coords cue-table))
                  coords)
                ;; If failed, track untyped
                (unless cue-table (push root daselt-abv-untyped))
                nil))))))))

;;;; Sequence-string methods



;;;; Sequence-string methods

      (cl-defmethod abv-typed-layout-morph-sequence-string ((seq list) (layout daselt-abv-layout)
                                                      (language abv-language) &key not-cued)
      "Daselt method for `abv-typed-layout-morph-sequence-string'.

Can also handle coords and coord- and placeval-sequences in the LAYOUT's graph
for LANGUAGE.

If no typing can be found for a morph, uses the empty string."
      (let* ((graph (abv-typed-layout-language-typing-graph layout language))
         (parent-graphs (daselt-abv--parent-typing-graphs layout language))
         (in-cue (and (not not-cued)
                      (= 1 (length seq))
                      (= 3 (length (caar seq)))))
          (missing nil)
           (result (mapconcat
                    (lambda (morph)
                            (let* ((type (cdr morph))
                               (name-key (and (abv-morph--name-type-p type)
                                              (abv-name-lookup-key (car morph))))
                               (abs (if (or in-cue (cl-member type '(morph-separator formal)))
                                                (car morph)
                                          ;; Fall back to the raw form when
                                          ;; no abstraction exists: it (or
                                          ;; its plain twin) may still be
                                          ;; typed in a graph.
                                          (or (abv-language-abstraction morph language)
                                              (car morph))))
                             (typing (or
                                      ;; Name cells are typed by their
                                      ;; name-table abbreviation key,
                                      ;; which is already a rendered key
                                      ;; string; an unresolvable name
                                      ;; yields nil and fails the
                                      ;; sequence below like any
                                      ;; untypeable morph.
                                      name-key
                                      (abv-typed-layout--lookup-with-plain-twin
                                      abs type language
                                      ;; Own graph first; morphs typed only
                                      ;; in the parent language's graph
                                      ;; render through it, so a sequence
                                      ;; mixing own and parent typings is
                                      ;; never truncated.  The plain-twin
                                      ;; pass covers morphs whose stored
                                      ;; form is threaded (e.g. root
                                      ;; "fini" for plain "fine").
                                      (cons graph parent-graphs))))
                             (plain-typing (abv-plain-value typing)))
                      (cond
                       ((not typing)
                        ;; An untypeable morph must fail the whole
                        ;; sequence: a silently shortened string
                        ;; would be accepted as a distillate string
                        ;; and registered as garbage.
                        (setq missing t) "")
                       (t
                        (let ((rendered
                               (cond
                                ((stringp plain-typing) plain-typing)
                                ((daselt-coords-p plain-typing)
                                 (daselt-coords-binding plain-typing))
                                ((cl-every #'daselt-coords-p plain-typing)
                                 (mapconcat #'daselt-coords-binding plain-typing))
                                ((cl-every (lambda (plv)
                                             (and (consp plv)
                                                  (daselt-coords-p (car plv))))
                                           plain-typing)
                                 (mapconcat (lambda (plv)
                                              (daselt-coords-binding (car plv)))
                                            plain-typing))
                                (t ""))))
                          ;; A present typing whose binding renders
                          ;; to nothing (e.g. coordinates on a layer
                          ;; missing from the current keyboard
                          ;; layout) must fail the sequence too.
                          (when (string-empty-p rendered)
                            (setq missing t))
                          rendered)))))
                   seq)))
    ;; If no cued symbol has been found, try un-cued ones.
    (if (and (not missing)
             (daselt-base-string-exists-and-nonempty result))
                result
          (or (and in-cue
               (abv-typed-layout-morph-sequence-string seq layout language :not-cued t))
          (and (not missing) result)))))

(cl-defmethod abv-typed-layout-morph-sequence-string
    ((seq list) (layout daselt-abv-layout)
     (language abv-sub-language) &key not-cued)
  "Render SEQ from LANGUAGE's own graph, falling back to the parent's.
The sub-language owns its typing graph; when some morph of
SEQ is typed only in the parent language's graph, the parent
graph provides the missing pieces."
  (let ((own (cl-call-next-method)))
    (if (daselt-base-string-exists-and-nonempty own)
        own
      (or (when-let* ((parent (oref language parent-language)))
            (ignore-errors
              (abv-typed-layout-morph-sequence-string seq layout parent
                                                      :not-cued not-cued)))
          own))))

(cl-defmethod abv-typed-layout-exchange-characters-in-graph
      ((_layout daselt-abv-layout) (graph abv-typing-graph) c1 c2 &key change-coordinates)
      "Exchange C1 and C2 in GRAPH's Daselt typing tables.

If CHANGE-COORDINATES is t, look up the coordinates that bind to C1 and C2 via
`daselt-bind--get-unique-layout-match', then swap them in all coordinate-valued
slots of GRAPH.

For string-valued slots such as `cue-table' and `morph-sequence-table', apply
the usual string character exchange via `abv--exchange-chars-in-string'.

Handle both single coordinates and lists of coordinates in values."
      (when change-coordinates
    (let* ((c1-str (char-to-string c1))
           (c2-str (char-to-string c2))
           (pv-c1 (daselt-bind--get-unique-layout-match c1-str))
           (pv-c2 (daselt-bind--get-unique-layout-match c2-str))
           (coord-c1 (and pv-c1 (car pv-c1)))
           (coord-c2 (and pv-c2 (car pv-c2))))
      (when (and coord-c1 coord-c2)
        (cl-labels
                    ((swap-coords (v)
                   "Swap COORD-C1 and COORD-C2 in value V."
                   (cond
                ((equal v coord-c1) coord-c2)
                ((equal v coord-c2) coord-c1)
                ((and (listp v) (not (abv-rich-value-p v)))
                 (mapcar #'swap-coords v))
                (t v))))
          ;; Coordinate-valued slots.
          (dolist (slot '(prefix-table suffix-table infix-table root-table
                                       separator-table))
            (when (slot-exists-p graph slot)
              (let ((table (slot-value graph slot)))
                (when (hash-table-p table)
                  (let ((entries nil))
                    (maphash
                     (lambda (k v)
                           (let* ((plain (abv-plain-value v))
                              (new-val (swap-coords plain)))
                         (unless (equal plain new-val)
                           (push (cons k new-val) entries))))
                     table)
                    (dolist (entry entries)
                      (puthash (car entry) (cdr entry) table)))))))))))

      ;; String-valued slots: use string character exchange.
      (dolist (slot '(cue-table morph-sequence-table))
    (when (slot-exists-p graph slot)
      (let ((table (slot-value graph slot)))
        (when (hash-table-p table)
          (let ((entries nil))
            (maphash
             (lambda (k v)
                   (when (stringp v)
                 (let ((new-v (abv--exchange-chars-in-string
                               v c1 c2)))
                   (unless (string= v new-v)
                     (push (cons k new-v) entries)))))
             table)
            (dolist (entry entries)
              (puthash (car entry) (cdr entry) table))))))))

(cl-defmethod abv-typed-layout-morph-typing-string ((morph cons)
                                                    (layout abv-typed-layout)
                                                    (language abv-language)
                                                    &key in-cue)
        "Return a string representation of the typing for MORPH.

Queries LAYOUT for the typing assigned to MORPH within LANGUAGE. If IN-CUE is
non-nil, assume it is inside a cue sequence. Special coordinates like (4 2 0)
and (6 2 0) are translated into printable Unicode separators."
        (let ((typing (abv-plain-value
                 (abv-typed-layout-morph-typing morph layout
                                                language :in-cue
                                                in-cue))))
    (if typing (cond ((stringp typing)
                      typing)
                     ((equal typing '(4 2 0))
                      "␠")
                     ((equal typing '(6 2 0))
                      "␟")
                     ((daselt-coords-p typing)
                      (daselt-coords-binding typing))
                     ((and (daselt-coords-p (car typing))
                           (stringp (cdr typing)))
                      (daselt-coords-binding (car typing)))
                     (t (mapconcat (lambda (coords)
                                           (if (and (daselt-coords-p (car coords))
                                              (stringp (cdr coords)))
                                                     (daselt-coords-binding
                                          (car coords))
                                         (daselt-coords-binding
                                          coords)))
                                   typing)))
      "")))



(defun daselt-abv--taken-p (taken-strings)
  "Return a predicate that checks membership in TAKEN-STRINGS.

Works with both hash-tables and lists."
  (cond
   ((hash-table-p taken-strings)
    (lambda (s) (gethash s taken-strings)))
   ((listp taken-strings)
    (lambda (s) (cl-member s taken-strings :test #'string=)))
   (t (lambda (_) nil))))

(defun daselt-abv--one-hot (dim idx)
  "Return a list of length DIM with t at IDX and nil elsewhere."
  (cl-loop for k below dim collect (and (= k idx) t)))

(defun daselt-abv--make-search-rings (len &optional dim)
  "Return the rings for sequences of length LEN over DIM positions (default 3)."
  (let ((d (or dim 3)))
    (cons nil
          (cl-loop for j below d append
                   (cl-loop for i from (1- len) downto 0 collect
                            (cl-loop for k below len
                                     collect (if (= k i)
                                                 (daselt-abv--one-hot d j)
                                               (make-list d nil))))))))


(defun daselt-abv--case-variant-p (s base)
  "Return non-nil if S is a pure case variant of BASE.
S and BASE must have the same length and differ only in the case of
some letters (same string after `downcase'), and not be equal."
  (and (not (string= s base))
       (= (length s) (length base))
       (string= (downcase s) (downcase base))))

(defun daselt-abv--first-diff-index (s base)
  "Return the index of the first differing char of S and BASE, or -1."
  (catch 'daselt-abv--first-diff
    (cl-loop for k below (min (length s) (length base))
             when (/= (aref s k) (aref base k))
             do (throw 'daselt-abv--first-diff k))
    -1))


(defvar daselt-abv--variant-layer-order '(1 2 4 3 5 6 8 7)
  "Layers tried for letter variants, by mnemonic value.
Every layer counts as \"close enough\" to its base key — the
memorization goes by LAYOUT GEOMETRY (\"r shifted by three
layers\"), not by glyph optics — but nearer layers are worth
more.  The order follows the layer pairs ((1 . 2) (4 . 3)
(5 . 6) (8 . 7)), each pair's lower layer first: base letters,
case shift, then the math pair, the Greek pair, arrows and
emoji last.  An emoji same-length variant still beats a longer
key.")

(defvar daselt-abv--mnemonic-cache (make-hash-table :test 'equal)
  "Memo for `abv-typed-layout--mnemonic-strings': (STRING .
LENGTH) -> results.  The layout is fixed per session; repack
sweeps re-ask the same words repeatedly.")

(cl-defmethod abv-typed-layout--mnemonic-strings
  ((layout daselt-abv-layout) string length)
  "Daselt method: in-order letter subsequences of STRING.
Every subsequence position must resolve to a layout symbol
(`daselt-abv--unique-layout-match') whose placeval is an
assignable single-symbol binding.  Ordered most prefix-like
first (the enumeration order of `daselt-abv--string-combinations').
Memoized in `daselt-abv--mnemonic-cache'."
  (when (and (stringp string) (<= 1 length (length string)))
    (let ((key (cons string length)))
      (let ((cached (gethash key daselt-abv--mnemonic-cache 'miss)))
        (if (eq cached 'miss)
            (let ((res (daselt-abv--mnemonic-strings-compute
                        layout string length)))
              (puthash key res daselt-abv--mnemonic-cache)
              res)
          cached)))))

(defvar daselt-abv--letter-placeval-memo
  (make-hash-table :test 'equal)
  "Session-persistent letter -> placeval memo for mnemonic
enumeration.  `daselt-abv--string-combinations' resolves each
letter through the recursive layout walk (~70ms uncached); a
per-call dynamic cache still re-walks every letter for every
word, which made the typing reset 20x slower.")

(defun daselt-abv--mnemonic-strings-compute (layout string length)
  (let ((daselt-abv--layout-match-cache
         daselt-abv--letter-placeval-memo)
        (combos (daselt-abv--string-combinations string length length))
        (rps (oref (oref layout placevals) single-symbol-placevals))
        (out nil))
    (dolist (combo combos)
      (let ((str (and (cl-every (lambda (elt)
                                  (member (cdr elt) rps))
                                combo)
                      (mapconcat (lambda (elt) (cddr elt)) combo))))
        (when (and str (not (string-empty-p str)))
          (push str out))))
    (nreverse out)))

(defvar daselt-abv--mnemonic-variant-cap 256
  "Maximum variant mnemonic strings per call.
`abv-typed-layout--mnemonic-variant-strings' enumerates layer
variants of the word's own letter subsequences; the list is
capped so long words cannot blow up the candidate budget (the
caller examines it under the shared typing-candidate budget
anyway).")

(defvar daselt-abv--mnemonic-variant-cache (make-hash-table :test 'equal)
  "Memo for `abv-typed-layout--mnemonic-variant-strings':
(STRING . LENGTH) -> results.  The layout is fixed per session.")

(cl-defmethod abv-typed-layout--mnemonic-variant-strings
  ((layout daselt-abv-layout) string length)
  "Daselt method: layer variants of STRING's letter subsequences.
Like `abv-typed-layout--mnemonic-strings', but individual symbols
are swapped for other layers' bindings at the same coordinate
(h -> H/eta/H-double-struck...): a word whose plain letter
subsequences are all taken still types as itself (her -> hE or
h-variant, not a deep pair like E-rho).  Combos run most
prefix-like first; within a combo, single-position variants
(rightmost position first) come before double-position ones, and
layers follow `daselt-abv--variant-layer-order'.  At most
`daselt-abv--mnemonic-variant-cap' strings are produced.
Memoized in `daselt-abv--mnemonic-variant-cache'."
  (when (and (stringp string) (<= 1 length (length string)))
    (let ((key (cons string length)))
      (let ((cached (gethash key daselt-abv--mnemonic-variant-cache 'miss)))
        (if (eq cached 'miss)
            (let ((res (daselt-abv--mnemonic-variant-strings-compute
                        layout string length)))
              (puthash key res daselt-abv--mnemonic-variant-cache)
              res)
          cached)))))

(defun daselt-abv--mnemonic-variant-strings-compute (layout string length)
  "Return the ordered variant strings for STRING at LENGTH.
See `abv-typed-layout--mnemonic-variant-strings' for the ordering."
  (let* ((daselt-abv--layout-match-cache
          daselt-abv--letter-placeval-memo)
         (combos (daselt-abv--string-combinations string length length))
         (rps (oref (oref layout placevals) single-symbol-placevals))
         (assignable (let ((ht (make-hash-table :test 'equal)))
                       (dolist (pv rps ht)
                         (puthash (cdr pv) t ht))))
         (seen (make-hash-table :test 'equal))
         (out nil))
    (cl-block daselt-abv--mnemvar-done
      (dolist (combo combos)
        ;; Only combos whose base placevals are assignable symbols,
        ;; matching the plain mnemonic tier's filter.
        (when (cl-every (lambda (elt) (member (cdr elt) rps)) combo)
          (let* ((coords (mapcar (lambda (elt) (car (cdr elt))) combo))
                 (bnds (mapcar (lambda (elt) (cddr elt)) combo))
                 ;; Variants per position: other layers' single-symbol
                 ;; bindings at the same coordinate, layer order.
                 (variants
                  (mapcar
                   (lambda (coord)
                     (let ((vs nil))
                       (dolist (L2 daselt-abv--variant-layer-order)
                         (unless (= L2 (nth 0 coord))
                           (let ((bnd (daselt-coords-binding
                                       (list L2 (nth 1 coord)
                                             (nth 2 coord)))))
                             (when (and (stringp bnd)
                                        (= 1 (length bnd))
                                        (gethash bnd assignable))
                               (push bnd vs)))))
                       (nreverse vs)))
                   coords))
                 (emit
                  (lambda (subs)
                    (let ((str (apply #'concat
                                      (cl-mapcar
                                       (lambda (b v)
                                         (or v b))
                                       bnds subs))))
                      (unless (or (gethash str seen)
                                  ;; The plain subsequence itself is
                                  ;; the plain tier's business.
                                  (cl-every #'null subs))
                        (puthash str t seen)
                        (push str out)
                        (when (>= (length out)
                                  daselt-abv--mnemonic-variant-cap)
                          (cl-return-from
                           daselt-abv--mnemvar-done)))))))
            ;; Single-position variants, rightmost position first.
            (cl-loop for i from (1- length) downto 0
                     do (dolist (v (nth i variants))
                          (funcall emit
                                   (let ((subs (make-list length nil)))
                                     (setf (nth i subs) v)
                                     subs))))
            ;; Double-position variants (length >= 2 only).
            (when (>= length 2)
              (cl-loop for i2 from (1- length) downto 1
                       do (cl-loop for i1 from (1- i2) downto 0
                                   do (dolist (v2 (nth i2 variants))
                                        (dolist (v1 (nth i1 variants))
                                          (funcall emit
                                                   (let ((subs
                                                          (make-list
                                                           length nil)))
                                                     (setf (nth i1 subs) v1)
                                                     (setf (nth i2 subs) v2)
                                                     subs)))))))))))
    (nreverse out)))

(cl-defmethod abv-typed-layout--string-base-letters
  ((layout daselt-abv-layout) string)
  "Daselt method: per-symbol base-layer letters of STRING.
Each symbol resolves through `daselt-abv--unique-layout-match' to
its coordinate; the letter is the layer-1 binding there,
downcased (rho -> r).  Symbols without a resolvable coordinate or
without a letter base contribute nil.  Uses the session-persistent
`daselt-abv--letter-placeval-memo' for the coordinate lookups."
  (ignore layout)
  (when (stringp string)
    (let ((daselt-abv--layout-match-cache
           daselt-abv--letter-placeval-memo))
      (mapcar (lambda (i)
                (let* ((pv (daselt-abv--unique-layout-match
                            (substring string i (1+ i)))))
                  (when pv
                    (pcase-let ((`(,_L ,r ,c) (car pv)))
                      (let ((base (daselt-coords-binding (list 1 r c))))
                        (and (stringp base)
                             (= 1 (length base))
                             (<= ?a (downcase (aref base 0)) ?z)
                             (downcase (aref base 0))))))))
              (number-sequence 0 (1- (length string)))))))

(cl-defmethod abv-typed-layout--single-symbol-strings
  ((layout daselt-abv-layout))
  "Daselt method: bindings of the assignable single-symbol placevals."
  (mapcar #'cdr (oref (oref layout placevals) single-symbol-placevals)))

(cl-defmethod abv-typed-layout--separator-strings
  ((layout daselt-abv-layout))
  "Daselt method: bindings of the separator placevals (␠, ␟).
These layer bindings share coordinates with ordinary letters, so
without an explicit exclusion the one-symbol pool and the
same-position variant search would hand them out as keys (the
word \"a\" once landed on \"a␟\")."
  (and (slot-boundp layout 'separator-placevals)
       (mapcar #'cdr (oref (oref layout placevals) separator-placevals))))


(cl-defmethod abv-typed-layout--variant-strings
  ((layout daselt-abv-layout) string)
  "Daselt method: same-position symbols of other layers.
For each position (rightmost first) the symbol's coordinate is
looked up and every other layer's binding at the SAME row/column
becomes a variant, ordered by `daselt-abv--variant-layer-order' —
so \"hl\" claims \"hL\" or the Greek lookalike \"hΛ\" before any
longer truncation is considered.  Variants must be ASSIGNABLE
symbols: bindings outside the layout's single-symbol placevals
(separator signs like \"-\", multi-char bindings) are skipped —
the placeval filters exclude them from generation, and the
layer-variation here must not smuggle them back in."
  (when (and (stringp string) (<= 1 (length string) 6))
    (let ((daselt-abv--layout-match-cache
           (make-hash-table :test 'equal))
          (assignable
           (let ((ht (make-hash-table :test 'equal)))
              (dolist (pv (oref (oref layout placevals) single-symbol-placevals) ht)
                (puthash (cdr pv) t ht))))
          (out nil))
      (cl-loop for i from (1- (length string)) downto 0
               do (let* ((char (substring string i (1+ i)))
                         (pv (daselt-abv--unique-layout-match char)))
                    (when pv
                      (pcase-let ((`(,L ,r ,c) (car pv)))
                        (dolist (L2 daselt-abv--variant-layer-order)
                          (unless (= L2 L)
                            (let ((bnd (daselt-coords-binding
                                        (list L2 r c))))
                              (when (and (stringp bnd)
                                         (not (string= bnd char))
                                         (= 1 (length bnd))
                                         (gethash bnd assignable))
                                (push (concat (substring string 0 i)
                                              bnd
                                              (substring string (1+ i)))
                                      out)))))))))
      (nreverse out))))


(defun daselt-abv--fresh-single-symbol-twin
    (base-string layout taken-p)
  "Return a free single-symbol layer twin of BASE-STRING, or nil.
BASE-STRING must be one symbol long; the symbols at its position
across all layers (case partners, Greek lookalikes, ...) are
tried in ascending layer order, so an exhausted one-letter key
degrades to a same-position twin before any two-symbol or
separator fallback.  TAKEN-P is the free-string predicate."
  (when (= 1 (length base-string))
    (let* ((pv (oref (oref layout placevals)
                     single-symbol-placevals))
           (cell (cl-find-if (lambda (c)
                               (string= (cdr c) base-string))
                             pv)))
      (when cell
        (let ((row (nth 1 (car cell)))
              (col (nth 2 (car cell))))
          (cl-loop for other in (sort (copy-sequence pv)
                                      (lambda (a b)
                                        (< (nth 0 (car a))
                                           (nth 0 (car b)))))
                   when (and (= (nth 1 (car other)) row)
                             (= (nth 2 (car other)) col)
                             (not (string= (cdr other) base-string))
                             (not (funcall taken-p (cdr other))))
                   return (cdr other)))))))

(defun daselt-abv--fresh-2symbol-candidate (root layout taken-p base-string)
  "Return a fresh free 2-symbol key string for ROOT, or nil.

TAKEN-P is the free-string predicate; BASE-STRING (the colliding
key) never counts as a candidate.

Phase A tries the in-order letter pairs of ROOT's own spelling —
most prefix-like first, then cheapest — so a colliding deep is
replaced by a different mnemonic of the word itself.

Phase A' then varies the LAYERS of those same letters
(a/A/alpha...), ranked by ergonomic cost, so a mnemonic layer
variant of the word wins over any arbitrary pair.

Phase B scans the WHOLE valid 2-symbol space of the layout
(root-placevals squared — roughly 40000 pairs) in ascending
ergonomic cost, so any free pair anywhere on the keyboard
(including all higher layers) is found, not only ring neighbors
of the base; an emoji pair is acceptable when it keeps the key at
two symbols.  The scan stops as soon as no unvisited prefix can
beat the best pair found."
  (let* ((rps (oref (oref layout placevals) root-placevals))
         ;; Phase A: mnemonic letter pairs of the root itself.
         (combos (daselt-abv--string-combinations root 2 2))
         (letter-pairs
          (delq nil
                (mapcar (lambda (combo)
                          (let ((idx-sum
                                 (apply #'+ (mapcar
                                             (lambda (elt) (cdr (car elt)))
                                             combo)))
                                (cost
                                 (apply #'+ (mapcar
                                             (lambda (elt)
                                               (daselt-abv--erg-score
                                                (car (cdr elt))))
                                             combo)))
                                (str
                                 (and (cl-every
                                       (lambda (elt)
                                         (consp (member (cdr elt) rps)))
                                       combo)
                                      (mapconcat (lambda (elt) (cddr elt))
                                                 combo))))
                            (and str
                                 (not (string= str base-string))
                                 (not (funcall taken-p str))
                                 (list idx-sum cost str))))
                        combos))))
    (or (nth 2 (car (sort letter-pairs
                          (lambda (a b)
                            (or (< (nth 0 a) (nth 0 b))
                                (and (= (nth 0 a) (nth 0 b))
                                     (< (nth 1 a) (nth 1 b))))))))
        ;; Phase A': LAYER VARIANTS of the root's own letter pairs.
        ;; The same physical keys on other layers (a/A/alpha...)
        ;; keep the key mnemonic for the word while escaping taken
        ;; base pairs.  Ranked by ergonomic cost of the variant
        ;; placevals, so the cheapest layer flip wins before any
        ;; arbitrary pair from the whole space - which would
        ;; otherwise prefer cheap digits (e.g. "10") over
        ;; memorable letter variants (e.g. "alpha-m" for "aim").
        (let ((layer-variants
               (lambda (pv)
                 (delq pv
                       (cl-remove-if-not
                        (lambda (p)
                          (equal (cdr (car p)) (cdr (car pv))))
                        rps))))
              (cands nil))
          (dolist (combo combos)
            (let* ((elt1 (car combo))
                   (elt2 (cadr combo))
                   (vs1 (cons (cdr elt1)
                              (funcall layer-variants (cdr elt1))))
                   (vs2 (cons (cdr elt2)
                              (funcall layer-variants (cdr elt2)))))
              (dolist (v1 vs1)
                (dolist (v2 vs2)
                  (let ((str (concat (cdr v1) (cdr v2))))
                    (when (and (not (string= str base-string))
                               (not (funcall taken-p str)))
                      (push (list (apply #'+ (mapcar
                                              (lambda (v)
                                                (daselt-abv--erg-score
                                                 (car v)))
                                              (list v1 v2)))
                                  str)
                            cands)))))))
          (nth 1 (car (sort cands
                            (lambda (a b)
                              (if (= (nth 0 a) (nth 0 b))
                                  (string< (nth 1 a) (nth 1 b))
                                (< (nth 0 a) (nth 0 b))))))))
        ;; Phase B: cheapest free pair over the whole space, but
        ;; pairs sharing a base letter with the root scan first —
        ;; a fully arbitrary pair (digits, unrelated emoji) stays
        ;; the last resort even at a lower ergonomic cost.
        (let* ((sorted
                (sort (mapcar (lambda (pv)
                                (cons (daselt-abv--erg-score (car pv)) pv))
                              rps)
                      (lambda (a b) (< (car a) (car b)))))
               (cmin (car (car sorted)))
               (root-letters
                (let ((ht (make-hash-table :test 'eql)))
                  (dolist (ch (string-to-list (downcase (or root ""))))
                    (when (and (>= ch ?a) (<= ch ?z))
                      (puthash ch t ht)))
                  ht))
               (pv-letter
                (lambda (pv)
                  (pcase-let ((`(,_L ,r ,c) (car pv)))
                    (let ((base (daselt-coords-binding (list 1 r c))))
                      (and (stringp base)
                           (= 1 (length base))
                           (<= ?a (downcase (aref base 0)) ?z)
                           (downcase (aref base 0)))))))
               (letter-p
                (lambda (pv)
                  (and (gethash (funcall pv-letter pv) root-letters) t)))
               (scan
                (lambda (restrict-p)
                  (let ((best nil))
                    (catch 'daselt-abv--fresh2-done
                      (dolist (a sorted)
                        (let ((ca (car a)))
                          ;; Nothing starting at A can still beat BEST.
                          (when (and best (> (+ ca cmin) (car best)))
                            (throw 'daselt-abv--fresh2-done nil))
                          (when (or (not restrict-p)
                                    (funcall letter-p (cdr a)))
                            (catch 'daselt-abv--fresh2-row
                              (dolist (b sorted)
                                (when (or (not restrict-p)
                                          (funcall letter-p (cdr b)))
                                  (let ((str (concat (cdr (cdr a))
                                                     (cdr (cdr b)))))
                                    (when (and
                                           (not (string= str base-string))
                                           (not (funcall taken-p str))
                                           ;; Digits are structurally
                                           ;; reserved (disambiguation
                                           ;; suffixes); a fresh key
                                           ;; must never start with
                                           ;; one.
                                           (not (and (>= (aref str 0) ?0)
                                                     (<= (aref str 0) ?9))))
                                      ;; Inner loop is cost-ascending: the
                                      ;; first free partner is cheapest.
                                      (setq best (cons (+ ca (car b)) str))
                                      (throw 'daselt-abv--fresh2-row
                                             nil)))))))))
                    (cdr best))))))
          (or (funcall scan t)
              (funcall scan nil))))))




(cl-defmethod abv-typed-layout-embellished-sequence-string :around
    ((seq list) (layout daselt-abv-layout) (table abv-language-table)
     &key taken-strings)
  "Fall back to the numbered default when the Daselt search fails.
The Daselt embellishment searches placeval rings and can come up
empty (e.g. for single-morph distillates whose base string is
taken); the generic numbered fallback then still produces a free
variant so typing-key generation never dead-ends."
  (or (condition-case nil
          (cl-call-next-method)
        (error nil))
      (abv-typed-layout--numbered-sequence-string
       seq layout table taken-strings)))

(defvar daselt-abv--embellish-ring-length-cap 12
  "Maximum base length for the ring-embellishment search.

Each ring variant validates every element against the layout's
per-type placeval lists (an EIEIO `slot-value' plus a linear
`member' per element, times ~3 position rings per base symbol):
for long phrase bases the ring pass costs minutes and the variants
it produces are barely distinguishable from the numbered fallback.
Longer bases skip straight to the fresh-2symbol search (single
roots) and the numbered fallback.")

(cl-defmethod abv-typed-layout-embellished-sequence-string
  ((seq list) (layout daselt-abv-layout) (table abv-language-table)
   &key taken-strings)
  "Daselt method for `abv-typed-layout-embellished-sequence-string'.

Uses `daselt-abv--embellish' to generate variations of the typing string for SEQ
until one is found that is not already in TAKEN-STRINGS. TAKEN-STRINGS may be
either a hash-table or a list.

Candidate order: case variants of the base string (same letters,
some shifted to the layout's paired layer, e.g. \"tT\" for a taken
\"tt\") come first — they stay mnemonic at a small ergonomic cost —
with the rightmost flip preferred (\"tT\" before \"Tt\").  For a
single-root sequence, a fresh 2-symbol combination follows
(`daselt-abv--fresh-2symbol-candidate'): first the other in-order
letter pairs of the root's own spelling, then the WHOLE 2-symbol
space in ascending ergonomic cost — every free pair on any layer
qualifies, not only ring neighbors of the base.  Ring variants of
the base come next; 3-symbol mnemonic combinations of the root's
letters are the last resort (rarely necessary once the whole
2-symbol space is searched).  Separator-suffixed (␟/␠) variants
reuse the candidate order; the numbered fallback of the generic
`:around' method remains the final default."
  (let* ((language (oref table language))
         (taken-p (daselt-abv--taken-p taken-strings))
         (indexed-coords
          (apply #'append
                 (cl-mapcar
                  (lambda (morph idx)
                    (let ((coords (abv-plain-value
                                   (abv-typed-layout-morph-typing morph layout language))))
                      (if (daselt-coords-p coords)
                          (list (cons idx coords))
                        (mapcar (lambda (coord) (cons idx coord))
                                coords))))
                  seq (daselt-base-cardinal (length seq)))))
         (base-coords (mapcar #'cdr indexed-coords))
         (base-string (apply #'concat
                             (mapcar #'daselt-coords-binding base-coords)))
         (base-chars (string-to-list base-string))
         (base-data
          (list (cl-mapcar
                 (lambda (char idx-coords)
                   (let ((idx (car idx-coords))
                         (coords (cdr idx-coords)))
                     (cons (cons char idx)
                           (cons coords (char-to-string char)))))
                 base-chars indexed-coords)))
         (base-length (length (car base-data)))
         (onep (and (= 1 base-length)
                    (= 1 (length (cddaar base-data)))))
         (embellishment-search-rings
          (daselt-abv--make-search-rings base-length))
         (order-cands
          (lambda (cands)
            "Order (COST . STR) pairs: case variants of the base
string first (rightmost flip ahead), then ascending cost."
            (sort cands
                  (lambda (a b)
                    (let ((case-a (daselt-abv--case-variant-p
                                   (cdr a) base-string))
                          (case-b (daselt-abv--case-variant-p
                                   (cdr b) base-string)))
                      (cond
                       ((not (eq case-a case-b)) case-a)
                       ((/= (car a) (car b)) (< (car a) (car b)))
                       (t (> (daselt-abv--first-diff-index (cdr a) base-string)
                             (daselt-abv--first-diff-index (cdr b)
                                                           base-string)))))))))
          final-string)
     (unless onep
       (catch 'found-unique
         (let ((found-cands nil))
           (unless (> base-length daselt-abv--embellish-ring-length-cap)
           (dolist (ring embellishment-search-rings)
            (let* ((embellished-typings
                    (daselt-abv--embellish base-data ring))
                   (embellished-pairs
                    (mapcar
                     (lambda (typings)
                       (let ((pv-seq (mapcar #'cdr typings)))
                         (when (cl-every
                                (lambda (rpv)
                                  (and-let*
                                      ((meta (car rpv))
                                       (pv (cdr rpv))
                                       (idx (cdr meta))
                                       (orig (nth idx seq))
                                       (type (cdr orig))
                                       (slot-sym
                                        (if (memq type '(formal morph-separator))
                                            'separator-placevals
                                          (intern
                                           (concat (symbol-name type)
                                                   "-placevals"))))
                                       (type-pvs (slot-value layout slot-sym)))
                                    (member pv type-pvs)))
                                typings)
                            (let ((str (mapconcat #'cdr pv-seq)))
                              (when str
                                ;; Ergonomic cost of the variant:
                                ;; the cheapest free variant wins,
                                ;; not the first ring's first hit
                                ;; (which could land on an emoji
                                ;; layer).
                                (cons (apply #'+
                                             (mapcar
                                              (lambda (pv)
                                                (daselt-abv--erg-score
                                                 (car pv)))
                                              pv-seq))
                                      str))))))
                      embellished-typings)))
               (setq found-cands (append found-cands
                                         (delq nil embellished-pairs))))))
           (let* ((ordered (funcall order-cands found-cands))
                 (case-variants
                  (delq nil (mapcar (lambda (pair)
                                      (and (daselt-abv--case-variant-p
                                            (cdr pair) base-string)
                                           pair))
                                    ordered)))
                 (rest (delq nil (mapcar (lambda (pair)
                                           (and (not
                                                 (daselt-abv--case-variant-p
                                                  (cdr pair) base-string))
                                                pair))
                                         ordered))))
            (setq found-cands (delq nil (mapcar #'cdr ordered)))
            (dolist (pair case-variants)
              (when (and (cdr pair) (not (funcall taken-p (cdr pair))))
                (setq final-string (cdr pair))
                (throw 'found-unique t)))
            ;; Fresh 2-symbol search for single roots: a NEW
            ;; 2-symbol combo anywhere in the layout's ~40000-pair
            ;; space (own letters first, then whole space in
            ;; ergonomic order) beats longer and ring-neighbor
            ;; variants.
            (when (and (= (length seq) 1)
                       (eq (cdr (car seq)) 'root))
              (let ((fresh (daselt-abv--fresh-2symbol-candidate
                            (car (car seq)) layout taken-p base-string)))
                (when fresh
                  (setq final-string fresh)
                  (throw 'found-unique t))))
            (dolist (pair rest)
              (when (and (cdr pair) (not (funcall taken-p (cdr pair))))
                (setq final-string (cdr pair))
                (throw 'found-unique t)))
            ;; Last mnemonic resort for single roots: 3-symbol
            ;; combinations of the root's own letters (rarely
            ;; necessary once the whole 2-symbol space is
            ;; searched, e.g. form -> fom when everything short
            ;; collided).
            (when (and (= (length seq) 1)
                       (eq (cdr (car seq)) 'root))
              (let* ((root (car (car seq)))
                     (combos (daselt-abv--string-combinations root 3 3))
                     (rps (oref (oref layout placevals) root-placevals)))
                (dolist (combo combos)
                  (let ((str (and (cl-every (lambda (elt)
                                              (member (cdr elt) rps))
                                            combo)
                                  (mapconcat (lambda (elt) (cddr elt))
                                             combo))))
                    (when (and str
                               (not (string= str base-string))
                               (not (funcall taken-p str)))
                      (setq final-string str)
                      (throw 'found-unique t)))))))
          ;; The suffix passes only make sense with candidates;
          ;; otherwise they would spin forever below.
          (when found-cands
            (let ((i 0))
              (cl-loop
               do (dolist (candidate found-cands)
                    (let ((emb (format "%s\u241F%s" candidate (if (> i 0) i ""))))
                      (unless (funcall taken-p emb)
                        (setq final-string emb)
                        (throw 'found-unique t))))
               do (dolist (candidate found-cands)
                    (let ((emb (format "%s\u2420%s" candidate (if (> i 0) i ""))))
                      (unless (funcall taken-p emb)
                        (setq final-string emb)
                        (throw 'found-unique t))))
               do (cl-incf i)))))))
      ;; Single-symbol bases (ONEP) never entered the ring
      ;; search above, but they deserve the same mnemonic
      ;; rescue: first a single-symbol LAYER TWIN of the base
      ;; (same position, another layer — the case-shifted or
      ;; Greek-lookalike partner), then a fresh 2-symbol
      ;; combination of the root's own letters (layer variants
      ;; included), then 3-symbol combinations, BEFORE the
      ;; separator/numbered fallbacks fire - otherwise a
      ;; single-letter base with exhausted separator suffixes
      ;; degrades to the numbered fallback with an empty base
      ;; ("aim" -> "10" instead of a letter variant like "αι"),
      ;; or straight to a separator key ("I" -> "i\u241F"
      ;; instead of the iota twin).
      (when (and onep
                 (= (length seq) 1)
                 (eq (cdr (car seq)) 'root)
                 (not final-string))
        (or (setq final-string
                  (daselt-abv--fresh-single-symbol-twin
                   base-string layout taken-p))
            (setq final-string
                  (daselt-abv--fresh-2symbol-candidate
                   (car (car seq)) layout taken-p base-string))
            (let* ((root (car (car seq)))
                   (combos (daselt-abv--string-combinations root 3 3))
                   (rps (oref (oref layout placevals) root-placevals)))
              (dolist (combo combos)
                (unless final-string
                  (let ((str (and (cl-every
                                   (lambda (elt)
                                     (member (cdr elt) rps))
                                   combo)
                                  (mapconcat (lambda (elt) (cddr elt))
                                             combo))))
                    (when (and str
                               (not (string= str base-string))
                               (not (funcall taken-p str)))
                      (setq final-string str))))))))
      (or final-string
          (let* ((bs (apply #'concat
                            (mapcar (lambda (elt) (cddr elt))
                                    (car base-data))))
                 (fallback (concat bs "\u241F")))
            (if (not (funcall taken-p fallback))
                fallback
              (let ((i 1))
                (cl-loop
                 do (let ((cand (format "%s\u241F%d" bs i)))
                      (unless (funcall taken-p cand)
                        (cl-return cand))
                      (cl-incf i)))))))))

(provide 'daselt-abv-typing)
;;; daselt-abv-typing.el ends here
