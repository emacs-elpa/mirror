;;; daselt-abv-syntax-help-tests.el --- Tests for daselt-abv-syntax-help  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Keywords: abbrev

;; This program is free software; you can redistribute it and/or
;; modify it under the terms of the GNU General Public License as
;; published by the Free Software Foundation, either version 3 of the
;; License, or (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Tests for `daselt-abv-syntax-help': the enumeration
;; specializations round-trip through the decoding generics of
;; `daselt-abv-inflection', and the grid visualizations draw labels
;; into the current buffer.

;;; Code:

(require 'ert)
(require 'cl-lib)
(require 'daselt-abv-tests--setup)
(require 'daselt-abv-syntax-help)

(defmacro daselt-abv-syntax-help--with-layout (layout &rest body)
  "Bind LAYOUT to the default Daselt layout and run BODY.
Skip when the Daselt keyboard environment is unavailable."
  (declare (indent 1))
  `(let ((,layout (and (boundp 'daselt-abv--default-layout)
                       daselt-abv--default-layout)))
     (skip-unless ,layout)
     ,@body))

;;;; Inflection trigger groups

(ert-deftest daselt-abv-syntax-help-verb-groups ()
  "The verb groups have two characters with non-empty entries."
  (daselt-abv-syntax-help--with-layout layout
    (let ((groups (abv-layout-inflection-trigger-groups layout 'verb)))
      (should (= 2 (length groups)))
      (should (plist-get (car groups) :title))
      (should (plist-get (cadr groups) :title))
      (should (< 0 (length (plist-get (car groups) :entries))))
      (should (< 0 (length (plist-get (cadr groups) :entries)))))))

(ert-deftest daselt-abv-syntax-help-verb-first-char-roundtrip ()
  "Every first-char entry decodes back to its plist."
  (daselt-abv-syntax-help--with-layout layout
    (dolist (entry (plist-get
                    (car (abv-layout-inflection-trigger-groups
                          layout 'verb))
                    :entries))
      (should (equal (cdr entry)
                     (abv-layout-inflection-info
                      layout 'verb (car entry)))))))

(ert-deftest daselt-abv-syntax-help-verb-combo-roundtrip ()
  "Combined char-1/char-2 triggers decode to the appended plists."
  (daselt-abv-syntax-help--with-layout layout
    (let* ((groups (abv-layout-inflection-trigger-groups layout 'verb))
           (g1 (plist-get (car groups) :entries))
           (g2 (plist-get (cadr groups) :entries)))
      ;; All first chars against the first second char.
      (dolist (e1 g1)
        (should (equal (append (cdr e1) (cdr (car g2)))
                       (abv-layout-inflection-info
                        layout 'verb (concat (car e1)
                                             (car (car g2)))))))
      ;; All second chars against the first first char.
      (dolist (e2 g2)
        (should (equal (append (cdr (car g1)) (cdr e2))
                       (abv-layout-inflection-info
                        layout 'verb (concat (car (car g1))
                                             (car e2)))))))))

(ert-deftest daselt-abv-syntax-help-single-group-roundtrip ()
  "Noun, adjective, adverb and determiner entries round-trip."
  (daselt-abv-syntax-help--with-layout layout
    (dolist (type '(noun adjective adverb determiner))
      (let ((groups (abv-layout-inflection-trigger-groups layout type)))
        (should (= 1 (length groups)))
        (should (< 0 (length (plist-get (car groups) :entries))))
        (dolist (entry (plist-get (car groups) :entries))
          (should (equal (cdr entry)
                         (abv-layout-inflection-info
                          layout type (car entry)))))))))

(ert-deftest daselt-abv-syntax-help-pronoun-roundtrip ()
  "Pronoun groups are two; combined triggers round-trip."
  (daselt-abv-syntax-help--with-layout layout
    (let* ((groups (abv-layout-inflection-trigger-groups layout 'pronoun))
           (g1 (plist-get (car groups) :entries))
           (g2 (plist-get (cadr groups) :entries)))
      (should (= 2 (length groups)))
      (should (< 0 (length g1)))
      (should (< 0 (length g2)))
      (dolist (e1 g1)
        (should (equal (cdr e1)
                       (abv-layout-inflection-info
                        layout 'pronoun (car e1)))))
      (dolist (e2 g2)
        (should (equal (append (cdr (car g1)) (cdr e2))
                       (abv-layout-inflection-info
                        layout 'pronoun (concat (car (car g1))
                                                (car e2)))))))))

(ert-deftest daselt-abv-syntax-help-unknown-type-nil ()
  "An unsupported word type yields no groups."
  (daselt-abv-syntax-help--with-layout layout
    (should (null (abv-layout-inflection-trigger-groups
                   layout 'preposition)))))

(ert-deftest daselt-abv-syntax-help-optional-second-chars ()
  "Verb and pronoun second-char groups are optional; others not."
  (daselt-abv-syntax-help--with-layout layout
    (dolist (type '(verb pronoun))
      (let ((groups (abv-layout-inflection-trigger-groups layout type)))
        (should (plist-get (cadr groups) :optional))
        (should (not (plist-get (car groups) :optional)))))
    ;; Single-group types carry no optional marks.
    (dolist (type '(noun adjective adverb determiner))
      (let ((groups (abv-layout-inflection-trigger-groups layout type)))
        (should (not (plist-get (car groups) :optional)))))))

;;;; Word-type triggers

(ert-deftest daselt-abv-syntax-help-word-type-roundtrip ()
  "Word-type entries decode back to their type."
  (daselt-abv-syntax-help--with-layout layout
    (let ((entries (abv-layout-word-type-trigger-entries layout)))
      (should (< 0 (length entries)))
      (dolist (entry entries)
        (should (equal (cdr entry)
                       (abv-layout-word-type-from-string
                        layout (car entry))))))))

;;;; Conversion triggers

(ert-deftest daselt-abv-syntax-help-from-types ()
  "The source types come from the conversion-method table."
  (should (memq 'verb (daselt-abv-syntax-help--from-types)))
  (should (memq 'adjective (daselt-abv-syntax-help--from-types))))

(ert-deftest daselt-abv-syntax-help-conversion-roundtrip ()
  "Verb conversion entries decode back to their method."
  (daselt-abv-syntax-help--with-layout layout
    (let ((entries (abv-layout-conversion-trigger-entries layout 'verb)))
      (should (< 0 (length entries)))
      (dolist (entry entries)
        (should (symbolp (car (cdr entry))))
        (should (equal (cdr (cdr entry))
                       (abv-layout-conversion-method-from-string
                        layout (car entry) nil 'verb)))))))

(ert-deftest daselt-abv-syntax-help-conversion-adjective-adverb-entries ()
  "Adjective conversion entries still list the adverb target.
The adjective->adverb entry of `daselt-abv--conversion-method-table'
carries the `language' sentinel (no explicit affix: the language's
rules apply), but its keys must remain enumerated for the help
grid."
  (daselt-abv-syntax-help--with-layout layout
    (let ((entries (abv-layout-conversion-trigger-entries layout 'adjective)))
      (should (< 0 (length entries)))
      (should (cl-some (lambda (entry) (eq 'adverb (cadr entry)))
                       entries)))))

(ert-deftest daselt-abv-syntax-help-conversion-all-from-types ()
  "With no FROM-TYPE, entries cover every source type."
  (daselt-abv-syntax-help--with-layout layout
    (should (< 0 (length
                  (abv-layout-conversion-trigger-entries layout nil))))))

(ert-deftest daselt-abv-syntax-help-conversion-first-layer-entries ()
  "First-layer conversion triggers carry a nil method.
They resolve at expansion time to the word's stored
conversion-default, the language's regex-matched conversion
suffix, or the key's position affix, so the entry itself carries
no method while its position affix remains decodable."
  (daselt-abv-syntax-help--with-layout layout
    (let ((entries (abv-layout-conversion-trigger-entries layout 'noun))
          (first-layer nil))
      (should (< 0 (length entries)))
      (dolist (entry entries)
        (let* ((info (cdr entry))
               (method (cdr info))
               (coord (car (abv-layout-char-placeval
                            layout (string-to-char (car entry))))))
          (when (and (member (car info) '(verb adjective adverb))
                     (= 1 (daselt-abv--coord-layer coord)))
            (should (null method))
            (should (abv-layout-position-affix-from-string
                     layout (car entry) nil 'noun))
            (push entry first-layer))))
      (should first-layer))))

;;;; Grid visualization

(ert-deftest daselt-abv-syntax-help-draw-inflection-grid ()
  "The noun inflection grid draws trigger labels into the buffer."
  (daselt-abv-syntax-help--with-layout layout
    (with-temp-buffer
      (abv-layout-visualize-inflection-triggers layout 'noun)
      (should (string-match-p "Inflection triggers for noun"
                              (buffer-string)))
      (should (string-match-p "sg" (buffer-string)))
      (should (string-match-p "genitive" (buffer-string))))))

(ert-deftest daselt-abv-syntax-help-draw-verb-grid ()
  "The verb grid draws both character sections."
  (daselt-abv-syntax-help--with-layout layout
    (with-temp-buffer
      (abv-layout-visualize-inflection-triggers layout 'verb)
      (should (string-match-p "Verb char 1" (buffer-string)))
      (should (string-match-p "Verb char 2" (buffer-string)))
      (should (string-match-p "past" (buffer-string)))
      (should (string-match-p "indicative" (buffer-string))))))

(ert-deftest daselt-abv-syntax-help-draw-word-type-grid ()
  "The word-type grid draws type labels into the buffer."
  (daselt-abv-syntax-help--with-layout layout
    (with-temp-buffer
      (abv-layout-visualize-word-type-triggers layout)
      (should (string-match-p "Word-type triggers" (buffer-string)))
      (should (string-match-p "verb" (buffer-string)))
      (should (string-match-p "noun" (buffer-string))))))

(ert-deftest daselt-abv-syntax-help-draw-conversion-grid ()
  "The conversion grid draws suffix labels into the buffer."
  (daselt-abv-syntax-help--with-layout layout
    (with-temp-buffer
      (abv-layout-visualize-conversion-triggers layout 'verb)
      (should (string-match-p "Conversion triggers from verb"
                              (buffer-string)))
      (should (string-match-p "-ment" (buffer-string)))
      (should (string-match-p "-ion" (buffer-string))))))

(ert-deftest daselt-abv-syntax-help-draw-conversion-needs-from-type ()
  "The Daselt conversion grid rejects a missing FROM-TYPE."
  (daselt-abv-syntax-help--with-layout layout
    (should-error (abv-layout-visualize-conversion-triggers layout))))

(provide 'daselt-abv-syntax-help-tests)
;;; daselt-abv-syntax-help-tests.el ends here
