;;; daselt-abv-layout-tests.el --- Tests for daselt-abv-layout  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; Author: Alexander Praehauser <ahprae@protonmail.com>
;; Keywords: abbrev

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Tests for the foundation module `daselt-abv-layout': class,
;; default layout generation, placeval helpers, indexed-sequence
;; helpers and coordinate accessors.

;;; Code:

(require 'ert)
(require 'cl-lib)
(require 'daselt-abv-tests--setup)
(require 'daselt-abv-layout)


;;;; Class & default layout

(ert-deftest daselt-abv-layout-class-is-defined ()
  "The `daselt-abv-layout' class should be defined."
  (should (find-class 'daselt-abv-layout nil)))

(ert-deftest daselt-abv-layout-default-layout-bound ()
  "`daselt-abv--default-layout' should be bound to an instance."
  (should (boundp 'daselt-abv--default-layout))
  (should (object-of-class-p daselt-abv--default-layout 'daselt-abv-layout)))

(ert-deftest daselt-abv-layout-default-layout-slots ()
  "Default layout has the expected precomputed slots."
  (let ((l daselt-abv--default-layout))
    (should (string= (oref l name) "daselt-default"))
    (should (consp (oref l layer-pairs)))
    (should (equal (oref l layer-pairs) '((1 . 2) (4 . 3) (5 . 6) (8 . 7))))
    (should (consp (oref (oref l placevals) prefix-placevals)))
    (should (consp (oref (oref l placevals) suffix-placevals)))
    (should (consp (oref (oref l placevals) infix-placevals)))
    (should (consp (oref (oref l placevals) root-placevals)))
    (should (consp (oref (oref l placevals) standalone-placevals)))
    (should (object-of-class-p (oref l weights) 'abv-weights))))

(ert-deftest daselt-abv-layout-class-can-be-instantiated ()
  "A `daselt-abv-layout' can be constructed directly."
  (let ((layout (make-instance 'daselt-abv-layout :name "test")))
    (should (object-of-class-p layout 'daselt-abv-layout))
    (should (string= (oref layout name) "test"))
    (should (null (oref layout letter-frequency-alist)))
    (should (= 100 (oref (oref layout options) prefer-first-up-to)))))

(ert-deftest daselt-abv-layout-default-layout-excludes-separators ()
  "Expansion separators never appear as typing symbols.
The expansion-beginning/end separators (and the syntax separator)
delimit expansion islands while typing, so a placeval rendering to
one of them would make the generated typing keys ambiguous."
  (let* ((l daselt-abv--default-layout)
         (parse-data (abv-parse-data))
         (seps (delq nil
                     (list (and (characterp (oref parse-data
                                                  expansion-beginning-separator))
                                (string (oref parse-data
                                              expansion-beginning-separator)))
                           (and (characterp (oref parse-data
                                                  expansion-end-separator))
                                (string (oref parse-data
                                              expansion-end-separator)))
                           (and (characterp (oref parse-data syntax-separator))
                                (string (oref parse-data
                                              syntax-separator))))))
         (slots '(single-symbol-placevals prefix-placevals
                  suffix-placevals infix-placevals root-placevals
                  standalone-placevals standard-placevals)))
    (dolist (slot slots)
      (dolist (pv (slot-value l slot))
        (should-not (member (cdr pv) seps))))))

(ert-deftest daselt-abv-layout-filter-to-paired ()
  "`daselt-abv--filter-to-paired' keeps only lower-pair members.
Note: pairs are stored as (LOWER . UPPER); the lookup is by LOWER
layer only, so upper-layer placevals are dropped because their layer
is not a key in `pairs'."
  (let ((placevals '(((1 0 1) . "a")   ; lower=1, pair=2 -> check (2 0 1) yes
                     ((2 0 1) . "A")   ; lower=nil (2 isn't a key) -> dropped
                     ((1 0 2) . "b")   ; lower=1, pair=2 -> check (2 0 2) no
                     ((4 0 1) . "c")   ; lower=4, pair=3 -> check (3 0 1) yes
                     ((3 0 1) . "C")))) ; lower=nil -> dropped
    (should (equal (daselt-abv--filter-to-paired placevals)
                   '(((1 0 1) . "a") ((4 0 1) . "c"))))))


;;;; abv-layout-string

(ert-deftest daselt-abv-layout-string-passes-strings ()
  "`abv-layout-string' returns strings unchanged."
  (should (string= "hello" (abv-layout-string daselt-abv--default-layout "hello"))))


;;;; Placeval helpers

(ert-deftest daselt-abv-layout-seq-placevals-plain ()
  "Plain seq is returned unchanged."
  (let ((seq '(((1 0 1) . "a") ((1 0 2) . "b"))))
    (should (eq seq (daselt-abv--seq-placevals seq)))))

(ert-deftest daselt-abv-layout-seq-placevals-indexed ()
  "Indexed seq is unwrapped into plain placevals."
  (let ((indexed '((("a" . 0) (1 0 1) . "a")
                   (("b" . 1) (1 0 2) . "b"))))
    (should (equal (daselt-abv--seq-placevals indexed)
                   '(((1 0 1) . "a") ((1 0 2) . "b"))))))

(ert-deftest daselt-abv-layout-placevals->coord-hash ()
  "Builds a coord -> binding hash from a placeval alist."
  (let* ((placevals '(((1 0 1) . "a") ((1 0 2) . "b")))
         (ht (daselt-abv--placevals->coord-hash placevals)))
    (should (hash-table-p ht))
    (should (equal (gethash '(1 0 1) ht) "a"))
    (should (equal (gethash '(1 0 2) ht) "b"))
    (should (null (gethash '(9 9 9) ht)))))

(ert-deftest daselt-abv-layout-keys ()
  "`daselt-abv--keys' returns the keys of a hash."
  (let ((ht (make-hash-table :test 'equal)))
    (puthash 'a 1 ht)
    (puthash 'b 2 ht)
    (puthash 'c 3 ht)
    (let ((keys (daselt-abv--keys ht)))
      (should (= 3 (length keys)))
      (should (member 'a keys))
      (should (member 'b keys))
      (should (member 'c keys)))))

(ert-deftest daselt-abv-layout-letter-predicate ()
  "`daselt-abv--letter-p' recognizes single ASCII letters."
  (should (daselt-abv--letter-p "a"))
  (should (daselt-abv--letter-p "Z"))
  (should-not (daselt-abv--letter-p "ab"))
  (should-not (daselt-abv--letter-p ""))
  (should-not (daselt-abv--letter-p "1"))
  (should-not (daselt-abv--letter-p "?"))
  (should-not (daselt-abv--letter-p 5)))

(ert-deftest daselt-abv-layout-down ()
  "`daselt-abv--down' lowercases single chars and leaves others alone."
  (should (string= "a" (daselt-abv--down "A")))
  (should (string= "z" (daselt-abv--down "z")))
  (should (string= "AB" (daselt-abv--down "AB")))
  (should (string= "hello" (daselt-abv--down "hello"))))

(ert-deftest daselt-abv-layout-coord-layers-in-order ()
  "`daselt-abv--coord-layers-in-order' returns known orderings."
  (should (equal '(1 2 4 6 5 7 3 8) (daselt-abv--coord-layers-in-order nil)))
  (should (equal '(2 1 4 6 5 7 3 8) (daselt-abv--coord-layers-in-order t))))


;;;; Coordinate accessors

(ert-deftest daselt-abv-layout-coord-accessors ()
  "Accessor functions extract the right components of a coordinate."
  (let ((coord '(3 -1 4)))
    (should (= 3 (daselt-abv--coord-layer coord)))
    (should (= -1 (daselt-abv--coord-row coord)))
    (should (= 4 (daselt-abv--coord-col coord)))))

(ert-deftest daselt-abv-layout-lower-layer-predicate ()
  "`daselt-abv--lower-layer-p' recognizes lower paired layers."
  (should (daselt-abv--lower-layer-p 1))
  (should (daselt-abv--lower-layer-p 4))
  (should (daselt-abv--lower-layer-p 5))
  (should (daselt-abv--lower-layer-p 8))
  (should-not (daselt-abv--lower-layer-p 2))
  (should-not (daselt-abv--lower-layer-p 3))
  (should-not (daselt-abv--lower-layer-p 6))
  (should-not (daselt-abv--lower-layer-p 7)))


;;;; Indexed-sequence helpers

(ert-deftest daselt-abv-layout-first-index-of-letter ()
  "`daselt-abv--first-index-of-letter' returns 0-based index or length."
  (should (= 0 (daselt-abv--first-index-of-letter "banana" "b")))
  (should (= 1 (daselt-abv--first-index-of-letter "banana" "a")))
  (should (= 2 (daselt-abv--first-index-of-letter "banana" "n")))
  ;; Case-insensitive lookup
  (should (= 0 (daselt-abv--first-index-of-letter "Banana" "B")))
  (should (= 0 (daselt-abv--first-index-of-letter "banana" "B")))
  ;; Letter not in root -> length of root
  (should (= 6 (daselt-abv--first-index-of-letter "banana" "z")))
  ;; Multi-char letter falls back to length of root
  (should (= 6 (daselt-abv--first-index-of-letter "banana" "ab"))))

(ert-deftest daselt-abv-layout-index-plain-seq ()
  "`daselt-abv--index-plain-seq' attaches letter+index metadata."
  (let* ((plain '(((1 0 1) . "a") ((1 0 2) . "b")))
         (indexed (daselt-abv--index-plain-seq "ab" plain)))
    ;; Each element is ((LETTER . INDEX) . PLACEVAL) - a cons cell whose
    ;; car is (LETTER . INDEX) and cdr is the original placeval.
    (should (equal (car (car indexed)) '("a" . 0)))
    (should (equal (cdr (car indexed)) '((1 0 1) . "a")))
    (should (equal (car (cadr indexed)) '("b" . 1)))
    (should (equal (cdr (cadr indexed)) '((1 0 2) . "b")))))

(ert-deftest daselt-abv-layout-seq-coords ()
  "`daselt-abv--seq-coords' extracts coordinates from plain or indexed seq."
  (let ((plain '(((1 0 1) . "a") ((1 0 2) . "b")))
        (indexed '((("a" . 0) (1 0 1) . "a") (("b" . 1) (1 0 2) . "b"))))
    (should (equal (daselt-abv--seq-coords plain) '((1 0 1) (1 0 2))))
    (should (equal (daselt-abv--seq-coords indexed) '((1 0 1) (1 0 2))))))


;;;; Affix and letter helpers

(ert-deftest daselt-abv-layout-affix-letters-basic ()
  "`daselt-abv--affix-letters' returns unique lowercase letters in order."
  (should (equal '("a" "b" "c") (daselt-abv--affix-letters "abc")))
  ;; Duplicates removed, in first-seen order.
  (should (equal '("a" "b") (daselt-abv--affix-letters "abba")))
  ;; Non-letters ignored.
  (should (equal '("a" "b") (daselt-abv--affix-letters "a1b2")))
  ;; Bracketed groups: a letter alone in [] is still extracted.
  (should (equal '("a" "b" "c") (daselt-abv--affix-letters "a[b]c"))))

(ert-deftest daselt-abv-layout-letter-rarity ()
  "`daselt-abv--letter-rarity' counts coords binding to LETTER."
  (let ((preferred (make-hash-table :test 'equal)))
    (puthash '(1 0 1) "a" preferred)
    (puthash '(2 0 1) "A" preferred)
    (puthash '(1 0 2) "b" preferred)
    ;; 'a' has two coords ((1 0 1) "a" and (2 0 1) "A")
    (should (= 2 (daselt-abv--letter-rarity "a" preferred)))
    (should (= 1 (daselt-abv--letter-rarity "b" preferred)))
    (should (= 0 (daselt-abv--letter-rarity "z" preferred)))))

(ert-deftest daselt-abv-layout-complement-hash ()
  "`daselt-abv--complement-hash' subtracts subset from universe."
  (let ((univ (make-hash-table :test 'equal))
        (subset (make-hash-table :test 'equal)))
    (puthash 'a 1 univ)
    (puthash 'b 2 univ)
    (puthash 'c 3 univ)
    (puthash 'a 10 subset)
    (let ((compl (daselt-abv--complement-hash univ subset)))
      (should (null (gethash 'a compl)))
      (should (equal 2 (gethash 'b compl)))
      (should (equal 3 (gethash 'c compl))))))


;;;; Frequency normalization & sorting

(ert-deftest daselt-abv-layout-normalize-frequencies-strings ()
  "`daselt-abv--normalize-frequencies' keeps positive (string . count)."
  (should (equal '(("a" . 3) ("b" . 1))
                 (daselt-abv--normalize-frequencies '(("a" . 3) ("b" . 1)))))
  ;; Drop non-positive counts and non-string keys (after coercion).
  (should (equal '(("a" . 3))
                 (daselt-abv--normalize-frequencies
                  '(("a" . 3) ("b" . 0) ("c" . -2)))))
  ;; Symbol names accepted.
  (should (equal '(("foo" . 2))
                 (daselt-abv--normalize-frequencies '((foo . 2))))))

(ert-deftest daselt-abv-layout-sorted-affixes-by-frequency ()
  "Affixes are sorted by descending frequency."
  (let ((freq '(("a" . 1) ("b" . 5) ("c" . 3))))
    (should (equal '("b" "c" "a")
                   (daselt-abv--sorted-affixes-by-frequency '("a" "b" "c") freq)))))

(ert-deftest daselt-abv-layout-free-candidates ()
  "`daselt-abv--free-candidates' returns coords with zero count."
  (let ((preferred (make-hash-table :test 'equal))
        (counts (make-hash-table :test 'equal)))
    (puthash 'a "x" preferred)
    (puthash 'b "y" preferred)
    (puthash 'c "z" preferred)
    (puthash 'a 1 counts)  ; a is used
    (let ((free (daselt-abv--free-candidates preferred counts)))
      (should (member 'b free))
      (should (member 'c free))
      (should-not (member 'a free)))))


;;;; Table->bindlist helpers

(ert-deftest daselt-abv-layout-table->bindlist-var ()
  "`daselt-abv--table->bindlist-var' rewrites -table to -bindlist."
  (should (eq 'foo-bindlist
              (daselt-abv--table->bindlist-var 'foo-table)))
  (should (eq 'daselt-abv-prefix-bindlist
              (daselt-abv--table->bindlist-var 'daselt-abv-prefix-table))))


;;;; Lookup methods

(ert-deftest daselt-abv-layout-lookup-root-nil-when-empty ()
  "`abv-layout-lookup-root' returns nil when root-table is empty.

The method references the global `daselt-abv--default-layout' rather
than its argument.  Since `daselt-abv-layout' has no `root-table' slot
(it lives on `abv-typing-graph'), we test the related affix lookup path
instead, which goes through a bound table symbol."
  (let* ((layout daselt-abv--default-layout)
         (result (condition-case nil
                    (abv-layout-lookup-root layout "non-existent-root")
                  (error nil))))
    (should (null result))))

(ert-deftest daselt-abv-layout-lookup-affix-unknown-table-id-errors ()
  "`abv-layout-lookup-affix' errors on unknown table-id."
  (should-error (abv-layout-lookup-affix daselt-abv--default-layout 'unknown "x")
                :type 'user-error))


;;;; parse-data-separators

(ert-deftest daselt-abv-layout-parse-data-separators-nil-no-data ()
  "`daselt-abv--parse-data-separators' returns nil for nil."
  (should (null (daselt-abv--parse-data-separators nil))))

(ert-deftest daselt-abv-layout-filter-placevals-by-separators ()
  "`daselt-abv--filter-placevals-by-separators' filters by char."
  (let ((placevals '(((1 0 1) . "a") ((1 0 2) . "-") ((1 0 3) . "."))))
    ;; No separators: identity.
    (should (equal placevals (daselt-abv--filter-placevals-by-separators placevals nil)))
    ;; Remove "-" and ".".
    (should (equal '(((1 0 1) . "a"))
                   (daselt-abv--filter-placevals-by-separators placevals '(?- ?.))))))


(provide 'daselt-abv-layout-tests)
;;; daselt-abv-layout-tests.el ends here
