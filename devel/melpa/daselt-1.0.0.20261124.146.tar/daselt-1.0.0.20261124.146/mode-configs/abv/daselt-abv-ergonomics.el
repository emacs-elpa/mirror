;;; daselt-abv-ergonomics.el --- Daselt abv scoring (ergonomic, availability, mnemonic)  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; License: GPL-3+

;;; Commentary:

;; Scoring module for the Daselt abv integration.  Contains the
;; ergonomic, availability, mnemonic, collision-penalty and overall
;; candidate scoring functions used by the assignment and deep
;; generation algorithms in `daselt-abv-typing'.

;;; Code:

(require 'daselt-abv-layout)
(require 'abv-corpus)
(require 'abv-weights)
(require 'cl-lib)

;;;; Specialization shim for `abv-layout-ease'

(cl-defmethod abv-layout-ease ((_layout daselt-abv-layout) seq weights)
  "Compute ergonomic ease for SEQ using WEIGHTS for Daselt layouts.

This specialization currently delegates to the base method."
  (daselt-abv--ergonomic-score seq weights))

;;;; Ergonomic cost helpers

(defvar daselt-abv--default-weights nil
  "Cached default `abv-weights' instance for 1-arg callers.")

(defun daselt-abv--weights ()
  "Return the cached default `abv-weights' instance."
  (or daselt-abv--default-weights
      (setq daselt-abv--default-weights (abv-weights))))

(defun daselt-abv--erg-score (coord &optional wobj)
  "Return a rough ergonomic cost (lower is better) for COORD.

The row penalty is asymmetric (WOBJ slots `row-pen-top' and
`row-pen-bottom'): Dvorak's patent calls the bottom row
exceedingly slow while the top row is merely off-home.  Column
costs follow the AdNW finger-strength ladder with the pinky
surcharge folded in; layer costs mirror the hold-column
reachability ranking.  All tables live in WOBJ (an `abv-weights'
instance) so they can be tuned without code changes."
  (pcase-let ((`(,L ,row ,col) coord))
    (let* ((w (or wobj (daselt-abv--weights)))
           (abscol (abs col))
           (row-pen (cond ((= row 0) 0.0)
                          ((< row 0) (oref w row-pen-top))
                          (t (oref w row-pen-bottom))))
           (col-pen (or (alist-get abscol (oref w col-pens)) 5.0))
           (layer-pen (or (alist-get L (oref w layer-pens)) 1.0)))
      (+ row-pen col-pen layer-pen))))

;;;; Neighbor enumeration

(cl-defmethod abv-layout-neighbors (layout coords &key layers sortfun)
      "Return nearby coordinates around a daselt-coords triple.

Candidates are sorted by SORTFUN, or by same-column, same-row, same-layer
priority if SORTFUN is not provided. Lower layers in the layout's `layer-pairs'
come before upper layers and the layer order is induced by that of the slot's
layer pairs. Upper rows come before lower.

If LAYERS is given, restrict to those layers, otherwise use 1-8."
      (pcase-let ((`(,l ,r ,c) coords))
    (let* ((layers (or layers (daselt-base-cardinal 8 t)))
           (lower-layers (mapcar #'car (oref layout layer-pairs)))
           (upper-layers (mapcar #'cdr (oref layout layer-pairs)))
           (valid-rows (list r (1+ r) (1- r)))
           (valid-cols (list c (1+ c) (1- c)))
           (neighbors nil))
      (dolist (L layers)
        (dolist (row valid-rows)
          (when (and (<= (abs row) 1) (<= (abs c) 5))
            (cl-pushnew (list L row c) neighbors :test #'equal)))
        (dolist (col valid-cols)
          (when (and (<= (abs r) 1) (<= (abs col) 5))
            (cl-pushnew (list L r col) neighbors :test #'equal))))
      (setq neighbors (cl-remove-if (lambda (coord)
                                          (or (and (= 1 (nth 1 coord))
                                               (= 1 (abs (nth 2 coord))))
                                          (and (not (= 1 (nth 1 coord)))
                                               (= 0 (nth 2 coord)))))
                                    neighbors))
      (sort neighbors
            :lessp (or sortfun
                       (lambda (a b)
                             (pcase-let ((`(,layer1 ,row1 ,col1) a)
                                     (`(,layer2 ,row2 ,col2) b))
                           (cond ((and (= col1 c) (not (= col2 c)))
                                  t)
                                 ((and (= col2 c) (not (= col1 c)))
                                  nil)
                                 ((and (= row1 r) (not (= row2 r)))
                                  t)
                                 ((and (= row2 r) (not (= row1 r)))
                                  nil)
                                 ((and (= layer1 l) (not (= layer2 l)))
                                  t)
                                 ((and (= layer2 l) (not (= layer1 l)))
                                  nil)
                                 ((and (memql layer1 lower-layers)
                                       (not (memql layer2 lower-layers)))
                                  t)
                                 ((and (memql layer2 lower-layers)
                                       (not (memql layer1 lower-layers)))
                                  nil)
                                 ((or (and (cl-position layer1 lower-layers)
                                           (cl-position layer2 lower-layers)
                                           (< (cl-position layer1 lower-layers)
                                              (cl-position layer2 lower-layers)))
                                      (and (cl-position layer1 upper-layers)
                                           (cl-position layer2 upper-layers)
                                           (< (cl-position layer1 upper-layers)
                                              (cl-position layer2 upper-layers))))
                                  t)
                                 ((< row1 row2)
                                  t)))))))))

;;;; Hand / finger / roll predicates

(defun daselt-abv--hand (coord)
  "Return the hand (left or right) used for COORD."
(let ((c (nth 2 coord))) (cond ((< c 0) 'left) ((> c 0) 'right) (t nil))))

(defun daselt-abv--cross-hand (c1 c2)
  "Return non-nil if C1 and C2 are typed with different hands."
  (let ((h1 (daselt-abv--hand c1)) (h2 (daselt-abv--hand c2))) (and h1 h2 (not
                                                                            (eq
                                                                             h1
                                                                             h2)))))

(defun daselt-abv--finger (coord)
  "Return the finger index typing COORD: 1=index, 2=middle, 3=ring, 4=pinky.
The index finger owns both columns 1-2 and the pinky owns 5-6
(staggered boards give each of them two columns); col 0 is a
formal place with no finger."
  (pcase (abs (nth 2 coord))
    ((or 1 2) 1)
    (3 2)
    (4 3)
    ((or 5 6) 4)
    (_ nil)))

(defun daselt-abv--same-finger (c1 c2)
  "Return non-nil if C1 and C2 use the same finger.
Finger classes, not column equality: 1 and 2 are both the index
finger (\"dt\" is a same-finger bigram), 5 and 6 are both the
pinky.  Cross-hand mirror fingers (\"ei\", both middle) do NOT
count: Dvorak measured them among the fastest pairs, so callers
must test `daselt-abv--cross-hand' first."
  (equal (daselt-abv--finger c1) (daselt-abv--finger c2)))

(defun daselt-abv--pinky (c)
  "Return non-nil if coordinate C is typed with the pinky."
  (>= (abs (nth 2 c)) 5))

(defun daselt-abv--roll (c1 c2)
  "Return `inward' or `outward' if C1 and C2 form a roll; else nil.
A roll is a same-hand, same-row pair on adjacent fingers (a
same-finger lateral move is not a roll).  Direction follows
Dvorak: same-hand sequences run more satisfactorily from outside
to inside (pinky toward index), i.e. with |col| decreasing."
  (let ((f1 (daselt-abv--finger c1)) (f2 (daselt-abv--finger c2)))
    (and (eq (daselt-abv--hand c1) (daselt-abv--hand c2))
         (daselt-abv--hand c1)
         (= (nth 1 c1) (nth 1 c2))
         f1 f2 (= 1 (abs (- f1 f2)))
         (cond ((> (abs (nth 2 c1)) (abs (nth 2 c2))) 'inward)
               ((< (abs (nth 2 c1)) (abs (nth 2 c2))) 'outward)
               (t nil)))))

(defun daselt-abv--hold-column-for-layer (L)
  "Return the column index used to hold layer L, or nil if none."
  (pcase L (2 1) (3 6) (7 6) (8 6) (5 4) (6 3) (_ nil)))

(defun daselt-abv--hard-run-p (coords)
  "Return non-nil if COORDS contain a hard same-layer run.

Runs are maximal contiguous subsequences on one layer.  Per the
Daselt layout heuristics, a run of two or more same-layer keys is
hard when the positions sitting on the layer's hold column include
both hands: no hold-hand choice avoids the conflict then.  A
single key is always easy (hold with the other hand), and runs on
layer 1 have no hold column.  Sequences of any length are checked,
not just pairs: \\=\\EEE-style three-symbol keys must not escape."
  (let ((i 0) (hard nil))
    (while (and (< i (length coords)) (not hard))
      (let* ((L (nth 0 (nth i coords)))
             (k (daselt-abv--hold-column-for-layer L))
             (run-end i))
        (while (and (< (1+ run-end) (length coords))
                    (= L (nth 0 (nth (1+ run-end) coords))))
          (cl-incf run-end))
        (when (and k (> run-end i))
          (let ((sigs nil))
            (cl-loop for j from i to run-end
                     for c = (nth j coords)
                     when (= k (abs (nth 2 c)))
                     do (push (daselt-abv--hand c) sigs))
            (when (and (memql 'left sigs) (memql 'right sigs))
              (setq hard t))))
        (setq i (1+ run-end))))
    hard))

;;;; Dvorak-unit interaction model

(defun daselt-abv--pair-units (c1 c2 wobj)
  "Return Dvorak delay units for the adjacent pair C1 C2.

Anchored to the bigram measurements in Dvorak's 1932 patent
(http://adnw.de, Bewertungsverfahren): \"ei\" (cross-hand, same
row) = 2 time units, \"em\" (cross-hand, top-bottom) = 4, \"es\"
(same-hand seitlich adjacent fingers, one row apart) = 5, \"on\"
(same-hand top-bottom hurdle) = 10, \"de\" (same finger, one row
apart) = 11.  Subtracting the 2-unit base pair cost, the
interaction anchors are 0 < 2 < 3 < 8 < 9, reproduced by this
model as:

  same-key repeat             0.0   (0.14s, Dvorak's fastest)
  cross-hand, drow 0..n       1.0 per row
  same-hand mittig, drow 0    0.5
  same-hand mittig, drow 1    1.5
  same-hand seitlich         +1.5   (AdNW mittig/seitlich split)
  same-hand hurdle drow 2     8.0
  same finger                8.0 + 1.0 per row

Cross-hand mirror fingers (\"ei\", both middle) are deliberately
cheap: Dvorak measured them among the fastest pairs.  The order
of the checks encodes this."
  (cond
   ((equal c1 c2) 0.0)
   ((daselt-abv--cross-hand c1 c2)
    (* (oref wobj dv-cross-row)
       (abs (- (nth 1 c1) (nth 1 c2)))))
   ((daselt-abv--same-finger c1 c2)
    (+ (oref wobj dv-same-finger-base)
       (* (oref wobj dv-same-finger-row)
          (abs (- (nth 1 c1) (nth 1 c2))))))
   (t
    (let* ((drow (abs (- (nth 1 c1) (nth 1 c2))))
           (base (cond ((= drow 0) (oref wobj dv-same-hand-row0))
                       ((= drow 1) (oref wobj dv-same-hand-row1))
                       (t (oref wobj dv-hurdle))))
           (f1 (daselt-abv--finger c1))
           (f2 (daselt-abv--finger c2))
           ;; Seitlich: adjacent fingers other than index+middle.
           (seitlich (and (<= drow 1) f1 f2
                          (= 1 (abs (- f1 f2)))
                          (>= (min f1 f2) 2))))
      (+ base (if seitlich (oref wobj dv-seitlich) 0.0))))))

(defun daselt-abv--redirect-units (coords wobj)
  "Return redirect penalty units for COORDS.
A redirect is three consecutive same-hand keys whose lateral
direction changes (|column| rises then falls, or vice versa);
same-finger steps have no direction and never redirect."
  (let ((n 0.0))
    (cl-loop for a in coords
             for b in (cdr coords)
             for c in (cddr coords)
             when (and (daselt-abv--hand a)
                       (eq (daselt-abv--hand a) (daselt-abv--hand b))
                       (eq (daselt-abv--hand b) (daselt-abv--hand c)))
             do (let ((d1 (- (abs (nth 2 b)) (abs (nth 2 a))))
                      (d2 (- (abs (nth 2 c)) (abs (nth 2 b)))))
                  (when (and (/= d1 0) (/= d2 0) (< (* d1 d2) 0))
                    (setq n (+ n (oref wobj dv-redirect))))))
    n))

;;;; Ergonomic score

(cl-defun daselt-abv--ergonomic-score (seq wobj)
  "Compute the ergonomic subscore for SEQ under weights WOBJ.

SEQ is a list of placevals, each a cons (COORD . BINDING). COORD is the triple
\(LAYER ROW COL). The base value is the negative sum of `daselt-abv--erg-score'
over the coordinates.

On top, every ADJACENT pair of the sequence (not only pairs of
length-2 sequences) contributes Dvorak-unit interaction penalties
from `daselt-abv--pair-units', scaled by `delay-unit-scale':
same-finger bigrams (with the index finger covering columns 1-2
and the pinky 5-6), the same-hand top-bottom hurdle, AdNW's
seitlich adjacent fingers and Daselt layer-switch churn all cost
units, while same-key repeats stay free (Dvorak measured them
fastest).  Cross-hand pairs earn bonus-alternation; inward rolls
outside->index earn bonus-roll and outward rolls
bonus-roll-outward (Dvorak's direction finding).  Three-key
same-hand direction changes pay `dv-redirect' via
`daselt-abv--redirect-units'.

A larger bonus increases the score; a larger penalty decreases it. If the
coordinates form a hard same-layer hold run of any length
(`daselt-abv--hard-run-p'), return nil to rule the candidate out."
  (let* ((coords (mapcar #'car seq)))
    (when (daselt-abv--hard-run-p coords) (cl-return-from daselt-abv--ergonomic-score nil))
    (let* ((base (- (apply #'+ (mapcar (lambda (c) (daselt-abv--erg-score c wobj))
                                        coords))))
           (units 0.0) (bon 0.0))
      (cl-loop for c1 in coords
               for c2 in (cdr coords)
               do (setq units (+ units (daselt-abv--pair-units c1 c2 wobj)))
               (when (daselt-abv--cross-hand c1 c2)
                 (setq bon (+ bon (oref wobj bonus-alternation))))
               (when (and (>= (max (nth 0 c1) (nth 0 c2)) 2)
                          (/= (nth 0 c1) (nth 0 c2)))
                 (setq units (+ units (oref wobj dv-layer-switch))))
               (let ((roll (daselt-abv--roll c1 c2)))
                 (cond ((eq roll 'inward)
                        (setq bon (+ bon (oref wobj bonus-roll))))
                       ((eq roll 'outward)
                        (setq bon (+ bon (oref wobj bonus-roll-outward)))))))
      (setq units (+ units (daselt-abv--redirect-units coords wobj)))
      (+ base (- (* (oref wobj delay-unit-scale) units)) bon))))

(defvar daselt-abv--root-reverse-index nil
  "Reverse index for root-table: maps coords (as comparable list) to list of
root keys.

When non-nil, `daselt-abv--value-free-p' and `daselt-abv--collision-penalty' use
this for O(1) lookups instead of scanning the entire table. Bound dynamically by
`abv-typed-layout-type-root'.")

;;;; Availability score

(defun daselt-abv--availability-score (layout seq table)
  "Compute the availability subscore for SEQ on LAYOUT.

SEQ is the candidate deep structure (a list of placevals). The score favors
coordinates whose layer has a defined pair in LAYOUT's layer-pairs and slightly
penalizes reuse of the exact same deep structure already present in LAYOUT's
root-table.

The current implementation adds +0.1 if the starting coordinate has an available
upper-layer pair and subtracts 0.05 for each existing mapping equal to SEQ.
The penalty stays mild: a shared ergonomic letter pair still beats a fresh
awkward one, and a large penalty flips close calls toward odd fresh pairs."
  (let* ((coord1 (car (car seq)))
         (L (nth 0 coord1)) (r (nth 1 coord1)) (c (nth 2 coord1))
         (pairs (or (and (slot-exists-p layout 'layer-pairs)
                         (slot-boundp layout 'layer-pairs)
                         (slot-value layout 'layer-pairs))
                    ;; Fall back to the global default layout only
                    ;; when it is actually initialized; depending on
                    ;; it unconditionally crashes in environments
                    ;; that never ran the dfk import.
                    (and (boundp 'daselt-abv--default-layout)
                         daselt-abv--default-layout
                         (slot-value daselt-abv--default-layout
                                     'layer-pairs))))
         (upper (cdr (assoc L pairs)))
         (pairedp (and upper
                       (assoc (list upper r c) (oref (oref layout placevals) root-placevals) #'equal)))
          (deep seq)
          (cnt (if daselt-abv--root-reverse-index
                    ;; Fast path: the reverse index buckets table
                    ;; entries by their plain value, so its bucket for
                    ;; DEEP holds exactly the entries the scan below
                    ;; would count (root-table values are coordinate
                    ;; lists, `equal' to DEEP only in the degenerate
                    ;; case of stored placeval sequences).  This avoids
                    ;; a full table scan per candidate.
                    (length (gethash deep daselt-abv--root-reverse-index nil))
                  (let ((n 0))
                    (maphash (lambda (_k v) (when (equal v deep)
                                              (setq n (1+ n))))
                             table)
                    n))))
    (+ (if pairedp 0.1 0.0) (* -0.05 cnt))))

;;;; Collision avoidance via shared-affix penalty

(defun daselt-abv--shared-affix (matrix r1 r2)
  "Lookup shared-affix score between R1 and R2 in MATRIX alist."
  (or (abv-corpus-shared-affix-lookup matrix r1 r2)
      (abv-corpus-shared-affix-lookup matrix r2 r1)
      0))

(defun daselt-abv--collision-penalty (_layout root deep matrix table)
  "Sum shared-affix scores for ROOT with others bound to DEEP."
  (if (null matrix)
      0
    (if daselt-abv--root-reverse-index
        ;; Fast path: use reverse index to get only roots sharing this deep
        (let* ((sum 0)
               (deep-key (if (cl-typep deep 'abv-rich-value)
                             (daselt-abv--value-coords deep)
                           deep))
               (roots (gethash deep-key daselt-abv--root-reverse-index nil)))
          (dolist (k roots sum)
            (let ((plain-k (abv-plain-value k)))
              (unless (string= plain-k root)
                (setq sum (+ sum (daselt-abv--shared-affix matrix root plain-k)))))))
      ;; Original path: scan entire table
      (let ((sum 0))
        (maphash (lambda (k v)
                   (let ((plain-k (abv-plain-value k)))
                     (when (and (not (string= plain-k root)) (equal v deep))
                       (setq sum (+ sum (daselt-abv--shared-affix matrix root plain-k))))))
                 table)
        sum))))

;;;; Mnemonic score

(defun daselt-abv--mnemonic-score (_layout _root indexed-seq weights)
  "Score INDEXED-SEQ for ROOT using mnemonic criteria.

INDEXED-SEQ is a list of indexed placevals where each element is ((LETTER .
 INDEX) . PLACEVAL).

The score combines two ideas: - smaller indices are better, especially when the
first element starts at index 0 in ROOT, which receives a large bonus; - letters
that are rarer (lower frequency) are preferred. Frequencies are looked up in the
LAYOUT's slot `letter-frequency-alist'.

When `letter-frequency-alist' is empty, the rarity term is skipped. If LETTER is
not found in the alist, treat it as very rare.

Return a real-valued score (higher is better)."
  (let* ((letter-weights (oref weights letter-weights))
         (use-freq (and (listp letter-weights) (> (length letter-weights) 0)))
         ;; Build a numeric rarity score where smaller frequency -> larger bonus.
         (freq-h (when use-freq (let ((ht (make-hash-table :test 'equal)))
                                  (dolist (kv letter-weights ht)
                                    (puthash (car kv) (cdr kv) ht)))))
         ;; indices of letters in the root
         (indices (mapcar (lambda (elt) (cdr (car elt))) indexed-seq))
         ;; Prefer early indices; use inverse with diminishing returns.
         (idx-term (apply #'+ (cl-mapcar (lambda (idx pos)
                                           (/ 1.0 (+ 1.0 idx (* 0.2 pos))))
                                         indices
                                         (number-sequence 0 (1- (length indices))))))
         ;; strong bonus for first element at index 0
         (start-bonus (if (and indices (= (car indices) 0)) 2.0 0.0))
         ;; rarity term: use -log(freq) with floor for unknowns.
         ;; Only credit rarity when the placeval's binding actually
         ;; IS the root letter: an embellished ring variant (swapped
         ;; to another symbol) must not inherit the header letter's
         ;; rarity bonus — otherwise odd fresh pairs outscore the
         ;; root's own letters.
         (rarity-term (if (not use-freq)
                          0.0
                        (cl-loop for elt in indexed-seq
                                 for letter = (car (car elt))
                                 ;; ELT is ((LETTER . INDEX) . PLACEVAL)
                                 ;; and PLACEVAL is (COORD . BINDING).
                                 ;; LETTER may be a string (layout
                                 ;; match) or a character.
                                 for binding = (cdr (cdr elt))
                                 for match = (and (stringp binding)
                                                  (= 1 (length binding))
                                                  (cond
                                                   ((stringp letter)
                                                    (string= (downcase binding)
                                                             (downcase letter)))
                                                   ((integerp letter)
                                                    (= (aref (downcase binding) 0)
                                                       (downcase letter)))))
                                 for freq = (and match
                                                 (or (and freq-h
                                                          (gethash (if (integerp letter)
                                                                       letter
                                                                     (aref letter 0))
                                                                   freq-h))
                                                     0.0005))
                                 when match
                                 sum (- (log (max freq 1e-6)))))))
    ;; Calibrate: rarity should usually outweigh start-bonus when a rare
    ;; first letter like q/x/j competes with a frequent first letter, so
    ;; give rarity a larger coefficient.
    (+ (* 0.8 idx-term) start-bonus (* 1.2 rarity-term))))

;;;; Letter score

(defun daselt-abv--letter-score (seq wobj)
  "Calculate the frequency-based letter score for SEQ using WOBJ.

SEQ is a list of placevals. The score is the sum of
log-inverse frequencies of the base letters of the coordinates,
divided by 20: a rare base letter makes a deep slightly more
distinctive, but the LOG keeps the term a small tie-break.  The
previous raw inverse-frequency sum reached ~20 for z/q/x and let
leftover rare symbols outrank a word's OWN letters in the cue
search (\"the\" landed on z while t/h/e were free)."
  (let ((lW (oref wobj letter-weights)))
    (apply #'+ (mapcar (lambda (pv)
                         (let* ((place (car pv))
                                (base-letter (pcase-let ((`(,_l ,r ,c) place))
                                               (string-to-char (daselt-coords-binding `(1 ,r ,c)))))
                                (freq (alist-get base-letter lW)))
                           (if freq (/ (- (log (max freq 1e-4))) 20)
                             0)))
                       seq))))

;;;; Combined score

(defvar daselt-abv--family-weights nil
  "Hash root string -> family weight points, or nil.
Bound by `daselt-abv--set-typings-helper' during root seating;
`daselt-abv--score' adds it (times the weights' family-weight-bonus)
so roots anchoring large families claim good initial cells.")

(defvar daselt-abv--initial-load nil
  "Hash coordinate list -> initial-cell load, or nil.
Bound by the second root-seating pass of
`daselt-abv--set-typings-helper'; `daselt-abv--score' subtracts
the load (times the weights' initial-load-weight) from
candidates whose first coordinate already serves many roots.")

(defun daselt-abv--weights-slot (wobj slot fallback)
  "Return WOBJ's SLOT, or FALLBACK when the slot is unbound.
Old persisted `abv-weights' instances predate newer slots."
  (if (and wobj (slot-exists-p wobj slot) (slot-boundp wobj slot))
      (slot-value wobj slot)
    fallback))

(cl-defun daselt-abv--score (layout root seq table wobj shared-matrix)
  "Combine subscores for ROOT and SEQ using WOBJ and SHARED-MATRIX.

The total score S is:

  S = wE * ERG + wM * MN + wA * AV - C * COLL + SUM(1/L)/20

where: - ERG is from `daselt-abv--ergonomic-score' (on the plain, de-indexed
seq), - MN is from `daselt-abv--mnemonic-score' (on the indexed seq), - AV is
from `daselt-abv--availability-score' (on the plain seq), - COLL is the
collision value from `daselt-abv--collision-penalty'. - L runs over each letter.

SEQ can be a plain sequence (list of placevals) or an indexed sequence. Return
nil if ERG is nil, meaning the candidate is ergonomically invalid."
  (let* ((is-plain (and seq (consp (car seq)) (stringp (cdar seq))))
         (indexed-seq (if is-plain (daselt-abv--index-plain-seq root seq) seq))
         (plain (if is-plain seq (mapcar #'cdr indexed-seq)))
         (erg (daselt-abv--ergonomic-score plain wobj)))
    (when (null erg) (cl-return-from daselt-abv--score nil))
    (let* ((mn (daselt-abv--mnemonic-score layout root indexed-seq wobj))
           (av (daselt-abv--availability-score layout plain table))
           (wE (or (ignore-errors (oref wobj weight-ergonomic)) 1.0))
           (wM (or (ignore-errors (oref wobj weight-mnemonic)) 1.0))
           (wA (oref wobj weight-availability))
           (coll (daselt-abv--collision-penalty layout root plain shared-matrix table))
           (C (oref wobj root-collision-weight))
           (lS (daselt-abv--letter-score plain wobj))
           ;; Family-weight bonus (C2): the initial of a root with a
           ;; heavy family is typed inside every member key.
           (fam (and daselt-abv--family-weights
                     (gethash root daselt-abv--family-weights 0.0)))
           (fam-term (* (daselt-abv--weights-slot
                         wobj 'family-weight-bonus 0.3)
                        (or fam 0.0)))
           ;; Initial-cell load penalty (C1): spread initials across
           ;; cells instead of stacking on saturated columns.
           (first-coord (and plain (car (car plain))))
           (load (and daselt-abv--initial-load first-coord
                      (gethash first-coord daselt-abv--initial-load 0.0)))
           (load-term (* (daselt-abv--weights-slot
                          wobj 'initial-load-weight 0.5)
                         (log (1+ (or load 0.0))))))
      (+ (* wE erg) (* wM mn) (* wA av) (* -1.0 C coll) lS fam-term (- load-term)))))

;;;; Reverse index, freedom checks, candidate filtering & scoring

(defun daselt-abv--build-reverse-index (table)
  "Build a reverse index hash for TABLE (root-table).

Maps coordinate tuples (as comparable lists) to lists of root keys that share
that deep structure."
  (let ((idx (make-hash-table :test 'equal)))
    (maphash (lambda (k v)
               (let ((coords (daselt-abv--value-coords v)))
                 (when coords
                   (puthash coords (cons k (gethash coords idx nil)) idx))))
             table)
    idx))

(defun daselt-abv--build-taken-reverse-index (table &optional taken-tables)
  "Like `daselt-abv--build-reverse-index', but also index TAKEN-TABLES.
Entries of TAKEN-TABLES (a list of root tables) count as occupied
even though they do not belong to TABLE itself; this lets typings
generated for one graph avoid deep structures already taken in
another graph, e.g. the parent language's."
  (let ((idx (daselt-abv--build-reverse-index table)))
    (dolist (tt (delq nil (and taken-tables (ensure-list taken-tables))))
      (when (hash-table-p tt)
        (maphash (lambda (k v)
                    (let ((coords (daselt-abv--value-coords v)))
                      (when coords
                        (puthash coords (cons k (gethash coords idx nil)) idx))))
                  tt)))
    idx))

(defvar daselt-abv--root-reverse-index-owner nil
  "Owner of the current `daselt-abv--root-reverse-index' binding.
A cons (TABLE . TAKEN-TABLES) naming the tables the index was
built from, compared by identity, so an index can be reused for
consecutive root typings on the same tables.")

(defmacro daselt-abv--with-taken-reverse-index (table taken-tables &rest body)
  "Run BODY with `daselt-abv--root-reverse-index' covering TABLE.
TAKEN-TABLES are additional root tables whose entries count as
occupied.  When the variable already indexes the same TABLE (by
identity) and TAKEN-TABLES, the existing index is reused instead
of being rebuilt; `abv-typed-layout-type-root' maintains it
incrementally, so wrapping a loop of root typings in this form
builds the index once per batch rather than once per root."
  (declare (indent 2) (debug (form form body)))
  `(let ((--daselt-abv--tri-table ,table)
         (--daselt-abv--tri-taken (and ,taken-tables (ensure-list ,taken-tables))))
     (if (and daselt-abv--root-reverse-index
              (equal daselt-abv--root-reverse-index-owner
                     (cons --daselt-abv--tri-table --daselt-abv--tri-taken)))
         (progn ,@body)
       (let ((daselt-abv--root-reverse-index
              (daselt-abv--build-taken-reverse-index
               --daselt-abv--tri-table --daselt-abv--tri-taken))
             (daselt-abv--root-reverse-index-owner
              (cons --daselt-abv--tri-table --daselt-abv--tri-taken)))
         ,@body))))

(defun daselt-abv--value-free-p (coords table &optional overcount)
  "Return non-nil if COORDS are not present as a value in TABLE.

When OVERCOUNT is nil, return non-nil only if COORDS are strictly not present in
TABLE. When OVERCOUNT is a number, return non-nil if the number of occurrences
of COORDS in TABLE is less than or equal to OVERCOUNT. When OVERCOUNT is t,
return the count of occurrences of COORDS in TABLE.

This checks for exact matches of coordinate sequences against the values stored
in TABLE (which may be lists of coordinates or abv-rich-value objects).

When `daselt-abv--root-reverse-index' is non-nil, uses it for O(1) lookup
instead of scanning the entire table."
  (if daselt-abv--root-reverse-index
      (let ((count (length (gethash coords daselt-abv--root-reverse-index nil))))
        (if (numberp overcount)
            (<= count overcount)
          (if (eq overcount t)
              count
            (= count 0))))
    (if overcount
        (let ((count (cl-loop for v being the hash-values of table
                              count (equal coords (daselt-abv--value-coords v)))))
          (if (numberp overcount)
              (<= count overcount)
            count))
      (not (cl-loop for v being the hash-values of table
                    thereis (equal coords (daselt-abv--value-coords v)))))))

(defun daselt-abv--filter-candidates (cands separators table cue-table &optional overcount)
  "Filter CANDS by SEPARATORS and freedom in TABLE and CUE-TABLE.

If OVERCOUNT is nil, return a list of strictly free candidates. If OVERCOUNT is
t, calculate the minimum number of existing bindings for all candidates in
TABLE, and return only those candidates that have at most that many bindings.
CUE-TABLE entries are always checked for strict uniqueness."
  (let* ((min-bindings (if (eq overcount t)
                           (apply #'min
                                  (mapcar (lambda (c)
                                            (daselt-abv--value-free-p
                                             (daselt-abv--seq-coords c)
                                             table t))
                                          cands))
                         0))
         (threshold (if (eq overcount t) min-bindings 0)))
    (cl-loop for cand in cands
             for plain = (daselt-abv--seq-placevals cand)
             for coords = (daselt-abv--seq-coords cand)
             when (and
                   ;; Renderability: candidates whose key bindings
                   ;; do not exist in the currently configured
                   ;; keyboard layout (e.g. the emoji layer) would
                   ;; produce typings that render as nothing; reject
                   ;; them so typing generation never picks them.
                   (cl-every (lambda (coord)
                               (and (daselt-coords-binding coord) t))
                             coords)
                   ;; Separator check
                   (not (and separators
                             (cl-some (lambda (pv)
                                        (cl-member (cdr pv) separators
                                                   :test (lambda (b s)
                                                           (and (stringp b)
                                                                (= (string-to-char b) s)))))
                                      plain)))
                   ;; Freedom checks
                   (daselt-abv--value-free-p coords table threshold)
                   (or (not cue-table)
                       (daselt-abv--value-free-p coords cue-table)))
             collect cand)))

(defun daselt-abv--score-candidates (cands layout root table wobj shared-matrix)
  "Score CANDS and return the best one (SEQ . SCORE)."
  (let ((scored (cl-loop for cand in cands
                         for score = (daselt-abv--score layout root cand table wobj shared-matrix)
                         when score
                         collect (cons cand score))))
    (car (cl-sort scored #'> :key #'cdr))))

(provide 'daselt-abv-ergonomics)
;;; daselt-abv-ergonomics.el ends here
