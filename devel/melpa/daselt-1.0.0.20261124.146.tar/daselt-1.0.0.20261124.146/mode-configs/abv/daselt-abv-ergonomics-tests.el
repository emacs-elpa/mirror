;;; daselt-abv-ergonomics-tests.el --- Tests for daselt-abv-ergonomics  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Praehauser

;; Author: Alexander Praehauser <ahprae@protonmail.com>
;; Keywords: abbrev

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Tests for `daselt-abv-ergonomics': ergonomic cost, hand/finger
;; predicates, candidate filtering/scoring and the reverse index.

;;; Code:

(require 'ert)
(require 'cl-lib)
(require 'daselt-abv-tests--setup)
(require 'daselt-abv-ergonomics)

(defun daselt-abv-tests--approx-equal (a b &optional tolerance)
  "Return non-nil if A and B are within TOLERANCE (default 1e-9)."
  (let ((eps (or tolerance 1e-9)))
    (< (abs (- a b)) eps)))


;;;; Ergonomic cost

(ert-deftest daselt-abv-erg-score-home-row-cheapest ()
  "Home row on layer 1 has zero row and layer penalty."
  (let ((score (daselt-abv--erg-score '(1 0 1))))
    (should (numberp score))
    ;; row-pen=0, layer-pen=0, col-pen=1.0
    (should (= score 1.0))))

(ert-deftest daselt-abv-erg-score-monotonic-with-distance ()
  "Outer columns and layers cost more."
  (let ((home (daselt-abv--erg-score '(1 0 1)))
        (far-col (daselt-abv--erg-score '(1 0 5)))
        (off-row (daselt-abv--erg-score '(1 1 1)))
        (upper-layer (daselt-abv--erg-score '(2 0 1))))
    (should (< home far-col))
    (should (< home off-row))
    (should (< home upper-layer))))

(ert-deftest daselt-abv-erg-score-row-penalty ()
  "Off-home rows add their row penalty; the bottom row is worse.
Dvorak's patent calls the bottom row exceedingly slow; the top
row is merely off-home (row-pen-top 0.5 < row-pen-bottom 0.9)."
  (let ((home (daselt-abv--erg-score '(1 0 1)))
        (upper-row (daselt-abv--erg-score '(1 -1 1)))
        (lower-row (daselt-abv--erg-score '(1 1 1))))
    (should (< home upper-row))
    (should (< home lower-row))
    (should (< upper-row lower-row))
    (should (daselt-abv-tests--approx-equal (- upper-row home) 0.5))
    (should (daselt-abv-tests--approx-equal (- lower-row home) 0.9))))

(ert-deftest daselt-abv-erg-score-weights-wired ()
  "Static costs come from the weights object, not code constants."
  (let* ((w (make-instance 'abv-weights
                           :col-pens '((1 . 1.0)) :layer-pens '((1 . 0.0))))
         (s1 (daselt-abv--erg-score '(1 0 1) w))
         (w2 (make-instance 'abv-weights
                            :col-pens '((1 . 2.0)) :layer-pens '((1 . 0.0)))))
    (should (daselt-abv-tests--approx-equal s1 1.0))
    (should (< s1 (daselt-abv--erg-score '(1 0 1) w2)))))


;;;; Hand / finger / roll helpers

(ert-deftest daselt-abv-hand ()
  "`daselt-abv--hand' detects left/right column."
  (should (eq 'left (daselt-abv--hand '(1 0 -2))))
  (should (eq 'right (daselt-abv--hand '(1 0 3))))
  (should (null (daselt-abv--hand '(1 0 0)))))

(ert-deftest daselt-abv-cross-hand ()
  "`daselt-abv--cross-hand' is true for opposite hands."
  (should (daselt-abv--cross-hand '(1 0 -1) '(1 0 1)))
  (should-not (daselt-abv--cross-hand '(1 0 -1) '(1 0 -2)))
  (should-not (daselt-abv--cross-hand '(1 0 0) '(1 0 1))))

(ert-deftest daselt-abv-same-finger ()
  "`daselt-abv--same-finger' compares finger classes.
Index owns columns 1-2, pinky owns 5-6 (staggered boards)."
  (should (daselt-abv--same-finger '(1 0 -2) '(1 0 2)))
  (should (daselt-abv--same-finger '(1 0 1) '(2 1 1)))
  ;; Both index columns: same finger.
  (should (daselt-abv--same-finger '(1 0 1) '(1 0 2)))
  ;; Both pinky columns: same finger.
  (should (daselt-abv--same-finger '(1 0 -5) '(1 1 6)))
  ;; Index vs middle: different fingers.
  (should-not (daselt-abv--same-finger '(1 0 2) '(1 0 3))))

(ert-deftest daselt-abv-pinky ()
  "`daselt-abv--pinky' is true for |col|>=5."
  (should (daselt-abv--pinky '(1 0 5)))
  (should (daselt-abv--pinky '(1 0 -5)))
  (should (daselt-abv--pinky '(1 0 6)))
  (should-not (daselt-abv--pinky '(1 0 4)))
  (should-not (daselt-abv--pinky '(1 0 0))))

(ert-deftest daselt-abv-hold-column-for-layer ()
  "`daselt-abv--hold-column-for-layer' returns known mappings."
  (should (= 1 (daselt-abv--hold-column-for-layer 2)))
  (should (= 6 (daselt-abv--hold-column-for-layer 3)))
  (should (= 6 (daselt-abv--hold-column-for-layer 7)))
  (should (= 6 (daselt-abv--hold-column-for-layer 8)))
  (should (= 4 (daselt-abv--hold-column-for-layer 5)))
  (should (= 3 (daselt-abv--hold-column-for-layer 6)))
  (should (null (daselt-abv--hold-column-for-layer 1)))
  (should (null (daselt-abv--hold-column-for-layer 99))))

(ert-deftest daselt-abv-hard-run-p-disallowed ()
  "`daselt-abv--hard-run-p' rejects same-layer holds across hands."
  ;; layer 2 hold column is 1; left+right hand on col ±1
  (should (daselt-abv--hard-run-p '((2 0 -1) (2 0 1))))
  ;; layer 1 has no hold column -> never a hard run
  (should-not (daselt-abv--hard-run-p '((1 0 -1) (1 0 1))))
  ;; Single key: hold with the other hand, always easy.
  (should-not (daselt-abv--hard-run-p '((2 0 -1))))
  ;; Length-3 same-layer run with both signs: hard (used to escape).
  (should (daselt-abv--hard-run-p '((2 0 -1) (2 0 1) (2 0 -1))))
  ;; Both-sign positions need not be adjacent within the run.
  (should (daselt-abv--hard-run-p '((6 0 -3) (6 1 1) (6 0 3))))
  ;; Different layers
  (should-not (daselt-abv--hard-run-p '((2 0 -1) (3 0 1)))))


;;;; Ergonomic score

(defun daselt-abv-erg-tests--make-weights ()
  "Build a fresh `abv-weights' instance for tests."
  (make-instance 'abv-weights))

;;;; Dvorak-unit pair model

(ert-deftest daselt-abv-pair-units-dvorak-anchors ()
  "The five patent anchors reproduce exactly (interaction units).
ei (cross, drow 0) = 0, em (cross, drow 2) = 2, es (seitlich,
drow 1) = 3, on (same-hand hurdle) = 8, de (same finger, drow 1)
= 9."
  (let ((w (daselt-abv-erg-tests--make-weights)))
    (let ((ei (daselt-abv--pair-units '(1 0 -3) '(1 0 3) w))
          (em (daselt-abv--pair-units '(1 -1 -3) '(1 1 3) w))
          (es (daselt-abv--pair-units '(1 -1 -3) '(1 0 -4) w))
          (on (daselt-abv--pair-units '(1 -1 -4) '(1 1 -1) w))
          (de (daselt-abv--pair-units '(1 0 -3) '(1 -1 -3) w)))
      (should (daselt-abv-tests--approx-equal ei 0.0 1e-6))
      (should (daselt-abv-tests--approx-equal em 2.0 1e-6))
      (should (daselt-abv-tests--approx-equal es 3.0 1e-6))
      (should (daselt-abv-tests--approx-equal on 8.0 1e-6))
      (should (daselt-abv-tests--approx-equal de 9.0 1e-6))
      ;; Strict Dvorak ordering of the five classes.
      (should (< ei em es on de)))))

(ert-deftest daselt-abv-pair-units-same-key-repeat-free ()
  "Same-key repeats cost nothing (Dvorak: 0.14s, fastest class)."
  (let ((w (daselt-abv-erg-tests--make-weights)))
    (should (daselt-abv-tests--approx-equal
             (daselt-abv--pair-units '(1 0 1) '(1 0 1) w) 0.0 1e-6))))

(ert-deftest daselt-abv-pair-units-cross-hand-mirror-fingers-cheap ()
  "Cross-hand mirror fingers (ei) are cross-hand pairs, not SFB."
  (let ((w (daselt-abv-erg-tests--make-weights)))
    (should (daselt-abv--same-finger '(1 0 -3) '(1 0 3)))
    (should (daselt-abv-tests--approx-equal
             (daselt-abv--pair-units '(1 0 -3) '(1 0 3) w) 0.0 1e-6))))

(ert-deftest daselt-abv-pair-units-index-lateral-is-sfb ()
  "Columns 1 and 2 are one finger: a lateral index move is SFB."
  (let ((w (daselt-abv-erg-tests--make-weights)))
    (should (<= (oref w dv-same-finger-base)
                (daselt-abv--pair-units '(1 0 1) '(1 0 2) w)))))

(ert-deftest daselt-abv-pair-units-jm-um-monotone ()
  "Same-finger row distance grows the penalty (jm 0.16 < um 0.17).
The measured ratio um/jm = 1.0625 must be met within 10% by
(base+2*row)/(base+1*row)."
  (let* ((w (daselt-abv-erg-tests--make-weights))
         (jm (daselt-abv--pair-units '(1 0 2) '(1 1 2) w))
         (um (daselt-abv--pair-units '(1 -1 2) '(1 1 2) w)))
    (should (< jm um))
    (should (< 0.95 (/ um jm) 1.18))))

(ert-deftest daselt-abv-pair-units-seitlich-vs-mittig ()
  "Seitlich adjacent fingers cost more than mittig (AdNW)."
  (let ((w (daselt-abv-erg-tests--make-weights)))
    ;; mittig: index -> middle, same row.
    (let ((mittig (daselt-abv--pair-units '(1 0 1) '(1 0 3) w))
          ;; seitlich: middle -> ring, same row.
          (seitlich (daselt-abv--pair-units '(1 0 3) '(1 0 4) w)))
      (should (< mittig seitlich)))))

(ert-deftest daselt-abv-pair-units-weights-wired ()
  "Tuning dv-hurdle changes the hurdle interaction."
  (let ((w (daselt-abv-erg-tests--make-weights))
        (w2 (make-instance 'abv-weights :dv-hurdle 12.0)))
    (should (< (daselt-abv--pair-units '(1 -1 1) '(1 1 3) w)
               (daselt-abv--pair-units '(1 -1 1) '(1 1 3) w2)))))

(ert-deftest daselt-abv-ergonomic-score-rejects-hard-run ()
  "Hard runs return nil."
  (let* ((w (daselt-abv-erg-tests--make-weights))
         (seq '(((2 0 -1) . "a") ((2 0 1) . "s"))))
    (should (null (daselt-abv--ergonomic-score seq w)))))

(ert-deftest daselt-abv-ergonomic-score-rejects-hard-run-length-3 ()
  "Three-symbol hard runs are vetoed too (E-RR-style sequences)."
  (let* ((w (daselt-abv-erg-tests--make-weights))
         (seq '(((6 0 -3) . "a") ((6 0 3) . "b") ((6 0 -3) . "c"))))
    (should (null (daselt-abv--ergonomic-score seq w)))))

(ert-deftest daselt-abv-ergonomic-score-single-coord ()
  "Single-coord seq returns the negated erg-score (no pair bonus)."
  (let* ((w (daselt-abv-erg-tests--make-weights))
         (seq '(((1 0 1) . "a")))
         (expected (- (daselt-abv--erg-score '(1 0 1) w))))
    (should (daselt-abv-tests--approx-equal (daselt-abv--ergonomic-score seq w) expected))))

(ert-deftest daselt-abv-roll-same-hand-adjacent-fingers ()
  "A same-hand, same-row, adjacent-FINGER pair is a roll.
Columns 1 and 2 are the same (index) finger: not a roll."
  ;; Right hand: middle -> index is inward (|col| decreasing).
  (should (eq 'inward (daselt-abv--roll '(1 0 3) '(1 0 1))))
  ;; Right hand: index -> middle is outward.
  (should (eq 'outward (daselt-abv--roll '(1 0 1) '(1 0 3))))
  ;; Left hand: ring -> middle is inward.
  (should (eq 'inward (daselt-abv--roll '(1 0 -4) '(1 0 -3))))
  ;; Both index columns: same finger, no roll.
  (should-not (daselt-abv--roll '(1 0 1) '(1 0 2)))
  (should-not (daselt-abv--roll '(1 0 -2) '(1 0 -1))))

(ert-deftest daselt-abv-roll-same-hand-different-row-no-error ()
  "Same-hand pairs with different rows return nil without erroring.
Regression: `(nth 1 2)' instead of `(nth 1 c2)' made every
same-hand pair signal `wrong-type-argument (listp 2)'."
  (should-not (daselt-abv--roll '(1 -1 -5) '(2 -1 -2)))
  (should-not (daselt-abv--roll '(1 0 -3) '(1 1 -2))))

(ert-deftest daselt-abv-ergonomic-score-same-hand-pair ()
  "Same-hand pairs score normally (no crash, interaction applies)."
  (let* ((w (daselt-abv-erg-tests--make-weights))
         (roll-seq '(((1 0 1) . "a") ((1 0 2) . "s")))
         (score (daselt-abv--ergonomic-score roll-seq w)))
    (should (numberp score))))

(ert-deftest daselt-abv-ergonomic-score-nlength-pairs ()
  "Interaction terms run over every adjacent pair of long seqs.
Both sequences share the same |col| multiset; only the last pair
differs (same-finger lateral vs cross-hand)."
  (let* ((w (daselt-abv-erg-tests--make-weights))
         (sfb '(((1 0 -1) . "x") ((1 0 3) . "y") ((1 0 2) . "z")))
         (good '(((1 0 -1) . "x") ((1 0 3) . "y") ((1 0 -1) . "z"))))
    (should (< (daselt-abv--ergonomic-score sfb w)
               (daselt-abv--ergonomic-score good w)))))

(ert-deftest daselt-abv-ergonomic-score-redirect ()
  "A same-hand direction change in a 3-run costs redirect units.
Same |col| multiset; the out-and-back arrangement scores lower
than the one starting with a same-key repeat."
  (let* ((w (daselt-abv-erg-tests--make-weights))
         ;; |col| 1 -> 3 -> 1 on the right hand: out then back in.
         (redirect '(((1 0 1) . "a") ((1 0 3) . "b") ((1 0 1) . "c")))
         ;; |col| 1 -> 1 -> 3: repeat, then out; no direction change.
         (repeat '(((1 0 1) . "a") ((1 0 1) . "b") ((1 0 3) . "c"))))
    (should (< (daselt-abv--ergonomic-score redirect w)
               (daselt-abv--ergonomic-score repeat w)))))

(ert-deftest daselt-abv-ergonomic-score-same-key-repeat-cheapest ()
  "A repeated key beats any different-key second stroke.
Compare pairs sharing the first coordinate: the identical repeat
scores highest."
  (let* ((w (daselt-abv-erg-tests--make-weights))
         (mk (lambda (c2) (daselt-abv--ergonomic-score
                            (list (cons '(1 0 1) "a") (cons c2 "b")) w))))
    (should (> (funcall mk '(1 0 1)) (funcall mk '(1 0 3))))
    (should (> (funcall mk '(1 0 1)) (funcall mk '(1 0 2))))))

(ert-deftest daselt-abv-ergonomic-score-roll-direction-bonus ()
  "Inward rolls score higher than their outward mirror."
  (let* ((w (daselt-abv-erg-tests--make-weights))
         (inward (daselt-abv--ergonomic-score
                  (list (cons '(1 0 3) "a") (cons '(1 0 1) "b")) w))
         (outward (daselt-abv--ergonomic-score
                   (list (cons '(1 0 1) "a") (cons '(1 0 3) "b")) w)))
    (should (> inward outward))))

(ert-deftest daselt-abv-availability-score-without-default-layout ()
  "A nil `daselt-abv--default-layout' must not crash the score.
Regression: the global is only set after the dfk import; scoring
new roots in a bare environment signaled `slot-value (nil
layer-pairs)'."
  (let ((daselt-abv--default-layout nil)
        (layout (make-instance 'daselt-abv-layout))
        (table (make-hash-table :test 'equal)))
    (let ((score (daselt-abv--availability-score
                  layout '(((1 -1 -5) . "p") ((2 -1 -2) . "Q")) table)))
      (should (numberp score)))))

(ert-deftest daselt-abv-ergonomic-score-cross-hand-bonus ()
  "Cross-hand pairs get the alternation bonus.

Both sequences use opposite-hand coords, but one alternates and the
other doesn't."
  (let* ((w (daselt-abv-erg-tests--make-weights))
         ;; Both pairs are cross-hand; the second pair has higher column
         ;; penalties which the alternation bonus offsets.
         (seq-low-cross  '(((1 0 -1) . "a") ((1 0  1) . "s")))
         (seq-high-cross '(((1 0 -3) . "a") ((1 0  3) . "s"))))
    (let ((lc (daselt-abv--ergonomic-score seq-low-cross w))
          (hc (daselt-abv--ergonomic-score seq-high-cross w)))
      (should lc)
      (should hc)
      ;; Lower-column cross-hand scores higher than high-column one.
      (should (> lc hc)))))


;;;; Mnemonic score

(ert-deftest daselt-abv-mnemonic-score-no-freqs ()
  "Without letter-weights, rarity term is zero."
  (let* ((w (make-instance 'abv-weights :letter-weights nil))
         (indexed '((("a" . 0) (1 0 1) . "a"))))
    (let ((score (daselt-abv--mnemonic-score nil "a" indexed w)))
      (should (numberp score))
      ;; idx-term=1.0 (+1.0/(1+0+0)), start-bonus=2.0, rarity=0
      ;; score = 0.8 * 1 + 2.0 + 0 = 2.8
      (should (daselt-abv-tests--approx-equal score 2.8)))))

(ert-deftest daselt-abv-mnemonic-score-index-at-zero-bonus ()
  "Sequences starting at index 0 get a strong start bonus."
  (let* ((w (make-instance 'abv-weights :letter-weights nil))
         (indexed-at-0  '((("a" . 0) (1 0 1) . "a")))
         (indexed-at-1  '((("a" . 1) (1 0 1) . "a"))))
    (let ((s0 (daselt-abv--mnemonic-score nil "ab" indexed-at-0 w))
          (s1 (daselt-abv--mnemonic-score nil "ab" indexed-at-1 w)))
      (should (> s0 s1)))))


;;;; Letter score

(ert-deftest daselt-abv-letter-score-zero-for-unknown ()
  "`daselt-abv--letter-score' is 0 when no freq matches."
  (let* ((w (make-instance 'abv-weights :letter-weights nil))
         (seq '(((1 0 1) . "a"))))
    (should (= 0 (daselt-abv--letter-score seq w)))))


;;;; Shared affix & collision penalty

(ert-deftest daselt-abv-shared-affix-empty-matrix ()
  "`daselt-abv--shared-affix' returns 0 when the matrix is nil."
  (should (= 0 (daselt-abv--shared-affix nil "a" "b"))))

(ert-deftest daselt-abv-shared-affix-lookup-direct ()
  "`abv-corpus-shared-affix-lookup' reads ((B1 B2) . VALUE) alists."
  (let ((matrix '((("a" "b") . 5) (("a" "c") . 3))))
    (should (= 5 (abv-corpus-shared-affix-lookup matrix "a" "b")))
    (should (= 3 (abv-corpus-shared-affix-lookup matrix "a" "c")))
    (should (null (abv-corpus-shared-affix-lookup matrix "x" "y")))))

(ert-deftest daselt-abv-collision-penalty-nil-matrix ()
  "`daselt-abv--collision-penalty' is 0 when matrix is nil."
  (should (= 0 (daselt-abv--collision-penalty daselt-abv--default-layout
                                              "foo" nil nil nil))))


;;;; Reverse index, freedom checks, candidate filtering

(ert-deftest daselt-abv-build-reverse-index ()
  "`daselt-abv--build-reverse-index' groups roots by coords."
  (let ((tbl (make-hash-table :test 'equal)))
    (puthash "foo" '((1 0 1) (1 0 2)) tbl)
    (puthash "bar" '((1 0 1) (1 0 2)) tbl)
    (puthash "baz" '((1 0 3)) tbl)
    (let ((idx (daselt-abv--build-reverse-index tbl)))
      (should (= 2 (length (gethash '((1 0 1) (1 0 2)) idx))))
      (should (= 1 (length (gethash '((1 0 3)) idx)))))))

(ert-deftest daselt-abv-value-free-p-strict ()
  "`daselt-abv--value-free-p' returns t when coords are not in table."
  (let ((tbl (make-hash-table :test 'equal)))
    (puthash "foo" '((1 0 1)) tbl)
    (should-not (daselt-abv--value-free-p '((1 0 1)) tbl))
    (should (daselt-abv--value-free-p '((9 9 9)) tbl))))

(ert-deftest daselt-abv-value-free-p-count-mode ()
  "`daselt-abv--value-free-p' with t returns the count."
  (let ((tbl (make-hash-table :test 'equal)))
    (puthash "foo" '((1 0 1)) tbl)
    (puthash "bar" '((1 0 1)) tbl)
    (should (= 2 (daselt-abv--value-free-p '((1 0 1)) tbl t)))
    (should (= 0 (daselt-abv--value-free-p '((9 9 9)) tbl t)))))

(ert-deftest daselt-abv-value-free-p-overcount-threshold ()
  "`daselt-abv--value-free-p' with a number is <= test."
  (let ((tbl (make-hash-table :test 'equal)))
    (puthash "foo" '((1 0 1)) tbl)
    (puthash "bar" '((1 0 1)) tbl)
    (should (daselt-abv--value-free-p '((1 0 1)) tbl 2))
    (should (daselt-abv--value-free-p '((1 0 1)) tbl 5))
    (should-not (daselt-abv--value-free-p '((1 0 1)) tbl 1))))

(ert-deftest daselt-abv-value-free-p-uses-reverse-index ()
  "When reverse index is bound, it is consulted."
  (let ((daselt-abv--root-reverse-index
         (let ((h (make-hash-table :test 'equal)))
           (puthash '((1 0 1)) '("foo" "bar") h)
           h))
        (tbl (make-hash-table :test 'equal)))
    (should (= 2 (daselt-abv--value-free-p '((1 0 1)) tbl t)))
    (should-not (daselt-abv--value-free-p '((1 0 1)) tbl))
    (should (daselt-abv--value-free-p '((9 9 9)) tbl))))


;;;; Filter candidates

(ert-deftest daselt-abv-filter-candidates-no-separators-no-cue ()
  "Filtering with no separators or cue-table returns strictly free candidates."
  (let ((table (make-hash-table :test 'equal))
        (cands '(((("a" . 0) (1 0 1) . "a"))
                 ((("b" . 0) (1 0 1) . "b")))))
    ;; Both candidates have the same coords ((1 0 1)); once one is bound
    ;; the other is not strictly free.
    (puthash "x" '((1 0 1)) table)
    (should (null (daselt-abv--filter-candidates cands nil table nil)))))


;;;; Family-weight bonus and initial-cell load (C1/C2)

(ert-deftest daselt-abv-score-family-bonus-raises-score ()
  "A root with family weight scores higher than without."
  (let* ((layout daselt-abv--default-layout)
         (seq '(((1 0 1) . "a")))
         (table (make-hash-table :test 'equal))
         (wobj (abv-weights))
         (plain (daselt-abv--score layout "test" seq table wobj nil))
         (fam (let ((daselt-abv--family-weights
                     (let ((h (make-hash-table :test 'equal)))
                       (puthash "test" 3.0 h) h)))
                (daselt-abv--score layout "test" seq table wobj nil))))
    (should (numberp plain))
    (should (> fam (+ plain (* 0.3 3.0) -1e-6)))))

(ert-deftest daselt-abv-score-initial-load-lowers-score ()
  "A loaded initial cell costs score points on the second pass."
  (let* ((layout daselt-abv--default-layout)
         (seq '(((1 0 1) . "a")))
         (table (make-hash-table :test 'equal))
         (wobj (abv-weights))
         (plain (daselt-abv--score layout "test" seq table wobj nil))
         (loaded (let ((daselt-abv--initial-load
                        (let ((h (make-hash-table :test 'equal)))
                          (puthash '(1 0 1) 4.0 h) h)))
                   (daselt-abv--score layout "test" seq table wobj nil))))
    (should (numberp plain))
    ;; load-term = 0.5 * log(5)
    (should (daselt-abv-tests--approx-equal
             loaded (- plain (* 0.5 (log 5.0))) 1e-6))))

(ert-deftest daselt-abv-weights-new-slots-default ()
  "Fresh weights carry the C1/C2 defaults."
  (let ((w (abv-weights)))
    (should (= (oref w family-weight-bonus) 0.3))
    (should (= (oref w initial-load-weight) 0.5))))

(ert-deftest daselt-abv-weights-slot-fallback-for-unbound ()
  "`daselt-abv--weights-slot' falls back for unbound slots."
  (let ((w (abv-weights)))
    (slot-makeunbound w 'initial-load-weight)
    (should (= (daselt-abv--weights-slot w 'initial-load-weight 0.5) 0.5))
    (should (= (daselt-abv--weights-slot nil 'family-weight-bonus 0.3) 0.3))))


(provide 'daselt-abv-ergonomics-tests)
;;; daselt-abv-ergonomics-tests.el ends here
