;;; daselt-configuration.el --- The persistent Daselt configuration object  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Keywords: keyboard, hardware

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; The `daselt-configuration' object is the source of truth for
;; Daselt's configuration.  It replaces the directory-walking of
;; the old `daselt-dirs' machinery and the cache system: one
;; persistent EIEIO object holds the per-package configuration
;; entries (bindlists, bindforms, constantlists, advicelists,
;; adviceforms, hooklists), the layout data needed at startup, and
;; the compiled code of the `.el' configuration files under
;; `mode-configs/'.
;;
;; The object is saved in the Daselt repository
;; (`daselt-configuration-file', default
;; `daselt-configuration-data.el' in `daselt-emacs-dir'), so it is
;; shared between computers like the rest of the repository.  The
;; compiled-code section is machine-specific:
;; `daselt-configuration-import-compiled-code' records a
;; fingerprint (system name, Emacs version, compile type, per-file
;; checksums) with every import, and `daselt-mode' re-imports
;; automatically on startup when it finds the code was compiled on
;; a different computer.
;;
;; The entry classes are plain EIEIO objects, so the whole
;; configuration can be navigated and edited with the
;; `ei-interface' choice interface (`ei-choose', `ei-edit', and
;; the edit buffers of Daselt built on `ei-edit-buffer').
;;
;; Import and export keep a hybrid workflow possible:
;; `daselt-configuration-import' reads the `.dbl'/`.dcl'/... files
;; of `mode-configs/' into a fresh object, and
;; `daselt-configuration-export' writes the entries back to their
;; source files for diffing and sharing.  Entry files are visited
;; in `daselt-configuration-entry-mode', derived from
;; `emacs-lisp-mode'; it binds re-importing the visited file.

;;; Code:

(require 'cl-lib)
(require 'eieio)
(require 'eieio-base)
(require 'ei-interface)
(require 'daselt-base)
(require 'daselt-eieio)
(require 'daselt-bind)

(defvar daselt-emacs-dir nil
  "Directory Daselt's Emacs component is installed in.
Defined in `daselt.el'; declared here so the functions below can
be used before it is loaded.")

(defvar daselt-xkb-file)

(defgroup daselt-configuration nil
  "The persistent Daselt configuration object."
  :group 'daselt)

(defcustom daselt-configuration-file nil
  "File where the Daselt configuration object is stored.

If nil, defaults to `daselt-configuration-data.el' in
`daselt-emacs-dir'.  The file is meant to live in the Daselt
repository and be shared between computers; the compiled-code
section is re-imported per machine, see
`daselt-configuration-import-compiled-code'."
  :type '(choice file (const :tag "Use default location" nil))
  :group 'daselt-configuration)

(defcustom daselt-compile-type 'byte
  "How the `.el' configuration files of `mode-configs/' are compiled.
`byte' embeds the byte-compiled forms in the configuration
object; `native' compiles with `native-compile-async' and stores
the `.eln' file to load (native compilation units cannot be
embedded)."
  :type '(choice (const :tag "Byte compilation" byte)
                 (const :tag "Native compilation" native))
  :group 'daselt-configuration)

(defcustom daselt-configuration-verbose nil
  "If non-nil, print messages about configuration operations."
  :type 'boolean
  :group 'daselt-configuration)

;;;; Entry and package classes

(defclass daselt-config-entry ()
  ((form
    :initarg :form
    :initform nil
    :documentation "The configuration s-expression: one bindlist,
constantlist, advicelist, adviceform, bindform or hooklist as it
was read from its source file.")
   (kind
    :initarg :kind
    :initform 'normal
    :type symbol
    :documentation "How the entry is applied: `normal' entries are
deferred until their package loads (see
`daselt-bind-with-eval-unless-init'), `init' entries are applied
immediately when Daselt starts, `special' entries are only saved
as variables and never applied, and `user-defined' entries are
user additions with their own variable naming.")
   (source-file
    :initarg :source-file
    :initform nil
    :type (or null string)
    :documentation "The file the entry was imported from, for
export and provenance."))
  (:documentation "One configuration entry of a package."))

(defclass daselt-package-config ()
  ((name
    :initarg :name
    :type symbol
    :documentation "The package name; also the name of its
subdirectory of `mode-configs/'.")
   (enabled
    :initarg :enabled
    :initform t
    :type boolean
    :documentation "Whether this package's configuration is
applied at all.  This replaces the generated `daselt-<pkg>'
customization options of the old directory machinery.")
   (lisp-files
    :initarg :lisp-files
    :initform nil
    :type list
    :documentation "The package's Emacs-Lisp source files, as
paths relative to `daselt-emacs-dir'.  Their compiled code is
imported into the configuration by
`daselt-configuration-import-compiled-code'.")
   (bindlists :initarg :bindlists :initform nil :type list
              :documentation "Bindlist entries.")
   (bindforms :initarg :bindforms :initform nil :type list
              :documentation "Bindform entries; each form
evaluates to a bindlist.")
   (constantlists :initarg :constantlists :initform nil :type list
                  :documentation "Constantlist entries.")
   (advicelists :initarg :advicelists :initform nil :type list
                :documentation "Advicelist entries.")
   (adviceforms :initarg :adviceforms :initform nil :type list
                :documentation "Adviceform entries; each form
evaluates to an advicelist.")
   (hooklists :initarg :hooklists :initform nil :type list
              :documentation "Hooklist entries of (FUNCTION .
HOOK) pairs."))
  (:documentation "The configuration of one package."))

(defclass daselt-configuration (eieio-persistent)
  ((name
    :initarg :name
    :initform "daselt"
    :type string
    :documentation "Name of the configuration.")
   (keyboard-layout-type
    :initarg :keyboard-layout-type
    :initform "iso"
    :type (or null string)
    :documentation "Keyboard type: \"ansi\" or \"iso\".")
   (xkb-layout
    :initarg :xkb-layout
    :initform nil
    :type (or null symbol)
    :documentation "The active xkb layout symbol.")
   (xkb-layouts
    :initarg :xkb-layouts
    :initform nil
    :type list
    :documentation "The parsed xkb layouts, as filled by
`daselt-xkb-generate-layouts'.")
   (dfk-layout
    :initarg :dfk-layout
    :initform nil
    :documentation "The active dfk layout, a `daselt-layout'
object.")
   (layout-data
    :initarg :layout-data
    :initform nil
    :type list
    :documentation "Alist (SYMBOL . DATA) of the values of the
layout symbols: every symbol of `daselt-xkb-layouts' and the
symbol named by `daselt-dfk-layout'.  Restoring these lets the
fast start-up path translate coordinates into key strings
without re-parsing the dxkb file.")
   (xkb-digest
    :initarg :xkb-digest
    :initform nil
    :type (or null string)
    :documentation "SHA-256 digest of `daselt-xkb-file' when the
layout data was captured.  See
`daselt-configuration-layout-current-p'.")
   (outside-mods
    :initarg :outside-mods
    :initform nil
    :type (or null list)
    :documentation "The `daselt-dfk-outside-mods' layout
data.")
   (translate-keys
    :initarg :translate-keys
    :initform t
    :type boolean
    :documentation "Whether key translations are active.")
   (key-translations
    :initarg :key-translations
    :initform nil
    :type list
    :documentation "The active key translations.")
   (boundaries
    :initarg :boundaries
    :initform nil
    :type list
    :documentation "Layout boundaries for drawing, as computed
from the coordinatized layers.")
   (packages
    :initarg :packages
    :initform nil
    :type list
    :documentation "The `daselt-package-config' objects, one per
package.")
   (compile-info
    :initarg :compile-info
    :initform nil
    :type list
    :documentation "Alist of per-machine compiled-code
fingerprints, keyed by system name.  Each entry is (SYSTEM
. ((emacs-version . VERSION) (compile-type . TYPE) (files
. ((REL-FILE . SHA256) ...)))).")
   (code
    :initarg :code
    :initform nil
    :type list
    :documentation "The imported compiled code, an alist
(REL-FILE . INFO).  For byte compilation INFO is ((type . byte)
(forms . FORMS)) with the forms of the `.elc' file, for embedded
sources ((type . source) (forms . FORMS)), and for native
compilation INFO is ((type . native) (eln . PATH)) with the
`.eln' file to load."))
  (:documentation "The complete Daselt configuration.

This object captures all the state Daselt needs at startup: the
layout data, the per-package configuration entries, and the
compiled code of the `.el' files under `mode-configs/'.  It is
the persistent replacement of both the old `mode-configs/'
directory walk and the cache system."))

;;;; The configuration file

(defun daselt-configuration--file ()
  "Return the configuration file path."
  (or daselt-configuration-file
      (expand-file-name
       "daselt-configuration-data.el"
       (if (and (boundp 'daselt-emacs-dir) daselt-emacs-dir)
           daselt-emacs-dir
         default-directory))))

(defun daselt-configuration-save (config)
  "Save CONFIG to its file atomically and validated.
Write to a temporary file first with a coding cookie and the
persistent-object machinery (which also reconstructs nested
objects on load), read the file back to prove it loads, and
rename into place; an unreadable file never replaces the old
one.  Return CONFIG."
  (let* ((file (daselt-configuration--file))
         (tmp (expand-file-name
               (concat ".daselt-configuration-" (prin1-to-string (emacs-pid)) ".tmp")
               (file-name-directory file))))
    (setf (slot-value config 'file) file)
    (unwind-protect
        (progn
          (let ((coding-system-for-write 'utf-8-emacs))
            (with-temp-file tmp
              ;; The coding cookie makes `read' decode the accented
              ;; key names of the layout data correctly on every
              ;; machine; without it the file may be read as raw
              ;; bytes and all bindings with non-ASCII keys break.
              (insert ";;; daselt configuration  -*- coding: utf-8-emacs; -*-\n")
              ;; `object-write' writes to `standard-output'.
              (let ((standard-output (current-buffer)))
                (object-write config))))
          (unless (daselt-configuration--file-readable-p tmp)
            (error "Configuration file %s did not read back correctly" tmp))
          (rename-file tmp file t)
          (when daselt-configuration-verbose
            (message "Daselt configuration saved to %s" file)))
      (when (file-exists-p tmp)
        (delete-file tmp)))
    config))

(defun daselt-configuration--file-readable-p (file)
  "Return non-nil when FILE reads back as the configuration object."
  (condition-case nil
      (prog1 t (eieio-persistent-read file 'daselt-configuration t))
    (error nil)))

(defun daselt-configuration-load ()
  "Read the configuration object from its file and return it.
Signal an error when the file is missing or unreadable."
  (let ((file (daselt-configuration--file)))
    (unless (file-exists-p file)
      (error "No Daselt configuration at %s; run daselt-configuration-import" file))
    ;; Force the coding the file was written with; see
    ;; `daselt-configuration-save'.
    (let ((coding-system-for-read 'utf-8-emacs))
      (eieio-persistent-read file 'daselt-configuration t))))

;;;; Finding and updating

(defun daselt-configuration-find-package (config name)
  "Return the `daselt-package-config' named NAME in CONFIG, or nil."
  (cl-find-if (lambda (pkg) (eq (oref pkg name) name))
              (oref config packages)))

(cl-defun daselt-configuration-update-package (config package)
  "Insert or replace PACKAGE in CONFIG's package list by name."
  (let ((old (daselt-configuration-find-package
              config (oref package name))))
    (if old
        (setf (slot-value config 'packages)
              (cl-substitute package old (oref config packages)
                             :test #'eql))
      (push package (slot-value config 'packages)))
    config))

;;;; Importing from the mode-configs directory

(defun daselt-configuration--read-forms-from-file (filename)
  "Read all top-level forms of FILENAME, skipping comments.
Always read the current on-disk content into a temporary buffer:
a buffer visiting FILENAME (stale or with unsaved edits) must not
shadow the file, or an import silently reads old forms."
  (with-temp-buffer
    (insert-file-contents filename)
    (save-excursion
      (goto-char (point-min))
      (let (forms)
        (condition-case nil
            (while t
              (skip-chars-forward " \t\r\n")
              (when (eq (char-after) ?\;)
                (forward-comment 1))
              (skip-chars-forward " \t\r\n")
              (when (eobp) (signal 'end-of-file nil))
              (push (read (current-buffer)) forms))
          (end-of-file))
        (nreverse forms)))))

(defun daselt-configuration--kind-from-filename (filename)
  "Derive the entry kind of FILENAME from its name modifiers.
Mirrors the filename matching of the old directory machinery:
`-init-' in the containing (package) directory name makes entries
immediate, `special' in the file name makes bindlists save-only
and everything else skipped, `-user-defined' in the file name
only influences the variable naming."
  (let ((dirname (daselt-base-containing-directory-base-name filename))
        (name (file-name-nondirectory filename)))
    (cond ((or (string-match-p "-init" dirname)
               (string-match-p "-init" (file-name-base name))) 'init)
          ((string-match-p "special" name) 'special)
          ((string-match-p "-user-defined" name) 'user-defined)
          (t 'normal))))

(defun daselt-configuration--import-file (package ext filename rel)
  "Import FILENAME with extension EXT into PACKAGE.
REL is FILENAME relative to `daselt-emacs-dir'."
  (cond
   ((member ext '("dbl" "deio"))
    (dolist (form (daselt-configuration--read-forms-from-file filename))
      ;; Unwrap `.deio'/`.dclo' persistent objects.
      (when (and (consp form)
                 (memq (car form)
                       '(daselt-persistent-bindlist
                         daselt-persistent-constantlist)))
        (setq form (plist-get (cdr form) :form)))
      (push (daselt-config-entry
             :form form
             :kind (daselt-configuration--kind-from-filename filename)
             :source-file rel)
            (slot-value package 'bindlists))))
   ((string= ext "dbf")
    (dolist (form (daselt-configuration--read-forms-from-file filename))
      (push (daselt-config-entry :form form
                                 :kind (daselt-configuration--kind-from-filename filename)
                                 :source-file rel)
            (slot-value package 'bindforms))))
   ((string= ext "dcl")
    (dolist (form (daselt-configuration--read-forms-from-file filename))
      (push (daselt-config-entry :form form
                                 :kind (daselt-configuration--kind-from-filename filename)
                                 :source-file rel)
            (slot-value package 'constantlists))))
   ((member ext '("dal" "daf"))
    (dolist (form (daselt-configuration--read-forms-from-file filename))
      (push (daselt-config-entry :form form
                                 :kind (daselt-configuration--kind-from-filename filename)
                                 :source-file rel)
            (slot-value package
                        (if (string= ext "dal") 'advicelists 'adviceforms)))))
   ((string= ext "dhl")
    (dolist (form (daselt-configuration--read-forms-from-file filename))
      (push (daselt-config-entry :form form
                                 :kind (daselt-configuration--kind-from-filename filename)
                                 :source-file rel)
            (slot-value package 'hooklists))))
   ((member ext '("el" "del"))
    (unless (string-match-p "tests?" (file-name-nondirectory filename))
      (push rel (slot-value package 'lisp-files))))))

(defun daselt-configuration--ensure-package (config name)
  "Return the package named NAME in CONFIG, creating it when absent.
A new package is registered in CONFIG and enabled like the
directory import does: from the `daselt-<name>' customization
option when bound, else by default.  The enabled flag replaces
the generated `daselt-<pkg>' customization options of the old
directory machinery; packages already in the object keep their
flag (the user may have toggled it through the ei interface),
and new ones are enabled by default --- the entries are deferred
until the package's feature loads, so nothing happens for
packages that are never loaded.  The old defaults
\(`featurep'/`package-installed-p') disabled built-in packages
like dired and site-lisp packages like abv.  Daselt's own
configuration must always be enabled; the old machinery forced
this with `(setopt daselt-daselt-mode t)'.  Return
\(PACKAGE . NEW-P), with NEW-P non-nil for a created package."
  (let ((package (daselt-configuration-find-package config name))
        (new-p nil))
    (unless package
      (setq package (daselt-package-config :name name)
            new-p t)
      (let ((custom (intern (format "daselt-%s" name))))
        (setf (slot-value package 'enabled)
              (if (boundp custom)
                  (and (symbol-value custom) t)
                t)))
      (daselt-configuration-update-package config package))
    ;; Daselt's own configuration must always be enabled.
    (when (eq name 'daselt-mode)
      (setf (slot-value package 'enabled) t))
    (cons package new-p)))

(defun daselt-configuration--import-directory (config dir)
  "Import the package subdirectories of DIR into CONFIG.
Recurse into nested directories, so nested packages (like
`avy/avy-act') are found, like the old directory walk."
  (dolist (subdir (directory-files dir t "\\`[^.]"))
    (when (file-directory-p subdir)
      (let* ((name (intern (file-name-nondirectory (directory-file-name subdir))))
             (package (car (daselt-configuration--ensure-package config name))))
        (dolist (file (directory-files subdir t "\\.\\(el\\|del\\|dbl\\|dbf\\|dcl\\|dal\\|daf\\|dhl\\|deio\\|dclo\\)\\'"))
          (unless (or (file-directory-p file)
                      ;; Skip compiled artifacts.
                      (member (file-name-extension file) '("elc" "eln")))
            (daselt-configuration--import-file
             package (file-name-extension file) file
             (file-relative-name file daselt-emacs-dir))))
        ;; Nested package directories.
        (daselt-configuration--import-directory config subdir)))))

(defun daselt-configuration-import (&optional pkg-configs-dir)
  "Build a `daselt-configuration' from PKG-CONFIGS-DIR.
PKG-CONFIGS-DIR defaults to the `mode-configs/' directory of
`daselt-emacs-dir'.  Read every `.dbl'/`.dbf'/`.dcl'/`.dal'/`.daf'/`.dhl'
file (and `.deio'/`.dclo' objects, which are unwrapped) into
`daselt-config-entry' objects and register the `.el'/`.del'
lisp files; capture the current layout data when it is
available.  Return, and save, the configuration."
  (interactive)
  (let* ((dir (or pkg-configs-dir
                  (expand-file-name "mode-configs" daselt-emacs-dir)))
         (config (daselt-configuration)))
    (daselt-configuration--import-directory config dir)
    (daselt-configuration--capture-layout-data config)
    (daselt-configuration-import-compiled-code config)
    (daselt-configuration-save config)
    (when (called-interactively-p 'interactive)
      (message "Imported Daselt configuration with %d packages to %s"
               (length (oref config packages))
               (daselt-configuration--file)))
    config))

(defconst daselt-configuration--import-extensions
  '("el" "del" "dbl" "dbf" "dcl" "dal" "daf" "dhl" "deio" "dclo")
  "File extensions `daselt-configuration-import-file' accepts.
Mirrors the extension matching of `daselt-configuration--import-directory'.")

(defun daselt-configuration--import-file-p (file)
  "Return non-nil when FILE is an importable configuration file.
An existing file with one of the importable extensions (see
`daselt-configuration--import-extensions'), never a directory."
  (and (file-exists-p file)
       (not (file-directory-p file))
       (member (file-name-extension file)
               daselt-configuration--import-extensions)))

(defun daselt-configuration--latest-entry-file (dir)
  "Return the most recently modified entry file under DIR, or nil.
Entry files only (`.dbl'/`.dbf'/`.dcl'/`.dal'/`.daf'/`.dhl'/`.deio'/`.dclo');
lisp files are never import defaults.  A nonexistent DIR yields nil."
  (when (file-directory-p dir)
    (car (sort
          (directory-files-recursively
           dir "\\.\\(dbl\\|dbf\\|dcl\\|dal\\|daf\\|dhl\\|deio\\|dclo\\)\\'")
          (lambda (a b)
            (time-less-p (nth 5 (file-attributes b))
                         (nth 5 (file-attributes a))))))))

(defun daselt-configuration--import-default ()
  "Return the most plausible entry file to import by default.
The current buffer's file when it is an entry file (the file just
edited), else the most recently modified entry file under
`mode-configs/'.  Without an explicit default, completion
frameworks show the current buffer's file anyway (Icicles does)
but return a directory on RET."
  (or (let ((bf (buffer-file-name)))
        (when (and bf
                   (member (file-name-extension bf)
                           '("dbl" "dbf" "dcl" "dal" "daf" "dhl"
                             "deio" "dclo")))
          bf))
      (when (and (boundp 'daselt-emacs-dir) daselt-emacs-dir)
        (daselt-configuration--latest-entry-file
         (expand-file-name "mode-configs" daselt-emacs-dir)))))

(defun daselt-configuration--resolve-import-choice (file default _dir)
  "Resolve the completion result FILE to an importable file, or nil.
FILE is what `read-file-name' returned with DEFAULT as the
default.  Return FILE when it is importable.  Return DEFAULT when
FILE is a directory: plain RET returns the pre-inserted directory,
an erased minibuffer returns `default-directory', and completion
frameworks like Icicles return directories on RET --- and the
displayed hint of `read-file-name' does not even come from its
DEFAULT argument, so the default has to be resolved here.
Return nil for anything else non-importable so the caller can
re-prompt."
  (cond ((daselt-configuration--import-file-p file) file)
        ((and default (file-directory-p file)) default)
        (t nil)))

(defun daselt-configuration--read-import-file ()
  "Read a configuration entry file to import, with completion.
Default to the `mode-configs/' directory and complete over the
importable extensions.  The default, named in the prompt, is the
current buffer's entry file or the most recently modified entry
file; an empty RET resolves to it.  Only a real entry file is
accepted: completion frameworks like Icicles return directories
on RET, which used to slip through and import nothing under a
junk package named after the parent directory."
  (cl-block exit
    (while t
      (let* ((default (daselt-configuration--import-default))
             (file (expand-file-name
                    (read-file-name
                     (if default
                         (format "Import configuration file (default %s): "
                                 (file-name-nondirectory default))
                       "Import configuration file: ")
                     (expand-file-name "mode-configs" daselt-emacs-dir)
                     default t nil
                     (lambda (f)
                       (or (file-directory-p f)
                           (member
                            (file-name-extension f)
                            daselt-configuration--import-extensions)))))))
        (let ((choice (daselt-configuration--resolve-import-choice
                       file default nil)))
          (when choice
            (cl-return-from exit choice))
          (message "%s is not an importable configuration file" file)
          (sit-for 1))))))

(defun daselt-configuration-import-file (file &optional config apply)
  "Import the configuration FILE into CONFIG; save and return CONFIG.
FILE is a `.dbl'/`.dbf'/`.dcl'/`.dal'/`.daf'/`.dhl' entry file
(or a `.deio'/`.dclo' persistent object, which is unwrapped); its
forms are read into the package named after FILE's directory,
replacing the entries previously imported from FILE.  This is the
file-based path back into the collection: edit an exported file
\(found with `daselt-configuration-find-entry-file') and re-import
it.  Importing a `.el'/`.del' lisp file registers it and re-imports
the compiled code.  CONFIG defaults to the current configuration,
built with `daselt-configuration-import' when there is none yet.
With APPLY non-nil, also apply the package through
`daselt-configuration-apply-package', so the imported entries
become effective immediately (entries of a loaded package apply
at once, the rest defer until their package loads, as at
startup); APPLY is always set when called interactively."
  (interactive (list (daselt-configuration--read-import-file) nil t))
  (let* ((file (expand-file-name file))
         (ext (file-name-extension file)))
    ;; Refuse a non-importable pick (a directory or a stray
    ;; extension) before touching the configuration; importing a
    ;; directory used to succeed vacuously and save a junk package.
    (unless (daselt-configuration--import-file-p file)
      (user-error "Not an importable configuration file: %s" file))
    (let* ((config (or config
                       (condition-case nil
                           (daselt-configuration-load)
                         (error (daselt-configuration-import)))))
           (rel (file-relative-name file daselt-emacs-dir))
           (name (intern (daselt-base-containing-directory-base-name file)))
           (package (car (daselt-configuration--ensure-package config name))))
      ;; Replace the entries of a previous import of FILE.
      (dolist (slot '(bindlists bindforms constantlists
                              advicelists adviceforms hooklists))
        (setf (slot-value package slot)
              (cl-remove-if (lambda (entry)
                              (equal (oref entry source-file) rel))
                            (slot-value package slot))))
      (setf (slot-value package 'lisp-files)
            (cl-remove rel (slot-value package 'lisp-files) :test #'equal))
      (daselt-configuration--import-file package ext file rel)
      (when (member ext '("el" "del"))
        (daselt-configuration-import-compiled-code config))
      (daselt-configuration-save config)
      (when apply
        (daselt-configuration-apply-package package))
      (when (called-interactively-p 'interactive)
        (message "Imported %s into package `%s' and saved the configuration%s"
                 rel name (if apply "; applying the package" "")))
      config)))

(defun daselt-configuration--capture-layout-data (config)
  "Fill CONFIG's layout slots from the current runtime state."
  (dolist (slot-var
           '((keyboard-layout-type daselt-dfk-keyboard-layout-type)
             (xkb-layout daselt-xkb-layout)
             (xkb-layouts daselt-xkb-layouts)
             (dfk-layout daselt-dfk-layout)
             (outside-mods daselt-dfk-outside-mods)
             (key-translations daselt-bind-key-translations-alist)
             (boundaries daselt-bind-boundaries)
             (translate-keys daselt-bind-translate-keys)))
    (cl-destructuring-bind (slot var) slot-var
      (when (and (boundp var) (symbol-value var))
        (setf (slot-value config slot) (symbol-value var)))))
  ;; The values of the layout symbols: without them a fresh session
  ;; cannot translate coordinates into key strings on the fast path.
  (let ((data nil))
    (dolist (sym (and (boundp 'daselt-xkb-layouts) daselt-xkb-layouts))
      (when (and sym (boundp sym))
        (push (cons sym (symbol-value sym)) data)))
    (when (and (boundp 'daselt-dfk-layout)
               daselt-dfk-layout
               (symbolp daselt-dfk-layout)
               (boundp daselt-dfk-layout))
      (cl-pushnew (cons daselt-dfk-layout (symbol-value daselt-dfk-layout))
                  data :test #'equal))
    (setf (slot-value config 'layout-data) data))
  (setf (slot-value config 'xkb-digest) (daselt-configuration--xkb-digest)))

(defun daselt-configuration--xkb-digest ()
  "Return the digest of `daselt-xkb-file', or nil if it is unreadable."
  (and (bound-and-true-p daselt-xkb-file)
       (file-readable-p daselt-xkb-file)
       (daselt-configuration--file-digest daselt-xkb-file)))

(defun daselt-configuration-layout-current-p (config)
  "Return non-nil when CONFIG's layout data matches `daselt-xkb-file'.
The data is current when it exists and was captured from a dxkb
file with the same contents.  An unreadable dxkb file cannot be
re-parsed, so the stored data counts as current then."
  (and (oref config layout-data)
       (let ((digest (daselt-configuration--xkb-digest)))
         (or (null digest)
             (equal digest (oref config xkb-digest))))))

(defun daselt-configuration--restore-layout-data (config)
  "Restore the runtime layout state from CONFIG's layout slots."
  (dolist (slot-var
           '((keyboard-layout-type daselt-dfk-keyboard-layout-type)
             (xkb-layout daselt-xkb-layout)
             (xkb-layouts daselt-xkb-layouts)
             (dfk-layout daselt-dfk-layout)
             (outside-mods daselt-dfk-outside-mods)
             (key-translations daselt-bind-key-translations-alist)
             (boundaries daselt-bind-boundaries)
             (translate-keys daselt-bind-translate-keys)))
    (cl-destructuring-bind (slot var) slot-var
      (let ((val (slot-value config slot)))
        (when val
          (set (intern (format "%s" var)) val)))))
  (dolist (pair (oref config layout-data))
    (set (car pair) (cdr pair))))

;;;; Exporting back to files

(defconst daselt-configuration--entry-extensions
  '((bindlists . "dbl")
    (bindforms . "dbf")
    (constantlists . "dcl")
    (advicelists . "dal")
    (adviceforms . "daf")
    (hooklists . "dhl"))
  "Extension to write each entry slot of a `daselt-package-config'.")

(defun daselt-configuration-export (&optional config pkg-configs-dir)
  "Write the entries of CONFIG back to their source files.
CONFIG defaults to the file's configuration; PKG-CONFIGS-DIR
defaults to the `mode-configs/' directory.  Every entry with a
`source-file' is written there (unwrapping to the `.dbl'/`.dcl'
extension), so the object and the files can be diffed and shared
even though the object is the source of truth."
  (interactive)
  (let ((config (or config (daselt-configuration-load)))
        (dir (or pkg-configs-dir
                 (expand-file-name "mode-configs" daselt-emacs-dir))))
    (dolist (package (oref config packages))
      (dolist (slot-ext daselt-configuration--entry-extensions)
        (let ((entries (slot-value package (car slot-ext))))
          (dolist (group (seq-group-by
                          (lambda (entry) (oref entry source-file))
                          entries))
            (let* ((rel (car group))
                   (file (if rel
                             (expand-file-name rel daselt-emacs-dir)
                           (expand-file-name
                            (format "%s.%s"
                                    (oref package name) (cdr slot-ext))
                            (expand-file-name
                             (symbol-name (oref package name)) dir)))))
              (make-directory (file-name-directory file) t)
              (with-temp-file file
                (insert (format ";;; %s --- exported by daselt-configuration-export\n\n"
                                (file-name-nondirectory file)))
                (dolist (entry (cdr group))
                  (insert (pp-to-string (oref entry form)) "\n"))))))))
    (when (called-interactively-p 'interactive)
      (message "Exported Daselt configuration to %s" dir))))

;;;; Importing compiled code

(defun daselt-configuration--file-digest (file)
  "Return the SHA-256 digest of FILE's contents.
Only the contents matter: re-writing a file with the same
contents keeps the compiled code current."
  (with-temp-buffer
    (insert-file-contents file)
    (secure-hash 'sha256 (current-buffer))))

(defun daselt-configuration--machine-info ()
  "Return the machine info of this computer as an alist."
  `((system . ,(system-name))
    (emacs-version . ,emacs-version)
    (compile-type . ,daselt-compile-type)))

(defun daselt-configuration--current-system-entry (config)
  "Return CONFIG's compile-info entry for this computer, or nil."
  (alist-get (system-name) (oref config compile-info) nil nil #'equal))

(defun daselt-configuration-code-current-p (config)
  "Return non-nil when CONFIG's compiled code is current here.
The code is current when an import ran on this system, with this
Emacs version and compile type, and none of the `.el' source
files changed since."
  (let* ((entry (daselt-configuration--current-system-entry config))
         (files (cdr (assq 'files entry))))
    (and entry
         (equal (cdr (assq 'emacs-version entry)) emacs-version)
         (eq (cdr (assq 'compile-type entry)) daselt-compile-type)
         (cl-every
          (lambda (code-entry)
            (let* ((rel (car code-entry))
                   (file (expand-file-name rel daselt-emacs-dir))
                   (info (cdr (assoc rel files #'equal))))
              (and (file-exists-p file)
                   info
                   (equal (daselt-configuration--file-digest file) info))))
          (oref config code)))))

(defun daselt-configuration--compile-file (file)
  "Compile FILE according to `daselt-compile-type'.
Return (INFO . FORMS): INFO describes the code entry and FORMS is
the list of forms to store; for native compilation FORMS is nil
and INFO names the `.eln' file."
  (pcase daselt-compile-type
    ('byte
     (let ((elc (concat (file-name-sans-extension file) ".elc")))
       (cons (if (and (byte-compile-file file)
                      (file-exists-p elc))
                 `((type . byte)
                   (forms . ,(daselt-configuration--read-forms-from-file elc)))
               ;; Byte compilation may fail when the file requires
               ;; packages that are not on `load-path' here; embed the
               ;; source forms instead, so the configuration stays
               ;; self-contained.
               `((type . source)
                 (forms . ,(daselt-configuration--read-forms-from-file file))))
             nil)))
    ('native
     (native-compile-async file 'late)
     (let ((timeout 60)
           (eln nil))
       (with-timeout (timeout (error "Native compilation of %s timed out" file))
         (while (null eln)
           (let ((buf (get-buffer "*Async-native-compile*")))
             (when (and buf (not (process-live-p (get-buffer-process buf))))
               (setq eln t)))
           (sit-for 0.1)))
       (let ((eln-file (expand-file-name
                        (concat (file-name-sans-extension (file-name-nondirectory file))
                                "--" (replace-regexp-in-string "/" "!" (file-name-sans-extension file))
                                ".eln")
                        (car (last (bound-and-true-p native-comp-eln-load-path))))))
         (unless (file-exists-p eln-file)
           (error "Native compilation of %s produced no .eln at %s"
                  file eln-file))
         (cons `((type . native) (eln . ,eln-file)) nil))))
    (_ (error "Unknown daselt-compile-type: %S" daselt-compile-type))))

(defun daselt-configuration-import-compiled-code (&optional config)
  "Import the compiled code of the `.el' files into CONFIG.
Every package's `lisp-files' are compiled according to
`daselt-compile-type'; the byte-compiled forms are embedded in
the configuration, native compilation stores the `.eln' file to
load.  A fingerprint of this computer is recorded so
`daselt-configuration-code-current-p' can detect stale code.
Return CONFIG."
  (interactive)
  (let ((config (or config (daselt-configuration-load))))
    (let ((code nil)
          (digests nil))
      (dolist (package (oref config packages))
        (dolist (rel (oref package lisp-files))
          (let* ((file (expand-file-name rel daselt-emacs-dir))
                 (compiled
                  (condition-case err
                      (daselt-configuration--compile-file file)
                    (error
                     (warn "Skipping %s: %s" rel (error-message-string err))
                     nil))))
            (when compiled
              (push (cons rel (car compiled)) code)
              (push (cons rel (daselt-configuration--file-digest file))
                    digests)))))
      (setf (slot-value config 'code) (nreverse code))
      (let ((info (daselt-configuration--machine-info)))
        (setf (alist-get (cdr (assq 'system info))
                         (slot-value config 'compile-info)
                         nil nil #'equal)
              (append info (list (cons 'files (nreverse digests)))))))
    (when (called-interactively-p 'interactive)
      (message "Imported compiled code for %d files into the configuration"
               (length (oref config code))))
    config))

(defun daselt-configuration-eval-code (config)
  "Make the compiled code of CONFIG effective, deferred per package.
The code of packages whose feature is already loaded is evaluated
immediately; everything else is registered through
`daselt-bind--register-after-load' and evaluated when the package
loads, like the old `.del' loading.  A form that signals an error
only produces a warning.  Return the number of code files
registered."
  (let ((count 0))
    (dolist (package (oref config packages))
      (when (oref package enabled)
        (let ((entries (cl-remove-if-not
                        (lambda (e) (member (car e) (oref package lisp-files)))
                        (oref config code))))
          (when entries
            (cl-incf count (length entries))
            (let ((pkg-name (oref package name)))
              (daselt-bind--register-after-load
               pkg-name
               (lambda ()
                 (dolist (e entries)
                   (pcase (cdr (assq 'type (cdr e)))
                     ((or 'byte 'source)
                      (dolist (form (cdr (assq 'forms (cdr e))))
                        (condition-case err
                            (eval form)
                          (error (warn "Daselt: skipping a form of %s: %s"
                                       (car e) (error-message-string err))))))
                     ('native
                      (condition-case err
                          (load (cdr (assq 'eln (cdr e))) nil t)
                        (error (warn "Daselt: cannot load native code of %s: %s"
                                     (car e) (error-message-string err)))))
                     (_ (warn "Unknown code entry type for %s" (car e))))))))))))
    count))

;;;; Applying the configuration

(defvar daselt-configuration--hook-removals nil
  "Alist of (FUNCTION . HOOK) pairs to remove when `daselt-mode' is disabled.")

(defun daselt-configuration--entry-file (entry package)
  "Return the absolute path standing in for ENTRY of PACKAGE.
The entry's source file when it has one; otherwise a synthetic
path under the package's `mode-configs/' subdirectory, so that
the naming and deferral logic that reads the file context keeps
working for entries created through the ei interface.  The path
must be absolute: value expressions read sibling files through
\(file-name-directory (buffer-file-name)), and a relative path
would resolve against `default-directory' at apply time —
`find-file-noselect' then silently creates an empty buffer and
the constant ends up nil."
  (expand-file-name
   (or (oref entry source-file)
       (format "mode-configs/%s/%s.dbl"
               (oref package name) (oref package name)))
   (and (boundp 'daselt-emacs-dir) daselt-emacs-dir)))

(defun daselt-configuration--defer (entry package fun &optional evalcond)
  "Run FUN now or once EVALCOND is fulfilled.
`init' entries run immediately; everything else is deferred
through `daselt-bind--register-after-load', with EVALCOND
defaulting to the feature named like PACKAGE."
  (if (eq (oref entry kind) 'init)
      (funcall fun)
    (daselt-bind--register-after-load
     (or evalcond (oref package name)) fun)))

(defun daselt-configuration-apply-bindlist-entry (package entry &optional apply)
  "Save ENTRY's bindlist of PACKAGE as a variable and apply it.
APPLY non-nil also applies the bindlist, deferred like the old
`mode-configs' machinery: `init' entries immediately, everything
else once the package (or the bindlist's head condition) is
fulfilled.  `special' entries are only saved, never applied."
  (let* ((form (oref entry form))
         (file (daselt-configuration--entry-file entry package))
         (head (daselt-bind-head form))
         ;; A multi-map form (EVAL (MAP1 ...) (MAP2 ...)) defers under
         ;; its EVAL head; a single-map form defers under the package
         ;; feature, exactly like `daselt-bind-apply-bindlist' does.
         (headpairt (and head (daselt-bind-head (cadr form))))
         (evalcnd (if headpairt head (oref package name)))
         (buffer-file-name file))
    (let ((symbol-s (daselt-bind-save-bindlist-as-variable form)))
      (when (and apply (not (eq (oref entry kind) 'special)))
        (cl-flet ((apply-from-symbol (symbol)
                    (let ((buffer-file-name file))
                      (daselt-bind-apply-bindlist (symbol-value symbol)))))
          (if (listp symbol-s)
              ;; A list of symbols means a non-trivial eval condition.
              (daselt-configuration--defer
               entry package
               (lambda () (mapcar #'apply-from-symbol symbol-s)) head)
            (daselt-configuration--defer
             entry package
             (lambda () (apply-from-symbol symbol-s)) evalcnd)))))))

(defun daselt-configuration-save-bindform-entry (package entry)
  "Evaluate ENTRY's bindform of PACKAGE and save the bindlist as a variable."
  (let ((buffer-file-name (daselt-configuration--entry-file entry package)))
    (daselt-bind-save-bindlist-as-variable (eval (oref entry form)))))

(defun daselt-configuration--set-constants (constlist pfx configname filename)
  "Set all constants in CONSTLIST according to their values.
Back each up in PFX-CONSTNAME-backup first and record it, then set
it and note CONFIGNAME and FILENAME in the documentation."
  (mapc (lambda (constcons)
          (let* ((constsymb (car constcons))
                 (constname (symbol-name constsymb))
                 (constval (eval (cdr constcons)))
                 (backupname (concat pfx constname "-backup"))
                 (backupsymb (intern backupname))
                 (symbdoc (get constsymb 'variable-documentation)))
            (unless (or (boundp backupsymb)
                        (not (boundp constsymb)))
              (set backupsymb (symbol-value constsymb))
              (put backupsymb 'variable-documentation symbdoc)
              (cl-pushnew (cons backupsymb constsymb)
                          daselt-bind--backed-up-variables
                          :test #'equal))
            (set constsymb constval)
            (if (stringp symbdoc)
                (put constsymb 'variable-documentation
                     (concat symbdoc
                             (format "\n\nThis symbol's value was changed by %s. in %s"
                                     configname filename))))))
        constlist))

(defun daselt-configuration-apply-constantlist-entry (package entry)
  "Set the constants of ENTRY of PACKAGE, deferred like a bindlist.
`special' entries are skipped, as in the old machinery.  The value
expressions may use `buffer-file-name' (like the old file-based
processing did), so it is bound to the entry's file."
  (unless (eq (oref entry kind) 'special)
    (let* ((form (oref entry form))
           (file (daselt-configuration--entry-file entry package))
           (head (unless (consp (car form)) (car form))))
      (daselt-configuration--defer
       entry package
       (lambda ()
         (let ((buffer-file-name file))
           (daselt-configuration--set-constants form "daselt-" "daselt" file)))
       head))))

(defun daselt-configuration--add-advice (adlist)
  "Add the advice entries of ADLIST.
See `daselt-configuration-apply-advicelist-entry' for the format."
  (mapcar (lambda (adv)
            (let ((symbs (car adv))
                  (how (cadr adv))
                  (funs (caddr adv))
                  (props (cadddr adv)))
              (mapcar (lambda (symb)
                        (mapcar (lambda (fun)
                                  (apply #'advice-add
                                         (remq nil (list symb how fun props))))
                                funs))
                      symbs)))
          adlist))

(defun daselt-configuration-apply-advicelist-entry (package entry)
  "Add the advice of ENTRY of PACKAGE, deferred like a bindlist.
`special' entries are skipped.  The advicelist should consist of
an optional eval condition (a head that is not a cons) and
entries (SYMBOLS HOW FUNCTIONS PROPS) as in `advice-add'."
  (unless (eq (oref entry kind) 'special)
    (let* ((adlist (oref entry form))
           (head (unless (consp (car adlist)) (car adlist)))
           (radlist (if head (cdr adlist) adlist)))
      (daselt-configuration--defer
       entry package
       (lambda () (daselt-configuration--add-advice radlist))
       head))))

(defun daselt-configuration-apply-adviceform-entry (package entry)
  "Evaluate ENTRY's adviceform of PACKAGE and add the resulting advicelist."
  (unless (eq (oref entry kind) 'special)
    (let* ((adlist (eval (oref entry form)))
           (head (unless (consp (car adlist)) (car adlist)))
           (radlist (if head (cdr adlist) adlist)))
      (daselt-configuration--defer
       entry package
       (lambda () (daselt-configuration--add-advice radlist))
       head))))

(defun daselt-configuration--add-hooks (pairs)
  "Add each (FUNCTION . HOOK) pair of PAIRS and record it for removal."
  (dolist (pair pairs)
    (let ((func (car pair))
          (hook (cdr pair)))
      (add-hook hook func)
      (push (cons func hook) daselt-configuration--hook-removals))))

(defun daselt-configuration-apply-hooklist-entry (package entry)
  "Add the hooks of ENTRY of PACKAGE, deferred like a bindlist.
The hooklist should consist of an optional eval condition and
\(FUNCTION . HOOK) pairs.  `special' entries are skipped."
  (unless (eq (oref entry kind) 'special)
    (let* ((form (oref entry form))
           (head (if (atom (car form)) (car form)))
           (pairs (if head (cdr form) form)))
      (daselt-configuration--defer
       entry package
       (lambda () (daselt-configuration--add-hooks pairs))
       head))))

(defun daselt-configuration--apply-entry-safe (package entry fun)
  "Apply FUN for ENTRY of PACKAGE, warning instead of failing.
Like the old machinery, which wrapped per-file application so one
bad entry cannot abort the whole startup."
  (condition-case err
      (funcall fun)
    (error (warn "Daselt: skipping an entry of `%s'%s: %s"
                 (oref package name)
                 (if (oref entry source-file)
                     (format " (%s)" (oref entry source-file))
                   "")
                 (error-message-string err)))))

(defun daselt-configuration-apply-package (package)
  "Apply the whole configuration of PACKAGE."
  (when (oref package enabled)
    (dolist (entry (oref package bindlists))
      (daselt-configuration--apply-entry-safe
       package entry
       (lambda ()
         (daselt-configuration-apply-bindlist-entry
          package entry (not (eq (oref entry kind) 'special))))))
    (dolist (entry (oref package bindforms))
      (daselt-configuration--apply-entry-safe
       package entry
       (lambda ()
         (daselt-configuration-save-bindform-entry package entry))))
    (dolist (entry (oref package constantlists))
      (daselt-configuration--apply-entry-safe
       package entry
       (lambda ()
         (daselt-configuration-apply-constantlist-entry package entry))))
    (dolist (entry (oref package advicelists))
      (daselt-configuration--apply-entry-safe
       package entry
       (lambda ()
         (daselt-configuration-apply-advicelist-entry package entry))))
    (dolist (entry (oref package adviceforms))
      (daselt-configuration--apply-entry-safe
       package entry
       (lambda ()
         (daselt-configuration-apply-adviceform-entry package entry))))
    (dolist (entry (oref package hooklists))
      (daselt-configuration--apply-entry-safe
       package entry
       (lambda ()
         (daselt-configuration-apply-hooklist-entry package entry))))))

(defun daselt-configuration--bind-package-variables (config)
  "Bind the old `daselt-<pkg>' variables from the `enabled' slots.
Bindlist values and embedded code may be conditional on these
variables (they were the generated customization options of the
old directory machinery), so they must all be bound before any
code is evaluated or entry is applied."
  (dolist (package (oref config packages))
    (set (intern (format "daselt-%s" (oref package name)))
         (oref package enabled))))

(defun daselt-configuration-apply (config)
  "Apply CONFIG: layout data, compiled code and all package entries."
  (daselt-configuration--restore-layout-data config)
  (daselt-configuration--bind-package-variables config)
  (let ((count (daselt-configuration-eval-code config)))
    (when daselt-configuration-verbose
      (message "Daselt: made %d compiled code files effective" count)))
  (dolist (package (oref config packages))
    (daselt-configuration-apply-package package)))

(defun daselt-configuration-remove-hooks ()
  "Remove the hooks added by `daselt-configuration-apply'."
  (mapc (lambda (hook-cns)
          (remove-hook (cdr hook-cns) (car hook-cns)))
        daselt-configuration--hook-removals)
  (setq daselt-configuration--hook-removals nil))

(defun daselt-configuration-reset-variables ()
  "Restore each variable for which applying the configuration recorded a backup."
  (dolist (backup-pair daselt-bind--backed-up-variables)
    (let ((backupsymb (car backup-pair))
          (origsymb (cdr backup-pair)))
      (when (boundp backupsymb)
        (set origsymb (symbol-value backupsymb))
        (makunbound backupsymb))))
  (setq daselt-bind--backed-up-variables nil)
  nil)

;;;; Interactive edit buffers (via ei-edit-buffer)

(defun daselt-configuration--bindlist-body (form)
  "Return (HEAD . BODY) of the bindlist FORM.
HEAD is nil for headless bindlists.  Multi-map forms
\(EVAL (MAP1 ...) (MAP2 ...)) return a head of t and no body;
they are not editable in the edit buffer."
  (let ((head (daselt-bind-head form)))
    (cond ((and head (daselt-bind-head (cadr form))) ; multi-map
           (cons t nil))
          (head (cons head (cdr form)))
          (t (cons nil form)))))

(defun daselt-configuration--parse-bindlist-fields (fields)
  "Turn FIELDS of an edit buffer back into a list of bindings.
Each field is a (KEY-STRING . VALUE-STRING) cons; both parts are
read as Lisp objects.  Signal an error naming the first bad line."
  (mapcar (lambda (field)
            (let ((key (car field))
                  (val (or (cdr field) "nil")))
              (cons (condition-case nil
                        (read key)
                      (error (error "Bad key in line `%s'" key)))
                    (condition-case nil
                        (read (ei-unescape-string val))
                      (error (error "Bad value in line `%s'" key))))))
          fields))

(defun daselt-configuration-edit-bindlist (entry)
  "Edit the bindlist of ENTRY in an interactive edit buffer.
Each binding is one line `KEY<TAB>VALUE' with KEY and VALUE as
printable Lisp objects.  C-c C-c stores the edited bindings as
ENTRY's form; C-c C-k or C-g leaves everything unchanged.  The
edited bindlist is not applied to the keymaps; apply it with
`daselt-configuration-apply-package' or the action menu."
  (interactive)
  (pcase-let ((`(,head . ,body)
               (daselt-configuration--bindlist-body (oref entry form))))
    (if (eq head t)
        (message "Multi-map bindlists cannot be edited in the buffer yet")
      (condition-case nil
          (progn
            (ei-edit-buffer
             (format "*daselt-bindlist-%s*"
                     (or (and head (symbol-name head)) "bindlist"))
             "Bindlist edit"
             '("Edit one binding per line as KEY<TAB>VALUE (Lisp objects)."
               "C-c C-c stores the result; C-c C-k cancels.")
             :populate
             (lambda ()
               (dolist (bind body)
                 (ei-edit-buffer-put-field
                  (prin1-to-string (car bind))
                  (ei-escape-string (prin1-to-string (cdr bind))))))
             :finish-help "C-c C-c stores the bindlist")
            (let ((new-body
                   (daselt-configuration--parse-bindlist-fields
                    (ei-edit-buffer-fields "\t"))))
              (setf (slot-value entry 'form)
                    (if head (cons head new-body) new-body))
              (message "Bindlist of `%s' updated in the configuration"
                       (or head "the entry"))))
        (quit nil)))))

(defun daselt-configuration-edit-constantlist (entry)
  "Edit the constantlist of ENTRY in an interactive edit buffer.
Each constant is one line `VARIABLE<TAB>VALUE-EXPRESSION'.  C-c C-c
stores the edited constantlist as ENTRY's form; C-c C-k or C-g
leaves everything unchanged."
  (interactive)
  (let* ((form (oref entry form))
         (head (unless (consp (car form)) (car form)))
         (body (if head (cdr form) form)))
    (condition-case nil
        (progn
          (ei-edit-buffer
           (format "*daselt-constants-%s*" (or head "constants"))
           "Constantlist edit"
           '("Edit one constant per line as VARIABLE<TAB>VALUE (a Lisp expression)."
             "C-c C-c stores the result; C-c C-k cancels.")
           :populate
           (lambda ()
             (dolist (const body)
               (ei-edit-buffer-put-field
                (prin1-to-string (car const))
                (ei-escape-string (prin1-to-string (cdr const))))))
           :finish-help "C-c C-c stores the constantlist")
          (let ((new-body
                 (mapcar (lambda (field)
                           (cons (read (car field))
                                 (read (ei-unescape-string
                                        (or (cdr field) "nil")))))
                         (ei-edit-buffer-fields "\t"))))
            (setf (slot-value entry 'form)
                  (if head (cons head new-body) new-body))
            (message "Constantlist of `%s' updated in the configuration"
                     (or head "the entry"))))
      (quit nil))))

;;;; ei-interface integration

(cl-defmethod ei-candidate-annotation ((entry daselt-config-entry)
                                       _candidate)
  "Annotate entries with their kind."
  (ei-choose--annotation-face
   (format "  [%s]" (oref entry kind))))

(cl-defmethod ei-extra-actions ((entry daselt-config-entry) _path)
  "Offer the edit buffers for bindlist and constantlist entries."
  (let ((actions nil)
        (config (condition-case nil (daselt-configuration-load) (error nil))))
    (when (and config
               (cl-some (lambda (pkg)
                          (and (memq entry
                                     (append (oref pkg bindlists)
                                             (oref pkg constantlists)))
                               t))
                        (oref config packages)))
      (cond ((memq entry
                   (cl-loop for pkg in (oref config packages)
                            append (oref pkg bindlists)))
             (push (list ?b "Edit in edit buffer"
                         (lambda (_entry) (daselt-configuration-edit-bindlist entry)))
                   actions))
            (t
             (push (list ?b "Edit in edit buffer"
                         (lambda (_entry) (daselt-configuration-edit-constantlist entry)))
                   actions)))
      (push (list ?s "Save the configuration"
                  (lambda (_entry) (daselt-configuration-save config)))
            actions))
    actions))

(cl-defmethod ei-actions ((config daselt-configuration))
  "Whole-configuration actions: apply, save, export and re-import code."
  (append
   (list (list ?p "Apply the configuration"
               (lambda (c) (daselt-configuration-apply c)))
         (list ?s "Save the configuration"
               (lambda (c) (daselt-configuration-save c)))
         (list ?e "Export entries to their files"
               (lambda (c) (daselt-configuration-export c)))
         (list ?f "Import entries from a file"
               (lambda (c) (daselt-configuration-import-file
                            (daselt-configuration--read-import-file) c t)))
         (list ?i "Re-import the compiled code"
               (lambda (c) (daselt-configuration-import-compiled-code c))))
   (cl-call-next-method config)))

;;;; Finding configuration files

(defun daselt-configuration-find-entry-file ()
  "Open a configuration entry's source file for editing.
Complete over the source files recorded in the configuration
object.  This replaces `daselt-dirs-find-bindlists-file' and
`daselt-dirs-find-pkg-file-by-type' of the old machinery."
  (interactive)
  (let ((files nil))
    (let ((config (condition-case nil (daselt-configuration-load)
                    (error nil))))
      (when config
        (dolist (pkg (oref config packages))
          (dolist (entry (append (oref pkg bindlists) (oref pkg bindforms)
                                 (oref pkg constantlists)
                                 (oref pkg advicelists)
                                 (oref pkg adviceforms)
                                 (oref pkg hooklists)))
            (when (oref entry source-file)
              (cl-pushnew (oref entry source-file) files :test #'equal))))))
    (if files
        (find-file (expand-file-name
                    (completing-read "Configuration file: " files nil t)
                    daselt-emacs-dir))
      (message "No entry files recorded; run daselt-configuration-import first"))))

;;;; Editing entry files

(defconst daselt-configuration-entry-extensions
  '("dbl" "dbf" "dcl" "dal" "daf" "dhl" "deio" "dclo")
  "File extensions of Daselt configuration entry files.
The entry-file part of `daselt-configuration--import-extensions':
the `.el'/`.del' lisp files are code, not entries, and stay in
`emacs-lisp-mode'.")

(defun daselt-configuration-entry-import ()
  "Import the entry file visited in the current buffer and apply it.
Save the buffer first when modified, then hand the file to
`daselt-configuration-import-file' with APPLY, so the edits become
effective at once.  This is the file-based path back into the
collection after editing a file found with
`daselt-configuration-find-entry-file'."
  (interactive)
  (let ((file (buffer-file-name)))
    (unless (and file
                 (member (file-name-extension file)
                         daselt-configuration-entry-extensions))
      (user-error "Not a Daselt configuration entry file"))
    (when (buffer-modified-p)
      (save-buffer))
    (daselt-configuration-import-file file nil t)))

(defvar-keymap daselt-configuration-entry-mode-map
  :parent emacs-lisp-mode-map
  "C-c C-i" #'daselt-configuration-entry-import)

(define-derived-mode daselt-configuration-entry-mode emacs-lisp-mode
  "Daselt-Entry"
  ;; This replaces the per-type modes of the old `daselt-dirs'
  ;; machinery (`daselt-dirs-create-save-customized-modes'), which
  ;; were generated for each file type separately.
  "Major mode for editing Daselt configuration entry files.
Files with one of the `daselt-configuration-entry-extensions'
visit in this mode: `.dbl' bindlists, `.dbf' bindforms, `.dcl'
constantlists, `.dal' advicelists, `.daf' adviceforms, `.dhl'
hooklists and `.deio'/`.dclo' persistent objects.

The mode is derived from `emacs-lisp-mode': entry files hold
plain s-expressions, so the syntax, font-lock, indentation and
sexp motion of Emacs Lisp apply unchanged, and the `;;;;'
section headers of exported files work with the outline
navigation inherited from it.

Re-import the visited file into the configuration (and apply its
package) with \\[daselt-configuration-entry-import].

\\{daselt-configuration-entry-mode-map}")

(dolist (ext daselt-configuration-entry-extensions)
  (let ((regexp (concat "\\." ext "\\'")))
    ;; Like the old machinery: never override a mode another
    ;; package installed for EXT.
    (unless (cl-member regexp auto-mode-alist
                       :key #'car :test #'string=)
      (add-to-list 'auto-mode-alist
                   (cons regexp 'daselt-configuration-entry-mode)))))

;;;; Navigation with the ei interface

(defun daselt-configuration-navigate (config)
  "Navigate CONFIG with the `ei-interface' choice interface.
When called interactively, load the configuration object,
importing it with `daselt-configuration-import' when there is
none yet."
  (interactive
   (list (condition-case nil
            (daselt-configuration-load)
          (error (daselt-configuration-import)))))
  (let ((config (or config
                    (condition-case nil
                        (daselt-configuration-load)
                      (error (daselt-configuration-import)))))
        (ei-current-choice-history nil)
        ;; Read with the default reader of `ei-interface': a reader
        ;; installed globally by another package, such as the
        ;; collection history of abv, is not about this object.
        (ei-completing-read-function nil))
    (ei-choose config)))

(defun daselt-configuration-current ()
  "Return the current configuration, loading it when necessary."
  (daselt-configuration-load))

(provide 'daselt-configuration)

;;; daselt-configuration.el ends here
