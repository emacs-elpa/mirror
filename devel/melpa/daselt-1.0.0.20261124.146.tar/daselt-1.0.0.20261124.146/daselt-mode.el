;;; daselt-mode.el --- Provides daselt-mode -*- lexical-binding: t; -*-

;; Copyright (C) 2024, 2025, 2026  Alexander Prähauser

;; Author: Alexander Prähauser <ahprae@protonmail.com>
;; Keywords: tools
;; URL: https://codeberg.org/nameiwillforget/d-emacs

;; This file is part of Daselt.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Define `daselt-mode', the implementation of the Daselt shortcut-layout in
;; Emacs and provide commands needed to start it. Commands bound to keys are in
;; `mode-configs/daselt-mode/daselt-ext.el'.

;; When `daselt-mode' starts, it loads the persistent
;; `daselt-configuration' object (see `daselt-configuration.el'),
;; which holds the per-package configuration entries, the layout
;; data and the compiled code of the `.el' files under
;; `mode-configs/'.  This is as quick as reading one file.  When
;; the compiled code was imported on a different computer --- or
;; the `.el' sources changed --- the mode re-imports it
;; automatically before applying the configuration.  On the first
;; start, or when the configuration file is missing, the full
;; generation runs and the object is built from the `mode-configs'
;; directory.

;;; Code:
;;;; Preamble
(declare-function daselt-minor-mode-key-binding "daselt-mode-ext" (key))

(require 'daselt-base)
(require 'daselt-coords)
(require 'daselt-xkb)
(require 'daselt-dfk)
(require 'daselt-bind)
(require 'daselt-configuration)
(require 'cl-lib)
(require 'org-table)

(defvar daselt-replace-untranslated-keys)
(defvar daselt-global-map-backup)
(defvar undo-tree-auto-save-history)

;; If daselt-stump isn't loaded, this variable will not be bound…
(defvar daselt-stump)

;; These are generated when starting the mode.
(defvar daselt-xkb-layouts)
(defvar daselt-dfk-layout)

(defvar daselt-mode-eval-log nil
  "Deprecated alias kept for compatibility.

Teardown of deferred eval forms is now handled by
`daselt-bind--remove-from-after-load-alist' via
`daselt-bind--deferred-registry' and no longer uses a log.")
(defvar daselt-emacs-dir)
;;;; Initialization
;; ;;;;; Let's read in the dxkb-file
;; (daselt-xkb-generate-layouts)

;;;; Customs
(defgroup daselt-mode
  nil
  "This group houses all customization options for daselt."
  :group 'daselt
  :prefix "daselt-mode-")

(defcustom daselt-mode-put-daselt-mode-map-into-emulation
  t
  "If non-nil, add `daselt-mode-map' to `emulation-mode-map-alists'.

Maps in this list supersede most other keymaps."
  :type 'boolean
  :group 'daselt-mode)

(defcustom daselt-mode-globalize-daselt-mode-map
  nil
  "Set `global-mode-map' to `daselt-mode-map' while `daselt-mode' is active.

Not needed if `daselt-mode-put-daselt-mode-map-into-emulation' is non-nil."
  :type 'boolean
  :group 'daselt-mode)

(defcustom daselt-mode-quick-key-coords-base-list
  '((0 2) (0 3) (-1 3) (0 4) (-1 4) (0 1) (-1 2) (0 5) (1 1) (1 2) (1 3) (-1 5) (1 4) (-1 1) (1 0))
  "Coordinates of the right-hand keys for quick-key selections.

This list is used in `d-special-quick-keys-bindlists' for generating bindlists
used in quick-key selections. The left-hand keys and coordinates from
`daselt-mode-quick-key-layers-list' are added in a way that ensures balanced
distribution."
  :type '(repeat coords)
  :group 'daselt-mode)

(defcustom daselt-mode-quick-key-layers-list
  (daselt-base-cardinal 8 t)
  "List of key layers for generating quick-key selection bindlists.

Used by `d-special-quick-keys-bindlists` to create constants for quick-key
selection mechanisms."
  :type 'boolean
  :group 'daselt-mode)

(defcustom daselt-mode-keep-read-buffers
  nil
  "If t, keep the buffers of configuration files that are read.
Speeds up reading many files at the cost of buffer clutter.
This replaces `daselt-dirs-keep-read-buffers' of the old
directory machinery, which some configuration files still
reference."
  :type 'boolean
  :group 'daselt-mode)

(defcustom daselt-mode-stump-configs-directory
  nil
  "Directory holding the StumpWM bindlists used outside Emacs.

This is the `stump-configs' directory of the d-stump project,
which also used to live in this repository.  When nil, it is
looked for next to `daselt-emacs-dir' and in the d-stump project
of the Daselt umbrella repository; its `stumpwm' subdirectory
must contain `remapped-keys-special.dbl'."
  :type '(choice directory (const :tag "Find automatically" nil))
  :group 'daselt-mode)

(defcustom daselt-mode-show-tutorial
  t
  "Show the Daselt tutorial when `daselt-mode' is started.

If non-nil, the tutorial will be displayed upon entering the mode."
  :type 'boolean
  :group 'daselt-mode)


;; This is a custom mostly to have it saved between sessions.
(defcustom daselt-mode-pkg-configs-directory
  nil
  "The pkg-configs-directory of `daselt-mode'.

This should be the directory named `mode-configs' in the root directory
of Daselt."
  :type 'directory
  :group 'daselt-mode)

(defcustom daselt-mode-keep-tab-bar-status
  nil
  "If t, keep the tab bar disabled when commands like `tab-new' are used.

Uses advice."
  :type 'boolean
  :group 'daselt-mode)

(defcustom daselt-mode-include-imitation-commands
  (not (bound-and-true-p daselt-stump))
  "Include the imitation commands on keys C-(1 0 [-2-2]) in `daselt-mode-map'.

Unnecessary if you are using a program like StumpWM to translate these key
combinations."
  :type 'boolean
  :group 'daselt-mode)

(defcustom daselt-mode-redaselt
  t
  "Have the `redaselt' shell script run when `daselt-mode' starts.

The argument to the script is the part of the value of `daselt-xkb-layout'
between the prefix and the suffix.

If you are using some other means of setting Daselt's layout, then you can turn
this off."
  :type 'boolean
  :group 'daselt-mode)

(defcustom daselt-mode-undaselt
  nil
  "Have the `undaselt' shell script run with these arguments when
`daselt-mode' ends.

You can use this to specify the layout you're using outside of Daselt, if any.

Note that the default of the `undaselt' script is `en us'."
  :type '(choice string boolean)
  :group 'daselt-mode)

(defcustom daselt-mode-redaselt-time
  1
  "The time the `redaselt'-script should wait between (re)starting udevmon and
setting the xkb-layout.

You only need to set this by hand if the current amount of time is too little
for your computer to properly start up udevmon. In that case, the layout will
not be set."
  :type 'number
  :group 'daselt-mode)

(defcustom daselt-mode-global-udevmon
  nil
  "If set to t, run `redaselt' with a --global flag.

This makes systemctl search for a global udevmon-service.

Requires sudo and slows down the starting process a bit.

Doesn't have any effect if neither of the options `daselt-mode-redaselt' or
`daselt-mode-undaselt' are set."
  :type 'boolean
  :group 'daselt-mode)

(defcustom daselt-mode-exchange-H-2-H-6
  nil
  "Set to t to exchange H-2 with H-6 bindings.

On some systems this might be necessary because H in combination with other
modifiers acts as a level 5 shift for currently unknown reasons."
  :type 'boolean
  :group 'daselt-mode)

(defcustom daselt-insert-latex-normpairs
  t
  "If non-nil, insert a norm-pair yasnippet for specific inputs.

Inserts a norm-pair yasnippet when typing (8 0 -5) and (8 0 5).
Refer to `daselt-latex-insert-normpair-yas-snippet' for details."
  :type 'boolean
  :group 'daselt-mode)


;;;; Maps
(defvar-keymap daselt-mode-miscellaneous-map)
(defvar-keymap daselt-mode-theme-map)

(defvar-keymap daselt-mode-map)

;;;; Rebinder functions, taken from Abdulla Bubshait's rebinder package: https://github.com/darkstego/rebinder.el
(defun daselt-mode-dynamic-binding (key &optional toggle)
  "Create a dynamic binding for KEY in the current context.

This function generates a menu item that computes the actual binding
dynamically. If TOGGLE is non-nil, it allows switching from Ctrl mappings to
standard key mappings."
  `(menu-item
    ,""
    nil
    :filter
    (lambda (&optional _)
      ,`(daselt-mode-key-binding ,key ,toggle))))

;; might need to do keymap inheretence to perserve priority
(defun daselt-mode-key-binding (key &optional toggle)
  "Retrieve the keymap associated with KEY.

If TOGGLE is non-nil, the Ctrl status of all bindings in the resulting keymap
will be inverted."
  (let ((map (make-composed-keymap (list (daselt-minor-mode-key-binding key) (local-key-binding (kbd key)) (global-key-binding (kbd key))))))
    (if toggle
	(mapcar #'daselt-mode-toggle-ctrl map)
      map)))

(defun daselt-mode-toggle-ctrl (item)
  "Toggle the Ctrl status of ITEM key binding.

If ITEM is a list, recursively toggle the Ctrl status of its elements. If ITEM
is a key event, the modifiers are toggled appropriately."
  (cond
   ((and (listp item)
	 (not (listp (cdr item))))
     (cons (daselt-mode-toggle-ctrl (car item)) (cdr item)))
    ((listp item)
     (mapcar #'daselt-mode-toggle-ctrl item))
    ((event-basic-type item)
     (let ((mods (event-modifiers item))
	   (key (event-basic-type item)))
       (if (member 'control mods)
	   (event-convert-list (append (remove 'control mods) (list key)))
	 (event-convert-list (append (append mods '(control)) (list key))))))
    (t item)))

(defun daselt-mode-rebind (keylist)
  "Rebind keys according to KEYLIST, where each entry is a cons cell.

The car of each cons cell is a prefix key combination and the cdr is the new key
combination that acts as the prefix key."
  (mapcar (lambda (i) (define-key global-map (kbd (car i)) (daselt-mode-dynamic-binding (nth 1 i))))
          keylist))


;;;; Functions
(defun daselt-mode--generate-replace-strings ()
  "Update `daselt-bind-replace-binding-strings-alist' based on current bindings.

Uses `daselt-bind-translate-C-1-1--2-C-g', `daselt-bind-translate-keys', and
`daselt-replace-untranslated-keys' to determine the relevant bindings."
  (declare (ftype (function () list))
           (side-effect-free t))
  (remq nil (append (unless (or (and (boundp daselt-stump) daselt-stump)
                                daselt-bind-translate-C-1-1--2-C-g)
                      `(("C-g" . ,(daselt-bind-string `(("C-" . (1 1 -2)))))))

                    (unless (or daselt-bind-translate-keys
                                (not daselt-replace-untranslated-keys))
                      (mapcar (lambda (cns)
                                (let ((str (car cns)))
                                  (cons str (string-replace "C-" "A-" str))))
                              daselt-bind-key-translations-alist)))))

(defun daselt-mode--generate-quick-key-variables ()
  "Generate quick key variables used in Daselt configurations.

Utilizes `d-special-quick-keys-bindlist` as a foundation for generation."
  (declare (ftype (function () string)))
  (let* ((filepath
          (concat daselt-mode-pkg-configs-directory "quick-keys.dbf"))

         (keylist (cl-remove-duplicates
                   (flatten-list
                    (mapcar (lambda (form)
                              (let ((blist (eval form)))
                                (remq nil (mapcar (lambda (bind)
                                                    (let ((sig (daselt-bind-string bind)))
                                                      (if (= 1 (length sig))
                                                          (string-to-char
                                                           sig))))
                                                    (cdr blist)))))
                            (daselt-configuration--read-forms-from-file
                             filepath)))))

         runlist
         (permutedlist (cl-loop for n from 0 to (- (length keylist) 2)
                                do (setq runlist
                                         (append runlist
                                                 (list (if (cl-evenp n)
                                                           (nth (1+ n) keylist)
                                                         (nth (1- n) keylist)))))
                                finally return runlist))

         (keystring (mapconcat #'char-to-string keylist))

         (keystringpair (cons keystring
                              (mapconcat #'char-to-string permutedlist))))

    (defvar daselt-mode-quick-key-list keylist
      "Quick key list for Daselt.
Auto-generated using `daselt-mode--generate-quick-key-variables.'")

    (defvar daselt-mode-quick-key-string keystring
      "Quick key string for Daselt.
Auto-generated using `daselt-mode--generate-quick-key-variables.'")

    (defvar daselt-mode-quick-key-string-cons keystringpair
      "Quick key string pair for Daselt.
Auto-generated using `daselt-mode--generate-quick-key-variables.'")))

(defun daselt-mode-generate-tutorial (&optional no-refresh)
  "Generate the Daselt-tutorial.

NO-REFRESH is or optimization-purposes: `daselt-mode' already refreshes
`daselt-dfk', so it's unnecessary to do it again."
  (declare (ftype (function (&optional boolean)
                            ;; void  ; Compiler complains.
                            t)))
  (interactive)
  (unless no-refresh
    (daselt-dfk-import-current-layout))
  (let ((display-buffer-alist-backup display-buffer-alist))
    (condition-case report
        (let ((tutfile (concat daselt-mode-pkg-configs-directory "daselt-mode/daselt-mode.tut"))
              (display-buffer-alist '((".*" display-buffer-full-frame))))
          (find-file tutfile)
          (daselt-base-goto-min)
          (mark-sexp)
          (let ((tuttext (eval (daselt-base-read-region))))
            (deactivate-mark)
            (pop-to-buffer "*daselt-tutorial*")
            (delete-minibuffer-contents)
            (org-mode)
            (visual-line-mode)
            (insert tuttext)
            (daselt-base-goto-min)
            nil)
          (kill-buffer (get-file-buffer tutfile)))
      (error (progn (setq display-buffer-alist display-buffer-alist-backup)
                    (error (error-message-string report)))))))

(defun daselt-mode-redaselt ()
  "Run the `redaselt'-bash-script to switch your keyboard layout.

The keyboard-layout loaded is the d-xkb-variant specified in
the option `daselt-mode-redaselt'."
  (interactive)
  ;; Arguments are passed as a list to a direct process call rather
  ;; than through a shell, so metacharacters in layout or option
  ;; names cannot be interpreted as shell syntax.
  (let ((args (remq nil
                    (list
                     (when daselt-mode-global-udevmon "--global")
                     (daselt-base-namecore daselt-xkb-layout "daselt-xkb-" "-layout")
                     (number-to-string daselt-mode-redaselt-time)))))
    (let ((display-buffer-alist
           '(("\\*Async Daselt Buffer\\*"
              (display-buffer-no-window)))))
      (if daselt-mode-global-udevmon
          (apply #'call-process "redaselt" nil "*Async Daselt Buffer*" nil args)
        (apply #'start-process "redaselt" "*Async Daselt Buffer*" "redaselt" args)))))

(defun daselt-mode-undaselt ()
  "Run the `undaselt'-bash-script to switch your keyboard layout.

The keyboard-layout loaded is the d-xkb-variant specified by
`daselt-xkb-layout'."
  (interactive)
  ;; See `daselt-mode-redaselt' on why this uses a direct process call.
  (let ((args (remq nil
                    (list
                     (when daselt-mode-global-udevmon "--global")
                     (when (stringp daselt-mode-undaselt)
                       daselt-mode-undaselt)))))
    (let ((display-buffer-alist
           '(("\\*Async Daselt Buffer\\*"
              (display-buffer-no-window)))))
      (if daselt-mode-global-udevmon
          (apply #'call-process "undaselt" nil "*Async Daselt Buffer*" nil args)
        (apply #'start-process "undaselt" "*Async Daselt Buffer*" "undaselt" args)))))

;;;; The pkg-configs-issue
(defun daselt-mode--pkg-configs-directory-test (dir)
  "Test whether DIR looks like daselt-mode's pkg-configs-directory."
  (declare (ftype (function (string) boolean))
           (pure t))
  (and dir
       (file-exists-p dir)
       (file-exists-p (concat dir "daselt-mode/"))))

(defun daselt-mode--pkg-configs-directory-enter-manually ()
  "Specify manually where the pkg-configs-directory is."
  (declare (ftype (function () string)))
  (let* ((use-file-dialog nil) ; Dialog box doesn't let you select folder (or I was doing something wrong).
         (filename (read-file-name "Please point daselt-mode to its pkg-configs directory (in the root directory of Daselt, include trailing backslash): "
                                   nil nil
                                   #'daselt-mode--pkg-configs-directory-test)))
    (customize-set-variable 'daselt-mode-pkg-configs-directory
                            filename)
    filename))

(defun daselt-mode--find-pkg-configs-directory ()
  "Find daselt-mode's pkg-configs-directory.

Set the corresponding option so it's saved for future sessions.

If the option already points to something that looks like the right directory,
don't do anything."
  (declare (ftype (function () string)))
  (unless (daselt-mode--pkg-configs-directory-test daselt-mode-pkg-configs-directory)
    (condition-case nil (let ((current-pkg-dir
                               (concat daselt-emacs-dir "mode-configs/")))
                          (if (daselt-mode--pkg-configs-directory-test current-pkg-dir)
                              (customize-set-variable 'daselt-mode-pkg-configs-directory
                                                      current-pkg-dir)
                            (daselt-mode--pkg-configs-directory-enter-manually)))
      (error (daselt-mode--pkg-configs-directory-enter-manually)))))

;;;; Startup pieces

(defun daselt-mode--apply-key-translations ()
  "Add the C-g translations and apply `daselt-bind-key-translations-alist'.
`key-translate' modifies Emacs global state, so translations are
applied on every start, also from the configuration object."
  (when daselt-bind-translate-keys
    (if daselt-bind-translate-C-1-1--2-C-g
        (let ((transcons
               `(,(daselt-bind-string `(("C-" . (1 1 -2)))) . "C-g"))
              (revtranscons
               `("C-g" . ,(daselt-bind-string `(("C-" . (1 1 -2)))))))
          (add-to-list 'daselt-bind-key-translations-alist transcons)
          (add-to-list 'daselt-bind-key-translations-alist revtranscons)))
    (mapc
     (lambda (cns)
       (condition-case err
           (key-translate (car cns) (cdr cns))
         (error (warn "Daselt: could not apply key translation %s: %s"
                      (car cns) (error-message-string err)))))
     daselt-bind-key-translations-alist)))

(defun daselt-mode--compute-boundaries ()
  "Compute `daselt-bind-boundaries' from the coordinatized layouts."
  (setq daselt-bind-boundaries
        (list (daselt-coords-boundaries
               (mapcar (lambda (placeval) (car placeval))
                       (daselt-base-flatten-until
                        (daselt-coords-get-layer
                         (daselt-coords-coordinatize-layout
                          (symbol-value daselt-dfk-layout))
                         0)
                        (lambda (lst) (daselt-coords-p (caar lst))))))

              (daselt-coords-boundaries
               (mapcar (lambda (placeval) (car placeval))
                       (daselt-base-flatten-until
                        (daselt-coords-get-layer
                         (daselt-coords-coordinatize-layout
                          (symbol-value daselt-xkb-layout))
                         1)
                        (lambda (lst) (daselt-coords-p (caar lst)))))))))

(defun daselt-mode--full-generation ()
  "Run the full first-start generation of Daselt's layout data."
  ;; Find out if it's an ansi keyboard
  (unless (or (not daselt-mode-show-tutorial)
              (not (eq (custom-variable-state 'daselt-dfk-keyboard-layout-type t)
                       'standard)))
    (customize-save-variable 'daselt-dfk-keyboard-layout-type
                             (daselt-base-remove-text-properties-from-string
                              (completing-read "Do you have an ansi or iso-keyboard (you have ansi if your left Shift-key is larger than CapsLock)? " daselt-dfk-supported-layout-types nil t))))

  (daselt-xkb-generate-layouts)

  ;; Refresh the daselt-xkb-layouts in case someone has changed bindings.
  (daselt-xkb-set-layouts-list)
  (put 'daselt-xkb-layout 'custom-options daselt-xkb-layouts)

  ;; Add the key translations for C-g and ("C-" . (1 1 -2)) if they aren't there yet.
  (daselt-mode--apply-key-translations)

  ;; Choose the layout
  (if (or (not (boundp 'daselt-xkb-layout))
          (and daselt-mode-show-tutorial
               (eq (custom-variable-state 'daselt-xkb-layout t)
                   'standard)))
      (customize-save-variable 'daselt-xkb-layout
                               (daselt-base-intern-from-parts
                                "daselt-xkb"
                                (completing-read
                                 "Please pick the Daselt layout you want to use: "
                                 (mapcar (lambda (sym)
                                           (daselt-base-namecore sym
                                                                 "daselt-xkb-"
                                                                 "-layout"))
                                         daselt-xkb-layouts))
                                "layout")))

  ;; For a non-main layout put modifiers outside the layout unless they have been put in by hand.
  (when (eq (custom-variable-state 'daselt-dfk-outside-mods t)
            'standard)
    (if (eq (symbol-value 'daselt-xkb-layout)
            'daselt-xkb-main-layout)
        (setopt daselt-dfk-outside-mods nil)
      (setopt daselt-dfk-outside-mods t)))

  ;; Generate daselt-dfk-layout from the daselt-xkb-layout.
  (daselt-dfk-import-current-layout)

  ;; Calculate layer boundaries.
  (daselt-mode--compute-boundaries)

  ;; redaselt
  (if daselt-mode-redaselt
      (if (file-exists-p "/usr/share/X11/xkb/symbols/dxkb")
          (daselt-mode-redaselt)
        (error "Please put the dxkb-file into `/usr/share/X11/xkb/symbols/' or deactivate daselt-mode-redaselt"))))

;;;; StumpWM outside translations

(defun daselt-mode--stump-configs-directory ()
  "Return the directory of the StumpWM bindlists, or nil.
`daselt-mode-stump-configs-directory' when set; otherwise the old
location in this repository and the d-stump project are tried."
  (or daselt-mode-stump-configs-directory
      (cl-some
       (lambda (dir)
         (and dir
              (file-exists-p
               (expand-file-name "stumpwm/remapped-keys-special.dbl" dir))
              dir))
       (list (and (boundp 'daselt-emacs-dir)
                  (expand-file-name "stump-configs" daselt-emacs-dir))
             (expand-file-name
              "stump-configs"
              (expand-file-name
               "daselt/d-stump"
               (or (getenv "DASELT_PROJECT_DIR")
                   (expand-file-name "~/proj/d-ext"))))))
       ))

(defun daselt-mode-set-outside-translations ()
  "Fill `daselt-bind-outside-translations-alist' from the remapped-keys bindlist.
The `emacs' section of `remapped-keys-(user-defined-)special.dbl'
says which signals StumpWM delivers instead of the layout keys
\(e.g. the `g' key delivers `C-x' and the key at (1 1 -2)
delivers the low-level `C-g' quit signal).  The binding strings
must be swapped accordingly when the bindlists are applied;
without this, the binding of the `g' position would land on the
literal `C-g' key and hijack the quit switch.

This replaces the setup the old `daselt-stump' package did when
`daselt-stump' is non-nil."
  (interactive)
  (when (bound-and-true-p daselt-stump)
    (let* ((dir (daselt-mode--stump-configs-directory))
           (file (when dir
                   (cl-find-if
                    #'file-exists-p
                    (mapcar (lambda (f) (expand-file-name f dir))
                            '("stumpwm/remapped-keys-user-defined-special.dbl"
                              "stumpwm/remapped-keys-special.dbl"))))))
      (if file
          (let (transconses)
            (dolist (form (daselt-configuration--read-forms-from-file file))
              (when (and (consp form)
                         (equal (daselt-bind-head form) "emacs"))
                (dolist (bind (cdr form))
                  (let ((val (cdr bind)))
                    (push (cons (daselt-bind-string bind)
                                (if (member val daselt-xkb-special-key-names)
                                    (daselt-xkb--format-special-key val)
                                  val))
                          transconses)))))
            (setq daselt-bind-outside-translations-alist
                  (nreverse transconses))
            (when (called-interactively-p 'interactive)
              (message "Outside translations: %S"
                       daselt-bind-outside-translations-alist)))
        (message "Daselt: no remapped-keys bindlist found for the outside translations")))))

;;;; Mode
(define-minor-mode daselt-mode
  "Daselt's minor mode.

Rebinds most keys and revamps Emacs to implement Daselt's shortcut layout.

Note that this assumes you have Daselt installed (most simply using Daselt's
configure script from the repository):

https://codeberg.org/nameiwillforget/d-emacs

During startup, daselt-mode loads the persistent `daselt-configuration'
object, which is kept in the Daselt repository and holds the
per-package configuration, the layout data and the compiled code
of the `.el' files under `mode-configs/'.  When the compiled code
was imported on a different computer, it is re-imported
automatically at startup.  On the first start (or after deleting
the object), the full generation runs and the object is built
from the `mode-configs/' directory; you will be asked to set the
options `daselt-xkb-layout' and `daselt-dfk-keyboard-layout-type'
then, and the `redaselt' shell script is run as specified by
`daselt-mode-redaselt'.

Navigate and edit the configuration with
`daselt-configuration-navigate', the choice interface of the
`ei-interface' package.

When you quit `daselt-mode', all constants are reset. If the option
`daselt-mode-undaselt' is non-nil, the `undaselt' shell-script is run,
resetting the keyboard layout as well."
  :init-value nil
  :global t
  :interactive t
  :lighter " Daselt"
  (if daselt-mode
      (progn
        ;; Just to be sure that `daselt-emacs-dir' is set (if possible).
        (require 'daselt)

        ;; Locate the pkg-configs directory (needed for the tutorial,
        ;; quick keys and importing).
        (daselt-mode--find-pkg-configs-directory)

        ;; `daselt-mode' without translated keys is borderline unusable.
        (setq daselt-bind-translate-keys t)

        ;; Add all files in pkg-configs to the load-path; the
        ;; configuration files require each other through it.
        (let ((default-directory daselt-mode-pkg-configs-directory))
          (normal-top-level-add-to-load-path '("."))
          (normal-top-level-add-subdirs-to-load-path))

        (let ((config (condition-case nil
                          (daselt-configuration-load)
                        (error nil))))
          (when (and config
                     (not (daselt-configuration-layout-current-p config)))
            ;; The layout data is missing (older configuration files)
            ;; or was captured from a different dxkb file.  The full
            ;; generation must run first so there are layouts to
            ;; capture; the import then rebuilds the object.
            (message "Daselt: layout data missing or dxkb file changed; rebuilding")
            (daselt-mode--full-generation)
            (setq config (daselt-configuration-import
                          daselt-mode-pkg-configs-directory)))
          (if config
              ;; *** Fast path: apply the configuration object ***
              (progn
                ;; Re-import the compiled code when it was compiled on
                ;; a different computer or the sources changed.
                (unless (daselt-configuration-code-current-p config)
                  (message "Daselt: compiled code out of date on this computer; re-importing")
                  (daselt-configuration-import-compiled-code config)
                  (daselt-configuration-save config))

                ;; Restore the layout data first: the quick-key
                ;; variables and the bindlist entries translate
                ;; coordinates through it.
                (daselt-configuration--restore-layout-data config)

                ;; The StumpWM outside translations swap binding
                ;; strings like C-g and C-x before the entries are
                ;; applied; without them the quit switch is hijacked.
                (daselt-mode-set-outside-translations)

                ;; Quick-key variables before the entries: bindlist
                ;; values reference them.
                (daselt-mode--generate-quick-key-variables)

                ;; Apply layout data, compiled code and the package
                ;; entries.
                (daselt-configuration-apply config)

                ;; Key translations modify global state; apply them
                ;; again every time.
                (daselt-mode--apply-key-translations)

                ;; Refresh the layout list for the customization UI.
                (daselt-xkb-set-layouts-list)
                (put 'daselt-xkb-layout 'custom-options daselt-xkb-layouts))

            ;; *** First run: full generation and import ***
            (daselt-mode--full-generation)

            ;; The StumpWM outside translations (see the fast path).
            (daselt-mode-set-outside-translations)

            ;; Quick-key variables: bindlist values reference them;
            ;; the layouts are defined now, so coordinates translate.
            (daselt-mode--generate-quick-key-variables)

            ;; Build the configuration object from the pkg-configs
            ;; directory; this also compiles the `.el' files and saves
            ;; the object.
            (setq config (daselt-configuration-import
                          daselt-mode-pkg-configs-directory))

            ;; Apply it (registers the deferred evaluations, makes the
            ;; compiled code effective).
            (daselt-configuration-apply config)))

        ;; Add to emulation
        (if daselt-mode-put-daselt-mode-map-into-emulation
            (add-to-list 'emulation-mode-map-alists
                         `((daselt-mode . ,daselt-mode-map))))

        (if daselt-mode-globalize-daselt-mode-map
            (progn (unless (boundp daselt-global-map-backup)
                     (setq daselt-global-map-backup global-map))
                   (setq global-map daselt-mode-map)))

        (if daselt-mode-show-tutorial (daselt-mode-generate-tutorial t)))
    ;; Remove all eval forms that have been set by `daselt-mode'.
    (daselt-bind--remove-from-after-load-alist)

    ;; Similarly remove hooks.
    (daselt-configuration-remove-hooks)

    ;; Let's also reset all global variables that have been found by the recursion.
    (daselt-configuration-reset-variables)

    ;; Restore the keyboard layout.
    (if daselt-mode-undaselt (daselt-mode-undaselt))))

;;;; Provide
(provide 'daselt-mode)
;;; daselt-mode.el ends here
