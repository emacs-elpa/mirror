;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "1.0.0.20261012.21"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "df3e17f618fcb6867c59e00eb279158b89d5c903"
  :revdesc "df3e17f618fc"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
