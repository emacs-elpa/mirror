;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "riscv-mode" "0.1.0.20220916.6"
  "Major-mode for RISC V assembly."
  '((emacs "24.4"))
  :url "https://github.com/AdamNiederer/riscv-mode"
  :commit "8e335b9c93de93ed8dd063d702b0f5ad48eef6d7"
  :revdesc "8e335b9c93de"
  :keywords '("riscv" "assembly")
  :authors '(("Adam Niederer" . "https://github.com/AdamNiederer")))
