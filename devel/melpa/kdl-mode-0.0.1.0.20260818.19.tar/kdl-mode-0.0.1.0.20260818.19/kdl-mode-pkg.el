;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kdl-mode" "0.0.1.0.20260818.19"
  "Major mode for editing KDL files."
  '((emacs "29.1"))
  :url "https://github.com/taquangtrung/emacs-kdl-mode"
  :commit "c6ef2a0375b1e179c08a2e0f3809d318d8a0c090"
  :revdesc "c6ef2a0375b1"
  :keywords '("languages"))
