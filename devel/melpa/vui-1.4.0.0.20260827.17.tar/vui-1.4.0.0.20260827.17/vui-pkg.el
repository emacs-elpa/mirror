;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "1.4.0.0.20260827.17"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "f010659c6b0173e153f622830a603008a759b014"
  :revdesc "v1.4.0-17-gf010659c6b01"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
