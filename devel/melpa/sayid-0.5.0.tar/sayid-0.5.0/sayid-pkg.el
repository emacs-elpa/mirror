;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "0.5.0"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.23"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "80c11a7fe41508f0baeefff4131d1a3a7ab662b3"
  :revdesc "v0.5.0-0-g80c11a7fe415"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
