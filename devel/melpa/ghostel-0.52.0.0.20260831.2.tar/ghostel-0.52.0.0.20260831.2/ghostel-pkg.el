;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "0.52.0.0.20260831.2"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "e374b7a5442671e88ee4ed70dc3ece15f0261e41"
  :revdesc "e374b7a54426"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
