;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-chat" "0.9.1"
  "Emacs client for Lisp Chat."
  '((emacs     "27.1")
    (websocket "1.12"))
  :url "https://github.com/ryukinix/lisp-chat"
  :commit "066f2a5d4ca2ff50f6a0a1413182e08f17040e3a"
  :revdesc "066f2a5d4ca2"
  :keywords '("comm" "chat" "lisp")
  :authors '(("Manoel V. Machado" . "(manoel_vilela@engineer.com)"))
  :maintainers '(("Manoel V. Machado" . "(manoel_vilela@engineer.com)")))
