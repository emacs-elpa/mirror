;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "f90-ts-mode" "0.3.0.0.20260811.24"
  "Tree-sitter based Fortran 90 mode."
  '((emacs "30.1"))
  :url "https://github.com/mscfd/emacs-f90-ts-mode"
  :commit "6b11fa589cfa5d4830df86ade3c5b050c1f96704"
  :revdesc "v0.3.0-24-g6b11fa589cfa"
  :keywords '("languages" "treesitter" "fortran")
  :authors '(("Martin Stein" . "mscfd@gmx.net"))
  :maintainers '(("Martin Stein" . "mscfd@gmx.net")))
