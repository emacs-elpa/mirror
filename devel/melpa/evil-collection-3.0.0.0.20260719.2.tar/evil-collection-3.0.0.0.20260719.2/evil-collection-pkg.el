;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "3.0.0.0.20260719.2"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "03e1c04b398bc8948a21fac5f3baa4f70da1a350"
  :revdesc "03e1c04b398b"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
