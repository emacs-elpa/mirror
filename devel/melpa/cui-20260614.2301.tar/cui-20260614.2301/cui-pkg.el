;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260614.2301"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "f05e2fbcfbc5cf754168b2beb986ec4d0f63bcc2"
  :revdesc "f05e2fbcfbc5"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
