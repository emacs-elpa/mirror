;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "1.0.2.0.20260826.7"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "d0b3daa538a6aecaadcc7336a0c9f5d03774725e"
  :revdesc "1.0.2-7-gd0b3daa538a6"
  :keywords '("tools" "processes" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
