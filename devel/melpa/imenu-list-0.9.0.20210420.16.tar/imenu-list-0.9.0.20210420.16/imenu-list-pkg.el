;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imenu-list" "0.9.0.20210420.16"
  "Show imenu entries in a separate buffer."
  '((emacs "24.3"))
  :url "https://github.com/bmag/imenu-list"
  :commit "76f2335ee6f2f066d87fe4e4729219d70c9bc70d"
  :revdesc "76f2335ee6f2")
