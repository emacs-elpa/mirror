;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambdapi-mode" "3.0.0.0.20260825.147"
  "A major mode for editing Lambdapi source code."
  '((emacs             "27.1")
    (eglot             "1.6")
    (math-symbol-lists "1.2.1")
    (highlight         "20190710.1527"))
  :url "https://github.com/Deducteam/lambdapi"
  :commit "95ea869762e4467633ab1dc8f61e87cbfb4ac11a"
  :revdesc "3.0.0-147-g95ea869762e4"
  :keywords '("languages")
  :maintainers '(("Deducteam" . "dedukti-dev@inria.fr")))
