;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keyswap" "0.1.1.0.20240717.38"
  "Swap bindings between key pairs."
  '((emacs "25.1"))
  :url "https://github.com/hardenedapple/keyswap.el"
  :commit "d4f9f56a0e6e1365fc7c8ea8d953b8fdffad27fe"
  :revdesc "d4f9f56a0e6e"
  :keywords '("convenience")
  :authors '(("Matthew Malcomson" . "hardenedapple@gmail.com"))
  :maintainers '(("Matthew Malcomson" . "hardenedapple@gmail.com")))
