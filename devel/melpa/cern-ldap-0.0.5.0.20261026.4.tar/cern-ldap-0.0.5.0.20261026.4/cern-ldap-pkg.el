;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cern-ldap" "0.0.5.0.20261026.4"
  "Library to interact with CERN's LDAP servers."
  '((emacs "27.1"))
  :url "https://git.sr.ht/~nbarrientos/cern-ldap.el"
  :commit "4e59da1e886bf77e60416c1c61176a1d8e56a8a6"
  :revdesc "4e59da1e886b"
  :keywords '("tools" "convenience")
  :authors '(("Nacho Barrientos" . "nacho.barrientos@cern.ch"))
  :maintainers '(("Nacho Barrientos" . "nacho.barrientos@cern.ch")))
