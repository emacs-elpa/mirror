;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-chicken" "0.17.0.20250803.5"
  "Chicken's implementation of the geiser protocols."
  '((emacs  "24.4")
    (geiser "0.19"))
  :url "https://gitlab.com/emacs-geiser/chicken"
  :commit "8342bad8ce1c79fee3563cd95ee27a8b062f6a9e"
  :revdesc "8342bad8ce1c"
  :keywords '("languages" "chicken" "scheme" "geiser"))
