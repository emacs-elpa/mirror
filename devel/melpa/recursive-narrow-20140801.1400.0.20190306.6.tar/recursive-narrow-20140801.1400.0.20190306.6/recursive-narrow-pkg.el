;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recursive-narrow" "20140801.1400.0.20190306.6"
  "Narrow-to-region that operates recursively."
  ()
  :url "https://github.com/nflath/recursive-narrow"
  :commit "5e3e2067d5a148d7e64e64e0355d3b6860e4c259"
  :revdesc "5e3e2067d5a1"
  :authors '(("Nathaniel Flath" . "flat0103@gmail.com"))
  :maintainers '(("Nathaniel Flath" . "flat0103@gmail.com")))
