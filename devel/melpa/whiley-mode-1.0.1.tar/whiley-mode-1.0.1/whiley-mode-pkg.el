;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "whiley-mode" "1.0.1"
  "Major mode for Whiley language."
  '((emacs "24.1"))
  :url "https://github.com/Whiley/WhileyEmacsMode"
  :commit "e7cc4759d46be589d421a2235af6771bcde9ae33"
  :revdesc "v1.0.1-0-ge7cc4759d46b"
  :keywords '("languages")
  :authors '(("David J. Pearce" . "dave01001110@gmail.com"))
  :maintainers '(("David J. Pearce" . "dave01001110@gmail.com")))
