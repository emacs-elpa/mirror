;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esxml" "0.3.8.0.20260329.1"
  "Library for working with xml via esxml and sxml."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/tali713/esxml"
  :commit "35940903049f05858d2519c9d8316d00bc228953"
  :revdesc "35940903049f"
  :keywords '("tools" "lisp" "comm")
  :authors '(("Vanya Izaksonas-Smith" . "izak0002atumndotedu")))
