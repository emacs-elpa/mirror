;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toggle-test" "1.0.2"
  "Toggle between source and test files in various programming languages."
  ()
  :url "https://github.com/rags/toggle-test"
  :commit "a0b64834101c2b8b24da365baea1d36e57b069b5"
  :revdesc "a0b64834101c"
  :keywords '("tdd" "test" "toggle" "productivity")
  :authors '(("Raghunandan Rao" . "r.raghunandan@gmail.com"))
  :maintainers '(("Raghunandan Rao" . "r.raghunandan@gmail.com")))
