;;; guava-themes-cordyline-theme.el --- A theme inspired by the ti plant colors -*- lexical-binding: t; -*-

;; Copyright (C) 2025-2026

;; Author: Geralld Borbón <geralldborbon@gmail.com>
;; Created: Jan 12, 2026
;; Keywords: themes, faces, color
;; URL: http://github.com/bormoge/guava-themes
;; Package-Requires: ((emacs "24.1"))
;; SPDX-License-Identifier: GPL-3.0-or-later

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; A theme inspired by the ti plant colors.
;;
;;; Code:

(require 'guava-themes)

(deftheme guava-themes-cordyline "A theme inspired by the ti plant colors.")

(let* (
       (cordyline-class '((class color) (min-colors 257)))
       (cordyline-black                     "#000000")
       (cordyline-white                     "#FFFFFF")

       (cordyline-orange-red                "#ce462c")
       (cordyline-pink-red                  "#df7882")
       (cordyline-pink-purple               "#da70d6")

       (cordyline-light-blue                "#7387e1")
       (cordyline-blue                      "#5064b9")
       (cordyline-alt-blue                  "#2173d5")
       (cordyline-steel-blue                "#4f94cd")
       (cordyline-cyan                      "#00d7d7")
       (cordyline-dark-cyan                 "#008787")

       (cordyline-light-green               "#afd2b9")
       (cordyline-green                     "#007d5f")

       (cordyline-light-purple              "#b46ee6")
       ;; (cordyline-alt-light-purple          "#a29cf1")
       (cordyline-purple                    "#7d5ab9")
       (cordyline-alt-purple                "#785a6e")
       (cordyline-purple-red                "#a03c5a")

       (cordyline-fg-1                      "#FFFFFF")
       (cordyline-fg-2                      "#c3c3c3")
       (cordyline-bg-1                      "#2f212e")
       (cordyline-highlight                 "#3e303d")
       (cordyline-shadow                    "#b3b3b3")
       (cordyline-tooltip                   "#ffffe0")
       (cordyline-region-1                  "#6e1551")
       (cordyline-region-2                  "#00695f")

       (cordyline-error                     "#FF0000")
       (cordyline-warning                   "#f6d909")
       (cordyline-success                   "#23a334")
       (cordyline-change                    "#214bd5")

       (cordyline-mode-line                 "#a03c5a")
       (cordyline-mode-line-inactive        "#5a375a")
       (cordyline-mode-line-modified        "#78A8CD")
       (cordyline-bell                      "#3C8CA0")

       (cordyline-tab-1                     cordyline-mode-line)
       (cordyline-tab-2                     cordyline-mode-line-inactive)
       (cordyline-tab-3                     cordyline-alt-purple)

       (cordyline-fl-comment                cordyline-light-blue)
       (cordyline-fl-string                 cordyline-pink-red)
       (cordyline-fl-keyword                cordyline-purple)
       (cordyline-fl-builtin                cordyline-purple-red)
       (cordyline-fl-type                   cordyline-light-purple)
       (cordyline-fl-function-name          cordyline-pink-purple)
       (cordyline-fl-variable-name          cordyline-blue)
       (cordyline-fl-constant               cordyline-alt-blue)
       (cordyline-fl-warning                cordyline-warning)
       (cordyline-fl-punctuation            cordyline-fg-2)
       (cordyline-fl-negation-char          cordyline-orange-red)

       (cordyline-diff-added                "#5aa05a")
       (cordyline-diff-removed              "#a05a5a")
       (cordyline-diff-refine-added         "#007800")
       (cordyline-diff-refine-removed       "#780000")
       (cordyline-diff-header               "#5a5a5a")
       (cordyline-diff-file-header          "#3c3c3c")
       (cordyline-diff-context              "#828282")
       (cordyline-smerge-base               "#5A5AA0")

       (cordyline-complementary-a-0         "#46C8A5")
       (cordyline-complementary-a-1         "#C84669")

       (cordyline-tetradic-a-0              cordyline-mode-line-modified)
       (cordyline-tetradic-a-1              "#C778CD")
       (cordyline-tetradic-a-2              "#7ECD78")
       (cordyline-tetradic-a-3              "#CD9D78")

       (cordyline-tetradic-b-0              "#A646B9")
       (cordyline-tetradic-b-1              "#59B946")
       (cordyline-tetradic-b-2              "#B96C46")
       (cordyline-tetradic-b-3              "#4693B9"))

  (custom-theme-set-faces
   'guava-themes-cordyline

   ;; built-in faces
   ;; with unique colors

   ;; default
   `(default ((,cordyline-class (:foreground ,cordyline-fg-1 :background ,cordyline-bg-1))))

   ;; error, warning, success
   `(error ((,cordyline-class (:foreground ,cordyline-error :weight bold))))
   `(warning ((,cordyline-class (:foreground ,cordyline-warning :weight bold))))
   `(success ((,cordyline-class (:foreground ,cordyline-success :weight bold))))

   ;; highlight
   `(highlight ((,cordyline-class (:background ,cordyline-highlight))))

   ;; shadow
   `(shadow ((,cordyline-class (:foreground ,cordyline-shadow))))

   ;; tooltip
   `(tooltip ((,cordyline-class (:weight bold :foreground ,cordyline-black :background ,cordyline-tooltip :inherit variable-pitch))))

   ;; region
   `(region ((,cordyline-class (:background ,cordyline-region-1 :extend t))))
   `(secondary-selection ((,cordyline-class (:background ,cordyline-region-2 :extend t))))

   ;; font-lock
   `(font-lock-comment-face ((,cordyline-class (:foreground ,cordyline-fl-comment :weight medium))))
   `(font-lock-string-face ((,cordyline-class (:foreground ,cordyline-fl-string :weight medium))))
   `(font-lock-keyword-face ((,cordyline-class (:foreground ,cordyline-fl-keyword :weight medium))))
   `(font-lock-builtin-face ((,cordyline-class (:foreground ,cordyline-fl-builtin :weight medium))))
   `(font-lock-type-face ((,cordyline-class (:foreground ,cordyline-fl-type :weight medium))))
   `(font-lock-function-name-face ((,cordyline-class (:foreground ,cordyline-fl-function-name :weight medium))))
   `(font-lock-variable-name-face ((,cordyline-class (:foreground ,cordyline-fl-variable-name :weight medium))))
   `(font-lock-constant-face ((,cordyline-class (:foreground ,cordyline-fl-constant :weight medium))))
   `(font-lock-warning-face ((,cordyline-class (:foreground ,cordyline-fl-warning :weight bold))))
   `(font-lock-punctuation-face ((,cordyline-class (:foreground ,cordyline-fl-punctuation :weight medium))))
   `(font-lock-negation-char-face ((,cordyline-class (:foreground ,cordyline-fl-negation-char :weight medium))))

   ;; built-in faces
   ;; with non-unique colors

   ;; cursor
   `(cursor ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-mode-line))))

   ;; fringe
   `(fringe ((,cordyline-class (:foreground ,cordyline-fl-builtin :background ,cordyline-bg-1))))
   `(diff-hl-change ((,cordyline-class (:foreground ,cordyline-change :background ,cordyline-change))))
   `(diff-hl-insert ((,cordyline-class (:foreground ,cordyline-success :background ,cordyline-success))))
   `(diff-hl-delete ((,cordyline-class (:foreground ,cordyline-error :background ,cordyline-error))))

   ;; line-number
   `(line-number ((,cordyline-class (:foreground ,cordyline-fg-1 :inherit default))))
   `(line-number-current-line ((,cordyline-class (:foreground ,cordyline-mode-line :weight bold :inherit (highlight line-number)))))
   `(line-number-minor-tick ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-2 :inherit line-number))))
   `(line-number-major-tick ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-3 :inherit line-number))))

   ;; mode-line
   `(mode-line ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-mode-line
                                               :box ,(if guava-themes-boxed-mode-line
                                                         '(:line-width -1 :style released-button)
                                                       'unspecified)))))
   `(mode-line-inactive ((,cordyline-class (:background ,cordyline-mode-line-inactive :inherit mode-line))))
   `(mode-line-emphasis ((,cordyline-class (:weight bold))))
   `(mode-line-highlight ((,cordyline-class (:foreground unspecified :background unspecified :box (:line-width 2 :color "grey40" :style released-button)))))
   `(guava-themes-visible-bell ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-bell))))

   ;; minibuffer
   `(minibuffer-prompt ((,cordyline-class (:weight bold :foreground ,cordyline-mode-line))))

   ;; borders
   `(vertical-border ((,cordyline-class (:foreground ,cordyline-mode-line))))

   ;; header-line
   `(header-line ((,cordyline-class (:background ,cordyline-tab-1 :inherit mode-line))))
   `(which-func ((,cordyline-class (:weight bold :foreground ,cordyline-mode-line-modified))))

   ;; tab-bar
   `(tab-bar ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-2 :weight bold :inherit mode-line))))
   `(tab-bar-tab ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-1 :inherit tab-bar))))
   `(tab-bar-tab-inactive ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-2 :inherit tab-bar-tab))))

   ;; tab-line
   `(tab-line ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-2 :weight bold :inherit mode-line))))
   `(tab-line-tab ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-2 :inherit tab-line))))
   `(tab-line-tab-current ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-1 :inherit tab-line-tab))))
   `(tab-line-tab-inactive ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-2 :inherit tab-line-tab))))
   `(tab-line-tab-inactive-alternate ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-3 :inherit tab-line-tab))))
   `(tab-line-tab-modified ((,cordyline-class (:foreground ,cordyline-mode-line-modified :weight bold))))
   `(tab-line-tab-special ((,cordyline-class (:slant italic :weight bold))))
   `(tab-line-highlight ((,cordyline-class (:foreground unspecified :background unspecified :box (:line-width 2 :style released-button)))))

   ;; parentheses
   `(show-paren-match ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-bell))))
   `(show-paren-mismatch ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-error :inherit show-paren-match))))

   ;; trailing whitespaces
   `(trailing-whitespace ((,cordyline-class (:background ,cordyline-error))))

   ;; links
   `(link ((,cordyline-class (:foreground ,cordyline-cyan :underline t :weight bold))))
   `(link-visited ((,cordyline-class (:foreground ,cordyline-dark-cyan :underline t :weight bold))))

   ;; outline
   `(outline-1 ((,cordyline-class (:foreground ,cordyline-light-blue :weight medium))))
   `(outline-2 ((,cordyline-class (:foreground ,cordyline-light-purple :weight medium))))
   `(outline-3 ((,cordyline-class (:foreground ,cordyline-alt-blue :weight medium))))
   `(outline-4 ((,cordyline-class (:foreground ,cordyline-purple-red :weight medium))))
   `(outline-5 ((,cordyline-class (:inherit outline-1))))
   `(outline-6 ((,cordyline-class (:inherit outline-2))))
   `(outline-7 ((,cordyline-class (:inherit outline-3))))
   `(outline-8 ((,cordyline-class (:inherit outline-4))))

   ;; homoglyph, escape-glyph, nobreak-space (C-x 8 RET "FORM FEED") (C-x 8 RET "NO-BREAK SPACE")
   `(homoglyph ((,cordyline-class (:foreground ,cordyline-cyan))))
   `(escape-glyph ((,cordyline-class (:inherit homoglyph))))
   `(nobreak-space ((,cordyline-class (:box (:line-width (2 . 2)) :inherit homoglyph))))
   `(nobreak-hyphen ((,cordyline-class (:inherit homoglyph))))

   ;; pulse-highlight-start-face
   ;; M-: (pulse-momentary-highlight-region (point-min) (point-max))
   `(pulse-highlight-start-face ((,cordyline-class (:background ,cordyline-cyan))))

   ;; help-key-binding
   `(help-key-binding ((,cordyline-class (:foreground ,cordyline-cyan :background "grey19" :box (:line-width (-1 . -1) :color "grey35") :inherit fixed-pitch))))

   ;; diff
   `(diff-added ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-diff-added :extend t :inherit diff-changed))))
   `(diff-removed ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-diff-removed :extend t :inherit diff-changed))))
   `(diff-refine-added ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-diff-refine-added :inherit diff-refine-changed))))
   `(diff-refine-removed ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-diff-refine-removed :inherit diff-refine-changed))))
   `(diff-header ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-diff-header :extend t))))
   `(diff-file-header ((,cordyline-class (:weight bold :foreground ,cordyline-white :background ,cordyline-diff-file-header :extend t))))
   `(diff-context ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-diff-context :extend t))))

   ;; smerge
   `(smerge-lower ((,cordyline-class (:extend t :inherit diff-added))))
   `(smerge-upper ((,cordyline-class (:extend t :inherit diff-removed))))
   `(smerge-markers ((,cordyline-class (:extend t :inherit diff-context))))
   `(smerge-refined-added ((,cordyline-class (:extend t :inherit diff-refine-added))))
   `(smerge-refined-removed ((,cordyline-class (:extend t :inherit diff-refine-removed))))
   `(smerge-base ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-smerge-base :extend t))))

   ;; completions
   `(completions-common-part ((,cordyline-class (:foreground ,cordyline-warning :weight bold))))
   `(completions-first-difference ((,cordyline-class (:foreground ,cordyline-error :weight bold))))

   ;; org-faces
   `(org-todo ((,cordyline-class (:foreground ,cordyline-error :weight bold))))
   `(org-done ((,cordyline-class (:foreground ,cordyline-success :weight bold))))
   `(org-hide ((,cordyline-class (:foreground ,cordyline-bg-1))))
   `(org-table ((,cordyline-class (:foreground ,cordyline-light-purple))))
   `(org-table-header ((,cordyline-class (:inverse-video t :inherit org-table))))
   `(org-date ((,cordyline-class (:foreground ,cordyline-orange-red))))
   `(org-date-selected ((,cordyline-class (:foreground unspecified :inverse-video t :inherit org-date))))
   `(org-headline-todo ((,cordyline-class (:foreground ,cordyline-tetradic-b-2))))
   `(org-headline-done ((,cordyline-class (:foreground ,cordyline-tetradic-b-1))))
   `(org-document-title ((,cordyline-class (:inherit font-lock-keyword-face))))
   `(org-document-info-keyword ((,cordyline-class (:inherit shadow))))
   `(org-meta-line ((,cordyline-class (:inherit font-lock-comment-face))))
   `(org-ellipsis ((,cordyline-class (:foreground unspecified :underline nil))))

   ;; window-divider
   `(window-divider ((,cordyline-class (:foreground ,cordyline-tab-3))))
   `(window-divider-first-pixel ((,cordyline-class (:inherit window-divider))))
   `(window-divider-last-pixel ((,cordyline-class (:inherit window-divider))))

   ;; isearch (use "M-x isearch-forward-regexp foo-\([0-9]+\)\([a-z]+\)\([0-9]+\)" to check the group faces)
   `(isearch ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tetradic-b-2))))
   `(isearch-fail ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-error))))
   `(lazy-highlight ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tetradic-b-3))))
   `(isearch-group-1 ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tetradic-b-0))))
   `(isearch-group-2 ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tetradic-b-1))))

   ;; replace (use "M-x occur" to check the match face)
   `(query-replace ((,cordyline-class (:inherit isearch))))
   `(match ((,cordyline-class (:inherit lazy-highlight))))

   ;; re-builder
   `(reb-match-0 ((,cordyline-class (:background ,cordyline-tetradic-b-0 :foreground ,cordyline-white))))
   `(reb-match-1 ((,cordyline-class (:background ,cordyline-tetradic-b-1 :foreground ,cordyline-white))))
   `(reb-match-2 ((,cordyline-class (:background ,cordyline-tetradic-b-2 :foreground ,cordyline-white))))
   `(reb-match-3 ((,cordyline-class (:background ,cordyline-tetradic-b-3 :foreground ,cordyline-white))))

   ;; custom
   ;; (progn (setopt custom-raised-buttons nil) (setq mouse-highlight t))
   `(custom-button ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-mode-line :box (:line-width 2 :style released-button)))))
   `(custom-button-pressed ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-mode-line :box (:line-width 2 :style pressed-button)))))
   `(custom-button-mouse ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-3 :box (:line-width 2 :style released-button)))))
   `(custom-button-unraised ((,cordyline-class (:foreground ,cordyline-mode-line :inherit underline))))
   `(custom-button-pressed-unraised ((,cordyline-class (:foreground ,cordyline-bell :inherit custom-button-unraised))))
   `(custom-comment ((,cordyline-class (:background ,cordyline-tab-3))))
   `(custom-variable-tag ((,cordyline-class (:weight bold :foreground ,cordyline-tab-2))))
   `(custom-group-tag ((,cordyline-class (:height 1.2 :inherit (custom-variable-tag variable-pitch)))))
   `(custom-state ((,cordyline-class (:foreground ,cordyline-fl-keyword))))

   ;; widget
   `(widget-field ((,cordyline-class (:background ,cordyline-tab-3 :box (:line-width (1 . -1) :color "gray46") :extend t))))
   `(widget-single-line-field ((,cordyline-class (:background ,cordyline-tab-3))))

   ;; package
   `(package-status-dependency ((,cordyline-class (:inherit (font-lock-string-face)))))

   ;; icomplete
   `(icomplete-selected-match ((,cordyline-class (:weight bold :foreground ,cordyline-mode-line :inherit (highlight)))))
   `(icomplete-first-match ((,cordyline-class (:weight bold :foreground ,cordyline-mode-line :inherit (highlight)))))

   ;; bookmark
   `(bookmark-face ((,cordyline-class (:foreground ,cordyline-mode-line :distant-foreground unspecified))))
   `(bookmark-menu-bookmark ((,cordyline-class (:weight bold :inherit bookmark-face))))

   ;; flymake
   `(flymake-note ((,cordyline-class (:underline (:style wave :color ,cordyline-success)))))
   `(flymake-warning ((,cordyline-class (:underline (:style wave :color ,cordyline-warning)))))
   `(flymake-error ((,cordyline-class (:underline (:style wave :color ,cordyline-error)))))

   ;; eww
   `(eww-valid-certificate ((,cordyline-class (:weight bold :foreground ,cordyline-success))))
   `(eww-invalid-certificate ((,cordyline-class (:weight bold :foreground ,cordyline-error))))
   ;; Example of eww-form-text: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-text ((,cordyline-class (:foreground ,cordyline-fg-1 :background ,cordyline-tab-3 :box (:line-width 1)))))
   ;; Example of eww-form-file: https://html.com/input-type-file/
   `(eww-form-file ((,cordyline-class (:foreground ,cordyline-fg-1 :background ,cordyline-tab-2 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-select: http://savannah.gnu.org/projects/emacs/
   ;; Example of eww-form-select: https://git.kernel.org/pub/scm/editors/uemacs/uemacs.git/
   `(eww-form-select ((,cordyline-class (:foreground ,cordyline-fg-1 :background ,cordyline-tab-1 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-submit: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-submit ((,cordyline-class (:foreground ,cordyline-fg-1 :background ,cordyline-tab-2 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-checkbox: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-checkbox ((,cordyline-class (:foreground ,cordyline-fg-1 :background ,cordyline-tab-1 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-textarea: https://en.wikipedia.org/w/index.php?title=Main_Page&action=edit
   `(eww-form-textarea ((,cordyline-class (:foreground ,cordyline-fg-1 :background ,cordyline-tab-3 :box (:line-width 1 :color ,cordyline-tab-1)))))


   ;; external packages

   ;; elfeed
   `(elfeed-search-tag-face ((,cordyline-class (:foreground ,cordyline-green))))
   `(elfeed-search-date-face ((,cordyline-class (:foreground ,cordyline-light-blue))))
   `(elfeed-search-feed-face ((,cordyline-class (:foreground ,cordyline-alt-blue))))
   `(elfeed-search-title-face ((,cordyline-class (:foreground ,cordyline-alt-purple))))
   `(elfeed-search-unread-title-face ((,cordyline-class (:weight bold :foreground ,cordyline-purple-red))))
   `(elfeed-search-filter-face ((,cordyline-class (:weight bold :foreground ,cordyline-tetradic-a-1))))
   `(elfeed-search-last-update-face ((,cordyline-class (:weight bold :foreground ,cordyline-tetradic-a-1))))
   `(elfeed-search-unread-count-face ((,cordyline-class (:weight bold :foreground ,cordyline-tetradic-a-1))))

   `(elfeed-show-header-face ((,cordyline-class (:inherit elfeed-search-date-face))))
   `(elfeed-show-author-face ((,cordyline-class (:inherit elfeed-search-unread-title-face))))
   `(elfeed-show-title-face ((,cordyline-class (:inherit elfeed-search-unread-title-face))))
   `(elfeed-show-date-face ((,cordyline-class (:inherit elfeed-search-feed-face))))
   `(elfeed-show-feed-face ((,cordyline-class (:inherit elfeed-search-feed-face))))
   `(elfeed-show-tags-face ((,cordyline-class (:inherit elfeed-search-tag-face))))

   `(elfeed-log-info-level-face ((,cordyline-class (:foreground ,cordyline-success))))
   `(elfeed-log-debug-level-face ((,cordyline-class (:foreground ,cordyline-change))))
   `(elfeed-log-warn-level-face ((,cordyline-class (:foreground ,cordyline-warning))))
   `(elfeed-log-error-level-face ((,cordyline-class (:foreground ,cordyline-error))))

   ;; doom-modeline
   ;; doom-modeline-buffer-file-name-style
   `(doom-modeline-project-name ((,cordyline-class (:foreground ,cordyline-tetradic-a-3 :inherit (doom-modeline bold italic)))))
   `(doom-modeline-project-dir ((,cordyline-class (:foreground ,cordyline-tetradic-a-3 :inherit (doom-modeline bold)))))
   `(doom-modeline-project-root-dir ((,cordyline-class (:foreground ,cordyline-tetradic-a-2 :inherit (doom-modeline bold)))))
   `(doom-modeline-project-parent-dir ((,cordyline-class (:foreground ,cordyline-tetradic-a-2 :inherit (doom-modeline bold)))))
   `(doom-modeline-buffer-minor-mode ((,cordyline-class (:foreground ,cordyline-tetradic-a-1 :inherit (doom-modeline)))))
   `(doom-modeline-buffer-modified ((,cordyline-class (:foreground ,cordyline-tetradic-a-0 :inherit (doom-modeline warning bold)))))
   `(doom-modeline-overwrite ((,cordyline-class (:foreground ,cordyline-tetradic-a-2 :inherit (doom-modeline-urgent)))))

   ;; corfu
   `(corfu-default ((,cordyline-class (:foreground ,cordyline-fg-1 :background ,cordyline-bg-1))))
   `(corfu-current ((,cordyline-class (:foreground unspecified :background unspecified :extend t :inherit highlight))))
   `(corfu-bar ((,cordyline-class (:background ,cordyline-shadow))))
   `(corfu-border ((,cordyline-class (:background ,cordyline-shadow))))

   ;; orderless
   `(orderless-match-face-0 ((,cordyline-class (:foreground ,cordyline-tetradic-b-0 :weight bold))))
   `(orderless-match-face-1 ((,cordyline-class (:foreground ,cordyline-tetradic-b-1 :weight bold))))
   `(orderless-match-face-2 ((,cordyline-class (:foreground ,cordyline-tetradic-b-2 :weight bold))))
   `(orderless-match-face-3 ((,cordyline-class (:foreground ,cordyline-tetradic-b-3 :weight bold))))

   ;; prescient (vertico-prescient-enable-filtering, corfu-prescient-enable-filtering)
   `(prescient-primary-highlight ((,cordyline-class (:foreground ,cordyline-complementary-a-0 :weight bold))))
   `(prescient-secondary-highlight ((,cordyline-class (:foreground ,cordyline-complementary-a-1 :underline t :weight bold))))

   ;; envrc
   `(envrc-mode-line-error-face ((,cordyline-class (:inherit error))))
   `(envrc-mode-line-denied-face ((,cordyline-class (:inherit warning))))
   `(envrc-mode-line-on-face ((,cordyline-class (:inherit success))))
   `(envrc-mode-line-none-face ((,cordyline-class (:inherit warning))))
   `(envrc-mode-line-running-face ((,cordyline-class (:inherit warning))))

   ;; devdocs
   `(devdocs-code-block ((,cordyline-class (:weight bold :background ,cordyline-highlight :extend t))))

   ;; pdf-tools
   `(pdf-view-region ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tetradic-b-3 :inherit region))))

   ;; idle-highlight
   `(idle-highlight ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-fl-builtin :inherit region))))

   ;; keycast
   `(keycast-command ((,cordyline-class (:weight bold))))
   `(keycast-key ((,cordyline-class (:foreground ,cordyline-white :background ,cordyline-tab-3 :box (:line-width -3 :style released-button) :inherit fixed-pitch))))

   ;; nerd-icons
   ;; nerd-icons-completion
   `(nerd-icons-completion-dir-face ((,cordyline-class (:foreground unspecified :inherit font-lock-function-name-face))))))

(provide-theme 'guava-themes-cordyline)

;; Local Variables:
;; no-byte-compile: t
;; End:

;;; guava-themes-cordyline-theme.el ends here
