;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kakapo-mode" "1.2.0.20171004.13"
  "TABS (hard or soft) for indentation (leading whitespace), and SPACES for alignment."
  '((cl-lib "0.5"))
  :url "https://github.com/listx/kakapo-mode"
  :commit "67d516138172fd60782df94454b3d0bd247e84f3"
  :revdesc "v1.2-13-g67d516138172"
  :keywords '("indentation"))
