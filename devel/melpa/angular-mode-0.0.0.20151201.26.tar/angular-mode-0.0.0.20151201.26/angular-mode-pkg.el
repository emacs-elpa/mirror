;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "angular-mode" "0.0.0.20151201.26"
  "Major mode for Angular.js."
  ()
  :url "https://github.com/omouse/angularjs-mode"
  :commit "8720cde86af0f1859ccc8580571e8d0ad1c52cff"
  :revdesc "8720cde86af0"
  :keywords '("languages" "javascript")
  :authors '(("Rudolf Olah" . "omouse@gmail.com"))
  :maintainers '(("Rudolf Olah" . "omouse@gmail.com")))
