;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cherry-blossom-theme" "0.0.2.0.20150622.4"
  "A soothing color theme for Emacs24."
  '((emacs "24.0"))
  :url "https://github.com/inlinestyle/emacs-cherry-blossom-theme"
  :commit "e5ea23694c0f20ab670c0aa87214c27f2232d922"
  :revdesc "e5ea23694c0f"
  :authors '(("Ben Yelsey" . "byelsey1@gmail.com"))
  :maintainers '(("Ben Yelsey" . "byelsey1@gmail.com")))
