;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magic-latex-buffer" "0.4.0.0.20261006.31"
  "Magically enhance LaTeX-mode font-locking for semi-WYSIWYG editing."
  '((cl-lib "0.5")
    (emacs  "25.1"))
  :url "http://zk-phi.github.io/"
  :commit "e80a2b98e714a975ace23790f4278f1fbdd7c258"
  :revdesc "e80a2b98e714")
