;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-json-to-hash" "0.1.0.20211108.4"
  "Convert JSON to Hash and play with the keys."
  '((emacs             "27.2")
    (smartparens       "1.11.0")
    (string-inflection "1.0.16"))
  :url "https://github.com/otavioschwanck/ruby-json-to-hash.el"
  :commit "8e94d8c5ac1732e1f4d09786968b46e14139520c"
  :revdesc "8e94d8c5ac17"
  :keywords '("tools" "languages")
  :authors '(("Otávio Schwanck dos Santos" . "otavioschwanck@gmail.com"))
  :maintainers '(("Otávio Schwanck dos Santos" . "otavioschwanck@gmail.com")))
