;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico-prescient" "6.3.2.0.20260628.2"
  "Prescient.el + Vertico."
  '((emacs     "27.1")
    (prescient "6.1.0")
    (vertico   "0.28")
    (compat    "29.1"))
  :url "https://github.com/radian-software/prescient.el"
  :commit "967087fa547474ab88b72ad543f547fc120129ed"
  :revdesc "967087fa5474"
  :keywords '("extensions")
  :authors '(("Radian LLC" . "contact+prescient@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+prescient@radian.codes")))
