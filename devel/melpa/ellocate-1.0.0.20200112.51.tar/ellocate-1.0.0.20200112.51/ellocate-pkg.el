;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellocate" "1.0.0.20200112.51"
  "The locate command reimplemented in Emacs Lisp."
  '((emacs "25.1")
    (s     "1.12.0")
    (f     "0.20.0"))
  :url "https://github.com/walseb/ellocate"
  :commit "81405082f68f0577c9f176d3d4f034a7142aba59"
  :revdesc "81405082f68f"
  :keywords '("matching")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
