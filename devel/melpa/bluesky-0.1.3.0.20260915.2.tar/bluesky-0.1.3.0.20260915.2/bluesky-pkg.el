;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesky" "0.1.3.0.20260915.2"
  "A Bluesky client."
  '((emacs "30.1")
    (plz   "0.9.0")
    (futur "1.7")
    (vui   "1.0.0"))
  :url "https://github.com/ahyatt/emacs-bluesky"
  :commit "86e33aa4923f15d0fb899b25921e5691364335d2"
  :revdesc "86e33aa4923f"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
