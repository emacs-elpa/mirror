;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fiplr" "0.2.4.0.20140724.18"
  "Fuzzy finder for files in a project."
  ()
  :url "https://github.com/d11wtq/fiplr"
  :commit "bb6b90ba3c558988c195048c4c40140b2ee17530"
  :revdesc "0.2.4-18-gbb6b90ba3c55"
  :keywords '("convenience" "usability" "project")
  :authors '(("Chris Corbyn" . "chris@w3style.co.uk"))
  :maintainers '(("Chris Corbyn" . "chris@w3style.co.uk")))
