;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sail" "0.1.0.0.20260209.2"
  "NOAA tide and wind reports for sailors."
  '((emacs "25.1"))
  :url "https://github.com/brannala/esail"
  :commit "1cc38e174139dfb4732cfb5eb597829a982e1e99"
  :revdesc "1cc38e174139"
  :keywords '("comm")
  :authors '(("Bruce Rannala" . "brannala@ucdavis.edu"))
  :maintainers '(("Bruce Rannala" . "brannala@ucdavis.edu")))
