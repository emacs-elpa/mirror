;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ruby-text-objects" "0.2.0.0.20240411.7"
  "Evil text objects for Ruby code."
  '((emacs "25.1")
    (evil  "1.2.0"))
  :url "https://github.com/porras/evil-ruby-text-objects"
  :commit "de138b3279817484d1d34ca5b293af09e00a4e1a"
  :revdesc "de138b327981"
  :keywords '("languages")
  :authors '(("Sergio Gil" . "sgilperez@gmail.com"))
  :maintainers '(("Sergio Gil" . "sgilperez@gmail.com")))
