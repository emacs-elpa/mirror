;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "io-mode" "20100405.0.20161004.20"
  "Major mode to edit Io language files in Emacs."
  ()
  :url "https://github.com/superbobry/io-mode"
  :commit "fd65ae769093defcf554d6d637eba6e6dfc29f56"
  :revdesc "fd65ae769093"
  :keywords '("languages" "io")
  :authors '(("Sergei Lebedev" . "superbobry@gmail.com"))
  :maintainers '(("Sergei Lebedev" . "superbobry@gmail.com")))
