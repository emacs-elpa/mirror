;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "less-css-mode" "0.21"
  "Major mode for editing LESS CSS files (lesscss.org)."
  ()
  :url "https://github.com/purcell/less-css-mode"
  :commit "59bf174c4e9f053ec2a7ef8c8a8198490390f6fb"
  :revdesc "59bf174c4e9f"
  :keywords '("less" "css" "mode")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
