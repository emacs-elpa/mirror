;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wotd" "0.1.0.0.20170328.2"
  "Fetch word-of-the-day from multiple online sources."
  '((emacs "24.4")
    (org   "8.2.10"))
  :url "https://github.com/cute-jumper/emacs-word-of-the-day"
  :commit "d2937a3d91e014f8028a1f33d21c18cc0b065a64"
  :revdesc "d2937a3d91e0"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
