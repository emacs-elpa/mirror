;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-prettify-mode" "1.0.0.20260429.19"
  "Hide `if err != nil' and prettify them."
  '((emacs "28.1"))
  :url "https://codeberg.org/snyssfx/go-prettify-mode.el"
  :commit "446907afa83d749dbd0a610d1d6fea6bbb822335"
  :revdesc "446907afa83d"
  :keywords '("languages" "go" "tools")
  :authors '(("Gleb Zakharov" . "snyssfx@posteo.net"))
  :maintainers '(("Gleb Zakharov" . "snyssfx@posteo.net")))
