;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-chrome-history" "0.0.0.20191031.14"
  "Browse Chrome History with Helm."
  '((emacs     "25.1")
    (helm-core "3.0"))
  :url "https://github.com/xuchunyang/helm-chrome-history"
  :commit "f9002d4c12df65a99830376b126dbbeae3ef2148"
  :revdesc "f9002d4c12df"
  :keywords '("tools")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
