;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "4.5.3.0.20260815.2"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "728cc43a4c555656f8884cd43f17bfd2c68f7012"
  :revdesc "v4.5.3-2-g728cc43a4c55"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
