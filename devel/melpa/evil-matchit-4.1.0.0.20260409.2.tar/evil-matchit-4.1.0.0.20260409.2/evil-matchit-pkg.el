;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-matchit" "4.1.0.0.20260409.2"
  "Vim matchit ported to Evil."
  '((emacs "27.1"))
  :url "https://github.com/redguardtoo/evil-matchit"
  :commit "751e74ce2e29c3f32b30e6a1012a33fe81ba0700"
  :revdesc "751e74ce2e29"
  :keywords '("matchit" "vim" "evil")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
