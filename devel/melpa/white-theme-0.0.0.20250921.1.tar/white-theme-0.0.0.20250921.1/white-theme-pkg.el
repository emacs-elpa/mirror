;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "white-theme" "0.0.0.20250921.1"
  "Minimalistic light color theme inspired by basic-theme."
  '((emacs "24"))
  :url "https://github.com/nullvec/white-theme.el"
  :commit "7c42cb08425ac7f7e33e8d947a950a55dee3fadf"
  :revdesc "7c42cb08425a"
  :keywords '("color" "theme" "minimal" "basic" "simple" "white")
  :authors '(("A. Hdez" . "trefoil_chilled_7k@icloud.com"))
  :maintainers '(("A. Hdez" . "trefoil_chilled_7k@icloud.com")))
