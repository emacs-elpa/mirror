;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "4.5.0.20261103.335"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "70696abaff29def0c17d7a740806b1687dba3153"
  :revdesc "v4.5-335-g70696abaff29"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
