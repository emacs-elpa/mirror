;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "0.2.4"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "e5b30eb5e3f8712f156822158e2c8cc782eb5c7f"
  :revdesc "e5b30eb5e3f8"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
