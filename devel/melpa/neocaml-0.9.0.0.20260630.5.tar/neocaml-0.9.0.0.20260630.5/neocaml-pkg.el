;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "0.9.0.0.20260630.5"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "1a7296c616075a7b090d662991fb9aa5ef718726"
  :revdesc "1a7296c61607"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
