;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-x" "0.2.0.0.20260820.4"
  "Extended flex completion style."
  '((emacs "30.1"))
  :url "https://github.com/kn66/flex-x"
  :commit "1ba9e9da6819dc426cae91db4f0c79cc8e411cbe"
  :revdesc "1ba9e9da6819"
  :keywords '("convenience" "matching")
  :authors '(("kn66" . "https://github.com/kn66"))
  :maintainers '(("kn66" . "https://github.com/kn66")))
