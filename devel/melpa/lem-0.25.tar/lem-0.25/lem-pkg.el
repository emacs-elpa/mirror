;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lem" "0.25"
  "A lemmy client."
  '((emacs         "29.1")
    (fedi          "0.2")
    (markdown-mode "2.5"))
  :url "https://codeberg.org/martianh/lem.el"
  :commit "3abd1604c3ab9451dcbc087099c499e6dc8882d7"
  :revdesc "3abd1604c3ab"
  :keywords '("multimedia" "comm" "web" "fediverse")
  :authors '(("martian hiatus" . "martianh@disroot.org"))
  :maintainers '(("martian hiatus" . "martianh@disroot.org")))
