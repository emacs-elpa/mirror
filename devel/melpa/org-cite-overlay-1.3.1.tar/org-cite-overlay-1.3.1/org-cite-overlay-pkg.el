;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-cite-overlay" "1.3.1"
  "Overlays for org-cite citations."
  '((emacs    "29.1")
    (citeproc "0.9.4"))
  :url "https://git.sr.ht/~swflint/org-cite-overlay"
  :commit "a5b8953f7f6788f025cd6e6f6ce5a9f32ad5408d"
  :revdesc "a5b8953f7f67"
  :keywords '("bib" "tex")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
