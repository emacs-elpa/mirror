;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "3.0.2"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "bce35101edcfe5ddccff270608ab71859fa90040"
  :revdesc "3.0.2-0-gbce35101edcf"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
