;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trust-manager" "0.4.0.0.20260723.4"
  "Convenient trust management."
  '((emacs "30.1"))
  :url "https://git.sr.ht/~eshel/trust-manager"
  :commit "e5aaceac51c06c496e64ff10408c9ee84585746f"
  :revdesc "v0.4.0-4-ge5aaceac51c0"
  :keywords '("security" "trust" "files")
  :authors '(("Eshel Yaron" . "me@eshelyaron.com"))
  :maintainers '(("Eshel Yaron" . "me@eshelyaron.com")))
