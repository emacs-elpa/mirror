;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-tbdiff" "1.2.0.0.20260811.8"
  "Magit extension for range diffs."
  '((emacs "26.1")
    (magit "4.0.0"))
  :url "https://github.com/magit/magit-tbdiff"
  :commit "62e2c726a26eb7b8c39048e091062d206610649d"
  :revdesc "v1.2.0-8-g62e2c726a26e"
  :keywords '("vc" "tools")
  :authors '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainers '(("Kyle Meyer" . "kyle@kyleam.com")))
