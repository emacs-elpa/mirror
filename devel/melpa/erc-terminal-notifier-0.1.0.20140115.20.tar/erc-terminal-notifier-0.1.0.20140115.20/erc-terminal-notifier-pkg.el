;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-terminal-notifier" "0.1.0.20140115.20"
  "OSX notifications via the terminal-notifier gem for Emacs ERC."
  ()
  :url "https://github.com/julienXX/"
  :commit "a3dacb935845e4a20031212bbd82b2170f68d2a8"
  :revdesc "a3dacb935845"
  :keywords '("erc" "terminal-notifier" "nick")
  :authors '(("Julien Blanchard" . "julien@sideburns.eu"))
  :maintainers '(("Julien Blanchard" . "julien@sideburns.eu")))
