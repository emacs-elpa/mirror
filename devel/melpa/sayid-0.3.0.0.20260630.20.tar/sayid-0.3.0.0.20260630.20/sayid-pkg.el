;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "0.3.0.0.20260630.20"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.0"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "e895d5799a6fe7bcb63f6d5979cf9b7c6b9e1883"
  :revdesc "v0.3.0-20-ge895d5799a6f"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
