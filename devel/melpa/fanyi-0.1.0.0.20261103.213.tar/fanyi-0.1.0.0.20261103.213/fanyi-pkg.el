;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fanyi" "0.1.0.0.20261103.213"
  "Not only English-Chinese translator."
  '((emacs "29.1"))
  :url "https://github.com/condy0919/fanyi.el"
  :commit "986a5d9cc01873a7acdc8e6e0260fbe54480144b"
  :revdesc "986a5d9cc018"
  :keywords '("convenience" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
