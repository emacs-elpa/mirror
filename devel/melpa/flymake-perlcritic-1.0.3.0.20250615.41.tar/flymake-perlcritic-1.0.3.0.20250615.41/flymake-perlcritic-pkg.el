;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-perlcritic" "1.0.3.0.20250615.41"
  "Flymake handler for Perl to invoke Perl::Critic."
  '((flymake "1.2"))
  :url "https://github.com/illusori/emacs-flymake-perlcritic"
  :commit "311743e97d2f705e76755697eea9ff451a39dd64"
  :revdesc "311743e97d2f"
  :authors '(("Sam Graham" . "libflymake-perlcritic-emacsBLAHBLAHillusori.co.uk")
             ("gemmaro" . "gemmaro.dev@gmail.com"))
  :maintainers '(("Sam Graham" . "libflymake-perlcritic-emacsBLAHBLAHillusori.co.uk")))
