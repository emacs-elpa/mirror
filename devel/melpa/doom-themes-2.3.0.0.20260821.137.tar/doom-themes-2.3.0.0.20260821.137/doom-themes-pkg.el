;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-themes" "2.3.0.0.20260821.137"
  "An opinionated pack of modern color-themes."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/doomemacs/themes"
  :commit "d114523c4c436d899170afe9ea9b99cd214c344f"
  :revdesc "v2.3.0-137-gd114523c4c43"
  :keywords '("themes" "faces")
  :authors '(("Henrik Lissner" . "contact@henrik.io"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
