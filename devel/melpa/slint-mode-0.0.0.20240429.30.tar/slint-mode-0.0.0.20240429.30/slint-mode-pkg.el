;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slint-mode" "0.0.0.20240429.30"
  "Major-mode for the Slint UI language."
  '((emacs "24.4"))
  :url "https://github.com/nilclass/slint-mode"
  :commit "168a6cfb90b5e36360074c83f80d5bbac2f0287e"
  :revdesc "168a6cfb90b5"
  :keywords '("languages")
  :authors '(("Niklas Cathor" . "niklas.cathor@gmx.de"))
  :maintainers '(("Niklas Cathor" . "niklas.cathor@gmx.de")))
