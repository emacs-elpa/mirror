;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jal" "2.0.0"
  "Java Agent Loader (JAL) for JDTLS."
  '((emacs "28.1"))
  :url "https://github.com/saulotoledo/java-agent-loader"
  :commit "54cbd7a6b613dc6ac2135ada9de47130e0665d3e"
  :revdesc "54cbd7a6b613"
  :keywords '("java" "languages" "tools")
  :authors '(("Saulo Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo Toledo" . "saulotoledo@gmail.com")))
