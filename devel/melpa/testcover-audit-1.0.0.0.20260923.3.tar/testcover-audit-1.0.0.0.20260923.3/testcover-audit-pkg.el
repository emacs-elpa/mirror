;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "testcover-audit" "1.0.0.0.20260923.3"
  "Quantitative coverage statistics for testcover.el."
  '((emacs   "27.1")
    (project "0.9.8"))
  :url "https://github.com/OverbearingPearl/testcover-audit"
  :commit "e910fa6ee162a99cf47644ce945519ae60acb0f5"
  :revdesc "e910fa6ee162"
  :keywords '("tools")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
