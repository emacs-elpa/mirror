;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-biome" "0.1.0.0.20241007.4"
  "A flymake plugin for Javascript files using biome."
  '((emacs "27.1"))
  :url "https://github.com/erickgnavar/flymake-biome"
  :commit "03fa55d23fdc80fb4bc963cd144da460e7da0220"
  :revdesc "03fa55d23fdc"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
