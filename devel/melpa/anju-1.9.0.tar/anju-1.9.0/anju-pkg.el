;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "1.9.0"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "b495fb0c53bd8e431b1a40c6fa027c38fc130b49"
  :revdesc "b495fb0c53bd"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
