;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zeno-theme" "20180211.1557.0.20211205.12"
  "A dark theme using different shades of blue."
  '((emacs "24"))
  :url "https://github.com/jbharat/zeno-theme"
  :commit "70fa7b7442f24ea25eab538b5a22da690745fef5"
  :revdesc "70fa7b7442f2"
  :keywords '("faces" "theme" "dark" "blue")
  :authors '(("Bharat Joshi" . "jbharat@outlook.com"))
  :maintainers '(("Bharat Joshi" . "jbharat@outlook.com")))
